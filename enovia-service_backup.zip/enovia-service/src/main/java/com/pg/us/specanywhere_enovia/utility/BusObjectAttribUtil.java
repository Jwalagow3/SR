
/**
 * Project : SpecsAnyWhere
 * Author  : Infosys
 * Program : BusObjectAttribUtil
 * Description: Helper Class 
 * 
 */

package com.pg.us.specanywhere_enovia.utility;


import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Vector;

import javax.naming.CommunicationException;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.security.core.GrantedAuthority;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.domain.util.mxType;
import com.matrixone.apps.framework.lifecycle.LifeCyclePolicyDetails;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.bo.MCPBO;
import com.pg.us.specanywhere_enovia.bo.OnlinePrintingPartBO;
import com.pg.us.specanywhere_enovia.bo.PQRBO;
import com.pg.us.specanywhere_enovia.bo.PackagingAssemblyPart;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PackingSubassemblyBO;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.fop.FormulationAttribute;
import com.pg.us.specanywhere_enovia.fop.FormulationRelationship;
import com.pg.us.specanywhere_enovia.fop.FormulationSubstituteConstants;
import com.pg.us.specanywhere_enovia.fop.FormulationType;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaVendorSpecsServiceImpl;

import matrix.db.AttributeType;
import matrix.db.AttributeTypeList;
import matrix.db.BusinessInterface;
import matrix.db.BusinessInterfaceItr;
import matrix.db.BusinessInterfaceList;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.Group;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.Role;
import matrix.db.State;
import matrix.db.StateList;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

import java.util.Base64;
import java.util.regex.*;

public class BusObjectAttribUtil {
	StringValidatorUtil util = new StringValidatorUtil();
	private static Logger LOGGER = Logger.getLogger(BusObjectAttribUtil.class);
	private  Environment env;

	public BusObjectAttribUtil() {

	}

	/**
	 * Part basic selects
	 * 
	 * @return
	 */
	public static StringList getPartSpecSelects() {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		// SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY);
		busSelect.add(ConstantsUtil.strPARTSPEC);
		// SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.STR_AUTOCADIPCLASS);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		// SPEC: 10/30/2020: Added for Defect 36711 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYDESCRIPTION);
		busSelect.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
		// SPEC: 10/30/2020: Added for Defect 36711 -- END

		busSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		busSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		return busSelect;
	}

	/**
	 * Basic Bus Selects
	 * 
	 * @param context
	 * @return
	 */

	public static StringList getBasicInfoBusSelectable(Context context) {
		StringList busSelect = new StringList(15);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.TYPE_KIND_OF);
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_POLICY);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_VAULT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM);
		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE); // For EBP
		// User
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE); // For
		// EBP
		// User
		//modified by Ganesh for defect 38712 -----> Start
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);	
		//modified by Ganesh for defect 38712 -----> end
		//SPEC: Release SR18x.5.2 - Added for Defect# 37166  by gaikwad.tg on Date 19 Feb 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
		//SPEC: Release SR18x.5.2 - Added for Defect# 37166  by gaikwad.tg on Date 19 Feb 2021 -- END
		//SPEC: 22-08-2022: Pooja added for Internal Defect -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		//SPEC: 22-08-2022: Pooja added for Internal Defect -- END
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL);
		//Added by Ketan for Req. no. 46464 - START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCONSUMERPACKFAMILY);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCONSUMERPRIMARYPACKAGINGTYPE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCONSUMERSECONDARYPACKAGINGTYPE);
		//Added by Ketan for Req. no. 46464 - END
		//Added by Ajay for Req. no. 99576 - START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEPHARMACOPEIA);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSMATERIALGRADE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSFREETEXT);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEFREETEXT);
		//Added by Ajay for Req. no. 99576 - END
		return busSelect;
	}

	/**
	 * Transport unit char selectables
	 * 
	 * @param context
	 * @return
	 */
	public static StringList getTUPCharSelectables(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFICIENCY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_REF_DOC_TONAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER);

		return busSelect;
	}

	/**
	 * Packing Unit selectables
	 * 
	 * @param context
	 * @return
	 */
	public static StringList getPackingUnitSelectables(Context context) {
		StringList busSelect = new StringList(25);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDEPTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFICIENCY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);

		return busSelect;
	}

	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}

	public void formatDataWithAndSymbol(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_AND);
	}
	
	public Map<String, String> parsePUMaplist(MapList mapList, boolean isPU) {
		Map<String, String> mpPackingUnit = new HashMap<String, String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbPackingType = new StringBuilder();
		StringBuilder sbAuom = new StringBuilder();
		StringBuilder sbGtin = new StringBuilder();
		StringBuilder sbDepth = new StringBuilder();
		StringBuilder sbWidth = new StringBuilder();
		StringBuilder sbHeight = new StringBuilder();
		StringBuilder sbUom = new StringBuilder();
		StringBuilder sbGrossWtUom = new StringBuilder();
		StringBuilder sbGrossWt = new StringBuilder();
		StringBuilder sbNumberOfCopPerUnit = new StringBuilder();
		StringBuilder sbNetWt = new StringBuilder();
		StringBuilder sbUom1 = new StringBuilder();
		StringBuilder sbDimUom = new StringBuilder();

		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			String strType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
			if (!isPU && ConstantsUtil.TYPE_PGTRANSPORTUNITCHARACTERISTIC.equals(strType)) {
				continue;
			}

			//SPEC: <08-24-2021>: Sanjeeva Commented for Stress Testing Defect 44365  -- START
			//String sPackingType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			//SPEC: <08-24-2021>: Sanjeeva Commented for Stress Testing Defect 44365  -- END
			String sGtin = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);
			/*
			 * String sDepth =
			 * (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDEPTH);
			 * String sWidth
			 * =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWIDTH);
			 * String sHeight
			 * =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEIGHT);
			 */
			// String sNumCopPerUnit
			// =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT);
			//SPEC: <08-24-2021>: Sanjeeva Commented for Stress Testing Defect 44365  -- START
			//String sDimUom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUNITOFMEASURE);
			//SPEC: <08-24-2021>: Sanjeeva Commented for Stress Testing Defect 44365  -- END
			formatData(sbGtin, sGtin);
			/*
			 * formatData(sbDepth,sDepth); formatData(sbWidth,sWidth);
			 * formatData(sbHeight,sHeight);
			 */
			// formatData(sbNumberOfCopPerUnit,sNumCopPerUnit);
			// formatData(sbDimUom,sDimUom);
		}
		mpPackingUnit.put(ConstantsUtil.GTIN, sbGtin.toString());
		/*
		 * mpPackingUnit.put(ConstantsUtil.DEPTH, sbDepth.toString());
		 * mpPackingUnit.put(ConstantsUtil.WIDTH, sbWidth.toString());
		 * mpPackingUnit.put(ConstantsUtil.HEIGHT, sbHeight.toString());
		 */
		mpPackingUnit.put(ConstantsUtil.GROSSWEIGHT, sbGrossWt.toString());
		// mpPackingUnit.put(ConstantsUtil.NUMBEROFCONSUMERUNITSPERUNIT,
		// sbNumberOfCopPerUnit.toString());
		mpPackingUnit.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCONSUMERUNIT, sbNetWt.toString());
		// mpPackingUnit.put(ConstantsUtil.DIMENSIONUNITOFMEASURE,
		// sbDimUom.toString());

		return filterMapList(mpPackingUnit);
	}

	public Map<String, String> parseMaplist(Context context, MapList mapList) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership = filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();

		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState = new StringBuilder();
		StringBuilder sbEBOMStage = new StringBuilder();
		StringBuilder sbEBOMRDOC = new StringBuilder();
		StringBuilder sbEBOMRevRelDt = new StringBuilder();
		StringBuilder sbEBOMTupName = new StringBuilder();

		// SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		// SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END

		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
			String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
			String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
			String sReleaseDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
			String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON + sReleaseDate;
			String spgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
			String sFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
			String sTupName = (String) objectMap.get(ConstantsUtil.TUPNAME);
			sType = mapType(sType);
			
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
			String sParentId = (String) objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID);
			String sParentName = (String) objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME);
			String sParentRevision = (String) objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV);
			String sParentType = (String) objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE);
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
			
			// Removed as part of 18X.5 --START
			/*
			 * String sSubstitute = (String)
			 * objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE); sSubstitute =
			 * replaceSpecialSymbols(sSubstitute);
			 */
			// Removed as part of 18X.5 --END

			// SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			String strSubPart = validator.getStringEquivalentForStringListWithComma(
					objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			strSubPart = strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(
					objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			strSubPartType = strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartId = checkSubstituteHasAccess(context, objectMap);
			// SPEC: <10.20.2020>: Added for req 18x.5 ## -- END

			String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			String sBuom = validator.getStringEquivalentForStringList(
					objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
			String sComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
			sCurrent = mapType(sCurrent);
			String sStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
			sRD = replaceSpecialSymbols(sRD);
			String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
			sOC = replaceSpecialSymbols(sOC);
			String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
			String strClassFied = validator
					.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));

			boolean bHasOwnership = false;
			boolean showData = false;
			boolean bHasOwnershipParent = false;
			boolean showDataParent = false;
			if (isModificatinRequired()) {
				// Formulation part does not have ownership on itself, hence
				// expand to get it from the Cosmetic formulation
				/*
				 * if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)
				 * ) { String sFormulaPropagate = getFormulaPropagate(context,
				 * sId); if(!sFormulaPropagate.isEmpty()) { bHasOwnership =
				 * checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
				 * }
				 * 
				 * }else { bHasOwnership = checkOwnerShip(context,
				 * slUserOwnership, sId); }
				 */
				// Added by Ganesh start
				bHasOwnership = checkHasAccess(context, null, sId);
				// Added by Ganesh stop

				if (!bHasOwnership) {
					sId = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;					
				}
				bHasOwnershipParent=checkHasAccess(context, null, sParentId);
				if(!bHasOwnershipParent) {
					sParentId = ConstantsUtil.NO_ACCESS;
				}
			} else if (sec.isStaffAUGUser()) {
				showData = checkHasAccess(context, null, sId);
				showDataParent=checkHasAccess(context, null, sParentId);
			} else {
				showData = checkHasAccess(context, null, sId);
				showDataParent=checkHasAccess(context, null, sParentId);
			}
			if(!isModificatinRequired()) {
				if (!showData) {
					sId = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
				}
				if(!showDataParent) {
					sParentId = ConstantsUtil.NO_ACCESS;
				}
			}
			sParentType = mapType(sParentType);

			formatData(sbEBOMName, sName);
			formatData(sbEBOMId, sId);
			formatData(sbEBOMChg, spgChg);
			formatData(sbEBOMFN, sFN);
			formatData(sbEBOMTitle, sTitle);
			formatData(sbEBOMType, sType);
			formatData(sbEBOMQTY, sQty);
			formatData(sbEBOMBuom, sBuom);
			formatData(sbEBOMCommnts, sComments);
			formatData(sbEBOMState, sCurrent);
			formatData(sbEBOMStage, sStage);
			formatData(sbEBOMRDOC, sRDOC);
			formatData(sbEBOMRevRelDt, sRevRelease);
			
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
			formatData(sbEBOMParentId,sParentId);
			formatData(sbEBOMParentName,sParentName);
			formatData(sbEBOMParentRevision,sParentRevision);
			formatData(sbEBOMParentType,sParentType);
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END

			// SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
			formatData(sbEBOMSubstitutePart, strSubPart);
			formatData(sbEBOMSubPartID, strSubPartId);
			formatData(sbEBOMSubPartType, strSubPartType);
			// SPEC: <10.13.2020>: Added for req 18x.5 ## -- END

			if (null != sTupName && !sTupName.isEmpty()) {
				formatData(sbEBOMTupName, sTupName);
			}

		}
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());

		// SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		// SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END

		if (null != sbEBOMTupName && sbEBOMTupName.length() > 0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		// return filterMapList(mpEBOMResult);

		return mpEBOMResult;
	}

	public Map<String, String> parseTUPMaplist(Context context, MapList mapList, StringList slTupName,
			StringList slTupId) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership = filterOwnerShip(sComp);
		try {
			// String strTupName = sbTupName.toString();
			if (mapList.size() > 0) {
				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMFN = new StringBuilder();
				StringBuilder sbEBOMTitle = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMQTY = new StringBuilder();
				StringBuilder sbEBOMBuom = new StringBuilder();
				StringBuilder sbEBOMCommnts = new StringBuilder();
				StringBuilder sbEBOMState = new StringBuilder();
				StringBuilder sbEBOMStage = new StringBuilder();
				StringBuilder sbEBOMRDOC = new StringBuilder();
				StringBuilder sbEBOMSubstute = new StringBuilder();
				StringBuilder sbEBOMRevRelDt = new StringBuilder();
				StringBuilder sbTupName = new StringBuilder();
				StringBuilder sbTupId = new StringBuilder();
				StringBuilder sbTupType = new StringBuilder();
				StringValidatorUtil validator = new StringValidatorUtil();
				for (int i = 0; i < mapList.size(); i++) {
					MapList mleach = (MapList) mapList.get(i);
					Iterator objectListItr = mleach.iterator();
					while (objectListItr.hasNext()) {
						Map objectMap = (Map) objectListItr.next();
						String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
						String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
						String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
						String sReleaseDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
						String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON + sReleaseDate;
						String spgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
						String sFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
						String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
						String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sTupName = "";
						sType = mapType(sType);
						String sSubstitute = (String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
						sSubstitute = replaceSpecialSymbols(sSubstitute);
						String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
						String sBuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
						String sComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
						String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
						sCurrent = mapType(sCurrent);
						String sStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
						String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
						sRD = replaceSpecialSymbols(sRD);
						String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
						sOC = replaceSpecialSymbols(sOC);
						String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
						sbTupName.append(slTupName.get(i).toString()).append(ConstantsUtil.SYMBL_PIPE);
						sbTupId.append(slTupId.get(i).toString()).append(ConstantsUtil.SYMBL_PIPE);
						sbTupType.append(mapType(ConstantsUtil.TYPE_PGTRANSPORTUNITPART)).append(ConstantsUtil.SYMBL_PIPE);
						String strClassFied = validator
								.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));

						boolean bHasOwnership = false;

						String sFormulaPropagate = sId;
						if (isModificatinRequired()) {

							// Formulation part does not have ownership on itself,
							// hence expand to get it from the Cosmetic formulation
							if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaPropagate = getFormulaPropagate(context, sId);
							}

							if (!sFormulaPropagate.isEmpty()) {
								// modified by Ganesh for security impl---->start
								// bHasOwnership = checkOwnerShip(context,
								// slUserOwnership, sFormulaPropagate);
								bHasOwnership = checkHasAccess(context, null, sId);
								// modified by Ganesh for security impl---->start
							}
							if (!bHasOwnership) {
								sId = ConstantsUtil.NO_ACCESS;
								sRevision = ConstantsUtil.NO_ACCESS;
								sReleaseDate = ConstantsUtil.NO_ACCESS;
								sRevRelease = ConstantsUtil.NO_ACCESS;
								sTitle = ConstantsUtil.NO_ACCESS;
								spgChg = ConstantsUtil.NO_ACCESS;
								sFN = ConstantsUtil.NO_ACCESS;
								sTupName = ConstantsUtil.NO_ACCESS;
								sSubstitute = ConstantsUtil.NO_ACCESS;
								sQty = ConstantsUtil.NO_ACCESS;
								sBuom = ConstantsUtil.NO_ACCESS;
								sComments = ConstantsUtil.NO_ACCESS;
								sCurrent = ConstantsUtil.NO_ACCESS;
								sStage = ConstantsUtil.NO_ACCESS;
								sRDOC = ConstantsUtil.NO_ACCESS;

							}
						} else {
							// commented by Ganesh for security impl----->start
							/*
							 * StringList slHIRTypes = new StringList();
							 * 
							 * slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
							 * slHIRTypes.add(ConstantsUtil.
							 * TYPE_ASSEMBLEDPRODUCTPART);
							 * slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
							 * slHIRTypes.add(ConstantsUtil.
							 * TYPE_INTERMEDIATE_PRODUCT_PART);
							 * slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT
							 * );
							 * 
							 * boolean showData = true;
							 * if(slHIRTypes.contains(sType) ){
							 * 
							 * String sFormulaClassif =strClassFied;
							 * 
							 * if(!sec.isExternalUser()){ String sUserlicense =
							 * sec.getUserLicense();
							 * 
							 * if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART))
							 * { sFormulaClassif =
							 * getFormulaPropagateClassification(context, sId); }
							 * if(null!=sUserlicense && null!=sFormulaClassif &&
							 * !sUserlicense.contains(sFormulaClassif)) {
							 * showData=false; } }
							 */// commented by Ganesh for security impl----->end
							// modified by Ganesh for security impl----->start
							boolean showData = checkHasAccess(context, null, sId);
							// modified by Ganesh for security impl----->end

							if (!showData) {

								sId = ConstantsUtil.NO_ACCESS;
								spgChg = ConstantsUtil.NO_ACCESS;
								/*
								 * sRevision = ConstantsUtil.NO_ACCESS; sReleaseDate
								 * = ConstantsUtil.NO_ACCESS; sRevRelease =
								 * ConstantsUtil.NO_ACCESS; sTitle =
								 * ConstantsUtil.NO_ACCESS; sFN =
								 * ConstantsUtil.NO_ACCESS; sTupName =
								 * ConstantsUtil.NO_ACCESS; sSubstitute =
								 * ConstantsUtil.NO_ACCESS; sQty =
								 * ConstantsUtil.NO_ACCESS; sBuom =
								 * ConstantsUtil.NO_ACCESS; sComments =
								 * ConstantsUtil.NO_ACCESS; sCurrent =
								 * ConstantsUtil.NO_ACCESS; sStage =
								 * ConstantsUtil.NO_ACCESS; sRDOC =
								 * ConstantsUtil.NO_ACCESS;
								 */
							}

						}
						// }

						/*
						 * if (isModificatinRequired()) {
						 * 
						 * boolean bHasOwnership = checkOwnerShip(context,
						 * slUserOwnership, sId);
						 * 
						 * if (!bHasOwnership) {
						 * 
						 * sId = ConstantsUtil.NO_ACCESS; sRevision =
						 * ConstantsUtil.NO_ACCESS; sReleaseDate =
						 * ConstantsUtil.NO_ACCESS; sRevRelease =
						 * ConstantsUtil.NO_ACCESS; sTitle =
						 * ConstantsUtil.NO_ACCESS; spgChg =
						 * ConstantsUtil.NO_ACCESS; sFN = ConstantsUtil.NO_ACCESS;
						 * sTupName = ConstantsUtil.NO_ACCESS; sSubstitute =
						 * ConstantsUtil.NO_ACCESS; sQty = ConstantsUtil.NO_ACCESS;
						 * sBuom = ConstantsUtil.NO_ACCESS; sComments =
						 * ConstantsUtil.NO_ACCESS; sCurrent =
						 * ConstantsUtil.NO_ACCESS; sStage =
						 * ConstantsUtil.NO_ACCESS; sRDOC = ConstantsUtil.NO_ACCESS;
						 * 
						 * } }
						 */

						formatData(sbEBOMName, sName);
						formatData(sbEBOMId, sId);
						formatData(sbEBOMChg, spgChg);
						formatData(sbEBOMFN, sFN);
						formatData(sbEBOMTitle, sTitle);
						formatData(sbEBOMType, sType);
						formatData(sbEBOMSubstute, sSubstitute);
						formatData(sbEBOMQTY, sQty);
						formatData(sbEBOMBuom, sBuom);
						formatData(sbEBOMCommnts, sComments);
						formatData(sbEBOMState, sCurrent);
						formatData(sbEBOMStage, sStage);
						formatData(sbEBOMRDOC, sRDOC);
						formatData(sbEBOMRevRelDt, sRevRelease);
						/*
						 * if (null != sTupName && !sTupName.isEmpty()) {
						 * formatData(sbEBOMTupName, sTupName); }
						 */

					}

				}
				mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
				mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
				mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.TUPNAME, sbTupName.toString());
				mpEBOMResult.put(ConstantsUtil.TUPID, sbTupId.toString());
				mpEBOMResult.put(ConstantsUtil.TUPTYPE, sbTupType.toString());
			}
		} catch (Exception e) {
			LOGGER.error("Error in BusObjectAttribUtil, parseTUPMaplist:"+e);
		}
		// return filterMapList(mpEBOMResult);
		// System.out.println("mpEBOMResult===>"+mpEBOMResult);
		return mpEBOMResult;
	}

	public Map<String, String> parseBomCopMaplist(MapList mapList) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState = new StringBuilder();
		StringBuilder sbEBOMStage = new StringBuilder();
		StringBuilder sbEBOMRDOC = new StringBuilder();
		StringBuilder sbEBOMSubstute = new StringBuilder();
		StringBuilder sbEBOMRevRelDt = new StringBuilder();
		StringBuilder sbEBOMTupName = new StringBuilder();
		try {
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sReleaseDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
				String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON + sReleaseDate;
				String spgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sTupName = (String) objectMap.get(ConstantsUtil.TUPNAME);
				sType = mapType(sType);
				String sSubstitute = (String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
				sSubstitute = replaceSpecialSymbols(sSubstitute);
				String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				String sBuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				String sComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				sCurrent = mapType(sCurrent);
				String sStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				sRD = replaceSpecialSymbols(sRD);
				String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sOC = replaceSpecialSymbols(sOC);
				String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;

				formatData(sbEBOMName, sName);
				formatData(sbEBOMId, sId);
				formatData(sbEBOMChg, spgChg);
				formatData(sbEBOMFN, sFN);
				formatData(sbEBOMTitle, sTitle);
				formatData(sbEBOMType, sType);
				formatData(sbEBOMSubstute, sSubstitute);
				formatData(sbEBOMQTY, sQty);
				formatData(sbEBOMBuom, sBuom);
				formatData(sbEBOMCommnts, sComments);
				formatData(sbEBOMState, sCurrent);
				formatData(sbEBOMStage, sStage);
				formatData(sbEBOMRDOC, sRDOC);
				formatData(sbEBOMRevRelDt, sRevRelease);
				if (null != sTupName && !sTupName.isEmpty()) {
					formatData(sbEBOMTupName, sTupName);
				}

			}
			mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
			mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
			mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());

			if (null != sbEBOMTupName && sbEBOMTupName.length() > 0) {
				mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
			}

		} catch (Exception e) {
			LOGGER.error("Error in BusObjectAttribUtil, parseBomCopMaplist:"+e);
		}

		return filterMapList(mpEBOMResult);
	}

	public Map<String, String> parseBOMMaplist(MapList mapList, String sUserlicense, boolean isExternalUser) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		StringValidatorUtil util = new StringValidatorUtil();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMComment = new StringBuilder();
		StringBuilder sbEBOMState = new StringBuilder();
		StringBuilder sbEBOMStage = new StringBuilder();
		StringBuilder sbEBOMRDOC = new StringBuilder();
		StringBuilder sbEBOMSubstute = new StringBuilder();
		StringBuilder sbEBOMRevRelDt = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		try {
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				int iLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));
				if (iLevel == 1) {
					String sClassification = validator
							.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
					if (isExternalUser && null != sUserlicense && null != sClassification
							&& !sUserlicense.contains(sClassification)) {
						continue;
					}

					String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sReleaseDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
					String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON + sReleaseDate;
					String spgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
					String sFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
					String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
					sType = mapType(sType);
					String sSubstitute = (String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
					sSubstitute = replaceSpecialSymbols(sSubstitute);
					String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					String sBuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					String sComments = util.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT))
							? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING;
							String sComment = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
							String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
							String sStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
							String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
							sRD = replaceSpecialSymbols(sRD);
							String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
							sOC = replaceSpecialSymbols(sOC);
							String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;

							formatData(sbEBOMName, sName);
							formatData(sbEBOMId, sId);
							formatData(sbEBOMChg, spgChg);
							formatData(sbEBOMFN, sFN);
							formatData(sbEBOMTitle, sTitle);
							formatData(sbEBOMType, sType);
							formatData(sbEBOMSubstute, sSubstitute);
							formatData(sbEBOMQTY, sQty);
							formatData(sbEBOMBuom, sBuom);
							formatData(sbEBOMCommnts, sComments);
							formatData(sbEBOMComment, sComment);
							formatData(sbEBOMState, sCurrent);
							formatData(sbEBOMStage, sStage);
							formatData(sbEBOMRDOC, sRDOC);
							formatData(sbEBOMRevRelDt, sRevRelease);

				}
				mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
				mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
				mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());

			}
		} catch (Exception e) {
			LOGGER.error("Error in BusObjectAttribUtil, parseBOMMaplist:"+e);
		}
		return filterMapList(mpEBOMResult);
	}

	public Map getTupBom(Context context, MapList mapTupList, StringList slObjSelects, StringList slRelSelects,
			Map mpTUPSubstituteResult) throws Exception {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		FinishedProductPartBO fppBO = new FinishedProductPartBO();
		MapList mlFinalConnectedEBOMParents = new MapList();
		MapList mlFinalConnectedEBOMParentsForSubstitues = new MapList();
		BusObjectAttribUtil busutil = new BusObjectAttribUtil();
		StringList slObjSelectsTup = slObjSelects;
		StringList slRelObjSelectsTup = slRelSelects;
		slObjSelectsTup.addAll(fppBO.addUnitSelects(fppBO.getMasterBusEbom()));
		slRelObjSelectsTup.addAll(fppBO.getMasterRelEbom());

		try {

			String strTupName = ConstantsUtil.EMPTY_STRING;
			StringList slTupName = new StringList();
			StringList slTupId = new StringList();
			if (mapTupList != null && mapTupList.size() > 0) {
				for (int i = 0; i < mapTupList.size(); i++) {
					MapList mlConnectedEBOMParents = new MapList();
					Map mapObject = (Map) mapTupList.get(i);
					String sTupId = (String) mapObject.get(ConstantsUtil.SELECT_ID);
					strTupName = (String) mapObject.get(ConstantsUtil.SELECT_NAME);

					// boolean bHasOwnshp = checkOwnerShip(context, sTupId);
					// modified by Ganesh for security impl------>start
					boolean bHasOwnshp = checkHasAccess(context, null, sTupId);
					// modified by Ganesh for security impl------->end
					if (sTupId != null) {
						DomainObject domObject = DomainObject.newInstance(context, sTupId);
						mlConnectedEBOMParents = domObject.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
								DomainConstants.QUERY_WILDCARD, slObjSelectsTup, slRelObjSelectsTup, false, true,
								(short) 0, "", "", 0);
						if (null != mlConnectedEBOMParents && mlConnectedEBOMParents.size() > 0) {
							mlConnectedEBOMParents.addSortKey(ConstantsUtil.STRING_FN, ConstantsUtil.ASCENDING,
									ConstantsUtil.INTEGER);
							mlConnectedEBOMParents.sort();
						}
					}

					if (!bHasOwnshp) {
						sTupId = ConstantsUtil.NO_ACCESS;
					}
					slTupName.add(strTupName);
					slTupId.add(sTupId);

					mlFinalConnectedEBOMParents.add(i, mlConnectedEBOMParents);
				}
				mlFinalConnectedEBOMParentsForSubstitues = mlFinalConnectedEBOMParents;
				mpEBOMResult = busutil.parseTUPMaplist(context, mlFinalConnectedEBOMParents, slTupName, slTupId);
				mpTUPSubstituteResult = fppBO.parseMaplistForTupSubstitute(context,
						mlFinalConnectedEBOMParentsForSubstitues, mpTUPSubstituteResult);
			}

		} catch (Exception e) {
			LOGGER.error("Exception in getTupBom : Program BusObjectAttribUtil " + e);
			return new HashMap();
		}

		return mpEBOMResult;
	}

	public Map<String, String> parseMaplistForSubstitute(Context context, MapList mapList) throws Exception {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		try {
			Iterator objectListItr = mapList.iterator();
			StringBuilder sbSubNameRev = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMTitleFor = new StringBuilder();
			StringBuilder sbEBOMTypeSubType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMComments = new StringBuilder();
			StringBuilder sbEBOMState = new StringBuilder();
			StringBuilder sbEBOMRDOC = new StringBuilder();
			StringBuilder sbEBOMSubstute = new StringBuilder();
			StringBuilder sbEBOMRevRelDt = new StringBuilder();
			StringBuilder sbEBOMValidStartDt = new StringBuilder();
			StringBuilder sbEBOMValidUntiltDt = new StringBuilder();
			StringBuilder sbEBOMSubFor = new StringBuilder();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				//SPEC: <08-25-2021>: Sanjeeva Commented for Stress Testing Defect 44365  -- START
				//String sReleaseDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
				//SPEC: <08-25-2021>: Sanjeeva Commented for Stress Testing Defect 44365  -- END
				String sSubType = (String) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);

				String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sSubstitute = (String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
				sSubstitute = replaceSpecialSymbols(sSubstitute);
				String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				String sBuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				String sComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				sRD = replaceSpecialSymbols(sRD);
				String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sOC = replaceSpecialSymbols(sOC);
				String sValidStartDate = (String) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
				String strValidUntilDt = (String) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
				String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
				String sSubstituteName = (String) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
				String sSubstituteRev = (String) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
				String sSubstituteTitle = (String) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
				String sSubstituteReleaseDate = (String) objectMap
						.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
				String sRevRelease = sSubstituteRev + ConstantsUtil.SYMBL_COLON + sSubstituteReleaseDate;

				formatData(sbSubNameRev, sSubstituteName + ConstantsUtil.SYMBL_COLON + sSubstituteRev);
				formatData(sbEBOMId, sId);
				formatData(sbEBOMTitle, sTitle);
				formatData(sbEBOMTypeSubType, sType + ConstantsUtil.SYMBL_COLON + sSubType);
				formatData(sbEBOMSubstute, sSubstitute);
				formatData(sbEBOMQTY, sQty);
				formatData(sbEBOMBuom, sBuom);
				formatData(sbEBOMComments, sComments);
				formatData(sbEBOMState, sCurrent);
				formatData(sbEBOMRDOC, sRDOC);
				formatData(sbEBOMRevRelDt, sRevRelease);
				formatData(sbEBOMValidStartDt, sValidStartDate);
				formatData(sbEBOMValidUntiltDt, strValidUntilDt);
				formatData(sbEBOMSubFor, sName + ConstantsUtil.SYMBL_COLON + sRevision);
				formatData(sbEBOMTitleFor, sSubstituteTitle);

			}
			mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEPARTS, sbSubNameRev.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
			mpEBOMResult.put(ConstantsUtil.TITLEFOR, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMComments.toString());
			mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
			mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
			mpEBOMResult.put(ConstantsUtil.VALIDSTARTDATE, sbEBOMValidStartDt.toString());
			mpEBOMResult.put(ConstantsUtil.VALIDTILLDATE, sbEBOMValidUntiltDt.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitleFor.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMTypeSubType.toString());
		} catch (Exception e) {
			LOGGER.error("Unable to parseMaplistForSubstitute : Program BusObjectAttribUtil " + e);
			return new HashMap();
		}
		return filterMapList(mpEBOMResult);
	}

	public Map<String, String> filterMapList(Map<String, String> mapResult) {
		boolean bFlag = false;
		StringValidatorUtil validator = new StringValidatorUtil();
		for (Map.Entry<String, String> entry : mapResult.entrySet()) {
			String val = entry.getValue();
			if (validator.isNotNullOrEmpty(val)) {
				bFlag = true;
				break;
			}
		}
		if (bFlag) {
			return mapResult;
		}
		return new HashMap();
	}

	//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
	//public Map updatePerformCharcteristic(Context context, MapList mlFinalList, Map resultMap, String objId) {
	public Map updatePerformCharcteristic(Context context, MapList mlFinalList, Map resultMap, String objId) {
		//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
		StringValidatorUtil validator = new StringValidatorUtil();
		String sName = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.SELECT_NAME))
				? (String) resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
				StringBuilder sCPS = new StringBuilder();
				StringBuilder sCPSName = new StringBuilder();
				StringBuilder sCPSId = new StringBuilder();
				StringBuilder schg = new StringBuilder();
				StringBuilder sCharcteristic = new StringBuilder();
				StringBuilder sbPathId = new StringBuilder();
				StringBuilder sbPathType = new StringBuilder();
				StringBuilder sCharSpec = new StringBuilder();
				StringBuilder sPath = new StringBuilder();
				StringBuilder sTMNActual = new StringBuilder();
				StringBuilder sTMNActualID = new StringBuilder();
				StringBuilder sTMNActualType = new StringBuilder();
				StringBuilder sTMName = new StringBuilder();
				StringBuilder sTMLogic = new StringBuilder();
				StringBuilder sMethodOrigin = new StringBuilder();
				StringBuilder sMethodNumber = new StringBuilder();
				StringBuilder sMethodSpecific = new StringBuilder();
				StringBuilder sTMNameID = new StringBuilder();
				StringBuilder sTMNameType = new StringBuilder();
				StringBuilder sSampling = new StringBuilder();
				StringBuilder sSubGroup = new StringBuilder();

				StringBuilder sPlantTesting = new StringBuilder();
				StringBuilder sPlantRetesting = new StringBuilder();
				StringBuilder sTestingUOM = new StringBuilder();

				StringBuilder sLowerSpecLimit = new StringBuilder();
				StringBuilder sLowerRoutineReleaseLimit = new StringBuilder();
				StringBuilder sPGLowerTarget = new StringBuilder();
				StringBuilder sPGTarget = new StringBuilder();
				StringBuilder sPGUpperTarget = new StringBuilder();
				StringBuilder sUpperRoutineRL = new StringBuilder();
				StringBuilder sPGUpperSpecLimit = new StringBuilder();

				StringBuilder sUnitOfMeasure = new StringBuilder();
				StringBuilder sPGReportNear = new StringBuilder();
				StringBuilder sPGReportType = new StringBuilder();
				StringBuilder sReleseCriteria = new StringBuilder();

				StringBuilder sPGACtionRequired = new StringBuilder();
				StringBuilder sCriticalFactor = new StringBuilder();
				StringBuilder sPGBasis = new StringBuilder();

				StringBuilder sPTestGroup = new StringBuilder();
				StringBuilder sPApplication = new StringBuilder();
				StringBuilder sPMTitle = new StringBuilder();

				Iterator objectListItr = mlFinalList.iterator();
				Map<String, String> mpFinal = new HashMap<String, String>();
				SecurityService sct = new SecurityService();
				String sUserType = getUserType();
				String sUserlicense = sct.getUserLicense();
				//SPEC: Release SR18x.5.2 - Added for Defect# 40066  by gaikwad.tg on Date 19 Feb 2021 -- START
				
				StringList slExcludeTypes = getPerformCharSelectsForTypeExclude();
				//SPEC: Release SR18x.5.2 - Added for Defect# 40066  by gaikwad.tg on Date 19 Feb 2021 -- START
				

				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- START
				boolean isExternal=isModificatinRequired();
				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- END

				try {
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
					Map paramMap1 = new HashMap();
					paramMap1.put("objectList", mlFinalList);
					Map mptable = new HashMap ();
					mptable.put("table", "pgVPDPerformanceCharacteristicTable");
					paramMap1.put("paramList", mptable);
					paramMap1.put("parentOID", objId);

					Map mpResultMPT = getDerivedTitleForRow(context,JPO.packArgs(paramMap1));
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
					//SPEC: <05.07.2022>: Manikanta Modified for Req 43397 22x Release  -- START
					String strAttrPgOriginatingsource = validator.getEquivalentStringComma(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE));
					if(UIUtil.isNullOrEmpty(strAttrPgOriginatingsource))
					{
						String strID = (String) resultMap.get(DomainConstants.SELECT_ID);
						DomainObject dobject = DomainObject.newInstance(context, strID);
						strAttrPgOriginatingsource = dobject.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
					}
					//SPEC: <05.07.2022>: Manikanta Modified for Req 43397 22x Release  -- END
					
					while (objectListItr.hasNext()) {
						{
							Map objectMap = (Map) objectListItr.next();
							
							// START :: gaikwad.tg

							String sForCPSType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
									? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
									String sForCPSName = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_NAME))
											? (String) objectMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;

											String sForCPSId = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
													? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
													
													// END :: gaikwad.tg
													String sPchg = validator
															.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE))
															? ((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE))
																	: ConstantsUtil.EMPTY_STRING;

															
															String sPCharcteristic = validator.getStringEquivalentForSubstituteString(
																	objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC));

															
															String sPCharSpec = validator.getStringEquivalentForSubstituteString(
																	objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS));
															sPCharSpec = sPCharSpec.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);//Added by Ketan for Defect no. 8596
															
															//Added by Ketan for Defect no. 53059 -- START
															String sProductPlatform = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTPLATFORM))
																	? (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTPLATFORM) : ConstantsUtil.EMPTY_STRING;
															String sProductPlatformRev = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTPLATFORMREV))
																	? (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTPLATFORMREV) : ConstantsUtil.EMPTY_STRING;
															String sPPath = ConstantsUtil.EMPTY_STRING;
															if(sProductPlatform.equalsIgnoreCase(ConstantsUtil.EMPTY_STRING)) {
																sPPath = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.PATH))
																		? (String) objectMap.get(ConstantsUtil.PATH) : ConstantsUtil.EMPTY_STRING;
															}
															else {
																sPPath = sProductPlatform + ConstantsUtil.EMPTY_SPACE + sProductPlatformRev;
															}
															//Added by Ketan for Defect no. 53059 -- END
															
																	String sPTMName = ConstantsUtil.EMPTY_STRING;
																	String sPTMNameActual = ConstantsUtil.EMPTY_STRING;
																	String sPTMNameID = ConstantsUtil.EMPTY_STRING;
																	String sPTMNameActualID = ConstantsUtil.EMPTY_STRING;
																	String sPTMNameActualType = ConstantsUtil.EMPTY_STRING;
																	String sPTMType = ConstantsUtil.EMPTY_STRING;
																	//SPEC: Release SR18x.5.2 - Added for Defect# 39245  by gaikwad.tg on Date 17 Feb 2021 -- START
																	String strParentType= (String) resultMap.get(ConstantsUtil.SELECT_TYPE);
																	//SPEC: Release SR18x.5.2 - Added for Defect# 39245  by gaikwad.tg on Date 17 Feb 2021 -- END

																	boolean sClass = objectMap.containsKey(ConstantsUtil.SELECT_REF_DOC_TONAME);
																	boolean sClassTo = objectMap.containsKey(ConstantsUtil.SELECT_REF_DOC_NAME);

																	if (sClass) {
																		String sClassName = objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME).getClass()
																				.getSimpleName();
																		//SPEC: Release SR18x.5.2 - Added for Defect# 39245  by gaikwad.tg on Date 17 Feb 2021 -- START
																		boolean isString = false;
																		String strClassFied  =  ConstantsUtil.EMPTY_STRING;
																		String sTamu =  ConstantsUtil.EMPTY_STRING;
																		String sTMHasSharedAccess =  ConstantsUtil.EMPTY_STRING;

																		if(sClassName.equals(ConstantsUtil.STRING))
																		{
																			isString= true;

																			sPTMName = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME): ConstantsUtil.EMPTY_STRING;

																			sPTMType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE) : ConstantsUtil.EMPTY_STRING;

																			sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS))? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS): ConstantsUtil.EMPTY_STRING;

																			sPTMNameID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID): ConstantsUtil.EMPTY_STRING;

																			strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_REF_DOC_IPCLASS)));

																			sTamu = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_CSS))? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_CSS): ConstantsUtil.EMPTY_STRING;
																		}
																		else
																		{
																			StringList slTempTMName = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME);
																			if (slTempTMName != null && slTempTMName.size() == 1)
																			{
																				isString= true;

																				StringList slTempTMType = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
																				StringList slTempsChildObjectID = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID);
																				StringList slTempTMHasSharedAccess = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);
																				StringList slTempTamuList = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_CSS);
																				StringList slTempClassFiedList = (StringList) objectMap.get(ConstantsUtil.STR_REF_DOC_IPCLASS);

																				sPTMName = (slTempTMName != null && validator.isNotNullOrEmpty(slTempTMName.get(0)))? slTempTMName.get(0) : ConstantsUtil.EMPTY_STRING;
																				sPTMType = (slTempTMType != null && validator.isNotNullOrEmpty(slTempTMType.get(0)))? slTempTMType.get(0) : ConstantsUtil.EMPTY_STRING;
																				sTMHasSharedAccess = (slTempTMHasSharedAccess != null && validator.isNotNullOrEmpty(slTempTMHasSharedAccess.get(0)))? slTempTMHasSharedAccess.get(0) : ConstantsUtil.EMPTY_STRING;
																				sPTMNameID = (slTempsChildObjectID != null && validator.isNotNullOrEmpty(slTempsChildObjectID.get(0)))? slTempsChildObjectID.get(0) : ConstantsUtil.EMPTY_STRING;
																				strClassFied = (slTempClassFiedList != null && validator.isNotNullOrEmpty(slTempClassFiedList.get(0)))? slTempClassFiedList.get(0) : ConstantsUtil.EMPTY_STRING;
																				sTamu = (slTempTamuList != null && validator.isNotNullOrEmpty(slTempTamuList.get(0)))? slTempTamuList.get(0) : ConstantsUtil.EMPTY_STRING;
																			}
																		}
																		if (isString) 
																		{
																			BusObjectAttribUtil util = new BusObjectAttribUtil();
																			boolean showData = util.checkHasAccess(context, sUserType, sPTMNameID);
																			boolean strTempCurrentIsRelease = checkIfReleased(context, sPTMNameID);
																			if (!showData && !strTempCurrentIsRelease) 
																			{
																				sPTMNameID=ConstantsUtil.EMPTY_STRING;
																			}
																			if (isModificatinRequired()) 
																			{
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- START
																				if(!showData || !strTempCurrentIsRelease)
																					//SPEC: Release SR18x.6.0.1 - Req#43188 Added  by gaikwad.tg on Date 31 May 2021 -- START
																				{
																					util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
																					util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																					util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);

																					util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
																					util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																					util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
																					//continue;
																				}
																				//SPEC: Release SR18x.6.0.1 - Req#43188 Added  by gaikwad.tg on Date 31 May 2021 -- END
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- END
																				
																				
																				//SPEC: Release SR18x.6.0.1 - Req#43188 Added  by gaikwad.tg on Date 31 May 2021 -- START
																				else
																				{
																					//SPEC: <07.03.2022>: Guna Added for 46850 Defect  Dev 18x.6.0.3   -- START
																					showData = util.checkHasAccess(context, sUserType, sPTMNameID);
																					if(!showData ) {
																						sPTMNameID =ConstantsUtil.NO_ACCESS;
																					}
																					//SPEC: <07.03.2022>: Guna Added for 46850 Defect  Dev 18x.6.0.3   -- END
																					if (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || sPTMType.equals(ConstantsUtil.TYPE_TESTMETHOD) || sPTMType.equals(ConstantsUtil.TYPE_PGTESTMETHOD)) 
																					{
																						//SPEC: Release SR18x.5.2 - Added for Defect# 40066  by gaikwad.tg on Date 19 Feb 2021 -- START
																						if(slExcludeTypes.contains(strParentType) && (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || sPTMType.equals(ConstantsUtil.TYPE_TESTMETHOD)))
																						{
																							//SPEC: Release SR18x.5.2 - Added for Defect# 40066  by gaikwad.tg on Date 19 Feb 2021 -- END
																							util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
																							util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																							util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);
																						}
																						else
																						{
																							if ("DSO".equals(strAttrPgOriginatingsource) && !"pgTestMethod".equals(sPTMType)) {
																								util.formatData(sTMNActual, sPTMName);
																								util.formatData(sTMNActualID, sPTMNameID);
																								util.formatData(sTMNActualType, sPTMType);
																							}
																							else if(sPTMType.equals("pgTestMethod") && (UIUtil.isNotNullAndNotEmpty(sTamu) && !sTamu.equals("TAMU")))
																							{
																								util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
																								util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																								util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);
																							}
																							else
																							{
																								util.formatData(sTMNActual, sPTMName);
																								util.formatData(sTMNActualID, sPTMNameID);
																								util.formatData(sTMNActualType, sPTMType);
																							}
																						}
																						//SPEC: Release SR18x.5.2 - Added for Defect# 40047  by gaikwad.tg on Date 20 Feb 2021 -- END
																						if(!"DSO".equals(strAttrPgOriginatingsource))
																						{
																							if (UIUtil.isNotNullAndNotEmpty(sTamu) && !sTamu.equals("TAMU"))  {
																								util.formatData(sTMName, sPTMName);
																								util.formatData(sTMNameID, sPTMNameID);
																								util.formatData(sTMNameType, sPTMType);

																							} else {
																								util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
																								util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																								util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
																							}
																						}
																						else if("DSO".equals(strAttrPgOriginatingsource) && sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || sPTMType.equals(ConstantsUtil.TYPE_TESTMETHOD))
																						{
																							util.formatData(sTMName, sPTMName);
																							util.formatData(sTMNameID, sPTMNameID);
																							util.formatData(sTMNameType, sPTMType);
																						}
																						//SPEC: Release SR18x.5.2 - Added for Defect# 40047  by gaikwad.tg on Date 20 Feb 2021 -- END
																						//SPEC: Release SR18x.6.0 - Added for Defect#Internal by gaikwad.tg on Date 30 April 2021 -- START
																					} else if (sPTMType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE) || ConstantsUtil.TYPE_PG_TMRD_TYPES.contains(sPTMType)) 
																					{
																						//SPEC: Release SR18x.6.0 - Added for Defect#Internal by gaikwad.tg on Date 30 April 2021 -- END
																						util.formatData(sTMNActual, sPTMName);
																						util.formatData(sTMNActualID, sPTMNameID);
																						util.formatData(sTMNActualType, sPTMType);
																						util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
																						util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																						util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
																					}
																					else {
																						util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
																						util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																						util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);

																						util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
																						util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																						util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
																					}
																					//SPEC: Release SR18x.5.2 - Added for Defect# 39245  by gaikwad.tg on Date 17 Feb 2021 -- END
																					// }
																				}
																				//SPEC: Release SR18x.6.0.1 - Req#43188 Added  by gaikwad.tg on Date 31 May 2021 -- END
																			}
																			
																			else
																			{
																				
																				if (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || sPTMType.equals(ConstantsUtil.TYPE_TESTMETHOD) || sPTMType.equals(ConstantsUtil.TYPE_PGTESTMETHOD)) 
																				{
																					//SPEC: <07.03.2022>: Guna Added for 46850 Defect  Dev 18x.6.0.3   -- START
																					showData = util.checkHasAccess(context, sUserType, sPTMNameID);
																					if(!showData) {
																						sPTMNameID =ConstantsUtil.NO_ACCESS;
																					}
																					//SPEC: <07.03.2022>: Guna Added for 46850 Defect  Dev 18x.6.0.3   -- END
																					//SPEC: Release SR18x.5.2 - Added for Defect# 40066  by gaikwad.tg on Date 19 Feb 2021 -- START
																					if(slExcludeTypes.contains(strParentType) && (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || sPTMType.equals(ConstantsUtil.TYPE_TESTMETHOD)))
																					{
																						//SPEC: Release SR18x.5.2 - Added for Defect# 40066  by gaikwad.tg on Date 19 Feb 2021 -- END
																						util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
																						util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																						util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);
																					}
																					else
																					{
																						if ("DSO".equals(strAttrPgOriginatingsource) && !"pgTestMethod".equals(sPTMType)) {
																							util.formatData(sTMNActual, sPTMName);
																							util.formatData(sTMNActualID, sPTMNameID);
																							util.formatData(sTMNActualType, sPTMType);
																						}
																						else if(sPTMType.equals("pgTestMethod") && (UIUtil.isNotNullAndNotEmpty(sTamu) && !sTamu.equals("TAMU")))
																						{
																							util.formatData(sTMNActual, ConstantsUtil.EMPTY_STRING);
																							util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																							util.formatData(sTMNActualType, ConstantsUtil.EMPTY_STRING);
																						}
																						else
																						{
																							util.formatData(sTMNActual, sPTMName);
																							util.formatData(sTMNActualID, sPTMNameID);
																							util.formatData(sTMNActualType, sPTMType);
																						}
																					}
																					//SPEC: Release SR18x.5.2 - Added for Defect# 40047  by gaikwad.tg on Date 20 Feb 2021 -- END
																					if(!"DSO".equals(strAttrPgOriginatingsource))
																					{
																						if (UIUtil.isNotNullAndNotEmpty(sTamu) && !sTamu.equals("TAMU"))  {
																							util.formatData(sTMName, sPTMName);
																							util.formatData(sTMNameID, sPTMNameID);
																							util.formatData(sTMNameType, sPTMType);

																						} else {
																							util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
																							util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																							util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
																						}
																					}
																					else if("DSO".equals(strAttrPgOriginatingsource) && sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || sPTMType.equals(ConstantsUtil.TYPE_TESTMETHOD))
																					{
																						util.formatData(sTMName, sPTMName);
																						util.formatData(sTMNameID, sPTMNameID);
																						util.formatData(sTMNameType, sPTMType);
																					}
																					//SPEC: Release SR18x.5.2 - Added for Defect# 40047  by gaikwad.tg on Date 20 Feb 2021 -- END
																				} else 
																				{
																					util.formatData(sTMNActual, sPTMName);
																					util.formatData(sTMNActualID, sPTMNameID);
																					util.formatData(sTMNActualType, sPTMType);
																					util.formatData(sTMName, ConstantsUtil.EMPTY_STRING);
																					util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																					util.formatData(sTMNameType, ConstantsUtil.EMPTY_STRING);
																				}
																				//SPEC: Release SR18x.5.2 - Added for Defect# 39245  by gaikwad.tg on Date 17 Feb 2021 -- END
																			}
																		
																			
																		} else {
																			// For StringList
																			StringList slTMName = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME);

																			StringList slTMType = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
																			StringList slsChildObjectID = (StringList) objectMap
																					.get(ConstantsUtil.SELECT_REF_DOC_TO_ID);
																			StringList slTMHasSharedAccess = (StringList) objectMap
																					.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);
																			//SPEC: Release SR18x.5.2 - Added for Defect# 39245  by gaikwad.tg on Date 17 Feb 2021 -- START
																			StringList slTamuList = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_CSS);
																			//SPEC: Release SR18x.5.2 - Added for Defect# 39245  by gaikwad.tg on Date 17 Feb 2021 -- END
																			boolean showData = false;
																			boolean bHasOwnership = false;
																			if (isModificatinRequired()) {
																				Map<String, StringList> mpTemp = new HashMap<String, StringList>();
																				mpTemp.put(ConstantsUtil.TYPE, slTMType);
																				mpTemp.put(ConstantsUtil.NAME, slTMName);
																				mpTemp.put(ConstantsUtil.SECURITY, slTMHasSharedAccess);
																				mpTemp.put(ConstantsUtil.ID, slsChildObjectID);

																				Map mpTemp1 = showOrHideSOPAndTM(context, mpTemp);

																				SecurityService sec = new SecurityService();
																				String sComp = sec.getUserCauthorities();
																				StringList slUserOwnership = filterOwnerShip(sComp);

																				slTMName = (StringList) mpTemp1.get(ConstantsUtil.NAME);
																				slTMType = (StringList) mpTemp1.get(ConstantsUtil.TYPE);
																				slsChildObjectID = (StringList) mpTemp1.get(ConstantsUtil.ID);
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																				StringList slTempsChildObjectID = new StringList();
																				StringList slTempTMName = new StringList();
																				StringList slTempTMType = new StringList();
																				//								SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																				int iSize = slsChildObjectID.size();
																				boolean strTempCurrentIsRelease = false;
																				for (int i = 0; i < iSize; i++) {
																					String strOID = slsChildObjectID.get(i);
																					//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																					String strName = slTMName.get(i);
																					String strType = slTMType.get(i);
																					//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																					BusObjectAttribUtil util = new BusObjectAttribUtil();
																					bHasOwnership = util.checkHasAccess(context, sUserType, strOID);
																					strTempCurrentIsRelease = checkIfReleased(context, strOID);
																					// Added by Ganesh 1.0.2 Release Start
																					if (bHasOwnership && strTempCurrentIsRelease) {
																						showData = true;
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																						slTempsChildObjectID.add(strOID);
																						slTempTMName.add(strName);
																						slTempTMType.add(strType);
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END

																					} else {
																						showData = false;
																						strOID = ConstantsUtil.NO_ACCESS;
																						
																					}
																					slsChildObjectID.add(strOID);
																				}
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																				if(isExternal)
																				{
																					slTMName = slTempTMName;
																					slTMType = slTempTMType;
																					slsChildObjectID = slTempsChildObjectID;
																				}
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END

																			}
																			//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- START
																			Map mpTemp2 = removeTestMethod(slTMName, slTMType, slsChildObjectID,slTamuList, strAttrPgOriginatingsource, strParentType);
																			//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- END
																			
																			StringList slTMFilteredName = (StringList) mpTemp2.get(ConstantsUtil.TMFILNAME);
																			StringList slTMFilterID = (StringList) mpTemp2.get(ConstantsUtil.TMFILID);
																			StringList slTMFilterType = (StringList) mpTemp2.get(ConstantsUtil.TMFILTYPE);

																			slTMType = (StringList) mpTemp2.get(ConstantsUtil.BASETYPE);
																			slTMName = (StringList) mpTemp2.get(ConstantsUtil.BASENAME);
																			slsChildObjectID = (StringList) mpTemp2.get(ConstantsUtil.BASEID);

																			sPTMName = validator.isNotNullOrEmpty(slTMName.toString()) ? slTMName.toString()
																					: ConstantsUtil.EMPTY_STRING;
																			sPTMName = sPTMName.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																					.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																					.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																			// Security added for Staff AUG
																			StringList slTMSecurityCheck = new StringList();
																			if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																				int iSize = slsChildObjectID.size();
																				boolean strTempCurrentIsRelease = false;
																				for (int i = 0; i < iSize; i++) {
																					String strOID = slsChildObjectID.get(i);

																					BusObjectAttribUtil util = new BusObjectAttribUtil();
																					showData = util.checkHasAccess(context, sUserType, strOID);
																					// Added by Ganesh 1.0.2 Release End
																					strTempCurrentIsRelease = checkIfReleased(context, strOID);
																					if (showData && strTempCurrentIsRelease) {
																						slTMSecurityCheck.add(strOID);
																					} else {
																						slTMSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																					}
																				}
																			} else {

																				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 29, 2021 for Defect 41085 -- START
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																				StringList slTempsChildObjectID = new StringList();
																				StringList slTempTMName = new StringList();
																				StringList slTempTMType = new StringList();
																				boolean strTempCurrentIsRelease = false;
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																				int iSize = slsChildObjectID.size();
																				for (int i = 0; i < iSize; i++) {
																					String strOID = slsChildObjectID.get(i);
																					//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																					String strName = slTMName.get(i);
																					String strType = slTMType.get(i);
																					//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																					
																					BusObjectAttribUtil util = new BusObjectAttribUtil();
																					showData = util.checkHasAccess(context, sUserType, strOID);
																					// Added by Ganesh 1.0.2 Release End
																					strTempCurrentIsRelease = checkIfReleased(context, strOID);
																					if (showData && strTempCurrentIsRelease) {
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																						if(isExternal)
																						{
																							slTempsChildObjectID.add(strOID);
																							slTempTMType.add(strType);
																							slTempTMName.add(strName);
																						}
																						else
																							//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																							slTMSecurityCheck.add(strOID);
																					} else {
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																						if(isExternal)
																							continue;
																						else
																							//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																							slTMSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																					}
																				}
																				
																				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 29, 2021 for Defect 41085 -- END
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																				if(isExternal)
																				{
																					slTMName = slTempTMName;
																					slTMType = slTempTMType;
																					slTMSecurityCheck = slTempsChildObjectID;
																				}
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																			}

																			
																			

																			sPTMNameID = validator.isNotNullOrEmpty(slTMSecurityCheck.toString())
																					? slTMSecurityCheck.toString() : ConstantsUtil.EMPTY_STRING;

																					sPTMNameID = sPTMNameID.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																							.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																							.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																					sPTMType = validator.isNotNullOrEmpty(slTMType.toString()) ? slTMType.toString()
																							: ConstantsUtil.EMPTY_STRING;
																					sPTMType = sPTMType.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																							.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																							.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																					formatData(sTMNActualID, sPTMNameID);
																					formatData(sTMNActual, sPTMName);
																					formatData(sTMNActualType, sPTMType);

																					sPTMNameActual = validator.isNotNullOrEmpty(slTMFilteredName.toString())
																							? slTMFilteredName.toString() : ConstantsUtil.EMPTY_STRING;
																							sPTMNameActual = sPTMNameActual
																									.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																									.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																									.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																							StringList slTMActualSecurityCheck = new StringList();
																							if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																								int iSize = slTMFilterID.size();
																								boolean strTempCurrentIsRelease = false;
																								for (int i = 0; i < iSize; i++) {
																									String strOID = slTMFilterID.get(i);

																									BusObjectAttribUtil util = new BusObjectAttribUtil();
																									showData = util.checkHasAccess(context, sUserType, strOID);
																									// Added by Ganesh 1.0.2 Release End
																									strTempCurrentIsRelease = checkIfReleased(context, strOID);
																									if (showData && strTempCurrentIsRelease) {
																										slTMActualSecurityCheck.add(strOID);
																									} else {
																										slTMActualSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																									}
																								}
																							} else {

																								StringList slTempsChildObjectID = new StringList();
																								StringList slTempTMName = new StringList();
																								StringList slTempTMType = new StringList();
																								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																								int iSize = slTMFilterID.size();
																								boolean strTempCurrentIsRelease = false;
																								for (int i = 0; i < iSize; i++) {
																									String strOID = slTMFilterID.get(i);
																									//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																									String strFlName = slTMFilteredName.get(i);
																									String strFlType = slTMFilterType.get(i);
																									//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																									
																									
																									BusObjectAttribUtil util = new BusObjectAttribUtil();
																									showData = util.checkHasAccess(context, sUserType, strOID);
																									// Added by Ganesh 1.0.2 Release End
																									strTempCurrentIsRelease = checkIfReleased(context, strOID);
																									if (showData && strTempCurrentIsRelease) {
																										//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																										if(isExternal)
																										{
																											slTempsChildObjectID.add(strOID);
																											slTempTMName.add(strFlName);
																											slTempTMType.add(strFlType);
																										}
																										else
																											//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																											slTMActualSecurityCheck.add(strOID);
																									} else {
																										//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																										if(isExternal)
																											continue;
																										else
																											//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																											slTMActualSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																									}
																								}
																								//SPEC: Release SR18x.6.0 - Added by Amman on Mar 29, 2021 for Defect 41085 -- END
																								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																								if(isExternal)
																								{
																									slTMName = slTempTMName;
																									slTMType = slTempTMType;
																									slTMActualSecurityCheck = slTempsChildObjectID;
																								}
																								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																							}

																							sPTMNameActualID = validator.isNotNullOrEmpty(slTMActualSecurityCheck.toString())
																									? slTMActualSecurityCheck.toString() : ConstantsUtil.EMPTY_STRING;

																									sPTMNameActualID = sPTMNameActualID
																											.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																											.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																											.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																									sPTMNameActualType = validator.isNotNullOrEmpty(slTMFilterType.toString())
																											? slTMFilterType.toString() : ConstantsUtil.EMPTY_STRING;
																											sPTMNameActualType = sPTMNameActualType
																													.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																													.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																													.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																											
																											formatData(sTMName, sPTMNameActual);
																											formatData(sTMNameID, sPTMNameActualID);
																											formatData(sTMNameType, sPTMNameActualType);

																											
							
																											
																		}

																	}
																	

																	else if (sClassTo) {
																		String sClassName = objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME).getClass().getSimpleName();

																		if (sClassName.equals(ConstantsUtil.STRING)) {
																			if (isModificatinRequired()) {
																				sPTMName = validator
																						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME))
																						? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME)
																								: ConstantsUtil.EMPTY_STRING;
																						sPTMType = validator
																								.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE))
																								? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE)
																										: ConstantsUtil.EMPTY_STRING;
																								String sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap
																										.get(ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS))
																										? (String) objectMap
																												.get(ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS)
																												: ConstantsUtil.EMPTY_STRING;
																												sPTMNameID = validator
																														.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID))
																														? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID)
																																: ConstantsUtil.EMPTY_STRING;
																														
																														// Added by Ganesh Start
																														BusObjectAttribUtil util = new BusObjectAttribUtil();
																														boolean bHasOwnership = util.checkHasAccess(context, sUserType, sPTMNameID);
																														
																														if (bHasOwnership) {
																															formatData(sTMNActual, sPTMName);
																															// START :: gaikwad.tg :: Defect#36537
																															// formatData(sTMNActualID, sPTMNameActual);
																															formatData(sTMNActualID, sPTMNameID);
																															// END :: gaikwad.tg :: Defect#36537
																															formatData(sTMNActualType, sPTMType);
																														} else {
																															//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																															continue;

																															//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																														} // Added by Ganesh Stop

																			} else {
																				sPTMType = validator
																						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE))
																						? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE)
																								: ConstantsUtil.EMPTY_STRING;
																						boolean showData = false;
																						if (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {
																							if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																								String strClassFied = validator.getStringEquivalentForStringList(
																										(objectMap.get(ConstantsUtil.STR_REF_DOC_FROMIPCLASS)));
																								// Added by Ganesh 1.0.2 Release Start
																								
																								BusObjectAttribUtil util = new BusObjectAttribUtil();
																								showData = util.checkHasAccess(context, sUserType, sPTMNameID);
																								// Added by Ganesh 1.0.2 Release End
																							}

																							sPTMName = validator
																									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME))
																									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME)
																											: ConstantsUtil.EMPTY_STRING;
																									sPTMNameID = validator
																											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID))
																											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID)
																													: ConstantsUtil.EMPTY_STRING;

																											if (showData) {
																												formatData(sTMName, sPTMName);
																												formatData(sTMNameID, sPTMNameID);
																												formatData(sTMNameType, sPTMType);
																											} else {
																												formatData(sTMName, sPTMName);
																												formatData(sTMNameID, ConstantsUtil.NO_ACCESS);
																												formatData(sTMNameType, sPTMType);
																											}

																						} else {
																							if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																								String strClassFied = validator.getStringEquivalentForStringList(
																										(objectMap.get(ConstantsUtil.STR_REF_DOC_FROMIPCLASS)));
																								//// Added by Ganesh 1.0.2 Release Start
																								
																								BusObjectAttribUtil util = new BusObjectAttribUtil();
																								showData = util.checkHasAccess(context, sUserType, sPTMNameID);
																								// Added by Ganesh 1.0.2 Release End
																							}

																							sPTMNameActual = validator
																									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME))
																									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME)
																											: ConstantsUtil.EMPTY_STRING;
																									sPTMNameActualType = validator
																											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE))
																											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE)
																													: ConstantsUtil.EMPTY_STRING;
																											sPTMNameActualID = validator
																													.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID))
																													? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID)
																															: ConstantsUtil.EMPTY_STRING;
																													if (showData) {
																														formatData(sTMNActual, sPTMNameActual);
																														formatData(sTMNActualID, sPTMNameActualID);
																														formatData(sTMNActualType, sPTMNameActualType);
																													} else {
																														formatData(sTMNActual, sPTMNameActual);
																														formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
																														formatData(sTMNActualType, sPTMNameActualType);
																													}

																						}
																			}
																		} else {

																			StringList slTMName = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME);
																			StringList slTMType = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE);
																			StringList slsChildObjectID = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID);
																			StringList slTMHasSharedAccess = (StringList) objectMap
																					.get(ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS);

																			boolean showData = false;
																			boolean bHasOwnership = false;
																			if (isModificatinRequired()) {
																				Map<String, StringList> mpTemp = new HashMap<String, StringList>();
																				mpTemp.put(ConstantsUtil.TYPE, slTMType);
																				mpTemp.put(ConstantsUtil.NAME, slTMName);
																				mpTemp.put(ConstantsUtil.SECURITY, slTMHasSharedAccess);
																				mpTemp.put(ConstantsUtil.ID, slsChildObjectID);

																				Map mpTemp1 = showOrHideSOPAndTM(context, mpTemp);

																				SecurityService sec = new SecurityService();
																				String sComp = sec.getUserCauthorities();
																				StringList slUserOwnership = filterOwnerShip(sComp);

																				slTMName = (StringList) mpTemp1.get(ConstantsUtil.NAME);
																				slTMType = (StringList) mpTemp1.get(ConstantsUtil.TYPE);
																				slsChildObjectID = (StringList) mpTemp1.get(ConstantsUtil.ID);
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																				StringList slTempsChildObjectID = new StringList();
																				StringList slTempTMName = new StringList();
																				StringList slTempTMType = new StringList();
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END

																				for (int i = 0; i < slsChildObjectID.size(); i++) {
																					String strOID = slsChildObjectID.get(i);
																					//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																					String strName = slTMName.get(i);
																					String strType = slTMType.get(i);
																					//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																					// Added by Ganesh 1.0.2 Release Start
																					
																					bHasOwnership = checkHasAccess(context, sUserType, strOID);
																					// Added by Ganesh 1.0.2 Release End
																					if (bHasOwnership) {
																						showData = true;
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																						slTempsChildObjectID.add(strOID);
																						slTempTMName.add(strName);
																						slTempTMType.add(strType);
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																					} else {
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																						continue;
																						
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																					}
																					//SPEC: <18.07.2022>: Guna Modified for Defect 47236 22x Release  -- START
																					slTempsChildObjectID.add(strOID);
																					//SPEC: <18.07.2022>: Guna Modified for Defect 47236 22x Release  -- END
																				}
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																				slTMName = (StringList) mpTemp1.get(ConstantsUtil.NAME);
																				slTMType = (StringList) mpTemp1.get(ConstantsUtil.TYPE);
																				slsChildObjectID = (StringList) mpTemp1.get(ConstantsUtil.ID); 

																				slsChildObjectID = slTempsChildObjectID;
																				slTMName = slTempTMName;
																				slTMType = slTempTMType;
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END

																			}

																			Map mpTemp2 = removeTestMethod(context, slTMName, slTMType, slsChildObjectID);

																			StringList slTMFilteredName = (StringList) mpTemp2.get(ConstantsUtil.TMFILNAME);
																			StringList slTMFilterID = (StringList) mpTemp2.get(ConstantsUtil.TMFILID);
																			StringList slTMFilterType = (StringList) mpTemp2.get(ConstantsUtil.TMFILTYPE);

																			slTMType = (StringList) mpTemp2.get(ConstantsUtil.BASETYPE);
																			slTMName = (StringList) mpTemp2.get(ConstantsUtil.BASENAME);
																			slsChildObjectID = (StringList) mpTemp2.get(ConstantsUtil.BASEID);

																			sPTMName = validator.isNotNullOrEmpty(slTMName.toString()) ? slTMName.toString()
																					: ConstantsUtil.EMPTY_STRING;
																			sPTMName = sPTMName.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																					.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																					.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																			// Security added for Staff AUG
																			StringList slTMSecurityCheck = new StringList();
																			if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																				int iSize = slsChildObjectID.size();
																				for (int i = 0; i < iSize; i++) {
																					String strOID = slsChildObjectID.get(i);

																					
																					showData = checkHasAccess(context, sUserType, strOID);
																					// Added by Ganesh 1.0.2 Release End

																					if (showData) {
																						slTMSecurityCheck.add(strOID);
																					} else {
																						slTMSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																					}
																				}
																			} else {
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 --START
																				StringList slTempsChildObjectID = new StringList();
																				StringList slTempTMName = new StringList();
																				StringList slTempTMType = new StringList();
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 29, 2021 for Defect 41085 -- START
																				int iSize = slsChildObjectID.size();
																				for (int i = 0; i < iSize; i++) {
																					String strOID = slsChildObjectID.get(i);
																					//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																					String strType = slTMType.get(i);
																					String strName = slTMName.get(i);
																					//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																					
																					// Added by Ganesh 1.0.2 Release Start
																					
																					BusObjectAttribUtil util = new BusObjectAttribUtil();
																					showData = util.checkHasAccess(context, sUserType, strOID);
																					// Added by Ganesh 1.0.2 Release End

																					if (showData) {
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																						if(isExternal)
																						{
																							slTempsChildObjectID.add(strOID);
																							slTempTMName.add(strName);
																							slTempTMType.add(strType);
																						}
																						else
																							//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																							slTMSecurityCheck.add(strOID);	
																					} else {
																						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																						if(isExternal)
																							continue;
																						else
																							//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																							slTMSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																					}
																				}
																				
																				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 29, 2021 for Defect 41085 -- END
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																				if(isExternal)
																				{
																					slTMSecurityCheck = slTempsChildObjectID;
																					slTMName = slTempTMName;
																					slTMType = slTempTMType;
																				}
																				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																			}

																			

																			sPTMNameID = validator.isNotNullOrEmpty(slTMSecurityCheck.toString())
																					? slTMSecurityCheck.toString() : ConstantsUtil.EMPTY_STRING;

																					sPTMNameID = sPTMNameID.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																							.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																							.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																					sPTMType = validator.isNotNullOrEmpty(slTMType.toString()) ? slTMType.toString()
																							: ConstantsUtil.EMPTY_STRING;
																					sPTMType = sPTMType.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																							.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																							.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																					

																					formatData(sTMNActualID, sPTMNameID);
																					formatData(sTMNActual, sPTMName);
																					formatData(sTMNActualType, sPTMType);

																					sPTMNameActual = validator.isNotNullOrEmpty(slTMFilteredName.toString())
																							? slTMFilteredName.toString() : ConstantsUtil.EMPTY_STRING;
																							sPTMNameActual = sPTMNameActual
																									.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																									.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																									.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																							StringList slTMActualSecurityCheck = new StringList();
																							if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																								int iSize = slTMFilterID.size();
																								for (int i = 0; i < iSize; i++) {
																									String strOID = slTMFilterID.get(i);

																									
																									BusObjectAttribUtil util = new BusObjectAttribUtil();
																									showData = util.checkHasAccess(context, sUserType, strOID);
																									// Added by Ganesh 1.0.2 Release End

																									if (showData) {
																										slTMActualSecurityCheck.add(strOID);
																									} else {
																										slTMActualSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																									}
																								}
																							} else {

																								StringList slTempsChildObjectID = new StringList();
																								StringList slTempTMName = new StringList();
																								StringList slTempTMType = new StringList();
																								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																								int iSize = slTMFilterID.size();
																								for (int i = 0; i < iSize; i++) {
																									String strOID = slTMFilterID.get(i);
																									//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																									String strName = slTMFilteredName.get(i);
																									String strType = slTMFilterType.get(i);
																									//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																									
																									BusObjectAttribUtil util = new BusObjectAttribUtil();
																									showData = util.checkHasAccess(context, sUserType, strOID);
																									// Added by Ganesh 1.0.2 Release End

																									if (showData) {
																										//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																										if(isExternal)
																										{
																											slTempsChildObjectID.add(strOID);
																											slTempTMName.add(strName);
																											slTempTMType.add(strType);
																										}
																										else
																											//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																											slTMActualSecurityCheck.add(strOID);	
																									} else {
																										//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																										if(isExternal)
																											continue;
																										else
																											//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																											slTMActualSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																									}
																								}
																								//SPEC: Release SR18x.6.0 - Added by Amman on Mar 29, 2021 for Defect 41085 -- END
																								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																								if(isExternal)
																								{
																									slTMActualSecurityCheck = slTempsChildObjectID;
																									slTMFilteredName = slTempTMName;
																									slTMFilterType = slTempTMType;
																								}
																								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																							}

																							

																							sPTMNameActualID = validator.isNotNullOrEmpty(slTMActualSecurityCheck.toString())
																									? slTMActualSecurityCheck.toString() : ConstantsUtil.EMPTY_STRING;

																									sPTMNameActualID = sPTMNameActualID
																											.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																											.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																											.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																									sPTMNameActualType = validator.isNotNullOrEmpty(slTMFilterType.toString())
																											? slTMFilterType.toString() : ConstantsUtil.EMPTY_STRING;
																											sPTMNameActualType = sPTMNameActualType
																													.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																													.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																													.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																											

																											formatData(sTMName, sPTMNameActual);
																											formatData(sTMNameID, sPTMNameActualID);
																											formatData(sTMNameType, sPTMNameActualType);

																		}
																		//SPEC: Release SR18x.6.0 - #Defect-43785 Added by Ganesh -- START
																		//commented by Ganesh for Defect 43830 ------>START
																		
					
																		//commented by Ganesh for Defect 43830 ------>STOP
																		//SPEC: Release SR18x.6.0 - #Defect-43785 Added by Ganesh -- END
																	} else {
																		boolean showData = false;
																		if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																			
																			BusObjectAttribUtil util = new BusObjectAttribUtil();
																			showData = util.checkHasAccess(context, sUserType, sPTMNameID);
																			// Added by Ganesh 1.0.2 Release Start
																		}
																		if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF) && !showData) {
																			formatData(sTMNameID, ConstantsUtil.NO_ACCESS);
																			formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
																		} else {
																			formatData(sTMNameID, sPTMNameActualID);
																			formatData(sTMNActualID, sPTMNameID);
																		}
																		formatData(sTMName, sPTMNameActual);
																		formatData(sTMNameType, sPTMNameActualType);
																		formatData(sTMNActual, sPTMName);
																		formatData(sTMNActualType, sPTMType);

																		//SPEC: Release SR18x.6.0 - #Defect-43785 Added by Ganesh -- START
																		
																		//Commented by Ganesh for Defect 43830 ------>STOP
																		//SPEC: Release SR18x.6.0 - #Defect-43785 Added by Ganesh -- END
																	}
																	// SPEC: 10/09/2020: Modified for 18x.5 DEV -- END

																	//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- START
																	if (sForCPSType.equalsIgnoreCase("Shared Table")) {
																		sCPS.append(sForCPSType).append("|");
																		sCPSName.append(sForCPSName).append("|");
																		sCPSId.append(sForCPSId).append("|");
																	} else {
																		String sCPSCharName = validator
																				.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME))
																				? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME)
																						: ConstantsUtil.EMPTY_STRING;
																				String sCPSCharType = validator
																						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE))
																						? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE)
																								: ConstantsUtil.EMPTY_STRING;
																						String sCPSCharID = validator
																								.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID))
																								? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID)
																										: ConstantsUtil.EMPTY_STRING;

																								sCPS.append(sCPSCharType).append("|");
																								sCPSName.append(sCPSCharName).append("|");
																								sCPSId.append(sCPSCharID).append("|");
																	}
																	//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 10 May 2021 -- END
																	String sPathId = validator
																			.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_ID));
																	//modified by for Defect 38256 Release 18x.5.2---->start

																	//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT Internal Defect on 05/18/2021 - START
																	String sPathIdforMPT = sPathId;
																	//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT Internal Defect on 05/18/2021 - END

																	boolean showData = checkHasAccess(context, sUserType, sPathId);
																	if(!showData)
																	{
																		sPathId = ConstantsUtil.NO_ACCESS;
																	}
																	//modified by for Defect 38256 Release 18x.5.2---->end
																	String sPathType = validator
																			.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_TYPE));

																	String sPTMLogic = validator
																			.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC));
																	String sPMethodOrigin = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN));

																	// SPEC: 12/04/2020: Modified for Defect 37782 by Amman--
																	
																	String sPMethodNumber = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER));

																	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 24, 2021 for Defect #43763/43764 -- START
																	sPMethodNumber=sPMethodNumber.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_AND);
																	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 24, 2021 for Defect #43763/43764 -- END

																	
																	String sPMethodSpecific = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS));
																	sPMethodSpecific = sPMethodSpecific.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);//Added by Ketan for Defect no. 8596
																	// SPEC: 12/04/2020: Modified for Defect 37782 by Amman--
																	// END

																	String sPSampling = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING));
																	sPSampling = sPSampling.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);//Added by Ajay for Defect no. 13124

																	
																	String sPSubGroup = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP));
																	
																	String sPPlantTesting = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING));
																	String sPPlantRetesting = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING));

																	// SPEC: 12/04/2020: Modified for Defect 37782 by Amman--
																	// START
																	
																	String sPTestingUOM = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM));
																	// SPEC: 12/04/2020: Modified for Defect 37782 by Amman--
																	// END
																	// SPEC: 02/04/2021: Added for Defect 38792 -- START
																	String sPPlantTestingText = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGTEXT));
																	String sReTestUOM = ConstantsUtil.EMPTY_STRING;
																	if((null!=sPTestingUOM)&&(sPTestingUOM.equalsIgnoreCase("DAYS"))){
																		sReTestUOM = "D";
																	}else if((null!=sPTestingUOM)&&(sPTestingUOM.equalsIgnoreCase("WEEKS"))){
																		sReTestUOM = "W";
																	}else if((null!=sPTestingUOM)&&(sPTestingUOM.equalsIgnoreCase("MONTHS"))){
																		sReTestUOM = "M";
																	}else if((null!=sPTestingUOM)&&((sPTestingUOM.equalsIgnoreCase("YEARS") || (sPTestingUOM.equalsIgnoreCase("YEAR"))))){
																		sReTestUOM = "Y";
																	}

																	StringBuffer slInter = new StringBuffer();
																	slInter.append(sPPlantTesting).append(" ").append(sPPlantTestingText).append(" ").append(sReTestUOM);
																	String sPlantTestingValue =slInter.toString();
																	// SPEC: 02/04/2021: Added for Defect 38792 -- End

																	//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 09, 2021 for Defect #43397 -- START
																	
																	String sPLowerSpecLimit = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT));
																	//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 09, 2021 for Defect #43397 -- END

																	String sPLowerRoutineReleaseLimit = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT));
																	//SPEC: 15-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50642-- START
																	String sPPGLowerTarget = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET));
																	String sPPGTarget = validator
																			.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET));
																	String sPPGUpperTarget = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET));
																	//SPEC: 15-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50642-- END
																	String sPUpperRoutineRL = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT));

																	//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 09, 2021 for Defect #43397 -- START
																	
																	String sPPGUpperSpecLimit = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT));
																	//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 09, 2021 for Defect #43397 -- END
																	//SPEC: Release SR18x.6.0.2 Modified by Dominic for Defect 44190 on Date 02/09/2021 --START
																	/*String sPUnitOfMeasure = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE));*/
																	String sPUnitOfMeasure = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE));
																	//SPEC: Release SR18x.6.0.2 Modified by Dominic for Defect 44190 on Date 02/09/2021 --END
																	//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 29, 2021 for Defect #43896 -- START
																	
																	String sPPGReportNear = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST));
																	//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 29, 2021 for Defect #43896 -- END

																	String sPPGReportType = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE));
																	String sPReleseCriteria = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA));
																	sPReleseCriteria = sPReleseCriteria.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);//Added by Ketan for Defect no. 8596
																	String sPPGACtionRequired = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED));
																	String sPCriticalFactor = validator.getStringEquivalentForStringList(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR));
																	// SPEC: 12/04/2020: Modified for Defect 37782 by Amman--
																	
																	String sPPGBasis = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS));
																	
																	String sTestGroup = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP));
																	// SPEC:01/10/2020- Modified for Defect 37217 - START
																	
																	String sApplication = validator.getStringEquivalentForSubstituteString(
																			objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION));
																	sApplication = sApplication.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);//Added by Ketan for Defect no. 50544
																	// SPEC: 12/04/2020: Modified for Defect 37782 by Amman--
																	// END
																	// SPEC:01/10/2020- Modified for Defect 37217 - END

																	String sTitle = ConstantsUtil.EMPTY_STRING;

																	//Release SR18x.5.2 - Modified for Defect#39538 by Govind On Date 16/02/2021 start
																	boolean bPresent = objectMap.containsKey(ConstantsUtil.PERFORMCHAR_MPT_TITLE);
																	
																	// SPEC: 12/04/2020: Modified for Defect 37782 by Amman--
																	// START
																	//SPEC: Release SR18x.6.0 - Modified  by Manikanta for defect 41917 on Date 31/03/2021 -- START
																	if (bPresent) {
																		
																		sTitle = (String) mpResultMPT.get(sPathIdforMPT);
																		//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for Internal Defect on 05/18/2021 - END

																		//SPEC: Release SR18x.6.0 - Added for ExternalDefect# by gaikwad.tg on Date 29 April 2021 -- START

																		
																		////SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
																		formatData(sbPathId, sPathId);
																		formatData(sbPathType, sPathType);
																		formatData(sPath, sPPath);

																		formatData(schg, sPchg);
																		formatData(sCharcteristic, sPCharcteristic);
																		formatData(sCharSpec, sPCharSpec);

																		
																		//SPEC: Release SR18x.6.0 - #Defect-43785 Added by Ganesh -- START
																		//Modified by Ganesh for Defect 43830 ------>START
					
																		formatData(sTMLogic, sPTMLogic);
																		//Modified by Ganesh for Defect 43830 ------>STOP
																		//SPEC: Release SR18x.6.0 - #Defect-43785 Added by Ganesh -- END
																		formatData(sMethodOrigin, sPMethodOrigin);
																		formatData(sMethodNumber, sPMethodNumber);
																		formatData(sMethodSpecific, sPMethodSpecific);

																		formatData(sSampling, sPSampling);
																		formatData(sSubGroup, sPSubGroup);
																		// SPEC: 02/04/2021: Added for Defect 38792 -- START					
																		//SPEC: Release SR18x5.2- modified for Defect #38792 by Govind on Date 20/02/2021 start
																		//String sType = ((String) resultMap.get(ConstantsUtil.SELECT_TYPE));
																		//Modified by Ganesh for Defect 41386 & 41483 on date <24/Mar/2021>---->Start
																		

						//SPEC: Release SR18x6.0- modified for Defect #41546 by Manikanta on Date 24/03/2021 end
					
					//Modified by Ganesh for Defect 41386 & 41483 on date <24/Mar/2021>---->END
																		 
																		formatData(sPlantTesting, sPPlantTesting);
																		//SPEC: Release SR18x.6.0 - Added by Amman on Apr 2, 2021 for Defect related to LVL attribute -- END

																		formatData(sTestingUOM, sPTestingUOM);

																		formatData(sLowerSpecLimit, sPLowerSpecLimit);
																		formatData(sLowerRoutineReleaseLimit, sPLowerRoutineReleaseLimit);
																		formatData(sPGLowerTarget, sPPGLowerTarget);
																		formatData(sPGTarget, sPPGTarget);
																		formatData(sPGUpperTarget, sPPGUpperTarget);
																		formatData(sUpperRoutineRL, sPUpperRoutineRL);
																		formatData(sPGUpperSpecLimit, sPPGUpperSpecLimit);

																		formatData(sUnitOfMeasure, sPUnitOfMeasure);
																		formatData(sPGReportNear, sPPGReportNear);
																		formatData(sPGReportType, sPPGReportType);
																		formatData(sReleseCriteria, sPReleseCriteria);
																		formatData(sPGACtionRequired, sPPGACtionRequired);
																		formatData(sCriticalFactor, sPCriticalFactor);
																		formatData(sPGBasis, sPPGBasis);

																		formatData(sPTestGroup, sTestGroup);
																		formatData(sPApplication, sApplication);
																		formatData(sPMTitle, sTitle);

																		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 26, 2021 for Defect 41788 -- START
																		formatData(sPlantRetesting,sPPlantRetesting);
																		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 26, 2021 for Defect 41788 -- END
																	}
																	mpFinal.put(ConstantsUtil.CHG, schg.toString());
																	mpFinal.put(ConstantsUtil.CHARACTERISTICCH, sCharcteristic.toString());
																	mpFinal.put(ConstantsUtil.CS, sCharSpec.toString());

																	// SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
																	mpFinal.put(ConstantsUtil.CHARP, sPath.toString());
																	
																	// SPEC: 10/09/2020: Modified for 18x.5 DEV -- END

																	mpFinal.put(ConstantsUtil.REF, sTMNActual.toString());
																	mpFinal.put(ConstantsUtil.REFID, sTMNActualID.toString());
																	mpFinal.put(ConstantsUtil.REFTYPE, sTMNActualType.toString());

																	mpFinal.put(ConstantsUtil.PATH_ID, sbPathId.toString());
																	mpFinal.put(ConstantsUtil.PATH_TYPE, sbPathType.toString());

																	mpFinal.put(ConstantsUtil.TMTYPE, sTMNameType.toString());
																	mpFinal.put(ConstantsUtil.TESTMETHODNAME, sTMName.toString());
																	mpFinal.put(ConstantsUtil.TESTMETHODNAMEID, sTMNameID.toString());

																	mpFinal.put(ConstantsUtil.TML, sTMLogic.toString());
																	mpFinal.put(ConstantsUtil.ORIGIN, sMethodOrigin.toString());
																	mpFinal.put(ConstantsUtil.TM, sMethodNumber.toString());
																	mpFinal.put(ConstantsUtil.SP, sMethodSpecific.toString());

																	mpFinal.put(ConstantsUtil.SAMPLINGSM, sSampling.toString());
																	mpFinal.put(ConstantsUtil.SG, sSubGroup.toString());
																	// Added by Pooja for the req 35902-- START
																	if ((sUserType.equals(ConstantsUtil.PG)) || (sUserType.equals(ConstantsUtil.PGSTAFF))|| (sUserType.equals(ConstantsUtil.PG_CM))) { 
																	mpFinal.put(ConstantsUtil.PLANTTESTING, sPlantTesting.toString());
																	mpFinal.put(ConstantsUtil.RT, sPlantRetesting.toString());
																	mpFinal.put(ConstantsUtil.UOM, sTestingUOM.toString());
																	}
																	// Added by Pooja for the req 35902-- START
																	
																	mpFinal.put(ConstantsUtil.LOWERSPECLIMIT, sLowerSpecLimit.toString());
																	mpFinal.put(ConstantsUtil.LRRL, sLowerRoutineReleaseLimit.toString());
																	mpFinal.put(ConstantsUtil.LTGT, sPGLowerTarget.toString());
																	mpFinal.put(ConstantsUtil.TGT, sPGTarget.toString());
																	mpFinal.put(ConstantsUtil.UTGT, sPGUpperTarget.toString());
																	mpFinal.put(ConstantsUtil.URRL, sUpperRoutineRL.toString());
																	mpFinal.put(ConstantsUtil.USL, sPGUpperSpecLimit.toString());

																	mpFinal.put(ConstantsUtil.UNITOF, sUnitOfMeasure.toString());
																	mpFinal.put(ConstantsUtil.RTN, sPGReportNear.toString());
																	mpFinal.put(ConstantsUtil.RTT, sPGReportType.toString());
																	mpFinal.put(ConstantsUtil.RELEASECRITERIA, sReleseCriteria.toString());

																	mpFinal.put(ConstantsUtil.ACTIONREQUIRED, sPGACtionRequired.toString());
																	mpFinal.put(ConstantsUtil.CAPSCR, sCriticalFactor.toString());
																	mpFinal.put(ConstantsUtil.BA, sPGBasis.toString());

																	mpFinal.put(ConstantsUtil.TESTGROUP, sPTestGroup.toString());
																	mpFinal.put(ConstantsUtil.AP, sPApplication.toString());
																	mpFinal.put(ConstantsUtil.MPT, sPMTitle.toString());
																	// if(isModificatinRequired()){

																	mpFinal.put(ConstantsUtil.CPS, sCPS.toString());
																	mpFinal.put(ConstantsUtil.CPSNAME, sCPSName.toString());
																	mpFinal.put(ConstantsUtil.CPSID, sCPSId.toString());
																	// }

						}
					}
				} catch (Exception e) {
					LOGGER.error("Exception from BusObjectAttribUtil:  updatePerformCharcteristic" + e);
					return new HashMap();
				}
				return mpFinal = filterMapList(mpFinal);

	}

	//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
	//SPEC: Release SR18x.6.0.1 - Added for Defect# 43145  by gaikwad.tg on Date 25 May 2021 -- START
	public boolean checkIfReleased(Context context, String sPTMNameID) {
		// TODO Auto-generated method stub
		boolean isReleased = false;
		try
		{
			if(UIUtil.isNotNullAndNotEmpty(sPTMNameID))
			{
				DomainObject dObject = DomainObject.newInstance(context, sPTMNameID);
				String strCurrent = dObject.getInfo(context, ConstantsUtil.SELECT_CURRENT);
				if(UIUtil.isNotNullAndNotEmpty(strCurrent) && strCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE))
					isReleased = true;
			}
		}
		catch(Exception e)
		{
			LOGGER.error("Exception from BusObjectAttribUtil:  checkIfReleased" + e);
			return false;
		}
		return isReleased;
	}
	//SPEC: Release SR18x.6.0.1 - Added for Defect# 43145  by gaikwad.tg on Date 25 May 2021 -- END
	public Map getDerivedTitleForRow(Context context, String[] args) throws Exception {
		List returnVector = new Vector();
		Map mpReturnMap = new HashMap();
		final String SELECT_ATTR_REF_TYPE = "attribute[Reference Type]";
		final String SELECT_ATTR_TITLE = "attribute[Title]";
		final String SELECT_TO_CLASS_ITEM_FROM_PART_FAMILY_ID =  "to[Protected Item].from[Part Family].id";
		final String SELECT_ATTR_REL_REF_DOC = "attribute[Reference Document]";
		final String SELECT_ATTR_PG_INHERIT_TYPE = "attribute[pgPFInheritanceType]";
		//DSM (DS) 2015x.5 ALM 16966 - Suppliers cant see right path of performance characteristic - STARTS
		boolean isContextPushed = false;
		//DSM (DS) 2015x.5 ALM 16966 - Suppliers cant see right path of performance characteristic - ENDS
		try
		{
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			MapList mlObjectList = (MapList)programMap.get("objectList");
			Map paramMap = (Map<?,?>)programMap.get("paramList");
			String strselectedTable = "pgVPDPerformanceCharacteristicTable";
			String strMasterPartId = DomainConstants.EMPTY_STRING;
			String strMasterPartName = DomainConstants.EMPTY_STRING;
			String strMasterPartTitle = DomainConstants.EMPTY_STRING;
			boolean bMasterExists = false;
			String strselectedFilter = "pgVPDCPNCharacteristicDerivedFilter";
			String strParentId = programMap.get("parentOID").toString();
			String strCharwhere ="attribute[pgPFInheritanceType]==Local";
			MapList partFamilyList = new MapList();
			String strSpecInheritanceType = DomainConstants.EMPTY_STRING;
			String strParentName = DomainConstants.EMPTY_STRING;
			String strParentTitle = DomainConstants.EMPTY_STRING;
			String strParentType = DomainConstants.EMPTY_STRING;
			MapList lowerPartFamilyMapList = null;
			StringList upperPartFamilyList = null;
			StringList lowerPartFamilyListLower = null;
			String strParentRefType = DomainConstants.EMPTY_STRING;
			StringList partFamilyisList = new StringList();
			DomainObject partFamilyObj = null;

			String objReadAccess = "";
			String strRowMasterId = DomainConstants.EMPTY_STRING;
			String strRowMasterName = DomainConstants.EMPTY_STRING;
			String strRowMasterTitle = DomainConstants.EMPTY_STRING;
			String strRowType = DomainConstants.EMPTY_STRING;
			String strRowId = DomainConstants.EMPTY_STRING;
			String strRowTitle = DomainConstants.EMPTY_STRING;
			DomainObject masterObj = null;
			String derivedPath = DomainConstants.EMPTY_STRING;

			if(UIUtil.isNotNullAndNotEmpty(strParentId))
			{
				DomainObject parentObj = DomainObject.newInstance(context, strParentId);
				StringList slParentObj = new StringList(2);
				slParentObj.add(SELECT_ATTR_REF_TYPE);
				slParentObj.add(SELECT_TO_CLASS_ITEM_FROM_PART_FAMILY_ID);
				slParentObj.add("name");
				slParentObj.add("attribute[Title]");
				slParentObj.add("type");
				slParentObj.add("to[Protected Item].frommid[Part Family Reference].torel.to.id");
				slParentObj.add("to[Protected Item].frommid[Part Family Reference].torel.to.name");
				slParentObj.add("to[Protected Item].frommid[Part Family Reference].torel.to.attribute[Title]");

				Map<?,?> mapParentObj = parentObj.getInfo(context,slParentObj);
				strParentRefType = (String) mapParentObj.get(SELECT_ATTR_REF_TYPE);

				String partFamilyId = (String) mapParentObj.get(SELECT_TO_CLASS_ITEM_FROM_PART_FAMILY_ID);
				strParentName = (String)mapParentObj.get("name");
				strParentTitle = (String)mapParentObj.get("attribute[Title]");
				strParentType = (String)mapParentObj.get("type");
				strMasterPartId = (String)mapParentObj.get("to[Protected Item].frommid[Part Family Reference].torel.to.id");
				strMasterPartName = (String)mapParentObj.get("to[Protected Item].frommid[Part Family Reference].torel.to.name");
				strMasterPartTitle = (String)mapParentObj.get("to[Protected Item].frommid[Part Family Reference].torel.to.attribute[Title]");
				if(UIUtil.isNotNullAndNotEmpty(strMasterPartId) && UIUtil.isNotNullAndNotEmpty(strMasterPartName)) {
					bMasterExists = true;
				}
				StringList objectSelects = new StringList();
				objectSelects.add("name");
				objectSelects.add("id");

				if(UIUtil.isNotNullAndNotEmpty(partFamilyId) && !"pgVPDPerformanceCharacteristicTable".equals(strselectedTable) && !"pgVPDPerformanceCharacteristicMasterPathTable".equals(strselectedTable))	

				{

					HashMap hmArgs = new HashMap();
					hmArgs.put("objectId",partFamilyId);
					String[] strArgs = JPO.packArgs(hmArgs);	
					partFamilyisList = JPO.invoke(context, "emxCPNCharacteristicList", null,"getPartFamilyListFromHeirarchy", strArgs, StringList.class);	    			
				}
			}
			if(UIUtil.isNullOrEmpty(strselectedTable))
			{
				strselectedTable = (String)paramMap.get("table");
			}

			if(mlObjectList != null && !mlObjectList.isEmpty())
			{
				Iterator objListItr = mlObjectList.iterator();

				StringBuilder tempValBuffer = new StringBuilder();
				DomainObject charObj = null;
				String strSpecObjId = DomainConstants.EMPTY_STRING;
				String strRefType = DomainConstants.EMPTY_STRING;
				String strConnectedPFId = DomainConstants.EMPTY_STRING;
				StringList connectedMasterNameList = new StringList();
				StringList connectedMasterTitleList = new StringList();
				StringList connectedMasterIdList = new StringList();

				StringList selectStmts = new StringList(4);
				selectStmts.add("name");
				selectStmts.add("id");
				selectStmts.add(SELECT_ATTR_TITLE);
				selectStmts.add(SELECT_ATTR_REF_TYPE);
				selectStmts.add("to[Protected Item].from[Part Family].id");
				StringList connectedMasterPFList = new StringList();
				Map<String, StringList> MasterPFMap = new HashMap<String, StringList>();

				StringList selectRelStmts = new StringList(2);
				selectRelStmts.add(SELECT_ATTR_REL_REF_DOC);
				selectRelStmts.add(SELECT_ATTR_PG_INHERIT_TYPE);

				String strInheritanceType  = null;
				MapList connectedPartList = null;
				String strTitle = "";
				Iterator mapItr = null;
				Map map = null;
				DomainObject connectedMasterObj = null;
				StringList masterTitleList = new StringList();
				StringList masterNamelist = new StringList();


				if(UIUtil.isNotNullAndNotEmpty(strselectedFilter) &&  strselectedFilter.equals("Local"))
				{

					while (objListItr.hasNext())
					{
						Map objMap = (Map) objListItr.next();
						//returnVector.add(DomainConstants.EMPTY_STRING);
						mpReturnMap.put(DomainConstants.EMPTY_STRING,DomainConstants.EMPTY_STRING);
					}
					//return returnVector;
					return mpReturnMap;
				}
				ContextUtil.pushContext(context,"User Agent",DomainConstants.EMPTY_STRING,DomainConstants.EMPTY_STRING);
				isContextPushed = true;
				String strPathId = DomainConstants.EMPTY_STRING;
				while (objListItr.hasNext())
				{
					Map objMap = (Map) objListItr.next();
					if(objMap != null && !objMap.isEmpty())
					{
						objReadAccess = (String)objMap.get("objReadAccess");
						objReadAccess = "TRUE"; //temp value
						if((UIUtil.isNotNullAndNotEmpty(objReadAccess) && "TRUE".equals(objReadAccess)) && ("pgDSOMasterPartDetails".equals(strselectedTable) 
								|| "pgVPDPerformanceCharacteristicTable".equals(strselectedTable) 
								|| "ENCDocumentSummary".equals(strselectedTable) 
								|| "pgVPDAPPDocumentSummary".equals(strselectedTable) 
								|| "pgVPDPerformanceCharacteristicMasterPathTable".equals(strselectedTable)))

						{
							strPathId = (String)objMap.get(ConstantsUtil.PERFORMCHAR_ID);
							String strCharId = (String)objMap.get("id");//pass
							String strRelationship = (String)objMap.get("relationship");//pass
							strRowMasterId = (String)objMap.get("strMasterID");
							strRowMasterName = (String)objMap.get("strMasterName");
							strRowMasterTitle = (String)objMap.get("strMasterTitle");
							strRowTitle = (String)objMap.get("strRowTitle");
							strRowType = (String)objMap.get("strRowType");
							derivedPath = (String)objMap.get("derivedPath");//pass

							if(UIUtil.isNotNullAndNotEmpty(strRowMasterId) && UIUtil.isNotNullAndNotEmpty(strParentType) 
									&& "Finished Product Part".equals(strParentType) && ("pgVPDAPPDocumentSummary".equals(strselectedTable) 
											|| "pgDSOMasterPartDetails".equals(strselectedTable)))									 
							{
								masterObj = DomainObject.newInstance(context, strRowMasterId);
								strConnectedPFId = masterObj.getInfo(context, "to[Protected Item].from["+ DomainConstants.TYPE_PART_FAMILY +"].id");

								HashMap hArgs = new HashMap();
								hArgs.put("objectId",strConnectedPFId);
								String[] strArgs = JPO.packArgs(hArgs);	
								partFamilyisList = JPO.invoke(context, "emxCPNCharacteristicList", null,"getPartFamilyListFromHeirarchy", strArgs, StringList.class);	    						 
							}


							if(UIUtil.isNotNullAndNotEmpty(strRelationship) && strRelationship.equals("pgInheritedCADSpecification"))
							{
								strRelationship = strRelationship + ",Part Specification";
							}
							charObj = DomainObject.newInstance(context, strCharId);

							/*if(UIUtil.isNotNullAndNotEmpty(strIsStructureCompare) 
		    								&& pgDSOConstants_mxJPO.CONST_TRUE.equalsIgnoreCase(strIsStructureCompare) 
		    								&& !charObj.isKindOf(context, CPNCommonConstants.TYPE_CHARACTERISTIC )){
		    							returnVector.add(DomainConstants.EMPTY_STRING);
		    							continue;
		    						}*/
							tempValBuffer = new StringBuilder();	
							connectedMasterNameList.removeAll(connectedMasterNameList);
							connectedMasterTitleList.removeAll(connectedMasterTitleList);
							connectedMasterIdList.removeAll(connectedMasterIdList);
							strSpecInheritanceType = (String)objMap.get("attribute[pgPFInheritanceType].value");
							if(UIUtil.isNullOrEmpty(strSpecInheritanceType)) {
								strSpecInheritanceType = (String)objMap.get("attribute[pgPFInheritanceType]");
							}
							if(UIUtil.isNullOrEmpty(strSpecInheritanceType))
							{
								strSpecInheritanceType = (String)objMap.get("strInheritanceType");
							}
							if("Finished Product Part".equals(strParentType) 
									&& ("pgVPDAPPDocumentSummary".equals(strselectedTable)|| "pgDSOMasterPartDetails".equals(strselectedTable)) 
									&& ("pgCustomerUnitPart".equals(strRowType) || "pgInnerPackUnitPart".equals(strRowType) || "pgConsumerUnitPart".equals(strRowType)))
							{
								connectedMasterTitleList.add(strRowMasterTitle);
								//returnVector.add(strRowMasterTitle);
								mpReturnMap.put(strPathId,strRowMasterTitle);
								return mpReturnMap;
								//return returnVector;

							}
							if("Local".equalsIgnoreCase(strSpecInheritanceType) 
									&& !"pgVPDPerformanceCharacteristicTable".equals(strselectedTable) 
									&& !"pgVPDPerformanceCharacteristicMasterPathTable".equals(strselectedTable)) {

								if("Finished Product Part".equals(strParentType) && ("pgVPDAPPDocumentSummary".equals(strselectedTable) 
										|| "pgDSOMasterPartDetails".equals(strselectedTable))
										&& UIUtil.isNotNullAndNotEmpty(strRowMasterName) && UIUtil.isNotNullAndNotEmpty(strRowMasterId))								
								{
									connectedMasterIdList.add(strRowMasterId);
									connectedMasterNameList.add(strRowMasterName);
									connectedMasterTitleList.add(strRowMasterTitle);
								}
								else if("Finished Product Part".equals(strParentType) && 
										("pgVPDAPPDocumentSummary".equals(strselectedTable) || "pgDSOMasterPartDetails".equals(strselectedTable)) 
										&& ("pgCustomerUnitPart".equals(strRowType) || "pgInnerPackUnitPart".equals(strRowType) || "pgConsumerUnitPart".equals(strRowType)))								
								{
									if(UIUtil.isNotNullAndNotEmpty(strRowTitle))
									{
										//returnVector.add(strRowTitle);
										mpReturnMap.put(strPathId,strRowTitle);
										continue;
									}

								}
								else if(("pgVPDAPPDocumentSummary".equals(strselectedTable) || "pgDSOMasterPartDetails".equals(strselectedTable)) 
										&& bMasterExists) {
									connectedMasterIdList.add(strMasterPartId);
									connectedMasterNameList.add(strMasterPartName);
									connectedMasterTitleList.add(strMasterPartTitle);
								} else {
									connectedMasterIdList.add(strParentId);
									connectedMasterNameList.add(strParentName);
									connectedMasterTitleList.add(strParentTitle);
								}

							} else {
								connectedPartList = charObj. getRelatedObjects(context,
										strRelationship,     				// relationship pattern
										DomainConstants.QUERY_WILDCARD, 	// object pattern
										selectStmts,						// object selects
										selectRelStmts,						// relationship selects
										true,				 				// to direction
										false,								// from direction
										(short) 1,							// recursion level
										"",									// object where clause
										strCharwhere,						// relationship where clause
										(short)0);

								connectedPartList.sort("name", "ascending", "String");		    							

								if (connectedPartList != null && connectedPartList.size() > 0)
								{
									mapItr = connectedPartList.iterator();
									connectedMasterNameList = new StringList();
									connectedMasterTitleList = new StringList();
									connectedMasterIdList = new StringList();
									connectedMasterPFList = new StringList();
									while(mapItr.hasNext())
									{
										map = (Map)mapItr.next();
										strRefType = (String)map.get("attribute[Reference Type]");
										strInheritanceType = (String)map.get(SELECT_ATTR_PG_INHERIT_TYPE);

										if(UIUtil.isNotNullAndNotEmpty(strRefType) && "R".equals(strRefType))
										{
											String strConnectedRefId  = (String)map.get("id");
											DomainObject conRefObj = DomainObject.newInstance(context ,strConnectedRefId);
											if(UIUtil.isNotNullAndNotEmpty(strInheritanceType) && strInheritanceType.equals("Referenced"))
											{
												strTitle = (String)conRefObj.getInfo(context, "to[Protected Item].frommid[Part Family Reference].torel.to.attribute[Title]");
											} 
											else 
											{
												strTitle = "";
											}

										}
										else if(UIUtil.isNullOrEmpty(strRefType) || "U".equals(strRefType))
										{
											strTitle = "";
										}
										else if(("M".equals(strRefType) 
												&& ("pgVPDAPPDocumentSummary".equals(strselectedTable) || "pgDSOMasterPartDetails".equals(strselectedTable))) 
												|| "pgVPDPerformanceCharacteristicTable".equals(strselectedTable) 
												|| (((("M".equals(strParentRefType) && "M".equals(strRefType)) || ("R".equals(strParentRefType) && "R".equals(strRefType))) 
														&& "ENCDocumentSummary".equals(strselectedTable))) || "pgVPDPerformanceCharacteristicMasterPathTable".equals(strselectedTable))		
										{
											strTitle = (String)map.get(SELECT_ATTR_TITLE);
										}
										if(UIUtil.isNotNullAndNotEmpty(strInheritanceType) && strInheritanceType.equals("Local"))
										{
											connectedMasterTitleList.add(strTitle);
											connectedMasterNameList.add((String)map.get("name"));
											connectedMasterIdList.add((String)map.get("id"));
											Object pfObjecIds = map.get("to[Protected Item].from[Part Family].id");
											connectedMasterPFList = new StringList();
											if(null != pfObjecIds) {
												if (pfObjecIds instanceof String) { 
													connectedMasterPFList.add((String)pfObjecIds);
												} else {    									 			
													connectedMasterPFList.addAll((StringList)pfObjecIds);
												}
											}
											MasterPFMap.put((String)map.get("id"), connectedMasterPFList);
										}	
									}
									if(!"pgVPDPerformanceCharacteristicTable".equals(strselectedTable) && !"pgVPDPerformanceCharacteristicMasterPathTable".equals(strselectedTable))
									{
										if(connectedMasterIdList.size() > 1)
										{
											for(int i=0, nSize = connectedMasterIdList.size() ; i < nSize ; i++)
											{
												StringList MasterPFList = MasterPFMap.get((String)connectedMasterIdList.get(i));
												boolean isSameHier = false;
												if(!MasterPFList.isEmpty()) {
													for(int l=0; l<MasterPFList.size();l++) {
														if(partFamilyisList.contains((String)MasterPFList.get(l)))
														{
															isSameHier=true;
															break;
														}
													}
												}
												if(isSameHier)
												{
													masterTitleList.add((String)connectedMasterTitleList.get(i));
													masterNamelist.add((String)connectedMasterNameList.get(i));
												}
											}
											connectedMasterTitleList = masterTitleList;
											connectedMasterNameList = masterNamelist;
										}
									}

									if(connectedMasterNameList.isEmpty())
									{
										map = (Map)connectedPartList.get(0);
										connectedMasterTitleList.add((String)map.get(SELECT_ATTR_TITLE));
										connectedMasterNameList.add((String)map.get("name"));
									}
								}

							}
							if(connectedMasterNameList.isEmpty())
								returnVector.add(DomainConstants.EMPTY_STRING);
							//mpReturnMap.put(DomainConstants.EMPTY_STRING,DomainConstants.EMPTY_STRING);
							else{
								String strTempVal = "";
								String strDelimiter ="";
								for(int i=0, nSize = connectedMasterNameList.size() ; i < nSize ; i++)
								{
									tempValBuffer.append(strDelimiter);
									tempValBuffer.append((String)connectedMasterTitleList.get(i));
									strDelimiter = " | ";
								}
								strTempVal = tempValBuffer.toString();
								//returnVector.add(strTempVal);
								mpReturnMap.put(strPathId,strTempVal);
							}

						}
						else
						{	//DSM (DS) 2015x.1.2 Added code to check the read access of the objects : Start
							if((UIUtil.isNotNullAndNotEmpty(objReadAccess) && "TRUE".equals(objReadAccess)))
							{

								String strDerivedPath = (String)objMap.get("derivedPath");
								if(UIUtil.isNotNullAndNotEmpty(strDerivedPath))
								{
									//returnVector.add(strDerivedPath);
									mpReturnMap.put(strPathId,strDerivedPath);
								}
								else
								{
									//returnVector.add(DomainConstants.EMPTY_STRING);
									mpReturnMap.put(DomainConstants.EMPTY_STRING,DomainConstants.EMPTY_STRING);
								}
							}
						}
					}
				}
			}
		}
		catch(Exception Ex)
		{
			Ex.printStackTrace();
			throw Ex;

		}
		finally
		{
			if(isContextPushed)
				ContextUtil.popContext(context);
		}
		//return returnVector;
		return mpReturnMap;
	}

	/** Gets the id of all performance characteristic related to Raw Material.

	 * 

	 * @author hmagar */

	public MapList pgGetPerformanceCharData(matrix.db.Context context, String objId) throws Exception {


		MapList objList = null;

		MapList outputList = new MapList();

		StringList objectSelects = new StringList();
		objectSelects.add(DomainConstants.SELECT_ID);
		objectSelects.add(DomainObject.SELECT_NAME);
		objectSelects.add(DomainObject.SELECT_TYPE);

		objectSelects.add("attribute[pgCharacteristic]");
		objectSelects.add("attribute[pgCharacteristicSpecifics]");
		objectSelects.add("attribute[Specification]");
		objectSelects.add("attribute[pgMethodOrigin]");
		objectSelects.add("attribute[pgMethodNumber]");
		objectSelects.add("attribute[pgMethodSpecifics]");
		objectSelects.add("attribute[pgSampling]");
		objectSelects.add("attribute[pgSubGroup]");
		objectSelects.add("attribute[pgPlantTesting]");
		objectSelects.add("attribute[pgPlantTestingText]");
		objectSelects.add("attribute[pgRetestingUOM]");
		objectSelects.add("attribute[pgLowerSpecificationLimit]");
		objectSelects.add("attribute[pgLowerTarget]");
		objectSelects.add("attribute[pgTarget]");
		objectSelects.add("attribute[pgUpperTarget]");
		objectSelects.add("attribute[pgUpperSpecificationLimit]");
		objectSelects.add("attribute[pgUnitOfMeasure]");
		objectSelects.add("attribute[pgReportToNearest]");
		objectSelects.add("attribute[pgReportType]");
		objectSelects.add("attribute[pgActionRequired]");
		objectSelects.add("attribute[pgReleaseCriteria]");
		objectSelects.add("attribute[pgCriticalityFactor]");
		objectSelects.add("attribute[pgBasis]");
		objectSelects.add("attribute[pgTestGroup]");
		objectSelects.add("attribute[pgApplication]");
		objectSelects.add("attribute[pgChange]");
		//objectSelects.add("to[Shared Characteristic].from.name");
		//objectSelects.add("from[Shared Table].to.name");
		objectSelects.add(DomainConstants.SELECT_LEVEL);
		objectSelects.add("attribute[pgTMLogic]");

		//	objectSelects.add(CPNCommonConstants.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);

		StringList relSelects = new StringList();

		relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);

		relSelects.add("from.name");

		relSelects.add("to.name");

		//Modification for 15x as enginuity schema is not available

		//relSelects.add(CPNCommonConstants.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

		relSelects.add("attribute[SharedTableCharacteristicSequence]");

		//Modification ends

		//HashMap paramMap = (HashMap) JPO.unpackArgs(args);
		//String objectId = (String) paramMap.get("objectId");
		//String objectId = objId;

		//Modification for 15x as enginuity schema is not available	
		//String relPattern = CPNCommonConstants.RELATIONSHIP_CHARACTERISTIC + "," + CPNCommonConstants.RELATIONSHIP_SHARED_TABLE + "," + CPNCommonConstants.RELATIONSHIP_SHARED_CHARACTERISTIC;
		String relPattern = "Characteristic,Shared Table,Shared Characteristic";
		//Modification ends

		// CPN 110110 zbp-->added for..create new table view error ---------->END

		String type = PropertyUtil.getSchemaProperty("type_pgPerformanceCharacteristic");
		String typePattern = "Shared Table," + type;
		DomainObject doObj = DomainObject.newInstance(context, objId);
		boolean isShared = Boolean.valueOf((String)doObj.getInfo(context, "relationship[Shared Table]"));

		if(isShared){		
			objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects, false, true, (short) 2, null, null,0);

		}else{

			objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects, false, true, (short) 1, null, null,0);
		}

		Iterator sharedmapItr = objList.iterator();

		HashMap sharedmap = new HashMap();

		while(sharedmapItr.hasNext()){
			Map perMap = (Map) sharedmapItr.next();
			String mapType = (String)perMap.get(DomainObject.SELECT_TYPE);
			//Modification for 15x as enginuity schema is not available
			String tableSeqNo = (String)perMap.get("attribute[SharedTableCharacteristicSequence]");
			//Modification ends
			String tabName = (String)perMap.get("name");

			if(mapType.equals("Shared Table")){
				//Modified for 2018x Upgrade STARTS
				//StringList charList = new StringList();
				Vector charList = new Vector();
				//Modified for 2018x Upgrade ENDS
				charList.add(tableSeqNo);
				charList.add(perMap);
				sharedmap.put(tabName, charList);

			}

		}

		StringList tabList  = new StringList();
		Set sharedTabNames  = new HashSet(); 
		sharedTabNames.addAll(sharedmap.keySet());

		Integer sortNo = 0;

		Iterator objListItr = objList.iterator();

		while (objListItr.hasNext()) {

			Map perMap = (Map) objListItr.next();
			//Modification for 15x to fix compilation
			//String seq = (String) perMap.get(CPNCommonConstants.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
			String seq = (String) perMap.get("attribute[SharedTableCharacteristicSequence]");
			//Modification ends

			//Modified by DSM (Sogeti) 2015X.2 - Check for null value- Starts
			if(!"".equals(seq) && seq != null){
				sortNo = Integer.parseInt(seq) * 100;
			}
			//Modified by DSM (Sogeti) 2015X.2 - Check for null value- Ends

			perMap.put("sortNo", ""+sortNo);
			String relation = (String)perMap.get("relationship");
			//Modification for 15x to fix compilation
			//if(relation.equals(CPNCommonConstants.RELATIONSHIP_SHARED_CHARACTERISTIC)){
			if(relation.equals("Shared Characteristic")){
				//Modification ends
				//get parent attribute sequence also
				String tableName = (String)perMap.get("from.name");
				//DSM(DS) 2018X.0 - 20545 : typecasting changes STARTS
				//StringList charList = (StringList)sharedmap.get(tableName);
				Vector charList = (Vector)sharedmap.get(tableName);
				//DSM(DS) 2018X.0 - 20545 : typecasting changes ENDS
				//Modified : Start
				String tabSeqNo="0";
				if(charList!=null&&!charList.isEmpty()){
					tabSeqNo  = (String)charList.get(0);
				}
				//String tabSeqNo  = (String)charList.get(0);
				//Modified : End
				if((sharedTabNames.contains(tableName))&&(null!=tabSeqNo)&&(!tabSeqNo.isEmpty())){
					sharedTabNames.remove(tableName);	
				}

				//Modification for 15x compilation
				String perMapSeqNo = (String)perMap.get("attribute[SharedTableCharacteristicSequence]");
				//Modification ends

				sortNo = Integer.parseInt(tabSeqNo)*100+Integer.parseInt(perMapSeqNo);

				perMap.put("sortNo", ""+sortNo);

			}

			if(!relation.equals("Shared Table")){
				outputList.add(perMap);

			}
		}

		//this code is to add empty shared tables which dont have any perf characteristicobjs attached 

		for (Iterator emptySharedTableItr = sharedTabNames.iterator(); emptySharedTableItr.hasNext();) {

			String tableName = (String) emptySharedTableItr.next();
			//Modified for 2018x Upgrade STARTS
			//StringList charList = (StringList)sharedmap.get(tableName);
			Vector charList = (Vector)sharedmap.get(tableName);
			//Modified for 2018x Upgrade ENDS
			//Modified : Start
			String tabSeqNo="0";
			if(charList!=null&&!charList.isEmpty()){
				tabSeqNo  = (String)charList.get(0);
			}
			//String tabSeqNo  = (String)charList.get(0);
			//Modified : End
			sortNo = Integer.parseInt(tabSeqNo) * 100;
			Map perMap = (Map)charList.get(1);
			perMap.put("sortNo", ""+sortNo);
			outputList.add(perMap);
		}

		try{

			outputList.sort("sortNo", "ascending", "Integer");

		}catch(Exception ex){

			ex.printStackTrace();

		}

		if(outputList.size()>0){
			return pgGetCharacteristicList(context,outputList);

		}else
			return outputList;

	}

	/*

	 * This method accepts all the performance Characteristic List

	 * @param context the eMatrix <code>Context</code> object

	 * @param 

	 * @return Void

	 * @throws Exception if the operation fails 

	 * Added for V2 on 22-Aug-2012

	 */

	public MapList pgGetCharacteristicList(Context context, MapList inputList) throws Exception {

		Iterator objListItr = inputList.iterator();
		int nCount=0;
		MapList outputList=new MapList();
		while (objListItr.hasNext()) {
			Map perMap = (Map) objListItr.next();
			nCount++;
			perMap.put("nCount", ""+nCount);

			outputList.add(perMap);
		}

		return outputList;

	}

	//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END

	public boolean checkOwnerShip(Context context, String sContextObjectId) throws Exception {
		StringValidatorUtil validator = new StringValidatorUtil();

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		//String[] aCompany = sUserCompanies.split(",");
		String[] aCompany = splitCompanyValues(context,sUserCompanies);
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		StringBuilder sbCompany = new StringBuilder();

		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		if (UIUtil.isNotNullAndNotEmpty(sContextObjectId)) {
			//DomainObject dob = new DomainObject(sContextObjectId);
			DomainObject dob = DomainObject.newInstance(context, sContextObjectId);

			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtil.OWNERSHIP);

			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.OWNERSHIP);
			Map mpChildOwnership = dob.getInfo(context, slSelects);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dob.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.OWNERSHIP);

			String sPartOwnership = validator
					.getStringEquivalentForStringList(mpChildOwnership.get(ConstantsUtil.OWNERSHIP));

			StringList slEachOwnership = filterOwnerShip(sPartOwnership);
			return checkOwnerShip(sbCompany, slEachOwnership);
		} else {
			return false;
		}
	}

	private Map applyOwnership(Context context, String sTMName, String sID, String sType) {
		StringValidatorUtil validator = new StringValidatorUtil();

		try {
			StringList slPTMName = getStringList(sTMName);
			StringList slPTMType = getStringList(sID);
			StringList slPTMNameID = getStringList(sType);

			boolean bHasOwnerShip = false;
			StringList sbFinalIndex = new StringList();
			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			//String[] aCompany = sUserCompanies.split(",");
			String[] aCompany = splitCompanyValues(context,sUserCompanies);
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			StringBuilder sbCompany = new StringBuilder();

			StringBuilder sbPName = new StringBuilder();
			StringBuilder sbPId = new StringBuilder();
			StringBuilder sbPType = new StringBuilder();

			if (aCompany.length > -1) {
				for (int i = 0; i < aCompany.length; i++) {
					if (null != aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					}
				}
			}

			for (int i = 0; i < slPTMNameID.size(); i++) {
				String sContextObjectId = validator.isNotNullOrEmpty(slPTMNameID.get(i)) ? slPTMNameID.get(i)
						: ConstantsUtil.EMPTY_STRING;

				sbPType.append(slPTMType.get(i)).append("&");
				sbPName.append(slPTMName.get(i)).append("&");

				if (UIUtil.isNotNullAndNotEmpty(sContextObjectId)) {
					//DomainObject dob = new DomainObject(slPTMNameID.get(i));
					DomainObject dob = DomainObject.newInstance(context, slPTMNameID.get(i));
					String sPartOwnership = validator
							.getStringEquivalentForStringList(dob.getInfo(context, ConstantsUtil.OWNERSHIP));
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					dob.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					StringList slEachOwnership = filterOwnerShip(sPartOwnership);
					// modified by Ganesh for security impl------>start
					// bHasOwnerShip = checkOwnerShip(sbCompany,
					// slEachOwnership);
					bHasOwnerShip = checkHasAccess(context, null, slPTMNameID.get(i));
					// modified by Ganesh for security impl------>end
					if (bHasOwnerShip)
						sbPId.append(slPTMNameID.get(i)).append("&");
					else
						sbPId.append("").append("&");
				} else {

					sbPId.append("").append("&");
				}

			}

		} catch (Exception e) {

		}
		return null;
	}

	public Map removeTestMethod(Context context, StringList slTMName, StringList slTMType, StringList slsChildObjectID)
			throws Exception {
		StringList slTMNameFiltered = new StringList();
		StringList slTMFilteredType = new StringList();
		StringList slTMFilteredID = new StringList();

		StringList slTMSName = new StringList();
		StringList slTMSType = new StringList();
		StringList slTMSFID = new StringList();

		String sType = ConstantsUtil.TYPE_TESTMETHODSPECIFCATION;

		for (int i = 0; i < slTMType.size(); i++) {
			if (sType.equals(slTMType.get(i))) {
				slTMNameFiltered.add(slTMName.get(i));
				slTMFilteredType.add(slTMType.get(i));
				slTMFilteredID.add(slsChildObjectID.get(i));

			} else {

				slTMSName.add(slTMName.get(i));
				slTMSType.add(slTMType.get(i));
				slTMSFID.add(slsChildObjectID.get(i));

			}

		}
		Map<String, StringList> mpTemp = new HashMap<String, StringList>();

		mpTemp.put(ConstantsUtil.TMFILNAME, slTMNameFiltered);
		mpTemp.put(ConstantsUtil.TMFILID, slTMFilteredID);
		mpTemp.put(ConstantsUtil.TMFILTYPE, slTMFilteredType);

		mpTemp.put(ConstantsUtil.BASENAME, slTMSName);
		mpTemp.put(ConstantsUtil.BASETYPE, slTMSType);
		mpTemp.put(ConstantsUtil.BASEID, slTMSFID);

		return mpTemp;

	}

	public StringList createSelects(String... selects) {
		StringList selectList = new StringList();
		for (String select : selects) {
			selectList.add(select);
		}
		return selectList;
	}

	public String getMasterPartSelect(Context context, String finalSelect) {
		StringBuilder masterPartSelectBuf = new StringBuilder();
		//SPEC: <14.07.2022>: Guna Modified for Req 41754 22x Release  -- START
		masterPartSelectBuf.append("to[").append(ConstantsUtilIRM.RELATIONSHIP_CLASSIFIED_ITEM).append("].frommid[")
		.append(ConstantsUtil.RELATIONSHIP_PARTFAMILYREFERENCE).append("].torel.to.").append(finalSelect);
		//SPEC: <14.07.2022>: Guna Modified for Req 41754 22x Release  -- END
		return masterPartSelectBuf.toString();
	}

	public MapList getPath(MapList ml, String masterPartName, String masterPartRev) {
		Iterator objectListItr = ml.iterator();
		MapList mlFinalList = new MapList();
		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			String path = masterPartName + " " + masterPartRev;
			objectMap.put(ConstantsUtil.PATH, path);
			mlFinalList.add(objectMap);
		}
		return mlFinalList;
	}

	public String getLastUpdateUser(StringList slHistoryInfo) {

		String lastModifiedHistory = ConstantsUtil.EMPTY_STRING;
		String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;

		if (slHistoryInfo != null && slHistoryInfo.size() > 0) {
			for (int i = slHistoryInfo.size() - 1; i > 0; i--) {
				lastModifiedHistory = (String) slHistoryInfo.get(i);
				if (UIUtil.isNotNullAndNotEmpty(lastModifiedHistory)) {
					lastUpdatedUser = lastModifiedHistory.substring(lastModifiedHistory.indexOf(ConstantsUtil.USER) + 6,
							lastModifiedHistory.indexOf(ConstantsUtil.TIME) - 2).trim();
					if (lastUpdatedUser.equalsIgnoreCase(ConstantsUtil.USERAGENT)) {
						continue;
					} else {
						break;
					}

				}
			}
		}

		return lastUpdatedUser;
	}

	public String createTempQuery(String sType, String sName, String sRev, String sSelectables) {

		StringBuilder sbQuery = new StringBuilder("temp query bus ");
		sbQuery.append(sType).append(" ");
		sbQuery.append(sName).append(" ");
		sbQuery.append(sRev).append(" ");
		sbQuery.append("select ");
		sbQuery.append("id ").append(sSelectables);
		sbQuery.append(" dump;");

		return sbQuery.toString();
	}

	public String createPrintQuery(String sOid, StringList busSelect) {

		int length = busSelect.toString().length();
		String selects = busSelect.toString().substring(1, length - 1).replace(",", " ");
		StringBuilder sbQuery = new StringBuilder("print bus ");
		sbQuery.append(sOid).append(" ");
		sbQuery.append("select ");
		sbQuery.append(selects);
		sbQuery.append(" dump;");
		return sbQuery.toString();
	}

	public String replaceSpecialSymbols(String sData) {
		if (!UIUtil.isNotNullAndNotEmpty(sData)) {
			return ConstantsUtil.EMPTY_STRING;
		}
		sData = sData.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
				.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
		sData = sData.replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES).replace(ConstantsUtil.SYMBL_FALSE,
				ConstantsUtil.SYMBL_NO);
		sData = sData.replace(ConstantsUtil.SYMBL_CAPTRUE, ConstantsUtil.SYMBL_YES)
				.replace(ConstantsUtil.SYMBL_CAPFALSE, ConstantsUtil.SYMBL_NO);
		return sData;
	}

	public String replaceSpecialForTitle(String sData) {
		if (!UIUtil.isNotNullAndNotEmpty(sData)) {
			return ConstantsUtil.EMPTY_STRING;
		}
		sData = sData.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
				.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
		return sData;
	}

	public String replacePIPE(String sData) {
		if (UIUtil.isNullOrEmpty(sData)) {
			return ConstantsUtil.EMPTY_STRING;
		}
		return sData.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.EMPTY_STRING);
	}

	public Map updatePlantInfo(Map objectMap) {
		Map<String, String> mpPlant = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();		
		try {
			String sPlants = validator
					.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_NAME));
			/*
			 * if(sPlants.isEmpty()) { return new HashMap(); }
			 */
			String sAutorized = validator
					.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE));
			String sProduce = validator
					.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE));
			String sActivated = validator
					.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED));
			String sAutorizedToView = validator
					.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW));

			mpPlant.put(ConstantsUtil.PLANTS, sPlants);
			mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOUSE, sAutorized);
			mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOPRODUCE, sProduce);
			mpPlant.put(ConstantsUtil.PLANTSISACTIVATED, sActivated);
			mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOVIEW, sAutorizedToView);

		} catch (Exception e) {
			LOGGER.error("Error from ObjectAttribUtil:  updatePlantInfo" + e);
			return new HashMap();
		}
		// return filterMapList(mpPlant);

		return mpPlant;
	}

	public StringList removeDuplicateSlType(StringList slData) {
		StringList slMapType = new StringList();
		String sType = DomainConstants.EMPTY_STRING;
		for (int i = 0; i < slData.size(); i++) {
			sType = slData.get(i);
			if (!slMapType.contains(sType)) {
				slMapType.add(sType);
			}
		}

		return slMapType;
	}

	public StringList MapsType(String[] sData) {
		StringList slMapType = new StringList();
		String sType = DomainConstants.EMPTY_STRING;
		for (int i = 0; i < sData.length; i++) {
			sType = sData[i];
			if (UIUtil.isNotNullAndNotEmpty(sType) && sData.length > 0) {
				sType = mapType(sType);
				slMapType.add(sType);
			}
		}

		return slMapType;
	}

	public String MapsType(String data) {
		StringList slMapType = new StringList();
		String sData[] = data.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		String sType = DomainConstants.EMPTY_STRING;
		for (int i = 0; i < sData.length; i++) {
			sType = sData[i];
			if (UIUtil.isNotNullAndNotEmpty(sType)) {
				sType = mapType(sType);
				slMapType.add(sType);
			}
		}

		return replaceSpecialSymbols(slMapType.toString());
	}

	public StringList MapSlType(StringList slData) {
		StringList slMapType = new StringList();
		String sType = DomainConstants.EMPTY_STRING;
		for (int i = 0; i < slData.size(); i++) {
			sType = slData.get(i);
			sType = mapType(sType);
			slMapType.add(sType);
		}

		return slMapType;
	}

	public StringBuilder MapSlType(StringBuilder sbData) {
		StringBuilder sbMapType = new StringBuilder();
		String[] saData = sbData.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		String sType = DomainConstants.EMPTY_STRING;
		for (int i = 0; i < saData.length; i++) {

			sType = saData[i].trim();

			if (sType.equals("Approve")) {

				sType = sType.replace("Approve", "Approved");

			} else if (sType.equalsIgnoreCase("ignore")) {
				sType = sType.replace("Ignore", "Ignored");
			} else if (sType.equalsIgnoreCase("None")) {
				sType = sType.replace("None", "Comment");

				//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- START
			} else if (sType.equalsIgnoreCase("Notify Only")) {
				sType = "Notify Only";
			}
			//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- END

			sbMapType.append(sType).append(ConstantsUtil.SYMBL_PIPE);
		}

		return sbMapType;
	}

	public String mapType(String sType) {
		if (null != sType) {
			switch (sType.trim()) {
			case "pgFinishedProduct":
				sType = "Finished Product";
				break;
			case "pgPKGStabilityProtocol":
				sType = "Stability Protocol";
				break;
			case "pgRawMaterialPlantInstruction":
				sType = "Raw Material Plant Instruction";
				break;

			case "pgPackagingMaterial":
				sType = "Packaging Material Part";
				break;
			case "VPMReference":
				sType = "Physical Product";
				break;
			case "pgMasterPackingMaterial":
				sType = "Master Packaging Material Part";
				break;
			case "pgCustomerUnitPart":
				sType = "Customer Unit Part";
				break;
			case "pgConsumerUnitPart":
				sType = "Consumer Unit Part";
				break;
			case "pgPackingMaterial":
				//SPEC: 06-03-2022: Added for req #43495 by Satyam -- START
				sType = "Packaging Material Part";
				//SPEC: 06-03-2022: Added for req #43495 by Satyam -- END
				break;
			case "pgMasterCustomerUnitPart":
				sType = "Master Customer Unit Part";
				break;
			case "pgMasterPackagingAssemblyPart":
				sType = "Master Packaging Assembly Part";
				break;
			case "pgMasterPackagingMaterialPart":
				sType = "Master Packaging Material Part";
				break;
			case "pgPackingInstructions":
				sType = "Packing Instruction"; //Modified by Ketan for req no. 1563
				break;
			case "pgMasterInnerPackUnitPart":
				sType = "Master Inner Pack";
				break;
			case "pgMasterConsumerUnitPart":
				sType = "Master Consumer Unit Part";
				break;
			case "pgIntermediateProductPart":
				sType = "Intermediate Product Part";
				break;
			case "pgFormulatedProduct":
				sType = "Formula Card";
				break;
			case "pgMasterRawMaterialPart":
				sType = "Master Raw Material Part";
				break;
			case "pgMasterRawMaterial":
				sType = "Master Raw Material Part";
				break;
			case "pgQualitySpecification":
				sType = "Quality Specification";
				break;
			case "pgIllustration":
				sType = "Illustration";
				break;
			case "pgIPMDocument":
				sType = "IPM Document";
				break;
			case "QAC":
				sType = "Quality Acceptance Criteria";
				break;
			case "pgInnerPackUnitPart":
				sType = "Inner Pack";
				break;
			case "Approve":
				sType = "Approved";
				break;
			case "pgAncillaryPackagingMaterialPart":
				sType = "Ancillary Packaging Material Part";
				break;
			case "pgRawMaterial":
				sType = "Raw Material IRMS";
				break;
			case "Raw Material": // SPEC: Modified by Ketan for req no. 43495
				sType = "Raw Material"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgApprovedSupplierList":
				sType = "Approved Supplier List";
				break;
			case "pgMakingInstructions":
				sType = "Making Instruction";
				break;
			case "pgFabricatedPart":
				sType = "Fabricated Part";
				break;
			case "pgDeviceProductPart":
				sType = "Device Product Part";
				break;
			case "pgProcessStandard":
				sType = "Process Standard";
				break;
			case "pgTransportUnitPart":
				sType = "Transport Unit Part";
				break;
			case "pgStackingPattern":
				sType = "Stacking Pattern Specification";
				break;
			case "pgAncillaryRawMaterialPart":
				sType = "Ancillary Raw Material Part";
				break;
			case "pgAssembledProductPart":
				sType = "Assembled Product Part";
				break;
			case "pgConsumerDesignBasis":
				sType = "Consumer Design Basis";
				break;
			case "pgPromotionalItemPart":
				sType = " Promotional Item Part";
				break;
			case "pgOnlinePrintingPart":
				sType = "Online Printing Part";
				break;
			case "pgMasterProductPart":
				sType = "Master Product Part";
				break;
			case "pgStandardOperatingProcedure":
				sType = "Standard Operating Procedure";
				break;
			case "pgDSOAffectedFPPList":
				sType = "Affected Finished Product Part List";
				break;
			case "pgPKGDIPlatform":
				sType = "DI Platform";
				break;
			case "pgPKGDevelopmentOther":
				sType = "General Innovation Record";
				break;
			case "pgPKGTechnicalRationale":
				sType = "Technical Rationale";
				break;
			case "pgPKGTranslationFile":
				sType = "Translation File";
				break;
			case "pgStabilityOther":
				sType = "Stability Other";
				break;
			case "pgPKGValidationReport":
				sType = "Validation Report";
				break;
			case "pgAuthorizedTemporarySpecification":
				sType = "Authorized Temporary Specification"; //SPEC: Modified by Ketan for req no. 43495
				break;
			//Added by Ketan for Req no. 47957 -- START
			case "pgStructuredATS":
				sType = "Structured Authorized Temporary Standard";
				break;
			//Added by Ketan for Req no. 47957 -- END
			case "pgAuthorizedConfigurationStandard":
				sType = "Authorized Configuration Standard";
				break;
			case "pgPKGProductReadiness":
				sType = "Core Innovation Record";
				break;
			case "Formula Technical Specification":
				sType = "Intermediate Assembled Product Specification";
				break;
			case "Preliminary":
				sType = "In Work";
				break;
			case "Review":
				sType = "Frozen";
				break;
			case "Release":
				sType = "Released";
				break;
			case "Approved":
				sType = "Released";
				break;

			case "pgArtwork":
				sType = "Art"; //SPEC: Modified by Ketan for req no. 43495
				break;
			case "None":
				sType = "Comment";
				break;
			case "FALSE":
				sType = "No";
				break;
			case "TRUE":
				sType = "yes";
				break;
			case "No":
				sType = "FALSE";
				break;
			case "pgPLIMaterialCertifications":
				sType = "Material Certification";
				break;
			case "pgPackingSubassembly":
				sType = "Packing Subassembly Part"; //SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgPKGStudyProtocol":
				sType = "Study Protocol";
				break;
			case "pgPKGStabilityReport":
				sType = "Stability Report";
				break;
			case "pgLaboratoryIndexSpecification":
				sType = "Laboratory Index Specification";
				break;
				// SPEC: 10-23-2020 : added for Defect: 36712 ## -- START
			case "Document":
				sType = "Innovation Record";
				break;
				// SPEC: 10-23-2020 : added for Defect : 36712 ## -- END
				// SPEC: 11-07-2020 : added for Defect: 37114 ## -- START
			case "pgReleasedSupplierList":
				sType = "Approved Supplier List";
				break;
				// SPEC: 11-07-2020 : added for Defect : 37114 ## -- END
			case "pgPKGValidationProtocol":
				sType = "Validation Protocol";
				break;
			case "pgStudyLeg":
				sType = "Leg";
				break;
				// SPEC: added by Jwala for Defect: 39277 ## -- START
			case "pgNonGCASPart":
				sType = "NGCAS";
				break;
				// SPEC: added by Jwala for Defect: 39277 ## -- START
			case "pgCompetitiveProductPart":
				sType = "Competitive Product Part";
				break;
			case "pgPKGSignatureReferenceDoc":
				sType = "Signature Reference";
				break;
			case "pgPKGConsumerProposition":
				sType = "Consumer Research";
				break;
			case "pgPKGOutofSpec":
				sType = "Stability Out Of Spec Report";
				break;
			case "pgAAA_RTA_Generic_Document":
				sType = "RTA Generic Document";
				break;
			case "pgSelfApproval":
				sType = "Self Approval";
				break;
			case "pgMasterFinishedProduct":
				//SPEC: 06-03-2022: Added for req #43495 by Satyam -- START
				sType = "Master Finished Product";
				//SPEC: 06-03-2022: Added for req #43495 by Satyam -- END
				break;
			case "pgValidationOther":
				sType = "Validation Other";
				break;
				// <SPEC>:16/01/2021 Added by Govind For POA/ART changes start
			case "pgPOADocument":
				sType = "POA Document";
				break;
			case "pgAAA_CIC":
				sType = "CIC";
				break;
				// <SPEC>:16/01/2021 Added by Govind For POA/ART changes end
				//SPEC: <25.02.2021>: Guna Added for Dev 18x.6   -- START
			case "pgSmartLabel":
				sType = "Smart Label";
				break;
				//SPEC: <25.02.2021>: Guna Added for Dev 18x.6   -- END

			case "pgSoftwarePart":
				sType = "Software Part";
				break;
				//SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- START
			case "pgPKGReferenceDocs":
				sType = "Reference Documents";
				break;
				//SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- END
				//SPEC: <24.03.2021>: Guna Added for 41374 Defect 18x.6   -- START
			case "pgProductPlatform":
				sType = "Product Platform";
				break;
				//SPEC: <24.03.2021>: Guna Added for 41374 Defect 18x.6   -- END
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41585 on Date 25/03/2021 --START
			case "pgBulkUpload":
				sType = "Bulk Upload";
				break;
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41585 on Date 25/03/2021 --END

				//SPEC: 10-28-2021: Added for Defect# 42821  by Sanjeeva -- START
			case ConstantsUtilIRM.COSMETICFORMULATION:
				sType = ConstantsUtilIRM.FORMULATION;
				break;
				//SPEC: 10-28-2021: Added  for Defect# 42821  by Sanjeeva -- END
				//SPEC: July 02,2021: Added for SR18x.6.0.1 for Defect# 43983 by Bala -- START	
			case "pgPhase":
				sType = "Phase";
				break;
			//SPEC: July 02,2021: Added for SR18x.6.0.1 for Defect# 43983 by Bala -- END
				//SPEC: <02.09.2021>: Guna Added for 42819 Defect  Dev 18x.6.0.2   -- START
			case "Yes":
				sType = "TRUE";
				break;
				//SPEC: <02.09.2021>: Guna Added for 42819 Defect  Dev 18x.6.0.2   -- END
				// SPEC: Added by Ketan for req no. 43495 -- START
			case "Qualification":
				sType = "Part Qualification Record";
				break;
			case "Packaging Assembly Part":
				sType = "Packaging Assembly Part"; 
				break;
			case "pgTestMethod":
				sType = "Test Method Specification";
				break;
			//SPEC: 06-03-2022: Added for req #43495 by Satyam -- END
			//SPEC: Added for defect #136010 by Ajay -- Start
			case "pgPackagingMinimizationReport":
				sType = "Packaging Minimization Report";
				break;
			//SPEC: Added for defect #136010 by Ajay -- END
			default:
				sType = sType;
				break;
			}
		}
		return sType;
	}

	public StringList getPersonFullName(Context context, StringList slData) throws FrameworkException {
		StringList slFinal = new StringList();
		PersonUtil person = new PersonUtil();
		String sTaskApprover = DomainConstants.EMPTY_STRING;
		for (int i = 0; i < slData.size(); i++) {
			sTaskApprover = slData.get(i);
			String PersonName = person.getFullName(context, sTaskApprover);
			slFinal.add(PersonName);
		}
		return slFinal;
	}

	public StringList getPersonFullName(Context context, StringBuilder sbData) throws FrameworkException {
		StringList slFinal = new StringList();
		PersonUtil person = new PersonUtil();
		String sTaskApprover = DomainConstants.EMPTY_STRING;
		String[] saData = sbData.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		for (int i = 0; i < saData.length; i++) {
			sTaskApprover = saData[i].trim();
			String PersonName = person.getFullName(context, sTaskApprover);
			slFinal.add(PersonName);
		}
		return slFinal;
	}

	public Map getCOName(Context context, String[] changeargs) throws Exception {
		Map mpLifecycle = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		StringList slObjectSelects = new StringList();
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_NAME);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_ID);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_TITLE);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_APPROVER);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_STATUS);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_COMPL_DATE);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVER_NAME);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_STATUS);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_DATE);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_TITLE);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_COMMENTS);
		// SPEC: Added for 18x.5.2 Defect #38718 --Bala -- START
		slObjectSelects.addElement(ConstantsUtil.SELECT_ROUTE_INSTRUCTIONS);
		// SPEC: Added for 18x.5.2 Defect #38718 --Bala -- END

		//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- START		
		slObjectSelects.addElement("from[Object Route].to[Route].to[Route Task].from.attribute[Route Action]");
		//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- END
		//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- START
		slObjectSelects.addElement(ConstantsUtilIRM.REL_ROUTE_SEQUENCE);
		//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- END
		//modified by Ganesh for defect 40911 <22/Mar/2021> ----->start
		slObjectSelects.addElement(ConstantsUtilIRM.REL_ROUTENODE_TO_NAME);
		//modified by Ganesh for defect 40911 <22/Mar/2021> ----->end

		StringBuilder sbCOName = new StringBuilder();
		StringBuilder sbTaskName = new StringBuilder();
		StringBuilder sbTaskApprover = new StringBuilder();
		StringBuilder sbTaskApproverFullName = new StringBuilder();
		StringBuilder sbTaskTitle = new StringBuilder();
		StringBuilder sbTaskStatus = new StringBuilder();
		StringBuilder sbTaskCompletionDate = new StringBuilder();
		StringBuilder sbTaskId = new StringBuilder();
		// SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		StringBuilder sbComments = new StringBuilder();
		// SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- START
		StringBuilder sbSequence = new StringBuilder();
		//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- END
		//modified by Ganesh for defect 40911 <22/Mar/2021> ----->start
		StringBuilder sbRouteApprover=new StringBuilder();
		//modified by Ganesh for defect 40911 <22/Mar/2021> ----->end
		String sCAName = ConstantsUtil.EMPTY_STRING;
		String sCAId = ConstantsUtil.EMPTY_STRING;
		String sCOName = ConstantsUtil.EMPTY_STRING;
		// Added for 37343 Defect
		String sCAState = ConstantsUtil.EMPTY_STRING;
		try {
			if (UIUtil.isNullOrEmpty(changeargs[1])) {
				return new HashMap();
			}
			String sQueryResult = new String ();
			//SPEC: 03-31-2020: Added for 18x.6 Defect# 41222 by Sanjeeva -- START
			sQueryResult = BusExtractUtil.executeTempQuery(context, BusExtractUtil.createQueryPath(changeargs[1],"Realized Activity"));
			//sQueryResult = BusExtractUtil.executeTempQuery(context, BusExtractUtil.createQueryPath("44ED7689D41944BFB15E9A0984DD59FE","Proposed Activity"));


			if (!validator.isNotNullOrEmpty(sQueryResult)) {
				sQueryResult = BusExtractUtil.executeTempQuery(context, BusExtractUtil.createQueryPath(changeargs[1],"Proposed Activity"));
				//sQueryResult = BusExtractUtil.executeTempQuery(context, BusExtractUtil.createQueryPath("44ED7689D41944BFB15E9A0984DD59FE","Realized Activity"));
			}
			//SPEC: 03-31-2020: Added for 18x.6 Defect# 41222 by Sanjeeva -- END		

			if (UIUtil.isNullOrEmpty(sQueryResult)) {
				return new HashMap();
			}
			// Added for 37343 Defect -- START
			String[] sQueResult = sQueryResult.split(ConstantsUtil.SYMBL_NEWLINE);
			// String[] sQueResult =
			// sQueryResult.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			// Added for 37343 Defect -- END
			for (int j = 0; j < sQueResult.length; j++) {
				String[] sActualResult = (String[]) sQueResult[j].split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
				if (sActualResult.length > 2) {
					sCAName = sActualResult[1];
					sCAId = sActualResult[2];
					sCAState = sActualResult[3];
				}

				if (sActualResult.length > 4) {
					sCOName = sActualResult[4];
				}

				if (UIUtil.isNotNullAndNotEmpty(sCAId) && sCAState.equals("Complete")) {

					//DomainObject domChangeAction = new DomainObject(sCAId);
					DomainObject domChangeAction = DomainObject.newInstance(context, sCAId);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_NAME);
					// SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_COMMENTS);
					// SPEC: 10/09/2020: Added for 18x.5 DEV -- END
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_ID);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_TITLE);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_APPROVER);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_STATUS);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_COMPL_DATE);
					// SPEC: Added for 18x.5.2 Defect #38718 --Bala -- START
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_ROUTE_INSTRUCTIONS);
					// SPEC: Added for 18x.5.2 Defect #38718 --Bala -- END

					//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- START
					DomainConstants.MULTI_VALUE_LIST.add("from[Object Route].to[Route].to[Route Task].from.attribute[Route Action]");
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SO_APPROVAL_TITLE);
					//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- END
					//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- START
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.REL_ROUTE_SEQUENCE);
					//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- END
					//modified by Ganesh for defect 40911 <22/Mar/2021> ----->start
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.REL_ROUTENODE_TO_NAME);
					//modified by Ganesh for defect 40911 <22/Mar/2021> ----->end
					
					//SPEC: <15.06.2022>: Guna Modified for Req  41754 22x Release  -- START
					Map mapCAInfo = domChangeAction.getInfo(context, slObjectSelects,slObjectSelects);
					//SPEC: <15.06.2022>: Guna Modified for Req  41754 22x Release  -- END
					
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					domChangeAction.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

					//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- START
					DomainConstants.MULTI_VALUE_LIST.remove("from[Object Route].to[Route].to[Route Task].from.attribute[Route Action]");
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SO_APPROVAL_TITLE);
					//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- END


					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_NAME);
					// SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_COMMENTS);
					// SPEC: 10/09/2020: Added for 18x.5 DEV -- END
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_ID);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_TITLE);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_APPROVER);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_STATUS);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_COMPL_DATE);
					// SPEC: Added for 18x.5.2 Defect #38718 --Bala -- START
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ROUTE_INSTRUCTIONS);
					// SPEC: Added for 18x.5.2 Defect #38718 --Bala -- END
					//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- START
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_ROUTE_SEQUENCE);
					//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- END
					//modified by Ganesh for defect 40911 <22/Mar/2021> ----->start
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_ROUTENODE_TO_NAME);
					//modified by Ganesh for defect 40911 <22/Mar/2021> ----->end
					if (mapCAInfo.isEmpty()) {
						return new HashMap();
					}
					sbTaskName.append(
							validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_NAME)));
					sbTaskId.append(
							validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_ID)));
					sbTaskTitle.append(
							validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_TITLE)));

					//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- START
					//sbTaskStatus.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_STATUS)));
					sbTaskStatus.append(
							validator.getStringEquivalentForStringList(mapCAInfo.get("from[Object Route].to[Route].to[Route Task].from.attribute[Route Action]")));
					//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- END

					sbTaskApprover.append(
							validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_APPROVER)));

					//SPEC: 04-08-2020: Added for 18x.6 Defect# 37511 by Sanjeeva -- START
					StringBuilder sbTaskApprForOwnership = new StringBuilder();
					sQueryResult = BusExtractUtil.executeTempQuery(context, "expand bus "+sCAId+" rel 'Object Route,Route Task,Project Task' type 'Route,Inbox Task,Person'  recurse to 2 select bus attribute[Route Action].value id dump |;");

					//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					if (validator.isNotNullOrEmpty(sQueryResult))
					{
						//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						String slTaskAppr[] = sQueryResult.split("\\r?\\n");
						String strTemp = new String ();
						String strTemp2 = new String ();
						String saEachTask[] = new String[7];
						String saEachAppr[] = new String[5];
						int intTokens = slTaskAppr.length;

						for (int i=0;i<intTokens;i++)
						{
							strTemp = slTaskAppr[i];
							if (strTemp.contains("Inbox Task") && strTemp.contains("Approve")) {
								//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
								if (validator.isNotNullOrEmpty(sQueryResult))
								{
									//saEachTask = saEachTask = strTemp.split("\\|");
									saEachTask = strTemp.split("\\|");
									//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

									sQueryResult = BusExtractUtil.executeTempQuery(context, "expand bus "+saEachTask[7]+" rel 'Project Task' type 'Person' dump |;");

									saEachAppr = sQueryResult.split("\\|");
									strTemp2 = saEachAppr[4];
									if (validator.isNotNullOrEmpty(strTemp2)) {
										if (sbTaskApprForOwnership.indexOf(strTemp2) == -1 ) {
											sbTaskApprForOwnership.append(strTemp2);
											if (i != intTokens-1)
												sbTaskApprForOwnership.append(ConstantsUtil.SYMBL_COMMA);
										}

									}
								}
								//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							}
							//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						}
						//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					}
					//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END	
					//mpLifecycle.put(ConstantsUtil.TASKAPPROVERS, sbTaskApprover.toString());
					String strFinalTaskApprovers = new String ();
					if (sbTaskApprForOwnership.length() != 0)
					{
						strFinalTaskApprovers = sbTaskApprForOwnership.toString();
					}
					mpLifecycle.put(ConstantsUtil.TASKAPPROVERS, strFinalTaskApprovers);
					//SPEC: 04-08-2020: Added for 18x.6 Defect# 37511 by Sanjeeva -- END

					String sApproverName = validator
							.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVER_NAME));

					String sApprovalStatus = validator
							.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_STATUS));

					sbSequence.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtilIRM.REL_ROUTE_SEQUENCE)));
					mpLifecycle.put(ConstantsUtilIRM.ROUTE_SEQUENCE, sbSequence.toString());
					sbRouteApprover.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtilIRM.REL_ROUTENODE_TO_NAME)));
					mpLifecycle.put(ConstantsUtilIRM.ROUTEAPPROVERS, sbRouteApprover.toString());

					//SPEC: 04-07-2020: Added for 18x.6 for Defect# 42147 by Sanjeeva -- START
					//SPEC: 23-04-2021: Modified for 18x.6 Internal Defect by Bala -- START
					/*sbComments.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SELECT_ROUTE_INSTRUCTIONS)));
					if (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE))))
					{
					 sbComments.append(ConstantsUtil.SYMBL_SLASH);
					 sbComments.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE)));
					}*/
					String strComments = getLifeCycleComment (mapCAInfo);
					//SPEC: 23-04-2021: Modified for 18x.6 Internal Defect by Bala -- END
					//SPEC: 04-07-2020: Added for 18x.6 for Defect# 42147 by Sanjeeva -- END


					// SPEC: <11.19.2020>: Added by Guna for Defect:37488 ## --
					// END
					//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					if (validator.isNotNullOrEmpty(sApprovalStatus))
					{
						//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						if (sApprovalStatus.equalsIgnoreCase(ConstantsUtil.TRUE)
								|| sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
							sApprovalStatus = ConstantsUtil.APPROVED;
						} else if (sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_FALSE)
								|| sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
							sApprovalStatus = ConstantsUtil.IGNORED;
						} else {
							sApprovalStatus = "";

						}
						//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					}
					//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					// Added for 37511 defect -- START
					String strApprover = validator
							.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_APPROVER));
					// SPEC: Modified for 18x.5.2 Defect #38718 --Bala -- START
					//strApprover = strApprover.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
					strApprover = replaceSpecialSymbols(strApprover);
					// SPEC: Modified for 18x.5.2 Defect #38718 --Bala -- END
					// Added for 37511 defect -- END
					//SPEC: <15.06.2022>: Guna Modified for Req  41754 22x Release  -- START
					String sApprovedDate = validator
							.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_DATE));
					//SPEC: <15.06.2022>: Guna Modified for Req  41754 22x Release  -- END
							//SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- START
							/*String sApprovalTitle = validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE)))
									? (String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE)
									: ConstantsUtil.EMPTY_STRING;*/
							//SPEC: Modified for Defect.66341 by Ajay -- START
							/*String sApprovalTitle = validator.isNotNullOrEmpty(validator.getStringEquivalentForStringListWithComma(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE)))
									? (String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE)
											: ConstantsUtil.EMPTY_STRING;*/
									//SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- END
									//SPEC: Modified for Defect.66341 by Ajay -- END
									sbTaskName.append(ConstantsUtil.SYMBL_PIPE);
									sbTaskName.append(ConstantsUtil.SO_APPROVAL_SIGNATURE);

									sbTaskStatus.append(ConstantsUtil.SYMBL_PIPE);
									sbTaskStatus.append(sApprovalStatus);
									//SPEC: Modified for Defect.66341 by Ajay -- START
									//sbTaskTitle.append(ConstantsUtil.SYMBL_PIPE);
									//sbTaskTitle.append(sApprovalTitle);
									//SPEC: Modified for Defect.66341 by Ajay -- END
									
									sbTaskApprover.append(ConstantsUtil.SYMBL_PIPE);
									sbTaskApprover.append(sApproverName);
									

									// For eliminating the SO Approver name in Ownership
									//SPEC: Release SR18x.5.2 - Added for Defect #38718 by Bala on Date Feb 16, 2021 -- START
									//mpLifecycle.put(ConstantsUtil.APPROVER_FULLNAME, strApprover);
									mpLifecycle.put(ConstantsUtil.APPROVER, strApprover);

									StringList slTaskApproverFullName = getPersonFullName(context, sbTaskApprover);

									// slTaskApprover.remove(sApproverName);
									StringBuilder sbTaskStatusRendered = MapSlType(sbTaskStatus);

									//SPEC: <07-27-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
									//StringList slTaskCompletionDate = 	validator.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_COMPL_DATE));
									StringList slTaskCompletionDate = 	validator.isNotNullOrEmpty(validator.getStringListEquivalentForString(mapCAInfo.get(ConstantsUtil.REL_TASK_COMPL_DATE)));
									//SPEC: <07-27-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END

									slTaskCompletionDate.add(sApprovedDate);
									String strApproverFullName = ConstantsUtil.EMPTY_STRING;
									String strTaskApproverFullName = ConstantsUtil.EMPTY_STRING;
									for (int k = 0; k < slTaskApproverFullName.size(); k++) {
										strApproverFullName = (String) slTaskApproverFullName.get(k);
										strApproverFullName = replaceSpecialSymbols(strApproverFullName);
										strTaskApproverFullName += strApproverFullName + ConstantsUtil.SYMBL_PIPE;
									}

									String strApprovalDueDate = ConstantsUtil.EMPTY_STRING;
									String strTaskCompletionDate = ConstantsUtil.EMPTY_STRING;
									for (int k = 0; k < slTaskCompletionDate.size(); k++) {
										strTaskCompletionDate = (String) slTaskCompletionDate.get(k);
										strTaskCompletionDate = validator.DateFormatter(strTaskCompletionDate);
										strApprovalDueDate += strTaskCompletionDate + ConstantsUtil.SYMBL_PIPE;
									}
									mpLifecycle.put(ConstantsUtil.APPROVALDATE, strApprovalDueDate);

									mpLifecycle.put(ConstantsUtil.NAME, sbTaskName.toString());
									mpLifecycle.put(ConstantsUtil.APPROVER_FULLNAME, strTaskApproverFullName.toString());
									mpLifecycle.put(ConstantsUtil.TITLE, sbTaskTitle.toString());
									mpLifecycle.put(ConstantsUtil.APPROVALSTATUS, sbTaskStatusRendered.toString());
									mpLifecycle.put(ConstantsUtil.CO, sCOName.trim() + ConstantsUtil.SYMBL_PIPE + sCAName.trim());
									//mpLifecycle.put(ConstantsUtil.COMMENTS, sbComments);
									//SPEC: 23-04-2021: Modified for 18x.6 Internal Defect by Bala -- START
									//mpLifecycle.put(ConstantsUtil.COMMENTS, sbComments.toString());
									mpLifecycle.put(ConstantsUtil.COMMENTS, strComments);
									//SPEC: 23-04-2021: Modified for 18x.6 Internal Defect by Bala -- END
				}
			}
		}catch(NullPointerException e) {
			LOGGER.error("Error in BusObjectAttribUtil method getCOName " + e);
			return new HashMap();
		} 
		catch (Exception e) {
			LOGGER.error("Error in BusObjectAttribUtil method getCOName " + e);
			return new HashMap();
		}
		return mpLifecycle;
	}

	public MapList getPackingUnitWeightsAndDiamensionsData(Context context, MapList objList) throws Exception

	{
		MapList tempList = new MapList();
		// MapList objList = null;
		MapList finalBomList = new MapList();
		String sLevelPrev = ConstantsUtil.GEN_NUM_ZERO;
		String sLevelNext = ConstantsUtil.GEN_NUM_ZERO;

		try {
			StringList busSelects = new StringList();
			busSelects.add(ConstantsUtil.SELECT_NAME);
			busSelects.add(ConstantsUtil.SELECT_TYPE);
			busSelects.add(ConstantsUtil.SELECT_ID);
			StringList relSelects = new StringList();
			relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);

			relSelects.add(DomainObject.SELECT_ATTRIBUTE_QUANTITY);
			String strObjectType = null;

			String strLevel = null;

			String strCOPId = null;

			StringList listCOPLevel = new StringList();

			StringList listCOPDetails = new StringList();

			StringList COPIgnoreList = new StringList();

			MapList listFinalCharacteristics = new MapList();

			if (!objList.isEmpty()) {
				Iterator listCharacteristicsIterator = objList.iterator();

				while (listCharacteristicsIterator.hasNext())

				{
					Map listCharacteristicsMap = (Map) listCharacteristicsIterator.next();

					strObjectType = (String) listCharacteristicsMap.get(ConstantsUtil.SELECT_TYPE);
					if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNIT)) {
						strLevel = (String) listCharacteristicsMap.get(ConstantsUtil.SELECT_LEVEL);
						strCOPId = (String) listCharacteristicsMap.get(ConstantsUtil.SELECT_ID);

						listCOPLevel.add(strLevel);
						listCOPDetails.add(strLevel + ConstantsUtil.SYMBL_DASH + strCOPId);

					}
				}

				if (listCOPLevel.isEmpty()) {
					return objList;
				}
				listCOPLevel.sort();

				String strFirstLevel = (String) listCOPLevel.get(0);

				for (int i = 0; i < listCOPDetails.size(); i++)

				{

					String strCOPDetails = (String) listCOPDetails.get(i);

					String[] COPDetails = strCOPDetails.split(ConstantsUtil.SYMBL_DASH);

					if (!strFirstLevel.equals(COPDetails[0])) {
						COPIgnoreList.add(COPDetails[1]);
					}

				}

				Iterator listRemoveCharacteristicsIterator = objList.iterator();

				while (listRemoveCharacteristicsIterator.hasNext())

				{

					Map listRemoveCharacteristicsMap = (Map) listRemoveCharacteristicsIterator.next();

					if (!COPIgnoreList.contains((String) listRemoveCharacteristicsMap.get(ConstantsUtil.SELECT_ID))) {
						listFinalCharacteristics.add(listRemoveCharacteristicsMap);
					}

				}
			}

			if (listFinalCharacteristics.size() > 0) {
				Iterator objItr = listFinalCharacteristics.iterator();

				while (objItr.hasNext())

				{

					Map objMap = (Map) objItr.next();
					Map objects = new HashMap();
					objects.put(ConstantsUtil.SELECT_NAME, (String) objMap.get(ConstantsUtil.SELECT_NAME));
					objects.put(ConstantsUtil.RELATIONSHIP, (String) objMap.get(ConstantsUtil.RELATIONSHIP));
					objects.put(ConstantsUtil.LEVEL, (String) objMap.get(ConstantsUtil.LEVEL));
					objects.put(ConstantsUtil.SELECT_ID, (String) objMap.get(ConstantsUtil.SELECT_ID));
					objects.put(ConstantsUtil.SELECT_RELATIONSHIP_ID,
							(String) objMap.get(ConstantsUtil.SELECT_RELATIONSHIP_ID));
					objects.put(ConstantsUtil.SELECT_TYPE, (String) objMap.get(ConstantsUtil.SELECT_TYPE));
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY,
							(String) objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
					finalBomList.add(objects);
				}

			}

		} catch (Exception e) {
			LOGGER.error("Unable to getPackingUnitWeightsAndDiamensionsData " + e);
		}
		return finalBomList;
	}

	public Map getUOM(Context context, MapList mlBom, Map mapPackagingUnitResult) throws Exception {
		Map mapObject = new HashMap();
		String strId;
		StringList slCI = new StringList();
		MapList mlCI = new MapList();
		StringList slUOM = new StringList();
		StringList strPGDUoM = new StringList();
		StringBuilder sbGrossWtUom = new StringBuilder();
		StringBuilder sbNetWt = new StringBuilder();
		StringBuilder sbAuom = new StringBuilder();
		StringBuilder sbGrossWtReal = new StringBuilder();
		StringBuilder sbPackingType = new StringBuilder();
		StringBuilder sbNetWetOfProdInCU = new StringBuilder();
		StringBuilder sbGtin = new StringBuilder();

		for (int i = 0; i < mlBom.size(); i++) {
			mapObject = new HashMap();
			mapObject = (Map) mlBom.get(i);
			strId = (String) mapObject.get(ConstantsUtil.SELECT_ID);
			StringList slWeigth = new StringList(7);
			slWeigth.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			slWeigth.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
			slWeigth.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			slWeigth.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
			slWeigth.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
			slWeigth.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT);
			slWeigth.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);

			DomainObject bomObject = DomainObject.newInstance(context, strId);

			Map mapWeightAttributeInfo = bomObject.getInfo(context, slWeigth);

			String strGrossWth = (String) mapWeightAttributeInfo
					.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			String strNetWetUoM = (String) mapWeightAttributeInfo
					.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
			String strGrossWtReal = (String) mapWeightAttributeInfo
					.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			String strNetWetOfProdInCU = (String) mapWeightAttributeInfo
					.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
			String sAUOM = (String) mapWeightAttributeInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
			String sGtin = (String) mapWeightAttributeInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);

			formatData(sbGtin, sGtin);
			formatData(sbGrossWtUom, strGrossWth);
			formatData(sbNetWt, strNetWetUoM);
			formatData(sbAuom, sAUOM);
			formatData(sbGrossWtReal, strGrossWtReal);
			formatData(sbNetWetOfProdInCU, strNetWetOfProdInCU);

			String sType = (String) mapObject.get(ConstantsUtil.SELECT_TYPE);
			sType = mapType(sType);
			String sName = (String) mapObject.get(ConstantsUtil.SELECT_NAME);
			sName = sType + ConstantsUtil.SYMBL_OPNBRACE + sName + ConstantsUtil.SYMBL_CLSBRACE;
			formatData(sbPackingType, sName);
		}
		mapPackagingUnitResult.put(ConstantsUtil.PACKINGUNITTYPE, sbPackingType.toString());
		mapPackagingUnitResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWtReal.toString());
		mapPackagingUnitResult.put(ConstantsUtil.AUOM, sbAuom.toString());
		mapPackagingUnitResult.put(ConstantsUtil.GTIN, sbGtin.toString());
		mapPackagingUnitResult.put(ConstantsUtil.UNITOFMEASURE, sbGrossWtUom.toString());
		mapPackagingUnitResult.put(ConstantsUtil.UNITOFMEASURE1, sbNetWt.toString());
		mapPackagingUnitResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCONSUMERUNIT, sbNetWetOfProdInCU.toString());

		return mapPackagingUnitResult;
	}

	public Vector getLevel(Context context, MapList objList) throws Exception {
		Vector columnVals = new Vector(objList.size());
		Iterator i = objList.iterator();
		while (i.hasNext()) {
			Map m = (Map) i.next();
			String level = (String) m.get(ConstantsUtil.LEVEL);
			if (level == null) {
				level = ConstantsUtil.GEN_NUM_ONE;
			}
			columnVals.addElement(level);
		}
		return columnVals;
	}

	public Map<String, String> updateDerivedDataInfo(Context context, String sSourceName, String sSourceRev,
			String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map mpDerived = new HashMap();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();

		MapList mlDerivedList = new MapList();
		try {
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, getTo, getFrom, (short) 2,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			if (mlDerivedList.isEmpty()) {
				return new HashMap();
			}
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName = new StringBuilder();
			StringBuilder sbDesc = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbOrganization = new StringBuilder();
			StringBuilder sbRevision = new StringBuilder();
			StringBuilder sbOwner = new StringBuilder();
			StringBuilder sbOriginated = new StringBuilder();
			StringBuilder sbGenerationNum = new StringBuilder();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();

				String sDerivedName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization = (String) objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner = (String) objectMap.get(ConstantsUtil.SELECT_OWNER);
				// String sGenerationNum
				// =(String)objectMap.get(ConstantsUtil.SELECT_LEVEL);
				String sGenerationNum = ConstantsUtil.GEN_NUM_ZERO;

				formatData(sbDerivedName, sDerivedName);
				formatData(sbSourceName, sSourceName);
				formatData(sbDesc, sDesc);
				formatData(sbCurrent, sCurrent);
				formatData(sbOrganization, sOrganization);
				formatData(sbRevision, sSourceRev);
				formatData(sbOwner, sOwner);
				formatData(sbOriginated, sCreatedDate);
				formatData(sbGenerationNum, sGenerationNum);

			}
			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Error From BusObjectAttribUtil : updateDerivedDataInfo " + e);
			return new HashMap();
		}
		return util.filterMapList(mpDerived);
	}

	public Map<String, String> updateDerivedDataCopInfo(Context context, String sSourceName, String sSourceRev,
			String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map mpDerived = new HashMap();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();

		MapList mlDerivedList = new MapList();
		try {
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, true, true, (short) 2,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			if (mlDerivedList.isEmpty()) {
				return new HashMap();
			}

			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName = new StringBuilder();
			StringBuilder sbDesc = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbOrganization = new StringBuilder();
			StringBuilder sbRevision = new StringBuilder();
			StringBuilder sbOwner = new StringBuilder();
			StringBuilder sbOriginated = new StringBuilder();
			StringBuilder sbGenerationNum = new StringBuilder();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();

				String sDerivedName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sLevel = (String) objectMap.get(ConstantsUtil.SELECT_LEVEL);
				String sDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization = (String) objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner = (String) objectMap.get(ConstantsUtil.SELECT_OWNER);
				// String sGenerationNum
				// =(String)objectMap.get(ConstantsUtil.SELECT_LEVEL);
				String sGenerationNum = ConstantsUtil.GEN_NUM_ZERO;
				if (sLevel.equals(ConstantsUtil.GEN_NUM_ONE)) {
					sSourceName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);

				}
				if (!sSourceName.equals(sDerivedName)) {
					formatData(sbDerivedName, sDerivedName);
					formatData(sbSourceName, sSourceName);
					formatData(sbDesc, sDesc);
					formatData(sbCurrent, sCurrent);
					formatData(sbOrganization, sOrganization);
					formatData(sbRevision, sSourceRev);
					formatData(sbOwner, sOwner);
					formatData(sbOriginated, sCreatedDate);
					formatData(sbGenerationNum, sGenerationNum);
				}
			}
			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Unable to BusObjectAttribUtil : updateDerivedDataCopInfo " + e);
			return new HashMap();
		}
		return util.filterMapList(mpDerived);
	}

	public MapList getPath(MapList ml, String masterPartName, String masterPartRev, MapList mlFinalList) {
		Iterator objectListItr = ml.iterator();
		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			String path = masterPartName + " " + masterPartRev;
			objectMap.put(ConstantsUtil.PATH, path);
			mlFinalList.add(objectMap);
		}
		return mlFinalList;
	}

	public String getParam(String[] args, String paramName) throws Exception {
		Map paramMap = (Map) JPO.unpackArgs(args);
		String paramValue = ConstantsUtil.EMPTY_STRING;
		if (paramMap.get(paramName) != null) {
			Object value = paramMap.get(paramName);
			if (value instanceof String[]) {
				paramValue = ((String[]) paramMap.get(paramName))[0];
			} else if (value instanceof String) {
				paramValue = (String) paramMap.get(paramName);
			}
		} else {
			Map requestMap = (Map) paramMap.get(ConstantsUtil.REQUEST_MAP);
			if (requestMap != null)
				paramValue = (String) requestMap.get(paramName);
		}
		return paramValue;
	}

	public StringList getPerformCharSelects() {
		// START :: gaikwad.tg
		// SPEC: 02/04/2021: Added for Defect 38792 -- Start
		StringList objectSelects = createSelects(ConstantsUtil.SELECT_ID, ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC,
				ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING, ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP,
				ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE, ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING,
				ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGTEXT,
				ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING, ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM,
				ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT,
				ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT, ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET,
				ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET, ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET,
				ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT,
				ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT,
				ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE, ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST,
				ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE, ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA,
				ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED, ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR,
				ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS, ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP,
				ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION, ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS,
				ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER, ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN,
				ConstantsUtil.SELECT_NAME, ConstantsUtil.SELECT_TYPE, ConstantsUtil.STR_REF_DOC,
				ConstantsUtil.STR_REF_DOC_IPCLASS, ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS,
				ConstantsUtil.SELECT_REF_DOC_TO_TYPE, 
				ConstantsUtil.STR_PARTFAMILY_TITLE, ConstantsUtil.PERFORMCHAR_APMPMPT_TITLE,
				ConstantsUtil.SELECT_REF_DOC_TO_IPCLASS, ConstantsUtil.SELECT_REF_DOC_TO_ID,
				ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS,
				ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC,
				ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE,
				ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE, ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE,
				ConstantsUtil.SELECT_REF_DOC_NAME, ConstantsUtil.SELECT_REF_DOC_TYPE,
				ConstantsUtil.SELECT_REF_DOC_IPCLASS, ConstantsUtil.SELECT_REF_DOC_ID,
				ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS, ConstantsUtil.STR_REF_DOC_FROMIPCLASS,
				ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE, ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME,
				ConstantsUtil.SELECT_ATTRIBUTE_CPSID,
				//SPEC: Release SR18x.5.2 - Added for Defect# 39416  by gaikwad.tg on Date 17 Feb 2021 -- END
				ConstantsUtil.SELECT_REF_DOC_TO_CSS,
				//SPEC: Release SR18x.5.2 - Added for Defect# 39416  by gaikwad.tg on Date 17 Feb 2021 -- END
				//Release SR18x.5.2 - Modified for Defect#39538 by Govind On Date 16/02/2021 start
				ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		//Release SR18x.5.2 - Modified for Defect#39538 by Govind On Date 16/02/2021 end
		// SPEC: 02/04/2021: Added for Defect 38792 -- End
		// END :: gaikwad.tg
		return objectSelects;
	}

	public MapList getExtendedPerformChar(Context context, DomainObject doFop, String sRevision, String sName,
			Map resultMaps) {
		MapList mlPerformChars = new MapList();
		try {
			StringList objectSelects = createSelects(ConstantsUtil.SELECT_ID, ConstantsUtil.SELECT_NAME,
					ConstantsUtil.STR_REF_DOC_IPCLASS, ConstantsUtil.SELECT_REVISION,
					ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC, ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING,
					ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP, ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING,
					ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING,
					ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM,
					ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT,
					ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT,
					ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET, ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET,
					ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET,
					ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT,
					ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT,
					ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE, ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST,
					ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE, ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA,
					ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED, ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR,
					ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS, ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP,
					ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION, ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS,
					ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER, ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN,
					ConstantsUtil.SELECT_NAME, ConstantsUtil.SELECT_TYPE, ConstantsUtil.STR_REF_DOC,
					ConstantsUtil.SELECT_REF_DOC_TO_ID, ConstantsUtil.SELECT_REF_DOC_TO_IPCLASS,
					ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS, ConstantsUtil.SELECT_REF_DOC_TO_TYPE,
					ConstantsUtil.TITLE, ConstantsUtil.PERFORMCHAR_ID, ConstantsUtil.PERFORMCHAR_TYPE,
					ConstantsUtil.STR_PARTFAMILY_TITLE, ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS,
					ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE, ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC,
					ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE,
					//SPEC: Release SR18x.5.2 - Added for Defect# 39245  by gaikwad.tg on Date 17 Feb 2021 -- START
					ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE, ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE,ConstantsUtil.SELECT_REF_DOC_TO_CSS);
			//SPEC: Release SR18x.5.2 - Added for Defect# 39245  by gaikwad.tg on Date 17 Feb 2021 -- END
			StringList relSelects = createSelects(ConstantsUtil.SELECT_RELATIONSHIP_ID,
					ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,
					ConstantsUtil.SELECT_ATTRIBUTE_PGINHERITANCETYPE);
			String typePattern = ConstantsUtil.TYPE__PERFORMANCE_CHAR + "," + ConstantsUtil.TYPE_NOTES_CHAR + ","
					+ ConstantsUtil.TYPE_PACKING_UNIT_CHAR;
			mlPerformChars = doFop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EXTENDEDDATA,
					ConstantsUtil.TYPE__PERFORMANCE_CHAR, objectSelects, relSelects, false, true, (short) 0, null, null,
					0);

			if (mlPerformChars.isEmpty()) {
				return new MapList();
			}

			mlPerformChars = getPath(mlPerformChars, sName, sRevision);

		} catch (Exception e) {
			LOGGER.error("Unable to BusObjectAttribUtil : getExtendedPerformChar " + e);
			return new MapList();
		}

		// return updatePerformCharcteristic(context,mlPerformChars,resultMaps);

		return mlPerformChars;
	}

	public Object setLDAPConnection(Context context, String[] args,String ldapuser,String ldappwd) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strName = (String) programMap.get(ConstantsUtil.SIGNUPFORM);
		boolean isTNumber = (boolean) programMap.get(ConstantsUtil.ISTNUMBER);

		String strUser = null;
		String strTNumber = null;
		String strLDAPUserPassword = null;
		String strLDAPUserUid = null;
		Object obj = null;
		
		//Added by Jwala for LDAP Profiling -- START
		String strLDAP_PRINCIPAL_VAL = "uid="+ldapuser+",ou=people,ou=pg,o=world";
		//Added by Jwala for LDAP Profiling -- END
		

		try {
			EncryptCrypto encrpto = new EncryptCrypto();
			Hashtable hashtable = new Hashtable();
			hashtable.put(ConstantsUtil.INITIAL_KEY, ConstantsUtil.INITIAL_VALUE);
			hashtable.put(ConstantsUtil.LDAP_URL, ConstantsUtil.STR_LDAPURL);
			hashtable.put(ConstantsUtil.STR_AUTHENTICATION, ConstantsUtil.STR_SIMPLE);
			//Modified by Jwala for LDAP Profiling -- START
			//hashtable.put(ConstantsUtil.LDAP_PRINCIPAL, ConstantsUtil.LDAP_PRINCIPAL_VAL);
			hashtable.put(ConstantsUtil.LDAP_PRINCIPAL, strLDAP_PRINCIPAL_VAL);
			//hashtable.put(ConstantsUtil.LDAP_CRED, EncryptCrypto.decryptString(ConstantsUtil.STR_LDAP_PASS));
			hashtable.put(ConstantsUtil.LDAP_CRED, encrpto.decryptString(ldappwd));
			//Modified by Jwala for LDAP Profiling -- END
			hashtable.put(ConstantsUtil.LDAP_PROTOCOL, ConstantsUtil.LDAP_SSL);

			InitialDirContext initialdircontext = new InitialDirContext(hashtable);
			SearchControls searchcontrols = new SearchControls();
			searchcontrols.setReturningAttributes(null);
			if (isTNumber) {
				strUser = ConstantsUtil.SYMBL_OPNBRACE + ConstantsUtil.UID + strName + ConstantsUtil.SYMBL_CLSBRACE;
			} else {
				strUser = ConstantsUtil.SYMBL_OPNBRACE + ConstantsUtil.EXT_SHORTNAME + strName
						+ ConstantsUtil.SYMBL_CLSBRACE;
			}
			NamingEnumeration namingenumeration = initialdircontext.search(ConstantsUtil.NAMING_ENUM, strUser,
					searchcontrols);
			if (namingenumeration == null || !namingenumeration.hasMore()) {
				return "";
			}

			SearchResult searchresult = (SearchResult) namingenumeration.next();

			Attributes attributes = searchresult.getAttributes();

			obj = attributes.getAll();

		} catch (Exception exception) {
			LOGGER.error("BusObjectAttribUtil, Unable to setLDAPConnection: " + exception);
		}
		return obj;
	}

	public String getLDAPInfo(String paramString, boolean isTNumber,String ldapuser,String ldappwd) {
		String strReturn = paramString;
		String strSN = "";
		String strGivenName = "";
		Context context = null;

		try {
			Map argmap = new HashMap();
			argmap.put(ConstantsUtil.SIGNUPFORM, paramString);
			argmap.put(ConstantsUtil.ISTNUMBER, isTNumber);
			String[] methodArgs = JPO.packArgs(argmap);
			context = Context.getExistingContext();
			Object localObject = setLDAPConnection(context, methodArgs,ldapuser,ldappwd);

			if (null == localObject || ConstantsUtil.STR_NULL.equals(localObject) || localObject == ""
					|| ("").equals(localObject)) {
				if(null!=context) {
					context.close();//Added for Defect 45181
					}
				return strReturn;
			}
			while (((NamingEnumeration) (NamingEnumeration) localObject).hasMore()) {

				Attribute localAttribute = (Attribute) ((NamingEnumeration) (NamingEnumeration) localObject).next();

				String str19 = localAttribute.getID();

				NamingEnumeration localNamingEnumeration2 = localAttribute.getAll();
				if (localNamingEnumeration2.hasMore()) {

					if (str19.equalsIgnoreCase(ConstantsUtil.STR_SN)) {
						strSN = (String) localNamingEnumeration2.next();
					}

					if (str19.equalsIgnoreCase(ConstantsUtil.GIVEN_NAME)) {

						strGivenName = (String) localNamingEnumeration2.next();
					}
				}
			}
			strReturn = strGivenName + " " + strSN;

		} catch (NameNotFoundException localNameNotFoundException) {
			LOGGER.error("BusObjectAttribUtil, Unable to getLDAPInfo:localNameNotFoundException " + localNameNotFoundException);
			if(null!=context) {
				context.close();//Added for Defect 45181
				}
			return strReturn;

		} catch (CommunicationException localCommunicationException) {
			LOGGER.error("BusObjectAttribUtil, Unable to getLDAPInfo:localCommunicationException " + localCommunicationException);
			if(null!=context) {
				context.close();//Added for Defect 45181
				}
			return strReturn;

		} catch (Exception localException) {
			LOGGER.error("BusObjectAttribUtil, Unable to getLDAPInfo:localException " + localException);
			if(null!=context) {
				context.close();//Added for Defect 45181
				}
			return strReturn;

		}
		if(null!=context) {
			context.close();//Added for Defect 45181
			}

		return strReturn;

	}

	public String getClassification(Map resultMaps) {

		StringValidatorUtil validator = new StringValidatorUtil();
		StringList slHiRTypes = new StringList();
		slHiRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHiRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHiRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHiRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHiRTypes.add(ConstantsUtil.TYPE_MASTERPRODUCTPART);
		slHiRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		String sType = (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE)));
		/*String sIPClassfication = (validator
				.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION)))
						? (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION)
						: ConstantsUtil.EMPTY_STRING;*/
		String sIPClassfication = validator
				.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
		String sSecurityClassfication = (validator
				.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION)))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION)
						: ConstantsUtil.EMPTY_STRING;

				if (!sIPClassfication.isEmpty()) {
					if (sIPClassfication.equalsIgnoreCase(ConstantsUtil.RESTRICTED)) {
						return ConstantsUtil.BUSINESS_USE;
					} else {
						return sIPClassfication;
					}
				} else {

					if (sSecurityClassfication.equalsIgnoreCase(ConstantsUtil.RESTRICTED)) {
						return ConstantsUtil.BUSINESS_USE;
					} else {
						if (slHiRTypes.contains(sType)) {
							return ConstantsUtil.HIGHLY_RESTRICTED;
						} else {
							return ConstantsUtil.BUSINESS_USE;
						}
					}

				}

	}

	public Map<String, String> getSubstitute(Context context, MapList mapList) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentRev = new StringBuilder();
		StringBuilder sbEBOMParentTitle = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMRefDoc = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMSubType = new StringBuilder();
		StringBuilder sbEBOMEffectDate = new StringBuilder();
		StringBuilder sbEBOMUntilDate = new StringBuilder();
		StringBuilder sbEBOMCobNum = new StringBuilder();
		StringBuilder sbEBOMChildRev = new StringBuilder();
		StringBuilder sbEBOMTupName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();

		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			String sChildExists = validator
					.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
			if (sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)
					|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
				String sParentName = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sParentRev = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				String sParentTitle = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sChildName = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				String sChildRev = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
				String sCombinationNum = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
				String sChildTitle = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
				String sChildType = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				sChildType = mapType(sChildType);
				String sSUBType = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
				String sQTY = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
				String sBASEUOM = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
				String sEffectvityDate = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
				String sUntilDate = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
				String sRefDoc = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
				String sComments = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
				String sParentID = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sChildId = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
				String sParentType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);

				// SPEC: 11/04/2020: Modified for 18x.5 DEV DEFECTS-- START
				boolean bChildHasAccess = checkSubstituteHasAccesss(context, objectMap);
				boolean bHasOwnership = false;

				if (isModificatinRequired()) {
					// commented by Ganes for security impl------>start
					/*
					 * SecurityService sec = new SecurityService(); String sComp
					 * = sec.getUserCauthorities(); StringList slUserOwnership =
					 * filterOwnerShip(sComp); String sFormulaPropagate =
					 * sParentID; if(sParentType.equalsIgnoreCase(ConstantsUtil.
					 * TYPE_FORMULATIONPART)) { sFormulaPropagate =
					 * getFormulaPropagate(context, sParentID); }
					 * 
					 * if(!sFormulaPropagate.isEmpty()) { bHasOwnership =
					 * checkOwnerShip(context, slUserOwnership,
					 * sFormulaPropagate); }
					 */
					// commented by Ganes for security impl------>end
					// modified by Ganes for security impl------>start
					bHasOwnership = checkHasAccess(context, null, sParentID);
					// modified by Ganes for security impl------>end
					if (!bHasOwnership) {
						sParentType = ConstantsUtil.NO_ACCESS;
						sParentID = ConstantsUtil.NO_ACCESS;
						// sChildId = ConstantsUtil.NO_ACCESS;
						sParentName = ConstantsUtil.NO_ACCESS;
						sParentRev = ConstantsUtil.NO_ACCESS;
						sParentTitle = ConstantsUtil.NO_ACCESS;
						sCombinationNum = ConstantsUtil.NO_ACCESS;
						// sChildTitle = ConstantsUtil.NO_ACCESS;
						sSUBType = ConstantsUtil.NO_ACCESS;
						sEffectvityDate = ConstantsUtil.NO_ACCESS;
						sUntilDate = ConstantsUtil.NO_ACCESS;
						sRefDoc = ConstantsUtil.NO_ACCESS;
						sComments = ConstantsUtil.NO_ACCESS;
						sQTY = ConstantsUtil.NO_ACCESS;
						sBASEUOM = ConstantsUtil.NO_ACCESS;
						// sChildRev = ConstantsUtil.NO_ACCESS;

					}
				}
				StringList slHIRTypes = new StringList();

				slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
				slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

				if (slHIRTypes.contains(sParentType)) {
					// SPEC: 11/04/2020: Modified for 18x.5 DEV DEFECTS-- END

					sParentType = ConstantsUtil.NO_ACCESS;
					sParentID = ConstantsUtil.NO_ACCESS;
					// sChildId = ConstantsUtil.NO_ACCESS;
					sParentName = ConstantsUtil.NO_ACCESS;
					sParentRev = ConstantsUtil.NO_ACCESS;
					sParentTitle = ConstantsUtil.NO_ACCESS;
					sCombinationNum = ConstantsUtil.NO_ACCESS;
					// sChildTitle = ConstantsUtil.NO_ACCESS;
					sSUBType = ConstantsUtil.NO_ACCESS;
					sEffectvityDate = ConstantsUtil.NO_ACCESS;
					sUntilDate = ConstantsUtil.NO_ACCESS;
					sRefDoc = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
				}
				sChildType = mapType(sChildType);

				formatData(sbEBOMParentType, sParentType);
				formatData(sbEBOMParentId, sParentID);
				formatData(sbEBOMId, sChildId);

				formatData(sbEBOMParentName, sParentName);
				formatData(sbEBOMParentRev, sParentRev);
				formatData(sbEBOMParentTitle, sParentTitle);
				formatData(sbEBOMName, sChildName);
				formatData(sbEBOMChildRev, sChildRev);
				formatData(sbEBOMCobNum, sCombinationNum);
				formatData(sbEBOMTitle, sChildTitle);
				formatData(sbEBOMType, sChildType);
				formatData(sbEBOMSubType, sSUBType);
				formatData(sbEBOMQTY, sQTY);
				formatData(sbEBOMBuom, sBASEUOM);
				formatData(sbEBOMEffectDate, sEffectvityDate);
				formatData(sbEBOMUntilDate, sUntilDate);
				formatData(sbEBOMRefDoc, sRefDoc);
				formatData(sbEBOMCommnts, sComments);

			}
		}
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
		mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
		mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
		mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
		mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());

		// return filterMapList(mpEBOMResult);
		return mpEBOMResult;

	}

	/**
	 * Parse Reference Document section for MEP and SEP
	 * 
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseRefDoclist(Context context, MapList mapList) {
		Map<String, String> mpRefDocResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		//StringBuilder sbSource = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbDescription = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbGendocName = new StringBuilder();
		StringBuilder sbGendocPath = new StringBuilder();
		StringBuilder sbLanguage = new StringBuilder();
		CommonDocBO commonDoc = new CommonDocBO();
		// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- START
		StringBuilder sbIsIRM = new StringBuilder();
		StringBuilder sbGendocFormat = new StringBuilder();
		// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- END
		//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- START
		boolean isExternal=isModificatinRequired();
		//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- END
		FileUtil fileUtil = new FileUtil();
		try {
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
				if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_PGIPMDOCUMENT)) {
					continue;
				}
				//SPEC: Release SR18x.5.2 - Commented for Defect# 39269  by Guna on Date 10/02/2021 -- START
				//sType = mapType(sType);
				//SPEC: Release SR18x.5.2 - Commented for Defect# 39269  by Guna on Date 10/02/2021 -- END
				String sId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sRevision = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				String sTitle = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

				String sCurrent = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String sDescription = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sLanguage = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE));
				//SPEC: <16.06.2021>: Guna Added for 43645 Defect  Dev 18x.6.0.1   -- START
				if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE)){
					sLanguage = validator
							.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE));
				}
				//SPEC: <16.06.2021>: Guna Added for 43645 Defect  Dev 18x.6.0.1   -- END
				//Modified by Ganesh for defect 38865 <2/18/2021> ---->Start
				//String sSource=ConstantsUtil.SOURCE_DIRECT;
				//Modified by Ganesh for defect 38865 <2/18/2021> ---->END
				// SPEC: Added for 18x.5.2 DEV --Shashank -- START
				Map mpFiles = new HashMap();
				//DomainObject doRefDoc = new DomainObject(sId);
				DomainObject doRefDoc = DomainObject.newInstance(context, sId);
				boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
				String sGendocName = "";
				String sGendocPath = "";
				// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- START
				String sGendocPathFormat = "";
				// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- END
				if (bisIRMDoc) {
					mpFiles = fileUtil.getGendocForIRM(context, doRefDoc);
					sGendocName = validator.getStringEquivalentForSubstituteString(
							mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
					sGendocPath = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
				} else {
					// SPEC: Modified for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- START
					//mpFiles = fileUtil.getGendocForReferenceDocuments(context, doRefDoc);
					mpFiles = fileUtil.getFilesForIPM(context, doRefDoc);
					// SPEC: Modified for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- END
					sGendocName = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- START
					sGendocPathFormat=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
					// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- END
				}
				// SPEC: Added for 18x.5.2 DEV --Shashank -- END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doRefDoc.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				if (sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
					continue;
				}

				String sUserType = getUserType();
				if((ConstantsUtil.PG_CM.equalsIgnoreCase(sUserType) || ConstantsUtil.PG_SP.equalsIgnoreCase(sUserType)) && bisIRMDoc && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
					continue;
				}
				//SPEC: Release SR18x.6 - Added for Req# 38552 by Manikanta on Date 20/04/2021 -- END
				boolean showData=checkHasAccess(context, null, sId);
				//Modified by Ganesh for defect 38865 <2/18/2021> ---->Start
				/*if (!showData || (!sCurrent.equalsIgnoreCase((String) ConstantsUtil.RELEASE) && !sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) )) {
					sId=ConstantsUtil.NO_ACCESS;
				}*/
				if ((!sCurrent.equalsIgnoreCase((String) ConstantsUtil.RELEASE) && !sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) )) {
					sId=ConstantsUtil.NO_ACCESS;
				}
				if(!showData)
				{
					sId=ConstantsUtil.NO_ACCESS;
					sTitle=ConstantsUtil.NO_ACCESS;
					sRevision=ConstantsUtil.NO_ACCESS;
					sDescription=ConstantsUtil.NO_ACCESS;
					sCurrent=ConstantsUtil.NO_ACCESS;
					sLanguage=ConstantsUtil.NO_ACCESS;
					//sSource=ConstantsUtil.NO_ACCESS;
				}
				//Modified by Ganesh for defect 38865 <2/18/2021> ---->END
				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 06 May 2021 -- START
				if(isExternal && sId.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
					continue;
				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 06 May 2021 -- END
				formatData(sbName, sName);
				formatData(sbId, sId);
				formatData(sbTitle, sTitle);
				formatData(sbRev, sRevision);
				//SPEC: Release SR18x.5.2 - Added for Defect# 39269  by Guna on Date 10/02/2021 -- START
				sType = mapType(sType);
				//SPEC: Release SR18x.5.2 - Added for Defect# 39269  by Guna on Date 10/02/2021 -- END
				formatData(sbType, sType);
				formatData(sbDescription, sDescription);
				formatData(sbState, sCurrent);
				formatData(sbLanguage, sLanguage);
				formatData(sbGendocName, sGendocName);
				formatData(sbGendocPath, sGendocPath);
				// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- START
				formatData(sbIsIRM,String.valueOf(bisIRMDoc));
				formatData(sbGendocFormat, sGendocPathFormat);
				// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- END
				//Added by Ganesh for defect 38865 <2/18/2021> ---->Start
				//formatData(sbSource,sSource);
				//commented by Ganesh for defect 38865 <2/18/2021> ---->END
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in Program : BusObjectAttributeUtil Method :parseRefDoclist " + ex);
			return new HashMap();
		}

		mpRefDocResult.put(ConstantsUtil.ID, sbId.toString());
		mpRefDocResult.put(ConstantsUtil.NAME, sbName.toString());
		mpRefDocResult.put(ConstantsUtil.TITLE, sbTitle.toString());
		//mpRefDocResult.put(ConstantsUtil.SOURCE, sbSource.toString()); //Commented by Ketan for Req. no. 47200
		mpRefDocResult.put(ConstantsUtil.REVISION, sbRev.toString());
		mpRefDocResult.put(ConstantsUtil.TYPE, sbType.toString());
		mpRefDocResult.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
		mpRefDocResult.put(ConstantsUtil.LANGUAGE, sbLanguage.toString());
		//commented by Ganesh for defect 38865 <2/18/2021> ---->Start
		//mpRefDocResult.put(ConstantsUtil.SOURCE, ConstantsUtil.SOURCE_DIRECT);
		//commented by Ganesh for defect 38865 <2/18/2021> ---->END
		mpRefDocResult.put(ConstantsUtil.STATE, sbState.toString());
		mpRefDocResult.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
		mpRefDocResult.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
		// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- START
		mpRefDocResult.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
		mpRefDocResult.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());
		// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-09-2021 -- END
		return mpRefDocResult;
	}

	public String getSpecificationSubType(Context context, String strSubtypeAttributeValue, String strSpecObjectType)
			throws Exception

	{
		String strTypepgQualitySpecification = PropertyUtil.getSchemaProperty("type_pgQualitySpecification");
		String strAttributeValue = "";
		try {
			if (strTypepgQualitySpecification.equals(strSpecObjectType)) {
				if (strSubtypeAttributeValue.equalsIgnoreCase("AMAT")) {
					strAttributeValue = "Approval Matrix";
				} else if (strSubtypeAttributeValue.equalsIgnoreCase("QAC")) {
					strAttributeValue = "Quality Acceptance Criteria";
				} else if (strSubtypeAttributeValue.equalsIgnoreCase("RMPI")) {
					strAttributeValue = "Raw Material Plant Instruction";
				} else if (strSubtypeAttributeValue.equalsIgnoreCase("CBA")) {
					strAttributeValue = "Current Best Approach";
				} else if (strSubtypeAttributeValue.equalsIgnoreCase("GPMS")) {
					strAttributeValue = "General Packaging Material Specification";
				} else if (strSubtypeAttributeValue.equalsIgnoreCase("GPS")) {
					strAttributeValue = "General Packing Standard";
				} else if (strSubtypeAttributeValue.equalsIgnoreCase("IAS")) {
					strAttributeValue = "Incoming Acceptance Specification";
				} else if (strSubtypeAttributeValue.equalsIgnoreCase("MOC")) {
					strAttributeValue = "Material of Construction";
				}

			}
			//SPEC: <19.03.2021>: Guna Commented for Internal Defect 18x.6   -- START
			/*if (UIUtil.isNotNullAndNotEmpty(strSubtypeAttributeValue)
					&& "Test Method Specification".equals(strSpecObjectType)) {
				strAttributeValue = strSubtypeAttributeValue;
			}*/
			//SPEC: <19.03.2021>: Guna Commented for Internal Defect 18x.6   -- END
			if ("pgTestMethod".equals(strSpecObjectType)) {
				if ("TAMU".equals(strSubtypeAttributeValue)) {
					strAttributeValue = "TAMU";
				}
			}			

			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 24, 2021 for Defect 41564 -- START
			if ("Test Method Specification".equals(strSpecObjectType)) {
				// Added by Jwala for Internal defects strSubtypeAttributeValue value can be "TM" in this case // 98884034
				if ("TM".equals(strSubtypeAttributeValue)) {
					strAttributeValue = "TM";
				}else if("TAMU".equals(strSubtypeAttributeValue)){
					strAttributeValue = "TAMU";
				}
			}
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 24, 2021 for Defect 41564 -- END

			//SPEC: Release SR18x.5.2 - Added for Defect #39443 by Bala on Date Feb 14, 2021 -- START
			if (UIUtil.isNotNullAndNotEmpty(strSubtypeAttributeValue)
					&& ConstantsUtil.TYPE_PACKINGMATERIAL.equals(strSpecObjectType)) {
				strAttributeValue = ConstantsUtil.PACKAGING;				
			}
			//SPEC: Release SR18x.5.2 - Added for Defect #39443 by Bala on Date Feb 14, 2021 -- END
			//SPEC: <17.06.2021>: Guna Added for 43700 Defect  Dev 18x.6.0.1   -- START
			if(ConstantsUtil.TYPE_PGRAWMATERIAL.equals(strSpecObjectType)){
				strAttributeValue = ConstantsUtil.SPEC_SUB_TYPE;
			}
			//SPEC: <17.06.2021>: Guna Added for 43700 Defect  Dev 18x.6.0.1   -- END
		} catch (Exception e)

		{
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getSpecificationSubType " + e);
		}

		return strAttributeValue;

	}

	public StringList updateSource(Context context, StringList slId) {
		StringList strFinalList = new StringList();
		String strType = "";
		String strRefDocId = "";
		for (int j = 0; j < slId.size(); j++) {
			strRefDocId = slId.get(j);
			strType = getSource(context, strRefDocId);
			strFinalList.add(strType);
		}

		return strFinalList;
	}

	public String getSource(Context context, String strRefDocId) {

		DomainObject dmObj = null;
		Map refDocMap = null;
		Map charMap = null;
		MapList charList = new MapList();
		StringList strCharList = new StringList();
		String strType = "";
		String strFinalType = "";
		try {
			strFinalType = ConstantsUtil.SOURCE_DIRECT;
			StringList strSelectList = StringList.create(DomainConstants.SELECT_ID, DomainConstants.SELECT_TYPE);

			dmObj = DomainObject.newInstance(context, strRefDocId);
			
			//Added Limit to 1 by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527  - Discussed with Nick
			charList = dmObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.TYPE_CHARACTERISTIC, strSelectList, null, false, true, (short) 1, null, null, (short) 1);

			if (charList != null && !charList.isEmpty()) {
				Iterator charListIterator = charList.iterator();
				while (charListIterator.hasNext()) {
					charMap = (Map) charListIterator.next();
					strType = (String) charMap.get(DomainConstants.SELECT_TYPE);
					int n = strType.lastIndexOf(" ");
					if (n < 0) {
						n = strType.length();
					}
					strType = strType.substring(0, n);

					if (!strCharList.contains(strType)) {
						strCharList.add(strType);
					}
				}
				if (strCharList.size() > 1) {
					for (int i = 0; i < strCharList.size(); i++) {
						strFinalType = strFinalType + "," + strCharList.get(i);
					}
					strFinalType = strFinalType.substring(1, strFinalType.length());
				} else {
					strFinalType = (String) strCharList.get(0);
				}
			}

		} catch (Exception e) {

			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :updateSource " + e);
		}
		return strFinalType;
	}

	public String getSpecificationSubtype(Context context, String sid) throws Exception {
		StringList returnList = new StringList();
		String sSpecSubType = ConstantsUtil.EMPTY_STRING;
		StringList slId = getStringList(sid);
		StringList slSelectable = new StringList();
		slSelectable.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		slSelectable.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		slSelectable.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		slSelectable.addElement(DomainConstants.SELECT_TYPE);
		slSelectable.addElement(DomainConstants.SELECT_ID);

		StringValidatorUtil validator = new StringValidatorUtil();
		EnoviaVendorSpecsServiceImpl vend = new EnoviaVendorSpecsServiceImpl();
		for (int j = 0; j < slId.size(); j++) {
			String sObjectId = slId.get(j);
			// sSpecSubType = UpdateSpecSubType(context, sObjectId);

			if (sObjectId != null && !"".equals(sObjectId)) {
				DomainObject productObject = DomainObject.newInstance(context, sObjectId);

				Map<String, String> mpSelectableMap = productObject.getInfo(context, slSelectable);
				if (mpSelectableMap != null && !mpSelectableMap.isEmpty()) {
					Map mpSubType = vend.getSpecificationSubtype(context, mpSelectableMap);
					sSpecSubType = validator.getStringEquivalentForStringListWithComma(
							mpSubType.get(ConstantsUtil.SPECIFICATIONSUBTYPE));

				}
			}
			returnList.add(sSpecSubType);
		}

		return replaceSquareBrackets(returnList.toString());
	}

	public String UpdateSpecSubType(Context context, String sObjectId) {
		String sSpecSubType = ConstantsUtil.EMPTY_STRING;

		try {
			if (sObjectId != null && !"".equals(sObjectId)) {
				DomainObject productObject = DomainObject.newInstance(context, sObjectId);
				StringList slSelectable = new StringList();
				slSelectable.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				slSelectable.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
				slSelectable.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slSelectable.addElement(DomainConstants.SELECT_ID);

				Map<String, String> mpSelectableMap = productObject.getInfo(context, slSelectable);
				if (mpSelectableMap != null && !mpSelectableMap.isEmpty()) {
					String strOriginatingSource = mpSelectableMap
							.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
					String strSpecObjectId = mpSelectableMap.get(DomainConstants.SELECT_ID);
					String strSpecObjectType = mpSelectableMap.get(DomainConstants.SELECT_TYPE);
					String strCSSType = mpSelectableMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);

					if (UIUtil.isNotNullAndNotEmpty(strOriginatingSource)
							&& ConstantsUtil.DSO.equalsIgnoreCase(strOriginatingSource))
						sSpecSubType = mpSelectableMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					else
						sSpecSubType = getSpecificationSubType(context, strCSSType, strSpecObjectType);

				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :UpdateSpecSubType " + e);
			return ConstantsUtil.EMPTY_STRING;
		}
		return sSpecSubType;
	}

	public boolean getHIRComplaintForSupplier(Context context, DomainObject objId, Map objectMap) throws Exception {
		boolean bflag = false;
		try {
			String strCompanyName = ConstantsUtil.EMPTY_STRING;
			String strCompanyData = ConstantsUtil.EMPTY_STRING;
			String strHIRComplaint = ConstantsUtil.EMPTY_STRING;
			StringValidatorUtil validator = new StringValidatorUtil();
			DomainObject domCom = null;

			String strPartId = ConstantsUtil.EMPTY_STRING;
			SecurityService sec = new SecurityService();
			String cAuthorities = sec.getUserCauthorities();

			//SPEC:Added for the Defect #43783 & 43770 by Jwala -- START
			StringList slSelects = new StringList();
			slSelects.addElement(ConstantsUtil.OWNERSHIP);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.OWNERSHIP);
			Map mpObjectwnership = objId.getInfo(context, slSelects);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.OWNERSHIP);

			//SPEC: <07-28-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			//StringList slObjectOwnership = validator.isNotNullOrEmpty((StringList) mpObjectwnership.get(ConstantsUtil.OWNERSHIP));
			StringList slObjectOwnership = validator.isNotNullOrEmpty(validator.getStringListEquivalentForString(mpObjectwnership.get(ConstantsUtil.OWNERSHIP)));
			//SPEC: <07-28-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END 



			slObjectOwnership = filterOwnerShip(slObjectOwnership);

			if (slObjectOwnership.isEmpty()) {
				return false;
			}
			//SPEC:Added for the Defect #43783 & 43770 by Jwala -- END
			StringList slCompanys = FrameworkUtil.split(cAuthorities.trim(), ",");

			for (int i = 0; i < slCompanys.size(); ++i) {
				strCompanyName = (String) slCompanys.get(i).trim();
				//SPEC: Commented for the Defect #43783 & 43770 by Jwala -- START
				/*BusinessObject busObj = new BusinessObject(ConstantsUtil.TYPE_COMPANY, strCompanyName,
						ConstantsUtil.SYMBL_DASH, ConstantsUtil.USER_VAULT);

				if (busObj.exists(context))
					strPartId = busObj.getObjectId(context);*/
				//SPEC: Commented for the Defect #43783 & 43770 by Jwala -- END

				//SPEC:Added for the Defect #43783 & 43770 by Jwala -- START
				strPartId = getObjectId(context,strCompanyName);
				//SPEC:Added for the Defect #43783 & 43770 by Jwala -- END

				//SPEC: Modified for the Defect #43783 & 43770 by Jwala -- START
				if(slObjectOwnership.contains(strCompanyName)){
					if (UIUtil.isNotNullAndNotEmpty(strPartId)) {
						//domCom = new DomainObject(strPartId);
						domCom = DomainObject.newInstance(context, strPartId);
						strHIRComplaint = domCom.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGHIRCOMPLAINT);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
						domCom.close(context);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					}
				}
				//SPEC: Modified for the Defect #43783 & 43770 by Jwala -- END
				if (ConstantsUtil.SYMBL_CAPTRUE.equalsIgnoreCase(strHIRComplaint)) {
					return bflag = true;
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getHIRComplaintForSupplier " + ex);
			return bflag;
		}
		return bflag;
	}

	//SPEC:Added for the Defect #43783 & 43770 by Jwala -- START
	/**
	 * @Desc This method will return the object ID of object
	 * @param Context context
	 * @param String strName
	 * @return String
	 * @throws Exception 
	 */
	public static String getObjectId(Context context,String strName) throws Exception {
		String strObjectId = null;
		BusinessObject busObj = new BusinessObject(ConstantsUtil.TYPE_COMPANY, strName,
				ConstantsUtil.SYMBL_DASH, ConstantsUtil.USER_VAULT);
		if(busObj != null && busObj.exists(context)) {
			strObjectId = busObj.getObjectId(context);
			if(busObj.isOpen()) {
				busObj.close(context);
			}
		}
		return strObjectId;
	}
	//SPEC:Added for the Defect #43783 & 43770 by Jwala -- END

	public boolean isAuthorizedtoUse(Context context, DomainObject objId, Map objectMap, String strPDFView) {

		boolean bAuthToUse = false;
		boolean bPlantMatches = false;
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sec = new SecurityService();
		String cAuthorities = sec.getUserCauthorities();
		StringList slPlants = new StringList();

		if (UIUtil.isNotNullAndNotEmpty(cAuthorities)) {
			try{
				//SPEC: 14/04/2022: Added by Manikanta for 22x DEV -- START
				slPlants = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_NAME));
				//SPEC: 14/04/2022: Added by Manikanta for 22x DEV -- END
			}catch(ClassCastException ce){
				LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getAuthorizedtoUse " + ce);
				StringList sTempPlant = new StringList();
				sTempPlant.add(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_NAME).toString());
				slPlants = validator.isNotNullOrEmpty(sTempPlant);
			}

			cAuthorities = cAuthorities.replace(ConstantsUtil.SYMBL_COMMA , ConstantsUtil.SYMBL_PIPE);
			StringList slCompanys = getStringList(cAuthorities);

			StringList slPlantAuthUse = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE));
			slPlantAuthUse = this.trimStringList(slPlantAuthUse);

			//Modified by Jwala for PDF Views
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				for ( int i = 0; i < slPlantAuthUse.size(); i++) {
					String strValue = slPlantAuthUse.get(i);
					if (strValue.equalsIgnoreCase(ConstantsUtil.CONST_TRUE)) {
						bAuthToUse = true;
						break;
					}

				}

			} else {

				for (int j = 0; j < slPlants.size(); j++) {

					if (UIUtil.isNotNullAndNotEmpty(slPlants.get(j))) {
						boolean bMatched = slCompanys.contains(slPlants.get(j).trim());
						if (bMatched) {
							String sValue = slPlantAuthUse.get(j);
							if (sValue.equalsIgnoreCase("FALSE")) {
								bAuthToUse = false;
								break;
							}
							bAuthToUse = true;
						}
					}
				}
			}
		}
		return bAuthToUse;
	}


	//SPEC: 03-12-2020: Added for 18x.6 DEV by Sanjeeva -- START

	public boolean isAuthorizedtoProduce(Context context, DomainObject objId, Map objectMap, String strPDFView) throws Exception {

		boolean bAuthToProduce = false;
		boolean bPlantMatches = false;
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sec = new SecurityService();
		String cAuthorities = sec.getUserCauthorities();
		StringList slPlants = new StringList();

		if (UIUtil.isNotNullAndNotEmpty(cAuthorities)) {
			try{
				//SPEC: Release 22x - Modified for Req 43397, by Sanjeeva -- START
				slPlants = validator
						.getStringListEquivalentForString(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_NAME));
				//SPEC: Release 22x - Modified for Req 43397, by Sanjeeva -- END
			}catch(ClassCastException ce){
				LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getAuthorizedtoUse " + ce);
				StringList sTempPlant = new StringList();
				sTempPlant.add(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_NAME).toString());
				slPlants = validator.isNotNullOrEmpty(sTempPlant);
			}
			// [CSS VTO 3~CA25, CSS VTO 2~CA24]
			StringList slCompanys = FrameworkUtil.split(cAuthorities.trim(), ",");
			// [CSS VTO 3~CA25 Plant]
			slCompanys = this.trimStringList(slCompanys);
			//SPEC: Release 22x - Modified for Req 43397, by Sanjeeva -- START
			StringList slPlantAuthUse = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE));
			//SPEC: Release 22x - Modified for Req 43397, by Sanjeeva -- END
			slPlantAuthUse = this.trimStringList(slPlantAuthUse);

			StringBuilder sb = new StringBuilder();
			String carray[] = cAuthorities.split(",");
			int iLength = carray.length;

			for (int i = 0; i < iLength; i++) {
				sb.append(carray[i].trim().replace(" Plant", "")).append("|");
			}

			//Modified by Jwala for PDF Views
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				for ( int i = 0; i < slPlantAuthUse.size(); i++) {
					String strValue = slPlantAuthUse.get(i);
					if (strValue.equalsIgnoreCase(ConstantsUtil.CONST_TRUE)) {
						bAuthToProduce = true;
						break;
					}

				}

			} else {
				int iMatchedPlantIndex = getIndexofMatchedPlant(slPlants, sb.toString());
				if (iMatchedPlantIndex != -1) {
					bAuthToProduce = Boolean.getBoolean(slPlantAuthUse.get(iMatchedPlantIndex));
					String sValue = slPlantAuthUse.get(iMatchedPlantIndex);
					if (sValue.equalsIgnoreCase("TRUE")) {
						bAuthToProduce = true;
					}

				}
			}
		}
		return bAuthToProduce;
	}
	//SPEC: 03-12-2020: Added for 18x.6 DEV by Sanjeeva -- END


	private int getIndexofMatchedPlant(StringList slObjectPlants, String cAuthorities) {
		int i = -1;

		boolean bMatched = false;
		for (int j = 0; j < slObjectPlants.size(); j++) {

			if (UIUtil.isNotNullAndNotEmpty(slObjectPlants.get(j))) {
				String[] cArray = cAuthorities.split("\\|");
				for (int k = 0; k < cArray.length; k++) {
					String strCompany = cArray[k].trim();
					bMatched = strCompany.contains(slObjectPlants.get(j).trim());
					if (bMatched) {
						i = j;
						break;
					}
				}

				if (bMatched) {
					break;
				}
			}
		}
		return i;
	}

	public StringList trimStringList(StringList slPlants) {
		StringList slList = new StringList();
		for (int i = 0; i < slPlants.size(); ++i) {
			String strPlantName = (String) slPlants.get(i);
			slList.add(strPlantName.trim());
		}
		return slList;
	}

	public String getUserType() {
		String sUserType = ConstantsUtil.EMPTY_STRING;
		SecurityService sct = new SecurityService();
		try {
			if (null != sct) {
				sUserType = sct.getUserType();
			}

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getUserType " + e);
			return sUserType;
		}
		return sUserType;
	}

	/*
	 * Role Check For EBP
	 */
	public boolean isModificatinRequired() {
		String sUserType = getUserType();
		boolean bModFlag = false;
		if (null != sUserType && (sUserType.equals(ConstantsUtil.PG_CM) || sUserType.equals(ConstantsUtil.PG_SP))) {
			bModFlag = true;
		}
		return bModFlag;

	}
	/*
	 * Role Check For Allowed MEP
	 */
	public boolean isOnlySupplier() {
		String sUserType = getUserType();
		boolean bModFlag = false;
		if (null != sUserType && !(sUserType.equals(ConstantsUtil.PG_CM)) && sUserType.equals(ConstantsUtil.PG_SP)) {
			bModFlag = true;
		}
		return bModFlag;

	}
	/*
	 * Method For displaying/hiding the SOP's and TM's
	 */

	private Map validateSpecs(Context context, Map mpTemp, StringList slOwnership) {

		StringValidatorUtil validator = new StringValidatorUtil();
		try {
			String sIPclass = ConstantsUtil.EMPTY_STRING;
			String sChildObjectID = ConstantsUtil.EMPTY_STRING;
			String sTMHasSharedAccess = ConstantsUtil.EMPTY_STRING;

			StringList slType = validator.isNotNullOrEmpty((StringList) mpTemp.get(ConstantsUtil.TYPE));
			StringList slIPClass = validator.isNotNullOrEmpty((StringList) mpTemp.get(ConstantsUtil.CLASSIFICATION));
			StringList slAttribSharing = validator.isNotNullOrEmpty((StringList) mpTemp.get(ConstantsUtil.SECURITY));
			StringList slID = validator.isNotNullOrEmpty((StringList) mpTemp.get(ConstantsUtil.ID));
			StringList slParentOwnerShip = validator.isNotNullOrEmpty((StringList) mpTemp.get(ConstantsUtil.OWNERSHIP));

			slParentOwnerShip = filterOwnerShip(slParentOwnerShip);

			StringList sbFinalIndex = new StringList();
			Map mpIndex = getTypeIndex(slType, true);

			StringList slTypeIndex = (StringList) mpIndex.get(ConstantsUtil.TYPE);
			StringList slHIR = (StringList) mpIndex.get(ConstantsUtil.CLASSIFICATION);
			sbFinalIndex = (StringList) mpIndex.get(ConstantsUtil.FORMULATION);
			StringList sbSOPIndex = (StringList) mpIndex.get(ConstantsUtil.SOP);

			String sUserType = getUserType();

			for (int x = 0; x < sbSOPIndex.size(); x++) {
				String index = sbSOPIndex.get(x);

				if (slType.size() == slAttribSharing.size())
					sTMHasSharedAccess = validator.isNotNullOrEmpty(slAttribSharing.get(Integer.parseInt(index)))
					? slAttribSharing.get(Integer.parseInt(index)) : ConstantsUtil.EMPTY_STRING;

					if (!ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) {
						sbFinalIndex.add(index);

					} else {
						sChildObjectID = validator.isNotNullOrEmpty(slID.get(Integer.parseInt(index)))
								? slID.get(Integer.parseInt(index)) : ConstantsUtil.EMPTY_STRING;
								String sView = updateReferences(context, sChildObjectID);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL) && !sView.equals("")) {
									sbFinalIndex.add(index);
								}
					}

			}

			for (int i = 0; i < slTypeIndex.size(); i++) {
				String index = slTypeIndex.get(i);

				if (slType.size() == slAttribSharing.size())
					sTMHasSharedAccess = validator.isNotNullOrEmpty(slAttribSharing.get(Integer.parseInt(index)))
					? slAttribSharing.get(Integer.parseInt(index)) : ConstantsUtil.EMPTY_STRING;

					if (!ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess))
						sbFinalIndex.add(index);
			}

			/*
			 * for(int j=0;j<slHIR.size();j++) { String index = slHIR.get(j);
			 * 
			 * if(slIPClass.size()>=slHIR.size()) sIPclass =
			 * validator.isNotNullOrEmpty(slIPClass.get(Integer.parseInt(index))
			 * )? slIPClass.get(Integer.parseInt(index)):
			 * ConstantsUtil.EMPTY_STRING;
			 * 
			 * if (ConstantsUtil.HIGHLY_RESTRICTED.equalsIgnoreCase(sIPclass)) {
			 * if(slID.size()==slType.size()) sChildObjectID =
			 * validator.isNotNullOrEmpty(slID.get(Integer.parseInt(index)))?
			 * slID.get(Integer.parseInt(index)): ConstantsUtil.EMPTY_STRING;
			 * 
			 * if (UIUtil.isNotNullAndNotEmpty(sChildObjectID)) { boolean
			 * bOwnership
			 * =checkOwnerShip(context,slParentOwnerShip,sChildObjectID);
			 * 
			 * if(!bOwnership) { sbFinalIndex.add(index); } } } }
			 */

			// Check for any Object has to remove
			if (sbFinalIndex.size() > 0)
				return updateMap(sbFinalIndex, mpTemp);
			else
				return mpTemp;

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :validateSpecs " + e);
			return new HashMap();
		}

	}

	/**
	 * Validate the Security rules on Performance Characteristic TM and TMRD's
	 * 
	 * @param context
	 * @param mpRefDoc
	 * @return
	 * @throws Exception
	 */

	public Map<String, String> showOrHideSOPAndTM(Context context, Map mpRefDoc) throws Exception {
		StringValidatorUtil validator = new StringValidatorUtil();

		try {
			String sIPclass = ConstantsUtil.EMPTY_STRING;
			String sChildObjectID = ConstantsUtil.EMPTY_STRING;
			String sTMHasSharedAccess = ConstantsUtil.EMPTY_STRING;

			StringList slType = validator.isNotNullOrEmpty((StringList) mpRefDoc.get(ConstantsUtil.TYPE));
			StringList slIPClass = validator.isNotNullOrEmpty((StringList) mpRefDoc.get(ConstantsUtil.CLASSIFICATION));
			StringList slAttribSharing = validator.isNotNullOrEmpty((StringList) mpRefDoc.get(ConstantsUtil.SECURITY));
			StringList slID = validator.isNotNullOrEmpty((StringList) mpRefDoc.get(ConstantsUtil.ID));

			// Check for the Type which has to be hidden/Show

			if (slType.contains(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)
					|| slType.contains(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
					|| slType.contains(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
				StringList sbFinalIndex = new StringList();
				Map mpIndex = getTypeIndex(slType, true);

				StringList slTypeIndex = (StringList) mpIndex.get(ConstantsUtil.TYPE);
				StringList sbSOPIndex = (StringList) mpIndex.get(ConstantsUtil.SOP);
				StringList sbOtherIndexes = (StringList) mpIndex.get(ConstantsUtil.CLASSIFICATION);

				String sUserType = getUserType();

				for (int x = 0; x < sbOtherIndexes.size(); x++) {
					String index = sbOtherIndexes.get(x);
					// modified by Ganesh for security impl------->start
					// boolean bHasOwnerShip = checkOwnerShip(context,
					// slID.get(Integer.parseInt(index)));
					boolean bHasOwnerShip = checkHasAccess(context, sUserType, slID.get(Integer.parseInt(index)));
					// modified by Ganesh for security impl------->start
					if (!bHasOwnerShip) {
						sbFinalIndex.add(index);
					}
				}

				// SOP Indexes Validation
				for (int x = 0; x < sbSOPIndex.size(); x++) {
					String index = sbSOPIndex.get(x);

					if (slType.size() == slAttribSharing.size())
						sTMHasSharedAccess = validator.isNotNullOrEmpty(slAttribSharing.get(Integer.parseInt(index)))
						? slAttribSharing.get(Integer.parseInt(index)) : ConstantsUtil.EMPTY_STRING;
						// modified by Ganesh for security impl----->start
						// boolean bHasOwnerShip = checkOwnerShip(context,
						// slID.get(Integer.parseInt(index)));
						boolean bHasOwnerShip = checkHasAccess(context, sUserType, slID.get(Integer.parseInt(index)));
						// modified by Ganesh for security impl----->end

						if (bHasOwnerShip) {
							if (!ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) {
								sbFinalIndex.add(index);

							} else {
								sChildObjectID = validator.isNotNullOrEmpty(slID.get(Integer.parseInt(index)))
										? slID.get(Integer.parseInt(index)) : ConstantsUtil.EMPTY_STRING;
										String sView = updateReferences(context, sChildObjectID);

										if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
												&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL) && !sView.equals("")) {
											sbFinalIndex.add(index);
										}
							}
						} else {
							sbFinalIndex.add(index);
						}
				}

				// Test Method Indexes Validation
				for (int i = 0; i < slTypeIndex.size(); i++) {
					String index = slTypeIndex.get(i);

					if (slType.size() == slAttribSharing.size())
						sTMHasSharedAccess = validator.isNotNullOrEmpty(slAttribSharing.get(Integer.parseInt(index)))
						? slAttribSharing.get(Integer.parseInt(index)) : ConstantsUtil.EMPTY_STRING;
						// modified by Ganesh for security impl------>start
						// boolean bHasOwnerShip = checkOwnerShip(context,
						// slID.get(Integer.parseInt(index)));
						boolean bHasOwnerShip = checkHasAccess(context, sUserType, slID.get(Integer.parseInt(index)));
						// modified by Ganesh for security impl------>end
						if (bHasOwnerShip) {
							if (!ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess))
								sbFinalIndex.add(index);
						} else {
							sbFinalIndex.add(index);
						}
				}

				/*
				 * StringList slTypeIndex = (StringList)
				 * mpIndex.get(ConstantsUtil.TYPE);
				 * 
				 * for (int i = 0; i < slTypeIndex.size(); i++) { String index =
				 * slTypeIndex.get(i);
				 * 
				 * if (slType.size() == slAttribSharing.size())
				 * sTMHasSharedAccess =
				 * validator.isNotNullOrEmpty(slAttribSharing.get(Integer.
				 * parseInt(index))) ?
				 * slAttribSharing.get(Integer.parseInt(index)) :
				 * ConstantsUtil.EMPTY_STRING;
				 * 
				 * if (!ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess))
				 * sbFinalIndex.add(index); }
				 */

				// Check for any Object has to remove
				if (sbFinalIndex.size() > 0)
					return updateMapwithID(sbFinalIndex, mpRefDoc);
				else
					return mpRefDoc;
			} else {
				return mpRefDoc;
			}

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :showOrHideSOPAndTM " + e);
			return new HashMap();

		}

	}

	/*
	 * Removing the object id from the Map .For disabling the Hyperlink on
	 * TestMethod
	 */
	public Map<String, String> updateMapwithID(StringList slFinalIndex, Map mpRefDoc) {
		StringValidatorUtil validator = new StringValidatorUtil();
		StringList slID = validator.isNotNullOrEmpty((StringList) mpRefDoc.get(ConstantsUtil.ID));
		StringList slTemp = new StringList();
		StringList slTemp12 = new StringList();
		Map mpTemp = new HashMap();
		slFinalIndex.sort();

		for (int j = 0; j < slID.size(); j++) {
			mpTemp.put(j, slID.get(j));
		}

		for (int i = 0; i < slFinalIndex.size(); i++) {
			if (!mpTemp.isEmpty()) {
				// mpTemp.replace(Integer.parseInt(sbFinalIndex.get(i)));
				mpTemp.replace(Integer.parseInt(slFinalIndex.get(i)), ConstantsUtil.EMPTY_STRING);
			}
		}

		for (int j = 0; j < mpTemp.size(); j++) {
			slTemp.add((String) mpTemp.get(j));
		}

		mpRefDoc.replace(ConstantsUtil.ID, slTemp);

		return mpRefDoc;
	}

	/*
	 * Checking for the exact SOP/TM object index
	 */
	private Map getTypeIndex(StringList slType, boolean bFromPartSpec) {
		StringList sbTypeIndex = new StringList();
		StringList sbSOPTypeIndex = new StringList();
		StringList sbFormulatedTypeIndex = new StringList();
		StringList sbIPIndex = new StringList();

		Map mpIndexes = new HashMap();
		// Checking for the exact SOP/TM object index
		for (int i = 0; i < slType.size(); i++) {
			String sType = slType.get(i);

			if (bFromPartSpec) {
				if (sType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {
					sbTypeIndex.add(String.valueOf(i));

				} else if (sType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
						|| sType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
					sbSOPTypeIndex.add(String.valueOf(i));

				} else if (sType.equals(ConstantsUtil.TYPE_FORMULA_CARD)) {
					sbFormulatedTypeIndex.add(String.valueOf(i));
				} else {
					sbIPIndex.add(String.valueOf(i));
				}

			} else if (sType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)
					|| sType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
					|| sType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
				sbTypeIndex.add(String.valueOf(i));
			}
		}

		mpIndexes.put(ConstantsUtil.TYPE, sbTypeIndex);
		mpIndexes.put(ConstantsUtil.SOP, sbSOPTypeIndex);
		mpIndexes.put(ConstantsUtil.FORMULATION, sbFormulatedTypeIndex);
		mpIndexes.put(ConstantsUtil.CLASSIFICATION, sbIPIndex);

		return mpIndexes;
	}

	/*
	 * Update all the values as per security and return
	 */
	public Map<String, String> updateMap(StringList sbIndex, Map<String, String> mpRefDoc) {

		StringValidatorUtil validator = new StringValidatorUtil();

		Map mpTemp = new HashMap();
		try {
			for (Map.Entry<String, String> entry : mpRefDoc.entrySet()) {
				String sKey = entry.getKey();
				Object sVal = entry.getValue();
				StringList slValueList = (StringList) sVal;

				// Check for reducing the unwanted iterations
				if (!ConstantsUtil.SECURITY.equals(sKey) && !ConstantsUtil.IPCLASSES.equals(sKey)) {
					if (!ConstantsUtil.NAME.equals(sKey) && !ConstantsUtil.TYPE.equals(sKey)) {
						slValueList = validator.isNotNullOrEmpty(removeObjects(sbIndex, slValueList, true));
					}
					mpTemp.put(sKey, replaceSpecialSymbols(slValueList.toString()));
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :updateMap " + e);
		}
		return mpTemp;
	}

	/*
	 * Remove the unwanted objects
	 */
	private StringList removeObjects(StringList sbIndex, StringList slTMName, boolean bflag) {
		StringList slTemp = new StringList();
		sbIndex.sort();
		try {
			Map mpTemp = new TreeMap();

			for (int j = 0; j < slTMName.size(); j++) {
				mpTemp.put(j, slTMName.get(j));
			}

			for (int i = 0; i < sbIndex.size(); i++) {
				if (!mpTemp.isEmpty()) {
					// mpTemp.remove(Integer.parseInt(sbIndex.get(i)));
					mpTemp.replace(Integer.parseInt(sbIndex.get(i)), ConstantsUtil.NO_ACCESS);
				}
			}

			for (int j = 0; j < mpTemp.size(); j++) {

				String sVal = (String) mpTemp.get(j);
				if (bflag)
					slTemp.add(sVal);
				else if (!sVal.equals(ConstantsUtil.NO_ACCESS)) {
					slTemp.add(sVal);
				}

			}

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :removeObjects " + e);
		}
		return slTemp;
	}

	/*
	 * Return the StringLlist
	 */

	public StringList getStringList(String sType) {
		if (UIUtil.isNullOrEmpty(sType)) {
			return ConstantsUtil.EMPTY_STRINGLIST;
		}
		String sTemp[] = sType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

		StringList sFinal = new StringList();
		for (int i = 0; i < sTemp.length; i++) {
			String sData = sTemp[i].trim();

			sFinal.add(sData);
		}
		return sFinal;
	}

	/*
	 * Return the connected Part Specifications
	 */

	public Map updatePartSpec(Context context, Map objectMap) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

							mpPartSpecs = getPartSpecifications(context, sType, sID);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :updatePartSpec " + e);
			return new HashMap();

		}
		// Modified by Jwala for EBP Dev_6.0 -- START
		return mpPartSpecs;
		//return filterMapList(mpPartSpecs);
		// Modified by Jwala for EBP Dev_6.0 -- END
	}

	public Map<String, String> getMasterSpecs(Context context, String sObjectId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpMasterSpecs = new HashMap<String, String>();
		String sMasterObjectId = ConstantsUtil.EMPTY_STRING;
		// SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
		String sMasterObjectName = ConstantsUtil.EMPTY_STRING;
		String sMasterObjectType = ConstantsUtil.EMPTY_STRING;
		// SPEC: 10/09/2020: Modified for 18x.5 DEV -- END
		String sMasterObjectClassfiedItem = ConstantsUtil.EMPTY_STRING;
		try {
			//DomainObject domChild = new DomainObject(sObjectId);
			DomainObject domChild = DomainObject.newInstance(context, sObjectId);
			sMasterObjectId = domChild.getInfo(context, ConstantsUtil.STR_MASTER_ID);

			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtil.STR_MASTER_ID);
			slSelects.add(ConstantsUtil.SELECT_MASTERPARTNAME);
			slSelects.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
			slSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			Map mp = domChild.getInfo(context, slSelects);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domChild.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			if (!mp.isEmpty()) {
				sMasterObjectId = validator.getStringEquivalentForStringList(mp.get(ConstantsUtil.STR_MASTER_ID));
				// SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
				// SPEC: Modified for Defect#37656 1.0.2 Release - Jwala --
				// START
				// getEquivalentString() apending the extra pipe "|" with the
				// name
				// sMasterObjectName =
				// validator.getEquivalentString(mp.get(ConstantsUtil.SELECT_MASTERPARTNAME));
				sMasterObjectName = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.SELECT_MASTERPARTNAME));
				// SPEC: Modified for Defect#37656 1.0.2 Release - Jwala -- END
				sMasterObjectType = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.SELECT_MASTERPARTTYPE));
				// SPEC: 10/09/2020: Modified for 18x.5 DEV -- END
				sMasterObjectClassfiedItem = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME));
			}

			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			if (UIUtil.isNotNullAndNotEmpty(sMasterObjectId)) {
				mpMasterSpecs = getMasterPartSpecifications(context, sMasterObjectId, sMasterObjectClassfiedItem,
						sMasterObjectName, sMasterObjectId, sMasterObjectType);
			} else {
				return new HashMap();
			}

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getMasterSpecs " + e);
			return new HashMap();
		}

		return mpMasterSpecs;

	}

	/**
	 * added for defect 37262 getProducingFormula method used to get connected
	 * Producing Formula objects*
	 * 
	 * @param context
	 * @param sObjectId
	 * @return
	 */
	public Map<String, String> getProducingFormula(Context context, String sObjectId) {

		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);

		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpProcucingFormula = new HashMap<String, String>();
		String sPFObjectId = ConstantsUtil.EMPTY_STRING;
		String sPFObjectName = ConstantsUtil.EMPTY_STRING;
		String sPFObjectType = ConstantsUtil.EMPTY_STRING;
		String sPFObjectRevision = ConstantsUtil.EMPTY_STRING;
		String sPFObjectDes = ConstantsUtil.EMPTY_STRING;
		String sPFObjectState = ConstantsUtil.EMPTY_STRING;
		String sPFObjectTitle = ConstantsUtil.EMPTY_STRING;
		StringBuilder pfType = new StringBuilder();
		StringBuilder pfName = new StringBuilder();
		StringBuilder pfState = new StringBuilder();
		StringBuilder pfRevision = new StringBuilder();
		StringBuilder pfTitle = new StringBuilder();
		StringBuilder pfId = new StringBuilder();
		StringBuilder pfDesc = new StringBuilder();

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership = filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		boolean bHasOwnerShip = false;

		try {
			//DomainObject domChild = new DomainObject(sObjectId);
			DomainObject domChild = DomainObject.newInstance(context, sObjectId);

			StringList busSelect = new StringList();
			RawMaterialPartBO RMPBO= new RawMaterialPartBO();
			busSelect.add(ConstantsUtil.PRODUCING_FORMULA_NAME);
			busSelect.add(ConstantsUtil.PRODUCING_FORMULA_TYPE);
			busSelect.add(ConstantsUtil.PRODUCING_FORMULA_ID);
			busSelect.add(ConstantsUtil.PRODUCING_FORMULA_REVISON);
			busSelect.add(ConstantsUtil.PRODUCING_FORMULA_DESCRIPTION);
			busSelect.add(ConstantsUtil.PRODUCING_FORMULA_STATE);
			busSelect.add(ConstantsUtil.PRODUCING_FORMULA_ATTRIBUTE_TITLE);
			busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
			
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.PRODUCING_FORMULA_ID);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.PRODUCING_FORMULA_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.PRODUCING_FORMULA_REVISON);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.PRODUCING_FORMULA_DESCRIPTION);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.PRODUCING_FORMULA_STATE);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.PRODUCING_FORMULA_ATTRIBUTE_TITLE);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.PRODUCING_FORMULA_TYPE);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
			//Added by Ajay for Defect 12042 - START
			Map mp = domChild.getInfo(context, busSelect ,RMPBO.addMultiList1());  
			//Added by Ajay for Defect 12042 - END
			
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domChild.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if (!mp.isEmpty()) {
				sPFObjectId = validator.getStringEquivalentForStringList(mp.get(ConstantsUtil.PRODUCING_FORMULA_ID));
				sPFObjectName = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.PRODUCING_FORMULA_NAME));
				sPFObjectDes = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.PRODUCING_FORMULA_DESCRIPTION));
				sPFObjectTitle = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.PRODUCING_FORMULA_ATTRIBUTE_TITLE));
				sPFObjectState = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.PRODUCING_FORMULA_STATE));
				sPFObjectType = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.PRODUCING_FORMULA_TYPE));
				sPFObjectRevision = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.PRODUCING_FORMULA_REVISON));

				String sIpClass = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME));

				StringList slPFIdList = FrameworkUtil.split(sPFObjectId, ConstantsUtil.SYMBL_PIPE);
				StringList slPFNameList = FrameworkUtil.split(sPFObjectName, ConstantsUtil.SYMBL_PIPE);
				StringList slPFDescList = FrameworkUtil.split(sPFObjectDes, ConstantsUtil.SYMBL_PIPE);
				StringList slPFTitleList = FrameworkUtil.split(sPFObjectTitle, ConstantsUtil.SYMBL_PIPE);
				StringList slPFStateList = FrameworkUtil.split(sPFObjectState, ConstantsUtil.SYMBL_PIPE);
				StringList slPFTypeList = FrameworkUtil.split(sPFObjectType, ConstantsUtil.SYMBL_PIPE);
				StringList slPFRevisionList = FrameworkUtil.split(sPFObjectRevision, ConstantsUtil.SYMBL_PIPE);

				if (slPFIdList.size() != 0) {
					for (int i = 0; i < slPFIdList.size(); i++) {

						boolean showData = false;
						String strState = (String) slPFStateList.get(i);
						//SPEC: Release SR18x5.2- modified for Defect #39613 by Govind on Date 17/02/2021 start	
						//if (!strState.trim().equals("Preliminary")) {
						//Modified by Ajay for Defect 12042 - START
						if (strState.trim().equals("Release") || strState.trim().equals("Released")) {
							//SPEC: Release SR18x5.2- modified for Defect #39613 by Govind on Date 17/02/2021 end	
							// commented by Ganesh for security impl start
							/*
							 * if(util.isModificatinRequired()) { //For EBP User
							 * showData = util.checkOwnerShip(context,
							 * slUserOwnership, slPFIdList.get(i));
							 * 
							 * }else if(sec.isStaffAUGUser()) { //For Staff Aug
							 * USer check
							 * if(slPFTypeList.get(i).equalsIgnoreCase(
							 * ConstantsUtil.TYPE_FORMULATIONPART)) {
							 * //Validation for Hir checks on Formulation String
							 * sFormulaClassif =
							 * util.getFormulaPropagateClassification(context,
							 * slPFIdList.get(i));
							 * showData=util.checkInternalUserAcess(sUserlicense
							 * ,sFormulaClassif); }else { //Validation for Hir
							 * checks for other than Formulation
							 * showData=util.checkInternalUserAcess(sUserlicense
							 * ,validator.replaceSpecialSymbols(sIpClass)); }
							 * }else { //For Internal User check
							 * if(slHIRTypes.contains(slPFTypeList.get(i))) {
							 * //Validation for Hir checks on Formulation
							 * if(slPFTypeList.get(i).equalsIgnoreCase(
							 * ConstantsUtil.TYPE_FORMULATIONPART)) { String
							 * sFormulaClassif =
							 * util.getFormulaPropagateClassification(context,
							 * slPFIdList.get(i));
							 * showData=util.checkInternalUserAcess(sUserlicense
							 * ,sFormulaClassif); }else { //Validation for Hir
							 * checks for other than Formulation
							 * showData=util.checkInternalUserAcess(sUserlicense
							 * ,validator.replaceSpecialSymbols(sIpClass)); }
							 * }else { //If it is Non-Hir we can show without
							 * checks for internal user showData=true; }
							 * }commented by Ganesh stop
							 */
							// Added by Ganesh Start
							// Guna Modified for Defect 38626 18x.5.2 Release --
							// START
							// checkHasAccess(context, null, slPFIdList.get(i));
							String strPFId=slPFIdList.get(i);
							showData = checkHasAccess(context, null, strPFId.trim());
							// Guna Modified for Defect 38626 18x.5.2 Release --
							// END
							// Added by Ganesh stop
							
								if (!showData) {
									if(!util.isModificatinRequired()){
										//SPEC: Release SR18x5.2- modified for Defect #39613 by Govind on Date 18/02/2021 start	
										//pfType.append(((String) slPFTypeList.get(i))).append(ConstantsUtil.SYMBL_PIPE);
										pfType.append(mapType((String) slPFTypeList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
										//SPEC: Release SR18x5.2- modified for Defect #39613 by Govind on Date 18/02/2021 end	
										pfName.append(((String) slPFNameList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
										pfState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
										pfRevision.append(((String) slPFRevisionList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
										pfTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
										pfId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
										pfDesc.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								}
							}
							 else {
								//SPEC: Release SR18x5.2- modified for Defect #39613 by Govind on Date 18/02/2021 start	
								//pfType.append(((String) slPFTypeList.get(i))).append(ConstantsUtil.SYMBL_PIPE);
								pfType.append(mapType((String) slPFTypeList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: Release SR18x5.2- modified for Defect #39613 by Govind on Date 18/02/2021 end	
								pfName.append(((String) slPFNameList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
								pfState.append(((String) slPFStateList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
								pfRevision.append(((String) slPFRevisionList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
								pfTitle.append(((String) slPFTitleList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
								pfId.append(((String) slPFIdList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
								pfDesc.append(((String) slPFDescList.get(i).trim())).append(ConstantsUtil.SYMBL_PIPE);
							}
							//Modified by Ajay for Defect 12042 - END
						}
					}
				}
				mpProcucingFormula.put(ConstantsUtil.NAME, pfName.toString());
				mpProcucingFormula.put(ConstantsUtil.ID, pfId.toString());
				mpProcucingFormula.put(ConstantsUtil.TYPE, pfType.toString());
				mpProcucingFormula.put(ConstantsUtil.STATE, pfState.toString());
				mpProcucingFormula.put(ConstantsUtil.TITLE, pfTitle.toString());
				mpProcucingFormula.put(ConstantsUtil.REVISION, pfRevision.toString());
				mpProcucingFormula.put(ConstantsUtil.DESCRIPTION, pfDesc.toString());
			}
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRODUCING_FORMULA_ID);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRODUCING_FORMULA_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRODUCING_FORMULA_REVISON);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRODUCING_FORMULA_DESCRIPTION);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRODUCING_FORMULA_STATE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRODUCING_FORMULA_ATTRIBUTE_TITLE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRODUCING_FORMULA_TYPE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getProducingFormula " + e);
			return new HashMap();
		}

		return mpProcucingFormula;

	}

	/*
	 * 
	 * Get the Master AttributeData
	 * 
	 */
	public Map<String, String> getMasterAttributes(Context context, String sObjectId, String string) throws Exception {

		String sMasterObjectId = ConstantsUtil.EMPTY_STRING;
		Map mpMasterAttributes = new HashMap();

		try {
			if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				//DomainObject domChild = new DomainObject(sObjectId);
				DomainObject domChild = DomainObject.newInstance(context, sObjectId);
				sMasterObjectId = domChild.getInfo(context, ConstantsUtil.STR_MASTER_ID);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				domChild.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

				if (UIUtil.isNotNullAndNotEmpty(sMasterObjectId))
					if (string.equals("OPP")) {
						OnlinePrintingPartBO OPPBO = new OnlinePrintingPartBO();
						mpMasterAttributes = OPPBO.getMasterAttributeData(context, sMasterObjectId);

					} else if (string.equals("RMP")) {
						RawMaterialPartBO RawBO = new RawMaterialPartBO();
						mpMasterAttributes = RawBO.getMasterAttributeData(context, sMasterObjectId);
					} else if (string.equals("PAP")) {
						PackagingAssemblyPart PAPBO = new PackagingAssemblyPart();
						mpMasterAttributes = PAPBO.getMasterAttributeData(context, sMasterObjectId);
					} else if (string.equals("PMP")) {
						PackagingMaterialPartBO PMPBO = new PackagingMaterialPartBO();
						mpMasterAttributes = PMPBO.getMasterAttributeData(context, sMasterObjectId);
					}
				// SPEC: 10/21/2020: Commented for req 18x.5 ## -- START
				/*
				 * else if (string.equals("APP")) { APPBO APPBO = new
				 * APPBO(); mpMasterAttributes =
				 * APPBO.getMasterAttributeData(context, sMasterObjectId); }
				 */
				// SPEC: 10/21/2020: Commented for req 18x.5 ## -- END
					else {
						FabricatedPartBO FABBO = new FabricatedPartBO();
						mpMasterAttributes = FABBO.getMasterAttributeData(context, sMasterObjectId);
					}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getMasterAttributes " + e);
			return new HashMap();
		}

		return mpMasterAttributes;
	}

	public String replaceSquareBrackets(String sData) {
		if (UIUtil.isNullOrEmpty(sData)) {
			return ConstantsUtil.EMPTY_STRING;
		}
		return sData.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
				.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
	}

	public String replaceSquareBracketsOnly(String sData) {
		if (UIUtil.isNullOrEmpty(sData)) {
			return ConstantsUtil.EMPTY_STRING;
		}
		return sData.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING);
	}

	
	public Map<String, String> updateMaterials(Context context, DomainObject dob, boolean bFlag, Map mpContextMap)
			throws Exception {

		Map<String, String> mpComp = new HashMap<String, String>();

		StringValidatorUtil validator = new StringValidatorUtil();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbENVClass = new StringBuilder();
		StringBuilder sbPostCust = new StringBuilder();
		StringBuilder sbManuf = new StringBuilder();
		StringBuilder sbQTY = new StringBuilder();
		StringBuilder sbMaxPercent = new StringBuilder();
		StringBuilder sbMinPercent = new StringBuilder();
		StringBuilder sbMateLayer = new StringBuilder();
		StringBuilder sbGenerationNum = new StringBuilder();
		StringBuilder sbComment = new StringBuilder();
		StringBuilder sbSeq = new StringBuilder();
		StringBuilder sbTarget = new StringBuilder();
		StringBuilder sbPCID = new StringBuilder();
		StringBuilder sbID = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbQTYUom = new StringBuilder();
		StringBuilder sbNSPCG = new StringBuilder();

		StringBuilder sbClassfied = new StringBuilder();
		StringBuilder sbIPClassAttr = new StringBuilder();
		StringBuilder sbParentName = new StringBuilder();//Added by Ajay for 22x.06 Req.9264

		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		slBusSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME);
		slBusSelects.add(ConstantsUtil.LEGACYENVCLASSNAME);
		slBusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_SUBSTANCENAME);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
		StringList slRelSelects = new StringList();
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
		slRelSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
		
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		slRelSelects.add("attribute[Quantity Unit Of Measure]");
		slRelSelects.add("from.name");
		slRelSelects.add("from.id");
		BigDecimal dDefaultValue = BigDecimal.valueOf(0.0);
		MapList mlCopmonentsList = new MapList();
		try {

			String strContextType = validator
					.getStringEquivalentForStringList(mpContextMap.get(ConstantsUtil.SELECT_TYPE));
			String strContextName = validator
					.getStringEquivalentForStringList(mpContextMap.get(ConstantsUtil.SELECT_NAME));
			String strContextID = validator.getStringEquivalentForStringList(mpContextMap.get(ConstantsUtil.SELECT_ID));
			String strContextDesc = validator
					.getStringEquivalentForStringListWithComma(mpContextMap.get(ConstantsUtil.SELECT_DESCRIPTION));
			String strContextcurrent = validator
					.getStringEquivalentForStringList(mpContextMap.get(ConstantsUtil.SELECT_CURRENT));
			String strContextTitle = validator
					.getStringEquivalentForStringListWithComma(mpContextMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
			String strPManufacturer = validator
					.getStringEquivalentForStringListWithComma(mpContextMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER));
			String strConPostCon = validator.getStringEquivalentForStringList(
					mpContextMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT));
			String strTradeName = validator.getStringEquivalentForStringList(
					mpContextMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME));//Added by Pooja for Internal defect
			if(UIUtil.isNotNullAndNotEmpty(strConPostCon)){
				strConPostCon = getPostRecycledContent(new BigDecimal(strConPostCon), dDefaultValue);
			}
			
			MCPBO mcp=new MCPBO();
			StringList strContextPostIndu=mcp.getPostIndustrialValue(context,dob);
			String strContextPCID = validator.getStringEquivalentForStringList(strContextPostIndu);

			Pattern objType = new Pattern(ConstantsUtil.TYPE_MATERIAL);
			objType.addPattern(ConstantsUtil.TYPE_SUBSTANCE);
			
			Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL);
			relType.addPattern(ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE);
			relType.addPattern(ConstantsUtil.RELATIONSHIP_SECURE_COMPONENT_SUBSTANCE);
			
			mlCopmonentsList = dob.getRelatedObjects(context, 
					relType.getPattern(),
					objType.getPattern(), 
					slBusSelects, 
					slRelSelects, 
					false, 
					true, 
					(short) 0,
					ConstantsUtil.EMPTY_STRING, 
					ConstantsUtil.EMPTY_STRING, 
					ConstantsUtil.ZERO_LEVEL);
			//Added by Dominic for 22x Defect 50169 -- START	
			mlCopmonentsList =getSortedMaplistWithSequence(context,mlCopmonentsList,strContextID);
			//Added by Dominic for 22x Defect 50169 -- END

			if (bFlag) {
				mlCopmonentsList = filterPhase(mlCopmonentsList);
			}

			String sLegacyValue = getLegacyName(context, strContextID, ConstantsUtil.LEGACYENVCLASSNAME);
			String sContextObjectId = dob.getObjectId(context);
			if (mlCopmonentsList != null && mlCopmonentsList.size() > 0) {
				formatData(sbName, strContextName);
				formatData(sbType, mapType(strContextType));
				formatData(sbTitle, strContextTitle);
				formatData(sbDesc, strContextDesc);
				formatData(sbCurrent, strContextcurrent);
				formatData(sbID, strContextID);
				formatData(sbENVClass, sLegacyValue);
				strConPostCon = getPostRecycledContent(context, mlCopmonentsList, ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT);
				formatData(sbPostCust,strConPostCon);
				formatData(sbManuf, UIUtil.isNotNullAndNotEmpty(strPManufacturer)? strPManufacturer : DomainConstants.EMPTY_STRING);
				formatData(sbMaxPercent, ConstantsUtil.EMPTY_STRING);
				formatData(sbMinPercent, ConstantsUtil.EMPTY_STRING);
				formatData(sbMateLayer, ConstantsUtil.EMPTY_STRING);
				formatData(sbComment, ConstantsUtil.EMPTY_STRING);
				formatData(sbPCID, strContextPCID);
				formatData(sbQTYUom, ConstantsUtil.EMPTY_STRING);
				formatData(sbQTY,ConstantsUtil.EMPTY_STRING);
				formatData(sbSeq,ConstantsUtil.EMPTY_STRING);//Added by Pooja for 22x Defect 50596
				formatData(sbNSPCG,ConstantsUtil.EMPTY_STRING);
				formatData(sbTarget,strTradeName);//Added by Pooja for Internal defect
				formatData(sbParentName, ConstantsUtil.EMPTY_STRING);//Added by Ajay for 22x.06 Req.9264

			}

			Iterator objectListItr = mlCopmonentsList.iterator();

			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();

				String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.TYPE));
				
				String sTitle = validator
						.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				
				String sDesc = validator
						.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sParentName	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME));
				String sCurrent = validator.getStringEquivalentForString(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				if (sCurrent.equalsIgnoreCase(ConstantsUtil.APPROVED)) {
					sCurrent = ConstantsUtil.RELEASED;
				}
				if (sType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL)) {
					if (sCurrent.equals(ConstantsUtil.DEVELOPMENT)) {
						sCurrent = ConstantsUtil.STATE_INWORK;
					}
				}
				
				String sENVClass = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.LEGACYENVCLASSNAME));
				
				String sID = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sQTY = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
				String sMax = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT));
				String sMin = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT));
				
				String sMaterialLayer = validator.getStringEquivalentForSubstituteString(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER));

				String sPostCon = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT));
				
				String sManuf = validator.getStringEquivalentForSubstituteString(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER));

				String sPCID = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT));

				String sComment = validator
						.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));

				String sSequence = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));
				String sTarget = validator.getStringEquivalentForSubstituteString(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME));
				
				String strNSPCG	 =  validator.getStringEquivalentForString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG));

				String strClassFied = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String sQTYUom = validator
						.getStringEquivalentForStringList(objectMap.get("attribute[Quantity Unit Of Measure]"));
				if(sType.equals(ConstantsUtil.TYPE_SUBSTANCE) ||  sType.equals(ConstantsUtilIRM.TYPE_PPMSUBSTANCE)){
					sTitle	 =  validator.getStringEquivalentForSubstituteStringTitle(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCENAME));
				}
				if(sType.equals(ConstantsUtilIRM.TYPE_PPMSUBSTANCE)){
					sQTY     =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGETPERCENTAGEWEIGHTBYWEIGHT));
				}

				if(UIUtil.isNotNullAndNotEmpty(sPostCon) && UIUtil.isNotNullAndNotEmpty(sPCID)) {
					sPostCon = getPostRecycledContent(new BigDecimal(sPostCon), dDefaultValue);
					sPCID = getPostRecycledContent(new BigDecimal(sPCID), dDefaultValue);
				}
				

				formatData(sbClassfied, strClassFied);
				formatData(sbIPClassAttr, sIPClassfication);
				formatData(sbName, sName);
				formatData(sbType, mapType(sType));
				formatData(sbTitle, sTitle);
				formatData(sbDesc, sDesc);
				formatData(sbCurrent, sCurrent);
				formatData(sbENVClass, sENVClass);
				formatData(sbPostCust, sPostCon);
				formatData(sbManuf, sManuf);
				formatData(sbQTY, sQTY);
				formatData(sbMaxPercent, sMax);
				formatData(sbMinPercent, sMin);
				formatData(sbMateLayer, sMaterialLayer);
				formatData(sbComment, sComment);
				formatData(sbSeq, sSequence);
				formatData(sbTarget, sTarget);
				formatData(sbPCID, sPCID);
				formatData(sbNSPCG,strNSPCG);
				formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
						

				boolean bHasAccess = false;
				if (!sType.equals(ConstantsUtil.TYPE_SUBSTANCE) && !sType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL)) {
					bHasAccess = checkHasAccess(context, null, sID);
				} else {
					bHasAccess = true;
				}

				if (!bHasAccess) {
					sID = ConstantsUtil.NO_ACCESS;
				}
				if (!sCurrent.equals(ConstantsUtil.RELEASE) &&  !sCurrent.equals(ConstantsUtil.RELEASED)) {
					sID = ConstantsUtil.NO_ACCESS;
				}

				formatData(sbID, sID);
				formatData(sbQTYUom, sQTYUom);
			}

			mpComp.put(ConstantsUtil.ID, sbID.toString());
			mpComp.put(ConstantsUtil.NAME, sbName.toString());
			mpComp.put(ConstantsUtil.TYPE, sbType.toString());
			mpComp.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpComp.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
			mpComp.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpComp.put(ConstantsUtil.LEGACY_ENV_CLASS, sbENVClass.toString());
			mpComp.put(ConstantsUtil.TARGET_PERCEN_WBW, sbQTY.toString());
			mpComp.put(ConstantsUtil.MIN_PERCEN_WBW, sbMinPercent.toString());
			mpComp.put(ConstantsUtil.MAX_PERCEN_WBW, sbMaxPercent.toString());
			mpComp.put(ConstantsUtil.LAYER, sbMateLayer.toString());
			mpComp.put(ConstantsUtil.POSTCONSUMERRECYCLED, sbPostCust.toString());
			mpComp.put(ConstantsUtil.MANUFACTURER, sbManuf.toString());
			mpComp.put(ConstantsUtil.COMMMENTS, sbComment.toString());
			mpComp.put(ConstantsUtil.FN, sbSeq.toString());
			mpComp.put(ConstantsUtil.TRADENAME, sbTarget.toString());
			mpComp.put(ConstantsUtil.POST_INDUSTRIAL, sbPCID.toString());
			mpComp.put(ConstantsUtil.SECURITY, sbClassfied.toString());
			mpComp.put(ConstantsUtil.IPCLASSES, sbIPClassAttr.toString());
			mpComp.put(ConstantsUtil.QTYUOM, sbQTYUom.toString());
			mpComp.put(ConstantsUtilIRM.NSPCG, sbNSPCG.toString());
			mpComp.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString());//Added by Ajay for 22x.06 Req.9264
			

		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :updateMaterials " + e);
			return new HashMap();
		}

		return mpComp;

		// return filterMapList(mpComp);
	}

	/*
	 * Get the Related Universal DOcuments and return as per the User
	 * 
	 */
	public String updateReferences(Context context, String sObjectId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpUnvDOcs = new HashMap<String, String>();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID = new StringBuilder();
		StringBuilder sbAttribCheck = new StringBuilder();

		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIVERSALDOCUMENTRECIPIENTGROUP);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

		String sUserType = getUserType();
		MapList mlUnvDocList = new MapList();
		try {
			if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {

				//DomainObject dob = new DomainObject(sObjectId);
				DomainObject dob = DomainObject.newInstance(context, sObjectId);

				mlUnvDocList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGUNIVERSALDOCUMENTTOSTANDARD,
						DomainConstants.QUERY_WILDCARD, slBusSelects, null, true, false, (short) 1,
						"current == Active", DomainConstants.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: Release SR18x.6.0.1 Modified by Sanjeeva for Defect# 43687 on 06/25/2021 --END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				dob.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				Iterator objectListItr = mlUnvDocList.iterator();

				while (objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();

					String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sID = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					String sAttribCheck = (String) objectMap
							.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIVERSALDOCUMENTRECIPIENTGROUP);

					if (sAttribCheck.equals(ConstantsUtil.STR_ALL_CM) && sUserType.equals(ConstantsUtil.PG_CM)) {
						//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43944 on Date 06/07/2021 --START
						sUserType = getUserView(context, sObjectId);
						if(sUserType.equals(ConstantsUtil.PG_SP))
						{
							return ConstantsUtil.PG_SP;
						}
						else
						{
							return ConstantsUtil.PG_CM;
						}
						//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43944 on Date 06/07/2021 --END

					} else if (sAttribCheck.equals(ConstantsUtil.STR_ALL_SUPPLIER)
							&& sUserType.equals(ConstantsUtil.PG_SP)) {
						return ConstantsUtil.PG_SP;
					} else if (sAttribCheck.equals(ConstantsUtil.ALL_CM_AND_ALL_SUPP)) {
						return ConstantsUtil.ALLOW_FOR_ALL;
						//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43944 on Date 05/07/2021 --START
					} else if (sAttribCheck.equals(ConstantsUtil.STR_ALL_SUPPLIER) && sUserType.equals(ConstantsUtil.PG_CM)) {
						sUserType = getUserView(context, sObjectId);
						if(sUserType.equals(ConstantsUtil.PG_SP))
						{
							return ConstantsUtil.PG_SP;
						}
						else
						{
							return ConstantsUtil.EMPTY_STRING;
						}
						//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43944 on Date 05/07/2021 --END
					} else {
						return ConstantsUtil.EMPTY_STRING;
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :updateReferences " + e);
			return ConstantsUtil.EMPTY_STRING;
		}
		return "NO Connection Exists";
	}

	/*
	 * Check the Ownership. If the Parent and Child has matching Ownership Send
	 * the Original Map If not Modify for the Particular Object
	 */

	public boolean checkOwnerShip(Context context, StringList slParentOwnerShip, String sObjectID) {
		StringValidatorUtil validator = new StringValidatorUtil();
		boolean bHasOwnerShip = false;
		try {
			//DomainObject domChild = new DomainObject(sObjectID);
			DomainObject domChild = DomainObject.newInstance(context, sObjectID);
			
			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtil.OWNERSHIP);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.OWNERSHIP);
			Map mpChildOwnership = domChild.getInfo(context, slSelects);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domChild.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.OWNERSHIP);

			StringList slChildOwnership = validator
					.isNotNullOrEmpty((StringList) mpChildOwnership.get(ConstantsUtil.OWNERSHIP));

			if (slChildOwnership.isEmpty()) {
				return false;
			}
			slChildOwnership = filterOwnerShip(slChildOwnership);
			
			//Added by Jwala to Check Obsolete object Ownership for Comparision req - START
			String strObsoleteState = domChild.getInfo(context, DomainConstants.SELECT_CURRENT);

			if(ConstantsUtil.STATE_OBSOLETE.equalsIgnoreCase(strObsoleteState)&& slChildOwnership.isEmpty()) {
				slChildOwnership = getObsoleteOwnership(context,domChild,sObjectID);
			}
			//Added by Jwala to Check Obsolete object Ownership for Comparision req - END

			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();

			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			//String[] aCompany = sUserCompanies.split(",");
			String[] aCompany = splitCompanyValues(context,sUserCompanies);
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START

			StringBuilder sbCompany = new StringBuilder();

			if (aCompany.length > -1) {
				for (int i = 0; i < aCompany.length; i++) {
					if (null != aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					}
				}
			}
			bHasOwnerShip = checkOwnerShip(sbCompany, slChildOwnership);

			/*
			 * for (int j = 0; j < slChildOwnership.size(); j++) { bHasOwnerShip
			 * = slParentOwnerShip.contains(slChildOwnership.get(j).trim());
			 * if(bHasOwnerShip) break; }
			 */

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :checkOwnerShip " + e);
			return false;
		}

		//Commented by Jwala 
		/*if (bHasOwnerShip)
			LOGGER.info(" Child and Parent  has common Ownership ");
		else
			LOGGER.info(" Child and Parent  Don't have common Ownership ");*/

		return bHasOwnerShip;

	}

	/*
	 * Update the Ownership on StringList by removing the PIPE and Partners PG,
	 * Multiownership
	 */
	public StringList filterOwnerShip(StringList slParentOwnerShip) {
		StringValidatorUtil validator = new StringValidatorUtil();
		String sTempParentOwnership = replaceSpecialSymbols(validator.isNotNullOrEmpty(slParentOwnerShip.toString())
				? slParentOwnerShip.toString() : ConstantsUtil.EMPTY_STRING);
		return filterOwnerShip(sTempParentOwnership);
	}

	public StringList filterOwnerShip(String sTempParentOwnership) {
		StringValidatorUtil validator = new StringValidatorUtil();
		StringList slOwnerShip = new StringList();
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		if (UIUtil.isNotNullAndNotEmpty(sTempParentOwnership))
		{
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END	
			String[] saParentOwnership = sTempParentOwnership.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);	

			for (int j = 0; j < saParentOwnership.length; j++) {
				if (!saParentOwnership[j].trim().equals(ConstantsUtil.PROJECT_PARTNERS_PG)
						&& !saParentOwnership[j].trim().equals(ConstantsUtil.STR_MULTIPLE_OWNERSHIP)) {
					slOwnerShip.add(saParentOwnership[j].trim());
				}
			}
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		}
		//SPEC: <14-09-2021>: Guna Commented for Stress Testing (2nd Round) -- START
	    /*else {
			LOGGER.error("NullPointer Exception in Program : BusObjectAttribUtil Method :filterOwnerShip:"+sTempParentOwnership);
		}*/
		//SPEC: <14-09-2021>: Guna Commented for Stress Testing (2nd Round) -- END
		// }
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		return slOwnerShip;
	}

	public MapList filterPhase(MapList mlDataList) {
		MapList mlTemp = new MapList();
		boolean bFlag = false;
		StringValidatorUtil validator = new StringValidatorUtil();

		int size = mlDataList.size();
		if (mlDataList.size() == 0) {
			return new MapList();
		}

		try {
			Iterator objectListItr = mlDataList.iterator();

			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				if (objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)
						&& objectMap.containsKey(ConstantsUtil.SELECT_CURRENT)) {
					String sPhase = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
					String sState = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
					if (isProduction(sPhase, mapType(sState.trim())))
						mlTemp.add(objectMap);
				} else {
					//SPEC: 04-30-2021: Added for 18x.6 Internal Defect by Bala -- START
					return mlDataList;
					//SPEC: 04-30-2021: Added for 18x.6 Internal Defect by Bala -- END
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :filterPhase  signature of MapList " + e);
			return new MapList();
		}

		return mlTemp;
	}

	public Map<String, String> filterPhase(Map<String, String> mpMaterialResult) {
		StringList slNonProd = new StringList();

		if (mpMaterialResult.isEmpty()) {
			return new HashMap();
		}
		Map objectMap = new HashMap();
		try {
			if (mpMaterialResult.containsKey(ConstantsUtil.PHASE)
					&& mpMaterialResult.containsKey(ConstantsUtil.STATE)) {
				String sPhase = (String) mpMaterialResult.get(ConstantsUtil.PHASE);
				String sState = (String) mpMaterialResult.get(ConstantsUtil.STATE);

				if (UIUtil.isNullOrEmpty(sPhase) && UIUtil.isNullOrEmpty(sState)) {
					return mpMaterialResult;
				}

				String saPhase[] = sPhase.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
				String saState[] = sState.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

				if (saPhase.length != 0 && saState.length != 0) {
					for (int i = 0; i < saState.length; i++) {
						if (!UIUtil.isNotNullAndNotEmpty(saPhase[i]) && !UIUtil.isNotNullAndNotEmpty(saState[i])) {
							slNonProd.add(String.valueOf(i));
						}
						if (!isProduction(saPhase[i], mapType(saState[i].trim())))
							slNonProd.add(String.valueOf(i));
					}
				}
				//SPEC: 04-30-2021: Added for 18x.6 Internal Defect by Sanjeeva -- START
				else {
					return mpMaterialResult;
				}
				//SPEC: 04-30-2021: Added for 18x.6 Internal Defect by Sanjeeva -- END
				if (slNonProd.size() != 0) {
					mpMaterialResult = filterProdObjects(slNonProd, mpMaterialResult);
				}
			} else {
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- START (For Internal Defect)
				//SPEC: 04-30-2021: Modified for 18x.6 Internal Defect by Sanjeeva -- START
				//if(mpMaterialResult.containsKey(ConstantsUtil.STATE))
				if(mpMaterialResult.containsKey(ConstantsUtil.STATE) || mpMaterialResult.containsKey("ATSstate"))
					//SPEC: 04-30-2021: Modified for 18x.6 Internal Defect by Sanjeeva -- END
					return mpMaterialResult;
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- END (For Internal Defect)

				return new HashMap();

			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :filterPhase signature of Map " + e);
			return new HashMap();
		}
		return mpMaterialResult;
	}

	/*
	 * Update all the values as per security and return
	 */
	public Map<String, String> filterProdObjects(StringList sbIndex, Map<String, String> mpRefDoc) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpTemp = new HashMap();
		try {
			for (Map.Entry<String, String> entry : mpRefDoc.entrySet()) {
				String sKey = entry.getKey();
				String sVal = entry.getValue();

				if (!ConstantsUtil.PHASE.equals(sKey)) {
					StringList slValueList = FrameworkUtil.split(sVal, ConstantsUtil.SYMBL_PIPE);
					slValueList = validator.isNotNullOrEmpty(removeObjects(sbIndex, slValueList, false));
					mpTemp.put(sKey, replaceSpecialSymbols(slValueList.toString()));
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :filterProdObjects " + e);
		}
		return mpTemp;
	}

	public Map<String, String> filterNonReleasedObjects(StringList sbIndex, Map<String, String> mpRefDoc) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpTemp = new HashMap();
		try {
			for (Map.Entry<String, String> entry : mpRefDoc.entrySet()) {
				String sKey = entry.getKey();
				String sVal = entry.getValue();

				// if (!ConstantsUtil.STATE.equals(sKey)) {

				StringList slValueList = FrameworkUtil.split(sVal, ConstantsUtil.SYMBL_PIPE);
				slValueList = validator.isNotNullOrEmpty(removeObjects(sbIndex, slValueList, false));
				mpTemp.put(sKey, replaceSpecialSymbols(slValueList.toString()));
				// }
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :filterNonReleasedObjects " + e);
		}
		return mpTemp;
	}

	/**
	 * 
	 * @param sPhase
	 * @param state
	 * @return
	 */
	public boolean isProduction(String sPhase, String state) {

		try {
			sPhase = sPhase.trim();
			state = state.trim();

			if (UIUtil.isNullOrEmpty(sPhase) && UIUtil.isNullOrEmpty(state)) {
				sPhase = ConstantsUtil.EMPTY_STRING;
				state = ConstantsUtil.EMPTY_STRING;
				return false;
			}

			if ((state.equals(ConstantsUtil.RELEASE) || state.equals(ConstantsUtil.RELEASED) || state.equals(ConstantsUtil.STATE_OBSOLETE)
					|| state.equals(ConstantsUtil.NO_ACCESS))
					&& (sPhase.equals(ConstantsUtil.PRODUCTION) || sPhase.equals(ConstantsUtil.NO_ACCESS)
							|| sPhase.equals(ConstantsUtil.EMPTY_STRING))) {
				return true;
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :isProduction " + e);
		}
		return false;
	}

	public boolean isReleased(String state) {

		try {
			state = state.trim();

			if (UIUtil.isNullOrEmpty(state)) {
				state = ConstantsUtil.EMPTY_STRING;
				return false;
			}

			if ((state.equals(ConstantsUtil.RELEASE) || state.equals(ConstantsUtil.RELEASED)
					|| state.equals(ConstantsUtil.NO_ACCESS))) {
				return true;
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :isProduction " + e);
		}
		return false;
	}

	/**
	 * 
	 * @param context
	 * @param sClassFiedID
	 * @param sClassFiedName
	 * @return
	 */

	public String getMaterial(Context context, String sClassFiedID, String sClassFiedName) {
		StringBuilder sbFinal = new StringBuilder();
		MapList mlMaterialList = new MapList();
		try {
			//START :: gaikwad.tg :: Defect#38976 :: Added null check
			if(UIUtil.isNotNullAndNotEmpty(sClassFiedID))
			{
				//END :: gaikwad.tg :: Defect#38976
				//DomainObject dob = new DomainObject(sClassFiedID);
				DomainObject dob = DomainObject.newInstance(context, sClassFiedID);

				StringList busSelect = new StringList();
				busSelect.add(ConstantsUtil.SELECT_NAME);
				busSelect.add(ConstantsUtil.SELECT_ID);

				mlMaterialList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_SUBCLASS,
						ConstantsUtil.SYMBL_ASTERISK, busSelect, null, true, false, (short) 0, ConstantsUtil.EMPTY_STRING,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				dob.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				mlMaterialList.sort("level", "descending", "integer");

				Iterator objectListItr = mlMaterialList.iterator();

				while (objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
					sbFinal.append(sName).append(ConstantsUtil.SYMBL_ARROW);
				}
				sbFinal.append(sClassFiedName);
				//SPEC: Release SR18x.5.2 - Added for Defect# 38976  by gaikwad.tg on Date 11 Feb 2021 -- START
			}
		}catch(NullPointerException ne) 
		{ 
			System.out.print("NullPointerException Caught in busObjectAttibUtil method getMaterial :" + ne.getMessage()); 
		}
		//SPEC: Release SR18x.5.2 - Added for Defect# 38976  by gaikwad.tg on Date 11 Feb 2021 -- END
		catch (Exception e) {
			System.out.println("Exception in busObjectAttibUtil method getMaterial :" + e.getMessage());
		}
		return sbFinal.toString();
	}

	/**
	 * 
	 * @param sbIndex
	 * @param mpRefDoc
	 * @return
	 */

	public Map<String, String> filterRelatedPartObjects(StringList sbIndex, Map<String, String> mpRefDoc) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpTemp = new HashMap();
		try {
			for (Map.Entry<String, String> entry : mpRefDoc.entrySet()) {
				String sKey = entry.getKey();
				String sVal = entry.getValue();

				if (!ConstantsUtil.CLASSIFICATION.equals(sKey) && !ConstantsUtil.SECURITY.equals(sKey)
						&& !ConstantsUtil.PHASE.equals(sKey) && !ConstantsUtil.OWNERSHIP.equals(sKey)) {
					StringList slValueList = FrameworkUtil.split(sVal, ConstantsUtil.SYMBL_PIPE);

					if (!ConstantsUtil.NAME.equals(sKey) && !ConstantsUtil.TYPE.equals(sKey)) {
						slValueList = validator.isNotNullOrEmpty(removeObjects(sbIndex, slValueList, true));
					}
					mpTemp.put(sKey, replaceSpecialSymbols(slValueList.toString()));
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :filterRelatedPartObjects " + e);
		}
		return mpTemp;
	}

	public String getValidRelatedSpecsForPart(String sPartType, String sUserType) {
		StringBuilder sbSpecTypes = new StringBuilder();
		if (sUserType.equals(ConstantsUtil.PG_CM)) {
			if (ConstantsUtil.tAPMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tCOP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tPIP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tMEP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSEP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tCUP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tFAB.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSEP));
			} else if (ConstantsUtil.tFPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tIP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tIPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tRMPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tMCOP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tMCUP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tMIP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tMPAP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tMPMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tPMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tART)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPOA)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSEP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tOPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tART)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPOA)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSEP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tPAP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSEP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tMEP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tTUP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tSPS)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPI));
			} else if (ConstantsUtil.tFOP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI));
			} else if (ConstantsUtil.tAPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI)).append(mapType(ConstantsUtil.tIAPS));
			} else if (ConstantsUtil.tDPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI));
			} else if (ConstantsUtil.tRMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tART)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPOA)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI));
			} else if (ConstantsUtil.tIRMS.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tART)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPOA)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI));
			} else if (ConstantsUtil.tMRMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI));
			} else if (ConstantsUtil.tMPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI));
			} else if (ConstantsUtil.tARMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI));
			} else if (ConstantsUtil.tMI.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL));
			} else if (ConstantsUtil.tPROS.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL));
			} else if (ConstantsUtil.tLIS.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tACS.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM));
			} else if (ConstantsUtil.tIAPS.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM));
			}
		} else {
			if (ConstantsUtil.tAPMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tFAB.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST));
			} else if (ConstantsUtil.tIPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tRMPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(mapType(ConstantsUtil.tQUAL))).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tMPAP.contains(sPartType)) {
				sbSpecTypes.append(ConstantsUtil.tPI).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tMPMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tPMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tART)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPOA)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSEP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tOPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tART)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPOA)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSEP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tPAP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPI)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPOA)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSEP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP));
			} else if (ConstantsUtil.tDPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI));
			} else if (ConstantsUtil.tRMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tART)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tPOA)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL));
			} else if (ConstantsUtil.tMRMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL));
			} else if (ConstantsUtil.tMPP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tRMPI));
			} else if (ConstantsUtil.tARMP.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tSOP)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tTM)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL));
			} else if (ConstantsUtil.tMI.contains(sPartType)) {
				sbSpecTypes.append(mapType(ConstantsUtil.tILST)).append(ConstantsUtil.SYMBL_COMMA)
				.append(mapType(ConstantsUtil.tQUAL));
			}
		}
		return sbSpecTypes.toString();
	}

	public Map<String, String> validatePartSpecsForEbp(Context context, Map<String, String> mpPartSpecResult,
			String sParentType, String sAllowedSpecs) {
		Map<String, String> mpFinalList = new HashMap();
		try {

			if (mpPartSpecResult.isEmpty()) {

				return mpPartSpecResult;
			}
			StringValidatorUtil validator = new StringValidatorUtil();
			String strType = mpPartSpecResult.get(ConstantsUtil.TYPE);
			String strName = mpPartSpecResult.get(ConstantsUtil.NAME);
			String strState = mpPartSpecResult.get(ConstantsUtil.STATE);
			String strSubType = mpPartSpecResult.get(ConstantsUtil.SPECIFICATIONSUBTYPE);
			String strTitle = mpPartSpecResult.get(ConstantsUtil.TITLE);
			String strId = mpPartSpecResult.get(ConstantsUtil.ID);
			String strPhase = mpPartSpecResult.get(ConstantsUtil.PHASE);
			String strSource = mpPartSpecResult.get(ConstantsUtil.SOURCE);
			String strOrig = mpPartSpecResult.get(ConstantsUtil.ORIGINATOR);
			String sOwnership = mpPartSpecResult.get(ConstantsUtil.OWNERSHIP);

			// StringList aType = FrameworkUtil.split(strType,
			// ConstantsUtil.SYMBL_PIPE);
			StringList aType = getStringList(strType);
			StringList aSubType = getStringList(strSubType);
			StringList aName = getStringList(strName);
			StringList aState = getStringList(strState);
			StringList aTitle = getStringList(strTitle);
			StringList aId = getStringList(strId);
			StringList aPhase = getStringList(strPhase);
			StringList aSource = getStringList(strSource);
			StringList aOrig = getStringList(strOrig);

			StringBuilder sbType = new StringBuilder();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbState = new StringBuilder();
			StringBuilder sbSubType = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbPhase = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			StringBuilder sbOrig = new StringBuilder();

			for (int i = 0; i < aType.size(); i++) {

				String sType = validator.isNotNullOrEmpty(aType, i);
				String sName = validator.isNotNullOrEmpty(aName, i);
				if (sAllowedSpecs.contains(sType.trim())
						|| ((sParentType.equalsIgnoreCase(ConstantsUtil.SHARINGRULE_MEP_SEP_TYPES))
								&& (sName.contains("MEP-") || sName.contains("SEP-")))) {

					SecurityService ss = new SecurityService();
					String sUserCompanies = ss.getUserCauthorities();

					if (sUserCompanies.contains(sOwnership)) {

					}

					sbType.append(sType);
					sbType.append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(validator.isNotNullOrEmpty(aName, i));
					sbName.append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(validator.isNotNullOrEmpty(aState, i));
					sbState.append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(validator.isNotNullOrEmpty(aSubType, i));
					sbSubType.append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(validator.isNotNullOrEmpty(aTitle, i));
					sbTitle.append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(validator.isNotNullOrEmpty(aId, i));
					sbId.append(ConstantsUtil.SYMBL_PIPE);
					sbPhase.append(validator.isNotNullOrEmpty(aPhase, i));
					sbPhase.append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(validator.isNotNullOrEmpty(aSource, i));
					sbSource.append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(validator.isNotNullOrEmpty(aOrig, i));
					sbOrig.append(ConstantsUtil.SYMBL_PIPE);
				} else {
					sbType.append(sType).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(validator.isNotNullOrEmpty(aName, i)).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbPhase.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
				}

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.PHASE, sbPhase.toString());
			if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
				mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
				mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			}
		} catch (Exception e) {
			LOGGER.error("Exception in BusObjectAttribUtil validatePartSpecsForEbp: " + e);
			return mpFinalList;
		}
		return mpFinalList;
	}

	public boolean isOfDSOOrigin(Context context, String strObjectId) throws FrameworkException {
		boolean isDSO = false;
		try {
			if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
				DomainObject doObject = DomainObject.newInstance(context, strObjectId);
				String strAttrValue = doObject.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				if (ConstantsUtil.DSO.equalsIgnoreCase(strAttrValue)) {
					isDSO = true;
				}
			}
		} catch (FrameworkException fme) {
			throw fme;
		}
		return isDSO;
	}

	public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		//StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		//Commented by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527
		//StringBuilder sbOwnership = new StringBuilder();
		StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbDescription = new StringBuilder();
		StringBuilder sbArtworkPrimary = new StringBuilder();
		StringBuilder sbInHerType = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		boolean showData = false;
		ArrayList idAlreadyPresent = new ArrayList();
		StringBuilder sbRelPattern = new StringBuilder();
		String sRelationPattern = sbRelPattern.append(ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION)
				.append(ConstantsUtil.SYMBL_COMMA)
				.append(ConstantsUtil.REL_PG_INHERITED_CAD_SPEC)
				.toString();
		
		// Guna modified for Defect 35928 18x.5.2 Release -- START
		// Jwala modified for Defect 38092 18x.5.2 Release -- START
		//<SPEC> 03/02/2021- Modified by Govind for Defect #38883 start : Added SIS type to if condition
		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)
				|| sParentType.equals(ConstantsUtil.TYPE_PGRAWMATERIAL)
				|| sParentType.equals(ConstantsUtil.TYPE_PGPACKINGMATERIAL) 
				|| sParentType.equals(ConstantsUtil.TYPE_PGSUPPLIERINFORMATIONSHEET)
				|| sParentType.equals(ConstantsUtil.TYPE_PGMASTERRAWMATERIAL)
				|| sParentType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT)
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41469 on Date 26/03/2021 --START
				|| sParentType.equals(ConstantsUtil.tMPMS)
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41469 on Date 26/03/2021 --END
				|| sParentType.equals(ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY)) {
			// Jwala modified for Defect 38092 18x.5.2 Release -- START
			// Guna modified for Defect 35928 18x.5.2 Release -- END
			//<SPEC> 03/02/2021- Modified by Govind for Defect #38883 end
			sbRelPattern = new StringBuilder ();
			sRelationPattern = sbRelPattern.append(ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION)
					.append(ConstantsUtil.SYMBL_COMMA)
					.append(ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST)
					.toString();
		}
		boolean isTo = false;
		boolean isFrom = false;
		if (sParentType.equals(ConstantsUtil.TYPE_POA) || sParentType.equals(ConstantsUtil.TYPE_PGARTWORK)) {
			isFrom = true;
		} else {
			isFrom = true;
		}
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = splitCompanyValues(context,sUserCompanies);
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = getUserType();
		// Guna modified for Defect 35928 18x.5.2 Release -- START
		if (sUserType.equals(ConstantsUtil.PG) || sct.isStaffAUGUser()) {
			sWhere = ConstantsUtilIRM.CURRENTNOTOBSOLETE;
		} else {
			//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43936 on Date 30/06/2021 --START
			sWhere = ConstantsUtilIRM.CURRENTRELEASE;
			//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43936 on Date 30/06/2021 --END
		}
		// Guna modified for Defect 35928 18x.5.2 Release -- END
		int intCompLength = aCompany.length;
		if (intCompLength > -1) {
			for (int i = 0; i < intCompLength; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(ConstantsUtilIRM.SPACEPLANT, ConstantsUtil.EMPTY_STRING)).append(ConstantsUtil.SYMBL_PIPE);
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		//Added by Subhajit - For Performance Issue - Defect No - 51963 and PRB0100527 - Start
		slPartSpecSelects.remove(ConstantsUtil.OWNERSHIP);
		//Added by Subhajit - For Performance Issue - Defect No - 51963 and PRB0100527 - End
		StringList slRelSelects = new StringList();
		slRelSelects.add(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY);
		slRelSelects.add(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
		MapList mapList;
		try {
			//DomainObject doAPP = new DomainObject(sObjectID);
			DomainObject doAPP = DomainObject.newInstance(context, sObjectID);
			mapList = doAPP.getRelatedObjects(context, sRelationPattern, DomainConstants.QUERY_WILDCARD,
					slPartSpecSelects, slRelSelects, isTo, isFrom, (short) 1, sWhere, DomainConstants.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			doAPP.close(context);
			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				//Commented by Subhajit - For Performance Issue - Defect No - 51963 and PRB0100527 - Start
				//StringList eachOwnership = validator.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				//StringList slEachOwnership = filterOwnerShip(eachOwnership);
				//Commented by Subhajit - For Performance Issue - Defect No - 51963 and PRB0100527 - End

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator
						.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				// Added for defect #37081 -- START
				String strOriginatingSrc = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE));
				String strPolicy = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.POLICY));
				// Added for defect #37081 -- END
				String strRevision = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strDescription = validator
						.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_DESCRIPTION));

				// SPEC: 10/30/2020: Added for Defect 36711 -- START
				if (strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)) {
					strDescription = validator.getStringEquivalentForSubstituteString(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYDESCRIPTION));
				}
				// SPEC: 10/30/2020: Added for Defect 36711 -- END

				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				//SPEC: Release SR18x.5.2 - Added for Defect# 39288  by Dominic on Date 11/02/2021 -- START
				if (!idAlreadyPresent.contains(strId)) {
					//SPEC: Release SR18x.5.2 - Added for Defect# 39288  by Dominic on Date 11/02/2021 -- END
					String strClassFied = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
					String strAutocadClassFied = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
					String sIPClassfication = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
					String sArtworkPrimary = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY));
					//String strSource = getSource(context, strId);
					String strSubType = UpdateSpecSubType(context, strId);
					String strInHerType = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE));
					if (sArtworkPrimary.isEmpty()) {
						sArtworkPrimary = ConstantsUtil.KEY_NO;
					}
					
					String strState = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
					String strId_Result = strId;
					if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)) {
						strId_Result = ConstantsUtil.NO_ACCESS;
					}
					
					showData = checkHasAccess(context, sUserType, strId);
					//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
					if(!showData && isModificatinRequired()){
						continue;
					}
					//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END

					//SPEC: Release SR18x.6. Added by Dominic for Req#35908 on Date 26/04/2021 --START
					if (isModificatinRequired()) {
						if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								//sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbInHerType.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
							} 
							else
							{
								sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
								sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								if (strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)) {
									strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
								}
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								//sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
								if (strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
									sbId.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
								} else {
									sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								}
								sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
							}

						} 
						else
						{
							if (showData) {
								sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
								sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								if (strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)) {
									strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
								}
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								//sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
								if (strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
									sbId.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
								} else {
									sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								}
								sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								//sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbInHerType.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
							}
						}
					}
					else
					{
						//SPEC: Release SR18x.6. Added by Dominic for Req#35908 on Date 26/04/2021 --END
						if (showData) {
							sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							// SPEC: 10/30/2020: Added for Defect 36711 -- START
							if (strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)) {
								strTitle = validator.getStringEquivalentForSubstituteString(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
							}
							// SPEC: 10/30/2020: Added for Defect 36711 -- END
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							//sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							// temporary fix to prevent users from downloading a
							// Physical product(VPMReference)
							if (strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
								sbId.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								
								sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								
							}
							sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							// Modified for Defect #37081 -- START
							// sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							// Modified for Defect #37081 -- START
							sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							//sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: Release SR18x.6. Modified by Dominic for Defect 41879 on Date 29/03/2021 --START
							sbInHerType.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: Release SR18x.6. Modified by Dominic for Defect 41879 on Date 29/03/2021 --END

						}
						//SPEC: Release SR18x.6. Added by Dominic for Req#35908 on Date 26/04/2021 --START
					}
					//SPEC: Release SR18x.6. Added by Dominic for Req#35908 on Date 26/04/2021 --END
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39288  by Dominic on Date 11/02/2021 -- START
				idAlreadyPresent.add(strId);
			}
			//SPEC: Release SR18x.5.2 - Added for Defect# 39288  by Dominic on Date 11/02/2021 -- END
			// }
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			//mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString()); //Commented by Ketan for Req. no. 47200
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			mpFinalList.put(ConstantsUtil.ARTWORKPRIMARY, sbArtworkPrimary.toString());
			mpFinalList.put(ConstantsUtil.INHERITANCETYPE, sbInHerType.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Exception in BusObjectAttribUtil getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}

	public boolean checkOwnerShip(StringBuilder sbCompany, StringList slEachOwnership) {

		boolean bHasOwnerShip = false;
		StringBuffer sb = new StringBuffer();
		// sb.append("CSS VTO 2~CA24|VTO TEST SUPPLIER
		// 1~20514297|ZOBELE-GARLAND-PGMFG~C454|");
		//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
		String tempVal =sbCompany.toString();
		tempVal=tempVal.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
		StringList slTokens =getStringListWithComma(tempVal);

		for (int i = 0; i < slEachOwnership.size(); i++) {
			if (UIUtil.isNotNullAndNotEmpty(slEachOwnership.get(i))) {
				//bHasOwnerShip = sbCompany.toString().contains(slEachOwnership.get(i));
				bHasOwnerShip = slTokens.contains(slEachOwnership.get(i));

				//SPEC: 04-30-2021: Added for 18x.6 Internal Defect by Sanjeeva -- START
				//if (bHasOwnerShip)
				//if (bHasOwnerShip || sbCompany.toString().contains(slEachOwnership.get(i).replace(" Plant", ""))) {
				if (bHasOwnerShip || slTokens.contains(slEachOwnership.get(i).replace(" Plant", ""))) {
					bHasOwnerShip = true;
					break;
				}
				//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
				//SPEC: 04-30-2021: Added for 18x.6 Internal Defect by Sanjeeva -- END
			}
		}
		return bHasOwnerShip;
	}

	public String getFormulaPropagate(Context context, String sFop) {

		String strFormulationProcessId = "";
		try {

			//DomainObject doFormPart = new DomainObject(sFop);
			DomainObject doFormPart = DomainObject.newInstance(context, sFop);
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.SELECT_ID);
			MapList mlResult = doFormPart.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE,
					DomainConstants.QUERY_WILDCARD, busSelect, null, true, false, (short) 0, DomainConstants.EMPTY_STRING,
					DomainConstants.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doFormPart.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if (mlResult.size() > 0) {
				Map mpFormProcess = (Map) mlResult.get(0);
				strFormulationProcessId = (String) mpFormProcess.get(ConstantsUtil.SELECT_ID);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in BusObjectAttribUtil getFormulaPropagate: " + e);
		}
		return strFormulationProcessId;
	}

	public String getFormulaPropagateClassification(Context context, String sFop) {

		StringList slFormulationProcessClass = new StringList();
		try {

			//DomainObject doFormPart = new DomainObject(sFop);
			DomainObject doFormPart = DomainObject.newInstance(context, sFop);
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.STR_IPCLASS);
			MapList mlResult = doFormPart.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE,
					DomainConstants.QUERY_WILDCARD, busSelect, null, true, false, (short) 0, DomainConstants.EMPTY_STRING,
					DomainConstants.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doFormPart.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if (null != mlResult && mlResult.size() > 0) {
				Map mpFormProcess = (Map) mlResult.get(0);
				Object value = mpFormProcess.get(ConstantsUtil.STR_IPCLASS);
				if (null != value && value.getClass().getSimpleName().equals(ConstantsUtil.STRING)) {
					String sFormulationProcess = (String) mpFormProcess.get(ConstantsUtil.STR_IPCLASS);
					slFormulationProcessClass = getStringList(sFormulationProcess);
				} else if (null != value) {
					slFormulationProcessClass = (StringList) mpFormProcess.get(ConstantsUtil.STR_IPCLASS);
				} else {
					// Empty map do nothing
					return slFormulationProcessClass.toString();
				}

			}
		} catch (Exception e) {
			LOGGER.error("Exception in BusObjectAttribUtil getFormulaPropagateClassification: " + e);
		}
		return replaceSquareBrackets(slFormulationProcessClass.toString());
	}

	// SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
	// public Map<String, String> getMasterPartSpecifications(Context context,
	// String sObjectID,
	// String sMasterObjectClassfiedItem) throws Exception {
	// SPEC: 10/09/2020: Modified for 18x.5 DEV -- START

	public Map<String, String> getMasterPartSpecifications(Context context, String sObjectID,
			String sMasterObjectClassfiedItem, String sMasterObjectName, String sMasterObjectId,
			String sMasterObjectType) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		// SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		StringBuilder sbMasterParts = new StringBuilder();
		StringBuilder sbMasterID = new StringBuilder();
		StringBuilder sbMasterType = new StringBuilder();
		StringBuilder sbArtworkPrimary = new StringBuilder();
		// SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		StringValidatorUtil validator = new StringValidatorUtil();

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		//String[] aCompany = sUserCompanies.split(",");
		String[] aCompany = splitCompanyValues(context,sUserCompanies);
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = getUserType();
		//SPEC: <10.05.2021>: Bala Added for External Requirement 33248 Dev 18x.6.0.1-- START
		if (isModificatinRequired()) {
			//sWhere = "current==Release";
			//Modified By Jwala for Defect 50651 - START
			sWhere = "current==" + ConstantsUtil.RELEASE + " || current=="
					+ ConstantsUtil.STR_CAP_RELEASED; 
		}else {
			sWhere = "current!=Obsolete";
		}
		//SPEC: <10.05.2021>: Bala Added for External Requirement 33248 Dev 18x.6.0.1-- END
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		StringList slRelSelects = new StringList();
		slRelSelects.addElement(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY);
		MapList mapList;
		//SPEC: <02.08.2022>: Guna Added for 48041 Defect   Dev 22x    -- START
		slPartSpecSelects.remove(ConstantsUtil.OWNERSHIP);
		//SPEC: <02.08.2022>: Guna Added for 48041 Defect   Dev 22x    -- END
		try {
			//DomainObject doAPP = new DomainObject(sObjectID);
			DomainObject doAPP = DomainObject.newInstance(context, sObjectID);

			mapList = doAPP.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION + "," + ConstantsUtil.REL_PG_INHERITED_CAD_SPEC,
					DomainConstants.QUERY_WILDCARD, slPartSpecSelects, slRelSelects, false, true, (short) 1, sWhere,
					DomainConstants.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			BusObjectAttribUtil busutil = new BusObjectAttribUtil();
			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator
						.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String sIpClass = validator
						.getStringEquivalentForStringList((mpEachObj.get(ConstantsUtil.STR_IPCLASS)));
				// SPEC: 11.25.2020: Added for Defect :37572 ## --START
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				// SPEC: 11.25.2020: Added for Defect :37572 ## --START
				String sArtworkPrimary = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY));

				String strTitle = validator
						.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

				if (strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
					String strPhysicalProdTitle = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
					strTitle = strPhysicalProdTitle;

				}

				String strState = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				strState = strState.replace(ConstantsUtil.STR_CAP_RELEASED, ConstantsUtil.RELEASED);

				String strSource = getSource(context, strId);
				String strSubType = UpdateSpecSubType(context, strId);

				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)) {
					strId_Result = ConstantsUtil.NO_ACCESS;
				}

				if((strType.equals(ConstantsUtil.TYPE_ARTIOSCADCOMPONENT) && isModificatinRequired()))
				{
					showData = checkHasAccess(context, sUserType, sObjectID);
				}else {
					showData = checkHasAccess(context, sUserType, strId);	
				}
				boolean 	bMastershowData = checkHasAccess(context, sUserType, sMasterObjectId);
				if(!showData && isModificatinRequired()){
					continue;
				}

				if(!bMastershowData){
					sMasterObjectId=ConstantsUtil.NO_ACCESS;
					// SPEC: Jwala Added for Defect : 42699 -- START
					sMasterObjectName = ConstantsUtil.NO_ACCESS;
					// SPEC: Jwala Added for Defect : 42699 -- END
				}
				sbMasterID.append(sMasterObjectId).append(ConstantsUtil.SYMBL_PIPE);


				if (showData) {
					sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);

					sbMasterParts.append(sMasterObjectName).append(ConstantsUtil.SYMBL_PIPE);
					sbMasterType.append(sMasterObjectType).append(ConstantsUtil.SYMBL_PIPE);
					sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);

					sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
					
					sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
					
					sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
					String strOrig = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
					sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
				} else {
					sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);

					sbMasterParts.append(sMasterObjectName).append(ConstantsUtil.SYMBL_PIPE);
					
					sbMasterType.append(sMasterObjectType).append(ConstantsUtil.SYMBL_PIPE);
					sbArtworkPrimary.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

				}
				// Added by Ganesh for security implementation stop

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			// SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			mpFinalList.put(ConstantsUtil.MASTERPARTNAME, sbMasterParts.toString());
			mpFinalList.put(ConstantsUtil.MASTERID, sbMasterID.toString());
			mpFinalList.put(ConstantsUtil.MASTERPARTTYPE, sbMasterType.toString());
			mpFinalList.put(ConstantsUtil.ARTWORKPRIMARY, sbArtworkPrimary.toString());
			// SPEC: 10/09/2020: Added for 18x.5 DEV -- END

		} catch (FrameworkException e) {
			LOGGER.error("Exception in BusObjectAttribUtil getMasterPartSpecifications: " + e);
			return new HashMap();
		}
		return filterMapList(mpFinalList);
	}

	/**
	 * This Method is for getting the Vendor Views
	 * 
	 * @param context
	 * @param user
	 * @param vendorId
	 * @param view
	 * @return
	 * @throws Exception
	 */

	//public MapList getVendorViews(Context context, String user, String vendorId, String view) throws Exception {
	public MapList getVendorViews(Context context, String user, String vendorId, String view, String uName) throws Exception {
		MapList relatedSpecMaplist = null;
		MapList mlFilteredSpec = new MapList(1);
		MapList mlRelatedEBPMaplist = null;
		boolean isContextPush = false;
		long startTime = System.currentTimeMillis();
		try {
			String personId = PersonUtil.getPersonObjectID(context, user);
			DomainObject domainObjEBP = null;
			DomainObject domainObj = null;
			Map mapProductData = null;

			String strTypesAllowed = ConstantsUtil.ALLOWED_TYPES;
			StringList strlObjSelectListEBP = new StringList(3);
			strlObjSelectListEBP.add(DomainConstants.SELECT_NAME);
			strlObjSelectListEBP.add(DomainConstants.SELECT_ID);
			strlObjSelectListEBP.add(DomainConstants.SELECT_CURRENT);

			StringList strlObjSelectListSpec = new StringList(5);
			strlObjSelectListSpec.add(DomainConstants.SELECT_ID);
			strlObjSelectListSpec.add(DomainConstants.SELECT_NAME);
			strlObjSelectListSpec.add(DomainConstants.SELECT_CURRENT);
			strlObjSelectListSpec.add(DomainConstants.SELECT_TYPE);
			strlObjSelectListSpec.add(DomainConstants.SELECT_POLICY);

			StringList slPartSelects = new StringList(9);
			slPartSelects.add(ConstantsUtil.SELECT_NAME);
			slPartSelects.add(ConstantsUtil.SELECT_ID);
			slPartSelects.add(ConstantsUtil.SELECT_TYPE);
			slPartSelects.add(ConstantsUtil.SELECT_POLICY);
			slPartSelects.add(DomainConstants.SELECT_CURRENT);
			slPartSelects.add(ConstantsUtil.SELECT_REVISION);
			slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP);
			slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION);
			slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
			slPartSelects.add(ConstantsUtil.OWNERSHIP);
			slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS);

			slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
			slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);

			mlRelatedEBPMaplist = new MapList();
			relatedSpecMaplist = new MapList();
			Map hmRelatedEBP = new HashMap();

			if (vendorId == null || "".equals(vendorId) || "null".equals(vendorId)) {
				String sPreSelectedVendorId = MqlUtil.mqlCommand(context,
						"print person " + context.getUser() + " select property[SITE].value");
				if (UIUtil.isNotNullAndNotEmpty(sPreSelectedVendorId) && sPreSelectedVendorId.indexOf("=") != -1) {
					sPreSelectedVendorId = sPreSelectedVendorId.substring(sPreSelectedVendorId.indexOf("=") + 1,
							sPreSelectedVendorId.length());
					sPreSelectedVendorId = sPreSelectedVendorId.trim();
					if (!"null".equals(sPreSelectedVendorId) && null != sPreSelectedVendorId
							&& !"".equals(sPreSelectedVendorId)) {
						vendorId = sPreSelectedVendorId;
						view = ConstantsUtil.PENDING;
						domainObjEBP = DomainObject.newInstance(context, vendorId);
					}
				} else {
					domainObj = DomainObject.newInstance(context, personId);
					mlRelatedEBPMaplist = domainObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_MEMBER,
							ConstantsUtil.TYPE_COMPANY + "," + ConstantsUtil.TYPE_PLANT, strlObjSelectListSpec, null,
							true, false, (short) 1, null, "");
					if (null != mlRelatedEBPMaplist && !mlRelatedEBPMaplist.isEmpty()) {
						Map map = null;
						for (Object object : mlRelatedEBPMaplist) {
							map = (Map) object;
							if ("Active".equalsIgnoreCase((String) map.get(DomainConstants.SELECT_CURRENT))) {
								vendorId = (String) map.get(DomainConstants.SELECT_ID);
								view = ConstantsUtil.PENDING;
								domainObjEBP = DomainObject.newInstance(context, vendorId);
								break;
							}
						}
					}
				}
			} else {
				domainObjEBP = DomainObject.newInstance(context, vendorId);
			}
			if (ConstantsUtil.ARCHIVED.equals(view)) {
				ContextUtil.pushContext(context, "User Agent", "", "");
				isContextPush = true;
			}
			//SPEC: 09-23-2021: Modified for 18x.6.0.1x for Defects# 45038,45039 by Sanjeeva -- START
			//SPEC: 05-21-2021: Modified for 18x.6.0.1 for Defect# 43441 by Sanjeeva -- START
			//ContextUtil.pushContext(context, uName, "", "");
			//isContextPush = true;
			//SPEC: 05-21-2021: Modified for 18x.6.0.1 for Defect# 43441 by Sanjeeva -- END
			//SPEC: 09-23-2021: Modified for 18x.6.0.1x for Defects# 45038,45039 by Sanjeeva -- END

			//SPEC: 05-21-2021: Modified for 18x.6.0.1 Internal Defect on Vendor Service by Sanjeeva -- START
			/*if (ConstantsUtil.PENDING.equals(view) || ConstantsUtil.ACCEPTED.equals(view)
					|| ConstantsUtil.REJECTED.equals(view) || ConstantsUtil.SPECIFICATION.equals(view)
					|| ConstantsUtil.ARCHIVED.equals(view)) {*/
			if (ConstantsUtil.PENDING.equalsIgnoreCase(view) || ConstantsUtil.ACCEPTED.equalsIgnoreCase(view)
					|| ConstantsUtil.REJECTED.equalsIgnoreCase(view) || ConstantsUtil.SPECIFICATION.equalsIgnoreCase(view)
					|| ConstantsUtil.ARCHIVED.equalsIgnoreCase(view)) {
				String strObjectWhereClause = ConstantsUtil.EMPTY_STRING;
				if (ConstantsUtil.PENDING.equalsIgnoreCase(view) || ConstantsUtil.ACCEPTED.equalsIgnoreCase(view)
						|| ConstantsUtil.REJECTED.equalsIgnoreCase(view)) {
					strObjectWhereClause = "current=='" + view + "' || current==" + ConstantsUtil.STATE_RELEASE;
				} else if (ConstantsUtil.SPECIFICATION.equalsIgnoreCase(view)) {
					strObjectWhereClause = "current==" + ConstantsUtil.PENDING + " || current=="
							+ ConstantsUtil.ACCEPTED + "|| current==" + ConstantsUtil.REJECTED + " || current=="
							+ ConstantsUtil.STATE_RELEASE;
				} else if (ConstantsUtil.ARCHIVED.equalsIgnoreCase(view)) {
					strObjectWhereClause = "current==" + ConstantsUtil.PENDING + " || current=="
							+ ConstantsUtil.ACCEPTED + " || current==" + ConstantsUtil.REJECTED + " || current=="
							+ ConstantsUtil.STATE_OBSOLETE;
				}
				//SPEC: 05-21-2021: Modified for 18x.6.0.1 Internal Defect on Vendor Service by Sanjeeva -- END
				mlRelatedEBPMaplist = domainObjEBP.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_PGPLANTORSUPPLIERTOSUMMARY + ","
								+ ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA,
								ConstantsUtil.TYPE_PGEBPSUMMARY + "," + strTypesAllowed, slPartSelects, null, false, true,
								(short) 2, strObjectWhereClause, "");
				if (null == mlRelatedEBPMaplist) {
					mlRelatedEBPMaplist = new MapList();
				}

				boolean isValidEBPObject = false;
				String strEBPObjectState = ConstantsUtil.EMPTY_STRING;
				for (Object object : mlRelatedEBPMaplist) {
					hmRelatedEBP = (Map) object;
					Map suparMap = null;
					String strLevel = (String) hmRelatedEBP.get(ConstantsUtil.LEVEL);
					if (strLevel.equals("1")) {
						isValidEBPObject = false;
						strEBPObjectState = "";
					}

					if (ConstantsUtil.PENDING.equals(view)) {
						if (strLevel.equals("1") && ConstantsUtil.PENDING
								.equalsIgnoreCase((String) hmRelatedEBP.get(DomainConstants.SELECT_CURRENT))) {
							isValidEBPObject = true;
							strEBPObjectState = ConstantsUtil.PENDING;
						} else if (strLevel.equals("2") && isValidEBPObject) {
							if (!ConstantsUtil.STATE_OBSOLETE
									.equalsIgnoreCase((String) hmRelatedEBP.get(DomainConstants.SELECT_CURRENT))) {
								suparMap = new HashMap();
								suparMap = hmRelatedEBP;
								suparMap.put(ConstantsUtil.CURRENT_STATUS, strEBPObjectState);
								relatedSpecMaplist.add(suparMap);
							}
						}
					} else if (ConstantsUtil.ACCEPTED.equals(view)) {
						if (strLevel.equals("1") && ConstantsUtil.ACCEPTED
								.equalsIgnoreCase((String) hmRelatedEBP.get(DomainConstants.SELECT_CURRENT))) {
							isValidEBPObject = true;
							strEBPObjectState = ConstantsUtil.ACCEPTED;
						} else if (strLevel.equals("2") && isValidEBPObject) {
							if (!ConstantsUtil.STATE_OBSOLETE
									.equalsIgnoreCase((String) hmRelatedEBP.get(DomainConstants.SELECT_CURRENT))) {
								suparMap = new HashMap();
								suparMap = hmRelatedEBP;
								suparMap.put(ConstantsUtil.CURRENT_STATUS, strEBPObjectState);
								relatedSpecMaplist.add(suparMap);
							}
						}
					} else if (ConstantsUtil.REJECTED.equals(view)) {
						if (strLevel.equals("1") && ConstantsUtil.REJECTED
								.equalsIgnoreCase((String) hmRelatedEBP.get(DomainConstants.SELECT_CURRENT))) {
							isValidEBPObject = true;
							strEBPObjectState = ConstantsUtil.REJECTED;
						} else if (strLevel.equals("2") && isValidEBPObject) {
							if (!ConstantsUtil.STATE_OBSOLETE
									.equalsIgnoreCase((String) hmRelatedEBP.get(DomainConstants.SELECT_CURRENT))) {
								suparMap = new HashMap();
								suparMap = hmRelatedEBP;
								suparMap.put(ConstantsUtil.CURRENT_STATUS, strEBPObjectState);
								relatedSpecMaplist.add(suparMap);
							}
						}
					} else if (ConstantsUtil.SPECIFICATION.equals(view)) {
						if (strLevel.equals("1")) {
							isValidEBPObject = true;
							strEBPObjectState = (String) hmRelatedEBP.get(DomainConstants.SELECT_CURRENT);
						} else if (strLevel.equals("2") && isValidEBPObject) {
							if (!ConstantsUtil.STATE_OBSOLETE
									.equalsIgnoreCase((String) hmRelatedEBP.get(DomainConstants.SELECT_CURRENT))) {
								suparMap = new HashMap();
								suparMap = hmRelatedEBP;
								suparMap.put(ConstantsUtil.CURRENT_STATUS, strEBPObjectState);
								relatedSpecMaplist.add(suparMap);
							}
						}
					} else if (ConstantsUtil.ARCHIVED.equals(view)) {
						if (strLevel.equals("1")) {
							isValidEBPObject = true;
							strEBPObjectState = ConstantsUtil.STATE_OBSOLETE;
						} else if (strLevel.equals("2") && isValidEBPObject && ConstantsUtil.STATE_OBSOLETE
								.equalsIgnoreCase((String) hmRelatedEBP.get(DomainConstants.SELECT_CURRENT))) {
							suparMap = new HashMap();
							suparMap = hmRelatedEBP;
							suparMap.put(ConstantsUtil.CURRENT_STATUS, strEBPObjectState);
							relatedSpecMaplist.add(suparMap);
						}
					}
				}
			}
			String strPolicy = null;
			String strEbpAllowedPolicy = ConstantsUtil.ALLOWED_POLICIES;
			for (Object object : relatedSpecMaplist) {
				mapProductData = (Map) object;
				strPolicy = (String) mapProductData.get(DomainConstants.SELECT_POLICY);
				if (strEbpAllowedPolicy.contains(strPolicy)) {
					mlFilteredSpec.add(mapProductData);
				}
			}
			if (isContextPush) {
				ContextUtil.popContext(context);
				isContextPush = false;
			}
			long endTime = System.currentTimeMillis();
		} catch (Exception e) {
			LOGGER.error(
					"Exception occured while processing the EBP views data in program : BusObjectAttribUtil : getVendorViews -->"
							+ e.getMessage());
		} finally {
			if (isContextPush) {
				ContextUtil.popContext(context);
				isContextPush = false;
			}
		}
		return mlFilteredSpec;
	}


	/**
	 * This method is to validate Ownership for EBP and License Check for
	 * Internal Users
	 * 
	 * @param context
	 * @param mpData
	 * @return map
	 */

	public Map verifyOwnership(Context context, Map mpData) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpTemp = new HashMap();

		/*
		 * StringList slSelects = new StringList();
		 * slSelects.add(ConstantsUtil.OWNERSHIP);
		 * 
		 * 
		 * StringList slIPClassSelects = new StringList();
		 * slSelects.add(ConstantsUtil.STR_IPCLASS);
		 * 
		 * boolean bHasOwnerShip = false;
		 */
		StringList sbFinalIndex = new StringList();

		StringList slFinalId = new StringList();

		/*
		 * SecurityService ss = new SecurityService(); String sUserCompanies =
		 * ss.getUserCauthorities(); String[] aCompany =
		 * sUserCompanies.split(","); StringBuilder sbCompany = new
		 * StringBuilder();
		 * 
		 * StringList slUserOwnership = filterOwnerShip(sUserCompanies);
		 * 
		 * String sUserlicense = ss.getUserLicense();
		 * 
		 * if (aCompany.length > -1) { for (int i = 0; i < aCompany.length; i++)
		 * { if (null != aCompany[i]) { String Company = aCompany[i].toString();
		 * sbCompany.append(Company.trim().replace(" Plant", "")).append("|"); }
		 * } }
		 * 
		 * StringList slHIRTypes = new StringList();
		 * slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		 * slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		 * slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		 * slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		 * slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		 */

		try {
			// Map mpStringListData = getStringListMap(mpData);

			// StringList slID = validator.isNotNullOrEmpty((StringList)
			// mpStringListData.get(ConstantsUtil.ID));
			// StringList sltype = validator.isNotNullOrEmpty((StringList)
			// mpStringListData.get(ConstantsUtil.TYPE));

			StringList slID = new StringList();
			if (mpData.containsKey(ConstantsUtil.ID)) {
				slID = getStringList(validator.getStringEquivalentForString(mpData.get(ConstantsUtil.ID)));
			} else {
				return new HashMap();

			}
			// if(!sltype.contains(ConstantsUtil.TYPE_INTERNAL_MATERIAL) ||
			// !sltype.contains("Internal Material"))
			// {
			for (int i = 0; i < slID.size(); i++) {

				String sId = validator.isNotNullOrEmpty(slID.get(i)) ? slID.get(i) : ConstantsUtil.EMPTY_STRING;
				// Added by Bala for SR18x.5.2 Defect 38223 STARTS---
				if (UIUtil.isNotNullAndNotEmpty(sId)) {
					// Added by Bala for SR18x.5.2 Defect 38223 ENDS---
					//DomainObject dob = new DomainObject(sId);
					DomainObject dob = DomainObject.newInstance(context, sId);
					String sCurrent = dob.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					
					String sType = dob.getInfo(context, ConstantsUtil.SELECT_TYPE);
					dob.close(context);
					
					if (sType.equals(ConstantsUtil.TYPE_SOFTWAREBUILD)){
						boolean hasAccess = checkAccessForSoftwareBuild(context,  sId);
						//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- START
						if(isModificatinRequired() && !hasAccess) {
							//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43252 -- START
							//continue;
							sId = ConstantsUtil.NO_ACCESS;
							//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43252 -- END

						}
						//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- END
						if (hasAccess) {
							sId = sId;
						} else {
							sId = ConstantsUtil.NO_ACCESS;
						}
					}
					else

						if (sType.equals(ConstantsUtil.TYPE_SUBSTANCE) || sType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL)) {
							if (!sCurrent.equals(ConstantsUtil.RELEASE) && !sCurrent.equals(ConstantsUtil.RELEASED) && !sCurrent.equals(ConstantsUtil.APPROVED) && !sCurrent.equals("Active")) {
								//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43108 on Date 21/05/2021 --END	
								sId = ConstantsUtil.NO_ACCESS;
							}else{
								boolean hasAccess = checkAccessForIMorMCP(context,  sId);
								if(isModificatinRequired() && !hasAccess) {
									if (!sType.equals(ConstantsUtil.TYPE_SUBSTANCE))
										
										sId = ConstantsUtil.NO_ACCESS;
								}
								if (hasAccess) {
									sId = sId;
								} else {
									sId = ConstantsUtil.NO_ACCESS;
								}
							}
							sId = sId;
						} 
						else if(sType.equals(ConstantsUtilIRM.TYPE_EXTERNAL_MATERIAL) && sCurrent.equals("Active"))
						{
							sId = sId;
						}
						else {

							if (!sCurrent.equals(ConstantsUtil.RELEASE) && !sCurrent.equals(ConstantsUtil.RELEASED)) {
								//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- START
								if(isModificatinRequired()) {
									//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43252 -- START	
									//continue;
									sId = ConstantsUtil.NO_ACCESS;
									//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43252 -- END	
								}
								//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- END
								sId = ConstantsUtil.NO_ACCESS;
							} else {
								boolean hasAccess = checkHasAccess(context, null, sId);
								//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- START
								if(isModificatinRequired() && !hasAccess) {
									//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43252 -- START
									//continue;
									sId = ConstantsUtil.NO_ACCESS;
									//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43252 -- END
								}
								//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- END
								if (hasAccess) {
									sId = sId;
								} else {
									sId = ConstantsUtil.NO_ACCESS;
								}
							}
						}
					// modified by Ganesh ---->end
					slFinalId.add(sId);

				}

				mpData.put(ConstantsUtil.ID, replaceSquareBrackets(slFinalId.toString()));
				
			}
			// Added by Bala for SR18x.5.2 Defect 38223 ENDS---
			return filterMapList(mpData);
		} catch (Exception e) {

			LOGGER.error("Error from BusObjectAttribUtil :  verifyOwnership : " + e);
			return new HashMap();
		}
	}


	/**
	 * This method is to validate security Ownership for ACS column sections 
	 * Internal Users - Security
	 * 
	 * @param context
	 * @param mpData, sParamType
	 * @return map
	 */

	public Map verifyOwnership(Context context, Map mpData, String sParamType) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpTemp = new HashMap();
		StringList sbFinalIndex = new StringList();
		StringList slFinalId = new StringList();		
		//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
		StringList slFinalState = new StringList();
		StringList slFinalTitle = new StringList();
		//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END

		try {			
			StringList slID = new StringList();			
			//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
			StringList slTitle = new StringList();
			StringList slState = new StringList();
			//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END

			if (mpData.containsKey(ConstantsUtil.ID)) {
				slID = getStringList(validator.getStringEquivalentForString(mpData.get(ConstantsUtil.ID)));				
				//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
				slTitle = getStringList(validator.getStringEquivalentForString(mpData.get(ConstantsUtil.TITLE)));
				slState = getStringList(validator.getStringEquivalentForString(mpData.get(ConstantsUtil.STATE)));
				//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END
			} else {
				return new HashMap();
			}
			for (int i = 0; i < slID.size(); i++) {

				String sId = validator.isNotNullOrEmpty(slID.get(i)) ? slID.get(i) : ConstantsUtil.EMPTY_STRING;

				//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
				String sTitle = validator.isNotNullOrEmpty(slTitle.get(i)) ? slTitle.get(i) : ConstantsUtil.EMPTY_STRING;
				String sState = validator.isNotNullOrEmpty(slState.get(i)) ? slState.get(i) : ConstantsUtil.EMPTY_STRING;
				//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END

				if (UIUtil.isNotNullAndNotEmpty(sId)) {
					//DomainObject dob = new DomainObject(sId);
					DomainObject dob = DomainObject.newInstance(context, sId);
					String sCurrent = dob.getInfo(context, ConstantsUtil.SELECT_CURRENT);					
					String sType = dob.getInfo(context, ConstantsUtil.SELECT_TYPE);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					dob.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					if (sType.equals(ConstantsUtil.TYPE_SUBSTANCE) || sType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL)) 
					{
						sId = sId;

						//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
						sTitle = sTitle;
						sState = sState;
						//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END
					} else {
						if (!sCurrent.equals(ConstantsUtil.RELEASE) && !sCurrent.equals(ConstantsUtil.RELEASED)) {
							sId = ConstantsUtil.NO_ACCESS;

							//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
							sTitle = ConstantsUtil.NO_ACCESS;
							sState = ConstantsUtil.NO_ACCESS;
							//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END
						} else {
							boolean hasAccess = checkHasAccess(context, null, sId);

							if (hasAccess) {
								sId = sId;								
								//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
								sTitle = sTitle;
								sState = sState;
								//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END
							} else {
								sId = ConstantsUtil.NO_ACCESS;

								//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
								sTitle = ConstantsUtil.NO_ACCESS;
								sState = ConstantsUtil.NO_ACCESS;
								//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END
							}
						}
					}
					slFinalId.add(sId);					
					//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
					slFinalTitle.add(sTitle);
					slFinalState.add(sState);
					//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END

					/*
					 * boolean bHasOwnership =false; // For EBP if
					 * (isModificatinRequired()) { String sFormulaPropagate
					 * =slID.get(i); if (sType.equalsIgnoreCase(ConstantsUtil.
					 * TYPE_FORMULATIONPART)) { sFormulaPropagate =
					 * getFormulaPropagate(context, sFormulaPropagate); }
					 * 
					 * if (!sFormulaPropagate.isEmpty()) { bHasOwnership =
					 * checkOwnerShip(context, slUserOwnership,
					 * sFormulaPropagate); } if (!bHasOwnerShip)
					 * sbFinalIndex.add(String.valueOf(i)); } // For Interanl
					 * Users else { boolean showData = true; if
					 * (slHIRTypes.contains(sType)) { String sFormulaClassif =
					 * slID.get(i); if (!ss.isExternalUser()) { if
					 * (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
					 * sFormulaClassif =
					 * getFormulaPropagateClassification(context,
					 * sFormulaClassif); } if (null != sUserlicense && null !=
					 * sFormulaClassif &&
					 * !sUserlicense.contains(sFormulaClassif)) { showData =
					 * false; } } if (!showData)
					 * sbFinalIndex.add(String.valueOf(i));
					 * 
					 * } }
					 */
					// }

				}

				mpData.put(ConstantsUtil.ID, replaceSquareBrackets(slFinalId.toString()));

				//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- START
				mpData.put(ConstantsUtil.TITLE, replaceSquareBrackets(slFinalTitle.toString()));
				mpData.put(ConstantsUtil.STATE, replaceSquareBrackets(slFinalState.toString()));
				//SPEC: Release SR18x.5.2 - Added for Defect 38679  by Amman -- END				
			}
			return filterMapList(mpData);
		} catch (Exception e) {

			LOGGER.error("Error from BusObjectAttribUtil :  verifyOwnership : " + e);
			return new HashMap();
		}
	}

	/**
	 * For Parsing the data from String to StringList
	 * 
	 * @param mpData
	 * @return
	 */
	private Map<String, StringList> getStringListMap(Map<String, String> mpData) {
		Map mpTemp = new HashMap();

		StringValidatorUtil validator = new StringValidatorUtil();
		for (Map.Entry<String, String> entry : mpData.entrySet()) {
			String sKey = entry.getKey();
			String sval = entry.getValue();
			if (!ConstantsUtil.OWNERSHIP.equals(sKey)) {
				StringList slValue = getStringList(sval);
				mpTemp.put(sKey, slValue);
			}

		}
		return mpTemp;
	}

	/**
	 * Get Formulation Substitutes
	 * 
	 * @param context
	 * @param partId
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getFormulationSubstituteDetails(Context context, String partId) throws Exception {
		BusObjectAttribUtil utill = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpProces = new TreeMap();

		String sPId = ConstantsUtil.EMPTY_STRING;
		String sPType = ConstantsUtil.EMPTY_STRING;
		String sPName = ConstantsUtil.EMPTY_STRING;
		String sPtitle = ConstantsUtil.EMPTY_STRING;
		String sPMin = ConstantsUtil.EMPTY_STRING;
		String sPMax = ConstantsUtil.EMPTY_STRING;
		String sPWet = ConstantsUtil.EMPTY_STRING;
		String strWW = ConstantsUtil.EMPTY_STRING;
		String sPMinWet = ConstantsUtil.EMPTY_STRING;
		String sPMaxWet = ConstantsUtil.EMPTY_STRING;
		String sPTargetWet = ConstantsUtil.EMPTY_STRING;
		String sPDiff = ConstantsUtil.EMPTY_STRING;
		String sPDate = ConstantsUtil.EMPTY_STRING;
		String sPProcessNotes = ConstantsUtil.EMPTY_STRING;
		String sCertficate = ConstantsUtil.EMPTY_STRING;

		try {
			//DomainObject domObj = new DomainObject(partId);
			DomainObject domObj = DomainObject.newInstance(context, partId);
			String objName = (String) domObj.getInfo(context, ConstantsUtil.SELECT_NAME);
			StringList relsel = new StringList();

			relsel.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ID);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_TO_ID);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_TO_TYPE);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INST);

			StringList strObjList = new StringList(6);
			strObjList.add(DomainConstants.SELECT_ID);
			strObjList.add(DomainConstants.SELECT_TYPE);
			strObjList.add(DomainConstants.SELECT_NAME);
			strObjList.add(DomainConstants.SELECT_REVISION);

			MapList substituteList = domObj.getRelatedObjects(context, ConstantsUtil.REL_FBOM,
					ConstantsUtil.TYPE_RAWMATERIALPART.concat(",").concat(ConstantsUtil.TYPE_FORMULATIONPHASE)
					.concat(",").concat(ConstantsUtil.TYPE_FORMULATIONPART).concat(",")
					.concat(ConstantsUtil.TYPE_PGRAWMATERIAL).concat(",")
					.concat(ConstantsUtil.TYPE_PGMASTERRAWMATERIAL).concat(",")
					.concat(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART),
					strObjList, relsel, false, true, (short) 0, "", "", 0);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domObj.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator itr1 = substituteList.iterator();
			MapList ll = new MapList();
			int i = 0;
			while (itr1.hasNext()) {
				StringBuilder sbTitle = new StringBuilder();
				StringBuilder sbPName = new StringBuilder();
				StringBuilder sbPId = new StringBuilder();
				StringBuilder sbPType = new StringBuilder();
				StringBuilder sbPRev = new StringBuilder();
				StringBuilder sbPCurrent = new StringBuilder();
				StringBuilder sbPDescription = new StringBuilder();
				StringBuilder sbPMin = new StringBuilder();
				StringBuilder sbPMax = new StringBuilder();
				StringBuilder sbPWet = new StringBuilder();

				StringBuilder sbPMinWt = new StringBuilder();
				StringBuilder sbPMaxWt = new StringBuilder();
				StringBuilder sbPWetWt = new StringBuilder();
				StringBuilder sbPDiff = new StringBuilder();
				StringBuilder sbPDate = new StringBuilder();
				StringBuilder sbPProces = new StringBuilder();
				StringBuilder sbPCert = new StringBuilder();

				StringBuilder sbFName = new StringBuilder();
				StringBuilder sbFId = new StringBuilder();
				StringBuilder sbFType = new StringBuilder();

				StringBuilder sbFTitle = new StringBuilder();
				StringBuilder sbFWetWt = new StringBuilder();

				StringBuilder sbHeader = new StringBuilder();
				StringBuilder sbInst = new StringBuilder();
				StringBuilder sbDec = new StringBuilder();

				int integerPlaces = ConstantsUtil.ZERO_LEVEL;
				int decimalPlaces = ConstantsUtil.ZERO_LEVEL;
				DecimalFormat decimalformatter = new DecimalFormat(ConstantsUtil.PATTERN_DECIMALFORMAT);

				Map<String, String> mpSubstitutes = new HashMap<String, String>();

				Map relmap = (Map) itr1.next();
				String sobjType = (String) relmap.get(DomainConstants.SELECT_TYPE);
				if (sobjType.equals(ConstantsUtil.TYPE_PGRAWMATERIAL)
						|| sobjType.equals(ConstantsUtil.TYPE_RAWMATERIALPART)
						|| mxType.isOfParentType(context, sobjType, ConstantsUtil.TYPE_FORMULATIONPART)
						|| mxType.isOfParentType(context, sobjType, ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART)
						|| sobjType.equals(ConstantsUtil.TYPE_PGMASTERRAWMATERIAL)) {

					String strsubsPartId = validator.getStringEquivalentForStringList(
							(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_TO_ID)));

					String strsubsDesc = validator.getStringEquivalentForStringList(
							(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC)));
					String strsubsInst = validator.getStringEquivalentForStringList(
							(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INST)));

					sbHeader.append(strsubsDesc).append(ConstantsUtil.SYMBL_PIPE);
					sbInst.append(strsubsDesc).append(ConstantsUtil.SYMBL_PIPE);
					sbDec.append(strsubsInst).append(ConstantsUtil.SYMBL_PIPE);

					String subsType = validator.getStringEquivalentForStringList(
							(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_TO_TYPE)));

					String sOID[] = { strsubsPartId };
					//DomainObject subsObj = new DomainObject(strsubsPartId);
					DomainObject subsObj = DomainObject.newInstance(context, strsubsPartId);
					if (subsType.equals(ConstantsUtil.TYPE_PARENTSUB)) {
						MapList mlSubstitutes = subsObj.getRelatedObjects(context, ConstantsUtil.REL_FBOM,
								DomainConstants.QUERY_WILDCARD, getSubstituteBusSelects(), getSubstituteRelSelects(),
								false, true, (short) 1, null, null, 0);

						Iterator itrSubstitutes = mlSubstitutes.iterator();

						while (itrSubstitutes.hasNext()) {

							Map mpSubstituteFor = (Map) itrSubstitutes.next();
							sPId = validator.getStringEquivalentForStringList(mpSubstituteFor.get(ConstantsUtil.ID));
							sPType = validator
									.getStringEquivalentForStringList(mpSubstituteFor.get(ConstantsUtil.TYPE));
							sPName = validator
									.getStringEquivalentForStringList(mpSubstituteFor.get(ConstantsUtil.NAME));
							sPtitle = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sPMin = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.ATTRIBUTE_MIN_INPUT));
							sPMax = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.ATTRIBUTE_MAX_INPUT));
							sPWet = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE));
							strWW = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE));
							sPTargetWet = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT));
							sPMinWet = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT));
							sPMaxWet = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT));
							sPDiff = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_ADJUSTMENT_VALUE));
							sPDate = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.ATTRIBUTE_VALID_DATE));
							sPProcessNotes = validator.getStringEquivalentForStringList(
									mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE_VALUE));

							formatData(sbPName, sPName);
							formatData(sbPType, mapType(sPType));
							formatData(sbPId, sPId);
							formatData(sbPDescription, sPtitle);

							formatData(sbPMin, sPMin);
							formatData(sbPMax, sPMax);
							formatData(sbPWet, sPWet);

							formatData(sbPMinWt, sPMinWet);
							formatData(sbPMaxWt, sPMaxWet);
							formatData(sbPWetWt, sPTargetWet);

							formatData(sbPDiff, sPDiff);
							formatData(sbPDate, sPDate);
							formatData(sbPProces, sPProcessNotes);
							formatData(sbPCert, sCertficate);

						}

						MapList mlSubPartsFor = subsObj.getInfo(context, sOID, objectSelects());

						Iterator itrSubPartsFor = mlSubPartsFor.iterator();
						while (itrSubPartsFor.hasNext()) {
							Map mpSubstitutePart = (Map) itrSubPartsFor.next();
							sPId = validator.getStringEquivalentForStringList(
									mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_ID));
							sPType = validator.getStringEquivalentForStringList(
									mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_TYPE));
							sPName = validator.getStringEquivalentForStringList(
									mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_NAME));
							sPtitle = validator.getStringEquivalentForStringList(
									mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_TITLE));
							sPMin = validator.getStringEquivalentForStringList(mpSubstitutePart
									.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MIN_ACTUAL_PERCENT));
							sPMax = validator.getStringEquivalentForStringList(mpSubstitutePart
									.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MAX_ACTUAL_PERCENT));
							sPWet = validator.getStringEquivalentForStringList(mpSubstitutePart
									.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_QUANTITY));

							sPTargetWet = validator.getStringEquivalentForStringList(mpSubstitutePart
									.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_TARGET_WEIGHT));
							sPMinWet = validator.getStringEquivalentForStringList(mpSubstitutePart
									.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MIN_ACTUAL_PERCENT));
							sPMaxWet = validator.getStringEquivalentForStringList(mpSubstitutePart
									.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MAX_ACTUAL_PERCENT));
							sPDiff = validator.getStringEquivalentForStringList(mpSubstitutePart
									.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_QUATITY_ADJUSTMENT));
							sPDate = validator.getStringEquivalentForStringList(mpSubstitutePart
									.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_VALID_DATE));
							sPProcessNotes = validator.getStringEquivalentForStringList(mpSubstitutePart
									.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_PROCESSING_NOTE));

							if (validator.isNotNullOrEmpty(sPDiff)) {
								integerPlaces = sPDiff.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
								decimalPlaces = sPDiff.length() - integerPlaces - 1;
								sPDiff = String.valueOf(decimalformatter.format(Double.parseDouble(sPDiff)));
							} else
								sPDiff = ConstantsUtil.EMPTY_STRING;

							formatData(sbPName, sPName);
							formatData(sbPType, mapType(sPType));
							formatData(sbPId, sPId);
							formatData(sbPDescription, sPtitle);

							formatData(sbPMin, sPMin);
							formatData(sbPMax, sPMax);
							formatData(sbPWet, sPWet);

							formatData(sbPMinWt, sPMinWet);
							formatData(sbPMaxWt, sPMaxWet);
							formatData(sbPWetWt, sPTargetWet);

							formatData(sbPDiff, sPDiff);
							formatData(sbPDate, sPDate);
							formatData(sbPProces, sPProcessNotes);
							formatData(sbPCert, sCertficate);

							formatData(sbFName, sPName);
							formatData(sbFType, mapType(sPType));
							formatData(sbFId, sPId);
							formatData(sbFTitle, sPtitle);
							formatData(sbFWetWt, strWW);
						}

						mpSubstitutes.put(ConstantsUtil.SP_ID, sbPId.toString());
						mpSubstitutes.put(ConstantsUtil.SP_TYPE, sbPType.toString());
						mpSubstitutes.put(ConstantsUtil.SP_NAME, sbPName.toString());
						mpSubstitutes.put(ConstantsUtil.SP_TITLE, sbPDescription.toString());
						mpSubstitutes.put(ConstantsUtil.MIN, sbPMin.toString());
						mpSubstitutes.put(ConstantsUtil.MAX, sbPMax.toString());
						mpSubstitutes.put(ConstantsUtil.SP_WET, sbPWet.toString());
						mpSubstitutes.put(ConstantsUtil.TWW, sbPWetWt.toString());
						mpSubstitutes.put(ConstantsUtil.WEM, sbPMaxWt.toString());
						mpSubstitutes.put(ConstantsUtil.WWM, sbPWetWt.toString());
						mpSubstitutes.put(ConstantsUtil.DIFF, sbPDiff.toString());
						mpSubstitutes.put(ConstantsUtil.DATE, sbPDate.toString());
						mpSubstitutes.put(ConstantsUtil.PROCESS, sbPProces.toString());
						mpSubstitutes.put(ConstantsUtil.CERT, sbPCert.toString());
						mpSubstitutes.put(ConstantsUtil.SF_TITLE, sbFTitle.toString());
						mpSubstitutes.put(ConstantsUtil.SF_ID, sbFId.toString());
						mpSubstitutes.put(ConstantsUtil.SF_TYPE, sbFType.toString());
						mpSubstitutes.put(ConstantsUtil.SF_NAME, sbFName.toString());
						mpSubstitutes.put(ConstantsUtil.SF_WET, sbFWetWt.toString());
						mpSubstitutes.put(ConstantsUtil.DESCRIPTION, strsubsInst.toString());
						mpSubstitutes.put(ConstantsUtil.INSTRUCTIONS, strsubsDesc.toString());

						mpProces.put(i, mpSubstitutes);
						i++;
					}

				}
			}
			return mpProces;
		} catch (Exception e) {
			LOGGER.error("Error from program BusObjectAttribUtil:  getSubstituteDetails" + e);
			return new HashMap();
		}
	}

	/**
	 * Substitute Selects
	 * 
	 * @return
	 */
	private StringList getSubstituteRelSelects() {

		StringList relSelects = new StringList();
		relSelects.add(ConstantsUtil.STR_FROM_ID);
		relSelects.add(DomainRelationship.SELECT_ID);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_ADJUSTMENT_VALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_NEEDS_UPDATE_VALUE);
		relSelects.add(ConstantsUtil.ATTRIBUTE_MIN_INPUT);
		relSelects.add(ConstantsUtil.ATTRIBUTE_MAX_INPUT);
		relSelects.add(ConstantsUtil.ATTRIBUTE_TARGET_WET_WEIGHT_INPUT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE_VALUE);
		relSelects.add(ConstantsUtil.ATTRIBUTE_PROCESS_NOTE_INPUT);

		return relSelects;
	}

	/**
	 * Bus Selects
	 * 
	 * @return
	 */

	private StringList objectSelects() {
		StringList objectSelects = new StringList();

		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_TYPE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_NAME);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_ID);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_TITLE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_MIN_WEIGHT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_QUANTITY);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_MAX_WEIGHT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_TARGET_WEIGHT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MIN_ACTUAL_PERCENT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MAX_ACTUAL_PERCENT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_QUATITY_ADJUSTMENT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_VALID_DATE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_PROCESSING_NOTE);

		return objectSelects;
	}

	/**
	 * Substitute Bus Selects
	 * 
	 * @return
	 */
	public StringList getSubstituteBusSelects() {

		StringList objectSelects = new StringList();

		objectSelects.add(ConstantsUtil.SELECT_NAME);
		objectSelects.add(ConstantsUtil.SELECT_ID);
		objectSelects.add(ConstantsUtil.SELECT_TYPE);
		objectSelects.add(ConstantsUtil.SELECT_REVISION);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET);

		return objectSelects;
	}

	/**
	 * Helper Method For Concating the strings
	 * 
	 * @param var0
	 * @return
	 */

	public static String strcat(Object... var0) {
		StringBuilder var1 = new StringBuilder();
		Object[] var2 = var0;
		int var3 = var0.length;

		for (int var4 = 0; var4 < var3; ++var4) {
			Object var5 = var2[var4];
			var1.append(var5 == null ? "null" : var5.toString());
		}

		return var1.toString();
	}

	/**
	 * Get the Master Substitutes Of : CUP,COP.IP
	 * 
	 * @param context
	 * @param ebomPgCustPartList
	 * @param slSelects
	 * @param slRelEBOMSelects
	 * @param type
	 * @return
	 */

	public Map getMasterCopCupIpBom(Context context, MapList ebomPgCustPartList, StringList slSelects,
			StringList slRelEBOMSelects, String type) {

		StringValidatorUtil validator = new StringValidatorUtil();
		FinishedProductPartBO fppBO = new FinishedProductPartBO();
		
		slRelEBOMSelects.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		slRelEBOMSelects.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		slRelEBOMSelects.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		
		
		Map<String, String> resultmap = new HashMap();
		try {
			String sMasterType = "";
			if (type.equalsIgnoreCase("cup")) {
				sMasterType = ConstantsUtil.TYPE_PG_MASTER_CUSTOMER_UNIT_PART;
			} else if (type.equalsIgnoreCase("cop")) {
				sMasterType = ConstantsUtil.TYPE_PG_MASTER_CONSUMER_UNIT_PART;
			} else if (type.equalsIgnoreCase("IP")) {
				sMasterType = ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART;
			} else {
				return new HashMap();
			}

			if (ebomPgCustPartList.size() > 0) {
				Iterator objectListItr = ebomPgCustPartList.iterator();
				MapList tempList = new MapList(); //SPEC: <28.02.2023>: Satyam Added for Defect 52053
				while (objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					String sType = (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE);
					if (sMasterType.equals(sType)) {

						String sId = (validator
								.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID)))
								? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID)
										: ConstantsUtil.EMPTY_STRING;
								if (null != sId) {
									//DomainObject doMaster = new DomainObject(sId);
									DomainObject doMaster = DomainObject.newInstance(context, sId);
									MapList mlMasterBom = doMaster.getRelatedObjects(context, DomainObject.RELATIONSHIP_EBOM, // Rel
											// Pattern
											DomainConstants.QUERY_WILDCARD, // Type
											// Pattern
											slSelects, // Object Select
											slRelEBOMSelects, // rel Select
											false, // get To
											true, // get From
											(short) 0, // recurse level
											DomainConstants.EMPTY_STRING, // where Clause
											null, // relationshipWhere Clause
											0);
									//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
									doMaster.close(context);
									//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
									if (mlMasterBom.size() > 0) {
										tempList.addAll(mlMasterBom); //SPEC: <28.02.2023>: Satyam Added for Defect 52053
									}
								}
					}
				}
				//SPEC: <28.02.2023>: Satyam Added for Defect 52053 -- START
				if(tempList.size() > 0) {
					MapList finalList = removeDuplicateMapList(tempList);
					resultmap = fppBO.parseBOMMaplist(context, finalList);
				}
				//SPEC: <28.02.2023>: Satyam Added for Defect 52053 -- END
			}

		} catch (Exception e) {
			LOGGER.error("Exception In BusObjectAttribUtil : getMasterCopCupIpBom: " + e);
			return new HashMap();
		}
		return resultmap;
	}

	/**
	 * Getting the Substitutes of
	 * 
	 * @param context
	 * @param ebomPgCustPartList
	 * @param slSelects
	 * @param slRelEBOMSelects
	 * @param type
	 * @return
	 */
	public Map getMasterCopCupIpSubstitutes(Context context, MapList ebomPgCustPartList, StringList slSelects,
			StringList slRelEBOMSelects, String type) {

		StringValidatorUtil validator = new StringValidatorUtil();
		FinishedProductPartBO fppBO = new FinishedProductPartBO();
		Map<String, String> resultmap = new HashMap();
		Map<String, String> resultmapFinal = new HashMap();
		try {
			String sMasterType = "";
			if (type.equalsIgnoreCase("cup")) {
				sMasterType = ConstantsUtil.TYPE_PG_MASTER_CUSTOMER_UNIT_PART;
			} else if (type.equalsIgnoreCase("cop")) {
				sMasterType = ConstantsUtil.TYPE_PG_MASTER_CONSUMER_UNIT_PART;
			} else if (type.equalsIgnoreCase("IP")) {
				sMasterType = ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART;
			} else {
				return new HashMap();
			}

			if (ebomPgCustPartList.size() > 0) {
				Iterator objectListItr = ebomPgCustPartList.iterator();
				while (objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					String sType = (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE);
					if (sMasterType.equals(sType)) {

						String sId = (validator
								.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID)))
								? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID)
										: ConstantsUtil.EMPTY_STRING;
								if (null != sId) {
									//DomainObject doMaster = new DomainObject(sId);
									DomainObject doMaster = DomainObject.newInstance(context, sId);
									MapList mlMasterBom = doMaster.getRelatedObjects(context, DomainObject.RELATIONSHIP_EBOM, // Rel
											// Pattern
											DomainConstants.QUERY_WILDCARD, // Type
											// Pattern
											slSelects, // Object Select
											slRelEBOMSelects, // rel Select
											false, // get To
											true, // get From
											(short) 1, // recurse level (Modified by Ketan for Defect no. 52855)
											DomainConstants.EMPTY_STRING, // where Clause
											null, // relationshipWhere Clause
											0);
									//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
									doMaster.close(context);
									//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
									if (mlMasterBom.size() > 0) {
										// resultmap =
										// getCOPCUPIPSubstitutes(context,mlMasterBom);
										CommonBusUtilBO commonBO = new CommonBusUtilBO();
										resultmap = commonBO.parseSubstitute(context, mlMasterBom);
										resultmapFinal.putAll(resultmap); //Added by Ketan for Defect no. 52855
									}
								}
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception In BusObjectAttribUtil : getMasterCopCupIpSubstitutes: " + e);
			return new HashMap();
		}
		return filterMapList(resultmapFinal);
	}

	/**
	 * Getting the Substitutes of COP,CUP,IP
	 * 
	 * @param context
	 * @param mapList
	 * @return
	 * @throws Exception
	 */

	public Map<String, String> getCOPCUPIPSubstitutes(Context context, MapList mapList) throws Exception {

		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		StringBuilder sbSubPartType = new StringBuilder();
		StringBuilder sbSubPartName = new StringBuilder();
		StringBuilder sbSubPartRev = new StringBuilder();
		StringBuilder sbSubPartId = new StringBuilder();
		StringBuilder sbSubPartTitle = new StringBuilder();
		StringBuilder sbSubPartSpecSubType = new StringBuilder();
		StringBuilder sbSubPartRevRelDt = new StringBuilder();
		StringBuilder sbSubPartValidStartDt = new StringBuilder();
		StringBuilder sbSubPartValidUntiltDt = new StringBuilder();
		StringBuilder sbSubPartBUOM = new StringBuilder();

		StringBuilder sbSubForType = new StringBuilder();
		StringBuilder sbSubForName = new StringBuilder();
		StringBuilder sbSubForRev = new StringBuilder();
		StringBuilder sbSubForId = new StringBuilder();
		StringBuilder sbSubForTitle = new StringBuilder();
		StringBuilder sbSubstituteSCN = new StringBuilder();
		StringBuilder sbSubForQty = new StringBuilder();

		StringBuilder sbSubForComments = new StringBuilder();
		StringBuilder sbSubForCurrent = new StringBuilder();
		StringBuilder sbSubForRDOC = new StringBuilder();

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership = filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();

		try {
			Iterator objectListItr = mapList.iterator();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();

				if (objectMap.containsKey(ConstantsUtil.SELECT_SUBSTITUTE)) {

					String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sReleaseDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
					String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					String sComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);

					String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
					sCurrent = mapType(sCurrent.trim());
					String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
					sRD = replaceSpecialSymbols(sRD);
					String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
					sOC = replaceSpecialSymbols(sOC);
					String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;

					String strClassFied = validator
							.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
					boolean bHasOwnership = false;
					boolean showData = true;
					boolean isExternal = isModificatinRequired();
					String sFormulaPropagate = sId;
					if (isExternal) {
						// commented by Ganesh for security impl----->start
						/*
						 * if (sType.equalsIgnoreCase(ConstantsUtil.
						 * TYPE_FORMULATIONPART)) { sFormulaPropagate =
						 * getFormulaPropagate(context, sFormulaPropagate); }
						 * bHasOwnership = checkOwnerShip(context,
						 * slUserOwnership, sFormulaPropagate);
						 */
						// commented by Ganesh for security impl----->end
						// modified by Ganesh for security impl----->start
						bHasOwnership = checkHasAccess(context, null, sId);
						// modified by Ganesh for security impl----->end
						if (!bHasOwnership)
							continue;
					} else if (!isExternal) {
						if (slHIRTypes.contains(sType)) {
							String sFormulaClassif = strClassFied;
							if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaClassif = getFormulaPropagateClassification(context, sId);
							}

							if (null != sUserlicense && null != sFormulaClassif
									&& !sUserlicense.contains(sFormulaClassif)) {
								continue;
							}

						}

					}
					String sHasSubstitute = validator
							.getStringEquivalentForStringList((String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
					StringList slSubType = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE)));

					StringList slSubCSSType = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCSSTYPE)));

					StringList slValidStartDate = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY)));
					StringList sltrValidUntilDt = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
					StringList slSubstituteName = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME)));
					StringList slSubstituteType = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)));
					StringList slSubstituteRev = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)));
					StringList slSubComments = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT)));

					StringList slSubstituteSCN = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER)));

					StringList slSubstituteTitle = new StringList();

					if (objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE)) {

						String clClass = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE).getClass()
								.getSimpleName();
						if (clClass.equals(ConstantsUtil.STRING)) {
							String sSubstituteTitle = validator.isNotNullOrEmpty(
									(String) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE))
									? (String) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE)
											: ConstantsUtil.EMPTY_STRING;
									slSubstituteTitle = getStringList(sSubstituteTitle);
						} else {
							slSubstituteTitle = validator.isNotNullOrEmpty(
									(StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						}

					}

					StringList slSubstitutePart = getStringList(validator
							.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID)));
					StringList slSubstituteReleaseDate = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE)));
					StringList slBuom = getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_BASEUNITOFMEASURE)));
					for (int i = 0; i < slSubstituteName.size(); i++) {

						if (UIUtil.isNotNullAndNotEmpty(sHasSubstitute)
								&& (sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)
										|| sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE))) {
							String sSubstituteStartDate = getValueFromStringList(slValidStartDate, i);
							String sSubstituteUntilDate = getValueFromStringList(sltrValidUntilDt, i);
							String sSubstituteName = getValueFromStringList(slSubstituteName, i);
							String sSubstituteType = getValueFromStringList(slSubstituteType, i);
							String sSubstituteRev = getValueFromStringList(slSubstituteRev, i);
							String sSubstitutecmt = getValueFromStringList(slSubComments, i);
							String sSubstituteTitle = getValueFromStringList(slSubstituteTitle, i);
							String sSubstitutePartId = getValueFromStringList(slSubstitutePart, i);
							String sSubstituteRelDate = getValueFromStringList(slSubstituteReleaseDate, i);
							String sSubstituteBUOM = getValueFromStringList(slBuom, i);
							String sRevRelease = sSubstituteRev + ConstantsUtil.SYMBL_COLON + sSubstituteRelDate;
							String sSubstituteSCN = getValueFromStringList(slSubstituteSCN, i);
							String sSubstituteAssemblyType = getValueFromStringList(slSubType, i);
							String strAttrPgCSSType = getValueFromStringList(slSubCSSType, i);
							// String sSpecSubType = (String)
							// objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							sSubstituteAssemblyType = getSpecificationSubtype(context, sSubstituteType,
									sSubstituteAssemblyType, strAttrPgCSSType);

							formatData(sbSubPartRev, sSubstituteRev);
							formatData(sbSubPartName, sSubstituteName);
							formatData(sbSubForType, mapType(sType));
							formatData(sbSubForRev, sRevision);
							formatData(sbSubForName, sName);

							boolean bSubstuteHasAccess = false;
							if (isExternal) { // modified by Ganesh for security
								// impl----->start
								/*
								 * if (sSubstituteType.equalsIgnoreCase(
								 * ConstantsUtil.TYPE_FORMULATIONPART)) {
								 * sSubstitutePartId =
								 * getFormulaPropagate(context,
								 * sSubstitutePartId); } bSubstuteHasAccess =
								 * checkOwnerShip(context, slUserOwnership,
								 * sSubstitutePartId);
								 */
								bSubstuteHasAccess = checkHasAccess(context, null, sSubstitutePartId);
								// modified by Ganesh for security impl----->end
								if (!bSubstuteHasAccess)
									formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
								formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
								formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
								formatData(sbSubPartRevRelDt, ConstantsUtil.NO_ACCESS);
								formatData(sbSubPartValidStartDt, ConstantsUtil.NO_ACCESS);
								formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
								formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
								formatData(sbSubPartBUOM, ConstantsUtil.NO_ACCESS);
								formatData(sbSubForComments, ConstantsUtil.NO_ACCESS);
								formatData(sbSubForCurrent, ConstantsUtil.NO_ACCESS);
								formatData(sbSubForRDOC, ConstantsUtil.NO_ACCESS);
								formatData(sbSubForId, ConstantsUtil.NO_ACCESS);
								formatData(sbSubForTitle, ConstantsUtil.NO_ACCESS);
								formatData(sbSubForQty, ConstantsUtil.NO_ACCESS);

								continue;
							} else if (!isExternal) {
								if (slHIRTypes.contains(sSubstituteType)) {
									//DomainObject dobSubstitute = new DomainObject(sSubstitutePartId);
									DomainObject dobSubstitute = DomainObject.newInstance(context, sSubstitutePartId);
									String sSubstituteIPClass = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));

									String sSubFormulalassif = sSubstituteIPClass;
									if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
										sSubFormulalassif = getFormulaPropagateClassification(context,
												sSubstitutePartId);
									}

									if (null != sUserlicense && null != sSubFormulalassif
											&& !sUserlicense.contains(sSubFormulalassif)) {
										formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
										formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
										formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
										formatData(sbSubPartRevRelDt, ConstantsUtil.NO_ACCESS);
										formatData(sbSubPartValidStartDt, ConstantsUtil.NO_ACCESS);
										formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
										formatData(sbSubPartBUOM, ConstantsUtil.NO_ACCESS);
										formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
										formatData(sbSubForComments, ConstantsUtil.NO_ACCESS);
										formatData(sbSubForCurrent, ConstantsUtil.NO_ACCESS);
										formatData(sbSubForRDOC, ConstantsUtil.NO_ACCESS);
										formatData(sbSubForId, ConstantsUtil.NO_ACCESS);
										formatData(sbSubForTitle, ConstantsUtil.NO_ACCESS);
										formatData(sbSubForQty, ConstantsUtil.NO_ACCESS);

										continue;
									}

								}

							}

							formatData(sbSubPartType, mapType(sSubstituteType));
							formatData(sbSubPartId, sSubstitutePartId);
							formatData(sbSubPartTitle, sSubstituteTitle);
							formatData(sbSubstituteSCN, sSubstituteSCN);
							formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
							formatData(sbSubPartRevRelDt, sRevRelease);
							formatData(sbSubPartValidStartDt, sSubstituteStartDate);
							formatData(sbSubPartValidUntiltDt, sSubstituteUntilDate);
							formatData(sbSubPartBUOM, sSubstituteBUOM);
							formatData(sbSubForComments, sSubstitutecmt);
							formatData(sbSubForCurrent, sCurrent);
							formatData(sbSubForRDOC, sRDOC);
							formatData(sbSubForId, sId);
							formatData(sbSubForTitle, sTitle);
							formatData(sbSubForQty, sQty);

						}
					}

				} // For

			} // while

			mpEBOMResult.put(ConstantsUtil.SF_ID, sbSubForId.toString());
			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbSubForType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_REVISION, sbSubForRev.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubForName.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbSubForTitle.toString());
			mpEBOMResult.put(ConstantsUtil.SCN, sbSubstituteSCN.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbSubForQty.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbSubPartBUOM.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbSubForComments.toString());
			mpEBOMResult.put(ConstantsUtil.STATE, sbSubForCurrent.toString());
			mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbSubForRDOC.toString());
			mpEBOMResult.put(ConstantsUtil.SST, sbSubPartSpecSubType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbSubPartId.toString());
			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbSubPartType.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
			mpEBOMResult.put(ConstantsUtil.SF_REVISION, sbSubPartRev.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEPARTS, sbSubPartName.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbSubPartRevRelDt.toString());
			mpEBOMResult.put(ConstantsUtil.VALIDSTARTDATE, sbSubPartValidStartDt.toString());
			mpEBOMResult.put(ConstantsUtil.VALIDTILLDATE, sbSubPartValidUntiltDt.toString());
			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbSubPartTitle.toString());

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in BusObjectAttribUtil : " + e);
			return new HashMap();
		}
		return filterMapList(mpEBOMResult);
	}

	/**
	 * Getting the Substitute Value
	 * 
	 * @param slSubType
	 * @param i
	 * @return
	 */
	public String getValueFromStringList(StringList slSubType, int i) {

		try {
			String sValue = slSubType.get(i);
			return sValue;

		} catch (Exception e) {

			return "";
		}
	}

	public String getPdfViewtype(boolean isAllInfoView, boolean bGendocView, boolean bSupplierView) {
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 19 Mar 2021 -- START :: Sequence Changed
		if (isAllInfoView) {
			return ConstantsUtil.ALL_INFO_VIEW; // If user is Internal User
		} else if (bGendocView) {
			return ConstantsUtil.GENDOC_VIEW;	// If user is GenDoc True (CM +) Auth to Produce True)
		} else if (bGendocView && !bSupplierView) {
			return ConstantsUtil.CM_VIEW;		// If User GenDoc true + not supplier
		} else if (!bGendocView && !bSupplierView) {
			return ConstantsUtil.CM_VIEW;		// If user is only CM + Auth to Use true
		}  else if (bSupplierView) {
			return ConstantsUtil.SUPPLIER_VIEW;	// If user is supplier
		} else {
			return ConstantsUtil.ALL_INFO_VIEW;		// Display All Info view
		}
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 19 Mar 2021 -- END
	}

	public Object getDocuments(Context context, String parentId, String parentRel) throws Exception {
		try {
			/*
			 * HashMap programMap = (HashMap) JPO.unpackArgs(args); String
			 * parentId = (String) programMap.get("objectId"); String parentRel
			 * = (String) programMap.get("parentRelName");
			 */
			Pattern relPattern = new Pattern("");
			// If parent relation ship is passed separated by comma
			// Tokenize and add it rel pattern
			if (parentRel != null) {
				StringTokenizer relString = new StringTokenizer(parentRel, ",");
				while (relString.hasMoreTokens()) {
					String relStr = relString.nextToken().trim();
					if (relStr != null && !"null".equals(relStr) && !"".equals(relStr)) {

						String actRelName = PropertyUtil.getSchemaProperty(context, relStr);
						if (actRelName != null && !"null".equals(actRelName) && !"".equals(actRelName)) {
							relPattern.addPattern(actRelName);
						}
					}
				}
			}

			// if not passed, or non-existing relationship passed then default
			// to "Reference
			// Document" relationship

			if ("".equals(relPattern.getPattern()))

			{
				relPattern.addPattern(ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT);

			}

			String objectWhere = "";
			String strProtocolType = "";

			DomainObject masterObject = DomainObject.newInstance(context, parentId);
			String contextType = masterObject.getInfo(context, ConstantsUtil.SELECT_TYPE);
			boolean isStabilityReport = contextType.equals(PropertyUtil.getSchemaProperty("type_pgPKGStabilityReport"))
					? true : false;
			boolean isValidationReport = contextType
					.equals(PropertyUtil.getSchemaProperty("type_pgPKGValidationReport")) ? true : false;

			StringList typeSelects = new StringList(1);
			typeSelects.add(ConstantsUtil.SELECT_ID);
			StringList relSelects = new StringList(1);
			relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			relSelects.add("attribute[" + ConstantsUtil.ATTR_PG_INHERITANCE_TYPE + "].value");

			MapList documentList = masterObject.getRelatedObjects(context, relPattern.getPattern(), "*", typeSelects,
					relSelects, false, true, (short) 1, objectWhere, null, null, null, null);

			if (isStabilityReport || isValidationReport) {
				strProtocolType = isStabilityReport ? PropertyUtil.getSchemaProperty("type_pgPKGStabilityProtocol")
						: PropertyUtil.getSchemaProperty("type_pgPKGValidationProtocol");
				MapList documentListProtocol = masterObject.getRelatedObjects(context, relPattern.getPattern(),
						strProtocolType, typeSelects, relSelects, true, false, (short) 1, objectWhere, null, null, null,
						null);

				documentList.addAll(documentListProtocol);
			}
			return documentList;
		} catch (Exception ex) {
			ex.printStackTrace();
			LOGGER.error("Exception in BusObjectAttribUtil : getDocuments: " + ex);
		}
		return null;

	}

	public MapList sortSpecifications(Context context, MapList specList) throws Exception {
		MapList returnList = new MapList();
		String specId = DomainConstants.EMPTY_STRING;
		String partType = DomainConstants.EMPTY_STRING;
		DomainObject specDO = DomainObject.newInstance(context);
		Map specMap = new HashMap();
		List typeDefinedOrder = Arrays.asList(ConstantsUtil.TYPE_PG_CUSTOMERUNIT,
				ConstantsUtil.TYPE_PG_MASTERCUSTOMERUNIT, ConstantsUtil.TYPE_PGINNERPACKUNITPART,
				ConstantsUtil.TYPE_PG_MASTERINNERPACKUNIT, ConstantsUtil.TYPE_PGCONSUMERUNITPART,
				ConstantsUtil.TYPE_PG_MASTERCONSUMERUNIT);
		Iterator specListItr = specList.iterator();
		while (specListItr.hasNext()) {
			specMap = (Map) specListItr.next();
			specId = (String) specMap.get(DomainConstants.SELECT_ID);
			if (UIUtil.isNotNullAndNotEmpty(specId)) {
				specDO.setId(specId);
				partType = specDO.getInfo(context,
						"to[" + DomainRelationship.RELATIONSHIP_PART_SPECIFICATION + "].from.type");
				specMap.put("typeindex", typeDefinedOrder.indexOf(partType));
				returnList.add(specMap);
			}
		}
		returnList.sort("typeIndex", "ascending", "integer");
		return returnList;
	}

	/**
	 * 
	 * @param context
	 * @param mlMasterSpecs
	 * @return
	 * @throws Exception
	 */

	public Map getFPPMasterSpecifications(Context context, MapList mlMasterSpecs) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();

		try {
			String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION;
			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			//String[] aCompany = sUserCompanies.split(",");
			String[] aCompany = splitCompanyValues(context,sUserCompanies);
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			StringBuilder sbCompany = new StringBuilder();
			StringList slCompanies = new StringList();

			boolean bHasOwnerShip = false;
			String sWhere = ConstantsUtil.EMPTY_STRING;
			String sUserType = getUserType();
			if (isModificatinRequired()) {
				sWhere = "current!=Obsolete";
			}
			if (aCompany.length > -1) {
				for (int k = 0; k < aCompany.length; k++) {
					if (null != aCompany[k]) {
						String Company = aCompany[k].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
						slCompanies.add(Company);
					}
				}
			}
			StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
			MapList mapList;

			for (int j = 0; j < mlMasterSpecs.size(); j++) {
				Map mpMasterEachObj = (Map) mlMasterSpecs.get(j);

				String strMasterId = validator.getStringEquivalentForStringList(mpMasterEachObj.get(ConstantsUtil.ID));

				//DomainObject doAPP = new DomainObject(strMasterId);
				DomainObject doAPP = DomainObject.newInstance(context, strMasterId);

				mapList = doAPP.getRelatedObjects(context, sRelationPattern, DomainConstants.QUERY_WILDCARD,
						slPartSpecSelects, null, false, true, (short) 1, sWhere, DomainConstants.EMPTY_STRING,
						ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doAPP.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				for (int x = 0; x < mapList.size(); x++) {
					Map mpEachObj = (Map) mapList.get(x);
					StringList eachOwnership = validator
							.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
					// Split this to get only the companies
					StringList slEachOwnership = filterOwnerShip(eachOwnership);

					String strType = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
					String strName = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_NAME));
					String strSharable = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
					String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
					String strClassFied = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
					String sIPClassfication = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
					String strSource = getSource(context, strId);
					String strSubType = UpdateSpecSubType(context, strId);
					if (isModificatinRequired()) {
						if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							}

						} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
								|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {

							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = updateReferences(context, strId);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									String strState = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

								}
							}

						} else {
							// modified by Ganesh for security impl----->start
							// bHasOwnerShip = checkOwnerShip(sbCompany,
							// slEachOwnership);
							bHasOwnerShip = checkHasAccess(context, sUserType, strId);
							// modified by Ganesh for security impl----->end
							if (bHasOwnerShip) {
								sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

							} else {
								sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							}
						}

					} else {
						boolean showData = true;
						
						showData = checkHasAccess(context, null, strId);

						if (showData) {
							sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							sbType.append(mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

						}

					}

				}
			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Exception in BusObjectAttribUtil getFPPPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;

	}

	public String getMultiLineAttributeValueForBrandInformation(Context context, String objectId) throws Exception {

		String formatedString = "";
		String strTypePLICSSBrand = PropertyUtil.getSchemaProperty("type_pgPLICSSBrand");

		String strTypeBrand = PropertyUtil.getSchemaProperty("type_pgBrand");

		String strAttrBrand = PropertyUtil.getSchemaProperty("attribute_pgBrand");

		String strRelpgBrandtopgPLICSSBrand = PropertyUtil.getSchemaProperty("relationship_pgBrandtopgPLICSSBrand");

		String strTypeFinishedProduct = PropertyUtil.getSchemaProperty("type_pgFinishedProduct");
		String strDelimiterPipe = "|";
		String strAttrBrandInfo = PropertyUtil.getSchemaProperty("attribute_pgBrandInformation");
		String ATTRIBUTE_V_NAME = PropertyUtil.getSchemaProperty("attribute_PLMEntity.V_Name");
		String SELECT_ATTRIBUTE_V_NAME = "attribute[" + ATTRIBUTE_V_NAME + "]";
		// StringBuffer stBuff = new StringBuffer();

		StringBuilder stBuff = new StringBuilder();

		try {

			String sAttr = strAttrBrandInfo;

			DomainObject doj = DomainObject.newInstance(context, objectId);

			String sAttrVal = "";

			if (sAttr != null && !"null".equals(sAttr) && !"".equals(sAttr)) {

				sAttrVal = doj.getAttributeValue(context, sAttr);

			}

			String strObjectType = doj.getInfo(context, "type");

			formatedString = sAttrVal;

			StringList strBrandValueList = new StringList();

			StringTokenizer st = new StringTokenizer(sAttrVal, "|");

			String strValue = null;

			while (st.hasMoreTokens()) {

				String strTemp = st.nextToken();

				int i = strTemp.indexOf("~");

				if (i != -1)

				{

					strValue = strTemp.substring(0, i);

				} else {

					strValue = strTemp;

				}

				strValue = (String) getBrandObjects(context, strValue);

				if (!strBrandValueList.contains(strValue)) {

					strBrandValueList.addElement(strValue);

				}

			}
			if (strTypeFinishedProduct.equals(strObjectType)) {

				String strpgBrandAttr = doj.getAttributeValue(context, strAttrBrand);

				if (!"".equals(strpgBrandAttr)) {

					if (!strBrandValueList.contains(strpgBrandAttr)) {

						strBrandValueList.addElement(strpgBrandAttr);

					}

				}

			}

			strBrandValueList.sort();

			// Added by Jwala for the defect #38078 -- START
			int iLength = strBrandValueList.size();
			for (int nCount = 0; nCount < iLength; nCount++) {
				String strNewValue = (String) strBrandValueList.get(nCount);
				if (stBuff.length() == 0) {
					stBuff.append(strNewValue);
				} else {
					stBuff.append(" ");
					stBuff.append("|");
					stBuff.append(" ");
					stBuff.append(strNewValue);

				}
				/*
				 * if(stBuff.length()<1){ stBuff.append(strNewValue); }
				 */
			}
			// Added by Jwala for the defect #38078 -- END
		}

		catch (Exception ex) {

			ex.printStackTrace();

			throw ex;

		} /*
		 * finally { return stBuff.toString();
		 * 
		 * }
		 */
		return stBuff.toString();
		//Modified by Jwala for leak
	}

	public String getBrandObjects(Context context, String strValue) throws Exception {

		StringBuffer sbBrandInfoValue = new StringBuffer();

		String strTypePLICSSBrand = PropertyUtil.getSchemaProperty("type_pgPLICSSBrand");

		String strTypeBrand = PropertyUtil.getSchemaProperty("type_pgBrand");

		String strAttrBrand = PropertyUtil.getSchemaProperty("attribute_pgBrand");

		String strRelpgBrandtopgPLICSSBrand = PropertyUtil.getSchemaProperty("relationship_pgBrandtopgPLICSSBrand");
		try {

			StringList objSelect = new StringList(2);

			objSelect.add(DomainObject.SELECT_NAME);

			objSelect.add(DomainObject.SELECT_ID);

			if (strValue != null && !"null".equals(strValue) && !"".equals(strValue)) {

				MapList mlpgPLICSSBrandObjectList = DomainObject.findObjects(context, //MatrixContext
													strTypePLICSSBrand, //typePattern
													strValue.trim(), //namePattern
													DomainConstants.QUERY_WILDCARD, //revPattern
													DomainConstants.QUERY_WILDCARD, //ownerPattern
													ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
													DomainConstants.EMPTY_STRING, //whereExpression
													false, //expandType
													objSelect); //objectSelects

				String strCSSBrandObjectId = "";

				String strpgBrandName = "";

				ArrayList alAlreadyPresent = new ArrayList();

				for (int i = 0; i < mlpgPLICSSBrandObjectList.size(); i++) {

					strCSSBrandObjectId = (String) ((Map) mlpgPLICSSBrandObjectList.get(i)).get(DomainObject.SELECT_ID);

					DomainObject dopgPLICSSBrand = DomainObject.newInstance(context, strCSSBrandObjectId);

					MapList mlpgBrandObjectList = dopgPLICSSBrand.getRelatedObjects(context,
							strRelpgBrandtopgPLICSSBrand, strTypeBrand, objSelect, new StringList(), true, false,
							(short) 1, "", null, null, null, null);

					for (int j = 0; j < mlpgBrandObjectList.size(); j++) {

						strpgBrandName = (String) ((Map) mlpgBrandObjectList.get(j)).get(DomainObject.SELECT_NAME);

						if (!alAlreadyPresent.contains(strpgBrandName)) {

							alAlreadyPresent.add(strpgBrandName);

							sbBrandInfoValue.append(strpgBrandName);

						}

					}

				}

			}

		} catch (Exception ex) {

			ex.printStackTrace();

			throw ex;

		} 
			return sbBrandInfoValue.toString().trim();

	}

	public String getBrandInformationValue(Context context, String strObjectId) throws Exception {

		String strBrandInfoValue = "";

		try {
			String strDelimiter = "";
			if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
				StringBuffer sbBuffer = new StringBuffer();
				DomainObject dobGCASObj = DomainObject.newInstance(context, strObjectId);
				String strOriginatingSource = dobGCASObj.getInfo(context,
						ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				if (isOfDSOOrigin(context, strObjectId)) {
					String strProductDataToPickListExpr = "from[" + ConstantsUtil.RELATIONSHIP_PGPDTEMPLATESTOPGBRAND
							+ "].to." + DomainConstants.SELECT_NAME;

					StringList slBrandInfo = (StringList) dobGCASObj.getInfoList(context, strProductDataToPickListExpr);
					if (slBrandInfo != null && slBrandInfo.size() > 0) {

						for (int iB = 0; iB < slBrandInfo.size(); iB++)

						{
							String strNewValue = slBrandInfo.get(iB).toString();
							if (UIUtil.isNotNullAndNotEmpty(strNewValue)) {
								//SPEC: Added by Ketan for ALM Defect 49804 -- START
								if(iB ==0) {
									sbBuffer.append(strNewValue);
								}else {
									sbBuffer.append(ConstantsUtil.SYMBL_COMMA).append(strNewValue);
								}
								//SPEC: Added by Ketan for ALM Defect 49804 -- END
							}

						}

					}

					strBrandInfoValue = sbBuffer.toString();

				} else {

					HashMap hmMethodArg = new HashMap();

					hmMethodArg.put("objectId", strObjectId);

					hmMethodArg.put("Delimiter", strDelimiter);

					String[] methodArgs = JPO.packArgs(hmMethodArg);

					strBrandInfoValue = (String) getMultiLineAttributeValueForBrandInformation(context, strObjectId);

				}

			}

		} catch (Exception ex) {

			ex.printStackTrace();

			throw ex;

		} /*
		 * finally { return strBrandInfoValue;
		 * 
		 * }
		 */
		return strBrandInfoValue;
		// SPEC: Modified by Jwala for the resource leak
	}

	// SPEC: ADD for Defect#38623 1.0.2 Release - Jwala -- START
	/**
	 * 
	 * @param context
	 * @param strObjectId
	 * @return String
	 * @throws Exception
	 */
	public String getPrintingProcessValue(Context context, String strObjectId) throws Exception {

		String strPPValue = "";
		StringBuffer sbPP = new StringBuffer();

		try {
			if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {

				DomainObject doPP = DomainObject.newInstance(context, strObjectId);
				String strPrintingProcess = "from[" + ConstantsUtil.RELATIONSHIP_PGPDTEMPLATESTOPGPLIPRINTINGPROCESS
						+ "].to." + DomainConstants.SELECT_NAME;
				StringList slPPInfo = (StringList) doPP.getInfoList(context, strPrintingProcess);

				int iLength = slPPInfo.size();
				for (int nCount = 0; nCount < iLength; nCount++) {
					String strNewValue = (String) slPPInfo.get(nCount);
					if (sbPP.length() == 0) {
						sbPP.append(strNewValue);
					} else {
						sbPP.append(",");
						sbPP.append("\n");
						sbPP.append(strNewValue);

					}
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Error from BusObjectAttribUtil:  getPrintingProcessValue" + ex);
			return sbPP.toString();
		}

		return sbPP.toString();
	}

	// SPEC: Modified for Defect#38623 1.0.2 Release - Jwala -- END
	/**
	 * 
	 * @param context
	 * @param strType
	 * @param strAttrPgAssemblyType
	 * @param strAttrPgCSSType
	 * @return
	 * @throws Exception
	 */

	public String getSpecificationSubtype(Context context, String strType, String strAttrPgAssemblyType,
			String strAttrPgCSSType) throws Exception {
		Map mapDataMapping = new HashMap();
		mapDataMapping.put("pgPackingMaterial", "Packaging");
		mapDataMapping.put("pgRawMaterial", "Raw");
		if ("pgFinishedProduct".equals(strType)) {
			if ("".equals(strAttrPgAssemblyType)) {
				mapDataMapping.put("pgFinishedProduct", "Finished Product");
			} else if ("FWIP-Finished Work in Process".equals(strAttrPgAssemblyType)) {
				mapDataMapping.put("pgFinishedProduct", "FWIP-Finished Work in Process");
			} else if ("Purchased Subassembly".equals(strAttrPgAssemblyType)) {
				mapDataMapping.put("pgFinishedProduct", "Purchased Subassembly");
			} else if ("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)) {
				mapDataMapping.put("pgFinishedProduct", "Purchased and/or Produced Subassembly");
			}
		} else if ("pgQualitySpecification".equals(strType)) {
			if (!UIUtil.isNullOrEmpty(strAttrPgCSSType)) {
				mapDataMapping.put("pgQualitySpecification", strAttrPgCSSType);
			} else {
				if (!UIUtil.isNullOrEmpty(strAttrPgAssemblyType)) {

					String strSpecSubType = "";
					if (strAttrPgAssemblyType.equalsIgnoreCase("Sampling")) {
						strSpecSubType = "SMPL";
					} else if (strAttrPgAssemblyType.equalsIgnoreCase("Cleaning/Inspection/Lubrication")) {
						strSpecSubType = "CIL";
					}
					mapDataMapping.put("pgQualitySpecification", strSpecSubType);
				}
			}
		} else if ("pgTestMethod".equals(strType)) {
			if ("TAMU".equals(strAttrPgCSSType)) {
				mapDataMapping.put("pgTestMethod", "TAMU");
			} else {
				mapDataMapping.put("pgTestMethod", "");
			}
		} else if ("pgPackingSubassembly".equals(strType)) {
			if ("Purchased Subassembly".equals(strAttrPgAssemblyType)) {
				mapDataMapping.put("pgPackingSubassembly", "Purchased Subassembly");
			} else if ("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)) {
				mapDataMapping.put("pgPackingSubassembly", "Purchased and/or Produced Subassembly");
			}
		} // Added for defect 37587 (missing SST on TUP Substitutes
		else if ("Packaging Material Part".equalsIgnoreCase(strType)) {
			mapDataMapping.put("Packaging Material Part", "Packaging");
		}

		String strSpecSubType = (String) mapDataMapping.get(strType);
		if (strSpecSubType == null) {
			strSpecSubType = strAttrPgAssemblyType;
		}
		/*
		 * else { strSpecSubType=""; }
		 */

		return strSpecSubType;
	}

	/**
	 * Method Name : getGHSProdcutValue
	 * Method Description : to extract the values for GLOBAL HARMONIZED SECTION for FPP
	 * @param context
	 * @param resultMaps
	 * @return
	 */

	public Map getGHSProdcutValue(Context context, Map resultMaps) {
		Map mpGlobalHarStandard = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbGName = new StringBuilder();
		StringBuilder sbGTitle = new StringBuilder();
		StringBuilder sbGRev = new StringBuilder();
		StringBuilder sbGDec = new StringBuilder();
		StringBuilder sbMarkets = new StringBuilder();
		StringBuilder sbLang = new StringBuilder();
		StringBuilder sbID = new StringBuilder();
		StringBuilder sbGType = new StringBuilder();

		String strRev = ConstantsUtil.EMPTY_STRING;
		String strName = ConstantsUtil.EMPTY_STRING;
		String strTitle = ConstantsUtil.EMPTY_STRING;
		String strId = ConstantsUtil.EMPTY_STRING;
		String strState = ConstantsUtil.EMPTY_STRING;
		String strPhase = ConstantsUtil.EMPTY_STRING;
		String strType = ConstantsUtil.EMPTY_STRING;

		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 for Defect 40855 -- START
		String strGHSName = ConstantsUtil.EMPTY_STRING;
		String strGHSTitle = ConstantsUtil.EMPTY_STRING;
		String strGHSRev = ConstantsUtil.EMPTY_STRING;
		String strGHSDec = ConstantsUtil.EMPTY_STRING;
		String strGHSMarkets = ConstantsUtil.EMPTY_STRING;
		String strGHSLang = ConstantsUtil.EMPTY_STRING;
		String strGHSID = ConstantsUtil.EMPTY_STRING;
		String strGHSType = ConstantsUtil.EMPTY_STRING;
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 for Defect 40855 -- END

		StringList slProductSelects = new StringList();
		slProductSelects.add(ConstantsUtil.SELECT_NAME);
		slProductSelects.add(ConstantsUtil.SELECT_TYPE);
		slProductSelects.add(ConstantsUtil.SELECT_REVISION);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		slProductSelects.add(ConstantsUtil.SELECT_CURRENT);

		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 for Defect 40855 -- START
		slProductSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slProductSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_COPYLISTCOUNTRY_NAME);
		slProductSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_COPYLISTLOCALLANGUAGE_NAME);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 for Defect 40855 -- END

		//SPEC: Release SR18x.6.0 - Added by Jwala for defect #42138 -- START
		boolean showData = false;
		String sUserType = getUserType();
		//SPEC: Release SR18x.6.0 - Added by Jwala for defect #42138 -- END

		String strIdsObjectId = validator.getStringEquivalentForStringList(
				resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID));

		StringList slsObjectId = FrameworkUtil.split(strIdsObjectId, ConstantsUtil.SYMBL_PIPE);

		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 for Defect 40855 -- START
		String strGHSObjectId = validator.getStringEquivalentForStringList(
				resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_ID));

		StringList slGHSObjectId = FrameworkUtil.split(strGHSObjectId, ConstantsUtil.SYMBL_PIPE);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 for Defect 40855 -- END

		try {
			for (String strID : slsObjectId) {

				String sObjectId = strID.trim();
				if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
					DomainObject doProductPart = new DomainObject(sObjectId);
					//DomainObject doProductPart = DomainObject.newInstance(context, sObjectId);
					Map mpTemp = doProductPart.getInfo(context, slProductSelects);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doProductPart.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					strRev = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
					strName = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
					strType = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
					strTitle = validator
							.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					strId = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.ID));
					strState = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_CURRENT));
					strPhase = validator
							.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

					//SPEC: Release SR18x.6.0 - Added by Jwala for defect #42138 -- START
					showData = checkHasAccess(context, sUserType, strId);

					if(!showData){
						strId = ConstantsUtil.NO_ACCESS;
						strTitle = ConstantsUtil.NO_ACCESS;
					}
					if(!ConstantsUtil.RELEASED.equalsIgnoreCase(strState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strState))){
						strId = ConstantsUtil.NO_ACCESS;
					}
					//SPEC: Release SR18x.6.0 - Added by Jwala for defect #42138 -- END

					formatData(sbName, strName);
					formatData(sbType, strType);
					formatData(sbRev, strRev);
					formatData(sbTitle, strTitle);
					formatData(sbId, strId);
					formatData(sbState, strState);
					formatData(sbPhase, strPhase);
				}
			}

			for (String sGHSID : slGHSObjectId) {

				String sGHSObjectId = sGHSID.trim();

				if (UIUtil.isNotNullAndNotEmpty(sGHSObjectId)) {
					//DomainObject doGHSData = new DomainObject(sGHSObjectId);
					DomainObject doGHSData = DomainObject.newInstance(context, sGHSObjectId);

					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.STR_RELATIONSHIP_COPYLISTCOUNTRY_NAME);
					Map mpGHSTemp = doGHSData.getInfo(context, slProductSelects);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doGHSData.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.STR_RELATIONSHIP_COPYLISTCOUNTRY_NAME);

					strGHSRev = validator.getStringEquivalentForStringList(mpGHSTemp.get(ConstantsUtil.SELECT_REVISION));
					strGHSName = validator.getStringEquivalentForStringList(mpGHSTemp.get(ConstantsUtil.SELECT_NAME));
					strGHSType = validator.getStringEquivalentForStringList(mpGHSTemp.get(ConstantsUtil.SELECT_TYPE));
					strGHSTitle = validator.getStringEquivalentForStringList(mpGHSTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					strGHSID = validator.getStringEquivalentForStringList(mpGHSTemp.get(ConstantsUtil.ID));
					strGHSDec = validator.getStringEquivalentForStringList(mpGHSTemp.get(ConstantsUtil.SELECT_DESCRIPTION));
					strGHSMarkets = validator.getStringEquivalentForStringListWithComma(mpGHSTemp.get(ConstantsUtilIRM.STR_RELATIONSHIP_COPYLISTCOUNTRY_NAME));
					strGHSLang = validator.getStringEquivalentForStringList(mpGHSTemp.get(ConstantsUtilIRM.STR_RELATIONSHIP_COPYLISTLOCALLANGUAGE_NAME));

					formatData(sbGName, strGHSName);
					formatData(sbGType, strGHSType);
					formatData(sbGRev, strGHSRev);
					formatData(sbGTitle, strGHSTitle);
					formatData(sbID, strGHSID);
					formatData(sbGDec, strGHSDec);
					formatData(sbMarkets, strGHSMarkets);
					formatData(sbLang, strGHSLang);
				}
			}
			//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 15, 2021 for Defect 40855 -- END

			mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTNAME, sbName.toString());
			mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTTYPE, sbType.toString());
			mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTID, sbId.toString());
			mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTREVISION, sbRev.toString());
			mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTTITLE, sbTitle.toString());
			mpGlobalHarStandard.put(ConstantsUtil.PHASE, sbPhase.toString());
			mpGlobalHarStandard.put(ConstantsUtil.STATE, sbState.toString());
			mpGlobalHarStandard.put(ConstantsUtil.ID, sbID.toString());
			//SPEC: 10/09/2020: Commented for Defect #42138 DEV -- START
			//mpGlobalHarStandard.put(ConstantsUtil.TYPE, sbGType.toString());
			//SPEC: 10/09/2020: Commented for Defect #42138 DEV -- END
			mpGlobalHarStandard.put(ConstantsUtil.NAME, sbGName.toString());
			mpGlobalHarStandard.put(ConstantsUtil.TITLE, sbGTitle.toString());
			mpGlobalHarStandard.put(ConstantsUtil.REVISION, sbGRev.toString());
			mpGlobalHarStandard.put(ConstantsUtil.DESCRIPTION, sbGDec.toString());
			mpGlobalHarStandard.put(ConstantsUtil.MARKETS, sbMarkets.toString());
			mpGlobalHarStandard.put(ConstantsUtil.LANGUAGE, sbLang.toString());

		} catch (Exception e) {
			LOGGER.error("Error from BusObjectAttribUtil:  getGHSProdcutValue" + e);
			return new HashMap();
		}
		return mpGlobalHarStandard;
	}

	/**
	 * 
	 * @param context
	 * @param resultMaps
	 * @return
	 */

	public Map getDangerousProdcutValue(Context context, Map resultMaps) {
		Map mpDangerousProdcut = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		// SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		// StringBuilder sbName = new StringBuilder();
		// StringBuilder sbRev = new StringBuilder();
		// StringBuilder sbTitle = new StringBuilder();
		// SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();

		String strRev = ConstantsUtil.EMPTY_STRING;
		String strName = ConstantsUtil.EMPTY_STRING;
		String strTitle = ConstantsUtil.EMPTY_STRING;
		String strId = ConstantsUtil.EMPTY_STRING;
		String strTyp = ConstantsUtil.EMPTY_STRING;
		String strState = ConstantsUtil.EMPTY_STRING;
		String strPhase = ConstantsUtil.EMPTY_STRING;

		StringBuilder sbDGD = new StringBuilder();
		StringBuilder sbUNN = new StringBuilder();
		StringBuilder sbPSN = new StringBuilder();
		StringBuilder sbHC = new StringBuilder();
		StringBuilder sbPgroup = new StringBuilder();
		StringBuilder sbShipqty = new StringBuilder();
		StringBuilder sbCON = new StringBuilder();
		StringBuilder sbOPR = new StringBuilder();
		StringBuilder sbUSPGreq = new StringBuilder();
		StringBuilder sbCust = new StringBuilder();
		StringBuilder sbGCUP = new StringBuilder();
		StringBuilder sbGCOP = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		// SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		StringBuilder sbTN1 = new StringBuilder();
		StringBuilder sbTN2 = new StringBuilder();
		StringBuilder sbNo = new StringBuilder();
		// SPEC: 10/09/2020: Added for 18x.5 DEV -- END

		StringList slProductSelects = new StringList();
		slProductSelects.add(ConstantsUtil.SELECT_NAME);
		slProductSelects.add(ConstantsUtil.SELECT_TYPE);
		slProductSelects.add(ConstantsUtil.SELECT_CURRENT);
		slProductSelects.add(ConstantsUtil.SELECT_REVISION);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

		StringList slHCPGSelects = new StringList();
		slHCPGSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC);
		slHCPGSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP);

		String strIdsObjectId = validator.getStringEquivalentForStringList(
				resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID));

		StringList slsObjectId = FrameworkUtil.split(strIdsObjectId, ConstantsUtil.SYMBL_PIPE);
		try {
			for (String strID : slsObjectId) {

				String sObjectId = strID.trim();

				if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
					//DomainObject doProductPart = new DomainObject(sObjectId);
					DomainObject doProductPart = DomainObject.newInstance(context, sObjectId);
					Map mpTemp = doProductPart.getInfo(context, slProductSelects);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doProductPart.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					// SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
					// strRev =
					// validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
					// strName =
					// validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
					// strTitle =
					// validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					// SPEC: 10/09/2020: Commented for 18x.5 DEV -- END

					strId = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ID));
					strTyp = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
					strState = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_CURRENT));
					strPhase = validator
							.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

					// SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
					// formatData(sbName, strName);
					// formatData(sbRev, strRev);
					// formatData(sbTitle, strTitle);
					// SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
					formatData(sbId, strId);
					formatData(sbType, strTyp);
					formatData(sbState, strState);
					formatData(sbPhase, strPhase);
				}
			}

			String strDGD = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION));
			String strUNN = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER));
			String strPSN = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN));
			String strShipqty = validator.getStringEquivalentForString(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY));
			String strCON = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON));
			String strOPR = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR));
			String strUSPGreq = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZE));
			String strCUST = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST));
			String strSDgcup = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP));
			String strSDgcop = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP));
			String strHC = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC));
			String strPGGroup = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP));
			// SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			String strTN1 = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1));
			String strTN2 = validator.getStringEquivalentForStringList(
					resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2));
			String strNo = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.EMPTY_STRING));
			// SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			StringList slHCValues = FrameworkUtil.split(strHC, ConstantsUtil.SYMBL_PIPE);
			StringList slPGGroupValues = FrameworkUtil.split(strPGGroup, ConstantsUtil.SYMBL_PIPE);

			String strHCFInal = ConstantsUtil.EMPTY_STRING;
			String strPGFInal = ConstantsUtil.EMPTY_STRING;

			for (int i = 0; i < slHCValues.size(); i++) {

				String sHC = slHCValues.get(i);
				String sPGGroup = slPGGroupValues.get(i);

				if (i % 2 == 0) {
					strHCFInal += sHC + ConstantsUtil.SYMBL_COMMA;
					strPGFInal += sPGGroup + ConstantsUtil.SYMBL_COMMA;
				} else {
					strHCFInal += sHC + ConstantsUtil.SYMBL_PIPE;
					strPGFInal += sPGGroup + ConstantsUtil.SYMBL_PIPE;
				}
			}

			formatData(sbHC, strHCFInal);
			formatData(sbPgroup, strPGFInal);
			formatData(sbDGD, strDGD);
			formatData(sbUNN, strUNN);
			formatData(sbPSN, strPSN);
			formatData(sbShipqty, strShipqty);
			formatData(sbCON, strCON);
			formatData(sbOPR, strOPR);
			formatData(sbUSPGreq, strUSPGreq);
			formatData(sbCust, strCUST);
			formatData(sbGCUP, strSDgcup);
			formatData(sbGCOP, strSDgcop);
			formatData(sbTN1, strTN1);
			formatData(sbTN2, strTN2);
			formatData(sbNo, strNo);

			// SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			// mpDangerousProdcut.put(ConstantsUtil.PPN, sbName.toString());
			// SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			mpDangerousProdcut.put(ConstantsUtil.ID, sbId.toString());
			mpDangerousProdcut.put(ConstantsUtil.TYPE, sbType.toString());
			// SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			// mpDangerousProdcut.put(ConstantsUtil.PPR,sbRev.toString());
			// mpDangerousProdcut.put(ConstantsUtil.PPT,sbTitle.toString());
			// SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			mpDangerousProdcut.put(ConstantsUtil.DGD, sbDGD.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNN, sbUNN.toString());
			mpDangerousProdcut.put(ConstantsUtil.PSN, sbPSN.toString());
			mpDangerousProdcut.put(ConstantsUtil.HC, sbHC.toString());
			mpDangerousProdcut.put(ConstantsUtil.PGGROUP, sbPgroup.toString());
			mpDangerousProdcut.put(ConstantsUtil.SHIPPINGQTY, sbShipqty.toString());
			mpDangerousProdcut.put(ConstantsUtil.CON, sbCON.toString());
			mpDangerousProdcut.put(ConstantsUtil.OPR, sbOPR.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNSPECPACKGGREQUIRED, sbUSPGreq.toString());
			mpDangerousProdcut.put(ConstantsUtil.CUST, sbCust.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCUP, sbGCUP.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCOP, sbGCOP.toString());
			mpDangerousProdcut.put(ConstantsUtil.PHASE, sbPhase.toString());
			mpDangerousProdcut.put(ConstantsUtil.STATE, sbState.toString());
			// SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			mpDangerousProdcut.put(ConstantsUtil.TN1, sbTN1.toString());
			mpDangerousProdcut.put(ConstantsUtil.TN2, sbTN2.toString());
			mpDangerousProdcut.put(ConstantsUtil.NO, sbNo.toString());
			// SPEC: 10/09/2020: Added for 18x.5 DEV -- END

		} catch (Exception e) {
			LOGGER.error("Error from BusObjectAttribUtil:  getGHSProdcutValue" + e);
			return new HashMap();
		}
		return mpDangerousProdcut;
	}

	/**
	 * 
	 * @param context
	 * @param resultMaps
	 * @return
	 */

	public Map getWeightProdcutValue(Context context, Map resultMaps) {
		Map mpGlobalHarStandard = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();

		String strRev = ConstantsUtil.EMPTY_STRING;
		String strName = ConstantsUtil.EMPTY_STRING;
		String strTitle = ConstantsUtil.EMPTY_STRING;
		String strId = ConstantsUtil.EMPTY_STRING;
		String strTyp = ConstantsUtil.EMPTY_STRING;

		StringList slProductSelects = new StringList();
		slProductSelects.add(ConstantsUtil.SELECT_NAME);
		slProductSelects.add(ConstantsUtil.SELECT_REVISION);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);

		String sObjectId = validator
				.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID)
						: ConstantsUtil.EMPTY_STRING;

				try {
					if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
						//DomainObject doProductPart = new DomainObject(sObjectId);
						DomainObject doProductPart = DomainObject.newInstance(context, sObjectId);
						Map mpTemp = doProductPart.getInfo(context, slProductSelects);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
						doProductPart.close(context);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						strRev = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
						strName = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
						strTitle = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						strId = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.ID));
						strTyp = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
					}
					mpGlobalHarStandard.put(ConstantsUtil.MASTERPRODUCTPARTNAME, strName);
					mpGlobalHarStandard.put(ConstantsUtil.ID, strId);
					mpGlobalHarStandard.put(ConstantsUtil.TYPE, strTyp);
					mpGlobalHarStandard.put(ConstantsUtil.MASTERPRODUCTPARTREV, strRev);
					mpGlobalHarStandard.put(ConstantsUtil.MASTERPRODUCTPARTTITLE, strTitle);

				} catch (Exception e) {
					LOGGER.error("Error from BusObjectAttribUtil:  getGHSProdcutValue" + e);
					return new HashMap();
				}
				return mpGlobalHarStandard;
	}

	/**
	 * 
	 * @param context
	 * @param resultMaps
	 * @return
	 */

	public Map getStabilityWeightProdcutValue(Context context, Map resultMaps) {
		Map mpGlobalHarStandard = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();

		String strRev = ConstantsUtil.EMPTY_STRING;
		String strName = ConstantsUtil.EMPTY_STRING;
		String strTitle = ConstantsUtil.EMPTY_STRING;
		String strId = ConstantsUtil.EMPTY_STRING;
		String strTyp = ConstantsUtil.EMPTY_STRING;

		StringList slProductSelects = new StringList();
		slProductSelects.add(ConstantsUtil.SELECT_NAME);
		slProductSelects.add(ConstantsUtil.SELECT_REVISION);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);

		String sObjectId = validator
				.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID)
						: ConstantsUtil.EMPTY_STRING;

				try {
					if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
						//DomainObject doProductPart = new DomainObject(sObjectId);
						DomainObject doProductPart = DomainObject.newInstance(context, sObjectId);
						Map mpTemp = doProductPart.getInfo(context, slProductSelects);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
						doProductPart.close(context);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						strRev = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
						strName = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
						strTitle = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						strId = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.ID));
						strTyp = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
					}
					mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTNAME, strName);
					mpGlobalHarStandard.put(ConstantsUtil.ID, strId);
					mpGlobalHarStandard.put(ConstantsUtil.TYPE, strTyp);
					mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTREVISION, strRev);
					mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTTITLE, strTitle);

				} catch (Exception e) {
					LOGGER.error("Error from BusObjectAttribUtil:  getGHSProdcutValue" + e);
					return new HashMap();
				}
				return mpGlobalHarStandard;
	}

	/**
	 * 
	 * @param context
	 * @param strRootNode
	 * @param objectList
	 * @return
	 * @throws Exception
	 */

	public String getMappedTypeData(Context context, String sObjType) throws Exception
	
	{
		long startTime = System.currentTimeMillis();
		Vector vc = new Vector();
		boolean isContextPush = false;

		ContextUtil.pushContext(context, "User Agent", "", "");

		String strLocale = context.getLocale().getLanguage();

		isContextPush = true;
		String strTypeName = PropertyUtil.getSchemaProperty("type_pgPhase");

		Map mapCodeMapping = new HashMap();
		//modified by Ganesh for defect 38816 ------>start
		mapCodeMapping.put("pgReleasedSupplierList", "ASL");
		//modified by Ganesh for defect 38816 ------>end
		mapCodeMapping.put("pgApprovedSupplierList", "ASL");
		mapCodeMapping.put("pgArtwork", "ART");
		mapCodeMapping.put("pgBaseFormula", "BSF");
		mapCodeMapping.put("ECR", "CR");
		mapCodeMapping.put("pgCommonPerformanceSpecification", "CPST");
		mapCodeMapping.put("pgConsumerDesignBasis", "CDB");
		mapCodeMapping.put("pgFinishedProduct", "FP");
		mapCodeMapping.put("Finished Product Part", "FPP");
		mapCodeMapping.put("pgAncillaryPackagingMaterialPart", "APMP");
		mapCodeMapping.put("pgPromotionalItemPart", "PIP");
		mapCodeMapping.put("pgAuthorizedTemporarySpecification", "ATS");
		mapCodeMapping.put("pgOnlinePrintingPart", "OPP");
		mapCodeMapping.put("Packaging Material Part", "PMP");
		mapCodeMapping.put("Packaging Assembly Part", "PAP");
		mapCodeMapping.put("pgIllustration", "ILST");
		mapCodeMapping.put("pgLogisticSpec", "LOG");
		mapCodeMapping.put("pgMakingInstructions", "MI");
		mapCodeMapping.put("pgMasterPackingMaterial", "MPMS");
		mapCodeMapping.put("pgMasterRawMaterial", "MRMS");
		mapCodeMapping.put("pgMasterFinishedProduct", "MPS");
		mapCodeMapping.put("pgPackingMaterial", "MATL");
		mapCodeMapping.put("pgRawMaterial", "MATL");
		mapCodeMapping.put("Shared Table", "CPS");
		mapCodeMapping.put("pgNonGCASPart", "NGCAS");
		mapCodeMapping.put("pgPackingInstructions", "Packing Instruction");//Modified by Ketan for Req. no. 1563
		mapCodeMapping.put("pgPackingSubassembly", "PSUB");
		mapCodeMapping.put("pgProcessStandard", "PROS");
		mapCodeMapping.put("pgApplianceProduct", "APP");
		mapCodeMapping.put("pgAssembledProduct", "ASP");
		mapCodeMapping.put("pgFormulatedProduct", "FC");
		mapCodeMapping.put("pgQualitySpecification", "QUAL");
		mapCodeMapping.put("pgStackingPattern", "SPS");
		mapCodeMapping.put("pgStandardOperatingProcedure", "SOP");
		mapCodeMapping.put("pgSupplierInformationSheet", "SIS");
		mapCodeMapping.put("pgTestMethod", "TM");
		mapCodeMapping.put("Safety And Regulatory Characteristic", "SRS");
		mapCodeMapping.put("pgFormulatedMaterial", "FMATL");
		mapCodeMapping.put("pgMaterial", "MATL");
		mapCodeMapping.put("pgPPMConstituent", "Constituent");
		mapCodeMapping.put("pgMasterPackagingAssemblyPart", "MPAP");
		mapCodeMapping.put("pgMasterPackagingMaterialPart", "MPMP");
		mapCodeMapping.put("pgMasterConsumerUnitPart", "MCOP");
		mapCodeMapping.put("pgMasterCustomerUnitPart", "MCUP");
		mapCodeMapping.put("pgMasterInnerPackUnitPart", "MIP");
		mapCodeMapping.put("pgConsumerUnitPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgConsumerUnitPart", strLocale));
		mapCodeMapping.put("pgCustomerUnitPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgCustomerUnitPart", strLocale));
		mapCodeMapping.put("pgInnerPackUnitPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgInnerPackUnitPart", strLocale));
		mapCodeMapping.put("Finished Product Part",
				UINavigatorUtil.getAdminI18NString("Type", "Finished Product Part", strLocale));
		mapCodeMapping.put("pgPromotionalItemPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgPromotionalItemPart", strLocale));
		mapCodeMapping.put("pgAncillaryPackagingMaterialPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgAncillaryPackagingMaterialPart", strLocale));
		mapCodeMapping.put("pgFabricatedPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgFabricatedPart", strLocale));
		mapCodeMapping.put("pgDeviceProductPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgDeviceProductPart", strLocale));
		mapCodeMapping.put("pgAssembledProductPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgAssembledProductPart", strLocale));
		mapCodeMapping.put("pgMasterProductPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgMasterProductPart", strLocale));
		mapCodeMapping.put("Raw Material", UINavigatorUtil.getAdminI18NString("Type", "Raw Material", strLocale));
		mapCodeMapping.put("pgMasterRawMaterialPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgMasterRawMaterialPart", strLocale));
		mapCodeMapping.put("Formulation Part",
				UINavigatorUtil.getAdminI18NString("Type", "Formulation Part", strLocale));
		mapCodeMapping.put("pgAncillaryRawMaterialPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgAncillaryRawMaterialPart", strLocale));
		mapCodeMapping.put("Formula Technical Specification",
				UINavigatorUtil.getAdminI18NString("Type", "Formula Technical Specification", strLocale));
		mapCodeMapping.put("pgAuthorizedConfigurationStandard",
				UINavigatorUtil.getAdminI18NString("Type", "pgAuthorizedConfigurationStandard", strLocale));
		mapCodeMapping.put("pgIntermediateProductPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgIntermediateProductPart", strLocale));
		mapCodeMapping.put("pgRawMaterialPlantInstruction",
				UINavigatorUtil.getAdminI18NString("Type", "pgRawMaterialPlantInstruction", strLocale));
		mapCodeMapping.put("pgLaboratoryIndexSpecification",
				UINavigatorUtil.getAdminI18NString("Type", "pgLaboratoryIndexSpecification", strLocale));
		mapCodeMapping.put("pgTransportUnitPart",
				UINavigatorUtil.getAdminI18NString("Type", "pgTransportUnitPart", strLocale));
		mapCodeMapping.put("pgSoftwarePart", UINavigatorUtil.getAdminI18NString("Type", "pgSoftwarePart", strLocale));
		// <SPEC> 04/02/2021 Added by Govind for Defect #38816 start
		mapCodeMapping.put("pgReleasedSupplierList","ASL");
		// <SPEC> 04/02/2021 Added by Govind for Defect #38816 end
		//SPEC: <26.02.2021>: Guna Added for Dev 18x.6   -- START
		mapCodeMapping.put("pgSmartLabel","SML");
		//SPEC: <26.02.2021>: Guna Added for Dev 18x.6   -- END

		String strID = "";
		String strRootNode = "";
		String strAbbr = "";
		Map object = null;
		String strType = "";

		/*
		 * MapList mlFinal = new MapList(); for (Iterator iterator =
		 * objectList.iterator(); iterator.hasNext();) { object = (Map)
		 * iterator.next(); strID=(String)object.get(DomainConstants.SELECT_ID);
		 * strRootNode=(String)object.get("Root Node"); strType =
		 * (String)object.get("type");
		 */

		if (strTypeName.equalsIgnoreCase(sObjType)) {
			// vc.add("");
			// object.put(ConstantsUtil.TYPE, strType);
			// sObjType=sObjType;

			sObjType = "";
		}

		else if (!"true".equalsIgnoreCase(strRootNode)) {
			strAbbr = (String) mapCodeMapping.get(sObjType);

			if (strAbbr != null)
				// vc.add(strAbbr);
				// object.put(ConstantsUtil.TYPE, strAbbr);
				sObjType = strAbbr;

			else
				// vc.add(strType);
				// object.put(ConstantsUtil.TYPE, strType);
				sObjType = sObjType;
		} else {
			// vc.add("");
			// object.put(ConstantsUtil.TYPE, "");
			sObjType = "";
		}

		// mlFinal.add(object);

		return sObjType;

	}

	//SPEC: 06-011-2020: Modified for 18x.6.0.1 Defect# 43450 by Sanjeeva -- START
	//SPEC: 06-02-2020: Added for 18x.6.0.1 Defect# 43058 by Sanjeeva -- START
	/**
	 * 
	 * @param sType
	 * @param strLocale
	 * @return sType
	 * @throws Exception
	 */
	public String mapVendorServiceType(String sType, String strLocale) throws Exception {
		if (null != sType) {
			switch (sType.trim()) {
			case "pgAncillaryPackagingMaterialPart":
				//SPEC: 06-10-2020: Added for 18x.6.0.1 Defect# 43450 by Sanjeeva -- START
				//sType = UINavigatorUtil.getAdminI18NString("Type", ConstantsUtil.TYPE_ANCILLARYPACKAGINGMATERIALPART, strLocale);
				sType = "Ancillary Packaging Material Part";
				//SPEC: 06-10-2020: Added for 18x.6.0.1 Defect# 43450 by Sanjeeva -- END
				break;
			case "pgConsumerUnitPart":
				sType = "Consumer Unit Part";
				break;
			case "pgCustomerUnitPart":
				sType = "Customer Unit Part"; 
				break;
			case "pgFabricatedPart":
				sType = "Fabricated Part";
				break;
			//SPEC: 06-03-2022: Added for req #43495 by Satyam -- START
			case "pgFinishedProduct":
				// Satyam
				sType = "Finished Product";
				break;
			case "Finished Product Part":
				// Satyam
				sType = "Finished Product Part";
				break;
			case "pgFormulatedProduct":
				sType = "FC";
				break;
			case "pgInnerPackUnitPart":
				// Satyam
				sType = "Inner Pack";
				break;
			case "pgMasterConsumerUnitPart":
				// Satyam
				sType = "Master Consumer Unit Part";
				break;
			case "pgMasterCustomerUnitPart":
				// Satyam
				sType = "Master Customer Unit Part";
				break;
			case "pgMasterInnerPackUnitPart":
				// Satyam
				sType = "Master Inner Pack";
				break;
			case "pgMasterPackagingAssemblyPart":
				// Satyam
				sType = "Master Packaging Assembly Part";
				break;
			case "pgMasterPackagingMaterialPart":
				// Satyam
				sType = "Master Packaging Material Part";
				break;
			case "pgMasterPackingMaterial":
				// Satyam
				sType = "Master Packaging Material Part";
				break;
			//SPEC: 06-03-2022: Added for req #43495 by Satyam -- END
			case "pgMasterFinishedProduct":
				sType = "MPS";
				break;
			case "pgMasterRawMaterial":
				sType = "Master Raw Material Part"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgMaterialComposition":
				sType = "pgMaterialComposition";
				break;
			case "Packaging Material Part":
				sType = "Packaging Material Part"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgPackingMaterial":
				sType = "Packaging Material Part";
				break;
			case "pgOnlinePrintingPart":
				sType = "Online Printing Part"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "Packaging Assembly Part":
				sType = "Packaging Assembly Part"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgPackingSubassembly":
				sType = "Packing Subassembly Part"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgPromotionalItemPart":
				//SPEC: 06-14-2020: Modified for 18x.6.0.1 for Defect#43541 by Sanjeeva -- START
				//sType = "PIP";
				sType = "Promotional Item Part";
				//SPEC: 06-14-2020: Modified for 18x.6.0.1 for Defect#43541 by Sanjeeva -- END
				break;
			case "pgTransportUnitPart":
				sType = "Transport Unit Part";
				break;
				//SPEC: 06-07-2020: Added for 18x.6.0.1 for internal defect by Sanjeeva -- SANJEEVA
			case "pgArtwork":
				sType = "ART/POA"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "POA":
				sType = "POA";
				//SPEC: 06-07-2020: Added for 18x.6.0.1 for internal defect by Sanjeeva -- END
				break;
			case "pgAuthorizedTemporarySpecification":
				sType = "Authorized Temporary Specification"; // SPEC: Modified by Ketan for req no. 43495
				break;
			//Added by Ketan for Req no. 47957 -- START
			case "pgStructuredATS":
				sType = "Structured Authorized Temporary Standard";
				break;
			//Added by Ketan for Req no. 47957 -- END
			case "pgIllustration":
				sType = "Illustration"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgMakingInstructions":
				sType = "Making Instruction"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgPackingInstructions":
				sType = "Packing Instruction"; //Modified by Ketan for Req no. 1563
				break;
			case "pgProcessStandard":
				sType = "Process Standard "; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgQualitySpecification":
				sType = "Quality Specification"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgStackingPattern":
				sType = "Stacking Pattern Specification"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgStandardOperatingProcedure":
				sType = "Standard Operating Procedure"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgSupplierInformationSheet":
				sType = "SIS";
				break;
			case "pgTestMethod":
			case "Test Method":
			case "Test Method Specification":
				sType = "Test Method Specification";
				break;
			case "pgAssembledProductPart":
				sType = "Assembled Product Part";
				break;
			case "pgDeviceProductPart":
				sType = "Device Product Part";
				break;
			case "Raw Material Part":
				sType = "RMP";
				break;
			case "pgRawMaterial":
				sType = "Raw Material IRMS";
				break;
			case "Raw Material":
				sType = "Raw Material";
				break;
			case "Formulation Part":
				sType = "Formulation Part";
				break;
			case "pgMasterProductPart":
				sType = "Master Product Part";
				break;

			case "pgMasterRawMaterialPart":
				//SPEC: 06-14-2020: Modified for 18x.6.0.1 for Defect#43541 by Sanjeeva -- START
				//sType = "MRMP";
				sType = "Master Raw Material Part";
				//SPEC: 06-14-2020: Modified for 18x.6.0.1 for Defect#43541 by Sanjeeva -- END

				break;
			case "pgAuthorizedConfigurationStandard":
				sType = "Authorized Configuration Standard";
				break;
			case "Formula Technical Specification":
				//SPEC: 06-10-2020: Added for 18x.6.0.1 Defect# 43675 by Sanjeeva -- START
				//sType = "Formula Technical Specification";
				sType = "Intermediate Assembled Product Specification";
				//SPEC: 06-10-2020: Added for 18x.6.0.1 Defect# 43675 by Sanjeeva -- END
				break;
			case "pgAncillaryRawMaterialPart":
				//SPEC: 06-10-2020: Added for 18x.6.0.1 Defect# 43450 by Sanjeeva -- START
				//sType = UINavigatorUtil.getAdminI18NString("Type", "pgAncillaryRawMaterialPart", strLocale);
				sType = "Ancillary Raw Material Part";
				//SPEC: 06-10-2020: Added for 18x.6.0.1 Defect# 43450 by Sanjeeva -- END
				break;
			case "pgIntermediateProductPart":
				sType = "Intermediate Product Part";
				break;
			case "pgRawMaterialPlantInstruction":
				sType = "Raw Material Plant Instruction"; // SPEC: Modified by Ketan for req no. 43495
				break;
			case "pgLaboratoryIndexSpecification":
				sType = "Laboratory Index Specification";
				break;
			case "pgSoftwarePart":
				sType = "Software Part";
				break;
				// SPEC: Added by Ketan for req no. 43495 -- START
			case "Qualification":
				sType = "Part Qualification Record";
				break;
				// SPEC: Added by Ketan for req no. 43495 -- END
			}
		}
		return sType;

	}

	//SPEC: 06-02-2020: Added for 18x.6.0.1 Defect# 43058 by Sanjeeva -- END
	//SPEC: 06-011-2020: Modified for 18x.6.0.1 Defect# 43450 by Sanjeeva -- END



	/**
	 * Check ATS Flag
	 * 
	 * @param sName
	 * @param sCurrent
	 * @return
	 */

	public String checkIsATSAttribute(String sName, String sCurrent) {

		StringList slObsoleteATS = new StringList();
		String sATS = "";
		try {
			StringList slName = getStringList(sName);
			StringList slCurrent = getStringList(sCurrent);
			for (int i = 0; i < slCurrent.size(); i++) {
				if (slCurrent.get(i).equals(ConstantsUtil.STATE_OBSOLETE)) {
					slObsoleteATS.add(slCurrent.get(i));
				}
			}
			if (slName.size() != 0) {
				if (slObsoleteATS.size() == slName.size()) {
					sATS = "No";
				} else {
					sATS = "Yes";
				}
			}
		} catch (Exception e) {
		}
		return sATS;
	}

	public Map updatePerformCharcteristicforMPS(Context context, MapList mlFinalList, Map resultMap) {

		StringValidatorUtil validator = new StringValidatorUtil();
		// START:: gaikwad.tg
		StringBuilder sCPS = new StringBuilder();
		StringBuilder sCPSName = new StringBuilder();
		StringBuilder sCPSId = new StringBuilder();
		// END:: gaikwad.tg
		String sType = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.SELECT_TYPE))
				? (String) resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
				boolean isExternal=isModificatinRequired();
				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- END

				StringBuilder schg = new StringBuilder();
				StringBuilder sCharcteristic = new StringBuilder();
				StringBuilder sbPathId = new StringBuilder();
				StringBuilder sbPathType = new StringBuilder();
				StringBuilder sCharSpec = new StringBuilder();
				StringBuilder sPath = new StringBuilder();
				StringBuilder sTMNActual = new StringBuilder();
				StringBuilder sTMNActualID = new StringBuilder();
				StringBuilder sTMNActualType = new StringBuilder();
				StringBuilder sTMName = new StringBuilder();
				StringBuilder sTMLogic = new StringBuilder();
				StringBuilder sMethodOrigin = new StringBuilder();
				StringBuilder sMethodNumber = new StringBuilder();
				StringBuilder sMethodSpecific = new StringBuilder();
				StringBuilder sTMNameID = new StringBuilder();
				StringBuilder sTMNameType = new StringBuilder();
				StringBuilder sSampling = new StringBuilder();
				StringBuilder sSubGroup = new StringBuilder();

				StringBuilder sPlantTesting = new StringBuilder();
				StringBuilder sPlantRetesting = new StringBuilder();
				StringBuilder sTestingUOM = new StringBuilder();

				StringBuilder sLowerSpecLimit = new StringBuilder();
				StringBuilder sLowerRoutineReleaseLimit = new StringBuilder();
				StringBuilder sPGLowerTarget = new StringBuilder();
				StringBuilder sPGTarget = new StringBuilder();
				StringBuilder sPGUpperTarget = new StringBuilder();
				StringBuilder sUpperRoutineRL = new StringBuilder();
				StringBuilder sPGUpperSpecLimit = new StringBuilder();

				StringBuilder sUnitOfMeasure = new StringBuilder();
				StringBuilder sPGReportNear = new StringBuilder();
				StringBuilder sPGReportType = new StringBuilder();
				StringBuilder sReleseCriteria = new StringBuilder();

				StringBuilder sPGACtionRequired = new StringBuilder();
				StringBuilder sCriticalFactor = new StringBuilder();
				StringBuilder sPGBasis = new StringBuilder();

				StringBuilder sPTestGroup = new StringBuilder();
				StringBuilder sPApplication = new StringBuilder();
				StringBuilder sPMTitle = new StringBuilder();

				Iterator objectListItr = mlFinalList.iterator();
				Map<String, String> mpFinal = new HashMap<String, String>();

				/*
				 * if(mlFinalList.size()==0) { return new HashMap(); }
				 */

				try {

					while (objectListItr.hasNext()) {
						Map objectMap = (Map) objectListItr.next();

						/**
						 * Logic for CPS
						 */
						// START :: gaikwad.tg
						/*
						 * String sForCPSType = validator.isNotNullOrEmpty((String)
						 * objectMap.get(ConstantsUtil.SELECT_TYPE)) ? (String)
						 * resultMap.get(ConstantsUtil.SELECT_TYPE) :
						 * ConstantsUtil.EMPTY_STRING;
						 * 
						 * String sForCPSName = validator.isNotNullOrEmpty((String)
						 * objectMap.get(ConstantsUtil.SELECT_NAME)) ? (String)
						 * resultMap.get(ConstantsUtil.SELECT_TYPE) :
						 * ConstantsUtil.EMPTY_STRING;
						 */

						String sForCPSType = validator
								.getStringEquivalentForSubstituteString((String) objectMap.get(ConstantsUtil.SELECT_TYPE));

						String sForCPSName = validator
								.getStringEquivalentForSubstituteString((String) objectMap.get(ConstantsUtil.SELECT_NAME));
						String sForCPSId = validator
								.getStringEquivalentForSubstituteString((String) objectMap.get(ConstantsUtil.SELECT_ID));
						// END :: gaikwad.tg
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
						/*if (sForCPSType.equalsIgnoreCase("Shared Table")) {
					// START:: gaikwad.tg
					sCPS.append(sForCPSName).append("|");
					sCPSName.append(sForCPSName).append("|");
					sCPSId.append(sForCPSId).append("|");
					// END :: gaikwad.tg
				} else {
					// START :: gaikwad.tg

						 * String sCPSCharName = validator.isNotNullOrEmpty((String)
						 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME)) ?
						 * (String)
						 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME) :
						 * ConstantsUtil.EMPTY_STRING; String sCPSCharType =
						 * validator.isNotNullOrEmpty((String)
						 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE)) ?
						 * (String)
						 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE) :
						 * ConstantsUtil.EMPTY_STRING; String sCPSCharID =
						 * validator.isNotNullOrEmpty((String)
						 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID)) ?
						 * (String)
						 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID) :
						 * ConstantsUtil.EMPTY_STRING;
						 * sCPS.append(sCPSCharName).append("|");

					String sCPSCharName = validator.getStringEquivalentForSubstituteString(
							(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME));
					String sCPSCharType = validator.getStringEquivalentForSubstituteString(
							(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE));
					String sCPSCharID = validator.getStringEquivalentForSubstituteString(
							(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID));
					// END :: gaikwad.tg
					sCPS.append(sCPSCharName).append("|");
					// START :: gaikwad.tg
					sCPSName.append(sCPSCharName).append("|");
					sCPSId.append(sCPSCharID).append("|");
					// END :: gaikwad.tg
				}*/
						// System.out.println("CPS Name :" + sCPS.toString());

						String sPathId = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_ID));
						//modified by for Defect 38256 Release 18x.5.2---->start
						boolean showData = checkHasAccess(context, null, sPathId);
						if(!showData)
						{
							if(isExternal)
								continue;
							else
								sPathId = ConstantsUtil.NO_ACCESS;
						}
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- END
						// START :: gaikwad.tg
						/*
						 * String sPchg = validator .isNotNullOrEmpty((String)
						 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE)) ?
						 * ((String)
						 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE)) :
						 * ConstantsUtil.EMPTY_STRING; String sPCharcteristic =
						 * validator .isNotNullOrEmpty((String)
						 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC
						 * )) ? (String) objectMap.get(ConstantsUtil.
						 * SELECT_ATTRIBUTE_PGCHARACTERISTIC) :
						 * ConstantsUtil.EMPTY_STRING; String sPCharSpec =
						 * validator.isNotNullOrEmpty( (String)
						 * objectMap.get(ConstantsUtil.
						 * SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS)) ? (String)
						 * objectMap.get(ConstantsUtil.
						 * SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS) :
						 * ConstantsUtil.EMPTY_STRING;
						 */
						String sPchg = validator.getStringEquivalentForSubstituteString(
								(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
						String sPCharcteristic = validator.getStringEquivalentForSubstituteString(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC));
						String sPCharSpec = validator.getStringEquivalentForSubstituteString(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS));
						/*
						 * String sPPath = validator.isNotNullOrEmpty((String)
						 * objectMap.get(ConstantsUtil.PATH)) ? (String)
						 * objectMap.get(ConstantsUtil.PATH) :
						 * ConstantsUtil.EMPTY_STRING;
						 */
						String sPPath = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.PATH));
						// END :: gaikwad.tg
						String sPTMName = ConstantsUtil.EMPTY_STRING;
						String sPTMNameActual = ConstantsUtil.EMPTY_STRING;
						String sPTMNameID = ConstantsUtil.EMPTY_STRING;
						String sPTMNameActualID = ConstantsUtil.EMPTY_STRING;
						String sPTMNameActualType = ConstantsUtil.EMPTY_STRING;
						String sPTMType = ConstantsUtil.EMPTY_STRING;
						// Guna Added for Defect 38346 18x.5.2 Release -- START
						String sPTMMutliName = ConstantsUtil.EMPTY_STRING;
						// Guna Added for Defect 38346 18x.5.2 Release -- END

						boolean sClass = objectMap.containsKey(ConstantsUtil.SELECT_REF_DOC_TONAME);
						if (sClass) {
							String sClassName = objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME).getClass().getSimpleName();
							if (sClassName.equals(ConstantsUtil.STRING)) {
								if (isModificatinRequired()) {
									// START :: gaikwad.tg
									/*
									 * sPTMName = validator .isNotNullOrEmpty((String)
									 * objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME
									 * )) ? (String) objectMap.get(ConstantsUtil.
									 * SELECT_REF_DOC_TONAME) :
									 * ConstantsUtil.EMPTY_STRING; sPTMType = validator
									 * .isNotNullOrEmpty((String)
									 * objectMap.get(ConstantsUtil.
									 * SELECT_REF_DOC_TO_TYPE)) ? (String)
									 * objectMap.get(ConstantsUtil.
									 * SELECT_REF_DOC_TO_TYPE) :
									 * ConstantsUtil.EMPTY_STRING; String
									 * sTMHasSharedAccess =
									 * validator.isNotNullOrEmpty((String) objectMap
									 * .get(ConstantsUtil.
									 * SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS))
									 * ? (String) objectMap .get(ConstantsUtil.
									 * SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS) :
									 * ConstantsUtil.EMPTY_STRING; sPTMNameID =
									 * validator .isNotNullOrEmpty((String)
									 * objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
									 * ) ? (String)
									 * objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
									 * : ConstantsUtil.EMPTY_STRING;
									 */

									// SPEC: Release SR18x.5.2 - Modified for Defect
									// 38361 by Amman ## -- START
									/*
									 * sPTMName =
									 * validator.getStringEquivalentForSubstituteString(
									 * ConstantsUtil.SELECT_REF_DOC_TONAME); sPTMType =
									 * validator.getStringEquivalentForSubstituteString(
									 * ConstantsUtil.SELECT_REF_DOC_TO_TYPE); String
									 * sTMHasSharedAccess =
									 * validator.getStringEquivalentForSubstituteString(
									 * ConstantsUtil.
									 * SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);
									 * sPTMNameID =
									 * validator.getStringEquivalentForSubstituteString(
									 * ConstantsUtil.SELECT_REF_DOC_TO_ID);
									 */
									sPTMName = validator.getStringEquivalentForSubstituteString(
											objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME));
									sPTMType = validator.getStringEquivalentForSubstituteString(
											objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE));
									String sTMHasSharedAccess = validator.getStringEquivalentForSubstituteString(
											objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS));
									sPTMNameID = validator.getStringEquivalentForSubstituteString(
											objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID));
									// Guna Added for Defect 38346 18x.5.2 Release -- START
									sPTMMutliName =validator.getStringEquivalentForSubstituteString(
											objectMap.get(ConstantsUtil.SELECT_TEST_METHOD_TONAME));
									if(UIUtil.isNotNullAndNotEmpty(sPTMMutliName)){
										sPTMName =sPTMName+ConstantsUtil.SYMBL_COMMA+sPTMMutliName;
										sPTMNameID =sPTMNameID+ConstantsUtil.SYMBL_COMMA+validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_TEST_METHOD_TOID));
									}
									// Guna Added for Defect 38346 18x.5.2 Release -- END
									// SPEC: Release SR18x.5.2 - Modified for Defect
									// 38361 by Amman ## -- END

									// END :: gaikwad.tg
									if ((sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION))) {
										if (ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) {
											formatData(sTMName, sPTMName);
											formatData(sTMNameID, sPTMNameID);
											formatData(sTMNameType, sPTMType);
										} else {
											//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
											continue;
											/*formatData(sTMName, sPTMName);
									formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
									formatData(sTMNameType, sPTMType);*/
											//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- END
										}

									}

									if (sPTMType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)) {
										// START :: gaikwad.tg
										/*
										 * sPTMNameActual = validator
										 * .isNotNullOrEmpty((String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TONAME)) ? (String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TONAME) :
										 * ConstantsUtil.EMPTY_STRING;
										 * sPTMNameActualType = validator
										 * .isNotNullOrEmpty((String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_TYPE)) ? (String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_TYPE) :
										 * ConstantsUtil.EMPTY_STRING;
										 * sTMHasSharedAccess =
										 * validator.isNotNullOrEmpty((String) objectMap
										 * .get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS
										 * )) ? (String) objectMap.get( ConstantsUtil.
										 * SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS)
										 * : ConstantsUtil.EMPTY_STRING;
										 * sPTMNameActualID = validator
										 * .isNotNullOrEmpty((String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_ID)) ? (String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_ID) :
										 * ConstantsUtil.EMPTY_STRING;
										 */

										// SPEC: Release SR18x.5.2 - Modified for Defect
										// 38361 by Amman ## -- START
										/*
										 * sPTMNameActual = validator.
										 * getStringEquivalentForSubstituteString(
										 * ConstantsUtil.SELECT_REF_DOC_TONAME);
										 * sPTMNameActualType = validator.
										 * getStringEquivalentForSubstituteString(
										 * ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
										 * sTMHasSharedAccess = validator.
										 * getStringEquivalentForSubstituteString(
										 * ConstantsUtil.
										 * SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS
										 * ); sPTMNameActualID = validator.
										 * getStringEquivalentForSubstituteString(
										 * ConstantsUtil.SELECT_REF_DOC_TO_ID);
										 */
										sPTMNameActual = validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME));
										sPTMNameActualType = validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE));
										sTMHasSharedAccess = validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS));
										sPTMNameActualID = validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID));
										// SPEC: Release SR18x.5.2 - Modified for Defect
										// 38361 by Amman ## -- END

										// END :: gaikwad.tg
										if (ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) {
											formatData(sTMNActual, sPTMName);
											formatData(sTMNActualID, sPTMNameActual);
											formatData(sTMNActualType, sPTMType);
										} else {
											//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
											continue;
											/*formatData(sTMNActual, sPTMName);
									formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
									formatData(sTMNActualType, sPTMType);*/
											//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- END
										}

									}
								} else {
									// START :: gaikwad.tg
									/*
									 * sPTMType = validator .isNotNullOrEmpty((String)
									 * objectMap.get(ConstantsUtil.
									 * SELECT_REF_DOC_TO_TYPE)) ? (String)
									 * objectMap.get(ConstantsUtil.
									 * SELECT_REF_DOC_TO_TYPE) :
									 * ConstantsUtil.EMPTY_STRING;
									 */
									// SPEC: Release SR18x.5.2 - Modified for Defect
									// 38361 by Amman ## -- START
									// sPTMType =
									// validator.getStringEquivalentForSubstituteString(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
									sPTMType = validator.getStringEquivalentForSubstituteString(
											objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE));
									// SPEC: Release SR18x.5.2 - Modified for Defect
									// 38361 by Amman ## -- END
									if (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {

										/*
										 * sPTMName = validator
										 * .isNotNullOrEmpty((String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TONAME)) ? (String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TONAME) :
										 * ConstantsUtil.EMPTY_STRING; sPTMNameID =
										 * validator .isNotNullOrEmpty((String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_ID)) ? (String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_ID) :
										 * ConstantsUtil.EMPTY_STRING;
										 */

										// SPEC: Release SR18x.5.2 - Modified for Defect
										// 38361 by Amman ## -- START
										/*
										 * sPTMName = validator.
										 * getStringEquivalentForSubstituteString(
										 * ConstantsUtil.SELECT_REF_DOC_TONAME);
										 * sPTMNameID = validator.
										 * getStringEquivalentForSubstituteString(
										 * ConstantsUtil.SELECT_REF_DOC_TO_ID);
										 */
										sPTMName = validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME));
										sPTMNameID = validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID));
										sPTMMutliName =validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_TEST_METHOD_TONAME));
										// Guna Added for Defect 38346 18x.5.2 Release -- START
										if(UIUtil.isNotNullAndNotEmpty(sPTMMutliName)){
											sPTMName =sPTMName+ConstantsUtil.SYMBL_COMMA+sPTMMutliName;
											sPTMNameID =sPTMNameID+ConstantsUtil.SYMBL_COMMA+validator.getStringEquivalentForSubstituteString(
													objectMap.get(ConstantsUtil.SELECT_TEST_METHOD_TOID));
										}
										// Guna Added for Defect 38346 18x.5.2 Release -- END
										// SPEC: Release SR18x.5.2 - Modified for Defect
										// 38361 by Amman ## -- END

										// END :: gaikwad.tg
										formatData(sTMName, sPTMName);
										formatData(sTMNameID, sPTMNameID);
										formatData(sTMNameType, sPTMType);
									} else {
										// START :: gaikwad.tg
										/*
										 * sPTMNameActual = validator
										 * .isNotNullOrEmpty((String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TONAME)) ? (String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TONAME) :
										 * ConstantsUtil.EMPTY_STRING;
										 * sPTMNameActualType = validator
										 * .isNotNullOrEmpty((String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_TYPE)) ? (String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_TYPE) :
										 * ConstantsUtil.EMPTY_STRING; sPTMNameActualID
										 * = validator .isNotNullOrEmpty((String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_ID)) ? (String)
										 * objectMap.get(ConstantsUtil.
										 * SELECT_REF_DOC_TO_ID) :
										 * ConstantsUtil.EMPTY_STRING;
										 */

										// SPEC: Release SR18x.5.2 - Modified for Defect
										// 38361 by Amman ## -- START
										/*
										 * sPTMNameActual = validator.
										 * getStringEquivalentForSubstituteString(
										 * ConstantsUtil.SELECT_REF_DOC_TONAME);
										 * sPTMNameActualType = validator.
										 * getStringEquivalentForSubstituteString(
										 * ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
										 * sPTMNameActualID = validator.
										 * getStringEquivalentForSubstituteString(
										 * ConstantsUtil.SELECT_REF_DOC_TO_ID);
										 */
										sPTMNameActual = validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME));
										sPTMNameActualType = validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE));
										sPTMNameActualID = validator.getStringEquivalentForSubstituteString(
												objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID));
										// SPEC: Release SR18x.5.2 - Modified for Defect
										// 38361 by Amman ## -- END

										// END :: gaikwad.tg
										formatData(sTMNActual, sPTMNameActual);
										formatData(sTMNActualID, sPTMNameActualID);
										formatData(sTMNActualType, sPTMNameActualType);
									}
								}
							} else {

								StringList slTMName = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME);
								StringList slTMType = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
								StringList slsChildObjectID = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID);
								StringList slTMHasSharedAccess = (StringList) objectMap
										.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);
								// Guna Added for Defect 38346 18x.5.2 Release -- START				
								StringList slTMNameList = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.SELECT_TEST_METHOD_TONAME));
								if(slTMNameList.size() !=0){
									slTMName.addAll(slTMNameList);
									slTMType.addAll(validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.SELECT_TEST_METHOD_TOTYPE)));
									slsChildObjectID.addAll(validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.SELECT_TEST_METHOD_TOID)));
								}
								// Guna Added for Defect 38346 18x.5.2 Release -- END
								if (isModificatinRequired()) {
									Map<String, StringList> mpTemp = new HashMap<String, StringList>();
									mpTemp.put(ConstantsUtil.TYPE, slTMType);
									mpTemp.put(ConstantsUtil.NAME, slTMName);
									mpTemp.put(ConstantsUtil.SECURITY, slTMHasSharedAccess);
									mpTemp.put(ConstantsUtil.ID, slsChildObjectID);

									Map mpTemp1 = showOrHideSOPAndTM(context, mpTemp);
									slTMName = (StringList) mpTemp1.get(ConstantsUtil.NAME);
									slTMType = (StringList) mpTemp1.get(ConstantsUtil.TYPE);
									slsChildObjectID = (StringList) mpTemp1.get(ConstantsUtil.ID);
								}

								Map mpTemp2 = removeTestMethod(context, slTMName, slTMType, slsChildObjectID);

								StringList slTMFilteredName = (StringList) mpTemp2.get(ConstantsUtil.TMFILNAME);
								StringList slTMFilterID = (StringList) mpTemp2.get(ConstantsUtil.TMFILID);
								StringList slTMFilterType = (StringList) mpTemp2.get(ConstantsUtil.TMFILTYPE);

								slTMType = (StringList) mpTemp2.get(ConstantsUtil.BASETYPE);
								slTMName = (StringList) mpTemp2.get(ConstantsUtil.BASENAME);
								slsChildObjectID = (StringList) mpTemp2.get(ConstantsUtil.BASEID);
								// START :: gaikwad.tg
								/*
								 * sPTMName =
								 * validator.isNotNullOrEmpty(slTMName.toString()) ?
								 * slTMName.toString() : ConstantsUtil.EMPTY_STRING;
								 */

								sPTMName = validator.getStringEquivalentForSubstituteString(slTMName.toString());
								// END :: gaikwad.tg
								sPTMName = sPTMName.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
								// START :: gaikwad.tg
								/*
								 * sPTMNameID =
								 * validator.isNotNullOrEmpty(slsChildObjectID.toString(
								 * )) ? slsChildObjectID.toString() :
								 * ConstantsUtil.EMPTY_STRING;
								 */

								sPTMNameID = validator.getStringEquivalentForSubstituteString(slsChildObjectID.toString());
								// END :: gaikwad.tg
								sPTMNameID = sPTMNameID.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
								// START :: gaikwad.tg
								/*
								 * sPTMType =
								 * validator.isNotNullOrEmpty(slTMType.toString()) ?
								 * slTMType.toString() : ConstantsUtil.EMPTY_STRING;
								 */
								sPTMType = validator.getStringEquivalentForSubstituteString(slTMType.toString());
								// END :: gaikwad.tg
								sPTMType = sPTMType.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

								formatData(sTMNActual, sPTMName);

								if (isModificatinRequired()) {
									// modified by Ganesh for security impl------>start
									// boolean bHasOwnership = checkOwnerShip(context,
									// sPTMNameID);
									boolean bHasOwnership = checkHasAccess(context, null, sPTMNameID);
									// modified by Ganesh for security impl------>start
									if (bHasOwnership)
										sPTMNameID = sPTMNameID;
									else
										//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
										continue;
									//sPTMNameID = "";
									//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- END
								}

								formatData(sTMNActualID, sPTMNameID);
								formatData(sTMNActualType, sPTMType);
								// START :: gaikwad.tg
								sPTMNameActual = validator.getStringEquivalentForSubstituteString(slTMFilteredName.toString());
								/*
								 * sPTMNameActual =
								 * validator.isNotNullOrEmpty(slTMFilteredName.toString(
								 * )) ? slTMFilteredName.toString() :
								 * ConstantsUtil.EMPTY_STRING;
								 */
								sPTMNameActual = sPTMNameActual
										.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

								/*
								 * sPTMNameActualID =
								 * validator.isNotNullOrEmpty(slTMFilterID.toString()) ?
								 * slTMFilterID.toString() : ConstantsUtil.EMPTY_STRING;
								 */
								sPTMNameActualID = validator.getStringEquivalentForSubstituteString(slTMFilterID.toString());
								// END :: gaikwad.tg
								sPTMNameActualID = sPTMNameActualID
										.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
								// START :: gaikwad.tg
								/*
								 * sPTMNameActualType =
								 * validator.isNotNullOrEmpty(slTMFilterType.toString())
								 * ? slTMFilterType.toString() :
								 * ConstantsUtil.EMPTY_STRING;
								 */
								sPTMNameActualType = validator
										.getStringEquivalentForSubstituteString(slTMFilterType.toString());
								// END :: gaikwad.tg
								sPTMNameActualType = sPTMNameActualType
										.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

								formatData(sTMName, sPTMNameActual);
								formatData(sTMNameID, sPTMNameActualID);
								formatData(sTMNameType, sPTMNameActualType);

							}

						} else {
							formatData(sTMName, sPTMNameActual);
							formatData(sTMNameID, sPTMNameActualID);
							formatData(sTMNameType, sPTMNameActualType);

							formatData(sTMNActual, sPTMName);
							formatData(sTMNActualID, sPTMNameID);
							formatData(sTMNActualType, sPTMType);
						}

						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- START
						if (sForCPSType.equalsIgnoreCase("Shared Table")) {
							// START:: gaikwad.tg
							sCPS.append(sForCPSName).append("|");
							sCPSName.append(sForCPSName).append("|");
							sCPSId.append(sForCPSId).append("|");
							// END :: gaikwad.tg
						} else {
							// START :: gaikwad.tg
							/*
							 * String sCPSCharName = validator.isNotNullOrEmpty((String)
							 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME)) ?
							 * (String)
							 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME) :
							 * ConstantsUtil.EMPTY_STRING; String sCPSCharType =
							 * validator.isNotNullOrEmpty((String)
							 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE)) ?
							 * (String)
							 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE) :
							 * ConstantsUtil.EMPTY_STRING; String sCPSCharID =
							 * validator.isNotNullOrEmpty((String)
							 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID)) ?
							 * (String)
							 * objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID) :
							 * ConstantsUtil.EMPTY_STRING;
							 * sCPS.append(sCPSCharName).append("|");
							 */
							String sCPSCharName = validator.getStringEquivalentForSubstituteString(
									(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME));
							String sCPSCharType = validator.getStringEquivalentForSubstituteString(
									(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSTYPE));
							String sCPSCharID = validator.getStringEquivalentForSubstituteString(
									(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CPSID));
							// END :: gaikwad.tg
							sCPS.append(sCPSCharName).append("|");
							// START :: gaikwad.tg
							sCPSName.append(sCPSCharName).append("|");
							sCPSId.append(sCPSCharID).append("|");
							// END :: gaikwad.tg
						}

						/*String sPathId = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_ID));
				//modified by for Defect 38256 Release 18x.5.2---->start
				boolean showData = checkHasAccess(context, null, sPathId);
				if(!showData)
				{
				sPathId = ConstantsUtil.NO_ACCESS;
				}*/
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 12 May 2021 -- END
						//modified by for Defect 38256 Release 18x.5.2---->end
						String sPathType = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_TYPE));

						String sPTMLogic = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC));
						String sPMethodOrigin = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN));
						String sPMethodNumber = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER));
						String sPMethodSpecific = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS));
						sPMethodSpecific = sPMethodSpecific.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_AND);
						String sPSampling = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING));
						// SPEC: Added for 18x.5.2 DEV --Guna -- START
						sPSampling = sPSampling.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_AND);
						// SPEC: Added for 18x.5.2 DEV --Guna -- END
						String sPSubGroup = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP));
						String sPPlantTesting = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING));
						String sPPlantRetesting = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING));
						String sPTestingUOM = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM));
						String sPLowerSpecLimit = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT));
						String sPLowerRoutineReleaseLimit = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT));
						String sPPGLowerTarget = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET));
						String sPPGTarget = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET));
						String sPPGUpperTarget = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET));
						String sPUpperRoutineRL = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT));
						String sPPGUpperSpecLimit = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT));
						String sPUnitOfMeasure = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE));
						String sPPGReportNear = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST));
						String sPPGReportType = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE));

						String sPReleseCriteria = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA));
						// SPEC: Added for 18x.5.2 DEV --Guna -- START
						sPReleseCriteria = sPReleseCriteria.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_AND);
						// SPEC: Added for 18x.5.2 DEV --Guna -- END

						String sPPGACtionRequired = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED));
						String sPCriticalFactor = validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR));
						String sPPGBasis = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS));
						// SPEC: Added for 18x.5.2 DEV --Guna -- START
						sPPGBasis = sPPGBasis.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_AND);
						// SPEC: Added for 18x.5.2 DEV --Guna -- END
						String sTestGroup = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP));
						String sApplication = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION));

						String sTitle = ConstantsUtil.EMPTY_STRING;

						boolean bPresent = objectMap.containsKey(ConstantsUtil.PERFORMCHAR_MPT_TITLE);
						if (bPresent) {
							sTitle = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_MPT_TITLE));
						} else {
							sTitle = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						}

						formatData(sbPathId, sPathId);
						formatData(sbPathType, sPathType);
						formatData(sPath, sPPath);

						formatData(schg, sPchg);
						formatData(sCharcteristic, sPCharcteristic);
						formatData(sCharSpec, sPCharSpec);

						formatData(sTMLogic, sPTMLogic);
						formatData(sMethodOrigin, sPMethodOrigin);
						formatData(sMethodNumber, sPMethodNumber);
						formatData(sMethodSpecific, sPMethodSpecific);

						formatData(sSampling, sPSampling);
						formatData(sSubGroup, sPSubGroup);

						formatData(sPlantTesting, sPPlantTesting);
						formatData(sPlantRetesting, sPPlantRetesting);
						formatData(sTestingUOM, sPTestingUOM);

						formatData(sLowerSpecLimit, sPLowerSpecLimit);
						formatData(sLowerRoutineReleaseLimit, sPLowerRoutineReleaseLimit);
						formatData(sPGLowerTarget, sPPGLowerTarget);
						formatData(sPGTarget, sPPGTarget);
						formatData(sPGUpperTarget, sPPGUpperTarget);
						formatData(sUpperRoutineRL, sPUpperRoutineRL);
						formatData(sPGUpperSpecLimit, sPPGUpperSpecLimit);

						formatData(sUnitOfMeasure, sPUnitOfMeasure);
						formatData(sPGReportNear, sPPGReportNear);
						formatData(sPGReportType, sPPGReportType);
						formatData(sReleseCriteria, sPReleseCriteria);
						formatData(sPGACtionRequired, sPPGACtionRequired);
						formatData(sCriticalFactor, sPCriticalFactor);
						formatData(sPGBasis, sPPGBasis);

						formatData(sPTestGroup, sTestGroup);
						formatData(sPApplication, sApplication);
						formatData(sPMTitle, sTitle);

					}
					mpFinal.put(ConstantsUtil.CHG, schg.toString());
					mpFinal.put(ConstantsUtil.CHARACTERISTICCH, sCharcteristic.toString());
					mpFinal.put(ConstantsUtil.CS, sCharSpec.toString());

					/*
					 * if ((sType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART) ||
					 * sType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) &&
					 * isModificatinRequired()) { mpFinal.put(ConstantsUtil.CHARP,
					 * sPath.toString()); } else if
					 * (!sType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART) &&
					 * !sType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) {
					 * mpFinal.put(ConstantsUtil.CHARP, sPath.toString()); }
					 */

					mpFinal.put(ConstantsUtil.REF, sTMNActual.toString());
					mpFinal.put(ConstantsUtil.REFID, sTMNActualID.toString());
					mpFinal.put(ConstantsUtil.REFTYPE, sTMNActualType.toString());

					// mpFinal.put(ConstantsUtil.PATH_ID, sbPathId.toString());
					// mpFinal.put(ConstantsUtil.PATH_TYPE, sbPathType.toString());

					mpFinal.put(ConstantsUtil.TMTYPE, sTMNameType.toString());
					mpFinal.put(ConstantsUtil.TESTMETHODNAME, sTMName.toString());
					mpFinal.put(ConstantsUtil.TESTMETHODNAMEID, sTMNameID.toString());

					// mpFinal.put(ConstantsUtil.TML, sTMLogic.toString());
					mpFinal.put(ConstantsUtil.ORIGIN, sMethodOrigin.toString());
					mpFinal.put(ConstantsUtil.TM, sMethodNumber.toString());
					mpFinal.put(ConstantsUtil.SP, sMethodSpecific.toString());

					mpFinal.put(ConstantsUtil.SAMPLINGSM, sSampling.toString());
					mpFinal.put(ConstantsUtil.SG, sSubGroup.toString());

					// mpFinal.put(ConstantsUtil.RT, sPlantRetesting.toString());
					mpFinal.put(ConstantsUtil.RT, sPGReportType.toString());
					// mpFinal.put(ConstantsUtil.UOM, sTestingUOM.toString());
					mpFinal.put(ConstantsUtil.UOM, sUnitOfMeasure.toString());

					mpFinal.put(ConstantsUtil.LOWERSPECLIMIT, sLowerSpecLimit.toString());
					// mpFinal.put(ConstantsUtil.LRRL,
					// sLowerRoutineReleaseLimit.toString());
					mpFinal.put(ConstantsUtil.LTGT, sPGLowerTarget.toString());
					mpFinal.put(ConstantsUtil.TGT, sPGTarget.toString());
					mpFinal.put(ConstantsUtil.UTGT, sPGUpperTarget.toString());
					// mpFinal.put(ConstantsUtil.URRL, sUpperRoutineRL.toString());
					mpFinal.put(ConstantsUtil.USL, sPGUpperSpecLimit.toString());

					// mpFinal.put(ConstantsUtil.UNITOF, sUnitOfMeasure.toString());
					mpFinal.put(ConstantsUtil.RTN, sPGReportNear.toString());
					// mpFinal.put(ConstantsUtil.RTT, sPGReportType.toString());
					mpFinal.put(ConstantsUtil.RELEASECRITERIA, sReleseCriteria.toString());

					mpFinal.put(ConstantsUtil.ACTIONREQUIRED, sPGACtionRequired.toString());
					mpFinal.put(ConstantsUtil.CAPSCR, sCriticalFactor.toString());
					mpFinal.put(ConstantsUtil.BA, sPGBasis.toString());

					mpFinal.put(ConstantsUtil.TESTGROUP, sPTestGroup.toString());
					mpFinal.put(ConstantsUtil.AP, sPApplication.toString());
					// mpFinal.put(ConstantsUtil.MPT, sPMTitle.toString());

					SecurityService sct = new SecurityService();
					String sUserType = sct.getUserType();

					if ((sUserType.equals(ConstantsUtil.PG)) || (sUserType.equals(ConstantsUtil.PGSTAFF))) {
						mpFinal.put(ConstantsUtil.PLANTTESTING, sPlantTesting.toString());
						mpFinal.put(ConstantsUtil.CPS, sCPS.toString());
						// START:: gaikwad.tg
						mpFinal.put(ConstantsUtil.CPSNAME, sCPSName.toString());
						mpFinal.put(ConstantsUtil.CPSID, sCPSId.toString());
						// END :: gaikwad.tg
					}

				} catch (Exception e) {
					LOGGER.error("Exception from BusObjectAttribUtil:  updatePerformCharcteristic" + e);
					return new HashMap();
				}
				// return mpFinal = filterMapList(mpFinal);

				return mpFinal;
	}

	public Map updatePartSpecforMPS(Context context, Map objectMap, boolean readaccess_structured) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

							mpPartSpecs = getPartSpecificationsforMPS(context, sType, sID, readaccess_structured);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :updatePartSpec " + e);
			return new HashMap();

		}
		return mpPartSpecs;
		// return filterMapList(mpPartSpecs);
	}

	public HashMap getPartSpecificationsforMPS(Context context, String sParentType, String sObjectID,
			boolean readaccess_structured) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		//SPEC: Release SR18x.5.2 - Added for Defect# 40010  by Dominic on Date 19/02/2021 -- START
		ArrayList idAlreadyPresent = new ArrayList();
		//SPEC: Release SR18x.5.2 - Added for Defect# 40010  by Dominic on Date 19/02/2021 -- END

		//SPEC: Release SR18x.6.0.1 - Added by Amman on June 07, 2021 for Defect raised by Internal Testing Team -- START
		//String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION;
		//if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
				+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		//}
		//SPEC: Release SR18x.6.0.1 - Added by Amman on June 07, 2021 for Defect raised by Internal Testing Team -- END


		Pattern sTypePattern;

		if (readaccess_structured) {
			sTypePattern = getTypePatternforMPS(true);
		} else {
			sTypePattern = getTypePatternforMPS(false);
		}

		/*
		 * String sTypePattern = ConstantsUtil.EMPTY_STRING;;
		 * 
		 * if(readaccess_structured){ sTypePattern=getTypePatternforMPS(true); }
		 * else { sTypePattern=getTypePatternforMPS(false); }
		 */

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		//String[] aCompany = sUserCompanies.split(",");
		String[] aCompany = splitCompanyValues(context,sUserCompanies);
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = getUserType();
		// Guna modified for Defect 38897  18x.5.2 Release -- START
		/*if (isModificatinRequired()) {
									sWhere = "current!=Obsolete";
								}*/
		if (sUserType.equals(ConstantsUtil.PG) || ss.isStaffAUGUser()) {
			sWhere = "current!=Obsolete";
		}else{
			sWhere = "current==Release";
		}
		// Guna modified for Defect 38897 18x.5.2 Release -- END
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			//DomainObject doAPP = new DomainObject(sObjectID);
			DomainObject doAPP = DomainObject.newInstance(context, sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, sTypePattern.getPattern(), slPartSpecSelects,
					null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			mapList.sort(ConstantsUtil.SELECT_TYPE, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				//SPEC: Release SR18x.5.2 - Added for Defect# 40010  by Dominic on Date 19/02/2021 -- START
				if (!idAlreadyPresent.contains(strId)) {
					//SPEC: Release SR18x.5.2 - Added for Defect# 40010  by Dominic on Date 19/02/2021 -- END
					String strClassFied = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
					String sIPClassfication = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
					String strSource = getSource(context, strId);
					
					String strSubType = UpdateSpecSubType(context, strId);
					boolean showData = true;
					String strState = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
					String strId_Result = strId;
					if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)) {
						strId_Result = ConstantsUtil.NO_ACCESS;
					}

					showData = checkHasAccess(context, sUserType, strId);

					if(!showData && isModificatinRequired()){
						continue;
					}

					strType=getMappedTypeData(context,strType);
					formatData(sbType,strType);
					if (isModificatinRequired()) {
						if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} 
							else
							{
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = (String) mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							}

						} 
						else
						{
							if (showData) {
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = (String) mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							}
						}
					}
					else
					{
						//SPEC: Release SR18x.6. Added by Dominic for Req#35908 on Date 26/04/2021 --END
						if (showData) {
														sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							// SPEC: Modified for 18x.5.2 DEV --Guna -- START
							String strTitle = (String) mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							// SPEC: Modified for 18x.5.2 DEV --Guna -- END
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

						}
						}
				}
				idAlreadyPresent.add(strId);
			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.SAPDESCRIPTION, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
				mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
				mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			}

		} catch (FrameworkException e) {
			LOGGER.error("Exception in BusObjectAttribUtil getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}

	public String getMappedTypeforMPS(String sType) {

		try {
			Map mapCodeMapping = new HashMap();
			mapCodeMapping.put("pgApprovedSupplierList", "ASL");
			mapCodeMapping.put("pgArtwork", "ART");
			mapCodeMapping.put("pgBaseFormula", "BSF");
			mapCodeMapping.put("ECR", "CR");
			mapCodeMapping.put("pgCommonPerformanceSpecification", "CPST");
			mapCodeMapping.put("pgConsumerDesignBasis", "CDB");
			mapCodeMapping.put("pgFinishedProduct", "FP");
			mapCodeMapping.put("pgIllustration", "ILST");
			mapCodeMapping.put("pgLogisticSpec", "LOG");
			mapCodeMapping.put("pgMakingInstructions", "MI");
			mapCodeMapping.put("pgMasterPackingMaterial", "MPMS");
			mapCodeMapping.put("pgMasterRawMaterial", "MRMS");
			mapCodeMapping.put("pgMasterFinishedProduct", "MPS");
			mapCodeMapping.put("pgPackingMaterial", "MATL");
			mapCodeMapping.put("pgRawMaterial", "MATL");
			mapCodeMapping.put("Shared Table", "CPS");
			mapCodeMapping.put("pgNonGCASPart", "NGCAS");
			mapCodeMapping.put("pgPackingInstructions", "Packing Instruction");//Modified by Ketan for Req. no. 1563
			mapCodeMapping.put("pgPackingSubassembly", "PSUB");
			mapCodeMapping.put("pgProcessStandard", "PROS");
			mapCodeMapping.put("pgApplianceProduct", "APP");
			mapCodeMapping.put("pgAssembledProduct", "ASP");
			mapCodeMapping.put("pgFormulatedProduct", "FC");
			mapCodeMapping.put("pgQualitySpecification", "QUAL");
			mapCodeMapping.put("pgStackingPattern", "SPS");
			mapCodeMapping.put("pgStandardOperatingProcedure", "SOP");
			mapCodeMapping.put("pgSupplierInformationSheet", "SIS");
			mapCodeMapping.put("pgTestMethod", "TM");
			mapCodeMapping.put("Safety And Regulatory Characteristic", "SRS");
			mapCodeMapping.put("pgFormulatedMaterial", "FMATL");
			mapCodeMapping.put("pgMaterial", "MATL");
			mapCodeMapping.put("Finished Product Part", "FPP");
			mapCodeMapping.put("pgConsumerUnitPart", "COP");
			mapCodeMapping.put("pgCustomerUnitPart", "CUP");
			mapCodeMapping.put("pgInnerPackUnitPart", "IP");
			mapCodeMapping.put("pgTransportUnitPart", "TUP");
			mapCodeMapping.put("pgMasterConsumerUnitPart", "MCOP");
			mapCodeMapping.put("pgMasterCustomerUnitPart", "MCUP");
			mapCodeMapping.put("pgMasterInnerPackUnitPart", "MIP");
			mapCodeMapping.put("pgAncillaryPackagingMaterialPart", "APMP");
			mapCodeMapping.put("pgPromotionalItemPart", "PIP");
			mapCodeMapping.put("Formulation Part", "FOP");
			mapCodeMapping.put("Packaging Material Part", "PMP");
			mapCodeMapping.put("Raw Material", "RMP");
			mapCodeMapping.put("pgMasterPackagingMaterialPart", "MPMP");
			mapCodeMapping.put("Packaging Assembly Part", "PAP");
			mapCodeMapping.put("pgMasterPackagingAssemblyPart", "MPAP");
			mapCodeMapping.put("pgAuthorizedTemporarySpecification", "ATS");
			mapCodeMapping.put("pgStackingPattern", "SPS");
			mapCodeMapping.put("pgPPMConstituent", "CNT");
			mapCodeMapping.put("pgOnlinePrintingPart", "OPP");
			mapCodeMapping.put("pgFabricatedPart", "FAB");
			mapCodeMapping.put("pgAncillaryRawMaterialPart", "ARMP");
			mapCodeMapping.put("pgAssembledProductPart", "APP");
			mapCodeMapping.put("pgAuthorizedConfigurationStandard", "ACS");
			mapCodeMapping.put("pgDeviceProductPart", "DPP");
			mapCodeMapping.put("Formula Technical Specification", "IAPS");
			mapCodeMapping.put("pgMasterProductPart", "MPP");
			mapCodeMapping.put("pgMasterRawMaterialPart", "MRMP");
			mapCodeMapping.put("Formulation Process", "FOPR");
			mapCodeMapping.put("Test Method Specification", "TMS");
			mapCodeMapping.put("pgSoftwarePart", "SWP");
			mapCodeMapping.put("POA", "POA"); // Added by Ketan for Defect No. 55948
			mapCodeMapping.put("pgIntermediateProductPart", "IPP"); // Added by Ketan for Req. No. 1589,2180

			if (ConstantsUtil.TYPE_PGPHASE.equals(sType)) {

				return "";

			} else {

				return (String) mapCodeMapping.get(sType);
			}

		} catch (Exception e) {
			LOGGER.error("Exception in MPS : getMPSSubstitutes : " + e);
			return sType;
		}
	}

	public HashMap getPartSpecificationsforPSUB(Context context, String sParentType, String sObjectID,
			boolean readaccess) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();

		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
				+ ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;
		// START :: gaikwad.tg :: Defect#38260
		// Modified if block added check for PSUB part
		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)
				|| sParentType.equals(ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY)
				|| sParentType.equals(ConstantsUtil.TYPE_PGRAWMATERIAL)
				|| sParentType.equals(ConstantsUtil.TYPE_PGPACKINGMATERIAL) 
				|| sParentType.equals(ConstantsUtil.TYPE_PGSUPPLIERINFORMATIONSHEET)
				|| sParentType.equals(ConstantsUtil.TYPE_PGMASTERRAWMATERIAL)
				|| sParentType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT)) {
			sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		}
		// END :: gaikwad.tg :: Defect#38260
		Pattern sTypePattern;
		//SPEC: Modified for External Defect by Bala on 26/05/2021 -- START
		PackingSubassemblyBO psubbo = new PackingSubassemblyBO();
		if (readaccess) {
			//sTypePattern = getTypePatternforMPS(true);
			sTypePattern = psubbo.getTypePatternforSpecification(true);
		} 
		else {
			//sTypePattern = getTypePatternforMPS(false);
			sTypePattern = psubbo.getTypePatternforSpecification(false);
		}
		//SPEC: Modified for External Defect by Bala on 26/05/2021 -- END

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = splitCompanyValues(context,sUserCompanies);
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = getUserType();

		if (sUserType.equals(ConstantsUtil.PG) || ss.isStaffAUGUser()) {
			sWhere = "current!=Obsolete";
		}else{
			sWhere = "current==Release";
		}
		// Guna modified for Defect 38897 18x.5.2 Release -- END
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			//DomainObject doAPP = new DomainObject(sObjectID);
			DomainObject doAPP = DomainObject.newInstance(context, sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, sTypePattern.getPattern(), slPartSpecSelects,
					null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String strSource = getSource(context, strId);

				String strSubType = UpdateSpecSubType(context, strId);

				String strState = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)) {
					strId_Result = ConstantsUtil.NO_ACCESS;
				}
				//SPEC: Added as per Req 33248 and for External Defect by Bala on 26/05/2021 -- START
				if (isModificatinRequired()) {
					if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)) {
						continue;
					}
				}
				strType = (String) mpEachObj.get(ConstantsUtil.SELECT_TYPE);
				boolean showData = checkHasAccess(context, sUserType, strId);
				if (isModificatinRequired()) {
					if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {
						if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
							continue;
						} 
						else
						{
							sbType.append(getMappedTypeforMPS(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						}

					} 
					else
					{
						if (showData) {
							sbType.append(getMappedTypeforMPS(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							continue;
						}
					}
				}
				else
				{
					//SPEC: Release SR18x.6. Added by Dominic for Req#35908 on Date 26/04/2021 --END
					if (showData) {
						sbType.append(getMappedTypeforMPS(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
					} else {
						sbType.append(getMappedTypeforMPS(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					}
					}
			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.SAPDESCRIPTION, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
				mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
				mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			}

		} catch (FrameworkException e) {
			LOGGER.error("Exception in BusObjectAttribUtil getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}

	/**
	 * Check isTamu
	 * 
	 * @param slTMName
	 * @param slTMType
	 * @param slsChildObjectID
	 * @param slTamuList
	 * @return
	 */
	public Map removeTestMethodTamu(StringList slTMName, StringList slTMType, StringList slsChildObjectID,
			StringList slTamuList) {
		StringList slTMNameFiltered = new StringList();
		StringList slTMFilteredType = new StringList();
		StringList slTMFilteredID = new StringList();

		StringList slTMSName = new StringList();
		StringList slTMSType = new StringList();
		StringList slTMSFID = new StringList();

		String sType = ConstantsUtil.TYPE_TESTMETHODSPECIFCATION;

		for (int i = 0; i < slTMType.size(); i++) {
			if (sType.equals(slTMType.get(i)) && !"TAMU".equals(slTamuList.get(i))) {
				slTMNameFiltered.add(slTMName.get(i));
				slTMFilteredType.add(slTMType.get(i));
				slTMFilteredID.add(slsChildObjectID.get(i));

			} else {

				slTMSName.add(slTMName.get(i));
				slTMSType.add(slTMType.get(i));
				slTMSFID.add(slsChildObjectID.get(i));

			}

		}
		Map<String, StringList> mpTemp = new HashMap<String, StringList>();

		mpTemp.put(ConstantsUtil.TMFILNAME, slTMNameFiltered);
		mpTemp.put(ConstantsUtil.TMFILID, slTMFilteredID);
		mpTemp.put(ConstantsUtil.TMFILTYPE, slTMFilteredType);

		mpTemp.put(ConstantsUtil.BASENAME, slTMSName);
		mpTemp.put(ConstantsUtil.BASETYPE, slTMSType);
		mpTemp.put(ConstantsUtil.BASEID, slTMSFID);

		return mpTemp;

	}

	/**
	 * Returns StringList from StringWith Comma
	 * 
	 * @param sValue
	 * @return
	 */

	public StringList returnStringListFromStringWithComma(String sValue) {
		StringList slMapType = new StringList();
		String sType = DomainConstants.EMPTY_STRING;
		String[] sData = sValue.split(ConstantsUtil.SYMBL_COMMA);
		for (int i = 0; i < sData.length; i++) {
			sType = sData[i].trim();
			if (UIUtil.isNotNullAndNotEmpty(sType)) {
				slMapType.add(sType.trim());
			}
		}

		return slMapType;
	}

	/**
	 * Verify the Licenses
	 * 
	 * @param sUserlicense
	 * @param sFormulaClassif
	 * @return
	 */
	public boolean checkLicenses(String sUserlicense, String sFormulaClassif) {
		boolean bHasLicense = false;
		try {
			if (UIUtil.isNotNullAndNotEmpty(sUserlicense) && UIUtil.isNotNullAndNotEmpty(sFormulaClassif)) {
				StringList slUserLicense = returnStringListFromStringWithComma(sUserlicense);
				StringList slObjectLicenses = getStringList(sFormulaClassif);
				StringList slObjectHirLicenses = getStringListOfHirLicense(sFormulaClassif);
				boolean bHasHir =checkHiRLicense(slObjectHirLicenses,slUserLicense);
				if(bHasHir)		
				{
					for (int i = 0; i < slUserLicense.size(); i++) {
						bHasLicense = slObjectLicenses.contains(slUserLicense.get(i).trim());
						if (bHasLicense)
							return true;
					}
				} else 
				{
					return false;
				}

			}else 
			{
				return false;
			}
		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :checkLicenses ");
			return false;
		}

		return bHasLicense;

	}



	public boolean checkInternalUserAcess(String sUserlicense, String sFormulaClassif) {
		boolean showData = false;
		try {
			StringTokenizer st1 = new StringTokenizer(sFormulaClassif, ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			while (st1.hasMoreTokens()) {
				String token = st1.nextToken();
				if (sUserlicense.contains(token.trim())) {
					showData = true;
					break;
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :checkInternalUserAcess ");
			return false;
		}
		return showData;
	}

	public Map getPOAGendoc(Context context, Map resultMaps) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);

		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);

		String strTypePattern = ConstantsUtil.TYPE_PFAAACIC + "," + ConstantsUtil.TYPE_PGPOADOCUMENT;

		String sObjectId = validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

				Map<String, String> mpRefDoc = new HashMap();
				// SPEC: Added for 18x.5.2 DEV --Guna -- START
				String strWhere = "revision !=Rendition && revision !=SPANISH";
				// SPEC: Added for 18x.5.2 DEV --Guna -- END
				try {
					//DomainObject dobCdoc = new DomainObject(sObjectId);
					DomainObject dobCdoc = DomainObject.newInstance(context, sObjectId);
					// SPEC: Modified for 18x.5.2 DEV --Guna -- START
					MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
							DomainConstants.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1, strWhere,
							ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
					// SPEC: Modified for 18x.5.2 DEV --Guna -- END
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					dobCdoc.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					StringBuilder sbName = new StringBuilder();
					StringBuilder sbId = new StringBuilder();
					StringBuilder sbType = new StringBuilder();
					StringBuilder sbRev = new StringBuilder();
					StringBuilder sbCurrent = new StringBuilder();
					StringBuilder sbDescription = new StringBuilder();
					StringBuilder sbTitle = new StringBuilder();
					StringBuilder sbLanguage = new StringBuilder();
					StringBuilder sbSource = new StringBuilder();

					StringBuilder sbFileName = new StringBuilder();
					StringBuilder sbFileSize = new StringBuilder();
					StringBuilder sbFileFormat = new StringBuilder();
					StringBuilder sbFilePath = new StringBuilder();

					if (!util.isModificatinRequired()) {
						// mlRelatedSpecs=util.filterPhase(mlRelatedSpecs);
						Iterator objectListItr = mlRelatedSpecs.iterator();
						while (objectListItr.hasNext()) {
							Map objectMap = (Map) objectListItr.next();
							String sType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
							String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
							String sId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
							String sCurrent = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
							String sRev = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
							String sFileName = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_NAME));
							String sFileSize = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_SIZE));
							String sFileFormat = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMAT_FILE));
							String sFilePath = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_CAPTURED));
							String sDesc = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
							String sTitle = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							String sPGLangBuffer = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE));
							String sPLangBuffer = validator
									.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE));
							// SPEC: Modified for 18x.5.2 DEV --Guna -- END

							util.formatData(sbType, util.mapType(sType));
							util.formatData(sbName, sName);
							util.formatData(sbCurrent, sCurrent);
							util.formatData(sbId, sId);
							util.formatData(sbRev, sRev);
							util.formatData(sbLanguage, sPGLangBuffer);
							util.formatData(sbDescription, sDesc);
							util.formatData(sbTitle, sTitle);
							util.formatData(sbFileSize, sFileSize);
							util.formatData(sbFileFormat, sFileFormat);
							util.formatData(sbFileName, sFileName);
							util.formatData(sbFilePath, sFilePath);
						}

					}

					mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
					mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
					mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
					mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
					mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
					// SPEC: Modified for 18x.5.2 DEV --Guna -- START
					mpRefDoc.put(ConstantsUtil.SOURCE, ConstantsUtil.SOURCE_DIRECT);
					// SPEC: Modified for 18x.5.2 DEV --Guna -- END
					mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
					mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
					mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLanguage.toString());
					mpRefDoc.put(ConstantsUtil.FILESFORMAT, sbFileFormat.toString());
					mpRefDoc.put(ConstantsUtil.FILESNAMES, sbFileName.toString());
					mpRefDoc.put(ConstantsUtil.FILESPATH, sbFilePath.toString());
					mpRefDoc.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());

				} catch (Exception e) {

					LOGGER.error("Exception in Program : BusObjectAttribUtil Method :updateRefDocs " + e);
					return new HashMap();
				}

				return util.filterMapList(mpRefDoc);
	}

	public Pattern getTypePattern(boolean isStructured) {
		String sReturnPattern = "*";
		Pattern sbTypePattern = new Pattern(ConstantsUtil.tPROS);
		sbTypePattern.addPattern(ConstantsUtil.tMI);

		try {
			if (isStructured) {
				sbTypePattern.addPattern(ConstantsUtil.tART);
				sbTypePattern.addPattern(ConstantsUtil.tASL);
				sbTypePattern.addPattern(ConstantsUtil.tILST);
				sbTypePattern.addPattern(ConstantsUtil.tQUAL);
				sbTypePattern.addPattern(ConstantsUtil.tSPS);
				sbTypePattern.addPattern(ConstantsUtil.tPI);
				sbTypePattern.addPattern(ConstantsUtil.tTM);
				return sbTypePattern;
			} else {
				sbTypePattern.addPattern(ConstantsUtil.tART);
				sbTypePattern.addPattern(ConstantsUtil.tASL);
				
				sbTypePattern.addPattern(ConstantsUtil.tILST);
				sbTypePattern.addPattern(ConstantsUtil.tQUAL);
				sbTypePattern.addPattern(ConstantsUtil.tSPS);
				sbTypePattern.addPattern(ConstantsUtil.tPI);
				sbTypePattern.addPattern(ConstantsUtil.tTM);
				//SPEC: Release SR18x.5.2 - Added for Defect# 39116  by Guna on Date 10/02/2021 -- START
				sbTypePattern.addPattern(ConstantsUtil.tIRMS);
				sbTypePattern.addPattern(ConstantsUtil.tSOP);
				sbTypePattern.addPattern(ConstantsUtil.tFPP);
				sbTypePattern.addPattern(ConstantsUtil.tPMP);
				//SPEC: Release SR18x.5.2 - Added for Defect# 39116  by Guna on Date 10/02/2021 -- END
				return sbTypePattern;
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getTypePattern " + e);
		}
		return sbTypePattern;
	}

	public Pattern getTypePatternforMPS(boolean readaccess_structured) {
		String asterik = "*";
		Pattern sbTypePattern = new Pattern(ConstantsUtil.tILST);
		try {
			if (readaccess_structured) {
				sbTypePattern.addPattern(ConstantsUtil.tQUAL);
				sbTypePattern.addPattern(ConstantsUtil.tTAMU);
				sbTypePattern.addPattern(ConstantsUtil.tSPS);
				sbTypePattern.addPattern(ConstantsUtil.tPI);
				sbTypePattern.addPattern(ConstantsUtil.tPROS);
				sbTypePattern.addPattern(ConstantsUtil.tSOP);
				sbTypePattern.addPattern(ConstantsUtil.TYPE_PGCONSUMERDESIGNBASIS);
				// START :: gaikwad.tg :: Defect#38260
				sbTypePattern.addPattern(ConstantsUtil.tASL);
				// END :: gaikwad.tg :: Defect#38260
				// SPEC :: Added by Jwala for  Defect#41613 -- START
				sbTypePattern.addPattern("pgConsumerDesignBasis");
				// SPEC :: Added by Jwala for  Defect#41613 -- END
				return sbTypePattern;
			} else {
				sbTypePattern.addPattern(ConstantsUtil.tMPMS);
				sbTypePattern.addPattern(ConstantsUtilIRM.tMRMS);
				sbTypePattern.addPattern(ConstantsUtil.tQUAL);
				sbTypePattern.addPattern(ConstantsUtil.tTAMU);
				sbTypePattern.addPattern(ConstantsUtil.tSPS);
				sbTypePattern.addPattern(ConstantsUtil.tPI);
				sbTypePattern.addPattern(ConstantsUtil.tTM);
				sbTypePattern.addPattern(ConstantsUtil.tPROS);
				sbTypePattern.addPattern(ConstantsUtil.tSOP);
				// Guna Added for Defect 38373 18x.5.2 Release -- START
				sbTypePattern.addPattern(ConstantsUtil.tFPP);
				sbTypePattern.addPattern(ConstantsUtil.tMPS);

				// Guna Added for Defect 38373 18x.5.2 Release -- END
				return sbTypePattern;
			}
		} catch (Exception e) {
			LOGGER.error("Exception :: BusObjectAttributeUtil : getTypePattern" + e);
			return sbTypePattern;
		}
	}

	/**
	 * Added by Jwala for SR2018x.6.0.1 Dev getMaterialsProceeded method used to get ALL connected
	 * Materials Proceeded *
	 * 
	 * @param context
	 * @param sObjectId
	 * @return
	 * @throws Exception 
	 */
	public Map<String, String> getMaterialsProceeded(Context context, String strObjectId) throws Exception {

		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpMaterialProduced = new HashMap<String, String>();
		MapList mlMaterialsProceed = new MapList();

		StringBuilder sbID = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSAPDescription = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbName = new StringBuilder();

		StringList slObjSel = new StringList(5);
		slObjSel.add(DomainConstants.SELECT_ID);
		slObjSel.add(DomainConstants.SELECT_TYPE);
		slObjSel.add(DomainConstants.SELECT_NAME);
		slObjSel.add(DomainConstants.SELECT_CURRENT);
		slObjSel.add(DomainConstants.SELECT_DESCRIPTION);

		//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for Defect#43904 on 06/29/2021 - START
		slObjSel.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for Defect#43904 on 06/29/2021 - END

		slObjSel.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

		try{
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				String sUserType = util.getUserType();
				DomainObject domObj = DomainObject.newInstance(context, strObjectId);

				mlMaterialsProceed = domObj.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_PGDEFINESMATERIAL,
						ConstantsUtil.TYPE_PGRAWMATERIAL,
						slObjSel, //objectSelects
						null,     //relationshipSelects
						false,     //getTo
						true,    //getFrom
						(short)0, //recurseToLevel
						null,     //objectWhere
						null,     //relationshipWhere
						0);

				Iterator objectListItr = mlMaterialsProceed.iterator();

				while(objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					boolean showData = false;

					String strID = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ID));
					String strype = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_TYPE));
					String strPhase = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for Defect#43904 on 06/29/2021 - START
					//String strSAPDescription = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
					String strSAPDescription = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.SELECT_ATTRIBUTE_TITLE));
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for Defect#43904 on 06/29/2021 - END

					String strCurrent = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_CURRENT));
					String strName = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_NAME));

					showData = util.checkHasAccess(context, sUserType, strID);

					if(!showData && util.isModificatinRequired()){
						continue;
					}

					if (showData) {
						util.formatData(sbID, strID);
						util.formatData(sbType, strype);
						util.formatData(sbPhase, strPhase);
						util.formatData(sbSAPDescription, strSAPDescription);
						util.formatData(sbState, strCurrent);
						util.formatData(sbName, strName);
					}

					mpMaterialProduced.put(ConstantsUtil.ID,sbID.toString());
					mpMaterialProduced.put(ConstantsUtil.TYPE,sbType.toString());
					mpMaterialProduced.put(ConstantsUtil.PHASE,sbPhase.toString());
					mpMaterialProduced.put(ConstantsUtil.SAPDESCRIPTION,sbSAPDescription.toString());
					mpMaterialProduced.put(ConstantsUtil.STATE,sbState.toString());
					mpMaterialProduced.put(ConstantsUtil.NAME,sbName.toString());
				}

			}
		}catch(Exception e){
			LOGGER.error("Error from BusObjectAttribUtil.java :  getMaterialsProceeded" + e);
			return new HashMap();
		}
		return mpMaterialProduced;

	}

	/**
	 * Get the Name appended with Revision
	 * 
	 * @param sSapTechName
	 * @param sSapTechRev
	 * @return
	 */

	private String getNameWithRevision(String sSapTechName, String sSapTechRev) {
		StringBuilder sbName = new StringBuilder();

		try {
			StringList slName = getStringList(sSapTechName);
			StringList slRev = getStringList(sSapTechRev);

			for (int i = 0; i < slName.size(); i++) {
				formatData(sbName, slName.get(i) + "." + slRev.get(i));
			}

		} catch (Exception e) {
			return "";
		}
		return sbName.toString();
	}

	/**
	 * HAS ATS Section
	 * 
	 * @param context
	 * @param objectMap
	 * @return
	 */

	public Map<String, String> checkIsATS(Context context, Map objectMap) {
		Map<String, String> mpHasATS = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		if(!validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_ATS_STATE)).equals(ConstantsUtil.STATE_OBSOLETE)) {
			mpHasATS.put(ConstantsUtil.ID,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_ATS_ID)));
			mpHasATS.put(ConstantsUtil.TYPE,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_ATS_TYPE)));
			mpHasATS.put(ConstantsUtil.PHASE,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_ATS_RELEASE_PHASE)));
			mpHasATS.put(ConstantsUtil.SAPDESCRIPTION,
				validator.getEquivalentString(objectMap.get(ConstantsUtil.REL_ATS_TITLE)));
			mpHasATS.put(ConstantsUtil.STATE,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_ATS_STATE)));

			String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_ATS_NAME));
			String sRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_ATS_REV));
			String sFinalName = getNameWithRevision(sName, sRev);

			mpHasATS.put(ConstantsUtil.NAME, sFinalName);

			return verifyOwnership(context, mpHasATS);
		}
		return mpHasATS;

	}

	/**
	 * HasATS
	 * 
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> checkHasATS(Context context, Map objectMap) {

		Map<String, String> mpIsATS = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		mpIsATS.put(ConstantsUtil.ID, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.ATL_ID)));
		mpIsATS.put(ConstantsUtil.TYPE,
				MapsType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.ATL_TYPE))));
		mpIsATS.put(ConstantsUtil.PHASE,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.ATL_RELEASE_PHASE)));
		mpIsATS.put(ConstantsUtil.SAPDESCRIPTION,
				validator.getEquivalentString(objectMap.get(ConstantsUtil.ATL_TITLE)));
		mpIsATS.put(ConstantsUtil.STATE,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.ATL_STATE)));
		String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.ATL_NAME));
		mpIsATS.put(ConstantsUtil.NAME, sName);
		String sRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.ATL_REVISION));
		mpIsATS.put(ConstantsUtil.REVISION, sRev);

		mpIsATS = filterStateByRelease(mpIsATS);

		// String sName =
		// validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.ATL_NAME));
		String sTempName = validator.getStringEquivalentForStringList(mpIsATS.get(ConstantsUtil.NAME));
		String sTempRev = validator.getStringEquivalentForStringList(mpIsATS.get(ConstantsUtil.REVISION));
		if (mpIsATS.containsKey(ConstantsUtil.REVISION)) {
			mpIsATS.remove(ConstantsUtil.REVISION);
		}
		// String sFinalName = getNameWithRevision(sName,sRev);
		String sFinalName = getNameWithRevision(sTempName, sTempRev);
		mpIsATS.put(ConstantsUtil.NAME, sFinalName);

		return verifyOwnership(context, mpIsATS);
	}

	/**
	 * Get the TechnicalSupersedes
	 * 
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> getTechnicalSupersedes(Context context, Map objectMap) {
		Map<String, String> mpTechnicalSupersedes = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		//SPEC: <26.05.2021>: Guna Modified for 43143 Defect  Dev 18x.6.0.1   -- START
		String sSapTechState = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_CURRENT));
		String sSapTechId = validator
				.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_ID));
		//SPEC: <27.05.2021>: Guna Modified for 43187 Defect  Dev 18x.6.0.1   -- START
		sSapTechId =getIdWithState(context,sSapTechState, sSapTechId);
		//SPEC: <27.05.2021>: Guna Modified for 43187 Defect  Dev 18x.6.0.1   -- END
		/*mpTechnicalSupersedes.put(ConstantsUtil.ID,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_ID)));*/
		mpTechnicalSupersedes.put(ConstantsUtil.ID,sSapTechId);
		//SPEC: <26.05.2021>: Guna Modified for 43143 Defect  Dev 18x.6.0.1   -- END
		mpTechnicalSupersedes.put(ConstantsUtil.TYPE,
				MapsType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_TYPE))));
		mpTechnicalSupersedes.put(ConstantsUtil.PHASE,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_PHASE)));
		mpTechnicalSupersedes.put(ConstantsUtil.SAPDESCRIPTION,
				validator.getEquivalentString(objectMap.get(ConstantsUtil.SELECT_SAP_TITLE)));
		mpTechnicalSupersedes.put(ConstantsUtil.STATE,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_CURRENT)));

		String strSupersedesOnDate = ConstantsUtil.EMPTY_STRING;
		String strSupersedesOnDates = ConstantsUtil.EMPTY_STRING;
		String strFinalSupersedesOnDates = ConstantsUtil.EMPTY_STRING;
		StringList slSupersedesOnDate = new StringList();
		String strParentType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
		Object oSupersedesOnDate = new Object();
		if (strParentType.equals(ConstantsUtil.TYPE_PGMASTERFINISHEDPRODUCT)) {
			oSupersedesOnDate = objectMap.get(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);
		} else {
			oSupersedesOnDate = objectMap.get(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		}
		// Guna Modified for Defect 38354 18x.5.2 Release -- END
		if (oSupersedesOnDate instanceof StringList) {

			// Guna Modified for Defect 38354 18x.5.2 Release -- START
			// slSupersedesOnDate = (StringList)
			// objectMap.get(ConstantsUtil.SELECT_SUPERSEDESONDATE);
			slSupersedesOnDate = (StringList) oSupersedesOnDate;
			// Guna Modified for Defect 38354 18x.5.2 Release -- END
			for (int k = 0; k < slSupersedesOnDate.size(); k++) {
				strSupersedesOnDates = (String) slSupersedesOnDate.get(k);
				strSupersedesOnDates = validator.DateFormatter(strSupersedesOnDates);
				strFinalSupersedesOnDates += strSupersedesOnDates + ConstantsUtil.SYMBL_PIPE;
			}
			strFinalSupersedesOnDates = strFinalSupersedesOnDates
					.replace(ConstantsUtil.SYMBL_PIPE + ConstantsUtil.EMPTY_STRING, ConstantsUtil.SYMBL_PIPE);
			mpTechnicalSupersedes.put(ConstantsUtil.DATE, strFinalSupersedesOnDates);
		} else if (oSupersedesOnDate instanceof String) {

			strSupersedesOnDate = (String) oSupersedesOnDate;
			// Guna Modified for Defect 38354 18x.5.2 Release -- END
			strSupersedesOnDate = validator.DateFormatter(strSupersedesOnDate);
			mpTechnicalSupersedes.put(ConstantsUtil.DATE, strSupersedesOnDate);
		}
		// SPEC: 18/01/2021: Added for 18x.5 Defect -- END

		String sSapTechName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_NAME));
		String sSapTechRev = validator
				.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_REVISION));

		String sName = getNameWithRevision(sSapTechName, sSapTechRev);

		mpTechnicalSupersedes.put(ConstantsUtil.NAME, sName);
		//SPEC: <27.05.2021>: Guna Modified for 43187 Defect  Dev 18x.6.0.1   -- START
		return mpTechnicalSupersedes;
		//return verifyOwnership(context, mpTechnicalSupersedes);
		//SPEC: <27.05.2021>: Guna Modified for 43187 Defect  Dev 18x.6.0.1   -- END

	}

	/**
	 * Get the TechnicalSupersedesBy
	 * 
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> getTechnicalSupersedesBy(Context context, Map objectMap) {
		Map<String, String> mpTechnicalSupersedes = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		mpTechnicalSupersedes.put(ConstantsUtil.ID,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_TO_ID)));
		mpTechnicalSupersedes.put(ConstantsUtil.TYPE,
				MapsType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_TO_TYPE))));
		mpTechnicalSupersedes.put(ConstantsUtil.PHASE,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_TO_PHASE)));
		mpTechnicalSupersedes.put(ConstantsUtil.SAPDESCRIPTION,
				validator.getEquivalentString(objectMap.get(ConstantsUtil.SELECT_SAP_TO_TITLE)));
		mpTechnicalSupersedes.put(ConstantsUtil.STATE,
				validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_TO_CURRENT)));
		String sSapTechName = validator
				.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_TO_NAME));
		//SPEC: 29-07-2022: Pooja Added for Internal Defect -- START
		String strSupersedesOnDate = validator
				.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE));
		strSupersedesOnDate = validator.DateFormatter(strSupersedesOnDate);
		mpTechnicalSupersedes.put(ConstantsUtil.DATE, strSupersedesOnDate);
		//SPEC: 29-07-2022: Pooja Added for Internal Defect -- END
		String sSapTechRev = validator
				.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SAP_TO_REVISION));

		String sName = getNameWithRevision(sSapTechName, sSapTechRev);

		mpTechnicalSupersedes.put(ConstantsUtil.NAME, sName);
		return verifyOwnership(context, mpTechnicalSupersedes);

	}

	public Map updatePartSpecforPSUB(Context context, Map objectMap, boolean readaccess) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

							mpPartSpecs = getPartSpecificationsforPSUB(context, sType, sID, readaccess);

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :updatePartSpec " + e);
			return new HashMap();

		}
		return mpPartSpecs;
		// return filterMapList(mpPartSpecs);
	}

	public Map getRelatedAts(Context context, DomainObject doFPP) {
		StringBuilder sbPartType = new StringBuilder();
		StringBuilder sbPartID = new StringBuilder();
		StringBuilder sbPartName = new StringBuilder();
		StringBuilder sbPartState = new StringBuilder();
		StringBuilder sbPartTitle = new StringBuilder();
		StringBuilder sbPartPhase = new StringBuilder();
		StringBuilder sbSrNo = new StringBuilder();
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpRelatedATS = new HashMap();
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		MapList mapList;

		try {
			mapList = doFPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION,
					DomainConstants.QUERY_WILDCARD, busSelect, null, true, false, (short) 1, null,
					null, ConstantsUtil.ZERO_LEVEL);
		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getRelatedAts " + e);
			return new HashMap();
		}
		Iterator objectListItr = mapList.iterator();
		int icount =0;
		while (objectListItr.hasNext()) {
			Map mpTemp = (Map) objectListItr.next();
			String sPartType = busUtil.mapType(validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_TYPE))));
			String sPartID = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_ID)));
			String sPartName = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_NAME)));
			String sPartState = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_CURRENT)));
			String sPartTitle = validator.getStringEquivalentForStringListWithComma((mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
			String sPartPhase = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)));

			if (!sPartState.equals((ConstantsUtil.STATE_RELEASE).trim())) {
				continue;
			}
			String strNumber = Integer.toString(icount + 1);
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sUserType = busUtil.getUserType();
			boolean showData = false;
			showData = busUtil.checkHasAccess(context, sUserType, sPartID);
			//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
			if(!showData && isModificatinRequired()){
				continue;
			}
			//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END
			if (showData) {
				busUtil.formatData(sbPartID, sPartID);
				busUtil.formatData(sbPartName, sPartName);
				busUtil.formatData(sbPartState, sPartState);
				busUtil.formatData(sbPartTitle, sPartTitle);
				busUtil.formatData(sbPartPhase, sPartPhase);
				busUtil.formatData(sbPartType, sPartType);
				busUtil.formatData(sbSrNo, strNumber);
			}else{
				busUtil.formatData(sbPartName, sPartName);
				busUtil.formatData(sbPartType, sPartType);
				busUtil.formatData(sbPartState, sPartState);
				busUtil.formatData(sbPartTitle, sPartTitle);
				busUtil.formatData(sbPartPhase, sPartPhase);
				busUtil.formatData(sbPartID, ConstantsUtil.NO_ACCESS);
				busUtil.formatData(sbSrNo, strNumber);
			}
			// Added by Jwala for defect #41434 defect 18x.6.0 Release -- END
			icount++;
			mpRelatedATS.put(ConstantsUtil.ATS_NAME, sbPartName.toString());
			mpRelatedATS.put(ConstantsUtil.ID, sbPartID.toString());
			mpRelatedATS.put(ConstantsUtil.ATS_TYPE, sbPartType.toString());
			mpRelatedATS.put(ConstantsUtil.ATS_STATE, sbPartState.toString());
			mpRelatedATS.put(ConstantsUtil.ATS_TITLE, sbPartTitle.toString());
			mpRelatedATS.put(ConstantsUtil.PHASE, sbPartPhase.toString());
			mpRelatedATS.put(ConstantsUtilIRM.SLNO, sbSrNo.toString());
			
		}
		return mpRelatedATS;
	}

	public String getLastUpdatedUser(Context context, String sContextObjectId) {
		String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;
		String lastModifiedHistory = ConstantsUtil.EMPTY_STRING;
		try {
			if (UIUtil.isNotNullAndNotEmpty(sContextObjectId)) {
				DomainObject dobPartData = DomainObject.newInstance(context, sContextObjectId);
				StringList slHistoryInfo = dobPartData.getHistory(context);
				//SPEC: 07/06/2021: Modified for 18x.6.0.1 defect #44052 by Bala-- START
				if (slHistoryInfo != null && slHistoryInfo.size() > 0) {
					for (int i = slHistoryInfo.size() - 1; i > 0; i--) {
						lastModifiedHistory = (String) slHistoryInfo.get(i);

						if (UIUtil.isNotNullAndNotEmpty(lastModifiedHistory)) {
							lastUpdatedUser = lastModifiedHistory.substring(lastModifiedHistory.indexOf("user:") + 6,
									lastModifiedHistory.indexOf("time:") - 2).trim();

							if (lastUpdatedUser.equalsIgnoreCase(ConstantsUtil.USERAGENT)) {
								continue;
							} else {
								break;
							}

						}
					}
				} else {					
					lastUpdatedUser = dobPartData.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
				}
				//SPEC: 07/06/2021: Modified for 18x.6.0.1 defect #44052 by Bala-- END
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lastUpdatedUser;
	}

	public Map getMaster(Context context, DomainObject doObj) {

		Map<String, String> mpMaster = new HashMap<String, String>();
		StringBuilder sbMasterName = new StringBuilder();
		StringBuilder sbMasterId = new StringBuilder();

		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_NAME);

		StringList slRelSelects = new StringList();
		try {
			MapList mlMaster = doObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGMASTER,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			Iterator objectListItr = mlMaster.iterator();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);

				formatData(sbMasterName, sName);
				formatData(sbMasterId, sId);
			}
			mpMaster.put(ConstantsUtil.NAME, sbMasterName.toString());
			mpMaster.put(ConstantsUtil.ID, sbMasterId.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getMaster " + e);
			e.printStackTrace();
		}
		return mpMaster;
	}

	public Map<String, String> getIpClass(Context context, String strType, DomainObject doFormObj,
			StringList slIpSelects) {
		Map<String, String> mpIpSecuritySetting = new HashMap<String, String>();
		MapList mlIPCLass;
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		boolean bHasAccess = false;
		try {
			String sId = doFormObj.getId(context);
			mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM,
					ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects, null, true, false, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			Iterator itr = mlIPCLass.iterator();
			Map mpIpClass = new HashMap();
			StringBuilder sbIpName = new StringBuilder();
			StringBuilder sbHasClassAccess = new StringBuilder();
			StringBuilder sbIpType = new StringBuilder();
			StringBuilder sbIpDesc = new StringBuilder();
			StringBuilder sbIpState = new StringBuilder();
			StringBuilder sbIpLibrary = new StringBuilder();
			StringBuilder sbIpClassPath = new StringBuilder();

			while (itr.hasNext()) {
				mpIpClass = (Map) itr.next();
				String sIpClassName = (String) mpIpClass.get(ConstantsUtil.SELECT_NAME);
				sbIpName.append(sIpClassName);
				sbIpType.append((String) mpIpClass.get(ConstantsUtil.SELECT_TYPE));
				sbIpDesc.append((String) mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
				sbIpState.append((String) mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
				String strIpClass = "";
				if (sIpClassName.contains(ConstantsUtil.HIR)) {
					strIpClass = ConstantsUtil.HIGHLY_RESTRICTED;
					sbIpLibrary.append(strIpClass);
				} else {
					strIpClass = ConstantsUtil.BUSINESS_USE;
					sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
				}
				if (!strIpClass.isEmpty()) {
					StringBuilder sbIpClassTemp = new StringBuilder();
					sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
					sbIpClassPath.append(sbIpClassTemp.toString());
				}

				bHasAccess = checkHasAccess(context, null, sId);
				// modified by Ganesh for security impl----->end
				sbHasClassAccess.append(String.valueOf(bHasAccess));

				if (itr.hasNext()) {
					sbIpName.append("|");
					sbIpType.append("|");
					sbIpDesc.append("|");
					sbIpState.append("|");
					sbIpLibrary.append("|");
					sbIpClassPath.append("|");
					sbHasClassAccess.append("|");
				}
			}
			mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
			mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
			mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
			mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
			mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
			mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
			mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
		} catch (FrameworkException e) {
			e.printStackTrace();
			LOGGER.error("Error from CommonBusUtil: getIpClass" + e);
		}
		return mpIpSecuritySetting;

	}

	/**
	 * This Method is for getting the PQR VIEW along with SEPS and MEPS
	 * 
	 * @param context
	 * @param sRelationShip
	 * @param objectMap
	 * @param bMEP
	 * @return
	 * @throws Exception
	 */

	public Map<String, String> getPQREquivalents(Context context, Map objectMap, boolean bMEP, String sRelationShip,String sUserViewType) {

		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpEquivalents = new HashMap<String, String>();
		MapList mlAllowedMEPList = new MapList();
		MapList mlList = new MapList();

		String sContextObjectId = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
				? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		if (UIUtil.isNullOrEmpty(sContextObjectId)) {

			return new HashMap();
		}
		//Added by Subhajit, Req - 45670
		String sContextObjectPolicy = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_POLICY))
				? (String) objectMap.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING;
				StringList slBusSelects = new StringList();
				slBusSelects.add(ConstantsUtil.SELECT_NAME);
				slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
				slBusSelects.add(ConstantsUtil.SELECT_TYPE);
				slBusSelects.add(ConstantsUtil.SELECT_REVISION);
				slBusSelects.add(ConstantsUtil.SELECT_ID);
				slBusSelects.add(ConstantsUtil.SELECT_POLICY);
				
				//Commented by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527
				//slBusSelects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
				//slBusSelects.addElement(ConstantsUtil.STR_IPCLASS);
				//slBusSelects.add(ConstantsUtil.OWNERSHIP);
				if (bMEP) {
					slBusSelects.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
					//Added by Manikanta for Req. no. 2334 - START
					slBusSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_CITY);
					slBusSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_STATE);
					slBusSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_COUNTRY);
					slBusSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_VENDOR);
					slBusSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_PGHOUSENUMBER);
					slBusSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_ADDRESS);
					//Added by Manikanta for Req. no. 2334 - END
					
				} else {
					slBusSelects.add(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME);
					//Added by Manikanta for Req. no. 2334 - START
					slBusSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY);
					slBusSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE);
					slBusSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_COUNTRY);
					slBusSelects.add(ConstantsUtilIRM.SELECT_SUPPLYRESPONSIBILITY_POSTALCODE);
					slBusSelects.add(ConstantsUtilIRM.SELECT_SUPPLYRESPONSIBILITY_PGHOUSENUMBER);
					slBusSelects.add(ConstantsUtilIRM.SELECT_SUPPLYRESPONSIBILITY_ADDRESS);
					//Added by Manikanta for Req. no. 2334 - END
				}

				StringList slRelSelects = new StringList();
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRDESCRIPTION);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATUS);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRCOMMENTS);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRPLANTS);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRPCP);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRBA);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRID);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRTYPE);
				//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- START
				slRelSelects.add(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY);
				slRelSelects.add(ConstantsUtilIRM.SELECT_ATTR_PG_ARTWORK_SECONDARY);
				//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- START
				//SPEC: Release SR18x.6.0 - Added for ExternalDefect# by gaikwad.tg on Date 29 April 2021 -- END
				slRelSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PQRPCPNAME);
				slRelSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PQRBANAME);
				//SPEC: Release SR18x.6.0 - Added for ExternalDefect# by gaikwad.tg on Date 29 April 2021 -- END

				try {

			boolean bHasOwnerShip = false;
			//SPEC: <28.12.2021>: Guna Modified for 45801 Defect  Dev 18x.6.0.3   -- START
			StringBuilder sbWhere =new StringBuilder();
			sbWhere.append("( policy == \""+ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT +"\" || policy == \""+ConstantsUtil.POLICY_SUPPLIEREQUIVALENT +"\" )");
			String sUserType = getUserType();
			SecurityService sct = new SecurityService();
			//SPEC: <07.04.2022>: Guna Modified for Req 35586 22x Release  -- START
			if (isModificatinRequired() || sct.isStaffAUGUser()) {
				// SPEC: <11-17-2020>: Modified for Defect 37342 -- START
				sbWhere.append(" && current!="+ConstantsUtil.STATE_OBSOLETE+" && current !="+ConstantsUtilIRM.STATE_LOCKED+"");
				// SPEC: <11-17-2020>: Modified for Defect 37342 -- END
			}
			//SPEC: <07.04.2022>: Guna Modified for Req 35586 22x Release  -- END
			
			//SPEC: <28.12.2021>: Guna Modified for 45801 Defect  Dev 18x.6.0.3   -- END
			// SPEC: <11.11.2020>: Modified for Defect 37194 Spec Reader 1.0.1
			// -- END
			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			//String[] aCompany = sUserCompanies.split(",");
			String[] aCompany = splitCompanyValues(context,sUserCompanies);
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			StringBuilder sbCompany = new StringBuilder();
			//SPEC: <22.12.2021>: Guna Modified for 42013 Req  Dev 18x.6.0.3 Release --- START
			StringList slUserOwnership = new StringList() ;
			if (aCompany.length > -1) {
				for (int i = 0; i < aCompany.length; i++) {
					if (null != aCompany[i]) {
						String company = aCompany[i];
						sbCompany.append(company.trim().replace(" Plant", "")).append("|");
						slUserOwnership.add(company.trim());
					}
				}
			}
			//DomainObject dob = new DomainObject(sContextObjectId);
			
			DomainObject dob = DomainObject.newInstance(context, sContextObjectId);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRBA);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PQRBANAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PQRPCPNAME);
			mlList = dob.getRelatedObjects(context, sRelationShip, DomainConstants.QUERY_WILDCARD, slBusSelects,
					slRelSelects, false, true, (short) 0, sbWhere.toString(), ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PQRBA);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SELECT_ATTRIBUTE_PQRBANAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SELECT_ATTRIBUTE_PQRPCPNAME);
			//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- END
			//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- END
			//Added by Ketan for Req. no. 946 -- START
			if(ConstantsUtil.MANUFACTURER_EQUIVALENT.equals(sRelationShip)) {
				mlList.sort(ConstantsUtil.SELECT_REVISION, ConstantsUtil.ASCENDING,
						ConstantsUtil.INTEGER);
				mlList.sort(ConstantsUtil.SELECT_NAME, ConstantsUtil.ASCENDING,
						ConstantsUtil.STRING);
			}
			//Added by Ketan for Req. no. 946 -- END
			Iterator objectListItr = mlList.iterator();

			StringList slParentOwnerShip = new StringList();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbDescription = new StringBuilder();
			StringBuilder sbAllowedMEPName = new StringBuilder();
			StringBuilder sbAllowedMEPTitle = new StringBuilder();
			StringBuilder sbAllowedMEPVendor = new StringBuilder();
			StringBuilder sbAllowedMEPId = new StringBuilder();
			StringBuilder sbAllowedMEPType = new StringBuilder();
			StringBuilder sbManuf = new StringBuilder();
			StringBuilder sbSupp = new StringBuilder();
			StringBuilder sbPQRName = new StringBuilder();
			StringBuilder sbPQRState = new StringBuilder();
			StringBuilder sbPQRRevision = new StringBuilder();
			StringBuilder sbPQRDescription = new StringBuilder();
			StringBuilder sbPQRStatus = new StringBuilder();
			StringBuilder sbPQRComments = new StringBuilder();
			StringBuilder sbPQRPlants = new StringBuilder();
			StringBuilder sbPQRPCP = new StringBuilder();
			StringBuilder sbPQRBA = new StringBuilder();
			StringBuilder sbPQRID = new StringBuilder();
			StringBuilder sbPQRType = new StringBuilder();
			//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- START
			StringBuilder sbArtworkPrimary = new StringBuilder();
			StringBuilder sbArtworkSecondary = new StringBuilder();
			//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- END
			//SPEC: <20.12.2021>: Guna Added for 42013 Req  Dev 18x.6.0.3 Release --- START
			PQRBO pqrBO = new PQRBO();
			//SPEC: <20.12.2021>: Guna Added for 42013 Req  Dev 18x.6.0.3 Release --- END
			String strSplier = "";
			String strMfr = "";
			//Added by Manikanta for Req. no. 2334 - START
			String strStreetNo = ConstantsUtil.EMPTY_STRING;
			String strSteetName = ConstantsUtil.EMPTY_STRING;
			String strCity = ConstantsUtil.EMPTY_STRING;
			String strState = ConstantsUtil.EMPTY_STRING;
			String strMarket = ConstantsUtil.EMPTY_STRING;
			String strPostalcode = ConstantsUtil.EMPTY_STRING;
			
			//Added by Manikanta for Req. no. 2334 - END
			
			
			StringList strSplierList = new StringList();
			StringList strMfrList = new StringList();

					while (objectListItr.hasNext()) {
						Map resultMaps = (Map) objectListItr.next();
						StringBuilder sbAddress = new StringBuilder();
						String sClassId = ConstantsUtil.EMPTY_STRING;
						//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- START
						String strArtworkPrimary = ConstantsUtil.EMPTY_STRING;
						String strArtworkSecondary = ConstantsUtil.EMPTY_STRING;
						
						String sPQRObjectId = validator.getClassType(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
						// SPEC: <11-17-2020>: Modified for Defect 37342 -- END

						if (sPQRObjectId != null) {
							sClassId = sPQRObjectId.getClass().getSimpleName();
						}
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 22 March 2021 -- START
						String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
						if (UIUtil.isNotNullAndNotEmpty(sCurrent) && sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE))
							continue;
						//SPEC: Release SR18x.6.0.1- Added by Manikanta for EBP Req# 33248- START
						String sObjId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
						boolean bshowData = checkHasAccess(context, sUserType, sObjId);
						
						//Check if Same Supplier : added by Jwala for the defect 50643 -- START
						boolean isUserCMandSP = isUserCMandSP(context, sObjId);
						//Check if Same Supplier : added by Jwala for the defect 50643 -- END
						
						if (isModificatinRequired() && !bshowData) {
							continue;
						}
						//SPEC: Release SR18x.6.0.1- Added by Manikanta for EBP Req# 33248- END
						//SPEC: Release SR18x.6.0 - Defect#InternalDefect Added  by gaikwad.tg on Date 04 May 2021 -- START :: Added
						String sTypeTemp = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));

						StringList slTypeList = getTypeToDisplayStateAsReleased();
						if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && slTypeList.contains(sTypeTemp))
							sCurrent = ConstantsUtil.RELEASED;
						if (sPQRObjectId.equalsIgnoreCase(ConstantsUtil.STRING)
								|| sPQRObjectId.equalsIgnoreCase(ConstantsUtil.EMPTY_STRING)) {

							String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
							
							String sType = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
							String sName = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
							String sRev = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));

							String sDesc = validator
									.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
							
							
							sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
							//SPEC: 03/03/2021: Modified for 18x.6 DEV by Bala-- START
							if (sType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)) {
								strArtworkPrimary = validator
										.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY));
								strArtworkPrimary = strArtworkPrimary.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
								strArtworkSecondary = validator
										.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTR_PG_ARTWORK_SECONDARY));
								strArtworkSecondary = strArtworkSecondary.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
							}
							if (sCurrent.equals(ConstantsUtil.STATE_PRELIMINARY)) {
								if (bMEP) {
									sCurrent = ConstantsUtil.STATE_INWORK;
								}
							}
							// Guna Added for Defect 38097 18x.5.2 Release -- END
							//Modified by Ganesh for External Defect---->START
							if (sCurrent.equals(ConstantsUtil.STATE_RELEASE)) {
								if (bMEP) {
									sCurrent = ConstantsUtil.RELEASED;
								}
							}
							//Modified by Ganesh for External Defect---->STOP
							if (bMEP) {
								strMfr = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
								//Modified by Manikanta for Req. no. 2334 - START
								strStreetNo = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_PGHOUSENUMBER));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strStreetNo))
									strStreetNo = ConstantsUtil.EMPTY_SPACE;
								strSteetName = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_ADDRESS));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strSteetName))
									strSteetName = ConstantsUtil.EMPTY_SPACE;
								strCity = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_CITY));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strCity))
									strCity = ConstantsUtil.EMPTY_SPACE;
								strState = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_STATE));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strState))
									strState = ConstantsUtil.EMPTY_SPACE;
								strMarket = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_COUNTRY));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strMarket))
									strMarket = ConstantsUtil.EMPTY_SPACE;
								strPostalcode = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_IS_VENDOR));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strPostalcode))
									strPostalcode = ConstantsUtil.EMPTY_SPACE;
								
								sbAddress.append(strMfr).append(ConstantsUtil.EMPTY_SPACE).append(strStreetNo).append(ConstantsUtil.EMPTY_SPACE).append(strSteetName).append(ConstantsUtil.SYMBL_NEWLINE).append(strCity).append(ConstantsUtil.EMPTY_SPACE).append(strState).append(ConstantsUtil.SYMBL_NEWLINE).append(strMarket).append(ConstantsUtil.EMPTY_SPACE).append(strPostalcode);
								
								//Check if Same Supplier : added by Jwala for the defect 50643 -- START
								if(isUserCMandSP && (ConstantsUtil.PG_SP.equals(sUserViewType))) {
								boolean bSameSupplier = isSameSupplier(context, strMfr);
								if(!bSameSupplier)
									continue;
								}
								strMfr = sbAddress.toString();
								//Modified by Manikanta for Req. no. 2334 - END
								//Check if Same Supplier : added by Jwala for the defect 50643 -- END
								
								// SPEC: Release 1.0.2: Modified for Defect 37852 by
								// Amman-- END
							} else {
								// SPEC: Release 1.0.2: Modified for Defect 37852 by
								// Amman-- START
								// strSplier = validator
								// .getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
								strSplier = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
								//Modified by Manikanta for Req. no. 2334 - START
								strStreetNo = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_SUPPLYRESPONSIBILITY_PGHOUSENUMBER));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strStreetNo))
									strStreetNo = ConstantsUtil.EMPTY_SPACE;
								strSteetName = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_SUPPLYRESPONSIBILITY_ADDRESS));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strSteetName))
									strSteetName = ConstantsUtil.EMPTY_SPACE;
								strCity = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strCity))
									strCity = ConstantsUtil.EMPTY_SPACE;
								strState = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strState))
									strState = ConstantsUtil.EMPTY_SPACE;
								strMarket = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_COUNTRY));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strMarket))
									strMarket = ConstantsUtil.EMPTY_SPACE;
								strPostalcode = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_SUPPLYRESPONSIBILITY_POSTALCODE));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strPostalcode))
									strPostalcode = ConstantsUtil.EMPTY_SPACE;
								
								sbAddress.append(strSplier).append(ConstantsUtil.EMPTY_SPACE).append(strStreetNo).append(ConstantsUtil.EMPTY_SPACE).append(strSteetName).append(ConstantsUtil.SYMBL_NEWLINE).append(strCity).append(ConstantsUtil.EMPTY_SPACE).append(strState).append(ConstantsUtil.SYMBL_NEWLINE).append(strMarket).append(ConstantsUtil.EMPTY_SPACE).append(strPostalcode);
								
								//Check if Same Supplier : added by Jwala for the defect 50643 -- START
								if(isUserCMandSP && (ConstantsUtil.PG_SP.equals(sUserViewType))) {
								boolean bSameSupplier = isSameSupplier(context, strSplier);
								if(!bSameSupplier)
									continue;
								}
								strSplier = sbAddress.toString();
								//Modified by Manikanta for Req. no. 2334 - END
								//Check if Same Supplier : added by Jwala for the defect 50643 -- END
								// SPEC: Release 1.0.2: Modified for Defect 37852 by
								// Amman-- END
							}
							
							//Added by Subhajit - Req - 45670 - Start
							String sPolicy = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_POLICY));
							mlAllowedMEPList = getAllowedMEPSEPforPQR(context,sId,sPolicy,sContextObjectPolicy);
							
							String sAllowedMEPName = "";
							String sAllowedMEPTitle = "";
							String sAllowedMEPManu = "";
							String sAllowedMEPId = "";
							String sAllowedMEPType = "";
							String sAllowedMEPState = "";
							StringBuilder sbEachAllowedMEPName = new StringBuilder();
							StringBuilder sbEachAllowedMEPTitle = new StringBuilder();
							StringBuilder sbEachAllowedMEPManu = new StringBuilder();
							StringBuilder sbEachAllowedMEPId = new StringBuilder();
							StringBuilder sbEachAllowedMEPType = new StringBuilder();
							Map mpAllowedSEP = null;
						
							
							if(mlAllowedMEPList != null && mlAllowedMEPList.size() > 0){
								for (Iterator itr = mlAllowedMEPList.iterator(); itr.hasNext();){
									mpAllowedSEP = (Map) itr.next();
									sAllowedMEPName =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_NAME);
									sAllowedMEPTitle =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_TITLE);
									sAllowedMEPManu =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_VENDOR);
									sAllowedMEPId =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_ID);
									sAllowedMEPType =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_TYPE);
									sAllowedMEPState =(String)mpAllowedSEP.get(ConstantsUtil.STATE );
									
									if(isUserCMandSP || isOnlySupplier()) {
										boolean bSameSupplier = isSameSupplier(context, sAllowedMEPManu);
										if(!bSameSupplier)
											continue;
									}
									//Added by Manikanta for Req. no. 2334 - START
									sAllowedMEPManu =(String)mpAllowedSEP.get(ConstantsUtil.VENDOR_STREET_ADDRESS);
									//Added by Manikanta for Req. no. 2334 - END
									sbEachAllowedMEPName.append(sAllowedMEPName);
									sbEachAllowedMEPName.append(ConstantsUtil.SYMBL_COMMA);
									sbEachAllowedMEPTitle.append(sAllowedMEPTitle);
									sbEachAllowedMEPTitle.append(ConstantsUtil.SYMBL_COMMA);
									sbEachAllowedMEPManu.append(sAllowedMEPManu);
									sbEachAllowedMEPManu.append(ConstantsUtil.SYMBL_COMMA);
									sbEachAllowedMEPType.append(sAllowedMEPType);
									sbEachAllowedMEPType.append(ConstantsUtil.SYMBL_COMMA);
									boolean showDataAllowedMEP = checkHasAccess(context, sUserType, sAllowedMEPId);
									
									if(!showDataAllowedMEP) {
										sAllowedMEPId = ConstantsUtil.NO_ACCESS;
									}
									if(!(sAllowedMEPState.equals(ConstantsUtil.RELEASE)|| sAllowedMEPState.equalsIgnoreCase(ConstantsUtil.RELEASED)))//added by pooja for internal defect
									{
										sAllowedMEPId = ConstantsUtil.NO_ACCESS;
									}
										
									sbEachAllowedMEPId.append(sAllowedMEPId);
									sbEachAllowedMEPId.append(ConstantsUtil.SYMBL_COMMA);
									
									
								}
							}	
							
							//Added by Subhajit - Req - 45670 - End

							
							//Commented by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527 - START
							//String sPartOwnership = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.OWNERSHIP)));
							//String strClassFied = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_IPCLASS));
							//String sIPClassfication = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
							//Commented by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527 - END

							String sPQRName = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME));
							String sPQRState = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE));
							sPQRState = sPQRState.replace(ConstantsUtil.RELEASED, ConstantsUtil.APPROVED);

							String sPQRRevision = validator.getStringEquivalentForStringList(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION));

							
							String sPQRDescription = validator.getStringEquivalentForSubstituteString(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRDESCRIPTION));
							// SPEC: Release 1.0.2: Modified for Defect 37852 by Amman--
							// END

							String sPQRStatus = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATUS));
							
							sPQRStatus = sPQRStatus.replace(ConstantsUtil.ACTIVERELEASED, ConstantsUtil.ACTIVEAPPROVED)
									.replace(ConstantsUtil.INACTIVERELEASED, ConstantsUtil.INACTIVEAPPROVED);

							// SPEC: <11-17-2020>: Modified for Defect 37345 -- START
							String sPQRComments = validator.getStringEquivalentForStringListWithComma(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRCOMMENTS));
							// SPEC: <11-17-2020>: Modified for Defect 37345 -- END

					
					String sPQRPlants = validator.getStringEquivalentForSubstituteString(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRPLANTS));
					//SPEC: <20.12.2021>: Guna Added for 42013 Req  Dev 18x.6.0.3 Release --- START
					if(sUserType.equals(ConstantsUtil.PG_CM)){
						StringList plantList = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRPLANTS));
						StringBuilder plantBuilder =pqrBO.getManufacturerPlants(plantList,slUserOwnership);
						sPQRPlants = plantBuilder.toString();
						if(!sPQRPlants.isEmpty()){
						sPQRPlants =sPQRPlants.substring(0, sPQRPlants.length()-1);
						sPQRPlants = sPQRPlants.replace("|",",");
						}
					}
					
							String sPQRPCP = DomainConstants.EMPTY_STRING;
							String sPQRBA = DomainConstants.EMPTY_STRING;
							if(dob.isKindOf(context, ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART))
							{
								sPQRPCP = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PQRPCPNAME));
								sPQRBA = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PQRBANAME));
							}
							else
							{
								sPQRPCP = validator.getStringEquivalentForStringListWithComma(
										resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRPCP));
								
								sPQRBA = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRBA));
								// SPEC: Release 1.0.2: Modified for Defect 37852 by Amman--
								// END

							}
							//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- END
							String sPQRID = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
							String sPQRType = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRTYPE));

							
							// Added by Ganesh Start
							BusObjectAttribUtil util = new BusObjectAttribUtil();
							
				            //Modified by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527
							//boolean showData = util.checkHasAccess(context, sUserType, sId);
							boolean showData = bshowData;
							//SPEC: Release SR18x.6.0 - Defect#InternalDefect Added  by gaikwad.tg on Date 04 May 2021 -- START :: Added
							//SPEC: Release SR18x.6.0.1- Modified by Manikanta for internal defect in Req# 34242- START
							if(showData && (sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM) || sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP)) && !(sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) || sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)))
								showData = false;
							//SPEC: Release SR18x.6.0.1- Modified by Manikanta for internal defect in Req# 34242- END
							//SPEC: Release SR18x.6.0.1 - Added for Defect# 33248 by gaikwad.tg on Date 19 May 2021 -- START
							
							if (!showData && isModificatinRequired() ) {
								continue;
							}
							//SPEC: Release SR18x.6.0 - Added for Defect# 33248 by gaikwad.tg on Date 19 May 2021 -- START
							//SPEC: Release SR18x.6.0 - Defect#InternalDefect Added  by gaikwad.tg on Date 04 May 2021 -- END :: Added
							if (showData) {
								//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- START
								if (sCurrent.equals(ConstantsUtil.STATE_RELEASE) || sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED)) {
									//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- END
									formatData(sbId, sId);
									// START :: gaikwad.tg Defect # 37852
									if (UIUtil.isNotNullAndNotEmpty(sPQRState)
											&& (sPQRState.equalsIgnoreCase(ConstantsUtil.QUALIFICATION_STATE_QUALIFIED)
													|| sPQRState.equalsIgnoreCase(ConstantsUtil.APPROVED)))
										formatData(sbPQRID, sPQRID);
									else
										formatData(sbPQRID, ConstantsUtil.NO_ACCESS);
									// END :: gaikwad.tg Defect # 37852
								} else {
									//SPEC: Release SR18x.6.0.1 - Added for Defect# 33248 by gaikwad.tg on Date 19 May 2021 -- START
									if(isModificatinRequired())
										continue;
									else
									{
										formatData(sbId, ConstantsUtil.NO_ACCESS);
										// START :: gaikwad.tg
										formatData(sbPQRID, ConstantsUtil.NO_ACCESS);
										// END :: gaikwad.tg
									}
									//SPEC: Release SR18x.6.0.1 - Added for Defect# 33248 by gaikwad.tg on Date 19 May 2021 -- END
								}

								formatData(sbRev, sRev);
								formatData(sbCurrent, sCurrent);
								formatData(sbDescription, sDesc);
								
								//Added by Subhajit, Req - 45670- Start
								formatData(sbAllowedMEPName, sbEachAllowedMEPName.toString());
								formatData(sbAllowedMEPTitle, sbEachAllowedMEPTitle.toString());
								formatData(sbAllowedMEPVendor, sbEachAllowedMEPManu.toString());
								formatData(sbAllowedMEPType, sbEachAllowedMEPType.toString());
								formatData(sbAllowedMEPId, sbEachAllowedMEPId.toString());
								//Added by Subhajit, Req - 45670 - End
								
								formatData(sbManuf, strMfr);
								formatData(sbSupp, strSplier);
								//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- START
								if (sType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)) {
									formatData(sbArtworkPrimary, strArtworkPrimary);
									formatData(sbArtworkSecondary, strArtworkSecondary);
								}
								//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- END
								// <SPEC>: 01/02/2021 Commented for defect#38183 start
								if (sPQRState != null && !sPQRState.equalsIgnoreCase(ConstantsUtil.STATE_FROZEN)) {
									formatData(sbPQRName, sPQRName);
									formatData(sbPQRState, sPQRState);
									formatData(sbPQRRevision, sPQRRevision);
									formatData(sbPQRDescription, sPQRDescription);
									formatData(sbPQRStatus, sPQRStatus);
									formatData(sbPQRComments, sPQRComments);
									formatData(sbPQRPlants, sPQRPlants);
									formatData(sbPQRPCP, sPQRPCP);
									formatData(sbPQRBA, sPQRBA);
									// formatData(sbPQRID, sPQRID);
									formatData(sbPQRType, sPQRType);
								} else {
									formatData(sbPQRName, ConstantsUtil.EMPTY_STRING);
									formatData(sbPQRState, ConstantsUtil.EMPTY_STRING);
									formatData(sbPQRRevision, ConstantsUtil.EMPTY_STRING);
									formatData(sbPQRDescription, ConstantsUtil.EMPTY_STRING);
									formatData(sbPQRStatus, ConstantsUtil.EMPTY_STRING);
									formatData(sbPQRComments, ConstantsUtil.EMPTY_STRING);
									formatData(sbPQRPlants, ConstantsUtil.EMPTY_STRING);
									formatData(sbPQRPCP, ConstantsUtil.EMPTY_STRING);
									formatData(sbPQRBA, ConstantsUtil.EMPTY_STRING);
									formatData(sbPQRType, ConstantsUtil.EMPTY_STRING);
								}
								// <SPEC>: 01/02/2021 Commented for defect#38183 end

								formatData(sbName, sName);
								formatData(sbType, mapType(sType));

							} else {
								formatData(sbId, ConstantsUtil.NO_ACCESS);
								//SPEC: Release SR18x.6.0 - Added for Defect# 41546  by gaikwad.tg on Date 30 March 2021 -- START
								//formatData(sbRev, ConstantsUtil.NO_ACCESS);
								formatData(sbRev, sRev);
								//SPEC: Release SR18x.6.0 - Added for Defect# 41546  by gaikwad.tg on Date 30 March 2021 -- END
								formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
								formatData(sbDescription, ConstantsUtil.NO_ACCESS);
								
								//Added by Subhajit, Req - 45670- , Start
								formatData(sbAllowedMEPName, ConstantsUtil.NO_ACCESS);
								formatData(sbAllowedMEPTitle, ConstantsUtil.NO_ACCESS);
								formatData(sbAllowedMEPVendor, ConstantsUtil.NO_ACCESS);
								formatData(sbAllowedMEPType, ConstantsUtil.NO_ACCESS);
								formatData(sbAllowedMEPId, ConstantsUtil.NO_ACCESS);
								//Added by Subhajit, Req -45670 - , End
								formatData(sbManuf, ConstantsUtil.NO_ACCESS);
								formatData(sbSupp, ConstantsUtil.NO_ACCESS);
								//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- START
								if (sType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)) {
									formatData(sbArtworkPrimary, ConstantsUtil.NO_ACCESS);
									formatData(sbArtworkSecondary, ConstantsUtil.NO_ACCESS);
								}
								//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- END
								// formatData(sbPQRName, sPQRName);
								formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRDescription, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRStatus, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRComments, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRPlants, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRPCP, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRBA, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRID, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRType, ConstantsUtil.NO_ACCESS);
								formatData(sbName, sName);
								// START :: gaikwad.tg
								formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
								formatData(sbType, mapType(sType));
								// END :: gaikwad.tg

							}
							// Added by Ganesh Stop
						} else {
							String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
							String sType = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
							String sName = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
							String sRev = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));

						
							String sDesc = validator
									.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
							
							sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
							// Guna Added for Defect 38097 18x.5.2 Release -- START
							if (sCurrent.equals(ConstantsUtil.STATE_PRELIMINARY)) {
								if (bMEP) {
									sCurrent = ConstantsUtil.STATE_INWORK;
								}
							}
							// Guna Added for Defect 38097 18x.5.2 Release -- END
							//Modified by Ganesh for External Defect---->START
							if (sCurrent.equals(ConstantsUtil.STATE_RELEASE)) {
								if (bMEP) {
									sCurrent = ConstantsUtil.RELEASED;
								}
							}
							//Modified by Ganesh for External Defect---->STOP
							if (bMEP) {
								
								strMfr = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
								//Modified by Manikanta for Req. no. 2334 - START
								strStreetNo = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_PGHOUSENUMBER));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strStreetNo))
									strStreetNo = ConstantsUtil.EMPTY_SPACE;
								strSteetName = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_ADDRESS));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strSteetName))
									strSteetName = ConstantsUtil.EMPTY_SPACE;
								strCity = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_CITY));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strCity))
									strCity = ConstantsUtil.EMPTY_SPACE;
								strState = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_STATE));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strState))
									strState = ConstantsUtil.EMPTY_SPACE;
								strMarket = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_COUNTRY));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strMarket))
									strMarket = ConstantsUtil.EMPTY_SPACE;
								strPostalcode = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_IS_VENDOR));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strPostalcode))
									strPostalcode = ConstantsUtil.EMPTY_SPACE;
								
								sbAddress.append(strMfr).append(ConstantsUtil.EMPTY_SPACE).append(strStreetNo).append(ConstantsUtil.EMPTY_SPACE).append(strSteetName).append(ConstantsUtil.SYMBL_NEWLINE).append(strCity).append(ConstantsUtil.EMPTY_SPACE).append(strState).append(ConstantsUtil.SYMBL_NEWLINE).append(strMarket).append(ConstantsUtil.EMPTY_SPACE).append(strPostalcode);
								
								// SPEC: Release 1.0.2: Modified for Defect 37852 by
								// Amman-- END
								//Check if Same Supplier : added by Jwala for the defect 50643 -- START
								if(isUserCMandSP && (ConstantsUtil.PG_SP.equals(sUserViewType))) {
								boolean bSameSupplier = isSameSupplier(context, strMfr);
								if(!bSameSupplier)
									continue;
								}
								strMfr = sbAddress.toString();
								//Modified by Manikanta for Req. no. 2334 - END
								//Check if Same Supplier : added by Jwala for the defect 50643 -- END
							} else {
								// SPEC: Release 1.0.2: Modified for Defect 37852 by
								// Amman-- START
								// strSplier = validator
								// .getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
								strSplier = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
								//Modified by Manikanta for Req. no. 2334 - START
								strStreetNo = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_SUPPLYRESPONSIBILITY_PGHOUSENUMBER));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strStreetNo))
									strStreetNo = ConstantsUtil.EMPTY_SPACE;
								strSteetName = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_SUPPLYRESPONSIBILITY_ADDRESS));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strSteetName))
									strSteetName = ConstantsUtil.EMPTY_SPACE;
								strCity = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strCity))
									strCity = ConstantsUtil.EMPTY_SPACE;
								strState = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strState))
									strState = ConstantsUtil.EMPTY_SPACE;
								strMarket = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_COUNTRY));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strMarket))
									strMarket = ConstantsUtil.EMPTY_SPACE;
								strPostalcode = validator.getStringEquivalentForSubstituteString(
										resultMaps.get(ConstantsUtilIRM.SELECT_SUPPLYRESPONSIBILITY_POSTALCODE));
								if(ConstantsUtil.SYMBL_ASTERISK.equals(strPostalcode))
									strPostalcode = ConstantsUtil.EMPTY_SPACE;
								
								sbAddress.append(strSplier).append(ConstantsUtil.EMPTY_SPACE).append(strStreetNo).append(ConstantsUtil.EMPTY_SPACE).append(strSteetName).append(ConstantsUtil.SYMBL_NEWLINE).append(strCity).append(ConstantsUtil.EMPTY_SPACE).append(strState).append(ConstantsUtil.SYMBL_NEWLINE).append(strMarket).append(ConstantsUtil.EMPTY_SPACE).append(strPostalcode);
								
								// SPEC: Release 1.0.2: Modified for Defect 37852 by
								// Amman-- END
								//Check if Same Supplier : added by Jwala for the defect 50643 -- START
								if(isUserCMandSP && (ConstantsUtil.PG_SP.equals(sUserViewType))) {
								boolean bSameSupplier = isSameSupplier(context, strSplier);
								if(!bSameSupplier)
									continue;
								}
								strSplier = sbAddress.toString();
								//Modified by Manikanta for Req. no. 2334 - END
								//Check if Same Supplier : added by Jwala for the defect 50643 -- END
							}

							
							//Added by Subhajit - Req - 45670 - Start
							String sPolicy = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_POLICY));
							mlAllowedMEPList = getAllowedMEPSEPforPQR(context,sId,sPolicy,sContextObjectPolicy);
							
							String sAllowedMEPName = "";
							String sAllowedMEPTitle = "";
							String sAllowedMEPManu = "";
							String sAllowedMEPId = "";
							String sAllowedMEPType = "";
							String sAllowedMEPState = "";
							StringBuilder sbEachAllowedMEPName = new StringBuilder();
							StringBuilder sbEachAllowedMEPTitle = new StringBuilder();
							StringBuilder sbEachAllowedMEPManu = new StringBuilder();
							StringBuilder sbEachAllowedMEPId = new StringBuilder();
							StringBuilder sbEachAllowedMEPType = new StringBuilder();
							Map mpAllowedSEP = null;
						
							
							if(mlAllowedMEPList != null && mlAllowedMEPList.size() > 0){
								for (Iterator itr = mlAllowedMEPList.iterator(); itr.hasNext();){
									mpAllowedSEP = (Map) itr.next();
									sAllowedMEPName =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_NAME);
									sAllowedMEPTitle =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_TITLE);
									sAllowedMEPManu =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_VENDOR);
									sAllowedMEPId =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_ID);
									sAllowedMEPType =(String)mpAllowedSEP.get(ConstantsUtilIRM.ALLOWED_MEP_TYPE);
									sAllowedMEPState =(String)mpAllowedSEP.get(ConstantsUtil.STATE );//added by pooja for internal defect
									
									if(isUserCMandSP || isOnlySupplier()) {
										boolean bSameSupplier = isSameSupplier(context, sAllowedMEPManu);
										if(!bSameSupplier)
											continue;
									}
					
									sbEachAllowedMEPName.append(sAllowedMEPName);
									sbEachAllowedMEPName.append(ConstantsUtil.SYMBL_COMMA);
									sbEachAllowedMEPTitle.append(sAllowedMEPTitle);
									sbEachAllowedMEPTitle.append(ConstantsUtil.SYMBL_COMMA);
									sbEachAllowedMEPManu.append(sAllowedMEPManu);
									sbEachAllowedMEPManu.append(ConstantsUtil.SYMBL_COMMA);
									sbEachAllowedMEPType.append(sAllowedMEPType);
									sbEachAllowedMEPType.append(ConstantsUtil.SYMBL_COMMA);
									boolean showDataAllowedMEP = checkHasAccess(context, sUserType, sAllowedMEPId);
									
										if(!showDataAllowedMEP) {
											sAllowedMEPId = ConstantsUtil.NO_ACCESS;
										}
										if(!(sAllowedMEPState.equals(ConstantsUtil.RELEASE)|| sAllowedMEPState.equalsIgnoreCase(ConstantsUtil.RELEASED)))//added by pooja for internal defect
										{
											sAllowedMEPId = ConstantsUtil.NO_ACCESS;
										}
										
									sbEachAllowedMEPId.append(sAllowedMEPId);
									sbEachAllowedMEPId.append(ConstantsUtil.SYMBL_COMMA);
									
									
								}
							}	
							
							//Added by Subhajit - Req - 45670 - End
							//Commented by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527 - START
							//String sPartOwnership = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.OWNERSHIP)));
							//String strClassFied = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_IPCLASS));
							//String sIPClassfication = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
							//Commented by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527 - END
							
							//SPEC: Release SR18x.6.0.1 - Added by Amman on June 11, 2021 for Defect #43485 -- START
							if (sType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)) {
								strArtworkPrimary = validator
										.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY));
								strArtworkPrimary = strArtworkPrimary.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
								strArtworkSecondary = validator
										.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTR_PG_ARTWORK_SECONDARY));
								strArtworkSecondary = strArtworkSecondary.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
							}
							//SPEC: Release SR18x.6.0.1 - Added by Amman on June 11, 2021 for Defect #43485 -- END

							StringList slChildId = (StringList) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID);

							StringList slSelectables = new StringList();
							slSelectables.add(ConstantsUtil.SELECT_NAME);
							slSelectables.add(ConstantsUtil.SELECT_ID);
							slSelectables.add(ConstantsUtil.SELECT_TYPE);
							slSelectables.add(ConstantsUtil.SELECT_CURRENT);
							slSelectables.add(ConstantsUtil.SELECT_REVISION);
							slSelectables.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCATIONSTATUS);
							slSelectables.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
							slSelectables.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
							slSelectables.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
							slSelectables.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
							slSelectables.add(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONDESCRIPTION);
							//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- START
							slSelectables.add(ConstantsUtilIRM.RELATIONSHIP_PRODUCT_PLATFORM_AREANAME);
							slSelectables.add(ConstantsUtilIRM.RELATIONSHIP_BUSINESS_AREANAME);
							//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- END

							//SPEC: Release SR18x5.2- modified for Defect #39183 by Govind on Date 19/02/2021 start
							BusObjectAttribUtil busutil = new BusObjectAttribUtil();
							//Modified by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527
							//boolean showDatatmp = busutil.checkHasAccess(context, sUserType, sId);
							boolean showDatatmp = bshowData;
							
							//SPEC: Release SR18x.6.0 - Added by Amman on June 11, 2021 for Defect #43468 -- START
							if(!showDatatmp && isModificatinRequired()) {
								continue;
							}
							
							//SPEC: Release SR18x.6.0 - Added by Amman on June 11, 2021 for Defect #43468 -- END

							if(!showDatatmp) {
								formatData(sbId, ConstantsUtil.NO_ACCESS);
								//SPEC: Release SR18x.6.0 - Added for Defect# 41546  by gaikwad.tg on Date 30 March 2021 -- START
								//formatData(sbRev, ConstantsUtil.NO_ACCESS);
								formatData(sbRev, sRev);
								//SPEC: Release SR18x.6.0 - Added for Defect# 41546  by gaikwad.tg on Date 30 March 2021 -- START
								formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
								formatData(sbDescription, ConstantsUtil.NO_ACCESS);
								
								//Added by Subhajit, Req - 45670- ,Start
								formatData(sbAllowedMEPName, ConstantsUtil.NO_ACCESS);
								formatData(sbAllowedMEPTitle, ConstantsUtil.NO_ACCESS);
								formatData(sbAllowedMEPVendor, ConstantsUtil.NO_ACCESS);
								formatData(sbAllowedMEPType, ConstantsUtil.NO_ACCESS);
								formatData(sbAllowedMEPId, ConstantsUtil.NO_ACCESS);
								//Added by Subhajit, Req - 45670- ,End
								
								formatData(sbManuf, ConstantsUtil.NO_ACCESS);
								formatData(sbSupp, ConstantsUtil.NO_ACCESS);
								//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- START
								if (sType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)) {
									formatData(sbArtworkPrimary, ConstantsUtil.NO_ACCESS);
									formatData(sbArtworkSecondary, ConstantsUtil.NO_ACCESS);
								}
								//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- END
								formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRDescription, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRStatus, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRComments, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRPlants, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRPCP, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRBA, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRID, ConstantsUtil.NO_ACCESS);
								formatData(sbPQRType, ConstantsUtil.NO_ACCESS);

								formatData(sbName, sName);
								formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
								formatData(sbType, mapType(sType));

							} else {
								String strtempPQRName="";
								String strtempPQRState="";
								String strtempPQRRevision="";
								String strtempPQRDescription="";
								String strtempPQRStatus="";
								String strtempPQRComments="";
								String strtempPQRPlants="";
								String strtempPQRPCP="";
								String strtempPQRBA="";
								String strtempPQRID="";
								String strtempPQRType="";
								//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- START
								String sTempRev="";
								String sTempCurrent="";
								String sTempDesc="";
								
								//Added by Subhajit, Req - 45670-,Start
								String sTempAllowedMEPName="";
								String sTempAllowedMEPTitle="";
								String sTempAllowedMEPVendor="";
								String sTempAllowedMEPType="";
								String sTempAllowedMEPId="";
								//Added by Subhajit, Req - 45670-,End
								
								String sTemptrMfr="";
								String sTemptrSplier="";
								String sTempName="";
								String sTempType="";
								String sTempId="";
								String strTempArtworkPrimary="";
								String strTempArtworkSecondary="";
								//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- END
								for (int i = 0; i < slChildId.size(); i++) { 
									String sEachChildId = slChildId.getElement(i);

									//DomainObject doPqr = new DomainObject(sEachChildId);
									DomainObject doPqr = DomainObject.newInstance(context, sEachChildId);
									// Added by Pooja for the req 35902,41754,33476 -- START
									StringList plantSelect =new StringList(1);
									plantSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
									// SPEC: Added by Ketan for Defect 50185 -- START
									plantSelect.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
									plantSelect.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
									// SPEC: Added by Ketan for Defect 50185 -- END
									// Added by Pooja for the req 35902,41754,33476 -- END
									// SPEC: <11-24-2020>: Modified for Defect 37555 by
									// Amman -- START
									DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
									//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- START
									DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
									//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- END
									// SPEC: Release SR18x.5.2: Added for Defect 38205 by
									// Amman ## -- START
									DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
									// SPEC: Release SR18x.5.2: Added for Defect 38205 by
									// Amman ## -- END
									//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- START
									DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.RELATIONSHIP_BUSINESS_AREANAME);
									DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.RELATIONSHIP_PRODUCT_PLATFORM_AREANAME);
									//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- END
									Map pqrMapList = doPqr.getInfo(context, slSelectables,plantSelect);
									
									//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
									doPqr.close(context);
									//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
									DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
									//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- START
									DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
									//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- END
									// SPEC: Release SR18x.5.2: Added for Defect 38205 by
									// Amman ## -- START
									DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
									// SPEC: Release SR18x.5.2: Added for Defect 38205 by
									// Amman ## -- END
									//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- START
									DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.RELATIONSHIP_BUSINESS_AREANAME);
									DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.RELATIONSHIP_PRODUCT_PLATFORM_AREANAME);
									//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- END
									// SPEC: Release SR18x.5.2: Added for Defect 37555 by
									// Amman -- END

									// SPEC: Release 1.0.2: Modified related to Defect 37852
									// by Amman after Code Review to provide null check --
									// START
									// String sPQRName = (String)
									// pqrMapList.get(ConstantsUtil.SELECT_NAME);
									String sPQRName = validator
											.getStringEquivalentForStringList(pqrMapList.get(ConstantsUtil.SELECT_NAME));
									// String sPQRState = (String)
									// pqrMapList.get(ConstantsUtil.SELECT_CURRENT);
									String sPQRState = validator
											.getStringEquivalentForStringList(pqrMapList.get(ConstantsUtil.SELECT_CURRENT));
									sPQRState = sPQRState.replace(ConstantsUtil.RELEASED, ConstantsUtil.APPROVED);
									//SPEC: Release SR18x5.2- Commented for Defect #39778 by Govind on Date 20/02/2021 start
									/*if (sPQRState.equalsIgnoreCase(ConstantsUtil.STATE_FROZEN)) {
									continue;
								}*/
								//SPEC: Release SR18x5.2- Commented for Defect #39778 by Govind on Date 20/02/2021 end
								// String sPQRRevision = (String)
								// pqrMapList.get(ConstantsUtil.SELECT_REVISION);
								String sPQRRevision = validator
										.getStringEquivalentForStringList(pqrMapList.get(ConstantsUtil.SELECT_REVISION));
								// String sPQRDescription = (String)
								// pqrMapList.get(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONDESCRIPTION);
								String sPQRDescription = validator.getStringEquivalentForSubstituteString(
										pqrMapList.get(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONDESCRIPTION));
								// String sPQRStatus = (String)
								// pqrMapList.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCATIONSTATUS);
								String sPQRStatus = validator.getStringEquivalentForStringList(
										pqrMapList.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCATIONSTATUS));
								
								sPQRStatus = sPQRStatus.replace(ConstantsUtil.ACTIVERELEASED, ConstantsUtil.ACTIVEAPPROVED)
										.replace(ConstantsUtil.INACTIVERELEASED, ConstantsUtil.INACTIVEAPPROVED);
		
								// String sPQRComments = (String)
								// pqrMapList.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
								String sPQRComments = validator.getStringEquivalentForSubstituteString(
										pqrMapList.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
								// String sPQRID = (String)
								// pqrMapList.get(ConstantsUtil.SELECT_ID);
								String sPQRID = validator
										.getStringEquivalentForStringList(pqrMapList.get(ConstantsUtil.SELECT_ID));
								// String sPQRType = (String)
								// pqrMapList.get(ConstantsUtil.SELECT_TYPE);
								String sPQRType = validator
										.getStringEquivalentForStringList(pqrMapList.get(ConstantsUtil.SELECT_TYPE));
								
								String sPQRPlants = validator.getStringEquivalentForSubstituteString(
										pqrMapList.get(ConstantsUtil.STR_SELECT_PLANT_NAME));
								//SPEC: <20.12.2021>: Guna Added for 42013 Req  Dev 18x.6.0.3 Release --- START
								if(sUserType.equals(ConstantsUtil.PG_CM)){
								
								StringList plantList = validator.getStringListEquivalentForString(pqrMapList.get(ConstantsUtil.STR_SELECT_PLANT_NAME));
								StringBuilder plantBuilder =pqrBO.getManufacturerPlants(plantList,slUserOwnership);
								sPQRPlants = plantBuilder.toString();
								if(!sPQRPlants.isEmpty()){
								sPQRPlants =sPQRPlants.substring(0, sPQRPlants.length()-1);
								sPQRPlants =sPQRPlants.replace("|",",");
								}
								}
								//SPEC: <20.12.2021>: Guna Added for 42013 Req  Dev 18x.6.0.3 Release --- END
								//sUserCompanies
								
								//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- START
								String sPQRPCP = DomainConstants.EMPTY_STRING;
								String sPQRBA = DomainConstants.EMPTY_STRING;
								if(dob.isKindOf(context, ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART))
								{
									sPQRPCP = validator.getStringEquivalentForStringListWithComma(pqrMapList.get(ConstantsUtilIRM.RELATIONSHIP_PRODUCT_PLATFORM_AREANAME));
									sPQRBA = validator.getStringEquivalentForStringListWithComma(pqrMapList.get(ConstantsUtilIRM.RELATIONSHIP_BUSINESS_AREANAME));
								}
								else
								{
									sPQRPCP = validator.getStringEquivalentForStringListWithComma(
										pqrMapList.get(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA));
								
									sPQRBA = validator.getStringEquivalentForStringListWithComma(pqrMapList.get(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA));
								//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- END
								}
								
								// Added by Ganesh Start
								BusObjectAttribUtil util = new BusObjectAttribUtil();
								//Modified by Subhajit for Performance Issue - Defect No - 51963 and PRB0100527
								//boolean showData = util.checkHasAccess(context, sUserType, sId);
								boolean showData = bshowData;
								
								if (showData) {

									if (sPQRState != null && !sPQRState.equalsIgnoreCase(ConstantsUtil.STATE_FROZEN)) {

										if (sCurrent.trim().equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) || sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED)) 
										{
											if (UIUtil.isNotNullAndNotEmpty(sPQRState) && (sPQRState.equalsIgnoreCase(ConstantsUtil.QUALIFICATION_STATE_QUALIFIED) || sPQRState.equalsIgnoreCase(ConstantsUtil.APPROVED)))
											{
												strtempPQRID+=sPQRID+ConstantsUtil.SYMBL_PIPE;
												strtempPQRType+=sPQRType+ConstantsUtil.SYMBL_PIPE;
											}
											else 
											{
												strtempPQRID+=ConstantsUtil.NO_ACCESS+ConstantsUtil.SYMBL_PIPE;
												strtempPQRType+=ConstantsUtil.NO_ACCESS+ConstantsUtil.SYMBL_PIPE;
											}
										} 
										else 
										{
											strtempPQRID+=ConstantsUtil.NO_ACCESS+ConstantsUtil.SYMBL_PIPE;
											strtempPQRType+=ConstantsUtil.NO_ACCESS+ConstantsUtil.SYMBL_PIPE;
										}
										//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- END
										strtempPQRName+=sPQRName+ConstantsUtil.SYMBL_PIPE;
										strtempPQRState+=sPQRState+ConstantsUtil.SYMBL_PIPE;
										strtempPQRRevision+=sPQRRevision+ConstantsUtil.SYMBL_PIPE;
										strtempPQRDescription+=sPQRDescription+ConstantsUtil.SYMBL_PIPE;
										strtempPQRStatus+=sPQRStatus+ConstantsUtil.SYMBL_PIPE;
										strtempPQRComments+=sPQRComments+ConstantsUtil.SYMBL_PIPE;
										strtempPQRPlants+=sPQRPlants+ConstantsUtil.SYMBL_PIPE;
										strtempPQRPCP+=sPQRPCP+ConstantsUtil.SYMBL_PIPE;
										strtempPQRBA+=sPQRBA+ConstantsUtil.SYMBL_PIPE;
										//SPEC: Release SR18x.6.0 - Added for Defect# 41584  by gaikwad.tg on Date 30 March 2021 -- START
										//strtempPQRType+=sPQRType+ConstantsUtil.SYMBL_PIPE;
										//SPEC: Release SR18x.6.0 - Added for Defect# 41584  by gaikwad.tg on Date 30 March 2021 -- END
										//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 March 2021 -- END
									} else {
											continue;

										}
										
										sTempRev+=sRev+ConstantsUtil.SYMBL_PIPE;
										sTempCurrent+=sCurrent+ConstantsUtil.SYMBL_PIPE;
										sTempDesc+=sDesc+ConstantsUtil.SYMBL_PIPE;
										
										//Added by Subhajit, Req - 45670- Start
										sTempAllowedMEPName+=sbEachAllowedMEPName.toString()+ConstantsUtil.SYMBL_PIPE;
										sTempAllowedMEPTitle+=sbEachAllowedMEPTitle.toString()+ConstantsUtil.SYMBL_PIPE;
										sTempAllowedMEPVendor+=sbEachAllowedMEPManu.toString()+ConstantsUtil.SYMBL_PIPE;
										sTempAllowedMEPType+=sbEachAllowedMEPType.toString()+ConstantsUtil.SYMBL_PIPE;
										sTempAllowedMEPId+=sbEachAllowedMEPId.toString()+ConstantsUtil.SYMBL_PIPE;
										
										//Added by Subhajit, Req - 45670- End
										
										sTemptrMfr+=strMfr+ConstantsUtil.SYMBL_PIPE;
										sTemptrSplier+=strSplier+ConstantsUtil.SYMBL_PIPE;
										sTempName+=sName+ConstantsUtil.SYMBL_PIPE;
										sTempType+=mapType(sType)+ConstantsUtil.SYMBL_PIPE;
										//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- START
										if(sCurrent.trim().equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) || sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED))
											sTempId+=sId+ConstantsUtil.SYMBL_PIPE;
										else
											sTempId+=ConstantsUtil.NO_ACCESS+ConstantsUtil.SYMBL_PIPE;
										//SPEC: Release SR18x.6.0 - Added for Defect# 41967 by gaikwad.tg on Date 01 April 2021 -- END
										strTempArtworkPrimary+=strArtworkPrimary+ConstantsUtil.SYMBL_PIPE;
										strTempArtworkSecondary+=strArtworkSecondary+ConstantsUtil.SYMBL_PIPE;
										//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 March 2021 -- END

									} 
									

								} 
								appendData(sbRev, sTempRev);
								appendData(sbCurrent, sTempCurrent);
								appendData(sbDescription, sTempDesc);
								//Added by Subhajit, Req - 45670- Start
								appendData(sbAllowedMEPName, sTempAllowedMEPName);
								appendData(sbAllowedMEPTitle, sTempAllowedMEPTitle);
								appendData(sbAllowedMEPVendor, sTempAllowedMEPVendor);
								appendData(sbAllowedMEPId, sTempAllowedMEPId);
								appendData(sbAllowedMEPType, sTempAllowedMEPType);
								//Added by Subhajit, Req -45670 - End
								appendData(sbManuf, sTemptrMfr);
								appendData(sbSupp, sTemptrSplier);
								appendData(sbName, sTempName);
								appendData(sbType, sTempType);
								appendData(sbId, sTempId);					
								if (sType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)) {
									appendData(sbArtworkPrimary, strTempArtworkPrimary);
									appendData(sbArtworkSecondary, strTempArtworkSecondary);
								}
								//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 March 2021 -- END
								appendData(sbPQRName, strtempPQRName);
								appendData(sbPQRState, strtempPQRState);
								appendData(sbPQRRevision, strtempPQRRevision);
								appendData(sbPQRDescription, strtempPQRDescription);
								appendData(sbPQRStatus,strtempPQRStatus);
								appendData(sbPQRComments, strtempPQRComments);
								appendData(sbPQRPlants,strtempPQRPlants);
								appendData(sbPQRPCP, strtempPQRPCP);
								appendData(sbPQRBA,strtempPQRBA);
								appendData(sbPQRType, strtempPQRType);
								appendData(sbPQRID, strtempPQRID);
								//SPEC: Release SR18x.6.0 - Added for Defect# 41584  by gaikwad.tg on Date 30 March 2021 -- END
							} 
							//SPEC: Release SR18x5.2- modified for Defect #39183 by Govind on Date 19/02/2021 end
						} // closing for if not String
					} // for iterator
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					dob.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					mpEquivalents.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
					mpEquivalents.put(ConstantsUtil.ID, sbId.toString());
					mpEquivalents.put(ConstantsUtil.TYPE, sbType.toString());
					mpEquivalents.put(ConstantsUtil.NAME, sbName.toString());
					mpEquivalents.put(ConstantsUtil.REV, sbRev.toString());
					mpEquivalents.put(ConstantsUtil.STATE, sbCurrent.toString());
					//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- START
					if (sbType.toString().contains(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)) {
						mpEquivalents.put(ConstantsUtil.ARTWORKPRIMARY, sbArtworkPrimary.toString());
						mpEquivalents.put(ConstantsUtilIRM.ARTWORKSECONDARY, sbArtworkSecondary.toString());
					}
					//SPEC: 03/03/2021: Added for 18x.6 DEV by Bala-- END
					if (bMEP) {
						mpEquivalents.put(ConstantsUtil.MANUFACTURER, sbManuf.toString());
					} else {
						mpEquivalents.put(ConstantsUtil.SUPPLIER, sbSupp.toString());
						//Added by Subhajit, Req - 45670- , Start
						mpEquivalents.put(ConstantsUtilIRM.ALLOWED_MEP_NAME, sbAllowedMEPName.toString());
						mpEquivalents.put(ConstantsUtilIRM.ALLOWED_MEP_TITLE, sbAllowedMEPTitle.toString());
						mpEquivalents.put(ConstantsUtilIRM.ALLOWED_MEP_VENDOR, sbAllowedMEPVendor.toString());
						mpEquivalents.put(ConstantsUtilIRM.ALLOWED_MEP_ID, sbAllowedMEPId.toString());
						mpEquivalents.put(ConstantsUtilIRM.ALLOWED_MEP_TYPE, sbAllowedMEPType.toString());
						//Added by Subhajit, Req - 45670- , End
					}
					// SPEC 11.19.2020 : Amman Commented --START
					mpEquivalents.put(ConstantsUtil.PQRNAME, sbPQRName.toString());
					// mpEquivalents.put(ConstantsUtil.QUALIFICATIONNAME,
					// sbPQRName.toString());
					// SPEC 11.19.2020 : Amman Commented --END
					mpEquivalents.put(ConstantsUtil.PQRSTATE, sbPQRState.toString());
					mpEquivalents.put(ConstantsUtil.PQRREVISION, sbPQRRevision.toString());
					mpEquivalents.put(ConstantsUtil.PQRDESCRIPTION, sbPQRDescription.toString());
					mpEquivalents.put(ConstantsUtil.PQRSTATUS, sbPQRStatus.toString());
					mpEquivalents.put(ConstantsUtil.PQRCOMMENTS, sbPQRComments.toString());
					mpEquivalents.put(ConstantsUtil.PQRPLANTS, sbPQRPlants.toString());
					mpEquivalents.put(ConstantsUtil.PQRPCP, sbPQRPCP.toString());
					mpEquivalents.put(ConstantsUtil.PQRBA, sbPQRBA.toString());
					mpEquivalents.put(ConstantsUtil.PQRID, sbPQRID.toString());
					mpEquivalents.put(ConstantsUtil.PQRTYPE, sbPQRType.toString());

				} catch (Exception e) {

					LOGGER.error("Error from BUSEXTRACTUTIL:  getPQREquivalents" + e);
					return new HashMap();
				}
				return filterMapList(mpEquivalents);
	}
	
	/**
	 * This Method is for getting the Allowed MEPs and SEPs for PQR Equivalents
	 * 
	 * @param Context context
	 * @param String strObjId (Connected Object Id)
	 * @param String strPolicy (Connected object policy)
	 * @param String strParentPolicy (Context object policy)
	 * @return MapList
	 * @throws Exception
	 */
	//Added by Subhajit, Req -45670 - , Start
	public MapList getAllowedMEPSEPforPQR(Context context, String strObjId, String strPolicy ,String strParentPolicy) throws Exception {
		MapList mlAllowedMEPList = new MapList();
		DomainObject doObj = DomainObject.newInstance(context, strObjId);
		StringList objectSelects=new StringList(4);
		String sManuName = "to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"].from.name";
		String sVendorName = "to["+ConstantsUtil.RELATIONSHIP_SUPPLYRESPONSIBILITY+"].from.name";
		objectSelects.add(sVendorName);
		objectSelects.add(sManuName);
		//Added by Manikanta for Req. no. 2334 - START
		objectSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_CITY);
		objectSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_STATE);
		objectSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_COUNTRY);
		objectSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_PGHOUSENUMBER);
		objectSelects.add(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_ADDRESS);
		objectSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_VENDOR);
		String strStreetNo = ConstantsUtil.EMPTY_STRING;
		String strSteetName = ConstantsUtil.EMPTY_STRING;
		String strCity = ConstantsUtil.EMPTY_STRING;
		String strState = ConstantsUtil.EMPTY_STRING;
		String strMarket = ConstantsUtil.EMPTY_STRING;
		String strPostalcode = ConstantsUtil.EMPTY_STRING;
		
		//Added by Manikanta for Req. no. 2334 - END
		String strManu = DomainConstants.EMPTY_STRING;
		
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		objectSelects.add(DomainConstants.SELECT_NAME);
		objectSelects.add(DomainConstants.SELECT_ID);
		objectSelects.add(DomainConstants.SELECT_TYPE);
		objectSelects.add(DomainConstants.SELECT_CURRENT);//added by pooja for internal defect
		Map mpAllowedSEP= new HashMap();
		Map mpAllowedMEP= new HashMap();
		Map mpAllowedMEPSEP= new HashMap();
		String strName= DomainConstants.EMPTY_STRING;
		String strTitle= DomainConstants.EMPTY_STRING;
		String strId= DomainConstants.EMPTY_STRING;
		String strType= DomainConstants.EMPTY_STRING;
		String strMEPObject = ConstantsUtilIRM.MEP ;
		String strSEPObject = ConstantsUtilIRM.SEP ;
		
		String strObjWhere = DomainConstants.SELECT_CURRENT +"!=" + ConstantsUtil.STATE_OBSOLETE;
	
		try{
			if(ConstantsUtil.POLICY_SUPPLIEREQUIVALENT.equalsIgnoreCase(strPolicy)){
					
				MapList mlObjListSEP= doObj.getRelatedObjects(context, //Context
						ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT, //relPattern
						ConstantsUtil.SYMBL_ASTERISK, //typePattern
																		objectSelects, //objectSelects
																		null,// relationshipSelects
																		false, //getTo - Get Parent Data
																		true, //getFrom - Get Child Data
																		(short)1, //recurseToLevel
																		strObjWhere, //objectWhere
																		null); //relationshipWhere
					
				if(mlObjListSEP != null && mlObjListSEP.size() > 0){
					for (Iterator i = mlObjListSEP.iterator(); i.hasNext();){
						StringBuilder sbAddress = new StringBuilder();
						mpAllowedSEP = (Map) i.next();
						strName =(String)mpAllowedSEP.get(DomainConstants.SELECT_NAME);
						strTitle=(String)mpAllowedSEP.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
						strId = (String)mpAllowedSEP.get(DomainConstants.SELECT_ID);
						strType = (String)mpAllowedSEP.get(DomainConstants.SELECT_TYPE);
						String strCurrent = (String)mpAllowedSEP.get(DomainConstants.SELECT_CURRENT);//added by pooja for internal defect
						strManu = (String) mpAllowedSEP.get(sManuName);
						//Added by Manikanta for Req. no. 2334 - START
						strStreetNo = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_PGHOUSENUMBER);
						if(ConstantsUtil.SYMBL_ASTERISK.equals(strStreetNo))
							strStreetNo = ConstantsUtil.EMPTY_SPACE;
						strSteetName = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_ADDRESS);
						if(ConstantsUtil.SYMBL_ASTERISK.equals(strSteetName))
							strSteetName = ConstantsUtil.EMPTY_SPACE;
						strCity = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_CITY);
						if(ConstantsUtil.SYMBL_ASTERISK.equals(strCity))
							strCity = ConstantsUtil.EMPTY_SPACE;
						strState = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_STATE);
						if(ConstantsUtil.SYMBL_ASTERISK.equals(strState))
							strState = ConstantsUtil.EMPTY_SPACE;
						strMarket = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_COUNTRY);
						if(ConstantsUtil.SYMBL_ASTERISK.equals(strMarket))
							strMarket = ConstantsUtil.EMPTY_SPACE;
						strPostalcode = (String) mpAllowedSEP.get(ConstantsUtil.STR_SELECT_PLANT_IS_VENDOR);
						if(ConstantsUtil.SYMBL_ASTERISK.equals(strPostalcode))
							strPostalcode = ConstantsUtil.EMPTY_SPACE;
						
						sbAddress.append(strManu).append(ConstantsUtil.EMPTY_SPACE).append(strStreetNo).append(ConstantsUtil.EMPTY_SPACE).append(strSteetName).append(ConstantsUtil.SYMBL_NEWLINE).append(strCity).append(ConstantsUtil.EMPTY_SPACE).append(strState).append(ConstantsUtil.SYMBL_NEWLINE).append(strMarket).append(ConstantsUtil.EMPTY_SPACE).append(strPostalcode);
						//Added by Manikanta for Req. no. 2334 - END
						Map<String, String> mapAllowedMEP = new HashMap<String, String>();
					
						
						if(!(ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT.equalsIgnoreCase(strParentPolicy) || ConstantsUtil.POLICY_SUPPLIEREQUIVALENT.equalsIgnoreCase(strParentPolicy))){
							if(strName.contains(strMEPObject)) {
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_NAME, strName);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_TITLE, strTitle);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_VENDOR, strManu);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_TYPE, strType);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_ID, strId);
								mapAllowedMEP.put(ConstantsUtil.STATE, strCurrent);
								//Added by Manikanta for Req. no. 2334 - START
								mapAllowedMEP.put(ConstantsUtil.VENDOR_STREET_ADDRESS, sbAddress.toString());
								//Added by Manikanta for Req. no. 2334 - END
							}
						}
						else{
							if(strName.contains(strSEPObject) || strName.contains(strMEPObject)){
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_NAME, strName);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_TITLE, strTitle);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_VENDOR, strManu);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_TYPE, strType);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_ID, strId);
								mapAllowedMEP.put(ConstantsUtil.STATE, strCurrent);
								//Added by Manikanta for Req. no. 2334 - START
								mapAllowedMEP.put(ConstantsUtil.VENDOR_STREET_ADDRESS, sbAddress.toString());
								//Added by Manikanta for Req. no. 2334 - END
							}
								
						}
						mlAllowedMEPList.add(mapAllowedMEP);
					}
				}
			}
			else if(ConstantsUtil.POLICY_EC_PART.equalsIgnoreCase(strPolicy)){
				Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT);
				relType.addPattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
				
				MapList mlObjListSEPMEP = doObj.getRelatedObjects(context, //Context
						relType.getPattern(),	//relPattern
						ConstantsUtil.SYMBL_ASTERISK, //typePattern
																		objectSelects, //objectSelects
																		null,// relationshipSelects
																		false, //getTo - Get Parent Data
																		true, //getFrom - Get Child Data
																		(short)1, //recurseToLevel
																		strObjWhere, //objectWhere
																		null); //relationshipWhere
				if(mlObjListSEPMEP != null && mlObjListSEPMEP.size() > 0){
					for (Iterator i = mlObjListSEPMEP.iterator(); i.hasNext();){
						StringBuilder sbAddress = new StringBuilder();
						mpAllowedMEPSEP = (Map) i.next();
						strName =(String)mpAllowedMEPSEP.get(DomainConstants.SELECT_NAME);
						strTitle=(String)mpAllowedMEPSEP.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
						strId = (String)mpAllowedSEP.get(DomainConstants.SELECT_ID);
						strType = (String)mpAllowedSEP.get(DomainConstants.SELECT_TYPE);
						String strCurrent = (String)mpAllowedSEP.get(DomainConstants.SELECT_CURRENT);
						Map<String, String> mapAllowedMEP = new HashMap<String, String>();
						 String strManuSEP = (String) mpAllowedMEPSEP.get(sVendorName);
						 String strManuMEP = (String) mpAllowedMEPSEP.get(sManuName);
						//Added by Manikanta for Req. no. 2334 - START
						 strStreetNo = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_PGHOUSENUMBER);
						 if(ConstantsUtil.SYMBL_ASTERISK.equals(strStreetNo))
								strStreetNo = ConstantsUtil.EMPTY_SPACE;
						 strSteetName = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_ADDRESS);
						 if(ConstantsUtil.SYMBL_ASTERISK.equals(strSteetName))
							 strSteetName = ConstantsUtil.EMPTY_SPACE;
						 strCity = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_CITY);
						 if(ConstantsUtil.SYMBL_ASTERISK.equals(strCity))
							 strCity = ConstantsUtil.EMPTY_SPACE;
						 strState = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_STATE);
						 if(ConstantsUtil.SYMBL_ASTERISK.equals(strState))
							 strState = ConstantsUtil.EMPTY_SPACE;
						 strMarket = (String) mpAllowedSEP.get(ConstantsUtilIRM.SELECT_MANUFACTURINGRESPONSIBILITY_COUNTRY);
						 if(ConstantsUtil.SYMBL_ASTERISK.equals(strMarket))
							 strMarket = ConstantsUtil.EMPTY_SPACE;
						 strPostalcode = (String) mpAllowedSEP.get(ConstantsUtil.STR_SELECT_PLANT_IS_VENDOR);
						 if(ConstantsUtil.SYMBL_ASTERISK.equals(strPostalcode))
							 strPostalcode = ConstantsUtil.EMPTY_SPACE;
						 
						 sbAddress.append(strManuMEP).append(ConstantsUtil.EMPTY_SPACE).append(strStreetNo).append(ConstantsUtil.EMPTY_SPACE).append(strSteetName).append(ConstantsUtil.SYMBL_NEWLINE).append(strCity).append(ConstantsUtil.EMPTY_SPACE).append(strState).append(ConstantsUtil.SYMBL_NEWLINE).append(strMarket).append(ConstantsUtil.EMPTY_SPACE).append(strPostalcode);
						//Added by Manikanta for Req. no. 2334 - END
						 if(strName.contains(strSEPObject))
							{
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_NAME, strName);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_TITLE, strTitle);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_VENDOR, strManuMEP);	
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_TYPE, strType);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_ID, strId);
								mapAllowedMEP.put(ConstantsUtil.STATE, strCurrent);
								//Added by Manikanta for Req. no. 2334 - START
								mapAllowedMEP.put(ConstantsUtil.VENDOR_STREET_ADDRESS, sbAddress.toString());
								//Added by Manikanta for Req. no. 2334 - END
							}
							else if(strName.contains(strMEPObject)){
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_NAME, strName);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_TITLE, strTitle);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_VENDOR, strManuMEP);	
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_TYPE, strType);
								mapAllowedMEP.put(ConstantsUtilIRM.ALLOWED_MEP_ID, strId);
								mapAllowedMEP.put(ConstantsUtil.STATE, strCurrent);
								//Added by Manikanta for Req. no. 2334 - START
								mapAllowedMEP.put(ConstantsUtil.VENDOR_STREET_ADDRESS, sbAddress.toString());
								//Added by Manikanta for Req. no. 2334 - END
							}
							mlAllowedMEPList.add(mapAllowedMEP);
						}
					}
			}
		}catch(Exception e){
					
					e.printStackTrace();
		}
				return mlAllowedMEPList;
				
	}
	//Added by Subhajit, Req -45670 - , End
	/**
	 * To avoid dead lock result
	 * 
	 * @param context
	 * @param sUserType
	 * @param objId
	 * @return
	 */

	public synchronized boolean checkHasAccess(Context context, String sUserType, String objId) {
		//SPEC: <07-28-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		SecurityService sec = new SecurityService();
		StringValidatorUtil validator = new StringValidatorUtil();
		if (!validator.isNotNullOrEmpty(sUserType))
		{
			sUserType = sec.getUserType();
		}
		//SPEC: <07-28-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		return provideHyperLink(context, sUserType, objId);
	}


	public synchronized boolean provideHyperLink(Context context, String sUserType, String objId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		boolean bReturnFlag = false;
		boolean bProjectLicense = false;
		boolean bFinalReturnFlag = false;
		String strObjectName = "";
		try {
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			if (validator.isNotNullOrEmpty(objId)) {
				if (objId.equalsIgnoreCase("No Access"))
					return bReturnFlag;
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				StringList slHIRTypes = new StringList();
				slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
				slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				slHIRTypes.add(ConstantsUtil.TYPE_FORMULA_CARD);
				slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
				slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
				StringList slEBPHIRTypes = new StringList();
				slEBPHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slEBPHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				slEBPHIRTypes.add(ConstantsUtil.TYPE_MASTERPRODUCTPART);
				slEBPHIRTypes.add(ConstantsUtil.TYPE_PGMAKINGINSTRUCTIONS);

				DomainObject bo = DomainObject.newInstance(context,objId);

				StringList slSelect = new StringList(6);
				slSelect.addElement(DomainConstants.SELECT_TYPE);
				slSelect.addElement(DomainConstants.SELECT_POLICY);
				slSelect.addElement(DomainConstants.SELECT_NAME);
				slSelect.addElement(ConstantsUtil.SELECT_CURRENT);
				slSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS);
				slSelect.addElement("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from[IP Control Class].name");
				slSelect.addElement("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from[Security Control Class].name");
				slSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
				slSelect.addElement(ConstantsUtilIRM.STR_PROJECT_SECURITY_FOP);
				slSelect.addElement(ConstantsUtil.STR_AUTOCADIPCLASS);

				StringList slMultiSel=new StringList();
				slMultiSel.add("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from[IP Control Class]."+DomainConstants.SELECT_NAME);
				slMultiSel.add("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from[IP Control Class]."+DomainConstants.SELECT_TYPE);
				slMultiSel.add("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
				slMultiSel.add("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from[Security Control Class].name");
				slMultiSel.add("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from.to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from[Security Control Class]");
				slMultiSel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
				slMultiSel.add("to["+ConstantsUtilIRM.RELATIONSHIP_AUTOCADIPCLASS+"].from.name");

				Map mObjList = bo.getInfo(context,slSelect,slMultiSel);
				
				StringList slPartSelect = new StringList();

				slPartSelect.addElement(ConstantsUtil.NAME);
				slPartSelect.addElement(ConstantsUtil.TYPE);
				slPartSelect.addElement(ConstantsUtil.SELECT_CURRENT);
				slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
				slPartSelect.addElement(ConstantsUtil.STR_AUTOCADIPCLASS);
				slPartSelect.addElement(ConstantsUtilIRM.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME_ACTIVE);
				slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS);
				slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
				slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slPartSelect.addElement(ConstantsUtilIRM.STR_PROJECT_SECURITY_FOP);
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				if (UIUtil.isNullOrEmpty(sUserType)) {
					sUserType = sct.getUserType();
				}
				String sUserProjectLicense = sct.getProjectLicenses();

				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				bo.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

				String strObjectType = (String) mObjList.get(DomainConstants.SELECT_TYPE);
				String strObjectPolicy = (String) mObjList.get(DomainConstants.SELECT_POLICY);
				strObjectName = (String) mObjList.get(DomainConstants.SELECT_NAME);
				if (sUserType.equals(ConstantsUtil.PG) || sUserType.equals(ConstantsUtil.PGSTAFF) ) 
				{
					if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE) || strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGNONGCASPART)) 
					{
						return true;
					}

				}
				// COmmented by Jwala for SB fix - 36803 - START 
				/*
				 * String strObjectState = (String)
				 * mObjList.get(DomainConstants.SELECT_CURRENT);
				 * if(strObjectType.equals(ConstantsUtil.TYPE_SOFTWAREBUILD) &&
				 * !strObjectState.equals(ConstantsUtil.RELEASE) &&
				 * !strObjectState.equals(ConstantsUtil.RELEASED)){ return false; }
				 */
				// COmmented by Jwala for SB fix - 36803 - END
				
				if (strObjectType.equals(ConstantsUtil.TYPE_SOFTWAREBUILD)){
					return checkAccessForSoftwareBuild(context,  objId);
				}
				if (strObjectType.equals(ConstantsUtil.TYPE_PGSMARTLABEL)){
					return true;
				}
				if (strObjectType.equals(ConstantsUtil.TYPE_COPYLIST)){
					return true;
				}

				if (strObjectType.equals(ConstantsUtil.TYPE_SUBSTANCE) || strObjectType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL) || strObjectType.equals(ConstantsUtilIRM.TYPE_EXTERNAL_MATERIAL)) {
					return checkAccessForIMorMCP(context,  objId);
				}
				if(isModificatinRequired()){
					if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_QUALIFICATION)){
						return checkAccessForPQRs(context,  objId);
					}
				}

				if(isModificatinRequired()){
					if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_ARTIOSCADCOMPONENT)){
						return checkAccessForArtiosCad(context,  objId);
					}
				}

				if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_QUALIFICATION)
						|| strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGSTUDYLEG)) {
					return true;
				}
				String strIPControlClass = "";
				if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_ARTIOSCADCOMPONENT)) {
					strIPControlClass = validator.getStringEquivalentForStringList(mObjList.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				} else 
				{
					strIPControlClass = validator.getStringEquivalentForStringList(
							mObjList.get("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from[IP Control Class]."+DomainConstants.SELECT_NAME));
				}
				String strProjSecClass = validator.getStringEquivalentForStringList(
						mObjList.get(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME));
				String strSharable = validator.getStringEquivalentForStringList(
						mObjList.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String sIsHir = validator.getStringEquivalentForStringList(
						mObjList.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));

				String strObjectPhase = (String) mObjList.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				if(ConstantsUtil.tFOP.equalsIgnoreCase(strObjectType)){
					strProjSecClass = validator.getStringEquivalentForStringList(mObjList.get(ConstantsUtilIRM.STR_PROJECT_SECURITY_FOP));
				}

				if (UIUtil.isNotNullAndNotEmpty(strProjSecClass.trim())) 
				{
					bProjectLicense = checkProjectLicenses(sUserProjectLicense, strProjSecClass);

				} else {
					bProjectLicense = true;
				}

				if (!strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGIPMDOCUMENT)	) 
				{
					if (UIUtil.isNullOrEmpty(sIsHir) && !isModificatinRequired() ){
						return false;
					}

				}			
				if (sUserType.equals(ConstantsUtil.PG)) {

					if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE))
					{
						return true;
					}
					if (bProjectLicense) {
						if (slHIRTypes.contains(strObjectType)
								|| sIsHir.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED)) {
							String sFormulaClassif = strIPControlClass;
							if (strObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaClassif = getFormulaPropagateClassification(context, objId);
							}
							boolean bObjectLicense = checkLicenses(sUserlicense, sFormulaClassif);
							if (bObjectLicense) {
								if (strObjectPhase.equals(ConstantsUtil.PRODUCTION)
										|| strObjectPhase.equals(ConstantsUtil.EMPTY_STRING))
									bFinalReturnFlag = true;
							}

						} else {
							if (bProjectLicense)
								if (strObjectPhase.equals(ConstantsUtil.PRODUCTION)
										|| strObjectPhase.equals(ConstantsUtil.EMPTY_STRING))
									bFinalReturnFlag = true;
						}
					}
					return bFinalReturnFlag;
				} else if (sct.isStaffAUGUser()) {
					if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)) {
						return true;
					}
					if (bProjectLicense) {
						String sFormulaClassif = strIPControlClass;
						if (strObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaClassif = getFormulaPropagateClassification(context, objId);
						}
						bReturnFlag = checkLicenses(sUserlicense, sFormulaClassif);
						if (bReturnFlag) {
							if (strObjectPhase.equals(ConstantsUtil.PRODUCTION)
									|| strObjectPhase.equals(ConstantsUtil.EMPTY_STRING))
								bFinalReturnFlag = true;
						}
					}
					return bFinalReturnFlag;
				} else if (sUserType.equals(ConstantsUtil.PG_CM) || sUserType.equals(ConstantsUtil.PG_SP)) {
					StringList slUserOwnership = filterOwnerShip(sct.getUserCauthorities());
					String sFormulaPropagate = objId;
					if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)) {
						return true;
					}
					if (strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = getFormulaPropagate(context, objId);
					}
					if (!sFormulaPropagate.isEmpty()) {
						if(!(strObjectType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
								|| strObjectType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)))
						{
							bReturnFlag = checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
						}
						else
						{
							String sView = updateReferences(context, objId);
							if(!sView.equals("NO Connection Exists"))
							{
								bReturnFlag=true;
							}
							else
							{
								bReturnFlag = checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
							}
						}
					}

					if (slEBPHIRTypes.contains(strObjectType) && sIsHir.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED) && bProjectLicense && sUserType.equals(ConstantsUtil.PG_SP) && ConstantsUtilIRM.POLICY_ECPART.equalsIgnoreCase(strObjectPolicy)) {
						Map resultMaps = null;
						boolean bHIRComplaint = getHIRComplaintForSupplier(context,bo,resultMaps);
						if(!bHIRComplaint) {
							bReturnFlag = false;
						}
					}
					else if (strObjectType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) && bReturnFlag) 
					{
						if (ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)
								|| ConstantsUtil.TRUE.equalsIgnoreCase(strSharable)) 
						{
							if (strObjectPhase.equals(ConstantsUtil.PRODUCTION)
									|| strObjectPhase.equals(ConstantsUtil.EMPTY_STRING))
								return true;
						} else {
							return false;
						}

					}

					else if ((strObjectType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strObjectType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) && bReturnFlag) {
						if (ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)
								|| ConstantsUtil.TRUE.equalsIgnoreCase(strSharable)) {

							String sView = updateReferences(context, objId);
							if ((!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
									&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL))) {
								bReturnFlag = false;
							} else {
								if (strObjectPhase.equals(ConstantsUtil.PRODUCTION)
										|| strObjectPhase.equals(ConstantsUtil.EMPTY_STRING))
									return true;
							}

						} else {
							return false;

						}

					}

				}
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			} else {
				return false;
			}
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

		} catch (Exception e) {
			LOGGER.error("Error from BusExtractUtil :  provideHyperLink:" + e);
			e.printStackTrace();
			return bReturnFlag;
		}
		return bReturnFlag;
	}


	/**
	 * This method will verify the substitute Ownership. SPEC: 10/29/2020: Added
	 * for 18x.5 DEV -- START
	 * 
	 * @param context
	 * @param objectMap
	 * @return
	 */

	public String checkSubstituteHasAccess(Context context, Map objectMap) {

		StringBuilder sbReturnVal = new StringBuilder();
		boolean showData = true;
		boolean bHasOwnership = false;

		String sFinalChildId = ConstantsUtil.EMPTY_STRING;
		try {
			StringValidatorUtil validator = new StringValidatorUtil();

			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership = filterOwnerShip(sComp);

			if (objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))
				if (null != validator
				.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))) {
					String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass()
							.getSimpleName();
					if (sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
						String strSubPartType = validator.getStringEquivalentForStringListWithComma(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						String strSubPartId = validator.getStringEquivalentForStringListWithComma(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));

						//DomainObject doEachChild = new DomainObject(strSubPartId);
						DomainObject doEachChild = DomainObject.newInstance(context, strSubPartId);
						DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						StringList slSelect = new StringList();
						slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						Map mpIpClass = doEachChild.getInfo(context, slSelect);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
						doEachChild.close(context);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						//SPEC: <08-09-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
						StringList sIpClass = new StringList();
						//SPEC: <16-09-2021>: Guna Modified for Stress Testing (2nd Round) -- START
					  if(mpIpClass.containsKey(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME)){
						if ( mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							sIpClass = (StringList)(mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME));
						} else {
							sIpClass = validator.getStringListEquivalentForString(mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME));
						}
					  }
					//SPEC: <16-09-2021>: Guna Modified for Stress Testing (2nd Round) -- END
					  DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						//SPEC: <08-09-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
						
						// modified by Ganesh for security impl----->start
						showData = checkHasAccess(context, null, strSubPartId);
						// modified by Ganesh for security impl----->end

						if (!showData) {
							strSubPartId = ConstantsUtil.NO_ACCESS;
						}

						sbReturnVal.append(strSubPartId);
					} else {
						// For Multi Substitutes
						//SPEC: <08-09-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
						StringList slSubPartType = new StringList ();
						if (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							slSubPartType = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
						} else
						{
							slSubPartType = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						}

						StringList slSubPartId = new StringList();
						if (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							slSubPartId = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						} else
						{
							slSubPartId = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						}
						//SPEC: <08-09-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END

						for (int i = 0; i < slSubPartId.size(); i++) {
							String sEachChildId = slSubPartId.getElement(i);
							//DomainObject doEachChild = new DomainObject(sEachChildId);
							DomainObject doEachChild = DomainObject.newInstance(context, sEachChildId);
							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							StringList slSelect = new StringList();
							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							Map mpIpClass = doEachChild.getInfo(context, slSelect);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							doEachChild.close(context);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
							//SPEC: <08-09-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
							StringList sIpClass = new StringList ();
							//SPEC: <30.12.2021>: Guna Modified for 45862 Defect  Dev 18x.6.0.3   -- START
							if(mpIpClass.containsKey(ConstantsUtil.SELECT_CLASSIFIED_ITEM)){
							if (mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM).getClass().getSimpleName().equalsIgnoreCase("StringList"))
							{
								sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							}else
							{
								sIpClass = validator.getStringListEquivalentForString(mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM));
							}
							}
							//SPEC: <30.12.2021>: Guna Modified for 45862 Defect  Dev 18x.6.0.3   -- END
							//SPEC: <08-09-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
							DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							// commented by Ganesh for security impl------>start
							
							// commented by Ganesh for security impl------>end
							// modified by Ganesh for security impl------>start
							showData = checkHasAccess(context, null, sEachChildId);
							// modified by Ganesh for security impl------>end

							if (!showData) {
								sEachChildId = ConstantsUtil.NO_ACCESS;
							}
							formatDataWithAndSymbol(sbReturnVal, sEachChildId);
						} // End For loop

					} // End of Class Name

				} else { // If no Substitue found
					return ConstantsUtil.EMPTY_STRING;
				}

		} catch (Exception e) {

			LOGGER.error("Error from BusObjectAttribUtil :  checkSubstituteHasAccess" + e);
			return ConstantsUtil.EMPTY_STRING;
		}
		return sbReturnVal.toString();
	}

	/**
	 * SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START This
	 * method will verify the Alternate Ownership. SPEC: 12/28/2020: Added for
	 * 18x.5 DEV -- START
	 * 
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public String checkAlternateHasAccess(Context context, Map objectMap) {

		StringBuilder AltReturnVal = new StringBuilder();
		boolean showData = true;
		boolean bHasOwnership = false;

		String sFinalChildId = ConstantsUtil.EMPTY_STRING;
		try {
			StringValidatorUtil validator = new StringValidatorUtil();

			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership = filterOwnerShip(sComp);

			if (objectMap.containsKey(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID))
				if (null != validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID))) {
					String sClassName = objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID).getClass()
							.getSimpleName();
					if (sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
						String strAltPartType = validator.getStringEquivalentForStringListWithComma(
								objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
						String strAltPartId = validator.getStringEquivalentForStringListWithComma(
								objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID));

						//DomainObject doEachChild = new DomainObject(strAltPartId);
						DomainObject doEachChild = DomainObject.newInstance(context, strAltPartId);
						DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						StringList slSelect = new StringList();
						slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						slSelect.add(ConstantsUtil.SELECT_CURRENT);
						Map mpIpClass = doEachChild.getInfo(context, slSelect);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
						doEachChild.close(context);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						//SPEC: 09-08-2022: Commented for Defect 49836 by Manikanta -- START
						//StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						//SPEC: 09-08-2022: Commented for Defect 49836 by Manikanta -- END
						String sCurrent = (String) mpIpClass.get(ConstantsUtil.SELECT_CURRENT);
						DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						// commented by Ganesh for security impl------>start
						
						// commented by Ganesh for security impl------>end
						// modified by Ganesh for security impl------>start
						showData = checkHasAccess(context, null, strAltPartId);
						// modified by Ganesh for security impl------>end

						if (!showData || !sCurrent.equals(ConstantsUtil.STATE_RELEASE)) {
							strAltPartId = ConstantsUtil.NO_ACCESS;
						}

						AltReturnVal.append(strAltPartId);
					} else {
						// For Multi Alternates
						StringList slSubPartType = (StringList) objectMap
								.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
						StringList slSubPartId = (StringList) objectMap
								.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);

						for (int i = 0; i < slSubPartId.size(); i++) {
							String sEachChildId = slSubPartId.getElement(i);
							//DomainObject doEachChild = new DomainObject(sEachChildId);
							DomainObject doEachChild = DomainObject.newInstance(context, sEachChildId);
							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							StringList slSelect = new StringList();
							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							slSelect.add(ConstantsUtil.SELECT_CURRENT);
							Map mpIpClass = doEachChild.getInfo(context, slSelect);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							doEachChild.close(context);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
							String sCurrent = (String) mpIpClass.get(ConstantsUtil.SELECT_CURRENT);
							DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							// commented by Ganesh for security impl----->start
							
							// commented by Ganesh for security impl----->end
							// modified by Ganesh for security impl----->start
							showData = checkHasAccess(context, null, sEachChildId);
							// modified by Ganesh for security impl----->end

							if (!showData || !sCurrent.equals(ConstantsUtil.STATE_RELEASE)) {
								sEachChildId = ConstantsUtil.NO_ACCESS;
							}
							formatDataWithAndSymbol(AltReturnVal, sEachChildId);
						} // End For loop

					} // End of Class Name

				} else { // If no Substitue found
					return ConstantsUtil.EMPTY_STRING;
				}

		} catch (Exception e) {

			LOGGER.error("Error from BusObjectAttribUtil :  checkAlternateHasAccess" + e);
			return ConstantsUtil.EMPTY_STRING;
		}
		return AltReturnVal.toString();
	}
	// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END

	public boolean checkSubstituteHasAccesss(Context context, Map objectMap) {

		StringBuilder sbReturnVal = new StringBuilder();
		boolean showData = false;
		try {
			StringValidatorUtil validator = new StringValidatorUtil();

			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership = filterOwnerShip(sComp);

			if (objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID)) {
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName();
				if (sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
					String strSubPartId = validator.getStringEquivalentForStringListWithComma(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));

					//DomainObject doEachChild = new DomainObject(strSubPartId);
					DomainObject doEachChild = DomainObject.newInstance(context, strSubPartId);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					StringList slSelect = new StringList();
					slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					Map mpIpClass = doEachChild.getInfo(context, slSelect);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doEachChild.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					// commented by Ganesh for security impl----->start
					
					// commented by Ganesh for security impl----->end
					// modified by Ganesh for security impl----->start
					showData = checkHasAccess(context, null, strSubPartId);
					// modified by Ganesh for security impl----->end

					//
				}
			} else { // If no Substitue found
				return showData;
			}

		} catch (Exception e) {

			LOGGER.error("Error from BusObjectAttribUtil :  checkSubstituteHasAccess" + e);
			return showData;
		}
		return showData;
	}

	/**
	 * remove the last element in StringBuffer
	 * 
	 * @param input
	 * @return
	 */
	public StringBuffer removeLastElement(StringBuffer input) {
		input.deleteCharAt(input.length() - 1);
		for (int i = input.length() - 1; i > 0; i--) {
			if (input.charAt(i) != '|') {
				input.deleteCharAt(i);
			} else {
				break;
			}
		}
		return input;
	}

	/**
	 * to get the formulation attribute value
	 * 
	 * @param context
	 * @param sContextObjectId
	 * @return
	 */
	public String formulationAttribute(Context context, String sContextObjectId) {

		String NameRevision = DomainConstants.EMPTY_STRING;

		StringList busSelect = new StringList();
		busSelect.add(DomainConstants.SELECT_NAME);
		busSelect.add(DomainConstants.SELECT_ID);
		busSelect.add(DomainConstants.SELECT_TYPE);
		busSelect.add(DomainConstants.SELECT_REVISION);
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- START (For Internal Defect)
		busSelect.add(DomainConstants.SELECT_POLICY);

		String sNameRev = DomainConstants.EMPTY_STRING;
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- END (For Internal Defect)

		FormulaPartBO formulationPartBO = new FormulaPartBO();
		try {
			DomainObject doFOP = formulationPartBO.getFopDO(context, sContextObjectId);
			MapList mapList = doFOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE,
					DomainConstants.QUERY_WILDCARD, busSelect, new StringList(), true, false, (short) 1,
					DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING, 0);

			Iterator objectListItr = mapList.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbRevision = new StringBuilder();
			StringBuilder sbNameRev = new StringBuilder();

			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();

				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				//SPEC: Release SR18x5.2- modified for Defect #38993 by Govind on Date 14/02/2021 start	
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- START (For Internal Defect)
				String strPolicy = (String)objectMap.get(DomainConstants.SELECT_POLICY);

				if(strPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_PGPARALLELCLONEPRODUCTDATAPART))
					sNameRev = sName;
				else
					sNameRev = sName + " " + sRevision;
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- END (For Internal Defect)
				//SPEC: Release SR18x5.2- modified for Defect #38993 by Govind on Date 14/02/2021 end	
				formatData(sbName, sName);
				formatData(sbId, sId);
				formatData(sbType, sType);
				formatData(sbRevision, sRevision);

				formatDataWithBlank(sbNameRev, sNameRev);

				NameRevision = sbNameRev.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return NameRevision;
	}

	/**
	 * 
	 * @param slData
	 * @param sData
	 */
	public void formatDataWithBlank(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(" ");
	}

	public Map<String, String> filterStateByRelease(Map<String, String> mpMap) {
		StringList slNonReleased = new StringList();

		if (mpMap.isEmpty()) {
			return new HashMap();
		}
		Map objectMap = new HashMap();
		try {
			if (mpMap.containsKey(ConstantsUtil.STATE)) {
				String sState = (String) mpMap.get(ConstantsUtil.STATE);
				if (UIUtil.isNullOrEmpty(sState)) {
					return mpMap;
				}
				String saState[] = sState.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

				if (saState.length != 0) {
					for (int i = 0; i < saState.length; i++) {
						if (!UIUtil.isNotNullAndNotEmpty(saState[i])) {
							slNonReleased.add(String.valueOf(i));
						}
						if (!isReleased(mapType(saState[i].trim())))
							slNonReleased.add(String.valueOf(i));
					}
				}
				if (slNonReleased.size() != 0) {
					mpMap = filterNonReleasedObjects(slNonReleased, mpMap);
				}
			} else {
				return new HashMap();

			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :filterPhase signature of Map " + e);
			return new HashMap();
		}
		return mpMap;
	}

	/**
	 * Replacing the comma with And symbol
	 * 
	 * @param resultMaps
	 * @return
	 */

	public String getTheValueWithComma(Map resultMaps) {
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbReturn = new StringBuilder();
		String sReturnValue = DomainConstants.EMPTY_STRING;
		try {
			if (resultMaps.containsKey((ConstantsUtil.COMP_MANUF))) {

				String sClass = resultMaps.get(ConstantsUtil.COMP_MANUF).getClass().getSimpleName();

				if (sClass.equals(ConstantsUtil.STRING)) {
					sReturnValue = validator
							.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.COMP_MANUF));
					formatData(sbReturn, sReturnValue);
				} else {
					StringList slSubstituteTitle = validator
							.isNotNullOrEmpty((StringList) resultMaps.get(ConstantsUtil.COMP_MANUF));

					for (int i = 0; i < slSubstituteTitle.size(); i++) {
						sReturnValue = slSubstituteTitle.get(i);
						sReturnValue.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
						formatData(sbReturn, sReturnValue);

					}
				}
			}
		} catch (Exception e) {

			LOGGER.error(
					"Exception in Program : BusObjectAttribUtil Method :getTheValueWithComma signature of Map " + e);
			return "";
		}
		return sbReturn.toString();
	}

	/**
	 * AVoidng comma
	 * 
	 * @param resultMaps
	 * @return
	 */
	// SPEC: Modified for 18x.5.2 Defect #38718 --Bala -- START
	// Modified this method for getting both and Comments and Instructions values
	public String getLifeCycleComment(Map resultMaps) {
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbReturn = new StringBuilder();
		String sReturnValue = DomainConstants.EMPTY_STRING;
		StringBuilder sbInsReturn = new StringBuilder();
		String sInsReturnValue = DomainConstants.EMPTY_STRING;

		// SPEC: Modified for 18x.6 Dev --Sanjeeva -- START
		String sClassInstruction = new String ();
		String sClass = new String ();
		try {

			if (resultMaps.containsKey((ConstantsUtil.REL_TASK_COMMENTS)) || resultMaps.containsKey(ConstantsUtil.SELECT_ROUTE_INSTRUCTIONS)) {

				sClass = resultMaps.get(ConstantsUtil.REL_TASK_COMMENTS).getClass().getSimpleName();
				


				//if (sClass.equals(ConstantsUtil.STRING) && sClassInstruction.equals(ConstantsUtil.STRING)) {
				if (sClass.equalsIgnoreCase(ConstantsUtil.STRING) || sClassInstruction.equalsIgnoreCase(ConstantsUtil.STRING)) {
					//SPEC: Modified for 18x.6 Dev --Sanjeeva -- END
					sReturnValue = validator
							.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.REL_TASK_COMMENTS));
				
					sbInsReturn.append(sReturnValue).append(sInsReturnValue);					
					formatData(sbReturn, sbInsReturn.toString());
				} else {
					StringList slComment =(StringList) resultMaps.get(ConstantsUtil.REL_TASK_COMMENTS);
					
					//SPEC: 23-04-2021: Modified for 18x.6 Internal Defect by Bala -- START
					StringList slCommentIns = new StringList();
					if (slComment.size()>0 ) {
						slCommentIns = slComment;
						
					}else {
						
					}
					if (slComment.size()>0) {					
						for (int i = 0; i < slCommentIns.size(); i++) {
							sbInsReturn = new StringBuilder();
							sReturnValue = slComment.get(i);
							//sInsReturnValue = slInstructions.get(i);
							sReturnValue.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							if (UIUtil.isNotNullAndNotEmpty(sReturnValue) && UIUtil.isNotNullAndNotEmpty(sInsReturnValue)) { 
								sbInsReturn.append(sReturnValue).append(ConstantsUtil.SYMBL_SLASH).append(sInsReturnValue);
							} else {
								if (UIUtil.isNullOrEmpty(sReturnValue)) {
									sbInsReturn.append(sInsReturnValue);
								}
								else {
									sbInsReturn.append(sReturnValue);
								}
							}								
							formatData(sbReturn, sbInsReturn.toString());
						}
						//SPEC: 23-04-2021: Modified for 18x.6 Internal Defect by Bala -- END
					}
				}
			}
		} catch (Exception e) {

			LOGGER.error(
					"Exception in Program : BusObjectAttribUtil Method :getTheValueWithComma signature of Map " + e);
			return "";
		}
		return sbReturn.toString();
	}
	// SPEC: Modified for 18x.5.2 Defect #38718 --Bala -- END
	/**
	 * This method returns Maplist of connected data of FPP
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 * @returns MapList
	 * @throws Exception
	 */
	public MapList getRequiredData(Context context, String strFPPObjectId, String strTypePattern, String strRelPattern)
			throws Exception {
		MapList mlAllTableData = new MapList();

		try {

			DomainObject domObj = DomainObject.newInstance(context);
			StringList slObjectSelect = new StringList();
			slObjectSelect.addElement(DomainConstants.SELECT_NAME);
			slObjectSelect.addElement(DomainConstants.SELECT_REVISION);
			slObjectSelect.addElement(SAPBOMConstants.SELECT_ATTRIBUTE_TITLE);
			slObjectSelect.addElement(DomainConstants.SELECT_DESCRIPTION);
			slObjectSelect.addElement(DomainConstants.SELECT_ID);

			StringList relSelects = new StringList();
			relSelects.addElement(SAPBOMConstants.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
			relSelects.addElement(SAPBOMConstants.SELECT_RELATIONSHIP_ID);

			// For Material Certifications Table Data
			if (UIUtil.isNotNullAndNotEmpty(strTypePattern)
					&& ((SAPBOMConstants.TYPE_PGPLIMATERIALCERTIFICATIONS).equals(strTypePattern))) {
				relSelects.addElement(SAPBOMConstants.RELATIONSHIP_COUNTRIES_CERTIFIED);
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
				relSelects.addElement(ConstantsUtilIRM.SELECT_RELATIONSHIP_REGIONMATERIALCERT);
				relSelects.addElement(ConstantsUtilIRM.SELECT_RELATIONSHIP_AREAMATERIALCERT);
				relSelects.addElement(ConstantsUtilIRM.SELECT_RELATIONSHIP_GROUPTOPMATERIALCERT);
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- ENDS
			}

			domObj.setId(strFPPObjectId);

			mlAllTableData = domObj.getRelatedObjects(context, strRelPattern, strTypePattern, slObjectSelect,
					relSelects, false, true, (short) 1, "", null, 0);

		} catch (Exception ex) {
			LOGGER.error("Exception in program BusObjectAttribUtil :getRequiredData ");
			return new MapList();
		}
		return mlAllTableData;
	}

	/**
	 * This method is get the string of relationship attribute value(stored as a
	 * physical id in the DB) using the rel id passed as an argument .
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 * @return Vector
	 * @throws Exception
	 *             if the operation fails
	 */
	public String getIdFromPhysicalIdFunction(Context context, String strApplications) {
		StringBuilder strBuilder = new StringBuilder();
		String sFunction = ConstantsUtil.EMPTY_STRING;
		try {
			StringList selectList = new StringList(DomainConstants.SELECT_NAME);
			StringList appList = new StringList(FrameworkUtil.split(strApplications, ","));
			String[] valueArray = convertListToArray(appList);
			MapList mapApplications = DomainObject.getInfo(context, valueArray, selectList);
			Iterator it = mapApplications.iterator();
			Map objMap = null;
			while (it.hasNext()) {
				objMap = (Map<?, ?>) it.next();
				sFunction = (String) objMap.get(DomainConstants.SELECT_NAME);
				sFunction.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				strBuilder.append(sFunction);
				if (it.hasNext())
					strBuilder.append(",");
			}
		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribUtil :getIdFromPhysicalIdFunction ");
		}
		return strBuilder.toString();
	}

	/**
	 * Method to convert a StringList to String Array after removing all
	 * preceding and trailing spaces from each String value
	 * 
	 * @param slFunctionList
	 *            Input StringList with Object Ids or Physical Ids
	 * @return String Array of object Ids and/or Physical Ids
	 */
	private String[] convertListToArray(StringList slFunctionList) {
		String[] strArrayIds = new String[] {};
		String strfuncId = null;
		if (slFunctionList != null) {
			int nSize = slFunctionList.size();
			strArrayIds = new String[nSize];
			for (int i = 0; i < nSize; i++) {
				strfuncId = (String) slFunctionList.get(i);
				if (UIUtil.isNotNullAndNotEmpty(strfuncId)) {
					strfuncId = strfuncId.trim();
				} else {
					strfuncId = "";
				}
				strArrayIds[i] = strfuncId;
			}
		}
		return strArrayIds;
	}

	// Added for Defect #37503 by Amman on 11/25/2020 -- START
	/**
	 * To print the final value of a field with commas
	 * 
	 * @param resultMaps
	 * @return
	 */
	public String getTheValueWithCommas(Map resultMaps, String strInput) {
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbReturn = new StringBuilder();
		String sReturnValue = DomainConstants.EMPTY_STRING;
		try {
			if (resultMaps.containsKey((strInput))) {

				String sClass = resultMaps.get(strInput).getClass().getSimpleName();

				if (sClass.equals(ConstantsUtil.STRING)) {
					sReturnValue = validator.getStringEquivalentForStringListWithComma(resultMaps.get(strInput));
					formatData(sbReturn, sReturnValue);
				} else {
					StringList slSubstituteTitle = validator.isNotNullOrEmpty((StringList) resultMaps.get(strInput));

					for (int i = 0; i < slSubstituteTitle.size(); i++) {
						sReturnValue = slSubstituteTitle.get(i);
						sReturnValue.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
						formatData(sbReturn, sReturnValue);

					}
				}
			}
		} catch (Exception e) {

			LOGGER.error(
					"Exception in Program : BusObjectAttribUtil Method :getTheValueWithComma signature of Map " + e);
			return "";
		}
		return sbReturn.toString();
	}
	// Added for Defect #37503 by Amman on 11/25/2020 -- END

	public static boolean isOfParentType(Context var0, String var1, String var2) throws FrameworkException {
		try {
			if (var1.equals(var2)) {
				return true;
			} else {
				String var3 = "derivative[" + var1 + "]";
				String var4 = MqlUtil.mqlCommand(var0, "print type $1 select $2 dump", new String[] { var2, var3 });
				return var4.equalsIgnoreCase("true");
			}
		} catch (Exception var5) {
			throw new FrameworkException(var5);
		}
	}

	/**
	 * DSM (DS) 2015x.4 - This method will return a numeric number with six
	 * digit after decimal number
	 * 
	 * @param context
	 * @param String
	 * @return
	 * @throws Exception
	 */
	public String getFormatedDecimalValue(String strValue, String strDecimalFormat) {
		double dNumber;
		try {
			int integerPlaces = strValue.indexOf('.');
			int decimalPlaces = strValue.length() - integerPlaces - 1;
			if (decimalPlaces > 6) {
				if (UIUtil.isNotNullAndNotEmpty(strDecimalFormat)) {
					DecimalFormat dfnumberFormat = new DecimalFormat(strDecimalFormat);
					if (UIUtil.isNotNullAndNotEmpty(strValue)) {
						dNumber = Double.parseDouble(strValue);
						if (dNumber > 0) {
							strValue = dfnumberFormat.format(dNumber);
						}
					}
				}
			}
			// Enginuity (DS) 2015x.5.1 -Added to display decimal value instead
			// of scientific value-ALM(19411) -Start
			
			// Enginuity (DS) 2015x.5.1 -Added to display decimal value instead
			// of scientific value-ALM(19411) -END
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		return strValue;
	}

	public String mapPsubType(String sType) {
		if (null != sType) {
			switch (sType) {
			case "pgPackingMaterial":
				sType = "MATL";
				break;
			case "Individual_Pack_Material":
				sType = "Packaging";
				break;
			case "IPMS":
				sType = "Packaging";
				break;
			case "RMS":
				sType = "Raw";
				break;
			case "pgFinishedProduct":
				sType = "FC";
				break;
			case "Formulation Part":
				sType = "FC";
				break;
			case "pgPackingSubassembly":
				sType = "PSUB";
				break;
			case "pgFormulatedProduct":
				sType = "FC";
				break;
			case "pgPhase":
				sType = "";
				break;
			case "pgRawMaterial":
				sType = "MATL";
				break;
			case "pgNonGCASPart":
				sType = "NGCAS";
				break;
			default:
				sType = sType;
				break;
			}
		}
		return sType;
	}

	// Commented Duplicate method
	/**
	 * the final value of a field without disturbing the commas
	 * 
	 * @param resultMaps
	 * @return
	 */

	public String UpdateSpecSubTypeforMPS(Context context, String sObjectId) {
		String sSpecSubType = DomainConstants.EMPTY_STRING;

		try {
			if (sObjectId != null && !"".equals(sObjectId)) {
				DomainObject productObject = DomainObject.newInstance(context, sObjectId);
				StringList slSelectable = new StringList();
				slSelectable.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				slSelectable.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
				slSelectable.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slSelectable.addElement(DomainConstants.SELECT_ID);

				Map<String, String> mpSelectableMap = productObject.getInfo(context, slSelectable);
				if (mpSelectableMap != null && !mpSelectableMap.isEmpty()) {
					String strOriginatingSource = mpSelectableMap
							.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
					String strSpecObjectId = mpSelectableMap.get(DomainConstants.SELECT_ID);
					String strSpecObjectType = mpSelectableMap.get(DomainConstants.SELECT_TYPE);
					String strCSSType = mpSelectableMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);

					if (UIUtil.isNotNullAndNotEmpty(strOriginatingSource)
							&& ConstantsUtil.DSO.equalsIgnoreCase(strOriginatingSource))
						sSpecSubType = mpSelectableMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					else
						sSpecSubType = getSpecificationSubTypeforMPS(context, strCSSType);

				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :UpdateSpecSubType " + e);
			return DomainConstants.EMPTY_STRING;
		}
		return sSpecSubType;
	}

	/**
	 * the final value of a field without disturbing the commas
	 * 
	 * @param resultMaps
	 * @return
	 */

	public String getTheValueWithSpecialSymbol(Map resultMaps, String sKey) {
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbReturn = new StringBuilder();
		String sReturnValue = DomainConstants.EMPTY_STRING;
		try {
			if (resultMaps.containsKey((sKey))) {
				String sClass = resultMaps.get(sKey).getClass().getSimpleName();
				if (sClass.equals(ConstantsUtil.STRING)) {
					sReturnValue = (String) resultMaps.get(sKey);
					formatData(sbReturn, sReturnValue);
				} else {
					StringList slSubstituteTitle = validator.isNotNullOrEmpty((StringList) resultMaps.get(sKey));
					for (int i = 0; i < slSubstituteTitle.size(); i++) {
						sReturnValue = slSubstituteTitle.get(i);
						formatData(sbReturn, sReturnValue);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getTheValueWithSpecialSymbol  " + e);
			return DomainConstants.EMPTY_STRING;
		}
		return sbReturn.toString();
	}

	public String getSpecificationSubTypeforMPS(Context context, String strSubtypeAttributeValue) throws Exception

	{

		String strAttributeValue = "";
		try {

			if (strSubtypeAttributeValue.equalsIgnoreCase("AMAT")) {
				strAttributeValue = "AMAT";
			} else if (strSubtypeAttributeValue.equalsIgnoreCase("QAC")) {
				strAttributeValue = "QAC";
			} else if (strSubtypeAttributeValue.equalsIgnoreCase("RMPI")) {
				strAttributeValue = "RMPI";
			} else if (strSubtypeAttributeValue.equalsIgnoreCase("CBA")) {
				strAttributeValue = "CBA";
			} else if (strSubtypeAttributeValue.equalsIgnoreCase("GPMS")) {
				strAttributeValue = "GPMS";
			} else if (strSubtypeAttributeValue.equalsIgnoreCase("GPS")) {
				strAttributeValue = "GPS";
			} else if (strSubtypeAttributeValue.equalsIgnoreCase("IAS")) {
				strAttributeValue = "IAS";
			} else if (strSubtypeAttributeValue.equalsIgnoreCase("MOC")) {
				strAttributeValue = "MOC";
			} else if (strSubtypeAttributeValue.equalsIgnoreCase("TAMU")) {
				strAttributeValue = "TAMU";
			}
		} catch (Exception e)

		{
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getSpecificationSubType " + e);
		}

		return strAttributeValue;

	}

	/**
	 * Added for getting post consumer and industrial recycled content values
	 * 
	 * @return String
	 */

	public String getPostRecycledContent(BigDecimal dFinalPostRecycledContent, BigDecimal dDefaultValue) {
		String rtnPostCon;
		if (dFinalPostRecycledContent.compareTo(dDefaultValue) != 0) {
			rtnPostCon = String.valueOf(dFinalPostRecycledContent);
		} else {
			rtnPostCon = DomainConstants.EMPTY_STRING;
		}
		return rtnPostCon;
	}

	/*
	 * Return the StringLlist
	 */

	public StringList getStringListWithComma(String sType) {
		if (UIUtil.isNullOrEmpty(sType)) {
			return ConstantsUtil.EMPTY_STRINGLIST;
		}
		String sTemp[] = sType.split(ConstantsUtil.SYMBL_COMMA);

		StringList sFinal = new StringList();
		for (int i = 0; i < sTemp.length; i++) {
			String sData = sTemp[i].trim();

			sFinal.add(sData);
		}
		return sFinal;
	}
	// END :: gaikwad.tg

	// SPEC: Added for 18x.5.2 DEV --Guna -- START
	public String getGenDocFile(Context context, DomainObject dobCdoc) {
		String rtnGendoc = DomainConstants.EMPTY_STRING;
		String FileName = DomainConstants.EMPTY_STRING;
		String FileCapturedFile = DomainConstants.EMPTY_STRING;
		StringValidatorUtil validator = new StringValidatorUtil();
		try {
			String strType = dobCdoc.getInfo(context, ConstantsUtil.TYPE);
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtilIRM.SELECT_POA_FILE_NAME);
			busSelect.add(ConstantsUtilIRM.SELECT_POA_FILE_PATH);
			busSelect.add(ConstantsUtilIRM.SELECT_ART_FILE_NAME);
			busSelect.add(ConstantsUtilIRM.SELECT_ART_FILE_PATH);

			//Map resultMaps = dobCdoc.getInfo(context, busSelect);
			Map resultMaps = dobCdoc.getInfo(context, busSelect,addMultiList());

			if (strType.equals(ConstantsUtil.TYPE_POA)) {
				FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtilIRM.SELECT_POA_FILE_NAME));
				FileCapturedFile = validator.getEquivalentString(resultMaps.get(ConstantsUtilIRM.SELECT_POA_FILE_PATH));
			} else if (strType.equals(ConstantsUtil.TYPE_PGARTWORK)) {
				FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtilIRM.SELECT_ART_FILE_NAME));
				FileCapturedFile = validator.getEquivalentString(resultMaps.get(ConstantsUtilIRM.SELECT_ART_FILE_PATH));
			}
			StringTokenizer nameTokenizer = new StringTokenizer(FileName, ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			StringTokenizer pathTokenizer = new StringTokenizer(FileCapturedFile, ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			if (nameTokenizer.countTokens() > 0) {
				int count = nameTokenizer.countTokens();
				for (int i = 0; i < count; i++) {
					String sName = nameTokenizer.nextToken();
					String sPath = pathTokenizer.nextToken();
					rtnGendoc = sPath + "||" + sName;
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		return rtnGendoc;
	}
	// SPEC: Added for 18x.5.2 DEV --Guna -- END
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	: 
	 */
	public StringList addMultiList() { 
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtilIRM.SELECT_POA_FILE_NAME);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_POA_FILE_PATH);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ART_FILE_NAME);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ART_FILE_PATH);
	
	return slMultiSelects;
	}

	/*
	 * Method to sort Maplist for Materail and Spec section Args Maplist and
	 * ParentObjID
	 */
	public MapList getSortedMaplistWithSequence(Context context, MapList mlComponentsAnMaterials, String sRawMatId)
			throws Exception {
		MapList mlTempList = new MapList();
		StringValidatorUtil validator = new StringValidatorUtil();
		try {
			// START :: gaikwad.td
			//SPEC: <02.20.2021>: Sumit Commented for Defect :38976 (No need to sort at level)## --START
			//mlComponentsAnMaterials.sort("level", "ascending", "integer");
			//SPEC: <02.20.2021>: Sumit Commented for Defect :38976 ## --ENDS
			Iterator objectListItrN = mlComponentsAnMaterials.iterator();
			String strTempSeq = DomainConstants.EMPTY_STRING;
			String strTempSeq1 = DomainConstants.EMPTY_STRING;
			Map mapForSeq = new HashMap();
			//SPEC: <07.02.2021>: Modified for Defect :43891 by Madhana ## --START
			int iVal =0;
			boolean isSortingRequired = false;
			//SPEC: <07.02.2021>: Modified for Defect :43891 by Madhana ## --END
			while (objectListItrN.hasNext()) {
				Map resultMapsTemp = (Map) objectListItrN.next();
				String sToID = (String) resultMapsTemp.get("from.id");
				String sFN = validator.getStringEquivalentForStringList(
						resultMapsTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));
				String sLevel = (String) (resultMapsTemp.get("level"));
				//SPEC: <07.02.2021>: Modified for Defect :43891 by Madhana ## --START
				//SPEC: <08-23-2021>: Guna Modified for Production Issue  -- START
				if(UIUtil.isNotNullAndNotEmpty(sLevel)){
						isSortingRequired = true;
					//SPEC: <07.02.2021>: Modified for Defect :43891 by Madhana ## --END

					String sObjID = validator.getStringEquivalentForStringList(resultMapsTemp.get(ConstantsUtil.SELECT_ID));
					if (sToID.equalsIgnoreCase(sRawMatId))
						strTempSeq = sLevel.concat(".").concat(sFN);
					else {
						strTempSeq1 = (String) mapForSeq.get(sToID);
						strTempSeq = strTempSeq1.concat(".").concat(sLevel).concat(".").concat(sFN);
					}
					mapForSeq.put(sObjID, strTempSeq);
					resultMapsTemp.put("FinalSeq", strTempSeq);
				}
				// END :: gaikwad.tg
			} 
			//SPEC: 08-08-2022: Dominic Added for Defect 49772 -- START
			if(isSortingRequired)
			{
				mlComponentsAnMaterials.sort("FinalSeq", "ascending", "integer");
			}
			//SPEC: 08-08-2022: Dominic Added for Defect 49772 -- END
		}catch (Exception e)

		{
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getSortedMaplistWithSequence " + e);
		}

		return mlComponentsAnMaterials;

	}
	// END :: gaikwad.tg

	// SPEC: <01.19.2020>: Added for Req :36032 by Sumit #(BOM Expansion)#
	// --START
	public MapList getExpandedBOM(Context context, DomainObject doParent, String sRel, String sType,
			StringList slEBOMSelects, StringList slRelEBOMSelects, String sWhereClause, String sNamePrefix)
					throws Exception {
		MapList mlReturnList = new MapList();
		StringValidatorUtil validator = new StringValidatorUtil();
		try {
			// Get 1st level BOMs
			MapList mlFirstBOMs = doParent.getRelatedObjects(context, sRel, DomainConstants.QUERY_WILDCARD, slEBOMSelects,
					slRelEBOMSelects, false, true, (short) 1, DomainConstants.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					0);

			if (mlFirstBOMs.size() > 0) {
				mlFirstBOMs.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING,
						ConstantsUtil.INTEGER);
			}
			Map objectMap = null;
			MapList mlPhase = null;
			MapList mlPhaseChild = null;
			MapList mlPhaseC = null;
			//SPEC: Release SR18x.6 - Added for Req# 36031 by Manikanta on Date 4/05/2021 -- START

			//SPEC: Release SR18x.6.0.1 - Added for internal defect by Sanjeeva on Date 5/13/2021 -- START
			//String sParentType = doParent.getType(context);
			String sParentType = doParent.getInfo(context, "type");
			//SPEC: Release SR18x.6.0.1 - Added for internal defect by Sanjeeva on Date 5/13/2021 -- END

			//SPEC: Release SR18x.6 - Added for Req# 36031 by Manikanta on Date 4/05/2021 -- END
			for (int i = 0; i < mlFirstBOMs.size(); i++) {
				objectMap = new HashMap();
				mlPhaseChild = new MapList();
				mlPhaseC = new MapList();
				objectMap = (Map) mlFirstBOMs.get(i);
				//SPEC: Release SR18x.6 - Modified for Req# 36031 by Manikanta on Date 4/05/2021 -- START
				String sPhaseType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sUserType = getUserType();
				if(sParentType.equals(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT) && (ConstantsUtil.PG_CM.equalsIgnoreCase(sUserType) || ConstantsUtil.PG_SP.equalsIgnoreCase(sUserType)) && sPhaseType.equalsIgnoreCase(ConstantsUtil.TYPE_PGBASEFORMULA)) {
					continue;
				}
				mlReturnList.add(objectMap);

				String sPhaseId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				//SPEC: Release SR18x.6 - Modified for Req# 36031 by Manikanta on Date 4/05/2021 -- END
				String sPhaseName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				int iPhaseLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));

				if (validator.isNotNullOrEmpty(sPhaseId) && validator.isNotNullOrEmpty(sPhaseType)
						&& sPhaseType.equals(ConstantsUtil.TYPE_PGPHASE) && sPhaseName.startsWith(sNamePrefix)) {
					//DomainObject doPhase = new DomainObject(sPhaseId);
					DomainObject doPhase = DomainObject.newInstance(context, sPhaseId);
					mlPhase = doPhase.getRelatedObjects(context, sRel, sType, slEBOMSelects, slRelEBOMSelects, false,
							true, (short) 0, sWhereClause, ConstantsUtil.EMPTY_STRING, 0);

					if (mlPhase.size() > 0) {
						mlPhase.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING,
								ConstantsUtil.INTEGER);
					}

					mlPhaseC = doPhase.getRelatedObjects(context, sRel, DomainConstants.QUERY_WILDCARD, slEBOMSelects,
							slRelEBOMSelects, false, true, (short) 1,
							ConstantsUtil.SELECT_TYPE + "!=" + ConstantsUtil.TYPE_PGPHASE, ConstantsUtil.EMPTY_STRING,
							0);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doPhase.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					if (mlPhaseC.size() > 0) {
						mlPhaseC.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING,
								ConstantsUtil.INTEGER);
						mlReturnList.addAll(increaseBOMLevel(mlPhaseC, iPhaseLevel + 1));
					}

					for (int j = 0; j < mlPhase.size(); j++) {
						objectMap = new HashMap();
						mlPhaseChild = new MapList();
						mlPhaseC = new MapList();
						objectMap = (Map) mlPhase.get(j);

						int iPhaseCLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));
						objectMap.remove(ConstantsUtil.SELECT_LEVEL);
						if (iPhaseCLevel == 1) {
							objectMap.put(ConstantsUtil.SELECT_LEVEL, String.valueOf(iPhaseLevel + 1));
						} else {
							//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 26, 2021 for Defect# 41772-- START
							//objectMap.put(ConstantsUtil.SELECT_LEVEL, String.valueOf(iPhaseLevel + 2));
							objectMap.put(ConstantsUtil.SELECT_LEVEL, String.valueOf(iPhaseCLevel + 1));
							//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 26, 2021 for Defect# 41772-- END
						}
						mlReturnList.add(objectMap);

						String sPhaseCId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
						String sPhaseCType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
						iPhaseCLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));

						if (validator.isNotNullOrEmpty(sPhaseCId) && validator.isNotNullOrEmpty(sPhaseCType)
								&& sPhaseCType.equals(ConstantsUtil.TYPE_PGPHASE)) {
							//DomainObject doPhaseChild = new DomainObject(sPhaseCId);
							DomainObject doPhaseChild = DomainObject.newInstance(context, sPhaseCId);
							mlPhaseChild = doPhaseChild.getRelatedObjects(context, sRel, DomainConstants.QUERY_WILDCARD,
									slEBOMSelects, slRelEBOMSelects, false, true, (short) 1,
									ConstantsUtil.SELECT_TYPE + "!=" + ConstantsUtil.TYPE_PGPHASE,
									ConstantsUtil.EMPTY_STRING, 0);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							doPhaseChild.close(context);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
							if (mlPhaseChild.size() > 0) {
								mlPhaseChild.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING,
										ConstantsUtil.INTEGER);
								mlReturnList.addAll(increaseBOMLevel(mlPhaseChild, iPhaseCLevel + 1));
							}
						}
					}
				}

			}

		} catch (Exception e)

		{
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getExpandedBOM " + e);
		}

		return mlReturnList;

	}

	public MapList increaseBOMLevel(MapList mlPhaseChild, int iLevel) {
		MapList mlReturnList = new MapList();
		Map objectMap = null;
		for (int k = 0; k < mlPhaseChild.size(); k++) {
			objectMap = new HashMap();
			objectMap = (Map) mlPhaseChild.get(k);
			objectMap.remove(ConstantsUtil.SELECT_LEVEL);
			objectMap.put(ConstantsUtil.SELECT_LEVEL, String.valueOf(iLevel));
			mlReturnList.add(objectMap);
		}
		return mlReturnList;
	}
	// SPEC: <01.19.2020>: Added for Req :36032 by Sumit #(BOM Expansion)#
	// --ENDS

	/**
	 * 
	 * @param context
	 * @param sContextObjectId
	 * @param legacyenvclassname
	 * @return
	 */
	public String getLegacyName(Context context, String sContextObjectId, String legacyenvclassname) {
		StringValidatorUtil validator = new StringValidatorUtil();
		String sReturnVal = ConstantsUtil.EMPTY_STRING;
		try {
			if (UIUtil.isNotNullAndNotEmpty(sContextObjectId)) {
				DomainConstants.MULTI_VALUE_LIST.add(legacyenvclassname);
				//DomainObject domObject = new DomainObject(sContextObjectId);
				DomainObject domObject = DomainObject.newInstance(context, sContextObjectId);
				DomainConstants.MULTI_VALUE_LIST.remove(legacyenvclassname);
				sReturnVal = validator
						.getStringEquivalentForSubstituteString(domObject.getInfo(context, legacyenvclassname));
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				domObject.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getLegacyName " + e);
			return "";
		}
		return sReturnVal;
	}

	/**
	 * 
	 * @param context
	 * @param objList
	 * @return
	 * @throws Exception
	 */
	public MapList getUsageFlags(Context context, MapList objList) throws Exception {

		SecurityService sec = new SecurityService();
		boolean bIsComplainceEngineer = sec.isComplainceEngineer();
		MapList mlfinalList = new MapList();
		Vector<String> strResult = new Vector();
		try {
			for (int i = 0; i < objList.size(); i++) {
				Map obj = (Map) objList.get(i);
				StringList strList = new StringList();
				String drugActive = "";
				String Colorant = "";
				String Preservative = "";
				String rel = "";
				if (UIUtil.isNotNullAndNotEmpty((String) obj.get("id[connection]"))) {
					StringList list = StringList.create(
							new String[] { FormulationAttribute.ACTIVE_INGREDIENT_FLAG.getAttributeSelect(context),
									FormulationAttribute.IS_COLORANT.getAttributeSelect(context),
									FormulationAttribute.PRESERVATIVE_FLAG.getAttributeSelect(context), "name" });

					String[] id = { (String) obj.get("id[connection]") };
					MapList resultMap = DomainRelationship.getInfo(context, id, list);

					Map<Object, Object> resMap = new HashMap<>();
					Iterator<Map<Object, Object>> itr = resultMap.iterator();
					while (itr.hasNext()) {
						resMap = itr.next();
					}

					drugActive = (String) resMap
							.get(FormulationAttribute.ACTIVE_INGREDIENT_FLAG.getAttributeSelect(context));
					Colorant = (String) resMap.get(FormulationAttribute.IS_COLORANT.getAttributeSelect(context));
					Preservative = (String) resMap
							.get(FormulationAttribute.PRESERVATIVE_FLAG.getAttributeSelect(context));
					rel = (String) resMap.get("name");
				} else {
					drugActive = (String) obj
							.get(FormulationAttribute.ACTIVE_INGREDIENT_FLAG.getAttributeSelect(context));
					Colorant = (String) obj.get(FormulationAttribute.IS_COLORANT.getAttributeSelect(context));
					Preservative = (String) obj.get(FormulationAttribute.PRESERVATIVE_FLAG.getAttributeSelect(context));
					rel = (String) obj.get("relationship");
				}

				String objType = (String) obj.get("type");
				boolean isSubstance = false;
				if (UIUtil.isNotNullAndNotEmpty(objType)) {
					isSubstance = objType.equalsIgnoreCase(FormulationType.SUBSTANCE.getType(context));
				}
				if (UIUtil.isNotNullAndNotEmpty(rel) && !bIsComplainceEngineer && rel.equalsIgnoreCase(
						FormulationRelationship.SECURE_COMPONENT_SUBSTANCE.getRelationship(context))) {
					strResult.add("");
				} else {
					if (isSubstance && UIUtil.isNotNullAndNotEmpty(drugActive) && UIUtil.isNotNullAndNotEmpty(Colorant)
							&& UIUtil.isNotNullAndNotEmpty(Preservative)) {
						if (UIUtil.isNotNullAndNotEmpty(drugActive) && UIUtil.isNotNullAndNotEmpty(Colorant)
								&& UIUtil.isNotNullAndNotEmpty(Preservative)) {
							if (drugActive.equalsIgnoreCase("Yes"))
								strList.add(ConstantsUtil.DRUG_ACTIVE);
							if (Colorant.equalsIgnoreCase("TRUE"))
								strList.add(ConstantsUtil.COLORANT);
							if (Preservative.equalsIgnoreCase("Yes"))
								strList.add(ConstantsUtil.PRESERVATIVE);
						}
					}

					strResult.add(FrameworkUtil.join(strList, ","));
				}
				obj.put(ConstantsUtil.FLAGS, FrameworkUtil.join(strList, ","));
				mlfinalList.add(obj);

			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getUsageFlags " + e);
		}
		return mlfinalList;
	}

	public StringList getDerivedTypes(Context context, DomainObject domainObject) throws Exception {
		String derivedType = domainObject.getInfo(context, DomainConstants.SELECT_TYPE);

		// Construct the list of type and its derived
		StringList derivedTypes = new StringList();
		while (derivedType != null && !derivedType.isEmpty()) {
			derivedTypes.add(derivedType);
			derivedTypes.add(FrameworkUtil.getAliasForAdmin(context, DomainConstants.SELECT_TYPE, derivedType, false));
			derivedType = MqlUtil.mqlCommand(context, "print type $1 select derived dump", derivedType);
		}
		return derivedTypes;
	}

	public String getDocumentDerivedTypes(Context context) throws Exception {
		String derivedType = "";
		derivedType = MqlUtil.mqlCommand(context, "print type $1 select derivative dump", ConstantsUtil.TYPE_DOCUMENT);

		return derivedType;
	}

	//START :: gaikwad.tg :: Defect#38630,37743
	public String getPostRecycledContent(Context context, MapList mlComponentsAnMaterials, String sPostRecycledKey)
			throws Exception {
		String strPostRecycledContent = "";
		StringValidatorUtil validator = new StringValidatorUtil();
		BigDecimal dDefaultValue = BigDecimal.valueOf(0.0D);
		BigDecimal dPostRecycledContent = dDefaultValue;
		BigDecimal dTempPostRecycledContent = dDefaultValue;
		BigDecimal dFinalPostRecycledContent = dDefaultValue;
		BigDecimal dTargetPercent = dDefaultValue;
		BigDecimal dDivideByHundred = new BigDecimal(100.0D);
		String strTargetPercentage = "";
		try {
			// START :: gaikwad.td
			Iterator objectListItrN = mlComponentsAnMaterials.iterator();
			Map resultMapsTemp = new HashMap();
			while (objectListItrN.hasNext()) 
			{
				resultMapsTemp = (Map) objectListItrN.next();
				strPostRecycledContent = validator.getStringEquivalentForStringList(resultMapsTemp.get(sPostRecycledKey));
				strTargetPercentage = validator.getStringEquivalentForStringList(resultMapsTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
				String sLevel = (String) (resultMapsTemp.get("level"));
				if (sLevel.equalsIgnoreCase("1"))
				{
					if (UIUtil.isNotNullAndNotEmpty(strTargetPercentage)) 
					{
						dTargetPercent = new BigDecimal(strTargetPercentage);
						dTargetPercent = dTargetPercent.divide(dDivideByHundred);
					} 
					if (UIUtil.isNotNullAndNotEmpty(strPostRecycledContent))
					{
						dPostRecycledContent = new BigDecimal(strPostRecycledContent);
					}

					dTempPostRecycledContent = dPostRecycledContent.multiply(dTargetPercent);
					dFinalPostRecycledContent = dFinalPostRecycledContent.add(dTempPostRecycledContent);
					dTempPostRecycledContent = dDefaultValue;
				}
			}
		} catch (Exception e)
		{
			LOGGER.error("Exception in Program : BusObjectAttribUtil Method :getPostRecycledContent " + e);
		}

		strPostRecycledContent = getPostRecycledContent(dFinalPostRecycledContent, dDefaultValue);

		return strPostRecycledContent;
	}
	//END :: gaikwad.tg :: Defect#38630,37743

	//START :: gaikwad.tg :: Defect#38338
	public String checkIsATSForSIS(Context context, Map objectMap) 
	{
		String sIsATSAttrVal = DomainConstants.EMPTY_STRING;
		String strObjectId = (String)objectMap.get(ConstantsUtil.SELECT_ID);
		String  strCurrent = DomainConstants.EMPTY_STRING;
		String  strID = DomainConstants.EMPTY_STRING;
		Map documentMap = null;
		StringList slSelect = new StringList(2);
		slSelect.addElement("current");
		slSelect.addElement("id");
		StringList slObsoleteATS = new StringList();
		try {
			if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
				DomainObject dObjIPM = DomainObject.newInstance(context, strObjectId);
				MapList documentList = dObjIPM.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION, "*", slSelect, null, false, true, (short)1, null, "");
				if (documentList != null && documentList.size() > 0) 
				{
					Iterator<Map> itrDocumentList = documentList.iterator();
					while (itrDocumentList.hasNext()) {
						documentMap = itrDocumentList.next();
						strCurrent = (String)documentMap.get("current");
						strID = (String)documentMap.get("id");
						if ("Release".equalsIgnoreCase(strCurrent)) {
							sIsATSAttrVal = "Yes"; break;
						} 
						if ("Obsolete".equalsIgnoreCase(strCurrent)) {
							slObsoleteATS.add(strCurrent);
						}
					} 
					if (slObsoleteATS.size() == documentList.size()) {
						sIsATSAttrVal = "No";
					}
				} 
				else {
					sIsATSAttrVal = "";
				}
			} 
		} catch (Exception ex) {
			ex.printStackTrace();
		} 

		return sIsATSAttrVal;

	}
	public String checkHasATSForSIS(Context context, Map resultMap) 
	{
		String sHasATSAttrVal = "No";
		try {
			StringValidatorUtil validator = new StringValidatorUtil();
			//SPEC: Release SR18x.5.2 - Added for Defect #39572 and #39574 by Bala on Date Feb 14, 2021 -- START
			//String strAttrValue = (String)resultMap.get(ConstantsUtil.ATTRIBUTE_PGORIGINATINGSOURCE);
			String strAttrValue = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE));
			//SPEC: Release SR18x.5.2 - Added for Defect #39572 and #39574 by Bala on Date Feb 14, 2021 -- END
			String strObjSymbType = (String)resultMap.get(ConstantsUtil.SELECT_TYPE);
			String strObjectId = (String)resultMap.get(ConstantsUtil.SELECT_ID);
			//StringValidatorUtil validator = new StringValidatorUtil();
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject doObj = DomainObject.newInstance(context, strObjectId);
				String strAllStates=	validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.ATL_STATE));
				//SPEC: Release SR18x.5.2 - Added for Defect #39572 and #39574 by Bala on Date Feb 14, 2021 -- START
				//StringList slFromTypeState =FrameworkUtil.split(strAllStates, ",");
				strAllStates=strAllStates.replace("| ", "|");
				StringList slFromTypeState =FrameworkUtil.split(strAllStates, "|");
				//SPEC: Release SR18x.5.2 - Added for Defect #39572 and #39574 by Bala on Date Feb 14, 2021 -- END
				boolean isDSO = (("DSO".equalsIgnoreCase(strAttrValue))?true:false);

				boolean isAPMP = doObj.isKindOf(context, ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART);
				boolean isTechSpec = doObj.isKindOf(context, ConstantsUtil.TYPE_TECHNICALSPECIFICATION);

				boolean bCheckForATSValue = false;
				//SPEC: Release SR18x.5.2 - Added for Defect #39572 and #39574 by Bala on Date Feb 14, 2021 -- START
				//String strTechSpecTypes = "type_pgPackingInstructions,type_pgStackingPattern,type_pgIllustration,type_pgLaboratoryIndexSpecification,type_pgMakingInstructions,type_pgProcessStandard,type_pgQualitySpecification,type_pgStandardOperatingProcedure,type_TestMethodSpecification,type_FormulaTechnicalSpecification,type_pgAuthorizedConfigurationStandard";
				String strTechSpecTypes = ConstantsUtil.TYPE_PGPACKINGINSTRUCTIONS+","+ConstantsUtil.TYPE_PGSTACKINGPATTERN+","+ConstantsUtil.TYPE_PGILLUSTRATION+","+ConstantsUtil.TYPE_PGLABORATORYINDEXSPECIFICATION+","+ConstantsUtil.TYPE_PGMAKINGINSTRUCTIONS+","+ConstantsUtil.TYPE_PGPROCESSSTANDARD+","+ConstantsUtil.TYPE_PGQUALITYSPECIFICATION+","+ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE+","+ConstantsUtil.TYPE_TESTMETHOD+","+ConstantsUtil.TYPE_FORMULATECHNICALSPEC+","+ConstantsUtil.TYPE_AUTHORIZEDCONFIGSTAND;
				//SPEC: Release SR18x.5.2 - Added for Defect #39572 and #39574 by Bala on Date Feb 14, 2021 -- END
				StringList slTechSpecTypes = FrameworkUtil.split(strTechSpecTypes, ",");
				if (isDSO) 
				{
					if ((isTechSpec && !slTechSpecTypes.contains(strObjSymbType)) || isAPMP)
					{
						sHasATSAttrVal = "N/A";
					}
					else {
						//SPEC: Release SR18x.5.2 - Added for Defect #39572 and #39574 by Bala on Date Feb 14, 2021 -- START
						//Added as per the Enovia code analysis.
						sHasATSAttrVal = DomainConstants.EMPTY_STRING;
						//SPEC: Release SR18x.5.2 - Added for Defect #39572 and #39574 by Bala on Date Feb 14, 2021 -- END
						bCheckForATSValue = true;
					}
				}
				else
					bCheckForATSValue = true;

				if(bCheckForATSValue)
				{
					Iterator itr = slFromTypeState.iterator();
					String strATSState = "";
					StringList slObsoleteATS = new StringList();
					while (itr.hasNext()) {
						strATSState = itr.next().toString();
						if ("Release".equalsIgnoreCase(strATSState)) {
							sHasATSAttrVal = "Yes"; break;
						} 
						if ("Obsolete".equalsIgnoreCase(strATSState)) {
							slObsoleteATS.add(strATSState);
						}
					}
					if (slObsoleteATS.size() == slFromTypeState.size()) 
					{
						sHasATSAttrVal = "No";
					}
					if (slFromTypeState.size() == 0) {
						sHasATSAttrVal = "";
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} 

		return sHasATSAttrVal;

	}
	//END :: gaikwad.tg :: Defect#38338

	//START :: gaikwad.tg :: Defect#39069
	public String getDryValueToDisplay(Context context, Map resultMap) 
	{
		String strTempDry = DomainConstants.EMPTY_STRING;
		String strTotalQuantytites = "";
		BigDecimal dQuantites = new BigDecimal(0.0D);
		StringList slQuantities = DomainConstants.EMPTY_STRINGLIST;
		int iQuantityListSize = 0;
		StringValidatorUtil validator = new StringValidatorUtil();
		try 
		{
			String sDRY 		= validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
			String strRelName	 = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_NAME));
			String sCont 		= validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
			String strID 		= validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ID));
			String sType 		= validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_TYPE));
			strTempDry = sDRY;
			//SPEC: Release SR18x.5.2 - Added for Defect# 39605  by gaikwad.tg on Date 18 Feb 2021 -- START
			if (UIUtil.isNotNullAndNotEmpty(strRelName) && strRelName.equalsIgnoreCase(ConstantsUtil.RELATIONSHIP_SECURE_COMPONENT_SUBSTANCE) && ("TRUE".equalsIgnoreCase(sCont) || sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES))) 
				strTempDry = "";
			else if ("TRUE".equalsIgnoreCase(sCont) || sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) 
				//SPEC: Release SR18x.5.2 - Added for Defect# 39605  by gaikwad.tg on Date 18 Feb 2021 -- END
				strTempDry = "";
			else if (UIUtil.isNotNullAndNotEmpty(strID) && ConstantsUtil.TYPE_INTERNAL_MATERIAL.equals(sType)) 
			{
				DomainObject domContextPart = DomainObject.newInstance(context, strID);
				String strInternalMaterialFor = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
				if ("Product".equals(strInternalMaterialFor))
				{
					slQuantities = getNonContaminantQuantities(context, domContextPart);
					slQuantities.sort();
					iQuantityListSize = slQuantities.size();
					for (int j = 0; j < iQuantityListSize; j++)
					{
						dQuantites = dQuantites.add(new BigDecimal((String)slQuantities.get(j)));
					}
					if (dQuantites.compareTo(new BigDecimal(0.0D)) != 0)
					{
						strTotalQuantytites = dQuantites.toPlainString();
						strTempDry = strTotalQuantytites;
						//SPEC: 09/04/2021: Modified for 18x.6 Defect-41995 by Manikanta -- START
						//SPEC: 22/04/2021: Commented for 18x.6 Defect-42680 by Guna -- START
					}/*else if(slQuantities.isEmpty()) {
						strTempDry = "";
					}*/
					//SPEC: 22/04/2021: Commented for 18x.6 Defect-42680 by Guna -- END
					//SPEC: 09/04/2021: Modified for 18x.6 Defect-41995 by Manikanta -- END
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
		return strTempDry;
	}

	public StringList getNonContaminantQuantities(Context context, DomainObject domContextPart) 
	{
		StringList slQuantList = new StringList();
		try 
		{
			StringList relSelects = new StringList(2);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			MapList mlQuantList = domContextPart.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE, ConstantsUtil.TYPE_SUBSTANCE, new StringList("id"), relSelects, false, true, (short)1, null, null, 0);
			if (mlQuantList != null && mlQuantList.size() > 0)
			{
				Map quantObjMap = null;
				String isContaminant = "";
				for (Object quantObj : mlQuantList) {
					quantObjMap = (Map)quantObj;
					isContaminant = (String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39605  by gaikwad.tg on Date 18 Feb 2021 -- START
					if (!("TRUE".equalsIgnoreCase(isContaminant) || isContaminant.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)))
						//SPEC: Release SR18x.5.2 - Added for Defect# 39605  by gaikwad.tg on Date 18 Feb 2021 -- END
						slQuantList.add((String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
				}
			} 
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		return slQuantList;
	}

	public String formattingDryValueToDisplay(Context context, String sDRY) 
	{
		String strTempDry = DomainConstants.EMPTY_STRING;
		StringValidatorUtil validator = new StringValidatorUtil();
		try 
		{
			//SPEC: Release SR18x.5.2 - Added for Defect# 39605  by gaikwad.tg on Date 18 Feb 2021 -- START
			if(!validator.isNotNullOrEmpty(sDRY) && sDRY.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
				//SPEC: Release SR18x.5.2 - Added for Defect# 39605  by gaikwad.tg on Date 18 Feb 2021 -- END
				strTempDry = "0";
			//Modified by Ganesh for Defect 41811 on Date <7 April 2021>----->START
			else if(sDRY.equalsIgnoreCase("1.0"))
				//strTempDry="100.0";
				strTempDry="1";
			//Modified by Ganesh for Defect 41811 on Date <7 April 2021>----->END
			else if (sDRY.endsWith(".0"))
			{
				Float objF = new Float(sDRY);
				strTempDry =  String.valueOf(objF.intValue());
			}
			else
				strTempDry = sDRY;
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
		} 
		return strTempDry;
	}
	//END :: gaikwad.tg :: Defect#39069

	//SPEC: Release SR18x.5.2 - Modified for Defect# 39185  by Jwala -- START
	public String mapPackingUnitType(String sType) {
		if (null != sType) {
			switch (sType.trim()) {
			case "Consumer_Unit":
				sType = "Consumer Unit";
				break;
			case "Customer_Unit":
				sType = "Customer Unit";
				break;
			case "Inner_Pack":
				sType = "Inner Pack";
				break;
			default:
				sType = sType;
				break;
			}
		}
		return sType;
	}
	//SPEC: Release SR18x.5.2 - Modified for Defect# 39185  by Jwala -- START
	//SPEC: Release SR18x.5.2 - Added for Defect# 39386  by gaikwad.tg on Date 16 Feb 2021 -- START

	/**
	 * Check isTamu
	 * 
	 * @param slTMName
	 * @param slTMType
	 * @param slsChildObjectID
	 * @param slTamuList
	 * @return
	 */
	public Map removeTestMethodTamuNew(StringList slTMName, StringList slTMType, StringList slsChildObjectID,
			StringList slTamuList, String strATTR_PG_ORIGINATINGSOURCE) {
		StringList slTMNameFiltered = new StringList();
		StringList slTMFilteredType = new StringList();
		StringList slTMFilteredID = new StringList();

		StringList slTMSName = new StringList();
		StringList slTMSType = new StringList();
		StringList slTMSFID = new StringList();

		String sType = ConstantsUtil.TYPE_TESTMETHODSPECIFCATION;
		for (int i = 0; i < slTMType.size(); i++) {
			if("DSO".equals(strATTR_PG_ORIGINATINGSOURCE) && !(slTMType.get(i)).equals("pgTestMethod"))
			{
				if((!slTMSName.isEmpty() && !slTMSName.contains(slTMName.get(i))) || slTMSName.isEmpty())
				{
					slTMSName.add(slTMName.get(i));
					slTMSType.add(slTMType.get(i));
					slTMSFID.add(slsChildObjectID.get(i));
				}

			}
			if ((sType.equals(slTMType.get(i)) || ConstantsUtil.TYPE_PGTESTMETHOD.equals(slTMType.get(i))) && !"TAMU".equals(slTamuList.get(i))) {
				slTMNameFiltered.add(slTMName.get(i));
				slTMFilteredType.add(slTMType.get(i));
				slTMFilteredID.add(slsChildObjectID.get(i));

			}
			else
			{
				slTMSName.add(slTMName.get(i));
				slTMSType.add(slTMType.get(i));
				slTMSFID.add(slsChildObjectID.get(i));
			}



		}
		Map<String, StringList> mpTemp = new HashMap<String, StringList>();

		mpTemp.put(ConstantsUtil.TMFILNAME, slTMNameFiltered);
		mpTemp.put(ConstantsUtil.TMFILID, slTMFilteredID);
		mpTemp.put(ConstantsUtil.TMFILTYPE, slTMFilteredType);

		mpTemp.put(ConstantsUtil.BASENAME, slTMSName);
		mpTemp.put(ConstantsUtil.BASETYPE, slTMSType);
		mpTemp.put(ConstantsUtil.BASEID, slTMSFID);

		return mpTemp;
	}
	//SPEC: Release SR18x.5.2 - Added for Defect# 39386  by gaikwad.tg on Date 16 Feb 2021 -- END


	/**	
	 * This Method will  separates the Hir Licenses
	 * @param sObjectLicense
	 * @returns HiRLicensesList
	 */
	private StringList getStringListOfHirLicense(String sObjectLicense)
	{
		if (UIUtil.isNullOrEmpty(sObjectLicense) && sObjectLicense.contains(ConstantsUtil.HIR) ) {
			return ConstantsUtil.EMPTY_STRINGLIST;
		}
		String sTemp[] = sObjectLicense.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

		StringList slFinal = new StringList();
		for (int i = 0; i < sTemp.length; i++) {
			String sData = sTemp[i].trim();
			if(sData.contains(ConstantsUtil.HIR) ) {
				slFinal.add(sData);
			}
		}

		return slFinal;
	}

	/**
	 * validates Hir Licenses
	 * @param slObjectHirLicenses
	 * @param slUserLicense
	 * @returns boolean value
	 */
	private boolean checkHiRLicense(StringList slObjectHirLicenses, StringList slUserLicense) 
	{
		boolean bHasHir=false;
		if (slObjectHirLicenses.size()!=0) 
		{
			for (int i = 0; i < slUserLicense.size(); i++)
			{
				bHasHir = slObjectHirLicenses.contains(slUserLicense.get(i).trim());
				if (bHasHir) 
					return true;
			}
		}else {
			bHasHir=true;
		}
		return bHasHir;

	}
	//SPEC: Release SR18x.5.2 - Added for Defect# 39386  by gaikwad.tg on Date 16 Feb 2021 -- START

	/**
	 * Check isTamu
	 * 
	 * @param slTMName
	 * @param slTMType
	 * @param slsChildObjectID
	 * @param slTamuList
	 * @return
	 */
	public Map removeTestMethod(StringList slTMName, StringList slTMType, StringList slsChildObjectID,
			StringList slTamuList, String strATTR_PG_ORIGINATINGSOURCE, String strParentType) {
		//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- START
		Map<String, StringList> mpTemp = new HashMap<String, StringList>();
		try
		{
			//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- END
			StringList slTMNameFiltered = new StringList();
			StringList slTMFilteredType = new StringList();
			StringList slTMFilteredID = new StringList();

			StringList slTMSName = new StringList();
			StringList slTMSType = new StringList();
			StringList slTMSFID = new StringList();
			String stTempTAMU = DomainConstants.EMPTY_STRING;

			String sType = ConstantsUtil.TYPE_TESTMETHODSPECIFCATION;

			//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- START
			StringList sortedNames = new StringList();
			String strTempName = DomainConstants.EMPTY_STRING;
			String strTempID = DomainConstants.EMPTY_STRING;
			StringList slExcludeTypes = getPerformCharSelectsForTypeExclude();
			//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- END
			for (int i = 0; i < slTMType.size(); i++) {

				String stTempType = slTMType.get(i);
				//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- START
				if (i != -1 && slTMName != null && !slTMName.isEmpty() && slTMName.size() >= i)
					strTempName = UIUtil.isNotNullAndNotEmpty(slTMName.get(i)) ? slTMName.get(i) : DomainConstants.EMPTY_STRING;
					if (i != -1 && slsChildObjectID != null && !slsChildObjectID.isEmpty() && slsChildObjectID.size() >= i)
						strTempID = UIUtil.isNotNullAndNotEmpty(slsChildObjectID.get(i)) ? slsChildObjectID.get(i) : DomainConstants.EMPTY_STRING;
						//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- END
						if (i != -1 && slTamuList != null && !slTamuList.isEmpty() && slTamuList.size() >= i)
							stTempTAMU = UIUtil.isNotNullAndNotEmpty(slTamuList.get(i)) ? slTamuList.get(i) : DomainConstants.EMPTY_STRING;

							boolean bIspgTestMethod = stTempType.equals("pgTestMethod");
							//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- START
							boolean bIspgTestMethodSpecification = stTempType.equals(sType);
							//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- END
							boolean bIsTAMU = stTempTAMU.equals("TAMU");
							//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- START
							if(ConstantsUtil.DSO.equals(strATTR_PG_ORIGINATINGSOURCE) && !bIspgTestMethod  && !sortedNames.contains(strTempName) && (slExcludeTypes.contains(strParentType) && !bIspgTestMethodSpecification))
							{
								if(!sortedNames.contains(strTempName))
								{
									slTMSName.add(strTempName);
									slTMSType.add(stTempType);
									slTMSFID.add(strTempID);
									sortedNames.add(strTempName);
								}

							}
							//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- END
							//SPEC: Release SR18x.5.2 - Added for Defect# 40047  by gaikwad.tg on Date 19 Feb 2021 -- END
							if(ConstantsUtil.DSO.equals(strATTR_PG_ORIGINATINGSOURCE) && (stTempType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || stTempType.equals(ConstantsUtil.TYPE_TESTMETHOD)))
							{
								slTMNameFiltered.add(strTempName);
								slTMFilteredType.add(stTempType);
								slTMFilteredID.add(strTempID);
							}
								else if(!ConstantsUtil.DSO.equals(strATTR_PG_ORIGINATINGSOURCE))
							{
								if ((sType.equals(stTempType) || ConstantsUtil.TYPE_PGTESTMETHOD.equals(stTempType)) && !"TAMU".equals(stTempTAMU)) {
									slTMNameFiltered.add(strTempName);
									slTMFilteredType.add(stTempType);
									slTMFilteredID.add(strTempID);
								}
							}
							//SPEC: Release SR18x.5.2 - Added for Defect# 40047  by gaikwad.tg on Date 19 Feb 2021 -- END
							//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- START
							if((!(bIspgTestMethod && !bIsTAMU)) && !sortedNames.contains(strTempName) && (slExcludeTypes.contains(strParentType) && !bIspgTestMethodSpecification))
							{
								slTMSName.add(strTempName);
								slTMSType.add(stTempType);
								slTMSFID.add(strTempID);
								sortedNames.add(strTempName);
							}
							//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- END


			}
			mpTemp.put(ConstantsUtil.TMFILNAME, slTMNameFiltered);
			mpTemp.put(ConstantsUtil.TMFILID, slTMFilteredID);
			mpTemp.put(ConstantsUtil.TMFILTYPE, slTMFilteredType);

			mpTemp.put(ConstantsUtil.BASENAME, slTMSName);
			mpTemp.put(ConstantsUtil.BASETYPE, slTMSType);
			mpTemp.put(ConstantsUtil.BASEID, slTMSFID);
			//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- START
		}

		catch(Exception e)
		{

			e.printStackTrace();
			LOGGER.error("Exception in BusObjectAttribUtil : " + e);
			return new HashMap();

		}
		//SPEC: Release SR18x.5.2 - Added for Defect# 40060  by gaikwad.tg on Date 19 Feb 2021 -- END
		return mpTemp;
	}
	//SPEC: Release SR18x.5.2 - Added for Defect# 39386  by gaikwad.tg on Date 16 Feb 2021 -- END
	//SPEC: Release SR18x.5.2 - Added for Defect #39207 #39844 by Bala on Feb 19, 2021 -- START
	/**
	 * Method Name 			: getOriginatorName
	 * Method Description 	: 
	 * @param context
	 * @param args
	 * @return
	 */
	public String getOriginatorName(Context context, Map resultMap,String ldapuser,String ldappwd) 
	{	
		String strOriginatorName = ConstantsUtil.EMPTY_STRING;

		try {
			String objectId = (String)resultMap.get(ConstantsUtil.ID);
			DomainObject doj = DomainObject.newInstance(context, objectId);
			String strAttributeValue = (String)doj.getInfo(context,DomainConstants.SELECT_ORIGINATOR);
			strOriginatorName =	getUserName(context,strAttributeValue,ldapuser,ldappwd);

		} catch (Exception ex) {
			LOGGER.error("Error from BusObjAttribUtil: getOriginatorName" + ex);
			strOriginatorName = ConstantsUtil.EMPTY_STRING;
		}
		return strOriginatorName;
	}


	/**
	 * Method Name 			: getUserName
	 * Method Description 	: 
	 * @param context
	 * @param strOriginator
	 * @return
	 * @throws Exception
	 */
	public String getUserName(Context context, String strOriginator,String ldapuser,String ldappwd) 
	{	
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String strUserName=ConstantsUtil.EMPTY_STRING;

		try{
			StringList slObjSelects = new StringList(5);
			slObjSelects.addElement(DomainConstants.SELECT_ID);
			slObjSelects.addElement(DomainConstants.SELECT_NAME);
			slObjSelects.addElement("attribute[First Name]");
			slObjSelects.addElement("attribute[Last Name]");
			slObjSelects.addElement("attribute[pgTNumber]");
			String strNamePattern="*";
			String strRevisionPattern="*";
			String strWhere="attribute[pgTNumber]==\""+strOriginator+"\" && revision==last";

			MapList mlDataList =  DomainObject.findObjects(context, //MatrixContext
														DomainConstants.TYPE_PERSON, //typePattern
														strNamePattern, //namePattern
														strRevisionPattern, //revPattern
														DomainConstants.QUERY_WILDCARD, //ownerPattern
														ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
														strWhere, //whereExpression
														false, //expandType
														slObjSelects); //objectSelects
			if(mlDataList.size()>0){
				Map dataMap= (Map)mlDataList.get(0);
				strUserName=(String)dataMap.get("attribute[First Name]")+" "+(String)dataMap.get("attribute[Last Name]");
			}else{
				strUserName = util.getLDAPInfo(strOriginator, true,ldapuser,ldappwd);
			}
		}catch (Exception ex) {
			LOGGER.error("Error from BusObjectAttribUtil: getUserName " + ex);
			strUserName=ConstantsUtil.EMPTY_STRING;
		} 
		return strUserName;
	}
	//SPEC: Release SR18x.5.2 - Added for Defect #39207 #39844 by Bala on Feb 19, 2021 -- END

	//SPEC: Release SR18x.5.2 - Added for Defect# 40066  by gaikwad.tg on Date 19 Feb 2021 -- START

	public StringList getPerformCharSelectsForTypeExclude() {
		//SPEC: 03-09-2020: Modified for 18x.6 DEV by Sanjeeva -- START -- Excluded IP Part
		StringList objectSelects = createSelects(ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART,

				ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART,
				ConstantsUtil.TYPE_RAWMATERIALPART,
				ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART,
				ConstantsUtil.TYPE_DEVICEPRODUCTPART,
				ConstantsUtil.TYPE_MASTERPRODUCTPART,
				ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART,
				ConstantsUtil.TYPE_MASTERRAWMATERIALPART,
				//SPEC: Added for Defect 40018 by Sanjeeva - END
				ConstantsUtil.TYPE_PACKAGINGMATERIALPART,
				ConstantsUtil.TYPE_PGCONSUMERUNITPART,
				//SPEC: Release SR18x.6.0 - Added  by Sumit on Date 15 March 2021 -- START
				ConstantsUtil.TYPE_PGMASTERPACKAGINGASSEMBLYPART,
				ConstantsUtil.TYPE_FINISHEDPRODUCTPART,
				ConstantsUtil.TYPE_PG_MASTER_CONSUMER_UNIT_PART,
				ConstantsUtil.TYPE_PG_MASTER_CUSTOMER_UNIT_PART,
				//SPEC: Release SR18x.6.0 - Added  by Sumit on Date 15 March 2021 -- END
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- START
				ConstantsUtil.TYPE_FORMULATIONPART,
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- END
				//SPEC: Release SR18x.6.0 - Modified for PIP Supplier View by Manikanta on Date 22/03/2021 -- START
				ConstantsUtil.TYPE_PGPROMOTIONALITEMPART,
				//SPEC: Release SR18x.6.0 - Modified for PIP Supplier View by Manikanta on Date 22/03/2021 -- END
				//SPEC: Release SR18x.6.0 - Modified for IRMS Supplier View by Manikanta on Date 23/03/2021 -- START
				//SPEC: Added for Defect 40051,40056 by Sanjeeva - START
				ConstantsUtil.TYPE_PGRAWMATERIAL,
				//SPEC: Added for Defect 40051,40056 by Sanjeeva - END
				//SPEC: Release SR18x.6.0 - Modified for IRMS Supplier View by Manikanta on Date 23/03/2021 -- END
				//SPEC: Release SR18x.6.0 - Modified for Missing Types for TMRDN Issue by gaikwad.tg on Date 05/04/2021 -- START
				ConstantsUtil.TYPE_PGONLINEPRINTINGPART,
				ConstantsUtil.TYPE_PGMASTERPACKAGINGMATERIALPART,
				ConstantsUtil.TYPE_FABRICATEDPART,
				ConstantsUtil.TYPE_PG_CUSTOMERUNIT,
				ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART,
				//SPEC: Release SR18x.6.0 - Modified for Missing Types for TMRDN Issue by gaikwad.tg on Date 05/04/2021 -- END
				//SPEC: Release SR18x.6.0 - Added for ExternalDefect# by gaikwad.tg on Date 29 April 2021 -- START
				ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART,
				//SPEC: Release SR18x.6.0 - Added for ExternalDefect# by gaikwad.tg on Date 29 April 2021 -- END
				//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43536 on Date 14/06/2021 --START
				ConstantsUtil.TYPE_SOFTWAREPART,
				//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43536 on Date 14/06/2021 --END
				ConstantsUtil.TYPE_PG_INNER_PACK_UNIT_PART);
		//SPEC: 03-09-2020: Modified for 18x.6 DEV by Sanjeeva -- END
		return objectSelects;
	}

	//SPEC: Release SR18x.5.2 - Added for Defect# 40066  by gaikwad.tg on Date 19 Feb 2021 -- END

	/**
	 * Verify All Project  Licenses
	 * @param sUserProjectlicense
	 * @param ObjectProject Security
	 * @returns boolean
	 */
	public boolean checkProjectLicenses(String sUserlicense, String sFormulaClassif) {
		boolean bHasLicense = false;
		try {

			if (UIUtil.isNullOrEmpty(sUserlicense)) {
				return bHasLicense;
			}

			if (UIUtil.isNotNullAndNotEmpty(sFormulaClassif)) 
			{
				StringList slUserLicense = returnStringListFromStringWithComma(sUserlicense);
				StringList slObjectLicenses = getStringList(sFormulaClassif);
				for (int i = 0; i < slObjectLicenses.size(); i++) {
					bHasLicense = slUserLicense.contains(slObjectLicenses.get(i).trim());
					if (!bHasLicense)
						return false;
				}
			} else 
			{
				return bHasLicense;
			}
		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :checkProjectLicenses ");
			return bHasLicense;
		}

		return bHasLicense;

	}

	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 24 Feb 2021 -- START
	/**
	 * This method will retrieve the Raw Material BOMs along with its MEP,SEP,Alternate and Substitutes connected to the Part
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public MapList getConnectedRawMaterialfromPart(Context context, String strPartId) throws Exception
	{
		MapList finalMapList = new MapList();

		//Added for expanding the individual BOM
		String strBOMId = DomainConstants.EMPTY_STRING;
		//Added for expanding the individual BOM

		MapList ebomList = new MapList();
		MapList mepList = new MapList();
		MapList sepList = new MapList();
		MapList alternateList = new MapList();
		MapList substituteList = new MapList();
		//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
		boolean bExpandSubstitute = false;
		boolean bExpandAlternate = false;
		String sSelectedObject = "";

		try{
			if(UIUtil.isNotNullAndNotEmpty(strPartId)) {
				
				sSelectedObject = strPartId;
		//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END			
				DomainObject domObj = DomainObject.newInstance(context, strPartId);	

				Pattern patternRel = new Pattern(DomainConstants.RELATIONSHIP_EBOM);
				patternRel.addPattern(ConstantsUtil.REL_FBOM);

			Pattern patternType = new Pattern(ConstantsUtil.TYPE_FORMULATIONPHASE);
			patternType.addPattern(ConstantsUtil.TYPE_RAWMATERIALPART);

			StringList slBusSelects = new StringList(5);
			slBusSelects.addElement(DomainConstants.SELECT_TYPE);
			slBusSelects.addElement(DomainConstants.SELECT_NAME);
			slBusSelects.addElement(DomainConstants.SELECT_REVISION);
			slBusSelects.addElement(DomainConstants.SELECT_ID);
			slBusSelects.addElement(DomainConstants.SELECT_POLICY);
			slBusSelects.addElement(DomainConstants.SELECT_CURRENT);

			StringList slRelSelects  = new StringList(6);
			slRelSelects.addElement(DomainRelationship.SELECT_NAME);
			slRelSelects.addElement(DomainRelationship.SELECT_ID);
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.id").toString());
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.policy").toString());
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM +"].to.id").toString());
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM +"].to.policy").toString());

			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM).append("].to.name").toString());
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM +"].to.type").toString());
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM).append("].to.revision").toString());
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM +"].to.current").toString());

			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.name").toString());
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.type").toString());
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.revision").toString());
			slRelSelects.addElement(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.current").toString());

			String sPartType = domObj.getInfo(context, DomainConstants.SELECT_TYPE);
			boolean isFormulationPart = false;

			if(UIUtil.isNotNullAndNotEmpty(sPartType) && sPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)){
				isFormulationPart = true;
				String sFOPRId = domObj.getInfo(context, new StringBuilder("from[").append(ConstantsUtil.RELATIONSHIP_PLANNEDFOR).append("].to.id").toString());
				if(UIUtil.isNotNullAndNotEmpty(sFOPRId)){
					domObj.setId(sFOPRId);
				}
			}

			MapList mlRawMatBOMs = domObj.getRelatedObjects(context,
					patternRel.getPattern(),	//relationship pattern 
					patternType.getPattern(),	//type pattern 
					slBusSelects,	//object selects
					slRelSelects,	//relationship selects
					false,	//to direction
					true,	//from direction
					(short)2,	//recursion level
					null,	//object where clause
					null,	//relationship where clause
					0);	//limit

			if(mlRawMatBOMs!= null && !mlRawMatBOMs.isEmpty())
			{
				Iterator itrRMBOMs = mlRawMatBOMs.iterator();
				Map mapBOMPartDetails = new HashMap();
				String sBOMPartType = DomainConstants.EMPTY_STRING;
				String sBOMPartId = DomainConstants.EMPTY_STRING;

				MapList mlConnectedMEPsSEPsAlternates = new MapList();
				Iterator itrConnectedMEPsSEPsAlternates = null;

				HashMap tempMap = new HashMap();
				Map mpConnectedPartDetails = new HashMap();

				String sConnectedPartId = DomainConstants.EMPTY_STRING;
				String sConnectedPartPolicy = DomainConstants.EMPTY_STRING;
				Object objMEPSEPCertification = null;
				String sREACHStatus = DomainConstants.EMPTY_STRING;
				String sREACHRegNum = DomainConstants.EMPTY_STRING;

				String sMEPSEPCertificationRelId = DomainConstants.EMPTY_STRING;
				StringList slMEPSEPCertificationRelId = new StringList();
				Iterator itrMEPSEPCertificationRelId = null;

				Object objSubstitute = null;
				Object objSubstitutePolicy = null;
				Object objSubstituteName = null;
				Object objSubstituteType = null;
				Object objSubstituteRev = null;
				Object objSubstituteCurrent = null;
				String sSubstitutePart = DomainConstants.EMPTY_STRING;
				String sSubstitutePolicy = DomainConstants.EMPTY_STRING;
				String sSubstituteType = DomainConstants.EMPTY_STRING;
				String sSubstituteName = DomainConstants.EMPTY_STRING;
				String sSubstituteRev = DomainConstants.EMPTY_STRING;
				String sSubstituteCurrent = DomainConstants.EMPTY_STRING;
				StringList slSubstitutePart = new StringList();
				StringList slSubstitutePolicy = new StringList();
				StringList slSubstituteType = new StringList();
				StringList slSubstituteName = new StringList();
				StringList slSubstituteRev = new StringList();
				StringList slSubstituteCurrent = new StringList();
				StringValidatorUtil validator = new StringValidatorUtil();
				//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
				String sAlternatePart = DomainConstants.EMPTY_STRING;
				//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END
				//SPEC: Release SR18x.6.0 - #Defect41538,42449 Added  by gaikwad.tg on Date 16 April 2021 -- START
				boolean showData = false;
				String sUserType = getUserType();
				//SPEC: Release SR18x.6.0 - #Defect41538,42449 Added  by gaikwad.tg on Date 16 April 2021 -- END
				HashSet setUniqueSubs = new HashSet();

				Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT);
				relPattern.addPattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
				relPattern.addPattern(DomainConstants.RELATIONSHIP_ALTERNATE);

				Pattern typePattern = new Pattern(ConstantsUtil.TYPE_RAWMATERIALPART);

				StringList selectStmts = new StringList(6);
				selectStmts.addElement(DomainConstants.SELECT_ID);
				selectStmts.addElement(DomainConstants.SELECT_POLICY);
				selectStmts.addElement(DomainConstants.SELECT_CURRENT);
				selectStmts.addElement(DomainConstants.SELECT_NAME);
				selectStmts.addElement(DomainConstants.SELECT_REVISION);
				selectStmts.addElement(DomainConstants.SELECT_TYPE);
				selectStmts.add(new StringBuilder("from[").append(ConstantsUtil.RELATIONSHIP_EBOM).append("].frommid["+ ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE +"].to.id").toString());
				selectStmts.addElement(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACH_STATUS));
				selectStmts.addElement(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACHREGISTRATIONNUMBER));

				StringList selectRelStmts = new StringList(2);
				selectRelStmts.addElement("frommid["+ConstantsUtil.RELATIONSHIP_PGMEPSEPCERTIFICATION+"].id");
				selectRelStmts.addElement(DomainRelationship.SELECT_ID);
				while(itrRMBOMs.hasNext())
				{
					mapBOMPartDetails = (Map)itrRMBOMs.next();
					sBOMPartType = (String)mapBOMPartDetails.get(DomainConstants.SELECT_TYPE);
					sBOMPartId = (String)mapBOMPartDetails.get(DomainConstants.SELECT_ID);

					if(isFormulationPart){
						objSubstitute = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM).append("].to.id").toString());
						objSubstitutePolicy = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM +"].to.policy").toString());
						objSubstituteName = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM).append("].to.name").toString());
						objSubstituteType = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM +"].to.type").toString());
						objSubstituteRev = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM).append("].to.revision").toString());
						objSubstituteCurrent = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).append("].to.from[").append(ConstantsUtil.REL_FBOM +"].to.current").toString());
					}else{
						objSubstitute = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.id").toString());
						objSubstitutePolicy = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.policy").toString());
						objSubstituteName = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.name").toString());
						objSubstituteType = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.type").toString());
						objSubstituteRev = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.revision").toString());
						objSubstituteCurrent = mapBOMPartDetails.get(new StringBuilder("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.current").toString());
					}

					if(UIUtil.isNotNullAndNotEmpty(sBOMPartType) && 
							(sBOMPartType.equalsIgnoreCase(ConstantsUtil.TYPE_PGRAWMATERIAL) || sBOMPartType.equalsIgnoreCase(ConstantsUtil.TYPE_RAWMATERIALPART) 
									||sBOMPartType.equalsIgnoreCase(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART)))
					{
						mapBOMPartDetails.put(DomainConstants.SELECT_LEVEL,"1");
						mapBOMPartDetails.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE, ConstantsUtilIRM.CONST_EP);

						mapBOMPartDetails.put(ConstantsUtilIRM.CONST_REACHSTATUS,DomainConstants.EMPTY_STRING);
						mapBOMPartDetails.put(ConstantsUtilIRM.CONST_REACHREGNUM,DomainConstants.EMPTY_STRING);
						ebomList.add(mapBOMPartDetails);

						//Added for expanding the individual BOM
						if(UIUtil.isNullOrEmpty(strBOMId)){
							finalMapList.addAll(ebomList);
						}
						//Added for expanding the individual BOM

						//SPEC: Release SR18x.6.0 - #Defect41538,42449 Added  by gaikwad.tg on Date 16 April 2021 -- START
						showData = checkHasAccess(context, sUserType, sBOMPartId);
						//SPEC: Release SR18x.6.0 - #Defect41538,42449 Added  by gaikwad.tg on Date 16 April 2021 -- END
						domObj.setId(sBOMPartId);
						String sWhere="current!="+ConstantsUtil.STATE_OBSOLETE;
						mlConnectedMEPsSEPsAlternates = domObj.getRelatedObjects(context,
								relPattern.getPattern(),	// relationship pattern
								typePattern.getPattern(),	// object pattern
								selectStmts,	// object selects
								selectRelStmts,	// relationship selects
								false,	// to direction
								true,	// from direction
								(short) 1,	// recursion level
								sWhere,	// object where clause
								null,	// relationship where clause
								0); 
						//SPEC: Release SR18x.6.0 - #Defect41538,42449 Added  by gaikwad.tg on Date 16 April 2021 -- START
						if((mlConnectedMEPsSEPsAlternates!=null && !mlConnectedMEPsSEPsAlternates.isEmpty()) && showData)
							//SPEC: Release SR18x.6.0 - #Defect41538,42449 Added  by gaikwad.tg on Date 16 April 2021 -- END
						{
							itrConnectedMEPsSEPsAlternates = mlConnectedMEPsSEPsAlternates.iterator();

							while(itrConnectedMEPsSEPsAlternates.hasNext())
							{
								tempMap = new HashMap();
								mpConnectedPartDetails = (Map)itrConnectedMEPsSEPsAlternates.next();
								sConnectedPartId = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_ID);
								sConnectedPartPolicy = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_POLICY);
								String strName = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_NAME);
								String strType = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_TYPE);
								String strRev = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_REVISION);
								String strCurrent = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_CURRENT);
								objMEPSEPCertification = mpConnectedPartDetails.get("frommid["+ConstantsUtil.RELATIONSHIP_PGMEPSEPCERTIFICATION+"].id");
								//APP Opening Defect -- START
								//sREACHStatus = (String) mpConnectedPartDetails.get(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACH_STATUS));
								//sREACHRegNum = (String) mpConnectedPartDetails.get(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACHREGISTRATIONNUMBER));
								sREACHStatus = validator.getStringEquivalentForSubstituteString(mpConnectedPartDetails.get(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACH_STATUS)));
								sREACHRegNum = validator.getStringEquivalentForSubstituteString(mpConnectedPartDetails.get(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACHREGISTRATIONNUMBER)));
								//APP Opening Defect -- END
								
								if (UIUtil.isNotNullAndNotEmpty(sConnectedPartPolicy) && ((ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT.equals(sConnectedPartPolicy)) || 
										(ConstantsUtil.POLICY_SUPPLIEREQUIVALENT.equals(sConnectedPartPolicy))))
								{

									if(null != objMEPSEPCertification && objMEPSEPCertification instanceof String)  {
										sMEPSEPCertificationRelId = (String)objMEPSEPCertification;
										if(UIUtil.isNotNullAndNotEmpty(sMEPSEPCertificationRelId) ){
											tempMap.put(DomainConstants.SELECT_ID,sConnectedPartId);
											tempMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, sMEPSEPCertificationRelId);
											tempMap.put(DomainConstants.SELECT_POLICY, sConnectedPartPolicy);
											tempMap.put(DomainConstants.SELECT_LEVEL,"2");

											tempMap.put(ConstantsUtilIRM.CONST_REACHSTATUS,DomainConstants.EMPTY_STRING);
											tempMap.put(ConstantsUtilIRM.CONST_REACHREGNUM,DomainConstants.EMPTY_STRING);

											tempMap.put(DomainConstants.SELECT_TYPE,strType);
											tempMap.put(DomainConstants.SELECT_REVISION, strRev);
											tempMap.put(DomainConstants.SELECT_CURRENT, strCurrent);
											tempMap.put(DomainConstants.SELECT_NAME,strName);

											if(sConnectedPartPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT)){
												tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,ConstantsUtilIRM.CONST_MEP);
												mepList.add(tempMap);
											}else{
												tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,ConstantsUtilIRM.CONST_SEP);
												sepList.add(tempMap);
											}
										}

									} else  if(null != objMEPSEPCertification && objMEPSEPCertification instanceof StringList)  {
										slMEPSEPCertificationRelId = (StringList)objMEPSEPCertification;

										if(slMEPSEPCertificationRelId != null && !slMEPSEPCertificationRelId.isEmpty()){
											itrMEPSEPCertificationRelId = slMEPSEPCertificationRelId.iterator();
											while(itrMEPSEPCertificationRelId.hasNext()){
												tempMap = new HashMap();
												sMEPSEPCertificationRelId = (String)itrMEPSEPCertificationRelId.next();
												if(UIUtil.isNotNullAndNotEmpty(sMEPSEPCertificationRelId) ){
													tempMap.put(DomainConstants.SELECT_ID,sConnectedPartId);
													tempMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, sMEPSEPCertificationRelId);
													tempMap.put(DomainConstants.SELECT_POLICY, sConnectedPartPolicy);
													tempMap.put(DomainConstants.SELECT_LEVEL,"2");
													tempMap.put(ConstantsUtilIRM.CONST_REACHSTATUS,DomainConstants.EMPTY_STRING);
													tempMap.put(ConstantsUtilIRM.CONST_REACHREGNUM,DomainConstants.EMPTY_STRING);
													tempMap.put(DomainConstants.SELECT_TYPE,strType);
													tempMap.put(DomainConstants.SELECT_REVISION, strRev);
													tempMap.put(DomainConstants.SELECT_CURRENT, strCurrent);
													tempMap.put(DomainConstants.SELECT_NAME,strName);

													if(sConnectedPartPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTURER_EQUIVALENT)){
														tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,ConstantsUtilIRM.CONST_MEP);
														mepList.add(tempMap);
													}else{
														tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,ConstantsUtilIRM.CONST_SEP);
														sepList.add(tempMap);
													}
												}
											}
										}
									}
									if(UIUtil.isNotNullAndNotEmpty(sREACHStatus) || UIUtil.isNotNullAndNotEmpty(sREACHRegNum)){
										tempMap = new HashMap();
										tempMap.put(DomainConstants.SELECT_ID,sConnectedPartId);
										tempMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, DomainConstants.EMPTY_STRING);
										tempMap.put(DomainConstants.SELECT_POLICY, sConnectedPartPolicy);
										tempMap.put(DomainConstants.SELECT_LEVEL,"2");
										tempMap.put(ConstantsUtilIRM.CONST_REACHSTATUS,sREACHStatus);
										tempMap.put(ConstantsUtilIRM.CONST_REACHREGNUM,sREACHRegNum);
										tempMap.put(DomainConstants.SELECT_TYPE,strType);
										tempMap.put(DomainConstants.SELECT_REVISION, strRev);
										tempMap.put(DomainConstants.SELECT_CURRENT, strCurrent);
										tempMap.put(DomainConstants.SELECT_NAME,strName);
										if(sConnectedPartPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTURER_EQUIVALENT)){
											tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,ConstantsUtilIRM.CONST_MEP);
											mepList.add(tempMap);
										}else{
											tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,ConstantsUtilIRM.CONST_SEP);
											sepList.add(tempMap);
										}
									}
								}
								//else if connected as Alternate
								else
								{
									//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
									sAlternatePart = sConnectedPartId;
									if(UIUtil.isNotNullAndNotEmpty(sAlternatePart) && sAlternatePart.equalsIgnoreCase(sSelectedObject)){
											bExpandAlternate = true;
									}
									//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END
									tempMap.put(DomainConstants.SELECT_ID,sConnectedPartId);
									tempMap.put(DomainConstants.SELECT_POLICY, sConnectedPartPolicy);
									tempMap.put(DomainConstants.SELECT_LEVEL,"2");
									tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,DomainConstants.RELATIONSHIP_ALTERNATE);
									tempMap.put(ConstantsUtilIRM.CONST_REACHSTATUS,DomainConstants.EMPTY_STRING);
									tempMap.put(ConstantsUtilIRM.CONST_REACHREGNUM,DomainConstants.EMPTY_STRING);
									tempMap.put(DomainConstants.SELECT_TYPE,strType);
									tempMap.put(DomainConstants.SELECT_REVISION, strRev);
									tempMap.put(DomainConstants.SELECT_CURRENT, strCurrent);
									tempMap.put(DomainConstants.SELECT_NAME,strName);
									alternateList.add(tempMap);
									//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
									getConnectedSubstitudePartForCertification(context, sAlternatePart, alternateList);
									//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END
								}
							} 
						}

						if(null!=objSubstitute && objSubstitute instanceof String)  {
							sSubstitutePart = (String) objSubstitute;
							sSubstitutePolicy = (String) objSubstitutePolicy;
							sSubstituteType = (String) objSubstituteType;
							sSubstituteName = (String) objSubstituteName;
							sSubstituteRev = (String) objSubstituteRev;
							sSubstituteCurrent = (String) objSubstituteCurrent;

							if(UIUtil.isNotNullAndNotEmpty(sSubstitutePart) ){
								tempMap = new HashMap();
								tempMap.put(DomainConstants.SELECT_ID,sSubstitutePart);
								tempMap.put(DomainConstants.SELECT_POLICY, sSubstitutePolicy);
								tempMap.put(DomainConstants.SELECT_LEVEL,"2");
								tempMap.put(DomainConstants.SELECT_TYPE,sSubstituteType);
								tempMap.put(DomainConstants.SELECT_REVISION, sSubstituteRev);
								tempMap.put(DomainConstants.SELECT_CURRENT, sSubstituteCurrent);
								tempMap.put(DomainConstants.SELECT_NAME,sSubstituteName);
								tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,ConstantsUtilIRM.RELATIONSHIP_SUBSTITUTE);
								tempMap.put(ConstantsUtilIRM.CONST_REACHSTATUS,DomainConstants.EMPTY_STRING);
								tempMap.put(ConstantsUtilIRM.CONST_REACHREGNUM,DomainConstants.EMPTY_STRING);
								substituteList.add(tempMap);
								//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
								getConnectedSubstitudePartForCertification(context, sSubstitutePart, substituteList);
								if(sSubstitutePart.equalsIgnoreCase(sSelectedObject)){
										bExpandSubstitute = true;
								}
								//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END
							}

						} else  if(null!=objSubstitute && objSubstitute instanceof StringList)  {
							slSubstitutePart = (StringList) objSubstitute;
							slSubstitutePolicy = (StringList) objSubstitutePolicy;
							slSubstituteType = (StringList) objSubstituteType;
							slSubstituteName = (StringList) objSubstituteName;
							slSubstituteRev = (StringList) objSubstituteRev;
							slSubstituteCurrent = (StringList) objSubstituteCurrent;
							if(slSubstitutePart != null && !slSubstitutePart.isEmpty()){
								setUniqueSubs.clear();
								//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
								if(slSubstitutePart.contains(sSelectedObject)){
										bExpandSubstitute = true;
								}
								//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END
								for(int i=0; i<slSubstitutePart.size(); i++){
									tempMap = new HashMap();
									sSubstitutePart = (String) slSubstitutePart.get(i);
									sSubstitutePolicy = (String) slSubstitutePolicy.get(i);
									if(UIUtil.isNotNullAndNotEmpty(sSubstitutePart) && setUniqueSubs.add(sSubstitutePart)){
										tempMap.put(DomainConstants.SELECT_ID,sSubstitutePart);
										tempMap.put(DomainConstants.SELECT_POLICY, sSubstitutePolicy);
										tempMap.put(DomainConstants.SELECT_LEVEL,"2");
										tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,ConstantsUtilIRM.RELATIONSHIP_SUBSTITUTE);
										tempMap.put(ConstantsUtilIRM.CONST_REACHSTATUS,DomainConstants.EMPTY_STRING);
										tempMap.put(ConstantsUtilIRM.CONST_REACHREGNUM,DomainConstants.EMPTY_STRING);
										tempMap.put(DomainConstants.SELECT_TYPE,(String) slSubstituteType.get(i));
										tempMap.put(DomainConstants.SELECT_REVISION, (String) slSubstituteRev.get(i));
										tempMap.put(DomainConstants.SELECT_CURRENT, (String) slSubstituteCurrent.get(i));
										tempMap.put(DomainConstants.SELECT_NAME,(String) slSubstituteName.get(i));
										substituteList.add(tempMap);
										//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
										getConnectedSubstitudePartForCertification(context, sSubstitutePart, substituteList);
										//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END
									}
								}
							}
						}

						finalMapList.addAll(mepList);
						finalMapList.addAll(sepList);
						finalMapList.addAll(alternateList);
						finalMapList.addAll(substituteList);

						ebomList.clear();
						mepList.clear();
						sepList.clear();
						alternateList.clear();
						substituteList.clear();
						//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
						if(finalMapList.isEmpty()) {
							MapList mlExpandObj = new MapList();
							if (bExpandAlternate) {
								getConnectedSubstitudePartForCertification(context, strBOMId, alternateList);
								mlExpandObj = arrangeLevelOfPart(alternateList);
							} else if (bExpandSubstitute) {
								getConnectedSubstitudePartForCertification(context, strBOMId, substituteList);
								mlExpandObj = arrangeLevelOfPart(substituteList);
							}
							finalMapList.addAll(mlExpandObj);
							}
						}
						//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END
					}
				}
			}
			MapList mlTempList = new MapList();
			Map mpTemp = null ;
			for (int iSeq = 0; iSeq < finalMapList.size(); iSeq++) {
				mpTemp = (Map) finalMapList.get(iSeq);
				mpTemp.put("Sequence", Integer.toString(iSeq + 1));
				mlTempList.add(mpTemp);
			}
			finalMapList.clear();
			finalMapList.addAll(mlTempList);

		}

		catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return finalMapList;
	}
	/**
	 * Method Name 			: getMaterialCompositionAndSubstance
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getCertValidationMap(Context context, Map resultMaps, MapList  mlCertValidation ) throws Exception
	{

		Map<String, String> mpCertValidation = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String sRawMatId = (String) resultMaps.get(ConstantsUtil.SELECT_ID);
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID	 =  new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbRelType = new StringBuilder();
		StringBuilder sbCert = new StringBuilder();
		StringBuilder sbCertState = new StringBuilder();
		StringBuilder sbExpDate = new StringBuilder();
		StringBuilder sbRegNo = new StringBuilder();

		String strCert = DomainConstants.EMPTY_STRING;
		String strExpDate = DomainConstants.EMPTY_STRING;
		String sTempValue = DomainConstants.EMPTY_STRING;
		String strMaterialCertification = DomainConstants.EMPTY_STRING;
		StringBuffer sbReturnValue = new StringBuffer();
		Pattern relPattern = new Pattern(ConstantsUtil.REL_PG_PLI_MATERIAL_CERTIFICATIONS);
		Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PG_PLI_MATERIAL_CERTIFICATIONS);

		StringList selectStmts = new StringList(1);
		selectStmts.addElement(DomainConstants.SELECT_NAME);
		selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		selectStmts.addElement(ConstantsUtil.CERTIFICATION_NAME);
		StringList slMultiSelects = new StringList();
		slMultiSelects.add(ConstantsUtil.SELECT_NAME);
		slMultiSelects.add(ConstantsUtil.CERTIFICATION_NAME);
		
		Map mpTest = new HashMap<>();

		try
		{
			/*if(mlCertValidation!=null && mlCertValidation.size()>0)
				{*/
			if(UIUtil.isNotNullAndNotEmpty(sRawMatId))
			{
				DomainObject dobPart = DomainObject.newInstance(context, sRawMatId);
				mpTest = dobPart.getInfo(context, selectStmts,slMultiSelects);
				strExpDate = (String) mpTest.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
				strMaterialCertification=	validator.getStringEquivalentForStringList(mpTest.get(ConstantsUtil.CERTIFICATION_NAME));
				strMaterialCertification = strMaterialCertification.replace("|", ",");

			}
			strCert = UIUtil.isNotNullAndNotEmpty(strMaterialCertification)? strMaterialCertification : DomainConstants.EMPTY_STRING;
			util.formatData(sbType, (String) resultMaps.get(ConstantsUtil.SELECT_TYPE));
			util.formatData(sbName, (String) resultMaps.get(ConstantsUtil.SELECT_NAME));
			util.formatData(sbID, sRawMatId);
			util.formatData(sbRev, (String) resultMaps.get(ConstantsUtil.SELECT_REVISION));
			util.formatData(sbRelType, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbCurrent, (String) resultMaps.get(ConstantsUtil.SELECT_CURRENT));
			util.formatData(sbCert, strCert);
			util.formatData(sbCertState, ConstantsUtil.EMPTY_STRING);
			//SPEC: Release SR18x.6.0 - MODIFIED  by gaikwad.tg on Date 03 March 2021 -- START
			//SPEC: <18.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
			//Modified by Jwala for the defect 41004 (Context Expiration date attribute value not using here)-- START
			//util.formatData(sbExpDate, validator.DateFormatterParse((UIUtil.isNotNullAndNotEmpty(strExpDate) && UIUtil.isNotNullAndNotEmpty(strCert))? strExpDate : DomainConstants.EMPTY_STRING));
			util.formatData(sbExpDate, ConstantsUtil.EMPTY_STRING);
			//Modified by Jwala for the defect 41004 (Context Expiration date attribute value not using here)-- END
			//SPEC: <18.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
			//SPEC: Release SR18x.6.0 - MODIFIED  by gaikwad.tg on Date 03 March 2021 -- END
			util.formatData(sbRegNo, ConstantsUtil.EMPTY_STRING);
			//}
			Iterator objectListItr = mlCertValidation.iterator();
			DomainRelationship domainRel = null;
			String strCurrent = DomainConstants.EMPTY_STRING;
			String strChildID =DomainConstants.EMPTY_STRING;
			String strConnID =DomainConstants.EMPTY_STRING;
			boolean showData = false;
			String sUserType = util.getUserType();
			String strChildExpDate = DomainConstants.EMPTY_STRING;
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				strConnID = (String) objectMap.get(DomainRelationship.SELECT_ID);
				strChildID = (String) objectMap.get(ConstantsUtil.SELECT_ID);

				//SPEC: Release SR18x.6.0 - Commented  by Jwala for ALM Defect #41638 -- START
				/*if(UIUtil.isNotNullAndNotEmpty(strChildID))
					{
						DomainObject dobChild = DomainObject.newInstance(context, strChildID);
						strChildExpDate = dobChild.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
					}*/
				//SPEC: Release SR18x.6.0 - Commented  by Jwala for ALM Defect #41638 -- START

				strCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sReachStatus = (String)objectMap.get(ConstantsUtilIRM.CONST_REACHSTATUS);
				if(UIUtil.isNullOrEmpty(sReachStatus) && UIUtil.isNotNullAndNotEmpty(strConnID)){
					//SPEC: Release SR18x.6.0 - Added  by Jwala for Internal -- START
					//domainRel = DomainRelationship.newInstance(context ,strConnID);
					domainRel = new DomainRelationship(strConnID);
					sReachStatus = domainRel.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_CERTIFICATION_STATUS);
					//SPEC: Release SR18x.6.0 - Added  by Jwala for ALM Defect #41638 -- START
					strChildExpDate = domainRel.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_EXPIRATION_DATE);
					//SPEC: Release SR18x.6.0 - Added  by Jwala for ALM Defect #41638 -- END
					//SPEC: Release SR18x.6.0 - Added  by Jwala for Internal -- END
				}

				strCert = getCertificationNames(context, objectMap);

				showData = util.checkHasAccess(context, sUserType, strChildID);
				//SPEC: <04.06.2021>: Guna UnCommented for 39652 Req  Dev 18x.6.0.1   -- START
				//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
				if(!showData && util.isModificatinRequired()){
					continue;
				}
				//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END
				//SPEC: <04.06.2021>: Guna UnCommented for 39652 Req  Dev 18x.6.0.1   -- END
				if (!showData) 
					strChildID = ConstantsUtil.NO_ACCESS;
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 16 March 2021 -- START
				if (!strCurrent.equals(ConstantsUtil.RELEASE) && !strCurrent.equals(ConstantsUtil.RELEASED))
					continue;
				//strChildID = ConstantsUtil.NO_ACCESS;
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 16 March 2021 -- END
				util.formatData(sbType, (String) objectMap.get(ConstantsUtil.SELECT_TYPE));
				util.formatData(sbName, (String) objectMap.get(ConstantsUtil.SELECT_NAME));
				util.formatData(sbID, strChildID);
				util.formatData(sbRev, (String) objectMap.get(ConstantsUtil.SELECT_REVISION));
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- START (For Internal Defect)
				//util.formatData(sbCurrent, strCurrent);
				//SPEC: Release SR18x.6.0 - MODIFIED  by gaikwad.tg on Date 03 March 2021 -- START
				if(strChildID.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
				{
					util.formatData(sbCert, ConstantsUtil.NO_ACCESS);
					util.formatData(sbCertState, ConstantsUtil.NO_ACCESS);
					util.formatData(sbExpDate, ConstantsUtil.NO_ACCESS);
					util.formatData(sbRegNo, ConstantsUtil.NO_ACCESS);
					util.formatData(sbRelType, ConstantsUtil.NO_ACCESS);
					util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
				}
				else
				{
					util.formatData(sbCert, strCert);
					util.formatData(sbCertState, UIUtil.isNotNullAndNotEmpty(sReachStatus)? sReachStatus : DomainConstants.EMPTY_STRING);
					util.formatData(sbExpDate, validator.DateFormatterParse((UIUtil.isNotNullAndNotEmpty(strChildExpDate) && UIUtil.isNotNullAndNotEmpty(strCert) && (sReachStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) || sReachStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)))? strChildExpDate : DomainConstants.EMPTY_STRING));//Modified by Ketan for ALM Defect No. 50565 and 50582
					util.formatData(sbRegNo, UIUtil.isNotNullAndNotEmpty((String) objectMap.get(ConstantsUtilIRM.CONST_REACHREGNUM)) ? (String) objectMap.get(ConstantsUtilIRM.CONST_REACHREGNUM) : DomainConstants.EMPTY_STRING);
					util.formatData(sbRelType, (String) objectMap.get(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE));
					util.formatData(sbCurrent, strCurrent);
				}
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- END (For Internal Defect)
				//SPEC: Release SR18x.6.0 - MODIFIED  by gaikwad.tg on Date 03 March 2021 -- END
			}
			mpCertValidation.put(ConstantsUtilIRM.RELTYPE, sbRelType.toString().trim());
			mpCertValidation.put(ConstantsUtil.CERT,sbCert.toString().trim());
			mpCertValidation.put(ConstantsUtilIRM.CERTSTATUS,sbCertState.toString().trim());
			mpCertValidation.put(ConstantsUtilIRM.REGNO,sbRegNo.toString().trim());
			mpCertValidation.put(ConstantsUtilIRM.EXPDATE,sbExpDate.toString().trim());
			mpCertValidation.put(ConstantsUtil.ID,sbID.toString().trim());
			mpCertValidation.put(ConstantsUtil.TYPE,sbType.toString().trim());
			mpCertValidation.put(ConstantsUtil.NAME,sbName.toString().trim());
			mpCertValidation.put(ConstantsUtil.REV,sbRev.toString().trim());
			mpCertValidation.put(ConstantsUtilIRM.CERTSTATE,sbCurrent.toString().trim());
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.error("Exception in BusObjectAttribUtil : Program BusObjectAttribUtil " + ex);
		}

		return mpCertValidation;
	}
	public String getCertificationNames(Context context, Map testMp) throws Exception { 
		String strCertifications = DomainConstants.EMPTY_STRING;
		try
		{
			Map objectMap = null;
			String sObjectId = DomainConstants.EMPTY_STRING;
			String sObjectType = DomainConstants.EMPTY_STRING;
			String sObjectName = DomainConstants.EMPTY_STRING;
			String sObjectPolicy = DomainConstants.EMPTY_STRING;
			String sRelId = DomainConstants.EMPTY_STRING;

			Pattern relPattern = new Pattern(ConstantsUtil.REL_PG_PLI_MATERIAL_CERTIFICATIONS);
			Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PG_PLI_MATERIAL_CERTIFICATIONS);

			StringList selectStmts = new StringList(6);
			selectStmts.addElement(DomainConstants.SELECT_ID);
			selectStmts.addElement(DomainConstants.SELECT_NAME);
			selectStmts.addElement(DomainConstants.SELECT_TYPE);
			selectStmts.addElement(DomainConstants.SELECT_CURRENT);
			selectStmts.addElement(DomainConstants.SELECT_POLICY);
			selectStmts.add(new StringBuilder("from[").append(ConstantsUtil.REL_PG_PLI_MATERIAL_CERTIFICATIONS).append("].tomid["+ ConstantsUtil.RELATIONSHIP_PGMEPSEPCERTIFICATION +"].torel.to.name").toString());

			StringList selectRelStmts = new StringList(2);
			selectRelStmts.addElement(new StringBuilder("to[").append(ConstantsUtil.REL_PG_PLI_MATERIAL_CERTIFICATIONS).append("].name").toString());
			selectRelStmts.addElement(DomainRelationship.SELECT_ID);

			boolean isMEPSEP = false;
			String sTempValue = DomainConstants.EMPTY_STRING;
			StringBuffer sbReturnValue = null;
			//DomainObject  domObject = new DomainObject();
			DomainObject domObject = DomainObject.newInstance(context);
			sObjectId = (String) testMp.get(DomainConstants.SELECT_ID);
			//SPEC: Release SR18x.6.0 - Added  by Jwala for Internal Defect -- START
			sRelId = (String) testMp.get(ConstantsUtil.SELECT_CONNECTION_ID);
			//SPEC: Release SR18x.6.0 - Added  by Jwala for Internal Defect -- START
			sObjectPolicy = (String) testMp.get(DomainConstants.SELECT_POLICY);
			MapList mlCertifications = new MapList();
			if (UIUtil.isNotNullAndNotEmpty(sObjectId))
			{
				domObject.setId(sObjectId);
				if(UIUtil.isNotNullAndNotEmpty(sObjectPolicy) && sObjectPolicy.equalsIgnoreCase(DomainConstants.POLICY_EC_PART))
				{
					mlCertifications = domObject.getRelatedObjects(context,
							relPattern.getPattern(),
							typePattern.getPattern(),//pgDSOConstants_mxJPO.TYPE_RAWMATERIAL, // object pattern
							selectStmts, // object selects
							selectRelStmts, // relationship selects
							false, // to direction
							true, // from direction
							(short) 1, // recursion level
							null, // object where clause
							null,
							0); // relationship where clause
				}
				else if(ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT.equals(sObjectPolicy) || ConstantsUtil.POLICY_SUPPLIEREQUIVALENT.equals(sObjectPolicy)){
					if(UIUtil.isNotNullAndNotEmpty(sRelId)){
						mlCertifications = DomainRelationship.getInfo(context, new String[]{sRelId}, new StringList("torel.to.name"));
						isMEPSEP = true;
					}
					else {
						strCertifications =  ConstantsUtilIRM.CONST_REACH;
						return strCertifications;
					}
				}

				if(mlCertifications!=null && !mlCertifications.isEmpty()){
					sbReturnValue = new StringBuffer();
					if(isMEPSEP){
						sbReturnValue.append((String) ((Map) mlCertifications.get(0)).get("torel.to.name"));
					}
					else 
					{
						Map tmpMap = new HashMap();
						for(int i=0; i<mlCertifications.size(); i++){
							tmpMap = (Map) mlCertifications.get(i);
							sTempValue = (String) tmpMap.get(DomainConstants.SELECT_NAME);

							if(sbReturnValue.length()>0){
								sbReturnValue.append(ConstantsUtilIRM.CONSTANT_STRING_COMMA).append(ConstantsUtilIRM.BLANK_SPACE).append(sTempValue);
							} else {
								sbReturnValue.append(sTempValue);
							}

						}	
					}
					strCertifications = sbReturnValue.toString();
				}
				else{
					strCertifications = DomainConstants.EMPTY_STRING;
				}
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				domObject.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.error("Exception in BusObjectAttribUtil : Program BusObjectAttribUtil " + ex);
		}
		return strCertifications;
	}
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 24 Feb 2021 -- END
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
	/* 
	 * Type include list to display Material & Composition category for MEP/SEP
	 */
	public StringList getTypeIncludeForMatAndComp() {
		//SPEC: <21.04.2022>: Guna Modified for Req 41754 22x Release  -- START
		String TYPE_EXTERNAL_MATERIAL= PropertyUtil.getSchemaProperty("type_ExternalMaterial");
		StringList objectSelects = createSelects(//TYPE_EXTERNAL_MATERIAL,
				ConstantsUtil.TYPE_DEVICEPRODUCTPART,
				ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART,
				ConstantsUtil.TYPE_PGRAWMATERIAL,
				ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		//SPEC: <21.04.2022>: Guna Modified for Req 41754 22x Release  -- END
		return objectSelects;
	}
	/* 
	 * Type include list to display Substance & Material category for MEP/SEP
	 */
	public StringList getTypeIncludeForSubAndMat() {
		//SPEC: <21.04.2022>: Guna Modified for Req 41754 22x Release  -- START
		StringList objectSelects = createSelects(ConstantsUtil.TYPE_PACKAGINGMATERIALPART,
				ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART,
				ConstantsUtil.TYPE_PGONLINEPRINTINGPART,
				ConstantsUtil.TYPE_FABRICATEDPART,
		        ConstantsUtil.TYPE_PGPROMOTIONALITEMPART,
		         ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART);
		//SPEC: <21.04.2022>: Guna Modified for Req 41754 22x Release  -- END
		return objectSelects;
	}
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- END

	public  boolean checkAccessForIMorMCP(Context context, String sId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		boolean bReturnFlag = false;

		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		try 
		{
			if (UIUtil.isNotNullAndNotEmpty(sId)) 
			{
				Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL);

				//DomainObject doObj = new DomainObject(sId);
				DomainObject doObj = DomainObject.newInstance(context, sId);
				MapList mlComponentsAnMaterials = doObj.getRelatedObjects(context, relType.getPattern(),
						DomainConstants.QUERY_WILDCARD, slBusSelects, null, true, false, (short) 0,
						DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doObj.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				
				// FPP Packing Material Defect PRB0124811 --START
				
				for (Object obj : mlComponentsAnMaterials) {
					Map objMap = (Map) obj;
					String objId = (String) objMap.get(DomainConstants.SELECT_ID);
					if(checkHasAccess(context, null, objId)) {
						bReturnFlag = true;
						break;
					}
					
				}
				
				/*
				 * bReturnFlag = mlComponentsAnMaterials.parallelStream().anyMatch(obj -> { Map
				 * objMap = (Map) obj; String objId = (String)
				 * objMap.get(DomainConstants.SELECT_ID); return checkHasAccess(context, null,
				 * objId); });
				 */
				
				// FPP Packing Material Defect PRB0124811 --END
				
				/*
				Iterator objectListItr = mlComponentsAnMaterials.iterator();

				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String objId	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));

					bReturnFlag =checkHasAccess(context, null, objId);
					if (bReturnFlag) {
						return bReturnFlag;
					}
				}
				*/


			}else
			{
				return false;
			}

		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :checkAccessForIMorMCP ");
			return bReturnFlag;
		}
		return bReturnFlag;
	}
	//SPEC: Release SR18x.6.0 - Added  by Dominic on Date 16/03/2021 -- START
	public void formatDataWithNewLine(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_NEWLINE);
	}
	//SPEC: Release SR18x.6.0 - Added  by Dominic on Date 16/03/2021 -- END

	/**Added  for Requirement:33203 
	 * For granting access to software build	
	 * @param context
	 * @param sId
	 * @return
	 */

	public  boolean checkAccessForSoftwareBuild(Context context, String sId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		boolean bReturnFlag = false;

		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_ID);

		try 
		{
			if (UIUtil.isNotNullAndNotEmpty(sId)) 
			{
				Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_ASSIGNEDPART);

				//DomainObject doObj = new DomainObject(sId);
				DomainObject doObj = DomainObject.newInstance(context, sId);
				
				MapList mlSoftwareParts = doObj.getRelatedObjects(context, relType.getPattern(),
						ConstantsUtil.TYPE_SOFTWAREPART, slBusSelects, null, false, true, (short) 0,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doObj.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				Iterator objectListItr = mlSoftwareParts.iterator();

				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String objId	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					bReturnFlag =checkHasAccess(context, null, objId);
					if (bReturnFlag) {
						return bReturnFlag;
					}
				}

			}else
			{
				return false;
			}

		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :checkAccessForSoftwareBuild ");
			return bReturnFlag;
		}
		return bReturnFlag;
	}
	//SPEC: Release SR18x.6.0 - Added for Defect# 41584  by gaikwad.tg on Date 30 March 2021 -- START
	public void appendData(StringBuilder slData, String sData) {
		slData.append(sData);
	}
	//SPEC: Release SR18x.6.0 - Added for Defect# 41584  by gaikwad.tg on Date 30 March 2021 -- END

	//SPEC: Release SR18x.6.0 - Added  by Manikanta for defect 41917 on Date 31/03/2021 -- START
	public String GetPerformCharcteristicMPT(Context context, String sObjectId) {
		String sTitle = ConstantsUtil.EMPTY_STRING;
		StringList slMPTSelects = new StringList();
		try {
			if (UIUtil.isNotNullAndNotEmpty(sObjectId)) 
			{
				DomainObject dobject = DomainObject.newInstance(context, sObjectId);
				slMPTSelects.add(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE);
				slMPTSelects.add("from["+ConstantsUtil.PGMASTER+"].to."+ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				Map mpTemp = dobject.getInfo(context, slMPTSelects);
				sTitle = (String)mpTemp.get(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE);
				if(UIUtil.isNotNullAndNotEmpty(sTitle)) {
					return sTitle;
				}else {
					sTitle = (String)mpTemp.get("from["+ConstantsUtil.PGMASTER+"].to."+ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				}
				if(UIUtil.isNullOrEmpty(sTitle)) {
					return sTitle = ConstantsUtil.EMPTY_STRING;
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :GetPerformCharcteristicMPT ");
			return sTitle;
		}
		return sTitle;
	}
	//SPEC: Release SR18x.6.0 - Added  by Manikanta for defect 41917 on Date 31/03/2021 -- END
	//SPEC: Release SR18x.6.0 - Added  by Manikanta for defect 41203 on Date 8/04/2021 -- START
	public  boolean checkAccessForIRMIMorMCP(Context context, String sId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		boolean bReturnFlag = false;
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		try 
		{
			if (UIUtil.isNotNullAndNotEmpty(sId)) 
			{
				Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL);
				//DomainObject doObj = new DomainObject(sId);
				DomainObject doObj = DomainObject.newInstance(context, sId);
				MapList mlComponentsAnMaterials = doObj.getRelatedObjects(context, relType.getPattern(),
						DomainConstants.QUERY_WILDCARD, slBusSelects, null, true, false, (short) 0,
						DomainConstants.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doObj.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				Iterator objectListItr = mlComponentsAnMaterials.iterator();
				if(mlComponentsAnMaterials.size() > 0) {
					while(objectListItr.hasNext())
					{
						Map objectMap = (Map) objectListItr.next();
						String objId	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						bReturnFlag =checkHasAccess(context, null, objId);
						//SPEC: <07-28-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
						if (bReturnFlag) {
							return bReturnFlag;
						}
					}
				}else {
					return bReturnFlag = true;
				}
			}else
			{
				return false;
			}

		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :checkAccessForIRMIMorMCP ");
			return bReturnFlag;
		}
		return bReturnFlag;
	}
	//SPEC: Release SR18x.6.0 - Added  by Manikanta for defect 41203 on Date 8/04/2021 -- END

	//SPEC: 04-09-2020: Added for 18x.6 Defect# 42271 by Sanjeeva -- START

	public String getFPCCodeForPOA(Context context, String objId) {

		String strFPCCode = new String ();

		try {
			StringValidatorUtil validator = new StringValidatorUtil();
			//Map programMap = (HashMap) JPO.unpackArgs(args);
			//Map paramMap = (Map) programMap.get("paramMap");
			//String objectId = (String) paramMap.get("objectId");
			if(validator.isNotNullOrEmpty(objId)){
				DomainObject domCIC = DomainObject.newInstance(context,objId);
				//String webServiceUser = EnoviaResourceBundle.getProperty(context, STRING_RESOURCE_KEY_APP_USER);
				StringList selectsData = new StringList();
				selectsData.add("attribute[pgAAA_FinishedProductCode]");
				selectsData.add(DomainConstants.SELECT_ORIGINATOR);
				Map dataMap = domCIC.getInfo(context, selectsData);
				String sOriginator = (String)dataMap.get(DomainConstants.SELECT_ORIGINATOR);
				//if(sOriginator.equals(webServiceUser)){
				strFPCCode = (String)dataMap.get("attribute[pgAAA_FinishedProductCode]");

				// REMOVE THIS WHEN REQUIRED
				strFPCCode = "";
				//
				//}
				if(!validator.isNotNullOrEmpty(strFPCCode)){
					StringList returnList= new StringList(5);
					MapList objectIdMapList = new MapList();
					Map objectMap = new HashMap();
					objectMap.put("id", objId);
					objectIdMapList.add(objectMap);
					HashMap mlArgs= new HashMap();
					mlArgs.put("objectList", objectIdMapList);
					String[] argsArray = JPO.packArgs(mlArgs);
					returnList = getFPCode(context,argsArray);
					if(returnList.size() != 0){
						strFPCCode = (String)returnList.get(0);
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :getFPCCodeForPOA ");
			return strFPCCode;
		}

		return strFPCCode;
	}


	public StringList getIPMSTypeList(Context context) throws Exception {
		StringList slIPMSObjectTypes = new StringList();
		try {
			String strIPMSTYPE = "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_pgAAA_IPMS_Type") + "]";
			BusinessObject bObjConfigurationObject = new BusinessObject("pgConfigurationAdmin", "ArtworkConfigurationDetails", "-", "eService Production");
			DomainObject dobjConfigurationObject = new DomainObject(bObjConfigurationObject);
			String strIPMSAllowesType = dobjConfigurationObject.getInfo(context, strIPMSTYPE);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobjConfigurationObject.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			StringList slTypeList = FrameworkUtil.split(strIPMSAllowesType, ",");
			for (int i = 0; i < slTypeList.size(); i++) {
				String strIPMSAttributeType = (String)slTypeList.get(i);
				slIPMSObjectTypes.add(PropertyUtil.getSchemaProperty(strIPMSAttributeType));
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return slIPMSObjectTypes;
	}



	public Map getIPMSInfo(Context context, String strIPMS) throws Exception {
		Map mpIPMSInfo = new HashMap();
		try {
			StringValidatorUtil validator = new StringValidatorUtil();
			if (validator.isNotNullOrEmpty(strIPMS))
			{
				String strIPMSid = null;			
				StringList slIPMS = FrameworkUtil.split(strIPMS, ".");
				String strIPMSType = "";
				String strIPMSName = "";
				String strIPMSRev = "*";
				if(slIPMS.size() > 2) {
					if(slIPMS.size() > 3) {
						strIPMSRev = (String)slIPMS.get(2);
						strIPMSName = (String)slIPMS.get(1);
						strIPMSType = (String)slIPMS.get(0);
					} else if(slIPMS.size() == 3){
						strIPMSRev = (String)slIPMS.get(1);
						strIPMSName = (String)slIPMS.get(0);
						strIPMSType = "pgPackingMaterial";
					}
				} else {
					strIPMSName = (String)slIPMS.get(0);
					StringList slIPMSTypeList = getIPMSTypeList(context);
					strIPMSType= FrameworkUtil.join(slIPMSTypeList,",");
				}

				BusinessObject boIPMS = new BusinessObject(strIPMSType, strIPMSName, strIPMSRev, "eService Production");
				if(boIPMS.exists(context))
				{
					strIPMSid = boIPMS.getObjectId(context);
					if(validator.isNotNullOrEmpty(strIPMSid)){
						mpIPMSInfo.put(DomainConstants.SELECT_ID, strIPMSid);
						mpIPMSInfo.put(DomainConstants.SELECT_TYPE, strIPMSType);
						mpIPMSInfo.put(DomainConstants.SELECT_NAME, strIPMSName);
						mpIPMSInfo.put(DomainConstants.SELECT_REVISION, strIPMSRev);
					}
				}
			}
		} catch(Exception ex){

			throw ex;
		}
		return mpIPMSInfo;
	}

	public static <V> String getString(Map paramMap, String paramString) {
		V v = (paramMap != null) ? (V)paramMap.get(paramString) : null;
		return (v != null) ? v.toString().trim() : "";
	}

	public static StringList toStringList(MapList paramMapList, String paramString) {
		StringList stringList = new StringList();
		for (Iterator<Map> iterator = paramMapList.iterator(); iterator.hasNext();)
			stringList.add(getString(iterator.next(), paramString)); 
		return stringList;
	}


	public StringList getFPPList(Context context, Pattern postTypePattern,
			StringList slFPPList1, String strPreviousCOPId)
					throws FrameworkException {
		MapList mlFPP1;
		Map postMap;
		DomainObject domPrevCOPObject;
		StringList slList2;
		domPrevCOPObject = DomainObject.newInstance(context,strPreviousCOPId);
		slList2 = new StringList(3);
		slList2.addElement(DomainConstants.SELECT_ID);
		slList2.addElement(DomainConstants.SELECT_NAME);
		slList2.addElement(DomainConstants.SELECT_IS_LAST);
		postMap = new HashMap();
		postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");
		mlFPP1 = domPrevCOPObject.getRelatedObjects(context,
				DomainConstants.RELATIONSHIP_EBOM,
				"Product Data Part",
				true, //getTo
				false, //getFrom
				(short)0,	// recursionLevel
				slList2,	//objectSelects
				null, 	//relSelects
				null,// busWhereClause,
				null,// relWhereClause,
				null,// postRelPattern,
				postTypePattern.getPattern(),	//postTypePattern
				postMap); 
		if(!mlFPP1.isEmpty()){
			slFPPList1 = toStringList(mlFPP1, DomainConstants.SELECT_NAME);
		}
		return slFPPList1;
	}


	public String getPrimaryPMP(Context context, String strPMPId)throws FrameworkException  {
		String strPackaginhgMaterialPart = PropertyUtil.getSchemaProperty(context, "type_PackagingMaterialPart");
		String strPackingMaterial = PropertyUtil.getSchemaProperty(context, "type_PackagingMaterialPart");
		String strPriPMPId = strPMPId;
		StringValidatorUtil validator = new StringValidatorUtil();
		if(validator.isNotNullOrEmpty(strPMPId)){
			DomainObject doPMPObject	= DomainObject.newInstance(context,strPMPId);
			String strType = doPMPObject.getInfo(context,DomainConstants.SELECT_TYPE);

			if("pgOnlinePrintingPart".equals(strType) || strPackaginhgMaterialPart.equals(strType) || strPackingMaterial.equals(strType))
			{
				StringList slPriPMP = doPMPObject.getInfoList(context,"to["+DomainRelationship.RELATIONSHIP_ALTERNATE+"].from.id");

				if(null != slPriPMP && !slPriPMP.isEmpty()) {
					strPriPMPId = (String)slPriPMP.get(0);
				}
			}

		}
		return strPriPMPId;
	}


	public String hasMutipleFPC(Context context, String strIPMSID) {
		String strMutlipleFPC=null;
		StringList finalMap = new StringList();
		DomainObject doCOPObject =null;
		DomainObject doIPMSObject=null;
		MapList mlFPP = new MapList();
		MapList mlFPP1 = new MapList();
		StringList slFPPList = new StringList();
		StringList slBOMList = new StringList();
		String strQuery=null;
		StringList slList1=null;
		StringList slqueryresult =null;
		String strCOPId = DomainConstants.EMPTY_STRING;
		Pattern postTypePattern = new Pattern("Finished Product Part");
		Map postMap = null;
		StringList slCOPList = new StringList();
		StringList slFPPList1 = new StringList();
		String objectWhere ="previous.id!=''&&previous.current==Release";
		Pattern postTypePattern1 = new Pattern("pgConsumerUnitPart");
		postTypePattern1.addPattern("pgCustomerUnitPart");
		try{
			StringValidatorUtil validator = new StringValidatorUtil();
			if(validator.isNotNullOrEmpty(strIPMSID)){
				//pgRTA_Util_mxJPO objRTAUtil = new pgRTA_Util_mxJPO();
				strIPMSID = getPrimaryPMP(context,strIPMSID);
				doIPMSObject = DomainObject.newInstance(context,strIPMSID);   					
				StringList slList = new StringList(3);
				slList.addElement(DomainConstants.SELECT_ID);
				slList.addElement(DomainConstants.SELECT_NAME);
				slList.addElement(DomainConstants.SELECT_IS_LAST);
				postMap = new HashMap();
				postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");
				mlFPP = doIPMSObject.getRelatedObjects(context,
						DomainConstants.RELATIONSHIP_EBOM,
						"Product Data Part",
						true, //getTo
						false, //getFrom
						(short)0,	//recursionLevel
						slList,	//objectSelects
						null, 	//relSelects
						null,// busWhereClause,
						null,// relWhereClause,
						null,// postRelPattern,
						postTypePattern.getPattern(),	//postTypePattern
						postMap);
				if(!mlFPP.isEmpty()) {
					slBOMList = toStringList(mlFPP, DomainConstants.SELECT_NAME);
				}
				strQuery =  "relationship[EBOMSubstitute].fromrel.from.id";
				if(validator.isNotNullOrEmpty(strQuery)){
					slqueryresult = doIPMSObject.getInfoList(context,strQuery);
				}
				int StrSize = slqueryresult.size();
				if(slqueryresult.size() !=0 ){
					for (int i=0;i<StrSize;i++){
						strCOPId= (String)slqueryresult.get(i);
						doCOPObject = DomainObject.newInstance(context,strCOPId);   					
						slList1 = new StringList(3);
						slList1.addElement(DomainConstants.SELECT_ID);
						slList1.addElement(DomainConstants.SELECT_NAME);
						slList1.addElement(DomainConstants.SELECT_IS_LAST);
						postMap = new HashMap();
						postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");
						mlFPP1 = doCOPObject.getRelatedObjects(context,
								DomainConstants.RELATIONSHIP_EBOM,
								"Product Data Part",
								true, //getTo
								false, //getFrom
								(short)0,	// recursionLevel
								slList1,	//objectSelects
								null, 	//relSelects
								null,// busWhereClause,
								null,// relWhereClause,
								null,// postRelPattern,
								postTypePattern.getPattern(),	//postTypePattern
								postMap); 
						if(!mlFPP1.isEmpty()){
							slFPPList = toStringList(mlFPP1, DomainConstants.SELECT_NAME);
						}
						finalMap.addAll(slFPPList);
					}					
				}

				slCOPList.addElement("previous.id");

				MapList mlCOPIdList = doIPMSObject.getRelatedObjects(context,
						DomainConstants.RELATIONSHIP_EBOM,
						"Product Data Part",
						true, //getTo
						false, //getFrom
						(short)1,	//recursionLevel
						slCOPList,	//objectSelects
						null, 	//relSelects
						objectWhere,// busWhereClause,
						null,// relWhereClause,
						null,// postRelPattern,
						postTypePattern1.getPattern(),	//postTypePattern
						null); 

				if(!mlCOPIdList.isEmpty())
				{
					for(int i=0;i<mlCOPIdList.size();i++)
					{
						Map mpCOP = (Map)mlCOPIdList.get(i);
						String strPreviousCOPId = (String)mpCOP.get("previous.id");
						if(validator.isNotNullOrEmpty(strPreviousCOPId)){
							slFPPList1 = getFPPList(context, postTypePattern,
									slFPPList1, strPreviousCOPId);
							finalMap.addAll(slFPPList1);
						}
					}
				}
				finalMap.addAll(slBOMList);
				if ((finalMap != null || !finalMap.isEmpty()) && finalMap.size()>1){
					//if ((finalMap.size() !=0 ) && finalMap.size()>1){
					strMutlipleFPC="True";
				}
				else{
					strMutlipleFPC="False";
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return strMutlipleFPC;
	}

	public String validateOrchestrationFPC(Context context, String strIPMSID)throws Exception {

		String strFPPName = DomainConstants.EMPTY_STRING;
		try{
			i18nNow i18nObject = new i18nNow();

			String strLocale = context.getLocale().toString();

			//String webServiceUser = i18nObject.GetString(STRING_RESOURCE_EMX_CPN, strLocale, STRING_RESOURCE_KEY_APP_USER);

			StringValidatorUtil validator = new StringValidatorUtil();

			if(validator.isNotNullOrEmpty(strIPMSID)) {
				DomainObject dobPMP = DomainObject.newInstance(context,strIPMSID);  
				StringList objectSelects = new StringList(DomainConstants.SELECT_ID);
				objectSelects.add(DomainConstants.SELECT_NAME);
				StringList relSelects = new StringList();
				MapList mPOADetails = dobPMP.getRelatedObjects(context, //ematrix context
						"Part Specification", //String relationship
						"POA", //String type
						objectSelects, //Stringlist Object selects
						relSelects,//Stringlist Relationship selects
						false, //boolean getTo
						true, //boolean getFrom
						(short)1, //int Recurse to level
						DomainConstants.EMPTY_STRING, // String objectWhere
						DomainConstants.EMPTY_STRING,// String relationshipWhere
						0, //int limit
						null,// String postRelPattern
						null,// String postTypePattern
						null);// Map postPatterns

				if(mPOADetails != null || !mPOADetails.isEmpty()){
					String sPOAId = getString((Map) mPOADetails.get(0),DomainConstants.SELECT_ID);
					DomainObject dPOA = DomainObject.newInstance(context,sPOAId);
					StringList selectsData = new StringList();
					selectsData.add("attribute[pgAAA_FinishedProductCode]");
					selectsData.add(DomainConstants.SELECT_ORIGINATOR);
					Map dataMap = dPOA.getInfo(context, selectsData);
					String sFPCVal = (String)dataMap.get("attribute[pgAAA_FinishedProductCode]");
					String sOriginator = (String)dataMap.get(DomainConstants.SELECT_ORIGINATOR);

					//if(validator.isNotNullOrEmpty(sFPCVal) && sOriginator.equals(webServiceUser)) {
					if(validator.isNotNullOrEmpty(sFPCVal)) {
						sFPCVal = sFPCVal.replace("CS:", "");
						sFPCVal = sFPCVal.replace("IT:", "");
						sFPCVal = sFPCVal.replace("SW:", "");
						sFPCVal = sFPCVal.replace("NGTIN:", "");
						StringList sFPCList = com.matrixone.apps.domain.util.StringUtil.splitString(sFPCVal, "|");
						for(int i=0;i<sFPCList.size();i++) {
							strFPPName = sFPCList.get(i);
							if(validator.isNotNullOrEmpty(strFPPName)) {
								break;
							}
						}
					}

				}
			}} catch(Exception e){
				throw e;			
			}

		return strFPPName;
	}

	public String getFPPFromPMP(Context context, String strIPMSID) throws Exception {
		StringList finalList = new StringList();
		String strMutlipleFPC=null;
		DomainObject doCOPObject =null;
		DomainObject doIPMSObject=null;
		MapList mlFPP = null;
		MapList mlFPP1 = null;
		StringList slFPPList = new StringList();
		StringList slBOMList = new StringList();
		String strQuery=null;
		StringList slList1=null;
		StringList slqueryresult =null;
		String strCOPId = DomainConstants.EMPTY_STRING;
		StringValidatorUtil validator = new StringValidatorUtil();
		Pattern postTypePattern = new Pattern("Finished Product Part");
		Map postMap = null;
		String strFPPValue = "";
		StringList slCOPList = new StringList(1);
		String objectWhere ="previous.id!=''&&previous.current==Release";
		StringList slFPPList1 = new StringList();
		Pattern postTypePattern1 = new Pattern("pgConsumerUnitPart");
		postTypePattern1.addPattern("pgCustomerUnitPart");
		try {
			strFPPValue = validateOrchestrationFPC(context,strIPMSID);
			if(validator.isNotNullOrEmpty(strIPMSID) && !validator.isNotNullOrEmpty(strFPPValue)){
				strIPMSID = getPrimaryPMP(context,strIPMSID);
				doIPMSObject = DomainObject.newInstance(context,strIPMSID);   					
				StringList slList = new StringList(3);
				slList.addElement(DomainConstants.SELECT_ID);
				slList.addElement(DomainConstants.SELECT_NAME);
				slList.addElement(DomainConstants.SELECT_IS_LAST);
				postMap = new HashMap();
				postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");
				mlFPP = doIPMSObject.getRelatedObjects(context,
						DomainConstants.RELATIONSHIP_EBOM,
						"Product Data Part",
						true, //getTo
						false, //getFrom
						(short)0,	// recursionLevel
						slList,	//objectSelects
						null, 	//relSelects
						null,// busWhereClause,
						null,// relWhereClause,
						null,// postRelPattern,
						postTypePattern.getPattern(),	//postTypePattern
						postMap); 
				if(!mlFPP.isEmpty()) {
					slBOMList = toStringList(mlFPP, DomainConstants.SELECT_NAME);
				}
				strQuery =  "relationship[EBOMSubstitute].fromrel.from.id";
				if(validator.isNotNullOrEmpty(strQuery)){
					slqueryresult = doIPMSObject.getInfoList(context,strQuery);
				}
				int StrSize = slqueryresult.size();
				if(slqueryresult != null || !slqueryresult.isEmpty()){
					for (int i=0;i<StrSize;i++){
						strCOPId= (String)slqueryresult.get(i);
						doCOPObject = DomainObject.newInstance(context,strCOPId);   					
						slList1 = new StringList(3);
						slList1.addElement(DomainConstants.SELECT_ID);
						slList1.addElement(DomainConstants.SELECT_NAME);
						slList1.addElement(DomainConstants.SELECT_IS_LAST);
						postMap = new HashMap();
						postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");
						mlFPP1 = doCOPObject.getRelatedObjects(context,
								DomainConstants.RELATIONSHIP_EBOM,
								"Product Data Part",
								true, //getTo
								false, //getFrom
								(short)0,	// recursionLevel
								slList1,	//objectSelects
								null, 	//relSelects
								null,// busWhereClause,
								null,// relWhereClause,
								null,// postRelPattern,
								postTypePattern.getPattern(),	//postTypePattern
								postMap); 
						if(!mlFPP1.isEmpty()){
							slFPPList = toStringList(mlFPP1, DomainConstants.SELECT_NAME);
						}
						finalList.addAll(slFPPList);
					}					
				}
				slCOPList.addElement("previous.id");
				MapList mlCOPIdList = doIPMSObject.getRelatedObjects(context,
						DomainConstants.RELATIONSHIP_EBOM,
						"Product Data Part",
						true, //getTo
						false, //getFrom
						(short)1,	//recursionLevel
						slCOPList,	//objectSelects
						null, 	//relSelects
						objectWhere,// busWhereClause,
						null,// relWhereClause,
						null,// postRelPattern,
						postTypePattern1.getPattern(),	//postTypePattern
						null); 
				if(!mlCOPIdList.isEmpty())
				{
					for(int i=0;i<mlCOPIdList.size();i++)
					{
						Map mpCOP = (Map)mlCOPIdList.get(i);
						String strPreviousCOPId = (String)mpCOP.get("previous.id");
						if(validator.isNotNullOrEmpty(strPreviousCOPId)){
							slFPPList1 = getFPPList(context, finalList, postTypePattern,
									slFPPList1, strPreviousCOPId);
							finalList.addAll(slFPPList1);
						}
					}
				}
				finalList.addAll(slBOMList);
				if ((finalList != null || !finalList.isEmpty()) && finalList.size()>1){
					strMutlipleFPC="True";
				}
				else{
					strMutlipleFPC="False";
				}
			}
			if(validator.isNotNullOrEmpty(strMutlipleFPC) && finalList.size()==1 && "False".equalsIgnoreCase(strMutlipleFPC)){
				strFPPValue =(String)finalList.get(0);
			}
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return strFPPValue;

	}

	public StringList getFPPList(Context context, StringList finalList,
			Pattern postTypePattern, StringList slFPPList1,	String strPreviousCOPId) throws FrameworkException {
		String strForIds = PropertyUtil.getRPEValue(context, "FOR_IDS", false);
		MapList mlFPP1 = null;
		Map postMap = null;
		DomainObject domPrevCOPObject;
		StringList slList2 = new StringList(3);
		try{
			StringValidatorUtil validator = new StringValidatorUtil();
			if(validator.isNotNullOrEmpty(strPreviousCOPId)){
				domPrevCOPObject = DomainObject.newInstance(context,strPreviousCOPId);

				slList2.addElement(DomainConstants.SELECT_ID);
				slList2.addElement(DomainConstants.SELECT_NAME);
				slList2.addElement(DomainConstants.SELECT_IS_LAST);
				postMap = new HashMap();
				postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");

				mlFPP1 = domPrevCOPObject.getRelatedObjects(context,
						DomainConstants.RELATIONSHIP_EBOM,
						"Product Data Part",
						true, //getTo
						false, //getFrom
						(short)0,	// recursionLevel
						slList2,	//objectSelects
						null, 	//relSelects
						null,// busWhereClause,
						null,// relWhereClause,
						null,// postRelPattern,
						postTypePattern.getPattern(),	//postTypePattern
						postMap); 
				if(!mlFPP1.isEmpty()){
					slFPPList1 = toStringList(mlFPP1, DomainConstants.SELECT_NAME);
					if("true".equalsIgnoreCase(strForIds)){
						slFPPList1 = toStringList(mlFPP1, DomainConstants.SELECT_ID);
					}
				}
			}
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return slFPPList1;
	}

	public StringList getFPCode(Context context,String[] args) throws Exception {
		StringList slFPCode  = new StringList();
		try{
			StringValidatorUtil validator = new StringValidatorUtil();
			HashMap programMap  = (HashMap)JPO.unpackArgs(args);
			MapList mlPOAObjectList =(MapList)programMap.get("objectList");
			String strCustIPMS = null;
			String strPhaseName = (String) programMap.get("IPMSNAME");
			StringList objSelects = new StringList(3);
			objSelects.addElement(DomainObject.SELECT_ID);
			objSelects.addElement(DomainObject.SELECT_NAME);
			objSelects.addElement("attribute[pgHasMultipleGTINS]");

			int iPOAObjectSize = mlPOAObjectList.size();
			String strPOAId = null;
			String strFPCode = null;
			StringBuffer sbFPCode = null;
			String strhasMutipleFPC =null;
			String strIPMSId = null;
			String strIPMS = null;
			DomainObject domPOA = null;
			StringList slIPMSTypeList = getIPMSTypeList(context);
			//pgRTA_Util_mxJPO pgRTA_Util = new pgRTA_Util_mxJPO();

			String strRTFPCCode = null;
			String strPOAPackLevel = null;
			String strDSMAttr = null;
			String strCase = null;
			String strItem = null;
			String strShrinkwrap = null;
			String sPackLevelValue = null;
			String sNGTIN = DomainConstants.EMPTY_STRING;
			Map mpPOASelects = null;
			StringList slPackLevelList	=  null; 
			StringList slPOASelects = new StringList(3);
			slPOASelects.add("attribute[pgAAA_CustomIPMS]");
			slPOASelects.add("attribute[pgAAA_PackagingLevel]");
			slPOASelects.add("attribute[pgAAA_DSOType]");
			//pgAWL_Util_mxJPO pgAWLUtilTemp = null;
			String strFPPNumber = null;
			int iPKGSize;
			for(int i=0; i<iPOAObjectSize; i++) {
				strFPCode = DomainConstants.EMPTY_STRING;
				sbFPCode = new StringBuffer();
				strIPMSId = DomainConstants.EMPTY_STRING;
				strRTFPCCode = DomainConstants.EMPTY_STRING;
				strCase = DomainConstants.EMPTY_STRING;
				strItem = DomainConstants.EMPTY_STRING;
				strShrinkwrap = DomainConstants.EMPTY_STRING;
				sNGTIN = DomainConstants.EMPTY_STRING;
				slPackLevelList = new StringList();
				strPOAId = (String)((Map)mlPOAObjectList.get(i)).get(DomainObject.SELECT_ID);
				strCustIPMS = DomainConstants.EMPTY_STRING;
				if(validator.isNotNullOrEmpty(strPOAId))
				{
					domPOA = DomainObject.newInstance(context,strPOAId);
					mpPOASelects = domPOA.getInfo(context, slPOASelects);
					strCustIPMS = (String)mpPOASelects.get("attribute[pgAAA_CustomIPMS]");
					strPOAPackLevel = (String)mpPOASelects.get("attribute[pgAAA_PackagingLevel]");
					strDSMAttr = (String)mpPOASelects.get("attribute[pgAAA_DSOType]");
					if(validator.isNotNullOrEmpty(strPOAPackLevel)){
						slPackLevelList = FrameworkUtil.split(strPOAPackLevel, ",");	
					}

					if(validator.isNotNullOrEmpty(strCustIPMS) && validator.isNotNullOrEmpty(strDSMAttr) && strCustIPMS.equalsIgnoreCase("No") && "DSM".equalsIgnoreCase(strDSMAttr)){
						if(validator.isNotNullOrEmpty(strPhaseName))
						{
							Map mpIPMSDetails =  getIPMSInfo(context,strPhaseName);
							if(!mpIPMSDetails.isEmpty())
							{
								strIPMSId = (String)mpIPMSDetails.get(DomainConstants.SELECT_ID);
							}
						}
						else
						{
							strIPMS = (String)domPOA.getInfo(context, "attribute[pgAAA_IPMS]"); 
							if(validator.isNotNullOrEmpty(strIPMS)) 
							{
								Map mpIPMSDetails =  getIPMSInfo(context,strIPMS);
								if(!mpIPMSDetails.isEmpty())
								{
									strIPMSId = (String)mpIPMSDetails.get(DomainConstants.SELECT_ID);
								}
							}
						}
						// pgAWLUtilTemp = new pgAWL_Util_mxJPO();
						strhasMutipleFPC = hasMutipleFPC(context,strIPMSId);

						if(validator.isNotNullOrEmpty(strhasMutipleFPC) && "False".equalsIgnoreCase(strhasMutipleFPC))
						{
							if(validator.isNotNullOrEmpty(strIPMSId)){
								strRTFPCCode = getFPPFromPMP(context,strIPMSId);

							}
							strFPPNumber		= strRTFPCCode;
							if(validator.isNotNullOrEmpty(strRTFPCCode))
							{
								if(strRTFPCCode.indexOf('-')>=0) {
									strRTFPCCode = strFPPNumber.substring(strFPPNumber.indexOf('-')+1, strFPPNumber.length());
								}
								if(null != slPackLevelList && slPackLevelList.size()>0){
									iPKGSize = slPackLevelList.size();
									for(int j=0;j<iPKGSize;j++){
										sPackLevelValue = (String) slPackLevelList.get(j);
										if(sPackLevelValue.indexOf("CS")!=-1){
											strCase = strRTFPCCode;
										} else if(sPackLevelValue.indexOf("IT")!=-1){
											strItem = strRTFPCCode;
										} else if(sPackLevelValue.indexOf("SW")!=-1){
											strShrinkwrap = strRTFPCCode;
										}
										else if(sPackLevelValue.indexOf("NGTIN")!=-1){
											sNGTIN = strRTFPCCode;
										}
									}
									sbFPCode.append("CS:");
									sbFPCode.append(strCase);
									sbFPCode.append("|IT:");
									sbFPCode.append(strItem);
									sbFPCode.append("|SW:");
									sbFPCode.append(strShrinkwrap);
									sbFPCode.append("|NGTIN:");
									sbFPCode.append(sNGTIN);
									strFPCode = sbFPCode.toString();
								}else{
									sbFPCode.append("CS:");
									sbFPCode.append(strRTFPCCode);
									sbFPCode.append("|IT:");
									sbFPCode.append(strRTFPCCode);
									sbFPCode.append("|SW:");
									sbFPCode.append(strRTFPCCode);
									sbFPCode.append("|NGTIN:");
									strFPCode = sbFPCode.toString();
								}
							}

							else {
								strFPCode = DomainConstants.EMPTY_STRING;
							}	
						}
						else
						{

							strFPCode = domPOA.getAttributeValue(context,"pgAAA_FinishedProductCode");
						}
					}
					else
					{

						strFPCode = domPOA.getAttributeValue(context,"pgAAA_FinishedProductCode");
					}

					slFPCode.addElement(strFPCode);
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return slFPCode;
	}

	//SPEC: Release SR18x.6.0 - Defect#InternalDefect Added  by gaikwad.tg on Date 04 May 2021 -- START :: Added

	public StringList getTypeToDisplayStateAsReleased() {
		StringList objectSelects = createSelects(ConstantsUtil.TYPE_PGONLINEPRINTINGPART);
		return objectSelects;
	}
	//SPEC: Release SR18x.6.0 - Defect#InternalDefect Added  by gaikwad.tg on Date 04 May 2021 -- END :: Added


	//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- START
	/**
	 * Method Name : getTypeToBeDisplayedAsReleaseNotReleased
	 * Method Description : For those types which have RELEASE state only and not RELEASED state
	 * @param sType
	 * @param sCurrent
	 * @return
	 */
	public String getTypeToBeDisplayedAsReleaseNotReleased(String sType, String sCurrent) {
		if (null != sType) {
			switch (sType.trim()) {
			case "Formulation Part":
				sCurrent = (String)ConstantsUtil.RELEASE;
				break;

			default:
				sCurrent = sCurrent;
				break;
			}
		}
		return sCurrent;
	}
	//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- END
	//SPEC: <26.05.2021>: Guna Added for 43143 Defect  Dev 18x.6.0.1   -- START
	//SPEC: <27.05.2021>: Guna Modified for 43187 Defect  Dev 18x.6.0.1   -- START
	private String getIdWithState(Context context, String sSapTechState, String sSapTechId) {
		StringBuilder sbId = new StringBuilder();
		//SPEC: <27.05.2021>: Guna Modified for 43187 Defect  Dev 18x.6.0.1   -- END
		try {
			StringList slState = getStringList(sSapTechState);
			StringList slId = getStringList(sSapTechId);

			for (int i = 0; i < slState.size(); i++) {
				//SPEC: <27.05.2021>: Guna Modified for 43187 Defect  Dev 18x.6.0.1   -- START
				if (!slState.get(i).equals(ConstantsUtil.RELEASE) && !slState.get(i).equals(ConstantsUtil.RELEASED)) {
					formatData(sbId, ConstantsUtil.NO_ACCESS);
				}else{
					Boolean showData =checkHasAccess(context, null, slId.get(i));
					if (showData) {
						formatData(sbId, slId.get(i));
					}else{
						formatData(sbId, ConstantsUtil.NO_ACCESS);
					}
					//SPEC: <27.05.2021>: Guna Modified for 43187 Defect  Dev 18x.6.0.1   -- END
				}

			}

		} catch (Exception e) {
			return "";
		}
		return sbId.toString();
	}

	//SPEC: <26.05.2021>: Guna Added for 43143 Defect  Dev 18x.6.0.1   -- END

	//SPEC: <27.05.2021>: Guna Added for 43100 Defect  Dev 18x.6.0.1   -- START
	/*
	 *  checking security for PQR objects EBP users
	 * 
	 */
	public boolean checkAccessForPQRs(Context context, String objId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Boolean bHasOwnerShip =false;
		try{
			SecurityService sct = new SecurityService();
			StringList slUserOwnership = filterOwnerShip(sct.getUserCauthorities());
			//DomainObject domChild = new DomainObject(objId);
			DomainObject domChild = DomainObject.newInstance(context, objId);
			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER);
			//SPEC: <29.08.2022>: Guna Modified for 50451 Defect   Dev 22x    -- START
			Map mpParentOwnership = domChild.getInfo(context, slSelects,new StringList(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER));
			//SPEC: <29.08.2022>: Guna Modified for 50451 Defect   Dev 22x    -- END
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domChild.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER);

			StringList slParentOwnership = validator
					.isNotNullOrEmpty((StringList) mpParentOwnership.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER));
			if(slParentOwnership.size()==0){
				return false;
			}
			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			//String[] aCompany = sUserCompanies.split(",");
			String[] aCompany = splitCompanyValues(context,sUserCompanies);
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			StringBuilder sbCompany = new StringBuilder();

			if (aCompany.length > -1) {
				for (int i = 0; i < aCompany.length; i++) {
					if (null != aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					}
				}
			}
			bHasOwnerShip = checkOwnerShip(sbCompany, slParentOwnership);
		}catch (Exception e) {
			// TODO: handle exception
		}
		// TODO Auto-generated method stub
		return bHasOwnerShip;
	}
	//SPEC: <27.05.2021>: Guna Added for 43100 Defect  Dev 18x.6.0.1   -- END

	//SPEC: Jwala Added for 36257 Defect  Dev 18x.6.0.1   -- START
	/**
	 * Method Name : checkAccessForArtiosCad
	 * Method Description : Artios CAD Component will inherit the parent object Ownership
	 * @param sType
	 * @param sCurrent
	 * @return
	 */
	public  boolean checkAccessForArtiosCad(Context context, String sId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		boolean bReturnFlag = false;

		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_ID);

		try 
		{
			if (UIUtil.isNotNullAndNotEmpty(sId)) 
			{
				// Modified(added Part Spec reltype) by Jwala for Internal Defect -- START
				Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_PGINHERITEDCADSPECIFICATION);
				relType.addPattern(ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION);
				// Modified by Jwala for Internal Defect -- END

				//DomainObject doObj = new DomainObject(sId);
				DomainObject doObj = DomainObject.newInstance(context, sId);

				MapList mlArtiosCard = doObj.getRelatedObjects(context, relType.getPattern(),
						DomainConstants.QUERY_WILDCARD, slBusSelects, null, true, false, (short) 0,
						DomainConstants.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doObj.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				Iterator objectListItr = mlArtiosCard.iterator();

				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String objId	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));

					bReturnFlag =checkHasAccess(context, null, objId);
					if (bReturnFlag) {
						return bReturnFlag;
					}
				}
			}else{
				return false;
			}

		} catch (Exception e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :checkAccessForArtiosCard ");
			return bReturnFlag;
		}
		return bReturnFlag;
	}
	//SPEC: Jwala Added for 36257 Defect  Dev 18x.6.0.1   -- END

	//SPEC: Release SR18x.6.0.1 - Added by Manikanta on June 17, 2021 for Defect #43415 -- START
	public String getUserView(Context context, String ObjId) throws Exception
	{	
		SecurityService sct = new SecurityService();
		Collection<? extends GrantedAuthority> authorities = sct.getAuthorities();
		HashMap<String, String> roleMap = (HashMap) sct.getRoleAuthorities(authorities);
		try {
			for (Entry<String, String> entry : roleMap.entrySet())
			{
				String key = entry.getKey();
				String value = entry.getValue();
				if(ConstantsUtil.COMPANYAUTHORITY.equalsIgnoreCase(key)) {
					boolean bIsCM = false;
					boolean bIsSupplier = false;
					if (sct.isContractManufacturer(roleMap.get(ConstantsUtil.SECURITYAUTHORITY))) {
						bIsCM = true;
					}
					if(sct.isSupplierManufacturer(roleMap.get(ConstantsUtil.SECURITYAUTHORITY))){
						bIsSupplier = true;
					}
					// Added by Jwala for the defect 52952 -- START
					DomainObject dobj = DomainObject.newInstance(context, ObjId);
					String strParentType = dobj.getType(context);
					if(strParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
					String strUNVDocValue = getSOPUNVDocValue(context, ObjId);
					
					if(strUNVDocValue.equalsIgnoreCase(ConstantsUtil.ALL_CM_AND_ALL_SUPP) || strUNVDocValue.equalsIgnoreCase(ConstantsUtil.STR_ALL_CM)) {
						return ConstantsUtil.PG_CM;
					}else if (strUNVDocValue.equalsIgnoreCase(ConstantsUtil.STR_ALL_SUPPLIER)) {
						return ConstantsUtil.PG_SP;
						}
					}
					// Added by Jwala for the defect 52952 -- END
					//SPEC: Release SR18x.6.0.1 - Added by Manikanta on June 24, 2021 for Defect #43826 -- START
					//if(bIsCM && bIsSupplier && !slPlants.isEmpty() && slPlants!=null) {
					if(bIsCM && bIsSupplier) {
						StringList slPlants = getPlants(context, ObjId);
						//SPEC: Release SR18x.6.0.1 - Added by Manikanta on June 24, 2021 for Defect #43826 -- END
						String sUserCompanies = sct.getUserCauthorities();
						//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
						//String[] aCompany = sUserCompanies.split(",");
						String[] aCompany = splitCompanyValues(context,sUserCompanies);
						//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						StringBuilder sbCompany = new StringBuilder();

						if (aCompany.length > -1) {
							for (int i = 0; i < aCompany.length; i++) {
								if (null != aCompany[i]) {
									String Company = aCompany[i].toString();
									sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
								}
							}
						}
						boolean bHasCMView = checkOwnerShip(sbCompany, slPlants);
						if(bHasCMView) {
							return ConstantsUtil.PG_CM;
						}else {
							return ConstantsUtil.PG_SP;

						}
					} else {
						if (sct.isContractManufacturer(roleMap.get(ConstantsUtil.SECURITYAUTHORITY))) {
							return ConstantsUtil.PG_CM;
						}else if(sct.isSupplierManufacturer(roleMap.get(ConstantsUtil.SECURITYAUTHORITY))){
							return ConstantsUtil.PG_SP;
						} else{
							return null;
						}
					}
				}
			}
		} catch (FrameworkException e) {
			LOGGER.error("Exception in program BusObjectAttribteUtil :getUserView" + e);
			return null;
		}
		return null;
	}		

	public  StringList getPlants(Context context, String ObjId) throws Exception {
		MapList mlPlants = new MapList();
		StringList slBusSelects = new StringList();
		slBusSelects.add(DomainConstants.SELECT_NAME);
		StringList slRelSelects = new StringList();
		StringList slPlants = new StringList();
		boolean getTo = true;
		boolean getFrom = true;
		// Added by Jwala for the defect 52952 -- START
		boolean issopunv = false;
		// Added by Jwala for the defect 52952 -- END
		try {
			if(UIUtil.isNotNullAndNotEmpty(ObjId)){
				//DomainObject dob = new DomainObject(ObjId);
				DomainObject dob = DomainObject.newInstance(context, ObjId);

				// Modified for the SR_MAYCW Defect 52838 -- START
				//Added By Jwala for MPP Objects pgExternalBusinessPartners rel has to taken into account -- START
				// Added by Jwala for the defect 52952 -- START
				// The SOP is UNV document we will not include  pgExternalBusinessPartners relationship as per 52952
				String strParentType = dob.getType(context);
				if(strParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
				issopunv = isSOPUNVDoc(context, ObjId);
				}
				Pattern relPattern = new Pattern(ConstantsUtilIRM.RELATIONSHIP_MANUFACTURING_RESPONSIBILITY);

				if(!issopunv)
				relPattern.addPattern(ConstantsUtil.RELATIONSHIP_PGEXTERNALBUSINESSPARTNERS);
				// Added by Jwala for the defect 52952 -- END

				mlPlants = dob.getRelatedObjects(context, 
						relPattern.getPattern(),     //relationship pattern
						ConstantsUtil.TYPE_PLANT,    // object pattern
						slBusSelects,                // object selects
						slRelSelects,                // relationship selects
						getTo,                       // to direction
						getFrom,                     // from direction
						(short) 1,                   // recursion level
						ConstantsUtil.EMPTY_STRING,  // object where clause
						ConstantsUtil.EMPTY_STRING,  // relationshipWhere Clause
						ConstantsUtil.ZERO_LEVEL);
				//Added By Jwala for MPP Objects pgExternalBusinessPartners rel has to taken into account -- END
				// Modified for the SR_MAYCW Defect 52838 -- END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				dob.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				Iterator objectListItr = mlPlants.iterator();
				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String strPlantName = (String) objectMap.get(DomainConstants.SELECT_NAME);
					slPlants.add(strPlantName);
				}
			}
		} catch (FrameworkException e) {
			LOGGER.error("Error in  program BusObjectAttribteUtil :getPlants" + e);
			return new StringList();
		}
		return slPlants;
	}
	//SPEC: Release SR18x.6.0.1 - Added by Manikanta on June 17, 2021 for Defect #43415 -- END

	//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START

	public String[] splitCompanyValues(Context context, String sUserCompanies) throws Exception
	{
		String [] strReturnCompVal = new String [100];
		try 
		{
			if (UIUtil.isNotNullAndNotEmpty(sUserCompanies))
			{
				strReturnCompVal = sUserCompanies.split(",");
			} else
			{
				LOGGER.error("Error in program BusObjectAttribteUtil :splitCompanyValues. sUserCompanies is null:" + sUserCompanies);
			}

		} catch (Exception e) 
		{
			LOGGER.error("Error in  program BusObjectAttribteUtil :splitCompanyValues" + e);
			return new String[0];
		}

		return strReturnCompVal;

	}
	//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
	


	public Map fetchGTINDataField(Context context, String poaId,Environment env) {
	    String strReturn = ConstantsUtil.EMPTY_STRING;
	    Vector<String> FPCList = null;
	    Map mpResult = new HashMap();
	    try {
	      String sPOAPackLevel = null;
	      String sPOAFPC = null;
	      String sPOAFPCDesc = null;
	      String sPOAGTIN = null;
	      String sCustomIPMS = null;
	      String sDSMType = null;
	      String strFPPData = null;
	      Map mPOAInfo = null;
	      StringBuffer sbPOAFPC = null;
	      StringBuffer sbPOAGTIN = null;
	      StringBuffer sbPOAFPCDesc = null;
	      StringList slSelects = new StringList(6);
	      slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKINGLEVEL);
	      slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE);
	      slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCDESCRIPTION);
	      slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGTIN);
	      slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CUSTOMIPMS);
	      slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSOTYPE);
	      String strFPCDescription = ConstantsUtil.EMPTY_STRING;
	      if (null != poaId && !ConstantsUtil.EMPTY_STRING.equals(poaId)) {
	        FPCList = new Vector(1);
	        StringBuffer builder = new StringBuffer(1);
	        StringBuilder sbFPCName = new StringBuilder();
	        StringBuilder sbFPCDescr = new StringBuilder();
	        StringBuilder sbFPCGTIN = new StringBuilder();
	        StringBuilder sbFPCPackLevel = new StringBuilder();
	        
	          DomainObject dobj = DomainObject.newInstance(context, poaId);
	          if (null != dobj) {
	            mPOAInfo = dobj.getInfo(context, slSelects);
	            sDSMType = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSOTYPE);
	            sCustomIPMS = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CUSTOMIPMS);
	            if (UIUtil.isNotNullAndNotEmpty(sCustomIPMS) && UIUtil.isNotNullAndNotEmpty(sDSMType) && sCustomIPMS.equalsIgnoreCase(ConstantsUtil.SYMBL_NO) && ConstantsUtilIRM.DSM.equalsIgnoreCase(sDSMType)) {
	              String strIPMSId = null;
	              String strIPMS = dobj.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_ATTRIBUTE_IPMS);
	              if (UIUtil.isNotNullAndNotEmpty(strIPMS)) {
	                Map mpIPMSDetails = getIPMSInfo(context, strIPMS);
	                if (!mpIPMSDetails.isEmpty())
	                  strIPMSId = (String)mpIPMSDetails.get(ConstantsUtil.ID); 
	              } 
	              if (UIUtil.isNotNullAndNotEmpty(strIPMSId))
	                strFPPData = getFPPFromPMP(context, strIPMSId); 
	              if (UIUtil.isNotNullAndNotEmpty(strFPPData)) {
	                String strFPPNumber = strFPPData;
	                if (strFPPData.indexOf(ConstantsUtil.SYMBL_DASH) >= 0)
	                  strFPPNumber = strFPPData.substring(strFPPData.indexOf(ConstantsUtil.SYMBL_DASH) + 1, strFPPData.length()); 
	                strFPPData = strFPPNumber;
	                Map<String, String> mpGTINandFPCDesc = null;
	                try {
	                	mpGTINandFPCDesc = getFPCDescription(context, strFPPNumber,env);
	                } catch (Exception e) {
	                  String strGTINFetchedITDefault = ConstantsUtil.EMPTY_STRING;
	                  String strGTINFetchedSWDefault = ConstantsUtil.EMPTY_STRING;
	                  String strGTINFetchedCSDefault = ConstantsUtil.EMPTY_STRING;
	                  String strDescriptionDefault = ConstantsUtil.EMPTY_STRING;
	                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
	                  String strGTINFetchedNGTINDefault = DomainConstants.EMPTY_STRING;
	                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
	                  mpGTINandFPCDesc.put(ConstantsUtilIRM.FPP_GTIN_IT, strGTINFetchedITDefault);
	                  mpGTINandFPCDesc.put(ConstantsUtilIRM.FPP_GTIN_SW, strGTINFetchedSWDefault);
	                  mpGTINandFPCDesc.put(ConstantsUtilIRM.FPP_GTIN_CS, strGTINFetchedCSDefault);
	                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
	                  mpGTINandFPCDesc.put(ConstantsUtilIRM.FPP_GTIN_NGTIN, strGTINFetchedNGTINDefault);
	                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
	                  mpGTINandFPCDesc.put(ConstantsUtilIRM.FPP_DESC, strDescriptionDefault);                
	                  LOGGER.error("In fetchGTINDataField Method. Unable to get FPC Description. Exception message : " + e.getMessage());
	                } 
	                String strGTINDataIT = ConstantsUtil.EMPTY_STRING;
	                String strGTINDataSW = ConstantsUtil.EMPTY_STRING;
	                String strGTINDataCS = ConstantsUtil.EMPTY_STRING;
	              //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
	                String strGTINDataNGTIN = ConstantsUtil.EMPTY_STRING;
	              //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
	                String strTempDESC = ConstantsUtil.EMPTY_STRING;
	                sbPOAFPC = new StringBuffer();
	                sbPOAGTIN = new StringBuffer();
	                sbPOAFPCDesc = new StringBuffer();
	                if (null != mpGTINandFPCDesc && mpGTINandFPCDesc.size() > 0) {
	                  strTempDESC = mpGTINandFPCDesc.get(ConstantsUtilIRM.FPP_DESC);
	                  if (UIUtil.isNotNullAndNotEmpty(mpGTINandFPCDesc.get(ConstantsUtilIRM.FPP_GTIN_CS)))
	                    strGTINDataCS = mpGTINandFPCDesc.get(ConstantsUtilIRM.FPP_GTIN_CS); 
	                  if (UIUtil.isNotNullAndNotEmpty(mpGTINandFPCDesc.get(ConstantsUtilIRM.FPP_GTIN_IT)))
	                    strGTINDataIT = mpGTINandFPCDesc.get(ConstantsUtilIRM.FPP_GTIN_IT); 
	                  if (UIUtil.isNotNullAndNotEmpty(mpGTINandFPCDesc.get(ConstantsUtilIRM.FPP_GTIN_SW)))
	                    strGTINDataSW = mpGTINandFPCDesc.get(ConstantsUtilIRM.FPP_GTIN_SW); 
	                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
	                  if (UIUtil.isNotNullAndNotEmpty(mpGTINandFPCDesc.get(ConstantsUtilIRM.FPP_GTIN_NGTIN)))
	                	  strGTINDataNGTIN = mpGTINandFPCDesc.get(ConstantsUtilIRM.FPP_GTIN_NGTIN); 
	                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
	                  sPOAPackLevel = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKINGLEVEL);
	                //SPEC: 26-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50273-- START
	                  if(UIUtil.isNullOrEmpty(strTempDESC)&&UIUtil.isNullOrEmpty(strGTINDataCS)&&UIUtil.isNullOrEmpty(strGTINDataIT)&&UIUtil.isNullOrEmpty(strGTINDataSW)&&UIUtil.isNullOrEmpty(strGTINDataNGTIN)) {
		                 sPOAFPC = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE);
		                 sPOAFPCDesc = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCDESCRIPTION);
		                 sPOAGTIN = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGTIN);
	                  }
	                  else {
	                //SPEC: 26-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50273-- END  
		                  sbPOAFPC.append(ConstantsUtil.BASEUNITOFMEASURE_CS);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPC.append(strFPPData);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPC.append(ConstantsUtil.BASEUNITOFMEASURE_IT);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPC.append(strFPPData);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPC.append(ConstantsUtil.BASEUNITOFMEASURE_SW);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPC.append(strFPPData);
		                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPC.append(ConstantsUtilIRM.BASEUNITOFMEASURE_NGTIN);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPC.append(strFPPData);
		                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
		                  sPOAFPC = sbPOAFPC.toString();
		                  sbPOAGTIN.append(ConstantsUtil.BASEUNITOFMEASURE_CS);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAGTIN.append(strGTINDataCS);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAGTIN.append(ConstantsUtil.BASEUNITOFMEASURE_IT);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAGTIN.append(strGTINDataIT);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAGTIN.append(ConstantsUtil.BASEUNITOFMEASURE_SW);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAGTIN.append(strGTINDataSW);
		                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAGTIN.append(ConstantsUtilIRM.BASEUNITOFMEASURE_NGTIN);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAGTIN.append(strGTINDataNGTIN);
		                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
		                  sPOAGTIN = sbPOAGTIN.toString();
		                  sbPOAFPCDesc.append(ConstantsUtil.BASEUNITOFMEASURE_CS);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPCDesc.append(strTempDESC);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPCDesc.append(ConstantsUtil.BASEUNITOFMEASURE_IT);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPCDesc.append(strTempDESC);
		                  
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPCDesc.append(ConstantsUtil.BASEUNITOFMEASURE_SW);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPCDesc.append(strTempDESC);
		                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPCDesc.append(ConstantsUtilIRM.BASEUNITOFMEASURE_NGTIN);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPCDesc.append(strTempDESC);
		                //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
		                  sPOAFPCDesc = sbPOAFPCDesc.toString();
		              //SPEC: 26-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50273-- START
	                  }
	                //SPEC: 26-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50273-- END
	                } 
	              //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
	                else {
	                      sPOAPackLevel = (String) mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKINGLEVEL);
	                	  sbPOAFPC.append(ConstantsUtil.BASEUNITOFMEASURE_CS);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPC.append(strFPPData);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPC.append(ConstantsUtil.BASEUNITOFMEASURE_IT);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPC.append(strFPPData);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPC.append(ConstantsUtil.BASEUNITOFMEASURE_SW);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPC.append(strFPPData);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPC.append(ConstantsUtilIRM.BASEUNITOFMEASURE_NGTIN);
		                  sbPOAFPC.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPC.append(strFPPData);
		                  sPOAFPC = sbPOAFPC.toString();
		                  
		                  sbPOAGTIN.append(ConstantsUtil.BASEUNITOFMEASURE_CS);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAGTIN.append(ConstantsUtil.BASEUNITOFMEASURE_IT);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAGTIN.append(ConstantsUtil.BASEUNITOFMEASURE_SW);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAGTIN.append(ConstantsUtilIRM.BASEUNITOFMEASURE_NGTIN);
		                  sbPOAGTIN.append(ConstantsUtil.SYMBL_COLON);
		                  sPOAGTIN = sbPOAGTIN.toString();
						  
		                  sbPOAFPCDesc.append(ConstantsUtil.BASEUNITOFMEASURE_CS);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPCDesc.append(ConstantsUtil.BASEUNITOFMEASURE_IT);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPCDesc.append(ConstantsUtil.BASEUNITOFMEASURE_SW);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_COLON);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_PIPE);
		                  sbPOAFPCDesc.append(ConstantsUtilIRM.BASEUNITOFMEASURE_NGTIN);
		                  sbPOAFPCDesc.append(ConstantsUtil.SYMBL_COLON);
		                  sPOAFPCDesc = sbPOAFPCDesc.toString();
	                }
	              //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
	              } else {
		            	String strTempFPCPackLevel = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKINGLEVEL);
		                sPOAPackLevel =  strTempFPCPackLevel.replace(ConstantsUtil.SYMBL_PIPE,ConstantsUtil.SYMBL_COMMA);
		                String strTempFPC = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE);
		                sPOAFPC = strTempFPC.replace(ConstantsUtil.SYMBL_PIPE,ConstantsUtil.SYMBL_COMMA);
		                String strTempFPCDesc = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCDESCRIPTION);
		                sPOAFPCDesc = strTempFPCDesc.replace(ConstantsUtil.SYMBL_PIPE,ConstantsUtil.SYMBL_COMMA);
		                String strTempGTIN = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGTIN);
		                sPOAGTIN = strTempGTIN.replace(ConstantsUtil.SYMBL_PIPE,ConstantsUtil.SYMBL_COMMA);
	              } 
	            } else {
	            	  //SPEC: 30-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50223-- START
		            	sPOAPackLevel = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKINGLEVEL);
		            	sPOAFPC = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE);
		            	sPOAFPCDesc = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCDESCRIPTION);		                
		            	sPOAGTIN = (String)mPOAInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGTIN);
		              //SPEC: 30-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50223-- END
	            } 
	            StringList slPackLevelList = new StringList(1);
	            StringList slPOAFPCList = new StringList(1);
	            StringList sPOAFPCDescList = new StringList(1);
	            StringList sPOAGTINList = new StringList(1);
	            slPackLevelList = FrameworkUtil.split(sPOAPackLevel, ConstantsUtil.SYMBL_COMMA);
	            if (null != slPackLevelList && slPackLevelList.size() > 0) {
	              try {
	                StringList slPipes = FrameworkUtil.split(sPOAFPC, ConstantsUtil.SYMBL_PIPE);
	              //SPEC: 23-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50225-- START
	                if (null != sPOAFPC && sPOAFPC.indexOf(ConstantsUtilIRM.ITCOLON) >= 0 && sPOAFPC.indexOf(ConstantsUtilIRM.SWCOLON) >= 0 && sPOAFPC
	  	                  .indexOf(ConstantsUtilIRM.CSCOLON) >= 0 && ( slPipes.size() == 3 || (sPOAFPC
	  	    	                  .indexOf(ConstantsUtilIRM.NGTINCOLON) >= 0 && slPipes.size() == 4))) {
	               //SPEC: 23-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50225-- END
	                  slPOAFPCList = FrameworkUtil.split(sPOAFPC, ConstantsUtil.SYMBL_PIPE);
	                  sPOAFPCDescList = FrameworkUtil.split(sPOAFPCDesc, ConstantsUtil.SYMBL_PIPE);
	                  sPOAGTINList = FrameworkUtil.split(sPOAGTIN, ConstantsUtil.SYMBL_PIPE);
	                  int iPKGSize = slPackLevelList.size();
	                  for (int j = 0; j < iPKGSize; j++) {
	                    String sFPCCodeSplit = ConstantsUtil.EMPTY_STRING;
	                    String sFPCDecSplit = ConstantsUtil.EMPTY_STRING;
	                    String sGTINSplit = ConstantsUtil.EMPTY_STRING;
	                    String sPackLevelValue = (String)slPackLevelList.get(j);
	                    String sKey = ConstantsUtil.EMPTY_STRING;
	                    if (sPackLevelValue.indexOf(ConstantsUtil.BASEUNITOFMEASURE_CS) != -1) {
	                      sKey = ConstantsUtilIRM.CSCOLON;
	                    } else if (sPackLevelValue.indexOf(ConstantsUtil.BASEUNITOFMEASURE_IT) != -1) {
	                      sKey = ConstantsUtilIRM.ITCOLON;
	                    } else if (sPackLevelValue.indexOf(ConstantsUtil.BASEUNITOFMEASURE_SW) != -1) {
	                      sKey = ConstantsUtilIRM.SWCOLON;
	                    }
	                  //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
	                    else if (sPackLevelValue.indexOf(ConstantsUtilIRM.BASEUNITOFMEASURE_NGTIN) != -1) {
		                      sKey = ConstantsUtilIRM.NGTINCOLON;
		                 } 
	                  //SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
	                    if (!ConstantsUtil.EMPTY_STRING.equals(sKey)) {      	
	                      HashMap hmFPCMap = getConsolidatedGTINMap(slPOAFPCList, sKey);
	                      HashMap hmFPCDescMap = getConsolidatedGTINMap(sPOAFPCDescList, sKey);
	                      HashMap hmGTINMap = getConsolidatedGTINMap(sPOAGTINList, sKey);
	                      if (null != hmFPCMap && hmFPCMap.size() > 0)
	                        sFPCCodeSplit = (String)hmFPCMap.get(sKey); 
	                      if (null != hmFPCDescMap && hmFPCDescMap.size() > 0)
	                        sFPCDecSplit = (String)hmFPCDescMap.get(sKey); 
	                      if (null != hmGTINMap && hmGTINMap.size() > 0)
	                        sGTINSplit = (String)hmGTINMap.get(sKey); 
	                      StringList FPCFinal = FrameworkUtil.split(sFPCCodeSplit, ConstantsUtil.SYMBL_COMMA);
	                      StringTokenizer stDesc = new StringTokenizer(sFPCDecSplit, ConstantsUtilIRM.DELIMITER);
	                      StringList FPCDescFinal = new StringList(1);
	                      while (stDesc.hasMoreTokens())
	                        FPCDescFinal.add(stDesc.nextToken()); 
	                      StringList GTINFinal = FrameworkUtil.split(sGTINSplit, ConstantsUtil.SYMBL_COMMA);
	                      int iFinalSize = FPCFinal.size();
	                      int iGTINFinalSize = GTINFinal.size();
	                      int iGtinLoop = iFinalSize - iGTINFinalSize;
	                      if (iGtinLoop > 0)
	                        for (int iLoop = 0; iLoop < iGtinLoop; iLoop++)
	                          GTINFinal.add(ConstantsUtilIRM.HYPHENS);  
	                      if (null != FPCFinal && iFinalSize > 0)
	                        for (int k = 0; k < iFinalSize; k++) {
	                          String sFPCCode = (String)FPCFinal.get(k);
	                          String sFPCDec = ConstantsUtilIRM.HYPHENS;
	                          String sGTIN = ConstantsUtilIRM.HYPHENS;
	                          if (null != GTINFinal && GTINFinal.size() > 0)
	                            sGTIN = (String)GTINFinal.get(k); 
	                          if (null != FPCDescFinal && FPCDescFinal.size() > 0)
	                            sFPCDec = (String)FPCDescFinal.get(k); 
	                          if (null == sFPCCode || ConstantsUtil.EMPTY_STRING.equals(sFPCCode) || ConstantsUtil.STR_NULL.equals(sFPCCode))
	                            sFPCCode = ConstantsUtilIRM.HYPHENS; 
	                          if (null == sGTIN || ConstantsUtil.EMPTY_STRING.equals(sGTIN) || ConstantsUtil.STR_NULL.equals(sGTIN))
	                            sGTIN = ConstantsUtilIRM.HYPHENS; 
	                          if (null == sFPCDec || ConstantsUtil.EMPTY_STRING.equals(sFPCDec) || ConstantsUtil.STR_NULL.equals(sFPCDec))
	                            sFPCDec = ConstantsUtilIRM.HYPHENS; 
	                          sbFPCPackLevel.append(sPackLevelValue);
	                          sbFPCPackLevel.append(ConstantsUtil.SYMBL_PIPE);
	                          sbFPCName.append(sFPCCode);
	                          sbFPCName.append(ConstantsUtil.SYMBL_PIPE);
	                          sbFPCDescr.append(sFPCDec);
	                          sbFPCDescr.append(ConstantsUtil.SYMBL_PIPE);
	                          sbFPCGTIN.append(sGTIN);
	                          sbFPCGTIN.append(ConstantsUtil.SYMBL_PIPE);
	                        }  
	                    } 
	                  } 
	                } else {
	                  String sPackLevelValue = (String)slPackLevelList.get(0);
	                  if (null != sPackLevelValue) {
	                    sPackLevelValue = sPackLevelValue.trim();
	                    if (null == sPOAFPC || ConstantsUtil.EMPTY_STRING.equals(sPOAFPC) || ConstantsUtil.STR_NULL.equals(sPOAFPC))
	                      sPOAFPC = ConstantsUtilIRM.HYPHENS; 
	                    if (null == sPOAGTIN || ConstantsUtil.EMPTY_STRING.equals(sPOAGTIN) || ConstantsUtil.STR_NULL.equals(sPOAGTIN))
	                      sPOAGTIN = ConstantsUtilIRM.HYPHENS; 
	                    if (null == sPOAFPCDesc || ConstantsUtil.EMPTY_STRING.equals(sPOAFPCDesc) || ConstantsUtil.STR_NULL.equals(sPOAFPCDesc))
	                      sPOAFPCDesc = ConstantsUtilIRM.HYPHENS; 
	                    sbFPCPackLevel.append(sPackLevelValue);
                        sbFPCPackLevel.append(ConstantsUtil.SYMBL_PIPE);
                        sbFPCName.append(sPOAFPC);
                        sbFPCName.append(ConstantsUtil.SYMBL_PIPE);
                        sbFPCDescr.append(sPOAFPCDesc);
                        sbFPCDescr.append(ConstantsUtil.SYMBL_PIPE);
                        sbFPCGTIN.append(sPOAGTIN);
                        sbFPCGTIN.append(ConstantsUtil.SYMBL_PIPE);
	                  } 
	                } 
	                FPCList.add(builder.toString());
	                mpResult.put(ConstantsUtilIRM.FPCPACKLEVEL, sbFPCPackLevel.toString());
	                mpResult.put(ConstantsUtilIRM.FPCDESCR, sbFPCDescr.toString());
	                mpResult.put(ConstantsUtilIRM.FPCNAME, sbFPCName.toString());
	                mpResult.put(ConstantsUtilIRM.FPCGTIN, sbFPCGTIN.toString());
	              } catch (Exception e) {
	                LOGGER.info("Exception while fetching GTIN details of POA:"+e);
	              } 
	            } 
	          } 
	        } 
	
	    } catch (Exception e) {
	    	LOGGER.error("Error in fetchGTINDataField method."+e);
	    } 
	     
	    return mpResult;
	  }
	  
	  public HashMap getConsolidatedGTINMap(StringList gtinList, String gtinKey) {
	    HashMap<Object, Object> hmGTIN = new HashMap<>();
	    if (null != gtinList && gtinList.size() > 0)
	      for (int i = 0; i < gtinList.size(); i++) {
	        String sData = (String)gtinList.get(i);
	        if (sData.indexOf(gtinKey) != -1) {
	          int startIndex = sData.indexOf(gtinKey);
	        //SPEC: 23-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50225-- START
	          sData =sData.substring(startIndex+(gtinKey.length()),sData.length());
	        //SPEC: 23-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50225-- END
	          hmGTIN.put(gtinKey, sData);
	        } 
	      }  
	    return hmGTIN;
	  }

	  
	  public Map getFPCDescription(Context context, String strObjectName,Environment env)
		{
			String strFPCCodePadding=DomainConstants.EMPTY_STRING;
			String strDesc = DomainConstants.EMPTY_STRING;
			 Map<Object, Object> FPCDataMap = new HashMap<>();
			try
			{
				
				String	strNamePrefix = null;
				if(UIUtil.isNotNullAndNotEmpty(strObjectName))
				{
					String	strName = FrameworkUtil.getAliasForAdmin(context, ConstantsUtil.TYPE, ConstantsUtil.TYPE_FINISHEDPRODUCTPART, true);
					StringList slNumGenSelect = new StringList(ConstantsUtil.SELECT_ATTRIBUTE_ESERVICE_NAME_PREFIX);
					MapList mpNumGen = DomainObject.findObjects(context, //context
							ConstantsUtil.TYPE_ESERVICE_OBJECT_GENERATOR, //Type
							strName, //Name
							ConstantsUtilIRM.LETTERA,// Revision
							DomainConstants.QUERY_WILDCARD,//owner
							ConstantsUtilIRM.VAULT_ESERVICEADMINISTRATION,//vault
							ConstantsUtil.EMPTY_STRING,//where exp
							false,//expand
							slNumGenSelect //selectables
							);
					for (int i = 0; i < mpNumGen.size(); i++) {
						Map mp = (Map) mpNumGen.get(i);
						strNamePrefix = (String) mp.get(ConstantsUtil.SELECT_ATTRIBUTE_ESERVICE_NAME_PREFIX);
						if (UIUtil.isNotNullAndNotEmpty(strNamePrefix))
							break;
					}
					
					if(UIUtil.isNotNullAndNotEmpty(strNamePrefix) && !strObjectName.contains(strNamePrefix))
					{
						 strFPCCodePadding = strObjectName;
						 StringBuilder sbFPCZeroPadding = new StringBuilder (strFPCCodePadding);
						 int intPadding = strFPCCodePadding.length();
						if (intPadding > 0 && intPadding <= 18)
						{
							while (sbFPCZeroPadding.toString().length() < 18)
							{
								sbFPCZeroPadding.insert(ConstantsUtilIRM.ZERO, ConstantsUtil.GEN_NUM_ZERO);
							}
							strFPCCodePadding = sbFPCZeroPadding.toString();
						}
					}
				}
						String strGTINFetchedIT = DomainConstants.EMPTY_STRING;
					    String strGTINFetchedSW = DomainConstants.EMPTY_STRING;
					    String strGTINFetchedCS = DomainConstants.EMPTY_STRING;
					    String strGTINFetchedNGTIN = DomainConstants.EMPTY_STRING;
					    String strDescription = DomainConstants.EMPTY_STRING;
					    String strAUoMSelection = DomainConstants.EMPTY_STRING;
					    String strAUoM = DomainConstants.EMPTY_STRING;
					    String strGTIN = DomainConstants.EMPTY_STRING;
					    String strChildFPC = DomainConstants.EMPTY_STRING;
						BusExtractUtil util = new BusExtractUtil();
						String username = env.getProperty(ConstantsUtil.USER_ENOVIA_SAP_PO_USER);
						String  password = env.getProperty(ConstantsUtil.USER_ENOVIA_SAP_PO_PASS);
						String strSAPSystemURL= env.getProperty(ConstantsUtil.USER_ENOVIA_SAP_PO_SIT_URL);
						EncryptCrypto encrpto = new EncryptCrypto();	
						password=encrpto.decryptString(password);
						SOAPConnectionFactory scfInstance = SOAPConnectionFactory.newInstance();
						SOAPConnection soapConnection = scfInstance.createConnection();
						MessageFactory messFactory = MessageFactory.newInstance();
						SOAPMessage message = messFactory.createMessage();
						String strRequestInput = (String)requestXMLGeneration(context, strFPCCodePadding);
					
						SOAPPart sp = message.getSOAPPart();
						StreamSource prepMessage = new StreamSource(new ByteArrayInputStream(strRequestInput.getBytes()));
						sp.setContent(prepMessage);
						// Save message

						message.saveChanges();
						String encodedUserInfo = username + ConstantsUtil.SYMBL_COLON + password;
						encodedUserInfo = new String(Base64.getEncoder().encode(encodedUserInfo.getBytes()));
						//Set Encoded UserInfo to Request SOAPMessage
						StringBuilder sbAuthType = new StringBuilder(ConstantsUtilIRM.BASIC);
						sbAuthType.append(encodedUserInfo);
						message.getMimeHeaders ().setHeader (ConstantsUtilIRM.AUTHORIZATION, sbAuthType.toString());
						encodedUserInfo = new String(Base64.getEncoder().encode(encodedUserInfo.getBytes()));
						// Send
						SOAPMessage response = soapConnection.call(message, strSAPSystemURL);
						TransformerFactory transformerFac = javax.xml.transform.TransformerFactory.newInstance();
						transformerFac.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ConstantsUtil.EMPTY_STRING); // Compliant
						transformerFac.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, ConstantsUtil.EMPTY_STRING); // Compliant
						Transformer transf = transformerFac.newTransformer();
						Source sc = response.getSOAPPart().getContent();
						// Close connection
						soapConnection.close();
						StringWriter outWriter = new StringWriter();
						StreamResult result = new StreamResult(outWriter);
						transf.transform(sc, result);
						String output = outWriter.toString();
						InputStream inputStream = new ByteArrayInputStream(output.getBytes(ConstantsUtil.STRING_UTF_EIGHT));
						DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
						dbFactory.setAttribute(XMLConstants.FEATURE_SECURE_PROCESSING, true);
						dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ""); // Compliant
						dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, ""); // compliant
						DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
						Document doc = dBuilder.parse(inputStream);
						doc.getDocumentElement().normalize();

						NodeList nAUOMList = doc.getElementsByTagName(ConstantsUtil.STRING_ALTERNATIVEUNITOFMEASURE); 
						NodeList nlDescription = doc.getElementsByTagName(ConstantsUtilIRM.DESCRIPTION);
						//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- START
						NodeList nlChildFPC = doc.getElementsByTagName(ConstantsUtilIRM.CHILDFPC);
						if(nlChildFPC.getLength() > 0) {
							Element nCFPCValue = (Element)(nlChildFPC.item(0));
							strChildFPC = (String)nCFPCValue.getTextContent();
						}
						//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- END
						if(nAUOMList.getLength() > 0)
						{
							HashMap <String, String> hmAUOM = new HashMap <String, String>();
							int intAUOMLength = nAUOMList.getLength();
							for (int i = 0; i < intAUOMLength; i++)

							{
								Node nAUOMNode = nAUOMList.item(i);
								Element eAUOMElement = (Element) nAUOMNode;
								String strAUOMName = (String)eAUOMElement.getAttribute(ConstantsUtil.STRING_AUOM);
								NodeList nGTINTag = eAUOMElement.getElementsByTagName(ConstantsUtil.STRING_GTIN);
								Element nGTINValue = (Element)(nGTINTag.item(0));
								String strGTINValue = (String)nGTINValue.getTextContent();
								hmAUOM.put(strAUOMName, strGTINValue);
								if (ConstantsUtil.BASEUNITOFMEASURE_IT.equals(strAUOMName))
					                  strGTINFetchedIT = (String)hmAUOM.get(strAUOMName); 
					                if (ConstantsUtil.BASEUNITOFMEASURE_CS.equals(strAUOMName))
					                  strGTINFetchedCS = (String)hmAUOM.get(strAUOMName); 
					                if (ConstantsUtil.BASEUNITOFMEASURE_SW.equals(strAUOMName))
					                  strGTINFetchedSW = (String)hmAUOM.get(strAUOMName); 
					                if (ConstantsUtilIRM.BASEUNITOFMEASURE_NGTIN.equals(strAUOMName))
					                  strGTINFetchedNGTIN = (String)hmAUOM.get(strAUOMName);
							}
							 

						}
						int nlDescrLength = nlDescription.getLength();
						if(nlDescrLength > 0)
						{
							for (int i = 0; i < nlDescrLength; i++)

							{
								Node nDescNode = nlDescription.item(i);
								Element elDescr = (Element) nDescNode;
								strDesc = (String)elDescr.getAttribute(ConstantsUtilIRM.LANGUAGE);
								//SPEC: 01-09-2022: Dominic Modified for SR22x.0_NovemberCW Internal Defect -- START
								if (ConstantsUtilIRM.LETTERE.equals(strDesc)) {
									strDescription = (String)elDescr.getTextContent();
									break;
								}
								//SPEC: 01-09-2022: Dominic Modified for SR22x.0_NovemberCW Internal Defect -- END
							}
						
						}
						//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- START
						if(UIUtil.isNullOrEmpty(strGTINFetchedCS)&&UIUtil.isNullOrEmpty(strGTINFetchedIT)&&UIUtil.isNullOrEmpty(strGTINFetchedSW)&&UIUtil.isNullOrEmpty(strGTINFetchedNGTIN)&&UIUtil.isNotNullAndNotEmpty(strChildFPC)){
							FPCDataMap=getGTINFromChildFPC(context,strChildFPC,env);
							FPCDataMap.put(ConstantsUtilIRM.FPP_DESC, strDescription);
						}else {
						//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- END
							FPCDataMap.put(ConstantsUtilIRM.FPP_GTIN_IT, strGTINFetchedIT);
							FPCDataMap.put(ConstantsUtilIRM.FPP_GTIN_SW, strGTINFetchedSW);
							FPCDataMap.put(ConstantsUtilIRM.FPP_GTIN_CS, strGTINFetchedCS);
							FPCDataMap.put(ConstantsUtilIRM.FPP_GTIN_NGTIN, strGTINFetchedNGTIN);
							FPCDataMap.put(ConstantsUtilIRM.FPP_DESC, strDescription);
						//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- START
						}
						//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- END
									
			}catch(Exception e){
				LOGGER.error("Error in BusExtractUtil, Unable to send request to SOAP PO: getGTIN:"+e);
			}
		
			return FPCDataMap;
		}
	  
	  
		public String requestXMLGeneration(Context context, String strFPCCode)throws Exception

		{
			String strRequestXMLString = ConstantsUtil.EMPTY_STRING;

			try
			{
				DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
				Document doc = docBuilder.newDocument();

				//Creating the XML tree
				Element root = doc.createElement(ConstantsUtilIRM.SOAPENVENVELOPE);
				root.setAttribute(ConstantsUtilIRM.XMLNSSOAPENVKEY, ConstantsUtilIRM.XMLNSSOAPENVVAL);
				root.setAttribute(ConstantsUtilIRM.XMLNSGPDBKEY, ConstantsUtilIRM.XMLNSGPDBVAL);
				doc.appendChild(root);
				Element header = doc.createElement(ConstantsUtilIRM.SOAPENVHEADER);
				root.appendChild(header);
				Element body = doc.createElement(ConstantsUtilIRM.SOAPENVBODY);
				root.appendChild(body);
				Element prodGetDetails = doc.createElement(ConstantsUtilIRM.GPDBSERVICE);
				body.appendChild(prodGetDetails);
				Element prodMand = doc.createElement(ConstantsUtilIRM.GPDBPRODUCTMAT);
				prodMand.setAttribute(ConstantsUtilIRM.INCLUDEDERIVEDATTRIBUTES, ConstantsUtil.CONSTANT_STRING_Y);
			    prodMand.setAttribute(ConstantsUtilIRM.INCLUDELEADINGZEROS, ConstantsUtil.CONSTANT_STRING_Y);
				prodGetDetails.appendChild(prodMand);

				//add a text element to the child

				Text text = doc.createTextNode(strFPCCode);
				prodMand.appendChild(text);

				//set up a transformer
				TransformerFactory transfac = javax.xml.transform.TransformerFactory.newInstance();
				transfac.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ConstantsUtil.EMPTY_STRING); // Compliant
				transfac.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, ConstantsUtil.EMPTY_STRING); // Compliant
				Transformer trans = transfac.newTransformer();
				trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, ConstantsUtil.ALL_SMALL_YES);
				trans.setOutputProperty(OutputKeys.INDENT, ConstantsUtil.ALL_SMALL_YES);

				//create string from xml tree
				StringWriter sw = new StringWriter();
				StreamResult result = new StreamResult(sw);
				DOMSource source = new DOMSource(doc);
				trans.transform(source, result);
				strRequestXMLString = sw.toString();

			}
			catch(Exception Ex)
			{
				LOGGER.error("Error in requestXMLGeneration method."+Ex);
			}
			return strRequestXMLString;
		}
		//Added by Jwala for 22x Development Req 42996 -- START
		public boolean isUserCMandSP(Context context, String ObjId){
			boolean isUserCMandSP = false;
			SecurityService sct = new SecurityService();
			Collection<? extends GrantedAuthority> authorities = sct.getAuthorities();
			HashMap<String, String> roleMap = (HashMap) sct.getRoleAuthorities(authorities);
			for (Entry<String, String> entry : roleMap.entrySet())
			{
				String key = entry.getKey();
				if(ConstantsUtil.COMPANYAUTHORITY.equalsIgnoreCase(key)) {
					boolean bIsCM = false;
					boolean bIsSupplier = false;
					if (sct.isContractManufacturer(roleMap.get(ConstantsUtil.SECURITYAUTHORITY))) {
						bIsCM = true;
					}
					if(sct.isSupplierManufacturer(roleMap.get(ConstantsUtil.SECURITYAUTHORITY))){
						bIsSupplier = true;
					}
					
					if(bIsCM && bIsSupplier) {
						isUserCMandSP = true;
						break;
					}
				}
			}
			return isUserCMandSP;
		}
		//Added by Jwala for 22x Development Req 42996 -- END
		//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- START
		public Map getGTINFromChildFPC(Context context, String strChildFPC,Environment env)
		{
			String strFPCCodePadding=ConstantsUtil.EMPTY_STRING;
			String strDesc = ConstantsUtil.EMPTY_STRING;
			 Map<Object, Object> FPCDataMap = new HashMap<>();
			try
			{
				
				String	strNamePrefix = null;
				if(UIUtil.isNotNullAndNotEmpty(strChildFPC))
				{
						 strFPCCodePadding = strChildFPC;
						 StringBuilder sbFPCZeroPadding = new StringBuilder (strFPCCodePadding);
						 int intPadding = strFPCCodePadding.length();
						if (intPadding > 0 && intPadding <= 18)
						{
							while (sbFPCZeroPadding.toString().length() < 18)
							{
								sbFPCZeroPadding.insert(ConstantsUtilIRM.ZERO, ConstantsUtil.GEN_NUM_ZERO);
							}
							strFPCCodePadding = sbFPCZeroPadding.toString();
						}
					}
						String strGTINFetchedIT = ConstantsUtil.EMPTY_STRING;
					    String strGTINFetchedSW = ConstantsUtil.EMPTY_STRING;
					    String strGTINFetchedCS = ConstantsUtil.EMPTY_STRING;
					    String strGTINFetchedNGTIN = ConstantsUtil.EMPTY_STRING;
					    String strDescription = ConstantsUtil.EMPTY_STRING;
					    String strAUoMSelection = ConstantsUtil.EMPTY_STRING;
					    String strAUoM = null;
					    String strGTIN = null;
						BusExtractUtil util = new BusExtractUtil();
						String username = env.getProperty(ConstantsUtil.USER_ENOVIA_SAP_PO_USER);
						String  password = env.getProperty(ConstantsUtil.USER_ENOVIA_SAP_PO_PASS);
						String strSAPSystemURL= env.getProperty(ConstantsUtil.USER_ENOVIA_SAP_PO_SIT_URL);
						EncryptCrypto encrpto = new EncryptCrypto();		
						password=encrpto.decryptString(password);
						SOAPConnectionFactory scfInstance = SOAPConnectionFactory.newInstance();
						SOAPConnection soapConnection = scfInstance.createConnection();
						MessageFactory messFactory = MessageFactory.newInstance();
						SOAPMessage message = messFactory.createMessage();
						String strRequestInput = (String)requestXMLGeneration(context, strFPCCodePadding);
	
					
						SOAPPart sp = message.getSOAPPart();
						StreamSource prepMessage = new StreamSource(new ByteArrayInputStream(strRequestInput.getBytes()));
						sp.setContent(prepMessage);
						// Save message

						message.saveChanges();
						String encodedUserInfo = username + ConstantsUtil.SYMBL_COLON + password;
						encodedUserInfo = new String(Base64.getEncoder().encode(encodedUserInfo.getBytes()));
						//Set Encoded UserInfo to Request SOAPMessage
						StringBuilder sbAuthType = new StringBuilder(ConstantsUtilIRM.BASIC);
						sbAuthType.append(encodedUserInfo);
						message.getMimeHeaders ().setHeader (ConstantsUtilIRM.AUTHORIZATION, sbAuthType.toString());
						encodedUserInfo = new String(Base64.getEncoder().encode(encodedUserInfo.getBytes()));
						// Send
						SOAPMessage response = soapConnection.call(message, strSAPSystemURL);
						TransformerFactory transformerFac = javax.xml.transform.TransformerFactory.newInstance();
						transformerFac.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ConstantsUtil.EMPTY_STRING); // Compliant
						transformerFac.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, ConstantsUtil.EMPTY_STRING); // Compliant
						Transformer transf = transformerFac.newTransformer();
						Source sc = response.getSOAPPart().getContent();
						// Close connection
						soapConnection.close();
						StringWriter outWriter = new StringWriter();
						StreamResult result = new StreamResult(outWriter);
						transf.transform(sc, result);
						String output = outWriter.toString();
						InputStream inputStream = new ByteArrayInputStream(output.getBytes(ConstantsUtil.STRING_UTF_EIGHT));
						DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
						dbFactory.setAttribute(XMLConstants.FEATURE_SECURE_PROCESSING, true);
						dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ""); // Compliant
						dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, ""); // compliant
						DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
						Document doc = dBuilder.parse(inputStream);
						doc.getDocumentElement().normalize();

						NodeList nAUOMList = doc.getElementsByTagName(ConstantsUtil.STRING_ALTERNATIVEUNITOFMEASURE); 
						if(nAUOMList.getLength() > 0)
						{
							HashMap <String, String> hmAUOM = new HashMap <String, String>();
							int intAUOMLength = nAUOMList.getLength();
							for (int i = 0; i < intAUOMLength; i++)
							{
								Node nAUOMNode = nAUOMList.item(i);
								Element eAUOMElement = (Element) nAUOMNode;
								String strAUOMName = (String)eAUOMElement.getAttribute(ConstantsUtil.STRING_AUOM);
								NodeList nGTINTag = eAUOMElement.getElementsByTagName(ConstantsUtil.STRING_GTIN);
								Element nGTINValue = (Element)(nGTINTag.item(0));
								String strGTINValue = (String)nGTINValue.getTextContent();
								hmAUOM.put(strAUOMName, strGTINValue);
								if (ConstantsUtil.BASEUNITOFMEASURE_IT.equals(strAUOMName))
					                  strGTINFetchedIT = (String)hmAUOM.get(strAUOMName); 
					                if (ConstantsUtil.BASEUNITOFMEASURE_CS.equals(strAUOMName))
					                  strGTINFetchedCS = (String)hmAUOM.get(strAUOMName); 
					                if (ConstantsUtil.BASEUNITOFMEASURE_SW.equals(strAUOMName))
					                  strGTINFetchedSW = (String)hmAUOM.get(strAUOMName); 
					                if (ConstantsUtilIRM.BASEUNITOFMEASURE_NGTIN.equals(strAUOMName))
					                  strGTINFetchedNGTIN = (String)hmAUOM.get(strAUOMName);
							}
							 

						}
						FPCDataMap.put(ConstantsUtilIRM.FPP_GTIN_IT, strGTINFetchedIT);
						FPCDataMap.put(ConstantsUtilIRM.FPP_GTIN_SW, strGTINFetchedSW);
						FPCDataMap.put(ConstantsUtilIRM.FPP_GTIN_CS, strGTINFetchedCS);
						FPCDataMap.put(ConstantsUtilIRM.FPP_GTIN_NGTIN, strGTINFetchedNGTIN);							
			}catch(Exception e){
				LOGGER.error("Error in BusExtractUtil, Unable to send request to SOAP PO: Child FPC:"+e);
			}
		
			return FPCDataMap;
		}
		//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- END
	//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
		/**
	 * Retrieve MEP/SEP for connected Substitute Part
	 * @param context
	 * @param sObjectId
	 * @param mlFinalSubstitudeList
	 * @throws Exception
	*/
	public void getConnectedSubstitudePartForCertification(Context context, String sObjectId,
			MapList mlFinalSubstitudeList) throws Exception {
		
		Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT);
		relPattern.addPattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
		relPattern.addPattern(DomainConstants.RELATIONSHIP_ALTERNATE);

		Pattern typePattern = new Pattern(ConstantsUtil.TYPE_RAWMATERIALPART);

		StringList selectStmts = new StringList(9);
		selectStmts.addElement(DomainConstants.SELECT_ID);
		selectStmts.addElement(DomainConstants.SELECT_TYPE);
		selectStmts.addElement(DomainConstants.SELECT_POLICY);
		selectStmts.addElement(DomainConstants.SELECT_CURRENT);
		selectStmts.addElement(DomainConstants.SELECT_NAME);
		selectStmts.addElement(DomainConstants.SELECT_REVISION);
		selectStmts.add(new StringBuilder("from[").append(ConstantsUtil.RELATIONSHIP_EBOM)
				.append("].frommid[" + ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE + "].to.id").toString());
		selectStmts.addElement(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACH_STATUS));
		selectStmts.addElement(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACHREGISTRATIONNUMBER));

		StringList selectRelStmts = new StringList(2);
		selectRelStmts.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_PGMEPSEPCERTIFICATION + "].id");
		selectRelStmts.addElement(DomainRelationship.SELECT_ID);

		MapList mepList = new MapList();
		MapList sepList = new MapList();
		HashMap tempMap = new HashMap();
		Map mpConnectedPartDetails = new HashMap();
		String sConnectedPartId = DomainConstants.EMPTY_STRING;
		String sConnectedPartPolicy = DomainConstants.EMPTY_STRING;
		Object objMEPSEPCertification = null;
		String sREACHStatus = DomainConstants.EMPTY_STRING;
		String sREACHRegNum = DomainConstants.EMPTY_STRING;
		String sMEPSEPCertificationRelId = DomainConstants.EMPTY_STRING;
		StringList slMEPSEPCertificationRelId = new StringList();
		Iterator itrMEPSEPCertificationRelId = null;
		String sWhere="current!="+ConstantsUtil.STATE_OBSOLETE;

		try {

			DomainObject domObj = DomainObject.newInstance(context, sObjectId);
			MapList mlConnectedMEPsSEPsAlternates = domObj.getRelatedObjects(context, relPattern.getPattern(), // relationship
																												// pattern
					typePattern.getPattern(), // object pattern
					selectStmts, // object selects
					selectRelStmts, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					sWhere, // object where clause
					null, // relationship where clause
					0);
			if((mlConnectedMEPsSEPsAlternates!=null && !mlConnectedMEPsSEPsAlternates.isEmpty())) {
				Iterator itrConnectedMEPsSEPsAlternates = mlConnectedMEPsSEPsAlternates.iterator();

				while (itrConnectedMEPsSEPsAlternates.hasNext()) {
					tempMap = new HashMap();
					mpConnectedPartDetails = (Map) itrConnectedMEPsSEPsAlternates.next();
					sConnectedPartId = (String) mpConnectedPartDetails.get(DomainConstants.SELECT_ID);
					sConnectedPartPolicy = (String) mpConnectedPartDetails.get(DomainConstants.SELECT_POLICY);
					String strName = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_NAME);
					String strType = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_TYPE);
					String strRev = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_REVISION);
					String strCurrent = (String)mpConnectedPartDetails.get(DomainConstants.SELECT_CURRENT);
					objMEPSEPCertification = mpConnectedPartDetails
							.get("frommid[" + ConstantsUtil.RELATIONSHIP_PGMEPSEPCERTIFICATION + "].id");
					sREACHStatus = (String) mpConnectedPartDetails
							.get(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACH_STATUS));
					sREACHRegNum = (String) mpConnectedPartDetails.get(
							DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_REACHREGISTRATIONNUMBER));
					if (UIUtil.isNotNullAndNotEmpty(sConnectedPartPolicy)
							&& ((ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT.equals(sConnectedPartPolicy))
									|| (ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT
											.equals(sConnectedPartPolicy)))) {

						if (null != objMEPSEPCertification && objMEPSEPCertification instanceof String) {
							sMEPSEPCertificationRelId = (String) objMEPSEPCertification;
							if (UIUtil.isNotNullAndNotEmpty(sMEPSEPCertificationRelId)) {
								tempMap.put(DomainConstants.SELECT_ID, sConnectedPartId);
								tempMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, sMEPSEPCertificationRelId);
								tempMap.put(DomainConstants.SELECT_POLICY, sConnectedPartPolicy);
								tempMap.put(DomainConstants.SELECT_LEVEL, ConstantsUtilIRM.CONSTANT_THIRDLEVEL);
								tempMap.put(ConstantsUtilIRM.CONST_REACHSTATUS,DomainConstants.EMPTY_STRING);
								tempMap.put(ConstantsUtilIRM.CONST_REACHREGNUM,DomainConstants.EMPTY_STRING);
								tempMap.put(DomainConstants.SELECT_TYPE,strType);
								tempMap.put(DomainConstants.SELECT_REVISION, strRev);
								tempMap.put(DomainConstants.SELECT_CURRENT, strCurrent);
								tempMap.put(DomainConstants.SELECT_NAME,strName);

								if (sConnectedPartPolicy
										.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTURER_EQUIVALENT)) {
									tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,
											ConstantsUtilIRM.CONST_MEP);
									mepList.add(tempMap);
								} else {
									tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,
											ConstantsUtilIRM.CONST_SEP);
									sepList.add(tempMap);
								}
							}

						} else if (null != objMEPSEPCertification && objMEPSEPCertification instanceof StringList) {
							slMEPSEPCertificationRelId = (StringList) objMEPSEPCertification;

							if (slMEPSEPCertificationRelId != null && !slMEPSEPCertificationRelId.isEmpty()) {
								itrMEPSEPCertificationRelId = slMEPSEPCertificationRelId.iterator();
								while (itrMEPSEPCertificationRelId.hasNext()) {
									tempMap = new HashMap();
									sMEPSEPCertificationRelId = (String) itrMEPSEPCertificationRelId.next();
									if (UIUtil.isNotNullAndNotEmpty(sMEPSEPCertificationRelId)) {
										tempMap.put(DomainConstants.SELECT_ID, sConnectedPartId);
										tempMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, sMEPSEPCertificationRelId);
										tempMap.put(DomainConstants.SELECT_POLICY, sConnectedPartPolicy);
										tempMap.put(DomainConstants.SELECT_LEVEL, ConstantsUtilIRM.CONSTANT_THIRDLEVEL);
										tempMap.put(ConstantsUtilIRM.CONST_REACHSTATUS,DomainConstants.EMPTY_STRING);
										tempMap.put(ConstantsUtilIRM.CONST_REACHREGNUM,DomainConstants.EMPTY_STRING);
										tempMap.put(DomainConstants.SELECT_TYPE,strType);
										tempMap.put(DomainConstants.SELECT_REVISION, strRev);
										tempMap.put(DomainConstants.SELECT_CURRENT, strCurrent);
										tempMap.put(DomainConstants.SELECT_NAME,strName);

										if (sConnectedPartPolicy.equalsIgnoreCase(
												ConstantsUtil.POLICY_MANUFACTURER_EQUIVALENT)) {
											tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,
													ConstantsUtilIRM.CONST_MEP);
											mepList.add(tempMap);
										} else {
											tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,
													ConstantsUtilIRM.CONST_SEP);
											sepList.add(tempMap);
										}
									}
								}
							}
						}
						if (UIUtil.isNotNullAndNotEmpty(sREACHStatus) || UIUtil.isNotNullAndNotEmpty(sREACHRegNum)) {
							tempMap = new HashMap();
							tempMap.put(DomainConstants.SELECT_ID, sConnectedPartId);
							tempMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, DomainConstants.EMPTY_STRING);
							tempMap.put(DomainConstants.SELECT_POLICY, sConnectedPartPolicy);
							tempMap.put(DomainConstants.SELECT_LEVEL, ConstantsUtilIRM.CONSTANT_THIRDLEVEL);
							tempMap.put(ConstantsUtilIRM.CONST_REACHSTATUS, sREACHStatus);
							tempMap.put(ConstantsUtilIRM.CONST_REACHREGNUM, sREACHRegNum);
							tempMap.put(DomainConstants.SELECT_TYPE,strType);
							tempMap.put(DomainConstants.SELECT_REVISION, strRev);
							tempMap.put(DomainConstants.SELECT_CURRENT, strCurrent);
							tempMap.put(DomainConstants.SELECT_NAME,strName);
							if (sConnectedPartPolicy
									.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTURER_EQUIVALENT)) {
								tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,
										ConstantsUtilIRM.CONST_MEP);
								mepList.add(tempMap);
							} else {
								tempMap.put(ConstantsUtilIRM.CONST_RELATIONSHIPTYPE,
										ConstantsUtilIRM.CONST_SEP);
								sepList.add(tempMap);
							}
						}
					}
				}
				mlFinalSubstitudeList.addAll(mepList);
				mlFinalSubstitudeList.addAll(sepList);
			}
		} catch (Exception ex) {
			LOGGER.error("Error in getConnectedSubstitudePartForCertification:"+ex);
		}
	}
	/**
		 * For Expand Substitute or ALternate Part, update the Level of connected MEP/SEP
		 * @param alternateList
		 * @return
		 */
		private MapList arrangeLevelOfPart(MapList alternateList) {
			MapList mlReturnObjList =  new MapList();
			if((alternateList!=null && !alternateList.isEmpty())) {
				for(int i=0;i<alternateList.size();i++) {
					Map mData = (Map) alternateList.get(i);
					mData.computeIfPresent(DomainConstants.SELECT_LEVEL,(key,value)-> ConstantsUtilIRM.CONST_VALUE_ONE);
					mlReturnObjList.add(mData);
				}		
			}
			return mlReturnObjList;	
		}
//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END	
		
		//SPEC: 02-09-2022: Jwala Added for SR22x.0_FEB_CW Defect 50643 -- START	
		public synchronized boolean isSameSupplier(Context context,String strMfr)throws Exception {
			boolean flag = false;
			StringBuilder sbCompany = new StringBuilder();
			SecurityService sct = new SecurityService();
			String sUserCompanies = sct.getUserCauthorities();
			String[] aCompany = splitCompanyValues(context,sUserCompanies);
			if (aCompany.length > -1) {
				for (int i = 0; i < aCompany.length; i++) {
					if (null != aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					}
				}
			}
			String tempVal =sbCompany.toString();
			tempVal=tempVal.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
			StringList slTokens =getStringListWithComma(tempVal);
			flag = slTokens.contains(strMfr);
			return flag;
		}
		//SPEC: 02-09-2022: Jwala Added for SR22x.0_FEB_CW Defect 50643 -- END
		
		//SPEC: <28.02.2023>: Satyam Added for Defect 52053 -- START
		public MapList removeDuplicateMapList(MapList mapList) {
			MapList finalMapList = new MapList();
			StringList slList = new StringList();
			Iterator objectListItr = mapList.iterator();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				if(!slList.contains(sId)) {
					slList.add(sId);
					finalMapList.add(objectMap);
				}
			}
			return finalMapList;
		}
		//SPEC: <28.02.2023>: Satyam Added for Defect 52053 -- END
		
		//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- START
		public MapList getReferencePart(Context context, String strObjectId, String sUserType) {
			 String strRefPartID = DomainConstants.EMPTY_STRING;
			 MapList referencePartList = new MapList();
			 Map objMap = null;
			 StringList objectSelect = new StringList(3);				
			 objectSelect.add(DomainConstants.SELECT_ID);
			 objectSelect.add(DomainConstants.SELECT_NAME);
			 objectSelect.add("last." + ConstantsUtil.ATTRIBUTE_PGORIGINATINGSOURCE);
			 MapList referencePrevPartList = new MapList();
			 String strPrevRevType = DomainConstants.EMPTY_STRING;
			 String strPrevRevState = DomainConstants.EMPTY_STRING;
			 String strPrevRevId = DomainConstants.EMPTY_STRING;
			 DomainObject domPrevRevObj = null;
			 String strObjType = DomainConstants.EMPTY_STRING;
			 String strObjState = DomainConstants.EMPTY_STRING;
			 StringList sPartSelStmts = new StringList(5);
			 sPartSelStmts.add(DomainConstants.SELECT_TYPE);
			 sPartSelStmts.add(DomainConstants.SELECT_CURRENT);
			 sPartSelStmts.add(ConstantsUtilIRM.PREVIOUSID);   
			 sPartSelStmts.add(ConstantsUtilIRM.PREVIOUSCURRENT);   
			 sPartSelStmts.add(ConstantsUtilIRM.PREVIOUSTYPE);
			 StringList slSelect = new StringList(DomainConstants.SELECT_ID);
             slSelect.add(DomainConstants.SELECT_NAME);
             slSelect.add(DomainConstants.SELECT_TYPE);
             slSelect.add(DomainConstants.SELECT_REVISION);
             slSelect.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
             slSelect.add(DomainConstants.SELECT_ORIGINATOR);
             slSelect.add(DomainConstants.SELECT_CURRENT);
             slSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
             slSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
             slSelect.add("last." + ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			 String strObjectWhere = new StringBuffer(DomainObject.SELECT_CURRENT).append( " != ").append(ConstantsUtil.STATE_PART_OBSOLETE).toString();
	 	    try {
	 	     
	 	    	MapList mlReturn = new MapList();
	 	    	StringValidatorUtil validator = new StringValidatorUtil();
	 	    	 String strPackMatCertification = ConstantsUtil.EMPTY_STRING;
	 	      if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
	 	        DomainObject domObj = DomainObject.newInstance(context, strObjectId);
				objMap = domObj.getInfo(context, sPartSelStmts);
				strObjType = (String)objMap.get(DomainConstants.SELECT_TYPE);
				strObjState = (String)objMap.get(DomainConstants.SELECT_CURRENT);
				if(((UIUtil.isNotNullAndNotEmpty(strObjType)) && (strObjType.equals(ConstantsUtil.TYPE_MASTERRAWMATERIALPART)))){
					strPrevRevId =	(String) objMap.get(ConstantsUtilIRM.PREVIOUSID);						
					strPrevRevType  = (String) objMap.get(ConstantsUtilIRM.PREVIOUSTYPE);
					strPrevRevState = (String) objMap.get(ConstantsUtilIRM.PREVIOUSCURRENT);
					if(UIUtil.isNotNullAndNotEmpty(strPrevRevId))
						domPrevRevObj = DomainObject.newInstance(context, strPrevRevId);
				}
				if((isOfDSOOrigin(context, strObjectId)) && ((UIUtil.isNotNullAndNotEmpty(strObjType)) && (strObjType.equals(ConstantsUtil.TYPE_MASTERRAWMATERIALPART)))){
					 referencePartList = domObj.getRelatedObjects(context,//context
							 										 ConstantsUtil.RELATIONSHIP_PGMASTER,//relationship pattern
																	 DomainConstants.TYPE_PART,//type pattern
																	 objectSelect,// object selects
																	 null,// relationship selects
																	 true,// to direction
																	 false,// from Direction
																	 (short)1,// recursion level
																	 strObjectWhere,// object where clause
																	 null); // level										 
					if(UIUtil.isNotNullAndNotEmpty(strPrevRevType) && UIUtil.isNotNullAndNotEmpty(strPrevRevState) && UIUtil.isNotNullAndNotEmpty(strPrevRevId)){								
					if(ConstantsUtil.TYPE_PGMASTERRAWMATERIAL.equals(strPrevRevType) && !ConstantsUtil.STATE_RELEASE.equals(strObjState) && ConstantsUtil.STATE_RELEASE.equals(strPrevRevState)){
						referencePrevPartList = domPrevRevObj.getRelatedObjects(context,
														 ConstantsUtil.RELATIONSHIP_PGMASTER,//relationship pattern
														 DomainConstants.TYPE_PART,//type pattern
														 objectSelect,// object selects
														 null,// relationship selects
														 true,// to direction
														 false,// from Direction
														 (short)1,// recursion level
														strObjectWhere,// object where clause
														 null);// level								 
						}
					 referencePartList.addAll(referencePrevPartList);
					}
				 }
				StringList strList=(StringList)domObj.getInfoList(context, "to["+ DomainConstants.RELATIONSHIP_CLASSIFIED_ITEM +"].tomid["+ConstantsUtil.REL_PARTFAMILYREFERENCE +"].fromrel.to.id");
				
				int iSize =strList.size();
				if(strList.size()>300) {
					 iSize = 300;
				}

				if(null!=strList && !strList.isEmpty())
				 {
					 for (int index = 0; index<iSize ; index ++)
					 {
						 strRefPartID = (String)strList.get(index);
						 domObj.setId(strRefPartID);
		                 Map map = domObj.getInfo(context, slSelect);
		                 if(map != null && !map.isEmpty())
		                 {
		                	String sId = validator.getEquivalentStringComma(map.get(DomainConstants.SELECT_ID));
		                    String slState = validator.getEquivalentStringComma(map.get(DomainConstants.SELECT_CURRENT));
		                    if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM) || sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP)) {
		                    	if(!UIUtil.isNullOrEmpty(slState) && ConstantsUtil.STATE_RELEASE.equals(slState) && checkHasAccess(context, null, sId))
			                    {
			                    	referencePartList.add(map);
			                    }	
		                    }
		                    else {
		                    	if(!UIUtil.isNullOrEmpty(slState) && !slState.equals(ConstantsUtil.STATE_OBSOLETE))
			                    {
			                    	referencePartList.add(map);
			                    }
		                    }			                    		
		                 }
					 }
				 }
	 	      }
	 	    } catch (Exception e) {
	 	    	LOGGER.error("Error in getReferencePart : "+e);
	 	    } 
	  
	 	    return referencePartList;
	 	  }
		
		
		public Map<String, String> parseReferencePart(Context context,MapList mlReferencePartList) throws Exception
		{
			Map<String, String> mpReferencePart = new HashMap<String, String>();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbRevision = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbOriginator = new StringBuilder();
			StringBuilder sbState = new StringBuilder();
			StringBuilder sbReleaseDate = new StringBuilder();
			StringBuilder sbExpirationDate = new StringBuilder();
			StringValidatorUtil validator = new StringValidatorUtil();
			boolean showData = false;
			try {
				Iterator objectListItr = mlReferencePartList.iterator();
				while (objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					showData = checkHasAccess(context, null, sId);
					if(!showData) {
						sId = ConstantsUtil.NO_ACCESS;
					}
					String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sReleaseDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
					sReleaseDate = validator.DateFormatter(sReleaseDate);
					String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
					sType = mapType(sType);
					String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
					if(!sCurrent.equals(ConstantsUtil.STATE_RELEASE)) {
						sId = ConstantsUtil.NO_ACCESS;
					}
					sCurrent = mapType(sCurrent);
					String sExpDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
					sExpDate = validator.DateFormatter(sExpDate);
					String sOriginator = (String) objectMap.get(DomainConstants.SELECT_ORIGINATOR);
					
					formatData(sbName, sName);
					formatData(sbId, sId);
					formatData(sbTitle, sTitle);
					formatData(sbType, sType);
					formatData(sbState, sCurrent);
					formatData(sbExpirationDate, sExpDate);
					formatData(sbOriginator, sOriginator);
					formatData(sbReleaseDate, sReleaseDate);
					formatData(sbRevision, sRevision);
				}
				mpReferencePart.put(ConstantsUtil.NAME, sbName.toString());
				mpReferencePart.put(ConstantsUtil.ID, sbId.toString());
				mpReferencePart.put(ConstantsUtil.TYPE, sbType.toString());
				mpReferencePart.put(ConstantsUtil.REVISION, sbRevision.toString());
				mpReferencePart.put(ConstantsUtil.TITLE, sbTitle.toString());
				mpReferencePart.put(ConstantsUtil.ORIGINATOR, sbOriginator.toString());
				mpReferencePart.put(ConstantsUtil.STATE, sbState.toString());
				mpReferencePart.put(ConstantsUtil.RELEASEDATE, sbReleaseDate.toString());
				mpReferencePart.put(ConstantsUtil.EXPIRATIONDATE, sbExpirationDate.toString());
			} catch (Exception e) {
	 	    	LOGGER.error("Error in parseReferencePart : "+e);
	 	    }
			return filterMapList(mpReferencePart);
		}
		//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- END

		// Added by Jwala for the defect 52952 -- START
		public boolean isSOPUNVDoc(Context context, String objId) {

			StringValidatorUtil validator = new StringValidatorUtil();
			boolean isSOPUNVDoc =false;
			MapList mlUnvDocList = new MapList();

			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_NAME);
			slBusSelects.add(ConstantsUtil.SELECT_ID);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIVERSALDOCUMENTRECIPIENTGROUP);

			try {
				if (UIUtil.isNotNullAndNotEmpty(objId)) {

					//DomainObject dob = new DomainObject(objId);
					DomainObject dob = DomainObject.newInstance(context, objId);
					mlUnvDocList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGUNIVERSALDOCUMENTTOSTANDARD,
							DomainConstants.QUERY_WILDCARD, slBusSelects, null, true, false, (short) 1,
							"current == Active", DomainConstants.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

					if(mlUnvDocList.size()!=0)
						isSOPUNVDoc = true;
				}

			}catch(Exception e) {
				LOGGER.error("Exception in program BusObjectAttribteUtil :isSOPUNVDoc ");
				return isSOPUNVDoc;
			}

			return isSOPUNVDoc;
		}
		// Added by Jwala for the defect 52952 -- END
		// Added by Jwala for the defect 52952 -- START
		public String getSOPUNVDocValue(Context context, String objId) {

			String IPMUnvRecipientGroup = ConstantsUtil.EMPTY_STRING;
			StringValidatorUtil validator = new StringValidatorUtil();
			MapList mlUnvDocList = new MapList();
			
			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_NAME);
			slBusSelects.add(ConstantsUtil.SELECT_ID);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIVERSALDOCUMENTRECIPIENTGROUP);

			try {
				if (UIUtil.isNotNullAndNotEmpty(objId)) {
					
					DomainObject dobj = DomainObject.newInstance(context, objId);
					mlUnvDocList = dobj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGUNIVERSALDOCUMENTTOSTANDARD,
							ConstantsUtil.SYMBL_ASTERISK, slBusSelects, null, true, false, (short) 1,
							"current == Active", ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
					
					Iterator objectListItr = mlUnvDocList.iterator();
					
					while (objectListItr.hasNext()) {
						Map objectMap = (Map) objectListItr.next();
						
						String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
						String sID = (String) objectMap.get(ConstantsUtil.SELECT_ID);
						IPMUnvRecipientGroup = (String) objectMap
								.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIVERSALDOCUMENTRECIPIENTGROUP);
					}
				}
				
			}catch(Exception ex) {
				LOGGER.error("Exception in program BusObjectAttribteUtil :isSOPUNVDoc ");
				return IPMUnvRecipientGroup;
			}
			return IPMUnvRecipientGroup;

		}
		// Added by Jwala for the defect 52952 -- END
		
		/**
		 * Added By Jwala For Comparision Req 21482 -- START
		 * This method will find Ownership of Obsolete Object
		 * @param context
		 * @param sObjectId
		 * @param DomainObject
		 * @throws Exception
		*/
		public StringList getObsoleteOwnership(Context context ,DomainObject domChild,String objectId) throws Exception {
			StringList slPlantsInfo = new StringList();
			StringValidatorUtil validator = new StringValidatorUtil();
			
			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtilIRM.MEP_OWNERSHIP);
			slSelects.add(ConstantsUtilIRM.SEP_OWNERSHIP);
			
			StringList slMEPOwnership = new StringList();
			StringList slSEPOwnership = new StringList();
			
			String sUserType = getUserType();
			if(UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = getUserView(context, objectId);
				}
			}
			String strRelPattern = "to[" +ConstantsUtil.RELATIONSHIP_MANUFACTURING_RESPONSIBILITY+ "].from." + DomainConstants.SELECT_NAME;
			try {
				if(sUserType.equals(ConstantsUtil.PG_SP)) {
					String command = "print bus " + objectId + " select history.connect";
					String result = MqlUtil.mqlCommand(context, command);
		            String strTemp = FrameworkUtil.split(result,"\n").toString();
		            slPlantsInfo = getCompanynamefromHistory(context,strTemp,slPlantsInfo);
		            //Checking Ownership from Connected MEP and SEP
		            Map slMEPInfo = domChild.getInfo(context, slSelects,addMultiSelects());
		            String sMEPOwnership = validator.getStringEquivalentForStringList(slMEPInfo.get(ConstantsUtilIRM.MEP_OWNERSHIP));
		            String sSEPOwnership = validator.getStringEquivalentForStringList(slMEPInfo.get(ConstantsUtilIRM.SEP_OWNERSHIP));
		            slMEPOwnership = filterOwnerShip(sMEPOwnership);
		            slSEPOwnership = filterOwnerShip(sSEPOwnership);

		            slPlantsInfo.addAll(slMEPOwnership);
		            slPlantsInfo.addAll(slSEPOwnership);
		            
		            LOGGER.info("Obsolete Parts Connected 111111 Vendor/Companys List ::: "+slPlantsInfo);
		           
				} else {
					slPlantsInfo = (StringList) domChild.getInfoList(context, strRelPattern);
				}
			} catch (Exception exc) {
				LOGGER.error("Exception in program BusObjectAttribteUtil :getObsoleteOwnership ");
				return slPlantsInfo;
			}
			return slPlantsInfo;
		}
		
		/**
		 * Added By Jwala For Comparision Req 21482 -- START
		 * This method will find Ownership of Obsolete Object from History only for Suppliers
		 * @param context
		 * @param sObjectId
		 * @param DomainObject
		 * @throws Exception
		*/
		
		public StringList getCompanynamefromHistory(Context context,String history, StringList slPlantsInfo) {
			
			String strCompanyName = DomainConstants.EMPTY_STRING;
			java.util.regex.Pattern strPattern =  	java.util.regex.Pattern.compile("Company\\s+(.*?)\\s*-");			
			strPattern.matcher(history);
			Matcher matcher = strPattern.matcher(history);
			while(matcher.find()) {
				strCompanyName = matcher.group(1).trim();
				if(!slPlantsInfo.contains(strCompanyName))
					slPlantsInfo.add(strCompanyName);
			}

			return slPlantsInfo;
		}
		public StringList addMultiSelects() {

			StringList slMultiSelects = new StringList();

			slMultiSelects.add(ConstantsUtilIRM.MEP_OWNERSHIP);
			slMultiSelects.add(ConstantsUtilIRM.SEP_OWNERSHIP);

			return slMultiSelects;
		}
		//SPEC: Modified by Subhajit for Req. no. 30189 START
		public Map<String,String> getExtendedAtrributes(Context context, String strobjId) throws Exception {

			Map<String, String> mAttributes = new HashMap<String, String> ();

			if(UIUtil.isNotNullAndNotEmpty(strobjId)) {
				try {
					InterfacePropertiesPageUtil ipageProperties = InterfacePropertiesPageUtil.getPagePropertiesContent(context, ConstantsUtilIRM.PAGE, ConstantsUtilIRM.EN);
					DomainObject domObj = DomainObject.newInstance(context, strobjId);
					BusinessInterfaceList bObjectInterfaceList = domObj.getBusinessInterfaces(context);

					if(null != bObjectInterfaceList && bObjectInterfaceList.size() > 0) {
						BusinessInterfaceItr biItr = new BusinessInterfaceItr(bObjectInterfaceList);

						while (biItr.next()) {
							BusinessInterface bObjectInterface = biItr.obj();
							AttributeTypeList attributeTypeList = bObjectInterface.getAttributeTypes(context);

							if( attributeTypeList != null && attributeTypeList.size() > 0 ) {
								String strInterfaceBackendName=bObjectInterface.getName();
								if(UIUtil.isNotNullAndNotEmpty(strInterfaceBackendName) && strInterfaceBackendName.startsWith(ConstantsUtilIRM.PREFIX)) {
									String strTemplateName = strInterfaceBackendName.replaceFirst("^"+ConstantsUtilIRM.PREFIX, DomainConstants.EMPTY_STRING).replaceFirst("\\.\\d+$", DomainConstants.EMPTY_STRING);
									if(UIUtil.isNotNullAndNotEmpty(strTemplateName)) {
										strTemplateName = ipageProperties.getPropertyName(ConstantsUtilIRM.TEMPLATE_PROPERTY_KEY+strTemplateName);
										String mAttributeNamesValues = getAttributeNamesAndValuesTildaSeparated(context, domObj, attributeTypeList);	
										mAttributes.put(strTemplateName, mAttributeNamesValues);
									}
								}
							}
						}
					}
				}
				catch (Exception e) {
					LOGGER.error("Exception in program BusObjectAttribteUtil :getExtendedAtrributes()");
				}
			}

			return mAttributes;
		}
		
		private String getAttributeNamesAndValuesTildaSeparated(Context context, DomainObject domObj, AttributeTypeList attributeTypeList) throws Exception {

			StringBuilder sballAtribute = new StringBuilder();
			StringValidatorUtil validator = new StringValidatorUtil();
			try {
				InterfacePropertiesPageUtil ipageProperties = InterfacePropertiesPageUtil.getPagePropertiesContent(context, ConstantsUtilIRM.PAGE, ConstantsUtilIRM.EN);

				Iterator attributeListItr = attributeTypeList.iterator();
				while (attributeListItr.hasNext()) {
					AttributeType attrtype = (AttributeType) attributeListItr.next();
					String strattribute = attrtype.getName();
					String strattriDataType = attrtype.getDataType(context);
					StringList slRange = attrtype.getChoices();
					if(strattribute.contains(ConstantsUtilIRM.CTA) ) {
						StringBuilder sbAtribute = new StringBuilder();
						String strAttributeVal = domObj.getInfo(context, ConstantsUtilIRM.ATTRIBUTE+"["+strattribute+"]");
						if(strattriDataType.equalsIgnoreCase(ConstantsUtilIRM.ATTRIBUTETYPE_TIMESTAMP)) {
							strAttributeVal = validator.DateFormatter(strAttributeVal);
						}
						//SPEC: Added by Ajay for Defect No. 83000 -- START
						if(slRange.contains(ConstantsUtil.SYMBL_YES) && slRange.contains(ConstantsUtil.KEY_NO) && slRange.size() == 2) {
							if(strAttributeVal.equals(ConstantsUtil.CONST_TRUE)) {
								strAttributeVal = ConstantsUtil.SYMBL_YES;
							}
							else {
								strAttributeVal = ConstantsUtil.KEY_NO;
							}
						}//SPEC: Added by Ajay for Defect No. 83000 -- END
						String strAttributeDisplayName = ipageProperties.getPropertyName(ConstantsUtilIRM.ATTRIBUTE_PROPERTY_KEY+strattribute);
						if(UIUtil.isNotNullAndNotEmpty(strAttributeDisplayName)){
							sbAtribute.append(strAttributeDisplayName);
							sbAtribute.append(ConstantsUtilIRM.SYMB_DOUBLE_EQUAL);//SPEC: Added by Ajay for Defect No. 82686 
							if(UIUtil.isNotNullAndNotEmpty(strAttributeVal)){
								sbAtribute.append(strAttributeVal);
								//SPEC: Added by Subhajit for Defect No. 82686 -- START
								if(slRange.size()> 0) {
									String strAttributeRangeValue = ipageProperties.getPropertyName(ConstantsUtilIRM.ATTRIBUTE_PROPERTY_KEY+strattribute+ConstantsUtilIRM.RANGE_KEY+strAttributeVal);
									if(UIUtil.isNotNullAndNotEmpty(strAttributeRangeValue)){
										sbAtribute.append(ConstantsUtil.SYMBL_TILDA);
										sbAtribute.append(strAttributeRangeValue);
									}
								}
								//SPEC: Added by Subhajit for Defect No. 82686 -- END
							} else {
								sbAtribute.append(DomainConstants.EMPTY_STRING);
							}
						}
						formatData(sballAtribute, sbAtribute.toString());
					}
				}
			} catch(Exception ex) {
				LOGGER.error("Exception in program BusObjectAttribteUtil :getAttributeNamesAndValuesTildaSeparated()");
			}

			return sballAtribute.toString();
		}
		
		//SPEC: Modified by Subhajit for Req. no. 30189 END
}
		
