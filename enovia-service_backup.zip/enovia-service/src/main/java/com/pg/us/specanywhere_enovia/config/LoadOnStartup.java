//testing for sonar PR for enovia service
package com.pg.us.specanywhere_enovia.config;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.pg.us.specanywhere_enovia.cp.EnoviaContext;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;	


	@Component
	public class LoadOnStartup
	{   

	    @EventListener(ApplicationReadyEvent.class)
	    public void loadData() throws Exception
	    {
	    	StopWatch sp = new StopWatch();
	    	sp.start();
	    	
	    	try {
			    sp.stop();
			    System.out.println("-CONNECTION TIME ON START UP:-"+sp.getTotalTimeMillis());
			    
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	    }
	}
