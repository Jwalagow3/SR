/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaASLServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.ApprovedSupplierListBO;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaASLService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;
import javax.servlet.http.HttpServletRequest;

public class EnoviaASLServiceImpl implements EnoviaASLService{

	private static Logger LOGGER = Logger.getLogger(EnoviaASLServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getASLdata(String oid, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();

		StopWatch sp = new StopWatch();
		sp.start();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("ASL CONTEXT ELAPSED TIME : "+swContext.getTime());

		try {
			
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, oid);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					// CM and Supplier Both are same
					bSupplierView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;
					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			ApprovedSupplierListBO asl = new ApprovedSupplierListBO();
			DomainObject doASL= asl.getASLDO(context,oid);	
			String strCurrent = doASL.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			//SPEC : 10/19/2020 : Security Check added for granting the access  -- START
			if(UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,oid);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + oid);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  -- END		
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String, String>();
			Map<String,String> mapSuplierInfo = new HashMap<String,String>();
			Map<String,String> mapInternalInfo = new HashMap<String, String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String, String>();
			//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- START
			Map<String,String> mpIpSecurity = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpRelatedSpecification = new HashMap<String,String>();
			Map<String,String> mpReferenceDocs = new HashMap<String,String>();
			//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- END
			
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- START
			Map<String,String> mpTechnicalSupersedes = new HashMap<String,String>();
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- END

			if (null == doASL) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("OBJECT NOT FOUND IN DB WITH OID : "+oid);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			Map BusinessObjectSelectableMap = asl.getApprovedSupplierListBasisSelectables(context);
			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

			//Map resultMaps = doASL.getInfo(context, slSelects);
			Map resultMaps = doASL.getInfo(context, slSelects,asl.addMultiList());
			
			
			/**
			 * Header Content SECTION
			 */
			StopWatch sHeader = new StopWatch();
			sHeader.start();
			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			Map mpHasATS=util.getRelatedAts(context, doASL);
			
			String strAttrValue = (String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGORIGINATINGSOURCE);
			String strObjSymbType = (String)resultMaps.get(ConstantsUtil.SELECT_TYPE);
			
			String strAllStates=	validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ATL_STATE));
			StringList slFromTypeState =FrameworkUtil.split(strAllStates, ",");
			
			boolean isDSO = (("DSO".equalsIgnoreCase(strAttrValue))?true:false);
			
			boolean isAPMP = doASL.isKindOf(context, ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART);
			boolean isTechSpec = doASL.isKindOf(context, ConstantsUtil.TYPE_TECHNICALSPECIFICATION);
			
			String sHasATSAttrVal = "No";
			boolean bCheckForATSValue = false;
			String strTechSpecTypes = "type_pgPackingInstructions,type_pgStackingPattern,type_pgIllustration,type_pgLaboratoryIndexSpecification,type_pgMakingInstructions,type_pgProcessStandard,type_pgQualitySpecification,type_pgStandardOperatingProcedure,type_TestMethodSpecification,type_FormulaTechnicalSpecification,type_pgAuthorizedConfigurationStandard";

			StringList slTechSpecTypes = FrameworkUtil.split(strTechSpecTypes, ",");
			if (isDSO) 
			{
				if ((isTechSpec && !slTechSpecTypes.contains(strObjSymbType)) || isAPMP)
				{
					sHasATSAttrVal = "N/A";
				}
				else
					bCheckForATSValue = true;
			}
			else
				bCheckForATSValue = true;
			
			if(bCheckForATSValue)
			{
				Iterator itr = slFromTypeState.iterator();
				String strATSState = "";
				StringList slObsoleteATS = new StringList();
				while (itr.hasNext()) {
				strATSState = itr.next().toString();
				if ("Release".equalsIgnoreCase(strATSState)) {
				sHasATSAttrVal = "Yes"; break;
				} 
				if ("Obsolete".equalsIgnoreCase(strATSState)) {
				slObsoleteATS.add(strATSState);
				}
				}
				if (slObsoleteATS.size() == slFromTypeState.size()) 
				{
					sHasATSAttrVal = "No";
					}
					if (slFromTypeState.size() == 0) {
					 sHasATSAttrVal = "";
				}
			}
			Map mphasATS=util.getRelatedAts(context, doASL);
			
			mphasATS=util.filterMapList(mphasATS);
			mpHeaderResult.put(ConstantsUtil.HASATS, sHasATSAttrVal);
			mpHeaderResult.put(ConstantsUtil.HEADERSAPDESC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			
			String sIsATS = ConstantsUtil.EMPTY_STRING;
			String sATSCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.REL_ATS_STATE));
			String sATSName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.REL_ATS_NAME));
			sIsATS = util.checkIsATSAttribute(sATSName,sATSCurrent);
			mpHeaderResult.put(ConstantsUtil.ISATS, sIsATS);
			//SPEC: 12/28/2020: Modified for SR18x.5.2 by Amman ## -- END
			mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			String sClassification = util.getClassification(resultMaps);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
			sHeader.stop();
			LOGGER.info("ASL Header ELAPSED TIME : "+sHeader.getTime());
			
			String strSAPname = validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_SAP_NAME));
			
			/**
			 * Attribute SECTION
			 */
			StopWatch swAttrib = new StopWatch();
			swAttrib.start();
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			strSAPname = strSAPname + ConstantsUtil.SYMBL_DOT + validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_SAP_REVISION));
			mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SEGMENT, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)));
			
			
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
			String sClassifictaion = util.getClassification(resultMaps);
			if(!bSupplierView){
				mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
			}
			swAttrib.stop();
			LOGGER.info("ASL GET Attribute ELAPSED TIME : "+swAttrib.getTime());

			
			/**
			 * Organization Data SECTION
			 */
			StopWatch swOrganization = new StopWatch();
			swOrganization.start();
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME))));
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME))));
			mpOrganization = util.filterMapList(mpOrganization);
			swOrganization.stop();
			LOGGER.info("ASL Organization ELAPSED TIME : "+swOrganization.getTime());

			
			/**
			 * Life-Cycle DATA
			 */
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={oid,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			mpLifeCycleApproval = util.getCOName(context, changeargs);
			swLifecycle.stop();
			LOGGER.info("ASL LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

			
			/**
			 * Ownership SECTION
			 */
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- START
			if(bAllInfoView) {
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- END
				StopWatch swOwnerShip = new StopWatch();
				swOwnerShip.start();
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, asl.getOriginatorName(context,resultMaps,ldapuser,ldappwd));
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.OWNINGSTANDARDOFFICE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, asl.getCoOwnersList(context, resultMaps,ldapuser,ldappwd));
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 12/28/2020: Modified for SR18x.5.2 by Amman ## -- START
				String sEDList = asl.getEDList(resultMaps,ldapuser,ldappwd);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- END
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
				swOwnerShip.stop();
				LOGGER.info("ASL OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- START
			}
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- END
			
			//try{
			/**
			 * Supplier Information SECTION
			 */
			//SPEC: 12/28/2020: Modified for SR18x.5.2 by Amman ## -- START
			
			//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 11, 2021 for Req #33248 -- START
			//SPEC: <12.07.2022>: Satyam modified for Internal Defect  -- START
			mapSuplierInfo = asl.GetSupplierInfo(context, resultMaps);
			mapSuplierInfo = util.filterMapList(mapSuplierInfo);
			//SPEC: <12.07.2022>: Satyam modified for Internal Defect  -- END
			
			/**
			 * Internal Information SECTION
			 */
			//SPEC: 12/28/2020: Modified for SR18x.5.2 by Amman ## -- START
			
			//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 11, 2021 for Req #33248 -- START
			if(bAllInfoView) {
				mapInternalInfo = asl.GetInternalInfo(context, resultMaps);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 11, 2021 for Req #33248 -- END
			
			String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String strBrand = util.getBrandInformationValue(context,sID);
			if(strBrand.isEmpty()) {
				strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
			}
			mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
			
			mapInternalInfo = util.filterMapList(mapInternalInfo);
			
			
			/**
			 * LOAD IP-CLASSES SECTION
			 * */
			StopWatch swIpSecurity = new StopWatch();
			swIpSecurity.start();
			mpIpSecurity =asl.getIpClass(context, doASL, asl.getIpSelects());
			swIpSecurity.stop();
			LOGGER.info("ASL IP CLASSes ELAPSED TIME : "+swIpSecurity.getTime());
			
			
			/**
			 * LOAD SECURITY SECTION
			 * */
			StopWatch swSecurity = new StopWatch();
			CommonBusUtilBO commonBO = new CommonBusUtilBO();
			swSecurity.start();
			//mpSecurity = commonBO.updateSecurity(context,resultMaps);
			mpSecurity = asl.updateSecurity(context,resultMaps);
			swSecurity.stop();
			LOGGER.info("ASL SECURITY CLASSes ELAPSED TIME : "+swSecurity.getTime());
			
			
			/**
			 * LOAD RELATED SPECIFICATIONS SECTION
			 * */
			StopWatch swSpec = new StopWatch();
			swSpec.start();
			mpRelatedSpecification = util.updatePartSpec(context,resultMaps);
			swSpec.stop();
			LOGGER.info("ASL Related Specs ELAPSED TIME : "+swSpec.getTime());
			
			
			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */
			StopWatch swReference= new StopWatch();
			swReference.start();
			mpReferenceDocs = asl.updateRefDocs(context, resultMaps);
			swReference.stop();
			LOGGER.info("ASL REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());
			
			
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- START
			/**
			 * Technical Supersedes SECTION
			 */
			//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 11, 2021 for Req #33248 -- START
			if(bAllInfoView) {
				mpTechnicalSupersedes = util.getTechnicalSupersedes(context, resultMaps);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 11, 2021 for Req #33248 -- END
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- END
			
			
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.SUPPLIERINFO, mapSuplierInfo);
			hmAttrib.put(ConstantsUtil.PGINTERNALINFO, mapInternalInfo);
			//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- START
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecification);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mpReferenceDocs);
			//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- END
		
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- START
			hmAttrib.put(ConstantsUtil.TECHSUPERSEDES, mpTechnicalSupersedes);
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- END
			
			//SPEC: <12.07.2022>: Satyam modified for Internal Defect  -- START
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.IPSECURITY, mpIpSecurity);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: <12.07.2022>: Satyam modified for Internal Defect  -- END
			pool.checkIn(context);
			sp.stop();
			LOGGER.info("ASL MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "ASL OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			
		} catch (IOException e) {
			LOGGER.error("Unable to getASLdata"+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getASLdata"+e);
		}
		//LOGGER.info("ASL RESPONSE MESSAGE:: \n" + hmAttrib);
		context.close();
		return hmAttrib;
	}

}
