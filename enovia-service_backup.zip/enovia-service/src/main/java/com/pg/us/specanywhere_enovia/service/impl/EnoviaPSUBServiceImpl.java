package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaCardBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PackingSubassemblyBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaPSUBService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaPSUBServiceImpl implements EnoviaPSUBService {

	private static Logger LOGGER = Logger.getLogger(EnoviaPSUBServiceImpl.class);

	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String,String>> getPSUBdata(String objId, Environment env) throws Exception {
		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		try {

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- START
			/*StopWatch swContext = new StopWatch();
			swContext.start();
			//EnoviaConnectionPool pool = new EnoviaConnectionPool(USER,PASS,VAULT);
			Context context = pool.checkOut();
			swContext.stop();*/
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- START
			LOGGER.info("PSUB CONTEXT ELAPSED TIME : "+swContext.getTime());
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}

			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			


			ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);

			if(UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;

				}
			}

			PackingSubassemblyBO psubbo = new PackingSubassemblyBO();
			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			FormulaCardBO fcBO = new FormulaCardBO();
			Map BusinessObjectSelectableMap = psubbo.getPackingSubassemblySelectableMap(context);

			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mapAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpHasATS = new HashMap<String,String>();
			Map<String,String> mpIsATS = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpTechnicalSupersedesBy = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mapCosResult = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();

			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			Map BusinessObjectRelSelectableMap = psubbo.getPSUBRelatedObjsSelectableMap(context);

			DomainObject doPSUB = psubbo.getPSUBDO(context, objId);
			MasterCOPBO mcop = new MasterCOPBO();
			FinishedProductPartBO fppBO = new FinishedProductPartBO();

			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMap = doPSUB.getInfo(context, slSelects);
			Map resultMap = doPSUB.getInfo(context, slSelects,psubbo.addMultiList());
			swAttributes.stop();
			LOGGER.info("PSUB GETINFO ELAPSED TIME : "+swAttributes.getTime());

			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			String sID = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			/**
			 * LOAD HEADER SECTION
			 * */
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)))?busUtil.mapType((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.PSUB_PGMASTER)))?(String)resultMap.get(ConstantsUtil.PSUB_PGMASTER) : ConstantsUtil.EMPTY_STRING);
			String sClassification = busUtil.getClassification(resultMap);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));

			mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.PSUB_PGMASTERTYPE))));
			mpHeaderResult.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.PSUB_PGMASTERID))));

			/**
			 * LOAD RELATED ATS SECTION
			 * */
			StopWatch swAts = new StopWatch();
			swAts.start();
			mpRelatedATS=busUtil.getRelatedAts(context, doPSUB);

			mpRelatedATS=busUtil.filterMapList(mpRelatedATS);
			if(!mpRelatedATS.isEmpty()){
				mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
			}else{
				mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
			}

			if(bManufacturerView) {
				mpRelatedATS=busUtil.filterPhase(mpRelatedATS);
			}

			String sIsATS = "";
			String sATSCurrent = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.REL_ATS_STATE));
			String sATSName = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.REL_ATS_NAME));
			sIsATS =busUtil.checkIsATSAttribute(sATSName,sATSCurrent);

			mpHeaderResult.put(ConstantsUtil.ISATS, sIsATS);

			swAts.stop();
			LOGGER.info("PSUB ATS ELAPSED TIME : "+swAts.getTime());

			if(bAllInfoView || bManufacturerView || bSupplierView){
				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID)))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				String strBrand = busUtil.getBrandInformationValue(context,sID);

				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mapAttribResult.put(ConstantsUtil.BRAND, strBrand);
				mapAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.WAREHOUSECLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.REERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.REERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				String sClassifictaion = busUtil.getClassification(resultMap);
				mapAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));
				String strPackTech = (String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY);
				strPackTech = strPackTech.replace(ConstantsUtil.SYMBL_PIPE, "\n");
				mapAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (strPackTech));

				/**
				 * Is ATS
				 */
				mpIsATS = busUtil.checkIsATS(context,resultMap);


				if(!bSupplierView) {
					/**
					 * LOAD MARKETS OF SALE SECTION
					 * */

					String strCosDateAndTime = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE));
					FabricatedPartBO FABBO = new FabricatedPartBO();
					mapCosResult = FABBO.getMarketOfSale(context,sContextObjectId);
					mapCosResult.put(ConstantsUtil.DATEANDTIMEOFLASTMOSCALC, strCosDateAndTime);
					mapCosResult.put(ConstantsUtil.POAOVERRIDELEGALREQORKREQUIRED, DomainConstants.EMPTY_STRING);
					mapCosResult = busUtil.filterMapList(mapCosResult);
				}

			}

			if(bAllInfoView || bSupplierView){
				mapAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);

			}

			if(bManufacturerView || bAllInfoView){

				mapAttribResult.put(ConstantsUtil.PGASLALLOCATION, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING));

			}


			if(bAllInfoView){

				mapAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.ISBATTERY, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
				mapAttribResult.put(ConstantsUtil.DOESTHEPRODUCTCONTAINBATTERY, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY) : ConstantsUtil.EMPTY_STRING));
				mapAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.CUSTOMIZATIONTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);

				/**
				 * Has ATS
				 */
				mpHasATS = busUtil.checkHasATS(context,resultMap);

				/**
				 * Technical SupersedesBy 
				 */

				mpTechnicalSupersedesBy=busUtil.getTechnicalSupersedesBy(context, resultMap);

				/**
				 * LOAD ORGANIZATION DATA SECTION
				 * */
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = busUtil.filterMapList(mpOrganization);

				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */

				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = fcBO.updateRefDocs(context, resultMap);
				swReference.stop();
				LOGGER.info("PSUB  REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());

				StringList OWSOffice =  busUtil.getStringListWithComma(validator.getStringEquivalentForStringListWithComma(resultMap.get(ConstantsUtil.OWNING_STANDARD_OFFICE)));
				String strAttributeValue ="";
				if(OWSOffice!=null)
				{
					if(OWSOffice.size() > 1)
					{
						for(int i=0;i<=OWSOffice.size()-2;i++)
						{
							strAttributeValue = strAttributeValue+(String)OWSOffice.get(i) +"<br>";
						}
						strAttributeValue = strAttributeValue+(String)OWSOffice.get(OWSOffice.size()-1);
					}
					else
					{
						strAttributeValue = (String)OWSOffice.get(0);
					}

				}

				/**
				 * LOAD SECURITY SECTION
				 * */
				StopWatch swSecurity = new StopWatch();
				swSecurity.start();
				mpSecurity =fcBO.getSecurityClass(context,sID,ConstantsUtil.TYPE_SECURITYCONTROLCLASS);
				swSecurity.stop();
				LOGGER.info("PSUB Security ELAPSED TIME : "+swSecurity.getTime());

				/**
				 * LOAD IP Class
				 * */
				mpIPClass =fcBO.getSecurityClass(context,sID,ConstantsUtil.TYPE_IPCONTROLCLASS);

			}

			if(bAllInfoView || bManufacturerView || bSupplierView){
				hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
				hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mapAttribResult);
				hmAttrib.put(ConstantsUtil.ISATS, mpIsATS);
			}
			if(bAllInfoView || bManufacturerView ){
				hmAttrib.put(ConstantsUtil.MARKETOFSALE, mapCosResult);
			}
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.HASATS, mpHasATS);
				hmAttrib.put(ConstantsUtil.TECHSUPERSEDESBY, mpTechnicalSupersedesBy);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
				hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
			}

			//LOGGER.info("PSUB RESPONSE MESSAGE:: \n" + hmAttrib);

			ContextUtil.popContext(context);
			pool.checkIn(context);
			sp.stop();
			LOGGER.info("PSUB MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "PSUB OBJECT NAME::"+resultMap.get(ConstantsUtil.SELECT_NAME));
		} catch (IOException e) {
			LOGGER.error("IOException from PSUB "+e);
		} catch (MatrixException e) {
			LOGGER.error("MatrixException from PSUB "+e);
		}
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		context.close();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmAttrib;
	}
}
