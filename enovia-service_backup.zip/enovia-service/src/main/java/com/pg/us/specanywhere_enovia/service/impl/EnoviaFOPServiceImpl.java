/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaFOPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.bo.SapBomAsFed;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.fop.FOPSubstitute;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaFOPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaFOPServiceImpl implements EnoviaFOPService {


	private static Logger LOGGER = Logger.getLogger(EnoviaFOPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getFOPdata(String objId, String sCompr, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		try {
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- START
			/*StopWatch swContext = new StopWatch();
			swContext.start();
			Context context = pool.checkOut();
			swContext.stop();*/
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- END
			LOGGER.info("FOP CONTEXT ELAPSED TIME : "+swContext.getTime());

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
				
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			FormulaPartBO formulationPartBO = new FormulaPartBO();
			DomainObject doFop =  formulationPartBO.getFopDO(context, objId);
			String strCurrent = doFop.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END

			//SPEC : 10/19/2020 : Security Check added for granting the access  --START

			if(UIUtil.isNotNullAndNotEmpty(sUserType) && sCompr!=ConstantsUtilIRM.STATE_PRILIMNARY)
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;

				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}
			else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}

			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mapWeightCharResult = new HashMap<String,String>();
			Map<String,String> mpFormulationProcess = new HashMap<String,String>();
			Map<String,String> mpFormulaIngr = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpPerformChar = new HashMap<String,String>();
			Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
			Map<String,String> mpPhyChemEngLegacyData = new HashMap<String,String>();
			Map<String,String> mpPhyChemEngWareHouse = new HashMap<String,String>();
			Map<String,String> mpPhysicalChemicalGHCProp = new HashMap<String,String>();
			Map<String,String> mpMaterialProduced = new HashMap<String,String>();
			Map<String,String> mpDangerousGoodsClf = new HashMap<String,String>();
			Map<String,String> mpGlobalHarStandard = new HashMap<String,String>();
			Map<String,String> mpStability = new HashMap<String,String>();
			Map<String,String> mpSubstitute = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mpMasterAttributes = new HashMap<String,String>();
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mapCountryClearanceResult = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String, String>();
			Map<String,String> mapCertifications = new HashMap<String, String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();

			//SPEC: <01.08.2021>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
			Map MPFinalFBOM = new HashMap();
			Map mpFinalFBOM = new HashMap();
			//SPEC: <01.08.2021>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS

			//SPEC: 9/30/2020 Added for 18.5x Dev -- START
			Map<String,String> mpSecurity = new HashMap<String, String>();
			Map<String,String> mpMaterialResult = new HashMap<String,String>();
			Map<String,String> mpProductPartStabilityDoc = new HashMap<String,String>();
			Map<String,String> mpMasterPartStabilityDoc = new HashMap<String,String>();
			//SPEC: 9/30/2020 Added for 18.5x Dev -- END

			//SPEC: 9/30/2020 Defect# 35817
			Map<String,String> mapMaterialResult = new HashMap<String,String>();
			//SPEC: 9/30/2020 Defect# 35817 - END

			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- START
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			Map<String,String> mpCertificationvalidation = new HashMap<String,String>();
			Map<String,String> mpIngredientstatement = new HashMap<String,String>();
			Map<String,String> mpSmartLabel = new HashMap<String,String>();
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- END

			BusObjectAttribUtil util = new BusObjectAttribUtil();
			//SPEC: 9/30/2020 Defect# 35817 - START
			DeviceProductPartBO DPPBO = new DeviceProductPartBO();
			//SPEC: 9/30/2020 Defect# 35817 - END
			Map<String, StringList> BusinessObjectSelectableMap = formulationPartBO.getFopSelectables(context);
			StringList slBusSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- START
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slBusSelects.add(ConstantsUtil.ATL_STATE);
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 23 Feb 2021 -- START
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_VAPOUR_DENSITY);
			
			StringList slRelSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);

			if(null==doFop) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			StopWatch swAttributes = new StopWatch();
			String strSelectSegment = "to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME;
			slBusSelects.add(ConstantsUtil.CERTIFICATION_NAME);
			slBusSelects.add(strSelectSegment);
			swAttributes.start();
			//Map resultMaps = doFop.getInfo(context, slBusSelects,formulationPartBO.getFileSelects(context));
			Map resultMaps = doFop.getInfo(context, slBusSelects,formulationPartBO.addMultiValueConstants());
			swAttributes.stop();

			String strMaterialCertification=	validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.CERTIFICATION_NAME));
			strMaterialCertification = strMaterialCertification.replace("|", ",");
			LOGGER.info("FOP GETINFO ELAPSED TIME : "+swAttributes.getTime());

			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			//SPEC: Added for the Defect #39123 -- Start
			String sContextType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			//SPEC: Added for the Defect #39123 -- Start
			String sClassifictaion = util.getClassification(resultMaps);
			String strCertificationvalidation = DomainConstants.EMPTY_STRING;//SPEC: 06/24/2022: Added by Ketan for Req no. 38897

			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			// Plant Autharizetouse FALSE for CM View
			boolean bAuthorizedtoUse = util.isAuthorizedtoUse(context,doFop,resultMaps,strPDFView);
			boolean bGendocView=false;
			boolean bAuthorizedtoProduce = util.isAuthorizedtoProduce(context,doFop,resultMaps,strPDFView);
			
			if(bManufacturerView && bAuthorizedtoProduce) {
				bGendocView=true;
			}
			
			//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- START
			boolean isExternal=util.isModificatinRequired();
			//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- END
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(bGendocView){
				mpHeaderResult.put(ConstantsUtil.VIEW, ConstantsUtil.GENDOCVIEW);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			//IP Security Setting
			StringList slIpSelects = new StringList();
			slIpSelects.add(ConstantsUtil.SELECT_NAME);
			slIpSelects.add(ConstantsUtil.SELECT_ID);
			slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
			slIpSelects.add(ConstantsUtil.SELECT_TYPE);
			slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);

			MapList mlFormulation = doFop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE, ConstantsUtil.TYPE_COSMETICFORMULATION, slIpSelects,
					null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			Iterator itr = mlFormulation.iterator();
			Map mpFormulation = new HashMap();
			while(itr.hasNext()) {
				mpFormulation = (Map)itr.next();
			}

			StringBuilder sbIpName = new StringBuilder();
			StringBuilder sbIpType = new StringBuilder();
			StringBuilder sbIpDesc = new StringBuilder();
			StringBuilder sbIpState = new StringBuilder();
			
			if(!mpFormulation.isEmpty()){
				String sFormulationOid = (String) mpFormulation.get(ConstantsUtil.SELECT_ID);
				DomainObject doFormObj = new DomainObject(sFormulationOid);
				MapList mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
						null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
						ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doFormObj.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				itr = mlIPCLass.iterator();
				Map mpIpClass = new HashMap();

				while(itr.hasNext()) {
					mpIpClass = (Map)itr.next();
					String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
					sbIpName.append(sIpClassName);
					sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
					sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
					sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));

					//Added "|" by Jwala for internal defect 90320855 -- START
					if(itr.hasNext()) {
						sbIpName.append("|");
						sbIpType.append("|");
						sbIpDesc.append("|");
						sbIpState.append("|");
					}
				}
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START
			if (!bManufacturerView && !bAllInfoView && !bGendocView) 
			{
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END
				mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
				mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
				mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
				mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
			}

			if(bAllInfoView || bManufacturerView || bGendocView) {
				StopWatch swOthers = new StopWatch();
				swOthers.start();
				/**
				 * Basic  Data
				 */
				mapStorageAndLabelResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.FORMULATIONTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strKeyFormulationType)))?(String)resultMaps.get(ConstantsUtil.strKeyFormulationType) : ConstantsUtil.EMPTY_STRING);

				//SPEC: <11.05.2020>: Modified for Defect 37136 ## -- START
				//mpAttribResult.put(ConstantsUtil.FORMULATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strKeyFormulation)))?(String)resultMaps.get(ConstantsUtil.strKeyFormulation) : ConstantsUtil.EMPTY_STRING);		
				mpAttribResult.put(ConstantsUtil.FORMULATION, util.formulationAttribute(context, sContextObjectId));
				//SPEC: <11.05.2020>: Modified for Defect 37136 ## -- END

				mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);

				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strPGBrand)))?(String)resultMaps.get(ConstantsUtil.strPGBrand) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);

				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);

				//Modified for Defect #37478 -- START
				//mpAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.RELATIONSHIP_OWNINGPRODUCTLINE_PGPLIPRODUCTFORM_NAME)))?(String)resultMaps.get(ConstantsUtil.RELATIONSHIP_OWNINGPRODUCTLINE_PGPLIPRODUCTFORM_NAME) : ConstantsUtil.EMPTY_STRING);
				//Modified for Defect #37478 -- END

				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strPGPDTTOPGPLIREFUN)))?(String)resultMaps.get(ConstantsUtil.strPGPDTTOPGPLIREFUN) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ONSHELFPRODDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);


				String strIntendMarket = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.strIntendedMarket));
				mpAttribResult.put(ConstantsUtil.INTENDEDMARKETS, strIntendMarket);

				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPLACE_PROD_ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.UNIQUE_FORMULA_IDENTIFIER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);

				//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- START
				mpAttribResult.put(ConstantsUtilIRM.SMARTLABELREADY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SMARTLABENREADY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SMARTLABENREADY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.CLONETRANSFERRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.PRODUCTDOSECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.REASONFORMANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- END
				//Added by Subhajit for Req 46464 - Start
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				//Added by Subhajit for Req 46464 - End
				//Added by Ajay for Req 7790 - START
				mpAttribResult.put(ConstantsUtil.AUTHORINGAPPLICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION) : ConstantsUtil.EMPTY_STRING);
				//Added by Ajay for Req 7790 - END
				//SPEC: <11.24.2020>: Added for Defect #37534 -- Start
				String strOnshelfDensicty = (String)mpAttribResult.get(ConstantsUtil.ONSHELFPRODDENSITY);
				if(strOnshelfDensicty.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					mpAttribResult.put(ConstantsUtil.ONSHELFPRODDENSITY, ConstantsUtil.GEN_NUM_ZERO);
				//SPEC: <11.24.2020>: Added for Defect #37534 -- END

				/**
				 * Header Content
				 */
				mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				if(!bGendocView)
				mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START
				mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
				mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END

				//Added for 36405 - END
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START
				if(!bManufacturerView && !bSupplierView && !bAllInfoView && !bGendocView){
					mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				}
				if(!bManufacturerView && !bGendocView)
				{
					mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
					mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END
				mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion); 
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 19 March 2021 -- START
				mpHeaderResult.put(ConstantsUtil.PDF_VIEW, bGendocView ? ConstantsUtil.GENDOC_VIEW : util.getPdfViewtype(bAllInfoView, bGendocView, bSupplierView));
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 19 March 2021 -- END
				
				if((strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) && bGendocView)) {
					mpHeaderResult.put(ConstantsUtil.PDF_VIEW,ConstantsUtil.GENDOC_VIEW);
				}

				/**
				 * STORATE TRANSPORT Content
				 */
				mapStorageAndLabelResult.put(ConstantsUtil.STR_TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTMARKETEDASCHILDREN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.DOESTHEPRODUCTREQUIRECHILDSAFEDESIGN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);        
				mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTEXPOSEDTOCHILDREN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.DANGEROUSGOODSCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.UNSPECIFICATIONPACKAGINGMATERIALREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.CUSTOMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.CONSUMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS)));
				//mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS)))?(String)resultMaps.get(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);

				mapStorageAndLabelResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.WAREHOUSECLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);

				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				if(!bManufacturerView && !bAllInfoView) {
					mapStorageAndLabelResult.put(ConstantsUtil.INTENDEDMARKETS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- END

				mapStorageAndLabelResult = util.filterMapList(mapStorageAndLabelResult);


				/**
				 * chemicalAndPhysicalPropertiesEnginuityLegacyData
				 */
				mpPhyChemEngLegacyData.put(ConstantsUtil.WTPERCENTPARAMETERIZED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWTPARAMETERIZED_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWTPARAMETERIZED_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngLegacyData.put(ConstantsUtil.PROPELLAMTISNONFLAMMABLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPELLANTNONFLAMMABLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPELLANTNONFLAMMABLE) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngLegacyData.put(ConstantsUtil.PROPELLANTEMULSIFIEDFORLIFEOFPROD, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPELLANTEMULSIFIEDPRODUCT_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPELLANTEMULSIFIEDPRODUCT_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngLegacyData.put(ConstantsUtil.KSTDUSTDEFLATIIONINDEXINBARMPSEC,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKSTDUSTDEFLAGRATIONINDEX_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKSTDUSTDEFLAGRATIONINDEX_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngLegacyData.put(ConstantsUtil.PMAXEXPOLOSIONPRESSUREINBAR,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPMAXEXPLOSIONPRESSURE_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPMAXEXPLOSIONPRESSURE_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngLegacyData = util.filterMapList(mpPhyChemEngLegacyData);

				/**
				 * chemicalAndPhysicalPropertiesWarehouseClassification
				 */
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISTHEPROPELLANTFLAMABLEORNONFLAMMBLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.PERCENTBYWEIGHTOFFLAMMABLEPROPELLANTINAEROCONTAINER,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTLESSWBYVOLANDBYWATERMISCALCHOL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTLESSWBYVOLANDBYWATERETPLUSISO,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISTHEBASEPDTNOPROPELLANTSUSTAINCOMBUSTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISTHEBASEPRODUCTHAVEAFIREPOINT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT) : ConstantsUtil.EMPTY_STRING);	
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTCONTAINGTWANDLESSTHBYWTLNIGP,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTCONTAINGTWANDLESSBYWTLIGP,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse = util.filterMapList(mpPhyChemEngWareHouse);

				/**
				 * chemicalAndPhysicalPropertiesGHCDGCClassification
				 */
				
				//SPEC: 07.11.2024: Jwala Added for Req 11640 Sprint 12 Release  -- START
				APPBO APPBO = new APPBO();
				mpPhysicalChemicalGHCProp =APPBO.getMeltingpointDetails(context, resultMaps);
				//SPEC: 07.11.2024: Jwala Added for Req 11640 Sprint 12 Release  -- END
				
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- END
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.SELDACCELERATINGDECOMPOSITIONTEMPERATURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSELFACCELDECOMTEMP_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSELFACCELDECOMTEMP_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				//mpPhysicalChemicalGHCProp.put(ConstantsUtil.EVAPORATION_RATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.BURNRATEINMMPERSEC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBURNRATE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBURNRATE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.RESERVE_ACIDITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.RESERVE_ALKANITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				//mpPhysicalChemicalGHCProp.put(ConstantsUtil.KINEMATICVISCOSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.AVAILABLEOXYGENCONTENTINPARCENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AVAILABLE_OXYGEN_CONTENT_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AVAILABLE_OXYGEN_CONTENT_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.BOILINGPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 21-06-2022: Satyam Added for Internal Defect -- START
				if(bAllInfoView || bManufacturerView || bGendocView) {
					mpPhysicalChemicalGHCProp.put(ConstantsUtil.CLASEDCUPFLASHPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
					mpPhysicalChemicalGHCProp.put(ConstantsUtil.VAPORDENSITY,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPOUR_DENSITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPOUR_DENSITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
					mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.DOESTHEFORMULACONTAINWATER,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISTHELIQUIDANAQEOUSSOLUTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISTHELIQUIDANAQEOUSSOLUTION) : ConstantsUtil.EMPTY_STRING);
				}
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.RELATIVEDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.VAPORPRESSURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PROPERTIESORISITTHERMALLYUNSTABLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.HEADOFDECOMPOSITIONINKJPERGRAM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTHAVEANYSPELFREACTIVE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISAFLAMMABLELIQUIDABSORBEDORCONTAINEDWITHINTHESOLID,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_LIQUID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_LIQUID) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CONDUCTIVITYOFTHELIQUID,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONDUCTIVITYOFTHELIQUID_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONDUCTIVITYOFTHELIQUID_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISTHELIQUIDCORROSIVETOMETAL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_LIQUID_CORROSIVE_TO_METAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_LIQUID_CORROSIVE_TO_METAL) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESPRODUCTCONTAINANORGANICPEROXIDEASRAWMATERIAL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ORGANIC_PEROXIDE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ORGANIC_PEROXIDE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTHAVETHEPOTENTIALTOINCREASETHEBURNINGRATEORINTENSITYOFACOMBUSTIBLESUBSTANCE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPOTENTIALTOINCREASEBURNINGRATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPOTENTIALTOINCREASEBURNINGRATE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISTHEOXIDIZERHYDROGENPEROXIDELESSTHANEIGHTPERSONT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISTHEOXIDIZERSODIUMPERCARBONATELESSTHENSIXTYPERCENT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTCONTAINANOXIDIZERASRAWMATERIAL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTOXIDIZER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTOXIDIZER) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTSUSTAINCOMBUSTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCTSUSTAINCOMBUSTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCTSUSTAINCOMBUSTION) : ConstantsUtil.EMPTY_STRING);//Modified by Ketan for Defect no. 54744
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.BOLINGPOINTVALUE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BOILINGPOINTVALUE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BOILINGPOINTVALUE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CONDUCTIVITYOFTHECONTENTSINTHEAEROSOLCAN,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.TECHNICALBASISFORTHECORROSIVETOMETALSDETERMINATIONPROVIDED,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_TECHNICAL_CTM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_TECHNICAL_CTM) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ARETHECONTENTSOFTHEAEROSOLCANCORROSIVETOMETALS,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PHDILUTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_DILUTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_DILUTION) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.FOAMFLAMMBILITYTESTFLAMEDUTIONINSEC,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEDURATION_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEDURATION_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.FOAMFLAMMABILITYTESTFLAMEHEIGHT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEHEIGHT_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEHEIGHT_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ENCLOSEDSPACEIGNITIONTIMEEQUIALENT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENCLOSEDSPACEIGNITION_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENCLOSEDSPACEIGNITION_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.IGNITIONDISTANCEINCM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIGNITIONDISTANCE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIGNITIONDISTANCE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISAEROSOLTESTDATANEEDED,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.AEROSOLTYPE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOLTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOLTYPE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.GAUGEPRESSUREINKPA,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CANCONSTRUCTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CAN_CONSTRUCTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CAN_CONSTRUCTION) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.HEATOFCOMBUSTIONONKJ,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: 07.04.2022: Jwala Added for Defect 20500  -- START
				//mpPhysicalChemicalGHCProp.put(ConstantsUtil.ODOUR,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR) : ConstantsUtil.EMPTY_STRING);
				String strODOUR = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR));
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ODOUR,strODOUR);
				//SPEC: 07.04.2022: Jwala Added for Defect 20500  -- END
				
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.COLORINTENSITY,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_COLOR_INTENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_COLOR_INTENSITY) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.COLOR,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOLOR_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOLOR_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);

				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGIPHDATAAVAILABLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPHDATAAVAILABLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPHDATAAVAILABLE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGPHMIN,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMIN_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMIN_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGPHMAX,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMAX_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMAX_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGRESERVEALKALINITYUOM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYUOM) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGRESERVEALKALINITYTITRATIONENDPOINT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYTITRATIONENDPOINT_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYTITRATIONENDPOINT_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DYNAMICVISCOSITY,((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE)))?((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE)).concat(ConstantsUtilIRM.SPACE_C) : ConstantsUtil.EMPTY_STRING));//Modified By Ajay for the Defect 19156
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.EVAPORATION_RATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				if(!bManufacturerView && !bGendocView)
				{
					mpPhysicalChemicalGHCProp.put(ConstantsUtil.KINEMATICVISCOSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
					mpPhysicalChemicalGHCProp.put(ConstantsUtil.PHAVAILABILITY,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_AVAILABILITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_AVAILABILITY) : ConstantsUtil.EMPTY_STRING);
				}
				mpPhysicalChemicalGHCProp = util.filterMapList(mpPhysicalChemicalGHCProp);

				mpStability =util.getWeightProdcutValue(context,resultMaps);

				mpStability.put(ConstantsUtil.PRODUCTEXPDATEREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TOTALSHELFLIFEDAYS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TEMPERATUREGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.HUMIDITYGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TRANSPORTHEATPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.BOUNDARYCONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.STABILITYREPORTLINK, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE) : ConstantsUtil.EMPTY_STRING);

				swOthers.stop();
				LOGGER.info("FOP ATTRIBUTE, STORAGE, PHYS, CHEM, STABILITY ELAPSED TIME : "+swOthers.getTime());

				if ((bManufacturerView && !bAuthorizedtoUse) || bAllInfoView || bGendocView){

					/**
					 * Formulation Process
					 */
					StopWatch swFormulation = new StopWatch();
					swFormulation.start();
					MapList mlFormulationProcess = doFop.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_PLANNEDFOR, ConstantsUtil.TYPE_FORMULATIONPROCESS, slBusSelects,
							null, false, true, (short) 1, null, null, 0);



					swFormulation.stop();
					LOGGER.info("FOP FORMULATION ELAPSED TIME : "+swFormulation.getTime());

					if(bManufacturerView) {
						mlFormulationProcess=util.filterPhase(mlFormulationProcess);
					}


					SecurityService sec = new SecurityService();
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);
					String sUserlicense = sec.getUserLicense();

					StringList slHIRTypes = new StringList();

					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);


					if(mlFormulationProcess.size()>0) {
						Map mMasterData = (Map)mlFormulationProcess.get(0);

						String strFPID = (String)mMasterData.get(ConstantsUtil.SELECT_ID);
						String FormulationTitle = (String) mMasterData.get(ConstantsUtil.SELECT_NAME);
						String[] parts = FormulationTitle.split(ConstantsUtil.SYMBL_DASH);
						String FormulationName = parts[0];
						String FormulationRevision=(String)mMasterData.get(ConstantsUtil.SELECT_REVISION);
						String FormulationProcessName=(String)mMasterData.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
						String FormulationStage=(String)mMasterData.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
						String FormulationState=(String)mMasterData.get(ConstantsUtil.SELECT_CURRENT);
						String FormulationType=(String)mMasterData.get(ConstantsUtil.SELECT_TYPE);
						String sFormulationType=(String)mMasterData.get(ConstantsUtil.STR_FORMULATION_TYPE);

						DomainObject domObjectIdd = DomainObject.newInstance(context,strFPID);

						MapList mlFormulaIngredients = new MapList();
						Map mpFormulaIngredients = new HashMap();
						String strFindNum = ConstantsUtil.EMPTY_STRING;

						StringList slBusSelect =  new StringList();
						slBusSelect.addAll(formulationPartBO.getFormulaIngredients(context));

						StringList slRelSelect =  new StringList();
						slBusSelect.addAll(formulationPartBO.getRelFormulaIngredients(context));

						StopWatch swIngredients = new StopWatch();
						swIngredients.start();
						mlFormulaIngredients = domObjectIdd.getRelatedObjects(context, //Context
								ConstantsUtil.REL_FBOM, //relPattern
								ConstantsUtil.QUERY_WILDCARD, //typePattern
								slBusSelects, //objectSelects
								slRelSelects,// relationshipSelects
								false, //getTo - Get Parent Data
								true, //getFrom - Get Child Data
								//SPEC: <01.08.2021>: Modified for Req :36032 by Sumit #(BOM Expansion)# --START
								(short)0, //recurseToLevel
								//SPEC: <01.08.2021>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
								ConstantsUtil.EMPTY_STRING, //objectWhere
								ConstantsUtil.EMPTY_STRING,
								ConstantsUtil.ZERO_LEVEL); //relationshipWhere

						Boolean findNumberIsNotEmpty = true;
						String strType = ConstantsUtil.EMPTY_STRING;
						String strName = ConstantsUtil.EMPTY_STRING;
						String strState = ConstantsUtil.EMPTY_STRING;;
						String strRev = ConstantsUtil.EMPTY_STRING;
						String strSequenceNum = ConstantsUtil.EMPTY_STRING;
						String strSortSequence = ConstantsUtil.EMPTY_STRING;
						String strSequenceNum2 = ConstantsUtil.EMPTY_STRING;
						String strSortSequence1 = ConstantsUtil.EMPTY_STRING;
						MapList mlFormulaIngredientSort = new MapList();

						for (int i = 0; i <mlFormulaIngredients.size(); i++){
							mpFormulaIngredients = (Map) mlFormulaIngredients.get(i);
							strFindNum = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
							if(!validator.isNotNullOrEmpty(strFindNum) || strFindNum.equalsIgnoreCase("NaN"))
							{
								strFindNum = ConstantsUtil.GEN_NUM_ZERO;
								findNumberIsNotEmpty=false;
							}
							strType = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_TYPE);
							if(strType.equals(ConstantsUtil.TYPE_FORMULATIONPHASE)){
								strSequenceNum  = strFindNum;
								strSortSequence = strFindNum.concat(ConstantsUtil.GEN_NUM_DOUBLEZEOR);
								strSequenceNum2 = strSequenceNum;
								strSortSequence1 = strSortSequence;
							}
							else {
								strSequenceNum =strSequenceNum2.concat(ConstantsUtil.SYMBL_DOT).concat(strFindNum);
								strSortSequence=Integer.toString(Integer.valueOf(strSortSequence1) + Integer.valueOf(strFindNum));
							}
							if (!findNumberIsNotEmpty)
								strSequenceNum=ConstantsUtil.EMPTY_SPACE;
							mpFormulaIngredients.put(ConstantsUtil.SEQUENCENUMBER, strSequenceNum);
							mpFormulaIngredients.put(ConstantsUtil.TEMP, strSortSequence);
							mlFormulaIngredientSort.add(mpFormulaIngredients);
						}
						// <SPEC>:01/18/2021 Modified for defect #36223 by Govind start
						//mlFormulaIngredientSort.sort(ConstantsUtil.SEQUENCENUMBER,ConstantsUtil.ASCENDING,ConstantsUtil.FLOAT);
						mlFormulaIngredientSort.sort(ConstantsUtil.TEMP,ConstantsUtil.ASCENDING,ConstantsUtil.INTEGER);
						// <SPEC>:01/18/2021 Modified for defect #36223 by Govind end

						int nMapMP = mlFormulaIngredientSort.size();
						//SPEC: <01.08.2021>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
						//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
						int index=1;
						StringBuffer sbFId = new StringBuffer();
						StringBuffer sbFName = new StringBuffer();
						StringBuffer sbFSeqNum = new StringBuffer();
						StringBuffer sbFTitle = new StringBuffer();
						StringBuffer sbFMin = new StringBuffer();
						StringBuffer sbFQty = new StringBuffer();
						StringBuffer sbFMax = new StringBuffer();
						StringBuffer sbFWeightWet = new StringBuffer();
						StringBuffer sbFDryPer = new StringBuffer();
						StringBuffer sbFWeightDry = new StringBuffer();
						StringBuffer sbFLoss = new StringBuffer();
						StringBuffer sbFMatFunc = new StringBuffer();
						StringBuffer sbFVirtual = new StringBuffer();
						StringBuffer sbFComments = new StringBuffer();
						StringBuffer sbFType = new StringBuffer();
						StringBuffer sbFChg = new StringBuffer();
						StringBuffer sbFMinWet = new StringBuffer();
						StringBuffer sbFMaxWet = new StringBuffer();
						StringBuffer sbFPhase = new StringBuffer();
						StringBuffer sbFReportedFunction = new StringBuffer();
						StringBuffer sbFUnitsValue = new StringBuffer();
						StringBuffer sbFCertifications = new StringBuffer();
						StringBuffer sbFSubstituteParts = new StringBuffer();
						StringBuffer sbFState = new StringBuffer();
						StringBuffer sbFRevision = new StringBuffer();
						StringBuffer sbFSubstitutePartsType = new StringBuffer();
						StringBuffer sbFSubstitutePartsID = new StringBuffer();
						//Added by Pooja for the req 41754,34415 -- START
						StringBuffer sbFGrossWeightReal = new StringBuffer();
						StringBuffer sbFGrossWeightUOM = new StringBuffer ();
						//Added by Pooja for the req 41754,34415 -- END
						//SPEC: Added by Pooja for req no. 45642 -- START
						StringBuffer sbFParentName = new StringBuffer();
						StringBuffer sbFParentREV = new StringBuffer();
						StringBuffer sbFParentId = new StringBuffer();
						StringBuffer sbFParentType = new StringBuffer();
						//SPEC: Added by Pooja for req no. 45642 -- END
						//Added by Subhajit for Req 46464 - Start
						StringBuffer sbFRelRestriction = new StringBuffer();
						StringBuffer sbFRelRestrictionComment = new StringBuffer();
						//Added by Subhajit for Req 46464 - End
						//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
						Map objectMap = null;
						int iParentLevel = 0;
						StringList slParentId = new StringList();
						String sParentId = ConstantsUtil.EMPTY_STRING;

						for(int i =0; i<mlFormulaIngredientSort.size(); i++)
						{
							objectMap = (Map) mlFormulaIngredientSort.get(i);
							iParentLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));
							mpFormulaIngr = new HashMap<String, String>();
							sParentId = ConstantsUtil.EMPTY_STRING;
							//SPEC: <01.08.2021>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS

							String strOid = ConstantsUtil.EMPTY_STRING;
							String strRelId = ConstantsUtil.EMPTY_STRING;
							String strId  = ConstantsUtil.EMPTY_STRING;
							String strSequenceNumber = ConstantsUtil.EMPTY_STRING;
							String strMin = ConstantsUtil.EMPTY_STRING;
							String strMax = ConstantsUtil.EMPTY_STRING;
							String strLoss = ConstantsUtil.EMPTY_STRING;
							String strQuantity = ConstantsUtil.EMPTY_STRING;
							String strWeightWet = ConstantsUtil.EMPTY_STRING;
							String strWeightDry = ConstantsUtil.EMPTY_STRING;
							String strDryPer = ConstantsUtil.EMPTY_STRING;
							String strComments = ConstantsUtil.EMPTY_STRING;
							String strMaterialFunction = ConstantsUtil.EMPTY_STRING;
							String strVirtualName = ConstantsUtil.EMPTY_STRING;
							String sIpClass = ConstantsUtil.EMPTY_STRING;
							String strTitle  =  ConstantsUtil.EMPTY_STRING;
							//SPEC: <10.14.2020>: Added for req 18x.5 ## -- START
							String strChg = ConstantsUtil.EMPTY_STRING;
							String strMinWet = ConstantsUtil.EMPTY_STRING;
							String strMaxWet = ConstantsUtil.EMPTY_STRING;
							String strPhase = ConstantsUtil.EMPTY_STRING;
							String strReportedFunction = ConstantsUtil.EMPTY_STRING;
							String strUnitsValue = ConstantsUtil.EMPTY_STRING;
							String strCertifications = ConstantsUtil.EMPTY_STRING;
							String strSubstituteParts = ConstantsUtil.EMPTY_STRING;
							String strSubstitutePartsType = ConstantsUtil.EMPTY_STRING;
							String strSubstitutePartsID = ConstantsUtil.EMPTY_STRING;
							//SPEC: <10.14.2020>: Added for req 18x.5 ## -- END
							int integerPlaces = ConstantsUtil.ZERO_LEVEL;
							int decimalPlaces = ConstantsUtil.ZERO_LEVEL;
							//Commented by Ketan for Req. no. 47949
							//DecimalFormat decimalformatter = new DecimalFormat(ConstantsUtil.PATTERN_DECIMALFORMAT);

							StringBuffer sbId = new StringBuffer();
							StringBuffer sbName = new StringBuffer();
							StringBuffer sbSeqNum = new StringBuffer();
							StringBuffer sbTitle = new StringBuffer();
							StringBuffer sbMin = new StringBuffer();
							StringBuffer sbQty = new StringBuffer();
							StringBuffer sbMax = new StringBuffer();
							StringBuffer sbWeightWet = new StringBuffer();
							StringBuffer sbDryPer = new StringBuffer();
							StringBuffer sbWeightDry = new StringBuffer();
							StringBuffer sbLoss = new StringBuffer();
							StringBuffer sbMatFunc = new StringBuffer();
							StringBuffer sbVirtual = new StringBuffer();
							StringBuffer sbComments = new StringBuffer();
							StringBuffer sbType = new StringBuffer();

							//SPEC: <10.14.2020>: Added for req 18x.5 ## -- START
							StringBuffer sbChg = new StringBuffer();
							StringBuffer sbMinWet = new StringBuffer();
							StringBuffer sbMaxWet = new StringBuffer();
							StringBuffer sbPhase = new StringBuffer();
							StringBuffer sbReportedFunction = new StringBuffer();
							StringBuffer sbUnitsValue = new StringBuffer();
							StringBuffer sbCertifications = new StringBuffer();
							StringBuffer sbSubstituteParts = new StringBuffer();
							StringBuffer sbState = new StringBuffer();
							StringBuffer sbRevision = new StringBuffer();
							StringBuffer sbSubstitutePartsType = new StringBuffer();
							StringBuffer sbSubstitutePartsID = new StringBuffer();
							//Added by Pooja for the req 41754,34415 -- START
							StringBuffer sbGrossWeightReal = new StringBuffer();
							StringBuffer sbGrossWeightUOM = new StringBuffer ();
							//Added by Pooja for the req 41754,34415 -- END
							//Added by Subhajit for Req 46464 - Start
							StringBuffer sbRelRestriction = new StringBuffer();
							String sRelRestriction = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
							StringBuffer sbRelRestrictionComment = new StringBuffer();							
							String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
							//Added by Subhajit for Req 46464 - End
							//SPEC: Added by Pooja for req no. 45642 -- START
							StringBuffer sbParentName = new StringBuffer();
							StringBuffer sbParentREV = new StringBuffer();
							StringBuffer sbParentId = new StringBuffer();
							StringBuffer sbParentType = new StringBuffer();
							
							String sfParentId =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID);
							String sParentName =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME);
							String sParentRevision =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV);
							String sParentType =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE);
							if (sParentType.equals(ConstantsUtil.TYPE_FORMULATIONPROCESS)||sParentType.equals(ConstantsUtil.TYPE_FORMULATIONPHASE )) {
								sfParentId = ConstantsUtil.NO_ACCESS;
							}
							//SPEC: Added by Pooja for req no. 45642 -- END
							strId = (String)objectMap.get(ConstantsUtil.SELECT_ID);
							strRelId = (String)objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_ID);
							strSequenceNumber = (String)objectMap.get(ConstantsUtil.SEQUENCENUMBER);
							strMin = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET);
							strMax = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET);
							strLoss = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
							strQuantity = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
							strWeightWet = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
							strWeightDry = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
							strDryPer = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
							strComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE);
							sIpClass = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
							//Added by Pooja for the req 41754,34415 -- START
							String strGrossWeightReal = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
							String strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
							//Added by Pooja for the req 41754,34415 -- END
							//SPEC: <10.14.2020>: Added for req 18x.5 ## -- START
							strChg = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
							strMinWet = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET));
							strMaxWet = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET));
							strPhase = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
							strReportedFunction = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REPORTED_FUNCTION));
							strUnitsValue = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_UNITSVALUE);
							strCertifications = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_FOPCERTIFICATIONS));

							strSubstituteParts = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_NAME));
							strSubstituteParts=strSubstituteParts.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_BLANK_AND);
							strSubstitutePartsType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_TYPE));
							strSubstitutePartsType=strSubstitutePartsType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_BLANK_AND);
							strSubstitutePartsID = formulationPartBO.checkFormulaIngredHasAccess(context, objectMap);
							

							strMaterialFunction = (String) formulationPartBO.getMaterialFunction(context,strRelId);
							strVirtualName = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID);

							DomainObject doObj = DomainObject.newInstance(context,strId);
							StringList objectSelects = BusObjectAttribUtil.getBasicInfoBusSelectable(context);
							objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							StopWatch swFormulaBasic = new StopWatch();
							swFormulaBasic.start();
							Map mpObjDetails = (Map) doObj.getInfo(context, objectSelects);
							swFormulaBasic.stop();
							//LOGGER.info("FOP INGREDIATE BASIC ELAPSED TIME: "+swFormulaBasic.getTime());
							strTitle = (String) mpObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							if(validator.isNotNullOrEmpty(strTitle)) {
								strTitle = strTitle.replaceAll(ConstantsUtil.SYMBL_LESSTHEN,ConstantsUtil.STR_LESSTHAN);						
								strTitle = strTitle.replaceAll(ConstantsUtil.SYMBL_GRETERTHAN,ConstantsUtil.STR_GREATERTHAN);
							}

							strName = (String) mpObjDetails.get(ConstantsUtil.SELECT_NAME);
							strState = (String) mpObjDetails.get(ConstantsUtil.SELECT_CURRENT);

							//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- START
							strState = strState.replace((String)ConstantsUtil.RELEASE, ConstantsUtil.RELEASED);
							//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END

							strRev = (String) mpObjDetails.get(ConstantsUtil.SELECT_REVISION);
							strType = (String) mpObjDetails.get(ConstantsUtil.SELECT_TYPE);
							strType = util.mapType(strType);

							//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- START
							if((((String) mpObjDetails.get(ConstantsUtil.SELECT_TYPE)).equalsIgnoreCase(ConstantsUtil.TYPE_RAWMATERIALPART))||(((String) mpObjDetails.get(ConstantsUtil.SELECT_TYPE)).equalsIgnoreCase(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART))) {
								if(UIUtil.isNotNullAndNotEmpty(strCertifications)) {
									strCertifications = ConstantsUtil.SYMBL_YES;
								}
								else {
									strCertifications = ConstantsUtil.SYMBL_NO;
									}
							}
							else {
								strCertifications = ConstantsUtil.EMPTY_STRING;
							}
							//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END

							if(objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE)){
								strMin = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
								//Commented by Ketan for Req. no. 47949
								/*if(validator.isNotNullOrEmpty(strMin))						
								{
									integerPlaces = strMin.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = strMin.length() - integerPlaces - 1;
									if(decimalPlaces>6){
										strMin = String.valueOf(decimalformatter.format(Double.parseDouble(strMin)));
									}
								}
								else
									strMin = ConstantsUtil.EMPTY_STRING;*/
							}

							//SPEC: <10.14.2020>: Added for req 18x.5 ## -- START
							if(objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET)){
								strMinWet = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET);
								//Commented by Ketan for Req. no. 47949
								/*if(validator.isNotNullOrEmpty(strMinWet))						
								{
									integerPlaces = strMinWet.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = strMinWet.length() - integerPlaces - 1;
									if(decimalPlaces>6){
										strMinWet = String.valueOf(decimalformatter.format(Double.parseDouble(strMinWet)));
									}
								}
								else
									strMinWet = ConstantsUtil.EMPTY_STRING;*/
							}

							if(objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET)){
								strMaxWet = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET);
								//Commented by Ketan for Req. no. 47949
								/*if(validator.isNotNullOrEmpty(strMaxWet))
								{
									integerPlaces = strMaxWet.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = strMaxWet.length() - integerPlaces - 1;
									if(decimalPlaces>6){
										strMaxWet = String.valueOf(decimalformatter.format(Double.parseDouble(strMaxWet)));
									}
								}
								else
									strMaxWet = ConstantsUtil.EMPTY_STRING;*/
							}
							//SPEC: <10.14.2020>: Added for req 18x.5 ## -- END

							if(objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE)){
								strMax = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
								//Commented by Ketan for Req. no. 47949
								/*if(validator.isNotNullOrEmpty(strMax))
								{
									integerPlaces = strMax.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = strMax.length() - integerPlaces - 1;
									if(decimalPlaces>6){
										strMax = String.valueOf(decimalformatter.format(Double.parseDouble(strMax)));
									}
								}
								else
									strMax = ConstantsUtil.EMPTY_STRING;*/
							}

							//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- START
							//if(mpFormulaIngredients.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_LOSS)){
							if(objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_INPUTVALUE)){
								//strLoss = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
								strLoss = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_INPUTVALUE);
								//Commented by Ketan for Req. no. 47949
								//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END
								/*if(validator.isNotNullOrEmpty(strLoss))
								{
									integerPlaces = strLoss.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = strLoss.length() - integerPlaces - 1;
									if(decimalPlaces>6){
										strLoss = String.valueOf(decimalformatter.format(Double.parseDouble(strLoss)));
									}
								}
								else
									strLoss = ConstantsUtil.EMPTY_STRING;*/
							}

							if(objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT)){
								strWeightWet = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
								//Commented by Ketan for Req. no. 47949
								/*if(validator.isNotNullOrEmpty(strWeightWet))
								{
									integerPlaces = strWeightWet.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = strWeightWet.length() - integerPlaces - 1;
									if(decimalPlaces>6){
										strWeightWet = String.valueOf(decimalformatter.format(Double.parseDouble(strWeightWet)));
									}
								}
								else
									strWeightWet = ConstantsUtil.EMPTY_STRING;*/
							}
							if(objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE)){
								strQuantity = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
								//Commented by Ketan for Req. no. 47949
								/*if(validator.isNotNullOrEmpty(strQuantity))
								{
									integerPlaces = strQuantity.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = strQuantity.length() - integerPlaces - 1;
									if(decimalPlaces>6){
										strQuantity = String.valueOf(decimalformatter.format(Double.parseDouble(strQuantity)));
									}
								}
								else
									strQuantity = ConstantsUtil.EMPTY_STRING;*/
							}

							if(objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_INPUTVALUE)){
								//strDryPer = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
								strDryPer = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_INPUTVALUE);
								//Commented by Ketan for Req. no. 47949
								//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END
								/*if(validator.isNotNullOrEmpty(strDryPer))
								{
									integerPlaces = strDryPer.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = strDryPer.length() - integerPlaces - 1;
									if(decimalPlaces>6){
										strDryPer = String.valueOf(decimalformatter.format(Double.parseDouble(strDryPer)));
									}
								}
								else
									strDryPer = ConstantsUtil.EMPTY_STRING;*/
							}
							if(objectMap.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY)){
								strWeightDry = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
								//Commented by Ketan for Req. no. 47949
								/*if(validator.isNotNullOrEmpty(strWeightDry))
								{
									integerPlaces = strWeightDry.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = strWeightDry.length() - integerPlaces - 1;
									if(decimalPlaces>6){
										strWeightDry = String.valueOf(decimalformatter.format(Double.parseDouble(strWeightDry)));
									}
								}
								else
									strWeightDry = ConstantsUtil.EMPTY_STRING;*/
							}


							boolean showData = true;
							String sFormulaPropagate = objId;
							String sFormulaPropagates = strId;
							if(util.isModificatinRequired())
							{
								String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));

								if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, objId);
									//SPEC: <14.07.2022>: Guna Modified for Req 41754 22x Release  -- START
									showData=util.checkHasAccess(context, null, strId);
									//SPEC: <14.07.2022>: Guna Modified for Req 41754 22x Release  -- END
								}else {
									//showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
									showData=util.checkHasAccess(context, null, strId);
								}
								//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 29, 2021 for Defect #43866 -- END
							}else if(sec.isStaffAUGUser())
							{
								String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));

								if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, objId);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
								}

							}else
							{
								if(slHIRTypes.contains(strType))
								{
									String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
									if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										String sFormulaClassif = util.getFormulaPropagateClassification(context, objId);
										showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
									}else {
										showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
									}
									//SPEC: <11.05.2020>: Modified for Defect 37146 ## -- END
								}
							}

							if(!showData)
							{
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbType.append(strType).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbMin.append(strMin).append(ConstantsUtil.SYMBL_PIPE);
								sbMax.append(strMax).append(ConstantsUtil.SYMBL_PIPE);
								sbQty.append(strQuantity).append(ConstantsUtil.SYMBL_PIPE);
								sbWeightDry.append(strWeightDry).append(ConstantsUtil.SYMBL_PIPE);
								sbWeightWet.append(strWeightWet).append(ConstantsUtil.SYMBL_PIPE);
								sbSeqNum.append(strSequenceNumber).append(ConstantsUtil.SYMBL_PIPE);
								sbLoss.append(strLoss).append(ConstantsUtil.SYMBL_PIPE);
								sbMatFunc.append(strMaterialFunction).append(ConstantsUtil.SYMBL_PIPE);
								sbVirtual.append(strVirtualName).append(ConstantsUtil.SYMBL_PIPE);
								sbDryPer.append(strDryPer).append(ConstantsUtil.SYMBL_PIPE);
								sbComments.append(strComments).append(ConstantsUtil.SYMBL_PIPE);
								//Added by Pooja for the req 41754,34415 -- START
								sbGrossWeightReal.append(strGrossWeightReal).append(ConstantsUtil.SYMBL_PIPE);
								sbGrossWeightUOM.append(strGrossWeightUOM).append(ConstantsUtil.SYMBL_PIPE);
								//Added by Pooja for the req 41754,34415 -- END
								sbChg.append(strChg).append(ConstantsUtil.SYMBL_PIPE);
								sbMinWet.append(strMinWet).append(ConstantsUtil.SYMBL_PIPE);
								sbMaxWet.append(strMaxWet).append(ConstantsUtil.SYMBL_PIPE);
								sbPhase.append(strPhase).append(ConstantsUtil.SYMBL_PIPE);
								sbReportedFunction.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbUnitsValue.append(strUnitsValue).append(ConstantsUtil.SYMBL_PIPE);
								sbCertifications.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubstituteParts.append(strSubstituteParts).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRev).append(ConstantsUtil.SYMBL_PIPE);
								sbSubstitutePartsType.append(strSubstitutePartsType).append(ConstantsUtil.SYMBL_PIPE);
								sbSubstitutePartsID.append(strSubstitutePartsID).append(ConstantsUtil.SYMBL_PIPE);
							}else{
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbMin.append(strMin).append(ConstantsUtil.SYMBL_PIPE);
								sbMax.append(strMax).append(ConstantsUtil.SYMBL_PIPE);
								sbQty.append(strQuantity).append(ConstantsUtil.SYMBL_PIPE);
								sbWeightDry.append(strWeightDry).append(ConstantsUtil.SYMBL_PIPE);
								sbWeightWet.append(strWeightWet).append(ConstantsUtil.SYMBL_PIPE);
								sbSeqNum.append(strSequenceNumber).append(ConstantsUtil.SYMBL_PIPE);
								sbLoss.append(strLoss).append(ConstantsUtil.SYMBL_PIPE);
								sbMatFunc.append(strMaterialFunction).append(ConstantsUtil.SYMBL_PIPE);
								sbVirtual.append(strVirtualName).append(ConstantsUtil.SYMBL_PIPE);
								sbDryPer.append(strDryPer).append(ConstantsUtil.SYMBL_PIPE);
								sbComments.append(strComments).append(ConstantsUtil.SYMBL_PIPE);
								sbType.append(strType).append(ConstantsUtil.SYMBL_PIPE);
								//Added by Pooja for the req 41754,34415 -- START
								sbGrossWeightReal.append(strGrossWeightReal).append(ConstantsUtil.SYMBL_PIPE);
								sbGrossWeightUOM.append(strGrossWeightUOM).append(ConstantsUtil.SYMBL_PIPE);
								//Added by Pooja for the req 41754,34415 -- END
								//SPEC: <10.14.2020>: Added for req 18x.5 ## -- START
								sbChg.append(strChg).append(ConstantsUtil.SYMBL_PIPE);
								sbMinWet.append(strMinWet).append(ConstantsUtil.SYMBL_PIPE);
								sbMaxWet.append(strMaxWet).append(ConstantsUtil.SYMBL_PIPE);
								sbPhase.append(strPhase).append(ConstantsUtil.SYMBL_PIPE);
								sbReportedFunction.append(strReportedFunction).append(ConstantsUtil.SYMBL_PIPE);
								sbUnitsValue.append(strUnitsValue).append(ConstantsUtil.SYMBL_PIPE);
								sbCertifications.append(strCertifications).append(ConstantsUtil.SYMBL_PIPE);
								sbSubstituteParts.append(strSubstituteParts).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRev).append(ConstantsUtil.SYMBL_PIPE);
								sbSubstitutePartsType.append(strSubstitutePartsType).append(ConstantsUtil.SYMBL_PIPE);
								sbSubstitutePartsID.append(strSubstitutePartsID).append(ConstantsUtil.SYMBL_PIPE);
							}
							if(!strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPHASE) && iParentLevel == 1) {

								formatData(sbFId,strId);
								formatData(sbFName,strName);
								formatData(sbFType,strType);
								formatData(sbFSeqNum,strSequenceNumber);
								formatData(sbFTitle,strTitle);
								formatData(sbFMin,strMin);
								formatData(sbFQty,strQuantity);
								formatData(sbFMinWet,strMinWet);
								formatData(sbFWeightWet,strWeightWet);
								formatData(sbFDryPer,strDryPer);
								formatData(sbFMatFunc,strMaterialFunction);
								formatData(sbFVirtual,strVirtualName);
								formatData(sbFComments,strComments);
								formatData(sbFChg,strChg);
								//Added by Pooja for the req 41754,34415 -- START
								formatData(sbFGrossWeightReal,strGrossWeightReal);
								formatData(sbFGrossWeightUOM,strGrossWeightUOM);
								//Added by Pooja for the req 41754,34415 -- END
								//SPEC: Added by Pooja for req no. 45642 -- START
								formatData(sbFParentName, sParentName);
								formatData(sbFParentREV, sParentRevision);
								formatData(sbFParentId, sfParentId);
								sParentType = util.mapType(sParentType);
								formatData(sbFParentType, sParentType);
								//SPEC: Added by Pooja for req no. 45642 -- END
								//Added by Subhajit for Req 46464 - Start
								formatData(sbFRelRestriction, sRelRestriction);
								formatData(sbFRelRestrictionComment, sRelRestrictionComment);
								//Added by Subhajit for Req 46464 - End
								formatData(sbFPhase,strPhase);
								formatData(sbFReportedFunction,strReportedFunction);
								formatData(sbFUnitsValue,strUnitsValue);
								formatData(sbFCertifications,strCertifications);
								formatData(sbFSubstituteParts,strSubstituteParts);
								formatData(sbFState,strState);
								formatData(sbFRevision,strRev);

								formatData(sbFSubstitutePartsType,strSubstitutePartsType);
								formatData(sbFSubstitutePartsID,strSubstitutePartsID);

								sbFId=util.removeLastElement(sbFId);
								sbFName=util.removeLastElement(sbFName);
								sbFType=util.removeLastElement(sbFType);
								sbFSeqNum=util.removeLastElement(sbFSeqNum);
								sbFTitle=util.removeLastElement(sbFTitle);
								sbFMin=util.removeLastElement(sbFMin);
								sbFQty=util.removeLastElement(sbFQty);
								sbFMinWet=util.removeLastElement(sbFMinWet);
								sbFWeightWet=util.removeLastElement(sbFWeightWet);
								sbFDryPer=util.removeLastElement(sbFDryPer);
								sbFMatFunc=util.removeLastElement(sbFMatFunc);
								sbFVirtual=util.removeLastElement(sbFVirtual);
								sbFComments=util.removeLastElement(sbFComments);
								sbFChg=util.removeLastElement(sbFChg);
								//Added by Pooja for the req 41754,34415 -- START
								sbFGrossWeightReal=util.removeLastElement(sbGrossWeightReal);
								sbFGrossWeightUOM=util.removeLastElement(sbGrossWeightUOM);
								//Added by Pooja for the req 41754,34415 -- END
								sbFPhase=util.removeLastElement(sbFPhase);
								sbFReportedFunction=util.removeLastElement(sbFReportedFunction);
								sbFUnitsValue=util.removeLastElement(sbFUnitsValue);
								sbFCertifications=util.removeLastElement(sbFCertifications);
								sbFSubstituteParts=util.removeLastElement(sbFSubstituteParts);
								sbFState=util.removeLastElement(sbFState);
								sbFRevision=util.removeLastElement(sbFRevision);

								sbFSubstitutePartsType=util.removeLastElement(sbFSubstitutePartsType);
								sbFSubstitutePartsID=util.removeLastElement(sbFSubstitutePartsID);
								int iLength = sbFSubstitutePartsID.length();

								if(iLength>2){
									sbFSubstitutePartsID=sbFSubstitutePartsID.deleteCharAt(sbFSubstitutePartsID.length()-2);
								}

							} else {
								//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS

								formatData(sbId,strId);
								formatData(sbName,strName);
								formatData(sbType,strType);
								formatData(sbSeqNum,strSequenceNumber);
								formatData(sbTitle,strTitle);
								formatData(sbMin,strMin);
								formatData(sbQty,strQuantity);
								formatData(sbMinWet,strMinWet);
								formatData(sbWeightWet,strWeightWet);
								formatData(sbDryPer,strDryPer);
								formatData(sbMatFunc,strMaterialFunction);
								formatData(sbVirtual,strVirtualName);
								formatData(sbComments,strComments);
								formatData(sbChg,strChg);
								//Added by Pooja for the req 41754,34415 -- START
								formatData(sbGrossWeightReal,strGrossWeightReal);
								formatData(sbGrossWeightUOM,strGrossWeightUOM);
								//Added by Pooja for the req 41754,34415 -- END
								//SPEC: Added by Pooja for req no. 45642 -- START
								formatData(sbParentName, sParentName);
								formatData(sbParentREV, sParentRevision);
								formatData(sbParentId, sfParentId);
								sParentType = util.mapType(sParentType);
								formatData(sbParentType, sParentType);
								//SPEC: Added by Pooja for req no. 45642 -- END
								//Added by Subhajit for Req 46464 - Start
								formatData(sbRelRestriction, sRelRestriction);
								formatData(sbRelRestrictionComment, sRelRestrictionComment);
								//Added by Subhajit for Req 46464 - End
								formatData(sbPhase,strPhase);
								formatData(sbReportedFunction,strReportedFunction);
								formatData(sbUnitsValue,strUnitsValue);
								formatData(sbCertifications,strCertifications);
								formatData(sbSubstituteParts,strSubstituteParts);
								formatData(sbState,strState);
								formatData(sbRevision,strRev);

								formatData(sbSubstitutePartsType,strSubstitutePartsType);
								formatData(sbSubstitutePartsID,strSubstitutePartsID);

								//SPEC: <11.05.2020>: Modified for Defect 37138 ## -- START
								sbId=util.removeLastElement(sbId);
								sbName=util.removeLastElement(sbName);
								sbType=util.removeLastElement(sbType);
								sbSeqNum=util.removeLastElement(sbSeqNum);
								sbTitle=util.removeLastElement(sbTitle);
								sbMin=util.removeLastElement(sbMin);
								sbQty=util.removeLastElement(sbQty);
								sbMinWet=util.removeLastElement(sbMinWet);
								sbWeightWet=util.removeLastElement(sbWeightWet);
								sbDryPer=util.removeLastElement(sbDryPer);
								sbMatFunc=util.removeLastElement(sbMatFunc);
								sbVirtual=util.removeLastElement(sbVirtual);
								sbComments=util.removeLastElement(sbComments);
								sbChg=util.removeLastElement(sbChg);
								//Added by Pooja for the req 41754,34415 -- START
								sbGrossWeightReal=util.removeLastElement(sbGrossWeightReal);
								sbGrossWeightUOM=util.removeLastElement(sbGrossWeightUOM);
								//Added by Pooja for the req 41754,34415 -- END
								sbPhase=util.removeLastElement(sbPhase);
								sbReportedFunction=util.removeLastElement(sbReportedFunction);
								sbUnitsValue=util.removeLastElement(sbUnitsValue);
								sbCertifications=util.removeLastElement(sbCertifications);
								sbSubstituteParts=util.removeLastElement(sbSubstituteParts);
								sbState=util.removeLastElement(sbState);
								sbRevision=util.removeLastElement(sbRevision);

								sbSubstitutePartsType=util.removeLastElement(sbSubstitutePartsType);
								sbSubstitutePartsID=util.removeLastElement(sbSubstitutePartsID);
								int iLength = sbSubstitutePartsID.length();

								if(iLength>2){
									sbSubstitutePartsID=sbSubstitutePartsID.deleteCharAt(sbSubstitutePartsID.length()-2);
								}
							}
							int j = 0;
							int iNextLevel = 0;
							Map objectMaps =null;
							if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPHASE)){
								sParentId=sFormulaPropagates;
								//SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --ENDS

								for(j =i+1; j<mlFormulaIngredientSort.size(); j++)
								{
									iNextLevel = 0;
									objectMaps = (Map) mlFormulaIngredientSort.get(j);
									int iCurrLevel = Integer.parseInt((String) objectMaps.get(ConstantsUtil.SELECT_LEVEL));
									if(j < mlFormulaIngredientSort.size()-1) {
										Map objectNxtMaps = (Map) mlFormulaIngredientSort.get(j+1);
										iNextLevel = Integer.parseInt((String) objectNxtMaps.get(ConstantsUtil.SELECT_LEVEL));
									}
									if((iParentLevel+1 == iCurrLevel) && strType.equals(ConstantsUtil.TYPE_FORMULATIONPHASE)) {

										String strCId = (String)objectMaps.get(ConstantsUtil.SELECT_ID);
										strRelId = (String)objectMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_ID);
										strSequenceNumber = (String)objectMaps.get(ConstantsUtil.SEQUENCENUMBER);
										strMin = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET);
										strMax = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET);
										strLoss = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
										strQuantity = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
										strWeightWet = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
										strWeightDry = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
										strDryPer = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
										strComments = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE);
										sIpClass = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.STR_IPCLASS));

										//SPEC: <10.14.2020>: Added for req 18x.5 ## -- START
										strChg = (String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
										//Added by Pooja for the req 41754,34415 -- START
										strGrossWeightReal = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
										strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
										//Added by Pooja for the req 41754,34415 -- END
										//Added by Subhajit for Req 46464 - Start
										sRelRestriction = validator.isNotNullOrEmpty((String)objectMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
										sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
										//Added by Subhajit for Req 46464 - End
										//SPEC: Added by Pooja for req no. 45642 -- START
										sfParentId =(String)objectMaps.get(ConstantsUtilIRM.SELECT_EBOM_ID);
										sParentName =(String)objectMaps.get(ConstantsUtilIRM.SELECT_EBOM_NAME);
										sParentRevision =(String)objectMaps.get(ConstantsUtilIRM.SELECT_EBOM_REV);
										sParentType =(String)objectMaps.get(ConstantsUtilIRM.SELECT_EBOM_TYPE);
										if (sParentType.equals(ConstantsUtil.TYPE_FORMULATIONPROCESS) || sParentType.equals(ConstantsUtil.TYPE_FORMULATIONPHASE )) {
											sfParentId = ConstantsUtil.NO_ACCESS;
										}
										//SPEC: Added by Pooja for req no. 45642 -- END
										strMinWet = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET));
										strMaxWet = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET));
										strPhase = (String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
										strReportedFunction = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.REPORTED_FUNCTION));
										strUnitsValue = (String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_UNITSVALUE);
										strCertifications = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_FOPCERTIFICATIONS));

										strSubstituteParts = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_NAME));
										strSubstituteParts=strSubstituteParts.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_BLANK_AND);
										strSubstitutePartsType = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_TYPE));
										strSubstitutePartsType=strSubstitutePartsType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_BLANK_AND);
										strSubstitutePartsID = formulationPartBO.checkFormulaIngredHasAccess(context, objectMaps);
										
										strMaterialFunction = (String) formulationPartBO.getMaterialFunction(context,strRelId);
										strVirtualName = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID);

										DomainObject doObjct = DomainObject.newInstance(context,strCId);
										StringList objectSels = BusObjectAttribUtil.getBasicInfoBusSelectable(context);
										objectSels.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
										StopWatch swFrmlaBasic = new StopWatch();
										swFrmlaBasic.start();
										Map mpObjDtls = (Map) doObjct.getInfo(context, objectSels);
										swFrmlaBasic.stop();
										//LOGGER.info("FOP INGREDIATE BASIC ELAPSED TIME: "+swFrmlaBasic.getTime());
										strTitle = (String) mpObjDtls.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
										if(validator.isNotNullOrEmpty(strTitle)) {
											strTitle = strTitle.replaceAll(ConstantsUtil.SYMBL_LESSTHEN,ConstantsUtil.STR_LESSTHAN);						
											strTitle = strTitle.replaceAll(ConstantsUtil.SYMBL_GRETERTHAN,ConstantsUtil.STR_GREATERTHAN);
										}

										strName = (String) mpObjDtls.get(ConstantsUtil.SELECT_NAME);
										strState = (String) mpObjDtls.get(ConstantsUtil.SELECT_CURRENT);

										//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- START
										strState = strState.replace((String)ConstantsUtil.RELEASE, ConstantsUtil.RELEASED);
										//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END

										strRev = (String) mpObjDtls.get(ConstantsUtil.SELECT_REVISION);
										String strCType = (String) mpObjDtls.get(ConstantsUtil.SELECT_TYPE);
										strCType = util.mapType(strCType);

										if((((String) mpObjDtls.get(ConstantsUtil.SELECT_TYPE)).equalsIgnoreCase(ConstantsUtil.TYPE_RAWMATERIALPART))||(((String) mpObjDtls.get(ConstantsUtil.SELECT_TYPE)).equalsIgnoreCase(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART))) {	
										//SPEC: 14/04/2021 Release 18x.6: Modified for Defect #40891 by Bala -- END
											if(UIUtil.isNotNullAndNotEmpty(strCertifications)) {
												strCertifications = ConstantsUtil.SYMBL_YES;
											}
											else {
												strCertifications = ConstantsUtil.SYMBL_NO;
											}
										}
										else {
											strCertifications = ConstantsUtil.EMPTY_STRING;
										}
										//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END

										if(objectMaps.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE)){
											strMin = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
											//Commented by Ketan for Req. no. 47949
											/*if(validator.isNotNullOrEmpty(strMin))						
											{
												integerPlaces = strMin.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
												decimalPlaces = strMin.length() - integerPlaces - 1;
												if(decimalPlaces>6){
													strMin = String.valueOf(decimalformatter.format(Double.parseDouble(strMin)));
												}
											}
											else
												strMin = ConstantsUtil.EMPTY_STRING;*/
										}

										if(objectMaps.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET)){
											strMinWet = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET);
											//Commented by Ketan for Req. no. 47949
											/*if(validator.isNotNullOrEmpty(strMinWet))						
											{
												integerPlaces = strMinWet.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
												decimalPlaces = strMinWet.length() - integerPlaces - 1;
												if(decimalPlaces>6){
													strMinWet = String.valueOf(decimalformatter.format(Double.parseDouble(strMinWet)));
												}
											}
											else
												strMinWet = ConstantsUtil.EMPTY_STRING;*/
										}
										if(objectMaps.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET)){
											strMaxWet = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET);
											//Commented by Ketan for Req. no. 47949
											/*if(validator.isNotNullOrEmpty(strMaxWet))
											{
												integerPlaces = strMaxWet.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
												decimalPlaces = strMaxWet.length() - integerPlaces - 1;
												if(decimalPlaces>6){
													strMaxWet = String.valueOf(decimalformatter.format(Double.parseDouble(strMaxWet)));
												}
											}
											else
												strMaxWet = ConstantsUtil.EMPTY_STRING;*/
										}
										//SPEC: <10.14.2020>: Added for req 18x.5 ## -- END

										if(objectMaps.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE)){
											strMax = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
											//Commented by Ketan for Req. no. 47949
											/*if(validator.isNotNullOrEmpty(strMax))
											{
												integerPlaces = strMax.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
												decimalPlaces = strMax.length() - integerPlaces - 1;
												if(decimalPlaces>6){
													strMax = String.valueOf(decimalformatter.format(Double.parseDouble(strMax)));
												}
											}
											else
												strMax = ConstantsUtil.EMPTY_STRING;*/
										}

										if(objectMaps.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_INPUTVALUE)){
											strLoss = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_INPUTVALUE);
											//Commented by Ketan for Req. no. 47949
											/*if(validator.isNotNullOrEmpty(strLoss))
											{
												integerPlaces = strLoss.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
												decimalPlaces = strLoss.length() - integerPlaces - 1;
												if(decimalPlaces>6){
													strLoss = String.valueOf(decimalformatter.format(Double.parseDouble(strLoss)));
												}
											}
											else
												strLoss = ConstantsUtil.EMPTY_STRING;*/
										}

										if(objectMaps.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT)){
											strWeightWet = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
											//Commented by Ketan for Req. no. 47949
											/*if(validator.isNotNullOrEmpty(strWeightWet))
											{
												integerPlaces = strWeightWet.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
												decimalPlaces = strWeightWet.length() - integerPlaces - 1;
												if(decimalPlaces>6){
													strWeightWet = String.valueOf(decimalformatter.format(Double.parseDouble(strWeightWet)));
												}
											}
											else
												strWeightWet = ConstantsUtil.EMPTY_STRING;*/
										}
										if(objectMaps.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE)){
											strQuantity = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
											//Commented by Ketan for Req. no. 47949
											/*if(validator.isNotNullOrEmpty(strQuantity))
											{
												integerPlaces = strQuantity.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
												decimalPlaces = strQuantity.length() - integerPlaces - 1;
												if(decimalPlaces>6){
													strQuantity = String.valueOf(decimalformatter.format(Double.parseDouble(strQuantity)));
												}
											}
											else
												strQuantity = ConstantsUtil.EMPTY_STRING;*/
										}

										if(objectMaps.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_INPUTVALUE)){
											strDryPer = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_INPUTVALUE);
											//Commented by Ketan for Req. no. 47949
											/*if(validator.isNotNullOrEmpty(strDryPer))
											{
												integerPlaces = strDryPer.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
												decimalPlaces = strDryPer.length() - integerPlaces - 1;
												if(decimalPlaces>6){
													strDryPer = String.valueOf(decimalformatter.format(Double.parseDouble(strDryPer)));
												}
											}
											else
												strDryPer = ConstantsUtil.EMPTY_STRING;*/
										}
										if(objectMaps.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY)){
											strWeightDry = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
											//Commented by Ketan for Req. no. 47949
											/*if(validator.isNotNullOrEmpty(strWeightDry))
											{
												integerPlaces = strWeightDry.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
												decimalPlaces = strWeightDry.length() - integerPlaces - 1;
												if(decimalPlaces>6){
													strWeightDry = String.valueOf(decimalformatter.format(Double.parseDouble(strWeightDry)));
												}
											}
											else
												strWeightDry = ConstantsUtil.EMPTY_STRING;*/
										}


										showData = true;
										sFormulaPropagate = objId;
										if(util.isModificatinRequired())
										{
											
											String strClassFied = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.STR_IPCLASS));
											if(strCType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
												String sFormulaClassif = util.getFormulaPropagateClassification(context, strCId);
												//SPEC: <14.07.2022>: Guna Modified for Req 41754 22x Release  -- START
												showData=util.checkHasAccess(context, null, strCId);
												//SPEC: <14.07.2022>: Guna Modified for Req 41754 22x Release  -- END
											}else {
												showData=util.checkHasAccess(context, null, strCId);
											}
										}else if(sec.isStaffAUGUser())
										{
											String strClassFied = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.STR_IPCLASS));
											if(strCType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
												String sFormulaClassif = util.getFormulaPropagateClassification(context, strCId);
												showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
											}else {
												showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
											}

										}else
										{
											if(slHIRTypes.contains(strCType))
											{
												String strClassFied = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.STR_IPCLASS));
												if(strCType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
													String sFormulaClassif = util.getFormulaPropagateClassification(context, strCId);
													showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
												}else {
													showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
												}
											}
										}
										if(!showData)
										{
											sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
											sbType.append(strCType).append(ConstantsUtil.SYMBL_PIPE);
											sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
											sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
											sbMin.append(strMin).append(ConstantsUtil.SYMBL_PIPE);
											sbMax.append(strMax).append(ConstantsUtil.SYMBL_PIPE);
											sbQty.append(strQuantity).append(ConstantsUtil.SYMBL_PIPE);
											sbWeightDry.append(strWeightDry).append(ConstantsUtil.SYMBL_PIPE);
											sbWeightWet.append(strWeightWet).append(ConstantsUtil.SYMBL_PIPE);
											sbSeqNum.append(strSequenceNumber).append(ConstantsUtil.SYMBL_PIPE);
											sbLoss.append(strLoss).append(ConstantsUtil.SYMBL_PIPE);
											sbMatFunc.append(strMaterialFunction).append(ConstantsUtil.SYMBL_PIPE);
											sbVirtual.append(strVirtualName).append(ConstantsUtil.SYMBL_PIPE);
											sbDryPer.append(strDryPer).append(ConstantsUtil.SYMBL_PIPE);
											sbComments.append(strComments).append(ConstantsUtil.SYMBL_PIPE);
											sbChg.append(strChg).append(ConstantsUtil.SYMBL_PIPE);
											//Added by Pooja for the req 41754,34415 -- START
											sbGrossWeightReal.append(strGrossWeightReal).append(ConstantsUtil.SYMBL_PIPE);
											sbGrossWeightUOM.append(strGrossWeightUOM).append(ConstantsUtil.SYMBL_PIPE);
											//Added by Pooja for the req 41754,34415 -- END
											sbMinWet.append(strMinWet).append(ConstantsUtil.SYMBL_PIPE);
											sbMaxWet.append(strMaxWet).append(ConstantsUtil.SYMBL_PIPE);
											sbPhase.append(strPhase).append(ConstantsUtil.SYMBL_PIPE);
											sbReportedFunction.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
											sbUnitsValue.append(strUnitsValue).append(ConstantsUtil.SYMBL_PIPE);
											sbCertifications.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
											sbSubstituteParts.append(strSubstituteParts).append(ConstantsUtil.SYMBL_PIPE);
											sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
											sbRevision.append(strRev).append(ConstantsUtil.SYMBL_PIPE);
											sbSubstitutePartsType.append(strSubstitutePartsType).append(ConstantsUtil.SYMBL_PIPE);
											sbSubstitutePartsID.append(strSubstitutePartsID).append(ConstantsUtil.SYMBL_PIPE);
										}else{
											sbId.append(strCId).append(ConstantsUtil.SYMBL_PIPE);
											sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
											sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
											sbMin.append(strMin).append(ConstantsUtil.SYMBL_PIPE);
											sbMax.append(strMax).append(ConstantsUtil.SYMBL_PIPE);
											sbQty.append(strQuantity).append(ConstantsUtil.SYMBL_PIPE);
											sbWeightDry.append(strWeightDry).append(ConstantsUtil.SYMBL_PIPE);
											sbWeightWet.append(strWeightWet).append(ConstantsUtil.SYMBL_PIPE);
											sbSeqNum.append(strSequenceNumber).append(ConstantsUtil.SYMBL_PIPE);
											sbLoss.append(strLoss).append(ConstantsUtil.SYMBL_PIPE);
											sbMatFunc.append(strMaterialFunction).append(ConstantsUtil.SYMBL_PIPE);
											sbVirtual.append(strVirtualName).append(ConstantsUtil.SYMBL_PIPE);
											sbDryPer.append(strDryPer).append(ConstantsUtil.SYMBL_PIPE);
											sbComments.append(strComments).append(ConstantsUtil.SYMBL_PIPE);
											sbType.append(strCType).append(ConstantsUtil.SYMBL_PIPE);
											//Added by Pooja for the req 41754,34415 -- START
											sbGrossWeightReal.append(strGrossWeightReal).append(ConstantsUtil.SYMBL_PIPE);
											sbGrossWeightUOM.append(strGrossWeightUOM).append(ConstantsUtil.SYMBL_PIPE);
											//Added by Pooja for the req 41754,34415 -- END
											sbChg.append(strChg).append(ConstantsUtil.SYMBL_PIPE);
											sbMinWet.append(strMinWet).append(ConstantsUtil.SYMBL_PIPE);
											sbMaxWet.append(strMaxWet).append(ConstantsUtil.SYMBL_PIPE);
											sbPhase.append(strPhase).append(ConstantsUtil.SYMBL_PIPE);
											sbReportedFunction.append(strReportedFunction).append(ConstantsUtil.SYMBL_PIPE);
											sbUnitsValue.append(strUnitsValue).append(ConstantsUtil.SYMBL_PIPE);
											sbCertifications.append(strCertifications).append(ConstantsUtil.SYMBL_PIPE);
											sbSubstituteParts.append(strSubstituteParts).append(ConstantsUtil.SYMBL_PIPE);
											sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
											sbRevision.append(strRev).append(ConstantsUtil.SYMBL_PIPE);
											sbSubstitutePartsType.append(strSubstitutePartsType).append(ConstantsUtil.SYMBL_PIPE);
											sbSubstitutePartsID.append(strSubstitutePartsID).append(ConstantsUtil.SYMBL_PIPE);
										}

										formatData(sbId,strCId);
										formatData(sbName,strName);
										formatData(sbType,strCType);
										formatData(sbSeqNum,strSequenceNumber);
										formatData(sbTitle,strTitle);
										formatData(sbMin,strMin);
										formatData(sbQty,strQuantity);
										formatData(sbMinWet,strMinWet);
										formatData(sbWeightWet,strWeightWet);
										formatData(sbDryPer,strDryPer);
										formatData(sbMatFunc,strMaterialFunction);
										formatData(sbVirtual,strVirtualName);
										formatData(sbComments,strComments);
										formatData(sbChg,strChg);
										formatData(sbPhase,strPhase);
										formatData(sbReportedFunction,strReportedFunction);
										formatData(sbUnitsValue,strUnitsValue);
										formatData(sbCertifications,strCertifications);
										formatData(sbSubstituteParts,strSubstituteParts);
										formatData(sbState,strState);
										formatData(sbRevision,strRev);
										//Added by Pooja for the req 41754,34415 -- START
										formatData(sbGrossWeightUOM,strGrossWeightUOM);
										formatData(sbGrossWeightReal,strGrossWeightReal);
										//Added by Pooja for the req 41754,34415 -- END
										//SPEC: Added by Pooja for req no. 45642 -- START
										formatData(sbParentName, sParentName);
										formatData(sbParentREV, sParentRevision);
										formatData(sbParentId, sfParentId);
										sParentType = util.mapType(sParentType);
										formatData(sbParentType, sParentType);
										//SPEC: Added by Pooja for req no. 45642 -- END
										//Added by Subhajit for Req 46464 - Start
										formatData(sbRelRestriction, sRelRestriction);
										formatData(sbRelRestrictionComment, sRelRestrictionComment);
										//Added by Subhajit for Req 46464 - End
										formatData(sbSubstitutePartsType,strSubstitutePartsType);
										formatData(sbSubstitutePartsID,strSubstitutePartsID);

										//SPEC: <11.05.2020>: Modified for Defect 37138 ## -- START
										sbId=util.removeLastElement(sbId);
										sbName=util.removeLastElement(sbName);
										sbType=util.removeLastElement(sbType);
										sbSeqNum=util.removeLastElement(sbSeqNum);
										sbTitle=util.removeLastElement(sbTitle);
										sbMin=util.removeLastElement(sbMin);
										sbQty=util.removeLastElement(sbQty);
										sbMinWet=util.removeLastElement(sbMinWet);
										sbWeightWet=util.removeLastElement(sbWeightWet);
										sbDryPer=util.removeLastElement(sbDryPer);
										sbMatFunc=util.removeLastElement(sbMatFunc);
										sbVirtual=util.removeLastElement(sbVirtual);
										sbComments=util.removeLastElement(sbComments);
										sbChg=util.removeLastElement(sbChg);
										sbPhase=util.removeLastElement(sbPhase);
										sbReportedFunction=util.removeLastElement(sbReportedFunction);
										sbUnitsValue=util.removeLastElement(sbUnitsValue);
										sbCertifications=util.removeLastElement(sbCertifications);
										sbSubstituteParts=util.removeLastElement(sbSubstituteParts);
										sbState=util.removeLastElement(sbState);
										sbRevision=util.removeLastElement(sbRevision);
										//Added by Pooja for the req 41754,34415 -- START
										sbGrossWeightReal=util.removeLastElement(sbGrossWeightReal);
										sbGrossWeightUOM=util.removeLastElement(sbGrossWeightUOM);
										//Added by Pooja for the req 41754,34415 -- END
										sbSubstitutePartsType=util.removeLastElement(sbSubstitutePartsType);
										sbSubstitutePartsID=util.removeLastElement(sbSubstitutePartsID);
						
										int iLengt = sbSubstitutePartsID.length();
									}
									if(iParentLevel+1 > iNextLevel || iParentLevel == iCurrLevel) {
										break;
									}
								}
								//SPEC: <01.08.2021>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS
								mpFormulaIngr.put(ConstantsUtil.ID, sbId.toString());
								mpFormulaIngr.put(ConstantsUtil.NAMETYPE, sbName.toString());
								mpFormulaIngr.put(ConstantsUtil.TYPE, sbType.toString());
								mpFormulaIngr.put(ConstantsUtil.SEQ, sbSeqNum.toString());
								mpFormulaIngr.put(ConstantsUtil.TITLEINST, sbTitle.toString());
								mpFormulaIngr.put(ConstantsUtil.MINWETMAX, sbMin.toString()+ConstantsUtil.SYMBL_COMMA+sbQty.toString()+ConstantsUtil.SYMBL_COMMA+sbMax.toString());

								//SPEC: <10.14.2020>: Modified for req 18x.5 ## -- START
								mpFormulaIngr.put(ConstantsUtil.TARGETWETWEIGHT, sbWeightWet.toString()+ConstantsUtil.SYMBL_COMMA+sbMinWet.toString()+ConstantsUtil.SYMBL_COMMA+sbMaxWet.toString());
								//SPEC: <10.14.2020>: Modified for req 18x.5 ## -- END

								//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- START
								mpFormulaIngr.put(ConstantsUtil.DRYTDWPL, sbDryPer.toString()+ ConstantsUtil.SYMBL_COMMA + sbWeightDry.toString()+ConstantsUtil.SYMBL_COMMA+sbLoss.toString());
								//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END

								mpFormulaIngr.put(ConstantsUtil.FUNCTIONS, sbMatFunc.toString());
								mpFormulaIngr.put(ConstantsUtil.VIRTUALINTNAME, sbVirtual.toString());
								mpFormulaIngr.put(ConstantsUtil.PROCESSINGNOTE, sbComments.toString());
								//Added by Pooja for the req 41754,34415 -- START
								mpFormulaIngr.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
								mpFormulaIngr.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
								//Added by Pooja for the req 41754,34415 -- END
								//SPEC: Added by Pooja for req no. 45642 -- START
								mpFormulaIngr.put(ConstantsUtilIRM.PARENT_ID, sbParentId.toString());
								mpFormulaIngr.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString());
								mpFormulaIngr.put(ConstantsUtilIRM.PARENT_REVISION, sbParentREV.toString());
								mpFormulaIngr.put(ConstantsUtilIRM.PARENT_TYPE, sbParentType.toString());
								//SPEC: Added by Pooja for req no. 45642 -- END
								//Added by Subhajit for Req 46464 - Start
								mpFormulaIngr.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
								mpFormulaIngr.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
								//Added by Subhajit for Req 46464 - End
								//SPEC: <10.14.2020>: Added for req 18x.5 ## -- START
								mpFormulaIngr.put(ConstantsUtil.CHG, sbChg.toString());
								mpFormulaIngr.put(ConstantsUtil.PHASE, sbPhase.toString());
								mpFormulaIngr.put(ConstantsUtil.REPORTEDFUNCTION, sbReportedFunction.toString());
								mpFormulaIngr.put(ConstantsUtil.UNITSVALUE, sbUnitsValue.toString());
								mpFormulaIngr.put(ConstantsUtil.CERTIFICATIONS, sbCertifications.toString());
								mpFormulaIngr.put(ConstantsUtil.SUBSTITUTEPARTS, sbSubstituteParts.toString());
								mpFormulaIngr.put(ConstantsUtil.STATE, sbState.toString());
								mpFormulaIngr.put(ConstantsUtil.REVISION, sbRevision.toString());

								mpFormulaIngr.put(ConstantsUtil.SUBSTITUTEPARTSTYPE, sbSubstitutePartsType.toString());
								mpFormulaIngr.put(ConstantsUtil.SUBSTITUTEPARTSID, sbSubstitutePartsID.toString());

								//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- START
								//mpFormulaIngr = util.filterMapList(mpFormulaIngr);
								if (UIUtil.isNotNullAndNotEmpty(sbName.toString())) {
									//no action needed
								}else {
									mpFormulaIngr = new HashMap(); //empty map
								}
							}
							//SPEC: <01.08.2021>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
							//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --START
							if(!mpFormulaIngr.isEmpty() && validator.isNotNullOrEmpty(sParentId) && (!slParentId.contains(sParentId) || (slParentId.contains(sParentId) && !strType.equals(ConstantsUtil.TYPE_FORMULATIONPHASE) && iParentLevel == 1))) {
								//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --ENDS
								slParentId.add(sParentId);
								mpFinalFBOM.put(String.valueOf(index), mpFormulaIngr);
								index++;
							}
						}
						//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
						mpFormulaIngr = new HashMap();
						if(null != sbFId && sbFId.length()>0) {
							mpFormulaIngr.put(ConstantsUtil.ID, sbFId.toString());
							mpFormulaIngr.put(ConstantsUtil.NAMETYPE, sbFName.toString());
							mpFormulaIngr.put(ConstantsUtil.TYPE, sbFType.toString());
							mpFormulaIngr.put(ConstantsUtil.SEQ, sbFSeqNum.toString());
							mpFormulaIngr.put(ConstantsUtil.TITLEINST, sbFTitle.toString());
							mpFormulaIngr.put(ConstantsUtil.MINWETMAX, sbFMin.toString()+ConstantsUtil.SYMBL_COMMA+sbFQty.toString()+ConstantsUtil.SYMBL_COMMA+sbFMax.toString());
							mpFormulaIngr.put(ConstantsUtil.TARGETWETWEIGHT, sbFWeightWet.toString()+ConstantsUtil.SYMBL_COMMA+sbFMinWet.toString()+ConstantsUtil.SYMBL_COMMA+sbFMaxWet.toString());
							mpFormulaIngr.put(ConstantsUtil.DRYTDWPL, sbFDryPer.toString()+ ConstantsUtil.SYMBL_COMMA + sbFWeightDry.toString()+ConstantsUtil.SYMBL_COMMA+sbFLoss.toString());
							mpFormulaIngr.put(ConstantsUtil.FUNCTIONS, sbFMatFunc.toString());
							mpFormulaIngr.put(ConstantsUtil.VIRTUALINTNAME, sbFVirtual.toString());
							mpFormulaIngr.put(ConstantsUtil.PROCESSINGNOTE, sbFComments.toString());
							mpFormulaIngr.put(ConstantsUtil.CHG, sbFChg.toString());
							mpFormulaIngr.put(ConstantsUtil.PHASE, sbFPhase.toString());
							mpFormulaIngr.put(ConstantsUtil.REPORTEDFUNCTION, sbFReportedFunction.toString());
							mpFormulaIngr.put(ConstantsUtil.UNITSVALUE, sbFUnitsValue.toString());
							mpFormulaIngr.put(ConstantsUtil.CERTIFICATIONS, sbFCertifications.toString());
							mpFormulaIngr.put(ConstantsUtil.SUBSTITUTEPARTS, sbFSubstituteParts.toString());
							mpFormulaIngr.put(ConstantsUtil.STATE, sbFState.toString());
							mpFormulaIngr.put(ConstantsUtil.REVISION, sbFRevision.toString());
							mpFormulaIngr.put(ConstantsUtil.SUBSTITUTEPARTSTYPE, sbFSubstitutePartsType.toString());
							mpFormulaIngr.put(ConstantsUtil.SUBSTITUTEPARTSID, sbFSubstitutePartsID.toString());
							//Added by Pooja for the req 41754,34415 -- START
							mpFormulaIngr.put(ConstantsUtil.GROSSWEIGHT, sbFGrossWeightReal.toString());
							mpFormulaIngr.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbFGrossWeightUOM.toString());
							//Added by Pooja for the req 41754,34415 -- END
							//SPEC: Added by Pooja for req no. 45642 -- START
							mpFormulaIngr.put(ConstantsUtilIRM.PARENT_ID, sbFParentId.toString());
							mpFormulaIngr.put(ConstantsUtilIRM.PARENT_NAME, sbFParentName.toString());
							mpFormulaIngr.put(ConstantsUtilIRM.PARENT_REVISION, sbFParentREV.toString());
							mpFormulaIngr.put(ConstantsUtilIRM.PARENT_TYPE, sbFParentType.toString());
							//SPEC: Added by Pooja for req no. 45642 -- END
							//Added by Subhajit for Req 46464 - Start
							mpFormulaIngr.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbFRelRestriction.toString());
							mpFormulaIngr.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbFRelRestrictionComment.toString());
							//Added by Subhajit for Req 46464 - End
							if(!mpFormulaIngr.isEmpty()) {
								mpFinalFBOM.put(String.valueOf(0), mpFormulaIngr);
							}
						}
						//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
						MPFinalFBOM.put(ConstantsUtil.FORMULATIONPROCESSFORMULA, mpFinalFBOM);
						mpFormulationProcess.put(ConstantsUtil.FORMULANUMBER, FormulationName);
						mpFormulationProcess.put(ConstantsUtil.REVISION, FormulationRevision);
						mpFormulationProcess.put(ConstantsUtil.REVISIONSTATUS,"");
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 20 Mar 2021 -- START
						String strFormulaNumberType = (String)resultMaps.get(ConstantsUtil.SELECT_TYPE);
						mpFormulationProcess.put(ConstantsUtilIRM.FORMULANUMBERID, objId);
						mpFormulationProcess.put(ConstantsUtilIRM.FORMULANUMBERTYPE, strFormulaNumberType);
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 20 Mar 2021 -- END

						mpFormulationProcess.put(ConstantsUtil.PHASE, FormulationStage+ConstantsUtil.SYMBL_COMMA+FormulationState);
						mpFormulationProcess.put(ConstantsUtil.FTFN, sFormulationType+ConstantsUtil.SYMBL_COMMA+FormulationProcessName);
						mpFormulationProcess.put(ConstantsUtil.NAME, FormulationTitle);
						//<SPEC>02/02/2021: Added for Defect#38457 start
						//SPEC:Commented by Jwala for the defect #42668 -- START

						mpFormulationProcess.put(ConstantsUtil.ID, ConstantsUtil.NO_ACCESS);
						//<SPEC>02/02/2021: Added for Defect#38457 end
						mpFormulationProcess.put(ConstantsUtil.TYPE, FormulationType);
						mpFormulationProcess.put(ConstantsUtil.TITLE, FormulationProcessName);


						mpFormulationProcess = util.filterMapList(mpFormulationProcess);
						swIngredients.stop();
						LOGGER.info("FOP FORMULA INGREDIENTS ELAPSED TIME : "+swIngredients.getTime());
					}
				}

				StringList slSubList = new StringList();
				slSubList.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
				slSubList.addAll(formulationPartBO.getBusSelects(context));

				//SPEC: <10.14.2020>: Modified for req 18x.5 ## -- START

				StopWatch swSubs = new StopWatch();
				swSubs.start();

				String strFOPProcess = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_FOPPROCESS_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_FOPPROCESS_ID) : ConstantsUtil.EMPTY_STRING;

				if(!strFOPProcess.isEmpty())
				{

					FOPSubstitute fopSub = new FOPSubstitute();
					Map paramMapSub = new HashMap();
					paramMapSub.put(ConstantsUtil.OBJECT_ID, strFOPProcess);
					MapList mlFopSub =fopSub.getSubstituteDetails(context,JPO.packArgs(paramMapSub));
					mpSubstitute =fopSub.getFopSubstitute(context,mlFopSub);

				}
				//SPEC: <10.14.2020>: Modified for req 18x.5 ## -- END
				swSubs.stop();
				LOGGER.info("FOP SUBSTITUTES ELAPSED TIME : "+swSubs.getTime());
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START :: COMMENTED

				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END :: COMMENTED
				/**
				 * Sap BOM as FED
				 */
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				//mpSapBomAsFedcResult = formulationPartBO.getSapBomAsFed(resultMaps);
				CalculateBOM clBom = new CalculateBOM();
				//mpSapBomAsFedcResult = clBom.getSapBOMasFed(context,sContextObjectId);
				//mpSapBomAsFedcResult = formulationPartBO.getSapBOMasFed(context,sContextObjectId);
				SapBomAsFed sap = new SapBomAsFed();
				mpSapBomAsFedcResult = sap.getSapBOMasFed(context,sContextObjectId);
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 23 Feb 2021 -- START
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZED);
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOUSE);
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOPRODUCE);
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 23 Feb 2021 -- END
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- END

				/**
				 * Materials Produced		
				 */
				StopWatch swMaterial = new StopWatch();
				swMaterial.start();
				FormulaPartBO fopBO = new FormulaPartBO();
				mpMaterialProduced = fopBO.getMaterialProduced(context,sContextObjectId);
				if(bManufacturerView) {
					mpMaterialProduced=util.filterPhase(mpMaterialProduced);
				}
				mpMaterialProduced = util.filterMapList(mpMaterialProduced);
				swMaterial.stop();
				LOGGER.info("FOP MATERIALS ELAPSED TIME : "+swMaterial.getTime());
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START :: COMMENTED
				
				/**
				 * Reference Docs
				 */
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END :: COMMENTED
				//Master Attribute Data
				String sMasterID= (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID) : ConstantsUtil.EMPTY_STRING);
				if(validator.isNotNullOrEmpty(sMasterID)){
					StopWatch swMasterAttrib = new StopWatch();
					FabricatedPartBO FABBO = new FabricatedPartBO();
					swMasterAttrib.start();
					mpMasterAttributes = FABBO.getMasterAttributeData(context,sMasterID);
					if(bManufacturerView) {
						mpMasterAttributes=util.filterPhase(mpMasterAttributes);
					}
					mpMasterAttributes = util.filterMapList(mpMasterAttributes);
					swMasterAttrib.stop();
					LOGGER.info("FOP GET MASTER ATTRIB ELAPSED TIME : "+swMasterAttrib.getTime());
				}
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START
			if(bAllInfoView || bManufacturerView || bGendocView)
			{
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- START (For Internal Defect)
				if(bAllInfoView || bGendocView)
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 27 April 2021 -- END (For Internal Defect)
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTPLATFORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTPLATFORM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTPLATFORM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DOESTHEPRODUCTCONTAINBATTERY, (validator.isNotNullOrEmpty(((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)).equals("TRUE")?"Yes":"No") ?(((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)).equals("TRUE")?"Yes":"No"): ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.PGDANGEROUSGOODSREADY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSREADY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSREADY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(strSelectSegment)))?(String)resultMaps.get(strSelectSegment) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Added for the Defect #39123 -- Start
				String strPrimary = (String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
				String strSecondary = (String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

				StringList strOrgList = new StringList();
				strOrgList.addElement("FHC PG Professional~GLOBAL");
				strOrgList.addElement("FHC PG Professional~NORTH AMERICA");
				strOrgList.addElement(",");

				if(sContextType.equalsIgnoreCase("Formulation Part") && (strOrgList.contains(strSecondary)|| strOrgList.contains(strPrimary))){
					mpAttribResult.put(ConstantsUtil.PGISPGPPRODUCTDILUTEDFORUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPGPPRODUCTDILUTEDFORUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPGPPRODUCTDILUTEDFORUSE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PERCENTCONCENTRATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PERCENTCONCENTRATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PERCENTCONCENTRATION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PGPERCENTWATER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPERCENTWATER_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPERCENTWATER_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 09 March 2021 -- START
				else
				{
					mpAttribResult.put(ConstantsUtil.PGISPGPPRODUCTDILUTEDFORUSE, ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PERCENTCONCENTRATION, ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PGPERCENTWATER, ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 09 March 2021 -- END
				//SPEC: Added for the Defect #39123 -- END
				if(!bGendocView)
					mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		

				mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 

				//SPEC: 10/12/2020: Added for 18x.5 DEV -- START
				mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				String masterId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID));
				if (UIUtil.isNotNullAndNotEmpty(masterId))
				{
					DomainObject obj = new DomainObject(masterId);
					String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					obj.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) 
					{
						masterId = ConstantsUtil.NO_ACCESS;
					}
					boolean showData = util.checkHasAccess(context, sUserType, masterId);
					if (!showData) 
					{
						masterId = ConstantsUtil.NO_ACCESS;
					}
				}
				mpHeaderResult.put(ConstantsUtil.MASTERPARTID, masterId);
				//Modified by Ganesh for Defect 38137  18x.5.2 Release ---->END

				/**
				 * Organization Data
				 */
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = util.filterMapList(mpOrganization);


				/**
				 * LOAD MARKET CLEARANCE
				 * */
				StopWatch swcountry = new StopWatch();
				swcountry.start();
				APPBO APPBO = new APPBO();
				mapCountryClearanceResult = APPBO.getCountryClearance(context,sContextObjectId);
				//Added by Jwala for defect 44115 fix under CHG0303796 -- END
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- END
				mapCountryClearanceResult = util.filterMapList(mapCountryClearanceResult);
				swcountry.stop();
				LOGGER.info("FOP MARKET CLEARANCE TIME : "+swcountry.getTime());

				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=util.getRelatedAts(context, doFop);

				mpRelatedATS=util.filterMapList(mpRelatedATS);
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- START
				String sHasATSAttrVal = util.checkHasATSForSIS(context,resultMaps);
				mpHeaderResult.put(ConstantsUtil.HASATS, sHasATSAttrVal);
				/*if(!mpRelatedATS.isEmpty()){
					mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
				}*/
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- END

				if(bManufacturerView) {
					mpRelatedATS=util.filterPhase(mpRelatedATS);
				}

				// Added for Defect 36404 - END
				swAts.stop();
				LOGGER.info("FOP ATS ELAPSED TIME : "+swAts.getTime());

				/**
				 * MASTER PART STABILITY DOC SECTION
				 */
				//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
				mpMasterPartStabilityDoc = formulationPartBO.getMasterPartStabilityDoc(context,resultMaps);
				//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END


				/**
				 * PRODUCT PART STABILITY DOC SECTION
				 */
				//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
				mpProductPartStabilityDoc = formulationPartBO.getProductPartStabilityDoc(context,resultMaps);
				//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END


				mapCertifications=APPBO.getCertificationClaims(context,objId);
				
				/**
				 * LOAD SECURITY SECTION
				 * */
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO bo = new CommonBusUtilBO();
				swSecurity.start();
				//SPEC:Modified by Jwala for Defect #41638 & 41608  -- START
				String strFormulationID = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.FORMULATION_ID));
				mpSecurity =formulationPartBO.updateSecurity(context,strFormulationID);
				//mpSecurity =formulationPartBO.updateSecurity(resultMaps);
				//SPEC:Modified by Jwala for Defect #41638 & 41608  -- END

				swSecurity.stop();
				LOGGER.info("FOP Security ELAPSED TIME : "+swSecurity.getTime());
				//SPEC: <10.09.2020>: Added for req 18x.5 ## -- END

				mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
				mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
				mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
				mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());

				/**
				 * Dangerous Goods Classification
				 */	
				//SPEC: 10/12/2020: Modified for 18x.5 DEV -- START
				//mpDangerousGoodsClf=util.getDangerousProdcutValue(context,resultMaps);
				FinishedProductPartBO fppBO = new FinishedProductPartBO();
				DeviceProductPartBO dppBo = new DeviceProductPartBO();
				//mpDangerousGoodsClf=fppBO.getDangerousProdcutValue(context,resultMaps);
				mpDangerousGoodsClf=dppBo.getDangerousProdcutValue(context,resultMaps);

				//mpDangerousGoodsClf=formulationPartBO.getDangerousProdcutValue(context,resultMaps);
				if(bManufacturerView) {
					mpDangerousGoodsClf=util.filterPhase(mpDangerousGoodsClf);
				}
				//SPEC: 10/12/2020: Modified for 18x.5 DEV -- START

				//Global Harmonized Standard

				// Guna modified for Defect 37202  18x.5.2 Release -- START
				//mpGlobalHarStandard = util.getGHSProdcutValue(context,resultMaps);
				mpGlobalHarStandard = dppBo.getGHSProdcutValue(context,resultMaps);

				// Guna modified for Defect 37202  18x.5.2 Release -- END

				if(bManufacturerView) {
					mpGlobalHarStandard=util.filterPhase(mpGlobalHarStandard);
				}

				/**
				 * Peformance Charcteristics
				 */
				Map paramMap = new HashMap();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				PefromChar perform = new PefromChar();

				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));

				int jj = mlPerformChar.size();
				if(!mlPerformChar.isEmpty())
				{
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
					//mpPerformChar = util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
					mpPerformChar = util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
				}
				swPerfChar.stop();
				LOGGER.info("FOP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
				StopWatch swOthers = new StopWatch();
				swOthers.start();
				/**
				 * Weight Characteristics
				 */
				mapWeightCharResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mapWeightCharResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);

				//SPEC: Added for Defect 39364 by Jwala-- START
				String strGrossWeight = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
				if(strGrossWeight.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)){
					mapWeightCharResult.put(ConstantsUtil.GROSSWEIGHT, ConstantsUtil.EMPTY_STRING);
				}
				
				mapWeightCharResult = util.filterMapList(mapWeightCharResult);


				/**
				 * Reference Docs
				 */
				StopWatch swReference= new StopWatch();
				swReference.start();
				MasterCOPBO mcop = new MasterCOPBO();
				mapReferenceDocs=mcop.updateRefDocs(context,resultMaps);

				swReference.stop();
				LOGGER.info("FOP Reference ELAPSED TIME : "+swReference.getTime());

				/**
				 * MASTER SPECIFICATION
				 * */
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				StopWatch swmpMasterSpecs = new StopWatch();
				swmpMasterSpecs.start();
				mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
				//mpMasterSpecs = formulationPartBO.getMasterSpecs(context,sContextObjectId);
				swmpMasterSpecs.stop();
				LOGGER.info("FOP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- END


				/**
				 * RelatedSpec
				 */
				mpRelatedSpecResult = util.updatePartSpec(context,resultMaps);

			}

			if(bAllInfoView) {
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA)));
				mpAttribResult.put(ConstantsUtil.BUSINESSAREA, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA)));
				mpAttribResult.put(ConstantsUtil.PRODUCTTECHNOLOGYPLATFORM, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM)));
				mpAttribResult.put(ConstantsUtil.PRODUCTTECHNOLOGYCHASSIS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS)));
				mpAttribResult.put(ConstantsUtil.FRANCHISE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE)));
				mpAttribResult.put(ConstantsUtil.STANDATDCOST, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTANDARDCOST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTANDARDCOST) : ConstantsUtil.EMPTY_STRING);

				/**
				 * Lifecycle
				 */
				//SPEC: <10.09.2020>: Modified for req 18x.5 ## -- START
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				//mpLifeCycleApproval = formulationPartBO.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("FOP LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				//SPEC: <10.09.2020>: Modified for req 18x.5 ## -- START
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- START
				String strCOCAName = (String) mpLifeCycleApproval.get(ConstantsUtil.CO);
				mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty(strCOCAName))?strCOCAName : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- START

				/**
				 * Plant Data
				 */
				mpPlantResult = util.updatePlantInfo(resultMaps);

				/**
				 * Ownership
				 */
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);

				/**
				 * LOAD MATERIAL RESULTS SECTION
				 * */
				StopWatch swMaterial = new StopWatch();
				swMaterial.start();
				mapMaterialResult = DPPBO.getSubstances(context,sContextObjectId);
				mapMaterialResult =util.verifyOwnership(context,mapMaterialResult);
				swMaterial.stop();
				LOGGER.info("FOP MATERIAL ELAPSED TIME : "+swMaterial.getTime());
				
				/**
				 * LOAD GPSASSESSMENTS SECTION
				 * */
				StopWatch swgps= new StopWatch();
				swgps.start();
				mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
				mpGPSAssessments = util.filterMapList(mpGPSAssessments);
				swgps.stop();
				LOGGER.info("FOP GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());

			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END
			if(bAllInfoView) {

				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				String FileSize = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
				StringBuilder sbFileSize = new StringBuilder();
				if(!FileSize.isEmpty()) {
					String[] strFileSize=FileSize.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					for (int i = 0; i < strFileSize.length; i++) {
						String strEachFileSize = strFileSize[i];
						double dFileSize = Double.parseDouble(strEachFileSize);
						dFileSize = dFileSize/1024;
						strEachFileSize=Double.toString(dFileSize).format("%.2f", dFileSize);
						sbFileSize.append(strEachFileSize).append(" KB").append(ConstantsUtil.SYMBL_PIPE);
					}
				}	
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());
				
				/**
				 * Materials & Composition SECTION
				 */
				//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
				boolean bHIRComplaint = util.getHIRComplaintForSupplier(context,doFop,resultMaps);
				StopWatch swSubts = new StopWatch();
				swSubts.start();
				mpMaterialResult = formulationPartBO.getMaterialCompositionAndSubstance(context, resultMaps);
				//SPEC: Modified related to Defect#37311 1.0.2 Release - Amman -- END

				mpMaterialResult =util.verifyOwnership(context,mpMaterialResult);
				if(bManufacturerView || (bSupplierView && bHIRComplaint)) {
					mpMaterialResult=util.filterPhase(mpMaterialResult);
				}
				mpMaterialResult = util.filterMapList(mpMaterialResult);
				swSubts.stop();
				LOGGER.info("FOP GET SUBSTANCE ELAPSED TIME : "+swSubts.getTime());
				//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END



				/**
				 * LOAD INGREDIENT STATEMENT SECTION
				 * */
				StopWatch swIngredient = new StopWatch();
				swIngredient.start();
				mpIngredientstatement = DPPBO.getIngredientstatements(context, sContextObjectId);
				mpIngredientstatement = util.filterMapList(mpIngredientstatement);
				swIngredient.stop();
				LOGGER.info("FOP INGREDIENT STATEMENT TIME : "+swIngredient.getTime());
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 24 Feb 2021 -- END
			}
			if(bGendocView)
			{
				StopWatch swSubts = new StopWatch();
				swSubts.start();
				boolean bHIRComplaint = util.getHIRComplaintForSupplier(context,doFop,resultMaps);
				mpMaterialResult = formulationPartBO.getMaterialCompositionAndSubstance(context, resultMaps);
				mpMaterialResult =util.verifyOwnership(context,mpMaterialResult);
				if(bManufacturerView || (bSupplierView && bHIRComplaint)) {
					mpMaterialResult=util.filterPhase(mpMaterialResult);
				}
				mpMaterialResult = util.filterMapList(mpMaterialResult);
				swSubts.stop();
				LOGGER.info("FOP GET SUBSTANCE ELAPSED TIME : "+swSubts.getTime());

				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);

			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 24 Feb 2021 -- START

			/**
			 * LOAD CERTIFICATIONVALIDATION SECTION
			 * */
			StopWatch swCerVali= new StopWatch();
			swCerVali.start();

			MapList mlCertValidation = util.getConnectedRawMaterialfromPart(context,sContextObjectId);
			mpCertificationvalidation = util.getCertValidationMap(context,resultMaps, mlCertValidation);
			mpCertificationvalidation = util.filterMapList(mpCertificationvalidation);
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- START
			strCertificationvalidation = validator.getStringEquivalentForStringList(mpCertificationvalidation.get(ConstantsUtil.SELECT_NAME));
			strCertificationvalidation = strCertificationvalidation.substring(0, strCertificationvalidation.length() -1);
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- END

			swCerVali.stop();
			LOGGER.info("FOP CERTIFICATIONVALIDATION ELAPSED TIME : "+swCerVali.getTime());
			
			/**
			 * SMART LABEL SECTION
			 * */ 
			APPBO APPBO = new APPBO();
			StopWatch swSmartLabel = new StopWatch();
			swSmartLabel.start();
			mpSmartLabel =APPBO.getConnectedSmartLabelForParts(context, objId);
			swSmartLabel.stop();

			//SPEC: <25.02.2021>: Guna Added for Dev 18x.6   -- END
			
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END

			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- START
			boolean bshowSection = true;
			if(bGendocView || bManufacturerView)
				bshowSection = false;
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- END
			hmAttrib.put(ConstantsUtil.ATTRIBUTES, mpAttribResult);
			hmAttrib.put(ConstantsUtil.DANGEROUSGOODCLASSIFICATION, mpDangerousGoodsClf);
			hmAttrib.put(ConstantsUtil.GLABALHARMONIZEDSTANDARD, mpGlobalHarStandard);
			hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATA, mapStorageAndLabelResult);
			hmAttrib.put(ConstantsUtil.CHEMICALANDPHYSLEGACYPROP, mpPhyChemEngLegacyData);
			hmAttrib.put(ConstantsUtil.CHEMICALANDPHYSLEGACYWAREHOUSEPROP, mpPhyChemEngWareHouse);
			hmAttrib.put(ConstantsUtil.CHEMICALANDPHYSLEGACYGHDCPROP, mpPhysicalChemicalGHCProp);
			hmAttrib.put(ConstantsUtilIRM.INGREDIENTSTATEMENT, mpIngredientstatement);
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- START
			if(bshowSection)
			{
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- END
				hmAttrib.put(ConstantsUtil.STABILITYRESULTS, mpStability);
				hmAttrib.put(ConstantsUtil.FORMULATIONPROCESS, mpFormulationProcess);
				hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
				hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
				hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
				hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
				hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
				hmAttrib.put(ConstantsUtil.FORMULATIONPROCESSFORMULA, MPFinalFBOM);
				hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialResult);
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- START
			if(bGendocView)
			{
				hmAttrib.put(ConstantsUtil.FORMULATIONPROCESS, mpFormulationProcess);
				hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
				hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
				hmAttrib.put(ConstantsUtil.FORMULATIONPROCESSFORMULA, MPFinalFBOM);
				hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialResult);
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- END
			hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mapWeightCharResult);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			hmAttrib.put(ConstantsUtil.MATERIALPRODUCED, mpMaterialProduced);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			hmAttrib.put(ConstantsUtil.MARKETOFCLEARANCE, mapCountryClearanceResult);
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START
			if(bAllInfoView || bManufacturerView || bGendocView){
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END
				hmAttrib.put(ConstantsUtil.CERTIFICATIONS, mapCertifications);
			}
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);

			//SPEC: <10.09.2020>: Added for req 18x.5 ## -- START
			
			hmAttrib.put(ConstantsUtil.MASTERPARTSTABILITYDOC, mpMasterPartStabilityDoc);
			hmAttrib.put(ConstantsUtil.PRODUCTPARTSTABILITYDOC, mpProductPartStabilityDoc);
			//SPEC: <10.09.2020>: Added for req 18x.5 ## -- END

			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONS, mpOrganization);
				hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- START
			
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- START
			if(mpCertificationvalidation.size()!=1 && !(strCertificationvalidation.equalsIgnoreCase(mpHeaderResult.get(DomainConstants.SELECT_NAME)))) {
				hmAttrib.put(ConstantsUtilIRM.CERTIFICATIONVALIDATION, mpCertificationvalidation);
			}
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- END
			hmAttrib.put(ConstantsUtil.SMARTLABEL, mpSmartLabel);
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- END

			pool.checkIn(context);
			sp.stop();
			//System.out.println("Execution TIME::" + sp.getTime() +"  " + "FOP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			LOGGER.info("FOP Execution TIME::" + sp.getTime() +"  " + "FOP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		} catch (IOException e) {
			LOGGER.error("Unable to getFOPdata IOException"+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getFOPdata MatrixException"+e);
		}
		//LOGGER.info("FOP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		context.close();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmAttrib;
	}

	public void formatData(StringBuffer sbId, String sData) {
		sbId.append(sData);
		sbId.append(ConstantsUtil.SYMBL_PIPE);
	}
}
