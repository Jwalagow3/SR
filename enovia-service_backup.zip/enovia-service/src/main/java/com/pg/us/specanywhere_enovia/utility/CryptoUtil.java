package com.pg.us.specanywhere_enovia.utility;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;


public class CryptoUtil {
	
	private final static String ENCRYPT_ALG = "DESede";
	private final static int KEY_SIZE = 112;

public static String encryptString(String sClearText, String sKey, String sFile) throws Exception {
		
		try {
			byte[] decodedKeyC = null;

			if (sFile.equals("")) {
				
				decodedKeyC = java.util.Base64.getMimeDecoder().decode(sKey);
			} else {
				try(FileInputStream in = new FileInputStream(sFile)) {
					decodedKeyC = new byte[ in.available() ];
					in.read(decodedKeyC);
					String b64decodedKeyC = new String(decodedKeyC,"UTF8");
					decodedKeyC = java.util.Base64.getMimeDecoder().decode(b64decodedKeyC);
				}
			}

			SecretKeySpec desKeySpec = new SecretKeySpec(decodedKeyC, ENCRYPT_ALG); 
			SecretKey key = (javax.crypto.SecretKey) desKeySpec;
	        Cipher ecipher;
            ecipher = Cipher.getInstance(ENCRYPT_ALG, "SunJCE");
            ecipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] utf8 = sClearText.getBytes("UTF8");
            byte[] enc = ecipher.doFinal(utf8);
            String sEncrypted = new String(java.util.Base64.getMimeEncoder().encode(enc));
			sEncrypted = sEncrypted.trim();
			System.out.print("sEncrypted:"+sEncrypted+"\n");
			return sEncrypted;

		} catch (Exception e) {
			return e.toString();
		}
	}
	
	
	
public static String decryptString(String sEncrypted, String sKey, String sFile) throws Exception {

	try {

		byte[] decodedKeyC = null;

		if (sFile.equals("")) {
			decodedKeyC = java.util.Base64.getMimeDecoder().decode(sKey);
		} else {
			try(FileInputStream in = new FileInputStream(sFile)) {
				decodedKeyC = new byte[ in.available() ];
				in.read(decodedKeyC);
				decodedKeyC = java.util.Base64.getMimeDecoder().decode(decodedKeyC);
			}
		}

		SecretKeySpec desKeySpec = new SecretKeySpec(decodedKeyC, ENCRYPT_ALG); 
		SecretKey key = (javax.crypto.SecretKey) desKeySpec;

        Cipher dcipher;
        dcipher = Cipher.getInstance(ENCRYPT_ALG, "SunJCE");
        dcipher.init(Cipher.DECRYPT_MODE, key);

		byte[] decode_input_bytes = java.util.Base64.getMimeDecoder().decode(sEncrypted);
		byte[] decode_output_bytes = dcipher.doFinal( decode_input_bytes );
		String decoded_string = new String( decode_output_bytes, "UTF8" );
		String sDecrypted = decoded_string.trim();
		System.out.print("sDecrypted:"+sDecrypted+"\n");
		return sDecrypted;

	} catch  (Exception e) {
		return e.toString();
	}
}
	
public static String makeSecretKey(String sFile) throws Exception {

	try {
		KeyGenerator generator = KeyGenerator.getInstance(ENCRYPT_ALG, "SunJCE");
		generator.init(KEY_SIZE, new SecureRandom());
		SecretKey secretkey = generator.generateKey(); 

		byte[] encodedKey = secretkey.getEncoded();
		String b64encodedKey = new String(java.util.Base64.getMimeEncoder().encode(encodedKey));

		if (!sFile.equals("")) {
			try(FileOutputStream out = new FileOutputStream(sFile)) { 
				out.write(b64encodedKey.getBytes());
				out.flush();
			}
		}
		return b64encodedKey;

	} catch (Exception e) {
		return e.toString();
	}
}
}
