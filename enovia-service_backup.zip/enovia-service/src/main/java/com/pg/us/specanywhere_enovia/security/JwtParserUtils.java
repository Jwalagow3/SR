package com.pg.us.specanywhere_enovia.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;

public class JwtParserUtils {

	public static Jws<Claims> parseJWTToken(String secretKey,String token) {
		return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token);
	}

	public static DecodedJWT parseJWTTokenPNG(String accessTokenIDP) {
		return JWT.decode(accessTokenIDP);
	}
	
	
}
