/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaMCPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.ConsumerUnitPartBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MCPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaMCPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaMCPServiceImpl implements EnoviaMCPService {


	private static Logger LOGGER = Logger.getLogger(EnoviaMCPServiceImpl.class);

	BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getMCPdata(String objId, Environment env) throws Exception {

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("MCP SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());
		try 
		{
			/**
			 * User Profile Section
			 * */
			SecurityService sct = new SecurityService();
			String sUserType = BbUtil.getUserType();
			if (UIUtil.isNotNullAndNotEmpty(sUserType)) {
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BbUtil.getUserView(context, objId);
				}
			}
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpSubStanceResult = new HashMap<String,String>();
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpGPSAssessments = new HashMap<String, String>();
			Map<String,String> mpCertification = new HashMap<>();

			BusObjectAttribUtil util = new BusObjectAttribUtil();
			ConsumerUnitPartBO CopBO = new ConsumerUnitPartBO();
			
			MCPBO mcp = new MCPBO();
			Map<String, StringList> BusinessObjectSelectableMap = mcp.getMCPSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

			DomainObject dobMCP = new DomainObject(objId);
			
			StopWatch swInfo = new StopWatch();
			swInfo.start();
			//Map resultMaps = dobMCP.getInfo(context, slContextSelects);
			Map resultMaps = dobMCP.getInfo(context, slContextSelects,mcp.addMultiList());
			swInfo.stop();
			LOGGER.info("MCP SERVICE GETINFO ELAPSED TIME : "+swInfo.getTime());

			/**
			 * BLOCK USER IF OBJECT IS NOT RELEASED
			 */
			if (sct.isExternalUser() || sct.isStaffAUGUser()) {
				String sState = (validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_CURRENT)))
						? (String) resultMaps.get(ConstantsUtil.SELECT_CURRENT)
								: ConstantsUtil.EMPTY_STRING;

				if ((!sState.equals(ConstantsUtil.RELEASE) && !sState.equals(ConstantsUtil.APPROVED)) && null != sState && !sState.isEmpty()) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(sState.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
			}

			//Header Content
			StopWatch sHeader = new StopWatch();
			sHeader.start();
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING));		
			mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			String sClassification = util.getClassification(resultMaps);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));

			sHeader.stop();
			LOGGER.info("MCP  Header ELAPSED TIME : "+sHeader.getTime());


			//Attribute Data
			mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.INTERNALMATERIAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty(PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)) : ConstantsUtil.EMPTY_STRING));

			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.POLICY)))?(String)resultMaps.get(ConstantsUtil.POLICY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.VAULT)))?(String)resultMaps.get(ConstantsUtil.VAULT) : ConstantsUtil.EMPTY_STRING);

			mpAttribResult.put(ConstantsUtil.TRADENAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_MCPRF)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_MCPRF) : ConstantsUtil.EMPTY_STRING);
			String strSG =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SPECIFICGRAVITY))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SPECIFICGRAVITY) : ConstantsUtil.EMPTY_STRING;
			if (strSG.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
			{
				strSG = ConstantsUtil.GEN_NUM_ZERO;
			}
			mpAttribResult.put(ConstantsUtil.SPECIFICGRAVITY,strSG);
			mpAttribResult.put(ConstantsUtil.MANUFACTURER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GPSORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED) : ConstantsUtil.EMPTY_STRING);

			mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LEGACYENVCLASS, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.RELATIONSHIP_MATERIAL_SUB_CLASS_NAME)))?(String)resultMaps.get(ConstantsUtil.RELATIONSHIP_MATERIAL_SUB_CLASS_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.POST_CONNSUMER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.POST_INDUSTRIAL, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT) : ConstantsUtil.EMPTY_STRING));
			String sClassFiedID=	validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID));
			StringList slClassFiedID =FrameworkUtil.split(sClassFiedID, "|");
			String sClassFiedName=	validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME));
			StringList slClassFiedName =FrameworkUtil.split(sClassFiedName, "|");

			String sMaterial = DomainConstants.EMPTY_STRING;
			StringBuilder sFinalString = new StringBuilder();

			for(int i =0;i<slClassFiedID.size();i++)
			{
				sMaterial = util.getMaterial(context,slClassFiedID.get(i).trim(),slClassFiedName.get(i).trim());
				if(i==0)
					sFinalString.append(sMaterial);
				else
					sFinalString.append(", ").append(sMaterial);
			}
			mpAttribResult.put(ConstantsUtil.MATERIALFAMILY,sFinalString.toString()); 
			String sClassifictaion = util.getClassification(resultMaps);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
			if(bManufacturerView || bSupplierView) {
				mpAttribResult.put(ConstantsUtilIRM.EXTERNALREVISIONLEVEL, ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtilIRM.EXTERNALREVISIONDATE,  ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONDATE)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONDATE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtilIRM.INTERNALMATERIALNUMBER, ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALNUMBER)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALNUMBER) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtilIRM.STANDARDMATERIALNUMBER, ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER) : ConstantsUtil.EMPTY_STRING));
			}

			/**
			 * LOAD SUBSTANCES SECTION
			 * */

			BusObjectAttribUtil busObjUtil = new BusObjectAttribUtil();
			mpSubStanceResult =  busObjUtil.updateMaterials(context, dobMCP, false,resultMaps);

			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */
			StopWatch swReference= new StopWatch();
			swReference.start();
			MasterCOPBO mcop = new MasterCOPBO();
			mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
			swReference.stop();
			LOGGER.info("MCP  REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());

			/**
			 * LOAD GPSASSESSMENTS SECTION
			 * */
			StopWatch swgps= new StopWatch();
			swgps.start();
			DeviceProductPartBO DPPBO = new DeviceProductPartBO();
			mpGPSAssessments = DPPBO.getGPSAssessments(context, objId);
			mpGPSAssessments = util.filterMapList(mpGPSAssessments);
			swgps.stop();
			LOGGER.info("MCP  GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
			
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- START
			/**
			 * LOAD PACKAGING CERTIFICATIONS
			 * */
			
			StopWatch swPkgCert = new StopWatch();
			swPkgCert.start();
			mpCertification = CopBO.getPackagingCertificationsList(context, objId,(String)resultMaps.get(ConstantsUtil.SELECT_TYPE));
			mpCertification = util.filterMapList(mpCertification); // Added by Satyam for defect 50235
			swPkgCert.stop();
			LOGGER.info("PACKAGING CERTIFICATIONS ELAPSED TIME : "+swPkgCert.getTime());
			hmAttrib.put(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS, mpCertification);
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- END

			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			if(bAllInfoView)
			{
				hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpSubStanceResult);
				hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
				hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
			}
			pool.checkIn(context);
			sp.stop();
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
			dobMCP.close(context);
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END	

		}catch (Exception e) {
			LOGGER.error("Exception in MCP Service IMPL: "+e);
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
			context.close();
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		
		//LOGGER.info("MCP SERVICE RESPONSE MESSAGE:: \n" + hmAttrib);
		context.close();//Added for Defect 45181
		return hmAttrib;


	}
}
