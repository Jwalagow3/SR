package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.EBPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaWhereUsedService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaWhereUsedServiceImpl implements EnoviaWhereUsedService {
	
	private static Logger LOGGER = Logger.getLogger(EnoviaMEPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	@Autowired
    private HttpServletRequest request;
	
	@Override
	public HashMap<String, Map<String, String>> getWhereUsedData(String sObjectID, Environment env) {
		StopWatch sp = new StopWatch();
		sp.start();
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		Map<String,String> mapImpactedParts = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("WHERE USED SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());
		EBPBO ebpbo = new EBPBO();

		try
		{
			DomainObject doObj = new DomainObject(sObjectID);

			StringList objectSelects = new StringList(5);
			objectSelects.add(DomainConstants.SELECT_NAME);
			objectSelects.add(DomainConstants.SELECT_REVISION);
			objectSelects.add(DomainConstants.SELECT_TYPE);
			objectSelects.add(DomainConstants.SELECT_CURRENT);
			objectSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);

			Map mlPartDetails = doObj.getInfo(context, objectSelects);

			String sType = validator.getStringEquivalentForStringList(mlPartDetails.get(DomainConstants.SELECT_TYPE));
			String sRev = validator.getStringEquivalentForStringList(mlPartDetails.get(DomainConstants.SELECT_REVISION));
			String sName = validator.getStringEquivalentForStringList(mlPartDetails.get(DomainConstants.SELECT_NAME));
			String sCurrent = validator.getStringEquivalentForStringList(mlPartDetails.get(DomainConstants.SELECT_CURRENT));
			String sTitle = validator.getStringEquivalentForStringList(mlPartDetails.get(DomainConstants.SELECT_ATTRIBUTE_TITLE));

			if(ConstantsUtilIRM.WHERE_USED_TYPE.contains(sType)) {
				mapImpactedParts = ebpbo.getImpactedParts(context,sObjectID,sType);
			}
			else if(ConstantsUtilIRM.IMPACTED_PART_TYPE.contains(sType)) {
				mapImpactedParts = ebpbo.getSpecImpactedPartDetails(context,sObjectID,sType);
			} 
			else if(ConstantsUtil.TYPE_PGAUTHORIZEDTEMPORARYSTANDARD.equalsIgnoreCase(sType)) {
				mapImpactedParts = ebpbo.getRelatedPartDetails(context,sObjectID,sType);
			} 
			else {
				mapImpactedParts = ebpbo.getImpactedPartDetails(context,sObjectID,sType,sName,sRev,sTitle,false);
			}

			hmAttrib.put(ConstantsUtilIRM.IMPACTEDPARTS, mapImpactedParts);

			sp.stop();
			LOGGER.info("WHERE USED MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "AFFECTED PART NAME::"+sName);
		}catch (Exception e) {
			LOGGER.error("Exception in WhereUsed Service IMPL: "+e);
		}
		context.close();
		return hmAttrib;
	}

}
