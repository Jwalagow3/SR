/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaMPMPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaCardBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.MasterPackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPMPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaMPMPServiceImpl implements EnoviaMPMPService  {

	
	private static Logger LOGGER = Logger.getLogger(EnoviaMPMPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
	
	@Override
	public HashMap<String, Map<String, String>> getMPMPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
	    Context context = pool.checkOut();
	    swContext.stop();
	    //SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		try
		{
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- START
			/*StopWatch swContext = new StopWatch();
			swContext.start();
		    Context context = pool.checkOut();
		    swContext.stop();
		    //SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- END
		    LOGGER.info("MPMP CONTEXT ELAPSED TIME : "+swContext.getTime());
		    
		    
		    /**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			String sUserType = sct.getUserType();
			
			//Added by Jwala for the defect #8998 -- START
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//Added by Jwala for the defect #8998 -- END
			
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bManufacturerView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bManufacturerView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			MasterPackagingMaterialPartBO MPMPBO =new MasterPackagingMaterialPartBO();
			DomainObject doMPMP =  MPMPBO.getMPMPDO(context, objId);
			String strCurrent = doMPMP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
				
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType) &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY)
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpPerformChar = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpMaterialResult = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String, String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- START
			Map<String,String> mpReferencePart = new HashMap<String,String>();
			//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- END
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = MPMPBO.getMasterPackagingMaterialPartSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slContextSelects.add(ConstantsUtil.ATL_STATE);
			Map<String, StringList> ChilsObjectSelectableMap = MPMPBO.getMPMPRelatedObjsSelectableMap(context);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);

			if (null == doMPMP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doMPMP.getInfo(context, slContextSelects);
			Map resultMaps = doMPMP.getInfo(context, slContextSelects,MPMPBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("MPMP GETINFO ELAPSED TIME : "+swAttributes.getTime());

			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			//Header Content
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING));		
			String sHasATSAttrVal = util.checkHasATSForSIS(context,resultMaps);
			mpHeaderResult.put(ConstantsUtil.HASATS, sHasATSAttrVal);
			String strHasATS = util.checkHasATSForSIS (context, resultMaps);
			mpHeaderResult.put(ConstantsUtil.HASATS, strHasATS);
			
			mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			String sClassification = util.getClassification(resultMaps);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));

			//Basic  Data
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);

			mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED))));
			mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT));
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.POAIMPACTCONFIRMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOAIMPACTCONFIRMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOAIMPACTCONFIRMATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PROJECTINITIATEMILESTONE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PROJECTMILESTONE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PROJECTMILESTONE) : ConstantsUtil.EMPTY_STRING);
			
			String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String strBrand = util.getBrandInformationValue(context,sID);
			if(strBrand.isEmpty()) {
				strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
			}
			mpAttribResult.put(ConstantsUtil.BRAND, strBrand);

			mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONHEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONDEPTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.INNERWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.INNERLENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.INNERHEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DIMENSIONUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
			
			mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
			String strPrintingProcess=	validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.STRPRINTINGPROSS));
			mpAttribResult.put(ConstantsUtil.PRINTINGPROCESS,strPrintingProcess);
			mpAttribResult.put(ConstantsUtil.DECORATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
			//SPEC: <16.06.2022>: Satyam Added for Internal Defect  -- START
			mpAttribResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
			//SPEC: <16.06.2022>: Satyam Added for Internal Defect  -- END
			mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);		
			mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
			
			
			
			//LifeCycle
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			mpLifeCycleApproval = util.getCOName(context, changeargs);
			
			if(bAllInfoView){
			mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
			}
			swLifecycle.stop();
			LOGGER.info("MPMP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

			//Organization Data
			StopWatch swOrganization = new StopWatch();
			swOrganization.start();
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)));
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)));
			// Modified by Jwala for the defect #44364 -- END
			
			mpOrganization = util.filterMapList(mpOrganization);
			swOrganization.stop();
			LOGGER.info("MPMP Organization ELAPSED TIME : "+swOrganization.getTime());


			/**
			 * LOAD PERFORMANCE CHAR SECTION
			 * */
			StopWatch swPerfChar = new StopWatch();
			swPerfChar.start();
			Map<String, String> paramMap = new HashMap<String, String>();
			paramMap.put(ConstantsUtil.OBJECT_ID, objId);
			paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
			paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
			paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);
			
			FinishedProductPartBO fppBO = new FinishedProductPartBO();
			PefromChar perform = new PefromChar();
			MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
			MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
			String strParentType = (String)resultMaps.get(ConstantsUtil.SELECT_TYPE);
			
			//SPEC: Release SR18x.6.0 - Defect#41472 by gaikwad.tg on Date 05/04/2021 -- START
			if(UIUtil.isNotNullAndNotEmpty(strParentType) && (strParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERPACKINGMATERIAL) || strParentType.equalsIgnoreCase("pgMasterPackingMaterial")))
			{
				FormulaCardBO fcBO = new FormulaCardBO();
				mpPerformChar =  fcBO.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
			}
			else
				mpPerformChar = util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
			swPerfChar.stop();
			LOGGER.info("MPMP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

			//Reference Docs
			StopWatch swReference= new StopWatch();
			swReference.start();
			MasterCOPBO mcop = new MasterCOPBO();
			mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
			swReference.stop();
			LOGGER.info("MPMP REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());

			// Materials
			
			StopWatch swMaterial = new StopWatch();
			swMaterial.start();

			if(bManufacturerView) {
				mpMaterialResult=MPMPBO.updateMaterials(context,doMPMP,true);
				
			}else{
				mpMaterialResult=MPMPBO.updateMaterials(context,doMPMP,false);
			}
			swMaterial.stop();
			LOGGER.info("MPMP  Material ELAPSED TIME : "+swMaterial.getTime());

			//Ownership
			StopWatch swOwnerShip = new StopWatch();
			swOwnerShip.start();
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER,  util.getLastUpdatedUser(context, sContextObjectId));
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS) : ConstantsUtil.EMPTY_STRING);
			//SPEC: 04/23/2020: Added for 18x6.0 Defect# 42725 by Sanjeeva-- END
			
			mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
			swOwnerShip.stop();
			LOGGER.info("MPMP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());

			//RelatedSpec
			StopWatch swRelatedSpec = new StopWatch();
			swRelatedSpec.start();
			mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
			
			swRelatedSpec.stop();
			LOGGER.info("MPMP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());

			//Security
			StopWatch swSecurity = new StopWatch();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			swSecurity.start();
			mpSecurity =commonBo.updateSecurity(context,resultMaps);
			swSecurity.stop();
			LOGGER.info("MPMP  Security ELAPSED TIME : "+swSecurity.getTime());

			
			
			//SPEC: 10.12.2020: Added for req 18x.5 ## -- START
			/**
			 * LOAD IP CLASSES SECTION
			 */
			//IP Class
			
			StringList slIpSelects = new StringList();
			slIpSelects.add(ConstantsUtil.SELECT_NAME);
			slIpSelects.add(ConstantsUtil.SELECT_ID);
			slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
			slIpSelects.add(ConstantsUtil.SELECT_TYPE);
			slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			mpIPClass =commonBo.getIpClass(context, doMPMP, slIpSelects);
			
			String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
			String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
			String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
			StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
			
			//SPEC Added on 12-Dec-2020 by Chandra for Defect 37746 ##--END	
			//SPEC: 30-06-2022: Pooja Added for Internal Defect -- START
			CommonDocBO cdoc = new CommonDocBO();
			String strFileSize = cdoc.updateFileSize(FileSize);
			//SPEC: 30-06-2022: Pooja Added for Internal Defect -- END
			
			mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
			mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
			mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
			mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);
			
			
			//SPEC: <16.06.2022>: Satyam Added for Internal Defect  -- START
			mpPerformChar.remove(ConstantsUtil.CPS);
			mpPerformChar.remove(ConstantsUtil.CPSNAME);
			mpPerformChar.remove(ConstantsUtil.CPSID);
			//SPEC: <29.06.2022>: Satyam Added for Internal Defect  -- END
			
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- START
			MapList mlReferencePartList = util.getReferencePart(context,objId, sUserType);
			mpReferencePart = util.parseReferencePart(context,mlReferencePartList);
			hmAttrib.put(ConstantsUtilIRM.REFERENCE, mpReferencePart);
			//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- END
			
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.MATERIALS, mpMaterialResult);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			if (bAllInfoView) {
				mpIPClass.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
				mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			}
			//SPEC: 26/04/2022: Modified by Manikanta for 22x DEV Req 34418-- END
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			//SPEC: 26/04/2022: Modified by Manikanta for 22x DEV Req 34418-- START
			if (bAllInfoView) {
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: 26/04/2022: Modified by Manikanta for 22x DEV Req 34418-- END
			
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
				hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
				hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			}

			//SPEC: 11-03-2021: Modified for 18x.6 DEV by Madhanagopal -- END

			// Added by Jwala for SIT Stress
			pool.checkIn(context);
		    sp.stop();
		  //SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		    doMPMP.close(context);
		  //SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			LOGGER.info("MPMP Execution TIME::" + sp.getTime() +"  " + "MPMP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
					
		} catch (IOException e) {
				LOGGER.error("Unable to getMPMPdetails "+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getMPMPdetails "+e);
		}
		//LOGGER.info("MPMP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		context.close();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmAttrib;
		}


}