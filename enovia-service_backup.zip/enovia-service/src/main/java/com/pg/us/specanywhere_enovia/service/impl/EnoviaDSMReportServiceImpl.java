/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaIMPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.DSMReportBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaDSMReportService;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import matrix.db.Context;

public class EnoviaDSMReportServiceImpl implements EnoviaDSMReportService{
	
	@Value("${connection.string}")
	private String connectionString;

	@Value("${container.docs}")
	private String containername;
	
	@Value("${azure.store}")
	private String azurestore;

	private static Logger dsmLOGGER = Logger.getLogger(EnoviaDSMReportServiceImpl.class);
	
	private  HttpServletRequest request;
	@Autowired
	private EnoviaConnectionPool pool;
    @Autowired
    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }
	
	StringValidatorUtil validator = new StringValidatorUtil();	

	@Override
	public HashMap<String, Map<String, String>> getDSMReportData(Environment env, String sKey, String sObjId)  {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		dsmLOGGER.info("DSM REPORT SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());
		
		DSMReportBO dsReportbo = new DSMReportBO();
		try 
		{
			String strUserName = getName();
			
			/**
			 * User Profile Section
			 * */
			if(UIUtil.isNullOrEmpty(sKey)) {
				dsmLOGGER.error("ERROR: INVALID Key FROM INTEGRATION SERVICE : "+sKey);
				HashMap<String,String> errorMap = new HashMap<>();
				String[] sError = ConstantsUtil.E102.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				context.close(); // Added for Defect 45181
				return hmAttrib;
			}
			
			if(sKey.equalsIgnoreCase(ConstantsUtilIRM.CONST_REPORTLIST)) {
				
				Map<String, String> mReportList = dsReportbo.getDSMReportData(context, strUserName,connectionString,containername,azurestore);			
				hmAttrib.put(ConstantsUtilIRM.REPORTLIST, mReportList);
			}
			if(sKey.equalsIgnoreCase(ConstantsUtilIRM.CONST_REPORTDETAIL)) {
				
				Map<String, String> mReportHeader = dsReportbo.getDSMReportDetailsHeader(context, sObjId);
				String sOwnerShip = mReportHeader.get(DomainConstants.SELECT_OWNER);
				if(strUserName.equalsIgnoreCase(sOwnerShip)) {
					hmAttrib.put(ConstantsUtil.HEADERCONTENT, mReportHeader);
					Map<String, String> mReportDetail = dsReportbo.getDSMReportDetails(context, sObjId);
					hmAttrib.put(ConstantsUtilIRM.REPORTDETAIL, mReportDetail);
					Map<String, String> mIPClassification = dsReportbo.getDSMReportIPClassification();
					hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mIPClassification);
				}
				else {
					Map<String, String> mReportError = new HashMap<String, String>();
					
					mReportError.put(ConstantsUtilIRM.E121, ConstantsUtilIRM.ERROR_PART_REPORT);
					hmAttrib.put(ConstantsUtil.ERROR, mReportError);
				}
				
			}
			if(sKey.equalsIgnoreCase(ConstantsUtilIRM.CONST_TEMPLATELIST)) {
				
				Map<String, String> mTemplateList = dsReportbo.getDSMReportTemplateData(context, strUserName);				
				hmAttrib.put(ConstantsUtilIRM.TEMPLATELIST, mTemplateList);
			}		
			if(sKey.equalsIgnoreCase(ConstantsUtilIRM.CONST_TEMPLATEDETAIL)) {
				Map<String, String> mTemplateDetail = dsReportbo.getDSMreportTemplateDetails(context, sObjId);				
				hmAttrib.put(ConstantsUtilIRM.TEMPLATEDETAIL, mTemplateDetail);
			}			
		}catch (Exception e) {
			dsmLOGGER.error("Exception in DSM Report Service IMPL: "+e);			
		}
		pool.checkIn(context);
		sp.stop();
		dsmLOGGER.info("DSM Report SERVICE GETINFO ELAPSED TIME : "+sp.getTime());
		dsmLOGGER.info("DSM Report Service IMPL Return:"+hmAttrib);
		//SPEC: <25-07-2022>: Manikanta Added for Defect 45181  -- START
		context.close();
		//SPEC: <25-07-2022>: Manikanta Added for Defect 45181  -- END
		return hmAttrib;		
	}
	
	private String getName() {
		String strAccessToken = request.getHeader(ConstantsUtilIRM.ACCESSTOKEN);  
		String strName=ConstantsUtil.EMPTY_STRING;
		
		if(strAccessToken!=null) {
		DecodedJWT jwt = JWT.decode(strAccessToken);
		strName=jwt.getClaim(ConstantsUtilIRM.USERNAME).asString();
			}
		dsmLOGGER.info("DSM Report SERVICE Application Login User : "+strName);
		return strName;
		
	}
}
