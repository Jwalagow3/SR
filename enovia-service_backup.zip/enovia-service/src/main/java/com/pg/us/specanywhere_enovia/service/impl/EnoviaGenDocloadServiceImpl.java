package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.bo.POAARTBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaGenDocloadService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaGenDocloadServiceImpl implements EnoviaGenDocloadService {
	private static Logger LOGGER = Logger.getLogger(EnoviaARMPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	@Autowired
	private HttpServletRequest request;
	@Override
	public String getGendocPayloaddata(Environment env, String sObjectName) {
		// TODO Auto-generated method stub
		String hmObj = ConstantsUtilIRM.EMPTY_STRING;
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		MapList mlObjectList = new MapList();
		Map<String, String> mpData = new HashMap<String, String>();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		try {
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- START
			/*StopWatch swContext = new StopWatch();
			swContext.start();
			Context context = pool.checkOut();
			swContext.stop();*/
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- END
			LOGGER.info("ARMP CONTEXT ELAPSED TIME : "+swContext.getTime());
			
			StringList slObjectsSelect = new StringList();
			slObjectsSelect.add(DomainConstants.SELECT_ID);
			slObjectsSelect.add(DomainConstants.SELECT_CURRENT);
			slObjectsSelect.add(DomainConstants.SELECT_TYPE);
			slObjectsSelect.add(ConstantsUtil.SELECT_REVISION);
			slObjectsSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
			slObjectsSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			slObjectsSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
			
			mlObjectList = DomainObject.findObjects
					(context, //MatrixContext
							DomainConstants.QUERY_WILDCARD, //typePattern
							sObjectName, //namePattern
							DomainConstants.QUERY_WILDCARD, //revPattern
							DomainConstants.QUERY_WILDCARD, //ownerPattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
							ConstantsUtilIRM.CURRENT_RELEASE, //whereExpression
							false, //expandType
							slObjectsSelect); //objectSelects
		Iterator<MapList> objectListItr = mlObjectList.iterator();
		Map<String, String> mpObject = (Map<String, String>)mlObjectList.get(0);
		
		
		String sId = mpObject.get(ConstantsUtil.ID);
		String	sCurrent = mpObject.get(DomainConstants.SELECT_CURRENT);
		String	sType = mpObject.get(DomainConstants.SELECT_TYPE);
		String	sClassification = mpObject.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		String	sRevision = mpObject.get(ConstantsUtil.SELECT_REVISION);
		
		Map<String,String> mpResult = new HashMap<String,String>();
		Map<String,String> mpResultForAuth = new HashMap<String,String>();
		Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpFiles = new HashMap<String,String>();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		POAARTBO poaBO = new POAARTBO();
		CommonDocBO cdoc = new CommonDocBO();
		/**
		 * User Profile
		 * */
		SecurityService sct = new SecurityService();
		String sUserType = sct.getUserType();
		BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
		if(UIUtil.isNotNullAndNotEmpty(sUserType))
		{
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, sId);
			}
		}
		if(null==sUserType) {
			LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
			String errorMap = ConstantsUtilIRM.EMPTY_STRING;
			String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
			errorMap = sError[1];
			
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
			context.close();
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
			return errorMap;
		}

		//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
		boolean bAllInfoView = false;
		boolean bSupplierView = false;
		boolean bManufacturerView = false;
		
		StringValidatorUtil validator = new StringValidatorUtil();
		String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
		LOGGER.info("PDF VIEW Info : "+strPDFView);
					
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				bManufacturerView = true;
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				bSupplierView = true;
			} else {
				switch (sUserType) {
				case ConstantsUtil.PG:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PGSTAFF:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PG_CM:
					bManufacturerView = true;
					break;

				case ConstantsUtil.PG_SP:
					bSupplierView = true;
					break;
				}

			}
		mpResult.put(DomainConstants.SELECT_TYPE, sType);
		mpResult.put(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION, sClassification);
		String sClassifictaion = util.getClassification(mpResult);
		
		FormulaPartBO formulationPartBO = new FormulaPartBO();
		DomainObject doId =  formulationPartBO.getFopDO(context, sId);
		String sSpecType = doId.getInfo(context, DomainConstants.SELECT_TYPE);
		String sSpType = util.mapType(sType);
		boolean bisIRMDoc = cdoc.isIRMDoc(sSpecType);
		
		BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
		boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,sId);
		//For POA and ART
		if(bObjectHasAccess) {
			if(sType.equalsIgnoreCase("POA") || sType.equalsIgnoreCase(ConstantsUtilIRM.ART)) {
				mpHeaderContent.put(ConstantsUtil.TYPE,util.mapType(sType));
				mpHeaderContent.put(ConstantsUtil.NAME,sObjectName);
				mpHeaderContent.put(ConstantsUtil.REVISION, sRevision);
				mpHeaderContent.put(ConstantsUtil.STATE, sCurrent);		
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassification);
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)mpObject.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)mpData.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)mpObject.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)mpData.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				String sGendoc =util.getGenDocFile(context,doId);
				mpHeaderContent.put(ConstantsUtilIRM.GENDOC, sGendoc);
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
				} else {
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
				}
				
				StringList busSelect = new StringList();
				busSelect.add(ConstantsUtil.STR_FILE_NAME);
				busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
				busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
				busSelect.add(ConstantsUtil.STR_FILE_SIZE);
				StringList addMultiList = new StringList();
				addMultiList.add(ConstantsUtil.STR_FILE_NAME);
				addMultiList.add(ConstantsUtil.STR_FORMAT_FILE);
				addMultiList.add(ConstantsUtil.STR_FILE_CAPTURED);
				addMultiList.add(ConstantsUtil.STR_FILE_SIZE);
				Map resultMaps = doId.getInfo(context, busSelect,addMultiList);
				
				
				if(sType.equals(ConstantsUtilIRM.ART))
				{
					String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
					String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
					String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
					StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
					//SPEC: 28-07-2022: Pooja Added for Internal Defect -- START
					String strFileSize = cdoc.updateFileSize(FileSize);
					//SPEC: 28-07-2022: Pooja Added for Internal Defect -- END
					StringTokenizer tokenizer = new StringTokenizer(FileFormats,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					StringBuilder sbTokenIndex = new StringBuilder();

					if(tokenizer.countTokens()>1) {
						int count = tokenizer.countTokens();
						for(int i = 0; i<count;i++) {
							String sFormat = tokenizer.nextToken();
							if(sFormat.trim().equalsIgnoreCase("generic")){
								sbTokenIndex.append(i).append(ConstantsUtil.SYMBL_COMMA);
							}
						}
					StringBuilder sbFilename = validator.tokenizeFiles(FileName,sbTokenIndex);
					StringBuilder sbFileCapturedFie = validator.tokenizeFiles(FileCapturedFie,sbTokenIndex);
					StringBuilder sbFileFormats = validator.tokenizeFiles(FileFormats,sbTokenIndex);
					StringBuilder sbFileSize = validator.tokenizeFiles(strFileSize,sbTokenIndex);

					mpFiles.put(ConstantsUtil.FILESPATH, sbFileCapturedFie.toString());
					mpFiles.put(ConstantsUtil.FILESFORMAT, sbFileFormats.toString());
					mpFiles.put(ConstantsUtil.FILESNAMES, sbFilename.toString());
					mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());
				} else {
					if(!FileFormats.contains("generic")) {
						mpFiles.put(ConstantsUtil.FILESPATH, FileCapturedFie.toString());
						mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats.toString());
						mpFiles.put(ConstantsUtil.FILESNAMES, FileName.toString());
						mpFiles.put(ConstantsUtil.FILESSIZES, FileSize.toString());
					}
				}
				}
				else
				{
					MapList mlFiles=(MapList)poaBO.getReferenceFileObjects(context,sId);
					mpFiles=poaBO.parseMaplistForFiles(context,mlFiles);
				}
				mpFiles.put(ConstantsUtilIRM.ATTRIBUTES,ConstantsUtilIRM.CURLYBRACES);
				mpFiles.put(ConstantsUtilIRM.CALLEDFROM,ConstantsUtil.SYMBL_PIPE);
				mpFiles.put(ConstantsUtil.TITLE,ConstantsUtil.SYMBL_PIPE);
				mpFiles.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent.toString());
				hmObj =mpFiles.toString();			
			}
			//For IRM
			else if(bisIRMDoc) {
				mpHeaderContent.put(ConstantsUtil.TYPE,util.mapType(sType));
				mpHeaderContent.put(ConstantsUtil.NAME,sObjectName);
				mpHeaderContent.put(ConstantsUtil.REVISION, sRevision);
				mpHeaderContent.put(ConstantsUtil.STATE, sCurrent);		
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassification);
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)mpObject.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)mpData.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)mpObject.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)mpData.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				//String sGendoc =util.getGenDocFile(context,doId);
				//mpHeaderContent.put(ConstantsUtilIRM.GENDOC, sGendoc);
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
				} else {
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
				}
				mpFiles=cdoc.getIRMDocFiles(context, doId);
				mpHeaderContent.put(ConstantsUtilIRM.GENDOC,mpFiles.get(ConstantsUtilIRM.GENDOC));
				mpFiles.remove(ConstantsUtilIRM.GENDOC);
				mpFiles.put(ConstantsUtil.ATTRIBUTES,ConstantsUtilIRM.CURLYBRACES);
				mpFiles.put(ConstantsUtilIRM.CALLEDFROM,ConstantsUtil.SYMBL_PIPE);
				mpFiles.put(ConstantsUtil.TITLE,ConstantsUtil.SYMBL_PIPE);
				mpFiles.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent.toString());
				hmObj =mpFiles.toString();	
			}
			//Added by Ajay for Defect 120878 -- START
			else if(sSpType.equalsIgnoreCase(ConstantsUtil.STRING_TYPE_APP) || sSpType.equalsIgnoreCase(ConstantsUtilIRM.PG_DPP) || sSpType.equalsIgnoreCase(ConstantsUtil.tFOP) || sSpType.equalsIgnoreCase(ConstantsUtilIRM.PG_IPP)) {
				boolean bGendocView=false;
				StringList slObjectsAutSelect = new StringList();
				slObjectsAutSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
				slObjectsAutSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
				boolean bHIRComplaint = util.getHIRComplaintForSupplier(context,doId,mpResultForAuth);
				mpResultForAuth = doId.getInfo(context,slObjectsAutSelect);
				boolean bAuthorizedtoProduce = util.isAuthorizedtoProduce(context,doId,mpResultForAuth,strPDFView);
				if((bManufacturerView && bAuthorizedtoProduce) || ((bSupplierView && bHIRComplaint))) {
					bGendocView = true;
				}
				//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43107 on Date 26/05/2021 --START
				if((util.isModificatinRequired() && bHIRComplaint)) {
					bGendocView = true;
				}
				if(bGendocView) {
					hmObj=sId;
				}else if(bAllInfoView){
					hmObj=sId;
				}
				else {
					hmObj=null;
				}
				//Added by Ajay for Defect 120878 -- END
			}
			else {
				hmObj=sId;
			}

		}
		else {
			hmObj = null;
		}
				//SPEC: Added by Ajay for Defect. no. 117048 START
		
		
		}catch (MatrixException e) {
			LOGGER.error("Unable to getGendodata MatrixException: "+e);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		context.close();
		return hmObj;
	}

}
