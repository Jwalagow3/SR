package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.PQRBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaPQRService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaPQRServiceImpl implements EnoviaPQRService{

	private static Logger LOGGER = Logger.getLogger(EnoviaPQRServiceImpl.class);

	@Autowired
	private EnoviaConnectionPool pool;

	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END

	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
	private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String,String>> getPQRData(String objId, Environment env) throws Exception {
		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("PQR CONTEXT ELAPSED TIME : "+swContext.getTime());

		try {

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();

			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}

			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;

			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);

			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				bManufacturerView = true;
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				bSupplierView = true;
			} else {
				switch (sUserType) {
				case ConstantsUtil.PG:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PGSTAFF:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PG_CM:
					bManufacturerView = true;
					break;

				case ConstantsUtil.PG_SP:
					bSupplierView = true;
					break;
				}

			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpReferenceDocs = new HashMap<String,String>();
			Map<String,String> mpQualifiedEqu = new HashMap<String, String>();
			Map<String,String> mpPlants = new HashMap<String, String>();

			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();

			ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);

			PQRBO pqrBO = new PQRBO();
			Map BusinessObjectSelectableMap = pqrBO.getPQRSelectableMap(context);
			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

			DomainObject doPQR = pqrBO.getPqrDO(context, objId);
			//START :: gaikwad.tg
			pqrBO.addMultiList();
			//END :: gaikwad.tg
			if (null == doPQR) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			StopWatch swAttributes = new StopWatch();
			swAttributes.start();			
			//Map resultMap = doPQR.getInfo(context, slSelects,plantSelect);
			Map resultMap = doPQR.getInfo(context, slSelects,pqrBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("PQR GETINFO ELAPSED TIME : "+swAttributes.getTime());
			Map BusinessObjectRelSelectableMap = pqrBO.getPqrRelatedObjsSelectableMap(context);

			String sID = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			//START :: gaikwad.tg
			/**
			 * LOAD HEADER SECTION
			 * */

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.TYPE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)))?busUtil.mapType((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, pqrBO.getOriginatorName(context,resultMap,ldapuser,ldappwd));
			//END :: gaikwad.tg
			/**
			 * ATTRIBUTES SECTION
			 */
			mpAttribResult.put(ConstantsUtil.QUALIFICATIONNAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);

			mpAttribResult.put(ConstantsUtil.PREFERENCE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREFERENCESCORE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCESCORE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCESCORE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.QUALIFICATIONDESC, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONDESCRIPTION) : ConstantsUtil.EMPTY_STRING);

			String strTpeConnToPqr = (String)resultMap.get(ConstantsUtilIRM.CONNECTED_TYPE_TO_PQR);
			String strManufacturer = DomainConstants.EMPTY_STRING;
			String strEquPartExpr = DomainConstants.EMPTY_STRING;
			String strResponsibilityName = DomainConstants.EMPTY_STRING;
			if(!strTpeConnToPqr.equalsIgnoreCase(ConstantsUtil.POLICY_SEPEQUIVALENT))
			{
				strEquPartExpr = ConstantsUtilIRM.STR_SELECT_MANU_EQU_PARTS;
				strResponsibilityName = ConstantsUtil.STR_SELECT_PLANT_NAME;
			}
			else
			{
				strEquPartExpr = ConstantsUtilIRM.STR_SELECT_SUPP_EQU_PARTS;
				strResponsibilityName = ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_NAME;
			}
			String strManuEquiID = (String)resultMap.get(strEquPartExpr);
			if(UIUtil.isNotNullAndNotEmpty(strManuEquiID))
			{
				DomainObject domSepEqvPartID = DomainObject.newInstance(context, strManuEquiID);

				StringList slSelectNew = new StringList();
				slSelectNew.add(strResponsibilityName);

				DomainConstants.MULTI_VALUE_LIST.add(strResponsibilityName);
				Map resultSepEqvMaps = domSepEqvPartID.getInfo(context, slSelectNew);
				DomainConstants.MULTI_VALUE_LIST.add(strResponsibilityName);

				strManufacturer = validator.getStringEquivalentForStringList(resultSepEqvMaps.get(strResponsibilityName));
			}
			if(!strTpeConnToPqr.equalsIgnoreCase(ConstantsUtil.POLICY_SEPEQUIVALENT)) {
				mpAttribResult.put(ConstantsUtil.MANUFACTURER, strManufacturer);
			}else {
				mpAttribResult.put(ConstantsUtil.SUPPLIER, strManufacturer);
				mpAttribResult.put(ConstantsUtil.MANUFACTURER, ConstantsUtil.EMPTY_STRING);
			}

			mpAttribResult.put(ConstantsUtil.MANUFACTURERLINES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURERLINES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURERLINES) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LOCATIONSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCATIONSTATUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCATIONSTATUS) : ConstantsUtil.EMPTY_STRING);

			if(bAllInfoView) {
				mpAttribResult.put(ConstantsUtil.BUSINESSAREA, validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA)));
			}

			if(bAllInfoView) {
				// START of Logic for Product Category Platform (PCP)
				StringList busSelect = new StringList();
				busSelect.add(ConstantsUtil.SELECT_ID);
				busSelect.add(ConstantsUtil.SELECT_TYPE);
				busSelect.add(ConstantsUtil.SELECT_NAME);

				StringList relSelect = new StringList();
				relSelect.add(ConstantsUtil.EMPTY_STRING);

				DomainObject dom = new DomainObject(sID);
				MapList mlPCP = dom.getRelatedObjects(context,ConstantsUtil.RELATIONSHIP_PGDOCUMENTTOPLATFORM, ConstantsUtil.QUERY_WILDCARD, busSelect,
						relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				dom.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				Iterator objectListItr = mlPCP.iterator();
				String slPCPDetails = ConstantsUtil.EMPTY_STRING;
				StringBuilder PCP = new StringBuilder();
				while(objectListItr.hasNext())
				{
					Map mpTemp = (Map) objectListItr.next();
					slPCPDetails = (String)mpTemp.get(ConstantsUtil.SELECT_NAME);
					pqrBO.formatDataforPCP(PCP,slPCPDetails);	
				}
				String slProductCategoryPlatform = PCP.toString();

				if(!slProductCategoryPlatform.isEmpty())
					slProductCategoryPlatform = slProductCategoryPlatform.substring(0, slProductCategoryPlatform.length()-1);
				// END of Logic for Product Category Platform (PCP)

				mpAttribResult.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM, slProductCategoryPlatform);
			}

			mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);


			/**
			 * REFERENCE DOCUMENTS SECTION
			 */
			StopWatch swReference= new StopWatch();
			swReference.start();
			CommonDocBO docBo =new CommonDocBO();
			mpReferenceDocs = docBo.getReferenceDocsForIRM(context, resultMap,false);
			swReference.stop();
			LOGGER.info("PQR REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());


			/**
			 * QUALIFIED EQUIVALENTS SECTION
			 */
			StopWatch swQualifiedEq= new StopWatch();
			swQualifiedEq.start();
			mpQualifiedEqu = pqrBO.getQualifiedEquivalent(context,resultMap);
			swQualifiedEq.stop();
			LOGGER.info("PQR QUALIFIED EQUIVALENTS ELAPSED TIME : "+swQualifiedEq.getTime());

			/**
			 * PLANTS SECTION
			 */
			if(bManufacturerView){
				StringList plantList = validator.getStringListEquivalentForString(resultMap.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
				String strUserOwnership =sct.getUserCauthorities();
				String[] aCompany = BObjutil.splitCompanyValues(context,strUserOwnership);
				StringList slUserOwnership =new StringList();
				if (aCompany.length > -1) {
					for (int i = 0; i < aCompany.length; i++) {
						if (null != aCompany[i]) {
							String company = aCompany[i];
							slUserOwnership.add(company.trim());
						}
					}
				}
				StringBuilder plantBuilder =pqrBO.getManufacturerPlants(plantList,slUserOwnership);
				mpPlants.put(ConstantsUtil.PLANTS,plantBuilder.toString());
			}else{
				mpPlants.put(ConstantsUtil.PLANTS, (validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME))));
			}
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mpReferenceDocs);
			hmAttrib.put(ConstantsUtil.QUALIFIEDEQUIVALENT, mpQualifiedEqu);
			if (!bSupplierView){
				hmAttrib.put(ConstantsUtil.PLANTS, mpPlants);
			}
			ContextUtil.popContext(context);
			pool.checkIn(context);
			sp.stop();

		} catch (IOException e) {
			LOGGER.error("IOException from PQR "+e);
		} catch (MatrixException e) {
			LOGGER.error("MatrixException from PQR "+e);
		}
		context.close();
		//LOGGER.info("PQR Structured RESPONSE MESSAGE:: \n" + hmAttrib);
		return hmAttrib;
	}
}
