/**
 * Project 		: SpecsAnywhere
 * Program 		: PackagingAssemblyPartImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.ConsumerUnitPartBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.InnerPackBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCUPBO;
import com.pg.us.specanywhere_enovia.bo.PackagingAssemblyPart;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.bo.SapBomAsFed;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaPackagingAssemblyPart;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class PackagingAssemblyPartImpl implements EnoviaPackagingAssemblyPart {

	private static Logger LOGGER = Logger.getLogger(PackagingAssemblyPartImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END

	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
	private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getPAPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		Context context = null;
		try
		{
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			swContext.stop();
			LOGGER.info("PAP CONTEXT ELAPSED TIME : "+swContext.getTime());
			
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
				
			PackagingAssemblyPart PAPBO = new PackagingAssemblyPart();
			DomainObject doPAP =  PAPBO.getPAPDO(context, objId);
			String strCurrent = doPAP.getInfo(context, DomainConstants.SELECT_CURRENT);
			
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			//SPEC: Modified by Ajay for Req. no. 23961 START
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;

				}
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {

					HashMap<String, String> errorMap = new HashMap<String, String>();
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC: Added by Ajay for Req. no. 23961 END
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END

			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpWeightResult = new HashMap<String,String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Map<String,String> mpSubstitute = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpPartSpecResult = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mpPerformChar = new HashMap<String,String>();			
			Map<String,String> mapCosResult = new HashMap<String,String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();					
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String>  mpLifeCycle = new HashMap<String,String>();
			//SPEC: 10/19/2020: Added for req 18x.5 ## -- START
			Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
			Map<String,String> mpMEPResult = new HashMap<String,String>();
			Map<String,String> mpSEPResult = new HashMap<String,String>();
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();

			//SPEC: Added for Dev 18x.6 Release by Jwala -- START
			Map<String,String> mpAlternates = new HashMap<String,String>();
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			Map<String,String> mpRegistrationDetails = new HashMap<String,String>();
			//SPEC: Added for Dev 18x.6 Release by Jwala -- END
			//Added by Pooja for the req 35902,41754,33476 -- START
			Map<String,String> mpMaterialResult = new HashMap<String,String>();
			Map<String,String> mpCertDetails = null;
			//Added by Pooja for the req 35902,41754,33476 -- END
			InnerPackBO IPBO = new InnerPackBO();

			//SPEC: 10/19/2020: Added for req 18x.5 ## -- END

			MasterCOPBO mcop = new MasterCOPBO();
			MasterCUPBO mcup = new MasterCUPBO();
			ConsumerUnitPartBO CopBO = new ConsumerUnitPartBO();
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = PAPBO.getPAPPartSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = PAPBO.getPAPRelatedObjsSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
			
			if (null == doPAP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doPAP.getInfo(context, slContextSelects, PackagingAssemblyPart.getPlantSelects(context));
			Map resultMaps = doPAP.getInfo(context, slContextSelects,PAPBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("PAP GETINFO ELAPSED TIME : "+swAttributes.getTime());


			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			String sClassifictaion = util.getClassification(resultMaps);

			if(bAllInfoView || bSupplierView || bManufacturerView) {
				//Basic  Data
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);

				//SPEC: 10/19/2020: Added by Jwala for 18x.6 External DEV -- START
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strSegment)))?(String)resultMaps.get(ConstantsUtil.strSegment) : ConstantsUtil.EMPTY_STRING);
				//Added jwala for Internal Defect for EBP - START
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
				//Added jwala for Internal Defect for EBP - END
				//SPEC: 10/19/2020: Added by Jwala for 18x.6 External DEV -- END

				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);

				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LEGACY_ENV_CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.LEGACYENVCLASSNAME)))?(String)resultMaps.get(ConstantsUtil.LEGACYENVCLASSNAME) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.POWERSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
				if(!bSupplierView) {
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
				//HeaderContent
				mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);

				if(!bManufacturerView && !bSupplierView){
					mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				}

				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			    mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);

				//SPEC: 10/19/2020: Added for 18x.5 DEV -- START
				mpHeaderContent.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderContent.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				mpHeaderContent.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))));
				//SPEC: 10/19/2020: Added for 18x.5 DEV -- END


				/**
				 * LOAD WEIGHT SECTION
				 * */
				//Supplier View & All Info View
				mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				mpWeightResult.put(ConstantsUtil.LEGACYPRODUCTWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYPRODUCTWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYPRODUCTWEIGHT) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.LEGACYWIGHTFACTOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTOR) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.LEGACYWIGHTFACTORUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTORUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTORUOM) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult = util.filterMapList(mpWeightResult);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END

				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				/**
				 * LOAD SAP BOM SECTION
				 * */
				StopWatch swSapBomAsFed = new StopWatch();
				swSapBomAsFed.start();
				CalculateBOM clBom = new CalculateBOM();

				SapBomAsFed sapBom = new SapBomAsFed();
				mpSapBomAsFedcResult = sapBom.getSapBOMasFed(context,sContextObjectId);

				//The below fields have been removed from 18x.6 template. Since SAPBOM as fed is common method handling here.
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZED);
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOUSE);
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOPRODUCE);
				
				mpSapBomAsFedcResult.remove(ConstantsUtil.MAX);
				mpSapBomAsFedcResult.remove(ConstantsUtil.MIN);
				
				mpSapBomAsFedcResult = util.filterMapList(mpSapBomAsFedcResult);
				swSapBomAsFed.stop();
				LOGGER.info("PAP GET SapBomAsFed ELAPSED TIME : "+swSapBomAsFed.getTime());

				/**
				 * LOAD MARKET OF SALE
				 * */
				String strCosDateAndTime = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE));
				FabricatedPartBO FABBO = new FabricatedPartBO();
				mapCosResult = FABBO.getMarketOfSale(context,sContextObjectId);
				mapCosResult.put(ConstantsUtil.DATEANDTIMEOFLASTMOSCALC, strCosDateAndTime);
				mapCosResult = util.filterMapList(mapCosResult);

				/**
				 * LOAD IP CLASSES SECTION
				 */
				
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				
				CommonBusUtilBO commonBO = new CommonBusUtilBO();
				mpIpSecuritySetting =commonBO.getIpClass(context, doPAP, slIpSelects);
				
				/**
				 * SECURITY SECTION
				 * */
				StopWatch swSecurity = new StopWatch();
				swSecurity.start();
				CommonBusUtilBO commonBo = new CommonBusUtilBO();
				mpSecurity =commonBo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				
				LOGGER.info("PAP  Security ELAPSED TIME : "+swSecurity.getTime());

				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=util.getRelatedAts(context, doPAP);

				mpRelatedATS=util.filterMapList(mpRelatedATS);
				if(!mpRelatedATS.isEmpty()){
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
					//mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
					//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
				}

				if(bManufacturerView || bSupplierView) {
					mpRelatedATS=util.filterPhase(mpRelatedATS);
				}
				swAts.stop();
				LOGGER.info("PAP ATS ELAPSED TIME : "+swAts.getTime());

				//SPEC: Added for Dev 18x.6 Release by Jwala -- END

				//Notes 
				mpNotes=mcop.updateNotes(context, resultMaps);

				//BOM
				StopWatch swBom = new StopWatch();
				swBom.start();
				MapList mapList = doPAP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slChildBusSelects , slChildRelSelects, false, true, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, 0);
				if(bSupplierView || bManufacturerView) {
					mapList=util.filterPhase(mapList);
				}
				if(mapList.size()!=0){

					//SPEC: 10/29/2020: modified for 18x.5 DEV  defect 36617-- START
					mpEBOMResult =PAPBO.parseMaplist(context,mapList);
					//Added by Ketan for Req no. 46464 -- START
					if(bSupplierView) {
						mpEBOMResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTION);
						mpEBOMResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS);
					}
					//Added by Ketan for Req no. 46464 -- END
					mpSubstitute =  commonBO.parseSubstitute(context,mapList);
					//Added by Ketan for Req no. 46464 -- START
					if(bSupplierView) {
						mpSubstitute.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTION);
						mpSubstitute.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS);
					}
					//Added by Ketan for Req no. 46464 -- END

				}
				swBom.stop();
				LOGGER.info("PAP BOM ELAPSED TIME : "+swBom.getTime());

				//Performance Char
				/**
				 * LOAD PERFORMANCE CHAR SECTION
				 * */
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				Map<String, String> paramMap = new HashMap<String, String>();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				FinishedProductPartBO fppBO = new FinishedProductPartBO();
				PefromChar perform = new PefromChar();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
			
				MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
				mpPerformChar = util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
				//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
				swPerfChar.stop();
				LOGGER.info("PAP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

				//Part Spec Data
				StopWatch swPartSpec = new StopWatch();
				swPartSpec.start();
				mpPartSpecResult = util.updatePartSpec(context,resultMaps);
				swPartSpec.stop();
				LOGGER.info("PAP GET UPDATE PART ELAPSED TIME : "+swPartSpec.getTime());

				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
				swReference.stop();
				LOGGER.info("PAP  Reference ELAPSED TIME : "+swReference.getTime());


				/**
				 * MASTER SPECIFICATION
				 * */

				StopWatch swmpMasterSpecs = new StopWatch();
				swmpMasterSpecs.start();
				mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
				LOGGER.info("PAP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());

				//SPEC: Commented by Jwala for req 18x.6 DEV ## -- START
				/**
				 * LOAD MASTER ATTRIBUTE DATA SECTION
				 * *//*

				/**
				 * ALTERNATES
				 * */
				mpAlternates = commonBO.getAlternates(context, sContextObjectId);
				if(bSupplierView || bManufacturerView) {
					mpAlternates=util.filterPhase(mpAlternates);
				}
				mpAlternates = util.filterMapList(mpAlternates);

				//Organization Data
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = util.filterMapList(mpOrganization);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END

				if(!bSupplierView){
					//SPEC: Added for Dev 18x.6 Release by Jwala -- START
					/**
					 * LOAD REGISTRATION DETAILS
					 * */
					StopWatch swRegD = new StopWatch();
					swRegD.start();
					mpRegistrationDetails=commonBo.getRegistrationDetails(context, objId);
					mpRegistrationDetails=util.filterMapList(mpRegistrationDetails);
					swRegD.stop();
					LOGGER.info("PAP REGISTRATION DETAILS ELAPSED TIME : "+swRegD.getTime());
					//SPEC: Added for Dev 18x.6 Release by Jwala -- END
					
					
				}

			}
			if(bSupplierView || bManufacturerView) {
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
			}

			if(bAllInfoView) {

				mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_VAULT)))?(String)resultMaps.get(ConstantsUtil.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				
				mpAttribResult.put(ConstantsUtil.ALTERNATIVEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				
				mpAttribResult.put(ConstantsUtil.OUTER_DIM_LENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OUTER_DIM_WIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTR_OUTER_DIMENSION_WIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTR_OUTER_DIMENSION_WIDTH) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OUTER_DIM_HEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CONSUMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.UNNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PROPERSHIPPINGNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.HAZARDCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKINGGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);


				//Plant Data
				mpPlantResult = util.updatePlantInfo(resultMaps);

				//Lifecycle
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				
				mpLifeCycle = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("PAP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.CO)))?(String)mpLifeCycle.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				mpLifeCycleApproval.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.NAME)))?(String)mpLifeCycle.get(ConstantsUtil.NAME) : ConstantsUtil.EMPTY_STRING);
				mpLifeCycleApproval.put(ConstantsUtil.APPROVER, (validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycle.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
				
				mpLifeCycleApproval.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.TITLE)))?(String)mpLifeCycle.get(ConstantsUtil.TITLE) : ConstantsUtil.EMPTY_STRING);
				mpLifeCycleApproval.put(ConstantsUtil.APPROVALSTATUS, util.mapType((validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.APPROVALSTATUS)))?(String)mpLifeCycle.get(ConstantsUtil.APPROVALSTATUS) : ConstantsUtil.EMPTY_STRING));
				// SPEC: Added for 18x.5.2 Defect #38718 --Bala -- START
				//mpLifeCycleApproval.put(ConstantsUtil.APPROVALDATE, (validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.APPROVALDATE)))?validator.DateFormatter((String)mpLifeCycle.get(ConstantsUtil.APPROVALDATE)) : ConstantsUtil.EMPTY_STRING);	
				mpLifeCycleApproval.put(ConstantsUtil.APPROVALDATE, (validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.APPROVALDATE)))?(String)mpLifeCycle.get(ConstantsUtil.APPROVALDATE) : ConstantsUtil.EMPTY_STRING);	
				mpLifeCycleApproval.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.COMMENTS)))?(String)mpLifeCycle.get(ConstantsUtil.COMMENTS) : ConstantsUtil.EMPTY_STRING);
				// SPEC: Added for 18x.5.2 Defect #38718 --Bala -- END
				LOGGER.info("PAP GET LIFECYCLE : "+mpLifeCycleApproval);

				//Ownership
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strSegment)))?(String)resultMaps.get(ConstantsUtil.strSegment) : ConstantsUtil.EMPTY_STRING);				
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(DomainConstants.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: 08-05-2020: Modified for 18x.6 DEV by Jwala -- END
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycle.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				String strUniqueApprovers = validator.removeDuplicateValues((String)mpLifeCycle.get(ConstantsUtil.TASKAPPROVERS));
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty(strUniqueApprovers))?strUniqueApprovers : ConstantsUtil.EMPTY_STRING);
				//SPEC: 08-05-2020: Modified for 18x.6 DEV by Jwala -- END
				String sCoOwner = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS) : ConstantsUtil.EMPTY_STRING;
				String sCoOwnerActual = util.getLDAPInfo(sCoOwner,true,ldapuser,ldappwd);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty(sCoOwnerActual))?(sCoOwnerActual) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
				
				/**
				 * FILES
				 * */

				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));

				//	SPEC	 Added on 12-Dec-2020 by Chandra for Defect 37746 ##--END
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
				CommonDocBO cdoc = new CommonDocBO();
				String strFileSize = cdoc.updateFileSize(FileSize);
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);
				//SPEC: 10/12/2020:: Added for req 18x.5 ## -- END

				//SPEC: Added by Jwala for Dev 18x.6 Release by Jwala -- START
				/**
				 * LOAD GPSASSESSMENTS SECTION
				 * */
				StopWatch swgps= new StopWatch();
				swgps.start();
				DeviceProductPartBO DPPBO = new DeviceProductPartBO();
				mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
				mpGPSAssessments = util.filterMapList(mpGPSAssessments);
				swgps.stop();
				LOGGER.info("PAP  GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
				//SPEC: Added by Jwala for Dev 18x.6 Release by Jwala -- END
			}

			//SPEC: Modified by Jwala for Dev 18x.6 Release by Jwala -- START
			//if(bManufacturerView || bAllInfoView) {
			if(bManufacturerView || bAllInfoView || bSupplierView) {
				//SPEC: Modified by Jwala for Dev 18x.6 Release by Jwala -- END
				/**
				 * This Method is for getting the MEPS
				 * @param context
				 * @param Relationship
				 * @param objectMap
				 * @param bMEP
				 * @return
				 * @throws Exception
				 */
				
				mpMEPResult = util.getPQREquivalents(context, resultMaps, true, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT,sUserType);
				
				// Added by Jwala for Req/Defect 35581 43951 -- START
				if(bManufacturerView || bSupplierView){
					mpMEPResult.remove(ConstantsUtil.PQRBA);
					mpMEPResult.remove(ConstantsUtil.PQRPCP);
					//Modified by Jwala for 22x Development Req 42996 -- START
					if(bSupplierView){
						mpMEPResult.remove(ConstantsUtil.PQRPLANTS);
					}
					//Modified by Jwala for 22x Development Req 42996 -- END
				}
				// Added by Jwala for Req/Defect 35581 43951 -- END
				
				//SPEC: 23-12-2022: Ketan added for Req 34055 -- START
                if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
                	mpMEPResult = new HashMap<String,String>();
                }
                //SPEC: 23-12-2022: Ketan added for Req 34055 -- END

				/**
				 * This Method is for getting the SEPS 
				 * @param context
				 * @param Relationship
				 * @param objectMap
				 * @param bSEP
				 * @return
				 * @throws Exception
				 */

				mpSEPResult = util.getPQREquivalents(context, resultMaps, false, ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT,sUserType);
				
				// Added by Jwala for Req/Defect 35581 43951 -- START
				
				if(bManufacturerView || bSupplierView) {
					mpSEPResult.remove(ConstantsUtil.PQRBA);
					mpSEPResult.remove(ConstantsUtil.PQRPCP);
					//Modified by Jwala for 22x Development Req 42996 -- START
					if(bSupplierView){
						mpSEPResult.remove(ConstantsUtil.PQRPLANTS);
					}
					//Modified by Jwala for 22x Development Req 42996 -- END
				}
				// Added by Jwala for Req/Defect 35581 43951 -- END
				
				//SPEC: 23-12-2022: Ketan added for Req 34055 -- START
	            if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
	                mpSEPResult = new HashMap<String,String>();
	            }
	            //SPEC: 23-12-2022: Ketan added for Req 34055 -- END
			}

			/**
			 * SUBSTANCES & MATERIALS SECTION
			 * */
			StopWatch swsub= new StopWatch();
			swsub.start();
			//Added by Pooja for the req 35902,41754,33476 -- START
			PackagingMaterialPartBO pmpBO = new PackagingMaterialPartBO();
			
			 mpMaterialResult = pmpBO.getSubstances(context,resultMaps);
			if(bSupplierView || bManufacturerView) {
				mpMaterialResult=util.filterPhase(mpMaterialResult);
				mpMaterialResult=util.filterMapList(mpMaterialResult);
               
			}
			swsub.stop();
			LOGGER.info("PAP  SUBSTANCES & MATERIALS ELAPSED TIME : "+swsub.getTime());
			//Added by Pooja for the req 35902,41754,33476 -- END
			

			//Added by Pooja for the req 41754,33476 -- START
			/**
			 * LOAD PACKAGING CERTIFICATIONS
			 * */
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				StopWatch swPkgCert = new StopWatch();
				swPkgCert.start();
				mpCertDetails = CopBO.getPackagingCertificationsList(context,objId,(String)resultMaps.get(ConstantsUtil.SELECT_TYPE));
				swPkgCert.stop();
				LOGGER.info("COP PACKAGING CERTIFICATIONS ELAPSED TIME : "+swPkgCert.getTime());
				//Added by Pooja for the req 41754,33476 -- END
			}
			// Added by Jwala for the req 4945 - END
			
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
			hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			// Market of sale?
			hmAttrib.put(ConstantsUtil.COUNTRIESOFSALE, mapCosResult);
			hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			//Added by Pooja for the req 35902,33476 -- START
			if(bAllInfoView) {
			hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
			hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//Added by Pooja for the req 35902,33476 -- END
			
			//SPEC: 10/19/2020: Added for 18x.5 DEV -- START
			hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
			hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
			hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult); 
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			//SPEC: 10/19/2020: Added for 18x.5 DEV -- END

			//SPEC: Added for Dev 18x.6 Release by Jwala -- START
			hmAttrib.put(ConstantsUtil.ALTERNATES, mpAlternates);
			hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
			hmAttrib.put(ConstantsUtilIRM.REGISTRATIONDETAILS, mpRegistrationDetails);
			//SPEC: Added for Dev 18x.6 Release by Jwala -- END
			//Added by Pooja for the req 41754,33476 -- START
			//SPEC: <10.08.2022>: Satyam Modified for Defect 49841 -- START
			hmAttrib.put(ConstantsUtil.MATERIALS, mpMaterialResult);
			//SPEC: <10.08.2022>: Satyam Modified for Defect 49841 -- END
			
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				hmAttrib.put(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS, mpCertDetails);
			}
			// Added by Jwala for the req 4945 - END
			//Added by Pooja for the req 41754,33476 -- END
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			pool.checkIn(context);
			sp.stop();

			LOGGER.info("PAP Execution TIME::" + sp.getTime() +"  " + "PAP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			
		} catch (IOException e) {
			LOGGER.error("Unable to getPAPdata IOException: "+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getPAPdata MatrixException: "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		
		if(sComp.equals(ConstantsUtilIRM.PAP)) {
			context.close();
		}
		return hmAttrib;
	}

}