/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaTUPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MPPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.TransportUnitBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaTUPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class EnoviaTUPServiceImpl implements EnoviaTUPService{


	private static Logger LOGGER = Logger.getLogger(EnoviaTUPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
	
	@Override
	public HashMap<String, Map<String, String>> getTUPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("TUP CONTEXT ELAPSED TIME : "+swContext.getTime());

		try 
		{
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bManufacturerView = false;
			
			//Added by Jwala Since Supplier will not be able to TUP Objects and he should have CM View only
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP))
				sUserType = ConstantsUtil.PG_CM;

			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bManufacturerView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;
						
					case ConstantsUtil.PG_SP:
						bManufacturerView = true;
						break;
					
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
				
			TransportUnitBO TupBO = new TransportUnitBO();
			DomainObject doTUP =  TupBO.getTupDO(context, objId);
			String strCurrent = doTUP.getInfo(context, DomainConstants.SELECT_CURRENT);
			
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && sComp!=ConstantsUtilIRM.STATE_PRILIMNARY)
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {

					HashMap<String, String> errorMap = new HashMap<String, String>();
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Map<String,String> mpPartSpecSelects = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpBomMcupResult = new HashMap<String,String>();
			Map<String,String> mpSubstitute = new HashMap<String,String>();
			Map<String,String> mpBomMIPResult = new HashMap<String,String>();
			Map<String,String> mpBomMIPSubstitutes = new HashMap<String,String>();
			Map<String,String> mpBomCOPResult = new HashMap<String,String>();
			Map<String,String> mpBomCOPSubstitutes = new HashMap<String,String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			
			//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
			Map<String,String> mpFiles = new HashMap<String,String>();
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END

			FinishedProductPartBO fppBO = new FinishedProductPartBO();
			MasterCOPBO mcop = new MasterCOPBO();
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = TupBO.getTUPSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = TupBO.getTupRelatedObjsSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);

			ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context,ConstantsUtil.USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);
			
			if(null==doTUP) {
				LOGGER.error("ERROR :OBJECT NOT FOUND : "+objId);
				Map<String,String> ERROR = new HashMap<String,String>();
				ERROR.put("ERROR", "OBJECT NOT FOUND : "+objId);
				hmAttrib.put("ERROR", ERROR);
				LOGGER.error("ERROR : OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doTUP.getInfo(context, slContextSelects);
			Map resultMaps = doTUP.getInfo(context, slContextSelects,TupBO.addMultiSelects());
			swAttributes.stop();
			LOGGER.info("TUP GETINFO ELAPSED TIME : "+swAttributes.getTime());

			
			String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			
			//BOM
			StopWatch swBom = new StopWatch();
			swBom.start();
			MapList mapList = doTUP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
					ConstantsUtil.QUERY_WILDCARD, slChildBusSelects, slChildRelSelects, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			if(mapList.size()!=0){
				MPPBO mppBO = new MPPBO();
				mpEBOMResult = mppBO.parseMaplistBOM(context,mapList);
				CommonBusUtilBO commonBO = new CommonBusUtilBO();
				mpSubstitute =  commonBO.parseSubstitute(context,mapList);
			}

			ContextUtil.popContext(context);
			swBom.stop();
			LOGGER.info("TUP BOM ELAPSED TIME : "+swBom.getTime());
			
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END

			if(bAllInfoView || bManufacturerView) {
				//Basic  Data
				mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));		
				mpAttribResult.put(ConstantsUtil.STRPALLETTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE) : ConstantsUtil.EMPTY_STRING);

				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASEPHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASEPHASE) : ConstantsUtil.EMPTY_STRING);

				//SPEC: Added for req no. 35902 by Ketan on 06.02.2022 -- START
				if(!bManufacturerView) {
					mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
				}

				if(bManufacturerView) {
					mpAttribResult.put(ConstantsUtil.STACKINGPATTERN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STACK_PATTEREN)))?(String)resultMaps.get(ConstantsUtil.STACK_PATTEREN) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Added for req no. 35902 by Ketan on 06.02.2022 -- END

				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);

				mpAttribResult.put(ConstantsUtil.DIM_UOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				//<12.28.20202> Lingeswari commented and added as reference to defect 37755 ---start
				//mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				//<12.28.20202> Lingeswari commented and added as reference to defect 37755 --end
				mpAttribResult.put(ConstantsUtil.OUTER_DIM_DEPTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OUTER_DIM_LENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OUTER_DIM_WIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OUTER_DIM_HEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.WAREHOUSEPALLETSTAKMAXGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.UNDER_MAX_HEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TRUCK_STACK_MAXHGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CUBE_EFF, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CUBEEFFECIENCY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CUBEEFFECIENCY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CUSTOM_PER_LAYER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LAYERS_PER_TRANSPORT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.AREA_EFF, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAREAEFFECIENCY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAREAEFFECIENCY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.WHSE_LOGSTICS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSELOGISTICS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSELOGISTICS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				String sClassifictaion = util.getClassification(resultMaps);
				//SPEC: Release SR18x.6.0 - Modified  by Dominic on Date 17/03/2021 -- START
				//if(bSupplierView || bAllInfoView){
				mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
				//}
				//SPEC: Release SR18x.6.0 - Modified  by Dominic on Date 17/03/2021 -- END
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
				mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, util.getLastUpdatedUser(context, sID));
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				// Guna Modified for Defect 39163  18x.5.2 Release -- START
				//mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STR_SEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_STR_SEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.STRSEGMENT))));
				// Guna Modified for Defect 39163  18x.5.2 Release -- END
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OVERHANGACTUALWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_OVERHANGACTUALWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_OVERHANGACTUALWIDTH) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OVERHANGACTUALLENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_OVERHANGACTUALLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_OVERHANGACTUALLENGTH) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.UNDERHANGACTUALWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_UNDERHANGACTUALWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_UNDERHANGACTUALWIDTH) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.UNDERHANGACTUALLENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_UNDERHANGACTUALLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_UNDERHANGACTUALLENGTH) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
				//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
				//Organization Data
				StopWatch swOrganization = new StopWatch();
				swOrganization.start();
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = util.filterMapList(mpOrganization);
				swOrganization.stop();
				LOGGER.info("TUP Organization ELAPSED TIME : "+swOrganization.getTime());


				//Part Specs
				StopWatch swPartSpecs = new StopWatch();
				swPartSpecs.start();
				mpPartSpecSelects = util.updatePartSpec(context,resultMaps);
				swPartSpecs.stop();
				LOGGER.info("TUP  PartSpecs ELAPSED TIME : "+swPartSpecs.getTime());


				//HeaderContent
				//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
				} else {
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
				}
				//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

				mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 07/09/2021: Modified for 18x.6.0.2 Defect#41839 by Manikanta-- START
				String sCurrent = (String)resultMaps.get(ConstantsUtil.SELECT_CURRENT);
				if (null != sCurrent && !sCurrent.isEmpty() && sCurrent.equalsIgnoreCase((String)ConstantsUtil.RELEASE)) {
					mpHeaderContent.put(ConstantsUtil.STATE, ConstantsUtil.RELEASED);
				} else {
					mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: 07/09/2021: Modified for 18x.6.0.2 Defect#41839 by Manikanta-- END
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);

				//Lifecycle
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				//SPEC: Release SR18x.6. Modified by Dominic on Date 10/03/2021 --START
				mpLifeCycleApproval.put(ConstantsUtil.APPROVER,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6. Modified by Dominic on Date 10/03/2021 --END
				swLifecycle.stop();
				LOGGER.info("TUP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

				//SPEC: <10.21.2020>: Commented for req 18x.5 ## -- START
				//SPEC: Release SR18x.6. Added by Dominic on Date 12/03/2021 --START
				if(bAllInfoView) {
					//SPEC: Release SR18x.6.0 - Modified for TUP  by Dominic on Date 04/03/2021 -- START
					mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
					//SPEC: Release SR18x.6.0 - Modified for TUP  by Dominic on Date 04/03/2021 -- END
				}


				/**
				 * Load All BOM Sections
				 */
				int i;
				Map<String, String> mp = null;
				StringList slObjID = new StringList();
				
				Pattern sbBOMTypePattern = new Pattern(ConstantsUtil.TYPE_PGMASTERCUSTOMERUNITPART);
				sbBOMTypePattern.addPattern(ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART);
				sbBOMTypePattern.addPattern(ConstantsUtil.TYPE_PGMASTERCONSUMERUNITPART);
				
				mapList = doTUP.getRelatedObjects(context, //Context
							ConstantsUtil.RELATIONSHIP_EBOM, //Rel Pattern
							sbBOMTypePattern.getPattern(), //Type Pattern
							slChildBusSelects, //Object Select
							slChildRelSelects, // rel Select
							false, //get To
							true, //get From
							(short) 0, //recurse level
							ConstantsUtil.EMPTY_STRING, //objectWhere
							ConstantsUtil.EMPTY_STRING, //relationshipWhere
							0);
				
				MapList mlFinalCup = new MapList();
				MapList mlFinalIp = new MapList();
				MapList mlFinalCop = new MapList();
				
				CommonBusUtilBO commonBO = new CommonBusUtilBO();
				
				for(i=0;i<mapList.size();i++) 
				{
					mp = (Map<String, String>) mapList.get(i);
					String name = mp.get(ConstantsUtil.SELECT_NAME).toString();
					String type = mp.get(ConstantsUtil.SELECT_TYPE).toString();
					String strOid = mp.get(ConstantsUtil.SELECT_ID);
					String rev = mp.get(ConstantsUtil.SELECT_REVISION);

					//CUP-BOM
					if(type.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERCUSTOMERUNITPART) && !slObjID.contains(strOid))
					{
						slObjID.add(strOid);
						if (!strOid.isEmpty()) 
						{
							DomainObject doCup = DomainObject.newInstance(context, strOid);
							slChildRelSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
							slChildRelSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
							slChildRelSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
							slChildRelSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
							slChildRelSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
							StopWatch swCup = new StopWatch();
							swCup.start();


							//SPEC: <10.27.2020>: Added for req 18x.5 ## -- START
							slContextSelects.addAll(fppBO.getBomBusSelect(context));
							//SPEC: <10.27.2020>: Added for req 18x.5 ## -- END

							// Get TUP connected CUP Objects

							MapList mlCup = doCup.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slContextSelects,
									slChildRelSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							doCup.close(context);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
							if(bManufacturerView){
								mlCup=util.filterPhase(mlCup);
							}
							swCup.stop();
							LOGGER.info("TUP  CUP BOM ELAPSED TIME : "+swCup.getTime());
							
							mlCup.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING,
									ConstantsUtil.INTEGER);
							Map<String, String> mCup = null;
							for(int j=0; j < mlCup.size();j++) {
								mCup = (Map<String, String>) mlCup.get(j);
								mCup.put(ConstantsUtilIRM.PARENT_NAME, name);
								mCup.put(ConstantsUtilIRM.PARENT_ID, strOid);
								mCup.put(ConstantsUtilIRM.PARENT_REVISION, rev);
								mCup.put(ConstantsUtilIRM.PARENT_TYPE, type);
								mlFinalCup.add(mCup);
							}
						}
					}
					//END of CUP Block
					else if ((type.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART) || type.equalsIgnoreCase(ConstantsUtil.TYPE_PG_MASTERINNERPACKUNIT)) && !slObjID.contains(strOid)) {
						slObjID.add(strOid);
						if (!strOid.isEmpty()) 
						{
							DomainObject doIp = DomainObject.newInstance(context, strOid);
							
							//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- END
							StopWatch swIp = new StopWatch();
							swIp.start();
							
							MapList mlIp = doIp.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slContextSelects,
									slChildRelSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							doIp.close(context);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
							if(bManufacturerView){
								mlIp=util.filterPhase(mlIp);
							}							
							swIp.stop();
							LOGGER.info("TUP  IPBOM ELAPSED TIME : "+swIp.getTime());
							mlIp.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING, ConstantsUtil.INTEGER);
							Map<String, String> mIp = null;
							for(int j=0; j < mlIp.size();j++) {
								mIp = (Map<String, String>) mlIp.get(j);
								mIp.put(ConstantsUtilIRM.PARENT_NAME, name);
								mIp.put(ConstantsUtilIRM.PARENT_ID, strOid);
								mIp.put(ConstantsUtilIRM.PARENT_REVISION, rev);
								mIp.put(ConstantsUtilIRM.PARENT_TYPE, type);
								mlFinalIp.add(mIp);
							}
						}
					}
					//End of IP block
					else if((type.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERCONSUMERUNITPART) || type.equalsIgnoreCase(ConstantsUtil.TYPE_PG_MASTERCONSUMERUNIT)) && !slObjID.contains(strOid)) {
						slObjID.add(strOid);
						if (!strOid.isEmpty()) 
						{
							DomainObject doCop = DomainObject.newInstance(context, strOid);
							
							//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- END
							StopWatch swCOPBom = new StopWatch();
							swCOPBom.start();
							
							MapList mlCop = doCop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slContextSelects,
									slChildRelSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							doCop.close(context);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
							if(bManufacturerView){
								mlCop=util.filterPhase(mlCop);
							}
							swCOPBom.stop();
							LOGGER.info("TUP GET COPBOM ELAPSED TIME : "+swCOPBom.getTime());
							mlCop.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING, ConstantsUtil.INTEGER);
							
							Map<String, String> mCop = null;
							for(int j=0; j < mlCop.size();j++) {
								mCop = (Map<String, String>) mlCop.get(j);
								mCop.put(ConstantsUtilIRM.PARENT_NAME, name);
								mCop.put(ConstantsUtilIRM.PARENT_ID, strOid);
								mCop.put(ConstantsUtilIRM.PARENT_REVISION, rev);
								mCop.put(ConstantsUtilIRM.PARENT_TYPE, type);
								mlFinalCop.add(mCop);
							}
						}
					}

					//COP-BOM

					if(name.contains(ConstantsUtil.CUP) || name.contains(ConstantsUtil.COP)) {
						continue;
					}
				}
				
				if(mlFinalCup.size()!=0)
				{
					/**
					 * Get CUP BOM
					 */
					//SPEC: <10.22.2020>: Commented for req 18x.5 ## -- START
					//mpBomMcupResult =	util.parseMaplist(context,mlCup);
					//mpBomMcupResult =	TupBO.parseMaplist(context,mlCup);
					//mpBomMcupResult =	TupBO.parseEBOMMaplist(context,mlCup);
					Map mpBomCupRslt=	fppBO.parseMaplist(context,mlFinalCup, true);
					mpBomMcupResult.putAll(mpBomCupRslt);
					//SPEC: Added by Ketan for req no. 41754 on 06.15.2022 -- START
					mpBomMcupResult.remove(ConstantsUtil.GROSSWEIGHT);
					mpBomMcupResult.remove(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE);
					//SPEC: Added by Ketan for req no. 41754 on 06.15.2022 -- END
					
					// This method was commented in the final map alredy.Hence commenting here to improve performance
					/**
					 * Get CUP Substitute 
					 */
					//mpBomMCupSubstitutes = util.getCOPCUPIPSubstitutes(context, mlCup);

					
					//mpBomMCupSubstitutes =  commonBO.parseSubstitute(context,mlCup);*/
					//SPEC: <10.21.2020>: Commented for req 18x.5 ## - Jwala -- END
				}
				if(mlFinalIp.size()!=0){
					/**
					 * Get IP BOM
					 */
					Map mpBomIpRslt =	fppBO.parseMaplist(context,mlFinalIp, true);
					mpBomMIPResult.putAll(mpBomIpRslt);
					//SPEC: Added by Ketan for req no. 41754 on 06.15.2022 -- START
					mpBomMIPResult.remove(ConstantsUtil.GROSSWEIGHT);
					mpBomMIPResult.remove(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE);
					//SPEC: Added by Ketan for req no. 41754 on 06.15.2022 -- END

					/**
					 * Get IP Substitute
					 */
					Map mpBomIpSubstituteRslt = commonBO.parseSubstitute(context, mlFinalIp);
					mpBomMIPSubstitutes.putAll(mpBomIpSubstituteRslt);

				}
				if(mlFinalCop.size()!=0){
					/**
					 * Get COP BOM
					 */
					Map mpBomCopRslt =	fppBO.parseBomCopMaplist(context,mlFinalCop, true);
					mpBomCOPResult.putAll(mpBomCopRslt);
					//SPEC: Added by Ketan for req no. 41754 on 06.15.2022 -- START
					mpBomCOPResult.remove(ConstantsUtil.GROSSWEIGHT);
					mpBomCOPResult.remove(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE); //Modified by Ketan
					//SPEC: Added by Ketan for req no. 41754 on 06.15.2022 -- END

					/**
					 * Get COP Substitute
					 */
					Map mpBomCopSubstituteRslt = commonBO.parseSubstitute(context, mlFinalCop);
					mpBomCOPSubstitutes.putAll(mpBomCopSubstituteRslt);
				}
			
				//Ownership
				StopWatch swOwnerShip = new StopWatch();
				swOwnerShip.start();
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.STRSEGMENT))));
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, util.getLastUpdatedUser(context, sID));
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
				swOwnerShip.stop();
				LOGGER.info("TUP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());

				/**
				 * LOAD NOTES SECTION
				 * */
				mpNotes=mcop.updateNotes(context, resultMaps);

				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
				//mapReferenceDocs = util.filterMapList(mapReferenceDocs);
				swReference.stop();
				LOGGER.info("TUP  REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());

				/**
				 * LOAD SECURITY SECTION
				 * */
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO bo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =bo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				LOGGER.info("TUP  Security ELAPSED TIME : "+swSecurity.getTime());

				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=util.getRelatedAts(context, doTUP);

				mpRelatedATS=util.filterMapList(mpRelatedATS);
				if(!mpRelatedATS.isEmpty()){
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
				}

				if(bManufacturerView) {
					mpRelatedATS=util.filterPhase(mpRelatedATS);
				}
				swAts.stop();
				LOGGER.info("TUP ATS ELAPSED TIME : "+swAts.getTime());


				/**
				 * FILES SECTION
				 */
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START

				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
				CommonDocBO cdoc = new CommonDocBO();
				String strFileSize = cdoc.updateFileSize(FileSize);
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);


				/**
				 * LOAD IP CLASSES SECTION
				 */
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIpSecuritySetting =TupBO.getIpClass(context, doTUP, slIpSelects);
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END

			}
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
				hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.FILES, mpFiles);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
				hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
			}
			//SPEC: Release SR18x.6. Added by Dominic on Date 12/03/2021 --START
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERCUSTOMERUNIT, mpBomMcupResult);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERINNERPACK, mpBomMIPResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTESMASTERINNERPACK, mpBomMIPSubstitutes);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERCONSUMERUNIT, mpBomCOPResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTESMASTERCONSUMERUNIT, mpBomCOPSubstitutes);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecSelects);
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			
			pool.checkIn(context);
			sp.stop();

			LOGGER.info("TUP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "TUP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
			context.close();
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		} catch (IOException e) {
			LOGGER.error("Unable to getTUPdata IOException: "+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getTUPdata MatrixException: "+e);
		}
		//LOGGER.info("TUP RESPONSE MESSAGE:: \n" + hmAttrib);
		context.close();
		return hmAttrib;

	}

}
