package com.pg.us.specanywhere_enovia.cp;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.pg.us.specanywhere_enovia.utility.CryptoUtil;
import com.pg.us.specanywhere_enovia.utility.EncryptCrypto;

import matrix.db.Context;



public abstract class ObjectPool<T> {
  private long expirationTime;
  private Context context;
  private int poolofobjects =60;
  private T t ;
  private Hashtable<T, Long> locked;
  private Hashtable<T, Long> unlocked;
  private long now = System.currentTimeMillis();
  static int nLevel;
  
	//Added by Jwala for Enovia Profiling -- START
	@Value("${enovia.user.pwd}")
	private String enoviauserpwd ;
	//Added by Jwala for Enovia Profiling -- END


	//Commented by Jwala for Enovia Profiling -- START
	/*public ObjectPool() {
		System.out.println("ObjectPool");
		expirationTime = 1; // seconds
		locked = new Hashtable<>(poolofobjects,.75f);
		unlocked = new Hashtable<>(poolofobjects,.75f);
		for(int i =0; i<poolofobjects ;i++) {   
			t = (T) getEnoviaContext();
			unlocked.put(t, now);
		}

	}*/
	//Commented by Jwala for Enovia Profiling -- END

	protected abstract T create();

	public abstract boolean validate(T o);

	public abstract void expire(T o);


	public synchronized T checkOut() {

		T temp=null;
		Enumeration<T> e = unlocked.keys();
		if (unlocked.size() > 0) {
			while (e.hasMoreElements()) {
				t = e.nextElement();

				if (validate(t)) {
					System.out.println("VALIDATE");
					unlocked.remove(t);
					locked.put(t, now);
					temp =t;
					break;
				} else {
					unlocked.remove(t);
					t = (T) getEnoviaContext();
					locked.put(t, now);
					temp =t;
					break;
				}

			}
		}else {
			System.out.println("CREATING A NEW CONTEXT FROM SERVICE");
			t = (T) getEnoviaContext();  
			locked.put(t, now);
			temp =t;
		}
		return temp;
	}


	public void checkIn(T t) {

		locked.remove(t);
		unlocked.put(t, now);
	}

	//Added by Jwala for Enovia Profiling -- START
	@PostConstruct
	public void init(){
		expirationTime = 1; // seconds
		locked = new Hashtable<>(poolofobjects,.75f);
		unlocked = new Hashtable<>(poolofobjects,.75f);
		for(int i =0; i<poolofobjects ;i++) {   
			t = (T) getEnoviaContext();
			unlocked.put(t, now);
		}

	}
	//Added by Jwala for Enovia Profiling -- END

	public Context getEnoviaContext() {
		try {

			System.out.println("getEnoviaContext");
			context = new Context("");
			//Jwala Commented for user change -- START
			context.setUser("sys_specreader");
			//Jwala Commented for user change -- END
			context.setPassword(decrypt());
			context.setVault("eService Production");
			System.out.println("-------------------");
			System.out.println("*CP CONTEXT NEW START*");
			System.out.println("-------------------");
			context.connect();
			System.out.println("*SESSION ID:*"+context.getSession().getSessionId());
			/*LOGGER.info("SessionID: "+context.getSession().getSessionId());*/
			System.out.println("-------------------");
			System.out.println("----CP CONTEXT CONNECTED----");
			System.out.println("-------------------");

		} catch (Exception ex) {
			/*LOGGER.info("EXCEPTION IN ENOVIACONTEXT::getEnoviaContext : "+ex);*/
			ex.printStackTrace();
		}
		return context;
	}

	//Modified by Jwala for Potential resource Leak-- START
	/*
	 * public String decrypt() { Properties props = new Properties();
	 * 
	 * //Modified by Jwala for Enovia Profiling -- START String
	 * strDecryptedPassword=enoviauserpwd; //Modified by Jwala for Enovia Profiling
	 * -- END try {
	 * props.load(EncryptCrypto.class.getClassLoader().getResourceAsStream(
	 * "crypto.properties")); nLevel = Integer.valueOf(props.getProperty("Level"));
	 * 
	 * for (int keyCount=nLevel-1; keyCount>=0; keyCount--) { strDecryptedPassword =
	 * CryptoUtil.decryptString(strDecryptedPassword,props.getProperty("SecretKey"+
	 * keyCount),"");
	 * 
	 * } } catch (IOException e) { e.printStackTrace(); } catch (Exception e) {
	 * e.printStackTrace(); } return strDecryptedPassword; }
	 */
	
	public String decrypt() {
		Properties props = new Properties();
		String strDecryptedPassword = enoviauserpwd;

		try (InputStream input = getClass().getClassLoader().getResourceAsStream("crypto.properties")) {
			if (input == null) {
				throw new FileNotFoundException("crypto.properties not found in classpath");
			}
			props.load(input);
			int nLevel = Integer.parseInt(props.getProperty("Level"));
			for (int keyCount = nLevel - 1; keyCount >= 0; keyCount--) {
				strDecryptedPassword = CryptoUtil.decryptString(
						strDecryptedPassword,
						props.getProperty("SecretKey" + keyCount),""
						);
			}
		} catch (IOException | RuntimeException e) {
			e.printStackTrace(); // log properly in production
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strDecryptedPassword;
	}
	//Modified by Jwala for Potential resource Leak-- END

}