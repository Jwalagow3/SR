/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaRMPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.IRMSBO;
import com.pg.us.specanywhere_enovia.bo.ManufacturingEquivalentPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaRMPServiceImpl implements EnoviaRMPService {


	private static Logger LOGGER = Logger.getLogger(EnoviaRMPServiceImpl.class);
	
	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END
	
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
	
	@Override
	public HashMap<String, Map<String, String>> getRMPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		Context context = null;
		try {
			
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			swContext.stop();
			LOGGER.info("RMP CONTEXT ELAPSED TIME : "+swContext.getTime());

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if (UIUtil.isNotNullAndNotEmpty(sUserType)) {
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)) {
					sUserType = BObjutil.getUserView(context, objId);
				}
			}
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			RawMaterialPartBO RawBO = new RawMaterialPartBO();
			//DomainObject doRMP =  RawBO.getRmpDO(context, objId);
			DomainObject doRMP = DomainObject.newInstance(context, objId);
			String strState = doRMP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: Modified by Ajay for Req. no. 21482 START
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strState.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				
				else if(!strState.equals(ConstantsUtil.RELEASE)) {

					HashMap<String, String> errorMap = new HashMap<String, String>();
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strState.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.info("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC: Modified by Ajay for Req. no. 21482 END
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			Map<String,String> mpProfileIdResult = new HashMap<String,String>();
			Map<String,String> mpChemClassResult = new HashMap<String,String>();
			Map<String,String> mpPhysicalPropResult = new HashMap<String,String>();
			Map<String,String> mpPerfumeResult = new HashMap<String,String>();
			Map<String,String> mpChemMoleculeResult = new HashMap<String,String>();
			Map<String,String> mpCDetergentResult = new HashMap<String,String>();
			Map<String,String> mpWeightResult = new HashMap<String,String>();
			Map<String,String> mpMEPResult = new HashMap<String,String>();
			Map<String,String> mpSEPResult = new HashMap<String,String>();
			Map<String,String> mpPartSpecResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpPerformChar = new HashMap<String,String>();			
			Map<String,String> mpRegSafety = new HashMap<String,String>();
			Map<String,String> mpSpecifications = new HashMap<String,String>();
			Map<String,String> mpStartingMaterials = new HashMap<String,String>();
			Map<String,String> mpAlternates = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpCertification = new HashMap<String,String>();
			Map<String,String> mpProducingFarmula = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpStability = new HashMap<String,String>();
			Map<String,String> mpIpSecurity = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String, String>();
			Map<String,String> mpRdSite = new HashMap<String, String>();
			//Added by Ketan for Req. no. 48322 -- START
			Map<String,String> mpSustainability = new HashMap<>();
			Map<String,String> mpPackagingCertification = new HashMap<>();
			//Added by Ketan for Req. no. 48322 -- END
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			Map mpBatteryDetails = new HashMap();
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();

			Map mpSubStanceResult = new HashMap();
			BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			Map<String, StringList> BusinessObjectSelectableMap = RawBO.getRMPPartSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slContextSelects.add(ConstantsUtil.ATL_STATE);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTHEPRODUCTABATTERY);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL);
			//Added by Ketan for Req. no. 48322 -- START
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGEDURABILITY);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALTHICKNESS);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALDENSITY);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY);
			//Added by Ketan for Req. no. 48322 -- END

			
			if(null==doRMP) {
				Map<String,String> ERROR = new HashMap<String,String>();
				ERROR.put("ERROR", "OBJECT NOT FOUND : "+objId);
				hmAttrib.put("ERROR", ERROR);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doRMP.getInfo(context, slContextSelects);
			Map resultMaps = doRMP.getInfo(context, slContextSelects,RawBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("RMP GETINFO ELAPSED TIME : "+swAttributes.getTime());
			
			
			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			//Added by Ketan for Req. no. 48322 -- START 
			String sContextObjecttype = validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_TYPE))?(String)resultMaps.get(DomainConstants.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			String sContextObjectName = validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_NAME))?(String)resultMaps.get(DomainConstants.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sContextObjectPolicy = validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_POLICY))?(String)resultMaps.get(DomainConstants.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING;
			//Added by Ketan for Req. no. 48322 -- END
			String sSapType = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
			String strStartingMaterials = DomainConstants.EMPTY_STRING; //SPEC: 06/24/2022: Added by Ketan for Req no. 38897
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			if(bManufacturerView || bAllInfoView || bSupplierView) 
			{

				/**
				 * LOAD HEADER SECTION
				 * */
				mpHeaderContent.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				String strCurrent = (String)resultMaps.get(ConstantsUtil.SELECT_CURRENT);
				strCurrent = RawBO.getReleasedState(context, strCurrent);
				mpHeaderContent.put(ConstantsUtil.STATE, strCurrent);
				String sHasATSAttrVal = BbUtil.checkHasATSForSIS(context,resultMaps);
				mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
				
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, sSapType); 
				mpHeaderContent.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderContent.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));

				String masterId = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID));
				if(bManufacturerView || bSupplierView) {
					mpHeaderContent.put(ConstantsUtil.HASATS, DomainConstants.EMPTY_STRING);
				}
				if (UIUtil.isNotNullAndNotEmpty(masterId)) {
					//DomainObject obj = new DomainObject(masterId);
					DomainObject obj = DomainObject.newInstance(context, masterId);
					String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					obj.close(context);
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
					BusObjectAttribUtil util=new BusObjectAttribUtil();
					boolean showData = util.checkHasAccess(context, sUserType, masterId);
					if (!showData) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
				}
				mpHeaderContent.put(ConstantsUtil.MASTERPARTID, masterId);
				
				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				String sClassification = BbUtil.getClassification(resultMaps);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION,(sClassification));
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);

				/**
				 * LOAD ATTRIBUTE SECTION
				 * */
				//Contract Manufacturer View && All Info View
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				if (!bSupplierView) {
					
					mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
					mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				}
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				String sSAPValue =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
				mpAttribResult.put(ConstantsUtil.PRODUCEDBYFORMULA, ConstantsUtil.CONSTANT_STRING_ROH.equals(sSAPValue)?ConstantsUtil.SYMBL_NO: ConstantsUtil.SYMBL_YES);

				if (!bManufacturerView) {
					if (resultMaps.get(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME) != null) {					
						if (resultMaps.get(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList")) {
								mpAttribResult.put(ConstantsUtil.MATERIALCERTIFICATIONS,  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME)));
						} else {
								mpAttribResult.put(ConstantsUtil.MATERIALCERTIFICATIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME) : ConstantsUtil.EMPTY_STRING);
						}
					} else {
						mpAttribResult.put(ConstantsUtil.MATERIALCERTIFICATIONS,  ConstantsUtil.EMPTY_STRING);
					}
					mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				}
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
				
				
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHELFLIFE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS)));
				mpAttribResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED))));
				mpAttribResult.put(ConstantsUtil.HASART, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART)))?validator.replaceSpecialSymbols((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART)) : ConstantsUtil.EMPTY_STRING);
				//SPEC:01/10/2020- Added for Release 18x5 - END
				
				//SPEC:04/20/2026 - Added for the req 125095 - START
				String sShelfLife = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSHELFLIFEDAYS))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSHELFLIFEDAYS) : ConstantsUtil.EMPTY_STRING;
				if(sShelfLife.equalsIgnoreCase(ConstantsUtil.GEN_NUM_ZERO)) {
					sShelfLife = ConstantsUtilIRM.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtilIRM.SHELFLIFEDAYS,sShelfLife);
				
				//SPEC:04/20/2026 - Added for the req 125095 - START
				
				//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
				if(!bSupplierView) {
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
					//Added by Ajay for Req. no. 99576 - START
					String sCompendialReferencePharmacopeia = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEPHARMACOPEIA));
					String sQualityStandardsMaterialGrade = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSMATERIALGRADE));
					mpAttribResult.put(ConstantsUtilIRM.PG_COMPENDIALREFERENCEPHARMACOPEIA, sCompendialReferencePharmacopeia);
					mpAttribResult.put(ConstantsUtilIRM.PG_QUALITYSTANDARDSMATERIALGRADE, sQualityStandardsMaterialGrade);
					if(sCompendialReferencePharmacopeia.contains(ConstantsUtilIRM.OTHER)) {
						mpAttribResult.put(ConstantsUtilIRM.PG_COMPENDIALREFERENCEFREETEXT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEFREETEXT))));
					}
					if(sQualityStandardsMaterialGrade.contains(ConstantsUtilIRM.OTHER)) {
						mpAttribResult.put(ConstantsUtilIRM.PG_QUALITYSTANDARDSFREETEXT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSFREETEXT))));
					}
					//Added by Ajay for Req. no. 99576 - END
				}
				//Added by Ketan for Req. no. 48322 -- START
				//SPEC: Modified by Ajay for Defect no. 41004 START
				if(mpAttribResult.get(ConstantsUtil.SPECIFICATIONSUBTYPE).equals(ConstantsUtilIRM.SUBTYPE_WITH_MCP)) {
					mpAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Modified by Ajay for Defect no. 41004 START
				//Added by Ketan for Req. no. 48322 -- END
				
				//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
				
				/**
				 * LOAD PROFILE SECTION
				 * */
				//Contract Manufacturer View & All Info View
				StopWatch swProfile = new StopWatch();
				swProfile.start();
				mpProfileIdResult.put(ConstantsUtil.INCINAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INCINAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INCINAME) : ConstantsUtil.EMPTY_STRING);
				mpProfileIdResult.put(ConstantsUtil.CHEMICALNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICALNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICALNAME) : ConstantsUtil.EMPTY_STRING);
				mpProfileIdResult.put(ConstantsUtil.EMPERICALFORMULA, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EMPIRICALFORMULA)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EMPIRICALFORMULA) : ConstantsUtil.EMPTY_STRING);

				mpProfileIdResult.put(ConstantsUtil.COLORINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLORINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLORINDEX) : ConstantsUtil.EMPTY_STRING);
				mpProfileIdResult.put(ConstantsUtil.CISPRO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMCISPRONUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMCISPRONUMBER) : ConstantsUtil.EMPTY_STRING);
				mpProfileIdResult.put(ConstantsUtil.EXPERIMENTALNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMEXPERIMENTNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMEXPERIMENTNUMBER) : ConstantsUtil.EMPTY_STRING);
				if(bAllInfoView) {
					mpProfileIdResult.put(ConstantsUtil.PREFERREDMATERIAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING);
					mpProfileIdResult.put(ConstantsUtil.MATERIALUSAGEGUIDANCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALUSAGEGUIDANCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALUSAGEGUIDANCE) : ConstantsUtil.EMPTY_STRING);
				}
				// Commented by Satyam for Req 46464
				/*if(bAllInfoView || bManufacturerView) {
					mpProfileIdResult.put(ConstantsUtil.MATERIALRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mpProfileIdResult.put(ConstantsUtil.MATERIALRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				}*/
				mpProfileIdResult = BbUtil.filterMapList(mpProfileIdResult);
				swProfile.stop();
				LOGGER.info("RMP GET PROFILE ELAPSED TIME : "+swProfile.getTime());

				/**
				 * LOAD CHEMICAL CLASSIFICATION SECTION
				 * */
				//Contract Manufacturer View & All Info View
				StopWatch swChem = new StopWatch();
				swChem.start();
				mpChemClassResult.put(ConstantsUtil.CAS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER) : ConstantsUtil.EMPTY_STRING);
				mpChemClassResult.put(ConstantsUtil.EINECSNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EINECSNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EINECSNUMBER) : ConstantsUtil.EMPTY_STRING);
				mpChemClassResult.put(ConstantsUtil.MATERIALFUNCTION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL)));
				mpChemClassResult.put(ConstantsUtil.CHEMICALGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP) : ConstantsUtil.EMPTY_STRING);
				mpChemClassResult.put(ConstantsUtil.INGREDIENTCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS) : ConstantsUtil.EMPTY_STRING);
				mpChemClassResult.put(ConstantsUtil.FLAVORCLUSTERRANK, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAVORCLUSTERRANK)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAVORCLUSTERRANK) : ConstantsUtil.EMPTY_STRING);
				mpChemClassResult = BbUtil.filterMapList(mpChemClassResult);
				swChem.stop();
				LOGGER.info("RMP GET CHEMICAL CLASS ELAPSED TIME : "+swChem.getTime());

				/**
				 * LOAD PERFUME SECTION
				 * */
				//Contract Manufacturer View & All Info View
				StopWatch swPerf = new StopWatch();
				swPerf.start();
				mpPerfumeResult.put(ConstantsUtil.ODORFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGODORFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGODORFAMILY) : ConstantsUtil.EMPTY_STRING);
				mpPerfumeResult.put(ConstantsUtil.PRIMARYODORDESCRIPTOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYODORDESCRIPTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYODORDESCRIPTOR) : ConstantsUtil.EMPTY_STRING);
				mpPerfumeResult.put(ConstantsUtil.SECONDARYODORDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYODORDESCRIPTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYODORDESCRIPTOR) : ConstantsUtil.EMPTY_STRING);
				mpPerfumeResult.put(ConstantsUtil.ODORDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGODORDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGODORDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpPerfumeResult = BbUtil.filterMapList(mpPerfumeResult);
				swPerf.stop();
				LOGGER.info("RMP GET PERF ELAPSED TIME : "+swPerf.getTime());

				
				/**
				 * LOAD DETERGENT SECTION
				 * */
				//Contract Manufacturer View & All Info View
				StopWatch swDetergent = new StopWatch();
				swDetergent.start();
				mpCDetergentResult.put(ConstantsUtil.CATSO3CONTRIBUTOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SO3CONTRIBUTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SO3CONTRIBUTOR) : ConstantsUtil.EMPTY_STRING);
				mpCDetergentResult = BbUtil.filterMapList(mpCDetergentResult);
				swDetergent.stop();
				LOGGER.info("RMP GET DETERGENT ELAPSED TIME : "+swDetergent.getTime());
				
				/**
				 * LOAD PERFORMANCE CHAR SECTION
				 * */
				//Performance Car
				Map paramMap = new HashMap();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);
				
				PerformanceCharcteristics perform = new PerformanceCharcteristics();
				MapList mlPerformChar = new MapList();
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				//SPEC: Added by Ajay for Defect no. 44930 START
				if(sComp.equals(ConstantsUtilIRM.COMPARE)) {
					mlPerformChar = RawBO.getPerformanceCharCompare(context,JPO.packArgs(paramMap));
				}
				else {
					mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				}
				//SPEC: Added by Ajay for Defect no. 44930 END
				if(!mlPerformChar.isEmpty()) {
					FinishedProductPartBO fppBO = new FinishedProductPartBO();
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					mpPerformChar = BbUtil.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
										
				}
				else
				{
					String sRevision = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
					String sPCName = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
					MapList mlPerformAttrib = BbUtil.getExtendedPerformChar(context,doRMP,sRevision,sPCName,resultMaps);
					mpPerformChar = BbUtil.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
					
				}
				
				
				swPerfChar.stop();
				LOGGER.info("RMP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

				/**
				 * LOAD WEIGHT SECTION
				 * */
				//Contract Manufacturer View & All Info View
				StopWatch swWeight = new StopWatch();
				swWeight.start();
				
				mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult = BbUtil.filterMapList(mpWeightResult);
				swWeight.stop();
				LOGGER.info("RMP GET WEIGHT ELAPSED TIME : "+swWeight.getTime());

				
				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				MasterCOPBO mcop = new MasterCOPBO();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
				mapReferenceDocs = BbUtil.filterMapList(mapReferenceDocs);
				swReference.stop();
				LOGGER.info("RMP  Reference ELAPSED TIME : "+swReference.getTime());

				
				/**
				 * LOAD PART-SPEC SECTION
				 * */
				//Contract Manufacturer View & All Info View
				StopWatch swPartSpec = new StopWatch();
				swPartSpec.start();
				mpPartSpecResult = BbUtil.updatePartSpec(context,resultMaps);
				
				swPartSpec.stop();
				LOGGER.info("RMP GET PART SPEC ELAPSED TIME : "+swPartSpec.getTime());
				
				/**
				 * MASTER SPECIFICATION
				 * */
				StopWatch swmpMasterSpecs = new StopWatch();
				swmpMasterSpecs.start();
				mpMasterSpecs = BbUtil.getMasterSpecs(context,sContextObjectId);
				swmpMasterSpecs.stop();
				LOGGER.info("RMP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());
				
				
				/**
				 * STARTING MATERIALS
				 * */
				//SPEC: 05/03/2021: Modified for 18x.6 DEV by Bala-- START				
				StringBuilder sbStartType = new StringBuilder();
				StringBuilder sbStartName = new StringBuilder();
				StringBuilder sbStartRev = new StringBuilder();
				StringBuilder sbStartPhase = new StringBuilder();
				StringBuilder sbStartTitle = new StringBuilder();
				StringBuilder sbStartState = new StringBuilder();
				StringBuilder sbStartID = new StringBuilder();
				
				MapList mlStartingMaterials=new MapList();
				StringList strStartOjectSelects = new StringList();								
				strStartOjectSelects.add(ConstantsUtil.SELECT_NAME);
				strStartOjectSelects.add(ConstantsUtil.SELECT_REVISION);
				strStartOjectSelects.add(ConstantsUtil.SELECT_TYPE);
				strStartOjectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				strStartOjectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				strStartOjectSelects.add(ConstantsUtil.SELECT_CURRENT);
				strStartOjectSelects.add(ConstantsUtil.SELECT_ID);
				StringList strRelSelects = new StringList(ConstantsUtil.SELECT_RELATIONSHIP_ID);
				//SPEC: <10.05.2021>: Bala Added for External Requirement 33248 Dev 18x.6.0.1-- START
				String sStartingWhere = ConstantsUtil.EMPTY_STRING;
				//SPEC: <08-12-2021>: Bala Modified for Stress Testing Defect 44365  -- START
				try {
				//SPEC: <08-12-2021>: Bala Modified for Stress Testing Defect 44365  -- END
				if(bAllInfoView) {
					sStartingWhere = "current!=Obsolete";
				}else {
					sStartingWhere = "current==Release";
				}
				//SPEC: <10.05.2021>: Bala Added for External Requirement 33248 Dev 18x.6.0.1-- END
				mlStartingMaterials=doRMP.getRelatedObjects(context, 
						ConstantsUtil.RELATIONSHIP_STARTINGMATERIAL,
						DomainConstants.QUERY_WILDCARD, 
						strStartOjectSelects, 
						strRelSelects, 
						false,
						true,
						(short) 1,
						sStartingWhere, 
						ConstantsUtil.EMPTY_STRING,
						0);
				
				Map mStartingMap=doRMP.getInfo(context, strStartOjectSelects);
				mlStartingMaterials.add(mStartingMap);
				
				Iterator iObjectListItr = mlStartingMaterials.iterator();								
				while(iObjectListItr.hasNext()) {
					Map mObjectMap = (Map) iObjectListItr.next();
					String strName = validator.getStringEquivalentForStringList(mObjectMap.get(ConstantsUtil.SELECT_NAME));
					String strRevision = validator.getStringEquivalentForStringList(mObjectMap.get(ConstantsUtil.SELECT_REVISION));
					String strType = BbUtil.MapsType(validator.getStringEquivalentForStringList(mObjectMap.get(ConstantsUtil.SELECT_TYPE)));
					String strReleasePhase = validator.getStringEquivalentForStringList(mObjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
					String strTitle = validator.getStringEquivalentForStringList(mObjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String strStartCurrent = validator.getStringEquivalentForStringList(mObjectMap.get(ConstantsUtil.SELECT_CURRENT));
					strStartCurrent = RawBO.getReleasedState(context, strStartCurrent);
					String strStartingID = validator.getStringEquivalentForStringList(mObjectMap.get(ConstantsUtil.SELECT_ID));
					
					boolean showData = BbUtil.checkHasAccess(context, sUserType, strStartingID);
					//SPEC: <07.02.2022>: Guna Added for defect 36086 18x6.0.3 release  -- START
					if (!strStartCurrent.equalsIgnoreCase((String) ConstantsUtil.RELEASE)
										&& !strStartCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED)) {

									strStartingID = ConstantsUtil.NO_ACCESS;
						}
					//SPEC: 23/08/2022: Modified by Manikanta for 22x Defect-50236  -- START
					if (!showData) {
						continue;
					}
					//SPEC: 23/08/2022: Modified by Manikanta for 22x Defect-50236  -- END
					//SPEC: <07.02.2022>: Guna Added for defect 36086 18x6.0.3 release  -- START
					if (UIUtil.isNotNullAndNotEmpty(strStartCurrent) && strStartCurrent.equalsIgnoreCase(ConstantsUtil.STATE_PRELIMINARY))
					{
						strStartCurrent = ConstantsUtil.STATE_INWORK;
					}
					formatData(sbStartName, strName);
					formatData(sbStartRev, strRevision);
					formatData(sbStartType, strType);
					formatData(sbStartPhase, strReleasePhase);
					formatData(sbStartTitle, strTitle);
					formatData(sbStartState, strStartCurrent);
					formatData(sbStartID, strStartingID);
				}
				mpStartingMaterials.put(ConstantsUtil.TYPE, sbStartType.toString());  
				mpStartingMaterials.put(ConstantsUtil.NAME, sbStartName.toString());				
				mpStartingMaterials.put(ConstantsUtil.REVISION, sbStartRev.toString());		
				mpStartingMaterials.put(ConstantsUtil.PHASE, sbStartPhase.toString());		
				mpStartingMaterials.put(ConstantsUtil.TITLE, sbStartTitle.toString());				
				mpStartingMaterials.put(ConstantsUtil.STATE, sbStartState.toString());				
				mpStartingMaterials.put(ConstantsUtil.ID, sbStartID.toString());				
				//SPEC: 05/03/2021: Modified for 18x.6 DEV by Bala-- END	
				
				//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- START
				strStartingMaterials = validator.getStringEquivalentForStringList(mpStartingMaterials.get(ConstantsUtil.SELECT_NAME));
				strStartingMaterials = strStartingMaterials.substring(0, strStartingMaterials.length() -1);
				//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- END
				
				if(bSupplierView || bManufacturerView) {
					mpStartingMaterials=BbUtil.filterPhase(mpStartingMaterials);
					}
				//SPEC: <08-12-2021>: Bala Modified for Stress Testing Defect 44365  -- START
				}
				catch(Exception e) {
					LOGGER.error("Exception From RMP Service IMPL Class "+e);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					throw e;
				}
				
				CommonBusUtilBO commonBO = new CommonBusUtilBO();
				mpAlternates = commonBO.getAlternates(context, sContextObjectId);
				
				
				mpAlternates = BbUtil.filterMapList(mpAlternates);
				//SPEC: 23/02/2021: commented for 18x.6 DEV by Bala-- END
				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=BbUtil.getRelatedAts(context, doRMP);
				
				mpRelatedATS=BbUtil.filterMapList(mpRelatedATS);
				
				
				if(bManufacturerView || bSupplierView) {
					mpRelatedATS=BbUtil.filterPhase(mpRelatedATS);
				}
				swAts.stop();
				LOGGER.info("RMP ATS ELAPSED TIME : "+swAts.getTime());
				
				//Added by Ketan for Req. no. 48322 -- START
				/**
				 *  SUSTAINABILITY
				 **/
				//SPEC: Modified by Ajay for Req. no. 30224 START
				if(mpAttribResult.get(ConstantsUtil.SPECIFICATIONSUBTYPE).equals(ConstantsUtilIRM.SUBTYPE_WITH_MCP)) {
					mpSustainability.put(ConstantsUtilIRM.PGPACKAGECOMPOPTPROPERTIES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES) : ConstantsUtil.EMPTY_STRING);
					mpSustainability.put(ConstantsUtilIRM.PGPACKAGEDURABILITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGEDURABILITY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGEDURABILITY) : ConstantsUtil.EMPTY_STRING);
					mpSustainability.put(ConstantsUtilIRM.PGMATERIALTHICKNESS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALTHICKNESS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALTHICKNESS) : ConstantsUtil.EMPTY_STRING);
					mpSustainability.put(ConstantsUtilIRM.PGMATERIALDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALDENSITY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALDENSITY) : ConstantsUtil.EMPTY_STRING);
					mpSustainability.put(ConstantsUtilIRM.PGPAPERDISSOLVABILITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Modified by Ajay for Req. no. 30224 END
				
				/**
				 * LOAD PACKAGING CERTIFICATIONS
				 * */
				
				StopWatch swPkgCert = new StopWatch();
				swPkgCert.start();
				ManufacturingEquivalentPartBO mep = new ManufacturingEquivalentPartBO();
				MapList mpPackagingCert =mep.getPackagingCertificationsList(context,objId,sContextObjectName,sContextObjecttype,sContextObjectPolicy);
				mpPackagingCertification =mep.getCertificationDetails(context,mpPackagingCert,(String)resultMaps.get(DomainConstants.SELECT_NAME),doRMP,sContextObjecttype);
				swPkgCert.stop();
				
				LOGGER.info("PACKAGING CERTIFICATIONS ELAPSED TIME : "+swPkgCert.getTime());
				hmAttrib.put(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS, mpPackagingCertification);
				//Added by Ketan for Req. no. 48322 -- END
			}
			}
			if(sSapType.equalsIgnoreCase("HALB") ) {
				mpStability =RawBO.getStabilityDocumentsonRM(context, objId);
			}
			//SPEC: <13.10.2020>: Added for the Release 18x5 -- END
				
			if(bAllInfoView) {	
				mpAttribResult.put(ConstantsUtil.FRANCHISE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE)));
				mpAttribResult.put(ConstantsUtil.BUSINESSAREA, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA)));
				mpAttribResult.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA)));
				mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
				
				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = BbUtil.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
					}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
				
				mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_VAULT)))?(String)resultMaps.get(ConstantsUtil.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ALTERNATIVEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.SHIPRECEIVEINFO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PGASLALLOCATION, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.RERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISBATTERY, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);


				/**
				 * LOAD LIFECYCLE SECTION
				 * */
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval= BbUtil.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("RMP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				//SPEC: 12/03/2021: Added for 18x.6 DEV by Bala-- START
				hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
				
				mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);

				/**
				 * LOAD PLANT SECTION
				 * */
				IRMSBO irmsbo = new IRMSBO();
				//SPEC: 16/03/2021: Added for 18x.6 DEV by Bala-- START
				Map mPlantResultMap = new HashMap();
				StringList slBusSelect= new StringList();	 
				slBusSelect.add(ConstantsUtil.SELECT_NAME);			
				StringList slRelSelectStmts= new StringList();
				slRelSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
				slRelSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
				slRelSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED);
				slRelSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
			
				StringList slName = new StringList();
				StringList slAuthorizedToUse = new StringList();
				StringList slAuthorizedToProduce = new StringList();
				StringList slActivated = new StringList();
				StringList slAuthorizedToView = new StringList();
				MapList mlPlantList=doRMP.getRelatedObjects(context, 
						ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY,
						DomainConstants.QUERY_WILDCARD, 
						slBusSelect, 
						slRelSelectStmts, 
						true,
						false,
						(short)1,
						ConstantsUtil.EMPTY_STRING, 
						ConstantsUtil.EMPTY_STRING,
						0);
				
				mlPlantList.sort(DomainConstants.SELECT_NAME, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
			    Iterator itrObjectList = mlPlantList.iterator();
				while(itrObjectList.hasNext()) 
				{
					mPlantResultMap = (Map) itrObjectList.next();
					slName.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_NAME));
					slAuthorizedToUse.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE));
					slAuthorizedToProduce.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE));
					slActivated.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED));
					slAuthorizedToView.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW));	
				}
				mPlantResultMap = new HashMap();
				mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_NAME, slName);
				mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE, slAuthorizedToUse);
				mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE, slAuthorizedToProduce);
				mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED, slActivated);
				mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW, slAuthorizedToView);
				mPlantResultMap.put(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE, sSapType);
				mpPlantResult = irmsbo.updatePlantInfo(mPlantResultMap);
				//SPEC: 16/03/2021: Added for 18x.6 DEV by Bala-- END
				hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
				//SPEC: 12/03/2021: Added for 18x.6 DEV by Bala-- END
				/**
				 * LOAD OWNERSHIP SECTION
				 * */
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.MODIFIED)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.OSO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
				

				mapOwnerShipResult.put(ConstantsUtil.ODL, BbUtil.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST) : ConstantsUtil.EMPTY_STRING));
				mapOwnerShipResult = BbUtil.filterMapList(mapOwnerShipResult);
				//SPEC: 12/03/2021: Added for 18x.6 DEV by Bala-- START
				hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
				//SPEC: 12/03/2021: Added for 18x.6 DEV by Bala-- END
				/**
				 * LOAD SAFETY SECTION
				 * */
				mpRegSafety.put(ConstantsUtil.CIN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLOR_INDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLOR_INDEX) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.VALENCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVALENCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVALENCE) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.CR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICAL_REACTIVITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICAL_REACTIVITY) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.CAS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.EEN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEINECSELINCSNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEINECSELINCSNUMBER) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.MO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIAL_ORIGIN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIAL_ORIGIN) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.MF, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.CG, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.MOF, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MOLECULAR_FORMULA)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MOLECULAR_FORMULA) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.IC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.RPH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_RPHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_RPHASE) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.SPH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SPHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SPHASE) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.SS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAFETYSYMBOL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAFETYSYMBOL) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety.put(ConstantsUtil.DC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGERCATEGORY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGERCATEGORY) : ConstantsUtil.EMPTY_STRING);
				mpRegSafety = BbUtil.filterMapList(mpRegSafety);
				
				hmAttrib.put(ConstantsUtil.REGULARSAFETY, mpRegSafety);				

				/**
				 * LOAD SPECIFICATION SECTION
				 * */
				mpSpecifications.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ID) : ConstantsUtil.EMPTY_STRING);
				mpSpecifications.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME) : ConstantsUtil.EMPTY_STRING);
				mpSpecifications.put(ConstantsUtil.TYPE, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpSpecifications.put(ConstantsUtil.SAPDES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpSpecifications.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpSpecifications.put(ConstantsUtil.SELECT_CURRENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT) : ConstantsUtil.EMPTY_STRING);
				
				hmAttrib.put(ConstantsUtil.SPECIFICATIONS, mpSpecifications);
				
				
				
				/**
				 * R&D SITES
				 * */
				StringList objectSelects = new StringList();
				objectSelects.add(ConstantsUtil.SELECT_ID);
				objectSelects.add(ConstantsUtil.SELECT_CURRENT);
				objectSelects.add(ConstantsUtil.SELECT_NAME);
				objectSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHORTCODE);
				//SPEC: 12/04/2021: Added for 18x.6 RM Internal Defect by Bala-- START
				objectSelects.add(ConstantsUtil.SELECT_TYPE);
				//SPEC: 12/04/2021: Added for 18x.6 RM Internal Defect by Bala-- END
				
				StringList lstRelSelects = new StringList(ConstantsUtil.SELECT_RELATIONSHIP_ID);
				
				//SPEC: <08-12-2021>: Bala Modified for Stress Testing Defect 44365  -- START
				try {
				//SPEC: <08-12-2021>: Bala Modified for Stress Testing Defect 44365  -- END				
				MapList returnMapList=doRMP.getRelatedObjects(context, 
						ConstantsUtil.RELATIONSHIP_ALLOCATION_RESPONSIBILITY,
						DomainConstants.QUERY_WILDCARD, 
						objectSelects, 
						lstRelSelects, 
						true,
						false,
						(short) 1,
						ConstantsUtil.EMPTY_STRING, 
						ConstantsUtil.EMPTY_STRING,
						0);
						
				
				Iterator objectListItr = returnMapList.iterator();
				StringBuilder sbName = new StringBuilder();
				StringBuilder sbDesc = new StringBuilder();
				StringBuilder sbState = new StringBuilder();
				StringBuilder sbShortCode = new StringBuilder();
				StringBuilder sbId = new StringBuilder();
				//SPEC: 12/04/2021: Added for 18x.6 RM Internal Defect by Bala-- START
				StringBuilder sbType = new StringBuilder();
				//SPEC: 12/04/2021: Added for 18x.6 RM Internal Defect by Bala-- END
				
				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					String sState = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
					String sDesc = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
					String sId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sShortCode = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHORTCODE));
					//SPEC: 12/04/2021: Added for 18x.6 RM Internal Defect by Bala-- START
					String sType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
					formatData(sbType, sType);
					//SPEC: 12/04/2021: Added for 18x.6 RM Internal Defect by Bala-- END
					formatData(sbName, sName);
					formatData(sbState, sState);
					formatData(sbDesc, sDesc);
					formatData(sbShortCode, sShortCode);
					formatData(sbId, sId);
					
				}
				mpRdSite.put(ConstantsUtil.NAME, sbName.toString());
				mpRdSite.put(ConstantsUtil.STATE, sbState.toString());
				mpRdSite.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
				mpRdSite.put(ConstantsUtil.SHORTCODE, sbShortCode.toString());
				mpRdSite.put(ConstantsUtil.ID, sbId.toString());
				mpRdSite.put(ConstantsUtil.TYPE, sbType.toString());
				
				hmAttrib.put(ConstantsUtil.RDSITE, mpRdSite);
				} 
				catch(Exception e) {
					LOGGER.error("Exception From RMP Service IMPL Class "+e);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					throw e;
				}
			}
			
			/**
			 * LOAD IP SECTION
			 * */
			StopWatch swIpSecurity = new StopWatch();
			swIpSecurity.start();
			String strType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			mpIpSecurity =BbUtil.getIpClass(context, strType, doRMP, RawBO.getIpSelects());
			swIpSecurity.stop();
			LOGGER.info("PMP  Security ELAPSED TIME : "+swIpSecurity.getTime());
			
			/**
			 * SECURITY
			 * */
			StopWatch swSecurity = new StopWatch();
			swSecurity.start();
			mpSecurity =commonBo.updateSecurity(context,resultMaps);
			swSecurity.stop();
			LOGGER.info("RMP  Security ELAPSED TIME : "+swSecurity.getTime());
			
			/**
			 * LOAD ORGANIZATION SECTION
			 */
			if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {
				
				if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList")) {
					mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
				} else  {
					mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				}
			}			
			if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {			
				if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList")) {
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
				} else {
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				}
			}
			mpOrganization = BbUtil.filterMapList(mpOrganization);

			// Modified to view PQR View Equivalents for all view.
			/**
			 * This Method is for getting the MEPS
			 * @param context
			 * @param Relationship
			 * @param objectMap
			 * @param bMEP
			 * @return
			 * @throws Exception
			 */
			
			//Added by Jwala for 22x Development Req 42996 -- START
			boolean isUserCMandSP = BObjutil.isUserCMandSP(context, objId);
			//Added by Jwala for 22x Development Req 42996 -- END
			
			mpMEPResult = BbUtil.getPQREquivalents(context, resultMaps, true, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT,sUserType);
			
			// Added by Jwala for Req/Defect 35581 43951 -- START
			if(bManufacturerView || bSupplierView){
				mpMEPResult.remove(ConstantsUtil.PQRBA);
				mpMEPResult.remove(ConstantsUtil.PQRPCP);
				//Modified by Jwala for 22x Development Req 42996 -- START
				if(bSupplierView && !isUserCMandSP){
					mpMEPResult.remove(ConstantsUtil.PQRPLANTS);
				}
				//Modified by Jwala for 22x Development Req 42996 -- END
			}
			// Added by Jwala for Req/Defect 35581 43951 -- END
			
			//SPEC: 23-12-2022: Ketan added for Req 34055 -- START
            if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
            	mpMEPResult = new HashMap<String,String>();
            }
            //SPEC: 23-12-2022: Ketan added for Req 34055 -- END
			
			/**
			 * This Method is for getting the SEPS 
			 * @param context
			 * @param Relationship
			 * @param objectMap
			 * @param bSEP
			 * @return
			 * @throws Exception
			 */
            
            StopWatch swSEP = new StopWatch();
            swSEP.start();
			mpSEPResult = BbUtil.getPQREquivalents(context, resultMaps, false, ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT,sUserType);
			swSEP.stop();
			LOGGER.info("RMP SEP Elapsed time : "+swSEP.getTime());
			// Added by Jwala for Req/Defect 35581 43951 -- START
			if(bManufacturerView || bSupplierView) {
				mpSEPResult.remove(ConstantsUtil.PQRBA);
				mpSEPResult.remove(ConstantsUtil.PQRPCP);
				//Modified by Jwala for 22x Development Req 42996 -- START
				if(bSupplierView && !isUserCMandSP){
					mpSEPResult.remove(ConstantsUtil.PQRPLANTS);
				}
				//Modified by Jwala for 22x Development Req 42996 -- END
			}
			// Added by Jwala for Req/Defect 35581 43951 -- END
			
			//SPEC: 23-12-2022: Ketan added for Req 34055 -- START
            if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
                mpSEPResult = new HashMap<String,String>();
            }
            //SPEC: 23-12-2022: Ketan added for Req 34055 -- END
			
			//SPEC: 12/03/2021: Modified for 18x.6 DEV by Bala-- START
			/**
			 * LOAD Battery Details SECTION
			 * */
			//SPEC: 31/08/2021: Modified for 18x.6.0.2 Defect#42909 by Manikanta-- START
			String strIfYesselectbatterytype=(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING;
			//if(UIUtil.isNotNullAndNotEmpty(strIfYesselectbatterytype)) {
				mpBatteryDetails= RawBO.getBatteryTypeFields(context, strIfYesselectbatterytype);
				//SPEC: Modified by Ajay for Defect. no. 66352 START
				if(mpBatteryDetails != null && ! mpBatteryDetails.isEmpty()) {
					mpBatteryDetails.put(ConstantsUtil.ISTHEPRODUCTABATTERY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTHEPRODUCTABATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTHEPRODUCTABATTERY) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Modified by Ajay for Defect. no. 66352 END
			//}
			//SPEC: 31/08/2021: Modified for 18x.6.0.2 Defect#42909 by Manikanta-- END
				
			// Modified by Ajay for Defect 12042 -- START
			if(bManufacturerView || bAllInfoView) {
				
				/**
				 * LOAD PHYSICAL PROP SECTION
				 * */
				//Contract Manufacturer View & All Info View
				StopWatch swPhys = new StopWatch();
				swPhys.start();
				mpPhysicalPropResult.put(ConstantsUtil.APPEARANCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_APPEARANCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_APPEARANCE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult.put(ConstantsUtil.COLOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLOR) : ConstantsUtil.EMPTY_STRING);
				String strSpecificGravity = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SPECIFICGRAVITY_INPUTVALUE);
				
				mpPhysicalPropResult.put(ConstantsUtil.SPECIFICGRAVITY, strSpecificGravity);
				mpPhysicalPropResult.put(ConstantsUtil.MELTINGPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MELTINGPOINT_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MELTINGPOINT_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult.put(ConstantsUtil.BOILINGPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_BOILINGPOINT_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_BOILINGPOINT_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult.put(ConstantsUtil.VISCOSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VISCOSITY_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VISCOSITY_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult.put(ConstantsUtil.FORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult.put(ConstantsUtil.VAPORPRESSURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult.put(ConstantsUtil.GRADE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GRADE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GRADE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult.put(ConstantsUtil.AQUEOUSSOLUBILITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMAQUEOUSSOLUBILITY_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMAQUEOUSSOLUBILITY_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult.put(ConstantsUtil.AUTOIGNITIONTEMP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPERATURE_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPERATURE_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult.put(ConstantsUtil.FLASHPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FLASHPOINT_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FLASHPOINT_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalPropResult = BbUtil.filterMapList(mpPhysicalPropResult);
				swPhys.stop();
				LOGGER.info("RMP GET PHYS PROP ELAPSED TIME : "+swPhys.getTime());
				
				hmAttrib.put(ConstantsUtil.PHYSICALPROPERTIES, mpPhysicalPropResult);
				
				
				
				/**
				 * PRODUCING FORMULA
				 * */
				StopWatch swProducingFormula = new StopWatch();
				swProducingFormula.start();
				mpProducingFarmula = BbUtil.getProducingFormula(context,sContextObjectId);
				swProducingFormula.stop();
				LOGGER.info("RMP PRODUCING FORMULA ELAPSED TIME : "+swProducingFormula.getTime());
				
				hmAttrib.put(ConstantsUtil.PRODUCINGFORMULA, mpProducingFarmula);
				
				// Modified by Ajay for Defect 12042 -- END
				
				
				/**
				 * LOAD GPSASSESSMENTS SECTION
				 * */
				StopWatch swgps= new StopWatch();
				swgps.start();
				DeviceProductPartBO DPPBO = new DeviceProductPartBO();
				mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
				//mpGPSAssessments = RawBO.getGPSAssessments(context, sContextObjectId,resultMaps);
				mpGPSAssessments = BbUtil.filterMapList(mpGPSAssessments);
				swgps.stop();
				LOGGER.info("DPP  GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
				
				//Added by Jwala for the defect 44292 -- START
				if(!bAllInfoView){
					mpGPSAssessments.remove(ConstantsUtilIRM.BUSINESSAREAFROMPART);
					mpGPSAssessments.remove(ConstantsUtilIRM.PRODUCTCATEPLATFORMFRMPART);
				}
				//Added by Jwala for the defect 44292 -- END
				//SPEC: 12/04/2022: Modified by Manikanta for 22x DEV -- START
				if(bAllInfoView){
					hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
				}
				//SPEC: 12/04/2022: Modified by Manikanta for 22x DEV -- END		
				/**
				 * LOAD CHEMICAL MOLECULE SECTION
				 * */
				//Contract Manufacturer View & All Info View
				StopWatch swChemMol = new StopWatch();
				swChemMol.start();
				mpChemMoleculeResult.put(ConstantsUtil.HLBVALUE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpChemMoleculeResult.put(ConstantsUtil.SAPONIFICATIONVALUE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPONIFICATIONVALUE_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPONIFICATIONVALUE_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpChemMoleculeResult.put(ConstantsUtil.HYDROPHILICINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHYDROPHILICINDEX_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHYDROPHILICINDEX_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpChemMoleculeResult.put(ConstantsUtil.HYDROXLVALUE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HYDROXYLVALUE_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HYDROXYLVALUE_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpChemMoleculeResult.put(ConstantsUtil.REACTIVITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACTIVITY_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACTIVITY_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpChemMoleculeResult.put(ConstantsUtil.IUSPERGRAM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_IUSPERGRAM_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_IUSPERGRAM_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpChemMoleculeResult.put(ConstantsUtil.ALKANITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ALKALINITY_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ALKALINITY_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpChemMoleculeResult.put(ConstantsUtil.ANIMALDERIVED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ANIMALDERIVED)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ANIMALDERIVED) : ConstantsUtil.EMPTY_STRING);//Modified by Ajay for Req no 36979
				mpChemMoleculeResult.put(ConstantsUtil.PH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PHVALUE_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PHVALUE_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpChemMoleculeResult = BbUtil.filterMapList(mpChemMoleculeResult);
				swChemMol.stop();
				LOGGER.info("RMP GET CHEM MOLECULE ELAPSED TIME : "+swChemMol.getTime());
				
				hmAttrib.put(ConstantsUtil.CHEMICALMOLECULARPROPERTIES, mpChemMoleculeResult);
				
			}
			/**
			 * LOAD SUBSTANCES SECTION
			 * */
			StopWatch swSubst = new StopWatch();
			swSubst.start();
			//SPEC: 26/07/2022: Modified by Manikanta for 22x DEV Req 41754-- START
			//Modified by Ketan for Req no 2332
			if(!bSupplierView) {
				//SPEC: Modified by Ajay for Req. no. 30224 START
				if(mpAttribResult.get(ConstantsUtil.SPECIFICATIONSUBTYPE).equals(ConstantsUtilIRM.SUBTYPE_WITH_MCP) || mpAttribResult.get(ConstantsUtil.SPECIFICATIONSUBTYPE).equals(ConstantsUtilIRM.DEVICE)) {
					PackagingMaterialPartBO pmpBO = new PackagingMaterialPartBO();
					mpSubStanceResult = pmpBO.getSubstances(context,resultMaps);
					mpSubStanceResult=BbUtil.filterPhase(mpSubStanceResult);
					mpSubStanceResult=BbUtil.filterMapList(mpSubStanceResult);
				} else {
					mpSubStanceResult = RawBO.getMaterialCompositionAndSubstance(context, resultMaps);
					//SPEC: <03.06.2021>: Bala Modified for External Requirement 33248 Revert Back changes Dev 18x.6.0.1-- START
					mpSubStanceResult = BbUtil.verifyOwnership(context, mpSubStanceResult);
					//SPEC: <03.06.2021>: Bala Modified for External Requirement 33248 Revert Back changes Dev 18x.6.0.1-- END
				}
				hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpSubStanceResult);
				//SPEC: Modified by Ajay for Req. no. 30224 END	
			}
			swSubst.stop();
			LOGGER.info("RMP GET SUBSTANCE ELAPSED TIME : "+swSubst.getTime());
			//SPEC: 26/07/2022: Modified by Manikanta for 22x DEV Req 41754-- END
			if (!bManufacturerView) {
				/**
				 * LOAD FILES
				 * */
				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
				CommonDocBO cdoc = new CommonDocBO();
				String strFileSize = cdoc.updateFileSize(FileSize);
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);
				
				hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			}
			
			/**
			 * LOAD CERTIFICATIONS SECTION
			 * */
			// Guna Added for Defect 37250  18x.5.2 Release -- START
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				StopWatch swCert = new StopWatch();
				swCert.start();
				MapList mlCertifications = commonBo.getCertifications(context, objId);

				Iterator itrCerts = mlCertifications.iterator();
				StringBuilder sbCertName = new StringBuilder();
				StringBuilder sbCertRev = new StringBuilder();
				StringBuilder sbCertType = new StringBuilder();
				StringBuilder sbCertDesc = new StringBuilder();
				StringBuilder sbCertState = new StringBuilder();
				StringBuilder sbCertifications = new StringBuilder();
				StringBuilder sbStatus = new StringBuilder();
				StringBuilder sbCExpirationDate = new StringBuilder();
				//SPEC:01/10/2020- Added for Defect#36319 - START
				StringBuilder sbManufacturer = new StringBuilder();
				//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- START
				StringBuilder sbCertId = new StringBuilder();
				//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- END
				//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
				StringBuilder sbCertificationSource = new StringBuilder();

				//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- START
				mlCertifications.sort(DomainConstants.SELECT_NAME, "ascending", "String");
				//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- END
				itrCerts = mlCertifications.iterator();
				while (itrCerts.hasNext()) {
					Map objectMap = (Map) itrCerts.next();
					String strCertification  =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_VALUE));
					StringTokenizer tokenize = new StringTokenizer(strCertification,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String strStatus =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_STATUS));
					String strExpireDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_EXPIRATION_DATE));
					StringTokenizer statusTokenize = new StringTokenizer(strStatus,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					StringTokenizer expireDateTokenize = new StringTokenizer(strExpireDate,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
					String strSource =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_CERTIFICATION_SOURCE));
					StringTokenizer sourceTokenize = new StringTokenizer(strSource,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- END
					while(tokenize.hasMoreTokens())
					{
						String strCert  = tokenize.nextToken().toString().trim();
						String relName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.KEY_RELATIONSHIP));

						//SPEC: Added for Defect 41799 by Jwala ## -- START
						String strCertState = ConstantsUtil.EMPTY_STRING;

						String strCertName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String strCertID = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String strCertRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
						String strCertType = BbUtil.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE)));
						String strCertDesc = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
						if(strCertName.contains("MEP-")){
							strCertState = BbUtil.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
						}else{
							strCertState = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
						}

						//SPEC: Added for Defect 42402 by Jwala ## -- END
						String sUserlicense = sct.getUserLicense();
						boolean showData = false;

						showData = BbUtil.checkHasAccess(context, sUserType, strCertID);

						//SPEC: Added for Defect 42402 by Jwala ## -- START
						if(!(strCertState.equals(ConstantsUtil.RELEASE)|| strCertState.equalsIgnoreCase(ConstantsUtil.RELEASED)))
							strCertID = ConstantsUtil.NO_ACCESS;
						//SPEC: Added for Defect 42402 by Jwala ## -- END

						//SPEC: Release SR18x.6.0.1 - Added by Amman on June 10, 2021 for Defect #43438 -- START
						if(BbUtil.isModificatinRequired()) {
							if(!showData) {
								continue;
							}
							if(!(strCertState.equals(ConstantsUtil.RELEASE)|| strCertState.equalsIgnoreCase(ConstantsUtil.RELEASED))) {
								continue;
							}
						}
						//SPEC: Release SR18x.6.0.1 - Added by Amman on June 10, 2021 for Defect #43438 -- END

						if (showData) {
							formatData(sbCertName,strCertName);
							formatData(sbCertRev,strCertRev);
							formatData(sbCertType,strCertType);
							formatData(sbCertDesc,strCertDesc);
							formatData(sbCertState,strCertState);
							formatData(sbCertId,strCertID);
							formatData(sbCertifications, strCert);
						} else{
							formatData(sbCertName,strCertName);
							formatData(sbCertRev,strCertRev);
							formatData(sbCertType,strCertType);
							formatData(sbCertDesc,ConstantsUtil.NO_ACCESS);
							formatData(sbCertState,ConstantsUtil.NO_ACCESS);
							formatData(sbCertId,ConstantsUtil.NO_ACCESS);
							formatData(sbCertifications, strCert);
						}

						if(statusTokenize.hasMoreTokens() && expireDateTokenize.hasMoreTokens()){
							formatData(sbStatus,statusTokenize.nextToken().toString().trim());
							//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- START
							formatData(sbCExpirationDate,validator.DateFormatterParse(expireDateTokenize.nextToken().toString().trim()));
							//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- END
						}else{
							formatData(sbStatus,ConstantsUtil.EMPTY_STRING);
							formatData(sbCExpirationDate,ConstantsUtil.EMPTY_STRING);
						}
						//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
						if(sourceTokenize.hasMoreTokens()) {
							formatData(sbCertificationSource,sourceTokenize.nextToken().trim());
						}else {
							formatData(sbCertificationSource,ConstantsUtil.EMPTY_STRING);
						}
						//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- END
						if(relName.equals(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT)){
							if(showData){
								formatData(sbManufacturer, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_NAME)));
							} else{
								formatData(sbManufacturer,ConstantsUtil.NO_ACCESS);
							}
						}else{
							if(showData){
								formatData(sbManufacturer, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_MANUFACTURINGRESPONSIBILITY_NAME)));
							} else{
								formatData(sbManufacturer,ConstantsUtil.NO_ACCESS);
							}
						}

					}
				}
				// Guna Added for Defect 37250  18x.5.2 Release -- END
				mpCertification.put(ConstantsUtil.NAME, sbCertName.toString());
				mpCertification.put(ConstantsUtil.REVISION, sbCertRev.toString());
				mpCertification.put(ConstantsUtil.TYPE, sbCertType.toString());
				mpCertification.put(ConstantsUtil.DESCRIPTION, sbCertDesc.toString());
				mpCertification.put(ConstantsUtil.STATE, sbCertState.toString());
				mpCertification.put(ConstantsUtil.CERTIFICATION, sbCertifications.toString());
				mpCertification.put(ConstantsUtil.STATUS, sbStatus.toString());
				mpCertification.put(ConstantsUtil.EXPIRATIONDATE, sbCExpirationDate.toString());
				mpCertification.put(ConstantsUtil.MANUFACTURER, sbManufacturer.toString());
				//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- START
				mpCertification.put(ConstantsUtil.ID, sbCertId.toString());
				//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- END
				//SPEC: 04/04/2022: Added by Manikanta for 18x.6.0.4 DEV -- START
				mpCertification.put(ConstantsUtilIRM.CERTIFICATIONSOURCE, sbCertificationSource.toString());
				//SPEC: 04/04/2022: Added by Manikanta for 18x.6.0.4 DEV -- END
				mpCertification = BbUtil.filterMapList(mpCertification);
				swCert.stop();
				LOGGER.info("RMP CERTIFICATION ELAPSED TIME : "+swCert.getTime());
			}
			// Added by Jwala for the req 4945 - END
			
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.PROFILEIDENTIFICATION, mpProfileIdResult);
			//SPEC: 12/04/2022: Modified by Manikanta for 22x DEV -- START
			if(!bSupplierView && !bManufacturerView){
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: 12/04/2022: Modified by Manikanta for 22x DEV -- END
			hmAttrib.put(ConstantsUtil.CHEMICALCLASSIFICATION, mpChemClassResult);
			hmAttrib.put(ConstantsUtil.PERFUMEPROPERTIES, mpPerfumeResult);
			hmAttrib.put(ConstantsUtil.DETERGENTSURFACTANTPROPERTIES, mpCDetergentResult);
			hmAttrib.put(ConstantsUtilIRM.BATTERYDETAILS, mpBatteryDetails);
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- START
			if(mpStartingMaterials.size()!=1 && !(strStartingMaterials.equalsIgnoreCase(mpHeaderContent.get(DomainConstants.SELECT_NAME)))) {
				hmAttrib.put(ConstantsUtil.STARTINGMATERIALS, mpStartingMaterials);
			}
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- END
			hmAttrib.put(ConstantsUtil.ALTERNATES, mpAlternates);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
			//SPEC: 12/04/2022: Modified by Manikanta for 22x DEV -- START
			if(!bSupplierView && !bManufacturerView){
				mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				mpIpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.IPSECURITY, mpIpSecurity);
			}
			//SPEC: 12/04/2022: Modified by Manikanta for 22x DEV -- END
			hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
			hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult); 
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				hmAttrib.put(ConstantsUtil.CERTIFICATION, mpCertification);
			}
			// Added by Jwala for the req 4945 - END
			
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			//SPEC: Release SR18x.5.2 - Added for Defect# 39549  by Guna on Date 17/02/2021 -- START
			hmAttrib.put(ConstantsUtil.STABILITYDOCUMENT, mpStability);
			//SPEC: Release SR18x.5.2 - Added for Defect# 39549  by Guna on Date 17/02/2021 -- END
			//Added by Ketan for Req. no. 48322 -- START
			hmAttrib.put(ConstantsUtilIRM.SUSTAINABILITY, mpSustainability);
			//Added by Ketan for Req. no. 48322 -- END
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			pool.checkIn(context);
			sp.stop();
			//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- START
			//doRMP.close(context);
			//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- END

			LOGGER.info("RMP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		} catch (IOException e) {
			LOGGER.error("Unable to getRMPdata IOException: "+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getRMPdata MatrixException: "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		//LOGGER.info("RMP RESPONSE MESSAGE:: \n" + hmAttrib);
		if(sComp.equals(ConstantsUtilIRM.RMP)) {
			context.close();
		}
		return hmAttrib;
	}
	public static void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
}
