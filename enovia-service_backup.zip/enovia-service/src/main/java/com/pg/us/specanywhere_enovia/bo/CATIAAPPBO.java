package com.pg.us.specanywhere_enovia.bo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.dassault_systemes.enovia.characteristic.util.CharacteristicMasterUtil;
import com.dassault_systemes.knowledge_itfs.IKweDictionary;
import com.dassault_systemes.knowledge_itfs.IKweType;
import com.dassault_systemes.knowledge_itfs.KweInterfacesServices;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.sapbom.pgV3Constants;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.Pattern;
import matrix.util.StringList;
import com.pg.us.specanywhere_enovia.utility.ReadWriteXMLForPLMDTDocument;
import matrix.db.BusinessObject;
import com.matrixone.apps.domain.util.FrameworkUtil;

public class CATIAAPPBO {
	private static Logger LOGGER = Logger.getLogger(APPBO.class);
	BusObjectAttribUtil util  = new BusObjectAttribUtil();
	StringValidatorUtil strValidator = new StringValidatorUtil();
	ReadWriteXMLForPLMDTDocument ReadWriteXMLForPLMDTDocument = new ReadWriteXMLForPLMDTDocument();
	public CATIAAPPBO() {
		// empty constructor
	}


	/**
	 * Method Name 			: getProductPartStabilityDoc
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getProductPartStabilityDoc(Context context,Map resultMaps) 
	{
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.STR_IPCLASS);

		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTREVISION);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);

		boolean bHasOwnerShip = false;

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();

		int iLength = aCompany.length;
		
		if(iLength>-1) {
			for(int i=0;i<iLength;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;


		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			DomainObject CATIAAPPDO = DomainObject.newInstance(context, sObjectId);
			
			 Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PGPKGSTABILITYREPORT);
			 		typePattern.addPattern(ConstantsUtil.TYPE_PGTECHNICALRATIONAL);
			MapList mlRefDocs = CATIAAPPDO.getRelatedObjects(context, 
					ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT, //relationship pattern
					typePattern.getPattern(),                     //type pattern
					busSelect,                                    // object selects
					new StringList(),                             // relationship selects
					false,                                        // to direction
					true,                                         // from direction
					(short) 1,                                    // recursion level
					ConstantsUtil.EMPTY_STRING,                   // object where clause
					ConstantsUtil.EMPTY_STRING,                   // Rel where clause
					ConstantsUtil.ZERO_LEVEL);                    // level

			String sUser = util.getUserType();

			if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}

			if(util.isModificatinRequired()) 
			{
				mlRefDocs=util.filterPhase(mlRefDocs);
			}
			Iterator objectListItr = mlRefDocs.iterator();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbMasterProductPartName = new StringBuilder();
			StringBuilder sbMasterProductPartType = new StringBuilder();
			StringBuilder sbMasterProductPartRevision = new StringBuilder();
			StringBuilder sbMasterProductPartTitle =new StringBuilder();
			StringBuilder sbMasterProductPartID =new StringBuilder();
			StringBuilder sbProductExpirationDataRequired=new StringBuilder();
			StringBuilder sbTotalShelfLifeDays=new StringBuilder();
			StringBuilder sbTemperatureGroup=new StringBuilder();
			StringBuilder sbHumidityGroup=new StringBuilder();
			StringBuilder sbTransportFreezeProtection = new StringBuilder();
			StringBuilder sbTransportHeatProtection = new StringBuilder();
			StringBuilder sbBoundaryConditions = new StringBuilder();
			StringBuilder sbStabilityDocument = new StringBuilder();
			StringBuilder sbStabilityDocumentType = new StringBuilder();
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sId    =  (String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	 =	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);

				String sMasterProductPartID    =  validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartName    =  validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartType    =  validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartRevision    =   validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTREVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartTitle		=	validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTITLE))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTITLE) : ConstantsUtil.EMPTY_STRING;
				String sProductExpirationDataRequired	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
				String sTotalShelfLifeDays		=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
				String sTemperatureGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
				String sHumidityGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
				String sTransportFreezeProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
				String sTransportHeatProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
				String sBoundaryConditions = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
				String sStabilityDocument = (String)objectMap.get(ConstantsUtil.SELECT_NAME);

				SecurityService sct = new SecurityService();
				boolean showData = false;

				if(sType.equalsIgnoreCase("pgPKGDevelopmentOther") || sType.equalsIgnoreCase("pgPKGProductReadiness")){
					continue;
				}

				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}
				if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
					continue;
				}

				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					String sLangBuffer =DomainConstants.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;

					if (util.isModificatinRequired()) 
					{
						showData=util.checkHasAccess(context, null, sId);
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							bHasOwnerShip=false;
						}

					}else if(sct.isStaffAUGUser()) {
						showData=util.checkHasAccess(context, null, sId);
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							showData=false;
						}
					}else {
						showData=util.checkHasAccess(context, null, sId);
					}	
					if(showData) 
					{
						util.formatData(sbId,sId);
						util.formatData(sbMasterProductPartID,sMasterProductPartID);
						util.formatData(sbMasterProductPartName,sMasterProductPartName);
						util.formatData(sbMasterProductPartType,sMasterProductPartType);
						util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
						util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
						util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						util.formatData(sbTemperatureGroup,sTemperatureGroup);
						util.formatData(sbHumidityGroup,sHumidityGroup);
						util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						util.formatData(sbBoundaryConditions,sBoundaryConditions);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						util.formatData(sbStabilityDocumentType,sType);

					}else
					{
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartID,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartName,sMasterProductPartName);
						util.formatData(sbMasterProductPartType,sMasterProductPartType);
						util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
						util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
						util.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
						util.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
						util.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						util.formatData(sbStabilityDocumentType,sType);
					}
				}
			}
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.TYPE, sbStabilityDocumentType.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTEXPDATEREQ, sbProductExpirationDataRequired.toString());
			mpRefDoc.put(ConstantsUtil.TOTALSHELFLIFEDAYS, sbTotalShelfLifeDays.toString());
			mpRefDoc.put(ConstantsUtil.TEMPERATUREGROUP, sbTemperatureGroup.toString());
			mpRefDoc.put(ConstantsUtil.HUMIDITYGROUP, sbHumidityGroup.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, sbTransportFreezeProtection.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTHEATPROTECTION, sbTransportHeatProtection.toString());
			mpRefDoc.put(ConstantsUtil.BOUNDARYCONDITIONS, sbBoundaryConditions.toString());
			mpRefDoc.put(ConstantsUtil.STABILITYDOCUMENT, sbStabilityDocument.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTID, sbMasterProductPartName.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTNAME, sbMasterProductPartName.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTTYPE, sbMasterProductPartType.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTREV, sbMasterProductPartRevision.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTTITLE, sbMasterProductPartTitle.toString());

		}catch(Exception e){
			LOGGER.error("Exception in Program : CATIAAPPBO Method :getProductPartStabilityDoc "+e);
			return new HashMap();
		}
		return mpRefDoc;
	}
	//SPEC: <17.05.2022>: Guna Added for Req 33205 22x Release  -- START
	public StringList charBusSelectables() {
		StringList selectables =new StringList();
		selectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHALOWERSPECIFICATIONLIMIT);
		selectables.add(ConstantsUtilIRM.SELECT_CRITERIA);
		selectables.add(ConstantsUtilIRM.INTERFACE);
		selectables.add(ConstantsUtilIRM.SELECT_OBSCURE_UNIT_OF_MEASURE);
		selectables.add(DomainConstants.SELECT_ID);
		selectables.add(ConstantsUtilIRM.SELECT_CHAR_MASTER);
		selectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARACTERISTIC_CATEGORY);
		selectables.add(ConstantsUtil.SELECT_PHYSICAL_ID);
		selectables.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		selectables.add(ConstantsUtil.DESCRIPTION);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGACTIONREQUIRED);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGCHANGE);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGCHARACTERISTIC);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGTMLOGIC);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGMETHODORIGIN);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGMETHODNUMBER);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGMETHODSPECIFICS);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGSAMPLING);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGSUBGROUP);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGPLANTTESTING);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGRETESTINGUOM);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGRELEASECRITERIA);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGREPORTTYPE);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASIS);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGTESTGROUP);
		selectables.add(pgV3Constants.SELECT_ATTRIBUTE_PGAPPLICATION);
		selectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CATEGORYSPECIFICS);
		selectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PG_CHARACTERISTIC_CATEGORY);
		selectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_DESIGNSPECIFICS);
		selectables.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST);
		selectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARNOTES);
		selectables.add(ConstantsUtilIRM.SELECT_CHAR_MASTER_TITLE);
		selectables.add(ConstantsUtilIRM.SELECT_TM_NAME);
		selectables.add(ConstantsUtilIRM.SELECT_TM_ID);
		selectables.add(ConstantsUtilIRM.SELECT_TM_TYPE);
		selectables.add(ConstantsUtilIRM.SELECT_TMRD_NAME);
		selectables.add(ConstantsUtilIRM.SELECT_TMRD_ID);
		selectables.add(ConstantsUtilIRM.SELECT_TMRD_TYPE);
		selectables.add(ConstantsUtilIRM.SELECT_CHAR_MASTER);
		selectables.add(ConstantsUtilIRM.SELECT_CHAR_MASTER_PHYSICALID);
		selectables.add(ConstantsUtilIRM.SELECT_CHAR_MASTER_NAME);
		selectables.add(ConstantsUtilIRM.SELECT_CHAR_MASTER_REVISION);
		selectables.add(ConstantsUtilIRM.SELECT_CHAR_MASTER_TYPE);
		selectables.add(ConstantsUtilIRM.SELECT_CHAR_MASTER_CURRENT);
		selectables.add(ConstantsUtilIRM.SELECT_CRITERIA);
		selectables.add(ConstantsUtilIRM.SELECT_CRITERIA_TITLE);
		selectables.add(ConstantsUtilIRM.SELECT_TMRD_ID);
		selectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHAUPPERSPECIFICATIONLIMIT);
		selectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHALOWERROUTINERELEASELIMIT);
		selectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHAUPPERROUTINERELEASELIMIT);
		//SPEC: <17.08.2022>: Guna Added for Defect 50094 22x Release  -- START
		selectables.add(ConstantsUtilIRM.SELECT_UNIT_OF_MEASURE);
		//SPEC: <17.08.2022>: Guna Added for Defect 50094 22x Release  -- END
	return selectables;
	}
	/**
	 * Method Name 			: gePerformChar
	 * Method Description 	: Getting the Characteristics of the Part
	 * @param context
	 * @param ojectId
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> gePerformChar(Context context, String sContextObjectId) {
		Map<String, String> mapCharDetails = new HashMap<>();
		try {
			Map<String, StringList> mpDimensionDisplayVals =  getDimensions(context);
			StringList relSelects = new StringList(4);
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_OVERRIDEALLOWEDONCHILD);
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_MANDATORY_CHARACTERISTIC);
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_SEQUENCE_ORDER);
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_TREE_ORDER);
			Map mpUnits =getCKEUnits();
			
			DomainObject doObj = DomainObject.newInstance(context,sContextObjectId);
			 Pattern relPattern = new Pattern(ConstantsUtil.REL_PARAMETERAGGREGATION);	 
			 Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PLMPARAMETER);
			 MapList appCharList = doObj.getRelatedObjects(context,
						relPattern.getPattern(),                //relationship pattern
						typePattern.getPattern(),               //type pattern
						charBusSelectables(),                              // object selects
						relSelects,                             // relationship selects
						false,                                   // to direction
						true,                                    // from direction
						(short)1,                             // recursion level
						DomainConstants.EMPTY_STRING,          // object where clause
						null,
						0);
			
			appCharList.sort(ConstantsUtilIRM.SELECT_ATTRIBUTE_SEQUENCE_ORDER, ConstantsUtil.ASCENDING, ConstantsUtil.INTEGER);
			appCharList.sort(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARACTERISTIC_CATEGORY,  ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
			mapCharDetails =getCharacteristicsDetails(context,appCharList,mapCharDetails,mpDimensionDisplayVals,mpUnits);
		}
		catch (Exception e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :gePerformChar "+e);
		}
		return mapCharDetails;
	}
	/**
	 * Method Name 			: getCharacteristicsDetails
	 * Method Description 	: Getting the Characteristics Details of the Part
	 * @param context
	 * @param MapList
	 * @return Map
	 */
	public Map<String, String> getCharacteristicsDetails(Context context, MapList appCharList, Map<String, String> mapCharDetails, Map<String, StringList> mpDimensionDisplayVals, Map mpUnits) {
		try {
			StringBuilder sbChg = new StringBuilder();
			StringBuilder sbCategory = new StringBuilder();
			StringBuilder sbSeqOrder = new StringBuilder();
			StringBuilder sbCatSpec = new StringBuilder();
			StringBuilder sbChar = new StringBuilder();
			StringBuilder sbCharSpec = new StringBuilder();
			StringBuilder sbDesignSpec  = new StringBuilder();
			StringBuilder sbTMName = new StringBuilder();
			StringBuilder sbTMType = new StringBuilder();
			StringBuilder sbTMID = new StringBuilder();
			StringBuilder sbTMLogic = new StringBuilder();
			StringBuilder sbMethodNumber = new StringBuilder();
			StringBuilder sbMethodOrigin = new StringBuilder();
			StringBuilder sbMethodSpecific = new StringBuilder();
			StringBuilder sbTMRDN = new StringBuilder();
			StringBuilder sbTMRDID = new StringBuilder();
			StringBuilder sbTMRDType = new StringBuilder();
			StringBuilder sbSampling = new StringBuilder();
			StringBuilder sbSubGroup = new StringBuilder();
			StringBuilder sbPlantTesting = new StringBuilder();
			StringBuilder sbPlantRetesting = new StringBuilder();
			StringBuilder sbTestingUOM = new StringBuilder();
			StringBuilder sbDimension = new StringBuilder();
			StringBuilder sbLowerSpecLimit = new StringBuilder();
			StringBuilder sbLowerRoutineReleaseLimit = new StringBuilder();
			StringBuilder sbLowerTarget = new StringBuilder();
			StringBuilder sbTarget = new StringBuilder();
			StringBuilder sbUpperTarget = new StringBuilder();
			StringBuilder sbUpperRoutineRL = new StringBuilder();
			StringBuilder sbUpperSpecLimit = new StringBuilder();
			StringBuilder sbUnitOfMeasure = new StringBuilder();
			StringBuilder sbReportNear = new StringBuilder();
			StringBuilder sbReportType = new StringBuilder();
			StringBuilder sbReleseCriteria = new StringBuilder();
			StringBuilder sbACtionRequired = new StringBuilder();
			StringBuilder sbCriticalFactor = new StringBuilder();
			StringBuilder sbBasis = new StringBuilder();
			StringBuilder sbTestGroup = new StringBuilder();
			StringBuilder sbNotes = new StringBuilder();
			StringBuilder sbDesc = new StringBuilder();
			StringBuilder sbApplication = new StringBuilder();
			StringBuilder sbCMT = new StringBuilder();
			StringBuilder sbCMR= new StringBuilder();
			StringBuilder sbCMN = new StringBuilder();
			StringBuilder sbCMType= new StringBuilder();
			StringBuilder sbCMId = new StringBuilder();
			StringBuilder sbCrit = new StringBuilder();
			
			Map<String,Object> mapCriteriaDetails = new HashMap<>();
		for(int j = 0 ; j < appCharList.size(); j++) { 
			Map  mpCharData = (Map)appCharList.get(j);
			filterCriteriaPhysicalIds(context, mpCharData, mapCriteriaDetails);
			//SPEC: <16.08.2022>: Guna Added for Defect 50049 22x Release  -- START
			StringList slTMID =strValidator.getStringListEquivalentForString(mpCharData.get(ConstantsUtilIRM.SELECT_TM_ID));
			StringList slTMName = strValidator.getStringListEquivalentForString(mpCharData.get(ConstantsUtilIRM.SELECT_TM_NAME));
			StringList slTMType = strValidator.getStringListEquivalentForString(mpCharData.get(ConstantsUtilIRM.SELECT_TM_TYPE));
			Map finalMap =checkAccessToTM(context, slTMID, slTMName, slTMType);
			
			util.formatData(sbTMName, strValidator.getStringEquivalentForSubstituteString(finalMap.get(ConstantsUtil.TMFILNAME)));
			util.formatData(sbTMType, strValidator.getStringEquivalentForSubstituteString(finalMap.get(ConstantsUtil.TMFILTYPE)));
			util.formatData(sbTMID, strValidator.getStringEquivalentForSubstituteString(finalMap.get(ConstantsUtil.TMFILID)));
			
					
			StringList slTMRDID =strValidator.getStringListEquivalentForString(mpCharData.get(ConstantsUtilIRM.SELECT_TMRD_ID));
			StringList slTMRDName = strValidator.getStringListEquivalentForString(mpCharData.get(ConstantsUtilIRM.SELECT_TMRD_NAME));
			StringList slTMRDType = strValidator.getStringListEquivalentForString(mpCharData.get(ConstantsUtilIRM.SELECT_TMRD_TYPE));
            Map finalMaps =checkAccessToTM(context, slTMRDID, slTMRDName, slTMRDType);
			
			util.formatData(sbTMRDN, strValidator.getStringEquivalentForSubstituteString(finalMaps.get(ConstantsUtil.TMFILNAME)));
			util.formatData(sbTMRDType, strValidator.getStringEquivalentForSubstituteString(finalMaps.get(ConstantsUtil.TMFILTYPE)));
			util.formatData(sbTMRDID, strValidator.getStringEquivalentForSubstituteString(finalMaps.get(ConstantsUtil.TMFILID)));
			
			//SPEC: <18.08.2022>: Guna Added for Defect 50051 22x Release  -- END
			util.formatData(sbChg, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGCHANGE));
			util.formatData(sbCategory, (String)mpCharData.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PG_CHARACTERISTIC_CATEGORY));
			util.formatData(sbSeqOrder, (String)mpCharData.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SEQUENCE_ORDER));
			util.formatData(sbCatSpec, (String)mpCharData.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CATEGORYSPECIFICS));
			//SPEC: <14.07.2022>: Guna Modified for Req 33205 22x Release  -- START
			util.formatData(sbChar, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_TITLE));
			//SPEC: <14.07.2022>: Guna Modified for Req 33205 22x Release  -- END
			util.formatData(sbCharSpec, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS));
			util.formatData(sbDesignSpec, (String)mpCharData.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_DESIGNSPECIFICS));
			util.formatData(sbTMLogic, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGTMLOGIC));
			util.formatData(sbMethodOrigin, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGMETHODORIGIN));
			util.formatData(sbMethodNumber, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGMETHODNUMBER));
			util.formatData(sbMethodSpecific, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGMETHODSPECIFICS));
			util.formatData(sbSampling, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAMPLING));
			util.formatData(sbSubGroup, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGSUBGROUP));
			util.formatData(sbPlantTesting, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGPLANTTESTING));
			util.formatData(sbPlantRetesting, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING));
			util.formatData(sbTestingUOM, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGRETESTINGUOM));
			StringList slInterface = (StringList)mpCharData.get(ConstantsUtilIRM.INTERFACE);
			String strDim =identifyDimensionUsingInterface(slInterface,mpDimensionDisplayVals);
			util.formatData(sbDimension, strDim);
			String strUom = (String)mpCharData.get(ConstantsUtilIRM.SELECT_OBSCURE_UNIT_OF_MEASURE);
			//SPEC: <17.08.2022>: Guna Modified for Defect 50094 22x Release  -- START
			if(strUom.isEmpty() && !strDim.equals(ConstantsUtil.STRING)) {
				strUom = (String)mpCharData.get(ConstantsUtilIRM.SELECT_UNIT_OF_MEASURE);
			}
			//SPEC: <17.08.2022>: Guna Modified for Defect 50094 22x Release  -- END
			util.formatData(sbUnitOfMeasure, strUom);
			util.formatData(sbReportNear, (String)mpCharData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST));
			util.formatData(sbReportType, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGREPORTTYPE));
			util.formatData(sbReleseCriteria, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGRELEASECRITERIA));
			util.formatData(sbACtionRequired, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGACTIONREQUIRED));
			util.formatData(sbCriticalFactor, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR));
			util.formatData(sbBasis, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASIS));
			util.formatData(sbTestGroup, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGTESTGROUP));
			util.formatData(sbNotes, (String)mpCharData.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARNOTES));
			util.formatData(sbDesc, (String)mpCharData.get(ConstantsUtil.DESCRIPTION));
			util.formatData(sbApplication, (String)mpCharData.get(pgV3Constants.SELECT_ATTRIBUTE_PGAPPLICATION));
			util.formatData(sbCMT, (String)mpCharData.get(ConstantsUtilIRM.SELECT_CHAR_MASTER_TITLE));
			util.formatData(sbCMN, (String)mpCharData.get(ConstantsUtilIRM.SELECT_CHAR_MASTER_NAME));
			util.formatData(sbCMR, (String)mpCharData.get(ConstantsUtilIRM.SELECT_CHAR_MASTER_REVISION));
			util.formatData(sbCMType, (String)mpCharData.get(ConstantsUtilIRM.SELECT_CHAR_MASTER_TYPE));
			String cmState =(String)mpCharData.get(ConstantsUtilIRM.SELECT_CHAR_MASTER_CURRENT);
			String cmId =(String)mpCharData.get(ConstantsUtilIRM.SELECT_CHAR_MASTER);
			if(!cmState.equals(ConstantsUtil.RELEASE) && !cmState.equals(ConstantsUtil.RELEASED)) {
				cmId = ConstantsUtil.EMPTY_STRING;
			}
			util.formatData(sbCMId, cmId);
			StringList critList =strValidator.getStringListEquivalentForString(mpCharData.get(ConstantsUtilIRM.SELECT_CRITERIA));
			util.formatData(sbCrit, strValidator.getStringEquivalentForSubstituteString(getCriteriaName(context, critList)));
			
			

            String strLowerSpecLimit = (String)mpCharData.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHALOWERSPECIFICATIONLIMIT);
           
            String strUpperSpecLimit = (String)mpCharData.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHAUPPERSPECIFICATIONLIMIT);
            String strLowerRoutineLimit = (String)mpCharData.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHALOWERROUTINERELEASELIMIT);
            String strUpperRoutineLimit = (String)mpCharData.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHAUPPERROUTINERELEASELIMIT);
            
            if(!strDim.equals(ConstantsUtil.STRING) && !strDim.equals(ConstantsUtilIRM.CONST_BOOLEAN)) {
            Map mpDynamic =getTargetValues(context,(String)mpCharData.get(DomainConstants.SELECT_ID),strDim);
            if(!strDim.equalsIgnoreCase(ConstantsUtil.INTEGER) && !strDim.equalsIgnoreCase(ConstantsUtilIRM.CONST_REAL)) {
				strDim =strDim.toUpperCase();
			}
            String strMax =(new StringBuilder()).append("attribute[").append(strDim).append("MaxValue]").toString();
            String strMin =(new StringBuilder()).append("attribute[").append(strDim).append("MinValue]").toString();
            String strParam =(new StringBuilder()).append("attribute[").append(strDim).append("ParameterValue]").toString();
            if(!strDim.equalsIgnoreCase(ConstantsUtilIRM.CONST_REAL)) {
            String strMaxValue =convertBasedOnUOM(mpUnits,(String)mpDynamic.get(strMax),strUom,strDim);
            String strMinValue =convertBasedOnUOM(mpUnits,(String)mpDynamic.get(strMin),strUom,strDim);
            String strParamValue =convertBasedOnUOM(mpUnits,(String)mpDynamic.get(strParam),strUom,strDim);
            
            util.formatData(sbLowerTarget, strMinValue);
			util.formatData(sbTarget, strParamValue);
			util.formatData(sbUpperTarget, strMaxValue);
            }else {
            	 util.formatData(sbLowerTarget, (String)mpDynamic.get(strMin));
     			util.formatData(sbTarget, (String)mpDynamic.get(strParam));
     			util.formatData(sbUpperTarget, (String)mpDynamic.get(strMax));
            }
            }else {
            	util.formatData(sbLowerTarget, ConstantsUtil.EMPTY_STRING);
    			util.formatData(sbTarget, ConstantsUtil.EMPTY_STRING);
    			util.formatData(sbUpperTarget, ConstantsUtil.EMPTY_STRING);
            }
            if(!strDim.equals(ConstantsUtil.STRING) && !strDim.equals(ConstantsUtilIRM.CONST_REAL) && !strDim.equalsIgnoreCase(ConstantsUtil.INTEGER)) {
				strLowerSpecLimit =convertBasedOnUOMforLimit(mpUnits,strLowerSpecLimit,strUom,strDim);
				strUpperSpecLimit =convertBasedOnUOMforLimit(mpUnits,strUpperSpecLimit,strUom,strDim);
				strLowerRoutineLimit =convertBasedOnUOMforLimit(mpUnits,strLowerRoutineLimit,strUom,strDim);
				strUpperRoutineLimit =convertBasedOnUOMforLimit(mpUnits,strUpperRoutineLimit,strUom,strDim);
			}
			util.formatData(sbLowerSpecLimit,strLowerSpecLimit);
			util.formatData(sbUpperSpecLimit,strUpperSpecLimit);
			util.formatData(sbLowerRoutineReleaseLimit,strLowerRoutineLimit);
			util.formatData(sbUpperRoutineRL, strUpperRoutineLimit);
			
		}
		mapCharDetails.put(ConstantsUtil.CHG, sbChg.toString());
		mapCharDetails.put(ConstantsUtil.CATEGORY, sbCategory.toString());
		mapCharDetails.put(ConstantsUtilIRM.SEQUENCEORDER, sbSeqOrder.toString());
		mapCharDetails.put(ConstantsUtilIRM.CATEGORYSPECIFICS, sbCatSpec.toString());
		mapCharDetails.put(ConstantsUtil.CHARACTERISTICSPECIFICS, sbCharSpec.toString());
		mapCharDetails.put(ConstantsUtil.CHARACTERISTIC, sbChar.toString());
		mapCharDetails.put(ConstantsUtilIRM.DESIGNSPECIFICS, sbDesignSpec.toString());
		mapCharDetails.put(ConstantsUtil.REF, sbTMRDN.toString());
		mapCharDetails.put(ConstantsUtil.REFID, sbTMRDID.toString());
		mapCharDetails.put(ConstantsUtil.REFTYPE, sbTMRDType.toString());
		mapCharDetails.put(ConstantsUtil.TMTYPE, sbTMType.toString());
		mapCharDetails.put(ConstantsUtil.TESTMETHODNAME, sbTMName.toString());
		mapCharDetails.put(ConstantsUtil.TESTMETHODNAMEID, sbTMID.toString());
		mapCharDetails.put(ConstantsUtil.TML, sbTMLogic.toString());
		mapCharDetails.put(ConstantsUtil.ORIGIN, sbMethodOrigin.toString());
		mapCharDetails.put(ConstantsUtil.TM, sbMethodNumber.toString());
		mapCharDetails.put(ConstantsUtil.SP, sbMethodSpecific.toString());
		mapCharDetails.put(ConstantsUtil.SAMPLINGSM, sbSampling.toString());
		mapCharDetails.put(ConstantsUtilIRM.SUBGROUP, sbSubGroup.toString());
		mapCharDetails.put(ConstantsUtilIRM.STR_CHAR_DIMENSION, sbDimension.toString());
		mapCharDetails.put(ConstantsUtil.PLANTTESTING, sbPlantTesting.toString());
		mapCharDetails.put(ConstantsUtil.RT, sbPlantRetesting.toString());
		mapCharDetails.put(ConstantsUtil.UOM, sbTestingUOM.toString());
		mapCharDetails.put(ConstantsUtil.LOWERSPECLIMIT, sbLowerSpecLimit.toString());
		mapCharDetails.put(ConstantsUtil.LRRL, sbLowerRoutineReleaseLimit.toString());
		mapCharDetails.put(ConstantsUtil.LTGT, sbLowerTarget.toString());
		mapCharDetails.put(ConstantsUtil.TGT, sbTarget.toString());
		mapCharDetails.put(ConstantsUtil.UTGT, sbUpperTarget.toString());
		mapCharDetails.put(ConstantsUtil.URRL, sbUpperRoutineRL.toString());
		mapCharDetails.put(ConstantsUtil.USL, sbUpperSpecLimit.toString());
		mapCharDetails.put(ConstantsUtil.UNITOFMEASURE, sbUnitOfMeasure.toString());
		mapCharDetails.put(ConstantsUtil.RTN, sbReportNear.toString());
		mapCharDetails.put(ConstantsUtil.RTT, sbReportType.toString());
		mapCharDetails.put(ConstantsUtil.RELEASECRITERIA, sbReleseCriteria.toString());
		mapCharDetails.put(ConstantsUtil.ACTIONREQUIRED, sbACtionRequired.toString());
		mapCharDetails.put(ConstantsUtil.CAPSCR, sbCriticalFactor.toString());
		mapCharDetails.put(ConstantsUtil.BA, sbBasis.toString());
		mapCharDetails.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
		mapCharDetails.put(ConstantsUtil.NOTES, sbNotes.toString());
		mapCharDetails.put(ConstantsUtilIRM.CHARMASTERTITLE, sbCMT.toString());
		mapCharDetails.put(ConstantsUtilIRM.CHARMASTERTYPE, sbCMType.toString());
		mapCharDetails.put(ConstantsUtilIRM.CHARMASTERNAME, sbCMN.toString());
		mapCharDetails.put(ConstantsUtilIRM.CHARMASTERID, sbCMId.toString());
		mapCharDetails.put(ConstantsUtilIRM.CRITERIA, sbCrit.toString());
		mapCharDetails.put(ConstantsUtil.TESTGROUP, sbTestGroup.toString());
		mapCharDetails.put(ConstantsUtil.AP, sbApplication.toString());
		mapCharDetails.put(ConstantsUtilIRM.CHARMASTERREVISION, sbCMR.toString());
		}catch (Exception e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :getCharacteristicsDetails "+e);
		}
		return mapCharDetails;
	}
	/**
	 * Method Name 			: checkAccessToTM
	 * Method Description 	: Checking access for TMs and TMRDNs
	 * @param context
	 * @param StringList
	 * @return StringList
	 */
	public Map checkAccessToTM(Context context, StringList slTMID, StringList slTMName, StringList slTMType) {
		StringList rtnTMList =new StringList();
		StringList rtnTMNameList =new StringList();
		StringList rtnTMTypeList =new StringList();
		//SPEC: <18.08.2022>: Guna Modified for Defect 50051 22x Release  -- START
		Map rtnMap =new HashMap<>();
		try {
			String sUserType = util.getUserType();
			if(!slTMID.isEmpty()) {
				for(int r=0;r<slTMID.size();r++) {
					Boolean showData = util.checkHasAccess(context, sUserType, slTMID.get(r));
					Boolean strTempCurrentIsRelease = util.checkIfReleased(context, slTMID.get(r));
					if (Boolean.TRUE.equals(showData) && strTempCurrentIsRelease) {
					    rtnTMList.add(slTMID.get(r));
					    rtnTMNameList.add(slTMName.get(r));
					    rtnTMTypeList.add(slTMType.get(r));
					} else {
						if(util.isModificatinRequired()) {
							continue;
						}else {
							rtnTMList.add(ConstantsUtil.NO_ACCESS);
							rtnTMNameList.add(slTMName.get(r));
							rtnTMTypeList.add(slTMType.get(r));
						}
					}
				}
				rtnMap.put(ConstantsUtil.TMFILNAME, rtnTMNameList);
				rtnMap.put(ConstantsUtil.TMFILID, rtnTMList);
				rtnMap.put(ConstantsUtil.TMFILTYPE, rtnTMTypeList);
				
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :checkAccessToTM "+e);
		}
		//SPEC: <18.08.2022>: Guna Modified for Defect 50051 22x Release  -- END
		return rtnMap;
	}

	/**
	 * Method Name 			: getCriteriaName
	 * Method Description 	: Getting Criteria Title.
	 * @param context
	 * @param StringList
	 * @return StringList
	 */
	public StringList getCriteriaName(Context context, StringList critList) {
		StringList rtnCritList =new StringList();
		try{
		MapList mapList = DomainObject.getInfo(context, critList.<String>toArray(new String[0]), new StringList(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
		if(!mapList.isEmpty()) {
			for(int ict=0;ict<mapList.size();ict++) {
				Map crtMap =(Map)mapList.get(ict);
				rtnCritList.add((String)crtMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
			}
		}
		}catch (Exception e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :getCriteriaName "+e);
		}
		return rtnCritList;
	}
	/**
	 * Method Name 			: getCriteriaName
	 * Method Description 	: Getting Dimensions based on Interface.
	 * @param context
	 * @param Map
	 * @return String
	 */
	public  String identifyDimensionUsingInterface(StringList slInterfaceList, Map<String, StringList> mpDimensionDisplayVals) {
		String sReturnDimension = DomainConstants.EMPTY_STRING;
		try {
	  	Map mpDimensionNames;
	  	if(mpDimensionDisplayVals.size() > 0 ) {
	  		mpDimensionNames = prepareMapForName(mpDimensionDisplayVals);
	  		if(!mpDimensionNames.isEmpty()) {
		  		String sValue;
			  	for(int i = 0 ; i < slInterfaceList.size(); i++) {
			  		sValue = slInterfaceList.get(i);
			  		if(UIUtil.isNotNullAndNotEmpty(sValue) && mpDimensionNames.containsKey(sValue)) {
			  			sReturnDimension = (String) mpDimensionNames.get(sValue);
			  			break;
			  		}
			  	}
		  	}
	  	}
		}catch (Exception e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :identifyDimensionUsingInterface "+e);
		}
		return sReturnDimension;
	}
	/**
	 * Method Name 			: prepareMapForName
	 * Method Description 	: Preparing the display names.
	 * @param Map
	 * @return Map
	 */
	public  Map prepareMapForName(Map<String, StringList> mpReturnMap) {
		HashMap<String,String> mpDisplayName = new HashMap<>();
		try {
		StringList slActual = mpReturnMap.get("field_choices");
		StringList slDisplay = mpReturnMap.get("field_display_choices"); 
		for(int i = 0 ; i < slActual.size(); i++ ) {
			mpDisplayName.put(slActual.get(i),slDisplay.get(i) );
		}
		}catch (Exception e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :prepareMapForName "+e);
		}
		return mpDisplayName;
	}
	/**
	 * Method Name 			: prepareMapForName
	 * Method Description 	: Filtering criteria based on physical id.
	 * @param context
	 * @param Map
	 * @return 
	 */
	public void filterCriteriaPhysicalIds(Context context, Map<String, Object> mpCharData,
			Map<String, Object> mapCriteriaDetails)  {
		try{
		StringList slCriteriaPhysicalIdList = new StringList();
		Object objectCriteriaPhysicalIdList;
		Map<String,Object> mapFinalCriteriaInfo = new HashMap<>();
		if(mpCharData.containsKey(ConstantsUtilIRM.SELECT_CRITERIA))
		{
			objectCriteriaPhysicalIdList = mpCharData.get(ConstantsUtilIRM.SELECT_CRITERIA);
			if ((objectCriteriaPhysicalIdList instanceof StringList)) {
				slCriteriaPhysicalIdList = (StringList)objectCriteriaPhysicalIdList;
			}				
		}
		StringList slCriteriaPhysicalIdToBeFetched = new StringList();
		if(!slCriteriaPhysicalIdList.isEmpty())
		{
			for(String sCriteriaPhysicalId : slCriteriaPhysicalIdList)
			{
				if(!mapCriteriaDetails.containsKey(sCriteriaPhysicalId))
				{
					slCriteriaPhysicalIdToBeFetched.add(sCriteriaPhysicalId);
				}
			}
			if(!slCriteriaPhysicalIdToBeFetched.isEmpty())
			{
				StringList slObjectSelects = new StringList();
				slObjectSelects.add(DomainConstants.SELECT_REVISION);
				slObjectSelects.add(ConstantsUtilIRM.SELECT_LOGICAL_ID);
				slObjectSelects.add(ConstantsUtil.SELECT_PHYSICAL_ID);
				MapList mlCriteriaFetched = DomainObject.getInfo(context, slCriteriaPhysicalIdToBeFetched.toArray(new String[slCriteriaPhysicalIdToBeFetched.size()]), slObjectSelects);
				for(int n = 0; n < mlCriteriaFetched.size(); n++)
				{
					Map<String,Object> mapCriteria = (Map) mlCriteriaFetched.get(n);
					String sObjectPhysicalId = (String) mapCriteria.get(ConstantsUtil.SELECT_PHYSICAL_ID);
					mapCriteriaDetails.put(sObjectPhysicalId, mapCriteria);
				}
			}		
			mapFinalCriteriaInfo =getCriteriaInfo(slCriteriaPhysicalIdList,mapCriteriaDetails,mapFinalCriteriaInfo);
			StringList slLocalCriteriaPhysicalIdList =getCriteria(slCriteriaPhysicalIdList,mapCriteriaDetails,mapFinalCriteriaInfo);
			mpCharData.put(ConstantsUtilIRM.SELECT_CRITERIA, slLocalCriteriaPhysicalIdList);
		}
		}catch (Exception e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :filterCriteriaPhysicalIds "+e);
		}
	}

	public Map<String, Object> getCriteriaInfo(StringList slCriteriaPhysicalIdList, Map<String, Object> mapCriteriaDetails, Map<String, Object> mapFinalCriteriaInfo) {
		try {
		for(String sCriteriaPhysicalId : slCriteriaPhysicalIdList)
		{
			if(mapCriteriaDetails.containsKey(sCriteriaPhysicalId))
			{
				Map<String,Object> mpCriteriaInfo = (Map)mapCriteriaDetails.get(sCriteriaPhysicalId);
				String sObjectLogicalId = (String)mpCriteriaInfo.get(ConstantsUtilIRM.SELECT_LOGICAL_ID);
				MapList mlCriteriaInfo = new MapList();
				if(mapFinalCriteriaInfo.containsKey(sObjectLogicalId))
				{
					mlCriteriaInfo = (MapList)mapFinalCriteriaInfo.get(sObjectLogicalId);
				}
				mlCriteriaInfo.add(mpCriteriaInfo);
				mapFinalCriteriaInfo.put(sObjectLogicalId, mlCriteriaInfo);
			}
		}
	}catch (Exception e) {
		LOGGER.error("Exception in Program : CATIAAPPBO Method :getCriteriaInfo "+e);
	}
		return mapFinalCriteriaInfo;
	}


	public StringList getCriteria(StringList slCriteriaPhysicalIdList, Map<String, Object> mapCriteriaDetails, Map<String, Object> mapFinalCriteriaInfo) {
		StringList rtnCritList =new StringList();
		try {
		for(String sCriteriaPhysicalId : slCriteriaPhysicalIdList)
		{
			Map<String,Object> mapCritInfo = (Map) mapCriteriaDetails.get(sCriteriaPhysicalId);
			String sLogicalId = (String)mapCritInfo.get(ConstantsUtilIRM.SELECT_LOGICAL_ID);
			if(mapFinalCriteriaInfo.containsKey(sLogicalId))
			{
				MapList mlCriteriaInfo = (MapList)mapFinalCriteriaInfo.get(sLogicalId);					
				if(!mlCriteriaInfo.isEmpty())
				{
					mlCriteriaInfo.sort(DomainConstants.SELECT_REVISION, "descending", "integer");
					Map<String,Object> mapLocalCriteriaMap = (Map)mlCriteriaInfo.get(0);
					String sCriteriaLocalPhysicalId = (String)mapLocalCriteriaMap.get(ConstantsUtil.SELECT_PHYSICAL_ID);	
					if(!rtnCritList.contains(sCriteriaLocalPhysicalId))
					{
						rtnCritList.add(sCriteriaLocalPhysicalId);						
					}
				}
			}
		}
		}catch (Exception e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :getCriteria "+e);
		}
		return rtnCritList;
	}

	/**
	 * Method Name 			: getDimensions
	 * Method Description 	: Getting the dimension values.
	 * @param context
	 * @return HashMap
	 */
	public Map<String, StringList> getDimensions(Context context) {
		 Map<Object, Object> hashMap = new HashMap<>();
		 try {
		 StringList stringList1 = getDefaultMagnitude(context);
		    Object[] arrayOfObject = stringList1.toArray();
		    StringList stringList2 = new StringList();
		    StringList stringList3 = new StringList();
		    for (Object object : arrayOfObject) {
		      if (!"COLORParameter".equals(object) && !"SUBJECTIVEParameter".equals(object)) {
		        stringList3.add(getDimensionNLS((String)object));
		      } else {
		        stringList3.add(CharacteristicMasterUtil.getCharacterisitcDimensionNLS(context, (String)object));
		      } 
		      stringList2.add((String)object);
		    } 
		    hashMap.put("field_choices", stringList2);
		    hashMap.put("field_display_choices", stringList3);
		 }catch (Exception e) {
			 LOGGER.error("Exception in Program : CATIAAPPBO Method :getDimensions "+e);
		}
		    return (HashMap)hashMap;
	}

	/**
	 * Method Name 			: getDimensionNLS
	 * Method Description 	: Getting the dimension values from properties file.
	 * @param String
	 * @return String
	 */
	public String getDimensionNLS(String strDim)  {
		String dimRtn =ConstantsUtil.EMPTY_STRING;
		InputStream stream = null;
		try {
		strDim =strDim.replace(ConstantsUtilIRM.PARAMETER_STRING, ConstantsUtil.VALUE_ALT_BOM_TEXT);
		Properties properties = new Properties();
		 stream = CATIAAPPBO.class.getClassLoader().getResourceAsStream("CATIAAPP.properties");
		properties.load(stream);
		if("String".equals(strDim) || "Boolean".equals(strDim) || "Real".equals(strDim) || "Integer".equals(strDim)) {
			String str1 =properties.getProperty("emxFramework.Attribute.Type." + strDim.toLowerCase());
			String str2 = str1.substring(0, 1).toUpperCase();
			 dimRtn = str1.replaceFirst(str1.substring(0, 1), str2);
		}else {
			dimRtn =properties.getProperty("emxFramework.Dimension.DSDim_" + strDim);
		}
		}catch (IOException e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :getDimensionNLS "+e);
		}
		finally {
			try {
		        if (stream != null) {
		        	stream.close();
		        }        
		    } catch (IOException ioe) {
		    	LOGGER.error("Exception in Program : CATIAAPPBO Method :getDimensionNLS "+ioe);
		    }
		}
		return dimRtn;
	}

	public StringList getDefaultMagnitude(Context context) {
		StringList stringList = new StringList();
		try {
	    String[] arrayOfString ;
	    String str = getPreference(context, "preference_DimensionsList");
	    if(str != null && !str.isEmpty()) {
	        arrayOfString = str.split(";");
	          stringList.addAll(arrayOfString); 
	      } else {
	              String str2 = ConstantsUtilIRM.TYPESLIST;
	              arrayOfString = str2.split(",");
	              if (null != arrayOfString) {
	                int i = arrayOfString.length;
	                for (byte b = 0; b < i; b++) {
	                  String str3 = arrayOfString[b];
	                  if (null != str3 && !str3.isEmpty())
	                    stringList.add(str3 + "Parameter"); 
	                } 
	              } 
	              IKweDictionary iKweDictionary = KweInterfacesServices.getKweDictionary();
	              IKweType iKweType = null;
	              String[] arrayOfString1 = "CMYKFormattedStringParameter,HEXFormattedStringParameter,RGBFormattedStringParameter,SubjectivityParameter".split(",");
	              for (String str3 : arrayOfString1) {
	                iKweType = iKweDictionary.findType(context, str3);
	                if (iKweType != null)
	                  stringList.add(iKweType.getNLSName(context)); 
	              } 
	      }
		}catch (Exception e) {
			LOGGER.error("Exception in Program : CATIAAPPBO Method :getDefaultMagnitude "+e);
		}
		return stringList;
	}
	public static String getPreference(Context paramContext, String paramString) throws FrameworkException {
	    return PropertyUtil.getAdminProperty(paramContext, "person", paramContext.getUser(), paramString);
	  }
	//SPEC: <17.05.2022>: Guna Added for Req 33205 22x Release  -- END
	//SPEC: 21/05/2022: Added by Manikanta for 22x DEV Req 42404-- START
	public Map<String, String> getValuesFromXML(Context context,String sObjectId,String container,String connectionString,String azureStore) throws Exception 
			{	

		
				MapList mlFinalList = new MapList();
				StringValidatorUtil validator = new StringValidatorUtil();
				StringBuilder sbParameterSet = new StringBuilder();
				StringBuilder sbRMPname = new StringBuilder();
				StringBuilder sbChg = new StringBuilder();
				StringBuilder sbGroup = new StringBuilder();
				StringBuilder sbDesignParameterValues = new StringBuilder();
				StringBuilder sbMaterialFunction = new StringBuilder();
				StringBuilder sbDesignParameter = new StringBuilder();
				StringBuilder sbLayer = new StringBuilder();
				Map<String, String> mpDesignParameter = new HashMap<>();
				try
				{
					String strPreviousObjectId = DomainConstants.EMPTY_STRING;
					if(UIUtil.isNotNullAndNotEmpty(sObjectId))
					{
						DomainObject domPartObject = DomainObject.newInstance(context,sObjectId);							
						boolean bPreviousAPPRevExists = false;
						BusinessObject boPreviousRevision= domPartObject.getPreviousRevision(context);
						if(null!=boPreviousRevision && boPreviousRevision.exists(context))
						{
							bPreviousAPPRevExists = true;
							strPreviousObjectId = boPreviousRevision.getObjectId(context);
						}
						Map mapXMLParameter = ReadWriteXMLForPLMDTDocument.getConfigXMLParameters(context, sObjectId, true, true,container,connectionString,azureStore);
						mlFinalList = getMapListForDesignParameterView(mapXMLParameter);
						if(bPreviousAPPRevExists)
						{
							mlFinalList = updateDesignParameterListForChange(context, strPreviousObjectId, mlFinalList,container,connectionString,azureStore);
						}
						mlFinalList.sort(ConstantsUtilIRM.UNIQUEKEY, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
						for (int i = 0; i < mlFinalList.size(); i++) 
						{
							Map resultMaps = (Map) mlFinalList.get(i);
							String strparameterSet    =  validator.getEquivalentStringComma(resultMaps.get(ConstantsUtilIRM.PARAMETERSET));
							String strRMPname    =  validator.getEquivalentStringComma(resultMaps.get(ConstantsUtilIRM.RMPNAME));
							String strChg    =  validator.getEquivalentStringComma(resultMaps.get(ConstantsUtilIRM.CHG));
							String strGroup   =  validator.getEquivalentStringComma(resultMaps.get(ConstantsUtilIRM.GROUP));
							String strDesignParameterValues    =  validator.getEquivalentStringComma(resultMaps.get(ConstantsUtilIRM.DESIGN_PARAMETER_VALUES));
							String strMaterialFunction    =  validator.getEquivalentStringComma(resultMaps.get(ConstantsUtilIRM.MATERIALFUNCTION));
							String strDesignParameter    =  validator.getEquivalentStringComma(resultMaps.get(ConstantsUtilIRM.DESIGN_PARAMETER));
							String strLayer    =  validator.getEquivalentStringComma(resultMaps.get(ConstantsUtilIRM.KEY_LAYER));
							
							util.formatData(sbParameterSet, strparameterSet);
							util.formatData(sbRMPname, strRMPname);
							util.formatData(sbChg, strChg);
							util.formatData(sbGroup, strGroup);
							util.formatData(sbDesignParameterValues, strDesignParameterValues);
							util.formatData(sbMaterialFunction, strMaterialFunction);
							util.formatData(sbDesignParameter, strDesignParameter);
							util.formatData(sbLayer, strLayer);
						}
						mpDesignParameter.put(ConstantsUtilIRM.PARAMETERSET, sbParameterSet.toString());			
						mpDesignParameter.put(ConstantsUtilIRM.RMPNAME, sbRMPname.toString());
						mpDesignParameter.put(ConstantsUtil.CHG, sbChg.toString());
						mpDesignParameter.put(ConstantsUtilIRM.GROUP, sbGroup.toString());
						mpDesignParameter.put(ConstantsUtilIRM.DESIGNPARAMETERVALUES, sbDesignParameterValues.toString());			
						mpDesignParameter.put(ConstantsUtil.MATERIALFUNCTION, sbMaterialFunction.toString());
						mpDesignParameter.put(ConstantsUtilIRM.DESIGNPARAMETER, sbDesignParameter.toString());
						mpDesignParameter.put(ConstantsUtil.LAYER, sbLayer.toString());
					}
				}
				catch(Exception ex)
				{
					LOGGER.error(ex.getMessage(), ex);
				}
				return mpDesignParameter;
			}
			
			@SuppressWarnings("unchecked")
			private MapList getMapListForDesignParameterView(Map mapXMLParameter) {
				MapList mlFinalList = new MapList();		
				if(null != mapXMLParameter && mapXMLParameter.containsKey(ConstantsUtilIRM.STR_PRODUCT_DEFINITION))
				{
					Map mapBaseAPPParameter = (Map)mapXMLParameter.get(ConstantsUtilIRM.STR_PRODUCT_DEFINITION);		  
					Iterator entries1 = mapBaseAPPParameter.entrySet().iterator();

					Map<String, String> mpRawMaterial = new HashMap<>();
					Map<String, String> mpMaterialFunc = new HashMap<>();
					Map<String, String> mpParam;
					String strRMPName;
					String strMaterialFunction;
					String key;
					String strDesignParam;
					String strGrpLayer;
					StringBuilder sbGrpLayer;				
					StringList slParamDetails;

					Map.Entry entry = null;
					while (entries1.hasNext()) 
					{
						entry = (Map.Entry) entries1.next();
						key = entry.getKey().toString();
						slParamDetails = FrameworkUtil.split(key, ConstantsUtil.SYMBL_DOT);
						if(slParamDetails.size() == 1 ) 
						{
							continue;
						}
						strDesignParam = slParamDetails.get(3);
						sbGrpLayer = new StringBuilder();
						strGrpLayer =sbGrpLayer.append(slParamDetails.get(0)).append(ConstantsUtil.SYMBL_DOT).append(slParamDetails.get(1)).toString();

						if(strDesignParam.equals(ConstantsUtilIRM.STR_RMP) && !mpRawMaterial.containsKey(strGrpLayer))
						{
							mpRawMaterial.put(strGrpLayer,entry.getValue().toString());
						}
						if(strDesignParam.equals(ConstantsUtilIRM.MATERIALFUNCTION) && !mpMaterialFunc.containsKey(strGrpLayer))
						{
							mpMaterialFunc.put(strGrpLayer,entry.getValue().toString());
						}
					}

					Iterator entries = mapBaseAPPParameter.entrySet().iterator();
					while (entries.hasNext()) 
					{
						entry = (Map.Entry) entries.next();
						key = entry.getKey().toString();
						slParamDetails = FrameworkUtil.split(key, ConstantsUtil.SYMBL_DOT);
						mpParam = new HashMap<>();

						if(slParamDetails.size() == 1)
						{

							mpParam.put(ConstantsUtilIRM.GROUP,ConstantsUtil.SYMBL_DASH);
							mpParam.put(ConstantsUtilIRM.KEY_LAYER,ConstantsUtil.SYMBL_DASH);				
							mpParam.put(ConstantsUtilIRM.PARAMETERSET,ConstantsUtil.SYMBL_DASH);
							mpParam.put(ConstantsUtilIRM.DESIGN_PARAMETER,slParamDetails.get(0));
							mpParam.put(ConstantsUtilIRM.DESIGN_PARAMETER_VALUES,entry.getValue().toString());
							mpParam.put(ConstantsUtilIRM.RMPNAME, ConstantsUtil.SYMBL_DASH);				
							mpParam.put(ConstantsUtilIRM.MATERIALFUNCTION,ConstantsUtil.SYMBL_DASH);

						}
						else
						{

							strDesignParam = slParamDetails.get(3);
							sbGrpLayer = new StringBuilder();
							strGrpLayer = sbGrpLayer.append(slParamDetails.get(0)).append(ConstantsUtil.SYMBL_DOT).append(slParamDetails.get(1)).toString();
							mpParam.put(ConstantsUtilIRM.GROUP,slParamDetails.get(0));
							mpParam.put(ConstantsUtilIRM.KEY_LAYER,slParamDetails.get(1));				
							mpParam.put(ConstantsUtilIRM.PARAMETERSET,slParamDetails.get(2));
							mpParam.put(ConstantsUtilIRM.DESIGN_PARAMETER,slParamDetails.get(3));
							mpParam.put(ConstantsUtilIRM.DESIGN_PARAMETER_VALUES,entry.getValue().toString());
							strRMPName = DomainConstants.EMPTY_STRING;
							strMaterialFunction = DomainConstants.EMPTY_STRING;
							if(mpRawMaterial.containsKey(strGrpLayer))
							{
								strRMPName = (String)mpRawMaterial.get(strGrpLayer);
							}
							if(mpMaterialFunc.containsKey(strGrpLayer))
							{
								strMaterialFunction = (String)mpMaterialFunc.get(strGrpLayer);
							}
							mpParam.put(ConstantsUtilIRM.RMPNAME, strRMPName);				
							mpParam.put(ConstantsUtilIRM.MATERIALFUNCTION,strMaterialFunction);			
						}
						mpParam.put(ConstantsUtilIRM.CHG, DomainConstants.EMPTY_STRING);			
						mpParam = updateDesignParameterMap(mpParam);						
						mlFinalList.add(mpParam);			
					}
				}
				return mlFinalList;
			}	
			
			/**
			 * Method to update Design Parameter Map
			 * @param mpParam
			 * @return
			 */
			private Map<String, String> updateDesignParameterMap(Map<String, String> mpParam) {
				StringBuilder sbUniqueKey;			
				if(null!=mpParam && !mpParam.isEmpty())
				{
					sbUniqueKey = new StringBuilder();
					sbUniqueKey.append((String)mpParam.get(ConstantsUtilIRM.GROUP));
					sbUniqueKey.append(ConstantsUtil.SYMBL_PIPE);
					sbUniqueKey.append((String)mpParam.get(ConstantsUtilIRM.KEY_LAYER));
					sbUniqueKey.append(ConstantsUtil.SYMBL_PIPE);
					sbUniqueKey.append((String)mpParam.get(ConstantsUtilIRM.PARAMETERSET));
					sbUniqueKey.append(ConstantsUtil.SYMBL_PIPE);
					sbUniqueKey.append((String)mpParam.get(ConstantsUtilIRM.DESIGN_PARAMETER));			
					mpParam.put(ConstantsUtilIRM.UNIQUEKEY, sbUniqueKey.toString());
				}		
				return mpParam;
			}
			
			private MapList updateDesignParameterListForChange(Context context, String strPreviousObjectId, MapList mlFinalList,String container,String connectionString,String azureStore) throws Exception {
				
				MapList mlPreviousPartFinalList = new MapList();
				Map<String, String> mapPreviousXMLParameter;
				if(UIUtil.isNotNullAndNotEmpty(strPreviousObjectId))
				{
					mapPreviousXMLParameter = ReadWriteXMLForPLMDTDocument.getConfigXMLParameters(context, strPreviousObjectId, true, true,container,connectionString,azureStore);
					mlPreviousPartFinalList = getMapListForDesignParameterView(mapPreviousXMLParameter);
				}
				if(null!=mlPreviousPartFinalList && !mlPreviousPartFinalList.isEmpty())
				{
					Map<String, String> mapDesignParameter;
					Map<String, String> mapPreviousDesignParameter;
					Iterator itr = mlFinalList.iterator();
					String strUniqueKey;
					String strPreviousUniqueKey;
					String strParameterValue;
					String strPreviousParameterValue;
					boolean isParameterFound = false;
					boolean isValueMatch = false;

					while(itr.hasNext())
					{
						mapDesignParameter = (Map)itr.next();
						if(mapDesignParameter.containsKey(ConstantsUtilIRM.UNIQUEKEY))
						{
							isParameterFound = false;
							isValueMatch = false;
							strUniqueKey = (String)mapDesignParameter.get(ConstantsUtilIRM.UNIQUEKEY);
							strParameterValue = (String)mapDesignParameter.get(ConstantsUtilIRM.DESIGN_PARAMETER_VALUES);					
							for(int i=0;i<mlPreviousPartFinalList.size();i++) 
							{	
								mapPreviousDesignParameter = (Map)mlPreviousPartFinalList.get(i);
								if(mapPreviousDesignParameter.containsKey(ConstantsUtilIRM.UNIQUEKEY))
								{
									strPreviousUniqueKey = (String)mapPreviousDesignParameter.get(ConstantsUtilIRM.UNIQUEKEY);
									if(strUniqueKey.equalsIgnoreCase(strPreviousUniqueKey))
									{
										isParameterFound = true;
										strPreviousParameterValue = (String)mapPreviousDesignParameter.get(ConstantsUtilIRM.DESIGN_PARAMETER_VALUES);
										if(strParameterValue.equalsIgnoreCase(strPreviousParameterValue))
										{
											isValueMatch = true;
										}								
									}
								}						
							}
							if(!isValueMatch && isParameterFound)
							{
								mapDesignParameter.put(ConstantsUtilIRM.CHG, ConstantsUtilIRM.RANGE_VALUE_CHG_C);
							}
							else if(!isParameterFound)
							{
								mapDesignParameter.put(ConstantsUtilIRM.CHG, ConstantsUtilIRM.RANGE_VALUE_CHG_CPLUS);
							}
						}
						
					}
				}
				return mlFinalList;
			}
		//SPEC: 21/05/2022: Added by Manikanta for 22x DEV Req 42404-- END
			private Map getCKEUnits() {
				Map rtnMap =new HashMap();
				InputStream file = CATIAAPPBO.class.getClassLoader().getResourceAsStream("CATCkeUnits.dim");
				try ( BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(file))){
				String str2 = null;
				while ((str2 = bufferedReader.readLine()) != null) {
			        str2 = str2.replace('\t', ' ');
			        str2 = str2.trim();
			         if (str2.startsWith("symbol=")) {
			            str2 = str2.substring(7);
			            str2 = str2.replace('\'', ' ');
			            String strFact =bufferedReader.readLine();
			            strFact =strFact.trim();
			            String strFormula =ConstantsUtil.EMPTY_STRING;
			            if(UIUtil.isNotNullAndNotEmpty(strFact.trim()) && strFact.startsWith("factor=")) {
			            		 strFormula = strFact.substring(7);
			            }
			            rtnMap.put(str2, strFormula);
			          } 
				}
				}
				catch (FileNotFoundException f) {
					LOGGER.error("FileNotFoundException in Program : CATIAAPPBO Method :getCKEUnits "+f);
				}catch (IOException e) {
					LOGGER.error("IOException in Program : CATIAAPPBO Method :getCKEUnits "+e);
				}
				finally {
			        if (file != null) {
			            try {
			            	file.close();
			            } catch (IOException e) {
			            	LOGGER.error("IOException in Program : CATIAAPPBO Method :getCKEUnits "+e);
			            }
			        }
				}
				return rtnMap;
			}
			private Map getTargetValues(Context context, String strObj, String strDim) {
				Map mpRtn =new HashMap();
				try {
					if(!strDim.equalsIgnoreCase(ConstantsUtil.INTEGER) && !strDim.equalsIgnoreCase(ConstantsUtilIRM.CONST_REAL)) {
						strDim =strDim.toUpperCase();
					}
					StringList objSelect =new StringList(3);
					objSelect.add((new StringBuilder()).append("attribute["+PropertyUtil.getSchemaProperty(null,"attribute_")).append(strDim).append("MaxValue]").toString());
					objSelect.add((new StringBuilder()).append("attribute["+PropertyUtil.getSchemaProperty(null,"attribute_")).append(strDim).append("MinValue]").toString());
					objSelect.add((new StringBuilder()).append("attribute["+PropertyUtil.getSchemaProperty(null,"attribute_")).append(strDim).append("ParameterValue]").toString());
					DomainObject domPar =DomainObject.newInstance(context, strObj);
					mpRtn =domPar.getInfo(context, objSelect);
				} catch (Exception e) {
					LOGGER.error("Exception in Program : CATIAAPPBO Method :getTargetValues "+e);
				}
				return mpRtn;
			}

			private String convertBasedOnUOM(Map mpUnits, String strLowerSpecLimit, String strUom, String strDim) {
				try {
					DecimalFormat dfZero = null;
					if(strDim.equalsIgnoreCase(ConstantsUtilIRM.MASS)) {
						dfZero = new DecimalFormat(ConstantsUtilIRM.DECIMAL_ZERO);
					} else {
						dfZero = new DecimalFormat(ConstantsUtil.ZERO_SIZE);
					}
					if(UIUtil.isNotNullAndNotEmpty(strLowerSpecLimit)) {
						double d=Double.parseDouble(strLowerSpecLimit);
						if(mpUnits.containsKey(strUom)) {
							String strFactor =(String) mpUnits.get(strUom);
							if(UIUtil.isNotNullAndNotEmpty(strFactor)) {
								double dfac=Double.parseDouble(strFactor);
								return String.valueOf(dfZero.format(d/dfac));
							}else if("Cdeg".equals(strUom)) {
								return String.valueOf(dfZero.format(d-273.15));
							} 
							else {
								return String.valueOf(d);
							}
						}else {
							return String.valueOf(d);
						}
					}
				} catch (Exception e) {
					LOGGER.error("Exception in Program : CATIAAPPBO Method :convertBasedOnUOM "+e);
				}
				
				return ConstantsUtil.EMPTY_STRING;
			}

			
			private String convertBasedOnUOMforLimit(Map mpUnits, String strLowerSpecLimit, String strUom, String strDim) {
				try {
					DecimalFormat dfZero = new DecimalFormat(ConstantsUtil.ZERO_SIZE);
					if(UIUtil.isNotNullAndNotEmpty(strLowerSpecLimit)) {
						double d=Double.parseDouble(strLowerSpecLimit);
						if(mpUnits.containsKey(strUom)) {
							String strFactor =(String) mpUnits.get(strUom);
							if(UIUtil.isNotNullAndNotEmpty(strFactor)) {
								double dfac=Double.parseDouble(strFactor);
								return String.valueOf(dfZero.format(d/dfac));
							}else if("Cdeg".equals(strUom)) {
								return String.valueOf(dfZero.format(d-273.15));
							} 
							else {
								return String.valueOf(d);
							}
						}else {
							return String.valueOf(d);
						}
					}
				} catch (Exception e) {
					LOGGER.error("Exception in Program : CATIAAPPBO Method :convertBasedOnUOM "+e);
				}

				return ConstantsUtil.EMPTY_STRING;
			}
}
