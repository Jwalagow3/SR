/**
 * Program 		: EnoviaCOPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.ConsumerUnitPartBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaCOPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaCOPServiceImpl implements EnoviaCOPService {


	private static Logger LOGGER = Logger.getLogger(EnoviaCOPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	private  HttpServletRequest request;
	@Autowired
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public HashMap<String, Map<String, String>> getCOPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();

		StopWatch sp = new StopWatch();
		sp.start();
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		try 
		{
			//Log Request ID from service
			getRequestOid();

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			
			LOGGER.info("COP CONTEXT ELAPSED TIME : "+swContext.getTime());
			
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			if(UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BObjutil.getUserView(context, objId);
				}
				//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			}
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bManufacturerView = false;

			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				bManufacturerView = true;
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				bManufacturerView = true;
			} else {
				switch (sUserType) {
				case ConstantsUtil.PG:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PGSTAFF:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PG_CM:
					bManufacturerView = true;
					break;
				}

			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END

			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			ConsumerUnitPartBO CopBO = new ConsumerUnitPartBO();
			DomainObject doCOP =  CopBO.getCopDO(context, objId);
			String strCurrent = doCOP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			//Modified by Ajay for Req No. 125736 -- START
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR IN COP: "+hmAttrib);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;

				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}//Modified by Ajay for Req No. 125736 -- END
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END


			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpPerformChar= new HashMap<String,String>();

			Map<String,String> mpSubstitute = new HashMap<String,String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			Map<String,String> mpWeightResult = new HashMap<String,String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			Map<String,String> mapCountryClearanceResult = new HashMap<String,String>();
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			Map<String,String> mpPackCert = new HashMap<String,String>();
			Map<String,String> mpCertDetails = new HashMap<String,String>();
			Map<String,String> mpSustainability = new HashMap<>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			CommonBusUtilBO commonBO = new CommonBusUtilBO();
			Map<String, StringList> BusinessObjectSelectableMap = CopBO.getConsumerUnitPartSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = ConsumerUnitPartBO.getCopRelatedObjsSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
			ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context,ConstantsUtil.USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);
			
			if(null==doCOP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doCOP.getInfo(context, slContextSelects, ConsumerUnitPartBO.getPlantSelects(context));
			Map resultMaps = doCOP.getInfo(context, slContextSelects,CopBO.addMultiSelects());
			swAttributes.stop();
			LOGGER.info("COP GETINFO ELAPSED TIME : "+swContext.getTime());
			
			//Common usage Variables 
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			String sName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			
			//BOM
			StopWatch swBom = new StopWatch();
			swBom.start();
			MapList mapList = doCOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
					ConstantsUtil.SYMBL_ASTERISK, slChildBusSelects, slChildRelSelects, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			if(util.isModificatinRequired()) {
				mapList=util.filterPhase(mapList);
			}
			
			swBom.stop();
			LOGGER.info("COP BOM ELAPSED TIME : "+swBom.getTime());

			ContextUtil.popContext(context);

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			if(bAllInfoView){
			
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("COP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				
				//Ownership
				StopWatch swOwnership = new StopWatch();
				swOwnership.start();
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
				swOwnership.stop();
				LOGGER.info("COP GET OWNERSHIP ELAPSED TIME : "+swOwnership.getTime());
			//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43659 on Date 17/06/2021 --START
			}
			//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43659 on Date 17/06/2021 --END
				
				//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- START
				/**
				 * LOAD MARKET CLEARANCE
				 * */
				
				StopWatch swcountry = new StopWatch();
				swcountry.start();
				BusObjectAttribUtil BbUtil=new BusObjectAttribUtil();
				//Added by Jwala for defect 44115 fix under CHG0303796 -- START
				//mapCountryClearanceResult = CopBO.getCountryClearanceResult(context,sContextObjectId);
				APPBO APPBO = new APPBO();
				mapCountryClearanceResult = APPBO.getCountryClearance(context,sContextObjectId);
				//Added by Jwala for defect 44115 fix under CHG0303796 -- END
				mapCountryClearanceResult = BbUtil.filterMapList(mapCountryClearanceResult);
				swcountry.stop();
				LOGGER.info("COP MARKET CLEARANCE TIME : "+swcountry.getTime());
				//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- END
			//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43659 on Date 17/06/2021 --START
			//}
		  //SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43659 on Date 17/06/2021 --END
				if(bAllInfoView || bManufacturerView){
					/**
					 * LOAD BASIC ATTRIBUTES SECTION
					 * */
					mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));		
					// Modified for Defect #37082 -- START
					//mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
					// Modified for Defect #37082 -- END				
					mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);


					mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
					// Modified by Jwala for Defect #42489 -- START
					//mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
					// Modified by Jwala for Defect #42489 -- END
					mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
					mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
					//Modified by Ganesh for Defect 41521 & 41362 on Date <24/mar/2021>--->start
					//mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC) : ConstantsUtil.EMPTY_STRING);
					//Modified by Ganesh for Defect 41521 & 41362 on Date <24/mar/2021>--->start
					mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
					//mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
					mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
					//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- START
					mpAttribResult.put(ConstantsUtilIRM.SETPRODUCTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SETPRODUCTNAME)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SETPRODUCTNAME) : ConstantsUtil.EMPTY_STRING);
					String strCOCAName = (String) mpLifeCycleApproval.get(ConstantsUtil.CO);
					mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty(strCOCAName))?strCOCAName : ConstantsUtil.EMPTY_STRING);
					//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- END

					//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
					String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String strBrand = util.getBrandInformationValue(context,sID);
					if(strBrand.isEmpty()) {
						strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
					}
					mpAttribResult.put(ConstantsUtil.BRAND, strBrand);

					//mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.ALTERNATIVEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
					//<12.28.2020>Lingeswari commented as reference to defect 37755===start
					//mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
					//<12.28.2020>Lingeswari commented as reference to defect 37755===end
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
					//mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
					//mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
					//mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
					//mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
					mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
					String sClassifictaion = util.getClassification(resultMaps);

					mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.WAREHOUSINGCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_WARE_HOUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_WARE_HOUSE) : ConstantsUtil.EMPTY_STRING);

					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
					//mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END

					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED))));
					mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					
					//Added by Ketan for Req. no. 46464 - START
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.PGCONSUMERPACKFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCONSUMERPACKFAMILY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCONSUMERPACKFAMILY) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.PGCONSUMERPRIMARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCONSUMERPRIMARYPACKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCONSUMERPRIMARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.PGCONSUMERSECONDARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCONSUMERSECONDARYPACKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCONSUMERSECONDARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
					//Added by Ketan for Req. no. 46464 - END

					//STORAGE AND LABEL
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
					//mapStorageAndLabelResult.put(ConstantsUtil.WAREHOUSINGCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
					mapStorageAndLabelResult.put(ConstantsUtil.UNNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER) : ConstantsUtil.EMPTY_STRING);
					mapStorageAndLabelResult.put(ConstantsUtil.PROPERSHIPPINGNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME) : ConstantsUtil.EMPTY_STRING);
					mapStorageAndLabelResult.put(ConstantsUtil.HAZARDCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS) : ConstantsUtil.EMPTY_STRING);
					mapStorageAndLabelResult.put(ConstantsUtil.PACKINGGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP) : ConstantsUtil.EMPTY_STRING);
					mapStorageAndLabelResult = util.filterMapList(mapStorageAndLabelResult);
					//Added by Pooja for the req 35902,41754,33476 -- START
					//Sustainability
					mpSustainability.put(ConstantsUtilIRM.PGINTEGRATEDLIDGLASSBOTTLEONLY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGINTEGRATEDLIDGLASSBOTTLEONLY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGINTEGRATEDLIDGLASSBOTTLEONLY) : ConstantsUtil.EMPTY_STRING);
					mpSustainability.put(ConstantsUtilIRM.PGDESIGNEDFORREUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDESIGNEDFORREUSE)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDESIGNEDFORREUSE) : ConstantsUtil.EMPTY_STRING);
					mpSustainability.put(ConstantsUtilIRM.PGLABELREMOVABILITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLABELREMOVABILITY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLABELREMOVABILITY) : ConstantsUtil.EMPTY_STRING);
					hmAttrib.put(ConstantsUtilIRM.SUSTAINABILITY, mpSustainability);
					//Added by Pooja for the req 35902,41754,33476 -- END
					//Organization Data
					StopWatch sqOrg = new StopWatch();
					sqOrg.start();
					//SPEC: <08-09-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
					//mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					//mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {

						if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} 
						else 
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
					}
					else {
						mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, ConstantsUtil.EMPTY_STRING);
					}

					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {

						if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} else 
						{
							mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
					}
					else {
						mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, ConstantsUtil.EMPTY_STRING);
					}
					//SPEC: <08-09-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
					mpOrganization = util.filterMapList(mpOrganization);
					sqOrg.stop();
					LOGGER.info("COP GET ORGANIZATION ELAPSED TIME : "+sqOrg.getTime());

					//Performance Specs	
					StopWatch swPerfChar = new StopWatch();
					swPerfChar.start();
					Map<String, String> paramMap = new HashMap<String, String>();
					paramMap.put(ConstantsUtil.OBJECT_ID, objId);
					paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
					paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
					paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

					FinishedProductPartBO fppBO = new FinishedProductPartBO();
					PefromChar perform = new PefromChar();
					MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
					//mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
					mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
					swPerfChar.stop();
					LOGGER.info("COP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

					/**
					 * LOAD PACKAGING CERTIFICATIONS
					 * */

					StopWatch swPkgCert = new StopWatch();
					swPkgCert.start();
					mpCertDetails = CopBO.getPackagingCertificationsList(context,objId,sType);
					swPkgCert.stop();
					LOGGER.info("COP PACKAGING CERTIFICATIONS ELAPSED TIME : "+swPkgCert.getTime());

					/**
					 * LOAD DERIVED DATA(RELATED PARTS) SECTION
					 * */
					//Modified by Ganesh for External defecct raised by Internal testing Team---->START
					//if(!bManufacturerView){
					if(bAllInfoView || bManufacturerView){
						//Modified by Ganesh for External defecct raised by Internal testing Team---->STOP

						//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
						/*StopWatch swDerived = new StopWatch();
				swDerived.start();
				IRMSBO irmsbo = new IRMSBO();
				String sDName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
				String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
				String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING;

				mpDerivedFromResult = irmsbo.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doCOP,true,false);
				mpDerivedToResult = irmsbo.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doCOP,false,true);
				swDerived.stop();
				LOGGER.info("COP  Derived ELAPSED TIME : "+swDerived.getTime());*/
						//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
						/**
						 * MASTER SPECIFICATION
						 * */
						StopWatch swmpMasterSpecs = new StopWatch();
						swmpMasterSpecs.start();

						// Guna Modified for Defect 37599  18x.5.2 Release -- START
						//mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
						mpMasterSpecs = CopBO.getMasterSpecs(context,sContextObjectId);
						// Guna Modified for Defect 37599  18x.5.2 Release -- END
						swmpMasterSpecs.stop();
						LOGGER.info("COP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());

					}
					//HeaderContent
					mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
					mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
					mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
					mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
					mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
					mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
					mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
					mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
					mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);

					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					mpHeaderContent.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
					mpHeaderContent.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
					//mpHeaderContent.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))));
					//Modified by Ganesh for Defect 38137  18x.5.2 Release ---->start
					String masterId = validator
							.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID));
					if (UIUtil.isNotNullAndNotEmpty(masterId)) {
						DomainObject obj = new DomainObject(masterId);
						String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
						//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
						obj.close(context);
						//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
						if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
							masterId = ConstantsUtil.NO_ACCESS;
						}
						boolean showData = util.checkHasAccess(context, sUserType, masterId);
						if (!showData) {
							masterId = ConstantsUtil.NO_ACCESS;
						}
					}
					mpHeaderContent.put(ConstantsUtil.MASTERPARTID, masterId);
					//Modified by Ganesh for Defect 38137  18x.5.2 Release ---->END
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

					if(mapList.size()!=0){
						mpEBOMResult =	CopBO.parseMaplist(context,mapList);
						//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
						//mpSubstitute =  commonBO.parseSubstitute(context,mapList);
						mpSubstitute =  CopBO.parseSubstitute(context,mapList);
						//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
					}

					/**
					 * LOAD NOTES SECTION
					 * */
					MasterCOPBO mcop = new MasterCOPBO();
					mpNotes=mcop.updateNotes(context, resultMaps);

					/**
					 * LOAD SECURITY SECTION
					 * */
					StopWatch swSecurity = new StopWatch();
					CommonBusUtilBO bo = new CommonBusUtilBO();
					swSecurity.start();
					mpSecurity =bo.updateSecurity(context, resultMaps);
					swSecurity.stop();
					LOGGER.info("COP  Security ELAPSED TIME : "+swSecurity.getTime());

					/**
					 * LOAD RELATED ATS SECTION
					 * */
					StopWatch swAts = new StopWatch();
					swAts.start();
					mpRelatedATS=util.getRelatedAts(context, doCOP);

					mpRelatedATS=util.filterMapList(mpRelatedATS);

					if(!mpRelatedATS.isEmpty()){
						mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
					}else{
						//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
						//mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
						mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
						//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
					}

					if(bManufacturerView) {
						mpRelatedATS=util.filterPhase(mpRelatedATS);
					}

					swAts.stop();
					LOGGER.info("COP ATS ELAPSED TIME : "+swAts.getTime());

					/**
					 * LOAD RELATED SPEC SECTION
					 * */
					StopWatch swRelatedSpec = new StopWatch();
					swRelatedSpec.start();
					mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
					swRelatedSpec.stop();
					LOGGER.info("COP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());

					/**
					 * LOAD REFERENCE DOCS SECTION
					 * */
					StopWatch swReference= new StopWatch();
					swReference.start();
					mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
					swReference.stop();
					LOGGER.info("COP  REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());

					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					/**
					 * LOAD WEIGHT SECTION
					 * */
					mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
					mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
					mpWeightResult.put(ConstantsUtil.LEGACYPRODUCTWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYPRODUCTWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYPRODUCTWEIGHT) : ConstantsUtil.EMPTY_STRING);
					mpWeightResult.put(ConstantsUtil.LEGACYWIGHTFACTOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTOR) : ConstantsUtil.EMPTY_STRING);
					mpWeightResult.put(ConstantsUtil.LEGACYWIGHTFACTORUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTORUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTORUOM) : ConstantsUtil.EMPTY_STRING);
					mpWeightResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
					mpWeightResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);

					mpWeightResult = util.filterMapList(mpWeightResult);

					/**
					 * PLANT DATA SECTION
					 * */
					mpPlantResult = util.updatePlantInfo(resultMaps);

					//SPEC: <10.12.2020>: Added for req 18x.5 ## -- START
					/**
					 * LOAD IP CLASSES SECTION
					 */
					//IP Class

					StringList slIpSelects = new StringList();
					slIpSelects.add(ConstantsUtil.SELECT_NAME);
					slIpSelects.add(ConstantsUtil.SELECT_ID);
					slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
					slIpSelects.add(ConstantsUtil.SELECT_TYPE);
					slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
					CommonBusUtilBO commonBo = new CommonBusUtilBO();
					mpIPClass =commonBo.getIpClass(context, doCOP, slIpSelects);

					/**
					 * FILES SECTION
					 */


					//SPEC Added on 12-Dec-2020 by Chandra for Defect 37746 ##--START	

					/*
				String FileCapturedFie = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				String FileSize = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));

				FileCapturedFie=FileCapturedFie.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
				FileFormats=FileFormats.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
				FileName=FileName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
				FileSize=FileSize.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE); */


					String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
					String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
					String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
					StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));

					//SPEC Added on 12-Dec-2020 by Chandra for Defect 37746 ##--END
					//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
					CommonDocBO cdoc = new CommonDocBO();
					String strFileSize = cdoc.updateFileSize(FileSize);
					//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
					mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
					mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
					mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
					mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);

					//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

					//Added by Pooja for the req 35902,41754,33476 -- START

					/**
					 * LOAD GPSASSESSMENTS SECTION
					 * */
					StopWatch swgps= new StopWatch();
					swgps.start();
					DeviceProductPartBO DPPBO = new DeviceProductPartBO();
					mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
					mpGPSAssessments = util.filterMapList(mpGPSAssessments);
					swgps.stop();
					LOGGER.info("COP  GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
					
					//SPEC: Modified by Ajay for Req. no. 30189 START
					/**
					 * LOAD EXTENDED SECTION
					 * */
					mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
					//SPEC: Modified by Ajay for Req. no. 30189 END
				}
			//Added by Pooja for the req 35902,41754,33476 -- END
			
			if(bAllInfoView || bManufacturerView){
				hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
				hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
				
				hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATAOBJECT, mapStorageAndLabelResult);
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
				hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
				hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
				hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
				//hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
				//hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO, mpDerivedToResult);
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
				hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
				hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
				hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
				//commented by Ganesh for External defect---->START
				//hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
				//commented by Ganesh for External defect---->STOP
				
				//commented by Ganesh for External defect raised by Internal testing Team-->START
				//hmAttrib.put(ConstantsUtil.FILES, mpFiles);
				//commented by Ganesh for External defect raised by Internal testing Team-->STOP
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
				//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43659 on Date 17/06/2021 --START
				//SPEC: 08-12-2022: Satyam added for Req 45670 -- START
				String setProduct = validator.getEquivalentString((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SETPRODUCTNAME));
				if(setProduct.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
					hmAttrib.put(ConstantsUtil.MARKETOFCLEARANCE, mapCountryClearanceResult);
				}
				//SPEC: 08-12-2022: Satyam added for Req 45670 -- END
				//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43659 on Date 17/06/2021 --END
				hmAttrib.put(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS, mpCertDetails);
				
				hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			}
			if(bAllInfoView){
				hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
				hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
				//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- START
				//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43659 on Date 17/06/2021 --START
				//hmAttrib.put(ConstantsUtil.MARKETOFCLEARANCE, mapCountryClearanceResult);
				//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43659 on Date 17/06/2021 --END
				//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- 
				//Modified by Ganesh for External defect raised by Internal Testing Team---->START
				hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
				//Modified by Ganesh for External defect raised by Internal Testing Team---->STOP
				//Modified by Ganesh for External defect raised by Internal testing Team-->START
				hmAttrib.put(ConstantsUtil.FILES, mpFiles);
				//Modified by Ganesh for External defect raised by Internal testing Team-->STOP
				hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			}
			
			pool.checkIn(context);
			sp.stop();
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
			doCOP.close(context);
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
			LOGGER.info("COP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "COP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		} catch (IOException e) {
			LOGGER.error("Exception in getCOPdata : "+e);
		} catch (MatrixException e) {
			LOGGER.error("Exception in getCOPdata : "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		//LOGGER.info("PMP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- START
		if(sComp.equals(ConstantsUtil.COP)|| sComp.equals(ConstantsUtilIRM.STATE_PRILIMNARY)) {
			context.close();
		}
		return hmAttrib;
	}
	public String getRequestOid() {
	    String requestId = request.getHeader("requestId");
		return requestId;
	}
}
