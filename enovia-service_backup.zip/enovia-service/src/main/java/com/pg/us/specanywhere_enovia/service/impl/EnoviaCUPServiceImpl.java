/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaCUPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.CustomerUnitPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaCUPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

public class EnoviaCUPServiceImpl implements EnoviaCUPService {

	private static Logger LOGGER = Logger.getLogger(EnoviaCUPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
	private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getCUPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();

		StopWatch sp = new StopWatch();
		sp.start();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		
		try 
		{
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			
			LOGGER.info("CUP CONTEXT ELAPSED TIME : "+swContext.getTime());
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			if (UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BObjutil.getUserView(context, objId);
				}
				//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			}
			//SPEC: <08-04-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bManufacturerView = false;

			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				bManufacturerView = true;
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				bManufacturerView = true;
			} else {
				switch (sUserType) {
				case ConstantsUtil.PG:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PGSTAFF:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PG_CM:
					bManufacturerView = true;
					break;

				}

			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			CustomerUnitPartBO CupBO = new CustomerUnitPartBO();
			DomainObject doCUP = CupBO.getCupDO(context, objId);
			String strCurrent = doCUP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			//Modified by Ajay for Req No. 122489 -- START
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR IN CUP: "+hmAttrib);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//Modified by Ajay for Req No. 122489 -- END
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
	
			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			CommonBusUtilBO commonBO = new CommonBusUtilBO();
			Map<String, String> mpAttribResult = new HashMap<String, String>();
			Map<String, String> mpHeaderContent = new HashMap<String, String>();
			Map<String, String> mpOrganization = new HashMap<String, String>();
			Map<String, String> mapStorageAndLabelResult = new HashMap<String, String>();
			Map<String, String> mapOwnerShipResult = new HashMap<String, String>();
			Map<String, String> mpEBOMResult = new HashMap<String, String>();
			Map<String,String>  mpLifeCycleApproval = new HashMap<String,String>();

			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mpSubstitute = new HashMap<String,String>();
			Map<String,String> mpPerformChar= new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			Map<String,String> mpWeightResult = new HashMap<String,String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();

			Map<String, StringList> BusinessObjectSelectableMap = CupBO.getCustmerUnitPartSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = CustomerUnitPartBO.getCupRelatedObjsSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
			
			if(null==doCUP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doCUP.getInfo(context, slContextSelects, CustomerUnitPartBO.getPlantSelects(context));
			Map resultMaps = doCUP.getInfo(context, slContextSelects,CupBO.addMultiSelects());
			swAttributes.stop();
			LOGGER.info("CUP GETINFO ELAPSED TIME : "+swContext.getTime());
			StopWatch swBom = new StopWatch();
			swBom.start();
			
			
			//Common usage Variables 
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			//BOM
			MapList mapList = doCUP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.SYMBL_ASTERISK, slChildBusSelects , slChildRelSelects, false, true, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			if(busUtil.isModificatinRequired()) {
				mapList=busUtil.filterPhase(mapList);
			}
			swBom.stop();
			LOGGER.info("CUP BOM ELAPSED TIME : "+swBom.getTime());

			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- START
			//String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;
			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- END

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			if(bAllInfoView){

				//Lifecycle
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = busUtil.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("CUP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				//mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);

				//Ownership
				StopWatch swOwnership = new StopWatch();
				swOwnership.start();
				//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- START
                StringBuilder sbPersonName = new StringBuilder();
                //modified by Ganesh for defect 40911 <22/Mar/2021> ----->start
				//String strPersons = (String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS);
				String strPersons = (String)mpLifeCycleApproval.get(ConstantsUtilIRM.ROUTEAPPROVERS);
				//modified by Ganesh for defect 40911 <22/Mar/2021> ----->end
				StringList slPersons = FrameworkUtil.split(strPersons, "|");
				String strSequence = (String)mpLifeCycleApproval.get(ConstantsUtilIRM.ROUTE_SEQUENCE);
				StringList slSequence = FrameworkUtil.split(strSequence, "|");
				HashMap<String, String> hmPerson= new HashMap<String,String>();
				if ( slSequence != null && slSequence.size() > 0 )
				{
					 for (int iSeq = 0 ; iSeq < slSequence.size() ; iSeq++)
					{
						hmPerson.put((String)slSequence.get(iSeq),(String)slPersons.get(iSeq));
					
					}
				}
				
			   for(Map.Entry m:hmPerson.entrySet()) 
			     {
				     String approvers=(String)m.getValue();
			         sbPersonName.append(approvers);
			         sbPersonName.append(ConstantsUtil.SYMBL_PIPE);
			     }
			
			    mapOwnerShipResult.put(ConstantsUtil.APPROVERS,sbPersonName.toString()) ;
			    //mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
			    //SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- END
			    mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = busUtil.filterMapList(mapOwnerShipResult);
				swOwnership.stop();
				LOGGER.info("CUP OWNERSHIP ELAPSED TIME::" + swOwnership.getTime());
				
				/**
				 * PLANT DATA SECTION
				 * */
				mpPlantResult = busUtil.updatePlantInfo(resultMaps);
				
				//Added by Jwala for SIT Stress Fixes
				/**
				 * FILES SECTION
				 */
				
				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
				CommonDocBO cdoc = new CommonDocBO();
				String strFileSize = cdoc.updateFileSize(FileSize);
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);

			}

			if(bAllInfoView || bManufacturerView){

				//Basic  Data
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: Release 18x.5.2: Added for Defect 35859 by Amman ## -- START
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release 18x.5.2: Added for Defect 35859 by Amman ## -- END
				
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED))));
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
				
				StopWatch swLastUpdateUser = new StopWatch();
				swLastUpdateUser.start();
				
				swLastUpdateUser.stop();
				LOGGER.info("CUP LASTEUPDAT USER ELAPSED TIME : "+swLastUpdateUser.getTime());
				//SPEC: 10/09/2020: Modified for 18x.5 DEV -- END
				
				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = busUtil.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
				
					//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
					//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				//mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CUSTOMIZATIONTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRIMARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SECONDARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				//Added by Ketan for Req. no. 46464 - START
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				//Added by Ketan for Req. no. 46464 - END
				
				//SPEC: Release 18x.5.2: Modified for Defect 38524 by Amman ## -- START
				//mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release 18x.5.2: Modified for Defect 38524 by Amman ## -- END

				String sClassifictaion = busUtil.getClassification(resultMaps);
				
				mpAttribResult.put(ConstantsUtil.ALTERNATIVEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Added  by Ganesh on Date 1st March 2021 -- START
				String strCOCAName = (String) mpLifeCycleApproval.get(ConstantsUtil.CO);
				mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty(strCOCAName))?strCOCAName : ConstantsUtil.EMPTY_STRING);
				
				String UnNumber = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER));
				String ProperShippingName = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME));
				String HarzadClass = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS));
				String PackingGroup = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP));
				
				
				
				mapStorageAndLabelResult.put(ConstantsUtil.UNNUMBER, UnNumber);
				mapStorageAndLabelResult.put(ConstantsUtil.PROPERSHIPPINGNAME, ProperShippingName);
				mapStorageAndLabelResult.put(ConstantsUtil.HAZARDCLASS, HarzadClass);
				mapStorageAndLabelResult.put(ConstantsUtil.PACKINGGROUP, PackingGroup);
				//SPEC: <11.03.2020>: Added for req 18x.5 ## -- END
				mapStorageAndLabelResult = busUtil.filterMapList(mapStorageAndLabelResult);

				//Organization Data
				StopWatch swOrg = new StopWatch();
				swOrg.start();
				if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {
				
					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} 
					else 
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
				}
				else {
					mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, ConstantsUtil.EMPTY_STRING);
				}
				
				if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {
				
					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
					{
						mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
					} else 
					{
						mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					}
				}
				else {
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
				BusObjectAttribUtil util = new BusObjectAttribUtil();
				mpOrganization = util.filterMapList(mpOrganization);
				swOrg.stop();
				LOGGER.info("CUP ORGANIZATION ELAPSED TIME::" + swOrg.getTime());


				//HeaderContent
				mpHeaderContent.put(ConstantsUtil.TYPE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion); 
				
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				mpHeaderContent.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderContent.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				//mpHeaderContent.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))));
				//Modified by Ganesh for Defect 38137  18x.5.2 Release ---->start
				String masterId = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID));
				if (UIUtil.isNotNullAndNotEmpty(masterId)) {
					DomainObject obj = new DomainObject(masterId);
					String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
					obj.close(context);
					//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
					boolean showData = busUtil.checkHasAccess(context, sUserType, masterId);
					if (!showData) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
				}
				mpHeaderContent.put(ConstantsUtil.MASTERPARTID, masterId);
                 //Modified by Ganesh for Defect 38137  18x.5.2 Release ---->END
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
				
				StopWatch swBOM = new StopWatch();
				swBOM.start();
				if(mapList.size()!=0){
					mpEBOMResult =	CupBO.parseMaplist(context,mapList);
					mpSubstitute =  commonBO.parseSubstitute(context,mapList);
				}//Maplist size
				swBOM.stop();
				LOGGER.info("CUP BOM-PARSING ELAPSED TIME::" + swBOM.getTime());

				/**
				 * LOAD NOTES SECTION
				 * */
				MasterCOPBO mcop = new MasterCOPBO();
				mpNotes=mcop.updateNotes(context, resultMaps);

				/**
				 * LOAD PERFORMANCE CHAR SECTION
				 * */
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				Map<String, String> paramMap = new HashMap<String, String>();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);
				
				FinishedProductPartBO fppBO = new FinishedProductPartBO();
				PefromChar perform = new PefromChar();
				
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
				mpPerformChar =busUtil.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
				//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
				swPerfChar.stop();
				LOGGER.info("CUP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

				
				/**
				 * LOAD SECURITY SECTION
				 * */
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO bo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =bo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				LOGGER.info("CUP  Security ELAPSED TIME : "+swSecurity.getTime());

				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=busUtil.getRelatedAts(context, doCUP);
				
				mpRelatedATS=busUtil.filterMapList(mpRelatedATS);
				if(!mpRelatedATS.isEmpty()){
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
					//mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
					//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
				}

				if(bManufacturerView) {
					mpRelatedATS=busUtil.filterPhase(mpRelatedATS);
				}

				swAts.stop();
				LOGGER.info("CUP ATS ELAPSED TIME : "+swAts.getTime());


				/**
				 * LOAD RELATED SPEC SECTION
				 * */
				StopWatch swRelatedSpec = new StopWatch();
				swRelatedSpec.start();
				mpRelatedSpecResult = busUtil.updatePartSpec(context, resultMaps);
				
				swRelatedSpec.stop();
				LOGGER.info("CUP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());

				
				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);

				swReference.stop();
				LOGGER.info("CUP REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());
				
				/**
				 * MASTER SPECIFICATION
				 * */
				StopWatch swmpMasterSpecs = new StopWatch();
				swmpMasterSpecs.start();
				mpMasterSpecs = busUtil.getMasterSpecs(context,sContextObjectId);
				swmpMasterSpecs.stop();
				LOGGER.info("CUP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());
				
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				/**
				 * LOAD WEIGHT SECTION
				 * */
				mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.LEGACYWIGHTFACTOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTOR) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.LEGACYWIGHTFACTORUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTORUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTORUOM) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult = busUtil.filterMapList(mpWeightResult);
				
				/**
				 * LOAD IP CLASSES SECTION
				 */
				//IP Class
				
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				CommonBusUtilBO commonBo = new CommonBusUtilBO();
				mpIPClass =commonBo.getIpClass(context, doCUP, slIpSelects);
				
				//SPEC: Modified by Ajay for Req. no. 30189 START
				/**
				 * LOAD EXTENDED SECTION
				 * */
				mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
				//SPEC: Modified by Ajay for Req. no. 30189 END

			}

			if(bAllInfoView || bManufacturerView){

				hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
				hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
				//Commented by Ganesh for External defect raised by Internal Testing Team---->START
				
				//Commented by Ganesh for External defect raised by Internal Testing Team---->STOP
				hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATAOBJECT, mapStorageAndLabelResult);
				hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
				hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
				hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
				hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
				if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
				}
				hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
				hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
				hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
				hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
				
				hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
				hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
				hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
				hmAttrib.put(ConstantsUtil.FILES, mpFiles);
				hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			}
			pool.checkIn(context);
			sp.stop();			
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
			doCUP.close(context);
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
			LOGGER.info("CUP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "CUP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
			
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		} catch (IOException e) {
			LOGGER.error("EXCEPTION in getCUPdata : "+e);
		} catch (MatrixException e) {
			LOGGER.error("EXCEPTION in getCUPdata : "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		//LOGGER.info("PMP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- START
		if(sComp.equals(ConstantsUtil.CUP) || sComp.equals(ConstantsUtilIRM.STATE_PRILIMNARY)) {
			context.close();
		}
		
		return hmAttrib;
	}
}
