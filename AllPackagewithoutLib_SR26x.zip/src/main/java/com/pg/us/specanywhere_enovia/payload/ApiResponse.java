package com.pg.us.specanywhere_enovia.payload;

import java.util.List;

public class ApiResponse {

	private Boolean success;
	private String message;

	private List<CustomAuthority> authorities;

	public List<CustomAuthority> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(List<CustomAuthority> authorities) {
		this.authorities = authorities;
	}

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}