/**
 * Project 		: SpecsAnywhere
 * Program 		: APPBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.fop.FormulationAttribute;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import com.matrixone.apps.framework.ui.UIUtil;
import matrix.util.Pattern;
import matrix.db.Access;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class APPBO {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(APPBO.class);
	BusObjectAttribUtil util  = new BusObjectAttribUtil();

	public APPBO() {
		// empty constructor
	}

	/**
	 * Method Name 			: getMaterialProduced
	 * Method Description 	: Fetching "Materials Produced" data
	 * @param context
	 * @param strObjId
	 * @returns materials Produced
	 */
	public Map getMaterialProduced(Context context,String strObjId)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();

		StringBuilder sbId=new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();

		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbRevision=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();

		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strObjId))
			{
				DomainObject contextObj = DomainObject.newInstance(context,strObjId);
				
				StringList selectStmts = new StringList(5);                     
				selectStmts.addElement(ConstantsUtil.SELECT_ID);
				selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
				selectStmts.addElement(ConstantsUtil.SELECT_NAME);
				selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
				selectStmts.addElement(ConstantsUtil.SELECT_DESCRIPTION);
				selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);		
				selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

				selectStmts.add(ConstantsUtil.SUBSTANCE_TYPE);
				selectStmts.add(ConstantsUtil.SUBSTANCE_ID);
				selectStmts.add(ConstantsUtil.SUBSTANCE_NAME);
				selectStmts.add(ConstantsUtil.SUBSTANCE_DESCRIPTION);
				selectStmts.add(ConstantsUtil.SUBSTANCE_TITLE);
				selectStmts.add(ConstantsUtil.SUBSTANCE_REVISION);
				selectStmts.add(ConstantsUtil.SUBSTANCE_STATE);
				selectStmts.add(ConstantsUtil.SUBSTANCE_RELEASEPHASE);

				MapList mlRelatedIAPSList = contextObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGDEFINESMATERIAL,
						ConstantsUtil.SYMBL_ASTERISK, selectStmts, null, false, true, (short) 0,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- START
				contextObj.close(context);
				//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- END
				Iterator objectListItr = mlRelatedIAPSList.iterator();

				while(objectListItr.hasNext())
				{
					Map resultMaps = (Map) objectListItr.next();

					String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.TYPE));
					String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ID));
					String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.NAME));

					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//String strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.DESCRIPTION));
					String strDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.DESCRIPTION));
					//String strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String strTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					String strRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
					String strState	 =  util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT)));
					String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

					//modified by Ganesh for defect 38188----->start

					if (!strState.equals(ConstantsUtil.RELEASE) &&  !strState.equals(ConstantsUtil.RELEASED)) {
						strID=ConstantsUtil.NO_ACCESS;

					}
					strState=util.mapType(strState);
					strType=util.mapType(strType);
					boolean isExternal = util.isModificatinRequired(); // Added by Ketan for Defect No. 50497
					//SPEC: <22.03.2021>: Guna Modified for Defect 41153 Dev 18x.6   -- START
					boolean showData = false;
					if (UIUtil.isNotNullAndNotEmpty(strID)) {
						showData = util.checkHasAccess(context, null, strID);
						//SPEC: <04.06.2021>: Guna UnCommented for 39652 Req  Dev 18x.6.0.1   -- START
						//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
						if(!showData && util.isModificatinRequired()){
							continue;
						}
						//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END
						//SPEC: <04.06.2021>: Guna UnCommented for 39652 Req  Dev 18x.6.0.1   -- END
					if(showData){
					formatData(sbType,strType);
					formatData(sbName,strName);
					formatData(sbDesc,strDesc);
					formatData(sbCurrent,strState);
					formatData(sbId,strID);
					formatData(sbRevision,strRev);
					formatData(sbPhase,strPhase);
					formatData(sbTitle,strTitle);
					}
					// Added by Ketan for Defect No. 50497 -- START
					else if (!showData && strState.equals(ConstantsUtil.STATE_INWORK) && !isExternal) {
						formatData(sbType,strType);
						formatData(sbName,strName);
						formatData(sbDesc,strDesc);
						formatData(sbCurrent,strState);
						formatData(sbId,strID);
						formatData(sbRevision,strRev);
						formatData(sbPhase,strPhase);
						formatData(sbTitle,strTitle);
					}
					// Added by Ketan for Defect No. 50497 -- END
					else{
						formatData(sbType,strType);
						formatData(sbName,strName);
						formatData(sbDesc,ConstantsUtil.NO_ACCESS);
						formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
						formatData(sbId,ConstantsUtil.NO_ACCESS);
						formatData(sbRevision,strRev);
						formatData(sbPhase,ConstantsUtil.NO_ACCESS);
						formatData(sbTitle,ConstantsUtil.NO_ACCESS);
					}
					}
					//SPEC: <22.03.2021>: Guna Modified for Defect 41153 Dev 18x.6   -- END
					//modified by Ganesh for defect 38188----->end
					strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_TYPE));
					strID	 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_ID));
					strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_NAME));

					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_DESCRIPTION));
					strDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SUBSTANCE_DESCRIPTION));
					//strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_TITLE));
					strTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SUBSTANCE_TITLE));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					strRev	 		=  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_REVISION));
					strState	 =  util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_STATE)));
					strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_RELEASEPHASE));

					//modified by Ganesh for defect 38188----->start
					if (! (strState.equals(ConstantsUtil.RELEASE) ||  !strState.equals(ConstantsUtil.RELEASED)) ) {
						strID=ConstantsUtil.NO_ACCESS;
					}
					strState=util.mapType(strState);
					strType=util.mapType(strType);
					//SPEC: <22.03.2021>: Guna Modified for Defect 41153 Dev 18x.6   -- START
					
					if (UIUtil.isNotNullAndNotEmpty(strID)) {
						showData = util.checkHasAccess(context, null, strID);
						//SPEC: <03.06.2021>: Guna Commented for 39652 Req  Dev 18x.6.0.1   -- START
						//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
					/*	if(!showData && util.isModificatinRequired()){
							continue;
						}*/
						//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END
						//SPEC: <03.06.2021>: Guna Commented for 39652 Req  Dev 18x.6.0.1   -- END
					if(showData){
					formatData(sbType,strType);
					formatData(sbName,strName);
					formatData(sbDesc,strDesc);
					formatData(sbCurrent,strState);
					formatData(sbId,strID);
					formatData(sbRevision,strRev);
					formatData(sbPhase,strPhase);
					formatData(sbTitle,strTitle);
					}else{
						formatData(sbType,strType);
						formatData(sbName,strName);
						formatData(sbDesc,ConstantsUtil.NO_ACCESS);
						formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
						formatData(sbId,ConstantsUtil.NO_ACCESS);
						formatData(sbRevision,strRev);
						formatData(sbPhase,ConstantsUtil.NO_ACCESS);
						formatData(sbTitle,ConstantsUtil.NO_ACCESS);
					}
					}
					//SPEC: <22.03.2021>: Guna Modified for Defect 41153 Dev 18x.6   -- END
					//modified by Ganesh for defect 38188----->end
				}

				mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString());
				mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString());
				mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString());
				mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString());
				mpSubStanceResult.put(ConstantsUtil.REV,sbRevision.toString());
				mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString());
				mpSubStanceResult.put(ConstantsUtil.PHASE, sbPhase.toString());
				mpSubStanceResult.put(ConstantsUtil.ID, sbId.toString());
			}

		}catch(Exception e){

			LOGGER.error("Error from DeviceProductPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return util.filterMapList(mpSubStanceResult);
	}


	/**
	 * Method Name 			: formatData
	 * Method Description 	: 
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}


	/**
	 * Method Name 			: getAppBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getAppBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getAppDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getAppDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			return doObj;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getAPPSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getAPPSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		busSelect.addAll(getStorageTrasportSelectable(context));
		busSelect.addAll(getPlantBusSelectable(context));
		//busSelect.addAll(getAPPMasterSpecs(context));
		busSelect.addAll(getDangerousgoodsSpecSelects(context));
		busSelect.addAll(getGlobalHarmonizedStandard(context));
		busSelect.addAll(getStabilityResults(context));
		busSelect.addAll(getWeightCharacterSelectable(context));
		busSelect.addAll(getSapBomAsFedBusSelectable(context));
		busSelect.addAll(getSubstanceSelectables(context));
		busSelect.addAll(getCountryClearanceSelectable(context));
		//SPEC: 10/21/2020: Added for 18x.5 DEV -- START
		//busSelect.addAll(getAlternateSelects(context));
		busSelect.addAll(getFileSelects(context));
		//SPEC: 10/21/2020: Added for 18x.5 DEV -- END
		//SPEC: 11/07/2020: Added for Defect 37063 -- START
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: 11/07/2020: Added for Defect 37063 -- END
		//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
		busSelect.addAll(getChemicalPhysicalSelectable(context));
		//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}


	/**
	 * Method Name 			: getAPPRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getAPPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();

		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		relSelect.addAll(getSubRelSelects());
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);

		return mapSelecables;
	}

	//SPEC: 10/21/2020: Added for the Release 18x5 -- START
	/**
	 * Method Name 			: getAlternateSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	//SPEC: Commented for Defect#37664 1.0.2 Release - Jwala -- START

	/*public static StringList getAlternateSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_APPNAME);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_APPREVISION);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_APPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE__RELEASE_APPPHASE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_APPSTATE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_APPDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_APPCERTIFICATIONS);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_APPID);

		return busSelect;
	}*/
	//SPEC: Commented for Defect#37664 1.0.2 Release - Jwala -- START
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	//SPEC: 10/21/2020: Added for 18x.5 DEV -- END

	/**
	 * Method Name 			: getAPPMasterSpecs
	 * Method Description 	: Fetching "Master Specifications" details
	 * @param context
	 * @return
	 */
	public static StringList getAPPMasterSpecs(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ID);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_NAME);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT);
		return busSelect;

	}


	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(DomainConstants.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.STR_TEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT);
		busSelect.add(ConstantsUtil.ATTRIBUTE_PGPRODUCTFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME); 
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT);
		//SPEC: <17.06.2022>: Satyam Added for Internal Defect  -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC);
		//SPEC: <17.06.2022>: Satyam Added for Internal Defect  -- END

		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.ATL_ORGNSOURCE);

		busSelect.add(ConstantsUtil.SELECT_REL_MATERIAL_CERTIFICATIONS_CERTIFICATIONCLAIM);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS);

		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		busSelect.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ROLLUPNETWEIGHTTOCOP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY);

		//SPEC: <11.25.2020>: Added for Defect :37575 by Madhana ## --START
		busSelect.add(ConstantsUtil.strIntendedMarket);
		//SPEC: <11.25.2020>: Added for Defect :37575 by Madhana ## --END

		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION);

		busSelect.add(ConstantsUtil.SELECT_REL_SHIPPINGCLASSIF);

		//SPEC: Added related to Defect#37301 1.0.2 Release - Amman -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//SPEC: Added related to Defect#37301 1.0.2 Release - Amman -- END
		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
		busSelect.add(ConstantsUtil.SELECT_REL_MARKETNAME);
		busSelect.add(ConstantsUtil.SELECT_REL_OWNINGPRODUCTLINE);
		busSelect.add(ConstantsUtil.SELECT_REL_PNGLPDMODELTYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_PNGDEFINITION);

		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
		
		//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_SMARTLABENREADY);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL);
		//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- END
		
		//CATIA APP
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDREGION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDSUBREGION);
		
		//SPEC: 29/04/2022: Added by Jwala for 22x DEV Req 34415-- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS);
		//SPEC: 29/04/2022: Added by Jwala for 22x DEV Req 34415-- END
		
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARUPDATESTATUS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDMODELUPDATESTATUS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDREASONCHANGEGENERICMODEL);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC);//SPEC: 01-09-2022: Pooja Modified for Defect 50496
		

		return busSelect;
	}


	/**
	 * Method Name 			: getStorageTrasportSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getStorageTrasportSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		//SPEC <12/03/2020> Modified for defect #37730 START 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGHAZARDCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_REL_SHIPPINGCLASSIF);
		//SPEC <12/03/2020> Modified for defect #37730 END 


		return busSelect;
	}


	/**
	 * Method Name 			: getCountryClearanceSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getCountryClearanceSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.STR_COUNTRY_NAME); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_CT_NUM); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS); 	
		busSelect.add(ConstantsUtil.STR_COUNTRY_MANU_SITE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PACK_SITE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PLANT_REST); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_REG_DATE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_REG_STATUS); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS);
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE);
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY);
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME);
		busSelect.add(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALLEADTIME);
		busSelect.add(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALSTATUS);
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END

		return busSelect;
	}


	/**
	 * Method Name 			: getSapBomAsFedBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getSapBomAsFedBusSelectable(Context context) {

		StringList busSelect = new StringList(7);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_NAME);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_TYPE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_SAPSUBTYPE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_TITLE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_BOMQTY);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_BUOM);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE);

		return busSelect;
	}


	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	: Fetching "Substances" related data
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.COMP_TYPE);
		busSelect.add(ConstantsUtil.COMP_ID);
		busSelect.add(ConstantsUtil.COMP_NAME);  
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC); 
		busSelect.add(ConstantsUtil.COMP_TITLE); 
		busSelect.add(ConstantsUtil.COMP_STATE); 
		busSelect.add(ConstantsUtil.COMP_CASNUM);  		
		busSelect.add(ConstantsUtil.COMP_SUBNAME);  		
		busSelect.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);  		
		busSelect.add(ConstantsUtil.COMP_QTY);  			
		busSelect.add(ConstantsUtil.COMP_MAXHGHT);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT);  		
		busSelect.add(ConstantsUtil.COMP_QUOM);  
		busSelect.add(ConstantsUtil.COMP_METALENVCLASS); 
		busSelect.add(ConstantsUtil.COMP_POSTCONSUMER); 
		busSelect.add(ConstantsUtil.COMP_MANUF);  		
		busSelect.add(ConstantsUtil.COMP_COMENT);  		
		busSelect.add(ConstantsUtil.COMP_MARKETNAME);  	
		busSelect.add(ConstantsUtil.COMP_SEQUENCE);  		
		busSelect.add(ConstantsUtil.COMP_MATELAYER);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_FN);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_STATE);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TITLE);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMATERIALLEGACYENVCLASS);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPOSTCOSUMERRECYCLEDCONTENT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_MANUFACTURER);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_MANUFACTURER);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_ORIGINSOURCE);

		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

		return busSelect;
	}


	/**
	 * Method Name 			: getWeightCharacterSelectable
	 * Method Description 	: Fetching "Weight Characteristics" related data
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharacterSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		return busSelect;
	}


	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME);
		busSelect.add(ConstantsUtil.CERTIFICATION_NAME);
		//SPEC: <11.22.2020>: Guna Added for Defect :37440 ## --START
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCSSTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		//SPEC: <11.22.2020>: Guna Added for Defect :37440 ## --END
		//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_APPLICATION);
		busSelect.add(ConstantsUtil.RELATIONSHIP_EBOM_SUBSTITUTE_FROMREL_TO_APPLICATION);
		//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- END
		
		//Added By Jwala for req 41754 template fix -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_PGLIFECYCLE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALRESTRICTIONCOMMENTS);
		//Added By Jwala for req 41754 template fix -- START
		//SPEC: 16-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50049-- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALRESTRICTIONCOMMENT);
		//SPEC: 16-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50049-- END

		return busSelect;
	}


	/**
	 * Method Name 			: getSubRelSelects
	 * Method Description 	: 
	 * @return
	 */
	public static StringList getSubRelSelects(){

		StringList busselect = new StringList();

		//busselect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		busselect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		busselect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		busselect.add(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS);
		//SPEC: 11/19/2020: Commented for Defect : 37446-- START
		//busselect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//SPEC: 11/19/2020: Commented for Defect : 37446-- END

		//Added for Defect# 37591 -- START
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
		//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
		busselect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_PGLIFECYCLE_STATUS);
		busselect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_MATERIALRESTRICTION);
		//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
		return busselect;
	}


	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
		
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RF);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		//Added by Ketan for Req. no. 46464 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC);
		//Added by Ketan for Req. no. 46464 -- END

		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END


		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		//SPEC: <20.11.2020>: Modified for Defect 37440 Spec Reader 1.0.1 --  Start
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MIN_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MAX_QUANTITY);
		//SPEC: <20.11.2020>: Modified for Defect 37440 Spec Reader 1.0.1 --  End
		//SPEC: <11.22.2020>: Guna added for Defect :37442 ## --START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_VALUE);
		//SPEC: <11.22.2020>: Guna added for Defect :37442 ## --END
		//SPEC: <11.23.2020>: Guna added for Defect :37442 ## --START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_VALUE);
		//SPEC: <11.23.2020>: Guna added for Defect :37442 ## --END

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
		//SPEC: <11.25.2020>: Guna added for Defect :37440 ## --START
		//relSelect.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_APPLICATION);
		//SPEC: <11.25.2020>: Guna added for Defect :37440 ## --START

		//Modified for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Modified for Defect# 37591 -- END
		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOMPONENTQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCOMPONENTQUANTITY);
		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
		
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LAYERNAME);
		//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
		relSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_LAYERGROUP);
		//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
		
		//SPEC: 16-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50049-- START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		//SPEC: 16-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50049-- END
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		relSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENT_LOCATION);//SPEC: Added by Ajay for Req. no. 36986

		
				return relSelect;
	}


	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	: 
	 * @param context
	 * @param mapList
	 * @return
	 */
	//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --START
	//public Map<String, String> parseMaplist(Context context,MapList mapList) {
	public Map<String, String> parseMaplist(Context context,MapList mapList, boolean bGendocView) {
		//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
		Map<String,String> mpEBOMResult = new HashMap<String,String>();

		StringValidatorUtil validator = new StringValidatorUtil();

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);

		//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --START
		//Iterator objectListItr = mapList.iterator();
		Map MPFinalEBOMSubStitute = new HashMap();
		Map mpFinalEBOM = new HashMap();
		Map mpFinalSubstitute = new HashMap();
		//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
		int index=1;
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		StringBuilder sbFEBOMName = new StringBuilder();
		StringBuilder sbFEBOMId = new StringBuilder();
		StringBuilder sbFEBOMRev = new StringBuilder();
		StringBuilder sbFEBOMChg = new StringBuilder();
		StringBuilder sbFEBOMFN = new StringBuilder();
		StringBuilder sbFEBOMTitle = new StringBuilder();
		StringBuilder sbFEBOMType = new StringBuilder();
		StringBuilder sbFEBOMQTY = new StringBuilder();
		StringBuilder sbFEBOMBuom = new StringBuilder();
		StringBuilder sbFEBOMCommnts = new StringBuilder();
		StringBuilder sbFEBOMState= new StringBuilder();
		StringBuilder sbFEBOMStage= new StringBuilder();
		StringBuilder sbFEBOMRDOC= new StringBuilder();
		StringBuilder sbFEBOMRevRelDt= new StringBuilder();
		StringBuilder sbFEBOMTupName= new StringBuilder();		 
		StringBuilder sbFMinqty= new StringBuilder();
		StringBuilder sbFMaxqty= new StringBuilder();
		StringBuilder sbFNetWUOM= new StringBuilder();
		StringBuilder sbFNetWet= new StringBuilder();
		StringBuilder sbFLoss= new StringBuilder();
		StringBuilder sbFMF= new StringBuilder();
		StringBuilder sbFGW= new StringBuilder();
		StringBuilder sbFAltName = new StringBuilder();
		StringBuilder sbFAltID = new StringBuilder();
		StringBuilder sbFAltType = new StringBuilder();
		StringBuilder sbFNet= new StringBuilder();
		StringBuilder sbFOSPD= new StringBuilder();
		StringBuilder sbFDen= new StringBuilder();
		StringBuilder sbFCerti= new StringBuilder();
		StringBuilder sbFRF= new StringBuilder();
		StringBuilder sbFEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbFEBOMSubPartID = new StringBuilder();
		StringBuilder sbFEBOMSubPartType = new StringBuilder();
		
		StringBuilder sbGrossWeightReal = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder();
		StringBuilder sbManufacturingStatus = new StringBuilder();
		StringBuilder sbMaterialRestriction = new StringBuilder();
		StringBuilder sbMRComments = new StringBuilder();
		StringBuilder sbLayerName = new StringBuilder();
		StringBuilder sbLayerGroup = new StringBuilder();
		StringBuilder sbComponentLocation = new StringBuilder();//SPEC: Added by Ajay for Req. no. 36986 
		
		MapList mlEBOMSubList = new MapList();
		//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS

		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
		StringBuilder sbFComponentCount= new StringBuilder();
		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
		try 
		{
			Map objectMap = null;
			Map<String, String> mpSubstituteResult = null;
			MapList mlPhaseEBOMList = null;
			int iParentLevel = 0;
			StringList slParentId = new StringList();
			String sParentId = ConstantsUtil.EMPTY_STRING;

			for(int i =0; i<mapList.size(); i++)
			{
				objectMap = (Map) mapList.get(i);

				iParentLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));

				mpSubstituteResult = new HashMap<String, String>();
				mpEBOMResult = new HashMap<String, String>();
				mlPhaseEBOMList = new MapList();
				sParentId = ConstantsUtil.EMPTY_STRING;
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS	
				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMRev = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMFN = new StringBuilder();
				StringBuilder sbEBOMTitle = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMQTY = new StringBuilder();
				StringBuilder sbEBOMBuom = new StringBuilder();
				StringBuilder sbEBOMCommnts = new StringBuilder();
				StringBuilder sbEBOMState= new StringBuilder();
				StringBuilder sbEBOMStage= new StringBuilder();
				StringBuilder sbEBOMRDOC= new StringBuilder(); ///
				StringBuilder sbEBOMRevRelDt= new StringBuilder();
				StringBuilder sbEBOMTupName= new StringBuilder();		 
				StringBuilder sbMinqty= new StringBuilder();
				StringBuilder sbMaxqty= new StringBuilder();
				StringBuilder sbNetWUOM= new StringBuilder();
				StringBuilder sbNetWet= new StringBuilder();
				StringBuilder sbLoss= new StringBuilder();
				StringBuilder sbMF= new StringBuilder();
				StringBuilder sbGW= new StringBuilder();

				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
				//StringBuilder sbAlt= new StringBuilder();
				StringBuilder sbAltName = new StringBuilder();
				StringBuilder sbAltID = new StringBuilder();
				StringBuilder sbAltType = new StringBuilder();
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END

				StringBuilder sbNet= new StringBuilder();
				StringBuilder sbOSPD= new StringBuilder();
				StringBuilder sbDen= new StringBuilder();
				StringBuilder sbCerti= new StringBuilder();
				//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
				StringBuilder sbRF= new StringBuilder();
				//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END

				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
				StringBuilder sbEBOMSubstitutePart = new StringBuilder();
				StringBuilder sbEBOMSubPartID = new StringBuilder();
				StringBuilder sbEBOMSubPartType = new StringBuilder();
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
				StringBuilder sbComponentCount= new StringBuilder();
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --START
				//while(objectListItr.hasNext())
				//{
				//Map objectMap = (Map) objectListItr.next();
				String sPId =(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sFormulaPropagate = sPId;
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
				String sName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sRevision =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sReleaseDate =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
				String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
				String spgChg =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sFN =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				String sTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sPType =(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sTupName =(String)objectMap.get(ConstantsUtil.TUPNAME);
				String sSubstitute=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
				sSubstitute = sSubstitute.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String sQty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				String sBuom =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				String sComments=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41700-- START
				String sCurrent = (!ConstantsUtil.TYPE_FORMULATIONPART.equalsIgnoreCase(sPType))?util.mapType((String)objectMap.get(ConstantsUtil.SELECT_CURRENT)):(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41700-- END
				String sStage =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				String sRD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				sRD = sRD.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
				String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
				String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
				String strNetWUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
				String strNetWet =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
				//Commented by Ketan for Req. no. 47950
				/*if(null!=strNetWet && strNetWet.isEmpty() || strNetWet.equalsIgnoreCase("0.0")) {
					//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41700-- START
					//strNetWet="0.0";
					strNetWet="0";
					//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41700-- END
				}*/
				
				
				String strLoss =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_VALUE);
				//Commented by Ketan for Req. no. 47950
				/*try
				{
					if(UIUtil.isNotNullAndNotEmpty(strLoss) && strLoss.equals(ConstantsUtil.ZERO_SIZE)){
						String[] arrLoss =strLoss.split(ConstantsUtil.SYMBL_BACKSLASH_DOT);
						strLoss = arrLoss[0];
					}
				}catch(Exception e){
					strLoss=ConstantsUtil.EMPTY_STRING;
				}*/
				//SPEC: <11.24.2020>: Guna Commented for Defect :37442 ## --END

				//String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
				String strMF =ConstantsUtil.EMPTY_STRING;
				String strMFObjId =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);

				try
				{
					if (UIUtil.isNotNullAndNotEmpty(strMFObjId)) 
					{
						strMF=util.getIdFromPhysicalIdFunction(context,strMFObjId);
					}
				}catch(Exception e){
					strMF=ConstantsUtil.EMPTY_STRING;
				}


				String strGW =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);

				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
				//String strAlt =(String)objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
				//strAlt = strAlt.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
				strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strAltID = util.checkAlternateHasAccess(context,objectMap);	
				String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
				strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END

				//SPEC: <11.24.2020>: Guna Commented for Defect :37442 ## --START
				//String strNet =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
				String strNet =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_VALUE);
				//Commented by Ketan for Req. no. 47950
				/*try
				{
					if(UIUtil.isNotNullAndNotEmpty(strNet) && strNet.equals(ConstantsUtil.ZERO_SIZE)){
						String[] arrNet =strNet.split(ConstantsUtil.SYMBL_BACKSLASH_DOT);
						strNet = arrNet[0];
					}
				}catch(Exception e){
					strNet=ConstantsUtil.EMPTY_STRING;
				}*/

				//SPEC: <11.24.2020>: Guna Commented for Defect :37442 ## --START
				String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END

				String strOSPD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
				String strDenUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);

				
				String strCertifications =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.CERTIFICATION_NAME));

				try
				{
					DomainObject dObj= new DomainObject(sPId);
					
					Access access = dObj.getAccessMask(context);
					//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- START
					dObj.close(context);
					//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- END
					boolean hasModifyAccess = access.hasReadAccess();

					if(hasModifyAccess && (ConstantsUtil.TYPE_RAWMATERIALPART.equalsIgnoreCase(sPType) ||
							ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART.equalsIgnoreCase(sPType)))
					{
						if(UIUtil.isNotNullAndNotEmpty(strCertifications)) 
						{
							strCertifications=strCertifications;
						}else {
							strCertifications=ConstantsUtil.SYMBL_NO;
						}
					}else{
						strCertifications=ConstantsUtil.EMPTY_STRING;
					}

				}catch(Exception e){

					strCertifications=ConstantsUtil.EMPTY_STRING;
				}


				//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START

				//SPEC: <11.22.2020>: Guna Commented for Null check  ## --START
				//String strRF =(String)objectMap.get(ConstantsUtil.REPORTED_FUNCTION);
				String strRF = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.REPORTED_FUNCTION)));

				//SPEC: <11.22.2020>: Guna Commented for Null check ## --END
				//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
				String strCC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOMPONENTQUANTITY);
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
				String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
				
				// Added by Jwala for the req 41754 22x Template Fix -- START
				String strGrossWeightReal = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
				String strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
				String strManufacturingStatus = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_PGLIFECYCLE_STATUS));
				//Added by Ketan for Req. no. 46464 -- START
				String strMaterialRestriction  = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))? (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
				String strMRComments = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))? (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
				//Added by Ketan for Req. no. 46464 -- START
				String strLayerName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LAYERNAME));
				// Added by Jwala for the req 41754 22x Template Fix -- START
				String strLayerGroup = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LAYERGROUP));
				//SPEC: Added by Ajay for Req. no. 36986 - START
				String strComponentLocation = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENT_LOCATION));
				//SPEC: Added by Ajay for Req. no. 36986 - END
				//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
				String sEBOMParentId =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID);
				String sEBOMParentName =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME);
				String sEBOMParentRevision =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV);
				String sEBOMParentType =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE);
				//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				boolean bHasOwnership = false;
				if(util.isModificatinRequired())
				{
					bHasOwnership = util.checkHasAccess(context, null, sPId);
					if(!bHasOwnership)
					{
						spgChg = ConstantsUtil.NO_ACCESS;
					}
					else{
						showData =true;
					}
				}
				else{

					showData=util.checkHasAccess(context, sct.getUserType(),sPId);
				}
				if(!showData){
					spgChg = ConstantsUtil.NO_ACCESS;
					sPId = ConstantsUtil.NO_ACCESS;
				}
				
				//Added by Ketan for Internal Defect -- START
				boolean bHasOwnershipParent = false;
				boolean showDataParent = false;
				if(validator.isNotNullOrEmpty(sParentId)) {
					if(util.isModificatinRequired())
					{
						bHasOwnershipParent = util.checkHasAccess(context, null, sParentId);

						if(!bHasOwnershipParent)
						{
							sParentId = ConstantsUtil.NO_ACCESS;
						}
					}else if(sct.isStaffAUGUser())
					{
						showDataParent = util.checkHasAccess(context, null, sParentId);
					}else
					{	
						showDataParent = util.checkHasAccess(context, null, sParentId);
					}

					if(!util.isModificatinRequired()) {
						if(!showDataParent){
							sParentId = ConstantsUtil.NO_ACCESS;
						}
					}
					
				}
				//Added by Ketan for Internal Defect -- END

				sPType = util.mapType(sPType);
				sEBOMParentType = util.mapType(sEBOMParentType);
				mlPhaseEBOMList.add(objectMap);
				if(!sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1) {
					util.formatData(sbFEBOMType,sPType);
					util.formatData(sbFEBOMRev,sRevision);
					util.formatData(sbFEBOMName,sName);
					util.formatData(sbFEBOMQTY,sQty);
					util.formatData(sbFEBOMBuom,sBuom);
					util.formatData(sbFEBOMState,sCurrent);
					util.formatData(sbFEBOMStage,sStage);
					util.formatData(sbFEBOMId,sPId);
					util.formatData(sbFEBOMChg,spgChg);
					util.formatData(sbFEBOMFN,sFN);
					util.formatData(sbFEBOMTitle,sTitle);
					util.formatData(sbFEBOMCommnts,sComments);
					util.formatData(sbFEBOMRDOC,sRDOC);
					util.formatData(sbFEBOMRevRelDt,sRevRelease);
					util.formatData(sbFMinqty,strMinqty);
					util.formatData(sbFMaxqty,strMaxqty);
					util.formatData(sbFNetWUOM,strNetWUOM);
					util.formatData(sbFNetWet,strNetWet);
					util.formatData(sbFLoss,strLoss);
					util.formatData(sbFMF,strMF);
					util.formatData(sbFGW,strGW);
					util.formatData(sbFAltName,strAltName);
					util.formatData(sbFAltID,strAltID);
					util.formatData(sbFAltType,strAltType);
					util.formatData(sbFNet,strNet);
					util.formatData(sbFOSPD,strOSPD);
					util.formatData(sbFDen,strDenUOM);
					util.formatData(sbFCerti,strCertifications);
					util.formatData(sbFRF, strRF);
					util.formatData(sbFEBOMSubstitutePart, strSubPart);
					util.formatData(sbFEBOMSubPartID, strSubPartId);
					util.formatData(sbFEBOMSubPartType, strSubPartType);
					//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
					util.formatData(sbFComponentCount, strCC);
					//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
					//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
					util.formatData(sbEBOMParentId,sEBOMParentId);
					util.formatData(sbEBOMParentName,sEBOMParentName);
					util.formatData(sbEBOMParentRevision,sEBOMParentRevision);
					util.formatData(sbEBOMParentType,sEBOMParentType);
					//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
					// Added by Jwala for the req 41754 22x Template Fix -- START
					util.formatData(sbGrossWeightReal, strGrossWeightReal);
					util.formatData(sbGrossWeightUOM, strGrossWeightUOM);
					util.formatData(sbManufacturingStatus, strManufacturingStatus);
					util.formatData(sbMaterialRestriction, strMaterialRestriction);
					util.formatData(sbMRComments, strMRComments);
					util.formatData(sbLayerName, strLayerName);
					// Added by Jwala for the req 41754 22x Template Fix -- END
					//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
					util.formatData(sbLayerGroup, strLayerGroup);
					//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
					util.formatData(sbComponentLocation, strComponentLocation);//SPEC: Added by Ajay for Req. no. 36986 
					
					if(null!=sTupName && !sTupName.isEmpty()) {
						util.formatData(sbFEBOMTupName,sTupName);
					}

					if(!mlPhaseEBOMList.isEmpty()) {
						mlEBOMSubList.addAll(mlPhaseEBOMList);
					}

				} else {
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
					util.formatData(sbEBOMType,sPType);
					util.formatData(sbEBOMRev,sRevision);
					util.formatData(sbEBOMName,sName);
					util.formatData(sbEBOMQTY,sQty);
					util.formatData(sbEBOMBuom,sBuom);
					util.formatData(sbEBOMState,sCurrent);

					util.formatData(sbEBOMStage,sStage);
					util.formatData(sbEBOMId,sPId);
					util.formatData(sbEBOMChg,spgChg);
					util.formatData(sbEBOMFN,sFN);
					util.formatData(sbEBOMTitle,sTitle);
					//util.formatData(sbEBOMSubstute,sSubstitute);
					util.formatData(sbEBOMCommnts,sComments);
					util.formatData(sbEBOMRDOC,sRDOC);
					util.formatData(sbEBOMRevRelDt,sRevRelease);
					util.formatData(sbMinqty,strMinqty);
					util.formatData(sbMaxqty,strMaxqty);
					util.formatData(sbNetWUOM,strNetWUOM);
					util.formatData(sbNetWet,strNetWet);
					util.formatData(sbLoss,strLoss);
					util.formatData(sbMF,strMF);
					util.formatData(sbGW,strGW);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//util.formatData(sbAlt,strAlt);
					util.formatData(sbAltName,strAltName);
					util.formatData(sbAltID,strAltID);
					util.formatData(sbAltType,strAltType);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					util.formatData(sbNet,strNet);
					util.formatData(sbOSPD,strOSPD);
					util.formatData(sbDen,strDenUOM);
					util.formatData(sbCerti,strCertifications);

					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
					util.formatData(sbRF, strRF);
					util.formatData(sbEBOMSubstitutePart, strSubPart);
					util.formatData(sbEBOMSubPartID, strSubPartId);
					util.formatData(sbEBOMSubPartType, strSubPartType);
					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
					//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
					util.formatData(sbComponentCount, strCC);
					//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
					//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
					util.formatData(sbEBOMParentId,sEBOMParentId);
					util.formatData(sbEBOMParentName,sEBOMParentName);
					util.formatData(sbEBOMParentRevision,sEBOMParentRevision);
					util.formatData(sbEBOMParentType,sEBOMParentType);
					//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
					// Added by Jwala for the req 41754 22x Template Fix -- START
					util.formatData(sbGrossWeightReal, strGrossWeightReal);
					util.formatData(sbGrossWeightUOM, strGrossWeightUOM);
					util.formatData(sbManufacturingStatus, strManufacturingStatus);
					util.formatData(sbMaterialRestriction, strMaterialRestriction);
					util.formatData(sbMRComments, strMRComments);
					util.formatData(sbLayerName, strLayerName);
					// Added by Jwala for the req 41754 22x Template Fix -- END
					//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
					util.formatData(sbLayerGroup, strLayerGroup);
					//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
					util.formatData(sbComponentLocation, strComponentLocation);//SPEC: Added by Ajay for Req. no. 36986
					
					if(null!=sTupName && !sTupName.isEmpty()) {
						util.formatData(sbEBOMTupName,sTupName);
					}
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
				}
				//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS

				//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
				int j = 0;
				int iNextLevel = 0;
				Map objectMaps =null;
				//SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --START
				//if(sPType.equals(ConstantsUtil.TYPE_PGPHASE) || iParentLevel == 1){
				if(sPType.equals(ConstantsUtil.TYPE_PGPHASE)){
					sParentId=sFormulaPropagate;
					//SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --ENDS

					for(j =i+1; j<mapList.size(); j++)
					{
						iNextLevel = 0;
						objectMaps = (Map) mapList.get(j);
						int iCurrLevel = Integer.parseInt((String) objectMaps.get(ConstantsUtil.SELECT_LEVEL));
						if(j < mapList.size()-1) {
							Map objectNxtMaps = (Map) mapList.get(j+1);
							iNextLevel = Integer.parseInt((String) objectNxtMaps.get(ConstantsUtil.SELECT_LEVEL));
						}
						if((iParentLevel+1 == iCurrLevel) && sPType.equals(ConstantsUtil.TYPE_PGPHASE)) {

							mlPhaseEBOMList.add(objectMaps);
							String sId =(String)objectMaps.get(ConstantsUtil.SELECT_ID);
							sName =(String)objectMaps.get(ConstantsUtil.SELECT_NAME);
							sRevision =(String)objectMaps.get(ConstantsUtil.SELECT_REVISION);
							sReleaseDate =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
							sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
							spgChg =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
							sFN =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
							sTitle =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							String sType =(String)objectMaps.get(ConstantsUtil.SELECT_TYPE);
							sTupName =(String)objectMaps.get(ConstantsUtil.TUPNAME);
							sSubstitute=(String)objectMaps.get(ConstantsUtil.SELECT_SUBSTITUTE);
							sSubstitute = sSubstitute.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
							sQty =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
							sBuom =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
							sComments=(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
							//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41700-- START
							//sCurrent = (!ConstantsUtil.TYPE_FORMULATIONPART.equalsIgnoreCase(sPType))?util.mapType((String)objectMaps.get(ConstantsUtil.SELECT_CURRENT)):(String)objectMaps.get(ConstantsUtil.SELECT_CURRENT);
							sCurrent = (!ConstantsUtil.TYPE_FORMULATIONPART.equalsIgnoreCase(sPType))?util
									.mapType((String)objectMaps
									.get(ConstantsUtil.SELECT_CURRENT)):(String)objectMaps
									.get(ConstantsUtil.SELECT_CURRENT);
							//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41700-- END
							sStage =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
							sRD =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
							sRD = sRD.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
							sOC =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
							sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
							sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
							strMinqty =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
							strMaxqty =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
							strNetWUOM =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
							strNetWet =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
							/*if(null!=strNetWet && strNetWet.isEmpty() || strNetWet.equalsIgnoreCase("0.0")) {
								//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41700-- START
								//strNetWet="0.0";
								strNetWet="0";
								//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41700-- END
							}*/
							strLoss =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_VALUE);
							/*try
							{
								if(UIUtil.isNotNullAndNotEmpty(strLoss) && strLoss.equals(ConstantsUtil.ZERO_SIZE)){
									String[] arrLoss =strLoss.split(ConstantsUtil.SYMBL_BACKSLASH_DOT);
									strLoss = arrLoss[0];
								}
							}catch(Exception e){
								strLoss=ConstantsUtil.EMPTY_STRING;
							}*/
							strMF =ConstantsUtil.EMPTY_STRING;
							strMFObjId =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);

							try
							{
								if (UIUtil.isNotNullAndNotEmpty(strMFObjId)) 
								{
									strMF=util.getIdFromPhysicalIdFunction(context,strMFObjId);
								}
							}catch(Exception e){
								strMF=ConstantsUtil.EMPTY_STRING;
							}
							strGW =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);
							strAltName =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
							strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strAltID = util.checkAlternateHasAccess(context,objectMaps);	
							strAltType =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
							strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strNet =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_VALUE);
							/*try
							{
								if(UIUtil.isNotNullAndNotEmpty(strNet) && strNet.equals(ConstantsUtil.ZERO_SIZE)){
									String[] arrNet =strNet.split(ConstantsUtil.SYMBL_BACKSLASH_DOT);
									strNet = arrNet[0];
								}
							}catch(Exception e){
								strNet=ConstantsUtil.EMPTY_STRING;
							}*/

							strSubPart = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strSubPartId = util.checkSubstituteHasAccess(context,objectMaps);
							strOSPD =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
							strDenUOM =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
							strCertifications =(String)objectMaps.get(ConstantsUtil.CERTIFICATION_NAME);
							//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
							strCC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOMPONENTQUANTITY);
							//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END

							try
							{
								DomainObject dObj= new DomainObject(sId);
								
								Access access = dObj.getAccessMask(context);
								//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- START
								dObj.close(context);
								//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- END
								boolean hasModifyAccess = access.hasReadAccess();

								if(hasModifyAccess && (ConstantsUtil.TYPE_RAWMATERIALPART.equalsIgnoreCase(sType) ||
										ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART.equalsIgnoreCase(sType)))
								{
									if(UIUtil.isNotNullAndNotEmpty(strCertifications)) 
									{
										strCertifications=strCertifications;
									}else {
										strCertifications=ConstantsUtil.SYMBL_NO;
									}
								}else{
									strCertifications=ConstantsUtil.EMPTY_STRING;
								}

							}catch(Exception e){

								strCertifications=ConstantsUtil.EMPTY_STRING;
							}

							strRF = validator.getStringEquivalentForStringList((objectMaps.get(ConstantsUtil.REPORTED_FUNCTION)));

							strClassFied = validator.getStringEquivalentForStringList((objectMaps.get(ConstantsUtil.STR_IPCLASS)));
							showData = false;
							bHasOwnership = false;
							if(util.isModificatinRequired())
							{
								/*String sFormulaPropagate = sId;
									if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										sFormulaPropagate = util.getFormulaPropagate(context, sId);
									}

									if(!sFormulaPropagate.isEmpty()) {
										bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
									}*/
								//modified by Ganesh for Security impl strat
								bHasOwnership = util.checkHasAccess(context, null, sId);
								
								
								////modified by Ganesh for Security impl end
								if(!bHasOwnership)
								{
									spgChg = ConstantsUtil.NO_ACCESS;
									sId = ConstantsUtil.NO_ACCESS;
									sQty = ConstantsUtil.NO_ACCESS;
									
								}
								else{
										showData =true;
									}
							}
							else{
								showData = util.checkHasAccess(context, null, sId);
							}

							if(!showData){
								spgChg = ConstantsUtil.NO_ACCESS;
								sId = ConstantsUtil.NO_ACCESS;	
							}
							sType = util.mapType(sType);

							util.formatData(sbEBOMType,sType);
							util.formatData(sbEBOMRev,sRevision);
							util.formatData(sbEBOMName,sName);
							util.formatData(sbEBOMQTY,sQty);
							util.formatData(sbEBOMBuom,sBuom);
							util.formatData(sbEBOMState,sCurrent);
							util.formatData(sbEBOMStage,sStage);
							util.formatData(sbEBOMId,sId);
							util.formatData(sbEBOMChg,spgChg);
							util.formatData(sbEBOMFN,sFN);
							util.formatData(sbEBOMTitle,sTitle);
							util.formatData(sbEBOMCommnts,sComments);
							util.formatData(sbEBOMRDOC,sRDOC);
							util.formatData(sbEBOMRevRelDt,sRevRelease);
							util.formatData(sbMinqty,strMinqty);
							util.formatData(sbMaxqty,strMaxqty);
							util.formatData(sbNetWUOM,strNetWUOM);
							util.formatData(sbNetWet,strNetWet);
							util.formatData(sbLoss,strLoss);
							util.formatData(sbMF,strMF);
							util.formatData(sbGW,strGW);
							util.formatData(sbAltName,strAltName);
							util.formatData(sbAltID,strAltID);
							util.formatData(sbAltType,strAltType);
							util.formatData(sbNet,strNet);
							util.formatData(sbOSPD,strOSPD);
							util.formatData(sbDen,strDenUOM);
							util.formatData(sbCerti,strCertifications);
							util.formatData(sbRF, strRF);
							util.formatData(sbEBOMSubstitutePart, strSubPart);
							util.formatData(sbEBOMSubPartID, strSubPartId);
							util.formatData(sbEBOMSubPartType, strSubPartType);

							//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
							util.formatData(sbComponentCount, strCC);
							//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
							if(null!=sTupName && !sTupName.isEmpty()) {
								util.formatData(sbEBOMTupName,sTupName);
							}
						}
						//SPEC: <01.21.2021>: Modified for Defect : 38181 by Sumit --START
						if(iParentLevel+1 > iNextLevel || iParentLevel == iCurrLevel) {
							//SPEC: <01.21.2021>: Added for Defect : 38181 by Sumit --ENDS	
							break;
						} 		
					}
					
					mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
					mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
					mpEBOMResult.put(ConstantsUtil.REVISION, sbEBOMRev.toString());
					mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
					mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
					mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
					mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
					//mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
					mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
					mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
					mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
					mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
					mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
					mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
					mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
					mpEBOMResult.put(ConstantsUtil.MIN, sbMinqty.toString());
					mpEBOMResult.put(ConstantsUtil.MAX, sbMaxqty.toString());
					mpEBOMResult.put(ConstantsUtil.NETWEIGHTUOM, sbNetWUOM.toString());
					mpEBOMResult.put(ConstantsUtil.NETWEIGHT, sbNetWet.toString());
					mpEBOMResult.put(ConstantsUtil.LOSS, sbLoss.toString());
					//SPEC: <02.01.2021>: Modified for Defect: 38377/38379 by Sumit --START
					//mpEBOMResult.put(ConstantsUtil.MATERIALFUNCTION, sbMF.toString());
					mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbMF.toString());
					//SPEC: <02.01.20211>: Added for Defect: 38377/38379 by Sumit --ENDS
					mpEBOMResult.put(ConstantsUtil.GW, sbGW.toString());
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//mpEBOMResult.put(ConstantsUtil.ALT, sbAlt.toString());
					mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
					mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
					mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					mpEBOMResult.put(ConstantsUtil.NET, sbNet.toString());
					mpEBOMResult.put(ConstantsUtil.OSPD, sbOSPD.toString());
					mpEBOMResult.put(ConstantsUtil.DUOM, sbDen.toString());
					mpEBOMResult.put(ConstantsUtil.CERTIFICATION, sbCerti.toString());

					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
					mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbRF.toString());
					mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
					mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
					mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
					//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
					mpEBOMResult.put(ConstantsUtil.COMPONENTCOUNT, sbComponentCount.toString());
					//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
					
					// Added by Jwala for the req 41754 22x Template Fix -- START
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
					//SPEC: 16-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50049-- START
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbNetWUOM.toString());
					//SPEC: 16-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50049-- END
					mpEBOMResult.put(ConstantsUtil.MANUFACTURINGSTATUS, sbManufacturingStatus.toString());
					//Added by Ketan for Req. no. 46464 - START
					//mpEBOMResult.put(ConstantsUtil.MATERIALRESTRICTION, sbMaterialRestriction.toString());
					//mpEBOMResult.put(ConstantsUtil.MATERIALRESTRICTIONCOMMENTS, sbMRComments.toString());
					mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbMaterialRestriction.toString());
					mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbMRComments.toString());
					//Added by Ketan for Req. no. 46464 - END
					mpEBOMResult.put(ConstantsUtil.LAYERNAME, sbLayerName.toString());
					// Added by Jwala for the req 41754 22x Template Fix -- END
					//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
					mpEBOMResult.put(ConstantsUtilIRM.LAYERGROUP, sbLayerGroup.toString());
					//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
					mpEBOMResult.put(ConstantsUtilIRM.COMPONENTLOCATION, sbComponentLocation.toString());//SPEC: Added by Ajay for Req. no. 36986
					if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
						mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
					}
					//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
				}

				//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --START
				if(!mpEBOMResult.isEmpty() && validator.isNotNullOrEmpty(sParentId) && (!slParentId.contains(sParentId) || (slParentId.contains(sParentId) && !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1))) {
					//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --ENDS
					slParentId.add(sParentId);
					mpFinalEBOM.put(String.valueOf(index), mpEBOMResult);
					//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --START
					if(!mlPhaseEBOMList.isEmpty()) {
						//mpFinalSubstitute.put(String.valueOf(index), mpSubstituteResult);
						mlEBOMSubList.addAll(mlPhaseEBOMList);
					}
					//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --ENDS
					index++;
				}
			}
			//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
			mpEBOMResult = new HashMap();
			if(null != sbFEBOMId && sbFEBOMId.length()>0) {
				mpEBOMResult.put(ConstantsUtil.ID, sbFEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbFEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.REVISION, sbFEBOMRev.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbFEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.FN, sbFEBOMFN.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbFEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbFEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbFEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbFEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbFEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.STATE, sbFEBOMState.toString());
				mpEBOMResult.put(ConstantsUtil.PHASE, sbFEBOMStage.toString());
				mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbFEBOMRDOC.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbFEBOMRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.MIN, sbFMinqty.toString());
				mpEBOMResult.put(ConstantsUtil.MAX, sbFMaxqty.toString());
				mpEBOMResult.put(ConstantsUtil.NETWEIGHTUOM, sbFNetWUOM.toString());
				mpEBOMResult.put(ConstantsUtil.NETWEIGHT, sbFNetWet.toString());
				mpEBOMResult.put(ConstantsUtil.LOSS, sbFLoss.toString());
				mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbFMF.toString());
				mpEBOMResult.put(ConstantsUtil.GW, sbFGW.toString());
				mpEBOMResult.put(ConstantsUtil.ALTNAME, sbFAltName.toString());
				mpEBOMResult.put(ConstantsUtil.ALTID, sbFAltID.toString());
				mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbFAltType.toString());
				mpEBOMResult.put(ConstantsUtil.NET, sbFNet.toString());
				mpEBOMResult.put(ConstantsUtil.OSPD, sbFOSPD.toString());
				mpEBOMResult.put(ConstantsUtil.DUOM, sbFDen.toString());
				mpEBOMResult.put(ConstantsUtil.CERTIFICATION, sbFCerti.toString());

				mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbFRF.toString());
				mpEBOMResult.put(ConstantsUtil.SP, sbFEBOMSubstitutePart.toString());
				mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbFEBOMSubPartType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbFEBOMSubPartID.toString());
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
				mpEBOMResult.put(ConstantsUtil.COMPONENTCOUNT, sbFComponentCount.toString());
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
				// Added by Jwala for the req 41754 22x Template Fix -- START
				mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
				//SPEC: 16-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50049-- START
				mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbFNetWUOM.toString());
				//SPEC: 16-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50049-- START
				mpEBOMResult.put(ConstantsUtil.MANUFACTURINGSTATUS, sbManufacturingStatus.toString());
				//Added by Ketan for Req. no. 46464 - START
				//mpEBOMResult.put(ConstantsUtil.MATERIALRESTRICTION, sbMaterialRestriction.toString());
				//mpEBOMResult.put(ConstantsUtil.MATERIALRESTRICTIONCOMMENTS, sbMRComments.toString());
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbMaterialRestriction.toString());
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbMRComments.toString());
				//Added by Ketan for Req. no. 46464 - END
				mpEBOMResult.put(ConstantsUtil.LAYERNAME, sbLayerName.toString());
				// Added by Jwala for the req 41754 22x Template Fix -- END
				//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
				mpEBOMResult.put(ConstantsUtilIRM.LAYERGROUP, sbLayerGroup.toString());
				//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
				mpEBOMResult.put(ConstantsUtilIRM.COMPONENTLOCATION, sbComponentLocation.toString());//SPEC: Added by Ajay for Req. no. 36986
				//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
				//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
				if (null != sbFEBOMTupName && sbFEBOMTupName.length()>0) {
					mpEBOMResult.put(ConstantsUtil.TUPNAME, sbFEBOMTupName.toString());
				}
				if(!mpEBOMResult.isEmpty()) {
					mpFinalEBOM.put(String.valueOf(0), mpEBOMResult);
				}
			}
			mpSubstituteResult = parseSubstitute(context,mlEBOMSubList, bGendocView);
			if(!mpSubstituteResult.isEmpty()) {
				HashMap mpSubstitute = new HashMap();
				mpSubstitute.put(String.valueOf(0), mpSubstituteResult);
				mpFinalSubstitute.put(String.valueOf(0), mpSubstitute);
			}

			//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS

			MPFinalEBOMSubStitute.put(ConstantsUtil.BILLOFMATERIALS, mpFinalEBOM);
			MPFinalEBOMSubStitute.put(ConstantsUtil.SUBSTITUTEPARTS, mpFinalSubstitute);

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("Exception in APPBO:  parseMaplist: " + e);
		}
		return MPFinalEBOMSubStitute;
		//return util.filterMapList(mpEBOMResult);
		//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS		
	}


	/**
	 * Method Name 			: getPlantBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getPlantBusSelectable(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		return busSelect;
	}


	/**
	 * Method Name 			: getPlantRelSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getPlantRelSelectable(Context context) {

		StringList relSelect = new StringList(2);
		relSelect.add(ConstantsUtil.ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
		relSelect.add(ConstantsUtil.ATTRIBUTE_PGISAUTHORIZEDTOUSE);
		return relSelect;
	}


	/**
	 * Method Name 			: getDangerousgoodsSpecSelects
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getDangerousgoodsSpecSelects(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);

		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

		return busSelect;
	}


	/**
	 * Method Name 			: getGlobalHarmonizedStandard
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getGlobalHarmonizedStandard(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID);

		return busSelect;
	}


	/**
	 * Method Name 			: getStabilityResults
	 * Method Description 	: Fetching "Stability" related data
	 * @param context
	 * @return
	 */
	public static StringList getStabilityResults(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS);

		return busSelect;
	}


	/**
	 * Method Name 			: addMultiSelects
	 * Method Description 	: 
	 */
	public StringList addMultiSelects()
	{

		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_PNGLPDMODELTYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_PNGDEFINITION);

		slMultiSelects.add(ConstantsUtil.COMP_TYPE);
		slMultiSelects.add(ConstantsUtil.COMP_ID);
		slMultiSelects.add(ConstantsUtil.COMP_NAME);  
		slMultiSelects.add(ConstantsUtil.COMP_REVS);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC); 
		slMultiSelects.add(ConstantsUtil.COMP_TITLE); 
		slMultiSelects.add(ConstantsUtil.COMP_STATE); 
		slMultiSelects.add(ConstantsUtil.COMP_CASNUM);  		
		slMultiSelects.add(ConstantsUtil.COMP_SUBNAME);  		
		slMultiSelects.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		slMultiSelects.add(ConstantsUtil.COMP_ISCONTAM);  		
		slMultiSelects.add(ConstantsUtil.COMP_QTY);  			
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);  
		slMultiSelects.add(ConstantsUtil.COMP_METALENVCLASS); 
		slMultiSelects.add(ConstantsUtil.COMP_POSTCONSUMER); 
		slMultiSelects.add(ConstantsUtil.COMP_MANUF);  		
		slMultiSelects.add(ConstantsUtil.COMP_COMENT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MARKETNAME);  	
		slMultiSelects.add(ConstantsUtil.COMP_SEQUENCE);  		
		slMultiSelects.add(ConstantsUtil.COMP_MATELAYER);
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_ORIGINSOURCE);

		slMultiSelects.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		slMultiSelects.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_NAME); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_CT_NUM); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS); 	
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_MANU_SITE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PACK_SITE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PLANT_REST); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REG_DATE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REG_STATUS); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY);
		//SPEC: 10/21/2020: Added for req 18x.5 ## -- START
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALLEADTIME);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALSTATUS);

		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		//SPEC: 10/21/2020: Added for req 18x.5 ## -- END


		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID);

		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE);

		// Guna Added for Defect 38531  18x.5.2 Release -- START
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		// Guna Added for Defect 38531  18x.5.2 Release -- END

		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Jwala -- START
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Jwala -- END
		// SPEC <16/03/2021>Guna Added for Defect 41021  18x.6 Release -- START
		slMultiSelects.add(ConstantsUtil.SELECT_REL_SHIPPINGCLASSIF);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS);
		slMultiSelects.add(ConstantsUtil.strIntendedMarket);
		// SPEC <16/03/2021>Guna Added for Defect 41021  18x.6 Release -- END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
		
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR);

		return slMultiSelects;
	}


	/**
	 * Method Name 			: removeMultiSelects
	 * Method Description 	: For removing the multiselects from DomainCOnstants
	 */
	public void removeMultiSelects()
	{

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SUBNAME);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QSTCOMPOSITE);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ISCONTAM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_METALENVCLASS); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_POSTCONSUMER); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MANUF);  	

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_COMENT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MARKETNAME);  	
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SEQUENCE);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MATELAYER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ORIGINSOURCE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_NAME); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_CT_NUM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS); 	
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_MANU_SITE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PACK_SITE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PLANT_REST); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REG_DATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REG_STATUS); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY);
		//SPEC: 10/21/2020: Added for req 18x.5 ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALLEADTIME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALSTATUS);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC: 10/21/2020: Added for req 18x.5 ## -- END

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASEDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE);

		//SPEC: Commented for Defect#37664 1.0.2 Release - Jwala -- START
		/*DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_APPNAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_APPREVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_APPTYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE__RELEASE_APPPHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_APPSTATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_APPDESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_APPCERTIFICATIONS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_APPID);*/
		//SPEC: Commented for Defect#37664 1.0.2 Release - Jwala -- END

		// Guna Added for Defect 38531  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		// Guna Added for Defect 38531  18x.5.2 Release -- END

		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Jwala -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Jwala -- END
		// SPEC <16/03/2021>Guna Added for Defect 41021  18x.6 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_SHIPPINGCLASSIF);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.strIntendedMarket);
		// SPEC <16/03/2021>Guna Added for Defect 41021  18x.6 Release -- END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END

	}


	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	: 
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sType, String sID, String sCreatedDate, String sCreator,DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();


		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, getTo, getFrom, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			/*if(mlDerivedList.isEmpty()){
				return new HashMap();
			}*/
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			StringBuilder sbDerivedType = new StringBuilder();
			StringBuilder sbSourceType=new StringBuilder();
			StringBuilder sbDerivedId = new StringBuilder();
			StringBuilder sbSourceId=new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDerivedId=(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sDerivedType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);

					util.formatData(sbDerivedType,sType);
					util.formatData(sbSourceType,sDerivedType);

					util.formatData(sbDerivedId,sID);
					util.formatData(sbSourceId,sDerivedId);
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);

					util.formatData(sbDerivedType,sDerivedType);
					util.formatData(sbSourceType,sType);

					util.formatData(sbDerivedId,sDerivedId);
					util.formatData(sbSourceId,sID);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sCreator);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);

			}
			mpDerived.put(ConstantsUtil.SOURCETYPE, sbSourceType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDTYPE, sbDerivedType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDID, sbDerivedId.toString());
			mpDerived.put(ConstantsUtil.SOURCEID, sbSourceId.toString());
			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : IRMSBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return mpDerived;
	}

	
	public Map<String, String> parseSubstitute(Context context,MapList mapList, boolean bGendocView) throws Exception
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = null;
		Map mpFinal = new HashMap();
		try {
			Iterator objectListItr = mapList.iterator();

			SecurityService sct = new SecurityService();
			mpEBOMResult = new HashMap<String,String>();
			StringBuilder sbEBOMName = new StringBuilder();
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentRev = new StringBuilder();
			StringBuilder sbEBOMParentTitle = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			StringBuilder sbEBOMRefDoc= new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMCommnts = new StringBuilder();
			StringBuilder sbEBOMSubType= new StringBuilder();
			StringBuilder sbEBOMEffectDate= new StringBuilder();
			StringBuilder sbEBOMUntilDate= new StringBuilder();
			StringBuilder sbEBOMCobNum= new StringBuilder();
			StringBuilder sbEBOMChildRev= new StringBuilder();
			StringBuilder sbEBOMRevRelDt= new StringBuilder();
			StringBuilder sbEBOMSubFor= new StringBuilder();
			StringBuilder sbEBOMParentType = new StringBuilder();
			StringBuilder sbEBOMChg = new StringBuilder();
			StringBuilder sbEBOMSFSubType= new StringBuilder();
			StringBuilder sbMinqty= new StringBuilder();
			StringBuilder sbMaxqty= new StringBuilder();
			StringBuilder sbRF= new StringBuilder();
			StringBuilder sbMF= new StringBuilder();
			StringBuilder sbCerti= new StringBuilder();
			StringBuilder sbComponentCount= new StringBuilder();
			StringBuilder sbManufacturingStatus = new StringBuilder();
			//Added by Subhajit for Req 46464 - Start
			StringBuilder sbRelRestriction = new StringBuilder();
			StringBuilder sbRelRestrictionComment = new StringBuilder();
			//StringBuilder sbMaterialRestriction = new StringBuilder();
			//StringBuilder sbMRComments = new StringBuilder();
			//Added by Subhajit for Req 46464 - End
			StringBuilder sbLayerName = new StringBuilder();
			StringBuilder sbLayerGroup = new StringBuilder();
			StringBuilder sbComponentLocation = new StringBuilder();//SPEC: Added by Ajay for Req. no. 36986
			while(objectListItr.hasNext())
			{

				Map objectMap = (Map) objectListItr.next();
				boolean showData = false;
				boolean bHasOwnership=false;
				boolean bProjectLicense=false;
				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
				if(null!=objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {

					String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
					if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
						//String
						if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
							String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
							String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
							String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
							String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
							String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
							String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
							String strCertifications =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.CERTIFICATION_NAME));
							
							//Added by Jwala for the req 22x 41754 - START
							String strManufacturingStatus =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_PGLIFECYCLE_STATUS));
							//Added by Subhajit for Req 46464 - Start
							//String strMaterialRestriction  = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION));
							//String strMRComments = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALRESTRICTIONCOMMENTS));
							String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
							String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
							// Added by Jwala for the req 41754 22x Template Fix -- START
							//Added by Subhajit for Req 46464 - End
							//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
							String strLayerName = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LAYERNAME));
							String strLayerGroup = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LAYERGROUP));
							//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
							//SPEC: Added by Ajay for Req. no. 36986 - START
							String strComponentLocation = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENT_LOCATION));
							//SPEC: Added by Ajay for Req. no. 36986 - END
							try
							{
								DomainObject dObj= new DomainObject(sParentID);
								
								Access access = dObj.getAccessMask(context);
								dObj.close(context);
								boolean hasModifyAccess = access.hasReadAccess();

								if(hasModifyAccess && (ConstantsUtil.TYPE_RAWMATERIALPART.equalsIgnoreCase(sParentType) ||
										ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART.equalsIgnoreCase(sParentType)))
								{
									if(UIUtil.isNotNullAndNotEmpty(strCertifications)) 
									{
										strCertifications=ConstantsUtil.SYMBL_YES;

									}else {
										strCertifications=ConstantsUtil.SYMBL_NO;
									}
								}else{
									strCertifications=ConstantsUtil.EMPTY_STRING;
								}

							}catch(Exception e){

								strCertifications=ConstantsUtil.EMPTY_STRING;
							}

							boolean bChildHasAccess =util.checkHasAccess(context, sct.getUserType(),sChildId);

							sReleaseDate =validator.DateFormatter(sReleaseDate);
							String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;

							String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
							String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));


							String sChildTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));

							String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							//SPEC: <06.07.2022>: Manikanta Modified for Req 41754 22x Release  -- START
							String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
							String sOriginatingSource = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_PGORIGINATINGSOURCE));
							if(sOriginatingSource.equalsIgnoreCase(ConstantsUtil.DSO)) {
								if(UIUtil.isNullOrEmpty(sSUBType)) {
									sSUBType = DomainConstants.EMPTY_STRING;
								} 
							} else {
							if ((ConstantsUtil.tRMP).equals(sChildType)) {       
								sSUBType=ConstantsUtil.SPEC_SUB_TYPE;  
							}
							else if ((ConstantsUtil.tIRMS).equals(sChildType)) {       
								sSUBType=ConstantsUtil.SPEC_SUB_TYPE;  
							}
							else if ((ConstantsUtilIRM.TYPE_PGPACKINGMATERIAL).equals(sChildType)) {
								sSUBType=ConstantsUtil.PACKAGING;
							} 
							else {
								sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
							}

							if (ConstantsUtilIRM.FPP_CSSTYPE.equals(sParentType))
							{
								if("".equals(sSUBType)){
									sSUBType=ConstantsUtilIRM.FINISHED_PRODUCT;
								}
								else if(ConstantsUtilIRM.FWIP_FINISHED_WORK_IN_PROCESS.equals(sSUBType)) {
									sSUBType=ConstantsUtilIRM.FWIP_FINISHED_WORK_IN_PROCESS;		
								}
								else if(ConstantsUtilIRM.PURCHASED_SUBASSEMBLY.equals(sSUBType)){
									sSUBType=ConstantsUtilIRM.PURCHASED_SUBASSEMBLY;
								}
								else if(ConstantsUtilIRM.PURCHASED_PRODUCED_SUBASSEMBLY.equals(sSUBType)){
									sSUBType=ConstantsUtilIRM.PURCHASED_PRODUCED_SUBASSEMBLY;	
								}				
							}
							}
							//SPEC: <06.07.2022>: Manikanta Modified for Req 41754 22x Release  -- END
							String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
							String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
							String sEffectvityDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY)));
							String sUntilDate=validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
							String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));

							String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));

							String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
							String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));

							String strProjSecClass = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME));
							String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
							//SPEC: <06.07.2022>: Manikanta Modified for Req 41754 22x Release  -- START
							String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
							if(sOriginatingSource.equalsIgnoreCase(ConstantsUtil.DSO)) {
								if(UIUtil.isNullOrEmpty(sSFSubType)) {
									sSFSubType = DomainConstants.EMPTY_STRING;
								} 
							} else {
							if ((ConstantsUtil.tRMP).equals(sChildType)) {       
								sSFSubType=ConstantsUtil.SPEC_SUB_TYPE;  
							}
							else if ((ConstantsUtil.tIRMS).equals(sChildType)) {       
								sSFSubType=ConstantsUtil.SPEC_SUB_TYPE;  
							}
							else if ((ConstantsUtilIRM.TYPE_PGPACKINGMATERIAL).equals(sChildType)) {
								sSFSubType=ConstantsUtil.PACKAGING;
							} 
					    
							else {
								sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
							}

							if (ConstantsUtilIRM.FPP_CSSTYPE.equals(sParentType))
							{
								if("".equals(sSFSubType)){
									sSFSubType=ConstantsUtilIRM.FINISHED_PRODUCT;
								}
								else if(ConstantsUtilIRM.FWIP_FINISHED_WORK_IN_PROCESS.equals(sSFSubType)) {
									sSFSubType=ConstantsUtilIRM.FWIP_FINISHED_WORK_IN_PROCESS;		
								}
								else if(ConstantsUtilIRM.PURCHASED_SUBASSEMBLY.equals(sSFSubType)){
									sSFSubType=ConstantsUtilIRM.PURCHASED_SUBASSEMBLY;
								}
								else if(ConstantsUtilIRM.PURCHASED_PRODUCED_SUBASSEMBLY.equals(sSFSubType)){
									sSFSubType=ConstantsUtilIRM.PURCHASED_PRODUCED_SUBASSEMBLY;	
								}				
							}
						}
						//SPEC: <06.07.2022>: Manikanta Modified for Req 41754 22x Release  -- END
							
							String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MIN_QUANTITY);
							String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MAX_QUANTITY);
							String strRF =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RF));
							String strCC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOMPONENTQUANTITY);
							String sFunction =ConstantsUtil.EMPTY_STRING;
							String strMFObjId =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);

							try
							{
								if (UIUtil.isNotNullAndNotEmpty(strMFObjId)) 
								{
									sFunction=util.getIdFromPhysicalIdFunction(context,strMFObjId);
								}
							}catch(Exception e){
								sFunction=ConstantsUtil.EMPTY_STRING;
							}
							if(!bChildHasAccess) {
								sChildId    = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
							}

							if(util.isModificatinRequired())
							{
								//Modified by Ganesh for security impl--->strat
								bHasOwnership = util.checkHasAccess(context, null, sParentID);
								//Modified by Ganesh for security impl--->strat
								if(!bHasOwnership)
								{
									sParentID = ConstantsUtil.NO_ACCESS;

								}
							}
							else {
								showData = util.checkHasAccess(context, null, sParentID);
							}
							if(!showData){
								sParentID = ConstantsUtil.NO_ACCESS;
								
							}

							sChildType = util.mapType(sChildType);
							util.formatData(sbEBOMName,sChildName);
							util.formatData(sbEBOMType,util.mapType(sChildType));
							util.formatData(sbEBOMQTY,sQTY);
							util.formatData(sbEBOMBuom,sBASEUOM);
							util.formatData(sbEBOMChildRev,sChildRev);
							util.formatData(sbEBOMParentType,util.mapType(sParentType));
							util.formatData(sbEBOMParentId,sParentID);
							util.formatData(sbEBOMId,sChildId);
							util.formatData(sbEBOMParentName,sParentName);
							util.formatData(sbEBOMParentRev,sParentRev);
							util.formatData(sbEBOMParentTitle,sParentTitle);
							util.formatData(sbEBOMCobNum,sCombinationNum);
							util.formatData(sbEBOMTitle,sChildTitle);
							util.formatData(sbEBOMSubType,sSUBType);
							util.formatData(sbEBOMRevRelDt,sRevRelease);
							util.formatData(sbEBOMEffectDate,sEffectvityDate);
							util.formatData(sbEBOMUntilDate,sUntilDate);
							util.formatData(sbEBOMRefDoc,sRDOC);
							util.formatData(sbEBOMCommnts,sComments);
							util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
							util.formatData(sbEBOMChg,sChg);
							util.formatData(sbEBOMSFSubType,sSFSubType);
							util.formatData(sbRF,strRF);
							util.formatData(sbMF,sFunction);
							util.formatData(sbMinqty,strMinqty);
							util.formatData(sbMaxqty,strMaxqty);
							util.formatData(sbCerti, strCertifications);
							util.formatData(sbComponentCount, strCC);
							//Added by Jwala for the req 22x 41754 - START
							util.formatData(sbManufacturingStatus, strManufacturingStatus);
							//Added by Subhajit for Req 46464 - Start
							//util.formatData(sbMaterialRestriction, strMaterialRestriction);
							//util.formatData(sbMRComments, strMRComments);
							util.formatData(sbRelRestriction, sRelRestriction);
							util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
							//Added by Subhajit for Req 46464 - End
							//Added by Jwala for the req 22x 41754 - END
							//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
							util.formatData(sbLayerName, strLayerName);
							util.formatData(sbLayerGroup, strLayerGroup);
							//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
							util.formatData(sbComponentLocation, strComponentLocation);//SPEC: Added by Ajay for Req. no. 36986
						}
					else{
							showData =true;
						}
					} else {
						//StringList
						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));

						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));

						String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));



						String strProjSecClass = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME));
						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));

						String strCertifications =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.CERTIFICATION_NAME));

						try
						{
							DomainObject dObj= new DomainObject(sParentID);
							
							Access access = dObj.getAccessMask(context);
							dObj.close(context);
							boolean hasModifyAccess = access.hasReadAccess();

							if(hasModifyAccess && (ConstantsUtil.TYPE_RAWMATERIALPART.equalsIgnoreCase(sParentType) ||
									ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART.equalsIgnoreCase(sParentType)))
							{
								if(UIUtil.isNotNullAndNotEmpty(strCertifications)) 
								{
									strCertifications=ConstantsUtil.SYMBL_YES;
								}else {
									strCertifications=ConstantsUtil.SYMBL_NO;
								}
							}else{
								strCertifications=ConstantsUtil.EMPTY_STRING;
							}

						}catch(Exception e){

							strCertifications=ConstantsUtil.EMPTY_STRING;
						}
						showData = util.checkHasAccess(context, null, sParentID);
						String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
							StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
							for(int i =0; i<slChildId.size(); i++) 
							{
								String sEachChildId = slChildId.getElement(i);

								StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
								boolean bChildHasAccess =util.checkHasAccess(context, sct.getUserType(),sEachChildId);

								
								StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
								StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
								StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
								StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
								StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
								StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
								StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
								StringList slEffectvityDate = (StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
								StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
								String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
								StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
								//Added by Jwala for the req 22x 41754 - START
								String sManufacturingStatus=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_PGLIFECYCLE_STATUS));
								//Added by Ketan for Defect no. 52810 - Start
	  							StringList slRelRestriction =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR));
	  							StringList slRelRestrictionComment =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC));
	  							//String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
	  							//String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
	  							//Added by Ketan for Defect no. 52810 - End
								//Added by Jwala for the req 22x 41754 - END
								//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
								String sLayerName=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LAYERNAME));
								String sLayerGroup=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LAYERGROUP));
								//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
								//SPEC: Added by Ajay for Req. no. 36986 - START
								String strComponentLocation = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENT_LOCATION));
								//SPEC: Added by Ajay for Req. no. 36986 - END
								String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
								sOC = util.replaceSpecialSymbols(sOC);
								String sRDOC = slRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
								StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);

								String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
								String strSubType =ConstantsUtil.EMPTY_STRING;
								  if (("pgRawMaterial").equals(slChildType.get(i))) {       
									  strSubType="Raw";  
								     }
			 					     else if (("pgPackingMaterial").equals(slChildType.get(i))) {
			 					    	strSubType="Packaging";
			 					     } 
								String sChildType = util.mapType(slChildType.get(i));

								String sSPCSSSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCSSTYPE));
								String sSFCSSType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE));

								String sSUBType = ConstantsUtil.EMPTY_STRING;
								String sChildSubType = ConstantsUtil.EMPTY_STRING;
								String strRF = ConstantsUtil.EMPTY_STRING;

								StringList slSelectables = new StringList();
								slSelectables.add(ConstantsUtil.STRPGPDTTOPGPLIREFUN);
								
								DomainObject doReportedFunction = new DomainObject(sEachChildId);
								
								Map RFMapList  = doReportedFunction.getInfo(context, slSelectables);
								doReportedFunction.close(context);
								strRF = validator.getStringEquivalentForStringList(RFMapList.get(ConstantsUtil.STRPGPDTTOPGPLIREFUN));
								StringList strFnList = new StringList();
								String strMFObjId =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
								String sFunction = ConstantsUtil.EMPTY_STRING;
								try
								{
									if (UIUtil.isNotNullAndNotEmpty(strMFObjId)) 
									{
										sFunction=util.getIdFromPhysicalIdFunction(context,strMFObjId);
									}
								}catch(Exception e){
									sFunction=ConstantsUtil.EMPTY_STRING;
								}

								
							StringList strMinqty =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MIN_QUANTITY);
							StringList strMaxqty =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MAX_QUANTITY);
							StringList strCClist =validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCOMPONENTQUANTITY));
							if(bChildHasAccess) {

									util.formatData(sbEBOMName,slChildName.get(i));
									util.formatData(sbEBOMType,sChildType);
									util.formatData(sbEBOMChildRev,slChildRev.get(i));
									util.formatData(sbEBOMId,sEachChildId);
									util.formatData(sbEBOMTitle,slChildTitle.get(i));
									util.formatData(sbEBOMChg,sChg.get(i));
									//Added by Ketan for Defect no. 52810 - Start
	  								util.formatData(sbRelRestriction,slRelRestriction.get(i));
	  								util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
	  								//Added by Ketan for Defect no. 52810 - Start
								}
								else
								{
									util.formatData(sbEBOMName,slChildName.get(i));
									util.formatData(sbEBOMType,sChildType);
									util.formatData(sbEBOMChildRev,slChildRev.get(i));
									util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMTitle,slChildTitle.get(i));
									util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
									//Added by Ketan for Defect no. 52810 - Start
		  							util.formatData(sbRelRestriction,slRelRestriction.get(i));
		  							util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
		  							//Added by Ketan for Defect no. 52810 - End
								}

								if(showData) {
									util.formatData(sbEBOMQTY,slQTY.get(i));
									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
									util.formatData(sbEBOMParentType,util.mapType(sParentType));
									util.formatData(sbEBOMParentId,sParentID);
									util.formatData(sbEBOMParentName,sParentName);
									util.formatData(sbEBOMParentRev,sParentRev);
									util.formatData(sbEBOMParentTitle,sParentTitle);
									util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
									if(UIUtil.isNotNullAndNotEmpty(strSubType)){
										util.formatData(sbEBOMSubType,strSubType);
									}else{
									util.formatData(sbEBOMSubType,slSUBType.get(i));
									}
									util.formatData(sbEBOMRevRelDt,sRevRelease);
									util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
									util.formatData(sbEBOMUntilDate,validator.DateFormatter(slUntilDate.get(i)));
									util.formatData(sbEBOMRefDoc,sRDOC);
									util.formatData(sbEBOMCommnts,slComments.get(i));
									util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
									util.formatData(sbEBOMSFSubType,sSFSubType);
									util.formatData(sbRF,strRF);
									util.formatData(sbMF,sFunction);
									util.formatData(sbMinqty,strMinqty.get(i));
									util.formatData(sbMaxqty,strMaxqty.get(i));
									//Added by Jwala for the req 22x 41754 - START
									util.formatData(sbManufacturingStatus, sManufacturingStatus);
									
									//Added by Jwala for the req 22x 41754 - END
									//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
									util.formatData(sbLayerName, sLayerName);
									util.formatData(sbLayerGroup, sLayerGroup);
									//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
									util.formatData(sbCerti, strCertifications);
									util.formatData(sbComponentLocation, strComponentLocation);//SPEC: Added by Ajay for Req. no. 36986
									if(strCClist.size() !=0){
									util.formatData(sbComponentCount, strCClist.get(i));
									}
								}else {
									util.formatData(sbEBOMQTY,slQTY.get(i));
									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
									util.formatData(sbEBOMParentType,util.mapType(sParentType));
									util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMParentName,sParentName);
									util.formatData(sbEBOMParentRev,sParentRev);
									util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
									util.formatData(sbEBOMParentTitle,sParentTitle);
									util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
									if(UIUtil.isNotNullAndNotEmpty(strSubType)){
										util.formatData(sbEBOMSubType,strSubType);
									}else{
									util.formatData(sbEBOMSubType,slSUBType.get(i));
									}

									util.formatData(sbEBOMRevRelDt,sRevRelease);
									util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
									util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
									util.formatData(sbEBOMRefDoc,sRDOC);
									util.formatData(sbEBOMCommnts,slComments.get(i));
									util.formatData(sbEBOMSFSubType,sSFSubType);
									util.formatData(sbRF,strRF);
									util.formatData(sbMF,sFunction);
									util.formatData(sbMinqty,strMinqty.get(i));
									util.formatData(sbMaxqty,strMaxqty.get(i));
									//Added by Jwala for the req 22x 41754 - START
									util.formatData(sbManufacturingStatus, sManufacturingStatus);
									//Added by Jwala for the req 22x 41754 - END
									//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
									util.formatData(sbLayerName, sLayerName);
									util.formatData(sbLayerGroup, sLayerGroup);
									//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
									util.formatData(sbComponentLocation, strComponentLocation);//SPEC: Added by Ajay for Req. no. 36986
								util.formatData(sbCerti, strCertifications);
								if(strCClist.size() !=0){
								util.formatData(sbComponentCount, strCClist.get(i));
								}
								}
							}
						}
					}
				}
				mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
				mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
				mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
				mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
				mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
				mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
				mpEBOMResult.put(ConstantsUtil.MIN, sbMinqty.toString());
				mpEBOMResult.put(ConstantsUtil.MAX, sbMaxqty.toString());
				mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbRF.toString());
				mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbMF.toString());
				mpEBOMResult.put(ConstantsUtil.CERTIFICATION, sbCerti.toString());
				mpEBOMResult.put(ConstantsUtil.COMPONENTCOUNT, sbComponentCount.toString());
				mpEBOMResult.put(ConstantsUtil.MANUFACTURINGSTATUS, sbManufacturingStatus.toString());
				//Added by Subhajit for Req 46464 - Start
	  			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
	  			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
	  			//Added by Subhajit for Req 46464 - End
				mpEBOMResult.put(ConstantsUtil.LAYERNAME, sbLayerName.toString());
				mpEBOMResult.put(ConstantsUtilIRM.LAYERGROUP, sbLayerGroup.toString());
				mpEBOMResult.put(ConstantsUtilIRM.COMPONENTLOCATION, sbComponentLocation.toString());//SPEC: Added by Ajay for Req. no. 36986
			}

		}catch(Exception e) {
			LOGGER.info("EXCEPTION IN APPBO : parseSubstitute: "+e.getMessage());
			return new HashMap();
		}
		return util.filterMapList(mpEBOMResult);
	}


	public boolean checkSubstituteHasAccess(Context context, Map objectMap) {

		StringBuilder  sbReturnVal = new StringBuilder();
		boolean showData = false;
		try
		{
			StringValidatorUtil validator = new StringValidatorUtil();

			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership=util.filterOwnerShip(sComp);

			if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))
			{
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
				{
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
					String strSubPartId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));

					DomainObject doEachChild = new DomainObject(strSubPartId);
					
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					StringList slSelect = new StringList();
					slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					Map mpIpClass = doEachChild.getInfo(context, slSelect);
					//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- START
					doEachChild.close(context);
					//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- END
					StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					//commented by Ganesh for security impl ----> start
					/*if(util.isModificatinRequired())
					{
						//For EBP User
						showData = util.checkOwnerShip(context, slUserOwnership, strSubPartId);

					}else if(sct.isStaffAUGUser())
					{
						//For Staff Aug USer check 
						if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							//Validation for Hir checks on Formulation
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else
						{
							//Validation for Hir checks for other than Formulation
							showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
						}
					}else 
					{
						//For Internal User check
						if(slHIRTypes.contains(strSubPartType)) 
						{
							//Validation for Hir checks on Formulation
							if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else 
							{
								//Validation for Hir checks for other than Formulation
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
						}else 
						{
							//If it is Non-Hir we can show without checks for internal user
							showData=true;
						}
					}*///commented by Ganesh for security impl---> end
					//modified by Ganesh for security impl ----> start
					showData = util.checkHasAccess(context, null, strSubPartId);
					//modified by Ganesh for security impl ----> end
					//						
				}//string close bracket
			}else
			{	//If no Substitue found
				return showData;
			}

		}catch(Exception e){

			LOGGER.error("Error from BusObjectAttribUtil :  checkSubstituteHasAccess" + e);
			return showData;
		}
		return showData;
	}
	//SPEC: 11/04/2020: Added for 18x.5 DEV -- END

	//SPEC: 11/07/2020: Added for Defect 37063 -- START
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	//SPEC: 11/07/2020: Added for Defect 37063 -- END
	/**
	 * Method Name 			: getCountryClearanceResult
	 * Method Description 	: 
	 * @param resultMaps
	 * @return
	 */
	public Map getCountryClearanceResult(Map resultMaps)
	{

		Map<String, String> mapCountryClearanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{

			String strMarketName    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_NAME));
			String strClearanceNum    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_CT_NUM));
			String strOveralClearence    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE));
			String strGPSApproval   =  validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS));
			String strManuSite    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_MANU_SITE));
			String strPackSite    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PACK_SITE));
			String strComments    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT));
			String strRestrictions    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PLANT_REST));
			String strRegExpDate    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_REG_DATE));
			String strRegStatus    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_REG_STATUS));
			String strMPDTNumber    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM));
			String strPRODRegClass    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS));

			//SPEC:10/21/2020: Modified for defect 37277 ## -- START
			String strRegrewlleadTime    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALLEADTIME));
			String strRegirewlStatus    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALSTATUS));
			//SPEC:10/21/2020: Modified for defect 37277 ## -- END

			String strRegProductName    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME));

			mapCountryClearanceResult.put(ConstantsUtil.MARKET_NAME, strMarketName);
			mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, strClearanceNum);
			mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, strOveralClearence);
			mapCountryClearanceResult.put(ConstantsUtil.GPS_APPROVAL, strGPSApproval);
			mapCountryClearanceResult.put(ConstantsUtil.MANU_SITE, strManuSite);
			mapCountryClearanceResult.put(ConstantsUtil.PACK_SITE, strPackSite);
			mapCountryClearanceResult.put(ConstantsUtil.COMMENTS, strComments);
			mapCountryClearanceResult.put(ConstantsUtil.RESTRICTIONS, strRestrictions);
			mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, strRegExpDate);
			mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, strRegStatus);
			mapCountryClearanceResult.put(ConstantsUtil.MARKETPRODUCTNUMBER, strMPDTNumber);
			mapCountryClearanceResult.put(ConstantsUtil.PROD_REG_CLASS, strPRODRegClass);
			mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALLEADTIME, strRegrewlleadTime);
			mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALSTATUS, strRegirewlStatus);
			mapCountryClearanceResult.put(ConstantsUtil.REGISTEREDPRODUCTNAME, strRegProductName);

		}catch(Exception e){

			LOGGER.error("Error from DeviceProductPartBO:  getCountryClearanceResult"+e);
			return new HashMap();
		}
		return mapCountryClearanceResult;
	}

	public Map<String, String> getCerifications(Context context, MapList mlCertifications) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 
	 * @param context
	 * @param strObjectID
	 * @return
	 * @throws Exception
	 */

	public Map getCertificationClaims (Context context,String strObjectID)throws Exception
	{
		MapList relatedPartList = new MapList();
		Map<String, String> mpCert = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		boolean isContextPushed = false;

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership = util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		String sUserProjectLicense = sec.getProjectLicenses();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbMarket = new StringBuilder();
		StringBuilder sbClaim = new StringBuilder();
		//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
		StringBuilder sbRegion = new StringBuilder();
		StringBuilder sbArea = new StringBuilder();
		StringBuilder sbGroupTop = new StringBuilder();
		//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END

		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULA_CARD);
		slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strObjectID))
			{
				DomainObject domObj =  DomainObject.newInstance(context, strObjectID) ;
				
				StringList selectStmts = new StringList();                     // putting elements to StringList
				selectStmts.addElement(DomainConstants.SELECT_ID);
				selectStmts.addElement(DomainConstants.SELECT_NAME);
				selectStmts.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
				selectStmts.addElement(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME);

				StringList selectRelStmts = new StringList();
				selectRelStmts.addElement(DomainConstants.SELECT_RELATIONSHIP_ID); // Relationship Selects
				selectRelStmts.addElement(DomainConstants.SELECT_RELATIONSHIP_NAME);
				selectRelStmts.addElement(ConstantsUtil.RELATIONSHIP_COUNTRY_NAME);
				//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
				selectRelStmts.addElement(ConstantsUtil.SELECT_RELATIONSHIP_REGIONMATERIALCERT);
				selectRelStmts.addElement(ConstantsUtil.SELECT_RELATIONSHIP_AREAMATERIALCERT);
				selectRelStmts.addElement(ConstantsUtil.SELECT_RELATIONSHIP_GROUPTOPMATERIALCERT);
				//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END

				// Retrieving related item
				Pattern relPattern = new Pattern(ConstantsUtil.REL_PG_PLI_MATERIAL_CERTIFICATIONS);
				Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PG_PLI_MATERIAL_CERTIFICATIONS);
				relatedPartList = domObj.getRelatedObjects(context,
						relPattern.getPattern(),  //relationship pattern
						typePattern.getPattern(),  // object pattern
						selectStmts,                 // object selects
						selectRelStmts,              // relationship selects
						false,                        // to direction
						true,                       // from direction
						(short)1,                    // recursion level
						null,                        // object where clause
						null,
						0);
				//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- START
				relatedPartList.sort(DomainConstants.SELECT_NAME, "ascending", "String");
				//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- END
				//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- START
				domObj.close(context);
				//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- END
				Iterator itr = relatedPartList.iterator();

				while (itr.hasNext())
				{
					Map resultMaps = (Map) itr.next();

					String sObjId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
					String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
					//String sClaim = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_NAME));
					//sClaim=	sClaim.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					String sClaim = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_NAME));
					//String sMarket = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.RELATIONSHIP_COUNTRY_NAME));
					//sMarket=sMarket.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					String sMarket = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.RELATIONSHIP_COUNTRY_NAME));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
					String strIPControlClass = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
					String strProjSecClass = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME));
					//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
					//SPEC: <09.03.2021>: Guna Modified for Dev 18x.6   -- START
					String strRegion=validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_REGIONMATERIALCERT));
					String strArea=validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_AREAMATERIALCERT));
					String strGroup =validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_GROUPTOPMATERIALCERT));
					//SPEC: <09.03.2021>: Guna Modified for Dev 18x.6   -- END
					//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END
					boolean bShowDetails = false;
					boolean bProjectLicense=false;
					String sFormulaPropagate = sObjId;
					if(util.isModificatinRequired())
					{

						//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
						/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaPropagate = util.getFormulaPropagate(context, sFormulaPropagate);
						}

						if(!sFormulaPropagate.isEmpty()) {
							bShowDetails = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
						}*/
						//Added by Ganesh 1.0.2 Release Start
						bShowDetails=util.checkHasAccess(context, null, sObjId);
						//Added by Ganesh 1.0.2 Release End
						
						//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- START
						//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
						//if (!bShowDetails && util.isModificatinRequired()) {
						
						//	continue;
						//}
						//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
						//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- END
					}
					else if(sec.isStaffAUGUser()) 
					{
						/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
							String sFormulaClassif = util.getFormulaPropagateClassification(context, sObjId);
							bShowDetails=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else {
							bShowDetails=util.checkInternalUserAcess(sUserlicense,strIPControlClass);
						}

						if (bShowDetails && UIUtil.isNotNullAndNotEmpty(strProjSecClass.trim())) 
						{
							//For Project License Check
							bProjectLicense=util.checkLicenses(sUserProjectLicense,strProjSecClass);

							if (bProjectLicense)
							{ 
								bShowDetails= true;
							}else
							{
								bShowDetails= false;
							}
						}
						else if (bShowDetails && UIUtil.isNullOrEmpty(strProjSecClass.trim()))
						{
							bShowDetails= true;
						}else
						{
							bShowDetails= false;
						}*/
						//Added by Ganesh 1.0.2 Release Start
						bShowDetails=util.checkHasAccess(context, null, sObjId);
						//Added by Ganesh 1.0.2 Release End


					}
					else
					{
						/*if(slHIRTypes.contains(sType) )
						{
							String sFormulaClassif =strIPControlClass;
								if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) 
								{
									if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
										 sFormulaClassif = util.getFormulaPropagateClassification(context, sObjId);
										 bShowDetails=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
									}else {
										bShowDetails=util.checkInternalUserAcess(sUserlicense,strIPControlClass);
									}
								}
								bShowDetails=util.checkInternalUserAcess(sUserlicense,strIPControlClass);
							if (bShowDetails && UIUtil.isNotNullAndNotEmpty(strProjSecClass.trim())) 
							{
								//For Project License Check
								bProjectLicense=util.checkLicenses(sUserProjectLicense,strProjSecClass);

								if (bProjectLicense)
								{ 
									bShowDetails= true;
								}else
								{
									bShowDetails= false;
								}
							}
							else if (bShowDetails && UIUtil.isNullOrEmpty(strProjSecClass.trim()))
							{
								bShowDetails= true;
							}else
							{
								bShowDetails= false;
							}

						}else
						{
							bShowDetails= true;
						}*/
						//Added by Ganesh 1.0.2 Release Start
						bShowDetails=util.checkHasAccess(context, null, sObjId);
						//Added by Ganesh 1.0.2 Release End
					}

					if (!bShowDetails) {
						sObjId=ConstantsUtil.NO_ACCESS;
					}	
					
					
					formatData(sbId,sObjId);
					formatData(sbType,sType);
					formatData(sbMarket,sMarket);
					formatData(sbClaim,sClaim);
					//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
					formatData(sbRegion, strRegion);
					formatData(sbArea, strArea);
					formatData(sbGroupTop, strGroup);
					//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
				}

				mpCert.put(ConstantsUtil.MARKETS,sbMarket.toString());
				mpCert.put(ConstantsUtil.CERTIFICATIONCLAIM,sbClaim.toString());
				//mpCert.put(ConstantsUtil.PRODUCTPARTID, sbId.toString());
				//mpCert.put(ConstantsUtil.PRODUCTPARTTYPE, sbType.toString());
				//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
				mpCert.put(ConstantsUtilIRM.REGION,sbRegion.toString());
				mpCert.put(ConstantsUtil.AREA,sbArea.toString());
				mpCert.put(ConstantsUtil.GROUPTOMARKET,sbGroupTop.toString());
				//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END

			}
		}
		catch(Exception e)
		{
			LOGGER.error("Exception in program APPBO :getCertifications ");
		}
		return mpCert;


	}

	//SPEC:11/21/2020: Added for defect 37533 by Amman## -- START
	/**
	 * Method Name 			: getCountryClearance
	 * Method Description 	: 
	 * @param resultMaps
	 * @return
	 */
	public Map getCountryClearance(Context context,String sContextObjectId)
	{

		Map<String, String> mapCountryClearanceResult = new HashMap<String, String>();

		StringBuilder sbMarketName = new StringBuilder();
		StringBuilder sbClearanceNum = new StringBuilder();
		StringBuilder sbOveralClearence = new StringBuilder();
		StringBuilder sbGPSApproval = new StringBuilder();
		StringBuilder sbManuSite = new StringBuilder();
		StringBuilder sbPackSite = new StringBuilder();
		StringBuilder sbComments = new StringBuilder();
		StringBuilder sbRestrictions = new StringBuilder();
		StringBuilder sbRegExpDate = new StringBuilder();
		StringBuilder sbRegStatus = new StringBuilder();
		StringBuilder sbMPDTNumber = new StringBuilder();
		StringBuilder sbPRODRegClass = new StringBuilder();
		StringBuilder sbRegrewlleadTime = new StringBuilder();
		StringBuilder sbRegirewlStatus = new StringBuilder();
		StringBuilder sbRegProductName = new StringBuilder();
		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
		StringBuilder sbMarketAppproverHolder = new StringBuilder();
		StringBuilder sbLegalEntity = new StringBuilder();
		StringBuilder sbBusinessChannel = new StringBuilder();
		StringBuilder sbPackSize = new StringBuilder();
		StringBuilder sbPackSizeUOM = new StringBuilder();
		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END

		StringValidatorUtil validator = new StringValidatorUtil();

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_NAME);

		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALLEADTIME);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME);
		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETAPPROVERHOLDER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLEGALENTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZEUOM);
		//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END

		try
		{
			MapList mapList;

			DomainObject doAPP = new DomainObject(sContextObjectId);
			
			mapList = doAPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE, ConstantsUtil.SYMBL_ASTERISK,
					busSelect, relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- END
			mapList.sort(DomainConstants.SELECT_NAME, "ascending", "String");

			for (int i = 0; i < mapList.size(); i++) {
				Map resultMaps = (Map) mapList.get(i);
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 40640 on Date 26/03/2021 --START
				String strMarketName    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_NAME));
				String strClearanceNum    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER));
				String strOveralClearence    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS));
				String strGPSApproval   =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS));
				//SPEC: <21.03.2021>: Guna Commented for Internal Defect 18x.6   -- START
				//String strManuSite    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE));
				//String strPackSite    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE));
				//SPEC: <21.03.2021>: Guna Commented for Internal Defect 18x.6   -- END
				
				String strComments    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT));
				//Added by Dominic for the defect 44115 -- START
				//String strRestrictions    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION));
				String strRestrictions    =  validator.getEquivalentStringForMC(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION));
				//Added by Dominic for the defect 44115 -- END
				String strRegExpDate    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE));
				String strRegStatus    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS));
				strRegStatus=strRegStatus.replace(ConstantsUtil.REGISTRATIONRELEASEDAPP, ConstantsUtil.REGISTRATIONAPPROVEDAPP);
				String strMPDTNumber    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER));
				String strPRODRegClass    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION));
				String strRegrewlleadTime    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALLEADTIME));
				String strRegirewlStatus    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS));
				String strRegProductName    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME));
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
				String strMarketAppproverHolder    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETAPPROVERHOLDER));
				String strLegalEntity    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLEGALENTITY));
				String strBusinessChannel    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL));
				String strPackSize    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZE));
				String strPackSizeUOM    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZEUOM));
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 40640 on Date 26/03/2021 --END
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
				//SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- START
				String strManuSite=getDataWithCommaSeparator(resultMaps, ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE);
				String strPackSite=getDataWithCommaSeparator(resultMaps, ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE);
				//SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- END
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41661 on Date 12/04/2021 --START
				int iSize = 0;
				for(int k = 0; k < strClearanceNum.length(); k++) {
				    if(strClearanceNum.charAt(k) == ',') iSize++;
				}
				strClearanceNum    =  strClearanceNum.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strGPSApproval   =  strGPSApproval.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strManuSite    =  strManuSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSite    =  strPackSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strComments    =  strComments.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				//Added by Dominic for the defect 44115 -- START
				//strRestrictions    =  strRestrictions.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				//Added by Dominic for the defect 44115 -- END
				strRegExpDate    =  strRegExpDate.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegStatus    =  strRegStatus.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strMPDTNumber    =  strMPDTNumber.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPRODRegClass    =  strPRODRegClass.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegProductName    =  strRegProductName.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegrewlleadTime    =  strRegrewlleadTime.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegirewlStatus    =  strRegirewlStatus.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strMarketAppproverHolder    =  strMarketAppproverHolder.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strLegalEntity    =  strLegalEntity.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strBusinessChannel    =  strBusinessChannel.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSize    =  strPackSize.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSizeUOM    =  strPackSizeUOM.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				//SPEC: <19.03.2021>: Guna Added for Internal Defect 18x.6   -- START
				strPackSite = strPackSite.replaceAll("\\"+ConstantsUtilIRM.SYMBOL_CAP,ConstantsUtil.SYMBL_COMMA);
				strManuSite = strManuSite.replaceAll("\\"+ConstantsUtilIRM.SYMBOL_CAP,ConstantsUtil.SYMBL_COMMA);
				//SPEC: <19.03.2021>: Guna Added for Internal Defect 18x.6   -- END
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 42396 on Date 14/04/2021 --START
				strRegExpDate=(String)getRegExpDateInFormat(resultMaps,ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE);
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 42396 on Date 14/04/2021 --END
				for (int j = 0; j <= iSize; j++) {
					formatData(sbMarketName, strMarketName);
					formatData(sbOveralClearence, strOveralClearence);
				}
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41661 on Date 12/04/2021 --END
				//util.formatData(sbMarketName, strMarketName);
				util.formatData(sbClearanceNum, strClearanceNum);
				//util.formatData(sbOveralClearence, strOveralClearence);
				util.formatData(sbGPSApproval, strGPSApproval);
				//SPEC: Release SR18x.6.0 - Added for Defect# 40993  by gaikwad.tg on Date 19 April 2021 -- START
				util.formatData(sbManuSite, UIUtil.isNotNullAndNotEmpty(strManuSite)? strManuSite : DomainConstants.EMPTY_STRING);
				util.formatData(sbPackSite, UIUtil.isNotNullAndNotEmpty(strPackSite)? strPackSite : DomainConstants.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Added for Defect# 40993  by gaikwad.tg on Date 19 April 2021 -- END
				util.formatData(sbComments, strComments);
				util.formatData(sbRestrictions, strRestrictions);
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 42396 on Date 14/04/2021 --START
				//SPEC: <09.04.2021>: Guna Modified for Internal defect 18x.6   -- START
				util.formatData(sbRegExpDate, strRegExpDate);
				//util.formatData(sbRegExpDate, validator.effectvityDateFormatter(strRegExpDate));
				//SPEC: <09.04.2021>: Guna Modified for Internal defect 18x.6   -- END
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 42396 on Date 14/04/2021 --START
				util.formatData(sbRegStatus, strRegStatus);
				util.formatData(sbMPDTNumber, strMPDTNumber);
				util.formatData(sbPRODRegClass, strPRODRegClass);
				util.formatData(sbRegrewlleadTime, strRegrewlleadTime);
				util.formatData(sbRegirewlStatus, strRegirewlStatus);
				util.formatData(sbRegProductName, strRegProductName);
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
				util.formatData(sbMarketAppproverHolder, strMarketAppproverHolder);
				util.formatData(sbLegalEntity, strLegalEntity);
				util.formatData(sbBusinessChannel, strBusinessChannel);
				util.formatData(sbPackSize, strPackSize);
				util.formatData(sbPackSizeUOM, strPackSizeUOM);
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END

				mapCountryClearanceResult.put(ConstantsUtil.MARKET_NAME, sbMarketName.toString());
				mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, sbClearanceNum.toString());
				mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, sbOveralClearence.toString());
				mapCountryClearanceResult.put(ConstantsUtil.GPS_APPROVAL, sbGPSApproval.toString());
				mapCountryClearanceResult.put(ConstantsUtil.MANU_SITE, sbManuSite.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PACK_SITE, sbPackSite.toString());
				//SPEC: <24.02.2021>: Guna Modified for Dev 18x.6   -- START
				//mapCountryClearanceResult.put(ConstantsUtil.COMMENTS, sbComments.toString());
				mapCountryClearanceResult.put(ConstantsUtil.GPSCOMMENTS, sbComments.toString());
				//SPEC: <24.02.2021>: Guna Modified for Dev 18x.6   -- END
				mapCountryClearanceResult.put(ConstantsUtil.RESTRICTIONS, sbRestrictions.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, sbRegExpDate.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, sbRegStatus.toString());
				mapCountryClearanceResult.put(ConstantsUtil.MARKETPRODUCTNUMBER, sbMPDTNumber.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PROD_REG_CLASS, sbPRODRegClass.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALLEADTIME, sbRegrewlleadTime.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALSTATUS, sbRegirewlStatus.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTEREDPRODUCTNAME, sbRegProductName.toString());
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- START
				mapCountryClearanceResult.put(ConstantsUtil.MARKETAPPROVALHOLDER, sbMarketAppproverHolder.toString());
				mapCountryClearanceResult.put(ConstantsUtil.LEGALENTITY, sbLegalEntity.toString());
				mapCountryClearanceResult.put(ConstantsUtil.BUSINESSCHANNEL, sbBusinessChannel.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PACKSIZE, sbPackSize.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PACKSIZEUOM, sbPackSizeUOM.toString());
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
			}
		}catch(Exception e){

				LOGGER.error("Error from APPBO:  getCountryClearance"+e);
				return new HashMap();
			}
			return mapCountryClearanceResult;
		}
		//SPEC:11/21/2020: Added for defect 37533 by Amman## -- END
		//SPEC: <25.02.2021>: Guna Added for Dev 18x.6   -- START
		/**
		 * Method Name 			: getChemicalPhysicalSelectable
		 * Method Description 	:
		 * @param context
		 * @return
		 */
		public static StringList getChemicalPhysicalSelectable (Context context) {
			StringList busSelect = new StringList();
			//SPEC: 11.03.2021>: Guna Modified for Dev 18x.6   -- START
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIGNITIONDISTANCE_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENCLOSEDSPACEIGNITION_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFOAMFLAMMABILITY); 
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTENTCONDUCTIVITY_INPUT_VALUE); 
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINTVALUE_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVETOMETALS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUSTAINCOMBUSTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOXIDIZER);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAVAILABLEOXYGEN);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBYVOLUME_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBYWEIGHT_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVAPORPRESSURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBURNRATE_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION_INPUT_VALUE); 
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSELFACCELDECOMTEMP_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_AVAILABILITY);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_LIQUID);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTOXIDIZER);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_TECHNICAL_CTM);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_DILUTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VAPOUR_DENSITY_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOLTYPE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_CAN_CONSTRUCTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_COLOR_INTENSITY);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOLOR_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_AVAILABLE_OXYGEN_CONTENT_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONDUCTIVITYOFTHELIQUID_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_BOILINGPOINTVALUE_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEDURATION_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEHEIGHT_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_ORGANIC_PEROXIDE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPOTENTIALTOINCREASEBURNINGRATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_LIQUID_CORROSIVE_TO_METAL);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTHELIQUIDANAQUEOUSSOL);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPHDATAAVAILABLE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMIN_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMAX_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYUOM);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYTITRATIONENDPOINT_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE_INPUTVALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION_INPUT_VALUE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTSUSTAINCOMBUSTION);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISTHELIQUIDANAQEOUSSOLUTION);
			
			//SPEC: 07.04.2022: Jwala Added for Req 11640 Release  -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMELTINGPOINTTARGET);
			busSelect.add(ConstantsUtilIRM.SELECT_AATTRIBUTE_PGMELTINGPOINTMIN);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMELTINGPOINTMAX);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPTARGET);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPMIN);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPMAX);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_DUSTEXPLOSIVITY);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGKST);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMAX);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PARTITIONCOEFFICIENT);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_WATERSOLUBILITY);
			//SPEC: 07.04.2022: Jwala Added for Req 11640 Release  -- END
			//Added By Ajay for the Req 14570 : START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYTMAX);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYTMIN);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITYMAX);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITYMIN);
			//Added By Ajay for the Req 14570 : END
			
			return busSelect;
		}
		public Map getConnectedSmartLabelForParts  (Context context,String objId)throws Exception
	    {
			StringValidatorUtil validator = new StringValidatorUtil();
	        String partId = objId;             //To get the context part id
	        MapList relatedPartList = new MapList();
	        Map<String,String> mpSmartLabel = new HashMap<String,String>();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbSubType = new StringBuilder();
			
			//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
			//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- START
			//boolean isExternal=util.isModificatinRequired();
			//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- END
			//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
			
	        try
	        {
	        	if(UIUtil.isNotNullAndNotEmpty(partId)){
	        		String sUserType = util.getUserType();
	        		DomainObject domObj =  DomainObject.newInstance(context, partId) ;
	        		
	        		StringList selectStmts = new StringList();                     // putting elements to StringList
	        		selectStmts.addElement(ConstantsUtil.SELECT_ID);
	        		selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
	        		selectStmts.addElement(ConstantsUtil.SELECT_NAME);
	        		selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSMARTLABELSUBTYPE);
	        		selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
	        		selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);
	        		StringList selectRelStmts = new StringList(2);
	        		selectRelStmts.addElement(DomainConstants.SELECT_RELATIONSHIP_ID); // Relationship Selects
	        		selectRelStmts.addElement(DomainConstants.SELECT_RELATIONSHIP_NAME);
	        		// Retrieving related item
	        		Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_PGSMARTLABEL);
	        		Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PGSMARTLABEL);

				relatedPartList = domObj.getRelatedObjects(context,
						relPattern.getPattern(),  //relationship pattern 
						typePattern.getPattern(), // object pattern
						selectStmts,                 // object selects
						selectRelStmts,              // relationship selects
						false,                        // to direction
						true,                       // from direction
						(short)1,                    // recursion level
						null,                        // object where clause
						null,
						0);
				//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- START
    			domObj.close(context);
    			//SPEC: <08-10-2021>: Guna Added for Stress Testing Defect 44365  -- END
				if(relatedPartList.size() !=0){

					Iterator objectListItr = relatedPartList.iterator();
					while (objectListItr.hasNext()) {
						SecurityService sct = new SecurityService();
						String sUserlicense = sct.getUserLicense();
						boolean showData = false;
						Map resultMaps = (Map) objectListItr.next();
						String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
						String sType = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
						sType =util.mapType(sType);
						String sName = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
						String sRev = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
						String sCurrent = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
						String sSubType = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSMARTLABELSUBTYPE));
						sSubType =util.mapType(sSubType);

						if (!sCurrent.equals((ConstantsUtilIRM.STATE_COMPLETE).trim())) {
							continue;
						}
						showData = util.checkHasAccess(context, sUserType, sId);
						
						//SPEC: Release SR18x.6.0.1 - Req#39652 modified by Sanjeeva -- START
						//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
						/*if (!showData && util.isModificatinRequired()) {
						
							continue;
						}*/
						//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
						//SPEC: Release SR18x.6.0.1 - Req#39652 modified by Sanjeeva -- END
						if (showData) {
							util.formatData(sbId, sId);
							util.formatData(sbType, sType);
							util.formatData(sbName, sName);
							util.formatData(sbRev, sRev);
							util.formatData(sbCurrent, sCurrent);
							util.formatData(sbSubType, sSubType);
						} else {
						//SPEC: Release SR18x.6.0.1 - Req#39652 modified by Sanjeeva -- START
							
								util.formatData(sbId, ConstantsUtil.NO_ACCESS);
								util.formatData(sbType, sType);
								util.formatData(sbName, sName);
								util.formatData(sbRev, sRev);
								util.formatData(sbCurrent, sCurrent);
								util.formatData(sbSubType, sSubType);
							//}
						//SPEC: Release SR18x.6.0.1 - Req#39652 modified by Sanjeeva -- END
						}
					}
					mpSmartLabel.put(ConstantsUtil.TYPE, sbType.toString());
					mpSmartLabel.put(ConstantsUtil.NAME, sbName.toString());
					mpSmartLabel.put(ConstantsUtil.STATE, sbCurrent.toString());
					mpSmartLabel.put(ConstantsUtil.SUBTYPE, sbSubType.toString());
					mpSmartLabel.put(ConstantsUtil.REVISION, sbRev.toString());
					mpSmartLabel.put(ConstantsUtil.ID, sbId.toString());
				}

			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new FrameworkException(e);
		}
		return mpSmartLabel ;
	}

/** SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- START
		 * AVoidng comma
		 * @param resultMaps
		 * @return
		 */
		
		
		public String getDataWithCommaSeparator(Map resultMaps,String Key)
		{
			StringValidatorUtil validator = new StringValidatorUtil();
			StringBuilder sbReturn = new StringBuilder();
			String sReturnValue =ConstantsUtil.EMPTY_STRING;
			try {
			if (resultMaps.containsKey((Key))) 
			{
				
				String sClass =resultMaps.get(Key).getClass().getSimpleName();
				
				if (sClass.equals(ConstantsUtil.STRING)) {
					 sReturnValue     =  validator.getStringEquivalentForStringListWithComma(resultMaps.get(Key));
					 sbReturn.append(sReturnValue);
					
				}else
				{
					StringList slSubstituteTitle = validator.isNotNullOrEmpty((StringList) resultMaps.get(Key));
					
					for (int i = 0; i < slSubstituteTitle.size(); i++) 
					{
						 sReturnValue =slSubstituteTitle.get(i);
						if(UIUtil.isNotNullAndNotEmpty(sReturnValue)){
							if(i == 0){
							sbReturn.append(sReturnValue);
							}else{
								sbReturn.append(ConstantsUtil.SYMBL_COMMA);
								sbReturn.append(sReturnValue);
							}
						}
						//SPEC: Release SR18x.6.0 - Added for Defect# 40993  by gaikwad.tg on Date 19 April 2021 -- START
						else {
							if(i == 0){
								sbReturn.append(sReturnValue);
								}else{
									sbReturn.append(ConstantsUtil.SYMBL_COMMA);
									sbReturn.append(sReturnValue);
								}
						}
						//SPEC: Release SR18x.6.0 - Added for Defect# 40993  by gaikwad.tg on Date 19 April 2021 -- END
					}
				}
			}
			}catch(Exception e){
				//SPEC: <08-10-2021>: Guna Modified for Stress Testing Defect 44365  -- START
				LOGGER.error("Exception in Program : APPBO Method :getDataWithCommaSeparator of Map " + e);
				//SPEC: <08-10-2021>: Guna Modified for Stress Testing Defect 44365  -- END
				return "";
			}
			return sbReturn.toString();
		}
		//SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- END
		//SPEC: Release SR18x.6. Modified by Dominic for Defect 42396 on Date 14/04/2021 --START
		public String getRegExpDateInFormat(Map resultMaps,String Key)
		{
			StringValidatorUtil validator = new StringValidatorUtil();
			StringBuilder sbReturn = new StringBuilder();
			String sReturnValue =ConstantsUtil.EMPTY_STRING;
			try {
				String sClass =resultMaps.get(Key).getClass().getSimpleName();
				if (sClass.equals(ConstantsUtil.STRING)) {
						 sReturnValue     =  validator.getStringEquivalentForStringListWithComma(resultMaps.get(Key));
						 sReturnValue = validator.effectvityDateFormatter(sReturnValue);
						 sbReturn.append(sReturnValue);
						
					}else
					{
						StringList slSubstituteTitle = validator.isNotNullOrEmpty((StringList) resultMaps.get(Key));
						
						for (int i = 0; i < slSubstituteTitle.size(); i++) 
						{
							 sReturnValue =slSubstituteTitle.get(i);
							if(UIUtil.isNotNullAndNotEmpty(sReturnValue)){
								sReturnValue = validator.effectvityDateFormatter(sReturnValue);
								if(i == 0){
								sbReturn.append(sReturnValue);
								}else{
									sbReturn.append(ConstantsUtil.SYMBL_PIPE);
									sbReturn.append(sReturnValue);
								}
							}
							
						}
					}
			}catch(Exception e){
				
				LOGGER.error("Exception in Program : getRegExpDateInFormat " + e);
				return "";
			}
			return sbReturn.toString();
		}
		//SPEC: Release SR18x.6. Modified by Dominic for Defect 42396 on Date 14/04/2021 --END
		
		//SPEC: 07.11.2024: Jwala Added for Req 11640 Sprint 12 Release  -- START
		public Map getMeltingpointDetails(Context context,Map resultMaps) {
			
			Map<String, String> mpPhysicalChemicalGHCProp = new HashMap<String, String>();
			StringValidatorUtil validator = new StringValidatorUtil();
			try {
				
				String strMeltingTarget    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMELTINGPOINTTARGET));
				String strMeltingMin    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_AATTRIBUTE_PGMELTINGPOINTMIN));
				String strMeltingMax    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMELTINGPOINTMAX));
				String strAutoTempTarget    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPTARGET));
				String strAutoTempMin    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPMIN));
				String strAutoTempMax    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPMAX));
				String strDustexplosivity    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_DUSTEXPLOSIVITY));
				String strPGkst    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGKST));
				String strPGmax    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMAX));
				String strPartionCoefficient    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PARTITIONCOEFFICIENT));
				String strWaterSolubility    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_WATERSOLUBILITY));
				//Added By Ajay for the Req 14570 : START
				
				String strRelativeDensityMax = 	validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYTMAX));
				String strRelativeDensityMin = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYTMIN));
				String strdynamicViscosityMax = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITYMAX)).concat(ConstantsUtilIRM.SPACE_C);
				String strdynamicViscosityMin = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITYMIN)).concat(ConstantsUtilIRM.SPACE_C);
				
				//Added By Ajay for the Req 14570 : END
				if(strMeltingTarget.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strMeltingTarget = ConstantsUtil.EMPTY_STRING;
				
				if(strMeltingMin.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strMeltingMin = ConstantsUtil.EMPTY_STRING;
				
				if(strMeltingMax.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strMeltingMax = ConstantsUtil.EMPTY_STRING;
				
				if(strAutoTempTarget.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strAutoTempTarget = ConstantsUtil.EMPTY_STRING;
				
				if(strAutoTempMin.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strAutoTempMin = ConstantsUtil.EMPTY_STRING;
				
				if(strAutoTempMax.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strAutoTempMax = ConstantsUtil.EMPTY_STRING;
				
				if(strPGkst.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strPGkst = ConstantsUtil.EMPTY_STRING;
				
				if(strPGmax.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strPGmax = ConstantsUtil.EMPTY_STRING;
				
				if(strPartionCoefficient.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strPartionCoefficient = ConstantsUtil.EMPTY_STRING;
				//Added By Ajay for the Req 14570 : START
				if(strRelativeDensityMax.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strRelativeDensityMax = ConstantsUtil.EMPTY_STRING;
				
				if(strRelativeDensityMin.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strRelativeDensityMin = ConstantsUtil.EMPTY_STRING;
				
				//Added By Ajay for the Defect 19156 : START
				if(strdynamicViscosityMax.endsWith(ConstantsUtilIRM.DOT_ZERO_C))
					strdynamicViscosityMax = (strdynamicViscosityMax.substring(0,(strdynamicViscosityMax.length()-4))).concat(ConstantsUtilIRM.SPACE_C);
		
				if(strdynamicViscosityMin.endsWith(ConstantsUtilIRM.DOT_ZERO_C))
					strdynamicViscosityMin = (strdynamicViscosityMin.substring(0,(strdynamicViscosityMin.length()-4))).concat(ConstantsUtilIRM.SPACE_C);
				
				if(strRelativeDensityMax.endsWith(ConstantsUtilIRM.DOT_ZERO))
					strRelativeDensityMax = (strRelativeDensityMax.substring(0,(strRelativeDensityMax.length()-2)));
				if(strRelativeDensityMin.endsWith(ConstantsUtilIRM.DOT_ZERO))
					strRelativeDensityMin = (strRelativeDensityMin.substring(0,(strRelativeDensityMin.length()-2)));
			
				if((strdynamicViscosityMax.trim().equalsIgnoreCase(ConstantsUtilIRM.ZERO_SIZE_C)))
					strdynamicViscosityMax = ConstantsUtil.EMPTY_STRING;
				
				if((strdynamicViscosityMin.trim().equalsIgnoreCase(ConstantsUtilIRM.ZERO_SIZE_C)))
					strdynamicViscosityMin = ConstantsUtil.EMPTY_STRING;
				//Modified By Ajay for the Defect 19156 : END
				//Added By Ajay for the Req 14570 : END
				
				
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.MELTINGPOINTTARGET, strMeltingTarget);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.MELTINGPOINTMIN, strMeltingMin);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.MELTINGPOINTMAX, strMeltingMax);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.AUTOIGNITIONTEMPTARGET, strAutoTempTarget);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.AUTOIGNITIONTEMPMIN, strAutoTempMin);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.AUTOIGNITIONTEMPMAX, strAutoTempMax);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.DUSTEXPLOSIVITY, strDustexplosivity);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.PGKST, strPGkst);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.PGPMAX, strPGmax);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.PARTITIONCOEFFICIENT, strPartionCoefficient);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.WATERSOLUBILITY, strWaterSolubility);
				//Added By Ajay for the Req 14570 : START
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.RELATIVEDENSITYMAX, strRelativeDensityMax);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.RELATIVEDENSITYMIN, strRelativeDensityMin);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.DYNAMICVISCOSITYMAX, strdynamicViscosityMax);
				mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.DYNAMICVISCOSITYMIN, strdynamicViscosityMin);
				//Added By Ajay for the Req 14570 : END
				
			} catch(Exception e){

				LOGGER.error("Error from APPBO:  getMeltingpointDetails"+e);
				return new HashMap();
			}
			return mpPhysicalChemicalGHCProp;
			
		}
		//SPEC: 07.11.2024: Jwala Added for Req 11640 Sprint 12 Release  -- END
}