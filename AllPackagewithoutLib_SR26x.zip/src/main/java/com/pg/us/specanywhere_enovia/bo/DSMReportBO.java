/**
 * Project 		: SpecsAnywhere
 * Program 		: DSMReportBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;


public class DSMReportBO {

	private static Logger dsmLOGGER = Logger.getLogger(DSMReportBO.class);
	BusObjectAttribUtil util  = new BusObjectAttribUtil();
	DSBO dsbo = new DSBO();
	static StringValidatorUtil validator = new StringValidatorUtil();

	public StringList getDSMReportSelectables() {

		StringList slReportObjSelect = new StringList();
		slReportObjSelect.add(DomainConstants.SELECT_TYPE);
		slReportObjSelect.add(DomainConstants.SELECT_NAME);
		slReportObjSelect.add(DomainConstants.SELECT_REVISION);
		slReportObjSelect.add(DomainConstants.SELECT_MODIFIED);
		slReportObjSelect.add(DomainConstants.SELECT_ID);
		slReportObjSelect.add(ConstantsUtil.STR_FILE_NAME);
		slReportObjSelect.add(ConstantsUtilIRM.STR_FILE_MODIFIED);
		slReportObjSelect.add(DomainConstants.SELECT_ORIGINATED);
		slReportObjSelect.add(DomainConstants.SELECT_CURRENT);
		slReportObjSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		slReportObjSelect.add(ConstantsUtilIRM.STR_FILE_FILEID);			

		return slReportObjSelect;
	}

	/**Method to display DSM Reports
	 * @param context 
	 * @param args - Information from the list of table,connectionString and Azure Containername
	 * @return MapList - with list of Dynamic Subscription
	 * @throws Exception If operation fails.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getDSMReportData(Context context, String strUserName, String connectionString, String containername,String azurestore) {
		Map<String, String> mpDSMReports = new HashMap<>();
		MapList mlDSMReportList = new MapList();
		StringBuilder sbReportId = new StringBuilder();
		StringBuilder sbReportName = new StringBuilder();
		StringBuilder sbFileName = new StringBuilder();
		StringBuilder sbFileModified = new StringBuilder();
		StringBuilder sbRequestedDate = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbFilePath = new StringBuilder();
		StringBuilder sbFileId = new StringBuilder();
		Map<String, String> mpReportObject = new HashMap<> ();
		MapList mlReportObjTNR = new MapList ();
		StringList slReportObjTNR = new StringList();
		slReportObjTNR.add(DomainConstants.SELECT_TYPE);
		slReportObjTNR.add(DomainConstants.SELECT_NAME);
		slReportObjTNR.add(DomainConstants.SELECT_REVISION);
		slReportObjTNR.add(DomainConstants.SELECT_ID);

		try {
			DateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
			Date curDate = new Date(System.currentTimeMillis());
			StringList slReportObjSelect = getDSMReportSelectables();

			String strObjectWhere = "(" +ConstantsUtil.OWNER+ "=='" + strUserName + "' && modified < '"+format.format(curDate)+ "')";
			dsmLOGGER.info("strObjectWhere:"+strObjectWhere);
			mlDSMReportList = DomainObject.findObjects 
					(context, //MatrixContext
							ConstantsUtilIRM.TYPE_PGDSMREPORT, //typePattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
							strObjectWhere, //whereExpression
							slReportObjSelect); //objectSelects
		}
		catch (Exception ex) {
			dsmLOGGER.info("=======================================================");
			dsmLOGGER.info("DSMReportBO:getDSMReportData :  1.Exception while querying all objects at once. Exception:"+ex);
			dsmLOGGER.info("=======================================================");
			try {
				mlDSMReportList = new MapList();
				String sReportId = "";
				String strObjectWhere = "(" +ConstantsUtil.OWNER+ "=='" + strUserName + "')";
				mlReportObjTNR = DomainObject.findObjects 
						(context, //MatrixContext
								ConstantsUtilIRM.TYPE_PGDSMREPORT, //typePattern
								ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
								strObjectWhere, //whereExpression
								slReportObjTNR); //objectSelects
				if(null != mlReportObjTNR && !mlReportObjTNR.isEmpty()) 
				{
					Iterator<MapList> itrReportObjectTNRList = mlReportObjTNR.iterator();	
					StringList slReportObjSelect = getDSMReportSelectables();
					while(itrReportObjectTNRList.hasNext()) 
					{
						Map<String, String> mpConnObj = (Map<String, String>) itrReportObjectTNRList.next();
						sReportId 	= validator.isNotNullOrEmpty(mpConnObj.get(DomainConstants.SELECT_ID))?mpConnObj.get(DomainConstants.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
						strObjectWhere = "(" +DomainConstants.SELECT_ID+ "=='" + sReportId + "') && (" +ConstantsUtil.OWNER+ "=='" + strUserName + "')";
						try {
							DomainObject.findObjects 
							(context, //MatrixContext
									ConstantsUtilIRM.TYPE_PGDSMREPORT, //typePattern
									ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
									strObjectWhere, //whereExpression
									slReportObjSelect); //objectSelects
							DomainObject doAPP = DomainObject.newInstance(context, sReportId);
							mpReportObject = doAPP.getInfo(context, getDSMReportSelectables());

						} catch (Exception ex0) {
							dsmLOGGER.error("DSMReportBO:getDSMReportData : 3.Exception while querying each object: "+sReportId+":"+ex0);
							try {

								DomainObject doAPP = DomainObject.newInstance(context, sReportId);
								mpReportObject = doAPP.getInfo(context, getDSMReportSelectables());

								dsmLOGGER.error("State before Replace:"+mpReportObject.get(DomainConstants.SELECT_CURRENT));
								mpReportObject.replace(DomainConstants.SELECT_CURRENT, "Pending");
								mpReportObject.replace(ConstantsUtil.STR_FILE_NAME, " ");
								dsmLOGGER.error("State after Replace:"+mpReportObject.get(DomainConstants.SELECT_CURRENT));
							} catch (Exception ex11) {
								dsmLOGGER.error("DSMReportBO:getDSMReportData : 2.Exception while fetching info for eah object: "+sReportId+":"+ex11);
							} 

						} 

						mlDSMReportList.add(mpReportObject);
					}
				}
			}
			catch (Exception ex1){
				dsmLOGGER.error("4.Exception in Program : DSMReportBO:getDSMReportData : Unable to get report list with TNR: "+ex1);
			} 
		} 
		try {
			if(null != mlDSMReportList && !mlDSMReportList.isEmpty()) {
				Collections.sort(mlDSMReportList, new Comparator<Map<String, String>>() {
					public int compare(Map<String, String> map1, Map<String, String> map2) {
						try {
							//SPEC: <14.03.2022>: Guna Modified for 46885 Defect  Dev 18x.6.0.3   -- START
							DateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
							return Long.valueOf(format.parse(map2.get(DomainConstants.SELECT_ORIGINATED)).getTime()).compareTo(format.parse(map1.get(DomainConstants.SELECT_ORIGINATED)).getTime());
							//SPEC: <14.03.2022>: Guna Modified for 46885 Defect  Dev 18x.6.0.3   -- END
						} catch (Exception e) {
							dsmLOGGER.error("5.Exception in Program : DSMReportBO:getDSMReportData: "+e);
							return 0;
						}
					}
				});
				Iterator<MapList> itrReportObjectList = mlDSMReportList.iterator();		 		
				while(itrReportObjectList.hasNext()) {
					Map<String, String> mConnObj = (Map<String, String>) itrReportObjectList.next();
					String sReportId 	= validator.getEquivalentStringComma(mConnObj.get(DomainConstants.SELECT_ID));
					String sReportName = validator.getEquivalentStringComma(mConnObj.get(DomainConstants.SELECT_NAME));
					String sFileName = validator.getEquivalentStringComma(mConnObj.get(ConstantsUtil.STR_FILE_NAME));
					String sFileModified = validator.getEquivalentStringComma(mConnObj.get(ConstantsUtilIRM.STR_FILE_MODIFIED));
					String sRequestedDate = validator.getEquivalentStringComma(mConnObj.get(DomainConstants.SELECT_ORIGINATED));
					String sState = validator.getEquivalentStringComma(mConnObj.get(DomainConstants.SELECT_CURRENT));
					String sFilePath = validator.getEquivalentStringComma(mConnObj.get(ConstantsUtil.STR_FILE_CAPTURED));
					String sFileId = validator.getEquivalentStringComma(mConnObj.get(ConstantsUtilIRM.STR_FILE_FILEID));

					//Added By Jwala for the defect 99107 : START
					String strBlobName = azurestore+sFilePath;
					boolean bReturnFlag = false;

					boolean fileExists = checkIfFileExists(connectionString, containername,strBlobName);

					if(!fileExists) {
						bReturnFlag = true;
						sFileName = DomainConstants.EMPTY_STRING;
					}
					//Added By Jwala for the defect 99107 : END
					//Modified for defects# 46965,46918,46917,46897,46883 -- START
					util.formatData (sbReportId, sReportId);  
					util.formatData (sbReportName, sReportName);
					if ((sState.equalsIgnoreCase("Submitted") || sState.equalsIgnoreCase(ConstantsUtil.PENDING)) && validator.isNotNullOrEmpty(sFileName)){
						util.formatData (sbFileName, ConstantsUtil.EMPTY_STRING);
					} else if(sState.equalsIgnoreCase(ConstantsUtil.STATE_COMPLETE) && !validator.isNotNullOrEmpty(sFileName) && bReturnFlag) {
						util.formatData (sbFileName, ConstantsUtilIRM.FILEERRORMESSAGE);
						util.formatData (sbState, "In Progress");
					} else {
						util.formatData (sbFileName, sFileName);
						util.formatData (sbState, sState);
					}
					util.formatData (sbFileModified, sFileModified);
					util.formatData (sbRequestedDate, sRequestedDate);      
					util.formatData (sbFilePath, sFilePath);
					util.formatData (sbFileId, sFileId);
					//Modified for defects# 46965,46918,46917,46897,46883 -- END
				}
			}
			mpDSMReports.put(ConstantsUtil.ID, sbReportId.toString());			
			mpDSMReports.put(ConstantsUtil.NAME, sbReportName.toString());
			mpDSMReports.put((String) ConstantsUtilIRM.FILENAME, sbFileName.toString());
			mpDSMReports.put(ConstantsUtil.MODIFIEDDATE, sbFileModified.toString());
			mpDSMReports.put(ConstantsUtil.CREATEDATE, sbRequestedDate.toString());
			mpDSMReports.put(ConstantsUtil.STATE, sbState.toString());
			mpDSMReports.put((String) ConstantsUtilIRM.FILEPATH, sbFilePath.toString());
			mpDSMReports.put(ConstantsUtilIRM.FILEID, sbFileId.toString());
		} catch (Exception ex) {
			dsmLOGGER.error("6.Exception in Program : DSMReportBO Method :getDSMReportData "+ex);
		}
		return mpDSMReports;	
	}

	//Added By Jwala for the defect 99107 : START
	/**Method to check DSM Reports file exists in Azure storage
	 * @param Azure connectionString and containerName
	 * @param args - Information from the list of table
	 * @throws Exception If operation fails.
	 */
	public static boolean checkIfFileExists(String connectionString, String containerName, String strBlobName) {

		CloudStorageAccount storageAccount = null;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container=null;
		CloudBlockBlob blob = null;
		boolean bFileFound = false;	
		try {
			storageAccount = CloudStorageAccount.parse(connectionString);
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(containerName);
			blob = container.getBlockBlobReference(strBlobName);
			if(blob.exists())
				bFileFound = true;
		} catch (InvalidKeyException | URISyntaxException | StorageException | NullPointerException e) {
			dsmLOGGER.error("Exception in getCloudBlobContainer",e);
		} 
		return bFileFound;
	}

	//Added By Jwala for the defect 99107 : END
	/**Method to display DSM Reports Templates
	 * @param context 
	 * @param args - Information from the list of table
	 * @throws Exception If operation fails.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getDSMReportTemplateData(Context context, String strUserName) {

		MapList mlObjectList = new MapList();
		Map<String, String> mpDSMRportTemplates = new HashMap<>();
		String strReportType = ConstantsUtil.EMPTY_STRING;
		String strDisplayName = ConstantsUtil.EMPTY_STRING;
		StringBuilder sbTemplateId = new StringBuilder();
		StringBuilder sbReportType = new StringBuilder();
		StringBuilder sbTemplateName = new StringBuilder();
		StringBuilder sbCreateDate = new StringBuilder();
		try {	       	       
			StringList slTMObjectsSelect = new StringList();
			slTMObjectsSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE);
			slTMObjectsSelect.add(DomainConstants.SELECT_ORIGINATED);
			slTMObjectsSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slTMObjectsSelect.add(DomainConstants.SELECT_ID);
			mlObjectList = DomainObject.findObjects
					(context, //MatrixContext
							ConstantsUtilIRM.TYPE_PGDSMREPORTTEMPLATE, //typePattern
							ConstantsUtil.SYMBL_ASTERISK + strUserName + ConstantsUtil.SYMBL_ASTERISK, //namePattern
							ConstantsUtil.EMPTY_STRING, //revPattern
							ConstantsUtil.SYMBL_ASTERISK, //ownerPattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
							ConstantsUtil.EMPTY_STRING, //whereExpression
							false, //expandType
							slTMObjectsSelect); //objectSelects
			if(null != mlObjectList && !mlObjectList.isEmpty()){
				Collections.sort(mlObjectList, new Comparator<Map<String, String>>() {
					public int compare(Map<String, String> map1, Map<String, String> map2) {
						try {
							DateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
							return Long.valueOf(format.parse(map2.get(DomainConstants.SELECT_ORIGINATED)).getTime()).compareTo(format.parse(map1.get(DomainConstants.SELECT_ORIGINATED)).getTime());
						} catch (Exception e) {
							dsmLOGGER.error("Exception in Program : DSMReportBO Method :compare "+e);
							return 0;
						}
					}
				});	
				int mlObjectListSize = mlObjectList.size();
				for (int i = 0; i < mlObjectListSize; i++) {
					Map<String, String> mpObject = (Map<String, String>)mlObjectList.get(i);
					strReportType = mpObject.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE);
					strDisplayName = getTypeDisplayName(strReportType);
					mpObject.put(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE, strDisplayName);
					String sTemplateId 	= validator.isNotNullOrEmpty(mpObject.get(DomainConstants.SELECT_ID))?mpObject.get(DomainConstants.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String sReportType = validator.isNotNullOrEmpty(mpObject.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE))?mpObject.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE) : ConstantsUtil.EMPTY_STRING;
					String sTemplateName 	= validator.isNotNullOrEmpty(mpObject.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))?mpObject.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING;
					String sCreateDate 	= validator.isNotNullOrEmpty(mpObject.get(DomainConstants.SELECT_ORIGINATED))?mpObject.get(DomainConstants.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING;
					util.formatData (sbTemplateId, sTemplateId);      
					util.formatData (sbReportType, sReportType);        
					util.formatData (sbTemplateName, sTemplateName);     
					util.formatData (sbCreateDate, sCreateDate);
				}
			}
			mpDSMRportTemplates.put(ConstantsUtil.ID, sbTemplateId.toString());			
			mpDSMRportTemplates.put(ConstantsUtil.TYPE, sbReportType.toString());
			mpDSMRportTemplates.put(ConstantsUtil.TEMPLATE, sbTemplateName.toString());
			mpDSMRportTemplates.put(ConstantsUtil.CREATEDATE, sbCreateDate.toString()); 
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getDSMReportTemplateData "+ex);
		} 
		return mpDSMRportTemplates;
	}

	/** Private Method to display Reports Type Name
	 * @param strTypeName
	 * @return String - display Reports Type Name
	 * @throws Exception If operation fails.
	 */	
	private String getTypeDisplayName(String strTypeName) {

		String strTypeDisplayName = ConstantsUtil.EMPTY_STRING;
		try {
			if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.DSMREPORT)) {
				strTypeDisplayName = ConstantsUtilIRM.PARTS_AND_SPECIFICATION_REPORT;
			}
			else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.PDFDOWNLOAD)) {
				strTypeDisplayName = ConstantsUtilIRM.PDF_DOWNLOAD;
			}      
			else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.MASSARTWORKDOWNLOAD)) {
				strTypeDisplayName = ConstantsUtilIRM.MASS_ARTWORK_DOWNLOAD;
			}
			else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.ATSREPORT)) {
				strTypeDisplayName = ConstantsUtilIRM.ATS_REPORT;
			}
			else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.REFERENCEDOCUMENTREPORT)) {
				strTypeDisplayName = ConstantsUtilIRM.REFERENCE_DOCUMENT_REPORT;
			}
			//Added by Ketan for Req. no. 42801 -- START
			else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.CHARACTERISTICMASTERREPORT)) {
				strTypeDisplayName = ConstantsUtilIRM.CHARACTERISTIC_MASTER_REPORT;
			}
			else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.CERTIFICATIONROLLUP)) {
				strTypeDisplayName = ConstantsUtilIRM.CERTIFICATION_ROLL_UP;
			}
			else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.WHEREUSEDREPORT)) {
				strTypeDisplayName = ConstantsUtilIRM.WHERE_USED_REPORT;
			}
			//Added by Ketan for Req. no. 42801 -- END
			else {         
				strTypeDisplayName = strTypeName;
			} 
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getTypeDisplayName "+ex);		      
		} 
		return strTypeDisplayName;
	}

	/**
	 * Method Name 			: getDSMReportDetails
	 * Method Description 	: Fetching "DSM Report Details" related data
	 * @param context 
	 * @param strObjId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getDSMReportDetails(Context context, String strObjId) {

		Map<String, String> mDSMReportDetails = new HashMap<>();
		StringList slDSMReportSelects = new StringList();
		slDSMReportSelects.add(DomainConstants.SELECT_TYPE);
		slDSMReportSelects.add(DomainConstants.SELECT_NAME);
		slDSMReportSelects.add(DomainConstants.SELECT_REVISION);
		slDSMReportSelects.add(DomainConstants.SELECT_VAULT);
		slDSMReportSelects.add(DomainConstants.SELECT_DESCRIPTION);
		slDSMReportSelects.add(DomainConstants.SELECT_OWNER);
		slDSMReportSelects.add(DomainConstants.SELECT_ID);
		slDSMReportSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCA);
		slDSMReportSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTGCAS);
		slDSMReportSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTREQUESTEDDATE);
		slDSMReportSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMCUSTOMNAME);
		slDSMReportSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCTRLM);
		slDSMReportSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTREALTIME);
		slDSMReportSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE);
		slDSMReportSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTREQUESTEDBY);
		String strOwner = ConstantsUtil.EMPTY_STRING;
		try {
			DomainObject doObjectDetails = DomainObject.newInstance(context,strObjId);
			Map<String, String> mObjDetails = doObjectDetails.getInfo(context,slDSMReportSelects);				
			if (mObjDetails!=null) {
				mDSMReportDetails.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_ID)))?mObjDetails.get(DomainConstants.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mDSMReportDetails.put(ConstantsUtil.TYPE, ConstantsUtilIRM.DSM_REPORT);
				mDSMReportDetails.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_NAME)))?mObjDetails.get(DomainConstants.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mDSMReportDetails.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_REVISION)))?mObjDetails.get(DomainConstants.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mDSMReportDetails.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_VAULT)))?mObjDetails.get(DomainConstants.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
				mDSMReportDetails.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_DESCRIPTION)))?mObjDetails.get(DomainConstants.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				String strUser = validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_OWNER))?mObjDetails.get(DomainConstants.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING;
				if (UIUtil.isNotNullAndNotEmpty(strUser)) {
					strOwner = PersonUtil.getFullName(context, strUser);
				}
				mDSMReportDetails.put(ConstantsUtil.OWNER, strOwner);
				mDSMReportDetails.put(ConstantsUtilIRM.CHANGEACTION, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCA)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCA) : ConstantsUtil.EMPTY_STRING);
				mDSMReportDetails.put(ConstantsUtilIRM.PGPRODUCTPARTNAME, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTGCAS)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTGCAS) : ConstantsUtil.EMPTY_STRING);		
				mDSMReportDetails.put(ConstantsUtilIRM.CUSTOMNAME, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMCUSTOMNAME)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMCUSTOMNAME) : ConstantsUtil.EMPTY_STRING);
				mDSMReportDetails.put(ConstantsUtilIRM.PGDSMREPORTCTRLM, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCTRLM)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCTRLM) : ConstantsUtil.EMPTY_STRING);
				mDSMReportDetails.put(ConstantsUtilIRM.PGDSMREPORTREALTIME, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTREALTIME)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTREALTIME) : ConstantsUtil.EMPTY_STRING);
				mDSMReportDetails.put(ConstantsUtil.CREATEDATE, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTREQUESTEDDATE)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTREQUESTEDDATE) : ConstantsUtil.EMPTY_STRING);
				String strReportType = mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE);
				String strDisplayName = getTypeDisplayName(strReportType);
				mDSMReportDetails.put(ConstantsUtil.CUSTOMIZATIONTYPE, strDisplayName);
				mDSMReportDetails.put(ConstantsUtilIRM.REQUESTEDBY, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTREQUESTEDBY)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTREQUESTEDBY) : ConstantsUtil.EMPTY_STRING);
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getDSMReportDetails "+ex);
		} 
		return mDSMReportDetails;
	}

	/**
	 * Method Name 			: getDSMReportDetailsHeader
	 * Method Description 	: Fetching "DSM Report Header" related data
	 * @param context 
	 * @param strObjId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getDSMReportDetailsHeader(Context context, String strObjId) {

		Map<String, String> mDSMReportHeader = new HashMap<>();
		StringList slDSMReportSelects = new StringList();
		slDSMReportSelects.add(DomainConstants.SELECT_TYPE);
		slDSMReportSelects.add(DomainConstants.SELECT_NAME);
		slDSMReportSelects.add(DomainConstants.SELECT_REVISION);
		slDSMReportSelects.add(DomainConstants.SELECT_OWNER);
		slDSMReportSelects.add(DomainConstants.SELECT_CURRENT);
		slDSMReportSelects.add(DomainConstants.SELECT_MODIFIED);
		try {
			DomainObject doObjectDetails = DomainObject.newInstance(context,strObjId);
			Map<String, String> mObjDetails = doObjectDetails.getInfo(context,slDSMReportSelects);
			mDSMReportHeader.put(ConstantsUtil.TYPE, ConstantsUtilIRM.DSM_REPORT);
			mDSMReportHeader.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_NAME)))?mObjDetails.get(DomainConstants.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mDSMReportHeader.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_REVISION)))?mObjDetails.get(DomainConstants.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mDSMReportHeader.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_OWNER)))?mObjDetails.get(DomainConstants.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mDSMReportHeader.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_CURRENT)))?mObjDetails.get(DomainConstants.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mDSMReportHeader.put(ConstantsUtil.MODIFIEDDATE, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_MODIFIED)))?mObjDetails.get(DomainConstants.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :mDSMReportHeader "+ex);
		} 
		return mDSMReportHeader;
	}

	/**
	 * Method Name 			: getDSMReportDetailsHeader
	 * Method Description 	: Fetching "DSM Report Header" related data
	 * @return
	 */
	public Map<String, String> getDSMReportIPClassification() {

		Map<String, String> mIPClassification = new HashMap<>();
		StringList slDSMReportSelects = new StringList();
		slDSMReportSelects.add(DomainConstants.SELECT_TYPE);
		slDSMReportSelects.add(DomainConstants.SELECT_NAME);
		slDSMReportSelects.add(DomainConstants.SELECT_REVISION);
		slDSMReportSelects.add(DomainConstants.SELECT_OWNER);
		slDSMReportSelects.add(DomainConstants.SELECT_CURRENT);
		slDSMReportSelects.add(DomainConstants.SELECT_MODIFIED);
		try {
			mIPClassification.put(ConstantsUtil.CLASSIFICATION, ConstantsUtil.EMPTY_STRING);
			mIPClassification.put(ConstantsUtilIRM.SECURITYCATEGORYCLASSIFICATION, ConstantsUtil.EMPTY_STRING);
			mIPClassification.put(ConstantsUtilIRM.PROJECTSECURITYCLASSIFICATION, ConstantsUtil.EMPTY_STRING);
			mIPClassification.put(ConstantsUtilIRM.LIMITACCESSTONAMEDUSERS, ConstantsUtil.EMPTY_STRING);

		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :mDSMReportHeader "+ex);
		} 
		return mIPClassification;
	}

	/**
	 * Method Name 			: getDSMreportTemplateDetails
	 * Method Description 	: Fetching "DSM Template Details" related data
	 * @param context 
	 * @param strObjId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getDSMreportTemplateDetails(Context context, String strObjId) {

		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		StringList slDSMTemplateSelects = new StringList();
		slDSMTemplateSelects.add(DomainConstants.SELECT_TYPE);
		slDSMTemplateSelects.add(DomainConstants.SELECT_NAME);
		slDSMTemplateSelects.add(DomainConstants.SELECT_REVISION);
		slDSMTemplateSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTEMPLATEVALUE);
		slDSMTemplateSelects.add(DomainConstants.SELECT_ID);
		slDSMTemplateSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCA);
		slDSMTemplateSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTGCAS);
		slDSMTemplateSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCUSTOMNAME);
		slDSMTemplateSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE);
		slDSMTemplateSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_TITLE);

		try {
			DomainObject doObjectDetails = DomainObject.newInstance(context,strObjId);
			Map<String, String> mObjDetails = doObjectDetails.getInfo(context,slDSMTemplateSelects);				

			String strReportType = mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE);
			String strDisplayName = getTypeDisplayName(strReportType);

			String strDescription = mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTEMPLATEVALUE);
			if(strReportType.equalsIgnoreCase(ConstantsUtilIRM.ATSREPORT)){
				mDSMTemplateDetails = getATSReportValues(strDescription);
				mDSMTemplateDetails.put(ConstantsUtilIRM.PDFVIEW, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.ARTWORKPDF, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.FINALARTWORKPDF, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.EXPORTPOA, ConstantsUtil.FALSE);
			}
			if(strReportType.equalsIgnoreCase(ConstantsUtilIRM.REFERENCEDOCUMENTREPORT)){
				mDSMTemplateDetails = getReferenceDocReportValues(strDescription);
				mDSMTemplateDetails.put(ConstantsUtilIRM.PDFVIEW, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.ARTWORKPDF, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.FINALARTWORKPDF, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.EXPORTPOA, ConstantsUtil.FALSE);
			}
			if(strReportType.equalsIgnoreCase(ConstantsUtilIRM.MASSARTWORKDOWNLOAD)){
				mDSMTemplateDetails = getMassArtworkReportValues(strDescription);
				mDSMTemplateDetails.put(ConstantsUtilIRM.PDFVIEW, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELESEINPUT, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.FALSE);
			}
			if(strReportType.equalsIgnoreCase(ConstantsUtilIRM.PDFDOWNLOAD)){
				mDSMTemplateDetails = getPDFDownloadReportValues(strDescription);
				mDSMTemplateDetails.put(ConstantsUtilIRM.ARTWORKPDF, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.FINALARTWORKPDF, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.EXPORTPOA, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELESEINPUT, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.FALSE);
			}
			if(strReportType.equalsIgnoreCase(ConstantsUtilIRM.DSMREPORT)){
				mDSMTemplateDetails = getPartAndSpecReportValues(strDescription);
				mDSMTemplateDetails.put(ConstantsUtilIRM.ARTWORKPDF, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.FINALARTWORKPDF, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.EXPORTPOA, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELESEINPUT, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.PDFVIEW, ConstantsUtil.FALSE);
			}

			//Added by Ketan for Req. no. 42801 -- START
			if(strReportType.equalsIgnoreCase(ConstantsUtilIRM.CHARACTERISTICMASTERREPORT)){
				mDSMTemplateDetails = getCharMasterReportValues(strDescription);
				String selectedBusValues = mDSMTemplateDetails.get(ConstantsUtilIRM.SELECTED_MASTER_BUSAREA);
				String strType = ConstantsUtilIRM.MASTER_BUSAREA;
				Map<String,String> mBAorCCpicklist = dsbo.getBusAreaOrCertClaimPickList(context, strType);
				mBAorCCpicklist.remove(ConstantsUtil.ID);
				String value = mBAorCCpicklist.remove(ConstantsUtilIRM.MASTER_BUSAREA);//changing the key here
				String[] values = value.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

				String tempBusValue = ConstantsUtil.EMPTY_STRING;
				StringList slBusValues = new StringList();
				for(int i=0;i<values.length;i++) {
					String sEachBusValues = values[i];
					if(!selectedBusValues.contains(sEachBusValues)) {
						tempBusValue = values[i];
						slBusValues.add(tempBusValue);
					}
				}
				String sBusValues = slBusValues.toString();
				sBusValues = sBusValues.replaceAll(ConstantsUtilIRM.COMMA_SPACE, ConstantsUtil.SYMBL_COMMA);
				mBAorCCpicklist.put(ConstantsUtilIRM.MASTER_BUSAREAS, sBusValues);
				mDSMTemplateDetails.putAll(mBAorCCpicklist);
			}

			if(strReportType.equalsIgnoreCase(ConstantsUtilIRM.CERTIFICATIONROLLUP)){
				mDSMTemplateDetails = getCertificationRollUpValues(strDescription);
				String selectedBusValues = mDSMTemplateDetails.get(ConstantsUtilIRM.SELECTED_CERT_BUSAREA);
				String strType = ConstantsUtilIRM.CERT_BUSAREA;
				Map<String,String> mBAorCCpicklist = dsbo.getBusAreaOrCertClaimPickList(context, strType);
				mBAorCCpicklist.remove(ConstantsUtil.ID);
				String value = mBAorCCpicklist.get(ConstantsUtilIRM.CERT_BUSAREA);
				String[] values = value.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

				String tempBusValue = ConstantsUtil.EMPTY_STRING;
				StringList slBusValues = new StringList();
				for(int i=0;i<values.length;i++) {
					String sEachBusValues = values[i];
					if(!selectedBusValues.contains(sEachBusValues)) {
						tempBusValue = values[i];
						slBusValues.add(tempBusValue);
					}
				}
				String sBusValues = slBusValues.toString();
				sBusValues = sBusValues.replaceAll(ConstantsUtilIRM.COMMA_SPACE, ConstantsUtil.SYMBL_COMMA);
				mBAorCCpicklist.put(ConstantsUtilIRM.CERT_BUSAREA, sBusValues);
				mDSMTemplateDetails.putAll(mBAorCCpicklist);
			}

			if(strReportType.equalsIgnoreCase(ConstantsUtilIRM.WHEREUSEDREPORT)){
				mDSMTemplateDetails = getWhereUsedReportValues(strDescription);
			}
			//Added by Ketan for Req. no. 42801 -- END

			if(!strReportType.equalsIgnoreCase(ConstantsUtilIRM.CHARACTERISTICMASTERREPORT)){
				mDSMTemplateDetails.put(ConstantsUtilIRM.MASTER_BUSAREAS, ConstantsUtil.EMPTY_STRING);
				mDSMTemplateDetails.put(ConstantsUtilIRM.SELECTED_MASTER_BUSAREA, ConstantsUtil.EMPTY_STRING);
			}
			if(!strReportType.equalsIgnoreCase(ConstantsUtilIRM.CERTIFICATIONROLLUP)){
				mDSMTemplateDetails.put(ConstantsUtilIRM.CERT_BUSAREA, ConstantsUtil.EMPTY_STRING);
				mDSMTemplateDetails.put(ConstantsUtilIRM.SELECTED_CERT_BUSAREA, ConstantsUtil.EMPTY_STRING);
			}
			if(!strReportType.equalsIgnoreCase(ConstantsUtilIRM.WHEREUSEDREPORT)){
				mDSMTemplateDetails.put(ConstantsUtilIRM.SELECTEDLEVEL, ConstantsUtil.EMPTY_STRING);
			}
			if(!strReportType.equalsIgnoreCase(ConstantsUtilIRM.DSMREPORT) && (!strReportType.equalsIgnoreCase(ConstantsUtilIRM.PDFDOWNLOAD))) {
				mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELEASE, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.EXPANDPRODUCTBOM, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEPRODUCTBOM, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEPACKAGEBOM, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.ATTRIBUTES, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.ALTERNATE, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.APPROVE, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.CONST_BATTERYROLLUP, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtil.BILLOFMATERIALS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.CHARACTERISTICSAPOLLO, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.CHEMPHYPROPERTIES, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.PGDESIGNPARAMETER, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.EBOMWND, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.FOPFORMULAINGREDIENT, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.FOPVIEWSUBSTITUTES, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.GPSASSESMENTS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.MARKETCLEARANCE, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.MARKETOFSALE, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.MATERIALSANDCOMPOSITION, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.MEPSEPCERTIFICATIONS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.MEPSEPCOMPEQTS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.NOTES, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.PARTCERTIFICATIONS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.PARTCOMPONENTEQUIVALENTS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtil.PLANTS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.PRODUCINGFORMULA, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.SAPBOMASFED, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.SPECSANDDOCS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.SUBSTANCESANDMATERIALS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.WEIGHTSANDDIMENSIONS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.CHARACTERISTICSLPD, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.DGCLASS, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.IPEXPORTCONTROL, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.SUBSPARTSIN, ConstantsUtil.FALSE);
				mDSMTemplateDetails.put(ConstantsUtilIRM.SUSTAINABILITY, ConstantsUtil.FALSE);
			}
			mDSMTemplateDetails.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_ID)))?mObjDetails.get(DomainConstants.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			mDSMTemplateDetails.put(ConstantsUtil.TYPE, ConstantsUtilIRM.DSM_REPORT);
			mDSMTemplateDetails.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_NAME)))?mObjDetails.get(DomainConstants.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mDSMTemplateDetails.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_REVISION)))?mObjDetails.get(DomainConstants.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mDSMTemplateDetails.put(ConstantsUtilIRM.CHANGEACTION, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCA)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCA) : ConstantsUtil.EMPTY_STRING);
			mDSMTemplateDetails.put(ConstantsUtilIRM.PGPRODUCTPARTNAME, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTGCAS)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTGCAS) : ConstantsUtil.EMPTY_STRING);		
			mDSMTemplateDetails.put(ConstantsUtilIRM.CUSTOMNAME, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCUSTOMNAME)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTCUSTOMNAME) : ConstantsUtil.EMPTY_STRING);
			mDSMTemplateDetails.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_TITLE)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mDSMTemplateDetails.put(ConstantsUtil.CUSTOMIZATIONTYPE, strDisplayName);
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getDSMreportTemplateDetails "+ex);
		} 
		return mDSMTemplateDetails;
	}

	//Added by Ketan for Req. no. 42796 -- START
	private Map<String, String> getCertificationRollUpValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtilIRM.SYMBOL_CAP);
			if (slDescription.size()>1) {
				mDSMTemplateDetails = getCertificationClaims(strDescription);
				Iterator<String> itrDesc = slDescription.iterator();
				while(itrDesc.hasNext()) {
					String strDescValue = itrDesc.next();
					if(strDescValue.contains(ConstantsUtilIRM.HYPERLINKASINPUT)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.FALSE);
						}
					}
					if(strDescValue.contains(ConstantsUtilIRM.LATESTVERSIONASINPUT)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELESEINPUT, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELESEINPUT, ConstantsUtil.FALSE);
						}
					}
				}
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getCertificationRollUpValues "+ex);
		} 
		return mDSMTemplateDetails;
	}

	private Map<String, String> getCertificationClaims(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			String strDesc = strDescription.replace(ConstantsUtilIRM.SELCERT_PIPE, ConstantsUtil.SYMBL_TILDA);
			String[] sDescription = strDesc.split(ConstantsUtil.SYMBL_TILDA);
			String[] sDesc = new String[sDescription.length-1];
			System.arraycopy(sDescription, 1, sDesc, 0, sDesc.length);
			String sDescFinal = Arrays.toString(sDesc);
			sDescFinal = sDescFinal.replaceAll(ConstantsUtilIRM.COMMA_SPACE, ConstantsUtil.SYMBL_COMMA);
			mDSMTemplateDetails.put(ConstantsUtilIRM.SELECTED_CERT_BUSAREA, sDescFinal);
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getSelectedBusinessAreas "+ex);
		} 
		return mDSMTemplateDetails;
	}
	//Added by Ketan for Req. no. 42796 -- END

	//Added by Ketan for Req. no. 42791 -- START
	private Map<String, String> getCharMasterReportValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtilIRM.SYMBOL_CAP);
			if (slDescription.size()>1) {
				mDSMTemplateDetails = getSelectedBusinessAreas(strDescription);
				Iterator<String> itrDesc = slDescription.iterator();
				while(itrDesc.hasNext()) {
					String strDescValue = itrDesc.next();
					if(strDescValue.contains(ConstantsUtilIRM.INPUT_RELEASECMONLY)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.RELEASECMONLY, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.RELEASECMONLY, ConstantsUtil.FALSE);
						}
					} 
					if(strDescValue.contains(ConstantsUtilIRM.INPUT_LATESTRELCM)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELCM, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELCM, ConstantsUtil.FALSE);
						}
					}
				}
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getCharMasterReportValues "+ex);
		} 
		return mDSMTemplateDetails;
	}

	private Map<String, String> getSelectedBusinessAreas(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			String strDesc = strDescription.replace(ConstantsUtilIRM.SELBUSAREAS_PIPE, ConstantsUtil.SYMBL_TILDA);
			String[] sDescription = strDesc.split(ConstantsUtil.SYMBL_TILDA);
			String[] sDesc = new String[sDescription.length-1];
			System.arraycopy(sDescription, 1, sDesc, 0, sDesc.length);
			String sDescFinal = Arrays.toString(sDesc);
			sDescFinal = sDescFinal.replaceAll(ConstantsUtilIRM.COMMA_SPACE, ConstantsUtil.SYMBL_COMMA);
			mDSMTemplateDetails.put(ConstantsUtilIRM.SELECTED_MASTER_BUSAREA, sDescFinal);
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getSelectedBusinessAreas "+ex);
		} 
		return mDSMTemplateDetails;
	}
	//Added by Ketan for Req. no. 42791 -- END

	//Added by Ketan for Req. no. 47049 -- START
	private Map<String, String> getWhereUsedReportValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtilIRM.SYMBOL_CAP);
			if (slDescription.size()>1) {
				Iterator<String> itrDesc = slDescription.iterator();
				while(itrDesc.hasNext()) {
					String strDescValue = itrDesc.next();
					if(strDescValue.contains(ConstantsUtilIRM.INPUT_WHEREUSEDLATESTRELPART)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.WHEREUSEDLATESTRELPART, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.WHEREUSEDLATESTRELPART, ConstantsUtil.FALSE);
						}
					} 
					if(strDescValue.contains(ConstantsUtilIRM.HYPERLINKASINPUT)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.FALSE);
						}
					}
					if(strDescValue.contains(ConstantsUtilIRM.INPUT_LEVELSELECTED)){
						String[] sDescValue = strDescValue.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						mDSMTemplateDetails.put(ConstantsUtilIRM.SELECTEDLEVEL, sDescValue[1]);
					}
				}
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getWhereUsedReportValues "+ex);
		} 
		return mDSMTemplateDetails;
	}
	//Added by Ketan for Req. no. 47049 -- END

	//SPEC: 12.30.2021: Added for Req- 41530,41531 Dev 18x.6.0.3  -- START
	/**Method to provide CA validation result
	 * @param context,Map
	 * @throws Exception If operation fails.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getCAValidationResult(Context context, Map<String, Object> mpCAValidationInput) {

		MapList mlObjectList = new MapList();
		Map<String, String> mpCAValidation = new HashMap<>();
		String strCAid = ConstantsUtil.EMPTY_STRING;
		String strPartName = (String) mpCAValidationInput.get(ConstantsUtilIRM.PARTNAME);
		String strCAName = (String) mpCAValidationInput.get(ConstantsUtilIRM.CHANGEACTION);
		String strDailyCount = (String) mpCAValidationInput.get(ConstantsUtilIRM.DAILYCOUNTER);
		String strMaxCounter = (String) mpCAValidationInput.get(ConstantsUtilIRM.MAXCOUNTER);
		int iMaxCounter = Integer.parseInt(strMaxCounter) ;
		String sReportType = (String) mpCAValidationInput.get(ConstantsUtilIRM.REPORTNAME);
		Boolean bArtworkPDF =(Boolean) mpCAValidationInput.get(ConstantsUtilIRM.ARTWORKPDF);
		Boolean bFinalArtworkPDF = (Boolean) mpCAValidationInput.get(ConstantsUtilIRM.FINALARTWORKPDF);
		Boolean bExportPOA = (Boolean) mpCAValidationInput.get(ConstantsUtilIRM.EXPORTPOA);

		Map<String, String> mDSMReportAttribute = new HashMap<>();
		int icountFinal = 0;
		int iDailyFinalCount = 0;
		int iDailyCount = 0;
		int iPartCount = 0;
		int iCountLeft = 0;
		boolean bCACheck = true;
		try {	
			StringList slObjectsSelect = new StringList();
			slObjectsSelect.add(DomainConstants.SELECT_ID);
			mlObjectList = DomainObject.findObjects
					(context, //MatrixContext
							ConstantsUtil.TYPE_CHANGEACTION, //typePattern
							strCAName, //namePattern
							ConstantsUtil.SYMBL_DASH, //revPattern
							ConstantsUtil.SYMBL_ASTERISK, //ownerPattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
							ConstantsUtil.EMPTY_STRING, //whereExpression
							false, //expandType
							slObjectsSelect); //objectSelects
			if(!strDailyCount.isEmpty()){
				iDailyCount = Integer.parseInt(strDailyCount) ;
			}
			int mlObjectListSize = mlObjectList.size();
			for (int i = 0; i < mlObjectListSize; i++) {
				Map<String, String> mpObject = (Map<String, String>)mlObjectList.get(i);
				strCAid = mpObject.get(DomainConstants.SELECT_ID);
				String sQuery = BusExtractUtil.createCAExpandQuery(strCAid);
				String sQueryResult = BusExtractUtil.executeTempQuery(context, sQuery);
				String[] sQueResult = sQueryResult.split(ConstantsUtil.SYMBL_NEWLINE);
				int iCount = sQueResult.length;
				icountFinal = iCount + icountFinal;
			}
			mDSMReportAttribute = getDSMReportConfiguration(context);
			if(icountFinal != 0){
				bCACheck = getCAValidationCount(icountFinal, mDSMReportAttribute, sReportType);
			}
			if(!strPartName.isEmpty()) {
				String[] sPartNames = strPartName.split(ConstantsUtil.SYMBL_COMMA);
				iPartCount = sPartNames.length;
			}
			icountFinal = icountFinal + iPartCount;
			boolean bCheck = getCAValidationCount(icountFinal, mDSMReportAttribute, sReportType);
			if(sReportType.equalsIgnoreCase(ConstantsUtilIRM.MASS_ARTWORK_DOWNLOAD)){
				icountFinal = getArtworkPOACount(icountFinal, bArtworkPDF, bFinalArtworkPDF, bExportPOA);
			}
			iDailyFinalCount = icountFinal + iDailyCount;
			if(bCheck) {
				if(iDailyCount >= iMaxCounter){
					mpCAValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.E111);			
					mpCAValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.E111_ERROR);
					mpCAValidation.put(ConstantsUtilIRM.DAILYCOUNTER, String.valueOf(iDailyCount));
				} else if(iDailyFinalCount <= iMaxCounter){
					mpCAValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.S101);			
					mpCAValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.S101_SUCCESS);
					mpCAValidation.put(ConstantsUtilIRM.DAILYCOUNTER, String.valueOf(iDailyFinalCount));
				} else {
					iCountLeft = iDailyFinalCount - iMaxCounter;
					mpCAValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.E112);
					String strE112Error = ConstantsUtilIRM.E112_ERROR1+String.valueOf(iMaxCounter)+ConstantsUtilIRM.E112_ERROR2+String.valueOf(iCountLeft)+ConstantsUtilIRM.E112_ERROR3;
					mpCAValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, strE112Error);
					mpCAValidation.put(ConstantsUtilIRM.DAILYCOUNTER, String.valueOf(iDailyCount));
				}
			} else if(!bCACheck){
				mpCAValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.E110);			
				mpCAValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.LIMIT_CA_ERROR1+mDSMReportAttribute.get(sReportType)+ConstantsUtilIRM.LIMIT_CA_ERROR2);
				mpCAValidation.put(ConstantsUtilIRM.DAILYCOUNTER, String.valueOf(iDailyCount));
			} else {
				mpCAValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.E110);			
				mpCAValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.LIMIT_ERROR1+mDSMReportAttribute.get(sReportType)+ConstantsUtilIRM.LIMIT_ERROR2);
				mpCAValidation.put(ConstantsUtilIRM.DAILYCOUNTER, String.valueOf(iDailyCount));
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getCAValidationResult "+ex);
		} 
		return mpCAValidation;
	}

	/**
	 * Method Name 			: getDSMReportConfiguration
	 * Method Description 	: Fetching "DSM Report" Configuration object related data
	 * @param context
	 * @throws Exception If operation fails.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getDSMReportConfiguration(Context context) {

		Map<String, String> mDSMReportObject = new HashMap<>();	
		StringList slObjectSelects = new StringList();			
		slObjectSelects.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE);
		try {
			MapList mlUpdateConfiguration = DomainObject.findObjects
					(context, //MatrixContext
							ConstantsUtil.TYPE_PGCONFIGURATIONADMIN, //typePattern
							ConstantsUtilIRM.DSMREPORTCONFIGURATION,  //namePattern
							ConstantsUtil.SYMBL_DASH,  //revPattern
							ConstantsUtil.SYMBL_ASTERISK,  //ownerPattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION,  //vaultPattern
							null, //whereExpression
							false, //expandType
							slObjectSelects); //objectSelects

			if(null != mlUpdateConfiguration){
				Map<String, String> mConfigInfo = (Map<String, String>)mlUpdateConfiguration.get(0);	
				String sReportOption = mConfigInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSMREPORTTYPE);
				StringList slReportIds =StringUtil.split(sReportOption, ConstantsUtil.SYMBL_PIPE);			
				Iterator<String> itrObjectList = slReportIds.iterator();
				while(itrObjectList.hasNext()) {
					String strMaster=itrObjectList.next();
					StringList slResult = StringUtil.split(strMaster, ConstantsUtil.SYMBL_TILDA);
					mDSMReportObject.put(slResult.get(0), slResult.get(7));
				}
			}	
		} catch (Exception e) {
			dsmLOGGER.error("Error from DSMREPORTBO: getDSMReportConfiguration"+e);
		} 
		return mDSMReportObject;	
	}

	public boolean getCAValidationCount(int strCount, Map<String, String> mDSMReportAttribute, String sReportType) {
		boolean bCheck = false;
		try {
			int iDefinedCount = Integer.parseInt(mDSMReportAttribute.get(sReportType));
			if (strCount > iDefinedCount){
				bCheck = false;
			} else{
				bCheck = true;
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getCAValidationCount "+ex);
		} 
		return bCheck;
	}

	public int getArtworkPOACount(int strCount, Boolean bArtworkPDF, Boolean bFinalArtworkPDF, Boolean bExportPOA) {
		int iArtworkCount = 0;
		try {
			if(Boolean.TRUE.equals(bArtworkPDF) || Boolean.TRUE.equals(bFinalArtworkPDF)){
				iArtworkCount++;
			}
			if(Boolean.TRUE.equals(bExportPOA)){
				iArtworkCount++;
			}
			if(iArtworkCount != 0){
				strCount = strCount * iArtworkCount;
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getArtworkPOACount "+ex);
		} 
		return strCount;
	}
	//SPEC: 12.30.2021: Added for Req- 41530,41531 Dev 18x.6.0.3  -- END
	//SPEC: 01.05.2021: Added for Req- 41555 Dev 18x.6.0.3  -- START	
	public Map<String, String> getATSReportValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtilIRM.SYMBOL_CAP);
			if (slDescription.size()>1) {
				Iterator<String> itrDesc = slDescription.iterator();
				while(itrDesc.hasNext()) {
					String strDescValue = itrDesc.next();
					if(strDescValue.contains(ConstantsUtilIRM.LATESTVERSIONASINPUT)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELESEINPUT, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELESEINPUT, ConstantsUtil.FALSE);
						}
					} 
					if(strDescValue.contains(ConstantsUtilIRM.HYPERLINKASINPUT)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.FALSE);
						}
					}
				}
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getATSReportValues "+ex);
		} 
		return mDSMTemplateDetails;
	}

	public Map<String, String> getReferenceDocReportValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtilIRM.SYMBOL_CAP);
			if (slDescription.size()>1) {
				Iterator<String> itrDesc = slDescription.iterator();
				while(itrDesc.hasNext()) {
					String strDescValue = itrDesc.next();
					if(strDescValue.contains(ConstantsUtilIRM.LATESTVERSIONASINPUTREFDOC)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELESEINPUT, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELESEINPUT, ConstantsUtil.FALSE);
						}
					} 
					if(strDescValue.contains(ConstantsUtilIRM.HYPERLINKASINPUT)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.FALSE);
						}
					}
					//Added By Ajay for the Req 17585 : START
					if(strDescValue.contains(ConstantsUtilIRM.INCLUDEFILEINFO)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEFILEINFO, ConstantsUtil.TRUE);
						} else {
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEFILEINFO, ConstantsUtil.FALSE);
						}
					}
					//Added By Ajay for the Req 17585 : END
				}
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getReferenceDocReportValues "+ex);
		} 
		return mDSMTemplateDetails;
	}

	public Map<String, String> getMassArtworkReportValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtilIRM.SYMBOL_CAP);
			if (slDescription.size()>1) {
				Iterator<String> itrDesc = slDescription.iterator();
				while(itrDesc.hasNext()) {
					String strDescValue = itrDesc.next();
					if(strDescValue.contains(ConstantsUtilIRM.CONST_FINALARTWORKPDF))
					{if(strDescValue.contains(ConstantsUtil.TRUE)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.FINALARTWORKPDF, ConstantsUtil.TRUE);
					} else {
						mDSMTemplateDetails.put(ConstantsUtilIRM.FINALARTWORKPDF, ConstantsUtil.FALSE);
					}
					} 
					if(strDescValue.contains(ConstantsUtilIRM.CONST_EXPORTPOA))
					{if(strDescValue.contains(ConstantsUtil.TRUE)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.EXPORTPOA, ConstantsUtil.TRUE);
					} else {
						mDSMTemplateDetails.put(ConstantsUtilIRM.EXPORTPOA, ConstantsUtil.FALSE);
					}
					}
					if(strDescValue.contains(ConstantsUtilIRM.CONST_PDFARTWORK))
					{if(strDescValue.contains(ConstantsUtil.TRUE)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.ARTWORKPDF, ConstantsUtil.TRUE);
					} else {
						mDSMTemplateDetails.put(ConstantsUtilIRM.ARTWORKPDF, ConstantsUtil.FALSE);
					}
					}
				}
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getMassArtworkReportValues "+ex);
		} 
		return mDSMTemplateDetails;
	}

	public Map<String, String> getPDFDownloadReportValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtil.SYMBL_PIPE);
			String strValue = DomainConstants.EMPTY_STRING;
			if (slDescription.size()>1) {
				//SPEC: 03.08.2022: Added for Defect- 46882 Dev 18x.6.0.3  -- START
				if(strDescription.contains(ConstantsUtilIRM.DEFAULT)){
					strValue = ConstantsUtilIRM.DEFAULT;
				}else if(strDescription.contains(ConstantsUtilIRM.CONTRACTPACKAGING)){
					strValue = ConstantsUtilIRM.CONTRACTPACKAGING;
				}else if(strDescription.contains(ConstantsUtilIRM.SUPPLIER)){
					strValue = ConstantsUtilIRM.SUPPLIER;
				} else if(strDescription.contains(ConstantsUtilIRM.CPV_CONSOLIDATEDPACKAGING)){
					strValue = ConstantsUtilIRM.CPV_CONSOLIDATEDPACKAGING;
				}
				//SPEC: 03.08.2022: Added for Defect- 46882 Dev 18x.6.0.3  -- END
			}
			mDSMTemplateDetails = getPDFDownloadSelectdValues(strDescription);
			mDSMTemplateDetails.put(ConstantsUtilIRM.PDFVIEW, strValue);

		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getPDFDownloadReportValues "+ex);
		} 
		return mDSMTemplateDetails;
	}

	public Map<String, String> getPartAndSpecReportValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtilIRM.SYMBOL_CAP);
			if (slDescription.size()>1) {
				mDSMTemplateDetails = getPartandSpecValues(strDescription);
				Iterator<String> itrDesc = slDescription.iterator();
				while(itrDesc.hasNext()) {
					String strDescValue = itrDesc.next();
					if(strDescValue.contains(ConstantsUtilIRM.CONST_INCLUDEFOPCHILDTOBOM))
					{
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEPRODUCTBOM, ConstantsUtil.TRUE);
						}
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.INCLUDEPRODUCTBOM)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEPRODUCTBOM, ConstantsUtil.FALSE);
					}
					if(strDescValue.contains(ConstantsUtilIRM.CONST_EXPANDPRODUCTBOM))
					{
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.EXPANDPRODUCTBOM, ConstantsUtil.TRUE);
						}
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.EXPANDPRODUCTBOM)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.EXPANDPRODUCTBOM, ConstantsUtil.FALSE);
					}
					if(strDescValue.contains(ConstantsUtilIRM.EXPANDPRODUCTCHILDBOM))
					{
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEPACKAGEBOM, ConstantsUtil.TRUE);
						}
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.INCLUDEPACKAGEBOM)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEPACKAGEBOM, ConstantsUtil.FALSE);
					}
					if(strDescValue.contains(ConstantsUtilIRM.LATESTRELEASEPARTONLY)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){
							mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELEASE, ConstantsUtil.TRUE);
						}
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.LATESTRELEASE)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.LATESTRELEASE, ConstantsUtil.FALSE);
					}
					if(strDescValue.contains(ConstantsUtilIRM.HYPERLINKASINPUT)){
						if(strDescValue.contains(ConstantsUtil.TRUE)){	
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.TRUE);
						}
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.INCLUDEHYPERLINK)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEHYPERLINK, ConstantsUtil.FALSE);
					}
					if(strDescValue.contains(ConstantsUtilIRM.INPUT_INCLUDEMATCOMPFROMCOMPEQUV)){	
						if(strDescValue.contains(ConstantsUtil.TRUE)) {
							mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEMATCOMPFROMCOMPEQUV, ConstantsUtil.TRUE);
						}
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.INCLUDEMATCOMPFROMCOMPEQUV)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.INCLUDEMATCOMPFROMCOMPEQUV, ConstantsUtil.FALSE);
					}
					//Added by Ajay for Req. 78583 -- START
					if(strDescValue.contains(ConstantsUtilIRM.CONST_EXTENDED_ATTRIBUTE)){	
						mDSMTemplateDetails.put(ConstantsUtilIRM.STR_EXTENDED_ATTRIBUTE, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.STR_EXTENDED_ATTRIBUTE)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.STR_EXTENDED_ATTRIBUTE, ConstantsUtil.FALSE);
					}
					//Added by Ajay for Req. 78583 -- END
				}
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getPartAndSpecReportValues "+ex);
		} 
		return mDSMTemplateDetails;
	}

	public Map<String, String> getPartandSpecValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtil.SYMBL_TILDA);
			if (slDescription.size()>1) {
				Iterator<String> itrDesc = slDescription.iterator();
				while(itrDesc.hasNext()) {
					//SPEC: <14.03.2022>: Guna Modified for 47004 Defect  Dev 18x.6.0.3   -- START
					String strDescValue = itrDesc.next().trim();
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CONST_ATTRIBUTES))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.ATTRIBUTES, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.ATTRIBUTES)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.ATTRIBUTES, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.KEY_ALTERNATE))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.ALTERNATE, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.ALTERNATE)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.ALTERNATE, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CONST_APPROVE))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.APPROVE, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.APPROVE)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.APPROVE, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.BATTERY_ROLL_UP))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.CONST_BATTERYROLLUP, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.CONST_BATTERYROLLUP)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.CONST_BATTERYROLLUP, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.BILL_OF_MATERIALS))
					{
						mDSMTemplateDetails.put(ConstantsUtil.BILLOFMATERIALS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtil.BILLOFMATERIALS)){
						mDSMTemplateDetails.put(ConstantsUtil.BILLOFMATERIALS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CHARACTERISTICS_APOLLO))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.CHARACTERISTICSLPD, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.CHARACTERISTICSLPD)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.CHARACTERISTICSLPD, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CHEMICAL_AND_PHYSICAL_PROPERTIES))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.CHEMPHYPROPERTIES, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.CHEMPHYPROPERTIES)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.CHEMPHYPROPERTIES, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.DESIGN_PARAMETER))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.PGDESIGNPARAMETER, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.PGDESIGNPARAMETER)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.PGDESIGNPARAMETER, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.EBOM_W_AND_D))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.EBOMWND, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.EBOMWND)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.EBOMWND, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.FOP_FORMULA_INGREDIENT))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.FOPFORMULAINGREDIENT, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.FOPFORMULAINGREDIENT)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.FOPFORMULAINGREDIENT, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.VIEW_SUBSTITUTES))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.FOPVIEWSUBSTITUTES, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.FOPVIEWSUBSTITUTES)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.FOPVIEWSUBSTITUTES, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.GPS_ASSESMENTS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.GPSASSESMENTS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.GPSASSESMENTS)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.GPSASSESMENTS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.MARKET_CLEARANCE))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.MARKETCLEARANCE, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.MARKETCLEARANCE)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.MARKETCLEARANCE, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.MARKET_OF_SALE))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.MARKETOFSALE, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.MARKETOFSALE)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.MARKETOFSALE, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.MATERIALS_AND_COMPOSITION))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.MATERIALSANDCOMPOSITION, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.MATERIALSANDCOMPOSITION)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.MATERIALSANDCOMPOSITION, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.MEP_SEP_CERTIFICATIONS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.MEPSEPCERTIFICATIONS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.MEPSEPCERTIFICATIONS)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.MEPSEPCERTIFICATIONS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.MEP_SEP_COMPONENT_EQUIVALENTS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.MEPSEPCOMPEQTS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.MEPSEPCOMPEQTS)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.MEPSEPCOMPEQTS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CONST_NOTES))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.NOTES, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.NOTES)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.NOTES, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.PART_CERTIFICATIONS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.PARTCERTIFICATIONS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.PARTCERTIFICATIONS)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.PARTCERTIFICATIONS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.PART_COMPONENT_EQUIVALENTS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.PARTCOMPONENTEQUIVALENTS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.PARTCOMPONENTEQUIVALENTS)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.PARTCOMPONENTEQUIVALENTS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.PERFORMANCE_CHARACTERISTICS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.PERFORMANCECHARACTERISTICS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CONST_PLANTS))
					{
						mDSMTemplateDetails.put(ConstantsUtil.PLANTS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtil.PLANTS)){
						mDSMTemplateDetails.put(ConstantsUtil.PLANTS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.PRODUCING_FORMULA))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.PRODUCINGFORMULA, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.PRODUCINGFORMULA)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.PRODUCINGFORMULA, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.SAP_BOM_AS_FED))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.SAPBOMASFED, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.SAPBOMASFED)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.SAPBOMASFED, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.SPECS_AND_DOCS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.SPECSANDDOCS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.SPECSANDDOCS)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.SPECSANDDOCS, ConstantsUtil.FALSE);
					}
					//Commented for Req. no. 42723
					/*if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.SUBSTANCES_AND_MATERIALS))
							 {

								mDSMTemplateDetails.put(ConstantsUtilIRM.SUBSTANCESANDMATERIALS, ConstantsUtil.TRUE);
							} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.SUBSTANCESANDMATERIALS)){
								mDSMTemplateDetails.put(ConstantsUtilIRM.SUBSTANCESANDMATERIALS, ConstantsUtil.FALSE);
							}*/
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.WEIGHTS_AND_DIMENSIONS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.WEIGHTSANDDIMENSIONS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.WEIGHTSANDDIMENSIONS)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.WEIGHTSANDDIMENSIONS, ConstantsUtil.FALSE);
					}

					//Added by Ketan for Req. no. 42723 -- START

					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.DG_CLASS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DGCLASS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DGCLASS)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.DGCLASS, ConstantsUtil.FALSE);
					}

					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.IP_EXPORT_CONTROL))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.IPEXPORTCONTROL, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.IPEXPORTCONTROL)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.IPEXPORTCONTROL, ConstantsUtil.FALSE);
					}

					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.SUBS_PARTS_IN))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.SUBSPARTSIN, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.SUBSPARTSIN)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.SUBSPARTSIN, ConstantsUtil.FALSE);
					}

					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CONST_SUSTAINABILITY))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.OUT_SUSTAINABILITY, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.OUT_SUSTAINABILITY)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.OUT_SUSTAINABILITY, ConstantsUtil.FALSE);
					}
					//Added by Ketan for Req. no. 42723 -- END

					//Added by Ajay for Req. 5489 -- START
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.Stability_Document))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.Stability_Document, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.Stability_Document)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.Stability_Document, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.MOS_Component_Details))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.MOS_Component_Details, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.MOS_Component_Details)){
						mDSMTemplateDetails.put(ConstantsUtilIRM.MOS_Component_Details, ConstantsUtil.FALSE);
					}
					//Added by Ajay for Req. 5489 -- END
				}
				//SPEC: <14.03.2022>: Guna Modified for 47004 Defect  Dev 18x.6.0.3   -- END
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getPartandSpecValues "+ex);
		} 
		return mDSMTemplateDetails;
	}
	//SPEC: 01.05.2021: Added for Req- 41555 Dev 18x.6.0.3  -- END

	//Added by Ketan for Req. no. 42796 -- START
	public Map<String, String> getPartNameValidationResult(Context context,
			Map<String, Object> mpPartNameValidationInput) {
		Map<String, String> mpPartNameValidation = new HashMap<>();
		StringList slValidParts = new StringList();
		StringList slInvalidParts = new StringList();
		StringList slValidTypeParts = new StringList();
		StringList slInvalidTypeParts = new StringList();
		String strPartName = (String) mpPartNameValidationInput.get(ConstantsUtilIRM.PARTNAME);
		if (!strPartName.isEmpty()) {
			String[] sPartNames = strPartName.split(ConstantsUtil.SYMBL_COMMA);
			for (String sPartName : sPartNames) {
				if (sPartName.matches(ConstantsUtilIRM.REGEX_EIGHTDOTTHREE)) {
					slValidParts.add(sPartName);
				} else {
					slInvalidParts.add(sPartName);
					break;
				}
			}
			if (slInvalidParts.isEmpty()) {
				MapList mlObjectList = new MapList();
				StringList slObjectsSelect = new StringList();
				slObjectsSelect.add(DomainConstants.SELECT_NAME);
				slObjectsSelect.add(DomainConstants.SELECT_TYPE);
				slObjectsSelect.add(DomainConstants.SELECT_REVISION);
				sPartNames = strPartName.split(ConstantsUtil.SYMBL_COMMA);
				for (String sPartName : sPartNames) {
					String[] strRev = sPartName.split(ConstantsUtil.SYMBL_BACKSLASH_DOT);
					String sName = strRev[0];
					String sRev = strRev[1];
					try {
						mlObjectList = DomainObject.findObjects(context, // MatrixContext
								ConstantsUtil.SYMBL_ASTERISK, // typePattern
								sName, // namePattern
								sRev, // revPattern
								ConstantsUtil.SYMBL_ASTERISK, // ownerPattern
								ConstantsUtil.VAULT_ESERVICEPRODUCTION, // vaultPattern
								ConstantsUtilIRM.CURRENT_RELEASE, // whereExpression
								false, // expandType
								slObjectsSelect);// objectSelects
						for (int j = 0; j < mlObjectList.size(); j++) {
							Map mpType = (Map) mlObjectList.get(j);
							String strType = (String) mpType.get(DomainConstants.SELECT_TYPE);
							if (strType.equalsIgnoreCase(ConstantsUtil.ttAPP)
									|| strType.equalsIgnoreCase(ConstantsUtil.tDPP)
									|| strType.equalsIgnoreCase(ConstantsUtil.tFOP)) {
								slValidTypeParts.add(sName);
							} else {
								slInvalidTypeParts.add(sName);
							}
						}
						if (mlObjectList.size() == 0) {
							slInvalidTypeParts.add(sName);
						}
					} catch (Exception ex) {
						dsmLOGGER.error(
								"Exception in Program : DSMReportBO Method :getPartNameValidationResult " + ex);
					}
					if (!slInvalidTypeParts.isEmpty()) {
						break;
					}
				}

				if (slInvalidTypeParts.isEmpty()) {
					mpPartNameValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.S101);
					mpPartNameValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.S101_SUCCESS);
					mpPartNameValidation.put(ConstantsUtilIRM.DAILYCOUNTER, ConstantsUtil.EMPTY_STRING);
				} else {
					mpPartNameValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.E113);
					mpPartNameValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.E113_MSG);
					mpPartNameValidation.put(ConstantsUtilIRM.DAILYCOUNTER, ConstantsUtil.EMPTY_STRING);
				}
			} else {
				mpPartNameValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.E114);
				mpPartNameValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.E114_FORMAT_ERROR_MSG1
						.concat(slInvalidParts.toString()).concat(ConstantsUtilIRM.E114_FORMAT_ERROR_MSG2));
				mpPartNameValidation.put(ConstantsUtilIRM.DAILYCOUNTER, ConstantsUtil.EMPTY_STRING);
			}
		} else {
			mpPartNameValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.E115);
			mpPartNameValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.E115_MSG);
			mpPartNameValidation.put(ConstantsUtilIRM.DAILYCOUNTER, ConstantsUtil.EMPTY_STRING);
		}
		return mpPartNameValidation;
	}
	//Added by Ketan for Req. no. 42796 -- END

	//Added by Ketan for Req. no. 47051 -- START 
	public Map<String, String> getPartTypeValidationResult(Context context,
			Map<String, Object> mpPartTypeValidationInput) {
		Map<String, String> mpPartTypeValidation = new HashMap<>();
		StringList slValidTypeParts = new StringList();
		StringList slInvalidTypeParts = new StringList();
		String strPartName = (String) mpPartTypeValidationInput.get(ConstantsUtilIRM.PARTNAME);
		if (!strPartName.isEmpty()) {
			MapList mlObjectList = new MapList();
			StringList slObjectsSelect = new StringList();
			slObjectsSelect.add(DomainConstants.SELECT_NAME);
			slObjectsSelect.add(DomainConstants.SELECT_TYPE);
			slObjectsSelect.add(DomainConstants.SELECT_REVISION);
			String[] sPartNames = strPartName.split(ConstantsUtil.SYMBL_COMMA);
			for (String sPartName : sPartNames) {
				try {
					mlObjectList = DomainObject.findObjects(context, // MatrixContext
							ConstantsUtil.SYMBL_ASTERISK, // typePattern
							sPartName, // namePattern
							ConstantsUtil.SYMBL_ASTERISK, // revPattern
							ConstantsUtil.SYMBL_ASTERISK, // ownerPattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, // vaultPattern
							ConstantsUtilIRM.CURRENT_RELEASE, // whereExpression
							false, // expandType
							slObjectsSelect);// objectSelects
					for (int j = 0; j < mlObjectList.size(); j++) {
						Map mpType = (Map) mlObjectList.get(j);
						String strType = (String) mpType.get(DomainConstants.SELECT_TYPE);
						if (ConstantsUtilIRM.ALLOWEDTYPES_WHEREUSEDREPORT.contains(strType)) {
							slValidTypeParts.add(sPartName);
						} else {
							slInvalidTypeParts.add(sPartName);
						}
					}
					if (mlObjectList.size() == 0) {
						slInvalidTypeParts.add(sPartName);
					}
				} catch (Exception ex) {
					dsmLOGGER.error("Exception in Program : DSMReportBO Method :getPartTypeValidationResult " + ex);
				}
			}
			if (slInvalidTypeParts.isEmpty()) {
				mpPartTypeValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.S101);
				mpPartTypeValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.S103_MSG);
				mpPartTypeValidation.put(ConstantsUtilIRM.DAILYCOUNTER, ConstantsUtil.EMPTY_STRING);
			} else {
				mpPartTypeValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.E116);
				mpPartTypeValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.E116_MSG);
				mpPartTypeValidation.put(ConstantsUtilIRM.DAILYCOUNTER, ConstantsUtil.EMPTY_STRING);
			}
		} else {
			mpPartTypeValidation.put(ConstantsUtilIRM.RESPONSECODE, ConstantsUtilIRM.E117);
			mpPartTypeValidation.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.E117_MSG);
			mpPartTypeValidation.put(ConstantsUtilIRM.DAILYCOUNTER, ConstantsUtil.EMPTY_STRING);
		}
		return mpPartTypeValidation;
	}
	//Added by Ketan for Req. no. 47051 -- END

	//Added By Jwala for the defect 14493 : START

	public Map<String, String> getPDFDownloadSelectdValues(String strDescription) {
		Map<String, String> mDSMTemplateDetails = new HashMap<>();
		try {
			StringList slDescription = StringUtil.split(strDescription, ConstantsUtil.SYMBL_TILDA);
			if (slDescription.size()>1) {
				Iterator<String> itrDesc = slDescription.iterator();
				while(itrDesc.hasNext()) {
					String strDescValue = itrDesc.next().trim();
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CONST_ATTRIBUTES))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.ATTRIBUTES, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.ATTRIBUTES)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.ATTRIBUTES, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_DANGEROUSGOODSCLASSIFICATION))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DGCLASSIFICATION, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DGCLASSIFICATION)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.DGCLASSIFICATION, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_GLOBALHARMONIZEDSTANDARD))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.GLOBALHARMONIZEDSTANDARD, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.GLOBALHARMONIZEDSTANDARD)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.GLOBALHARMONIZEDSTANDARD, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_STORAGETABLEFPP))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.STORAGETABLEFPP, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.STORAGETABLEFPP)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.STORAGETABLEFPP, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_DSOSTABILITYRESULTS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOSTABILITYRESULTS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DSOSTABILITYRESULTS)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOSTABILITYRESULTS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_BATTERYROLLUP))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.BATTERYROLUP, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.BATTERYROLUP)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.BATTERYROLUP, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_WHEREHOUSECLASSIFICATION))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.WHEREHOUSECLASSIFICATION, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.WHEREHOUSECLASSIFICATION)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.WHEREHOUSECLASSIFICATION, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_INGREDIENTTRANSPARENCY))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.INGREDIENTTRANSPARENCY, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.INGREDIENTTRANSPARENCY)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.INGREDIENTTRANSPARENCY, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_DSOUFI))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOUFI, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DSOUFI)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOUFI, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_DSONOTES))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSONOTES, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DSONOTES)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSONOTES, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_FLATBOM))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.FLATBOM, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.FLATBOM)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.FLATBOM, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_DSONEWCOSTABLE))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSONEWCOSTABLE, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DSONEWCOSTABLE)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSONEWCOSTABLE, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_FPPBOM))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.FPPBOM, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.FPPBOM)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.FPPBOM, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_DSOPERFORMANCE))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOPERFORMANCE, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DSOPERFORMANCE)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOPERFORMANCE, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_FORMULATEDPRODUCTTABLE))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.RELATEDSPECIFICATIONS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.RELATEDSPECIFICATIONS)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.RELATEDSPECIFICATIONS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_FORMULATEDPRODUCTTABLE))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.MASTERSPECIFICATIONS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.MASTERSPECIFICATIONS)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.MASTERSPECIFICATIONS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_DSOCERTIFICATIONS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOCERTIFICATIONS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DSOCERTIFICATIONS)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOCERTIFICATIONS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_DSOWND))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOWND, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DSOWND)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOWND, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_BASECODEDETAILS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.BASECODEDETAILS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.BASECODEDETAILS)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.BASECODEDETAILS, ConstantsUtil.FALSE);
					}
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.CON_DSOISATS))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOISATS, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.DSOISATS)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.DSOISATS, ConstantsUtil.FALSE);
					}
					//Added By Ajay for the Req 14493 : START
					if(strDescValue.equalsIgnoreCase(ConstantsUtilIRM.Master_PI_Gendoc))
					{
						mDSMTemplateDetails.put(ConstantsUtilIRM.Master_PI_Gendoc, ConstantsUtil.TRUE);
					} else if(!mDSMTemplateDetails.containsKey(ConstantsUtilIRM.Master_PI_Gendoc)) {
						mDSMTemplateDetails.put(ConstantsUtilIRM.Master_PI_Gendoc, ConstantsUtil.FALSE);
					}
					//Added By Ajay for the Req 14493 : END

				}
			}
		} catch (Exception ex) {
			dsmLOGGER.error("Exception in Program : DSMReportBO Method :getPDFDownloadSelectdValues "+ex);
		} 
		return mDSMTemplateDetails;

	}

	//Added By Jwala for the defect 14493 : END
}