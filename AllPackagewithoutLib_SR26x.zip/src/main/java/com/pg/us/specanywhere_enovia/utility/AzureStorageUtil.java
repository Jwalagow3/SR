package com.pg.us.specanywhere_enovia.utility;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.azure.storage.blob.models.BlobStorageException;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

public class AzureStorageUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(AzureStorageUtil.class);
	
	public CloudBlobContainer getCloudBlobContainer(String connectStr, String containerName) {
		logger.info("Azure connnection string is :: " + connectStr);
		CloudStorageAccount storageAccount = null;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container=null;
		try {
			storageAccount = CloudStorageAccount.parse(connectStr);
		} catch (InvalidKeyException e) {
			logger.error("exception in getCloudBlobContainer: InvalidKeyException",e);
		} catch (URISyntaxException e) {
			logger.error("exception in getCloudBlobContainer: URISyntaxException",e);
		}
		if(storageAccount != null) {
			blobClient = storageAccount.createCloudBlobClient();
		}
		try {
			if(blobClient != null) {
				container = blobClient.getContainerReference(containerName);
			}
		} catch (URISyntaxException e) {
			logger.error("exception in getContainerReference",e);
			} catch (StorageException e) {
				logger.error("StorageException in getCloudBlobContainer",e);
			}
		return container;

	}
	
	public String downloadBlobFilesUsingCloudBlobClient(String fileName, CloudBlobContainer  containerClient, String localfilestorage) {

		try {
			Path p = Paths.get(fileName);
			String file = p.getFileName().toString();
			CloudBlockBlob blobClient = null;
			try {
				blobClient = containerClient.getBlockBlobReference(fileName);
			} catch (URISyntaxException e) {
				logger.error("URISyntaxException in downloadBlobFilesUsingCloudBlobClient",e);
			} catch (StorageException e) {
				logger.error("StorageException in downloadBlobFilesUsingCloudBlobClient",e);
			}
			String localPath = localfilestorage;
			logger.info("Downloading blob to " + localPath + fileName);
			boolean isBlobExists=false;
			try {
				//Subhajit Modified for defect 45181 - Start
				FileOutputStream fos = new FileOutputStream(localPath+file);
				if(blobClient != null) {
					blobClient.download(fos);
					isBlobExists=true;
				}
				fos.close();
				//Subhajit Modified for defect 45181 - END
			} catch (StorageException e) {
				logger.error("StorageException exception in downloadBlobFilesUsingCloudBlobClient",e);
				return null;
			} catch (IOException e) {
				logger.error("IOException exception in downloadBlobFilesUsingCloudBlobClient",e);
			}finally {
				try {
					if(isBlobExists)
				      try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						logger.error("exception",e);
						Thread.currentThread().interrupt();
					}
				}catch(Exception e){
					logger.error("exception in blobClient download",e);
					Thread.currentThread().interrupt();
				}
			}
			return localPath + file;
		} catch (BlobStorageException e) {
			logger.error("BlobStorageException in AzureStorageUtil: downloadBlobFilesUsingCloudBlobClient",e);
			return null;
		}
	}

	
}