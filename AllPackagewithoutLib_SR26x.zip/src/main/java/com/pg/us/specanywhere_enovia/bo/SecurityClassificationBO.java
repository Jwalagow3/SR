/**
 * Project 		: SpecsAnywhere
 * Program 		: SecurityClassificationBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;

import java.util.Map;

import org.apache.log4j.Logger;

import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class SecurityClassificationBO {

	
	private static Logger LOGGER = Logger.getLogger(FinishedProductPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	
	
	public SecurityClassificationBO() {
		// empty constructor
	}

	public static Map<String, StringList> getSelectable(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		mapSelecables.put("busSelect", busSelect);
		
		return mapSelecables;
	}
		
	}
