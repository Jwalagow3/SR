package com.pg.us.specanywhere_enovia.test;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class FormulaPartService {

	private static Logger LOGGER = Logger.getLogger(FormulaPartService.class);

	public static void main(String[] args) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();
		//String oid = "20336.41905.32777.39832";
		//String objId = "20336.41905.32768.61544";//15132129 004
		//String oid = "20336.41905.45835.24537";
		//String objId = "20336.41905.32768.17119";
		String objId = "20336.41905.62173.59533"; //for defect 35405
		
		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.EMPTY_STRING,ConstantsUtil.USER_VAULT);
		Context context = pool.checkOut();

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();

		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpHeaderResult = new HashMap<String,String>();
		Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
		Map<String,String> mpPlantResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mapWeightCharResult = new HashMap<String,String>();
		Map<String,String> mpFormulationProcess = new HashMap<String,String>();
		Map<String,String> mpFormulaIngr = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
		Map<String,String> mpPerformChar = new HashMap<String,String>();
		Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
		Map<String,String> mpPhyChemEngLegacyData = new HashMap<String,String>();
		Map<String,String> mpPhyChemEngWareHouse = new HashMap<String,String>();
		Map<String,String> mpPhysicalChemicalGHCProp = new HashMap<String,String>();
		Map<String,String> mpMaterialProduced = new HashMap<String,String>();
		Map<String,String> mpDangerousGoodsClf = new HashMap<String,String>();
		Map<String,String> mpGlobalHarStandard = new HashMap<String,String>();
		Map<String,String> mpStability = new HashMap<String,String>();
		Map<String,String> mpSubstitute = new HashMap<String,String>();
		Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();

		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		FormulaPartBO formulationPartBO = new FormulaPartBO();
		Map<String, StringList> BusinessObjectSelectableMap = formulationPartBO.getFopSelectables(context);
		StringList slBusSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slRelSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
		
		DomainObject doFop =  formulationPartBO.getFopDO(context, objId);
		/*if(null==doFop) {
			HashMap<String,String> errorMap = new HashMap<String,String>();
			errorMap.put(ConstantsUtil.E100, ConstantsUtil.OBJECT_NOT_EXITS);
			hmAttrib.put(ConstantsUtil.ERROR, errorMap);
			return hmAttrib;
		}*/

		formulationPartBO.addMultiValueConstants();

		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doFop.getInfo(context, slBusSelects);
		swAttributes.stop();
		LOGGER.info("FOP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		formulationPartBO.removeMultiValueConstants();

		SecurityService sct = new SecurityService();
		//boolean bRoleFlag = sct.isContractManufacturer();
		boolean bRoleFlag = false;

		//Formulation Process
		StopWatch swFormulation = new StopWatch();
		swFormulation.start();
		MapList mlFormulationProcess = doFop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PLANNEDFOR, ConstantsUtil.TYPE_FORMULATIONPROCESS, slBusSelects, null, false, true, (short) 1, null, null, 0);
		swFormulation.stop();
		LOGGER.info("FOP FORMULATION ELAPSED TIME : "+swFormulation.getTime());

		//Lifecycle
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={objId,sPhysicalId};
		StopWatch swLifecycle = new StopWatch();
		swLifecycle.start();
		mpLifeCycleApproval = util.getCOName(context, changeargs);
		swLifecycle.stop();
		LOGGER.info("FOP LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

		
		//IP Security Setting
		StringList slIpSelects = new StringList();
		slIpSelects.add(ConstantsUtil.SELECT_NAME);
		slIpSelects.add(ConstantsUtil.SELECT_ID);
		slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
		slIpSelects.add(ConstantsUtil.SELECT_TYPE);
		slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		
		MapList mlFormulation = doFop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE, ConstantsUtil.TYPE_COSMETICFORMULATION, slIpSelects,
				null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
				ConstantsUtil.ZERO_LEVEL);
		Iterator itr = mlFormulation.iterator();
		Map mpFormulation = new HashMap();
		while(itr.hasNext()) {
			mpFormulation = (Map)itr.next();
		}
		String sFormulationOid = (String) mpFormulation.get(ConstantsUtil.SELECT_ID);
		DomainObject doFormObj = new DomainObject(sFormulationOid);
		MapList mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
				null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
				ConstantsUtil.ZERO_LEVEL);
		itr = mlIPCLass.iterator();
		Map mpIpClass = new HashMap();
		StringBuilder sbIpName = new StringBuilder();
		StringBuilder sbHasClassAccess = new StringBuilder();
		StringBuilder sbIpType = new StringBuilder();
		StringBuilder sbIpDesc = new StringBuilder();
		StringBuilder sbIpState = new StringBuilder();
		StringBuilder sbIpLibrary = new StringBuilder();
		StringBuilder sbIpClassPath = new StringBuilder();
		
		while(itr.hasNext()) {
			mpIpClass = (Map)itr.next();
			String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
			sbIpName.append(sIpClassName);
			sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
			sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
			sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
			String strIpClass="";
			if(sIpClassName.contains(ConstantsUtil.HIR)) {
				strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
				sbIpLibrary.append(strIpClass);
			} else {
				sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
			}
			if(!strIpClass.isEmpty()) {
				StringBuilder sbIpClassTemp = new StringBuilder();
				sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
				sbIpClassPath.append(sbIpClassTemp.toString());
			}
			
			//Compare user classification against IPName
			sbHasClassAccess.append("TRUE");
			
			if(itr.hasNext()) {
				sbIpName.append(",");
				sbIpType.append(",");
				sbIpDesc.append(",");
				sbIpState.append(",");
				sbIpLibrary.append(",");
				sbIpClassPath.append(",");
				sbHasClassAccess.append(",");
			}
		}
		mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
		mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
		mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
		mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
		mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
		mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
		mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
		
		
		//Basic  Data
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strPGBrand)))?(String)resultMaps.get(ConstantsUtil.strPGBrand) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CUSTOMIZATIONTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRIMARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SECONDARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION) : ConstantsUtil.BUSINESS_USE);
		String sClassifictaion = util.getClassification(resultMaps);
		mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
		mpAttribResult.put(ConstantsUtil.ALTERNATIVEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.FORMULATIONTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strKeyFormulationType)))?(String)resultMaps.get(ConstantsUtil.strKeyFormulationType) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.FORMULATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strKeyFormulation)))?(String)resultMaps.get(ConstantsUtil.strKeyFormulation) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strPGPDTTOPGPLIREFUN)))?(String)resultMaps.get(ConstantsUtil.strPGPDTTOPGPLIREFUN) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ONSHELFPRODDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.WAREHOUSECLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strSegment)))?(String)resultMaps.get(ConstantsUtil.strSegment) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);

		if(!bRoleFlag) {

			//Organization Data
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = util.filterMapList(mpOrganization);

			//Plant Data
			mpPlantResult = util.updatePlantInfo(resultMaps);

			//Ownership
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);

			//Header Content
			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);

		}

		if(mlFormulationProcess.size()>0) {
			Map mMasterData = (Map)mlFormulationProcess.get(0);
			String strId = (String)mMasterData.get(ConstantsUtil.SELECT_ID);
			String FormulationTitle = (String) mMasterData.get(ConstantsUtil.SELECT_NAME);
			String[] parts = FormulationTitle.split(ConstantsUtil.SYMBL_DASH);
			String FormulationName = parts[0];
			String FormulationRevision=(String)mMasterData.get(ConstantsUtil.SELECT_REVISION);
			String FormulationProcessName=(String)mMasterData.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			String FormulationStage=(String)mMasterData.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			String FormulationState=(String)mMasterData.get(ConstantsUtil.SELECT_CURRENT);
			String FormulationType=(String)mMasterData.get(ConstantsUtil.SELECT_TYPE);
			String sFormulationType=(String)mMasterData.get(ConstantsUtil.STR_FORMULATION_TYPE);

			DomainObject domObjectIdd = DomainObject.newInstance(context,strId);
			MapList mlFormulaIngredients = new MapList();
			Map mpFormulaIngredients = new HashMap();
			String strFindNum = ConstantsUtil.EMPTY_STRING;
			StopWatch swIngredients = new StopWatch();
			swIngredients.start();
			mlFormulaIngredients = domObjectIdd.getRelatedObjects(context, //Context
					ConstantsUtil.REL_FBOM, //relPattern
					ConstantsUtil.QUERY_WILDCARD, //typePattern
					slBusSelects, //objectSelects
					slRelSelects,// relationshipSelects
					false, //getTo - Get Parent Data
					true, //getFrom - Get Child Data
					(short)0, //recurseToLevel
					ConstantsUtil.EMPTY_STRING, //objectWhere
					ConstantsUtil.EMPTY_STRING); //relationshipWhere
			swIngredients.stop();
			LOGGER.info("FOP FORMULA INGREDIENTS ELAPSED TIME : "+swIngredients.getTime());
			Boolean findNumberIsNotEmpty = true;
			String strType = ConstantsUtil.EMPTY_STRING;
			String strSequenceNum = ConstantsUtil.EMPTY_STRING;
			String strSortSequence = ConstantsUtil.EMPTY_STRING;
			String strSequenceNum2 = ConstantsUtil.EMPTY_STRING;
			String strSortSequence1 = ConstantsUtil.EMPTY_STRING;
			MapList mlFormulaIngredientSort = new MapList();

			for (int i = 0; i <mlFormulaIngredients.size(); i++){
				mpFormulaIngredients = (Map) mlFormulaIngredients.get(i);
				strFindNum = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				if(!validator.isNotNullOrEmpty(strFindNum) || strFindNum.equalsIgnoreCase("NaN"))
				{
					strFindNum = ConstantsUtil.GEN_NUM_ZERO;
					findNumberIsNotEmpty=false;
				}
				strType = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_TYPE);
				if(strType.equals(ConstantsUtil.TYPE_FORMULATIONPHASE)){
					strSequenceNum  = strFindNum;
					strSortSequence = strFindNum.concat(ConstantsUtil.GEN_NUM_DOUBLEZEOR);
					strSequenceNum2 = strSequenceNum;
					strSortSequence1 = strSortSequence;
				}
				else {
					strSequenceNum =strSequenceNum2.concat(ConstantsUtil.SYMBL_DOT).concat(strFindNum);
					strSortSequence=Integer.toString(Integer.valueOf(strSortSequence1) + Integer.valueOf(strFindNum));
				}
				if (!findNumberIsNotEmpty)
					strSequenceNum=ConstantsUtil.EMPTY_SPACE;
				mpFormulaIngredients.put(ConstantsUtil.SEQUENCENUMBER, strSequenceNum);
				mpFormulaIngredients.put(ConstantsUtil.TEMP, strSortSequence);
				mlFormulaIngredientSort.add(mpFormulaIngredients);
			}

			int nMapMP = mlFormulaIngredientSort.size();
			String strOid = ConstantsUtil.EMPTY_STRING;
			String strRelId = ConstantsUtil.EMPTY_STRING;
			String strSequenceNumber = ConstantsUtil.EMPTY_STRING;
			String strMin = ConstantsUtil.EMPTY_STRING;
			String strMax = ConstantsUtil.EMPTY_STRING;
			String strLoss = ConstantsUtil.EMPTY_STRING;
			String strQuantity = ConstantsUtil.EMPTY_STRING;
			String strWeightWet = ConstantsUtil.EMPTY_STRING;
			String strWeightDry = ConstantsUtil.EMPTY_STRING;
			String strDryPer = ConstantsUtil.EMPTY_STRING;
			String strComments = ConstantsUtil.EMPTY_STRING;
			String strMaterialFunction = ConstantsUtil.EMPTY_STRING;
			String strVirtualName = ConstantsUtil.EMPTY_STRING;
			int integerPlaces = ConstantsUtil.ZERO_LEVEL;
			int decimalPlaces = ConstantsUtil.ZERO_LEVEL;
			DecimalFormat decimalformatter = new DecimalFormat(ConstantsUtil.PATTERN_DECIMALFORMAT);

			StringBuffer sbName = new StringBuffer();
			StringBuffer sbSeqNum = new StringBuffer();
			StringBuffer sbTitle = new StringBuffer();
			StringBuffer sbMin = new StringBuffer();
			StringBuffer sbQty = new StringBuffer();
			StringBuffer sbMax = new StringBuffer();
			StringBuffer sbWeightWet = new StringBuffer();
			StringBuffer sbDryPer = new StringBuffer();
			StringBuffer sbWeightDry = new StringBuffer();
			StringBuffer sbLoss = new StringBuffer();
			StringBuffer sbMatFunc = new StringBuffer();
			StringBuffer sbVirtual = new StringBuffer();
			StringBuffer sbComments = new StringBuffer();
			StringBuffer sbType = new StringBuffer();

			for (int i = 0; i <nMapMP; i++){
				mpFormulaIngredients = (Map) mlFormulaIngredientSort.get(i);
				strId = (String)mpFormulaIngredients.get(ConstantsUtil.SELECT_ID);
				strRelId = (String)mpFormulaIngredients.get(ConstantsUtil.SELECT_RELATIONSHIP_ID);
				strSequenceNumber = (String)mpFormulaIngredients.get(ConstantsUtil.SEQUENCENUMBER);
				strMin = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET);
				strMax = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET);
				strLoss = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
				strQuantity = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				strWeightWet = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
				strWeightDry = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
				strDryPer = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
				strComments = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE);

				strMaterialFunction = (String) formulationPartBO.getMaterialFunction(context,strRelId);
				strVirtualName = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID);

				DomainObject doObj = DomainObject.newInstance(context,strId);
				StringList objectSelects = BusObjectAttribUtil.getBasicInfoBusSelectable(context);
				objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				StopWatch swFormulaBasic = new StopWatch();
				swFormulaBasic.start();
				Map mpObjDetails = (Map) doObj.getInfo(context, objectSelects);
				swFormulaBasic.stop();
				LOGGER.info("FOP INGREDIATE BASIC ELAPSED TIME: "+swFormulaBasic.getTime());
				String strTitle = (String) mpObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				if(validator.isNotNullOrEmpty(strTitle)) {
					strTitle = strTitle.replaceAll(ConstantsUtil.SYMBL_LESSTHEN,ConstantsUtil.STR_LESSTHAN);						
					strTitle = strTitle.replaceAll(ConstantsUtil.SYMBL_GRETERTHAN,ConstantsUtil.STR_GREATERTHAN);
				}

				String strName = (String) mpObjDetails.get(ConstantsUtil.SELECT_NAME);
				String strState = (String) mpObjDetails.get(ConstantsUtil.SELECT_CURRENT);
				String strRev = (String) mpObjDetails.get(ConstantsUtil.SELECT_REVISION);
				strType = (String) mpObjDetails.get(ConstantsUtil.SELECT_TYPE);
				strType = util.mapType(strType);

				if(mpFormulaIngredients.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE)){
					strMin = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
					if(validator.isNotNullOrEmpty(strMin))						
					{
						integerPlaces = strMin.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
						decimalPlaces = strMin.length() - integerPlaces - 1;
						if(decimalPlaces>6){
							strMin = String.valueOf(decimalformatter.format(Double.parseDouble(strMin)));
						}
					}
					else
						strMin = ConstantsUtil.EMPTY_STRING;
				}

				if(mpFormulaIngredients.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE)){
					strMax = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
					if(validator.isNotNullOrEmpty(strMax))
					{
						integerPlaces = strMax.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
						decimalPlaces = strMax.length() - integerPlaces - 1;
						if(decimalPlaces>6){
							strMax = String.valueOf(decimalformatter.format(Double.parseDouble(strMax)));
						}
					}
					else
						strMax = ConstantsUtil.EMPTY_STRING;
				}
				if(mpFormulaIngredients.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_LOSS)){
					strLoss = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
					if(validator.isNotNullOrEmpty(strLoss))
					{
						integerPlaces = strLoss.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
						decimalPlaces = strLoss.length() - integerPlaces - 1;
						if(decimalPlaces>6){
							strLoss = String.valueOf(decimalformatter.format(Double.parseDouble(strLoss)));
						}
					}
					else
						strLoss = ConstantsUtil.EMPTY_STRING;
				}
				if(mpFormulaIngredients.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT)){
					strWeightWet = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
					if(validator.isNotNullOrEmpty(strWeightWet))
					{
						integerPlaces = strWeightWet.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
						decimalPlaces = strWeightWet.length() - integerPlaces - 1;
						if(decimalPlaces>6){
							strWeightWet = String.valueOf(decimalformatter.format(Double.parseDouble(strWeightWet)));
						}
					}
					else
						strWeightWet = ConstantsUtil.EMPTY_STRING;
				}
				if(mpFormulaIngredients.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE)){
					strQuantity = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
					if(validator.isNotNullOrEmpty(strQuantity))
					{
						integerPlaces = strQuantity.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
						decimalPlaces = strQuantity.length() - integerPlaces - 1;
						if(decimalPlaces>6){
							strQuantity = String.valueOf(decimalformatter.format(Double.parseDouble(strQuantity)));
						}
					}
					else
						strQuantity = ConstantsUtil.EMPTY_STRING;
				}
				if(mpFormulaIngredients.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL)){
					strDryPer = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
					if(validator.isNotNullOrEmpty(strDryPer))
					{
						integerPlaces = strDryPer.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
						decimalPlaces = strDryPer.length() - integerPlaces - 1;
						if(decimalPlaces>6){
							strDryPer = String.valueOf(decimalformatter.format(Double.parseDouble(strDryPer)));
						}
					}
					else
						strDryPer = ConstantsUtil.EMPTY_STRING;
				}
				if(mpFormulaIngredients.containsKey(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY)){
					strWeightDry = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
					if(validator.isNotNullOrEmpty(strWeightDry))
					{
						integerPlaces = strWeightDry.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
						decimalPlaces = strWeightDry.length() - integerPlaces - 1;
						if(decimalPlaces>6){
							strWeightDry = String.valueOf(decimalformatter.format(Double.parseDouble(strWeightDry)));
						}
					}
					else
						strWeightDry = ConstantsUtil.EMPTY_STRING;
				}
				sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
				sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
				sbMin.append(strMin).append(ConstantsUtil.SYMBL_PIPE);
				sbMax.append(strMax).append(ConstantsUtil.SYMBL_PIPE);
				sbQty.append(strQuantity).append(ConstantsUtil.SYMBL_PIPE);
				sbWeightDry.append(strWeightDry).append(ConstantsUtil.SYMBL_PIPE);
				sbWeightWet.append(strWeightWet).append(ConstantsUtil.SYMBL_PIPE);
				sbSeqNum.append(strSequenceNumber).append(ConstantsUtil.SYMBL_PIPE);
				sbLoss.append(strLoss).append(ConstantsUtil.SYMBL_PIPE);
				sbMatFunc.append(strMaterialFunction).append(ConstantsUtil.SYMBL_PIPE);
				sbVirtual.append(strVirtualName).append(ConstantsUtil.SYMBL_PIPE);
				sbDryPer.append(strDryPer).append(ConstantsUtil.SYMBL_PIPE);
				sbComments.append(strComments).append(ConstantsUtil.SYMBL_PIPE);
				sbType.append(strType).append(ConstantsUtil.SYMBL_PIPE);
			}

			mpFormulaIngr.put(ConstantsUtil.NAMETYPE, sbName.toString());
			mpFormulaIngr.put(ConstantsUtil.TYPE, sbType.toString());
			mpFormulaIngr.put(ConstantsUtil.SEQ, sbSeqNum.toString());
			mpFormulaIngr.put(ConstantsUtil.TITLEINST, sbTitle.toString());
			mpFormulaIngr.put(ConstantsUtil.MINWETMAX, sbMin.toString()+ConstantsUtil.SYMBL_COMMA+sbQty.toString()+ConstantsUtil.SYMBL_COMMA+sbMax.toString());
			mpFormulaIngr.put(ConstantsUtil.TARGETWETWEIGHT, sbWeightWet.toString());
			mpFormulaIngr.put(ConstantsUtil.DRYTDWPL, sbWeightDry.toString()+ConstantsUtil.SYMBL_COMMA+sbLoss);
			mpFormulaIngr.put(ConstantsUtil.MATERIALFUNCTION, sbMatFunc.toString());
			mpFormulaIngr.put(ConstantsUtil.VIRTUALINTNAME, sbVirtual.toString());
			mpFormulaIngr.put(ConstantsUtil.PROCESSINGNOTE, sbComments.toString());
			mpFormulationProcess.put(ConstantsUtil.ID, strId);
			mpFormulationProcess.put(ConstantsUtil.FORMULANUMBER, FormulationName);
			mpFormulationProcess.put(ConstantsUtil.REVISION, FormulationRevision);
			mpFormulationProcess.put(ConstantsUtil.PROCESSNAME, FormulationProcessName);
			mpFormulationProcess.put(ConstantsUtil.FORMULATIONTYPE, sFormulationType);
			mpFormulationProcess.put(ConstantsUtil.PHASE, FormulationStage+ConstantsUtil.SYMBL_COMMA+FormulationState);
			mpFormulationProcess.put(ConstantsUtil.FTFN, sFormulationType+ConstantsUtil.SYMBL_COMMA+FormulationProcessName);
			mpFormulationProcess.put(ConstantsUtil.NAME, FormulationName+ConstantsUtil.SYMBL_DASH+FormulationRevision);
			mpFormulationProcess.put(ConstantsUtil.TYPE, FormulationType);
			mpFormulationProcess.put(ConstantsUtil.TITLE, FormulationProcessName);
		}
		mpFormulaIngr = util.filterMapList(mpFormulaIngr);
		mpFormulationProcess = util.filterMapList(mpFormulationProcess);

		//StorageTransport
		mapStorageAndLabelResult.put(ConstantsUtil.STR_TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTMARKETEDASCHILDREN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.DOESTHEPRODUCTREQUIRECHILDSAFEDESIGN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);        
		mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTEXPOSEDTOCHILDREN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.DANGEROUSGOODSCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.UNSPECIFICATIONPACKAGINGMATERIALREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.CUSTOMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.CONSUMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.INTENDEDMARKETS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.BUSINESSAREA, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.STANDATDCOST, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTANDARDCOST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTANDARDCOST) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult.put(ConstantsUtil.WAREHOUSECLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
		mapStorageAndLabelResult = util.filterMapList(mapStorageAndLabelResult);

		//chemicalAndPhysicalPropertiesEnginuityLegacyData
		mpPhyChemEngLegacyData.put(ConstantsUtil.WTPERCENTPARAMETERIZED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWTPARAMETERIZED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngLegacyData.put(ConstantsUtil.PROPELLAMTISNONFLAMMABLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPELLANTNONFLAMMABLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngLegacyData.put(ConstantsUtil.PROPELLANTEMULSIFIEDFORLIFEOFPROD, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPELLANTEMULSIFIEDPRODUCT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPELLANTEMULSIFIEDPRODUCT) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngLegacyData.put(ConstantsUtil.KSTDUSTDEFLATIIONINDEXINBARMPSEC,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKSTDUSTDEFLAGRATIONINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKSTDUSTDEFLAGRATIONINDEX) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngLegacyData.put(ConstantsUtil.PMAXEXPOLOSIONPRESSUREINBAR,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPMAXEXPLOSIONPRESSURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPMAXEXPLOSIONPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngLegacyData = util.filterMapList(mpPhyChemEngLegacyData);

		//chemicalAndPhysicalPropertiesWarehouseClassification
		mpPhyChemEngWareHouse.put(ConstantsUtil.ISTHEPROPELLANTFLAMABLEORNONFLAMMBLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngWareHouse.put(ConstantsUtil.PERCENTBYWEIGHTOFFLAMMABLEPROPELLANTINAEROCONTAINER,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTLESSWBYVOLANDBYWATERMISCALCHOL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTLESSWBYVOLANDBYWATERETPLUSISO,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngWareHouse.put(ConstantsUtil.ISTHEBASEPDTNOPROPELLANTSUSTAINCOMBUSTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngWareHouse.put(ConstantsUtil.ISTHEBASEPRODUCTHAVEAFIREPOINT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT) : ConstantsUtil.EMPTY_STRING);	
		mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTCONTAINGTWANDLESSTHBYWTLNIGP,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTCONTAINGTWANDLESSBYWTLIGP,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS) : ConstantsUtil.EMPTY_STRING);
		mpPhyChemEngWareHouse = util.filterMapList(mpPhyChemEngWareHouse);

		//chemicalAndPhysicalPropertiesGHCDGCClassification
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.SUSTAINCOMBUSTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUSTAINCOMBUSTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.OXIDIZER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOXIDIZER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.PERCENBYWEIGHTEMULSIFIELDLIQUFIEDFLAMAGASPROPELLANT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBYWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.CORROSIVETOMETALS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVETOMETALS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.CONTENTCONDUCTIVITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTENTCONDUCTIVITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.SELDACCELERATINGDECOMPOSITIONTEMPERATURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.EVAPORATION_RATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBURNRATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.BURNRATEINMMPERSEC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKSTDUSTDEFLAGRATIONINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.RESERVE_ACIDITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.RESERVE_ALKANITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSELFACCELDECOMTEMP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.KINEMATICVISCOSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.AVAILABLEOXYGENCONTENTINPARCENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAVAILABLEOXYGEN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.BOILINGPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.CLASEDCUPFLASHPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.PH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.RELATIVEDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.PERCENTBYVOLUMETHANOLANDPROPANOL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBYVOLUME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.VAPORPRESSURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVAPORPRESSURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.PHAVAILABILITY,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_AVAILABILITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_AVAILABILITY) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.PROPERTIESORISITTHERMALLYUNSTABLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVAPORPRESSURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.HEADOFDECOMPOSITIONINKJPERGRAM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTHAVEANYSPELFREACTIVE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISAFLAMMABLELIQUIDABSORBEDORCONTAINEDWITHINTHESOLID,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_LIQUID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_LIQUID) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.CONDUCTIVITYOFTHELIQUID,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISTHELIQUIDCORROSIVETOMETAL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.CLOSEDCUPFLASHPOINTVALUE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESPRODUCTCONTAINANORGANICPEROXIDEASRAWMATERIAL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTHAVETHEPOTENTIALTOINCREASETHEBURNINGRATEORINTENSITYOFACOMBUSTIBLESUBSTANCE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVAPORPRESSURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISTHEOXIDIZERHYDROGENPEROXIDELESSTHANEIGHTPERSONT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISTHEOXIDIZERSODIUMPERCARBONATELESSTHENSIXTYPERCENT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTCONTAINANOXIDIZERASRAWMATERIAL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTOXIDIZER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTOXIDIZER) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTSUSTAINCOMBUSTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.BOLINGPOINTVALUE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.CONDUCTIVITYOFTHECONTENTSINTHEAEROSOLCAN,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.TECHNICALBASISFORTHECORROSIVETOMETALSDETERMINATIONPROVIDED,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_TECHNICAL_CTM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_TECHNICAL_CTM) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.ARETHECONTENTSOFTHEAEROSOLCANCORROSIVETOMETALS,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.PHDILUTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_DILUTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_DILUTION) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.VAPORDENSITY,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPOUR_DENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPOUR_DENSITY) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.FOAMFLAMMBILITYTESTFLAMEDUTIONINSEC,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFOAMFLAMMABILITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFOAMFLAMMABILITY) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.FOAMFLAMMABILITYTESTFLAMEHEIGHT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFOAMFLAMMABILITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFOAMFLAMMABILITY) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.ENCLOSEDSPACEIGNITIONTIMEEQUIALENT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENCLOSEDSPACEIGNITION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENCLOSEDSPACEIGNITION) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.IGNITIONDISTANCEINCM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIGNITIONDISTANCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIGNITIONDISTANCE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISAEROSOLTESTDATANEEDED,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.AEROSOLTYPE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOLTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOLTYPE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.GAUGEPRESSUREINKPA,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.CANCONSTRUCTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CAN_CONSTRUCTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CAN_CONSTRUCTION) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.HEATOFCOMBUSTIONONKJ,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.ODOUR,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.COLORINTENSITY,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_COLOR_INTENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_COLOR_INTENSITY) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp.put(ConstantsUtil.COLOR,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOLOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOLOR) : ConstantsUtil.EMPTY_STRING);
		mpPhysicalChemicalGHCProp = util.filterMapList(mpPhysicalChemicalGHCProp);

		//Performance Specs
		String sRevision = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
		String sName = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
		StopWatch swPerfChar = new StopWatch();
		swPerfChar.start();
		//mpPerformChar = util.getExtendedPerformChar(context,doFop,sRevision,sName,resultMaps);
		swPerfChar.stop();
		LOGGER.info("FOP PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

		//Weight Characteristics
		mapWeightCharResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mapWeightCharResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
		mapWeightCharResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mapWeightCharResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mapWeightCharResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
		mapWeightCharResult = util.filterMapList(mapWeightCharResult);

		//Sap BOM
		mpSapBomAsFedcResult = formulationPartBO.getSapBomAsFed(resultMaps);


		//RelatedSpec
		mpRelatedSpecResult = util.updatePartSpec(context,resultMaps);

		//Materials Produced
		mpMaterialProduced.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_NAME)))?(String)resultMaps.get(ConstantsUtil.COMP_NAME) : ConstantsUtil.EMPTY_STRING);
		mpMaterialProduced.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_TYPE)))?(String)resultMaps.get(ConstantsUtil.COMP_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpMaterialProduced.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_REVS)))?(String)resultMaps.get(ConstantsUtil.COMP_REVS) : ConstantsUtil.EMPTY_STRING);
		mpMaterialProduced.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_DESC)))?(String)resultMaps.get(ConstantsUtil.COMP_DESC) : ConstantsUtil.EMPTY_STRING);
		mpMaterialProduced.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_PHASE)))?(String)resultMaps.get(ConstantsUtil.COMP_PHASE) : ConstantsUtil.EMPTY_STRING);
		mpMaterialProduced.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_TITLE)))?(String)resultMaps.get(ConstantsUtil.COMP_TITLE)  : ConstantsUtil.EMPTY_STRING);
		mpMaterialProduced.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_STATE)))?(String)resultMaps.get(ConstantsUtil.COMP_STATE) : ConstantsUtil.EMPTY_STRING);		

		//Dangerous Goods Classification
		mpDangerousGoodsClf.put(ConstantsUtil.PPN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.PPR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.PPT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.DGD, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.UNN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.PSN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.HC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.PGGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.SHIPPINGQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.CON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.OPR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.CUST, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.SDGCUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP) : ConstantsUtil.EMPTY_STRING);
		mpDangerousGoodsClf.put(ConstantsUtil.SDGCOP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP) : ConstantsUtil.EMPTY_STRING);

		//Global Harmonized Standard
		mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTREVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTTITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpGlobalHarStandard.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME) : ConstantsUtil.EMPTY_STRING);
		mpGlobalHarStandard.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpGlobalHarStandard.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpGlobalHarStandard.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpGlobalHarStandard.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpGlobalHarStandard.put(ConstantsUtil.MARKETS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS) : ConstantsUtil.EMPTY_STRING);
		mpGlobalHarStandard.put(ConstantsUtil.LANGUAGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE) : ConstantsUtil.EMPTY_STRING);

		//mpStability
		mpStability.put(ConstantsUtil.MASTERPRODUCTPARTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.MASTERPRODUCTPARTREV,  (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.MASTERPRODUCTPARTTITLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.PRODUCTEXPDATEREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.TOTALSHELFLIFEDAYS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.TEMPERATUREGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.HUMIDITYGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.TRANSPORTHEATPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.BOUNDARYCONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS) : ConstantsUtil.EMPTY_STRING);
		mpStability.put(ConstantsUtil.STABILITYREPORTLINK, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);

		//Substitutes
		MapList mapList = doFop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, false, true, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
		if(mapList.size()!=0){
			mpSubstitute =  util.getSubstitute(context,mapList);
		}

		hmAttrib.put(ConstantsUtil.ATTRIBUTES, mpAttribResult);
		hmAttrib.put(ConstantsUtil.DANGEROUSGOODCLASSIFICATION, mpDangerousGoodsClf);
		hmAttrib.put(ConstantsUtil.GLABALHARMONIZEDSTANDARD, mpGlobalHarStandard);
		hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATA, mapStorageAndLabelResult);
		hmAttrib.put(ConstantsUtil.CHEMICALANDPHYSLEGACYPROP, mpPhyChemEngLegacyData);
		hmAttrib.put(ConstantsUtil.CHEMICALANDPHYSLEGACYWAREHOUSEPROP, mpPhyChemEngWareHouse);
		hmAttrib.put(ConstantsUtil.CHEMICALANDPHYSLEGACYGHDCPROP, mpPhysicalChemicalGHCProp);
		hmAttrib.put(ConstantsUtil.STABILITYRESULTS, mpStability);
		hmAttrib.put(ConstantsUtil.FORMULATIONPROCESS, mpFormulationProcess);
		hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
		hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mapWeightCharResult);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
		hmAttrib.put(ConstantsUtil.MATERIALPRODUCED, mpMaterialProduced);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
		hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);

		if(!bRoleFlag) {
			hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.ORGANIZATIONS, mpOrganization);
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.FORMULATIONPROCESSFORMULA, mpFormulaIngr);
		}

		sp.stop();
		System.out.println("Execution TIME::" + sp.getTime());
		/*for (Map.Entry<String, String> entry : resultMap.entrySet()) {
			System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
		}*/
		System.out.println("RESULT:: \n" + mpSubstitute);
		//System.out.println(new JSONObject(resultMap));
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End

	}
}
