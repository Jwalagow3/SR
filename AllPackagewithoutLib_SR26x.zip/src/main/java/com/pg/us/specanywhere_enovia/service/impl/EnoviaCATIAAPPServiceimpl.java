/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaCATIAAPPServiceimpl.java
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.CATIAAPPBO;
import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.SapBomAsFed;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaCATIAAPPServiceimpl {

	private static Logger LOGGER = Logger.getLogger(EnoviaCATIAAPPServiceimpl.class);


	public HashMap<String, Map<String,String>> getCatiaAPPdata(Context context ,String objId,String strPDFView,String container,String connectionString,String azureStore) throws Exception {
		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		try {
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();

			String sUserType = sct.getUserType();

			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
				
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			APPBO APPBO = new APPBO();
			DomainObject doAPP =  APPBO.getAppDO(context, objId);
			String strCurrent = doAPP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
				
			if(UIUtil.isNotNullAndNotEmpty(sUserType))
			{

				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					return hmAttrib;

				}
				//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
			}

			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mapWeightCharResult = new HashMap<String,String>();
			Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mpProductPartStabilityDoc = new HashMap<String,String>();
			Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
			Map<String,String> mapCountryClearanceResult = new HashMap<String,String>();
			Map<String,String> mpSubStanceResult = new HashMap<String,String>();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Map<String,String> mapPartSpecification = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			Map<String,String> mpAlternates = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpMaterialProduced = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			Map<String,String> mapCertifications = new HashMap<String,String>();
			Map<String,String> mpCertificationvalidation = new HashMap<String,String>();
			Map<String,String> mpDesignParameter = new HashMap<String,String>();
			Map<String,String> mpCharacteristics = new HashMap<>();

			CATIAAPPBO catiaAPPBO = new CATIAAPPBO();
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			RawMaterialPartBO RawBO = new RawMaterialPartBO();
			CommonBusUtilBO commonBO = new CommonBusUtilBO();
			DeviceProductPartBO DPPBO = new DeviceProductPartBO();

			Map<String, StringList> BusinessObjectSelectableMap = APPBO.getAPPSelectableMap(context);
			Map<String, StringList> ChilsObjectSelectableMap = APPBO.getAPPRelatedObjsSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);


			if(null==doAPP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				return hmAttrib;
			}

			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doAPP.getInfo(context, slContextSelects);
			Map resultMaps = doAPP.getInfo(context, slContextSelects,APPBO.addMultiSelects());
			swAttributes.stop();
			LOGGER.info("CATIA APP GETINFO ELAPSED TIME : "+swAttributes.getTime());

			boolean bGendocView = false;
			boolean bAuthorizedtoUse = util.isAuthorizedtoUse(context,doAPP,resultMaps,strPDFView);

			// Added by Jwala for PDF VIEW
			boolean bAuthorizedtoProduce = util.isAuthorizedtoProduce(context,doAPP,resultMaps,strPDFView);

			if((bManufacturerView && bAuthorizedtoProduce)) {
				bGendocView = true;
				mpHeaderContent.put(ConstantsUtil.VIEW,ConstantsUtil.GENDOCVIEW);
			}
			//SPEC: <17.08.2022>: Satyam Added for Defect 50091 -- START
			String strCertificationvalidation = DomainConstants.EMPTY_STRING;
			//SPEC: <17.08.2022>: Satyam Added for Defect 50091 -- END
			
			String sClassifictaion = util.getClassification(resultMaps);
			//Common usage Variables 
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			//ContextUtil.popContext(context);

			mpHeaderContent.put(ConstantsUtilIRM.CATIAAPP, ConstantsUtil.SYMBL_TRUE);

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			if(bAllInfoView || bManufacturerView || bGendocView) {
				/**
				 * LOAD HEADER CONTENT SECTION
				 * */
				mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 

				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
				mpHeaderContent.put(ConstantsUtil.PDF_VIEW, util.getPdfViewtype(bAllInfoView, bGendocView, bSupplierView));
				
				mpHeaderContent.put(ConstantsUtilIRM.CHARUPDATESTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARUPDATESTATUS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARUPDATESTATUS) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtilIRM.MODELUPDATESTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDMODELUPDATESTATUS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDMODELUPDATESTATUS) : ConstantsUtil.EMPTY_STRING);
				
				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPLACEDPRODUCTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BUSINESSAREA, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA)));
				mpAttribResult.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA)));
				mpAttribResult.put(ConstantsUtil.PRODUCTTECHNOLOGYPLATFORM, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM)));
				mpAttribResult.put(ConstantsUtil.PRODUCTTECHNOLOGYCHASSIS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS)));
				mpAttribResult.put(ConstantsUtil.FRANCHISE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE)));
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.UNIQUE_FORMULA_IDENTIFIER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 01-09-2022: Pooja Modified for Defect 50496 -- START
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 01-09-2022: Pooja Modified for Defect 50496 -- END
				mpAttribResult.put(ConstantsUtilIRM.PRODUCTDOSECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED))));
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DOESTHEPRODUCTCONTAINBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.PROD_VARIANNT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);

				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);

				mpAttribResult.put(ConstantsUtil.DUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ONSHELFPRODDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, (validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.strIntendedMarket))));
				mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);

				mpAttribResult.put(ConstantsUtilIRM.LPDREGION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDREGION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDREGION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.LPDSUBREGION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDSUBREGION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDSUBREGION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.CLONETRANSFERRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PROD_SIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.AUTHORINGAPPLICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DEFINITION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_REL_PNGDEFINITION)).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.EMPTY_SPACE).trim());
				mpAttribResult.put(ConstantsUtil.MODELTYPE, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_REL_PNGLPDMODELTYPE)).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.EMPTY_SPACE).trim());
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);

				//SPEC: <08.07.2022>: Satyam Added for Internal Defect  -- START
				mpAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.REASONFORMANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <08.07.2022>: Satyam Added for Internal Defect  -- END

				String strModelType = validator.getStringEquivalentForSubstituteString(mpAttribResult.get(ConstantsUtil.SELECT_REL_PNGLPDMODELTYPE));

				if(ConstantsUtilIRM.GENERIC.equalsIgnoreCase(strModelType))
					mpHeaderContent.put(ConstantsUtilIRM.REASONFORCHANGEGENERICMODEL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDREASONCHANGEGENERICMODEL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LPDREASONCHANGEGENERICMODEL) : ConstantsUtil.EMPTY_STRING);
				
				//Added by Ketan for Req. no. 46464 - START
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				//Added by Ketan for Req. no. 46464 - END

				if(bAllInfoView || bGendocView) {
					
					/**
					 * LOAD WEIGHT CHARACTERISTICS SECTION
					 * */ 
					StopWatch swWeightCharacteristics = new StopWatch();
					swWeightCharacteristics.start();
					mapWeightCharResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
					mapWeightCharResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
					mapWeightCharResult.put(ConstantsUtil.NETWEIGHT,  util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT) : ConstantsUtil.EMPTY_STRING));
					mapWeightCharResult.put(ConstantsUtil.ROLLUPNETWEIGHTTOCOP,  util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ROLLUPNETWEIGHTTOCOP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ROLLUPNETWEIGHTTOCOP) : ConstantsUtil.EMPTY_STRING));

					mapWeightCharResult = util.filterMapList(mapWeightCharResult);
					swWeightCharacteristics.stop();
					LOGGER.info("CATIA APP GET swWeightCharacteristics ELAPSED TIME : "+swWeightCharacteristics.getTime());


					/**
					 * LOAD SAP BOM SECTION
					 * */

					StopWatch swSapBomAsFed = new StopWatch();
					swSapBomAsFed.start();
					CalculateBOM clBom = new CalculateBOM();
					SapBomAsFed sapBom = new SapBomAsFed();
					mpSapBomAsFedcResult = sapBom.getSapBOMasFed(context,sContextObjectId);
					mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZED);
					mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOUSE);
					mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOPRODUCE);
					mpSapBomAsFedcResult = util.filterMapList(mpSapBomAsFedcResult);
					swSapBomAsFed.stop();
					LOGGER.info("CATIA APP GET SapBomAsFed ELAPSED TIME : "+swSapBomAsFed.getTime());

					/**
					 * LOAD SUBSTANCES SECTION
					 * */
					mpSubStanceResult = RawBO.getMaterialCompositionAndSubstance(context, resultMaps);
					mpSubStanceResult =util.verifyOwnership(context,mpSubStanceResult);
					mpSubStanceResult = util.filterMapList(mpSubStanceResult);

					/**
					 * LOAD BOM,SUBSTITUTES SECTION
					 * */
					StopWatch swBom = new StopWatch();
					swBom.start();

					MapList mapList = util.getExpandedBOM(context, doAPP, ConstantsUtil.RELATIONSHIP_EBOM, 
							ConstantsUtil.TYPE_PGPHASE, slChildBusSelects, slChildRelSelects, ConstantsUtil.SELECT_NAME+"=~~PCT*", "PCT");

					if(bManufacturerView) {
						mapList=util.filterPhase(mapList);
					}

					if(mapList.size()!=0){
						mpEBOMResult =	APPBO.parseMaplist(context,mapList, bGendocView);
					}
					hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
					swBom.stop();
					LOGGER.info("CATIA APP BOM ELAPSED TIME : "+swBom.getTime());
				}
				/**
				 * LOAD STORAGE AND LABEL SECTION
				 * */
				mapStorageAndLabelResult.put(ConstantsUtil.TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.PRODUCT_EXPOSED_CHILD, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.PRODUCTMARKETEDASCHILDREN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.PGDOESCILDSAFEDESIGN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_REL_SHIPPINGCLASSIF)));
				mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);								
				mapStorageAndLabelResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.EVAPORATION_RATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.RESERVE_ACIDITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.RESERVE_ALKANITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);

				/**
				 * LOAD NOTES SECTION
				 * */ 

				MasterCOPBO mcop = new MasterCOPBO();
				mpNotes=mcop.updateNotes(context, resultMaps);

				/**
				 * PRODUCT PART STABILITY DOC SECTION
				 */
				mpProductPartStabilityDoc = catiaAPPBO.getProductPartStabilityDoc(context,resultMaps);
				
				//SPEC: 08-12-2022: Satyam added for Req 45670 -- START
				mpProductPartStabilityDoc.remove(ConstantsUtil.MASTERPRODUCTPARTID);
				mpProductPartStabilityDoc.remove(ConstantsUtil.MASTERPRODUCTPARTNAME);
				mpProductPartStabilityDoc.remove(ConstantsUtil.MASTERPRODUCTPARTREV);
				mpProductPartStabilityDoc.remove(ConstantsUtil.MASTERPRODUCTPARTTITLE);
				mpProductPartStabilityDoc.remove(ConstantsUtil.MASTERPRODUCTPARTTYPE);
				//SPEC: 08-12-2022: Satyam added for Req 45670 -- END
				
				mpProductPartStabilityDoc = util.filterMapList(mpProductPartStabilityDoc);
				/**
				 * LOAD MARKET CLEARANCE
				 * */
				StopWatch swcountry = new StopWatch();
				swcountry.start();
				mapCountryClearanceResult = APPBO.getCountryClearance(context,sContextObjectId);
				//SPEC:11/21/2020: Modified for defect 37533 by Amman## -- END
				mapCountryClearanceResult = util.filterMapList(mapCountryClearanceResult);
				swcountry.stop();
				LOGGER.info("CATIA APP MARKET CLEARANCE TIME : "+swcountry.getTime());

				/**
				 * LOAD PART SPECIFICATION SECTION
				 * */ 
				mapPartSpecification = util.updatePartSpec(context,resultMaps);
				mapPartSpecification = util.filterMapList(mapPartSpecification);

				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
				swReference.stop();
				LOGGER.info("CATIA APP Reference ELAPSED TIME : "+swReference.getTime());

				if(bAllInfoView) {
					/**
					 * LOAD PLANTS SECTION
					 * */
					mpPlantResult=util.updatePlantInfo(resultMaps);
					mpPlantResult = util.filterMapList(mpPlantResult);
					
					/**
					 * LOAD LIFECYCLE SECTION
					 * */
					String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
					String[] changeargs={objId,sPhysicalId};
					StopWatch swLifecycle = new StopWatch();
					swLifecycle.start();
					mpLifeCycleApproval = util.getCOName(context, changeargs);
					swLifecycle.stop();
					LOGGER.info("CATIA APP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

					/**
					 * LOAD ORGANIZATION DATA SECTION
					 * */
					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {

						if ((ConstantsUtil.STRINGLIST).equalsIgnoreCase(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName()))
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} 
						else 
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
					}

					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {

						if ((ConstantsUtil.STRINGLIST).equalsIgnoreCase(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName()))
						{
							mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} else 
						{
							mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
					}
					mpOrganization = util.filterMapList(mpOrganization);

					/**
					 * LOAD IP CLASSES SECTION
					 */
					StringList slIpSelects = new StringList();
					slIpSelects.add(ConstantsUtil.SELECT_NAME);
					slIpSelects.add(ConstantsUtil.SELECT_ID);
					slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
					slIpSelects.add(ConstantsUtil.SELECT_TYPE);
					slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
					CommonBusUtilBO commonBo = new CommonBusUtilBO();
					mpIPClass =commonBo.getIpClass(context, doAPP, slIpSelects);

					/**
					 * LOAD SECURITY SECTION
					 * */
					StopWatch swSecurity = new StopWatch();
					CommonBusUtilBO bo = new CommonBusUtilBO();
					swSecurity.start();
					mpSecurity =bo.updateSecurity(context,resultMaps);
					mpSecurity = util.filterMapList(mpSecurity);
					swSecurity.stop();
					LOGGER.info("CATIA APP  Security ELAPSED TIME : "+swSecurity.getTime());
					
					/**
					 * LOAD OWNERSHIP SECTION
					 * */
					mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty(mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_ORIGINATOR)))?(String)resultMaps.get(DomainConstants.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(DomainConstants.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
					
					/**
					 * LOAD FILES SECTION
					 * */
					String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
					String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
					String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
					String FileSize = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
					
					//Added by Ketan for Internal Defect -- START
					
					/*StringBuilder sbFileSize = new StringBuilder();
					if(!FileSize.isEmpty()) {
						String[] strFileSize=FileSize.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

						for (int i = 0; i < strFileSize.length; i++) {
							String strEachFileSize = strFileSize[i];
							double dFileSize = Double.parseDouble(strEachFileSize);
							dFileSize = dFileSize/1024;
							strEachFileSize=Double.toString(dFileSize).format("%.2f", dFileSize);
							sbFileSize.append(strEachFileSize).append(" KB").append(ConstantsUtil.SYMBL_PIPE);
						}
					}*/
					
					StringBuilder sbFileName = new StringBuilder();
					StringBuilder sbFileCapturedFie = new StringBuilder();
					StringBuilder sbFileFormats = new StringBuilder();
					StringBuilder sbFileSize = new StringBuilder();
					if(!FileName.isEmpty()) {
						String[] strFileName=FileName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						String[] strFileCapturedFie=FileCapturedFie.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						String[] strFileFormats=FileFormats.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						String[] strFileSize=FileSize.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						
						for(int i = 0; i < strFileName.length; i++) {
							String strEachFileName = strFileName[i];
							String strEachFileCapturedFie = strFileCapturedFie[i];
							String strEachFileFormats = strFileFormats[i];
							String strEachFileSize = strFileSize[i];
							double dFileSize = Double.parseDouble(strEachFileSize);
							dFileSize = dFileSize/1024;
							strEachFileSize=Double.toString(dFileSize).format("%.2f", dFileSize);
							
							if(!strEachFileName.contains("Design_Parameters")) {
								sbFileName.append(strEachFileName).append(ConstantsUtil.SYMBL_PIPE);
								sbFileCapturedFie.append(strEachFileCapturedFie).append(ConstantsUtil.SYMBL_PIPE);
								sbFileFormats.append(strEachFileFormats).append(ConstantsUtil.SYMBL_PIPE);
								sbFileSize.append(strEachFileSize).append(" KB").append(ConstantsUtil.SYMBL_PIPE);
							}
							else {
								sbFileName.append(ConstantsUtil.EMPTY_STRING);
								sbFileCapturedFie.append(ConstantsUtil.EMPTY_STRING);
								sbFileFormats.append(ConstantsUtil.EMPTY_STRING);
								sbFileSize.append(ConstantsUtil.EMPTY_STRING);
							}
						}
					}
					//Added by Ketan for Internal Defect -- END
					
				mpFiles.put(ConstantsUtil.ACTION, sbFileCapturedFie.toString());
				mpFiles.put(ConstantsUtil.FILESFORMAT, sbFileFormats.toString());
				mpFiles.put(ConstantsUtil.FILESNAMES, sbFileName.toString());
				mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());
					
					
					
					/**
					 * LOAD GPSASSESSMENTS SECTION
					 * */
					StopWatch swgps= new StopWatch();
					swgps.start();
					mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
					mpGPSAssessments = util.filterMapList(mpGPSAssessments);
					swgps.stop();
					LOGGER.info("CATIA APP GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
				}

				/**
				 * ALTERNATES
				 * */

				mpAlternates = commonBO.getAlternates(context, sContextObjectId);
				mpAlternates = util.filterMapList(mpAlternates);
				//SPEC: 26/07/2022: Added by Manikanta for 22x DEV Req 41754-- START
				mpAlternates.remove(ConstantsUtil.WEIGHTDIFFERENCE);
				//SPEC: 26/07/2022: Added by Manikanta for 22x DEV Req 41754-- END

				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=util.getRelatedAts(context, doAPP);
				mpRelatedATS=util.filterMapList(mpRelatedATS);
				if(!mpRelatedATS.isEmpty()){
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
				}

				/**
				 * LOAD MATERIALS PRODUCED SECTION
				 * */ 
				StopWatch swMaterial = new StopWatch();
				swMaterial.start();
				mpMaterialProduced = APPBO.getMaterialProduced(context,sContextObjectId);
				mpMaterialProduced = util.filterMapList(mpMaterialProduced);
				swMaterial.stop();
				LOGGER.info("CATIA APP MATERIALS ELAPSED TIME : "+swMaterial.getTime());


				/**
				 * LOAD CERTIFICATIONVALIDATION SECTION
				 * */
				StopWatch swCerVali= new StopWatch();
				swCerVali.start();
				MapList mlCertValidation = util.getConnectedRawMaterialfromPart(context,sContextObjectId);
				mpCertificationvalidation = util.getCertValidationMap(context, resultMaps, mlCertValidation);
				mpCertificationvalidation = util.filterMapList(mpCertificationvalidation);
				//SPEC: <17.08.2022>: Satyam Added for Defect 50091 -- START
				strCertificationvalidation = validator.getStringEquivalentForStringList(mpCertificationvalidation.get(ConstantsUtil.SELECT_NAME));
				strCertificationvalidation = strCertificationvalidation.substring(0, strCertificationvalidation.length() -1);
				//SPEC: <17.08.2022>: Satyam Added for Defect 50091 -- END
				
				swCerVali.stop();
				LOGGER.info("CATIA APP CERTIFICATIONVALIDATION ELAPSED TIME : "+swCerVali.getTime());

				/**
				 * LOAD CERTIFICATIONS SECTION
				 * */
				mapCertifications=APPBO.getCertificationClaims(context,objId);
				mapCertifications = util.filterMapList(mapCertifications);

				/**
				 * LOAD CHARACTERISTICS SECTION
				 * */
				StopWatch swPerChar= new StopWatch();
				swPerChar.start();
				mpCharacteristics =catiaAPPBO.gePerformChar(context,sContextObjectId);
				swPerChar.stop();
				LOGGER.info("CATIA APP gePerformChar ELAPSED TIME : "+swPerChar.getTime());
			//SPEC: 21/05/2022: Added by Manikanta for 22x DEV Req 42404-- START
				/**
				 * DESIGN PARAMETER SECTION
				 * */
				StopWatch swDesignParam= new StopWatch();
				swDesignParam.start();
				if(!bManufacturerView) {
				mpDesignParameter = catiaAPPBO.getValuesFromXML(context,sContextObjectId,container,connectionString,azureStore);
				}
				swDesignParam.stop();
				LOGGER.info("CATIA APP Design Parameter ELAPSED TIME : "+swDesignParam.getTime());
			}
			
			hmAttrib.put(ConstantsUtilIRM.DESIGNPARAMETER, mpDesignParameter);
			//SPEC: 21/05/2022: Added by Manikanta for 22x DEV Req 42404-- END
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mapWeightCharResult);
			hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATAOBJECT, mapStorageAndLabelResult);
			hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			hmAttrib.put(ConstantsUtil.PRODUCTPARTSTABILITYDOC, mpProductPartStabilityDoc);
			hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
			hmAttrib.put(ConstantsUtil.MARKETOFCLEARANCE, mapCountryClearanceResult);
			hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpSubStanceResult);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mapPartSpecification);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
			hmAttrib.put(ConstantsUtil.ALTERNATES, mpAlternates);
			hmAttrib.put(ConstantsUtil.MATERIALPRODUCED, mpMaterialProduced);
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
			hmAttrib.put(ConstantsUtil.CERTIFICATIONS, mapCertifications);
			//SPEC: <17.08.2022>: Satyam Added for Defect 50091 -- START
			if(mpCertificationvalidation.size()!=1 && !(strCertificationvalidation.equalsIgnoreCase(mpHeaderContent.get(DomainConstants.SELECT_NAME)))) {
				hmAttrib.put(ConstantsUtilIRM.CERTIFICATIONVALIDATION, mpCertificationvalidation);
			}
			//SPEC: <17.08.2022>: Satyam Added for Defect 50091 -- END
			hmAttrib.put(ConstantsUtil.CHARACTERISTIC, mpCharacteristics);
		  	
			sp.stop();
		} catch (Exception e) {
			LOGGER.error("Unable to getCatiaAPPdata "+e);
		}
		//LOGGER.info("CATIA APP RESPONSE MESSAGE:: \n" + hmAttrib);
		return hmAttrib;
	}

}
