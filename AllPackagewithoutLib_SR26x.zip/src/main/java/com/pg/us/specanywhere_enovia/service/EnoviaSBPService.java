/**
 * Project 		: SpecReader
 * Program 		: EnoviaSBPService
 * Author  		: Chandra-Infosys Ltd.
 * Date 		:05-03-2021
 * Description 	: As part of 18x.6 this was introduced.
 */
package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaSBPService {
	public HashMap<String, Map<String, String>> getSBPdata(String objId, Environment env) throws Exception;
}
