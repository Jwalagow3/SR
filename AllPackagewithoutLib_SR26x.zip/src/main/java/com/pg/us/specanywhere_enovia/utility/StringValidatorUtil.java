package com.pg.us.specanywhere_enovia.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.TreeSet;

//SPEC: 03-05-2020: Added for 18x.6 DEV by Sanjeeva -- START
import java.util.LinkedList;
import java.util.LinkedHashSet;
//SPEC: 03-05-2020: Added for 18x.6 DEV by Sanjeeva -- END

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.util.StringList;
import com.matrixone.apps.domain.util.MapList;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

public class StringValidatorUtil {
	private static Logger LOGGER = Logger.getLogger(StringValidatorUtil.class);

	public StringValidatorUtil(){
		//empty constructor
	}
	public boolean isNotNullOrEmpty(String str) {
		if(null != str && !str.isEmpty() && !"null".equalsIgnoreCase(str))
			return true;
		return false;
	}

	public String isNotNullOrEmpty(StringList str, int i) {
		try {
		if(str.size()>i) {
			return str.get(i);
		} else {
			return "";
		}
		}catch(Exception e) {
			LOGGER.error("Exception in StringValidatorUtil::isNotNullOrEmpty(StringList,int)");
			return "";
		}
	}
	
	public boolean isNotNullOrEmptyArray(String[] str) {
		if(null != str && str.length!=0)
			return true;
		return false;
	}
	
	public StringList isNotNullOrEmpty(StringList slData) {
		try {
			if(null != slData && !slData.isEmpty()) {
				slData.toString();
			} else {
				return new StringList();
			}
		} catch (Exception e) {
			LOGGER.error("Exception while checking StringList isnullOrEmpty:"+e);
			return new StringList();
		}

		return slData;
	}
	
	public String getStringEquivalentForStringList(Object obj) {
		
		if(null!=obj) {
			if(obj.getClass()==String.class){
				return replaceSpecialSymbols((String)obj);
			}else {
				StringList sl = (StringList)obj;
				return replaceSpecialSymbols(sl.toString());
			}
		}else {
			return "";
		}
	}
	
	//SPEC: <11-17-2020>: Added for Defect 37342 -- START
	public String getClassType(Object obj) {
		
		if(null!=obj) {
			if(obj.getClass()==String.class){
				return "String";
			}else {
				return "StringList";
			}
		}else {
			return "";
		}
	}
	//SPEC: <11-17-2020>: Added for Defect 37342 -- END
	
	public String getStringEquivalentForStringListWithComma(Object obj) {
			
			if(null!=obj) {
				if(obj.getClass()==String.class){
					return replaceSpecialSymbolsWithComma((String)obj);
				}else {
					StringList sl = (StringList)obj;
					return replaceSpecialSymbolsWithComma(sl.toString());
				}
			}else {
				return "";
			}
		}
	
	public String replaceSpecialSymbolsWithComma(String sData)
	{
		if(!UIUtil.isNotNullAndNotEmpty(sData)){
			return ConstantsUtil.EMPTY_STRING;
		}
		sData= sData.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING);
		sData= sData.replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES).replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO);
		sData= sData.replace(ConstantsUtil.SYMBL_CAPTRUE, ConstantsUtil.SYMBL_YES).replace(ConstantsUtil.SYMBL_CAPFALSE, ConstantsUtil.SYMBL_NO);
		sData= sData.replace(ConstantsUtil.STATE_APPROVED, ConstantsUtil.RELEASED);
		return sData;
	}
	
	public String getStringEquivalentForString(Object obj) {
		
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		if(null!=obj) {
			if(obj.getClass()==String.class){
				return util.replaceSquareBrackets((String)obj);
			}else {
				StringList sl = (StringList)obj;
				return util.replaceSquareBrackets(sl.toString());
			}
		}else {
			return "";
		}
	}
	

	public String getStringEquivalentForSubstituteString(Object obj) {

		BusObjectAttribUtil util = new BusObjectAttribUtil();
		if(null!=obj) {
			if(obj.getClass()==String.class){
				return util.replaceSquareBracketsOnly((String)obj);
			}else {
				StringList sl = (StringList)obj;
				return util.replaceSquareBracketsOnly(sl.toString());
			}
		}else {
			return "";
		}
	}

	public String getStringEquivalentForSubstituteStringTitle(Object obj) {

		BusObjectAttribUtil util = new BusObjectAttribUtil();
		if(null!=obj) {
			if(obj.getClass()==String.class){
				return ((String)obj);
			}else {
				StringList sl = (StringList)obj;
				return ((String)obj);
			}
		}else {
			return "";
		}
	}
	
	public StringList getStringListEquivalentForString(Object obj) {
		if(null!=obj) {
			if(obj.getClass()==String.class){
				StringList _sl = new StringList();
				_sl.add((String)obj);
				return _sl;
			}else {
				StringList sl = (StringList)obj;
				return sl;
			}
		}else {
			return new StringList();
		}
	}
	
	public String getStringEquivalentForStringListWithSpecialChar(Object obj) {
		if(null!=obj) {
			if(obj.getClass()==String.class){
				return (String)obj;
			}else {
				StringList sl = (StringList)obj;
				return sl.toString();
			}
		}else {
			return "";
		}
	}
	public String replaceSpecialSymbols(String sData)
	{
		if(!UIUtil.isNotNullAndNotEmpty(sData)){
			return ConstantsUtil.EMPTY_STRING;
		}
		sData= sData.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
		sData= sData.replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES).replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO);
		sData= sData.replace(ConstantsUtil.SYMBL_CAPTRUE, ConstantsUtil.SYMBL_YES).replace(ConstantsUtil.SYMBL_CAPFALSE, ConstantsUtil.SYMBL_NO);
		sData= sData.replace(ConstantsUtil.STATE_APPROVED, ConstantsUtil.RELEASED);
		return sData;
	}
	
	public String formatRev(String[] sRD, String[] sRev, StringBuilder sb) {

		String sFinal = DomainConstants.EMPTY_STRING;
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		if (sRD.length == sRev.length) {
			for (int i = 0; i < sRD.length; i++) {
				sFinal = (String) sRD[i] + ConstantsUtil.SYMBL_COLON + (String) sRev[i];
				util.formatData(sb, sFinal);
			}
		}
		return sFinal;
	}
	
	/**
	 * Date Parser
	 * @param sDate
	 * @return
	 */
	public String DateFormatter(String sDate) {
		try {
			if(null!=sDate && !sDate.equalsIgnoreCase(ConstantsUtil.EMPTY_STRING)) {
				SimpleDateFormat formatter = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT);
				Date dDate = formatter.parse(sDate);
				sDate =  new SimpleDateFormat("MMM dd, yyyy").format(dDate);
			}else {
				return ConstantsUtil.EMPTY_STRING;
			}
		}catch(Exception e){
			LOGGER.error("EXCEPTION WHILE PARSING DATE IN STRINGVALIDATORUTIL : DATEFORMATTER: "+e);
			return "";
		}
		return sDate;
	}
	public String DateFormatterParse(String sDate) {
		try {
			if(null!=sDate && !sDate.equalsIgnoreCase(ConstantsUtil.EMPTY_STRING)) {

				SimpleDateFormat formatter = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT);
				Date dDate = formatter.parse(sDate);
				sDate =  new SimpleDateFormat("MMM dd, yyyy").format(dDate);

			}else {
				return ConstantsUtil.EMPTY_STRING;
			}
		}catch(Exception e){
			LOGGER.error("EXCEPTION WHILE PARSING DATE IN STRINGVALIDATORUTIL : DATEFORMATTER: "+e);
			return "";
		}
		return sDate;
	}
	
	/**
	 * Tokenize Files to not fetch only files from index
	 */
	public StringBuilder tokenizeFiles(String sStringToTokenize, StringBuilder sbTokenIndex) {
		StringTokenizer fileTokenizer = new StringTokenizer(sStringToTokenize,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		StringBuilder sbReturn = new StringBuilder();
		// Guna Added for Defect 38147  18x.5.2 Release -- START
		BusObjectAttribUtil util =new BusObjectAttribUtil();
		StringList slTokens =util.getStringListWithComma(sbTokenIndex.toString());
		// Guna Added for Defect 38147  18x.5.2 Release -- END
		int i=0;
		while(fileTokenizer.hasMoreTokens()) {
			// Guna Modified for Defect 38147  18x.5.2 Release -- START
			//if (!sStringToTokenize.contains(String.valueOf(i))) {
			if (!slTokens.contains(String.valueOf(i))) {
				// Guna Modified for Defect 38147  18x.5.2 Release -- END
				String sEachToken = fileTokenizer.nextToken();
				sbReturn.append(sEachToken).append(ConstantsUtil.SYMBL_PIPE);
			}else {
				fileTokenizer.nextToken();
			}
			i++;
		}
		return sbReturn;
	}
	
	
	
	
	/**
	 * SPEC : 11.27.2020 added by Chandra ## FOP Substitutes
	 * Added for reversing a string
	 * @param data
	 * @return
	 */
	
	public StringBuilder reverseString(String data)
	{
		StringBuilder sbPFunction  = new StringBuilder();
		try{
		List slData =FrameworkUtil.split(data, ConstantsUtil.SYMBL_PIPE);
		ListIterator itr = slData.listIterator(slData.size());
		while(itr.hasPrevious())
		{
			String 	sVal = getStringEquivalentForStringList(itr.previous());
			sbPFunction.append(sVal).append("|");
		}
		}catch(Exception e){
			LOGGER.error("Error from StringValidatorUtil: reverseString" + e);
			return sbPFunction;
		}
	
	return sbPFunction;
	
	}
	
	/**
	 * SPEC : 11.27.2020 added by Chandra ## FOP Substitutes
	 * Added for reversing a string
	 * @param data
	 * @return
	 */
	
	public StringBuilder sortString(String data)
	{
		StringBuilder sbPFunction  = new StringBuilder();
		Set mp = new TreeSet();
		try
		{
			List slData =FrameworkUtil.split(data, ConstantsUtil.SYMBL_PIPE);
			ListIterator itr = slData.listIterator(slData.size());
			while(itr.hasNext())
			{
				String 	sVal = getStringEquivalentForStringList(itr.next());
				mp.add(sVal);
			}
			for (Object sFinal : mp) {
				sbPFunction.append(sFinal).append("|");
			}
		}catch(Exception e){
			LOGGER.error("Error from StringValidatorUtil: reverseString" + e);
			return sbPFunction;
		}
	
	return sbPFunction;
	
	}
	
	
	public static String strcat(Object... var0) {
		StringBuilder var1 = new StringBuilder();
		Object[] var2 = var0;
		int var3 = var0.length;

		for (int var4 = 0; var4 < var3; ++var4) {
			Object var5 = var2[var4];
			var1.append(var5 == null ? "null" : var5.toString());
		}

		return var1.toString();
	}
	
	/**
	 * Added on 12-Dec-2020 by Chandra to avoid comma issues
	 * @param obj
	 * @return
	 */
	
	public String getEquivalentString(Object obj) {
		StringBuilder sbReturn = new StringBuilder();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		if(null!=obj) {
			if(obj.getClass()==String.class){
				util.formatData(sbReturn, (String)obj);
				return util.replaceSquareBracketsOnly(sbReturn.toString());
			}else
			{
				StringList sl = (StringList)obj;
				for (int i = 0; i < sl.size(); i++) {
					String sReturnValue =sl.get(i).trim();
					util.formatData(sbReturn, sReturnValue);
				}
				return util.replaceSquareBracketsOnly(sbReturn.toString());
			}
		}else {
			return "";
		}
	}
	// SPEC: Added for 18x.5.2 Defect 38603  --Jwala -- START
	/**
	 * Date Parser
	 * @param sDate
	 * @return
	 */
	public String effectvityDateFormatter(String sDate) {
		try {
			if(null!=sDate && !sDate.equalsIgnoreCase(ConstantsUtil.EMPTY_STRING)) {
			SimpleDateFormat formatter = new SimpleDateFormat(ConstantsUtil.DATE_FORMAT);
			formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
			Date dDate = formatter.parse(sDate);
			formatter.setTimeZone(TimeZone.getTimeZone("EST"));
			formatter.format(dDate);
			sDate =  new SimpleDateFormat("yyyy-MM-dd").format(dDate);
			//Modified for Defect #37254 -- END
			
			}else {
				return ConstantsUtil.EMPTY_STRING;
			}
			}catch(Exception e){
				LOGGER.error("EXCEPTION WHILE PARSING DATE IN STRINGVALIDATORUTIL : DATEFORMATTER: "+e);
				return "";
			}
			return sDate;
	}
	
	// SPEC: Added for 18x.5.2 Defect 38603  --Jwala -- START
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 04 Mar 2021 -- START
	/**
	 * Added on 04 March 2021 by gaikwad.tg to avoid list issues
	 * @param obj
	 * @return
	 */
	
	public String getEquivalentStringFromMapValue(Object obj) 
	{
		StringBuilder sbReturn = new StringBuilder();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		if(null!=obj) 
		{
			String strTemp = DomainConstants.EMPTY_STRING;
			//SPEC: Release SR18x.6.0 - #Defect41661 Added  by gaikwad.tg on Date 12 March 2021 -- START
			if(obj.getClass()==String.class)
			{
				strTemp = (String)obj;
				if(strTemp.equals(";"))
				strTemp = strTemp.replace(";", "");
				
				return util.replaceSquareBracketsOnly(strTemp);
			}
			else
			{
				StringList sl = (StringList)obj;
				sl.removeAll(sl.asList(";","", null));
				return util.replaceSquareBracketsOnly(sl.toString());
			}
			//SPEC: Release SR18x.6.0 - #Defect41661 Added  by gaikwad.tg on Date 12 March 2021 -- END
		}else 
			return "";
	}
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 04 Mar 2021 -- END
	
		//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 04/03/2021 -- START
	/**
	 * Data Parser
	 * @param paramMapList,paramString
	 * @return stringList
	 */
	public static StringList toStringList(MapList paramMapList, String paramString) {
	    StringList stringList = new StringList();
	    for (Iterator<Map> iterator = paramMapList.iterator(); iterator.hasNext();)
	      stringList.add(getString(iterator.next(), paramString)); 
	    return stringList;
	 }
	/**
	 * Data Parser
	 * @param paramMap,paramString
	 * @return String
	 */
	 public static String getString(Map paramMap, String paramString) {
		    String v = (paramMap != null) ? (String)paramMap.get(paramString) : null;
		    return (v != null) ? v.toString().trim() : "";
		 }
	//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 04/03/2021 -- END
//SPEC: 03-05-2020: Added for 18x.6 DEV by Sanjeeva -- START
	/**
	 * Duplicate Remover
	 * @param sString
	 * @return
	 */
	public String removeDuplicateValues(String sString) {
		try {

			if (isNotNullOrEmpty(sString)) {
				StringTokenizer tokenizer = new StringTokenizer(sString, ConstantsUtil.SYMBL_PIPE, true);
				List<String> removedList = new LinkedList<>();
				Set<String> s = new LinkedHashSet<>(removedList);
			
				while (tokenizer.hasMoreTokens()) {
			
				    String currentToken = tokenizer.nextToken().trim();
				    if (currentToken.equals(ConstantsUtil.SYMBL_PIPE)) {
				        continue;
				    }
				    s.add(currentToken);
				}
				sString = String.join(ConstantsUtil.SYMBL_PIPE,s);
				}
			}catch(Exception e){
				LOGGER.error("EXCEPTION WHILE PARSING STRING IN STRINGVALIDATORUTIL : DUPLICATEREMOVER: "+e);
				return "";
			}
		return sString;
	}
	//SPEC: 03-05-2020: Added for 18x.6 DEV by Sanjeeva -- END
	
	//SPEC: <04.05.2021>: Guna Added for 42853 Defect  Dev 18x.6   -- START
	public String getEquivalentStringComma(Object obj) {
		StringBuilder sbReturn = new StringBuilder();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		if(null!=obj) {
			if(obj.getClass()==String.class){
				sbReturn.append((String)obj);
				return getStringEquivalentForSubstituteString(sbReturn.toString());
			}else
			{
				StringList sl = (StringList)obj;
				for (int i = 0; i < sl.size(); i++) {
					String sReturnValue =sl.get(i).trim();
					if(i == 0){
						sbReturn.append(sReturnValue);
					}else{
						sbReturn.append(ConstantsUtil.SYMBL_COMMA).append(sReturnValue);
					}
					
				}
				return getStringEquivalentForSubstituteString(sbReturn.toString());
			}
		}else {
			return "";
		}
	}
	//SPEC: <04.05.2021>: Guna Added for 42853 Defect  Dev 18x.6   -- START
	/**
	 * Added by Dominic for the defect 44115 -- START
	 * @param obj
	 * @return
	 */
	
	public String getEquivalentStringForMC(Object obj) {
		StringBuilder sbReturn = new StringBuilder();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		if(null!=obj) {
			if(obj.getClass()==String.class){
				sbReturn.append((String)obj);
				return util.replaceSquareBracketsOnly(sbReturn.toString());
			}else
			{
				StringList sl = (StringList)obj;
				for (int i = 0; i < sl.size(); i++) {
					String sReturnValue =sl.get(i).trim();
					sbReturn.append(sReturnValue);
					sbReturn.append(ConstantsUtil.SYMBL_PIPE);
				}
				String strReturn=sbReturn.toString();
				if(strReturn.endsWith(ConstantsUtil.SYMBL_PIPE))
				{
					strReturn=strReturn.substring(0, strReturn.length() - 1);
				}		
				return util.replaceSquareBracketsOnly(strReturn);
			}
		}else {
			return "";
		}
	}
}
