package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;

import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.pg.us.specanywhere_enovia.bo.APMPBO;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.IRMSBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.MasterPackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PromotionalItemPartBO;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.EncryptCrypto;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class APMPService {

	private static Logger LOGGER = Logger.getLogger(APMPService.class);
	
	public static void main(String[] args) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		String objId = "20336.41905.58123.2854";
		
		StopWatch sppool = new StopWatch();
		sppool.start();
		
		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
	    Context context = pool.checkOut();
	    
	    sppool.stop();
		LOGGER.info("APMP sppool ELAPSED TIME : "+sppool.getTime());
		
	    boolean bAllInfoView = true;
		boolean bSupplierView = true;
		boolean bManufacturerView = true;
	   
		/*
		 * User Profile
		 * 
		SecurityService sct = new SecurityService();
		String sUserType = sct.getUserType();
		if(null==sUserType) {
			LOGGER.info("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
			HashMap<String,String> errorMap = new HashMap<String,String>();
			errorMap.put(ConstantsUtil.E101, ConstantsUtil.USER_PROFILE_EXCEPTION);
			hmAttrib.put(ConstantsUtil.ERROR, errorMap);
			return hmAttrib;
		}

		boolean bAllInfoView = false;
		boolean bSupplierView = false;
		boolean bManufacturerView = false;

		switch (sUserType) {
		case ConstantsUtil.PG:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PGSTAFF:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PG_CM:
			bManufacturerView = true;
			break;

		case ConstantsUtil.PG_SP:
			bSupplierView = true;
			break;
		}*/

		Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
		Map<String,String> mpDerivedToResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mpMaterialResult = new HashMap<String,String>();
		Map<String,String> mpPlantResult = new HashMap<String,String>();
		Map<String,String> mpPerformChar = new HashMap<String,String>();
		Map<String,String> mpPartSpecResult = new HashMap<String,String>();
		Map<String,String> mpSecurity = new HashMap<String,String>();
		Map<String,String> mpMasterSpecs = new HashMap<String,String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mpSubStanceResult = new HashMap<String,String>();

		APMPBO PAPBO = new APMPBO();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		MasterCOPBO mcop = new MasterCOPBO();
		Map<String, StringList> BusinessObjectSelectableMap = PAPBO.getAPMPPartSelectables(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringValidatorUtil validator = new StringValidatorUtil();
		DomainObject doPAP =  PAPBO.getAPMPDO(context, objId);
		/*if (null == doPAP) {
			HashMap<String,String> errorMap = new HashMap<String,String>();
			errorMap.put(ConstantsUtil.E100, ConstantsUtil.OBJECT_NOT_EXITS);
			hmAttrib.put(ConstantsUtil.ERROR, errorMap);
			LOGGER.info("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
			return hmAttrib;
		}*/
		PAPBO.addMultiList();
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doPAP.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("APMP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		PAPBO.removeMultiList();

		/*StringList slHistoryInfo = (StringList)resultMaps.get(ConstantsUtil.SELECT_HISTORY);
		String lastUpdatedUser = util.getLastUpdateUser(slHistoryInfo);*/

		String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;
		//Common usage Variables
		String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		
		if(bAllInfoView || bSupplierView || bManufacturerView) {
			
			
			/*
			 * LOAD PERFORMANCE CHAR SECTION
			 * */
			//Supplier View & All Info View
			String sRevision = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sName = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			StopWatch swPerfChar = new StopWatch();
			swPerfChar.start();
			//mpPerformChar = util.getExtendedPerformChar(context,doPAP,sRevision,sName,resultMaps);
			swPerfChar.stop();
			//mpPerformChar = util.filterMapList(mpPerformChar);
			LOGGER.info("APMP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
			
			
			/*
			 * SUBSTANCES & MATERIALS SECTION
			 * */
			RawMaterialPartBO RawBO = new RawMaterialPartBO();
			mpMaterialResult = RawBO.getSubstances(resultMaps);
			
			
			/*
			 * BASIC ATTRIBUTES SECTION
			 * */
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PARTCOLOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DECORATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LEGACY_ENV_CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS) : ConstantsUtil.EMPTY_STRING);
			
			/*
			 * HEADER CONTENT SECTION
			 * */
			mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);

			
			/*
			 * LOAD PART-SPEC SECTION
			 * */
			//Supplier View & All Info View
			mpPartSpecResult = util.updatePartSpec(context,resultMaps);
			
	
			/*
			 * MASTER SPECIFICATION
			 * */
			StopWatch swmpMasterSpecs = new StopWatch();
			swmpMasterSpecs.start();
			mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
			swmpMasterSpecs.stop();
			LOGGER.info("APMP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());
			
			
			
		}

		if(bSupplierView || bManufacturerView) {
			/*
			 * LOAD SUBSTANCES
			 * */
			//mpSubStanceResult = PAPBO.getSubstancesforSupplier(resultMaps);
		}

		if(bAllInfoView) {
			/*
			 * BASIC ATTRIBUTES SECTION
			 * */
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ALTERNATIVEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			String sClassifictaion = util.getClassification(resultMaps);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
			mpAttribResult.put(ConstantsUtil.OUTER_DIM_LENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OUTER_DIM_WIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OUTER_DIM_HEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);

			/*
			 * ORGANIZATION DATA SECTION
			 * */
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = util.filterMapList(mpOrganization);

			/*
			 * LOAD REFERENCE DOCS SECTION
			 * */
			StopWatch swReference= new StopWatch();
			swReference.start();
			mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
			swReference.stop();
			LOGGER.info("APMP  Reference ELAPSED TIME : "+swReference.getTime());
			//mapReferenceDocs = util.filterMapList(mapReferenceDocs);

			/*
			 * DERIVED PARTS DATA (RELATED PARTS)
			 * */
			APPBO APPBO = new APPBO();
			String sName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING;
			String sCreator = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)) : ConstantsUtil.EMPTY_STRING;
			
			//mpDerivedFromResult = APPBO.updateDerivedDataInfo(context,sName, sRev, sCreatedDate, sCreator,doPAP,true,false);
			//mpDerivedToResult = APPBO.updateDerivedDataInfo(context,sName, sRev, sCreatedDate,sCreator, doPAP,false,true);

			/*
			 * PLANT DATA SECTION
			 * */
			mpPlantResult = util.updatePlantInfo(resultMaps);
			
			/*
			 * LIFECYCLE SECTION
			 * */
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			mpLifeCycleApproval = util.getCOName(context, changeargs);
			swLifecycle.stop();
			LOGGER.info("APMP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
			mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);

			/*
			 * OWNERSHIP SECTION
			 * */
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
			
			/*
			 * SECURITY SECTION
			 * */
			StopWatch swSecurity = new StopWatch();
			swSecurity.start();
			CommonBusUtilBO bo = new CommonBusUtilBO();
			mpSecurity =bo.updateSecurity(context,resultMaps);
			swSecurity.stop();
			LOGGER.info("APMP  Security ELAPSED TIME : "+swSecurity.getTime());
		}

		pool.checkIn(context);

		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpMaterialResult);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO, mpDerivedToResult);
		hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
		hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
		hmAttrib.put(ConstantsUtil.SUBSTANCES, mpSubStanceResult);
				
		sp.stop();
		LOGGER.info("APMP Execution TIME::" + sp.getTime() +"  " + "APMP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
				
		System.out.println("RESULT:::::::::::::::::::: \n" + mpMasterSpecs);
		//LOGGER.info("RESULT:: \n" + hmAttrib);
		
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
	
	}
}
