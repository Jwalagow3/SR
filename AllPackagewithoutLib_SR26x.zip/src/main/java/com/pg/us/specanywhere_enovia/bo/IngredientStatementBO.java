/*
 * IngredientStatementBO File created for Copy List
 * To Manage all the constants created for SR2018x.6 Project.
   Project Name: SR2018x.6
   BO Name: IngredientStatementBO
   Clone From/Reference:
   Purpose: To Declare constants
   Change History : 
   SR 2018x.6 Added by Jwala for New services/type for the Dev SR2018x.6 Release 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class IngredientStatementBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(IngredientStatementBO.class);
	BusObjectAttribUtil util  = new BusObjectAttribUtil();

	public IngredientStatementBO() {
		// empty constructor
	}

	public IngredientStatementBO(String oid) {
		this.setObjectId(oid);
	}

	/**
	 * Method Name 			: getIngredientStatementBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getIngredientStatementBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	/**
	 * Method Name 			: getAPMPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */	
	public DomainObject getIngredientStatementDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	/**
	 * Method Name 			: getIngredientStatementSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getIngredientStatementSelectables(Context context) {
		StringList busSelect = new StringList(150);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXT);
		busSelect.add(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_PGAICN);
		busSelect.add(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_PGADJTARGET);
		busSelect.add(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_COMMONNAME);
		busSelect.add(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_ISBASECOPY);
		busSelect.add(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXTLANG);
		busSelect.add(ConstantsUtilIRM.CL_PARENTPART);
		busSelect.add(ConstantsUtilIRM.CL_PARENTPART_REVISION);

		return busSelect;

	}
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	: 
	 */
	public StringList addMultiList(){

		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXT);
		slMultiSelects.add(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_PGAICN);
		slMultiSelects.add(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_PGADJTARGET);
		slMultiSelects.add(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_COMMONNAME);
		slMultiSelects.add(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_ISBASECOPY);
		slMultiSelects.add(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXTLANG);
		
		return slMultiSelects;
		
	}
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	: 
	 */
	public  void removeMultiList(){

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_PGAICN);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_PGADJTARGET);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_COMMONNAME);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_ISBASECOPY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXTLANG);
		
	}
	
	public Map getCopyListAndMasterCopyElement(Context context, String strContextObjectId)throws Exception{
		MapList mlReturnList = new MapList();
		Map mpReturnMap = new HashMap();

		String strCopyTxt = DomainConstants.EMPTY_STRING;
		String strBaseCOpy = DomainConstants.EMPTY_STRING;
		String strCopyLang = DomainConstants.EMPTY_STRING;
		String strPgACN = DomainConstants.EMPTY_STRING;
		String strAdjTarget = DomainConstants.EMPTY_STRING;
		String strCommonName = DomainConstants.EMPTY_STRING;
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();

		try{
			if(UIUtil.isNotNullAndNotEmpty(strContextObjectId)){
				StringBuilder relPattern = new StringBuilder();	
				StringBuilder typePattern = new StringBuilder();	

				StringBuilder sbpgACIN = new StringBuilder();
				StringBuilder sbAdjTarget = new StringBuilder();
				StringBuilder sbCOmmonName = new StringBuilder();
				StringBuilder sbCopyText = new StringBuilder();

				StringList slObjSelects = new StringList(DomainConstants.SELECT_ID);
				StringList slRelSelects = new StringList(DomainRelationship.SELECT_ID);

				String strObjectId = DomainConstants.EMPTY_STRING;
				String strBaseCopyId = DomainConstants.EMPTY_STRING;
				DomainObject domObj = null;
				DomainObject domBaseCopyObj = null;
				Map tempObjMap = null;
				String strCLObjType = DomainConstants.EMPTY_STRING;
				String strCLObjState = DomainConstants.EMPTY_STRING;

				slObjSelects.addElement(new StringBuilder("from[").append(ConstantsUtilIRM.RELATIONSHIP_COPYLISTCOUNTRY).append("].to.name").toString());
				
				typePattern.append(ConstantsUtilIRM.TYPE_MASTER_COPY_ELEMENT);
				typePattern.append(ConstantsUtil.SYMBL_COMMA);
				typePattern.append(ConstantsUtilIRM.TYPE_COPY_ELEMENT);
				
				relPattern.append(ConstantsUtilIRM.REL_COPY_LIST_ARTWORK_MASTER);
				relPattern.append(ConstantsUtil.SYMBL_COMMA);
				relPattern.append(ConstantsUtilIRM.REL_ARTWORK_ASSEMLY);

				mlReturnList = DomainObject.newInstance(context, strContextObjectId).getRelatedObjects(
						context, 																				// Context
						relPattern.toString(), 																// Relationship Pattern
						typePattern.toString(), 																// Type Pattern
						slObjSelects,																			// Object Select	
						slRelSelects,																			// Relationship select
						false,																					// Get From side objects
						true, 																					// Get To side objects
						(short)1, 																				// Level to traverse
						null,																					// Object where clause
						null,																					// Object where clause
						0);																						// Number of objects to be retrieved


				StringList slSelects = new StringList();
				slSelects.addElement(ConstantsUtilIRM.SELECT_ATTR_PG_AICN);
				slSelects.addElement(ConstantsUtilIRM.SELECT_ATTR_PG_ADJ_TARGET);
				slSelects.addElement(ConstantsUtilIRM.SELECT_ATTR_COMMON_NAME);
				slSelects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_COPYTEXT);

				for (int i = 0, nSize = mlReturnList.size(); i < nSize; i++) {

					tempObjMap = (Map) mlReturnList.get(i);
					if(tempObjMap != null && !tempObjMap.isEmpty())
					{
						strObjectId = (String)tempObjMap.get(ConstantsUtil.SELECT_ID);
						strCLObjType = (String)tempObjMap.get(DomainConstants.SELECT_TYPE);
						strCLObjState = (String)tempObjMap.get(DomainConstants.SELECT_CURRENT);
						if(UIUtil.isNotNullAndNotEmpty(strCLObjType) && UIUtil.isNotNullAndNotEmpty(strCLObjState) && ConstantsUtil.TYPE_COPYLIST.equalsIgnoreCase(strCLObjType) && ConstantsUtil.STATE_OBSOLETE.equals(strCLObjState)) 
						continue;
						
						if(UIUtil.isNotNullAndNotEmpty(strObjectId)) {
							domObj = DomainObject.newInstance(context, strObjectId);

							Map tempMap = domObj.getInfo(context,slSelects);
							if(domObj.isKindOf(context, ConstantsUtilIRM.TYPE_MASTER_COPY_ELEMENT))
							{
								strPgACN = (String)tempMap.get(ConstantsUtilIRM.SELECT_ATTR_PG_AICN);
								strAdjTarget = (String)tempMap.get(ConstantsUtilIRM.SELECT_ATTR_PG_ADJ_TARGET);
								strCommonName = (String)tempMap.get(ConstantsUtilIRM.SELECT_ATTR_COMMON_NAME);
								//Get all connected Copy Element and select only the one with values "Is Base Copy=Yes" and 'Copy Text Language = Englist_US'
								strBaseCopyId = getConnectedCopyElements(context, domObj);
								if(UIUtil.isNotNullAndNotEmpty(strBaseCopyId)) {
									domBaseCopyObj = DomainObject.newInstance(context, strBaseCopyId);
									strCopyTxt = (String)domBaseCopyObj.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_COPYTEXT);
								} else {
									strCopyTxt = DomainConstants.EMPTY_STRING;
								}
								busUtil.formatData(sbCopyText, strCopyTxt);
								busUtil.formatData(sbpgACIN, strPgACN);
								busUtil.formatData(sbAdjTarget, strAdjTarget);
								busUtil.formatData(sbCOmmonName, strCommonName);
							} 
						}
					} // end of if empty check strObjectId
				} // end of if empty check tempObjMap

				mpReturnMap.put(ConstantsUtilIRM.INGREDIENTS, sbCopyText.toString().trim());
				mpReturnMap.put(ConstantsUtilIRM.AICN, sbpgACIN.toString().trim());
				mpReturnMap.put(ConstantsUtilIRM.ADJUSTEDTARGET, sbAdjTarget.toString().trim());
				mpReturnMap.put(ConstantsUtilIRM.COMMONNAME, sbCOmmonName.toString().trim());
			} // end of for loop
		}catch(Exception ex){
			throw ex;
		}

		return mpReturnMap;
	}
	
	
	public String getConnectedCopyElements(Context context,DomainObject domObj) throws Exception
	{
		String strBaseCopyId = DomainConstants.EMPTY_STRING;
		try {
			if(null!=domObj)
			{
				String strCopyId = DomainConstants.EMPTY_STRING;
				String strAttrIsBaseCopyValue = DomainConstants.EMPTY_STRING;
				String strAttrCopyTextLanValue = DomainConstants.EMPTY_STRING;
				StringList slObjSelects = new StringList(ConstantsUtil.SELECT_ID);
				slObjSelects.addElement(DomainObject.getAttributeSelect(ConstantsUtil.SELECT_ATTRIBUTE_COPYTEXT));
				slObjSelects.addElement(DomainObject.getAttributeSelect(ConstantsUtilIRM.ATTR_IS_BASE_COPY));
				slObjSelects.addElement(DomainObject.getAttributeSelect(ConstantsUtilIRM.ATTR_COPY_TEXT_LANGUAGE));
				Map mpCopyElementsMap = null;
				MapList mlCopyElements = null;
				
				mlCopyElements = domObj.getRelatedObjects(
						context, 												//context 
						ConstantsUtilIRM.REL_ARTWORK_ELEMENT_CONTENT,							//relationship Pattern
						ConstantsUtilIRM.TYPE_COPY_ELEMENT,		 								//type Pattern
						slObjSelects, 											//object selects
						null, 													//relationship Selects
						false, 													//get to direction
						true, 													//get from direction
						(short) 1, 												//recurse level
						null, 													//Object Where Clause
						null, 												    //Relationship Where Clause
						0); 													//limit
				if (mlCopyElements != null && !mlCopyElements.isEmpty()) {
					for (int j=0;j<mlCopyElements.size();j++) {
						mpCopyElementsMap = (Map) mlCopyElements.get(j);
						strCopyId = (String)mpCopyElementsMap.get(ConstantsUtilIRM.SELECT_ID);
						strAttrIsBaseCopyValue = (String)mpCopyElementsMap.get(DomainObject.getAttributeSelect(ConstantsUtilIRM.ATTR_IS_BASE_COPY));
						strAttrCopyTextLanValue = (String)mpCopyElementsMap.get(DomainObject.getAttributeSelect(ConstantsUtilIRM.ATTR_COPY_TEXT_LANGUAGE));
						//Add the attribute "Copy Text" of LC which have "Is Base Copy" as Yes and "Copy Text Language" as English_US
						if(UIUtil.isNotNullAndNotEmpty(strCopyId) && UIUtil.isNotNullAndNotEmpty(strAttrIsBaseCopyValue) && UIUtil.isNotNullAndNotEmpty(strAttrCopyTextLanValue) 
								&& ConstantsUtilIRM.INIT_CAPS_YES.equalsIgnoreCase(strAttrIsBaseCopyValue) && ConstantsUtilIRM.CONSTANT_ENGLISH_US.equalsIgnoreCase(strAttrCopyTextLanValue)){
							strBaseCopyId = strCopyId;
						} 
					}
				}
			}
		} catch(Exception e) {
			throw e;
		}
		return strBaseCopyId;
	}

}
