package com.pg.us.specanywhere_enovia.utility;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class FileUtil {

	private static Logger LOGGER = Logger.getLogger(BusExtractUtil.class);
	
	public void FileUtil() {
		// empty constructor
	}
	
	public Map getIrmReferenceDocumentFiles(Context context, String sObjectId) {
		
		DomainObject doIrm;
		Map resultMaps = new HashMap();
		try {
			doIrm = new DomainObject(sObjectId);
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME);
			busSelect.add(ConstantsUtil.SELECT_FILE_SIZE);
			busSelect.add(ConstantsUtil.SELECT_FILE_FORMAT);
			busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_FILE_SIZE);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_FILE_FORMAT);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_CAPTURED);
			
			resultMaps = doIrm.getInfo(context, busSelect);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doIrm.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_FILE_SIZE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_FILE_FORMAT);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FileUtil Method :getIrmReferenceDocumentFiles " + e);
			return new HashMap();
		}
		
		return resultMaps;
		
	}
	
	/**
	 * Get the Gendoc for IRM documents - Approval Document and associated Files (this is only for the Ref Docs section under parent part.
	 * @param context
	 * @param doIrm
	 * @return
	 */
	public Map getGendocForIRM(Context context, DomainObject doIrm) {
		
		Map resultMaps = new HashMap();
		try {
			StringList busSelect = new StringList();
			StringList slMultiSelect = new StringList();
			busSelect.add(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME);
			busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
			//Added by Jwala for IRMStore path 47636 -- START
			busSelect.add(ConstantsUtil.STR_FILE_STORE);
			//Added by Jwala for IRMStore path 47636 -- END
			
			slMultiSelect.add(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME);
			slMultiSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
			//Added by Jwala for IRMStore path 47636 -- START
			slMultiSelect.add(ConstantsUtil.STR_FILE_STORE);
			//Added by Jwala for IRMStore path 47636 -- END
			
			resultMaps = doIrm.getInfo(context, busSelect,slMultiSelect);
			
			if (!resultMaps.isEmpty()) {
				StringValidatorUtil validator = new StringValidatorUtil();
				String strCapturedFilePath = ConstantsUtil.EMPTY_STRING;
					if (resultMaps.containsKey(ConstantsUtil.STR_FILE_STORE)) {
						if (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_FILE_STORE)).contains(ConstantsUtilIRM.IRMSTORE)) {
							//SPEC: 22-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50179-- START
							strCapturedFilePath = getStringEquivalentForFile(resultMaps);			
							//SPEC: 22-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50179-- END
							resultMaps.replace(ConstantsUtil.STR_FILE_CAPTURED, strCapturedFilePath);
						}
					}
			}
			
			
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FileUtil Method :getGendocForIRM " + e);
			return new HashMap();
		}
		
		return resultMaps;
		
	}
	
	
	/**
	 * Get the Gendoc for Non-IRM documents (this is only for the Ref Docs section under parent part.
	 * @param context
	 * @param doRefDoc
	 * @return
	 */
	public Map getGendocForReferenceDocuments(Context context, DomainObject doRefDoc) {
		
		Map resultMaps = new HashMap();
		StringList busSelect = new StringList();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		StringBuilder sbGendocName = new StringBuilder();
		StringBuilder sbGendocPath = new StringBuilder();
		try {
			
			MapList mlRefDocs = doRefDoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.TYPE_PGIPMDOCUMENT, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			if(mlRefDocs.isEmpty()) {
				return new HashMap();
			}
			Iterator objectListItr = mlRefDocs.iterator();
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sRev    =  (String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					String sGendocName    =  (String)objectMap.get(ConstantsUtil.STR_FILE_NAME);
					String sGendocPath    =  (String)objectMap.get(ConstantsUtil.STR_FILE_CAPTURED);
					util.formatData(sbGendocName, sGendocName);
					util.formatData(sbGendocPath, sGendocPath);
				}
			}
			resultMaps.put(ConstantsUtil.STR_FILE_NAME, sbGendocName.toString());
			resultMaps.put(ConstantsUtil.STR_FILE_CAPTURED, sbGendocPath.toString());
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FileUtil Method :getGendocForReferenceDocuments " + e);
			return new HashMap();
		}
		
		return resultMaps;
		
	}
	
	
	/**
	 * Get the files for IPM documents since they do not have a gendoc themselves
	 * @param context
	 * @param doIrm
	 * @return
	 */
	public Map getFilesForIPM(Context context, DomainObject doIrm) {
		
		Map resultMaps = new HashMap();
		try {
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.STR_FILE_NAME);
			busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
			// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
			busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_CAPTURED);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FORMAT_FILE);
			
			resultMaps = doIrm.getInfo(context, busSelect);
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
			// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FileUtil Method :getGendocForIRM " + e);
			return new HashMap();
		}
		
		return resultMaps;
		
	}
	
	
	/**
	 * Get the Gendoc for any specification (non structured data) (this is only for related specification section under parent part.
	 * @param context
	 * @param doRefDoc
	 * @return
	 */
	public Map getGendocForSpecification(Context context, DomainObject doRefDoc) {
		
		Map resultMaps = new HashMap();
		StringList busSelect = new StringList();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		StringBuilder sbGendocName = new StringBuilder();
		StringBuilder sbGendocPath = new StringBuilder();
		try {
			
			MapList mlRefDocs = doRefDoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.TYPE_PGIPMDOCUMENT, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			if(mlRefDocs.isEmpty()) {
				return new HashMap();
			}
			Iterator objectListItr = mlRefDocs.iterator();
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sRev    =  (String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					String sGendocName    =  (String)objectMap.get(ConstantsUtil.STR_FILE_NAME);
					String sGendocPath    =  (String)objectMap.get(ConstantsUtil.STR_FILE_CAPTURED);
					util.formatData(sbGendocName, sGendocName);
					util.formatData(sbGendocPath, sGendocPath);
				}
			}
			resultMaps.put(ConstantsUtil.STR_FILE_NAME, sbGendocName.toString());
			resultMaps.put(ConstantsUtil.STR_FILE_CAPTURED, sbGendocPath.toString());
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FileUtil Method :getGendocForReferenceDocuments " + e);
			return new HashMap();
		}
		
		return resultMaps;
		
	}
	//SPEC: 22-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50179-- START
	/**
	 * Get the file path  for Reference documents .
	 * @param resultMaps
	 * @return String
	 */
	public String getStringEquivalentForFile(Map resultMaps) {

		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbGendocPath = new StringBuilder();
		String strCaptured=validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
		if(UIUtil.isNotNullAndNotEmpty(strCaptured)) {
			String strIRMStore=ConstantsUtilIRM.IRMSTORE.toLowerCase();
			strIRMStore=strIRMStore.replaceAll(ConstantsUtilIRM.BLANK_SPACE, DomainConstants.EMPTY_STRING);
			strCaptured=strCaptured.replaceAll((ConstantsUtil.SYMBL_COMMA+ConstantsUtilIRM.BLANK_SPACE), (ConstantsUtil.SYMBL_COMMA+strIRMStore+ConstantsUtil.SYMBL_SLASH));
			sbGendocPath.append(strIRMStore);
			sbGendocPath.append(ConstantsUtil.SYMBL_SLASH);
			sbGendocPath.append((strCaptured == null	? DomainConstants.EMPTY_STRING :strCaptured));
		}
		return sbGendocPath.toString();
	}
	//SPEC: 22-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50179-- END
}
