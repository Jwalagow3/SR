/*package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.ApprovedSupplierListBO;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.TransportUnitBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class ApprovedSupplierListService {

	private static Logger LOGGER = Logger.getLogger(ConsumerDesignBasisService.class);

	
	public static void main(String[] args) throws Exception {

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		//String oid = "20336.41905.26304.22737";
		String oid = "20336.41905.23936.23164";
		Context context = pool.checkOut();

		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
			
		Map<String,String> mpHeaderResult = new HashMap<String,String>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String, String>();
		Map<String,String> mapSuplierInfo = new HashMap<String,String>();
		Map<String,String> mapInternalInfo = new HashMap<String, String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String, String>();

		BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();

		ApprovedSupplierListBO asl = new ApprovedSupplierListBO();
		DomainObject doASL= asl.getASLDO(context,oid);
		Map BusinessObjectSelectableMap = asl.getApprovedSupplierListBasisSelectables(context);
		StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

		String strCSSManufacturer = (String) doASL.getInfo(context, ConstantsUtil.STR_SELECT_CSSMANUFACTURER);

		StringList strCSSManufacturerList = FrameworkUtil.split(strCSSManufacturer, ConstantsUtil.SYMBL_TILDA);

		String strManufacturer = ConstantsUtil.EMPTY_STRING;
		String strMfrPlantLocationCity = ConstantsUtil.EMPTY_STRING;
		String strMfrplantcountry = ConstantsUtil.EMPTY_STRING;
		String strMfrvendornumber = ConstantsUtil.EMPTY_STRING;
		
		if(!strCSSManufacturerList.isEmpty()){
		strManufacturer = strCSSManufacturerList.get(0);
		strMfrPlantLocationCity = strCSSManufacturerList.get(2);
		strMfrplantcountry = strCSSManufacturerList.get(4);
		strMfrvendornumber = strCSSManufacturerList.get(5);
		}

		Map resultMaps = doASL.getInfo(context, slSelects);

		//Header Content
		StopWatch sHeader = new StopWatch();
		sHeader.start();
		mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
		mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);

		String strSAPname = (String)resultMaps.get(ConstantsUtil.SELECT_SAP_NAME);
		strSAPname = strSAPname+"."+(String)resultMaps.get(ConstantsUtil.SELECT_SAP_REVISION);
		sHeader.stop();
		LOGGER.info("ASL  Header ELAPSED TIME : "+sHeader.getTime());

		//Attribute Data
		StopWatch swAttrib = new StopWatch();
		swAttrib.start();
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strSegment)))?(String)resultMaps.get(ConstantsUtil.strSegment) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NAME,strSAPname);
		mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_SAP_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_SAP_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);

		swAttrib.stop();
		LOGGER.info("ASL GET Attribute ELAPSED TIME : "+swAttrib.getTime());

		//Organization Data
		StopWatch swOrganization = new StopWatch();
		swOrganization.start();
		mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization = util.filterMapList(mpOrganization);
		swOrganization.stop();
		LOGGER.info("ASL Organization ELAPSED TIME : "+swOrganization.getTime());

		//Lifecycle
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={oid,sPhysicalId};
		StopWatch swLifecycle = new StopWatch();
		swLifecycle.start();
		mpLifeCycleApproval = util.getCOName(context, changeargs);
		swLifecycle.stop();
		LOGGER.info("ASL  LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

		//Ownership
		StopWatch swOwnerShip = new StopWatch();
		swOwnerShip.start();
		mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.OWNINGSTANDARDOFFICE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
		String sEDList =RawMaterialPartBO.getEDList(resultMaps);
		mapOwnerShipResult.put(ConstantsUtil.EDL, sEDList);
		mapOwnerShipResult.put(ConstantsUtil.ODL, util.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST) : ConstantsUtil.EMPTY_STRING));
		mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
		swOwnerShip.stop();
		LOGGER.info("ASL  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());

		//Supplier Information
		mapSuplierInfo.put(ConstantsUtil.CHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_SAP_PGCHANGE)))?(String)resultMaps.get((ConstantsUtil.SELECT_SAP_PGCHANGE)) : ConstantsUtil.EMPTY_STRING));
		mapSuplierInfo.put(ConstantsUtil.MANUFACTURER, strManufacturer);
		mapSuplierInfo.put(ConstantsUtil.MANUFACTURERNUMBER, strMfrvendornumber);
		mapSuplierInfo.put(ConstantsUtil.MANUFACTUREPLANTLOCATIONCITY, strMfrPlantLocationCity);
		mapSuplierInfo.put(ConstantsUtil.MANUFACTUREPLANTLOCATIONCONTRY, strMfrplantcountry);
		mapInternalInfo.put(ConstantsUtil.MANUFACTURERLINES, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_SAP_ASLLOCATION)))?(String)resultMaps.get((ConstantsUtil.SELECT_SAP_ASLLOCATION)) : ConstantsUtil.EMPTY_STRING));
		mapSuplierInfo.put(ConstantsUtil.TRADERDISTIBUTOR, strManufacturer);
		mapSuplierInfo.put(ConstantsUtil.TRADERDISTIBUTORVENDORNUMBER, strMfrvendornumber);
		mapSuplierInfo.put(ConstantsUtil.MANUFACTURERQUALIFICATIONSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_SAP_QUALIFICATIONSTATUS)))?(String)resultMaps.get((ConstantsUtil.SELECT_SAP_QUALIFICATIONSTATUS)) : ConstantsUtil.EMPTY_STRING));
		mapSuplierInfo.put(ConstantsUtil.MANUFACTURECLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_SAP_CLASSIFICATION)))?(String)resultMaps.get((ConstantsUtil.SELECT_SAP_CLASSIFICATION)) : ConstantsUtil.EMPTY_STRING));
		mapSuplierInfo.put(ConstantsUtil.MATERIALTRADENAME, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_SAP_SUPPLIERTRADENAME)))?(String)resultMaps.get((ConstantsUtil.SELECT_SAP_SUPPLIERTRADENAME)) : ConstantsUtil.EMPTY_STRING));
		mapSuplierInfo.put(ConstantsUtil.SUPPLIERINFOSHEETNAME, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.STR_PARTSPEC_NAME)))?(String)resultMaps.get((ConstantsUtil.STR_PARTSPEC_NAME)) : ConstantsUtil.EMPTY_STRING));
		mapSuplierInfo = BbUtil.filterMapList(mapSuplierInfo);

		//Internal Information
		mapInternalInfo.put(ConstantsUtil.CHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_SAP_PGCHANGE)))?(String)resultMaps.get((ConstantsUtil.SELECT_SAP_PGCHANGE)) : ConstantsUtil.EMPTY_STRING));
		mapInternalInfo.put(ConstantsUtil.MANUFACTURER, strManufacturer);
		mapInternalInfo.put(ConstantsUtil.MANUFACTUREPLANTLOCATIONCITY, strMfrPlantLocationCity);
		mapInternalInfo.put(ConstantsUtil.TRADERDISTIBUTOR, strManufacturer);
		mapInternalInfo.put(ConstantsUtil.USINGPLANTLOCATION, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_SAP_ASLLOCATION)))?(String)resultMaps.get((ConstantsUtil.SELECT_SAP_ASLLOCATION)) : ConstantsUtil.EMPTY_STRING));
		mapInternalInfo.put(ConstantsUtil.USINGGBU, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_PGGBU)))?(String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_PGGBU)) : ConstantsUtil.EMPTY_STRING));
		mapInternalInfo.put(ConstantsUtil.CATEGORY, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_CATEGORY)))?(String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_CATEGORY)) : ConstantsUtil.EMPTY_STRING));
		mapInternalInfo.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_BRAND)))?(String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_BRAND)) : ConstantsUtil.EMPTY_STRING));
		mapInternalInfo.put(ConstantsUtil.PRODUCTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_PRODUCT)))?(String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_PRODUCT)) : ConstantsUtil.EMPTY_STRING));
		mapInternalInfo.put(ConstantsUtil.PSRA, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_PSRAINFORMATION)))?(String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_PSRAINFORMATION)) : ConstantsUtil.EMPTY_STRING));
		mapInternalInfo.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_COMMENT)))?(String)resultMaps.get((ConstantsUtil.SELECT_PGINTERNUL_COMMENT)) : ConstantsUtil.EMPTY_STRING));
		mapInternalInfo = BbUtil.filterMapList(mapInternalInfo);

		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.SUPPLIERINFO, mapSuplierInfo);
		hmAttrib.put(ConstantsUtil.PGINTERNALINFO, mapInternalInfo);

		sp.stop();
		System.out.println("Execution TIME::" + sp.getTime());
		LOGGER.info(" ExecutionTime" + sp.getTime());
		System.out.println("RESULT:: \n" + hmAttrib);
		context.disconnect();


	}

}
*/