/**
 * Project 		: SpecsAnywhere
 * Program 		: APMPBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */
package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class SoftwarePartsBO extends BusinessObject {
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	private static Logger LOGGER = Logger.getLogger(SoftwarePartsBO.class);

	public SoftwarePartsBO() {
		// empty constructor
	}

	public SoftwarePartsBO(String oid) {
		this.setObjectId(oid);
	}
	/**
	 * Method Name 			: getSWPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getSWPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getSWPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */	
	public DomainObject getSWPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	/**
	 * Method Name 			: getSWPPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getSWPSelectables(Context context) {
		StringList busSelect = new StringList(100);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getRelatedSoftwareBuildSelects(context));
		busSelect.addAll(getFileSelects(context));
		// Added by Jwala for Defect 43018  18x.6.0 Release -- START
		busSelect.addAll(getSecuritySelects(context));
		// Added by Jwala for Defect 43018  18x.6.0 Release -- END
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	/**
	 * 
	 * @param context
	 * @return
	 */
	public static StringList getFileSelects(Context context) {

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	// Added by Jwala for Defect 43018  18x.6.0 Release -- START
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	// Added by Jwala for Defect 43018  18x.6.0 Release -- END

	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	: Fetching business object details
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList(70);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSAREA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.STR_TEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);//for specification sub type
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);//for Manufacturing status
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.ATTRIBUTE_REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		busSelect.add(ConstantsUtil.REL_TASK_APPROVER);		
		busSelect.add(ConstantsUtil.COOWNERS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);		
		busSelect.add(ConstantsUtil.SELECT_RELATEDSOFTWAREBUILD_ID);
		busSelect.add(ConstantsUtilIRM.SOFTWARE_PRODUCT_CATEGORY);
		busSelect.add(ConstantsUtilIRM.SOFTWARE_BUSINESS_AREA);

		//SPEC: 24-04-2021: Added for Internal Defect  by Sanjeeva -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		//SPEC: 24-04-2021: Added for Internal Defect  by Sanjeeva -- END
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END

		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- START
		busSelect.add(ConstantsUtil.ATL_STATE);
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- END

		return busSelect;

	}
	/**
	 * Method Name 			: getMarketClearanceResult
	 * Method Description 	: 
	 * @param resultMaps
	 * @return
	 */
	public Map getMarketClearanceResult(Map resultMaps)
	{

		Map<String, String> mapMarketClearanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{

			String strMarketName    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_NAME));
			String strClearanceNum    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_CT_NUM));
			String strOveralClearence    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE));
			String strGPSApproval   =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS));
			String strManuSite    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_MANU_SITE));
			String strPackSite    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_PACK_SITE));
			String strComments    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT));
			String strRestrictions    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_PLANT_REST));
			String strRegExpDate    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REG_DATE));
			String strRegStatus    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REG_STATUS));
			String strMPDTNumber    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM));
			String strPRODRegClass    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS));
			String strRegProductName    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME));

			String strRegrewlleadTime    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALLEADTIME));
			String strRegirewlStatus    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALSTATUS));

			mapMarketClearanceResult.put(ConstantsUtil.MARKET_NAME, strMarketName);
			mapMarketClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, strClearanceNum);
			mapMarketClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, strOveralClearence);
			mapMarketClearanceResult.put(ConstantsUtil.GPS_APPROVAL, strGPSApproval);
			mapMarketClearanceResult.put(ConstantsUtil.MANU_SITE, strManuSite);
			mapMarketClearanceResult.put(ConstantsUtil.PACK_SITE, strPackSite);
			mapMarketClearanceResult.put(ConstantsUtil.COMMENTS, strComments);
			mapMarketClearanceResult.put(ConstantsUtil.RESTRICTIONS, strRestrictions);
			mapMarketClearanceResult.put(ConstantsUtil.REG_EXP_DATE, strRegExpDate);
			mapMarketClearanceResult.put(ConstantsUtil.REG_STATUS, strRegStatus);
			mapMarketClearanceResult.put(ConstantsUtil.MARKETPRODUCTNUMBER, strMPDTNumber);
			mapMarketClearanceResult.put(ConstantsUtil.PROD_REG_CLASS, strPRODRegClass);
			mapMarketClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALLEADTIME, strRegrewlleadTime);
			mapMarketClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALSTATUS, strRegirewlStatus);
			mapMarketClearanceResult.put(ConstantsUtil.REGISTEREDPRODUCTNAME, strRegProductName);

		}catch(Exception e){

			LOGGER.error("Error from SoftwarePartsBO:  getCountryClearanceResult"+e);
			return new HashMap();
		}
		return mapMarketClearanceResult;
	}
	//SPEC: 02-26-2020: Added for 18x.6 DEV by Lingeswari -- END
	/**
	 * Method Name 			: updateSecurity
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> updateSecurity(Map objectMap) {

		Map<String, String> mpSecurity = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			String sName=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME));
			String sLibrary=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME));
			String sCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE));
			String sType=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE));
			String sDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC));
			String Name[]=sName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			String Library[]=sLibrary.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			String Type[]=sType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;

			StringBuilder sbHasAccess = new StringBuilder();

			if(!sType.isEmpty()){

				for (int i = 0; i < Type.length; i++)
				{
					if (UIUtil.isNotNullAndNotEmpty(Type[i])) {
						if ((sType).equalsIgnoreCase(ConstantsUtil.TYPE_SECURITYCONTROLCLASS)) {
							sbHasAccess.append("TRUE");

						}
						else {
							sbHasAccess.append("FALSE");
						}
					}
				}
			} 

			mpSecurity.put(ConstantsUtil.TYPE, sType);
			mpSecurity.put(ConstantsUtil.NAME, sName);
			mpSecurity.put(ConstantsUtil.STATE, sCurrent);
			mpSecurity.put(ConstantsUtil.DESCRIPTION, sDesc);
			mpSecurity.put(ConstantsUtil.HASCLASSACCESS, sbHasAccess.toString());

		}catch(Exception e){
			LOGGER.error("Error from SoftwarePartsBO: updateSecurity"+e);
			return new HashMap();
		}
		return  mpSecurity;
	}


	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching "Plant" related information
	 * @param context
	 * @return
	 */
	private StringList getPlantSelects(Context context) 
	{
		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		return busSelect;
	}
	/**
	 * Method Name 			: updatePlantInfo
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
	public Map updatePlantInfo(Map objectMap) {
		Map<String, String> mpPlant = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			String sPlantName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_NAME));
			String sAuthorize = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE));
			String sProduce = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE));
			String sIsActivated = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED));

			mpPlant.put(ConstantsUtil.PLANTS, sPlantName);
			mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOUSE, sAuthorize);
			mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOPRODUCE, sProduce);
			mpPlant.put(ConstantsUtil.PLANTSISACTIVATED, sIsActivated);

		}catch(Exception e){
			LOGGER.error("Error from SoftwarePartsBO:  updatePlantInfo"+e);
			return new HashMap();
		}

		return  util.filterMapList(mpPlant);
	}
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	: 
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();


		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, getTo, getFrom, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : SoftwarePartsBO Method :updateDerivedDataInfo "+e);
			return new HashMap();
		}
		return mpDerived;
	}

	public StringList addMultiList(){

		StringList slMultiSelects = new StringList();

		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW); 
		slMultiSelects.add(ConstantsUtil.COMP_TYPE); 
		slMultiSelects.add(ConstantsUtil.COMP_NAME);  
		slMultiSelects.add(ConstantsUtil.COMP_ID);  

		slMultiSelects.add(ConstantsUtil.COMP_REVS);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC);
		slMultiSelects.add(ConstantsUtil.COMP_REACHSTATUS);
		slMultiSelects.add(ConstantsUtil.COMP_RPRSTATUS); 
		slMultiSelects.add(ConstantsUtil.COMP_TITLE); 
		slMultiSelects.add(ConstantsUtil.COMP_STATE); 
		slMultiSelects.add(ConstantsUtil.COMP_CASNUM);  		
		slMultiSelects.add(ConstantsUtil.COMP_SUBNAME);  		
		slMultiSelects.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		slMultiSelects.add(ConstantsUtil.COMP_ISCONTAM);  		
		slMultiSelects.add(ConstantsUtil.COMP_QTY);  			
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);  			
		slMultiSelects.add(ConstantsUtil.COMP_METALENVCLASS); 
		slMultiSelects.add(ConstantsUtil.COMP_POSTCONSUMER); 
		slMultiSelects.add(ConstantsUtil.COMP_MANUF);  		
		slMultiSelects.add(ConstantsUtil.COMP_COMENT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MARKETNAME);  	
		slMultiSelects.add(ConstantsUtil.COMP_SEQUENCE);  		
		slMultiSelects.add(ConstantsUtil.COMP_MATELAYER);
		slMultiSelects.add(ConstantsUtil.COMP_POSTINDUSTRIAL);  
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_CURRENT);

		slMultiSelects.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		slMultiSelects.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		slMultiSelects.add(ConstantsUtil.COMP_RELCOMMENT);

		slMultiSelects.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_BUILDPATH);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_STATE);

		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);

		slMultiSelects.add(ConstantsUtil.SELECT_RELATEDSOFTWAREBUILD_ID);
		slMultiSelects.add(ConstantsUtilIRM.SOFTWARE_BUSINESS_AREA);
		slMultiSelects.add(ConstantsUtilIRM.SOFTWARE_PRODUCT_CATEGORY);

		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- START
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- END

		return 	slMultiSelects;	
	}
	public  void removeMultiList(){

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REACHSTATUS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RPRSTATUS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SUBNAME);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QSTCOMPOSITE);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ISCONTAM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_METALENVCLASS); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_POSTCONSUMER); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MANUF);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_COMENT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MARKETNAME);  	
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SEQUENCE);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MATELAYER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_POSTINDUSTRIAL);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CURRENT);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELCOMMENT);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_BUILDPATH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_STATE);		

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);

		//SPEC: 24-03-2021: Added for Defect : 41527  by Chandu -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_RELATEDSOFTWAREBUILD_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SOFTWARE_BUSINESS_AREA);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SOFTWARE_PRODUCT_CATEGORY);
		//SPEC: 24-03-2021: Added for Defect : 41527  by Chandu -- END

	}

	/**
	 * Method Name 			: updatePartSpec
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map updatePartSpec(Context context, Map objectMap) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
					? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

			mpPartSpecs = getPartSpecifications(context, sType, sID);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : SoftwarePartsBO Method :updatePartSpec " + e);
			return new HashMap();

		}
		return util.filterMapList(mpPartSpecs);
	}


	/**
	 * Method Name 			: getPartSpecifications
	 * Method Description 	:
	 * @param context
	 * @param sParentType
	 * @param sObjectID
	 * @return
	 * @throws Exception
	 */
	public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		//StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		//StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		boolean showData = false;

		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;

		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
			sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		}

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
					slPartSpecSelects, null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));

				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));

				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);

				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}

				showData = util.checkHasAccess(context, sUserType, strId);
				if (showData) {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);

					sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
					String strTitle = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
					String strOrig = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
					sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
					//temporary fix to prevent users from downloading a Physical product(VPMReference)
					if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
						sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
					}else {
						sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
					}
				} else {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					//sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					//sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

				}
				//Added by Ganesh stop

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
				mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			}

		} catch (FrameworkException e) {
			LOGGER.error("Exception in SoftwarePartsBO getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}


	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching "Plant" related information
	 * @param context
	 * @return
	 */
	private StringList getRelatedSoftwareBuildSelects(Context context) 
	{
		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_NAME);
		busSelect.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_TYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_STATE);
		busSelect.add(ConstantsUtil.SELECT_REL_RELATEDSOFTWAREBUILD_BUILDPATH);	

		return busSelect;
	}

	/**
	 * Method Name 			: getRelatedSoftwareBuilds
	 * Method Description 	:
	 * @param context
	 * @param sParentType
	 * @param sObjectID
	 * @return
	 * @throws Exception
	 */

	// Modified By Jwala for Internal defect SB-000001. Security Implemented
	@SuppressWarnings({ "deprecation", "unchecked", "rawtypes" })
	public Map getRelatedSoftwareBuilds(Context context ,String strObjectId) throws Exception {

		Map<String,String> mpRelatedSoftwareBulds=new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		MapList relatedPartList = new MapList();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbDescription = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbBuildPath = new StringBuilder();
		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){

				DomainObject doswp =  DomainObject.newInstance(context, strObjectId);

				StringList selectStmts = new StringList();
				selectStmts.addElement(DomainConstants.SELECT_ID);
				selectStmts.addElement(DomainConstants.SELECT_TYPE);
				selectStmts.addElement(DomainConstants.SELECT_NAME);
				selectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_BUILDPATH);
				selectStmts.addElement(DomainConstants.SELECT_REVISION);
				selectStmts.addElement(DomainConstants.SELECT_CURRENT);
				selectStmts.addElement(DomainConstants.SELECT_DESCRIPTION);

				StringList selectRelStmts = new StringList(2);
				selectRelStmts.addElement(DomainConstants.SELECT_RELATIONSHIP_NAME);

				Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_ASSIGNEDPART);
				Pattern typePattern = new Pattern(ConstantsUtil.TYPE_SOFTWAREBUILD);

				relatedPartList = doswp.getRelatedObjects(context,
						relPattern.getPattern(),  //relationship pattern 
						typePattern.getPattern(), // object pattern
						selectStmts,                 // object selects
						selectRelStmts,              // relationship selects
						true,                        // to direction
						false,                       // from direction
						(short)1,                    // recursion level
						null,                        // object where clause
						null,
						0);

				doswp.close(context);

				if(relatedPartList.size() !=0) {
					Iterator objectListItr = relatedPartList.iterator();
					while (objectListItr.hasNext()) {
						Map resultMaps = (Map) objectListItr.next();
						String soid = util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(DomainConstants.SELECT_ID)));
						String sType = util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(DomainConstants.SELECT_TYPE)));
						String sName = validator.getStringEquivalentForStringList(resultMaps.get(DomainConstants.SELECT_NAME));
						String sRev = validator.getStringEquivalentForStringList(resultMaps.get(DomainConstants.SELECT_REVISION));
						String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(DomainConstants.SELECT_CURRENT));
						String sDescription = validator.getStringEquivalentForStringList(resultMaps.get(DomainConstants.SELECT_DESCRIPTION));
						String sBuildPath = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_BUILDPATH));

						if (!sCurrent.equals((ConstantsUtilIRM.STATE_COMPLETE).trim())
								&& (!sCurrent.equalsIgnoreCase((ConstantsUtilIRM.STATE_COMPLETE).trim()))
								&& (!sCurrent.equalsIgnoreCase((ConstantsUtil.STATE_RELEASE).trim()))
								&& (!sCurrent.equalsIgnoreCase((ConstantsUtil.RELEASED).trim()))) {
							continue;
						}
						
						util.formatData(sbType, sType);
						util.formatData(sbName, sName);
						util.formatData(sbRev, sRev);
						util.formatData(sbId, soid);
						util.formatData(sbCurrent, sCurrent);
						util.formatData(sbDescription, sDescription);
						util.formatData(sbBuildPath, sBuildPath);

					}
					mpRelatedSoftwareBulds.put(ConstantsUtil.RELATEDSOFTWAREBUILD_NAME, sbName.toString());
					mpRelatedSoftwareBulds.put(ConstantsUtil.RELATEDSOFTWAREBUILD_TYPE, sbType.toString());
					mpRelatedSoftwareBulds.put(ConstantsUtil.RELATEDSOFTWAREBUILD_DESCRIPTION, sbDescription.toString());
					mpRelatedSoftwareBulds.put(ConstantsUtil.RELATEDSOFTWAREBUILD_STATE, sbCurrent.toString());
					mpRelatedSoftwareBulds.put(ConstantsUtil.RELATEDSOFTWAREBUILD_BUILDPATH, sbBuildPath.toString());
					mpRelatedSoftwareBulds.put(ConstantsUtil.TYPE, sbType.toString());
					mpRelatedSoftwareBulds.put(ConstantsUtil.ID, sbId.toString());
					//mpRelatedSoftwareBulds=	util.verifyOwnership(context,mpRelatedSoftwareBulds);
				}

			}
		}catch(Exception e){
			LOGGER.error("Error from SoftwarePartsBO:  getRelatedSoftwareBuilds"+e);
			return new HashMap();
		}
		return mpRelatedSoftwareBulds;
		
	}

}
