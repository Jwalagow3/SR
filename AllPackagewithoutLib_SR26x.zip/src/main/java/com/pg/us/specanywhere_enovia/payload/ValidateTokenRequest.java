package com.pg.us.specanywhere_enovia.payload;

import com.sun.istack.NotNull;

public class ValidateTokenRequest {
    @NotNull
    private String token;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
   
}