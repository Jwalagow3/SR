/**
 * Project 		: SpecsAnywhere
 * Program 		: ConsumerUnitPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UITableCustom;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.fop.FormulationSubstituteConstants;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class ConsumerUnitPartBO extends BusinessObject  {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(ConsumerUnitPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	private static final String ARROW_SYMBOL         = "<img style=\"padding-left:2px; padding-right:2px;\" src=\"../common/images/iconTreeToArrow.gif\"></img>";
	//Modified for 2018x Upgrade - Stage attribute is replaced by Release Phase attribute in 18x OOTB. 
	 //SJV4: Added for SmartScope :: START
	public static final String ATTRIBUTE_PG_INHERITED_FROM_PLATFORM = PropertyUtil.getSchemaProperty("attribute_pgInheritedFromPlatform");
	public static final String RELATIONSHIP_PGPRODUCTPLATFORMFOP = PropertyUtil.getSchemaProperty("relationship_pgProductPlatformFOP");
	 //SJV4: Added for SmartScope :: END
	public ConsumerUnitPartBO() {
		// empty constructor
	}

	public ConsumerUnitPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name : getCopBO
	 * Method Description : Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getCopBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getCopDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getCopDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getConsumerUnitPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getConsumerUnitPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getStorageTrasportSelectable(context));
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.addAll(getWeightCharSelectables(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getFileSelects(context));
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		busSelect.addAll(getSecuritySelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}


	/**
	 * Method Name 			: getCopRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getCopRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}

	//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
	/**
	 * Method Name 			: getWeightCharSelectables
	 * Method Description 	: Fetching "Weight Characteristics" data
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYPRODUCTWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTORUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);

		return busSelect;
	}
	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching PLANT related details
	 * @param context
	 * @return
	 */
	public static StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		return busSelect;
	}
	
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_BOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		//Added by Pooja for the req 35902,41754 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		//Added by Pooja for the req 35902,41754 -- END
		//Added by Ketan for Req. no. 46464 - START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		//Added by Ketan for Req. no. 46464 - END
		return busSelect;
	}


	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		//Added by Ketan for Req. no. 46464 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC);
		//Added by Ketan for Req. no. 46464 -- END
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
		//Added for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
		//Added by Pooja for the req 35902,41754 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
		//Added by Pooja for the req 35902,41754 -- END
		
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END

		return relSelect;
	}


	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(DomainConstants.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		//busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);

		busSelect.add(ConstantsUtil.STRSEGMENT);

		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);


		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);


		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);

		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		//SPEC: 04-Mar-2020: Added for 18x.6 DEV by Ganesh -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_SETPRODUCTNAME);
		//SPEC: 04-Mar-2020: Added for 18x.6 DEV by Ganesh -- END
		//Modified by Ganesh for Defect 41521 & 41362 on Date <24/mar/2021>--->start
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC);
		//Modified by Ganesh for Defect 41521 & 41362 on Date <24/mar/2021>--->end
		
		// Added by Jwala for Defect #42489 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		// Added by Jwala for Defect #42489 -- END
		//Added by Pooja for the req 35902,41754,33476 -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGINTEGRATEDLIDGLASSBOTTLEONLY);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDESIGNEDFORREUSE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLABELREMOVABILITY);
		//Added by Pooja for the req 35902,41754,33476 -- END
		return busSelect;

	}

	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related information
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getCOPConnectedObjectBusPerformanceSpecs
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getCOPConnectedObjectBusPerformanceSpecs(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION);

		return busSelect;
	}


	/** 
	 * Method Name 			: formatData
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}

	
	/**
	 * Method Name 			: getStorageTrasportSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getStorageTrasportSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_WARE_HOUSE);
		return busSelect;
	}

	
	
	
	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context,MapList mapList) throws Exception 
	{
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		//StringBuilder sbEBOMSubstute= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMTupName= new StringBuilder();
		
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlt = new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDUOM = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END

		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		//Added by Pooja for the req 35902,41754 -- START
		StringBuilder sbGrossWeightReal = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder ();
		StringBuilder sbEBOMpgNSPCG= new StringBuilder();
		//Added by Pooja for the req 35902,41754 -- END
		//Added by Ketan for Req. no. 46464 - START
		StringBuilder sbRelRestriction = new StringBuilder();
		StringBuilder sbRelRestrictionComment = new StringBuilder();
		//Added by Ketan for Req. no. 46464 - END
		try {
		SecurityService sct = new SecurityService();
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
			String sParentId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID)));
			String sParentName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME)));
			String sParentRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV)));
			String sParentType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE)));
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
			String sId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ID)));
			String sName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_NAME)));
			String sRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_REVISION)));
			String sReleaseDate = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			String sRevRelease = "";
			if (validator.isNotNullOrEmpty(sRevision)){
			//String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			String spgChg = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE)));
			String sFN = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER)));
			String sTitle = validator.getStringEquivalentForStringListWithComma((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
			String sType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_TYPE)));
			String sTupName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.TUPNAME)));
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//String sSubstitute = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE)));
			//sSubstitute = util.replaceSpecialSymbols(sSubstitute);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			String sQty = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY)));
			//Added by Pooja for the req 35902,41754 -- START
			String spgNSPCG = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG)));
			String strGrossWeightReal = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
			String strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
			//Added by Pooja for the req 35902,41754 -- END
			//SPEC: Added for SR18x.5.2 Defect #39380 -- START
			sQty = util.getFormatedDecimalValue(sQty,ConstantsUtil.FORMAT_DECIMAL_SIX);
			//SPEC: Added for SR18x.5.2 Defect #39380 -- END
			
			String sBuom = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)));
			// SPEC: Guna Modified for Defect 38083  -- START
			String sComments = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			// SPEC: Guna Modified for Defect 38083  -- START
			String sCurrent = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_CURRENT)));
			String sStage = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)));
			String sRD = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR)));
			sRD = util.replaceSpecialSymbols(sRD);
			String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
			
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			if (validator.isNotNullOrEmpty(strSubPart)){
				strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			if (validator.isNotNullOrEmpty(strSubPartType)){
			strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			
			
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//String strAlt =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
			//strAlt = strAlt.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			if (validator.isNotNullOrEmpty(strAltName)){
			strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			String strAltID = util.checkAlternateHasAccess(context,objectMap);	
			String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			if (validator.isNotNullOrEmpty(strAltType)){
			strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);	
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			
			String strOSPD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_BOM);
			String strDUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			
			//Added by Ketan for Req. no. 46464 - START
			String sRelRestriction = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))? (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
			String sRelRestrictionComment = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))? (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
			//Added by Ketan for Req. no. 46464 - END
			
			boolean showData = false;
			boolean bHasOwnership=false;
			//SPEC: <08-04-2021>: Sanjeeva modified for Stress Testing Defect 44365  -- START
			//String sUserlicense = sct.getUserLicense();
			//SPEC: <08-04-2021>: Sanjeeva modified for Stress Testing Defect 44365  -- END
			String sOC = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT)));
			sOC = util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
			if(util.isModificatinRequired())
			{
				/*SecurityService sec = new SecurityService();
				String sComp = sec.getUserCauthorities();
				StringList slUserOwnership=util.filterOwnerShip(sComp);

				//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
				if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")) {
					String sFormulaPropagate = util.getFormulaPropagate(context, sId);
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}

				}else {
					bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);
					if(bHasOwnership)
						showData=true;
				
				}*/
				//Added by Ganesh 1.0.2 Release Start
				bHasOwnership=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End

				if(!bHasOwnership)
				{
					//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- START
					//sTitle = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					//sFN    = ConstantsUtil.NO_ACCESS;
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
					//sSubstitute = ConstantsUtil.NO_ACCESS;
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
					/*sComments = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sReleaseDate = ConstantsUtil.NO_ACCESS;*/
					sId = ConstantsUtil.NO_ACCESS;
					//sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//strAlt = ConstantsUtil.NO_ACCESS;
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					/*strOSPD = ConstantsUtil.NO_ACCESS;
					strDUOM = ConstantsUtil.NO_ACCESS;*/
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- END

				}
			}else if(sct.isStaffAUGUser()) {

				/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
					String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
					showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
				}else {
					showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
				}*/
				//Added by Ganesh 1.0.2 Release Start
				showData=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End
			} else{

				/*StringList slHIRTypes = new StringList();
				slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
				slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

				if(slHIRTypes.contains(sType)) {
					//SPEC: <10.29.2020>: Added for req 18x.5 ## -- START
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
					}
					//SPEC: <10.29.2020>: Added for req 18x.5 ## -- END
				}else {
					showData=true;
				}*/
				//Added by Ganesh 1.0.2 Release Start
				showData=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End
			}
			
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- START
			if(!util.isModificatinRequired()) {
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- END
				if(!showData){
					spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
					/*sTitle = ConstantsUtil.NO_ACCESS;
				sFN    = ConstantsUtil.NO_ACCESS;
				sSubstitute = ConstantsUtil.NO_ACCESS;
				sComments = ConstantsUtil.NO_ACCESS;
				sStage = ConstantsUtil.NO_ACCESS;
				sRDOC = ConstantsUtil.NO_ACCESS;
				sTupName = ConstantsUtil.NO_ACCESS;
				sReleaseDate = ConstantsUtil.NO_ACCESS;
				sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;*/
				} 
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- START
			}
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- END
			
			//Added by Ketan for Internal Defect -- START
			boolean bHasOwnershipParent = false;
			boolean showDataParent = false;
			if(validator.isNotNullOrEmpty(sParentId)) {
				if(util.isModificatinRequired())
				{
					bHasOwnershipParent = util.checkHasAccess(context, null, sParentId);

					if(!bHasOwnershipParent)
					{
						sParentId = ConstantsUtil.NO_ACCESS;
					}
				}else if(sct.isStaffAUGUser())
				{
					showDataParent = util.checkHasAccess(context, null, sParentId);
				}else
				{	
					showDataParent = util.checkHasAccess(context, null, sParentId);
				}

				if(!util.isModificatinRequired()) {
					if(!showDataParent){
						sParentId = ConstantsUtil.NO_ACCESS;
					}
				}
				
			}
			//Added by Ketan for Internal Defect -- END
			sType = util.mapType(sType);
			sParentType = util.mapType(sParentType);
			//modified by Ganesh for defect 41500 on date <24/Mar/2021> ---->start
			//if(!sType.equals("Formula Card") )
			//modified by Ganesh for defect 41626 on date <25/Mar/2021> ---->start
			if(!sType.equals("Formula Card") && !sType.equals("Formulation Part"))
			sCurrent = util.mapType(sCurrent);
			//modified by Ganesh for defect 41626 on date <25/Mar/2021> ---->end
			//modified by Ganesh for defect 41500 on date <24/Mar/2021> ---->end

			// Security req -33193 HIR Components Attributes to Show
			formatData(sbEBOMType,sType);
			formatData(sbEBOMName,sName);
			formatData(sbEBOMQTY,sQty);
			formatData(sbEBOMBuom,sBuom);
			formatData(sbEBOMState,sCurrent);

			formatData(sbEBOMId,sId);
			formatData(sbEBOMChg,spgChg);
			formatData(sbEBOMFN,sFN);
			formatData(sbEBOMTitle,sTitle);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//formatData(sbEBOMSubstute,sSubstitute);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			formatData(sbEBOMCommnts,sComments);
			formatData(sbEBOMStage,sStage);
			formatData(sbEBOMRDOC,sRDOC);
			formatData(sbEBOMRevRelDt,sRevRelease);
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//formatData(sbEBOMAlt, strAlt);
			util.formatData(sbAltName,strAltName);
			util.formatData(sbAltID,strAltID);
			util.formatData(sbAltType,strAltType);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			
			formatData(sbEBOMOSPD, strOSPD);
			formatData(sbEBOMDUOM, strDUOM);
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			
			
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
			formatData(sbEBOMSubstitutePart, strSubPart);
			formatData(sbEBOMSubPartID, strSubPartId);
			formatData(sbEBOMSubPartType, strSubPartType);
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
			//Added by Pooja for the req 35902,41754 -- START
			formatData(sbEBOMpgNSPCG,spgNSPCG);
			formatData(sbGrossWeightReal, strGrossWeightReal);
			formatData(sbGrossWeightUOM, strGrossWeightUOM);
			//Added by Pooja for the req 35902,41754 -- END
			
			//Added by Ketan for Req. no. 46464 - START
			util.formatData(sbRelRestriction, sRelRestriction);
			util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
			//Added by Ketan for Req. no. 46464 - END
			
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
			formatData(sbEBOMParentId,sParentId);
			formatData(sbEBOMParentName,sParentName);
			formatData(sbEBOMParentRevision,sParentRevision);
			formatData(sbEBOMParentType,sParentType);
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
			
			if(null!=sTupName && !sTupName.isEmpty()) {
				formatData(sbEBOMTupName,sTupName);
			}

		}
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		//mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlt.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDUOM.toString());
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
		//Added by Pooja for the req 35902,41754 -- START
		mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbEBOMpgNSPCG.toString());
	    mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
		//Added by Pooja for the req 35902,41754 -- END
		//Added by Ketan for Req. no. 46464 - START
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
		//Added by Ketan for Req. no. 46464 - END
		} catch (Exception e){
			
			LOGGER.error("Exception in COPBO:parseMaplist. Exception:"+e);
			//e.printStackTrace();
		}		
				
		return mpEBOMResult;
	}
	
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
	/**
	 * Method Name 			: addMultiSelects
	 * Method Description 	: 
	 */
	public StringList addMultiSelects() {
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
		
		return slMultiSelects;
	}
	/**
	 * Method Name 			: removeMultiSelects
	 * Method Description 	: For removing the multiselects from DomainCOnstants
	 */
	public void removeMultiSelects()
	{

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END

	}
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
	
	
	
	
	
	
	
	
	
	
	//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  	public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
  	{
      	StringValidatorUtil validator = new StringValidatorUtil();
  		Map<String,String> mpEBOMResult = new HashMap<String,String>();
      	try {
  			Iterator objectListItr = mapList.iterator();
  			StringBuilder sbEBOMName = new StringBuilder();
  			StringBuilder sbEBOMParentName = new StringBuilder();
  			StringBuilder sbEBOMParentRev = new StringBuilder();
  			StringBuilder sbEBOMParentTitle = new StringBuilder();
  			StringBuilder sbEBOMId = new StringBuilder();
  			StringBuilder sbEBOMParentId = new StringBuilder();
  			StringBuilder sbEBOMRefDoc= new StringBuilder();
  			StringBuilder sbEBOMTitle = new StringBuilder();
  			StringBuilder sbEBOMType = new StringBuilder();
  			StringBuilder sbEBOMQTY = new StringBuilder();
  			StringBuilder sbEBOMBuom = new StringBuilder();
  			StringBuilder sbEBOMCommnts = new StringBuilder();
  			StringBuilder sbEBOMSubType= new StringBuilder();
  			StringBuilder sbEBOMEffectDate= new StringBuilder();
  			StringBuilder sbEBOMUntilDate= new StringBuilder();
  			StringBuilder sbEBOMCobNum= new StringBuilder();
  			StringBuilder sbEBOMChildRev= new StringBuilder();
  			StringBuilder sbEBOMRevRelDt= new StringBuilder();
  			StringBuilder sbEBOMSubFor= new StringBuilder();
  			StringBuilder sbEBOMParentType = new StringBuilder();
  			StringBuilder sbEBOMChg = new StringBuilder();
  			StringBuilder sbEBOMSFSubType= new StringBuilder();
  		    //Added by Ketan for Req. no. 46464 - START
  			StringBuilder sbRelRestriction = new StringBuilder();
  			StringBuilder sbRelRestrictionComment= new StringBuilder();
  			//Added by Ketan for Req. no. 46464 - END
  			
  			
  			SecurityService sct = new SecurityService();
  			String sUserlicense = sct.getUserLicense();
  			while(objectListItr.hasNext())
  			{
  				Map objectMap = (Map) objectListItr.next();
  				boolean showData = false;
  				boolean bHasOwnership=false;
  	
  				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
  				if (!objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
  					continue;
  				}
					
				
  				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
  				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
  				{
  					//String
  					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
  						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
  					//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
  						String sParentType = "";
  						if (objectMap.get(ConstantsUtil.SELECT_TYPE) != null)
  						{
  							sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
  						} else
  						{
  							LOGGER.info("Error in  COP BO: parseSubstitute: sParentType is null.");
  						}
  					//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
  						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
  						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
  						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
  						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
  						//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --START
  						//String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
  						String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
  						//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --END
  						String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE));
  						//Modified for Defect #37282 -- START
  						//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
  						//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap,null,null);
  						
  						//Access was corrected by Chandra but for EBP columns has to be confirmed which can be shown
  						boolean bChildHasAccess = util.checkHasAccess(context,null,sChildId);
  						
  						
  						//Modified for Defect #37282 -- END
  						
  						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- START
  						sReleaseDate =validator.DateFormatter(sReleaseDate);
  						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- END
  					//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
  						String sRevRelease = "";
  						if (validator.isNotNullOrEmpty(sParentRev)){
  						//String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
  							sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
  						}
  						//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
  						
  						
  						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
  						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
  						//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --START	
  						//String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  						String sChildTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  						//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --END
  						String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
  						//SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --START
  						String sSUBType = "";


  						if (null != sChildType && ("Raw Material").equals(sChildType)) 
  						{       
  							sSUBType="Raw";  
  						}
  						else if (null != sChildType && ("pgRawMaterial").equals(sChildType)) 
  						{       
  							sSUBType="Raw";  
  						}
  						else if (null != sChildType && ("pgPackingMaterial").equals(sChildType)) 
  						{
  							sSUBType="Packaging";
  						} 
  						/*else if("Packaging Material Part".equalsIgnoreCase(sChildType)) {
  							sSUBType="Packaging";
  						}*/
  						else 
  						{
  							//Modified for Defect# 37591 -- START
  							//sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
  							sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  							//Modified for Defect# 37591 -- END
  							
  						}
 						
  					     if ("pgFinishedProduct".equals(sChildType))
  						{
  							if("".equals(sSUBType)){
  								sSUBType="Finished Product";
  							}
  							else if("FWIP-Finished Work in Process".equals(sSUBType)) {
  								sSUBType="FWIP-Finished Work in Process";		
  							}
  							else if("Purchased Subassembly".equals(sSUBType)){
  								sSUBType="Purchased Subassembly";
  							}
  							else if("Purchased and/or Produced Subassembly".equals(sSUBType)){
  								sSUBType="Purchased and/or Produced Subassembly";	
  							}				
  						}
  					     
  					     //SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --END	
  					  
  						//SPEC: <11.26.2020>: Modified for Defect :37556 by Madhana ## --START		
  						//String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  						String sQTY = "";
  					//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
  						if (objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY) != null )
  						sQTY = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
  					//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
  				           if (UIUtil.isNullOrEmpty(sQTY))
  				          {
  				        	   sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  				          }
  				           if (sQTY == null)
  				           {
  				        	   sQTY = "";
  				           }
  				        //SPEC: <11.26.2020>: Modified for Defect :37556 by Madhana ## --END
  						String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
  						String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  						String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
  						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  						
  						//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- START
  						//String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  						String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  						//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- END
  						
	  					//SPEC: 11/09/2020: Modified for Defect : 37019 -- START
	  						String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT));
	  						/*String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
	  						sOC = util.replaceSpecialSymbols(sOC);*/
	  					//SPEC: 11/09/2020: Modified for Defect : 37019 -- END
	  					//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	  						String sRDOC = "";
	  						// Jwala Commented for the defect 45769 -- START
	  						//if (validator.isNotNullOrEmpty(sRefDoc)){
	  						//String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
	  							sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
	  						//}
	  						// Jwala Commented for the defect 45769 -- END
	  						//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
  						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
  						
  						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
  						
  					//SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --START
  						//String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
  						
  						
  						String sSFSubType = "";
  					    //Added by Ketan for Req. no. 46464 - START
  						String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
  						String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
  					    //Added by Ketan for Req. no. 46464 - END
		  					
 					    
 					    if (null != sParentType && ("pgPackingMaterial").equals(sParentType)) 
 						 {
 					    	sSFSubType="Packaging";
 					     } 
 					    /*else if("Packaging Material Part".equalsIgnoreCase(sParentType)) {
 					   	sSFSubType="Packaging";
 					    }*/
 							
 					    else {
 					    	sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
 					     }
 					    
 					     if ("pgFinishedProduct".equals(sParentType))
  						{
  							if("".equals(sSFSubType)){
  								sSFSubType="Finished Product";
  							}
  							else if("FWIP-Finished Work in Process".equals(sSFSubType)) {
  								sSFSubType="FWIP-Finished Work in Process";		
  							}
  							else if("Purchased Subassembly".equals(sSFSubType)){
  								sSFSubType="Purchased Subassembly";
  							}
  							else if("Purchased and/or Produced Subassembly".equals(sSFSubType)){
  								sSFSubType="Purchased and/or Produced Subassembly";	
  							}		
  						}
 					     
 					     
 					     
 					  //SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --END
  						if(!bChildHasAccess) {
  							sChildId    = ConstantsUtil.NO_ACCESS;
  						//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
  							sChg = ConstantsUtil.NO_ACCESS;
  						//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
  	 					  //SPEC: <11.27.2020>: Commented for Defect :37591 by Madhana ## --START
  							//sChildTitle = ConstantsUtil.NO_ACCESS;
  	 					  //SPEC: <11.27.2020>: Commented for Defect :37591 by Madhana ## --END

  							//sChildRev = ConstantsUtil.NO_ACCESS;
  						}
  						
  						
  						//Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
  						 showData = util.checkHasAccess(context,null,sParentID);
  						
  						
  						
  						
  						
  			/*			if(util.isModificatinRequired())
  						{
  							SecurityService sec = new SecurityService();
  							String sComp = sec.getUserCauthorities();
  							StringList slUserOwnership=util.filterOwnerShip(sComp);
  							
  							String sFormulaPropagate = sParentID;
  							if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  								sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
  							}
  							
  							if(!sFormulaPropagate.isEmpty()) {
  								bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
  							}
  							
  							if(!bHasOwnership)
  							{
  								sParentType = ConstantsUtil.NO_ACCESS;
  								sParentID = ConstantsUtil.NO_ACCESS;
  								//sChildId    = ConstantsUtil.NO_ACCESS;
  								sParentName = ConstantsUtil.NO_ACCESS;
  								sParentRev = ConstantsUtil.NO_ACCESS;
  								//sParentTitle = ConstantsUtil.NO_ACCESS;
  								sCombinationNum = ConstantsUtil.NO_ACCESS;
  								//sChildTitle = ConstantsUtil.NO_ACCESS;
  								sSUBType = ConstantsUtil.NO_ACCESS;
  								sEffectvityDate = ConstantsUtil.NO_ACCESS;
  								sRevRelease = ConstantsUtil.NO_ACCESS;
  								sUntilDate = ConstantsUtil.NO_ACCESS;
  								sRDOC = ConstantsUtil.NO_ACCESS;
  								sQTY = ConstantsUtil.NO_ACCESS;
  								sBASEUOM = ConstantsUtil.NO_ACCESS;
  								//sChildRev = ConstantsUtil.NO_ACCESS;
  								sChg = ConstantsUtil.NO_ACCESS;
  								sSFSubType = ConstantsUtil.NO_ACCESS;
  								
  						    }
  						}else if(sct.isStaffAUGUser()) {
  							
  							if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  								String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
  								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
  							}else {
  								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
  							}
  						}else {
  							StringList slHIRTypes = new StringList();
  							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
  							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
  							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
  							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
  							slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
  							slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
  							
  							if(slHIRTypes.contains(sParentType)) {
  								if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
  									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
  								}else {
  									showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
  								}
  							}else {
  								showData=true;
  							}
  						}*/
  						
  						if(!showData){
  							sParentID = ConstantsUtil.NO_ACCESS;
  							//sParentTitle = ConstantsUtil.NO_ACCESS;
  							//sBASEUOM = ConstantsUtil.NO_ACCESS;
  							
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
  							//sChildId    = ConstantsUtil.NO_ACCESS;
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
  							
  							/*sParentType = ConstantsUtil.NO_ACCESS;
  							sParentID = ConstantsUtil.NO_ACCESS;
  							sChildId    = ConstantsUtil.NO_ACCESS;
  							//sParentName = ConstantsUtil.NO_ACCESS;
  							//sParentRev = ConstantsUtil.NO_ACCESS;
  							sParentTitle = ConstantsUtil.NO_ACCESS;
  							sCombinationNum = ConstantsUtil.NO_ACCESS;
  							sChildTitle = ConstantsUtil.NO_ACCESS;
  							sSUBType = ConstantsUtil.NO_ACCESS;
  							sEffectvityDate = ConstantsUtil.NO_ACCESS;
  							sRevRelease = ConstantsUtil.NO_ACCESS;
  							sUntilDate = ConstantsUtil.NO_ACCESS;
  							sRDOC = ConstantsUtil.NO_ACCESS;
  							sComments = ConstantsUtil.NO_ACCESS;*/
  						}
  				    	//Modified by Ganesh for defect 41327 <3/23/2021>---->start
  					        if(showData)
  					       {
  					    	sParentType = util.mapType(sParentType.trim());	
  					        }
  					     	sChildType = util.mapType(sChildType.trim());
  						//sParentType = util.mapType(sParentType.trim());
  				     	//Modified by Ganesh for defect 41327 <3/23/2021>---->end
  						util.formatData(sbEBOMName,sChildName);
  						util.formatData(sbEBOMType,sChildType);
  						util.formatData(sbEBOMQTY,sQTY);
  						util.formatData(sbEBOMBuom,sBASEUOM);
  						util.formatData(sbEBOMChildRev,sChildRev);
  						
  						util.formatData(sbEBOMParentType,sParentType);
  						util.formatData(sbEBOMParentId,sParentID);
  						util.formatData(sbEBOMId,sChildId);
  						util.formatData(sbEBOMParentName,sParentName);
  						util.formatData(sbEBOMParentRev,sParentRev);
  						util.formatData(sbEBOMParentTitle,sParentTitle);
  						util.formatData(sbEBOMCobNum,sCombinationNum);
  						util.formatData(sbEBOMTitle,sChildTitle);
  						util.formatData(sbEBOMSubType,sSUBType);
  						util.formatData(sbEBOMRevRelDt,sRevRelease);
  						util.formatData(sbEBOMEffectDate,validator.DateFormatter(sEffectvityDate));
  						util.formatData(sbEBOMUntilDate,validator.DateFormatter(sUntilDate));
  						util.formatData(sbEBOMRefDoc,sRDOC);
  						util.formatData(sbEBOMCommnts,sComments);
  						util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  						
  						//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  						util.formatData(sbEBOMChg,sChg);
  						util.formatData(sbEBOMSFSubType,sSFSubType);
  						//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
  					    //Added by Ketan for Req. no. 46464 - START
  						util.formatData(sbRelRestriction,sRelRestriction);
	  					util.formatData(sbRelRestrictionComment,sRelRestrictionComment);
  					    //Added by Ketan for Req. no. 46464 - END
  					//}
  					}
  				}else {
  					//StringList
  				//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
  					String sParentType = "";
  					if (objectMap.get(ConstantsUtil.SELECT_TYPE) != null)
  					{
  						sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
  					} else {
  						LOGGER.info("Error in  COP BO: parseSubstitute:StringList:sParentType is null.");
  					}
  				//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
  					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
  					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
  					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
  					//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --START
  					String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
  					//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --END
  					//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
  					 //Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
						 showData = util.checkHasAccess(context,null,sParentID);
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
  					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
  						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
  						for(int i =0; i<slChildId.size(); i++) 
  						{
  							String sEachChildId = slChildId.getElement(i);
  							
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
//  							DomainObject doEachChild = new DomainObject(sEachChildId);
//  							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//  							StringList slSelect = new StringList();
//  							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//  							Map mpIpClass = doEachChild.getInfo(context, slSelect);
//  							StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//  							StringsIpClass = doEachChild.getInfo(contexts"to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
//  							DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
  						//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
  							StringList slChildType = new StringList();
  		  					if (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE) != null)
  							//StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
  		  					slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
  		  				//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
  							String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
  							
  							//Added for Defect #37282 -- START
  							String strEachChildType = slChildType.getElement(i);
  							
  							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
  							//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
  							//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap,strEachChildType,sEachChildId);
  							
  							//Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
  							boolean 	bChildHasAccess = util.checkHasAccess(context,null,sEachChildId);
  	  						 
  							//Added for Defect #37282 -- START

  							/*if(util.isModificatinRequired())
  							{
  								SecurityService sec = new SecurityService();
  								String sComp = sec.getUserCauthorities();
  								StringList slUserOwnership=util.filterOwnerShip(sComp);
  								
  								String sFormulaPropagate = sParentID;
  								if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  									sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
  								}
  								
  								if(!sFormulaPropagate.isEmpty()) {
  									bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
  								}
  								
  								if(bHasOwnership)
  								{
  									showData=true;
  							    }
  							}else if(sct.isStaffAUGUser()) {
  								if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
  									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
  								}else {
  									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
  								}
  								
  							}else {
  								StringList slHIRTypes = new StringList();
  								slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
  								slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
  								slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
  								slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
  								slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
  								slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
  								if(slHIRTypes.contains(slChildType.getElement(i))) {
  									if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  										String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
  										showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
  									}else {
  										showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
  									}
  								}else {
  									showData=true;
  								}
  								
  							}*/
  							
  							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END				
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
  							/*if(!showData) {
  								sEachChildId=ConstantsUtil.NO_ACCESS;
  							}*/
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
  							
  							String sChildSubType ="";
  							StringList slReleaseDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE));
  							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
  							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
  							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
  							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  							//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
  						   
  							//Modified for Defect# 37591 -- START
  							//StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
  							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  							//Modified for Defect# 37591 -- END
  							
  							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  							StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
  							StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
  							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  							
  							//SPEC: 11/09/2020: Modified for Defect : 37019 -- START
  							//String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  							StringList slOCs =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT));
  							StringList slRefDoc =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  							//SPEC: 11/09/2020: Modified for Defect : 37019 -- END
  							/*String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
  							sOC = util.replaceSpecialSymbols(sOC);*/
  							
  							String sRDOC = slRefDoc.get(i)+ConstantsUtil.SYMBL_COLON+slOCs.get(i);
  							
  							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
  							//SPEC: 11/07/2020: Modified for Defect : 37019 -- START
  							String sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
  							//SPEC: 11/07/2020: Modified for Defect : 37019-- END
  							
  						    //Added by Ketan for Req. no. 46464 - START
  							StringList slRelRestriction =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR));
  							StringList slRelRestrictionComment =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC));
  							//String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
  	  						//String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
  						    //Added by Ketan for Req. no. 46464 - END
  							
  							String sReleaseDate =validator.DateFormatter(slReleaseDate.get(i));
  		  					String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
  		  					
  							//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  							if(bChildHasAccess) {
  								String sChildType = util.mapType(slChildType.get(i));
  								util.formatData(sbEBOMName,slChildName.get(i));
  								util.formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMId,sEachChildId);
  								util.formatData(sbEBOMTitle,slChildTitle.get(i));
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
  								util.formatData(sbEBOMChg,sChg.get(i));
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
  								//Added by Ketan for Req. no. 46464 - START
  								util.formatData(sbRelRestriction,slRelRestriction.get(i));
  								util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
  								//Added by Ketan for Req. no. 46464 - END
  							}
  							else
  							{
  								String sChildType = util.mapType(slChildType.get(i));
  								util.formatData(sbEBOMName,slChildName.get(i));
  								util.formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
  								/*util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);*/
  								util.formatData(sbEBOMTitle,slChildTitle.get(i));
  								util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
  								//Added by Ketan for Req. no. 46464 - START
  								util.formatData(sbRelRestriction,slRelRestriction.get(i));
  								util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
  								//Added by Ketan for Req. no. 46464 - END
  							}
  							
  							//SPEC: 11/30/2020: Modified by Chandra for Defect : 37607 -- START
								if(null!=slSUBType)
								{
									sChildSubType=slSUBType.get(i);
									String sChildType=slChildType.get(i);
									
			 					     if (null != sChildType && ("Raw Material").equals(sChildType)) 
			 						 {       
			 					    	sChildSubType="Raw";  
			 					     }
			 					     else if (null != sChildType && ("pgRawMaterial").equals(sChildType)) 
									 {       
			 					    	sChildSubType="Raw";  
								     }
			 					     else if (null != sChildType && ("pgPackingMaterial").equals(sChildType)) 
			 						 {
			 					    	sChildSubType="Packaging";
			 					     } 
			 					    /*else if("Packaging Material Part".equalsIgnoreCase(sChildType)) {
			 					    	sChildSubType="Packaging";
			 	 					    }*/
			 					    else {
			 					    	sChildSubType =sChildSubType;
			 					     }
			 					    
			 					     if ("pgFinishedProduct".equals(sChildType))
			  						{
			  							if("".equals(sChildSubType)){
			  							sChildSubType="Finished Product";
			  							}
			  							else if("FWIP-Finished Work in Process".equals(sChildSubType)) {
			  							sChildSubType="FWIP-Finished Work in Process";		
			  							}
			  							else if("Purchased Subassembly".equals(sChildSubType)){
			  							sChildSubType="Purchased Subassembly";
			  							}
			  							else if("Purchased and/or Produced Subassembly".equals(sChildSubType)){
			  							sChildSubType="Purchased and/or Produced Subassembly";	
			  							}				
			  						}
								}
								

  							 if (null != sParentType && ("pgPackingMaterial").equals(sParentType)) 
  								 {
  							    	sSFSubType="Packaging";
  							     } 
  							   /*else if("Packaging Material Part".equalsIgnoreCase(sParentType)) {
  			 					   	sSFSubType="Packaging";
  			 					    }*/
  							   else {
  								 sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
		 					     }
  								
  							  if ("pgFinishedProduct".equals(sParentType))
  								{
  									if("".equals(sSFSubType)){
  										sSFSubType="Finished Product";
  									}
  									else if("FWIP-Finished Work in Process".equals(sSFSubType)) {
  										sSFSubType="FWIP-Finished Work in Process";		
  									}
  									else if("Purchased Subassembly".equals(sSFSubType)){
  										sSFSubType="Purchased Subassembly";
  									}
  									else if("Purchased and/or Produced Subassembly".equals(sSFSubType)){
  										sSFSubType="Purchased and/or Produced Subassembly";	
  									}				
  								}
  								
  							//SPEC: 11/30/2020: Modified by Chandra for Defect : 37607 -- END
  								
  							//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
  							
  							if(showData) {
  								//String sChildType = util.mapType(slChildType.get(i));
  								//formatData(sbEBOMName,slChildName.get(i));
  								//formatData(sbEBOMType,sChildType);
  								if(null!=slQTY) {
  									util.formatData(sbEBOMQTY,slQTY.get(i));
  								}else {
  									util.formatData(sbEBOMQTY,ConstantsUtil.EMPTY_STRING);	
  								}
  								
  								if(null!=slBASEUOM) {
  									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
  								}else {
  									util.formatData(sbEBOMBuom,ConstantsUtil.EMPTY_STRING);	
  								}
  								
  								//formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMParentType,util.mapType(sParentType));
  								util.formatData(sbEBOMParentId,sParentID);
  								//formatData(sbEBOMId,sEachChildId);
  								util.formatData(sbEBOMParentName,sParentName);
  								util.formatData(sbEBOMParentRev,sParentRev);
  								util.formatData(sbEBOMParentTitle,sParentTitle);
  							    if(null!=slCombinationNum) {
  									util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
  								}else {
  									util.formatData(sbEBOMCobNum,ConstantsUtil.EMPTY_STRING);	
  								}
  								
  								util.formatData(sbEBOMSubType,sChildSubType);  
  							
  								util.formatData(sbEBOMRevRelDt,sRevRelease);
  								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
  								util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
  								util.formatData(sbEBOMRefDoc,sRDOC);
  								if(null!=slComments) {
  									util.formatData(sbEBOMCommnts,slComments.get(i));
  								}else {
  									util.formatData(sbEBOMCommnts,ConstantsUtil.EMPTY_STRING);	
  								}
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								
  							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
  							/*	
  								if(null!=sChg) {
  									util.formatData(sbEBOMChg,sChg.get(i));
  								}else {
  									util.formatData(sbEBOMChg,ConstantsUtil.EMPTY_STRING);
  								}
  								*/
  							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
  							//SPEC: 11/07/2020: Modified for Defect : 37019 -- START
  								util.formatData(sbEBOMSFSubType,sSFSubType);
  							//SPEC: 11/07/2020: Modified for Defect : 37019 -- END
  								
  							}else {
  								//String sChildType = util.mapType(slChildType.get(i));
  								//formatData(sbEBOMName,slChildName.get(i));
  								//formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMQTY,slQTY.get(i));
  								
  								//SPEC: Release SR18x.5.2: Amman Added for Defect :37303 ## -- START
  								//util.formatData(sbEBOMBuom,ConstantsUtil.NO_ACCESS);
  								if(null!=slBASEUOM) {
  									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
  								}else {
  									util.formatData(sbEBOMBuom,ConstantsUtil.EMPTY_STRING);	
  								}
  								//SPEC: Release SR18x.5.2: Amman Added for Defect :37303 ## -- END
  								
  								//formatData(sbEBOMChildRev,slChildRev.get(i));
  							   //Modified by Ganesh for defect 41327 <3/23/2021>---->start
  								//util.formatData(sbEBOMParentType,util.mapType(sParentType));
  								util.formatData(sbEBOMParentType,sParentType);
  							  //Modified by Ganesh for defect 41327 <3/23/2021>---->end
  								util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
  								//util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMParentName,sParentName);
  								util.formatData(sbEBOMParentRev,sParentRev);
  								//util.formatData(sbEBOMParentTitle,ConstantsUtil.NO_ACCESS);
  								//util.formatData(sbEBOMCobNum,ConstantsUtil.NO_ACCESS);
  								//formatData(sbEBOMParentTitle,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMParentTitle,sParentTitle);
  								//util.formatData(sbEBOMSubType,ConstantsUtil.NO_ACCESS);
  								//util.formatData(sbEBOMRevRelDt,ConstantsUtil.NO_ACCESS);
  								/*util.formatData(sbEBOMEffectDate,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMUntilDate,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMRefDoc,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMCommnts,ConstantsUtil.NO_ACCESS);*/
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								/*util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMSFSubType,ConstantsUtil.NO_ACCESS);*/
  								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
  								//SPEC: 11/30/2020: Modified by Chandra for Defect : 37607 -- START
  								//util.formatData(sbEBOMSubType,slSUBType.get(i));
  								util.formatData(sbEBOMSubType,sChildSubType);
  								//SPEC: 11/30/2020: Modified by Chandra for Defect : 37607 -- END
  								util.formatData(sbEBOMRevRelDt,sRevRelease);
  								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
  								util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
  								util.formatData(sbEBOMRefDoc,sRDOC);
  								util.formatData(sbEBOMCommnts,slComments.get(i));
  							    //modified by Ganesh for Defect 41501 on date <24/Mar/2021>---->START
  								//util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  							    //modified by Ganesh for Defect 41501 on date <24/Mar/2021>---->END
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
  								//util.formatData(sbEBOMChg,sChg.get(i));
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
  								util.formatData(sbEBOMSFSubType,sSFSubType);
  								
  							}
  						}
  					}
  				}

  			}
  			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
  			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
  			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
  			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
  			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
  			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
  			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
  			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
  			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
  			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
  			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
  			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
  			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
  			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
  			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
  			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
  			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
  			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
  			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
  			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
  		    //Added by Ketan for Req. no. 46464 - START
  			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
  			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
  		    //Added by Ketan for Req. no. 46464 - END
  			
      	}catch(Exception e) {
      		
      		e.printStackTrace();
      		LOGGER.error("Exception In COPBO : parseSubstitute: "+e);
      	}
  		return util.filterMapList(mpEBOMResult);
  	
  	}
 // Guna Added for Defect 37599  18x.5.2 Release -- START
  	 public HashMap getDerivedPathForRow(Context context, MapList mlObjectList,Map mlParamList, HashMap mpFinalList) throws Exception {
  		 System.out.println("getDerivedPathForRow");
     	List returnVector = new Vector();
     	StringValidatorUtil validator =new StringValidatorUtil();
     	//DSM (DS) 2015x.5 ALM 16966 - Suppliers cant see right path of performance characteristic - STARTS
 		boolean isContextPushed = false;
 		//DSM (DS) 2015x.5 ALM 16966 - Suppliers cant see right path of performance characteristic - ENDS
 		StringBuilder sbMasterParts = new StringBuilder();
		StringBuilder sbMasterID = new StringBuilder();
     	try
     	{
     		
     		/*HashMap programMap = (HashMap)JPO.unpackArgs(args);

     		MapList mlObjectList = (MapList)programMap.get("objectList");
     		    		
     		//FSD_ChangeManagement_and_Release_Process sec 1.9.9- START 
     		Map mlParamList = (Map)programMap.get("paramList");*/
 			String strselectedTable = (String)mlParamList.get("selectedTable");
     		String strParentId = (String)mlParamList.get("parentOID");
     		
     		//DSM (DS) 2018x.2 ALM-13483 Path shows Obsolete MPP revision - TO show blank value in "Master Part" in Export - Start
     		String strPGExport = (String)mlParamList.get("isPGExport");
     		boolean isPGExport = false;
     		boolean isExport = false;
     		String strReportFormat = (String)mlParamList.get("reportFormat");
     		 if (strReportFormat != null) {
 	                isExport = true;
 	            }
 			 if (strPGExport != null) {
 				 	isPGExport = true;
 	            }
 			//DSM (DS) 2018x.2 ALM-13483 Path shows Obsolete MPP revision - TO show blank value in "Master Part" in Export - End
     		
 			//Added by DSM(Sogeti)-2015x.1 for PDF Views (Req ID-3985) on 27-May-2016 - Starts
     		String strMasterPDF = (String)mlParamList.get("MasterPDF");
 			//Added by DSM(Sogeti)-2015x.1 for PDF Views (Req ID-3985) on 27-May-2016 - Ends
     		//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - starts
 			String strRowMasterId = DomainConstants.EMPTY_STRING;
 			String strRowMasterName = DomainConstants.EMPTY_STRING;
 			String strRowType = DomainConstants.EMPTY_STRING;
 			DomainObject masterObj = null;
 			String strConnectedPFId = DomainConstants.EMPTY_STRING;
 			String strParentType = DomainConstants.EMPTY_STRING;
 			String derivedPath = DomainConstants.EMPTY_STRING;
 			//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - ends
 			//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - Starts
 			strselectedTable = UITableCustom.getSystemTableName(context,strselectedTable);
 			String strMasterPartId = DomainConstants.EMPTY_STRING;
 			String strMasterPartName = DomainConstants.EMPTY_STRING;
 			boolean bMasterExists = false;
 			//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - ends
 			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- START
 			//MapList partFamilyList = new MapList();
 			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- END
 			//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - STARTS
     		//MapList upperPartFamilyMapList = null;
 			String strSpecInheritanceType = DomainConstants.EMPTY_STRING;
 			String strParentName = DomainConstants.EMPTY_STRING;
 			//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - ENDS
 			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- START
 			//MapList lowerPartFamilyMapList = null;
     		//StringList upperPartFamilyList = null;
     		//StringList lowerPartFamilyListLower = null;
 			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- END
 			String strParentRefType = "";
 			StringList partFamilyisList = new StringList();
 			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- START
 			//DomainObject doPartFamily = null;
 			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- END
     		if(UIUtil.isNotNullAndNotEmpty(strParentId))
     		{
     			
     			DomainObject parentObj = DomainObject.newInstance(context, strParentId);
     			//DSM (DS) 2015x.2 - ALM 9005 - Wrong MCOP found in Master Sepcification -starts
     			StringList slStmtList = new StringList(3);
     			slStmtList.add("attribute["+ FormulationSubstituteConstants.ATTR_REFERENCE_TYPE +"]");
     			slStmtList.add("to["+FormulationSubstituteConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].from[Part Family].id");
     			slStmtList.add(FormulationSubstituteConstants.SELECT_TYPE);
 				//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - STARTS
 				slStmtList.add(FormulationSubstituteConstants.SELECT_NAME);
 				//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - ENDS
 				//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - STARTS
 				slStmtList.add(FormulationSubstituteConstants.SELECT_REVISION);
 				//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - ENDS
 				//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - Starts
 				slStmtList.add("to["+FormulationSubstituteConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].frommid["+FormulationSubstituteConstants.REL_PARTFAMILYREFERENCE+"].torel.to.id");
 				//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - STARTS
 				String selectMasterRevision = "to["+FormulationSubstituteConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].frommid["+FormulationSubstituteConstants.REL_PARTFAMILYREFERENCE+"].torel.to.revision";
 				String selectMasterName = "to["+FormulationSubstituteConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].frommid["+FormulationSubstituteConstants.REL_PARTFAMILYREFERENCE+"].torel.to.name";
 				slStmtList.add(selectMasterName);
 				slStmtList.add(selectMasterRevision);
 				//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - ENDS
 				//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - ends
     			Map parentObjInfo = parentObj.getInfo(context,slStmtList);
     			strParentRefType = (String)parentObjInfo.get("attribute["+ FormulationSubstituteConstants.ATTR_REFERENCE_TYPE +"]");
     			//DSM 2015x.1 below code is to check whether the spec belongs to the same part family heirarchy -starts
     			String partFamilyId = (String)parentObjInfo.get("to["+FormulationSubstituteConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].from[Part Family].id");
     			//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - start
     			 strParentType = (String)parentObjInfo.get(FormulationSubstituteConstants.SELECT_TYPE);
     			//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - ends
 				//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - STARTS
     			//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - STARTS
 				strParentName = validator.strcat((String)parentObjInfo.get(FormulationSubstituteConstants.SELECT_NAME),FormulationSubstituteConstants.BLANK_SPACE,(String)parentObjInfo.get(FormulationSubstituteConstants.SELECT_REVISION));
 				//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - ENDS
 				//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - ENDS
 				//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - Starts
 				strMasterPartId = (String)parentObjInfo.get("to["+FormulationSubstituteConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].frommid["+FormulationSubstituteConstants.REL_PARTFAMILYREFERENCE+"].torel.to.id");
 				//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - STARTS
 				strMasterPartName = (String)parentObjInfo.get(selectMasterName);
 				//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - ENDS
 				if(UIUtil.isNotNullAndNotEmpty(strMasterPartId) && UIUtil.isNotNullAndNotEmpty(strMasterPartName)) {
 					//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - STARTS
 					strMasterPartName = validator.strcat(strMasterPartName,FormulationSubstituteConstants.BLANK_SPACE,(String)parentObjInfo.get(selectMasterRevision));
 					//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - ENDS
 					bMasterExists = true;
 				}
 				//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - ends
 				//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - start
 				//commenting this part of code becasue the referenced connected path was showing wrong in FPP context . so it should follow the same logic which is for  Master page.
     			/*if(UIUtil.isNotNullAndNotEmpty(strParentType) && ${CLASS:pgDSOConstants}.TYPE_PG_FINISHEDPRODUCTPART.equals(strParentType) && "pgVPDAPPDocumentSummary".equals(strselectedTable))
     			{
     				if(mlObjectList != null && !mlObjectList.isEmpty())
     	    		{
     	    			Iterator objListItr = mlObjectList.iterator();
     	    			while (objListItr.hasNext())
     	    			{
     	    				Map objMap = (Map) objListItr.next();
     	    				if(objMap != null && !objMap.isEmpty())
     	    				{
     	    					String derivedPath = (String)objMap.get("derivedPath");
     		    				if(UIUtil.isNotNullAndNotEmpty(derivedPath))
     		    				{
     		    					returnVector.add(derivedPath);
     		    				}
     		    				else
     		    				{
     		    					returnVector.add(DomainConstants.EMPTY_STRING);
     		    				}
     	    				}
     	    			}
     	    		}
     				return returnVector;
     			}
     			*/
 				//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - ends
     			//DSM (DS) 2015x.2 - ALM 9005 - Wrong MCOP found in Master Sepcification -ends
 				//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - start
     			//StringList objectSelects = UTILS.createSelects(SELECT_NAME, SELECT_ID);
     			
     			
     			 
     			if(UIUtil.isNotNullAndNotEmpty(partFamilyId) && !FormulationSubstituteConstants.STR_PG_VPD_PERFORMANCE_CHARACTERISTIC_TABLE.equals(strselectedTable))
        			 {
 				 
        			 //Guna commented
     				partFamilyisList = getPartFamilyListFromHeirarchy(context,partFamilyId);
     				}
     			//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - ends
     			//DSM 2015x.1 below code is to check whether the spec belongs to the same part family heirarchy -ends
 		
     		}
     		if(UIUtil.isNullOrEmpty(strselectedTable))
     		{
     			strselectedTable = (String)mlParamList.get("table");
     		}
     		//FSD_ChangeManagement_and_Release_Process sec 1.9.9- END 
     		if(mlObjectList != null && !mlObjectList.isEmpty())
     		{
     			Iterator objListItr = mlObjectList.iterator();
     			//DSM (DS) 2015x.5 ALM 16966 - Suppliers cant see right path of performance characteristic - STARTS
     			//Guna Commented
 				//ContextUtil.pushContext(context,FormulationSubstituteConstants.PERSON_AGENT,DomainConstants.EMPTY_STRING,DomainConstants.EMPTY_STRING);
 				isContextPushed = true;
 				//DSM (DS) 2015x.5 ALM 16966 - Suppliers cant see right path of performance characteristic - ENDS
     			while (objListItr.hasNext())
     			{
     				Map objMap = (Map) objListItr.next();
     				if(objMap != null && !objMap.isEmpty())
     				{
     					
     					//DSM (DS) 2015x.1 - Added code to check the read access of the objects : Start
     					String objReadAccess = (String)objMap.get("objReadAccess");
     					//FSD_ChangeManagement_and_Release_Process sec 1.9.9- START  
     					//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - Starts
     					//if((UIUtil.isNotNullAndNotEmpty(objReadAccess) && ${CLASS:pgDSOConstants}.RANGE_VALUE_TRUE.equals(objReadAccess)) && ("pgVPDPerformanceCharacteristicTable".equals(strselectedTable) || "APPDocumentSummary".equals(strselectedTable) || "pgVPDAPPDocumentSummary".equals(strselectedTable)))
     					//if((UIUtil.isNotNullAndNotEmpty(objReadAccess) && ${CLASS:pgDSOConstants}.RANGE_VALUE_TRUE.equals(objReadAccess)) && ("pgVPDPerformanceCharacteristicTable".equals(strselectedTable) || "APPDocumentSummary".equals(strselectedTable) || "pgVPDAPPDocumentSummary".equals(strselectedTable) || ${CLASS:pgDSOConstants}.STR_PG_DSO_MASTERPART_DETAILS_TABLE.equals(strselectedTable)))
 						if((UIUtil.isNotNullAndNotEmpty(objReadAccess) && FormulationSubstituteConstants.RANGE_VALUE_TRUE.equals(objReadAccess)) && ("pgVPDPerformanceCharacteristicTable".equals(strselectedTable) || "ENCDocumentSummary".equals(strselectedTable) || "pgVPDAPPDocumentSummary".equals(strselectedTable) || FormulationSubstituteConstants.STR_PG_DSO_MASTERPART_DETAILS_TABLE.equals(strselectedTable)))
 						{
 							
     						//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - ends
     						//DSM (DS) 2015x.1 - Added code to check the read access of the objects : End
     						StringBuffer tempValBuffer = new StringBuffer();
     						String charId = (String)objMap.get("id");
     						String strRelationship = (String)objMap.get("relationship");
     						//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - starts
     						 strRowMasterId = (String)objMap.get("strMasterID");
     						 strRowMasterName = (String)objMap.get("strMasterName");
     						 strRowType = (String)objMap.get("strRowType");
     						 derivedPath = (String)objMap.get("derivedPath");
 							//SJV4: Added for SmartScope :: START
 						    String sInheritedFromPlatform = (String)objMap.get("attribute[" + ATTRIBUTE_PG_INHERITED_FROM_PLATFORM + "]");
 						    String sPRPPath= "";
 						    String sPlatformId ="";
 						    if("TRUE".equalsIgnoreCase(sInheritedFromPlatform))
 						    {
 							    DomainObject parentObj = DomainObject.newInstance(context, strParentId);
 								sPRPPath= parentObj.getInfo(context, "to["+RELATIONSHIP_PGPRODUCTPLATFORMFOP+"].from.name");
 								sPlatformId = parentObj.getInfo(context, "to["+RELATIONSHIP_PGPRODUCTPLATFORMFOP+"].from.id");
 						    }

 							//SJV4: Added for SmartScope :: END	
     						//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - Starts
     						 //if(UIUtil.isNotNullAndNotEmpty(strRowMasterId) && UIUtil.isNotNullAndNotEmpty(strParentType) && ${CLASS:pgDSOConstants}.TYPE_PG_FINISHEDPRODUCTPART.equals(strParentType) && "pgVPDAPPDocumentSummary".equals(strselectedTable))
     						 if(UIUtil.isNotNullAndNotEmpty(strRowMasterId) && UIUtil.isNotNullAndNotEmpty(strParentType) && FormulationSubstituteConstants.TYPE_PG_FINISHEDPRODUCTPART.equals(strParentType) && ("pgVPDAPPDocumentSummary".equals(strselectedTable) || FormulationSubstituteConstants.STR_PG_DSO_MASTERPART_DETAILS_TABLE.equals(strselectedTable)))							 
     						 {
     						 //DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - ends
     						 masterObj = DomainObject.newInstance(context, strRowMasterId);
     						 strConnectedPFId = masterObj.getInfo(context, "to["+FormulationSubstituteConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].from["+ DomainConstants.TYPE_PART_FAMILY +"].id");
	     					 //SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
     						 masterObj.close(context);
	     					 //SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
     						  partFamilyisList = getPartFamilyListFromHeirarchy(context,strConnectedPFId);
     						  
     						 }
     						//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - ends
     						if(UIUtil.isNotNullAndNotEmpty(strRelationship) && strRelationship.equals(FormulationSubstituteConstants.REL_PG_INHERITED_CAD_SPEC))
     						{
     							strRelationship = strRelationship + "," + FormulationSubstituteConstants.RELATIONSHIP_PART_SPECIFICATION;
     						}
     						DomainObject charObj = DomainObject.newInstance(context, charId);
     						
     						String specificationObjId = "";
     						String strRefType = "";
     						String connectedPFid = "";
     						StringList connectedMasterNameList = new StringList();
     						StringList connectedMasteridList = new StringList();
 							//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - STARTS
 							//Modified by DSM(DS) for 2015x.4 ALM 13251 STARTS
     						Map<String, StringList> MasterPFMap = new HashMap<String, StringList>();
 							//Modified by DSM(DS) for 2015x.4 ALM 13251 ENDS
 							StringList connectedMasterPFList = new StringList();
 							//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - Starts
 							strSpecInheritanceType = (String)objMap.get("attribute["+ FormulationSubstituteConstants.ATTR_PG_INHERITANCE_TYPE + "].value");
 							if(UIUtil.isNullOrEmpty(strSpecInheritanceType)) {
 								strSpecInheritanceType = (String)objMap.get("attribute["+ FormulationSubstituteConstants.ATTR_PG_INHERITANCE_TYPE + "]");
 							}
 							//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - start
 							if(UIUtil.isNullOrEmpty(strSpecInheritanceType))
 							{
 								strSpecInheritanceType = (String)objMap.get("strInheritanceType");
 							}
 							//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - ends
 							if(FormulationSubstituteConstants.STR_LOCAL.equalsIgnoreCase(strSpecInheritanceType) && !FormulationSubstituteConstants.STR_PG_VPD_PERFORMANCE_CHARACTERISTIC_TABLE.equals(strselectedTable)) {
 								//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - start
 								//the below check is for the specs which are shown in Master Spec tab for master parts
 								//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - Starts
 								//if(${CLASS:pgDSOConstants}.TYPE_PG_FINISHEDPRODUCTPART.equals(strParentType) && ${CLASS:pgDSOConstants}.STR_PG_VPD_APP_DOCUMENTSUMMARY.equals(strselectedTable) && UIUtil.isNotNullAndNotEmpty(strRowMasterName) && UIUtil.isNotNullAndNotEmpty(strRowMasterId))
 								if(FormulationSubstituteConstants.TYPE_PG_FINISHEDPRODUCTPART.equals(strParentType) && (FormulationSubstituteConstants.STR_PG_VPD_APP_DOCUMENTSUMMARY.equals(strselectedTable) || FormulationSubstituteConstants.STR_PG_DSO_MASTERPART_DETAILS_TABLE.equals(strselectedTable)) && UIUtil.isNotNullAndNotEmpty(strRowMasterName) && UIUtil.isNotNullAndNotEmpty(strRowMasterId))								
 								{
 									//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - ends
 									connectedMasteridList.add(strRowMasterId);
 									connectedMasterNameList.add(strRowMasterName);
 								}
 								//the below check is for the specs which are shown in Master Spec tab for reference parts
 								//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - Starts
 								//else if(${CLASS:pgDSOConstants}.TYPE_PG_FINISHEDPRODUCTPART.equals(strParentType) && ${CLASS:pgDSOConstants}.STR_PG_VPD_APP_DOCUMENTSUMMARY.equals(strselectedTable) && (${CLASS:pgDSOConstants}.TYPE_PG_CUSTOMERUNIT.equals(strRowType) || ${CLASS:pgDSOConstants}.TYPE_PG_INNERPACK.equals(strRowType) || ${CLASS:pgDSOConstants}.TYPE_PG_CONSUMERUNIT.equals(strRowType)))
 								else if(FormulationSubstituteConstants.TYPE_PG_FINISHEDPRODUCTPART.equals(strParentType) && (FormulationSubstituteConstants.STR_PG_VPD_APP_DOCUMENTSUMMARY.equals(strselectedTable) || FormulationSubstituteConstants.STR_PG_DSO_MASTERPART_DETAILS_TABLE.equals(strselectedTable)) && (FormulationSubstituteConstants.TYPE_PG_CUSTOMERUNIT.equals(strRowType) || FormulationSubstituteConstants.TYPE_PG_INNERPACK.equals(strRowType) || FormulationSubstituteConstants.TYPE_PG_CONSUMERUNIT.equals(strRowType)))								
 								{
 									//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - ends
 									returnVector.add(derivedPath);
 									continue;
 								}
 								//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - ends
 								//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - Starts
 								//else if(${CLASS:pgDSOConstants}.STR_PG_VPD_APP_DOCUMENTSUMMARY.equals(strselectedTable) && bMasterExists) {
 								else if((FormulationSubstituteConstants.STR_PG_VPD_APP_DOCUMENTSUMMARY.equals(strselectedTable) || FormulationSubstituteConstants.STR_PG_DSO_MASTERPART_DETAILS_TABLE.equals(strselectedTable)) && bMasterExists) {								
 								//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - Ends
 									connectedMasteridList.add(strMasterPartId);
 									connectedMasterNameList.add(strMasterPartName);
 								} else {
 									connectedMasteridList.add(strParentId);
 									connectedMasterNameList.add(strParentName);
 								}
 							//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - Ends
 							}
 							else if("TRUE".equalsIgnoreCase(sInheritedFromPlatform)) //Add For Smart Scope Start
 							{									
 								connectedMasteridList.add(sPlatformId);
 								connectedMasterNameList.add(sPRPPath);
 								
 							}//Add for Smart Scope End
 							else {
 							//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - ENDS
     						
     							StringList selectStmts = new StringList();
     							selectStmts.add(FormulationSubstituteConstants.SELECT_NAME);
     							//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - STARTS
     							selectStmts.add(FormulationSubstituteConstants.SELECT_REVISION);
     							//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - ENDS
     							selectStmts.add(FormulationSubstituteConstants.SELECT_ID);
     							selectStmts.add("attribute[" + FormulationSubstituteConstants.ATTR_REFERENCE_TYPE + "]");
 								//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - STARTS
 								selectStmts.add("to["+FormulationSubstituteConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].from[Part Family].id");
 								//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - ENDS
     							
     							StringList selectRelStmts = new StringList(1);
     							selectRelStmts.add("attribute["+ FormulationSubstituteConstants.RELATIONSHIP_REFERENCE_DOCUMENT + "]");
     							selectRelStmts.add("attribute["+ FormulationSubstituteConstants.ATTR_PG_INHERITANCE_TYPE + "]");
     							
     							String strInheritanceType  = null;
     							
     							MapList connectedPartList = charObj. getRelatedObjects(context,
     									strRelationship,
     									ConstantsUtil.SYMBL_ASTERISK,
     									selectStmts,
     									selectRelStmts,
     									true,
     									false,
     									(short) 1,
     									"",
     									"",
     									(short)0);
     							//DSM (DS) 2015x.1.2 - ALM 7252 - Add Master part Title to the Performance specs view : Start
     							connectedPartList.sort(FormulationSubstituteConstants.SELECT_NAME, "ascending", "String");
     							//DSM (DS) 2015x.1.2 - ALM 7252 - Add Master part Title to the Performance specs view : End
     							//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
     							charObj.close(context);
     							//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
     							if (connectedPartList != null && connectedPartList.size() > 0)
     							{
     								Iterator mapItr = connectedPartList.iterator();
     								Map map = null;
     							    connectedMasterNameList = new StringList();
     	    						connectedMasteridList = new StringList();
 									//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - STARTS
     	    						
 									connectedMasterPFList = new StringList();
 									//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - ENDS
 									//DSM (DS) 2015x.4 ALM 13268 - Performance issue on Spec and Document tab  6min Load time -starts
     	    						//DomainObject connectedMasterObj = null;
 									//DSM (DS) 2015x.4 ALM 13268 - Performance issue on Spec and Document tab  6min Load time -ends
     								while(mapItr.hasNext())
     								{
     									 map = (Map)mapItr.next();
     									strRefType = (String)map.get("attribute[" + FormulationSubstituteConstants.ATTR_REFERENCE_TYPE + "]");
     									strInheritanceType = (String)map.get("attribute[" + FormulationSubstituteConstants.ATTR_PG_INHERITANCE_TYPE + "]");
     									//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - Starts
     									//if((${CLASS:emxPartFamilyBase}.SYMB_M.equals(strRefType) && "pgVPDAPPDocumentSummary".equals(strselectedTable)) || "pgVPDPerformanceCharacteristicTable".equals(strselectedTable) || 
 										// Modified for 2018x PNGUPGRADE FD02 START
     									
     									if((FormulationSubstituteConstants.SYMB_M.equals(strRefType) && ("pgVPDAPPDocumentSummary".equals(strselectedTable) || FormulationSubstituteConstants.STR_PG_DSO_MASTERPART_DETAILS_TABLE.equals(strselectedTable))) || "pgVPDPerformanceCharacteristicTable".equals(strselectedTable) || 										
     											((((FormulationSubstituteConstants.SYMB_M.equals(strParentRefType) && FormulationSubstituteConstants.SYMB_M.equals(strRefType)) || (ConstantsUtil.SYMB_R.equals(strParentRefType) && ConstantsUtil.SYMB_R.equals(strRefType))) && "ENCDocumentSummary".equals(strselectedTable))))
 										// Modified for 2018x PNGUPGRADE FD02 START
     									{
     										
     										//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - ends
     										if(UIUtil.isNotNullAndNotEmpty(strInheritanceType) && strInheritanceType.equals(FormulationSubstituteConstants.STR_LOCAL))
     										{
     											//System.out.println("inside If"+(String)map.get(SELECT_NAME));
     											connectedMasteridList.add((String)map.get(FormulationSubstituteConstants.SELECT_ID));
     											//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - STARTS
     											connectedMasterNameList.add(validator.strcat((String)map.get(FormulationSubstituteConstants.SELECT_NAME)));
     											//DSM (DS) 2015x.5 ALM 13483 - Path shows Obsolete MPP revision - ENDS
     											//DSM(DS) 2015x.4 Modified for ALM 13423-[PC] PC Table Cannot be Saved Successfully- starts
     											//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - STARTS
     											Object pfObjecIds = map.get("to["+FormulationSubstituteConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].from[Part Family].id");
 												//Modified by DSM(DS) for 2015x.4 ALM 13251 STARTS
 												connectedMasterPFList = new StringList();
 												
     											if(null != pfObjecIds) {
     												if (pfObjecIds instanceof String) { 
     													connectedMasterPFList.add((String)pfObjecIds);
     												} else {    									 			
     													connectedMasterPFList.addAll((StringList)pfObjecIds);
     												}
     											}
     											MasterPFMap.put((String)map.get(FormulationSubstituteConstants.SELECT_ID),connectedMasterPFList);
 												//Modified by DSM(DS) for 2015x.4 ALM 13251 ENDS
 												//connectedMasterPFList.add((String)map.get("to["+RELATIONSHIP_CLASSIFIED_ITEM+"].from[Part Family].id"));
     											//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - ENDS
     											//DSM(DS) 2015x.4 Modified for ALM 13423-[PC] PC Table Cannot be Saved Successfully- ends    										

     										}
     									}
     								}
     								//DSM 2015x.1 below code is to check whether the spec belongs to the same part family heirarchy -starts
     								if(!"pgVPDPerformanceCharacteristicTable".equals(strselectedTable))
     								{
 		    								if(connectedMasteridList.size() > 1)
 		    								{
 		    									StringList masterIDlist = new StringList();
 		    									StringList masterNamelist = new StringList();
 		    									for(int i=0 ; i < connectedMasteridList.size() ; i++)
 		    									{
 		    										//DSM (DS) 2015x.4 ALM 13268 - Performance issue on Spec and Document tab  6min Load time -starts
 		    										//connectedMasterObj = DomainObject.newInstance(context, (String)connectedMasteridList.get(i));
 		    										//DSM (DS) 2015x.4 ALM 13268 - Performance issue on Spec and Document tab  6min Load time -ends
 													//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - STARTS
 													//Modified by DSM(DS) for 2015x.4 ALM 13251 STARTS
 		    										StringList MasterPFList = MasterPFMap.get((String)connectedMasteridList.get(i));
 		    										boolean isSameHier = false;
 		    										if(!MasterPFList.isEmpty()) {
 		    											for(int l=0; l<MasterPFList.size();l++) {
 		    												if(partFamilyisList.contains((String)MasterPFList.get(l)))
 				        									{
 		    													isSameHier=true;
 		    													break;
 				        									}
 		    											}
 		    										}
 													//connectedPFid = connectedMasterObj.getInfo(context,"to["+RELATIONSHIP_CLASSIFIED_ITEM+"].from[Part Family].id");
 													//connectedPFid = (String)connectedMasterPFList.get(i);
 													
 		    										
 		    										
 		    										//if(partFamilyisList.contains(connectedPFid))
 		    										if(isSameHier)
 		        									{
 		        									 masterIDlist.add((String)connectedMasteridList.get(i));
 		        									 masterNamelist.add((String)connectedMasterNameList.get(i));
 		        									}
 													//Modified by DSM(DS) for 2015x.4 ALM 13251 ENDS
 		    										//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - ENDS
 		    									}
 		    									connectedMasteridList = masterIDlist;
 		    									connectedMasterNameList = masterNamelist;
 		    									
 		    									//DSM (DS) 2015x.1.2 - ALM 7252 - Add Master part Title to the Performance specs view : Start
 		    									//connectedMasterNameList = BusinessUtil.toUniqueList(connectedMasterNameList);
 		    									//DSM (DS) 2015x.1.2 - ALM 7252 - Add Master part Title to the Performance specs view : End
 		    								}
     								}
 		    								if(connectedMasterNameList.isEmpty())
 		    								{
 		    									 map = (Map)connectedPartList.get(0);
 		    									 connectedMasteridList.add((String)map.get(FormulationSubstituteConstants.SELECT_ID));
 												connectedMasterNameList.add((String)map.get(FormulationSubstituteConstants.SELECT_NAME));
 		    								}
     								}
     							
     							//DSM 2015x.1 below code is to check whether the spec belongs to the same part family heirarchy -ends
     						//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - STARTS	
 							}
 							//Modified by DSM(DS) for Performance Improvement on Specs & Docs page ALM 13268 - ENDS
     						if(connectedMasterNameList.isEmpty())
     							returnVector.add(DomainConstants.EMPTY_STRING);
     						else{
     							String tempVal = "";
     							String delimiter ="";
     							
     							//DSM (DS) 2018x.2 ALM-13483 Path shows Obsolete MPP revision - TO show blank value in "Master Part" in Export - Start
     							String delimiterExport ="";
     							String delimiterPG ="";
     							//DSM (DS) 2018x.2 ALM-13483 Path shows Obsolete MPP revision - TO show blank value in "Master Part" in Export - End
     							for(int i=0;i < connectedMasterNameList.size() ; i++)
     							{
     								//DSM (DS) 2018x.2 ALM-13483 Path shows Obsolete MPP revision - TO show blank value in "Master Part" in Export - Start
     								if(isPGExport){
     									//DSM (DS) 2018x.2 ALM-13483 Path shows Obsolete MPP revision - TO show blank value in "Master Part" in Export - End
     									if(UIUtil.isNotNullAndNotEmpty(strPGExport) && "true".equalsIgnoreCase(strPGExport)){
 		    							returnVector.add(DomainConstants.EMPTY_STRING);
 									//Added by DSM(Sogeti)-2015x.1 for PDF Views (Req ID-3985) on 27-May-2016 - Starts
 		    						} else if(UIUtil.isNotNullAndNotEmpty(strMasterPDF) && "pdf".equalsIgnoreCase(strMasterPDF)){
 		    							
 											returnVector.add(connectedMasterNameList.get(i));
 									}
 									//Added by DSM(Sogeti)-2015x.1 for PDF Views (Req ID-3985) on 27-May-2016 - Ends
 									else{
 										 tempValBuffer.append(delimiter);
 										sbMasterParts.append(connectedMasterNameList.get(i)).append(ConstantsUtil.SYMBL_PIPE);
 										 sbMasterID.append(connectedMasteridList.get(i)).append(ConstantsUtil.SYMBL_PIPE);
 										// tempVal = tempValBuffer.append("<a href=\"../common/emxTree.jsp?objectId=").append(connectedMasteridList.get(i)).append("\" target=\"popup\">").append(connectedMasterNameList.get(i)).append("</a>").toString();
 		    						}
     								}
 		    						delimiter = " | ";
 		    						
 		    						//DSM (DS) 2018x.2 ALM-13483 Path shows Obsolete MPP revision - TO show blank value in "Master Part" in Export - Start
 		    						if(isExport){
 		    						if(UIUtil.isNotNullAndNotEmpty(strReportFormat) && ("CSV".equalsIgnoreCase(strReportFormat) || "HTML".equalsIgnoreCase(strReportFormat) || "text".equalsIgnoreCase(strReportFormat))){
 		    							returnVector.add(DomainConstants.EMPTY_STRING);
 		    						} else{
 										 tempValBuffer.append(delimiterExport);
 										sbMasterParts.append(connectedMasterNameList.get(i)).append(ConstantsUtil.SYMBL_PIPE);
										 sbMasterID.append(connectedMasteridList.get(i)).append(ConstantsUtil.SYMBL_PIPE);
 			    						// tempVal = tempValBuffer.append("<a href=\"../common/emxTree.jsp?objectId=").append(connectedMasteridList.get(i)).append("\" target=\"popup\">").append(connectedMasterNameList.get(i)).append("</a>").toString();
 		    						}
 		    						}
 		    						delimiterExport = " | ";
 		    						
 		    						if(!isPGExport && !isExport){
 		    							tempValBuffer.append(delimiterPG);
 		    							sbMasterParts.append(connectedMasterNameList.get(i)).append(ConstantsUtil.SYMBL_PIPE);
										 sbMasterID.append(connectedMasteridList.get(i)).append(ConstantsUtil.SYMBL_PIPE);
 			    						//tempVal = tempValBuffer.append("<a href=\"../common/emxTree.jsp?objectId=").append(connectedMasteridList.get(i)).append("\" target=\"popup\">").append(connectedMasterNameList.get(i)).append("</a>").toString();
 		    						}
 		    						delimiterPG = " | ";
 		    						//DSM (DS) 2018x.2 ALM-13483 Path shows Obsolete MPP revision - TO show blank value in "Master Part" in Export - End
     							}
     							returnVector.add(tempVal);
     						}	
     		    		}
     					else
     					{	//DSM (DS) 2015x.1 - Added code to check the read access of the objects : Start
     						if((UIUtil.isNotNullAndNotEmpty(objReadAccess) && FormulationSubstituteConstants.RANGE_VALUE_TRUE.equals(objReadAccess)))
     					{
 	    					//FSD_ChangeManagement_and_Release_Process sec 1.9.9- END  
     						//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - starts
 		    				 derivedPath = (String)objMap.get("derivedPath");
 		    				//DSM(DS) 2015x.4  ALM 14639-Related Spec Not Flowing from Upper Level MCUP to FPP - ends
 		    				// DSO - Null Check for Derived Path -START
 		    				if(UIUtil.isNotNullAndNotEmpty(derivedPath))
 		    				{
 		    					sbMasterParts.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
								 sbMasterID.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
 		    				}
 		    				else
 		    				{
 		    					sbMasterParts.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
								 sbMasterID.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
 		    				}
 		    				// DSO - Null Check for Derived Path -END
     					}
     						//DSM (DS) 2015x.1 - Added code to check the read access of the objects : End
     				}
     			}
     		}
     	}
     	}
     	catch(Exception Ex)
     	{
     		Ex.printStackTrace();
     		throw Ex;
     		
     	}
     	//DSM (DS) 2015x.5 ALM 16966 - Suppliers cant see right path of performance characteristic - STARTS
     	finally
     	{
     		if(isContextPushed)
     		{
     			//Guna commented
     			//ContextUtil.popContext(context);
     		}
     	}
     	mpFinalList.put(ConstantsUtil.MASTERPARTNAME, sbMasterParts.toString());
		mpFinalList.put(ConstantsUtil.MASTERID, sbMasterID.toString());
     	//DSM (DS) 2015x.5 ALM 16966 - Suppliers cant see right path of performance characteristic - ENDS
 		return mpFinalList;
     }
  	public Map<String, String> getMasterSpecs(Context context, String sObjectId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpMasterSpecs = new HashMap<String, String>();
		String sMasterObjectId = ConstantsUtil.EMPTY_STRING;
		//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
		String sMasterObjectName = ConstantsUtil.EMPTY_STRING;
		String sMasterObjectType = ConstantsUtil.EMPTY_STRING;
		//SPEC: 10/09/2020: Modified for 18x.5 DEV -- END
		String sMasterObjectClassfiedItem = ConstantsUtil.EMPTY_STRING;
		try {
			DomainObject domChild = new DomainObject(sObjectId);
			sMasterObjectId = domChild.getInfo(context, ConstantsUtil.STR_MASTER_ID);

			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtil.STR_MASTER_ID);
			slSelects.add(ConstantsUtil.SELECT_MASTERPARTNAME);
			slSelects.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
			slSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			Map mp = domChild.getInfo(context, slSelects);
			
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
			domChild.close(context);
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END

			if (!mp.isEmpty()) {
				sMasterObjectId = validator.getStringEquivalentForStringList(mp.get(ConstantsUtil.STR_MASTER_ID));
				//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
				//SPEC: Modified for Defect#37656 1.0.2 Release - Jwala -- START
				// getEquivalentString() apending the extra pipe "|" with the name
				//sMasterObjectName = validator.getEquivalentString(mp.get(ConstantsUtil.SELECT_MASTERPARTNAME));
				sMasterObjectName = validator.getStringEquivalentForStringList(mp.get(ConstantsUtil.SELECT_MASTERPARTNAME));
				//SPEC: Modified for Defect#37656 1.0.2 Release - Jwala -- END
				sMasterObjectType = validator.getStringEquivalentForStringList(mp.get(ConstantsUtil.SELECT_MASTERPARTTYPE));
				//SPEC: 10/09/2020: Modified for 18x.5 DEV -- END
				sMasterObjectClassfiedItem = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME));
			}

			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			if (UIUtil.isNotNullAndNotEmpty(sMasterObjectId)) {
				mpMasterSpecs = getMasterPartSpecifications(context, sMasterObjectId, sMasterObjectClassfiedItem,sMasterObjectName,sMasterObjectId,sMasterObjectType,sObjectId);
			} else {
				return new HashMap();
			}

		} catch (Exception e) {
			LOGGER.error("Exception in Program : COPBO Method :getMasterSpecs " + e);
			return new HashMap();
		}

		return mpMasterSpecs;

	}
  	
  	public Map<String, String> getMasterPartSpecifications(Context context, String sObjectID,
			String sMasterObjectClassfiedItem,String sMasterObjectName,String sMasterObjectId,String sMasterObjectType, String sObjectId2) throws Exception {
		
  		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		StringBuilder sbMasterParts = new StringBuilder();
		StringBuilder sbMasterID = new StringBuilder();
		StringBuilder sbMasterType = new StringBuilder();
		StringBuilder sbArtworkPrimary = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		StringValidatorUtil validator = new StringValidatorUtil();

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		
		//SPEC: <08-06-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		//String[] aCompany = sUserCompanies.split(",");
		String[] aCompany = util.splitCompanyValues(context,sUserCompanies);
		//SPEC: <08-06-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			//sWhere = "current!=Obsolete";
			//SPEC: <11.05.2021>: Ganesh Added for 33248 Req  Dev 18x.6.0.1   -- START
			sWhere = "current==Release";
			//SPEC: <11.05.2021>: Ganesh Added for 33248 Req  Dev 18x.6.0.1   -- STOP
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		
		StringList slRelSelects = new StringList();
		slRelSelects.addElement(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY);
		MapList mapList;
		try {
			//Modified by Ganesh for defect 40966 <17/mar/2021>---->start
			boolean provideAccess=false;
			if (UIUtil.isNotNullAndNotEmpty(sMasterObjectId)) {
			 provideAccess=util.checkHasAccess(context, sUserType, sMasterObjectId);
			}
			//Modified by Ganesh for defect 40966 <17/mar/2021>---->end
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION + "," + ConstantsUtil.REL_PG_INHERITED_CAD_SPEC,
					ConstantsUtil.SYMBL_ASTERISK, slPartSpecSelects, slRelSelects, false, true, (short) 1, sWhere,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
			Map paramMap =new HashMap<>();
			paramMap.put("selectedTable", "pgVPDAPPDocumentSummary");
			paramMap.put("parentOID", sObjectId2);
			paramMap.put("strInheritanceType", "Referenced");
			paramMap.put("strRefId", ConstantsUtil.EMPTY_STRING);
			paramMap.put("parentRelName", ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION);
			
		MapList newMapList =new MapList();
			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- START
				//StringList slEachOwnership = util.filterOwnerShip(eachOwnership);
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- END

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- START
				//String strSharable = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- END
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- START
				//String strClassFied = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- END
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- START
				/*String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));*/
				//String sIpClass =validator.getStringEquivalentForStringList((mpEachObj.get(ConstantsUtil.STR_IPCLASS)));
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- END
				//SPEC: 11.25.2020: Added for Defect :37572 ## --START
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- START
				/*String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));*/
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- END
				//SPEC: 11.25.2020: Added for Defect :37572 ## --START
				String sArtworkPrimary = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY));

				//SPEC: <11.21.2020>: Chandra Added for Defect :37521 ## --START	
				String strTitle = validator.getStringEquivalentForSubstituteString(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

				if (strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) 
				{
					String strPhysicalProdTitle = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYDESCRIPTION));
					strTitle=strPhysicalProdTitle;

				}

				String strState = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				strState=strState.replace(ConstantsUtil.STR_CAP_RELEASED,ConstantsUtil.RELEASED);


				
				//SPEC: <11.21.2020>: Chandra Added for Defect :37521 ## --END
				String strSource = util.getSource(context, strId);
				String strSubType =util.UpdateSpecSubType(context, strId);

				SecurityService sct = new SecurityService();
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- START
				//String sUserlicense = sct.getUserLicense();
				//SPEC: <08-06-2021>: <Unused declaration> Sanjeeva Modified for Stress Testing Defect 44365  -- END
				boolean showData = false;

				//Added by Ganesh for security implementation Start
				//BusObjectAttribUtil util=new BusObjectAttribUtil();

				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
				String  strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}

				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END	

				showData=util.checkHasAccess(context, sUserType, strId);
				
				//SPEC: <11.05.2021>: Ganesh Added for 33248 Req  Dev 18x.6.0.1   -- START
				if(!showData && util.isModificatinRequired()){
					continue;
				}
				//SPEC: <11.05.2021>: Ganesh Added for 33248 Req  Dev 18x.6.0.1   -- END
				
				// SPEC: Jwala Added for Defect : 42699 -- START
				if(!provideAccess){
					sMasterObjectId=ConstantsUtil.NO_ACCESS;
					sMasterObjectName = ConstantsUtil.NO_ACCESS;
					
				}
				// SPEC: Jwala Added for Defect : 42699 -- END
				//Modified by Ganesh for defect 40966 <17/mar/2021>---->start
				// SPEC: Jwala Commented for Defect : 42699 -- START
				/*if(provideAccess)
				{
					sbMasterID.append(sMasterObjectId).append(ConstantsUtil.SYMBL_PIPE);
				}
				else
				{
					sbMasterID.append(sMasterObjectId).append(ConstantsUtil.NO_ACCESS);
					
				}*/
				// SPEC: Jwala Commented for Defect : 42699 -- END
				// SPEC: Jwala Added for Defect : 42700 -- START
				sbMasterID.append(sMasterObjectId).append(ConstantsUtil.SYMBL_PIPE);
				// SPEC: Jwala Added for Defect : 42700 -- END
				
				//Modified by Ganesh for defect 40966 <17/mar/2021>---->end
				if (showData) {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);

					sbMasterParts.append(sMasterObjectName).append(ConstantsUtil.SYMBL_PIPE);
					//sbMasterID.append(sMasterObjectId).append(ConstantsUtil.SYMBL_PIPE);
					sbMasterType.append(sMasterObjectType).append(ConstantsUtil.SYMBL_PIPE);
					sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);

					sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
					strTitle = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

					sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
					//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
					/*String strState = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
					//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
					//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
					sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
					String strOrig = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
					sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
					
					mpEachObj.put("objReadAccess", "TRUE");
					
				} else {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);

					sbMasterParts.append(sMasterObjectName).append(ConstantsUtil.SYMBL_PIPE);
					//sbMasterID.append(sMasterObjectId).append(ConstantsUtil.SYMBL_PIPE);
					sbMasterType.append(sMasterObjectType).append(ConstantsUtil.SYMBL_PIPE);
					sbArtworkPrimary.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

				}
				//Added by Ganesh for security implementation stop
				newMapList.add(mpEachObj);
			}
			//mpFinalList =getDerivedPathForRow(context, newMapList,paramMap,mpFinalList);
			
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			/*mpFinalList.put(ConstantsUtil.MASTERPARTNAME, sbMasterParts.toString());
			mpFinalList.put(ConstantsUtil.MASTERID, sbMasterID.toString());*/
			
			mpFinalList.put(ConstantsUtil.MASTERPARTTYPE, sbMasterType.toString());
			mpFinalList.put(ConstantsUtil.ARTWORKPRIMARY, sbArtworkPrimary.toString());
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			//Modified by Ganesh for defect 40966 <17/mar/2021>---->start
			mpFinalList.put(ConstantsUtil.MASTERPARTNAME, sbMasterParts.toString());
			mpFinalList.put(ConstantsUtil.MASTERID, sbMasterID.toString());
			//Modified by Ganesh for defect 40966 <17/mar/2021>---->end


		} catch (FrameworkException e) {
			LOGGER.error("Exception in COPBO getMasterPartSpecifications: " + e);
			return new HashMap();
		}
		return util.filterMapList(mpFinalList);
	}
  	 public StringList getPartFamilyListFromHeirarchy(Context context,String partFamilyId) throws Exception
     {
     	StringList partFamilyisList = new StringList();
     //DSM(DS) 2015x.4 - ALM 15191 misleading Master Part path and Title on Master Specification tab of FPP - End
     	if(UIUtil.isNotNullAndNotEmpty(partFamilyId)){
     	DomainObject doPartFamily = DomainObject.newInstance(context, partFamilyId);
     	//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- START
     	//StringList partFamilyList = new StringList();
     	//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- END
 	    	
     	StringList objectSelects = util.createSelects(FormulationSubstituteConstants.SELECT_NAME, FormulationSubstituteConstants.SELECT_ID);
     	Map partFamilyMap = null;
     	try
     	{
     	//this gets all the part families that are in that heirarchy
 		 MapList partFamilyMapList = doPartFamily.getRelatedObjects(context,
 				ConstantsUtil.RELATIONSHIP_SUBCLASS,
 				ConstantsUtil.TYPE_PARTFAMILY,
 				 objectSelects,
 				 null,
 				 true,
 				 false,
 				 (short)0,
 				 null,
 				 null,
 				 0);
 			 
 		//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
 		doPartFamily.close(context);
		//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
 		 if(!partFamilyMapList.isEmpty())
 			 {
 				 Iterator itr=partFamilyMapList.iterator();
 				while(itr.hasNext())
 				{
 					partFamilyMap=(Map)itr.next();
 					partFamilyisList.add((String)partFamilyMap.get(DomainConstants.SELECT_ID));
 				}
 			 }
 	    	}	catch(Exception e)
 	    	{
 	    		throw e;
 	    	}
     	}
 			 return partFamilyisList;
     }
  // Guna Added for Defect 37599  18x.5.2 Release -- END
  	 
  	//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- START
  	/**
 	 * Method Name 			: getCountryClearanceResult
 	 * Method Description 	: 
 	 * @param resultMaps
 	 * @return
 	 */
 	public Map getCountryClearanceResult(Context context, String sContextObjectId)
 	{

 		Map<String, String> mapCountryClearanceResult = new HashMap<String, String>();
 		StringValidatorUtil validator = new StringValidatorUtil();

 		StringBuilder sbMarketName = new StringBuilder();
 		StringBuilder sbClearanceNum = new StringBuilder();
 		StringBuilder sbOveralClearence = new StringBuilder();
 		StringBuilder sbGPSApproval = new StringBuilder();
 		StringBuilder sbManuSite = new StringBuilder();
 		StringBuilder sbPackSite = new StringBuilder();
 		StringBuilder sbComments = new StringBuilder();
 		StringBuilder sbRestrictions = new StringBuilder();
 		StringBuilder sbRegExpDate = new StringBuilder();
 		StringBuilder sbRegStatus = new StringBuilder();
 		StringBuilder sbMPDTNumber = new StringBuilder();
 		StringBuilder sbPRODRegClass = new StringBuilder();
 		StringBuilder sbRegrewlleadTime = new StringBuilder();
 		StringBuilder sbRegirewlStatus = new StringBuilder();
 		StringBuilder sbRegProductName = new StringBuilder();
 		
 		StringBuilder sbMarketAppproverHolder = new StringBuilder();
 		StringBuilder sbLegalEntity = new StringBuilder();
 		StringBuilder sbBusinessChannel = new StringBuilder();
 		StringBuilder sbPackSize = new StringBuilder();
 		StringBuilder sbPackSizeUOM = new StringBuilder();
 		

 		StringList busSelect = new StringList();
 		busSelect.add(ConstantsUtil.SELECT_NAME);

 		StringList relSelect = new StringList();
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALLEADTIME);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME);
        relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETAPPROVERHOLDER);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLEGALENTITY);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZE);
 		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZEUOM);
 		

 		try
 		{

 			MapList mapList;

 			DomainObject doCOP = new DomainObject(sContextObjectId);

 			mapList = doCOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE, ConstantsUtil.SYMBL_ASTERISK,
 					busSelect, relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
 					ConstantsUtil.ZERO_LEVEL);

 			mapList.sort(DomainConstants.SELECT_NAME, "ascending", "String"); 			
 			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
 			doCOP.close(context);
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END

 			for (int i = 0; i < mapList.size(); i++) {
 				Map resultMaps = (Map) mapList.get(i);
 				//SPEC: Release SR18x.6. Modified by Dominic for Defect 40640 on Date 26/03/2021 --START
 				String strMarketName    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_NAME));
 				String strClearanceNum    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER));
 				String strOveralClearence    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS));
 				String strGPSApproval   =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS));
 				String strManuSite    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE));
 				String strPackSite    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE));
 				String strComments    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT));
 				String strRestrictions    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION));
 				//SPEC: Release SR18x.6.0.1 - Modified by Amman on July 05, 2021 for Defect raised by Internal Testing Team -- START
 				//String strRegExpDate    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE));
 				String strRegExpDate    =  validator.DateFormatter(validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE)));
 				//SPEC: Release SR18x.6.0.1 - Modified by Amman on July 05, 2021 for Defect raised by Internal Testing Team -- END
 				String strRegStatus    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS));
 				strRegStatus=strRegStatus.replace(ConstantsUtil.REGISTRATIONRELEASEDAPP, ConstantsUtil.REGISTRATIONAPPROVEDAPP);
 				String strMPDTNumber    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER));
 				String strPRODRegClass    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION));
 				String strRegrewlleadTime    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALLEADTIME));
 				String strRegirewlStatus    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS));
 				String strRegProductName    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME));
                String strMarketAppproverHolder    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETAPPROVERHOLDER));
 				String strLegalEntity    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLEGALENTITY));
 				String strBusinessChannel    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL));
 				String strPackSize    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZE));
 				String strPackSizeUOM    =  validator.getEquivalentStringFromMapValue(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZEUOM));
 				//SPEC: Release SR18x.6. Modified by Dominic for Defect 40640 on Date 26/03/2021 --END
 				//SPEC: Release SR18x.6. Added by Dominic for Defect 41661 on Date 12/04/2021 --START
				int iSize = 0;
				for(int k = 0; k < strClearanceNum.length(); k++) {
				    if(strClearanceNum.charAt(k) == ',') iSize++;
				}
				strClearanceNum    =  strClearanceNum.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strGPSApproval   =  strGPSApproval.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strManuSite    =  strManuSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSite    =  strPackSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strComments    =  strComments.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRestrictions    =  strRestrictions.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				//SPEC: Release SR18x.6.0.1 - Commented by Amman on July 05, 2021 for Defect raised by Internal Testing Team -- START
				//strRegExpDate    =  strRegExpDate.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				//SPEC: Release SR18x.6.0.1 - Commented by Amman on July 05, 2021 for Defect raised by Internal Testing Team -- END
				strRegStatus    =  strRegStatus.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strMPDTNumber    =  strMPDTNumber.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPRODRegClass    =  strPRODRegClass.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegProductName    =  strRegProductName.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegrewlleadTime    =  strRegrewlleadTime.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegirewlStatus    =  strRegirewlStatus.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strMarketAppproverHolder    =  strMarketAppproverHolder.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strLegalEntity    =  strLegalEntity.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strBusinessChannel    =  strBusinessChannel.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSize    =  strPackSize.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSizeUOM    =  strPackSizeUOM.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				for (int j = 0; j <= iSize; j++) {
					formatData(sbMarketName, strMarketName);
					formatData(sbOveralClearence, strOveralClearence);
				}
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41661 on Date 12/04/2021 --END
 				//util.formatData(sbMarketName, strMarketName);
 				util.formatData(sbClearanceNum, strClearanceNum);
 				//util.formatData(sbOveralClearence, strOveralClearence);
 				util.formatData(sbGPSApproval, strGPSApproval);
 				util.formatData(sbManuSite, strManuSite);
 				util.formatData(sbPackSite, strPackSite);
 				util.formatData(sbComments, strComments);
 				util.formatData(sbRestrictions, strRestrictions);
 				util.formatData(sbRegExpDate, strRegExpDate);
 				util.formatData(sbRegStatus, strRegStatus);
 				util.formatData(sbMPDTNumber, strMPDTNumber);
 				util.formatData(sbPRODRegClass, strPRODRegClass);
 				util.formatData(sbRegrewlleadTime, strRegrewlleadTime);
 				util.formatData(sbRegirewlStatus, strRegirewlStatus);
 				util.formatData(sbRegProductName, strRegProductName);
 				util.formatData(sbMarketAppproverHolder, strMarketAppproverHolder);
 				util.formatData(sbLegalEntity, strLegalEntity);
 				util.formatData(sbBusinessChannel, strBusinessChannel);
 				util.formatData(sbPackSize, strPackSize);
 				util.formatData(sbPackSizeUOM, strPackSizeUOM);
 				

 				mapCountryClearanceResult.put(ConstantsUtil.MARKET_NAME, sbMarketName.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, sbClearanceNum.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, sbOveralClearence.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.GPS_APPROVAL, sbGPSApproval.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.MANU_SITE, sbManuSite.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.PACK_SITE, sbPackSite.toString());
 			    mapCountryClearanceResult.put(ConstantsUtil.GPSCOMMENTS, sbComments.toString());
 			    mapCountryClearanceResult.put(ConstantsUtil.RESTRICTIONS, sbRestrictions.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, sbRegExpDate.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, sbRegStatus.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.MARKETPRODUCTNUMBER, sbMPDTNumber.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.PROD_REG_CLASS, sbPRODRegClass.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALLEADTIME, sbRegrewlleadTime.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALSTATUS, sbRegirewlStatus.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.REGISTEREDPRODUCTNAME, sbRegProductName.toString());
                mapCountryClearanceResult.put(ConstantsUtil.MARKETAPPROVALHOLDER, sbMarketAppproverHolder.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.LEGALENTITY, sbLegalEntity.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.BUSINESSCHANNEL, sbBusinessChannel.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.PACKSIZE, sbPackSize.toString());
 				mapCountryClearanceResult.put(ConstantsUtil.PACKSIZEUOM, sbPackSizeUOM.toString());
 				
 			}

 		}catch(Exception e){

 			LOGGER.error("Error from COPBO:  getCountryClearanceResult"+e);
 			return new HashMap();
 		}

 		return mapCountryClearanceResult;
 	}
 	//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- END
 	
 	public Map<String,String> getPackagingCertificationsList(Context context, String strPartId, String sType) throws Exception {
 		Map<String,String> mpCertDetails = new HashMap();
 	    try {
 	     
 	    	MapList mlReturn = new MapList();
 	    	StringValidatorUtil validator = new StringValidatorUtil();
 	    	 String strPackMatCertification = ConstantsUtil.EMPTY_STRING;
 	      if (UIUtil.isNotNullAndNotEmpty(strPartId)) {
 	        DomainObject domPart = DomainObject.newInstance(context, strPartId);
 	        StringList strBusSelList = new StringList(4);
 	        strBusSelList.add(DomainConstants.SELECT_NAME);
 	        strBusSelList.add(DomainConstants.SELECT_TYPE);
 	        strBusSelList.add(DomainConstants.SELECT_POLICY);
 	        strBusSelList.add(ConstantsUtilIRM.SELECT_ATTR_PG_PACKAGING_MATERIAL_CERTIFICATIONS);
 	        StringList slAttributeValueList = domPart.getInfoList(context,ConstantsUtilIRM.SELECT_ATTR_PG_PACKAGING_MATERIAL_CERTIFICATIONS);
 	        Map<String,String> mPartInfo = domPart.getInfo(context, strBusSelList); 
 	        String strType = (String)mPartInfo.get(DomainConstants.SELECT_TYPE);
 	        String strPolicy = (String)mPartInfo.get(DomainConstants.SELECT_POLICY);
 	        String strPartName = (String)mPartInfo.get(DomainConstants.SELECT_NAME);
 	        String strtest = (String)mPartInfo.get(ConstantsUtil.FALSE);
 	        String strone = (String)mPartInfo.get(ConstantsUtil.GEN_NUM_ONE);
 	        strPackMatCertification = validator.getStringEquivalentForSubstituteString(slAttributeValueList);
 	        MapList mlCertification = getRelatedPackagingCertifications(context, domPart, strPartName, strPartId, strtest, strone);
 	        
 	        mlReturn.addAll((Collection)mlCertification);
 	        if (strType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART) || strType.equals(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART) || strType.equals(ConstantsUtil.TYPE_FABRICATEDPART)) {
 	          mlCertification = getEquivalentAndAlternatePartRelatedPackagingCertifications(context, domPart, strPartName, strPartId, strPolicy);
 	          mlReturn.addAll((Collection)mlCertification);
 	        } 
 	        if (strType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART) || strType.equals(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART) || strType.equals(ConstantsUtil.TYPE_FABRICATEDPART)) {
 	          mlCertification = getMCPRelatedPackagingCertifications(context, domPart, strPartName, strPartId);
 	          mlReturn.addAll((Collection)mlCertification);
 	        } 
 	        if (strType.equals(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART) || strType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) || strType.equals(ConstantsUtil.TYPE_FABRICATEDPART)) {
 	          mlCertification = getPAPSubtitutePRelatedPackagingCertifications(context, domPart, strPartName, strPartId);
 	          mlReturn.addAll((Collection)mlCertification);
 	        } 
 	      } 
 	     
 	      mlReturn.sort("Position", "ascending", "Integer");
 	      mlReturn.sort("Source", "ascending", "string");
 	     //SPEC: <22.07.2022>: Guna Added for Req 42583 22x Release  -- START
 	     mlReturn = new MapList(new HashSet((Collection<?>)mlReturn));
 	    //SPEC: <22.07.2022>: Guna Added for Req 42583 22x Release  -- END
 	     mpCertDetails =  parseCertMapList(context,getSupportDocsData(context,mlReturn),sType);
 	    mpCertDetails.put(ConstantsUtilIRM.INTENDEDPACKAGINGMATERIALCERTIFICATION, strPackMatCertification);
 	    } catch (Exception e) {
 	    	LOGGER.error("Error in COPBO: getPackagingCertificationsList : "+e);
 	    	throw e;
 	    } 
  
 	    return mpCertDetails;
 	  }
 	private Map<String,String> parseCertMapList(Context context, MapList supportDocsData, String sType) {
 		Map<String,String> mpCertMap = new HashMap();
 		try {
 			StringValidatorUtil validator = new StringValidatorUtil();
 			StringBuilder sbPartName = new StringBuilder();
 			StringBuilder sbPartID = new StringBuilder();
 			StringBuilder sbSourceName = new StringBuilder();
 			StringBuilder sbSourceID = new StringBuilder();
 			StringBuilder sbPartType = new StringBuilder();
 			StringBuilder sbExpDate = new StringBuilder();
 			StringBuilder sbCertName = new StringBuilder();
 			StringBuilder sbCertComments = new StringBuilder();
 			StringBuilder sbSupportDocs = new StringBuilder();
 			StringBuilder sbSupportDocsID = new StringBuilder();
 			//SPEC: Modified for Req 42584 - Satyam -- START
 			StringBuilder sbSupportDocsType = new StringBuilder();
 			StringBuilder sbSourceType = new StringBuilder();
 			
 			Iterator itrCertMapList = supportDocsData.iterator();
 			Map mpTempMap = new HashMap();
 			while (itrCertMapList.hasNext()){
 				mpTempMap = (Map)itrCertMapList.next();
 				sbPartName.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtilIRM.SOURCE))?mpTempMap.get(ConstantsUtilIRM.SOURCE).toString():ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				sbPartID.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtilIRM.SOURCEID))?mpTempMap.get(ConstantsUtilIRM.SOURCEID).toString():ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				sbSourceName.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtilIRM.PARTNAME))?mpTempMap.get(ConstantsUtilIRM.PARTNAME).toString():ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				//SPEC: <30.08.2022>: Guna Modified for 50460 Defect   Dev 22x    -- START
 				String strCertId = (String)mpTempMap.get(ConstantsUtilIRM.PARTID);
 				 boolean showData =util.checkHasAccess(context, null, strCertId);
    			 if(!showData) {
    				 strCertId =ConstantsUtil.NO_ACCESS;
    			 }
    			 sbSourceID.append(strCertId).append(ConstantsUtil.SYMBL_PIPE);
 				//sbSourceID.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtilIRM.PARTID))?mpTempMap.get(ConstantsUtilIRM.PARTID).toString():ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
    			//SPEC: <30.08.2022>: Guna Modified for 50460 Defect   Dev 22x    -- END
 				sbSourceType.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtilIRM.PARTTYPE))?util.mapType(mpTempMap.get(ConstantsUtilIRM.PARTTYPE).toString()):ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				sbExpDate.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE))?validator.DateFormatter(mpTempMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE).toString()):ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				sbCertName.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtil.NAME))?mpTempMap.get(ConstantsUtil.NAME).toString():ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				sbCertComments.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS))?mpTempMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS).toString():ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				sbSupportDocs.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtilIRM.SUPPORTDOCS))?mpTempMap.get(ConstantsUtilIRM.SUPPORTDOCS).toString():ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				sbSupportDocsID.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtilIRM.SUPPORTDOCSID))?mpTempMap.get(ConstantsUtilIRM.SUPPORTDOCSID).toString():ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				sbSupportDocsType.append(validator.isNotNullOrEmpty((String)mpTempMap.get(ConstantsUtilIRM.SUPPORTDOCSTYPE))?mpTempMap.get(ConstantsUtilIRM.SUPPORTDOCSTYPE).toString():ConstantsUtil.EMPTY_SPACE).append(ConstantsUtil.SYMBL_PIPE);
 				sbPartType.append(util.mapType(sType));
 				sbPartType.append(ConstantsUtil.SYMBL_PIPE);
 			}
 			
 			mpCertMap.put(ConstantsUtilIRM.PARTNAME, sbPartName.toString());
 			mpCertMap.put(ConstantsUtilIRM.PARTID, sbPartID.toString());
 			mpCertMap.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
 			mpCertMap.put(ConstantsUtilIRM.SOURCEID, sbSourceID.toString());
 			mpCertMap.put(ConstantsUtilIRM.PARTTYPE, sbPartType.toString());
 			mpCertMap.put(ConstantsUtil.EXPIRATIONDATE, sbExpDate.toString());
 			mpCertMap.put(ConstantsUtilIRM.CERTIFICATENAME, sbCertName.toString());
 			mpCertMap.put(ConstantsUtilIRM.CERTCOMMENTS, sbCertComments.toString());
 			mpCertMap.put(ConstantsUtilIRM.SUPPORTDOCS, sbSupportDocs.toString());
 			mpCertMap.put(ConstantsUtilIRM.SUPPORTDOCSID, sbSupportDocsID.toString());
 			mpCertMap.put(ConstantsUtilIRM.SUPPORTDOCSTYPE, sbSupportDocsType.toString());
 			mpCertMap.put(ConstantsUtilIRM.SOURCETYPE, sbSourceType.toString());
 			//SPEC: Modified for Req 42584 - Satyam -- END
 			
 		} catch (Exception ex) {
 			LOGGER.error("Exception while Parsing Certificates MapList:"+ex);
 			throw ex;
 		}
		return mpCertMap;
	}

 	public MapList getPAPSubtitutePRelatedPackagingCertifications(Context context, DomainObject domObj, String strSourcePartName, String strSourcePartId) throws Exception {
 	    MapList mlReturn = new MapList();
 	   Map<String,String> mpRelPackCert = new HashMap();
 	    try {
 	      StringList selectStmts = new StringList(5);
 	      selectStmts.addElement(DomainConstants.SELECT_ID);
 	      selectStmts.addElement(DomainConstants.SELECT_NAME);
 	      selectStmts.addElement(DomainConstants.SELECT_TYPE);
 	      selectStmts.addElement(DomainConstants.SELECT_POLICY);
 	      selectStmts.addElement(DomainConstants.SELECT_CURRENT);
 	      
 	      StringList slRelSelects = new StringList(1);
 	      slRelSelects.addElement(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE);
 	      Pattern patternRel = new Pattern(DomainConstants.RELATIONSHIP_EBOM);
 	      Pattern patternType = new Pattern(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART);
 	      patternType.addPattern(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART);
 	      patternType.addPattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
 	      patternType.addPattern(ConstantsUtil.TYPE_FABRICATEDPART);
 	      MapList mlPMPs = domObj.getRelatedObjects(context, patternRel
 	          .getPattern(), patternType
 	          .getPattern(), selectStmts, slRelSelects, false, true, (short)1, null, null, 0);
 	     Iterator itr = mlPMPs.iterator();
 	      MapList mlCertifications = null;
 	      Map<String,String> mPMPInfo = null;
 	      Map<?,?> mSubPMPInfo = null;
 	      String strPMPId = null;
 	      String strType = null;
 	      String strCurrent = null;
 	      String strPolicy = null;
 	      StringList strSubPMPIdsList = new StringList();
 	      StringList strSubstituteTypesList = StringList.create(new String[] { ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART, ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART, ConstantsUtil.TYPE_FABRICATEDPART });
 	      DomainObject domPMP = null;
 	      
 	      while (itr.hasNext()) {
 	        mPMPInfo = (Map<String,String>)itr.next();
 	        strPMPId = (String)mPMPInfo.get(DomainConstants.SELECT_ID);
 	        strCurrent = (String)mPMPInfo.get(DomainConstants.SELECT_CURRENT);
 	       String strSelSubId = (String)mPMPInfo.get(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE);
 	       	//SPEC: Modified for Req 42583 - Satyam -- START
 	        if (UIUtil.isNotNullAndNotEmpty(strPMPId) && (strCurrent.equals(ConstantsUtil.RELEASED)|| strCurrent.equals(ConstantsUtil.STATE_RELEASE))) {
 	        //SPEC: Modified for Req 42583 - Satyam -- END
 	          domPMP = DomainObject.newInstance(context, strPMPId);
 	          strType = (String)mPMPInfo.get(DomainConstants.SELECT_TYPE);
 	          strPolicy = (String)mPMPInfo.get(DomainConstants.SELECT_POLICY);
 	          String strtest = (String)mPMPInfo.get(ConstantsUtil.TRUE);
 	          mlCertifications = getRelatedPackagingCertifications(context, domPMP, strSourcePartName, strSourcePartId, strtest, (String)null);
 	          mlReturn.addAll((Collection)mlCertifications);
 	          if (ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART.equals(strType)) {
 	            mlCertifications = getMCPRelatedPackagingCertifications(context, domPMP, strSourcePartName, strSourcePartId);
 	            mlReturn.addAll((Collection)mlCertifications);
 	          } 
 	          mlCertifications = getEquivalentAndAlternatePartRelatedPackagingCertifications(context, domPMP, strSourcePartName, strSourcePartId, strPolicy);
 	          mlReturn.addAll((Collection)mlCertifications);
 	          System.out.println(mPMPInfo);
 	         System.out.println(strSelSubId);
 	         if(UIUtil.isNotNullAndNotEmpty(strSelSubId)) {
 	          strSubPMPIdsList = getStringList(mPMPInfo, strSelSubId);
 	          
 	         }
 	         if(!strSubPMPIdsList.isEmpty()) {
 	          for (String stOID : strSubPMPIdsList) {
 	           DomainObject domSubPMP = DomainObject.newInstance(context, stOID);
 	            mSubPMPInfo = getSubstitutePartInfo(context, domSubPMP, selectStmts);
 	            strType = (String)mSubPMPInfo.get(DomainConstants.SELECT_TYPE);
 	            strCurrent = (String)mSubPMPInfo.get(DomainConstants.SELECT_CURRENT);
 	            //SPEC: Modified for Req 42583 - Satyam -- START
 	            if (strSubstituteTypesList.contains(strType) && (strCurrent.equals(ConstantsUtil.RELEASED)|| strCurrent.equals(ConstantsUtil.STATE_RELEASE))) {
 	            //SPEC: Modified for Req 42583 - Satyam -- END
 	              mlCertifications = getRelatedPackagingCertifications(context, domSubPMP, strSourcePartName, strSourcePartId, strtest, (String)null);
 	              mlReturn.addAll((Collection)mlCertifications);
 	              mlCertifications = getEquivalentAndAlternatePartRelatedPackagingCertifications(context, domSubPMP, strSourcePartName, strSourcePartId, strPolicy);
 	              mlReturn.addAll((Collection)mlCertifications);
 	            } 
 	          }
 	         }
 	        } 
 	      } 
 	    } catch (Exception e) {
 	      LOGGER.error("Error in COPBO: getPAPSubtitutePRelatedPackagingCertifications " +e);
 	     throw e;
 	    } 
 	    return mlReturn;
 	}
 	public static StringList getStringList(Map paramMap, String paramString) {
 	    StringList stringList = new StringList();
 	    Object object = paramMap.get(paramString);
 	    if (object instanceof StringList) {
 	      stringList = (StringList)object;
 	    } else if (object instanceof String) {
 	      stringList.add(object.toString());
 	    } 
 	    return stringList;
 	  }
 	public MapList getRelatedPackagingCertifications(Context context, DomainObject domObj, String strSourcePartName, String strSourcePartId, String strIsDisableSelection, String strPosition) throws Exception {
 	    MapList mlReturn = new MapList();
 	    try {
 	      StringList selectStmts = new StringList(3);
 	      selectStmts.addElement(DomainConstants.SELECT_ID);
 	      selectStmts.addElement(DomainConstants.SELECT_NAME);
 	      selectStmts.addElement(DomainConstants.SELECT_TYPE);
 	      StringList selectRelStmts = new StringList(4);
 	      selectRelStmts.addElement(ConstantsUtil.SELECT_CONNECTION_ID);
 	      selectRelStmts.addElement(ConstantsUtilIRM.SELECT_CONNECTION_NAME);
 	      selectRelStmts.addElement(DomainObject.getAttributeSelect(DomainConstants.ATTRIBUTE_COMMENTS));
 	      selectRelStmts.addElement(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_EXPIRATION_DATE));
 	      Map mObjInfo = domObj.getInfo(context, selectStmts);
 	      Pattern relPattern = new Pattern(ConstantsUtilIRM.RELATIONSHIP_PG_PLI_PACKAGING_CERTIFICATIONS);
 	      Pattern typePattern = new Pattern(ConstantsUtilIRM.TYPE_PG_PLI_PACKAGING_MATERIAL_CERTIFICATION);
 	      mlReturn = domObj.getRelatedObjects(context, relPattern
 	          .getPattern(), typePattern
 	          .getPattern(), selectStmts, selectRelStmts, false, true, (short)1, null, null, 0);
 	      Map<String, String> mPartInfo = new HashMap<>();
 	      mPartInfo.put(ConstantsUtilIRM.SOURCE, strSourcePartName);
 	      mPartInfo.put(ConstantsUtilIRM.SOURCEID, strSourcePartId);
 	      mPartInfo.put(ConstantsUtilIRM.PARTNAME, (String)mObjInfo.get(DomainConstants.SELECT_NAME));
 	      mPartInfo.put(ConstantsUtilIRM.PARTID, (String)mObjInfo.get(DomainConstants.SELECT_ID));
 	      mPartInfo.put(ConstantsUtilIRM.PARTTYPE, (String)mObjInfo.get(DomainConstants.SELECT_TYPE));
 	     
 	      mPartInfo.put(ConstantsUtilIRM.POSITION, strPosition);
 	      addPartNameRevisionToList(mlReturn, mPartInfo);
 	    } catch (Exception e) {
 	    	LOGGER.error("Error in COPBO: getRelatedPackagingCertifications " +e);
 	    	throw e;
 	    } 
 	    return mlReturn;
 	  }
 	public void addPartNameRevisionToList(MapList mlCertifications, Map<String, String> mPartInfo) throws Exception {
 	    Iterator<?> itr = mlCertifications.iterator();
 	    Map<String, String> mCertificationInfo = null;
 	    String strPosition = mPartInfo.get(ConstantsUtilIRM.POSITION);
 	    String strIsDisableSelection = mPartInfo.get(ConstantsUtilIRM.ISDISABLESELECTION);
 	    while (itr.hasNext()) {
 	      mCertificationInfo = (Map)itr.next();
 	      mCertificationInfo.put(ConstantsUtilIRM.PARTNAME, mPartInfo.get(ConstantsUtilIRM.PARTNAME));
 	      mCertificationInfo.put(ConstantsUtilIRM.SOURCE, mPartInfo.get(ConstantsUtilIRM.SOURCE));
 	      mCertificationInfo.put(ConstantsUtilIRM.SOURCEID, mPartInfo.get(ConstantsUtilIRM.SOURCEID));
 	      mCertificationInfo.put(ConstantsUtilIRM.PARTID, mPartInfo.get(ConstantsUtilIRM.PARTID));
 	      mCertificationInfo.put(ConstantsUtilIRM.PARTTYPE, mPartInfo.get(ConstantsUtilIRM.PARTTYPE));
 	      if (UIUtil.isNotNullAndNotEmpty(strPosition)) {
 	        mCertificationInfo.put(ConstantsUtilIRM.POSITION, strPosition);
 	      } else {
 	    	
 	        mCertificationInfo.put(ConstantsUtilIRM.POSITION, ConstantsUtil.PLANNING_CODE);
 	      } 
 	     
 	    } 
 	  }
 	public MapList getMCPRelatedPackagingCertifications(Context context, DomainObject domObj, String strSourcePartName, String strSourcePartId) throws Exception {
 	    MapList mlReturn = new MapList();
 	    try {
 	      StringList selectStmts = new StringList(3);
 	      selectStmts.addElement(DomainConstants.SELECT_ID);
 	      selectStmts.addElement(DomainConstants.SELECT_NAME);
 	      selectStmts.addElement(DomainConstants.SELECT_TYPE);
 	      selectStmts.addElement(DomainConstants.SELECT_CURRENT);
 	      MapList listMCPs = domObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL, ConstantsUtil.TYPE_INTERNAL_MATERIAL, selectStmts, null, false, true, (short)1, null, null, 0);
 	      Iterator itr = listMCPs.iterator();
 	      MapList mlCertifications = null;
 	      Map<String,String> mMCPInfo = null;
 	      String strMCPId = null;
 	      String strMCPCurrent = null;
 	      DomainObject domMCP = null;
 	      Map<String, String> mPartInfo = null;
 	      while (itr.hasNext()) {
 	        mMCPInfo = (Map<String,String>)itr.next();
 	        strMCPId = (String)mMCPInfo.get((DomainConstants.SELECT_ID));
 	        strMCPCurrent = mMCPInfo.get((DomainConstants.SELECT_CURRENT));
 	        if (UIUtil.isNotNullAndNotEmpty(strMCPId) && (strMCPCurrent.equals(ConstantsUtil.RELEASED)|| strMCPCurrent.equals(ConstantsUtil.STATE_RELEASE) || strMCPCurrent.equals(ConstantsUtil.STATE_APPROVED))) {
 	          domMCP = DomainObject.newInstance(context, strMCPId);
 	          mPartInfo = new HashMap<>();
 	          mPartInfo.put(ConstantsUtilIRM.SOURCE, strSourcePartName);
 	          mPartInfo.put(ConstantsUtilIRM.SOURCEID, strSourcePartId);
 	          mPartInfo.put(ConstantsUtilIRM.PARTNAME, (String)mMCPInfo.get(DomainConstants.SELECT_NAME));
 	          mPartInfo.put(ConstantsUtilIRM.PARTID, strMCPId);
 	          mPartInfo.put(ConstantsUtilIRM.PARTTYPE, (String)mMCPInfo.get(DomainConstants.SELECT_TYPE));
 	          mPartInfo.put(ConstantsUtilIRM.ISDISABLESELECTION, ConstantsUtil.TRUE);
 	         String strtest = (String)mPartInfo.get(ConstantsUtil.FALSE);
 	          mlCertifications = getRelatedPackagingCertifications(context, domMCP, strSourcePartName, strSourcePartId, strtest, (String)null);
 	          addPartNameRevisionToList(mlCertifications, mPartInfo);
 	          mlReturn.addAll((Collection)mlCertifications);
 	        } 
 	      } 
 	    } catch (Exception ex) {
 	      LOGGER.error("Error in COPBO: getMCPRelatedPackagingCertifications " +ex);
 	     throw ex;
 	    } 
 	    return mlReturn;
 	}
 	private MapList getEquivalentAndAlternatePartRelatedPackagingCertifications(Context context, DomainObject domObj, String strSourcePartName, String strSourcePartId, String strPolicy) throws Exception {
 	    MapList mlReturn = new MapList();
 	    try {
 	      StringList selectStmts = new StringList(4);
 	      selectStmts.addElement(DomainConstants.SELECT_ID);
 	      selectStmts.addElement(DomainConstants.SELECT_NAME);
 	      selectStmts.addElement(DomainConstants.SELECT_TYPE);
 	      selectStmts.addElement(DomainConstants.SELECT_CURRENT);
 	      StringList strRelSelList = new StringList(1);
 	      strRelSelList.add(ConstantsUtilIRM.SELECT_CONNECTION_TYPE);
 	      boolean isFrom = true; 
 	      boolean isTo = false;
 	      if (ConstantsUtil.POLICY_MANUFACTURER_EQUIVALENT.equals(strPolicy) || ConstantsUtil.POLICY_SUPPLIEREQUIVALENT.equals(strPolicy)) {
 	        isFrom = false;
 	        isTo = true;
 	      } 
 	      Pattern relationshipPattern = new Pattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
 	      relationshipPattern.addPattern(DomainConstants.RELATIONSHIP_MANUFACTURER_EQUIVALENT);
 	      relationshipPattern.addPattern(DomainConstants.RELATIONSHIP_ALTERNATE);
 	      MapList listMEPsSEPs = domObj.getRelatedObjects(context, relationshipPattern
 	          .getPattern(), DomainConstants.TYPE_PART, selectStmts, strRelSelList, isTo, isFrom, (short)1, null, null, 0);
 	      Iterator<?> itr = listMEPsSEPs.iterator();
 	      MapList mlCertifications = null;
 	      Map<?, ?> mEquivalentInfo = null;
 	      String strPartId = null;
 	      String strRelType = null;
 	      String strCurrent = null;
 	      DomainObject domEqvPart = null;
 	      Map<String, String> mPartInfo = null;
 	      while (itr.hasNext()) {
 	        mEquivalentInfo = (Map<?, ?>)itr.next();
 	        strPartId = (String)mEquivalentInfo.get(DomainConstants.SELECT_ID);
 	        strCurrent = (String)mEquivalentInfo.get(DomainConstants.SELECT_CURRENT);
 	        //SPEC: Modified for Req 42583 - Satyam -- START
 	        if (UIUtil.isNotNullAndNotEmpty(strPartId) && (strCurrent.equals(ConstantsUtil.RELEASED)|| strCurrent.equals(ConstantsUtil.STATE_RELEASE))) {
 	        //SPEC: Modified for Req 42583 - Satyam -- END
 	          strRelType = (String)mEquivalentInfo.get(ConstantsUtilIRM.SELECT_CONNECTION_TYPE);
 	          domEqvPart = DomainObject.newInstance(context, strPartId);
 	          mlCertifications = getRelatedPackagingCertifications(context, domEqvPart, strSourcePartName, strSourcePartId, "false", (String)null);
 	          mPartInfo = new HashMap<>();
 	          mPartInfo.put(ConstantsUtilIRM.SOURCE, strSourcePartName);
 	          mPartInfo.put(ConstantsUtilIRM.SOURCEID, strSourcePartId);
 	          mPartInfo.put(ConstantsUtilIRM.PARTNAME, (String)mEquivalentInfo.get(DomainConstants.SELECT_NAME));
 	          mPartInfo.put(ConstantsUtilIRM.PARTID, strPartId);
 	          mPartInfo.put(ConstantsUtilIRM.PARTTYPE, (String)mEquivalentInfo.get(DomainConstants.SELECT_TYPE));
 	          mPartInfo.put(ConstantsUtilIRM.ISDISABLESELECTION, ConstantsUtil.TRUE);
 	          addPartNameRevisionToList(mlCertifications, mPartInfo);
 	          mlReturn.addAll((Collection)mlCertifications);
 	          if (!DomainConstants.RELATIONSHIP_ALTERNATE.equals(strRelType)) {
 	            mlCertifications = getMCPRelatedPackagingCertifications(context, domEqvPart, strSourcePartName, strSourcePartId);
 	            mlReturn.addAll((Collection)mlCertifications);
 	            mlCertifications = getAlternatePartRelatedPackagingCertifications(context, domEqvPart, strSourcePartName, strSourcePartId);
 	            mlReturn.addAll((Collection)mlCertifications);
 	            continue;
 	          } 
 	          if (DomainConstants.RELATIONSHIP_ALTERNATE.equals(strRelType)) {
 	            mlCertifications = getEquivalentAndAlternatePartRelatedPackagingCertifications(context, domEqvPart, strSourcePartName, strSourcePartId, strPolicy);
 	            mlReturn.addAll((Collection)mlCertifications);
 	          } 
 	        } 
 	      } 
 	    } catch (Exception ex) {
 	    	LOGGER.error("Error in COPBO: getEquivalentAndAlternatePartRelatedPackagingCertifications " +ex);
 	      throw ex;
 	    } 
 	    return mlReturn;
 	  }
 	 private MapList getAlternatePartRelatedPackagingCertifications(Context context, DomainObject domObj, String strSourcePartName, String strSourcePartId) throws Exception {
 	    MapList mlReturn = new MapList();
 	    try {
 	      StringList selectStmts = new StringList(4);
 	      selectStmts.addElement(DomainConstants.SELECT_ID);
 	      selectStmts.addElement(DomainConstants.SELECT_NAME);
 	      selectStmts.addElement(DomainConstants.SELECT_TYPE);
 	      selectStmts.addElement(DomainConstants.SELECT_CURRENT);
 	      StringList strRelSelList = new StringList(1);
 	      strRelSelList.add(ConstantsUtilIRM.SELECT_CONNECTION_TYPE);
 	      Pattern relationshipPattern = new Pattern(DomainConstants.RELATIONSHIP_ALTERNATE);
 	      MapList listAlternates = domObj.getRelatedObjects(context, relationshipPattern
 	          .getPattern(), DomainConstants.TYPE_PART, selectStmts, strRelSelList, false, true, (short)1, null, null, 0);
 	      Iterator<?> itr = listAlternates.iterator();
 	      MapList mlCertifications = null;
 	      Map<?, ?> mEquivalentInfo = null;
 	      String strPartId = null;
 	      String strCurrent = null;
 	      DomainObject domAltPart = null;
 	      Map<String, String> mPartInfo = null;
 	      while (itr.hasNext()) {
 	        mEquivalentInfo = (Map<?, ?>)itr.next();
 	        strPartId = (String)mEquivalentInfo.get(DomainConstants.SELECT_ID);
 	        strCurrent = (String)mEquivalentInfo.get(DomainConstants.SELECT_CURRENT);
 	        //SPEC: Modified for Req 42583 - Satyam -- START
 	        if (UIUtil.isNotNullAndNotEmpty(strPartId) && (strCurrent.equals(ConstantsUtil.RELEASED)|| strCurrent.equals(ConstantsUtil.STATE_RELEASE))) {
 	        //SPEC: Modified for Req 42583 - Satyam -- END
 	          domAltPart = DomainObject.newInstance(context, strPartId);
 	          mlCertifications = getRelatedPackagingCertifications(context, domAltPart, strSourcePartName, strSourcePartId, "false", (String)null);
 	          mPartInfo = new HashMap<>();
 	          mPartInfo.put(ConstantsUtilIRM.SOURCE, strSourcePartName);
	          mPartInfo.put(ConstantsUtilIRM.SOURCEID, strSourcePartId);
	          mPartInfo.put(ConstantsUtilIRM.PARTNAME, (String)mEquivalentInfo.get(DomainConstants.SELECT_NAME));
	          mPartInfo.put(ConstantsUtilIRM.PARTID, strPartId);
	          mPartInfo.put(ConstantsUtilIRM.PARTTYPE, (String)mEquivalentInfo.get(DomainConstants.SELECT_TYPE));
	          mPartInfo.put(ConstantsUtilIRM.ISDISABLESELECTION, ConstantsUtil.TRUE);

 	          addPartNameRevisionToList(mlCertifications, mPartInfo);
 	          mlReturn.addAll((Collection)mlCertifications);
 	        } 
 	      } 
 	    } catch (Exception ex) {
 	    	LOGGER.error("Error in COPBO: getAlternatePartRelatedPackagingCertifications " +ex);
 	      throw ex;
 	    } 
 	    return mlReturn;
 	  }
 	private Map<?, ?> getSubstitutePartInfo(Context context, DomainObject domSub, StringList selectStmts) throws Exception {
 	    return domSub.getInfo(context, selectStmts);
 	  }
 	public MapList getSupportDocsData(Context context, MapList objectList) throws Exception {
 	    
 	    MapList mlResult = new MapList();
 	    try {
 	    
 	    StringList slSupportDocs = new StringList();
 	      Iterator<?> mlObjectListItr = objectList.iterator();
 	      //SPEC: Modified for Req 42584 - Satyam -- START
 	      StringList selectRelStmts = new StringList(6);
 	      selectRelStmts.addElement(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_NAME);
 	      selectRelStmts.addElement(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_ID);
 	      selectRelStmts.addElement(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_IS_LAST);
 	      selectRelStmts.addElement(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_CURRENT);
 	      selectRelStmts.addElement(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_TYPE);
 	      selectRelStmts.addElement(ConstantsUtil.SELECT_CONNECTION_ID);
 	      Map objectMap = null;
 	      Map tmpMap = null;
 	      StringBuilder sbSupportDocName = null;
 	      StringBuilder sbSupportDocID = null;
 	      StringBuilder sbSupportDocType = null;
 	      String strSupportDocName = null;
 	      String strSupportDocId = null;
 	      String strSupportDocType = null;
 	      String strSupportDocIsLast = null;
 	      String strSupportDocCurrent = null;
 	      String strRelID = null;
 	      StringList slSupportDocName = null;
 	      StringList slSupportDocId = null;
 	      StringList slSupportDocType = null;
 	      StringList slSupportDocIsLast = null;
 	      StringList slSupportDocCurrent = null;
 	      Iterator<?> itrSupportDocName = null;
 	      Iterator<?> itrSupportDocId = null;
 	      Iterator<?> itrSupportDocType = null;
 	      Iterator<?> itrSupportDocIsLast = null;
 	      Iterator<?> itrSupportDocCurrent = null;
 	      Iterator<?> itrSupportDocs = null;
 	     StringValidatorUtil validator = new StringValidatorUtil();
 	      boolean hasAccess = false;
 	      String relPkgCert = ConstantsUtilIRM.RELATIONSHIP_PG_PLI_PACKAGING_CERTIFICATIONS;
 	      StringList strRelList = new StringList();
 	      for (int i = 0; i < objectList.size(); i++) {
 	        Map<Object, Object> tempMap = (Map<Object, Object>)objectList.get(i);
 	        String sRelationshipName = (String)tempMap.get(ConstantsUtilIRM.SELECT_CONNECTION_NAME);
 	        if (sRelationshipName.equalsIgnoreCase(relPkgCert))
 	          strRelList.add(tempMap.get(ConstantsUtil.SELECT_CONNECTION_ID).toString()); 
 	      } 
 	      MapList mlSupportDocs = DomainRelationship.getInfo(context, (String[])strRelList.toArray((Object[])new String[strRelList.size()]), selectRelStmts);

 	      itrSupportDocs = mlSupportDocs.iterator();
 	      Map<Object, Object> mRelDocMapping = new HashMap<>();
 	     
 	      while (itrSupportDocs.hasNext()) {
 	        tmpMap = (Map)itrSupportDocs.next();
 	        mRelDocMapping.put(tmpMap.get(ConstantsUtil.SELECT_CONNECTION_ID), tmpMap);
 	      } 
 	      while (mlObjectListItr.hasNext()) {
 	        objectMap = (Map)mlObjectListItr.next();
 	        strRelID = (String)objectMap.get(ConstantsUtil.SELECT_CONNECTION_ID);
 	        String sRelationshipName = (String)objectMap.get(ConstantsUtilIRM.SELECT_CONNECTION_NAME);
 	        if (sRelationshipName.equalsIgnoreCase(relPkgCert)) {
 	          tmpMap = (Map)mRelDocMapping.get(strRelID);
 	          slSupportDocName = validator.getStringListEquivalentForString(tmpMap.get(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_NAME));
 	          slSupportDocId = validator.getStringListEquivalentForString(tmpMap.get(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_ID));
 	          slSupportDocType = validator.getStringListEquivalentForString(tmpMap.get(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_TYPE));
	          slSupportDocIsLast = validator.getStringListEquivalentForString(tmpMap.get(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_IS_LAST));
 	          slSupportDocCurrent = validator.getStringListEquivalentForString(tmpMap.get(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_CURRENT));
 	          sbSupportDocName = new StringBuilder();
 	          sbSupportDocID = new StringBuilder();
 	          sbSupportDocType = new StringBuilder();
 	          slSupportDocs = new StringList();
 	          if (slSupportDocName != null && !slSupportDocName.isEmpty()) {
 	            itrSupportDocName = slSupportDocName.iterator();
 	            itrSupportDocId = slSupportDocId.iterator();
 	            itrSupportDocType = slSupportDocType.iterator();
 	            itrSupportDocIsLast = slSupportDocIsLast.iterator();
 	            itrSupportDocCurrent = slSupportDocCurrent.iterator();
 	            while (itrSupportDocName.hasNext()) {
 	              strSupportDocName = (String)itrSupportDocName.next();
 	              strSupportDocId = (String)itrSupportDocId.next();
 	              strSupportDocType = (String)itrSupportDocType.next(); 
 	              strSupportDocIsLast = (String)itrSupportDocIsLast.next();
 	              strSupportDocCurrent = (String)itrSupportDocCurrent.next();
 	              if (ConstantsUtil.TRUE.equalsIgnoreCase(strSupportDocIsLast) && validator.isNotNullOrEmpty(strSupportDocName) &&
 	            		 (strSupportDocCurrent.equals(ConstantsUtil.STATE_RELEASE) || strSupportDocCurrent.equals(ConstantsUtil.RELEASED))) {
 	                if (sbSupportDocName.length() > 0)
 	                	sbSupportDocName.append(ConstantsUtil.SYMBL_COMMA);
 	               if (sbSupportDocID.length() > 0)
 	                	sbSupportDocID.append(ConstantsUtil.SYMBL_COMMA);
 	               if (sbSupportDocType.length() > 0)
	                	sbSupportDocType.append(ConstantsUtil.SYMBL_COMMA);
 	                hasAccess = false;
 	                try {
 	                	hasAccess = util.checkHasAccess(context, null, strSupportDocId);
 	                } catch (Exception ex) {
 	                	LOGGER.error("Error in COPBO: getSupportDocsData " +ex);
 	                } 
 	                if (hasAccess) {
 	                	sbSupportDocID.append(strSupportDocId);
 	                	sbSupportDocName.append(strSupportDocName);
 	                	sbSupportDocType.append(strSupportDocType);
 	                  continue;
 	                } 
 	               sbSupportDocName.append(strSupportDocName);
 	              } 
 	            } 
 	          } 
 	       
 	          if (sbSupportDocName.length() > 0) {
 	           objectMap.put(ConstantsUtilIRM.SUPPORTDOCS, sbSupportDocName.toString());
 	          objectMap.put(ConstantsUtilIRM.SUPPORTDOCSID, sbSupportDocID.toString());
 	          objectMap.put(ConstantsUtilIRM.SUPPORTDOCSTYPE, sbSupportDocType.toString());
 	 	      mlResult.add(objectMap);
 	            continue;
 	          } 
 	         sbSupportDocName.append(ConstantsUtil.EMPTY_SPACE);
 	         objectMap.put(ConstantsUtilIRM.SUPPORTDOCS, sbSupportDocName.toString());
 	        objectMap.put(ConstantsUtilIRM.SUPPORTDOCSID, sbSupportDocID.toString());
 	        objectMap.put(ConstantsUtilIRM.SUPPORTDOCSTYPE, sbSupportDocType.toString());
 	 	      mlResult.add(objectMap);
 	          continue;
 	        } 
 	        if (objectMap.containsKey(ConstantsUtilIRM.HASDOC)) {
 	          if (((Boolean)objectMap.get(ConstantsUtilIRM.HASDOC)).booleanValue()) {
 	        	 sbSupportDocName.append(objectMap.get(ConstantsUtilIRM.DOCNAME).toString());
 	           objectMap.put(ConstantsUtilIRM.SUPPORTDOCS, sbSupportDocName.toString());
 	          objectMap.put(ConstantsUtilIRM.SUPPORTDOCSID, sbSupportDocID.toString());
 	          objectMap.put(ConstantsUtilIRM.SUPPORTDOCSTYPE, sbSupportDocType.toString());
 	 	      mlResult.add(objectMap);
 	            continue;
 	          } 
 	         sbSupportDocName.append(ConstantsUtil.EMPTY_SPACE);
 	         objectMap.put(ConstantsUtilIRM.SUPPORTDOCS, sbSupportDocName.toString());
 	        objectMap.put(ConstantsUtilIRM.SUPPORTDOCSID, sbSupportDocID.toString());
 	        objectMap.put(ConstantsUtilIRM.SUPPORTDOCSTYPE, sbSupportDocType.toString()); 
 	 	      mlResult.add(objectMap);
 	          continue;
 	        } 
 	       sbSupportDocName.append(ConstantsUtil.EMPTY_SPACE);
 	        objectMap.put(ConstantsUtilIRM.SUPPORTDOCS, "");
 	       objectMap.put(ConstantsUtilIRM.SUPPORTDOCSID, "");
 	       objectMap.put(ConstantsUtilIRM.SUPPORTDOCSTYPE, ""); 
	 	    mlResult.add(objectMap);
 	       
 	      } 
 	   //SPEC: Modified for Req 42584 - Satyam -- END
 	    } catch (Exception e) {
 	    	LOGGER.error("Error in COPBO: hasAccess" +e);
 	      throw e;
 	    } 
 	    return mlResult;
 	  }
 	
 	  
 	  
}
