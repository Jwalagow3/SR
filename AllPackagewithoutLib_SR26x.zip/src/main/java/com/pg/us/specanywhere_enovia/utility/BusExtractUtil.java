package com.pg.us.specanywhere_enovia.utility;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.io.InputStream;
import java.util.StringTokenizer;

import jakarta.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.framework.ui.UIUtil;

import com.pg.us.specanywhere_enovia.bo.SearchBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;

import jakarta.xml.soap.MessageFactory;
import jakarta.xml.soap.SOAPConnection;
import jakarta.xml.soap.SOAPConnectionFactory;
import jakarta.xml.soap.SOAPMessage;
import jakarta.xml.soap.SOAPPart;

import matrix.db.Context;
import matrix.db.MQLCommand;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class BusExtractUtil {

	private static Logger LOGGER = Logger.getLogger(BusExtractUtil.class);
	private  Environment environmnt;
	
    
	public void BusSearchUtil() {
		// empty constructor
	}

	public static void main(String args[]) throws Exception {

		EnoviaConnectionPool pool = new EnoviaConnectionPool();
		Context context = pool.checkOut();
		StringList objSelects = BusObjectAttribUtil.getBasicInfoBusSelectable(context);
		StringBuffer sbTypes = new StringBuffer();
		sbTypes.append("'");
		sbTypes.append("Finished Product Part").append(",");
		sbTypes.append("Consumer Unit Part").append(",");
		sbTypes.append("Customer Unit Part").append(",");
		sbTypes.append("Packaging Material Part").append(",");
		sbTypes.append("Inner Pack").append(",");
		sbTypes.append("Raw Material Part").append(",");
		sbTypes.append("Formulation Part");
		sbTypes.append("'");

		StringBuffer sbWhere = new StringBuffer();
		sbWhere.append("'");
		sbWhere.append("modified>").append("11/29/2019");
		sbWhere.append(" && ");
		sbWhere.append("current==").append("Release");
		sbWhere.append("'");

		MapList mlSearch = DomainObject.findObjects(context, sbTypes.toString(), "*", "*", "*",
				ConstantsUtil.VAULT_ESERVICEPRODUCTION, sbWhere.toString(), false, objSelects);
		pool.checkIn(context);
		context.close();//Added for Defect 45181
		int i;
		StringValidatorUtil validator = new StringValidatorUtil();
		List<SearchBO> lsearchObs = new ArrayList();
		for (i = 0; i < mlSearch.size(); i++) {
			SearchBO searchObj = new SearchBO();
			Map mp = (Map) mlSearch.get(i);
			searchObj.setName((validator.isNotNullOrEmpty((String) mp.get(ConstantsUtil.SELECT_NAME)))
					? (String) mp.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			searchObj.setCreationDate(validator.isNotNullOrEmpty((String) mp.get(ConstantsUtil.SELECT_ORIGINATED))
					? (String) mp.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			searchObj.setDescription(validator.isNotNullOrEmpty((String) mp.get(ConstantsUtil.SELECT_DESCRIPTION))
					? (String) mp.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			searchObj.setLastModification(validator.isNotNullOrEmpty((String) mp.get(ConstantsUtil.SELECT_MODIFIED))
					? (String) mp.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			searchObj.setMaturityState(validator.isNotNullOrEmpty((String) mp.get(ConstantsUtil.SELECT_CURRENT))
					? (String) mp.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			searchObj.setRevision(validator.isNotNullOrEmpty((String) mp.get(ConstantsUtil.SELECT_REVISION))
					? (String) mp.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			searchObj.setType(validator.isNotNullOrEmpty((String) mp.get(ConstantsUtil.SELECT_TYPE))
					? (String) mp.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
			searchObj.setId(validator.isNotNullOrEmpty((String) mp.get(ConstantsUtil.SELECT_ID))
					? (String) mp.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			lsearchObs.add(searchObj);
		}
		context.close();//Added for Defect 45181
	}

	private static String createTempQuery(String sType, String sName, String sRev, String sSelectables) {

		String modifiedDate = "10/24/2019";
		StringBuffer sbQuery = new StringBuffer("temp query bus ");
		sbQuery.append("'Finished Product Part'").append(" ");
		sbQuery.append(sName).append(" ");
		sbQuery.append(sRev).append(" ");
		sbQuery.append("limit 10 ");
		sbQuery.append("where '").append("modified > ").append(modifiedDate).append("' ");
		sbQuery.append("select ");
		sbQuery.append(sSelectables);
		sbQuery.append(";");

		return sbQuery.toString();
	}
	//SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- START
	public static String createQueryPath(String sObjid, String strType) {

		StringBuffer sbQuery = new StringBuffer("query path type '"+strType+".Where' containing ");
	//SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- END
		sbQuery.append(sObjid).append(" ");
		sbQuery.append("select owner.to.from.name").append(" ");
		sbQuery.append("owner.to.from.id").append(" ");
		//SPEC 11.19.2020 : Guna modified for Defect : 37343 --START
		sbQuery.append("owner.to.from.current").append(" ");
		//SPEC 11.19.2020 : Guna modified for Defect : 37343 -- END
		
		sbQuery.append("owner.to.from.to[Change Action].from.name").append(" ").append("dump |");
		sbQuery.append(" ");
		sbQuery.append(";");

		return sbQuery.toString();
	}

	public static String executeTempQuery(Context context, String sQuery) throws MatrixException {

		StopWatch sp = new StopWatch();
		sp.start();
		MQLCommand cmd = new MQLCommand();
		cmd.executeCommand(context, sQuery);
		String result = cmd.getResult();
		sp.stop();

		return result;
	}

	/**
	 * This Method is for getting the SEPS and MEPS
	 * 
	 * @param context
	 * @param sRelationShip
	 * @param objectMap
	 * @param bMEP
	 * @return
	 * @throws Exception
	 */

	public Map<String, String> getEquivalents(Context context, Map objectMap, boolean bMEP, String sRelationShip) {

		Map<String, String> mpEquivalents = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		MapList mlList = new MapList();

		String sContextObjectId = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
				? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		if (UIUtil.isNullOrEmpty(sContextObjectId)) {

			return new HashMap();
		}
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		slBusSelects.addElement(ConstantsUtil.STR_IPCLASS);
		slBusSelects.add(ConstantsUtil.OWNERSHIP);
		if (bMEP) {
			slBusSelects.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
		} else {
			slBusSelects.add(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME);
		}

		try {

			boolean bHasOwnerShip = false;
			String sWhere = ConstantsUtil.EMPTY_STRING;
			String sUserType = util.getUserType();
			SecurityService sct = new SecurityService();
			
			if (util.isModificatinRequired() || sct.isStaffAUGUser()) {
				sWhere = "current==Release";
			}

			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			String[] aCompany = sUserCompanies.split(",");
			StringBuilder sbCompany = new StringBuilder();

			if (aCompany.length > -1) {
				for (int i = 0; i < aCompany.length; i++) {
					if (null != aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					}
				}
			}

			DomainObject dob = new DomainObject(sContextObjectId);
			
			mlList = dob.getRelatedObjects(context, sRelationShip, ConstantsUtil.SYMBL_ASTERISK, slBusSelects, null,
					false, true, (short) 0, sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			Iterator objectListItr = mlList.iterator();

			StringList slParentOwnerShip = new StringList();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbDescription = new StringBuilder();
			StringBuilder sbManuf = new StringBuilder();
			StringBuilder sbSupp = new StringBuilder();

			String strSplier = "";
			String strMfr = "";

			while (objectListItr.hasNext()) {
				Map resultMaps = (Map) objectListItr.next();

				String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
				String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
				String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
				String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
				String sDesc = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sCurrent = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
				sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
				if (bMEP) {
					strMfr = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
				} else {
					strSplier = validator
							.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
				}

				String sPartOwnership = validator
						.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.OWNERSHIP)));
				String strClassFied = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));

				util.formatData(sbName, sName);
				util.formatData(sbType, util.mapType(sType));

				if (util.isModificatinRequired()) {
					StringList slEachOwnership = util.filterOwnerShip(sPartOwnership);
					bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);

					if (bHasOwnerShip) {
						util.formatData(sbId, sId);
						util.formatData(sbRev, sRev);
						util.formatData(sbCurrent, sCurrent);
						util.formatData(sbDescription, sDesc);
						util.formatData(sbManuf, strMfr);
						util.formatData(sbSupp, strSplier);

					} else {
						util.formatData(sbId, ConstantsUtil.NO_ACCESS);
						util.formatData(sbRev, ConstantsUtil.NO_ACCESS);
						util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
						util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
						util.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
						util.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
					}
				} else {
					boolean showData = true;
					if (sIPClassfication.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED)) {
						//SecurityService sct = new SecurityService();
						String sUserlicense = sct.getUserLicense();
						/*if (null != sUserlicense && null != strClassFied && !sUserlicense.contains(strClassFied)) {
							showData = false;
						}*/
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);

						if (showData) {
							util.formatData(sbId, sId);
							util.formatData(sbRev, sRev);
							util.formatData(sbCurrent, sCurrent);
							util.formatData(sbDescription, sDesc);
							util.formatData(sbManuf, strMfr);
							util.formatData(sbSupp, strSplier);
						} else {
							util.formatData(sbId, ConstantsUtil.NO_ACCESS);
							util.formatData(sbRev, ConstantsUtil.NO_ACCESS);
							util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
							util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
							util.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
							util.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
						}
					} else {
						util.formatData(sbId, sId);
						util.formatData(sbRev, sRev);
						util.formatData(sbCurrent, sCurrent);
						util.formatData(sbDescription, sDesc);
						util.formatData(sbManuf, strMfr);
						util.formatData(sbSupp, strSplier);
					}
				}
			}

			mpEquivalents.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpEquivalents.put(ConstantsUtil.ID, sbId.toString());
			mpEquivalents.put(ConstantsUtil.TYPE, sbType.toString());
			mpEquivalents.put(ConstantsUtil.NAME, sbName.toString());
			mpEquivalents.put(ConstantsUtil.REV, sbRev.toString());
			mpEquivalents.put(ConstantsUtil.STATE, sbCurrent.toString());
			if (bMEP) {
				mpEquivalents.put(ConstantsUtil.MANUFACTURER, sbManuf.toString());
			} else {
				mpEquivalents.put(ConstantsUtil.SUPPLIER, sbSupp.toString());
			}

		} catch (Exception e) {

			LOGGER.error("Error from BusExtractUtil:  getEquivalents" + e);
			return new HashMap();
		}
		return util.filterMapList(mpEquivalents);
	}

	
	/**
	 * It will returns the GTIN value from SOAP PO
	 * @param context
	 * @param objId
	 * @param env 
	 * @return
	 */

	
	public Map getGTINFromSoapPO(Context context ,String objId, String strObjectType,String strObjectName, Environment env)
	{
		HashMap <String, Object> hmAttributeDetails = new HashMap <String, Object>();
		String strFPCCodePadding=ConstantsUtil.EMPTY_STRING;
		try
		{
			
			//LOGGER.info("GTIN::\nType:"+strObjectType+"\n:Name:"+strObjectName+"\n:ID:"+objId);
			
			if(UIUtil.isNotNullAndNotEmpty(objId) && ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strObjectType))
			{
				String	strName = FrameworkUtil.getAliasForAdmin(context, ConstantsUtil.TYPE, ConstantsUtil.TYPE_FINISHEDPRODUCTPART, true);
				String	strMQLCommand = "print bus '" + ConstantsUtil.TYPE_ESERVICE_OBJECT_GENERATOR + "' " + strName + " A select "+ ConstantsUtil.SELECT_ATTRIBUTE_ESERVICE_NAME_PREFIX +".value dump";
				String	strNamePrefix = MqlUtil.mqlCommand(context, strMQLCommand);
				if(UIUtil.isNotNullAndNotEmpty(strNamePrefix) && !strObjectName.contains(strNamePrefix))
				{
					 strFPCCodePadding = strObjectName;
					if (strFPCCodePadding.length() > 0 && strFPCCodePadding.length() <= 18)
					{
						while (strFPCCodePadding.length() < 18)
						{
							strFPCCodePadding = '0' + strFPCCodePadding;
						}

					}
				}
			}
					String username = env.getProperty(ConstantsUtil.USER_ENOVIA_SAP_PO_USER);
					String  password = env.getProperty(ConstantsUtil.USER_ENOVIA_SAP_PO_PASS);
					String strSAPSystemURL= env.getProperty(ConstantsUtil.USER_ENOVIA_SAP_PO_SIT_URL);
					EncryptCrypto encrpto = new EncryptCrypto();	
					password=encrpto.decryptString(password);
					//LOGGER.info("GTIN:1");
					SOAPConnectionFactory scfInstance = SOAPConnectionFactory.newInstance();
					SOAPConnection soapConnection = scfInstance.createConnection();
					//LOGGER.info("GTIN:2");
					MessageFactory messFactory = MessageFactory.newInstance();
					//LOGGER.info("GTIN:3");
					SOAPMessage message = messFactory.createMessage();
					//LOGGER.info("GTIN:4");
					String strRequestInput = (String)requestXMLGeneration(context, strFPCCodePadding);
					SOAPPart sp = message.getSOAPPart();
					//LOGGER.info("GTIN:5:strRequestInput:"+strRequestInput);
					StreamSource prepMessage = new StreamSource(new ByteArrayInputStream(strRequestInput.getBytes()));
					//LOGGER.info("GTIN:6");
					sp.setContent(prepMessage);
					//LOGGER.info("GTIN:7");
					// Save message

					message.saveChanges();
					//LOGGER.info("GTIN:8");
					String encodedUserInfo = username + ConstantsUtil.SYMBL_COLON + password;

					encodedUserInfo = new String(Base64.getEncoder().encode(encodedUserInfo.getBytes()));
					//LOGGER.info("GTIN:9");
					//Set Encoded UserInfo to Request SOAPMessage
					message.getMimeHeaders ().setHeader ("Authorization", "Basic " + encodedUserInfo );
					encodedUserInfo = new String(Base64.getEncoder().encode(encodedUserInfo.getBytes()));
					//LOGGER.info("GTIN:10");
					// Send
					//LOGGER.info("GTIN GET MSG"+strRequestInput);
					//SOAPMessage response = soapConnection.call(message, strSAPSystemURL);
					SAPGTINFetcher gtinFetcher = new SAPGTINFetcher();
					String strGTIMXml = gtinFetcher.getGTIN(message, strSAPSystemURL);
					Document doc = null;
					
					if (strGTIMXml != null && !strGTIMXml.equals(ConstantsUtilIRM.SAP_TIMEOUT)) {
					    // Proceed with GTIN response parsing
					    InputStream inputStream = new ByteArrayInputStream(strGTIMXml.getBytes(ConstantsUtil.STRING_UTF_EIGHT));
					    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					    doc = dBuilder.parse(inputStream);
					    // Extract GTIN from the Document as per your logic
					} else {
					    // Log and proceed without GTIN
						HashMap <String, String> hmAUOM = new HashMap <String, String>();
						hmAUOM.put(ConstantsUtilIRM.GTITEM, ConstantsUtilIRM.SAP_TIMEOUT);
						hmAttributeDetails.put(ConstantsUtil.STRING_ALTERNATIVEUNITOFMEASURE, hmAUOM);
					    System.out.println("GTIN not available - skipping SAP");
					} 

					//LOGGER.info("GTIN:10.1");
					/*TransformerFactory transformerFac = TransformerFactory.newInstance();
					Transformer transf = transformerFac.newTransformer();
					Source sc = response.getSOAPPart().getContent();
					//LOGGER.info("GTIN:11");
					// Close connection
					soapConnection.close();
					//LOGGER.info("GTIN:12");
					StringWriter outWriter = new StringWriter();
					StreamResult result = new StreamResult(outWriter);
					transf.transform(sc, result);
					String output = outWriter.toString();
					InputStream inputStream = new ByteArrayInputStream(output.getBytes(ConstantsUtil.STRING_UTF_EIGHT));
					//LOGGER.info("GTIN:13");
					DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					Document doc = dBuilder.parse(inputStream);*/
					//LOGGER.info("GTIN:14");*/
					doc.getDocumentElement().normalize();

					NodeList nAUOMList = doc.getElementsByTagName(ConstantsUtil.STRING_ALTERNATIVEUNITOFMEASURE);
					//LOGGER.info("GTIN:15");
					if(nAUOMList.getLength() > 0)
					{
						HashMap <String, String> hmAUOM = new HashMap <String, String>();
						for (int i = 0; i < nAUOMList.getLength(); i++)

						{
							Node nAUOMNode = nAUOMList.item(i);
							Element eAUOMElement = (Element) nAUOMNode;
							String strAUOMName = (String)eAUOMElement.getAttribute(ConstantsUtil.STRING_AUOM);
							NodeList nGTINTag = eAUOMElement.getElementsByTagName(ConstantsUtil.STRING_GTIN);
							Element nGTINValue = (Element)(nGTINTag.item(0));
							String strGTINValue = (String)nGTINValue.getTextContent();
							hmAUOM.put(strAUOMName, strGTINValue);

						}
						hmAttributeDetails.put(ConstantsUtil.STRING_ALTERNATIVEUNITOFMEASURE, hmAUOM);

					}
					
					//LOGGER.info("GTIN:16");
					// Getting all pick list Object of ConsumerUnit AlternateUoM and Updating the hashMap

					String strConsumerUnitAUOMName = getAUOMNameFromPicklistObject(context, ConstantsUtil.TYPE_PG_PLICONSUMERUNIT);

					if(UIUtil.isNotNullAndNotEmpty(strConsumerUnitAUOMName))

					{

						hmAttributeDetails.put(ConstantsUtil.STRING_CONSUMERUNIT, strConsumerUnitAUOMName);

					}

					// Getting all pick list Object of CustomerUnit AlternateUoM and Updating the hashMap

					String strCustomerUnitAUOMName = getAUOMNameFromPicklistObject(context, ConstantsUtil.TYPE_PG_PLICUSTOMERUNIT);

					if(UIUtil.isNotNullAndNotEmpty(strCustomerUnitAUOMName))
					{
						hmAttributeDetails.put(ConstantsUtil.STRING_CUSTOMERUNIT, strCustomerUnitAUOMName);
					}



					// Getting all pick list Object of InnerPack AlternateUoM and Updating the hashMap

					String strInnerpackAUOMName = getAUOMNameFromPicklistObject(context, ConstantsUtil.TYPE_PG_PLIINNERPACK);

					if(UIUtil.isNotNullAndNotEmpty(strInnerpackAUOMName))
					{
						hmAttributeDetails.put(ConstantsUtil.STRING_INNERPACK, strInnerpackAUOMName);
					}

					// Getting all pick list Object of PalletType AlternateUoM and Updating the hashMap

					String strPalletTypeAUOMName = getAUOMNameFromPicklistObject(context, ConstantsUtil.TYPE_PG_PLIPALLETTYPE);

					if(UIUtil.isNotNullAndNotEmpty(strPalletTypeAUOMName))
					{
						hmAttributeDetails.put(ConstantsUtil.STRING_PALLETTYPE, strPalletTypeAUOMName);
					}
								
		}catch(Exception e){
			LOGGER.error("Error in BusExtractUtil, Unable to send request to SOAP PO: getGTIN:"+e);
		}
		
	//LOGGER.info("IN getGTINFromSoapPO: hmAttributeDetails:"+hmAttributeDetails);
		return hmAttributeDetails;
	}
	
	
	public MapList getTransportUnitWeightAndDiamensionsData(Context context, String objectId) throws Exception

	{
		MapList objList = null;
		StringList busSelects = new StringList();
		busSelects.add(ConstantsUtil.SELECT_ID);
		busSelects.add(ConstantsUtil.SELECT_TYPE);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE);
		
		StringList relSelects = new StringList();
		relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
		
		String relPattern = ConstantsUtil.RELATIONSHIP_PGTRANSPORTUNIT; 
		String typePattern = ConstantsUtil.TYPE_PG_TRANSPORTUNIT;
		DomainObject doObj = DomainObject.newInstance(context, objectId);
		objList = doObj.getRelatedObjects(
								context, 
								relPattern, 
								typePattern, 
								busSelects, 
								relSelects, 
								true, 
								true, 
								(short) 1, 
								null, 
								null, 
								0
								);

		if( objList != null && !objList.isEmpty())	{
			objList.sort(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE , "ascending", "string");			
		} else {
			return objList;
		}
		return objList;

	}
	
	
	/**

	 * Get the the Alternate Unit of Measure Names for the respective Product Data Part from the Pick list object

	 * @param context

	 * @param strPicklistTypeInput - Type of the Object

	 * @return String with all the Pick list names (AUOM)

	 * @throws Exception

	 */

	public String getAUOMNameFromPicklistObject(Context context, String strPicklistTypeInput)throws Exception

	{

		StringBuffer sbAUOMName = new StringBuffer(20);

		try

		{

			StringTokenizer strTok = null;

			StringTokenizer strTokItem = null;

			String strPicklistItemName = "";

			String strPicklistType = "";

			String strNextItem = "";

			if(UIUtil.isNotNullAndNotEmpty(strPicklistTypeInput))

			{

				String mqlString = "temp query bus " + strPicklistTypeInput + " * * where \'(current == Active)\' !expand select name dump |";

				String strResult = MqlUtil.mqlCommand(context, mqlString.toString()).trim();



				strTok = new StringTokenizer(strResult, "\n");



				while (strTok.hasMoreTokens())

			    {

					strNextItem = strTok.nextToken();

			        strTokItem = new StringTokenizer(strNextItem, ConstantsUtil.SYMBL_PIPE);

			        strPicklistType = strTokItem.nextToken();

			        strPicklistItemName = strTokItem.nextToken();

			        if(sbAUOMName != null && sbAUOMName.length() > 0)

			        {

			        	sbAUOMName.append(ConstantsUtil.SYMBL_COMMA);

			        	sbAUOMName.append(strPicklistItemName);

			        }

			        else

			        {

			        	sbAUOMName.append(strPicklistItemName);

			        }

			    }

			}

		}

		catch(Exception Ex)

		{

			Ex.printStackTrace();

			throw Ex;

		}

		return sbAUOMName.toString();

	}


	
	
		/**
		 * Request the required parameters
		 * @param context
		 * @param strFPCCode
		 * @return
		 * @throws Exception
		 */
		
		public static String requestXMLGeneration(Context context, String strFPCCode)throws Exception

		{
			String strRequestXMLString = "";

			try
			{
				DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
				Document doc = docBuilder.newDocument();

				//Creating the XML tree
				Element root = doc.createElement("soapenv:Envelope");
				root.setAttribute("xmlns:soapenv", "http://schemas.xmlsoap.org/soap/envelope/");

				root.setAttribute("xmlns:gpdb", "http://pg.com/xi/mdm/gpdb");

				doc.appendChild(root);

				Element header = doc.createElement("soapenv:Header");

				root.appendChild(header);

				Element body = doc.createElement("soapenv:Body");

				root.appendChild(body);

				Element prodGetDetails = doc.createElement("gpdb:GPDB_ProductGetDetails");

				body.appendChild(prodGetDetails);

				//Element prodMand = doc.createElement("gpdb:ProductMatnr");
				//prodMand.setAttribute("includeUoMData", ConstantsUtil.CONSTANT_STRING_Y);
				
				Element prodMand = doc.createElement("gpdb:ProductMatnr");
			    prodMand.setAttribute("includeUoMData", ConstantsUtil.CONSTANT_STRING_Y);
			    prodMand.setAttribute("includeLeadingZeros", ConstantsUtil.CONSTANT_STRING_Y);

				/*prodMand.setAttribute("includeBasicData", ConstantsUtil.CONSTANT_STRING_Y);
				prodMand.setAttribute("includeSalesData", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includeAttributeData", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includeDerivedAttributes", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includeGroupedAttributes", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includeClassifications", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includeBomData", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includePlantData", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includeLifecycleData", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includeLeadingZeros", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includeHierarchyData", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("includeWFAttributeData", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("WFInitiativeID", ConstantsUtil.CONSTANT_STRING_Y);

				prodMand.setAttribute("WFAttributeTemplate", ConstantsUtil.CONSTANT_STRING_Y);*/

				prodGetDetails.appendChild(prodMand);



				//add a text element to the child

				Text text = doc.createTextNode(strFPCCode);

				prodMand.appendChild(text);



				//set up a transformer

				TransformerFactory transfac = TransformerFactory.newInstance();

				Transformer trans = transfac.newTransformer();

				trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, ConstantsUtil.ALL_SMALL_YES);

				trans.setOutputProperty(OutputKeys.INDENT, ConstantsUtil.ALL_SMALL_YES);



				//create string from xml tree

				StringWriter sw = new StringWriter();

				StreamResult result = new StreamResult(sw);

				DOMSource source = new DOMSource(doc);

				trans.transform(source, result);

				strRequestXMLString = sw.toString();

			}

			catch(Exception Ex)

			{

				Ex.printStackTrace();

				throw Ex;

			}
			return strRequestXMLString;

		}


	
	public String getGTINValue(Context context, Map hmAUOM, boolean bPackingChar, MapList objectList) throws FrameworkException
	{
		
		StopWatch swGtinFinal = new StopWatch();
		swGtinFinal.start();
		
		Vector vGTINValues = new Vector();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		try
		{
		/*StopWatch swGtinSoapCall = new StopWatch();
		swGtinSoapCall.start();
		//Map hmAUOM = getGTINFromSoapPO(context, objId,sType,sName,env);
		swGtinSoapCall.stop();
		
		LOGGER.info("GTIN SOAP Call Taken Time :"+swGtinSoapCall.getTime());*/
		
		Map mpTemp =(Map)hmAUOM.get("AlternativeUnitOfMeasure");
		if(objectList != null && !objectList.isEmpty())
		{
			for(int i = 0; i < objectList.size(); i ++)
			{
				Map mapIndividual = (Map) objectList.get(i);
				String	strObjId = (String) mapIndividual.get(DomainConstants.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strObjId))
				{
					DomainObject domObject = DomainObject.newInstance(context, strObjId);
					if(bPackingChar)
					{
						String strObjAUOM = (String) domObject.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
						
						if(strObjAUOM.equals("ConsumerUnit")){
							strObjAUOM = "type_pgConsumerUnitPart";
						}else 	if(strObjAUOM.equals("InnerPack")){
							strObjAUOM = "type_pgInnerPackUnitPart";
						}else 	if(strObjAUOM.equals("CustomerUnit")){
							strObjAUOM = "type_pgCustomerUnitPart";
						}else if(strObjAUOM.equals("PalletType")){
							strObjAUOM = "type_pgTransportUnit";
						}else 	if(strObjAUOM.equals("Actual/Physical Case")){
							strObjAUOM = "CS";
						}else 	if(strObjAUOM.equals("Shrink Wrap")){
							strObjAUOM = "SW";
							
					//SPEC 11.19.2020 : Chandra modified for Defect : 37425  --START
						//}else 	if(strObjAUOM.equals("BundlePack")){
						}else 	if(strObjAUOM.equals("Bundle Pack")){
					//SPEC 11.19.2020 : Chandra modified for Defect : 37425  --END
					
						strObjAUOM = "BP";
						}else	if(strObjAUOM.equals("IT")){
							strObjAUOM = "IT";
						}else 	if(strObjAUOM.equals("MP")){
							strObjAUOM = "MP";
						}else if(strObjAUOM.equals("SP")){
							strObjAUOM = "SP";
						}else 	if(strObjAUOM.equals("Item")){
							strObjAUOM = "IT";
						}else 	if(strObjAUOM.equals("SW")){
							strObjAUOM = "SW";
						}
						else{
							strObjAUOM = "";
						}
						
						
						if(mpTemp != null && !mpTemp.isEmpty() && UIUtil.isNotNullAndNotEmpty(strObjAUOM) && mpTemp.containsKey(strObjAUOM))
						{
							vGTINValues.add((String)mpTemp.get(strObjAUOM));
						}else{
							vGTINValues.add("");
						}
						
						if(mpTemp.containsValue(ConstantsUtilIRM.SAP_TIMEOUT)) {
							vGTINValues.add(ConstantsUtilIRM.SAP_TIMEOUT);
						}
				}
				else
				{
						String strPallType = (String) domObject.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE);
						
						
						if(UIUtil.isNotNullAndNotEmpty(strPallType) && mpTemp != null && !mpTemp.isEmpty() && mpTemp.containsKey(strPallType))
						{
							vGTINValues.add((String)mpTemp.get(strPallType));
						}else{
							vGTINValues.add("");
						}
						
						if(mpTemp.containsValue(ConstantsUtilIRM.SAP_TIMEOUT)) {
							vGTINValues.add(ConstantsUtilIRM.SAP_TIMEOUT);
						}

					}
				}

			}
		}
		
		
		swGtinFinal.stop();	
		
		//LOGGER.info("Total GTIN Taken  Time :"+swGtinFinal.getTime());
		//LOGGER.info("getGTINValue:"+vGTINValues.toString());
		return	validator.getStringEquivalentForStringList(vGTINValues.toString());
		
		}catch(Exception e){
			LOGGER.error("Error in BusExtractUtil  :unable to get  GTIN ");
			return "";
		}
	}
	
	/**
	 * Added by Chandra for 18x.6 Dev on 05-03-2021
	 * @param context
	 * @param strObjectId
	 * @return
	 * @throws Exception
	 */
	
	   public String getActiveECIconProperty(Context context, String strObjectId) throws Exception 
	   {
		     
		     String strActiveECIcon = "";
		 
		    try{ 
		     String strClose = FrameworkUtil.lookupStateName(context, ConstantsUtilIRM.POLICY_ENGINEERING_CHANGE_STANDARD, "state_Close");
		    String strReject = FrameworkUtil.lookupStateName(context, ConstantsUtilIRM.POLICY_ENGINEERING_CHANGE_STANDARD, "state_Reject");
		    String strComplete = FrameworkUtil.lookupStateName(context, ConstantsUtilIRM.POLICY_ENGINEERING_CHANGE_STANDARD, "state_Complete");
		    
		    StringList relSelects = new StringList();
		    StringList busSelects = new StringList();
		    busSelects.add("current");
		    relSelects.add("to.id");
		    
		    StringBuffer objWhere = new StringBuffer();
		    objWhere.append("((");
		    objWhere.append("current");
		    objWhere.append(" != \"");
		    objWhere.append(strClose);
		    objWhere.append("\")&&(");
		    objWhere.append("current");
		    objWhere.append(" != \"");
		    objWhere.append(strReject);
		    objWhere.append("\")&&(");
		    objWhere.append("current");
		    objWhere.append(" != \"");
		    objWhere.append(strComplete);
		    objWhere.append("\"))");
		    
		    DomainObject domObj = DomainObject.newInstance(context, strObjectId);
		    MapList relIdList = domObj.getRelatedObjects(context, DomainConstants.RELATIONSHIP_EC_AFFECTED_ITEM, DomainConstants.TYPE_ENGINEERING_CHANGE, busSelects,
		    		relSelects, true, false, (short)1, objWhere.toString(), "");  
		    
		    if (relIdList.size() > 0) {

		      strActiveECIcon = ConstantsUtil.SYMBL_YES;
		    } else
		    {
		      strActiveECIcon =ConstantsUtil.SYMBL_NO;
		    } 
		    
		    }catch(Exception e)
		    {
		    	LOGGER.error("Error in BusExtractUtil  :unable to get  getActiveECIconProperty ");
		    	return ConstantsUtil.EMPTY_STRING;
		    }
		    return strActiveECIcon;
		    
		    
		  }

	
	

	/**
	 * Added by Chandra for 18x.6 Dev on 05-03-2021
	 * @param context
	 * @param strObjectId
	 * @return
	 * @throws Exception
	 */
	
	   public static MapList getAllDerivationsOfRelationship(Context var0, String var1, String var2)
				throws FrameworkException {
			new MapList();

			try {
				StringList var4 = new StringList("id");
				var4.add("type");
				var4.add("name");
				var4.add("revision");
				var4.add("current");
				StringList var5 = new StringList("id[connection]");
				var5.add("name[connection]");
				StringBuffer var6 = (new StringBuffer(50)).append(ConstantsUtilIRM.RELATIONSHIP_DERIVED_ABSTRACT);
				Pattern var7 = new Pattern(var2);
				DomainObject var8 = new DomainObject(var1);
				MapList var3 = var8.getRelatedObjects(var0, var6.toString(), "*", var4, var5, false, true, (short) 0, "",
						"", (short) 0, true, false, (short) 1000, (Pattern) null, var7, (Map) null, "", "", (short) 1);
				return var3;
			} catch (Exception var9) {
				throw new FrameworkException(var9.getMessage());
			}
		}

		public static boolean higherRevisionExists(Context var0, String var1) throws FrameworkException {
			boolean var2 = false;
			MapList var3 = getAllDerivationsOfRelationship(var0, var1, ConstantsUtilIRM.RELATIONSHIP_MAIN_DERIVED);
			if (var3 != null && var3.size() > 0) {
				var2 = true;
			}

			return var2;
		}
		//SPEC: 12.30.2021: Added for Req- 41530,41531 Dev 18x.6.0.3  -- START
		public static String createCAExpandQuery(String sObjId) {
			StringBuilder sbQuery = new StringBuilder("expand bus ");
			sbQuery.append(sObjId).append(" ");
			sbQuery.append("rel '");
			sbQuery.append(ConstantsUtilIRM.RELATIONSHIP_PROPOSED_ACTIVITIES);
			sbQuery.append("' select bus from[").append(ConstantsUtilIRM.RELATIONSHIP_PROPOSED_ACTIVITIES).append("].to.paths[").append(ConstantsUtilIRM.TYPE_PROPOSED_ACTIVITY);
			sbQuery.append(".What].path.element[0].");
			sbQuery.append(ConstantsUtil.SELECT_PHYSICAL_ID);
			sbQuery.append(" ").append("dump |");
			sbQuery.append(";");
			return sbQuery.toString();
		}
		//SPEC: 12.30.2021: Added for Req- 41530,41531 Dev 18x.6.0.3  -- END
	
	}
	
	
	

