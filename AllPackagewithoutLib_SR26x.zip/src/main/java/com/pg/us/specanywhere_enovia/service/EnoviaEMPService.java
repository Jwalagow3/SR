package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaEMPService {
	public HashMap<String, Map<String, String>> getEMPdata(String objId, Environment env) throws Exception;
}
