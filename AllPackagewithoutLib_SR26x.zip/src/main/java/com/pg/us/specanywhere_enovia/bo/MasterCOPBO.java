/**
 * Project 		: SpecsAnywhere
 * Program 		: 
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.FileUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class MasterCOPBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(MasterCOPBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	public MasterCOPBO() {
		// empty constructor
	}

	public MasterCOPBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getMCopBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getMCopBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getMCopDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getMCopDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getMasterConsumerUnitPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getMasterConsumerUnitPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getFileSelects(context));
		
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
				
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	
	/**
	 * Method Name 			: getMcopRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getMcopRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}


	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		return busSelect;
	}

	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
		
		//Added for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
	
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --END
		//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
	    relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END

		return relSelect;
	}

	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE); 
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);  
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_DIMENSTION_UOM);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PROJECTINITIATIVEMILESTONE);


		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);
		
		//SPEC: 04/11/2020: Added for 18x.5 Defect 37084 -- START
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: 04/11/2020: Added for 18x.5 Defect 37084 -- END
		// Guna Added for Defect 39163  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		// Guna Added for Defect 39163  18x.5.2 Release -- END
		//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 22, 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 22, 2021 -- END
		return busSelect;
	}


	/**
	 * Method Name 			: updateRefDocs
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map updateRefDocs(Context context,Map resultMaps) 
	{
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		//SPEC: <01.21.2021>: Chandra Added for Defect :37569 ## --START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		//SPEC: <01.21.2021>: Chandra Added for Defect :37569 ## --END
		
		//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- START
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- END

		boolean bHasOwnerShip = false;
		
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		CommonDocBO commonDoc = new CommonDocBO();
		FileUtil fileUtil = new FileUtil();
		
		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

		
		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			DomainObject dobCdoc = new DomainObject(sObjectId);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobCdoc.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			//SPEC: <15.03.2021>: Chandra Added for Dev 18x.6   -- START
			mlRelatedSpecs.sort(ConstantsUtil.SELECT_NAME, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
			//SPEC: <15.03.2021>: Chandra Added for Dev 18x.6   -- END
			String sUser = util.getUserType();
			//SPEC: <05.05.2021>: Guna Commented for Internal Defect  Dev 18x.6.0.1   -- START
			/*if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}*/
			//SPEC: <05.05.2021>: Guna Commented for Internal Defect  Dev 18x.6.0.1   -- END
			//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 12, 2021 -- START
			/*if(util.isModificatinRequired()) 
			{
				mlRelatedSpecs=util.filterPhase(mlRelatedSpecs);
			}*/
			//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 12, 2021 -- END
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType=new StringBuilder();
			StringBuilder sbRev=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbDescription=new StringBuilder();
			StringBuilder sbTitle=new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			//StringBuilder sbSource = new StringBuilder();
			StringBuilder sbGendocName = new StringBuilder();
			StringBuilder sbGendocPath = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
			StringBuilder sbIsIRM = new StringBuilder();
			StringBuilder sbGendocFormat = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sName    =   validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sId		=	(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
				String sDesc	=	validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sTitle	=	validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String strClassFied = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				boolean bNonReleased = false;
				DomainObject doObj = new DomainObject(sId);
				Map mpFiles = new HashMap();
				String sGendocName = "";
				String sGendocPath = "";
				// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
				String sGendocPathFormat = "";
				// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
				if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
					continue;
				}
				
				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}
				
				// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
				boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
				// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
				
				//SPEC: Release SR18x.6 - Added for Req# 38552 by Jwala on Date 03/05/2021 -- START
				String sUserType = util.getUserType();
				if ((ConstantsUtil.PG_CM.equalsIgnoreCase(sUserType) || ConstantsUtil.PG_SP.equalsIgnoreCase(sUserType))
						&& bisIRMDoc && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
					continue;
				}
				//SPEC: Release SR18x.6 - Added for Req# 38552 by Jwala on Date 03/05/2021 -- END
				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					String sLangBuffer =ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;

				
				// SPEC: Added for 18x.5.2 DEV --Shashank -- START
					// SPEC: Moved to top  for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
					//boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
					// SPEC: Moved to Top  for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
				if(bisIRMDoc) {
					mpFiles=fileUtil.getGendocForIRM(context, doObj);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
				}else {
					//mpFiles=fileUtil.getGendocForReferenceDocuments(context, doObj);
					mpFiles=fileUtil.getFilesForIPM(context, doObj);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
					sGendocPathFormat=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
					// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
				}
				// SPEC: Added for 18x.5.2 DEV --Shashank -- END
				
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- START
				if(!bisIRMDoc){
					sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_NAME));
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- END
				
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41585 on Date 25/03/2021 --START
				if(sObjectType.equalsIgnoreCase("pgTransportUnitPart")) {
					sName    =   validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_NAME));
				}
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41585 on Date 25/03/2021 --END				
				// Release SR18x.5.2: Added for Defect 38079 by Amman ## -- START
				if(sObjectType.equalsIgnoreCase("pgFinishedProduct")) {
					sName=sGendocName;
				//SPEC: <01.21.2021>: Chandra Added for Defect :38079 ## --START
					String	strFileType=validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE));;
					if("Reference_File".equalsIgnoreCase(strFileType)){
						strFileType="Reference File";
						}else if("QEC_File".equalsIgnoreCase(strFileType)){
							strFileType="Quality Evolution Chart File";
						}else if("Design_File".equalsIgnoreCase(strFileType)){
							strFileType="Design File";
						}else if("Language_Rendition".equalsIgnoreCase(strFileType)){
							strFileType="Language Rendition";
						}
					sType=strFileType;
					
					if (sName.contains("LR_*")) {
						sLangBuffer = sRev;
					}
					else {
						sLangBuffer = "";
					}
				}
			//SPEC: <01.21.2021>: Chandra Added for Defect :38079 ## --END
				
				// Release SR18x.5.2: Added for Defect 38079 by Amman ## -- END
					
				if (util.isModificatinRequired()) 
				{    
					
					bHasOwnerShip=util.checkHasAccess(context, null, sId);
					
						if(!sCurrent.equals(ConstantsUtil.RELEASE) && !sCurrent.equals(ConstantsUtil.RELEASED) && !sCurrent.equals(ConstantsUtil.STR_CAP_RELEASED)) {
						bHasOwnerShip=false;
					}
					if(bHasOwnerShip) 
					{
					     showData =true;
					}
					
					else{
						continue;
					}
				}else if(sct.isStaffAUGUser()) {
					
					if(sType.equalsIgnoreCase("Document")) {
						showData =true;
					}else{
						showData=util.checkHasAccess(context, null, sId);
					}
					//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equals(ConstantsUtil.RELEASED) && !sCurrent.equals(ConstantsUtil.STR_CAP_RELEASED)) {
						bNonReleased=true;
					}
					//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
					//SPEC: Release SR18x.6. Added by Dominic for Defect 41585 on Date 25/03/2021 --START
					if(sObjectType.equalsIgnoreCase("pgTransportUnitPart")&&sType.equalsIgnoreCase("pgBulkUpload")) {
						showData =true;
					}
					//SPEC: Release SR18x.6. Added by Dominic for Defect 41585 on Date 25/03/2021 --END
					//Added by Ganesh 1.0.2 Release End	
				}else {
					
					showData=util.checkHasAccess(context, null, sId);
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equals(ConstantsUtil.RELEASED) && !sCurrent.equals(ConstantsUtil.STR_CAP_RELEASED)) {
						bNonReleased=true;
					}
				}	
				if(showData || bNonReleased) 
				{
					util.formatData(sbType,util.mapType(sType));
					util.formatData(sbName,sName);
					util.formatData(sbDescription,sDesc);
					util.formatData(sbCurrent,sCurrent);
					//util.formatData(sbId,sId);
					util.formatData(sbRev,sRev);
					util.formatData(sbTitle,sTitle);
					//util.formatData(sbSource,ConstantsUtil.EMPTY_STRING);
					//util.formatData(sbSource,ConstantsUtil.SOURCE_DIRECT);
					util.formatData(sbLangBuffer,sLangBuffer);
					// SPEC: Added for 18x.5.2 DEV --Shashank -- START
					util.formatData(sbGendocName,sGendocName);
					util.formatData(sbGendocPath,sGendocPath);
					// SPEC: Added for 18x.5.2 DEV --Shashank -- END
					// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
					util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
					util.formatData(sbGendocFormat, sGendocPathFormat);
					// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
					if(bNonReleased) {
						sId = ConstantsUtil.EMPTY_STRING;
						util.formatData(sbId,sId);
					}else {
						util.formatData(sbId,sId);
					}
					
				}else{
					util.formatData(sbType,util.mapType(sType));
					util.formatData(sbName,sName);
					util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
					util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
					util.formatData(sbId,ConstantsUtil.NO_ACCESS);
					util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
					util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
					//util.formatData(sbSource,ConstantsUtil.NO_ACCESS);
					util.formatData(sbLangBuffer,ConstantsUtil.NO_ACCESS);
					// SPEC: Added for 18x.5.2 DEV --Shashank -- START
					util.formatData(sbGendocName,ConstantsUtil.NO_ACCESS);
					util.formatData(sbGendocPath,ConstantsUtil.NO_ACCESS);
					// SPEC: Added for 18x.5.2 DEV --Shashank -- END
					// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
					util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
					util.formatData(sbGendocFormat, ConstantsUtil.NO_ACCESS);
					// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
				}
				}else
				{ 
					// SPEC: Added for 18x.5.2 DEV --Shashank -- START
					mpFiles = fileUtil.getFilesForIPM(context, doObj);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
					sGendocPathFormat=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
					// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
					// SPEC: Added for 18x.5.2 DEV --Shashank -- END
					
					//SPEC: <16.04.2021>: Guna Added for 42500 Defect Dev 18x.6   -- START
					String sLangBuffer =ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;
					
					if(sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)){
						if (sName.contains("LR_")) {
							sLangBuffer = sRev;
						}
						else {
							sLangBuffer = "";
						}
				       }
					//SPEC: <16.04.2021>: Guna Added for 42500 Defect Dev 18x.6   -- END
					//SPEC: Release SR18x.5.2 - Added for Defect# 39455  by Guna on Date 15/02/2021 -- START
					if(!bisIRMDoc){
						sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_NAME));
					}
					//SPEC: Release SR18x.5.2 - Added for Defect# 39455  by Guna on Date 15/02/2021 -- END
					
					//60035748
					// SPEC Added  Jwala for Defect #37659 --- START
					if(sObjectType.equalsIgnoreCase("pgMasterPackagingAssemblyPart")){
						sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					}
					// SPEC Added  Jwala for Defect #37659 --- END
					
					
					
					//SPEC: <19.03.2021>: Guna Added for Req 38530 Dev 18x.6   -- START
					sName=sGendocName;
					
					String	strFileType=validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE));;
					if("Reference_File".equalsIgnoreCase(strFileType)  || "Reference File".equalsIgnoreCase(strFileType)){
						strFileType="Reference File";
						}else if("QEC_File".equalsIgnoreCase(strFileType)){
							strFileType="Quality Evolution Chart File";
						}else if("Design_File".equalsIgnoreCase(strFileType)){
							strFileType="Design File";
						}else if("Language_Rendition".equalsIgnoreCase(strFileType)){
							strFileType="Language Rendition";
						}
					sType=strFileType;
					/*
					if (sName.contains("LR_*")) {
						sLangBuffer = sRev;
					}
					else {
						sLangBuffer = "";
					}*/
					//SPEC: <19.03.2021>: Guna Added  for Req 38530 Dev 18x.6   -- END
					
					if (util.isModificatinRequired()) 
					{    
						bHasOwnerShip=util.checkHasAccess(context, null, sId);
						
						//if(sCurrent!=ConstantsUtil.RELEASE ) {
						//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
						if(!sCurrent.equals(ConstantsUtil.RELEASE) && !sCurrent.equals(ConstantsUtil.STATE_EXISTS)) {
							//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
							bHasOwnerShip=false;
						}
						//SPEC: <04.06.2021>: Guna Modified for Internal Defect Dev 18x.6.0.1   -- START
						if(bHasOwnerShip) 
						{
							showData =true;
							
						}else {
							continue;
						}
						//SPEC: <04.06.2021>: Guna Modified for Internal Defect Dev 18x.6.0.1   -- END
					}else if(sct.isStaffAUGUser()) {
						if(sType.equalsIgnoreCase("Document")) {
							showData =true;
						}else{
							showData=util.checkHasAccess(context, null, sId);
							}
						//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equals(ConstantsUtil.STATE_EXISTS)) {
							//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
							bNonReleased=true;
						}
					}else {
						showData=util.checkHasAccess(context, null, sId);
						//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equals(ConstantsUtil.STATE_EXISTS)) {
							bNonReleased=true;
						}
						//SPEC: <19.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
					}
					
					//SPEC : Modified on 17-Feb-2021 by Chandra for Defect 39449 ##--START	
					if(!showData) {
						sId=ConstantsUtil.NO_ACCESS;
					}
					//SPEC : Modified on 17-Feb-2021 by Chandra for Defect 39449 ##--END
					
					if(sCurrent.equals("Exists") && !sRev.equals("Rendition")) {
						util.formatData(sbType,util.mapType(sType));
						util.formatData(sbName,sName);
						util.formatData(sbDescription,sDesc);
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbId,sId);
						util.formatData(sbRev,sRev);
						util.formatData(sbTitle,sTitle);
						//util.formatData(sbSource,ConstantsUtil.SOURCE_DIRECT);
						//SPEC: <16.04.2021>: Guna Modified for 42500 Defect Dev 18x.6   -- START
						util.formatData(sbLangBuffer,sLangBuffer);
						
						/*if(sObjectType.equalsIgnoreCase("pgFinishedProduct")) {
							util.formatData(sbLangBuffer,sLangBuffer);
						}else{
							util.formatData(sbLangBuffer,sPLangBuffer);
						}*/
						//SPEC: <16.04.2021>: Guna Modified for 42500 Defect Dev 18x.6   -- END
						// SPEC: Added for 18x.5.2 DEV --Shashank -- START
						util.formatData(sbGendocName,sGendocName);
						util.formatData(sbGendocPath,sGendocPath);
						// SPEC: Added for 18x.5.2 DEV --Shashank -- END
						// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, sGendocPathFormat);
						// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
					}else {
						util.formatData(sbType,util.mapType(sType));
						util.formatData(sbName,sName);
						util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
						util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
						//util.formatData(sbSource,ConstantsUtil.NO_ACCESS);
						util.formatData(sbLangBuffer,ConstantsUtil.NO_ACCESS);
						// SPEC: Added for 18x.5.2 DEV --Shashank -- START
						util.formatData(sbGendocName,ConstantsUtil.NO_ACCESS);
						util.formatData(sbGendocPath,ConstantsUtil.NO_ACCESS);
						// SPEC: Added for 18x.5.2 DEV --Shashank -- END
						
						// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, ConstantsUtil.NO_ACCESS);
						// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
					}
					
				}
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doObj.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				
			}

			mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
			mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
			//mpRefDoc.put(ConstantsUtil.SOURCE, sbSource.toString()); //Commented by Ketan for Req. no. 47200
			mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
			mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLangBuffer.toString());
			mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
			// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- START
			mpRefDoc.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());
			// SPEC: Added for 18x.5.2 DEV  -- Chandra For ReferenceDocuments On : 02-05-2021 -- END
		}catch(Exception e){
			//e.printStackTrace();
			LOGGER.error("Exception in Program : MasterCOPBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return util.filterMapList(mpRefDoc);
		//return mpRefDoc;
	}


	/**
	 * Method Name 			: addMultiSelects
	 * Method Description 	:
	 */
	public StringList addMultiSelects() {

		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.PRIMARYORGANIZATION);
		slMultiSelects.add(ConstantsUtil.SECONDARYORGANIZATION);

		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		
		return slMultiSelects;
	}


	/**
	 * Method Name 			: removeMultiselects
	 * Method Description 	:
	 */
	public void removeMultiselects()
	{
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRIMARYORGANIZATION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SECONDARYORGANIZATION);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		// Guna Added for Defect 39163  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
			// Guna Added for Defect 39163  18x.5.2 Release -- END
	}


	/**
	 * Method Name 			: updateNotes
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> updateNotes(Context context, Map objectMap) 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		Map<String,String> mpNotes = new HashMap<String,String>();
		StringBuilder sbNum = new StringBuilder();
		StringBuilder sbDes = new StringBuilder();

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);

		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

		try
		{

			String sContextObjectId = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_ID))?(String)objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			DomainObject dom = new DomainObject(sContextObjectId);
			MapList mlNotes = dom.getRelatedObjects(context,"Extended Data", ConstantsUtil.QUERY_WILDCARD, busSelect,
					relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dom.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			mlNotes.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE, "ascending", "integer");

			Iterator objectListItr = mlNotes.iterator();
			while(objectListItr.hasNext())
			{
				Map mpTemp = (Map) objectListItr.next();
				String strType = (String)mpTemp.get(ConstantsUtil.SELECT_TYPE);
				if (strType.equals(ConstantsUtil.TYPE_NOTES_CHAR))
				{
					String strDesTemp= (String)mpTemp.get(ConstantsUtil.SELECT_DESCRIPTION);
					String strDes = strDesTemp.replace(ConstantsUtil.ENCODED_PLUS, ConstantsUtil.SYMBL_PLUS);//Added by Ketan for Defect No. 51729
					String strNum = (String)mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

					util.formatData(sbDes,strDes);
					util.formatData(sbNum,strNum);
				}
			}
			
			mpNotes.put(ConstantsUtil.NUMBER, sbNum.toString());
			mpNotes.put(ConstantsUtil.NOTES, sbDes.toString());
			
		} catch(Exception ex){
			LOGGER.error("Unable to updateNotes : Program MasterCOPBO "+ex);
			return new HashMap();
		}
		return mpNotes;

	}
	
	
	public Map<String, String> parseMaplist(Context context, MapList mapList) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();

		
		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		
		
		Iterator objectListItr = mapList.iterator();
		
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState = new StringBuilder();
		StringBuilder sbEBOMStage = new StringBuilder();
		StringBuilder sbEBOMRDOC = new StringBuilder();
		StringBuilder sbEBOMRevRelDt = new StringBuilder();
		StringBuilder sbEBOMTupName = new StringBuilder();
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlternate = new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDensityUOM = new StringBuilder();
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		//SPEC: Added by Ketan for req no. 41754 on 06.16.2022 -- END
		//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
		StringBuilder sbFEBOMParentName = new StringBuilder();
		StringBuilder sbFEBOMParentREV = new StringBuilder();
		StringBuilder sbFEBOMParentId = new StringBuilder();
		StringBuilder sbFEBOMParentType = new StringBuilder();
		//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
			String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
			String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
			String sReleaseDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
			String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON + sReleaseDate;
			String spgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
			String sFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
			String sTupName = (String) objectMap.get(ConstantsUtil.TUPNAME);
			sType = util.mapType(sType);
			String sSubstitute = (String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
			sSubstitute = util.replaceSpecialSymbols(sSubstitute);
			String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			String sBuom = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
			String sComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
			sCurrent = util.mapType(sCurrent);
			String sStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
			sRD = util.replaceSpecialSymbols(sRD);
			String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
			sOC = util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
			String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));


			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//String sAlternate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
			//sAlternate = sAlternate.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
			strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strAltID = util.checkAlternateHasAccess(context,objectMap);	
			String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
			strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			String sOSPD = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY));
			String sDensityUOM = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM));
			//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
			String sParentId =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID);
			String sParentName =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME);
			String sParentRevision =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV);
			String sParentType =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE); 
			//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
			boolean bHasOwnership = false;
			if(util.isModificatinRequired())
			{
				//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
				/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
					String sFormulaPropagate = util.getFormulaPropagate(context, sId);
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}

				}else {
					bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);
				}*/
				//Added by Ganesh start
				bHasOwnership = util.checkHasAccess(context, null, sId);
				//Added by Ganesh stop

				if(!bHasOwnership)
				{
					//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- START
					sId = ConstantsUtil.NO_ACCESS;
					/*sRevision = ConstantsUtil.NO_ACCESS;
					sReleaseDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sTitle = ConstantsUtil.NO_ACCESS;*/
					spgChg = ConstantsUtil.NO_ACCESS;
					/*sFN = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sQty = ConstantsUtil.NO_ACCESS;
					sBuom = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
					sCurrent = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					sOSPD = ConstantsUtil.NO_ACCESS;
					sDensityUOM = ConstantsUtil.NO_ACCESS;*/
					//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- END
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//sAlternate = ConstantsUtil.NO_ACCESS;
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
				}
				boolean bHasOwnershipParent = util.checkHasAccess(context, null, sParentId);
				if(!bHasOwnershipParent)
				{
					sParentId = ConstantsUtil.NO_ACCESS;
				}
			}
				else
				{
					//Added by Ganesh Start
					boolean showData = util.checkHasAccess(context, null, sId);
					if(!showData){
						sId = ConstantsUtil.NO_ACCESS;
						spgChg = ConstantsUtil.NO_ACCESS;
					}// Added by Ganesh Stop
					boolean showDataParent = util.checkHasAccess(context, null, sParentId);
					if(!showDataParent){
						sParentId = ConstantsUtil.NO_ACCESS;
					}
				}
			
			
		/*}else if(sec.isStaffAUGUser()) 
		{
			boolean showData = true;
			if(slHIRTypes.contains(sType) )
			{
				String sFormulaClassif =strClassFied;
				if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) 
				{
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}
				}
			}

			if(!showData){
				sId = ConstantsUtil.NO_ACCESS;
				spgChg = ConstantsUtil.NO_ACCESS;
			}
		} else
		{
			boolean showData = true;
			if(slHIRTypes.contains(sType))
			{
				String sFormulaClassif =strClassFied;

				if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
					sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
					showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
				}else {
					showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
				}
			}else{
				showData=true;
			}
				if(!showData){
					sId = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					Revision = ConstantsUtil.NO_ACCESS;
					sReleaseDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sTitle = ConstantsUtil.NO_ACCESS;
					sFN = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					//Req 33193 - 3 columns to be displayed for users with Business Use / Restricted access
					//sQty = ConstantsUtil.NO_ACCESS;
					//sBuom = ConstantsUtil.NO_ACCESS;
					//sCurrent = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;

				}
			}

			if (isModificatinRequired()) {

				boolean bHasOwnership = checkOwnerShip(context, slUserOwnership, sId);

				if (!bHasOwnership) {

					sId = ConstantsUtil.NO_ACCESS;
					sRevision = ConstantsUtil.NO_ACCESS;
					sReleaseDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sTitle = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					sFN = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sQty = ConstantsUtil.NO_ACCESS;
					sBuom = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
					sCurrent = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;

				}
			}*/
			// SPEC: <01.13.2021>: Sumit Uncommented for Defect :36642 - START

			util.formatData(sbEBOMName, sName);
			util.formatData(sbEBOMId, sId);
			util.formatData(sbEBOMChg, spgChg);
			util.formatData(sbEBOMFN, sFN);
			util.formatData(sbEBOMTitle, sTitle);
			util.formatData(sbEBOMType, sType);
			util.formatData(sbEBOMQTY, sQty);
			util.formatData(sbEBOMBuom, sBuom);
			util.formatData(sbEBOMCommnts, sComments);
			util.formatData(sbEBOMState, sCurrent);
			util.formatData(sbEBOMStage, sStage);
			util.formatData(sbEBOMRDOC, sRDOC);
			util.formatData(sbEBOMRevRelDt, sRevRelease);
			//util.formatData(sbEBOMAlternate, sAlternate);
			util.formatData(sbEBOMOSPD, sOSPD);
			util.formatData(sbEBOMDensityUOM, sDensityUOM);
			
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
			util.formatData(sbEBOMSubstitutePart, strSubPart);
			util.formatData(sbEBOMSubPartID, strSubPartId);
			util.formatData(sbEBOMSubPartType, strSubPartType);
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
			//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
			util.formatData(sbFEBOMParentName, sParentName);
			util.formatData(sbFEBOMParentREV, sParentRevision);
			util.formatData(sbFEBOMParentId, sParentId);
			sParentType = util.mapType(sParentType);
			util.formatData(sbFEBOMParentType, sParentType);
			//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
			if (null != sTupName && !sTupName.isEmpty()) {
				util.formatData(sbEBOMTupName, sTupName);
			}
			// SPEC: <01.13.2021>: Sumit Uncommented for Defect :36642 - ENDS

		}
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlternate.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDensityUOM.toString());
		if (null != sbEBOMTupName && sbEBOMTupName.length() > 0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
						
			//SPEC: Added by Ketan for req no. 41754 on 06.16.2022 -- END
			//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbFEBOMParentId.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbFEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbFEBOMParentREV.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbFEBOMParentType.toString());	
			//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
		// return filterMapList(mpEBOMResult);

		return mpEBOMResult;
	}

	
	public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
	{
    	StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
    	try {
			Iterator objectListItr = mapList.iterator();
			
			StringBuilder sbEBOMName = new StringBuilder();
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentRev = new StringBuilder();
			StringBuilder sbEBOMParentTitle = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			StringBuilder sbEBOMRefDoc= new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMCommnts = new StringBuilder();
			StringBuilder sbEBOMSubType= new StringBuilder();
			StringBuilder sbEBOMEffectDate= new StringBuilder();
			StringBuilder sbEBOMUntilDate= new StringBuilder();
			StringBuilder sbEBOMCobNum= new StringBuilder();
			StringBuilder sbEBOMChildRev= new StringBuilder();
			StringBuilder sbEBOMRevRelDt= new StringBuilder();
			StringBuilder sbEBOMSubFor= new StringBuilder();
			StringBuilder sbEBOMParentType = new StringBuilder();
			StringBuilder sbEBOMChg = new StringBuilder();
			StringBuilder sbEBOMSFSubType= new StringBuilder();
			
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				boolean showData = false;
				boolean bHasOwnership=false;
				
				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
				if(null!=objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
	
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
					//String
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
						
						String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
						
						//SPEC: <11.19.2020>: Chandra Modified for Defect :37446 ## --START
						//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
						boolean bChildHasAccess =util.checkHasAccess(context, sct.getUserType(),sChildId);
						//SPEC: <11.19.2020>: Chandra Modified for Defect :37446 ## --END
						
						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- START
						sReleaseDate =validator.DateFormatter(sReleaseDate);
						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- END
						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						
						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));

						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//	String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						String sChildTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
						
						String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						
						//Added for Defect# 37591 -- START
						//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
						String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
						//Added for Defect# 37591 -- END
						
						String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
						String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
						String sEffectvityDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY)));
						String sUntilDate=validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END
						
						String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
						sOC = util.replaceSpecialSymbols(sOC);
						String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
						
						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
						
						if(!bChildHasAccess) {
							sChildId    = ConstantsUtil.NO_ACCESS;
							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
							sChg = ConstantsUtil.NO_ACCESS;
							//sChildTitle = ConstantsUtil.NO_ACCESS;
							//sChildRev = ConstantsUtil.NO_ACCESS;
							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
						}
						
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						 //Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
	  						 showData = util.checkHasAccess(context,null,sParentID);
	  						
	  						 
						
						/*if(util.isModificatinRequired())
						{
							SecurityService sec = new SecurityService();
							String sComp = sec.getUserCauthorities();
							StringList slUserOwnership=util.filterOwnerShip(sComp);
							
							String sFormulaPropagate = sParentID;
							if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
							}
							
							if(!sFormulaPropagate.isEmpty()) {
								bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
							}
							
							if(!bHasOwnership)
							{
								sParentType = ConstantsUtil.NO_ACCESS;
								sParentID = ConstantsUtil.NO_ACCESS;
								//sChildId    = ConstantsUtil.NO_ACCESS;
								sParentName = ConstantsUtil.NO_ACCESS;
								sParentRev = ConstantsUtil.NO_ACCESS;
								sParentTitle = ConstantsUtil.NO_ACCESS;
								sCombinationNum = ConstantsUtil.NO_ACCESS;
								//sChildTitle = ConstantsUtil.NO_ACCESS;
								sSUBType = ConstantsUtil.NO_ACCESS;
								sEffectvityDate = ConstantsUtil.NO_ACCESS;
								sRevRelease = ConstantsUtil.NO_ACCESS;
								sUntilDate = ConstantsUtil.NO_ACCESS;
								sRDOC = ConstantsUtil.NO_ACCESS;
								sQTY = ConstantsUtil.NO_ACCESS;
								sBASEUOM = ConstantsUtil.NO_ACCESS;
								//sChildRev = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								sSFSubType = ConstantsUtil.NO_ACCESS;
						    }
						}else if(sct.isStaffAUGUser()) {
							
							if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}
						}else {
							StringList slHIRTypes = new StringList();
							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
							slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
							
							if(slHIRTypes.contains(sParentType)) {
								if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
								}
							}else {
								showData=true;
							}
							
							
						}*/
						
	  						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END
						if(!showData){
							sParentID = ConstantsUtil.NO_ACCESS;
							//sChildId    = ConstantsUtil.NO_ACCESS;
							/*sParentType = ConstantsUtil.NO_ACCESS;
							sParentID = ConstantsUtil.NO_ACCESS;
							sChildId    = ConstantsUtil.NO_ACCESS;
							//sParentName = ConstantsUtil.NO_ACCESS;
							//sParentRev = ConstantsUtil.NO_ACCESS;
							sParentTitle = ConstantsUtil.NO_ACCESS;
							sCombinationNum = ConstantsUtil.NO_ACCESS;
							sChildTitle = ConstantsUtil.NO_ACCESS;
							sSUBType = ConstantsUtil.NO_ACCESS;
							sEffectvityDate = ConstantsUtil.NO_ACCESS;
							sRevRelease = ConstantsUtil.NO_ACCESS;
							sUntilDate = ConstantsUtil.NO_ACCESS;
							sRDOC = ConstantsUtil.NO_ACCESS;
							sComments = ConstantsUtil.NO_ACCESS;*/
						}
					
						sChildType = util.mapType(sChildType);
	
						util.formatData(sbEBOMName,sChildName);
						util.formatData(sbEBOMType,sChildType);
						util.formatData(sbEBOMQTY,sQTY);
						util.formatData(sbEBOMBuom,sBASEUOM);
						util.formatData(sbEBOMChildRev,sChildRev);
						
						util.formatData(sbEBOMParentType,sParentType);
						util.formatData(sbEBOMParentId,sParentID);
						util.formatData(sbEBOMId,sChildId);
						util.formatData(sbEBOMParentName,sParentName);
						util.formatData(sbEBOMParentRev,sParentRev);
						util.formatData(sbEBOMParentTitle,sParentTitle);
						util.formatData(sbEBOMCobNum,sCombinationNum);
						util.formatData(sbEBOMTitle,sChildTitle);
						util.formatData(sbEBOMSubType,sSUBType);
						util.formatData(sbEBOMRevRelDt,sRevRelease);
						util.formatData(sbEBOMEffectDate,sEffectvityDate);
						util.formatData(sbEBOMUntilDate,sUntilDate);
						util.formatData(sbEBOMRefDoc,sRDOC);
						util.formatData(sbEBOMCommnts,sComments);
						util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
					
						util.formatData(sbEBOMChg,sChg);
						util.formatData(sbEBOMSFSubType,sSFSubType);
					//}
					}
				}else {
					//StringList
					String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
					//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
					//String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
					String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					
					String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
					String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					
					 //Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
						 showData = util.checkHasAccess(context,null,sParentID);
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						for(int i =0; i<slChildId.size(); i++) {
							String sEachChildId = slChildId.getElement(i);
//							DomainObject doEachChild = new DomainObject(sEachChildId);
//							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//							StringList slSelect = new StringList();
//							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//							Map mpIpClass = doEachChild.getInfo(context, slSelect);
//							StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//							StringsIpClass = doEachChild.getInfo(contexts"to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
//							DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
							
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
							//Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
							//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
  							boolean 	bChildHasAccess = util.checkHasAccess(context,null,sEachChildId);
					
 	  						 
							/*if(util.isModificatinRequired())
							{
								SecurityService sec = new SecurityService();
								String sComp = sec.getUserCauthorities();
								StringList slUserOwnership=util.filterOwnerShip(sComp);
								
								String sFormulaPropagate = sParentID;
								if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
								}
								
								if(!sFormulaPropagate.isEmpty()) {
									bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
								}
								
								if(bHasOwnership)
								{
									showData=true;
							    }
							}else if(sct.isStaffAUGUser()) {
								if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
								}
								
							}else {
								StringList slHIRTypes = new StringList();
								slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
								slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
								slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
								if(slHIRTypes.contains(slChildType.getElement(i))) {
									if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
										showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
									}else {
										showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
									}
								}else {
									showData=true;
								}
								
							}*/
							
  							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
							
							/*if(!showData) {
								sEachChildId=ConstantsUtil.NO_ACCESS;
							}*/
							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							//Modified for Defect# 37591 -- START
  							//StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
  							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  							//Modified for Defect# 37591 -- END
							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
							StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
							StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
							String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = slRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
							
							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
							StringList sSFSubType = (StringList) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							
							if(bChildHasAccess) {
								String sChildType = util.mapType(slChildType.get(i));
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMId,sEachChildId);
								util.formatData(sbEBOMTitle,slChildTitle.get(i));
								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
  								util.formatData(sbEBOMChg,sChg.get(i));
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
							}
							else
							{
								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
								/*//String sChildType = util.mapType(slChildType.get(i));
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMChildRev,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
								*/
								
								String sChildType = util.mapType(slChildType.get(i));
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMTitle,slChildTitle.get(i));
  								util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
  							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
  								
							}
							
							if(showData) {
								//String sChildType = util.mapType(slChildType.get(i));
								//formatData(sbEBOMName,slChildName.get(i));
								//formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMQTY,slQTY.get(i));
								util.formatData(sbEBOMBuom,slBASEUOM.get(i));
								//formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMParentType,sParentType);
								util.formatData(sbEBOMParentId,sParentID);
								//formatData(sbEBOMId,sEachChildId);
								util.formatData(sbEBOMParentName,sParentName);
								util.formatData(sbEBOMParentRev,sParentRev);
								util.formatData(sbEBOMParentTitle,sParentTitle);
								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
								//formatData(sbEBOMTitle,slChildTitle.get(i));
								util.formatData(sbEBOMSubType,slSUBType.get(i));
								util.formatData(sbEBOMRevRelDt,sRevRelease);
								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
								util.formatData(sbEBOMUntilDate,validator.DateFormatter(slUntilDate.get(i)));
								util.formatData(sbEBOMRefDoc,sRDOC);
								util.formatData(sbEBOMCommnts,slComments.get(i));
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								util.formatData(sbEBOMSFSubType,sSFSubType.get(i));
							}else {
								//String sChildType = util.mapType(slChildType.get(i));
								//formatData(sbEBOMName,slChildName.get(i));
								//formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMQTY,slQTY.get(i));
								util.formatData(sbEBOMBuom,slBASEUOM.get(i));
								//formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMParentType,sParentType);
								util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
								//util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMParentName,sParentName);
								util.formatData(sbEBOMParentRev,sParentRev);
								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
								/*util.formatData(sbEBOMParentTitle,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMCobNum,ConstantsUtil.NO_ACCESS);
								//formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMSubType,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMRevRelDt,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMEffectDate,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMUntilDate,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMRefDoc,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMCommnts,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMSFSubType,ConstantsUtil.NO_ACCESS);*/
								
								util.formatData(sbEBOMParentTitle,sParentTitle);
								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
								//formatData(sbEBOMTitle,slChildTitle.get(i));
								util.formatData(sbEBOMSubType,slSUBType.get(i));
								util.formatData(sbEBOMRevRelDt,sRevRelease);
								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
								util.formatData(sbEBOMUntilDate,validator.DateFormatter(slUntilDate.get(i)));
								util.formatData(sbEBOMRefDoc,sRDOC);
								util.formatData(sbEBOMCommnts,slComments.get(i));
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								util.formatData(sbEBOMSFSubType,sSFSubType.get(i));
								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
								
							}
						}
					}
				}
				}

			}
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
    	}catch(Exception e) {
    		LOGGER.error("EXCEPTION IN MasterCOPBO : parseSubstitute: "+e);
    	}
		return util.filterMapList(mpEBOMResult);
	}
	 /*public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
		{
	    	StringValidatorUtil validator = new StringValidatorUtil();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
	    	try {
				Iterator objectListItr = mapList.iterator();
				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMParentName = new StringBuilder();
				StringBuilder sbEBOMParentRev = new StringBuilder();
				StringBuilder sbEBOMParentTitle = new StringBuilder();
				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMParentId = new StringBuilder();
				StringBuilder sbEBOMRefDoc= new StringBuilder();
				StringBuilder sbEBOMTitle = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMQTY = new StringBuilder();
				StringBuilder sbEBOMBuom = new StringBuilder();
				StringBuilder sbEBOMCommnts = new StringBuilder();
				StringBuilder sbEBOMSubType= new StringBuilder();
				StringBuilder sbEBOMEffectDate= new StringBuilder();
				StringBuilder sbEBOMUntilDate= new StringBuilder();
				StringBuilder sbEBOMCobNum= new StringBuilder();
				StringBuilder sbEBOMChildRev= new StringBuilder();
				StringBuilder sbEBOMRevRelDt= new StringBuilder();
				StringBuilder sbEBOMSubFor= new StringBuilder();
				StringBuilder sbEBOMParentType = new StringBuilder();
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMSFSubType= new StringBuilder();
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					boolean showData = false;
					boolean bHasOwnership=false;
					
					String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
					if(null!=objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
		
					String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
					if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
						//String
						if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
							String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
							String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
							String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
							String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
							String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
							String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
							String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
							
							String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
							String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
							String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
							String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
							String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
							String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
							String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
							String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
							String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
							String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
							
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
							String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							
							if(util.isModificatinRequired())
							{
								SecurityService sec = new SecurityService();
								String sComp = sec.getUserCauthorities();
								StringList slUserOwnership=util.filterOwnerShip(sComp);
		
								bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sChildId);
							
								if(!bHasOwnership)
								{
									sParentType = ConstantsUtil.NO_ACCESS;
									sParentID = ConstantsUtil.NO_ACCESS;
									sChildId    = ConstantsUtil.NO_ACCESS;
									sParentName = ConstantsUtil.NO_ACCESS;
									sParentRev = ConstantsUtil.NO_ACCESS;
									sParentTitle = ConstantsUtil.NO_ACCESS;
									sCombinationNum = ConstantsUtil.NO_ACCESS;
									sChildTitle = ConstantsUtil.NO_ACCESS;
									sSUBType = ConstantsUtil.NO_ACCESS;
									sEffectvityDate = ConstantsUtil.NO_ACCESS;
									sRevRelease = ConstantsUtil.NO_ACCESS;
									sUntilDate = ConstantsUtil.NO_ACCESS;
									sRDOC = ConstantsUtil.NO_ACCESS;
									sQTY = ConstantsUtil.NO_ACCESS;
									sBASEUOM = ConstantsUtil.NO_ACCESS;
									sChildRev = ConstantsUtil.NO_ACCESS;
									
									
							    }
							}else if(sct.isStaffAUGUser()) {
								
								if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sChildId);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
								}
							}else {
								StringList slHIRTypes = new StringList();
								slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
								slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
								
								if(slHIRTypes.contains(sChildType)) {
									showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
								}else {
									showData=true;
								}
								
							}
							
							if(!showData){
								sParentID = ConstantsUtil.NO_ACCESS;
								sChildId    = ConstantsUtil.NO_ACCESS;
								/*sParentType = ConstantsUtil.NO_ACCESS;
								sParentID = ConstantsUtil.NO_ACCESS;
								sChildId    = ConstantsUtil.NO_ACCESS;
								//sParentName = ConstantsUtil.NO_ACCESS;
								//sParentRev = ConstantsUtil.NO_ACCESS;
								sParentTitle = ConstantsUtil.NO_ACCESS;
								sCombinationNum = ConstantsUtil.NO_ACCESS;
								sChildTitle = ConstantsUtil.NO_ACCESS;
								sSUBType = ConstantsUtil.NO_ACCESS;
								sEffectvityDate = ConstantsUtil.NO_ACCESS;
								sRevRelease = ConstantsUtil.NO_ACCESS;
								sUntilDate = ConstantsUtil.NO_ACCESS;
								sRDOC = ConstantsUtil.NO_ACCESS;
								sComments = ConstantsUtil.NO_ACCESS;*/
							/*}
						
							sChildType = util.mapType(sChildType);
		
							util.formatData(sbEBOMName,sChildName);
							util.formatData(sbEBOMType,sChildType);
							util.formatData(sbEBOMQTY,sQTY);
							util.formatData(sbEBOMBuom,sBASEUOM);
							util.formatData(sbEBOMChildRev,sChildRev);
							
							util.formatData(sbEBOMParentType,sParentType);
							util.formatData(sbEBOMParentId,sParentID);
							util.formatData(sbEBOMId,sChildId);
							util.formatData(sbEBOMParentName,sParentName);
							util.formatData(sbEBOMParentRev,sParentRev);
							util.formatData(sbEBOMParentTitle,sParentTitle);
							util.formatData(sbEBOMCobNum,sCombinationNum);
							util.formatData(sbEBOMTitle,sChildTitle);
							util.formatData(sbEBOMSubType,sSUBType);
							util.formatData(sbEBOMRevRelDt,sRevRelease);
							util.formatData(sbEBOMEffectDate,sEffectvityDate);
							util.formatData(sbEBOMUntilDate,sUntilDate);
							util.formatData(sbEBOMRefDoc,sRDOC);
							util.formatData(sbEBOMCommnts,sComments);
							util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							util.formatData(sbEBOMChg,sChg);
							util.formatData(sbEBOMSFSubType,sSFSubType);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
						//}
						}
					} else {
						//StringList
						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
						String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
							StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
							for(int i =0; i<slChildId.size(); i++) {
								String sEachChildId = slChildId.getElement(i);
								DomainObject doEachChild = new DomainObject(sEachChildId);
								DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
								StringList slSelect = new StringList();
								slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
								Map mpIpClass = doEachChild.getInfo(context, slSelect);
								StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
								//String sIpClass = doEachChild.getInfo(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
								DomainConstants.MULTI_VALUE_LIST.remove("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
								StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
								if(util.isModificatinRequired())
								{
									SecurityService sec = new SecurityService();
									String sComp = sec.getUserCauthorities();
									StringList slUserOwnership=util.filterOwnerShip(sComp);
		
									bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sEachChildId);
									if(bHasOwnership)
									{
										showData=true;
								    }
								}else if(sct.isStaffAUGUser()) {
									if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										String sFormulaClassif = util.getFormulaPropagateClassification(context, sEachChildId);
										showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
									}else {
										showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
									}
								}else {
									StringList slHIRTypes = new StringList();
									slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
									slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
									slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
									slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
									if(slHIRTypes.contains(slChildType.getElement(i))) {
										showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
									}else {
										showData=true;
									}
								}
								
								if(!showData) {
									sEachChildId=ConstantsUtil.NO_ACCESS;
								}
								StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
								StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
								StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
								StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
								//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
								StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
								StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
								StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
								StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
								StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
								String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
								StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
								String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
								sOC = util.replaceSpecialSymbols(sOC);
								String sRDOC = slRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
								StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
								StringList sSFSubType = (StringList) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
								
								if(showData) {
									String sChildType = util.mapType(slChildType.get(i));
									util.formatData(sbEBOMName,slChildName.get(i));
									util.formatData(sbEBOMType,sChildType);
									util.formatData(sbEBOMQTY,slQTY.get(i));
									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
									util.formatData(sbEBOMChildRev,slChildRev.get(i));
									util.formatData(sbEBOMParentType,sParentType);
									util.formatData(sbEBOMParentId,sParentID);
									util.formatData(sbEBOMId,sEachChildId);
									util.formatData(sbEBOMParentName,sParentName);
									util.formatData(sbEBOMParentRev,sParentRev);
									util.formatData(sbEBOMParentTitle,sParentTitle);
									util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
									util.formatData(sbEBOMTitle,slChildTitle.get(i));
									util.formatData(sbEBOMSubType,slSUBType.get(i));
									util.formatData(sbEBOMRevRelDt,sRevRelease);
									util.formatData(sbEBOMEffectDate,slEffectvityDate.get(i));
									util.formatData(sbEBOMUntilDate,slUntilDate.get(i));
									util.formatData(sbEBOMRefDoc,sRDOC);
									util.formatData(sbEBOMCommnts,slComments.get(i));
									util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
									util.formatData(sbEBOMChg,sChg.get(i));
									util.formatData(sbEBOMSFSubType,sSFSubType.get(i));
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
								}else {
									String sChildType = util.mapType(slChildType.get(i));
									util.formatData(sbEBOMName,slChildName.get(i));
									util.formatData(sbEBOMType,sChildType);
									util.formatData(sbEBOMQTY,slQTY.get(i));
									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
									util.formatData(sbEBOMChildRev,slChildRev.get(i));
									util.formatData(sbEBOMParentType,sParentType);
									util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMParentName,sParentName);
									util.formatData(sbEBOMParentRev,sParentRev);
									util.formatData(sbEBOMParentTitle,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMCobNum,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMSubType,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMRevRelDt,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMEffectDate,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMUntilDate,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMRefDoc,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMCommnts,ConstantsUtil.NO_ACCESS);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
									util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMSFSubType,ConstantsUtil.NO_ACCESS);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
									util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								}
							}
						}
					}
					}

				}
				mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
				mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
				mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
				mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
				mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
				mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
	    	}catch(Exception e) {
	    		LOGGER.info("EXCEPTION IN CommonBusUtilBO : parseSubstitute: "+e);
	    	}
	    	//return mpEBOMResult;
			return util.filterMapList(mpEBOMResult);
		}*/
	
	public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		
		StringBuilder sbDescription = new StringBuilder();
		StringBuilder sbInHerType = new StringBuilder();
		boolean showData = false;
		
		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;
		
		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
			sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		}

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		
		StringList slRelSelects = new StringList();
		slRelSelects.add(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
					slPartSpecSelects, slRelSelects, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				
				String strInHerType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE));
				
				//commented by Ganesh for security implementation start
				/*if (util.isModificatinRequired()) {
					if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {

						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								
								
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteString(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
								
								sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
							}

						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}

					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = util.updateReferences(context, strId);
								LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

									
									sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
								}
							}
						}else
						{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

							sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
							
						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					}

				} else {
					if(sct.isStaffAUGUser()) {
						
						if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else if("ArtiosCAD Component".equalsIgnoreCase(strType)){
							showData=util.checkInternalUserAcess(sUserlicense,strAutocadClassFied);
						}else{
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
						
						if(slHIRTypes.contains(strType)) {
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}else {
							showData=true;
						}
						
					}
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						//temporary fix to prevent users from downloading a Physical product(VPMReference)
						if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
							sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
						}else {
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						}
						
						sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
						
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					}

					
				}*/
				//Added by Ganesh start
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
String strId_Result = strId;
if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
strId_Result=ConstantsUtil.NO_ACCESS;
}

//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END

				showData = util.checkHasAccess(context, sUserType, strId);
				if (showData) {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
					String strTitle = validator.getStringEquivalentForSubstituteString(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
					String strOrig = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
					sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
					//temporary fix to prevent users from downloading a Physical product(VPMReference)
					if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
						sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
					}else {
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
/*String strState = validator
.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
					}
					
					sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
					
				} else {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

				}

				//Added by Ganesh stop

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
				mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
				mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			}
			
			mpFinalList.put(ConstantsUtil.INHERITANCETYPE, sbInHerType.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Exception in MasterCOPBO getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}
	
	
	 public Map updatePartSpec(Context context, Map objectMap) {
			StringValidatorUtil validator = new StringValidatorUtil();
			Map<String, String> mpPartSpecs = new HashMap<String, String>();
			try {

				String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
						? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
						String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
								? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

								mpPartSpecs = getPartSpecifications(context, sType, sID);
			} catch (Exception e) {
				LOGGER.error("Exception in Program : MasterCOPBO Method :updatePartSpec " + e);
				return new HashMap();

			}
			return util.filterMapList(mpPartSpecs);
		}
	 
	 public StringList createSelects(String... selects) {
			StringList selectList = new StringList();
			for (String select : selects) {
				selectList.add(select);
			}
			return selectList;
		}
	 
	 public MapList getPath(MapList ml, String masterPartName, String masterPartRev) {
			Iterator objectListItr = ml.iterator();
			MapList mlFinalList = new MapList();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String path = masterPartName + " " + masterPartRev;
				objectMap.put(ConstantsUtil.PATH, path);
				mlFinalList.add(objectMap);
			}
			return mlFinalList;
		}
	 
	
	 
	 
	 public MapList getExtendedPerformChar(Context context, DomainObject doFop, String sRevision, String sName,
				Map resultMaps) {
			MapList mlPerformChars = new MapList();
			try {
				StringList objectSelects = createSelects(ConstantsUtil.SELECT_ID, ConstantsUtil.SELECT_NAME,
						 ConstantsUtil.STR_REF_DOC_IPCLASS,
						ConstantsUtil.SELECT_REVISION, ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC,
						ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING, ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP,
						ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING,
						ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING,
						ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM,
						ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT,
						ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT,
						ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET, ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET,
						ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET,
						ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT,
						ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT,
						ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE, ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST,
						ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE, ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA,
						ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED, ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR,
						ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS, ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP,
						ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION, ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS,
						ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER, ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN,
						ConstantsUtil.SELECT_NAME, ConstantsUtil.SELECT_TYPE, ConstantsUtil.STR_REF_DOC,
						ConstantsUtil.SELECT_REF_DOC_TO_ID, ConstantsUtil.SELECT_REF_DOC_TO_IPCLASS,
						ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS, ConstantsUtil.SELECT_REF_DOC_TO_TYPE,
						ConstantsUtil.TITLE, ConstantsUtil.PERFORMCHAR_ID, ConstantsUtil.PERFORMCHAR_TYPE,
						ConstantsUtil.STR_PARTFAMILY_TITLE, ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS,
						ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE, ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC,
						ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE,
						ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE, ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				StringList relSelects = createSelects(ConstantsUtil.SELECT_RELATIONSHIP_ID,
						ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,
						ConstantsUtil.SELECT_ATTRIBUTE_PGINHERITANCETYPE);
				String typePattern = ConstantsUtil.TYPE__PERFORMANCE_CHAR + "," + ConstantsUtil.TYPE_NOTES_CHAR + ","
						+ ConstantsUtil.TYPE_PACKING_UNIT_CHAR;
				mlPerformChars = doFop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EXTENDEDDATA,
						ConstantsUtil.TYPE__PERFORMANCE_CHAR, objectSelects, relSelects, false, true, (short) 0, null, null,
						0);

				if (mlPerformChars.isEmpty()) {
					return new MapList();
				}

				mlPerformChars = getPath(mlPerformChars, sName, sRevision);

			} catch (Exception e) {
				LOGGER.error("Unable to MasterCOPBO : getExtendedPerformChar " + e);
				return new MapList();
			}

			// return updatePerformCharcteristic(context,mlPerformChars,resultMaps);

			return mlPerformChars;
		}
	/*//SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- START
	 public Map getCOName(Context context, String[]changeargs) throws Exception{
			Map mpLifecycle= new HashMap();
			StringValidatorUtil validator = new StringValidatorUtil();

			StringList slObjectSelects = new StringList();
			slObjectSelects.addElement(ConstantsUtil.REL_TASK_NAME);
			slObjectSelects.addElement(ConstantsUtil.REL_TASK_ID);
			slObjectSelects.addElement(ConstantsUtil.REL_TASK_TITLE);
			slObjectSelects.addElement(ConstantsUtil.REL_TASK_APPROVER);
			slObjectSelects.addElement(ConstantsUtil.REL_TASK_STATUS);
			slObjectSelects.addElement(ConstantsUtil.REL_TASK_COMPL_DATE);
			slObjectSelects.addElement(ConstantsUtil.SO_APPROVER_NAME);
			slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_STATUS);
			slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_DATE);
			slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_TITLE);
			slObjectSelects.addElement(ConstantsUtil.REL_TASK_COMMENTS);

			StringBuilder sbCOName= new StringBuilder();
			StringBuilder sbTaskName = new StringBuilder();			
			StringBuilder sbTaskApprover = new StringBuilder();
			StringBuilder sbTaskApproverFullName = new StringBuilder();
			StringBuilder sbTaskTitle = new StringBuilder();			
			StringBuilder sbTaskStatus = new StringBuilder();			
			StringBuilder sbTaskCompletionDate = new StringBuilder();
			StringBuilder sbTaskId = new StringBuilder();
			StringBuilder sbTaskComments = new StringBuilder();

			String sCAName = ConstantsUtil.EMPTY_STRING;
			String sCAId = ConstantsUtil.EMPTY_STRING;
			String sCOName = ConstantsUtil.EMPTY_STRING;
			try {
				if (UIUtil.isNullOrEmpty(changeargs[1])) {
					return new HashMap();
				}
				String sQuery =BusExtractUtil.createQueryPath(changeargs[1]);
				String sQueryResult =BusExtractUtil.executeTempQuery(context,sQuery);

				if(UIUtil.isNullOrEmpty(sQueryResult)){
					return new HashMap();
				}
				String[] sQueResult = sQueryResult.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

				if (sQueResult.length > 2) {
					sCAName = sQueResult[1];
					sCAId = sQueResult[2];
				}

				if (sQueResult.length > 3) {
					sCOName = sQueResult[3];
				}

				if (UIUtil.isNotNullAndNotEmpty(sCAId)) {

					DomainObject domChangeAction = new DomainObject(sCAId);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_NAME);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_ID);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_TITLE);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_APPROVER);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_STATUS);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_COMPL_DATE);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_COMMENTS);

					Map mapCAInfo = domChangeAction.getInfo(context, slObjectSelects);

					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_ID);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_TITLE);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_APPROVER);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_STATUS);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_COMPL_DATE);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_COMMENTS);

					if (mapCAInfo.isEmpty()) {
						return new HashMap();
					}
					sbTaskName
					.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_NAME)));
					sbTaskId.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_ID)));
					sbTaskTitle.append(
							validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_TITLE)));
					sbTaskStatus.append(
							validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_STATUS)));
					sbTaskApprover.append(
							validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_APPROVER)));
					sbTaskComments.append(
							validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_COMMENTS)));
					
					String sApproverName = validator
							.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVER_NAME));
					String sApprovalStatus = validator
							.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_STATUS));

					if (sApprovalStatus.equalsIgnoreCase(ConstantsUtil.TRUE)
							|| sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
						sApprovalStatus = ConstantsUtil.APPROVED;
					} else if (sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_FALSE)
							|| sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
						sApprovalStatus = ConstantsUtil.IGNORED;
					} else {
						sApprovalStatus = "";

					}

					String sApprovedDate = validator
							.isNotNullOrEmpty((String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_DATE))
							? (String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_DATE) : ConstantsUtil.EMPTY_STRING;
							String sApprovalTitle = validator
									.isNotNullOrEmpty((String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE))
									? (String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE) : ConstantsUtil.EMPTY_STRING;

									sbTaskName.append(ConstantsUtil.SYMBL_PIPE);
									sbTaskName.append(ConstantsUtil.SO_APPROVAL_SIGNATURE);

									sbTaskStatus.append(ConstantsUtil.SYMBL_PIPE);
									sbTaskStatus.append(sApprovalStatus);
									sbTaskTitle.append(ConstantsUtil.SYMBL_PIPE);
									sbTaskTitle.append(sApprovalTitle);

									// For eliminating the SO Approver name in Ownership
									mpLifecycle.put(ConstantsUtil.APPROVER_FULLNAME, sbTaskApprover.toString());

									sbTaskApprover.append(ConstantsUtil.SYMBL_PIPE);
									sbTaskApprover.append(sApproverName);

									StringList slTaskApproverFullName = util.getPersonFullName(context, sbTaskApprover);

									// slTaskApprover.remove(sApproverName);
									StringBuilder sbTaskStatusRendered = util.MapSlType(sbTaskStatus);

									StringList slTaskCompletionDate = validator
											.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_COMPL_DATE));
									slTaskCompletionDate.add(sApprovedDate);

									String strTaskApproverFullName = validator.isNotNullOrEmpty(slTaskApproverFullName.toString())
											? slTaskApproverFullName.toString() : ConstantsUtil.EMPTY_STRING;
											String strTaskCompletionDate = validator.isNotNullOrEmpty(slTaskCompletionDate.toString())
													? slTaskCompletionDate.toString() : ConstantsUtil.EMPTY_STRING;

													strTaskApproverFullName = util.replaceSpecialSymbols(strTaskApproverFullName);
													strTaskCompletionDate = util.replaceSpecialSymbols(strTaskCompletionDate);
													
													//SPEC: 15/01/2021: Added for 18x.5 DEV -- START
													String strApprovalFinalDueDate = ConstantsUtil.EMPTY_STRING;
													String strApprovalDueDate = ConstantsUtil.EMPTY_STRING;
													StringList slTaskApprovalDueDate = new StringList();
													if (UIUtil.isNotNullAndNotEmpty(strTaskCompletionDate)) {
														if (strTaskCompletionDate.contains(ConstantsUtil.SYMBL_PIPE)) {
															slTaskApprovalDueDate = FrameworkUtil.split(strTaskCompletionDate, ConstantsUtil.SYMBL_PIPE);
															for (int k = 0; k < slTaskApprovalDueDate.size(); k++) {
																strApprovalDueDate = (String) slTaskApprovalDueDate.get(k);																
																strApprovalDueDate = validator.DateFormatter(strApprovalDueDate);																
																strApprovalFinalDueDate += strApprovalDueDate+ConstantsUtil.SYMBL_PIPE;
															}															
															strApprovalFinalDueDate = strApprovalFinalDueDate.replace(ConstantsUtil.SYMBL_PIPE + ConstantsUtil.EMPTY_STRING, ConstantsUtil.SYMBL_PIPE);
															mpLifecycle.put(ConstantsUtil.APPROVALDATE, strApprovalFinalDueDate);	
														}
														else {
															strTaskCompletionDate = validator.DateFormatter(strTaskCompletionDate);
															mpLifecycle.put(ConstantsUtil.APPROVALDATE, strTaskCompletionDate);															
														}
													}
													//SPEC: 15/01/2021: Added for 18x.5 DEV -- END
													
													mpLifecycle.put(ConstantsUtil.NAME, sbTaskName.toString());
													mpLifecycle.put(ConstantsUtil.APPROVER, strTaskApproverFullName);

													mpLifecycle.put(ConstantsUtil.TITLE, sbTaskTitle.toString());
													mpLifecycle.put(ConstantsUtil.APPROVALSTATUS, sbTaskStatusRendered.toString());
													//mpLifecycle.put(ConstantsUtil.APPROVALDATE, strTaskCompletionDate);
													mpLifecycle.put(ConstantsUtil.CO, sCOName.trim() + ConstantsUtil.SYMBL_PIPE + sCAName.trim());
													mpLifecycle.put(ConstantsUtil.COMMENTS, sbTaskComments.toString());
				}

			} catch (Exception e) {
				LOGGER.info("Error in MasterCOPBO method getCOName " + e);
				return new HashMap();
			}
			return mpLifecycle;
		}
	//SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- END
*/	 public Map<String, String> updateSecurity(Context context,Map objectMap) {
			
			Map<String, String> mpSecurity = new HashMap<String, String>();
			StringValidatorUtil validator = new StringValidatorUtil();
			try
			{
				String sName=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME));
				String sHasClassAccess=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT));
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
				//String sLibrary=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME));
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
				String sCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE));
				String sType=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE));
				String sDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC));
				
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
				/*String Name[]=sName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
				String Library[]=sLibrary.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;*/
				
				/*if(!sName.isEmpty()){
					
					StringBuilder sbSecurityClasspath = new StringBuilder();
					
					for (int i = 0; i < Name.length; i++)
					{
						if(UIUtil.isNotNullAndNotEmpty(Name[i]) && UIUtil.isNotNullAndNotEmpty(Library[i]))
						{
							sbSecurityClasspath.append(Library[i]).append(ConstantsUtil.SYMBL_ARROW).append(Name[i]);
							mpSecurity.put(ConstantsUtil.CLASSPATH, sbSecurityClasspath.toString());
						}else
						{
							sbSecurityClasspath.append(ConstantsUtil.EMPTY_STRING);
						}
					}
				} */
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
				
				mpSecurity.put(ConstantsUtil.TYPE, sType);
				mpSecurity.put(ConstantsUtil.NAME, sName);
				mpSecurity.put(ConstantsUtil.STATE, sCurrent);
				mpSecurity.put(ConstantsUtil.DESCRIPTION, sDesc);
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
				//mpSecurity.put(ConstantsUtil.LIBRARY, sLibrary);
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
				mpSecurity.put(ConstantsUtil.HASCLASSACCESS, sHasClassAccess);
			
			}catch(Exception e){
				LOGGER.error("Error from CommonBusUtil: updateSecurity"+e);
				return new HashMap();
			}
			return  mpSecurity;
		}
	 
	 public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
	    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
	    	MapList mlIPCLass;
			try {
				mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
						null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
						ConstantsUtil.ZERO_LEVEL);
				Iterator itr = mlIPCLass.iterator();
				Map mpIpClass = new HashMap();
				StringBuilder sbIpName = new StringBuilder();
				StringBuilder sbHasClassAccess = new StringBuilder();
				StringBuilder sbIpType = new StringBuilder();
				StringBuilder sbIpDesc = new StringBuilder();
				StringBuilder sbIpState = new StringBuilder();
				StringBuilder sbIpLibrary = new StringBuilder();
				StringBuilder sbIpClassPath = new StringBuilder();
				
				while(itr.hasNext()) {
					mpIpClass = (Map)itr.next();
					String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
					sbIpName.append(sIpClassName);
					sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
					sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
					sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
					String strIpClass="";
					if(sIpClassName.contains(ConstantsUtil.HIR)) {
						strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
						sbIpLibrary.append(strIpClass);
					} else {
						strIpClass= ConstantsUtil.BUSINESS_USE;
						sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
					}
					if(!strIpClass.isEmpty()) {
						StringBuilder sbIpClassTemp = new StringBuilder();
						sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
						sbIpClassPath.append(sbIpClassTemp.toString());
					}
					
					//Compare user classification against IPName
					sbHasClassAccess.append("TRUE");
					
					if(itr.hasNext()) {
						sbIpName.append("|");
						sbIpType.append("|");
						sbIpDesc.append("|");
						sbIpState.append("|");
						sbIpLibrary.append("|");
						sbIpClassPath.append("|");
						sbHasClassAccess.append("|");
					}
				}
				mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
				mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
				mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
				mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
				//mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
				//mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
				mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
			} catch (FrameworkException e) {
				e.printStackTrace();
				LOGGER.error("Error from CommonBusUtil: getIpClass" + e);
			}
			return mpIpSecuritySetting;

	 }
	 
	 public boolean checkSubstituteHasAccess(Context context, Map objectMap) {
			
			StringBuilder  sbReturnVal = new StringBuilder();
			boolean showData = false;
			try
			{
				StringValidatorUtil validator = new StringValidatorUtil();
				
				StringList slHIRTypes = new StringList();
				slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
				slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				String sComp = sct.getUserCauthorities();
				StringList slUserOwnership=util.filterOwnerShip(sComp);
				
			if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))
				{
					String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName();
					if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
					{
						String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						String strSubPartId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						
						DomainObject doEachChild = new DomainObject(strSubPartId);
						DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						StringList slSelect = new StringList();
						slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						Map mpIpClass = doEachChild.getInfo(context, slSelect);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
						doEachChild.close(context);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
						//commented by Ganesh for security impl ---->start
						/*if(util.isModificatinRequired())
						{
							//For EBP User
							showData = util.checkOwnerShip(context, slUserOwnership, strSubPartId);
							
						}else if(sct.isStaffAUGUser())
						{
							//For Staff Aug USer check 
							if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								//Validation for Hir checks on Formulation
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else
							{
								//Validation for Hir checks for other than Formulation
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
						}else 
						{
							//For Internal User check
							if(slHIRTypes.contains(strSubPartType)) 
							{
								//Validation for Hir checks on Formulation
								if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else 
								{
									//Validation for Hir checks for other than Formulation
									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
								}
							}else 
							{
								//If it is Non-Hir we can show without checks for internal user
								showData=true;
							}
						}*/
						//commented by Ganesh for security impl ---->end
						//modified by Ganesh for security impl ---->start
						showData = util.checkHasAccess(context, null, strSubPartId);
						//modified by Ganesh for security impl ---->end
						
//							
					}//close for string
					}else
				{	//If no Substitue found
					return showData;
				}
				
			}catch(Exception e){
				
				LOGGER.error("Error from BusObjectAttribUtil :  checkSubstituteHasAccess" + e);
				return showData;
			}
			return showData;
		}
	 
	 
	 		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
			public static StringList getSecuritySelects(Context context) {
				
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
				slIpSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
				slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
				slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
				slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
				
				return slIpSelects;

			}
			//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
}