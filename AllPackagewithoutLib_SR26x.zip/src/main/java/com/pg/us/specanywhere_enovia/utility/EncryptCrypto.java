package com.pg.us.specanywhere_enovia.utility;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Properties;

public class EncryptCrypto {

	static int nLevel;
	
	public String encryptString(String strPassword) throws Exception {
		
		Properties props = new Properties();
		try (InputStream input = getClass().getClassLoader().getResourceAsStream("crypto.properties")) {
			if (input == null) {
				throw new FileNotFoundException("crypto.properties not found in classpath");
			}
			props.load(input);
			//nLevel=Integer.valueOf(props.getProperty("Level"));
			nLevel=Integer.valueOf("3");
			String strEncryptedPassword=strPassword;
		
			for (int keyCount=0; keyCount<nLevel; keyCount++)
			{
				strEncryptedPassword= CryptoUtil.encryptString(strEncryptedPassword,props.getProperty("SecretKey"+keyCount),"");
			}
			props.clear();
		
			return strEncryptedPassword;	
		} 
		catch (Exception e) {
			System.out.println("exception "+e.toString());
			throw new Exception(e);
		}
			
	}
	
	
	public String decryptString(String encryptedPassword) throws Exception{
		Properties props = new Properties();
		try (InputStream input = getClass().getClassLoader().getResourceAsStream("crypto.properties")) {
			if (input == null) {
				throw new FileNotFoundException("crypto.properties not found in classpath");
			}
			props.load(input);
			nLevel=Integer.valueOf("3");
			//nLevel = Integer.valueOf(props.getProperty("Level"));
			String strDecryptedPassword = encryptedPassword;
			for (int keyCount=nLevel-1; keyCount>=0; keyCount--)
			{
				strDecryptedPassword = CryptoUtil.decryptString(strDecryptedPassword,props.getProperty("SecretKey"+keyCount),"");				
			}
			return strDecryptedPassword;	
		}
		catch (Exception e) {
			System.out.println("exception "+e.toString());
			throw new Exception(e);
		}
	}

	public void generateKey() throws Exception 
	{
		Properties props = new Properties();
		try (InputStream input = getClass().getClassLoader().getResourceAsStream("crypto.properties")) {
			if (input == null) {
				throw new FileNotFoundException("crypto.properties not found in classpath");
			}
			props.load(input);
			String strInitialKey=props.getProperty("key");
			nLevel=Integer.valueOf(props.getProperty("Level"));
			props.clear();
						
			for(int keyCount=0; keyCount<nLevel; keyCount++)
			{
				props.setProperty("SecretKey"+keyCount,CryptoUtil.makeSecretKey(strInitialKey) );	
			}
			
			 FileOutputStream out = new FileOutputStream("crypto.properties", true);
		      props.store(out, null);
		      out.flush();
		      out.close();
		}
		catch (Exception e) {
			System.out.println("exception "+e.toString());
			throw new Exception(e);
		}
			
	}
	public static void main(String[] args) throws Exception {

		try {
			String strReturn = null;
			String generateKey = "Decrypt";
			String strPwd = "";
			String strEncryptedPwd = "NmvtmK+msqimkcKieutE6RXG+y1lrDuFbzYo4BNDliybhZmA6miXnlaERCCV9CTZkpjcNZppjZ0RLToWcyvNn+8PmUXwGR/kWxMb2hdqCQroCiPwCkxSjDg9yrwNnuZzrCrffP2MjPP4hszHUI1f5Z3Mhf7X5mbmNaq4GPicJE8GwziAMNauLlskD28=";
			
			EncryptCrypto encyto = new EncryptCrypto();
			
			if (generateKey.equalsIgnoreCase("generateKey")) {
				encyto.generateKey();
							
			} else if (generateKey.equalsIgnoreCase("Encrypt")) {
				System.out.println("ENCRYPT: "+strPwd);
				strReturn = encyto.encryptString(strPwd);
								
			} else if (generateKey.equalsIgnoreCase("Decrypt")) {
				System.out.println("DECRYPT: "+strEncryptedPwd);
				strReturn = encyto.decryptString(strEncryptedPwd);
				
			} else {
				System.out.println("Invalid Arguments \n Usage:  arg0=[GenerateKey]|[Encrypt]|[Decrypt] arg1=<Password>|<encrypted string>");
			}
			
			System.out.println(strReturn);
			
			} catch (Exception e) {
				System.out.println("exception "+e.toString());
				throw new Exception(e);
		}
	}

}
