package com.pg.us.specanywhere_enovia.security;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pg.us.specanywhere_enovia.payload.ApiResponse;
import com.pg.us.specanywhere_enovia.security.role.SecurityConstants;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;

import io.jsonwebtoken.Claims;

import org.apache.log4j.Logger;

//import io.jsonwebtoken.Claims;
//import io.jsonwebtoken.Jwts;



@Service
public class CustomUserDetailsService implements UserDetailsService {
	private static Logger LOGGER = Logger.getLogger(CustomUserDetailsService.class);
	
	@Autowired
	RestTemplate restTemplate;
	ApiResponse apiResponse;
	String jwt;
	
	@Value("${ping.oauth.client_secret}")
    private String jwtSecret;
	
	@Override
	public UserDetails loadUserByUsername(String usernameOrEmail) throws UsernameNotFoundException {
		List<GrantedAuthority> roles=getRolesFromJWT();
		LOGGER.info("In CustomUserDetailsService."+usernameOrEmail+" | roles:::"+roles);
		
		User user = new User(apiResponse.getMessage(), "oYVaWmVkMBWMZZD0nTliRyrSPJ4=",getRolesFromJWT());
		//if ("john".equals(usernameOrEmail)) {
			return user;
		} /*else {
			throw new UsernameNotFoundException("User not found with username: " + usernameOrEmail);
		}*/
	
	public void setResponse(ApiResponse response,String jwt) {
		LOGGER.info("In CustomUserDetailsService. setResponse");
		this.apiResponse=response;
		this.jwt=jwt;
	}
	
	public List<GrantedAuthority> getRolesFromJWT() {
		
		LOGGER.info("In CustomUserDetailsService. getRolesFromJWT Method");
		Claims claims = JwtParserUtils.parseJWTToken(jwtSecret, jwt).getBody();

		List<GrantedAuthority> roleAuthorities = Stream
				.of(getAuthorities(SecurityConstants.SECURITYAUTHORITY, claims.get("securityAuthorities")),
						getAuthorities(SecurityConstants.LICENSEAUTHORITY, claims.get("licenseAuthorities")),
						getAuthorities(SecurityConstants.COMPANYAUTHORITY, claims.get("companyAuthorities")),
						//SPEC: <11.19.2020>: Chandra added for Defect :37446 ## --START
				        getAuthorities(ConstantsUtil.PROGRAMBRIEFINGAUTHORITY,claims.get("programAuthorities")),
				      //SPEC: <11.19.2020>: Chandra added for Defect :37446 ## --END
						getAuthorities(SecurityConstants.DEPARTMENTAUTHORITY, claims.get("departmentAuthorities")))
				.map(CustomAuthority::new).collect(Collectors.toList());
		LOGGER.info("In CustomUserDetailsService. getRolesFromJWT Method. Returning roleAuthorities:"+roleAuthorities);
		return roleAuthorities;

	}

	private String getAuthorities(String authConstant, Object authority) {
		LOGGER.info("In CustomUserDetailsService. getAuthorities Method.");
		if (authority != null && authority.toString().length()>2) {
			LOGGER.info("In CustomUserDetailsService. getAuthorities Method. If Authority object is not null.");
			return authConstant + SecurityConstants.SEPARATOR
					+ authority.toString().replace("{authority=", "").replace("[", "").replace("}", "").replace("]", "");
					
		} else {
			LOGGER.info("In CustomUserDetailsService. getAuthorities Method. If Authority object is null. Returning:"+authConstant + SecurityConstants.SEPARATOR);
			return authConstant + SecurityConstants.SEPARATOR;
		}
	}
	}


