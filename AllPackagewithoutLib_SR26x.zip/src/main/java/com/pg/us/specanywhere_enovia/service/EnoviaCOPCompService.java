package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaCOPCompService {
	public HashMap<String, HashMap<String, Map<String, String>>> getCOPCompdata(String objId, Environment env) throws Exception; 

}
