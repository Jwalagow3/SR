package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaCUPService {

	public HashMap<String, Map<String, String>> getCUPdata(String objId, String sComp, Environment env) throws Exception; 
}
