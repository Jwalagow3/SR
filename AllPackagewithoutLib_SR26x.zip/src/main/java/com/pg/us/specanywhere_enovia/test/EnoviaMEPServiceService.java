package com.pg.us.specanywhere_enovia.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.ManufacturingEquivalentPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCUPBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.PromotionalItemPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaMEPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.EncryptCrypto;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaMEPServiceService{

	private static Logger LOGGER = Logger.getLogger(EnoviaMEPServiceService.class);

	public static void main(String[] args) throws Exception {

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		EnoviaConnectionPool pool = new EnoviaConnectionPool();
		Context context = null;
		boolean bAllInfoView = true;
		boolean bSupplierView = true;
		boolean bManufacturerView = true;
		try 
		{
			/*
			 * User Profile
			 * 
			SecurityService sct = new SecurityService();
			String sUserType = sct.getUserType();
			if(null==sUserType || sUserType.isEmpty()) {
				throw new Exception("Error in request Log-In User Profile. User Type is null or empty.");
			}

			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;

			switch (sUserType) {
			case ConstantsUtil.PG:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PGSTAFF:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PG_CM:
				bManufacturerView = true;
				break;

			case ConstantsUtil.PG_SP:
				bSupplierView = true;
				break;
			}*/
			
			//String objId = "20336.41905.33027.31273";
			//String objId = "20336.41905.35331.10323";
			//String objId = "20336.41905.33253.54691";
			//String objId = "20336.41905.36610.60640";
			//String objId = "20336.41905.34674.12530";//mat comp
			String objId = "20336.41905.35331.10323";
			StopWatch swContext = new StopWatch();
			swContext.start();
			pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
			context = pool.checkOut();
			swContext.stop();
			LOGGER.info("MEP CONTEXT ELAPSED TIME : "+swContext.getTime());
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			StringValidatorUtil validator = new StringValidatorUtil();
			ManufacturingEquivalentPartBO MEP = new ManufacturingEquivalentPartBO();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			DomainObject doMEP = MEP.getMepDO(context,objId);
			if(null==doMEP) {
				LOGGER.info("MEP MESSAGE FAILED, INVALID OBJECT ID : "+objId);
				throw new Exception("Error: Invalid Object ID or Object not found in database"+objId);
			}
			Map BusinessObjectSelectableMap = MEP.getManufacturingEquivalentPartSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = MEP.getMepRelatedObjsSelectableMap(context);
			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);

			MEP.addMultiSelects();
			Map resultMaps = doMEP.getInfo(context, slSelects);
			MEP.removeMultiselects();
			

			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpReachResult = new HashMap<String,String>();
			Map<String,String> mpMaterialComposition = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpEnterpriseParts = new HashMap<String,String>();
			Map<String,String> mpEquivalentSep = new HashMap<String,String>();
			Map<String,String> mpCertification = new HashMap<String,String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			

			//Header Content
			StopWatch sHeader = new StopWatch();
			sHeader.start();
			mpHeaderResult.put(ConstantsUtil.NAME, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
			sHeader.stop();
			LOGGER.info("MEP HEADER ELAPSED TIME : "+sHeader.getTime());


			/*StringList slHistoryInfo = (StringList)resultMaps.get(ConstantsUtil.SELECT_HISTORY);
			String lastUpdatedUser = util.getLastUpdateUser(slHistoryInfo);*/

			String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;
			
			StopWatch swAttrib = new StopWatch();
			swAttrib.start();
			
			if(bAllInfoView || bSupplierView || bManufacturerView) {
				mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				
				//Vendor
				MapList mlObjList = commonBo.getVendorInfo(context, doMEP,ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY);
				Iterator objectListItr = mlObjList.iterator();
				while (objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					mpAttribResult.put(ConstantsUtil.VENDOR, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATION_NAME)));
					mpAttribResult.put(ConstantsUtil.VENDORID, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATIONID)));
					mpAttribResult.put(ConstantsUtil.VENDOR_STREET_ADDRESS, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ADDRESS)));
					mpAttribResult.put(ConstantsUtil.VENDOR_STREET_ADDRESS_NUMBER, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHOUSENUMBER)));
					mpAttribResult.put(ConstantsUtil.VENDOR_CITY, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CITY)));
					mpAttribResult.put(ConstantsUtil.VENDOR_STATE, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATEREGION)));
					mpAttribResult.put(ConstantsUtil.VENDOR_MARKET, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COUNTRY)));
					break;
				}
				
				//Material Composition
				//SPEC: Release SR18x.5.2 - Added for Defect# 39069  by gaikwad.tg on Date 10 Feb 2021 -- START
				String strInternalMaterialFor =(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
				String strAtrIsRestricted =(String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_ISRESTRICTED);
				String strParentType = (String)resultMaps.get(ConstantsUtil.SELECT_TYPE);
				
				boolean isCondToCheck = false;
				if(((doMEP.isKindOf(context, ConstantsUtil.TYPE_MATERIAL) && ("Product".equals(strInternalMaterialFor) || "".equals(strInternalMaterialFor))) || strParentType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strParentType.equals(ConstantsUtil.TYPE_FORMULATIONPART) || strParentType.equals(ConstantsUtil.TYPE_PGRAWMATERIAL) || strParentType.equals(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART) || strParentType.equals(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART) || strParentType.equals(ConstantsUtil.TYPE_DEVICEPRODUCTPART)) && (UIUtil.isNotNullAndNotEmpty(strAtrIsRestricted) && strAtrIsRestricted.equalsIgnoreCase("No")))
					isCondToCheck = true;
				
				if(isCondToCheck)
				{
					//SPEC: Release SR18x.5.2 - Added for Defect# 39069  by gaikwad.tg on Date 10 Feb 2021 -- END
					mpMaterialComposition.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_NAME) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.SUBSTANCENAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_SUBNAME)))?(String)resultMaps.get(ConstantsUtil.COMP_SUBNAME) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.MIN_PERCEN_WBW, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPGMINIMUMPERCENTWEIGHTBYWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPGMINIMUMPERCENTWEIGHTBYWEIGHT) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.MAX_PERCEN_WBW, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMAXIMUMPERCENTWEIGHTBYWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMAXIMUMPERCENTWEIGHTBYWEIGHT) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.UOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_QUOM)))?(String)resultMaps.get(ConstantsUtil.COMP_QUOM) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.QTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_QTY)))?(String)resultMaps.get(ConstantsUtil.COMP_QTY) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.FUNCTIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.FUNCTIONS)))?(String)resultMaps.get(ConstantsUtil.FUNCTIONS) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.DRYWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DRYWEGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_DRYWEGHT) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.IC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_ISCONTAM)))?(String)resultMaps.get(ConstantsUtil.COMP_ISCONTAM) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.CAS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_CASNUM)))?(String)resultMaps.get(ConstantsUtil.COMP_CASNUM) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_STATE)))?(String)resultMaps.get(ConstantsUtil.COMP_STATE) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_REVS)))?(String)resultMaps.get(ConstantsUtil.COMP_REVS) : ConstantsUtil.EMPTY_STRING);
					mpMaterialComposition.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_DESC)))?(String)resultMaps.get(ConstantsUtil.COMP_DESC) : ConstantsUtil.EMPTY_STRING);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39069  by gaikwad.tg on Date 10 Feb 2021 -- START
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39069  by gaikwad.tg on Date 10 Feb 2021 -- END

			}
			
			if(bAllInfoView) {
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				String sClassifictaion = util.getClassification(resultMaps);
				mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
				mpAttribResult.put(ConstantsUtil.MATERIALCERTIFICATIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RESTRICTED, "");
				mpAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISSUEDATE, util.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMEASISSUEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMEASISSUEDATE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TRADENAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET)))?(String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET) : ConstantsUtil.EMPTY_STRING);
				
				swAttrib.stop();
				LOGGER.info("MEP GET Attribute ELAPSED TIME : "+swAttrib.getTime());
	
				//Organization Data
				StopWatch swOrganization = new StopWatch();
				swOrganization.start();
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)));
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)));
				swOrganization.stop();
				LOGGER.info("MEP Organization ELAPSED TIME : "+swOrganization.getTime());
	
				
				//Reach
				mpReachResult.put(ConstantsUtil.STATUS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS)));
				mpReachResult.put(ConstantsUtil.REGISTRATIONNUMBER, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER)));
				
	
				//Lifecycle
				String sPhysicalId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID));
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("MEP  LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				
				//Ownership
				StopWatch swOwnerShip = new StopWatch();
				swOwnerShip.start();
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)));
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.strSegment)));
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)));
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MODIFIED)));
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,validator.getStringEquivalentForStringList(mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)));
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)));
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
				swOwnerShip.stop();
				LOGGER.info("MEP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());
	
				
				//RelatedSpec
				StopWatch swRelatedSpec = new StopWatch();
				swRelatedSpec.start();
				mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
				swRelatedSpec.stop();
				LOGGER.info("MEP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());
	
	
				//Reference Docs
				
				StopWatch swReference= new StopWatch();
				swReference.start();
				StringList slRefDocSelects = MEP.getRefDocBusSelect(context);
				MapList mlRefDocs = doMEP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
						ConstantsUtil.SYMBL_ASTERISK, slRefDocSelects, new StringList(), false, true, (short) 1,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				if(mlRefDocs.size()>0) {
					mapReferenceDocs =	util.parseRefDoclist(context,mlRefDocs);
				}
				swReference.stop();
				LOGGER.info("MEP  Reference ELAPSED TIME : "+swReference.getTime());
	
				//Security
				StopWatch swSecurity = new StopWatch();
				swSecurity.start();
				mpSecurity =commonBo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				LOGGER.info("MEP  Security ELAPSED TIME : "+swSecurity.getTime());
				
				
				// Enterprise Parts
				StopWatch swEnterprise = new StopWatch();
				swEnterprise.start();
				StringList busSelect = new StringList();
				busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
				busSelect.add(ConstantsUtil.SELECT_NAME);
				busSelect.add(ConstantsUtil.SELECT_REVISION);
				busSelect.add(ConstantsUtil.SELECT_TYPE);
				busSelect.add(ConstantsUtil.SELECT_CURRENT);
				busSelect.add(ConstantsUtil.SELECT_POLICY);
				StringBuilder sbName = new StringBuilder();
				StringBuilder sbRev = new StringBuilder();
				StringBuilder sbType = new StringBuilder();
				StringBuilder sbDesc = new StringBuilder();
				StringBuilder sbState = new StringBuilder();
				StringBuilder sbSupName = new StringBuilder();
				StringBuilder sbSupRev = new StringBuilder();
				StringBuilder sbSupType = new StringBuilder();
				StringBuilder sbSupDesc = new StringBuilder();
				StringBuilder sbSupState = new StringBuilder();
				MapList mlEnterpriseParts = doMEP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT,
						ConstantsUtil.SYMBL_ASTERISK, busSelect, null, true, false, (short) 1,
						"current!=Obsolete", ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				
				Iterator entPartsListItr = mlEnterpriseParts.iterator();
				while (entPartsListItr.hasNext()) {
					Map objectMap = (Map) entPartsListItr.next();
					String sPolicy = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_POLICY));
					if(sPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_SEPEQUIVALENT)) {
						formatData(sbSupName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
						formatData(sbSupRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
						formatData(sbSupType, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE)));
						formatData(sbSupDesc, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION)));
						formatData(sbSupState, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
					}else {
						formatData(sbName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
						formatData(sbRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
						formatData(sbType, util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
						formatData(sbDesc, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION)));
						formatData(sbState, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
					}
				}
				mpEnterpriseParts.put(ConstantsUtil.NAME, sbName.toString());
				mpEnterpriseParts.put(ConstantsUtil.REVISION, sbRev.toString());
				mpEnterpriseParts.put(ConstantsUtil.TYPE, sbType.toString());
				mpEnterpriseParts.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
				mpEnterpriseParts.put(ConstantsUtil.STATE, sbState.toString());
				swEnterprise.stop();
				LOGGER.info("MEP ENTERPRISE ELAPSED TIME : "+swEnterprise.getTime());
				
				//Equivalent SEP
				mpEquivalentSep.put(ConstantsUtil.NAME, sbSupName.toString());
				mpEquivalentSep.put(ConstantsUtil.REVISION, sbSupRev.toString());
				mpEquivalentSep.put(ConstantsUtil.TYPE, sbSupType.toString());
				mpEquivalentSep.put(ConstantsUtil.DESCRIPTION, sbSupDesc.toString());
				mpEquivalentSep.put(ConstantsUtil.STATE, sbSupState.toString());
				
				
				//Certification
				StopWatch swCert = new StopWatch();
				swCert.start();
				MapList mlCertifications = commonBo.getCertificationClaims(context, objId);
				Iterator itrCerts = mlCertifications.iterator();
				StringBuilder sbCertName = new StringBuilder();
				StringBuilder sbCertRev = new StringBuilder();
				StringBuilder sbCertType = new StringBuilder();
				StringBuilder sbCertDesc = new StringBuilder();
				StringBuilder sbCertState = new StringBuilder();
				
				while (itrCerts.hasNext()) {
					Map objectMap = (Map) itrCerts.next();
						formatData(sbCertName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
						formatData(sbCertRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
						formatData(sbCertType, util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
						formatData(sbCertDesc, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION)));
						formatData(sbCertState, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
				}
				mpCertification.put(ConstantsUtil.NAME, sbName.toString());
				mpCertification.put(ConstantsUtil.REVISION, sbRev.toString());
				mpCertification.put(ConstantsUtil.TYPE, sbType.toString());
				mpCertification.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
				mpCertification.put(ConstantsUtil.STATE, sbState.toString());
				mpCertification.put(ConstantsUtil.CERTIFICATION, sbState.toString());
				mpCertification.put(ConstantsUtil.STATUS, sbState.toString());
				mpCertification.put(ConstantsUtil.EXPIRATIONDATE, sbState.toString());
				swCert.stop();
				LOGGER.info("MEP CERTIFICATION ELAPSED TIME : "+swCert.getTime());
			}
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			hmAttrib.put(ConstantsUtil.REACH, mpReachResult);
			hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialComposition);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			hmAttrib.put(ConstantsUtil.ENTERPRISEPARTS, mpEnterpriseParts);
			hmAttrib.put(ConstantsUtil.EQUIVALENTSEP, mpEquivalentSep);
			hmAttrib.put(ConstantsUtil.CERTIFICATION, mpCertification);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
			
			sp.stop();
			pool.checkIn(context);
			LOGGER.info("MEP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "MEP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));

		} catch (IOException e) {
			LOGGER.error("Unable to getMEPdata"+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		} catch (MatrixException e) {
			LOGGER.error("Unable to getMEPdata"+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		} finally {
			//Subhajit Added for Memory Leakage Analysis - Start
			if(null!=context) {
				context.close();
			}
			//Subhajit Added for Memory Leakage Analysis - End
		}
	}
	
	public static void formatData(StringBuilder slData, String sData) {
		sData=sData.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
		
		
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
}
