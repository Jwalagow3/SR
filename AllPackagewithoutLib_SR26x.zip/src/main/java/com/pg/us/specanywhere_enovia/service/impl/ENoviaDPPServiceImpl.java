/**
 * Project 		: SpecsAnywhere
 * Program 		: ENoviaDPPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants; //<11.20.2020>: Added for #37454 START	
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MPPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.SapBomAsFed;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaDPPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.SelectConstants; //<11.20.2020>: Added for #37454 START	
import matrix.util.MatrixException;
import matrix.util.StringList;


public class ENoviaDPPServiceImpl implements EnoviaDPPService {

	private static Logger LOGGER = Logger.getLogger(ENoviaDPPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
	
	@SuppressWarnings("static-access")
	@Override
	public HashMap<String, Map<String, String>> getDPPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		try 
		{
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- START
			/*StopWatch swContext = new StopWatch();
			swContext.start();
			Context context = pool.checkOut();
			swContext.stop();*/
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- END
			LOGGER.info("DPP CONTEXT ELAPSED TIME : "+swContext.getTime());
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			DeviceProductPartBO DPPBO = new DeviceProductPartBO();
			DomainObject doDPP =  DPPBO.getDPPDO(context, objId);
			String strCurrent = doDPP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
				
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType) &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY)
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpDangerousGoodsClf = new HashMap<String,String>();
			Map<String,String> mpGlobalHarStandard = new HashMap<String,String>();
			Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
			Map<String,String> mpStability = new HashMap<String,String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Map<String,String> mpPerformChar = new HashMap<String,String>();
			Map<String,String> mpWeightResult = new HashMap<String,String>();
			Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
			Map<String,String> mapCountryClearanceResult = new HashMap<String,String>();
			Map<String,String> mapCertifications = new HashMap<String,String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpMaterialProduced = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpMEPResult = new HashMap<String,String>();
			Map<String,String> mpSEPResult = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mpMasterAttribute = new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			
			//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			Map<String,String> mpProductPartStabilityDoc = new HashMap<String,String>();
			Map<String,String> mpMasterPartStabilityDoc = new HashMap<String,String>();
			//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
			
			//SPEC: Added for Dev 18x.6 Release by Jwala -- START
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			Map<String,String> mpCertificationvalidation = new HashMap<String,String>();
			Map<String,String> mpIngredientstatement = new HashMap<String,String>();
			Map<String,String> mpSmartLabel = new HashMap<String,String>();
			//SPEC: Added for Dev 18x.6 Release by Jwala -- END
			
			//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- START
			Map<String,String> mpSubStanceResult = new HashMap<>();
			//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- END
			
			// Added for Defect #37046 -- START
			String strCertColValue = null;
			// Added for Defect #37046 -- END

			
			FabricatedPartBO fabBo = new FabricatedPartBO();
			CommonBusUtilBO commonBO = new CommonBusUtilBO();
			MPPBO mppbo = new MPPBO();
			MasterCOPBO mcop = new MasterCOPBO();
			BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = DPPBO.getDPPPartSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = DPPBO.getDPPRelatedObjsSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
			BusObjectAttribUtil util = new BusObjectAttribUtil();

			if (null == doDPP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Modified by Jwala for 2022x Schema change Multivalu list removed
			//Map resultMaps = doDPP.getInfo(context, slContextSelects);
			Map resultMaps = doDPP.getInfo(context, slContextSelects,DPPBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("DPP GETINFO ELAPSED TIME : "+swAttributes.getTime());

			boolean bGendocView=false;
			boolean bAuthorizedtoUse = BbUtil.isAuthorizedtoUse(context,doDPP,resultMaps,strPDFView);

			boolean bHIRComplaint = BbUtil.getHIRComplaintForSupplier(context,doDPP,resultMaps);
			
			boolean bAuthorizedtoProduce = util.isAuthorizedtoProduce(context,doDPP,resultMaps,strPDFView);

			if((bManufacturerView && bAuthorizedtoProduce) || ((bSupplierView && bHIRComplaint))) {
				bGendocView = true;
			}
			//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43107 on Date 26/05/2021 --START
			if((util.isModificatinRequired() && bHIRComplaint)) {
				bGendocView = true;
			}
			//SPEC: Release SR18x.6.0.1 Added by Dominic for Defect 43107 on Date 26/05/2021 --END
			String sClassifictaion = util.getClassification(resultMaps);
			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String strCertificationvalidation = DomainConstants.EMPTY_STRING;//SPEC: 06/24/2022: Added by Ketan for Req no. 38897
			//SPEC: 12.03.2020: Added for req 18x.5 ##34415 -- START
			if(bGendocView){
				mpHeaderContent.put(ConstantsUtil.VIEW, ConstantsUtil.GENDOCVIEW);
			}
			//SPEC: 12.03.2020: Added for req 18x.5 ##34415 -- END

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			

			if(bAllInfoView || bManufacturerView || bGendocView) {

				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);

				//SPEC: Modified for Dev 18x.6 Release by Jwala -- START
				if(bGendocView || bAllInfoView){
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				}
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Modified for Dev 18x.6 Release by Jwala -- END
				
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
				//Added for defect #37046
				strCertColValue = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING;
				//Added for defect #37046
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
				

				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				// Guna Modified for Defect 38531  18x.5.2 Release -- START
				mpAttribResult.put(ConstantsUtil.BRAND, (validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))));
				// Guna Modified for Defect 38531  18x.5.2 Release -- END
				mpAttribResult.put(ConstantsUtil.PROD_VARIANNT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM) : ConstantsUtil.EMPTY_STRING);

				String strOnshelf = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
				if(ConstantsUtil.ZERO_SIZE.equalsIgnoreCase(strOnshelf)){
					strOnshelf = ConstantsUtil.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtil.ONSHELFPRODDENSITY, strOnshelf);
				//SPEC: 09.30.2021:Added by Jwala for defect 42925 -- END
				mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				
				// Guna Modified for Defect 38531  18x.5.2 Release -- START
				//mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, (validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.strIntendedMarket))));
				// Guna Modified for Defect 38531  18x.5.2 Release -- END
				mpAttribResult.put(ConstantsUtil.UNIQUE_FORMULA_IDENTIFIER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DOESTHISDEVICECONTAINFLAMMABLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESDEVICECONTAINFLAMMABLELIQUID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESDEVICECONTAINFLAMMABLELIQUID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);

				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
				mpAttribResult.put(ConstantsUtil.REPLACEDPRODUCTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ) : ConstantsUtil.EMPTY_STRING);
				// SPEC : Added by Jwala for External Dev 18x.6 -- START
				if(bAllInfoView || (bManufacturerView && !bGendocView)){
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRPGPDTTOPGPLIREFUN)))?(String)resultMaps.get(ConstantsUtil.STRPGPDTTOPGPLIREFUN) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				}
				// SPEC : Commented by Jwala for External Dev 18x.6 -- END
				
				mpAttribResult.put(ConstantsUtil.PGDANGEROUSGOODSREADY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSREADY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSREADY) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
				
				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END
				
				//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- START
				mpAttribResult.put(ConstantsUtilIRM.SMARTLABELREADY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SMARTLABENREADY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SMARTLABENREADY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.CLONETRANSFERRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.PRODUCTDOSECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.REASONFORMANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- END
				
				//Added by Ajay for Req 7790 - START
				mpAttribResult.put(ConstantsUtil.AUTHORINGAPPLICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION) : ConstantsUtil.EMPTY_STRING);
				//Added by Ajay for Req 7790 - END
				/**
				 * LOAD HEADER CONTENT SECTION
				 * */
				mpHeaderContent.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Commented for Dev 18x.6 Release by Jwala -- JWALA
				//if(!bManufacturerView && !bSupplierView){
				//SPEC: Commented for Dev 18x.6 Release by Jwala -- JWALA
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				//}
				//SPEC: Commented for Dev 18x.6 Release by Jwala -- JWALA

				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
				mpHeaderContent.put(ConstantsUtil.PDF_VIEW, util.getPdfViewtype(bAllInfoView, bGendocView, bSupplierView));
				
				if((strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) && bGendocView)) {
					mpHeaderContent.put(ConstantsUtil.PDF_VIEW,ConstantsUtil.GENDOC_VIEW);
				}

				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
				mpHeaderContent.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderContent.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				//Modified by Ganesh for Defect 38137  18x.5.2 Release ---->Start
				String masterId = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID));
				if (UIUtil.isNotNullAndNotEmpty(masterId)) {
					DomainObject obj = new DomainObject(masterId);
					String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					obj.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
					boolean showData = util.checkHasAccess(context, sUserType, masterId);
					if (!showData) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
				}
				mpHeaderContent.put(ConstantsUtil.MASTERPARTID, masterId);
				//Modified by Ganesh for Defect 38137  18x.5.2 Release ---->END
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END


				/**
				 * LOAD DANGEROUS GOODS CLASSIFICATION SECTION
				 * */

				mpDangerousGoodsClf=DPPBO.getDangerousProdcutValue(context,resultMaps);

				mpDangerousGoodsClf.remove(ConstantsUtil.PRODUCTPARTNAME);
				mpDangerousGoodsClf.remove(ConstantsUtil.PRODUCTPARTTYPE);
				mpDangerousGoodsClf.remove(ConstantsUtil.PRODUCTPARTTITLE);
				mpDangerousGoodsClf.remove(ConstantsUtil.PRODUCTPARTREVISION);
				mpDangerousGoodsClf.remove(ConstantsUtil.PRODUCTPARTID);
				
				if(bManufacturerView || bGendocView) {
					mpDangerousGoodsClf=BbUtil.filterPhase(mpDangerousGoodsClf);
				}

				/**
				 * LOAD GLOBAL HARMONIZED STANDARD SECTION
				 * */
				mpGlobalHarStandard = DPPBO.getGHSProdcutValue(context,resultMaps);
				
				if(bManufacturerView || bGendocView) {
					mpGlobalHarStandard=BbUtil.filterPhase(mpGlobalHarStandard);
				}


				/**
				 * LOAD STORAGE AND LABEL SECTION
				 * */
				//SPEC 09/30/2021 Modified for defect 42868 -- START
				mapStorageAndLabelResult.put(ConstantsUtil.STR_TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.POWERSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.BATTERYWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHT) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.BATTERYWEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTUOM) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.BATTERYCHEMICALCOMPOSITION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYCHEMISTRY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYCHEMISTRY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.BATTERYLITHUM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYLITHUM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYLITHUM) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.BATTERYLITHUMUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTLIUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTLIUOM) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYENERGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYWHRATING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYWHRATING) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYVOLTAGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYVOLTAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYVOLTAGE) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.BATTERYSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYSIZE) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.ISABUTTON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLYESNO)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLYESNO) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.TYPICALCAPACITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCAPACITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCAPACITY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.TYPICALCAPACITYUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYTCUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYTCUOM) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.NUMBEROFCELLSSHIPPEDINSIDEDEVICE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTMARKETEDASCHILDRENSPRODUCT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.DOESTHEPRODUCTREQUIRECHILDSAFEDESIGN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);        
				//SPEC: <23.12.2021>: Guna Modified for 42892 Defect  Dev 18x.6.0.3 Release --- START
				mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTEXPOSEDTOCHILDREN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <23.12.2021>: Guna Modified for 42892 Defect  Dev 18x.6.0.3 Release --- END
				mapStorageAndLabelResult.put(ConstantsUtil.EVAPORATIONRATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.RESERVEACIDITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.RESERVEALKALLNITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY) : ConstantsUtil.EMPTY_STRING);
				//SPEC <12/03/2020> Modified for defect #37730 START
				mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS)));
				//SPEC <12/03/2020> Modified for defect #37730 END
				mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0.1 - Added by Amman on Apr 29, 2021 for Defect raised by Internal Testing Team -- START
				mapStorageAndLabelResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				//SPEC 11.24.2020: Commented for #37454 and 37410 - START
				//SPEC 11.24.2020: Commented for #37454 and 37410 - END
				mapStorageAndLabelResult.put(ConstantsUtil.WAREHOUSECLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				mapStorageAndLabelResult.put(ConstantsUtil.NUMBEROFBATTRIESREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_NUMBEROFBATTERIESREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_NUMBEROFBATTERIESREQUIRED) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END
				//SPEC 09/30/2021 Modified for defect 42868 -- END
				//Added By Ajay for the Req 15195 : START
				mapStorageAndLabelResult.put(ConstantsUtilIRM.TYPENUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTYPENUMBER)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTYPENUMBER) : ConstantsUtil.EMPTY_STRING);
				//Added By Ajay for the Req 15195 : END
				//<11.20.2020>: Added for #37454 START
				String strIfYesselectbatterytype=(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING;
				if(strIfYesselectbatterytype!=null && !strIfYesselectbatterytype.equals(ConstantsUtil.EMPTY_STRING)) {
					StringList objectSelects = new StringList();
					objectSelects.add(DomainConstants.SELECT_ID);
					objectSelects.add("attribute[pgPLBatteryWeight]");
					objectSelects.add("attribute[pgPLBatteryWeightUOM]");
					objectSelects.add("attribute[pgPLIBatteryVoltage]");
					objectSelects.add("attribute[pgPLBatteryWeightLiUOM]");
					objectSelects.add("attribute[pgPLBatteryVolUOM]");
					objectSelects.add("from[pgPLRelatedData|to.type==pgPLIBatteryChemistry].to.name");
					objectSelects.add("from[pgPLRelatedData|to.type==pgPLIBatterySize].to.name");
					objectSelects.add("attribute[pgPLBatteryEnRUOM]");
					objectSelects.add("attribute[pgPLBatteryTCUOM]");
					objectSelects.add("attribute[pgPLIBatteryWhRating]");
					objectSelects.add("attribute[pgPLIBatteryLithum]"); // Added for #37410
					objectSelects.add("attribute[pgPLBatteryEnRUOM]");
					objectSelects.add("attribute[pgPLIBatteryCells]");
					objectSelects.add("attribute[pgPLIBatteryCapacity]");
					objectSelects.add("from[pgPLRelatedData].to[pgPLIYesNo].name");

					MapList mlPickListObjects = DomainObject.findObjects(context, "pgPLIBatteryType",
							strIfYesselectbatterytype, "-", DomainConstants.QUERY_WILDCARD,
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, null, true, objectSelects);
					
					if(mlPickListObjects != null && ! mlPickListObjects.isEmpty())
					{
						Map mapPickListObj = (Map) mlPickListObjects.get(0);
						String strBatterWeight_Compo=(validator.isNotNullOrEmpty((String)mapPickListObj.get("from[pgPLRelatedData].to.name")))?(String)mapPickListObj.get("from[pgPLRelatedData].to.name") : ConstantsUtil.EMPTY_STRING;
						StringList strtemp = new StringList();
						if(strBatterWeight_Compo!=null && !"".equals(strBatterWeight_Compo))
							strtemp=FrameworkUtil.split((String)strBatterWeight_Compo, SelectConstants.cSelectDelimiter); 
						
						String strBatSize="";
						String strBatComp="";
						
						if(strtemp.size()>0)
							strBatComp=strtemp.get(0);
						if(strtemp.size()>1)
							strBatSize=strtemp.get(1);
						
						mapStorageAndLabelResult.put(ConstantsUtil.BATTERYCHEMICALCOMPOSITION, strBatComp);
						mapStorageAndLabelResult.put(ConstantsUtil.BATTERYSIZE, strBatSize);
						mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYVOLTAGEUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLBatteryVolUOM]")))?(String)mapPickListObj.get("attribute[pgPLBatteryVolUOM]") : ConstantsUtil.EMPTY_STRING);
						mapStorageAndLabelResult.put(ConstantsUtil.BATTERYWEIGHT, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLBatteryWeight]")))?(String)mapPickListObj.get("attribute[pgPLBatteryWeight]") : ConstantsUtil.EMPTY_STRING);
						mapStorageAndLabelResult.put(ConstantsUtil.BATTERYWEIGHTUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLBatteryWeightUOM]")))?(String)mapPickListObj.get("attribute[pgPLBatteryWeightUOM]") : ConstantsUtil.EMPTY_STRING);
						mapStorageAndLabelResult.put(ConstantsUtil.TYPICALCAPACITYUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLBatteryTCUOM]")))?(String)mapPickListObj.get("attribute[pgPLBatteryTCUOM]") : ConstantsUtil.EMPTY_STRING);
						mapStorageAndLabelResult.put(ConstantsUtil.BATTERYLITHUMUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLBatteryWeightLiUOM]")))?(String)mapPickListObj.get("attribute[pgPLBatteryWeightLiUOM]") : ConstantsUtil.EMPTY_STRING);
						mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYVOLTAGE, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLIBatteryVoltage]")))?(String)mapPickListObj.get("attribute[pgPLIBatteryVoltage]") : ConstantsUtil.EMPTY_STRING);
						mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYENERGY, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLIBatteryWhRating]")))?(String)mapPickListObj.get("attribute[pgPLIBatteryWhRating]") : ConstantsUtil.EMPTY_STRING);
						mapStorageAndLabelResult.put(ConstantsUtil.BATTERYLITHUM, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLIBatteryLithum]")))?(String)mapPickListObj.get("attribute[pgPLIBatteryLithum]") : ConstantsUtil.EMPTY_STRING); // Added for #37410
						mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYENERGYUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLBatteryEnRUOM]")))?(String)mapPickListObj.get("attribute[pgPLBatteryEnRUOM]") : ConstantsUtil.EMPTY_STRING); // Added for #37410
						mapStorageAndLabelResult.put(ConstantsUtil.NUMBEROFCELLS, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLIBatteryCells]")))?(String)mapPickListObj.get("attribute[pgPLIBatteryCells]") : ConstantsUtil.EMPTY_STRING); // Added for #37410
						mapStorageAndLabelResult.put(ConstantsUtil.TYPICALCAPACITY, (validator.isNotNullOrEmpty((String)mapPickListObj.get("attribute[pgPLIBatteryCapacity]")))?(String)mapPickListObj.get("attribute[pgPLIBatteryCapacity]") : ConstantsUtil.EMPTY_STRING); // Added for #37410
						mapStorageAndLabelResult.put(ConstantsUtil.ISABUTTON, (validator.isNotNullOrEmpty((String)mapPickListObj.get("from[pgPLRelatedData].to[pgPLIYesNo].name")))?(String)mapPickListObj.get("from[pgPLRelatedData].to[pgPLIYesNo].name") : ConstantsUtil.EMPTY_STRING); // Added for #37410
						
				//SPEC: Release SR18x5.2- modified for Defect #39570 by Govind on Date 18/02/2021 start		
					} else {
						mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYVOLTAGEUOM,ConstantsUtil.EMPTY_STRING);
						mapStorageAndLabelResult.put(ConstantsUtil.NUMBEROFCELLS,ConstantsUtil.EMPTY_STRING);
						mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYENERGYUOM,ConstantsUtil.EMPTY_STRING);
					}
					
				} else {
					mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYVOLTAGEUOM,ConstantsUtil.EMPTY_STRING);
					mapStorageAndLabelResult.put(ConstantsUtil.NUMBEROFCELLS,ConstantsUtil.EMPTY_STRING);
					mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYENERGYUOM,ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x5.2- modified for Defect #39570 by Govind on Date 18/02/2021 start
				//<11.20.2020>: Added for #37454 END
				/**
				 * LOAD STABILITY SECTION
				 * */
				mpStability =util.getWeightProdcutValue(context,resultMaps);

				mpStability.put(ConstantsUtil.PRODUCTEXPDATEREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TOTALSHELFLIFEDAYS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TEMPERATUREGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.HUMIDITYGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TRANSPORTHEATPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.BOUNDARYCONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.STABILITYREPORTLINK, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE) : ConstantsUtil.EMPTY_STRING);

				/**
				 * LOAD NOTES SECTION
				 * */
				mpNotes=mcop.updateNotes(context, resultMaps);

				/**
				 * LOAD PERFORMANCE CHAR SECTION
				 * */
				Map paramMap = new HashMap();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				PerformanceCharcteristics perform = new PerformanceCharcteristics();
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				if(!mlPerformChar.isEmpty())
				{
					FinishedProductPartBO fppBO = new FinishedProductPartBO();
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
					//mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
					mpPerformChar =BbUtil.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
				}
				swPerfChar.stop();
				LOGGER.info("DPP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

				/**
				 * LOAD WEIGHT CHAR SECTION
				 * */
				
				mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				
				
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
				mpWeightResult.put(ConstantsUtil.NETWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.ROLLUPNETWEIGHTTOCOP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ROLLUPNETWEIGHTTOCOP)))?util.replaceSpecialSymbols((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ROLLUPNETWEIGHTTOCOP)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
				
				/**
				 * LOAD MATERIALS PRODUCED SECTION
				 * */
				StopWatch swMaterial = new StopWatch();
				swMaterial.start();
				mpMaterialProduced = DPPBO.getMaterialProducedforDPP(context,sContextObjectId);
				if(bManufacturerView || bGendocView) {
					mpMaterialProduced=BbUtil.filterPhase(mpMaterialProduced);
				}
				mpMaterialProduced = BbUtil.filterMapList(mpMaterialProduced);
				swMaterial.stop();
				LOGGER.info("DPP MATERIALS ELAPSED TIME : "+swMaterial.getTime());

				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=BbUtil.getRelatedAts(context, doDPP);
				
				mpRelatedATS=BbUtil.filterMapList(mpRelatedATS);
				if(!mpRelatedATS.isEmpty()){
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
					//mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
					//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
				}

				if(bManufacturerView || bGendocView) {
					mpRelatedATS=BbUtil.filterPhase(mpRelatedATS);
				}

				swAts.stop();
				LOGGER.info("DPP ATS ELAPSED TIME : "+swAts.getTime());


				/**
				 * LOAD RELATED SPEC SECTION
				 * */
				StopWatch swRelatedSpec = new StopWatch();
				swRelatedSpec.start();
				mpRelatedSpecResult = BbUtil.updatePartSpec(context, resultMaps);
				swRelatedSpec.stop();
				LOGGER.info("DPP Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());

				/**
				 * MASTER SPECIFICATION
				 * */
				StopWatch swmpMasterSpecs = new StopWatch();
				swmpMasterSpecs.start();
				mpMasterSpecs = BbUtil.getMasterSpecs(context,sContextObjectId);
				//mpMasterSpecs = BbUtil.filterMapList(mpMasterSpecs);
				swmpMasterSpecs.stop();
				LOGGER.info("DPP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());

				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
				mapReferenceDocs = BbUtil.filterMapList(mapReferenceDocs);
				swReference.stop();
				LOGGER.info("DPP REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());


				/**
				 * LOAD MASTER ATTRIBUTES DATA 
				 * */
				StopWatch swMaster = new StopWatch();
				swMaster.start();
				String sMasterID= (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID) : ConstantsUtil.EMPTY_STRING);
				if(validator.isNotNullOrEmpty(sMasterID)){
					FabricatedPartBO FABBO = new FabricatedPartBO();
					mpMasterAttribute = FABBO.getMasterAttributeData(context,sMasterID);
					
					if(mpMasterAttribute.containsKey(ConstantsUtil.NAME)&& bManufacturerView){
						mpMasterAttribute.remove(ConstantsUtil.NAME);
					}
					if(bManufacturerView || (bSupplierView && bHIRComplaint)) {
						mpMasterAttribute=BbUtil.filterPhase(mpMasterAttribute);
					}
					mpMasterAttribute = BbUtil.filterMapList(mpMasterAttribute);

				}
				swMaster.stop();
				LOGGER.info("DPP GET MASTER ATTRIB ELAPSED TIME : "+swMaster.getTime());
				
				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				
				/**
				 * LOAD CERTIFICATIONVALIDATION SECTION
				 * */
				// Added by Jwala for the req 4945 - START
				if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)){
					StopWatch swCerVali= new StopWatch();
					swCerVali.start();
					MapList mlCertValidation = util.getConnectedRawMaterialfromPart(context,sContextObjectId);
					mpCertificationvalidation = util.getCertValidationMap(context, resultMaps, mlCertValidation);
					mpCertificationvalidation = BbUtil.filterMapList(mpCertificationvalidation);
					//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- START
					strCertificationvalidation = validator.getStringEquivalentForStringList(mpCertificationvalidation.get(ConstantsUtil.SELECT_NAME));
					strCertificationvalidation = strCertificationvalidation.substring(0, strCertificationvalidation.length() -1);
					//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- END

					swCerVali.stop();
					LOGGER.info("DPP CERTIFICATIONVALIDATION ELAPSED TIME : "+swCerVali.getTime());
				}
				// Added by Jwala for the req 4945 - END
				/**
				 * PRODUCT PART STABILITY DOC SECTION
				 */
				//Provided PRODUCT PART STABILITY section access to CM and Gendoc view as part of 18x.6 
				mpProductPartStabilityDoc = DPPBO.getProductPartStabilityDoc(context,resultMaps);
				mpProductPartStabilityDoc = BbUtil.filterMapList(mpProductPartStabilityDoc);
				
				/**
				 * MASTER PART STABILITY DOC SECTION
				 */
				//Provided MASTER PART STABILITY DOC section access to CM and Gendoc view as part of 18x.6 
				mpMasterPartStabilityDoc = DPPBO.getMasterPartStabilityDoc(context,resultMaps);
				
				/**
				 * LOAD MARKET CLEARANCE
				 * */
				//Provided MARKET CLEARANCE section access to CM and Gendoc view as part of 18x.6
				StopWatch swcountry = new StopWatch();
				swcountry.start();
				//Added by Jwala for defect 44115 fix under CHG0303796 -- START
				//mapCountryClearanceResult = DPPBO.getCountryClearanceResult(context,sContextObjectId);
				APPBO APPBO = new APPBO();
				mapCountryClearanceResult = APPBO.getCountryClearance(context,sContextObjectId);
				//Added by Jwala for defect 44115 fix under CHG0303796 -- END
				mapCountryClearanceResult = BbUtil.filterMapList(mapCountryClearanceResult);
				swcountry.stop();
				LOGGER.info("DPP MARKET CLEARANCE TIME : "+swcountry.getTime());
				
				//Provided PQRMEP and PQR SEP section access to CM and Gendoc view as part of 18x.6
				/**
				 * This Method is for getting the MEPS
				 * @param context
				 * @param Relationship
				 * @param objectMap
				 * @param bMEP
				 * @return
				 * @throws Exception
				 */
				//Added by Jwala for 22x Development Req 42996 -- START
				boolean isUserCMandSP = BObjutil.isUserCMandSP(context, objId);
				//Added by Jwala for 22x Development Req 42996 -- END
				mpMEPResult = util.getPQREquivalents(context, resultMaps,true, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT,sUserType);
				
				//SPEC: <10.22.2020>: Added for req 18x.6 External Dev ## -- START
				if(bManufacturerView || bSupplierView || bGendocView){
					mpMEPResult.remove(ConstantsUtil.PQRBA);
					mpMEPResult.remove(ConstantsUtil.PQRPCP);
					// Added by Jwala for Req/Defect 35581 43951 -- START
					//SPEC: <21.12.2021>: Guna Modified for 42013 Req  Dev 18x.6.0.3 Release --- START
					//Modified by Jwala for 22x Development Req 42996 -- START
					if((bSupplierView && !isUserCMandSP) || bHIRComplaint){
						//SPEC: 30-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50376-- START
						if(!(bManufacturerView&&bGendocView)) {
							mpMEPResult.remove(ConstantsUtil.PQRPLANTS);
						}
						//SPEC: 30-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50376-- END
					}
					//Modified by Jwala for 22x Development Req 42996 -- END
				}
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- START
				if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
					mpMEPResult = new HashMap<String,String>();
                }
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- END
				/**
				 * This Method is for getting the SEPS 
				 * @param context
				 * @param Relationship
				 * @param objectMap
				 * @param bSEP
				 * @return
				 * @throws Exception
				 */
				mpSEPResult = util.getPQREquivalents(context, resultMaps, false, ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT,sUserType);

				if(bManufacturerView || bSupplierView || bGendocView){
					mpSEPResult.remove(ConstantsUtil.PQRBA);
					mpSEPResult.remove(ConstantsUtil.PQRPCP);
					//Modified by Jwala for 22x Development Req 42996 -- START
					if((bSupplierView && !isUserCMandSP) || bHIRComplaint){
						//SPEC: 01-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50376-- START
						if(!(bManufacturerView&&bGendocView)) {
							mpSEPResult.remove(ConstantsUtil.PQRPLANTS);
						}
						//SPEC: 01-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50376-- END
					}
					//Modified by Jwala for 22x Development Req 42996 -- END
				}
				
				//SPEC: <10.22.2020>: Added for req 18x.6 External Dev ## -- END
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- START
				if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
					mpSEPResult = new HashMap<String,String>();
                }
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- END
				
				/**
				 * LOAD CERTIFICATION DATA SECTION
				 * */
				//Provided CERTIFICATION DATA SECTION access to CM and Gendoc view as part of 18x.6
				//APPBO APPBO = new APPBO();
				// Added by Jwala for the req 4945 - START
				if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)){
					mapCertifications=APPBO.getCertificationClaims(context,objId);
				}
				// Added by Jwala for the req 4945 - END
				/**
				 * SMART LABEL SECTION
				 * */ 
				StopWatch swSmartLabel = new StopWatch();
				swSmartLabel.start();
				mpSmartLabel =APPBO.getConnectedSmartLabelForParts(context, objId);
				swSmartLabel.stop();
			
				//SPEC: <25.02.2021>: Guna Added for Dev 18x.6   -- END
				
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END

			}
			//Added by Ketan for Defect no. 52838 - Start
			if(!bSupplierView) {
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
			}
			//Added by Ketan for Defect no. 52838 - End
			//SPEC: 12.03.2020: Added for GendocView req 18x.5 ##41754 -- START
			if(bAllInfoView || bGendocView) {

				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END
				
				/**
				 * LOAD SAP BOM as FED SECTION
				 * */
				StopWatch swSapBomAsFed = new StopWatch();
				swSapBomAsFed.start();
				CalculateBOM clBom = new CalculateBOM();

				SapBomAsFed sapBom = new SapBomAsFed();
				mpSapBomAsFedcResult = sapBom.getSapBOMasFed(context,sContextObjectId);

				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				//The below fields have been removed from 18x.6 template. Since SAPBOM as fed is common method handling here.
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZED);
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOUSE);
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOPRODUCE);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END
				//SPEC: <10.22.2020>: Modified for req 18x.5 ## -- END

				swSapBomAsFed.stop();
				LOGGER.info("DPP GET SAPBO AS FED ELAPSED TIME : "+swSapBomAsFed.getTime());

			}
			
			//SPEC: 12.03.2020: Added for GendocView req 18x.5 ##41754 -- END

			if(bAllInfoView) {
				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				// SPEC : Added by Jwala for External Dev 18x.6 -- START
				mpAttribResult.put(ConstantsUtil.BUSINESSAREA, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA)));
				mpAttribResult.put(ConstantsUtil.PRODUCTTECHNOLOGYPLATFORM, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM)));
				mpAttribResult.put(ConstantsUtil.PRODUCTTECHNOLOGYCHASSIS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS)));
				mpAttribResult.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA)));
				mpAttribResult.put(ConstantsUtil.FRANCHISE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE)));
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);

				/**
				 * LOAD GPSASSESSMENTS SECTION
				 * */
				StopWatch swgps= new StopWatch();
				swgps.start();
				mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
				mpGPSAssessments = BbUtil.filterMapList(mpGPSAssessments);
				swgps.stop();
				LOGGER.info("DPP GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());

				/**
				 * LOAD ORGANIZATION DATA SECTION
				 * */
				//Provided ORGANIZATION DATA SECTION access to CM and Gendoc view as part of 18x.6
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = BbUtil.filterMapList(mpOrganization);
				
				/**
				 * LOAD IP CLASSES SECTION
				 */
				StringList slIpSelects = new StringList();
				slIpSelects.add(DomainConstants.SELECT_NAME);
				slIpSelects.add(DomainConstants.SELECT_ID);
				slIpSelects.add(DomainConstants.SELECT_CURRENT);
				slIpSelects.add(DomainConstants.SELECT_TYPE);
				slIpSelects.add(DomainConstants.SELECT_DESCRIPTION);
				mpIpSecuritySetting =DPPBO.getIpClass(context, doDPP, slIpSelects);
				
				/**
				 * LOAD SECURITY SECTION
				 * */
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO bo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =bo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				LOGGER.info("DPP Security ELAPSED TIME : "+swSecurity.getTime());

				/**
				 * LOAD PLANTS SECTION
				 * */
				StopWatch swPlant = new StopWatch();
				swPlant.start();
				mpPlantResult=fabBo.updatePlantInfo(resultMaps);
				swPlant.stop();
				LOGGER.info("DPP PLANTS ELAPSED TIME : "+swPlant.getTime());

				/**
				 * LOAD LIFECYCLE SECTION
				 * */
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = BbUtil.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("DPP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END
				/**
				 * LOAD OWNERSHIP SECTION
				 * */
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = BbUtil.filterMapList(mapOwnerShipResult);


				/**
				 * LOAD FILE SECTION
				 * */
				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				String FileSize = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));

				StringBuilder sbFileSize = new StringBuilder();
				if(!FileSize.isEmpty()) {
					String[] strFileSize=FileSize.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					for (int i = 0; i < strFileSize.length; i++) {
						String strEachFileSize = strFileSize[i];
						double dFileSize = Double.parseDouble(strEachFileSize);
						dFileSize = dFileSize/1024;
						strEachFileSize=Double.toString(dFileSize).format("%.2f", dFileSize);
						sbFileSize.append(strEachFileSize).append(" KB").append(ConstantsUtil.SYMBL_PIPE);
					}
				}	

				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END

				/**
				 * LOAD INGREDIENT STATEMENT SECTION
				 * */
				StopWatch swIngredient = new StopWatch();
				swIngredient.start();

				mpIngredientstatement = DPPBO.getIngredientstatements(context, sContextObjectId);
				mpIngredientstatement = util.filterMapList(mpIngredientstatement);

				swIngredient.stop();
				LOGGER.info("DPP INGREDIENT STATEMENT TIME : "+swIngredient.getTime());
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END

			}
			/**
			 * LOAD BOM SECTION
			 * 
			 *if the user is CM and Plant AuthoriseToUse true he should not have access to BOM - 33221*/
			if (bGendocView || bAllInfoView ){
				StopWatch swBom = new StopWatch();
				swBom.start();
				
				MapList mapList = util.getExpandedBOM(context, doDPP, ConstantsUtil.RELATIONSHIP_EBOM, 
						ConstantsUtil.TYPE_PGPHASE, slChildBusSelects, slChildRelSelects, ConstantsUtil.SELECT_NAME+"=~~PCT*", "PCT");

				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
				if ((bManufacturerView) || (bSupplierView && bHIRComplaint) ){
					mapList=BbUtil.filterPhase(mapList);
				}
				
				//SPEC: <10.22.2020>: Modified for req 18x.5 ## -- START
				if(mapList.size()!=0){
					mpEBOMResult =	DPPBO.parseMaplist(context,mapList,bSupplierView);
					
				}
				//SPEC: <10.22.2020>: Modified for req 18x.5 ## -- END

				swBom.stop();
				LOGGER.info("DPP BOM ELAPSED TIME : "+swBom.getTime());
				
				//SPEC:Added for req 18x.5 ## -- START
				
				//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- START
				/**
				 * LOAD SUBSTANCES SECTION
				 * */
				StopWatch swSubst = new StopWatch();
				swSubst.start();
				//SPEC: 12-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 49989-- START
				PackagingMaterialPartBO pmpBO = new PackagingMaterialPartBO();
				
				mpSubStanceResult = pmpBO.getSubstances(context,resultMaps);
				if(bSupplierView || bManufacturerView) {
					mpSubStanceResult=util.filterPhase(mpSubStanceResult);
					mpSubStanceResult=util.filterMapList(mpSubStanceResult);
	               
				}
				//SPEC: 12-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 49989-- END
				swSubst.stop();
				LOGGER.info("DPP GET SUBSTANCE ELAPSED TIME : "+swSubst.getTime());
				//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- END
			}
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			if(bGendocView || bAllInfoView) {
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
			}

			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.GLABALHARMONIZEDSTANDARD, mpGlobalHarStandard);
			hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATA, mapStorageAndLabelResult);
			hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
			hmAttrib.put(ConstantsUtil.MATERIALPRODUCED, mpMaterialProduced);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.STABILITYRESULTS, mpStability);
			hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
			hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult);
			hmAttrib.put(ConstantsUtil.MARKETOFCLEARANCE, mapCountryClearanceResult);
			
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)){
				hmAttrib.put(ConstantsUtil.CERTIFICATIONS, mapCertifications);
			}
			// Added by Jwala for the req 4945 - END
			
			hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
			hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.DANGEROUSGOODCLASSIFICATION, mpDangerousGoodsClf);

			//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
			hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			hmAttrib.put(ConstantsUtil.MASTERPARTSTABILITYDOC, mpMasterPartStabilityDoc);
			hmAttrib.put(ConstantsUtil.PRODUCTPARTSTABILITYDOC, mpProductPartStabilityDoc);
			//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
			
			//SPEC: Added for Dev 18x.6 Release by Jwala -- START
			hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- START
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)){
				if(mpCertificationvalidation.size()!=1 && !(strCertificationvalidation.equalsIgnoreCase(mpHeaderContent.get(DomainConstants.SELECT_NAME)))) {
					hmAttrib.put(ConstantsUtilIRM.CERTIFICATIONVALIDATION, mpCertificationvalidation);
				}
			}
			// Added by Jwala for the req 4945 - END
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- END
			hmAttrib.put(ConstantsUtilIRM.INGREDIENTSTATEMENT, mpIngredientstatement);
			hmAttrib.put(ConstantsUtil.SMARTLABEL, mpSmartLabel);
			//SPEC: Added for Dev 18x.6 Release by Jwala -- END
			
			//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- START
			hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpSubStanceResult);
			//SPEC: 07.04.2022: Jwala Added for Req 41754 22x Release  -- END
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			pool.checkIn(context);
			sp.stop();
			LOGGER.info("DPP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "DPP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		} catch (IOException e) {
			LOGGER.error("Unable to getFOPdata IOException"+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getFOPdata MatrixException"+e);
		}
		//LOGGER.info("DPP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		context.close();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmAttrib;
	}
}
