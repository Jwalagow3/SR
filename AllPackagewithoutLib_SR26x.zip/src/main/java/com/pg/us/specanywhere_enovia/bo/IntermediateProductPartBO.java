/**
 * Project 		: SpecsAnywhere
 * Program 		: IntermediateProductPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.ArrayList;
import java.util.HashMap;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class IntermediateProductPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(IntermediateProductPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	public IntermediateProductPartBO() {
		// empty constructor
	}

	public IntermediateProductPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getIPPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getIPPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getIPPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getIPPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getIPPPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getIPPPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getSubstanceSelectables(context));
		busSelect.addAll(getSecuritySelects(context));
		
		//SPEC: <10.12.2020>: Added for req 18x.5 ## -- START
		busSelect.addAll(getWeightCharacterSelectable(context));
		busSelect.addAll(getFileSelects(context));
		//SPEC: <10.12.2020>: Added for req 18x.5 ## -- END
		
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getIPPRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getIPPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}

	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.STRPGPDTTOPGPLIREFUN);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		//Added By Jwala for Defect 51177 -- START
		busSelect.add(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL);
		//Added By Jwala for Defect 51177 -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - Start
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - End
		return busSelect;
	}

	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REPORTED_FUNCTION);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RF);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		//Added by Ketan for Req. no. 46464 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC);
		//Added by Ketan for Req. no. 46464 -- END
		// Added By Satyam for the defect 51177 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMATERIALFUNCTIONGLOBAL);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMATERIALFUNCTION);
		// Added By Satyam for the defect 51177 -- END

		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END

		//Added for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
		//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
		return relSelect;
	}


	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASEPHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PARTSPECIFICATION_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_TITLE);
		busSelect.add(ConstantsUtil.SELECT_STR_SEGMENT);

		busSelect.add(ConstantsUtil.STRPGPDTTOPGPLIREFUN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPARTCOLOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS);
		busSelect.add(ConstantsUtil.STRPRINTINGPROSS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_CONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		
		//SPEC: <10.10.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		//SPEC: <10.10.2020>: Added for req 18x.5 ## -- END
		
		//Added for Defect #37196 -- START
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		//Added for Defect #37196 -- END
		// Guna Added for Defect 38723  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
		// Guna Added for Defect 38723  18x.5.2 Release -- END
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - Start
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - End
		
		return busSelect;

	}


	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context,MapList mapList, boolean bSupplierView) {
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		SecurityService sct = new SecurityService();
		
		
		//SPEC: <12.30.2020>: Modified for Req :36032 by Madhana #(BOM Expansion)# --START
				Map MPFinalEBOMSubStitute = new HashMap<String,String>();
				Map mpFinalEBOM = new HashMap();
				Map mpFinalSubstitute = new HashMap();
		//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
				int index=1;
				StringBuilder sbFEBOMName = new StringBuilder();
				StringBuilder sbFEBOMId = new StringBuilder();
				StringBuilder sbFEBOMChg = new StringBuilder();
				StringBuilder sbFEBOMFN = new StringBuilder();
				StringBuilder sbFEBOMTitle = new StringBuilder();
				StringBuilder sbFEBOMType = new StringBuilder();
				StringBuilder sbFEBOMQTY = new StringBuilder();
				StringBuilder sbFEBOMBuom = new StringBuilder();
				StringBuilder sbFEBOMCommnts = new StringBuilder();
				StringBuilder sbFEBOMState= new StringBuilder();
				StringBuilder sbFEBOMStage= new StringBuilder();
				StringBuilder sbFEBOMRDOC= new StringBuilder(); 
				StringBuilder sbFEBOMRevRelDt= new StringBuilder();
				StringBuilder sbFEBOMTupName= new StringBuilder();		 
				StringBuilder sbFMinqty= new StringBuilder();
				StringBuilder sbFMaxqty= new StringBuilder();
				StringBuilder sbFNetWUOM= new StringBuilder();
				StringBuilder sbFNetWet= new StringBuilder();
				StringBuilder sbFLoss= new StringBuilder();
				StringBuilder sbFMF= new StringBuilder();
				StringBuilder sbFGW= new StringBuilder();
				StringBuilder sbFAltName = new StringBuilder();
				StringBuilder sbFAltID = new StringBuilder();
				StringBuilder sbFAltType = new StringBuilder();
				StringBuilder sbFNet= new StringBuilder();
				StringBuilder sbFOSPD= new StringBuilder();
				StringBuilder sbFDen= new StringBuilder();
				StringBuilder sbFRF = new StringBuilder();
				StringBuilder sbFEBOMSubstitutePart = new StringBuilder();
				StringBuilder sbFEBOMSubPartID = new StringBuilder();
				StringBuilder sbFEBOMSubPartType = new StringBuilder();
				StringBuilder sbfGrossWeightReal = new StringBuilder();
				StringBuilder sbfGrossWeightUOM = new StringBuilder (0);
				//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
				StringBuilder sbEBOMParentName = new StringBuilder();
				StringBuilder sbEBOMParentId = new StringBuilder();
				StringBuilder sbEBOMParentRevision = new StringBuilder();
				StringBuilder sbEBOMParentType = new StringBuilder();
				//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
				//Added by Subhajit for Req 46464 - Start
				StringBuilder sbFRelRestriction = new StringBuilder();
				StringBuilder sbFRelRestrictionComment = new StringBuilder();
				//Added by Subhajit for Req 46464 - End
				MapList mlEBOMSubList = new MapList();
				//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS

				try 
				{
					Map objectMap = null;
					Map<String, String> mpSubstituteResult = null;
					MapList mlPhaseEBOMList = null;
					int iParentLevel = 0;
					StringList slParentId = new StringList();
					String sParentId = ConstantsUtil.EMPTY_STRING;
					
					for(int i =0; i<mapList.size(); i++)
					{
						objectMap = (Map) mapList.get(i);
						iParentLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));
						
						mpSubstituteResult = new HashMap<String, String>();
						mpEBOMResult = new HashMap<String, String>();
						mlPhaseEBOMList = new MapList();
						sParentId = ConstantsUtil.EMPTY_STRING;
						//SPEC: <12.30.2020>: Modified for Req :36032 by Madhana #(BOM Expansion)# --ENDS
						Iterator objectListItr = mapList.iterator();
						StringBuilder sbEBOMName = new StringBuilder();
						StringBuilder sbEBOMId = new StringBuilder();
						StringBuilder sbEBOMChg = new StringBuilder();
						StringBuilder sbEBOMFN = new StringBuilder();
						StringBuilder sbEBOMTitle = new StringBuilder();
						StringBuilder sbEBOMType = new StringBuilder();
						StringBuilder sbEBOMQTY = new StringBuilder();
						StringBuilder sbEBOMBuom = new StringBuilder();
						StringBuilder sbEBOMCommnts = new StringBuilder();
						StringBuilder sbEBOMState= new StringBuilder();
						StringBuilder sbEBOMStage= new StringBuilder();
						StringBuilder sbEBOMRDOC= new StringBuilder(); 
						StringBuilder sbEBOMRevRelDt= new StringBuilder();
						StringBuilder sbEBOMTupName= new StringBuilder();		 
						StringBuilder sbMinqty= new StringBuilder();
						StringBuilder sbMaxqty= new StringBuilder();
						StringBuilder sbNetWUOM= new StringBuilder();
						StringBuilder sbNetWet= new StringBuilder();
						StringBuilder sbLoss= new StringBuilder();
						StringBuilder sbMF= new StringBuilder();
						StringBuilder sbGW= new StringBuilder();
						// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
						//StringBuilder sbAlt= new StringBuilder();
						StringBuilder sbAltName = new StringBuilder();
						StringBuilder sbAltID = new StringBuilder();
						StringBuilder sbAltType = new StringBuilder();
						// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
						StringBuilder sbNet= new StringBuilder();
						StringBuilder sbOSPD= new StringBuilder();
						StringBuilder sbDen= new StringBuilder();
						//SPEC: <10.10.2020>: Added for req 18x.5 ## -- START
						StringBuilder sbRF = new StringBuilder();
						StringBuilder sbEBOMSubstitutePart = new StringBuilder();
						StringBuilder sbEBOMSubPartID = new StringBuilder();
						StringBuilder sbEBOMSubPartType = new StringBuilder();
						//SPEC: <10.10.2020>: Added for req 18x.5 ## -- END
						StringBuilder sbGrossWeightReal = new StringBuilder();
						StringBuilder sbGrossWeightUOM = new StringBuilder();
						//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
						String sEBOMParentId =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID);
						String sEBOMParentName =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME);
						String sEBOMParentRevision =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV);
						String sEBOMParentType =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE);
						//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
						//Added by Subhajit for Req 46464 - Start
						String sRelRestriction = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
						String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;	
						//Added by Subhajit for Req 46464 - End
					String sPId =(String)objectMap.get(ConstantsUtil.SELECT_ID);
					String sFormulaPropagate = sPId;
					String sName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
					String sRevision =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sReleaseDate =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
					String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					String spgChg =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
					String sFN =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
					String sTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sPType =(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sTupName =(String)objectMap.get(ConstantsUtil.TUPNAME);
					String sQty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					String sBuom =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					String sComments=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					String sCurrent =(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
					//SPEC : 12/03/2020 : added for defect#37732 by Madhana --START
					sCurrent = util.mapType(sCurrent);
					//SPEC : 12/03/2020 : added for defect#37732 by Madhana --END
					String sStage =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
					String sRD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
					sRD = sRD.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
					String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
					sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
					String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
					String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
					String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
					String strNetWUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
					String strNetWet =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
					String strGrossWeightReal = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
					String strGrossWeightUOM = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
					//Commented by Ketan for Req. no. 47950
					/*if(null!=strNetWet && strNetWet.isEmpty()) {
						strNetWet="0.0";
					}*/
					String strLoss =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
					
					//Commented by Ketan for Req. no. 47950
					/*if(strLoss.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
						strLoss = ConstantsUtil.GEN_NUM_ZERO;*/
					
					// Added By Jwala for the defect 51177 -- START
					String strMF = DomainConstants.EMPTY_STRING;
					if(ConstantsUtil.tRMP.equalsIgnoreCase(sPType)) {
					strMF =(String)objectMap.get(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL);
					} else {
					strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
					}
					// Added By Jwala for the defect 51177 -- ENDS
					
					String strGW =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
					strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					String strAltID = util.checkAlternateHasAccess(context,objectMap);	
					String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
					strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		
					String strNet =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
					//Commented by Ketan for Req. no. 47950
					/*if(strNet.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
						strNet = ConstantsUtil.GEN_NUM_ZERO;*/
		
					String strOSPD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
					String strDenUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
					
					//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
					String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
					strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
					strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
					String strRF =(String)objectMap.get(ConstantsUtil.STRPGPDTTOPGPLIREFUN);
					//SPEC: <10.10.2020>: Added for req 18x.5 ## -- END
					//SPEC: <02.14.2021>: Sumit Added for Defect :39404 ## --START
					if(!validator.isNotNullOrEmpty(strRF))
						strRF = ConstantsUtil.EMPTY_STRING;
					//SPEC: <02.14.2021>: Sumit Added for Defect :39404 ## --ENDS
					String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
					
					boolean showData = false;
					boolean showDataParent = false;
					if(util.isModificatinRequired())
					{
						showData=util.checkHasAccess(context, null, sPId);
						if(!showData)
						{
							spgChg = ConstantsUtil.NO_ACCESS;
							sPId = ConstantsUtil.NO_ACCESS;
							sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						}
						showDataParent=util.checkHasAccess(context, null, sEBOMParentId);
						if(!showDataParent)
						{
							sEBOMParentId = ConstantsUtil.NO_ACCESS;
						}
					}else if(sct.isStaffAUGUser()) {
		
						showData=util.checkHasAccess(context, null, sPId);
						showDataParent=util.checkHasAccess(context, null, sEBOMParentId);
					}else{
		
						showData=util.checkHasAccess(context, null, sPId);
						showDataParent=util.checkHasAccess(context, null, sEBOMParentId);
					}
					if(!showData){
						sPId = ConstantsUtil.NO_ACCESS;
						spgChg = ConstantsUtil.NO_ACCESS;
					}
					if(!showDataParent){
						sEBOMParentId = ConstantsUtil.NO_ACCESS;
					}
		
					sPType = util.mapType(sPType);
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
					 mlPhaseEBOMList.add(objectMap);
					if(!sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1) {
						util.formatData(sbFEBOMType,sPType);
						util.formatData(sbFEBOMName,sName);
						util.formatData(sbFEBOMQTY,sQty);
						util.formatData(sbFEBOMBuom,sBuom);
						util.formatData(sbFEBOMState,sCurrent);
						util.formatData(sbFEBOMId,sPId);
						util.formatData(sbFEBOMChg,spgChg);
						util.formatData(sbFEBOMFN,sFN);
						util.formatData(sbFEBOMTitle,sTitle);
						util.formatData(sbFEBOMCommnts,sComments);
						util.formatData(sbFEBOMStage,sStage);
						util.formatData(sbFEBOMRDOC,sRDOC);
						util.formatData(sbFEBOMRevRelDt,sRevRelease);
						util.formatData(sbFMinqty,strMinqty);
						util.formatData(sbFMaxqty,strMaxqty);
						util.formatData(sbFNetWUOM,strNetWUOM);
						util.formatData(sbFNetWet,strNetWet);
						util.formatData(sbFLoss,strLoss);
						util.formatData(sbFMF,strMF);
						util.formatData(sbFGW,strGW);
						util.formatData(sbFAltName,strAltName);
						util.formatData(sbFAltID,strAltID);
						util.formatData(sbFAltType,strAltType);
						util.formatData(sbFNet,strNet);
						util.formatData(sbFOSPD,strOSPD);
						util.formatData(sbFDen,strDenUOM);
						util.formatData(sbFRF, strRF);
						util.formatData(sbFEBOMSubstitutePart, strSubPart);
						util.formatData(sbFEBOMSubPartID, strSubPartId);
						util.formatData(sbFEBOMSubPartType, strSubPartType);
						util.formatData(sbfGrossWeightReal, strGrossWeightReal);
						util.formatData(sbfGrossWeightUOM, strGrossWeightUOM);
						//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
						util.formatData(sbEBOMParentId,sEBOMParentId);
						util.formatData(sbEBOMParentName,sEBOMParentName);
						util.formatData(sbEBOMParentRevision,sEBOMParentRevision);
						sEBOMParentType = util.mapType(sEBOMParentType);
						util.formatData(sbEBOMParentType,sEBOMParentType);
						//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
						//Added by Subhajit for Req 46464 - Start
						util.formatData(sbFRelRestriction,sRelRestriction);
						util.formatData(sbFRelRestrictionComment,sRelRestrictionComment);
						//Added by Subhajit for Req 46464 - End
						if(null!=sTupName && !sTupName.isEmpty()) {
							util.formatData(sbFEBOMTupName,sTupName);
						}
						if(!mlPhaseEBOMList.isEmpty()) {
							mlEBOMSubList.addAll(mlPhaseEBOMList);
						}
					} else {
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
						// Security req -33193 HIR Components Attributes to Show
						util.formatData(sbEBOMType,sPType);
						util.formatData(sbEBOMName,sName);
						util.formatData(sbEBOMQTY,sQty);
						util.formatData(sbEBOMBuom,sBuom);
						util.formatData(sbEBOMState,sCurrent);
			
						util.formatData(sbEBOMId,sPId);
						util.formatData(sbEBOMChg,spgChg);
						util.formatData(sbEBOMFN,sFN);
						util.formatData(sbEBOMTitle,sTitle);
						util.formatData(sbEBOMCommnts,sComments);
						util.formatData(sbEBOMStage,sStage);
						util.formatData(sbEBOMRDOC,sRDOC);
						util.formatData(sbEBOMRevRelDt,sRevRelease);
						util.formatData(sbMinqty,strMinqty);
						util.formatData(sbMaxqty,strMaxqty);
						util.formatData(sbNetWUOM,strNetWUOM);
						util.formatData(sbNetWet,strNetWet);
						util.formatData(sbLoss,strLoss);
						util.formatData(sbMF,strMF);
						util.formatData(sbGW,strGW);
						// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
						//util.formatData(sbAlt,strAlt);
						util.formatData(sbAltName,strAltName);
						util.formatData(sbAltID,strAltID);
						util.formatData(sbAltType,strAltType);
						// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
						util.formatData(sbNet,strNet);
						util.formatData(sbOSPD,strOSPD);
						util.formatData(sbDen,strDenUOM);
						//SPEC: <10.10.2020>: Added for req 18x.5 ## -- START
						util.formatData(sbRF, strRF);
						util.formatData(sbEBOMSubstitutePart, strSubPart);
						util.formatData(sbEBOMSubPartID, strSubPartId);
						util.formatData(sbEBOMSubPartType, strSubPartType);
						//SPEC: <10.10.2020>: Added for req 18x.5 ## -- END
						util.formatData(sbGrossWeightReal, strGrossWeightReal);
						util.formatData(sbGrossWeightUOM, strGrossWeightUOM);
			
						if(null!=sTupName && !sTupName.isEmpty()) {
							util.formatData(sbEBOMTupName,sTupName);
						}
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
					}
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
					
					//SPEC: <12.30.2020>: Added for Req :36032 by Madhana #(BOM Expansion)# --START
					int j = 0;
					int iNextLevel = 0;
					Map objectMaps =null;
					//SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --START
					//if(sPType.equals(ConstantsUtil.TYPE_PGPHASE) || iParentLevel == 1){
					 if(sPType.equals(ConstantsUtil.TYPE_PGPHASE)){
						 sParentId=sFormulaPropagate;
						 //SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --ENDS
						 
						 for(j =i+1; j<mapList.size(); j++)
						 {
							iNextLevel = 0;
							objectMaps = (Map) mapList.get(j);
							int iCurrLevel = Integer.parseInt((String) objectMaps.get(ConstantsUtil.SELECT_LEVEL));
							if(j < mapList.size()-1) {
								Map objectNxtMaps = (Map) mapList.get(j+1);
								iNextLevel = Integer.parseInt((String) objectNxtMaps.get(ConstantsUtil.SELECT_LEVEL));
							}
							if((iParentLevel+1 == iCurrLevel) && sPType.equals(ConstantsUtil.TYPE_PGPHASE)) {
								
								mlPhaseEBOMList.add(objectMaps);
								String sId =(String)objectMaps.get(ConstantsUtil.SELECT_ID);
								sName =(String)objectMaps.get(ConstantsUtil.SELECT_NAME);
								sRevision =(String)objectMaps.get(ConstantsUtil.SELECT_REVISION);
								sReleaseDate =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
								sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
								spgChg =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
								sFN =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
								sTitle =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
								String sType =(String)objectMaps.get(ConstantsUtil.SELECT_TYPE);
								sTupName =(String)objectMaps.get(ConstantsUtil.TUPNAME);
								sQty =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
								sBuom =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
								sComments=(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
								sCurrent =(String)objectMaps.get(ConstantsUtil.SELECT_CURRENT);
								//SPEC : 12/03/2020 : added for defect#37732 by Madhana --START
								sCurrent = util.mapType(sCurrent);
								//SPEC : 12/03/2020 : added for defect#37732 by Madhana --END
								sStage =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
								sRD =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
								sRD = sRD.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
								sOC =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
								sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
								sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
								strMinqty =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
								strMaxqty =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
								strNetWUOM =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
								strNetWet =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
								/*if(null!=strNetWet && strNetWet.isEmpty()) {
									strNetWet="0.0";
								}*/
								strGrossWeightReal = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
								strGrossWeightUOM = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
								strLoss =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
								
								/*if(strLoss.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
									strLoss = ConstantsUtil.GEN_NUM_ZERO;*/
								// Added By Jwala for the defect 51177 -- START
								if(ConstantsUtil.tRMP.equalsIgnoreCase(sType)) {
								strMF =(String)objectMap.get(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL);
								} else {
								strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
								}
								// Added By Jwala for the defect 51177 -- END
								strGW =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);
								// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
								//String strAlt =(String)objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
								//strAlt = strAlt.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
								strAltName =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
								strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
								strAltID = util.checkAlternateHasAccess(context,objectMap);	
								strAltType =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
								strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
								// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					
								strNet =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
								
								/*if(strNet.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
									strNet = ConstantsUtil.GEN_NUM_ZERO;*/
					
								strOSPD =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
								strDenUOM =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
								
								//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
								strSubPart = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
								strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
								strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
								strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
								strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
								strRF =(String)objectMaps.get(ConstantsUtil.STRPGPDTTOPGPLIREFUN);
								//SPEC: <10.10.2020>: Added for req 18x.5 ## -- END
								//SPEC: <02.14.2021>: Sumit Added for Defect :39404 ## --START
								if(!validator.isNotNullOrEmpty(strRF))
									strRF = ConstantsUtil.EMPTY_STRING;
								//SPEC: <02.14.2021>: Sumit Added for Defect :39404 ## --ENDS
								strClassFied = validator.getStringEquivalentForStringList((objectMaps.get(ConstantsUtil.STR_IPCLASS)));
								
								showData = false;
								if(util.isModificatinRequired())
								{
									showData=util.checkHasAccess(context, null, sId);
									if(!showData)
									{
										spgChg = ConstantsUtil.NO_ACCESS;
										sId = ConstantsUtil.NO_ACCESS;
										sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
									}
								}else if(sct.isStaffAUGUser()) {
					
									showData=util.checkHasAccess(context, null, sId);
								}else{
					
									showData=util.checkHasAccess(context, null, sId);
								}
								if(!showData){
									sId = ConstantsUtil.NO_ACCESS;
									spgChg = ConstantsUtil.NO_ACCESS;
								}
					
								sType = util.mapType(sType);
					
								// Security req -33193 HIR Components Attributes to Show
								util.formatData(sbEBOMType,sType);
								util.formatData(sbEBOMName,sName);
								util.formatData(sbEBOMQTY,sQty);
								util.formatData(sbEBOMBuom,sBuom);
								util.formatData(sbEBOMState,sCurrent);
					
								util.formatData(sbEBOMId,sId);
								util.formatData(sbEBOMChg,spgChg);
								util.formatData(sbEBOMFN,sFN);
								util.formatData(sbEBOMTitle,sTitle);
								util.formatData(sbEBOMCommnts,sComments);
								util.formatData(sbEBOMStage,sStage);
								util.formatData(sbEBOMRDOC,sRDOC);
								util.formatData(sbEBOMRevRelDt,sRevRelease);
								util.formatData(sbMinqty,strMinqty);
								util.formatData(sbMaxqty,strMaxqty);
								util.formatData(sbNetWUOM,strNetWUOM);
								util.formatData(sbNetWet,strNetWet);
								util.formatData(sbLoss,strLoss);
								util.formatData(sbMF,strMF);
								util.formatData(sbGW,strGW);
								// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
								util.formatData(sbAltName,strAltName);
								util.formatData(sbAltID,strAltID);
								util.formatData(sbAltType,strAltType);
								// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
								util.formatData(sbNet,strNet);
								util.formatData(sbOSPD,strOSPD);
								util.formatData(sbDen,strDenUOM);
								util.formatData(sbRF, strRF);
								util.formatData(sbEBOMSubstitutePart, strSubPart);
								util.formatData(sbEBOMSubPartID, strSubPartId);
								util.formatData(sbEBOMSubPartType, strSubPartType);
								util.formatData(sbGrossWeightReal, strGrossWeightReal);
								util.formatData(sbGrossWeightUOM, strGrossWeightUOM);
					
								if(null!=sTupName && !sTupName.isEmpty()) {
									util.formatData(sbEBOMTupName,sTupName);
								}
							}
							//SPEC: <01.21.2021>: Modified for Defect : 38181 by Sumit --START
							if(iParentLevel+1 > iNextLevel || iParentLevel == iCurrLevel) {
							//SPEC: <01.21.2021>: Added for Defect : 38181 by Sumit --ENDS	
								break;
							} 		
						}
						//Get Substitutes
					mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
					mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
					mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
					mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
					mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
					mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
					mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
					mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
					mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
					mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
					mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
					mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
					mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
					mpEBOMResult.put(ConstantsUtil.NETWEIGHTUOM, sbNetWUOM.toString());
					mpEBOMResult.put(ConstantsUtil.NETWEIGHT, sbNetWet.toString());
					mpEBOMResult.put(ConstantsUtil.LOSS, sbLoss.toString());
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
		
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
					mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
					mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					mpEBOMResult.put(ConstantsUtil.NET, sbNet.toString());
					mpEBOMResult.put(ConstantsUtil.OSPD, sbOSPD.toString());
					mpEBOMResult.put(ConstantsUtil.DUOM, sbDen.toString());
					//SPEC: <10.10.2020>: Added for req 18x.5 ## -- START
					mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbRF.toString());
					mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbMF.toString());
					mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
					mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
					mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
					//SPEC: <10.10.2020>: Added for req 18x.5 ## -- END
		
					if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
						mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
					}
					//SPEC: <12.30.2020>: Added for Req :36032 by Madhana #(BOM Expansion)# --START
					 }
					//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --START
					 if(!mpEBOMResult.isEmpty() && validator.isNotNullOrEmpty(sParentId) && (!slParentId.contains(sParentId) || (slParentId.contains(sParentId) && !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1))) {
					//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --ENDS
						 slParentId.add(sParentId);
						mpFinalEBOM.put(String.valueOf(index), mpEBOMResult);
						//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --START
						if(!mlPhaseEBOMList.isEmpty()) {
							mlEBOMSubList.addAll(mlPhaseEBOMList);
						}
						//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --ENDS
						index++;
					 }
				}
				
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
					mpEBOMResult = new HashMap();
					if(null != sbFEBOMId && sbFEBOMId.length()>0) {
						mpEBOMResult.put(ConstantsUtil.ID, sbFEBOMId.toString());
						mpEBOMResult.put(ConstantsUtil.NAME, sbFEBOMName.toString());
						mpEBOMResult.put(ConstantsUtil.CHG, sbFEBOMChg.toString());
						mpEBOMResult.put(ConstantsUtil.FN, sbFEBOMFN.toString());
						mpEBOMResult.put(ConstantsUtil.TITLE, sbFEBOMTitle.toString());
						mpEBOMResult.put(ConstantsUtil.TYPE, sbFEBOMType.toString());
						mpEBOMResult.put(ConstantsUtil.QTY, sbFEBOMQTY.toString());
						mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbFEBOMBuom.toString());
						mpEBOMResult.put(ConstantsUtil.COMMENTS, sbFEBOMCommnts.toString());
						mpEBOMResult.put(ConstantsUtil.STATE, sbFEBOMState.toString());
						mpEBOMResult.put(ConstantsUtil.PHASE, sbFEBOMStage.toString());
						mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbFEBOMRDOC.toString());
						mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbFEBOMRevRelDt.toString());
						mpEBOMResult.put(ConstantsUtil.NETWEIGHTUOM, sbFNetWUOM.toString());
						mpEBOMResult.put(ConstantsUtil.NETWEIGHT, sbFNetWet.toString());
						mpEBOMResult.put(ConstantsUtil.LOSS, sbFLoss.toString());
						mpEBOMResult.put(ConstantsUtil.ALTNAME, sbFAltName.toString());
						mpEBOMResult.put(ConstantsUtil.ALTID, sbFAltID.toString());
						mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbFAltType.toString());
						mpEBOMResult.put(ConstantsUtil.NET, sbFNet.toString());
						mpEBOMResult.put(ConstantsUtil.OSPD, sbFOSPD.toString());
						mpEBOMResult.put(ConstantsUtil.DUOM, sbFDen.toString());
						mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbFRF.toString());
						mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbFMF.toString());
						mpEBOMResult.put(ConstantsUtil.SP, sbFEBOMSubstitutePart.toString());
						mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbFEBOMSubPartType.toString());
						mpEBOMResult.put(ConstantsUtil.SP_ID, sbFEBOMSubPartID.toString());
						mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbfGrossWeightReal.toString());
						mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbfGrossWeightUOM.toString());
						//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
						mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
						mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
						mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
						mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
						//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
						//Added by Subhajit for Req 46464 - Start
						mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbFRelRestriction.toString());
						mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbFRelRestrictionComment.toString());
						//Added by Subhajit for Req 46464 - End
						
						if (null != sbFEBOMTupName && sbFEBOMTupName.length()>0) {
							mpEBOMResult.put(ConstantsUtil.TUPNAME, sbFEBOMTupName.toString());
						}
						
						//Added by Ketan for Req. no. 46464 -- START
						if(bSupplierView) {
							mpEBOMResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTION);
							mpEBOMResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS);
						}
						//Added by Ketan for Req. no. 46464 -- END
						
						if(!mpEBOMResult.isEmpty()) {
							mpFinalEBOM.put(String.valueOf(0), mpEBOMResult);
						}
					}
					mpSubstituteResult = parseSubstitute(context,mlEBOMSubList);
					
					//Added by Ketan for Req. no. 46464 -- START
					if(bSupplierView) {
						mpSubstituteResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTION);
						mpSubstituteResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS);
					}
					//Added by Ketan for Req. no. 46464 -- END
					
					if(!mpSubstituteResult.isEmpty()) {
						HashMap mpSubstitute = new HashMap();
						mpSubstitute.put(String.valueOf(0), mpSubstituteResult);
						mpFinalSubstitute.put(String.valueOf(0), mpSubstitute);
					}
					
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
				MPFinalEBOMSubStitute.put(ConstantsUtil.BILLOFMATERIALS, mpFinalEBOM);
				MPFinalEBOMSubStitute.put(ConstantsUtil.SUBSTITUTEPARTS, mpFinalSubstitute);

	} catch (Exception e) {
		e.printStackTrace();
		LOGGER.error("Exception in IPPBO:  parseMaplist: " + e);
	}
	return MPFinalEBOMSubStitute;
	//return util.filterMapList(mpEBOMResult);
	//SPEC: <12.30.2020>: Added for Req :36032 by Madhana #(BOM Expansion)# --ENDS		
}



	/**
	 * Method Name 			: addMultiSelects
	 * Method Description 	:
	 */
	public StringList addMultiSelects() {
		
		StringList slMultiSelects = new StringList();

		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		slMultiSelects.add(ConstantsUtil.COMP_TYPE); 
		slMultiSelects.add(ConstantsUtil.COMP_ID); 
		slMultiSelects.add(ConstantsUtil.COMP_NAME);
		slMultiSelects.add(ConstantsUtil.COMP_SUBNAME);
		slMultiSelects.add(ConstantsUtil.COMP_TITLE);
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT);
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);
		slMultiSelects.add(ConstantsUtil.COMP_QTY);
		slMultiSelects.add(ConstantsUtil.COMP_ISCONTAM);
		slMultiSelects.add(ConstantsUtil.COMP_CASNUM);
		slMultiSelects.add(ConstantsUtil.COMP_STATE);
		slMultiSelects.add(ConstantsUtil.COMP_REVS);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC);
		slMultiSelects.add(ConstantsUtil.COMP_DRYWEIGHT);
		slMultiSelects.add(ConstantsUtil.COMP_FUNCTIONS);
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_CURRENT);

		slMultiSelects.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		slMultiSelects.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		slMultiSelects.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		
		return slMultiSelects;
	}

	
	/**
	 * Method Name 			: removeMultiselects
	 * Method Description 	:
	 */
	public void removeMultiselects()
	{  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SUBNAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ISCONTAM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DRYWEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_FUNCTIONS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);


		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END
		// Guna Added for Defect 38531  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		// Guna Added for Defect 38531  18x.5.2 Release -- END
		// Guna Added for Defect 38723  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME);
		// Guna Added for Defect 38723  18x.5.2 Release -- END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END

	}
	
	
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	: Fetching "Substances" related data 
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) 
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID); 
		busSelect.add(ConstantsUtil.COMP_NAME);
		busSelect.add(ConstantsUtil.COMP_SUBNAME);
		busSelect.add(ConstantsUtil.COMP_TITLE);
		busSelect.add(ConstantsUtil.COMP_MAXHGHT);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT);
		busSelect.add(ConstantsUtil.COMP_QUOM);
		busSelect.add(ConstantsUtil.COMP_QTY);
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);
		busSelect.add(ConstantsUtil.COMP_CASNUM);
		busSelect.add(ConstantsUtil.COMP_STATE);
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC);
		busSelect.add(ConstantsUtil.COMP_DRYWEIGHT);
		busSelect.add(ConstantsUtil.COMP_FUNCTIONS);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_CURRENT);
		
		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		 
		return busSelect;
	}
	
	//SPEC: <10.10.2020>: Added for req 18x.5 ## -- START
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	
	
	/**
	 * Method Name 			: getWeightCharacterSelectable
	 * Method Description 	: Fetching "Weight Characteristics" related data
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharacterSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		try
		{
			String sType    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REVS));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sDesc	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_DESC));
			//String sTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sTitle	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_TITLE));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sCurrent =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_STATE));
			sCurrent=sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sCAS 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			String sCAS 	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sSub 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SUBNAME));
			String sQTS 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QSTCOMPOSITE));
			String sCont    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_ISCONTAM));
			String sQTY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE));
			String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE));
			String sQUOM    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));	

			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sMlLgc   =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sMFR     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String sMFR     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MANUF));
			//String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sCMT     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_COMENT));
			//String sTrN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sTrN     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sMLyr    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sDRY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DRYWEIGHT));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sFunctions =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_FUNCTIONS));
			String sFunctions =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_FUNCTIONS));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String sQTYtype = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sUF = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.EMPTY_STRING));
			
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);

			sType = util.mapType(sType);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.REV,sRev);
			mpSubStanceResult.put(ConstantsUtil.STATE,sCurrent);
			mpSubStanceResult.put(ConstantsUtil.CAS,sCAS);
			//mpSubStanceResult.put(ConstantsUtil.SUBSTANCENAME,sSub);
			mpSubStanceResult.put(ConstantsUtil.QSTARGET,sQTS);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			//mpSubStanceResult.put(ConstantsUtil.IC,sCont);
			mpSubStanceResult.put(ConstantsUtil.IP,sCont);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.UOM,sQUOM);

			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sDRY);
			mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sFunctions);
			mpSubStanceResult.put(ConstantsUtil.PHASE, strPhase);
			//mpSubStanceResult.put(ConstantsUtil.QUANTITYTYPE, sQTS);
			mpSubStanceResult.put(ConstantsUtil.UF, sUF);

		}catch(Exception e){

			LOGGER.error("Error from IPPBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	/**
	 * Method Name 			: updatePartSpec
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map updatePartSpec(Context context, Map objectMap) {
		StringValidatorUtil validator = new StringValidatorUtil();

		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

							mpPartSpecs = getPartSpecifications(context, sType, sID);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : IPPBO Method :getPartSpecifications " + e);
			return new HashMap();

		}
		return util.filterMapList(mpPartSpecs);
	}
	
	
	/**
     * Method Name 			: getPartSpecifications
     * Method Description 	:
     * @param context
     * @param sParentType
     * @param sObjectID
     * @return
     * @throws Exception
     */
    public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		boolean showData = false;
		
		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;
		
		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
			sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		}

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
					slPartSpecSelects, null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END	
			
			
				if (util.isModificatinRequired()) {
					//commented by Ganesh for security impl---->start
					/*if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {

						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteString(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
								String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							}

						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

						}

					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = util.updateReferences(context, strId);
								LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
									String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
									//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

								}
							}
						}else
						{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					}*/
					//commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl----->start
					bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
					if (bHasOwnerShip) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
						 strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					}
					//modified by Ganesh for security impl------>end

				} else {
					//commented by Ganesh for security impl----->start
					/*if(sct.isStaffAUGUser()) {
						
						if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else if("ArtiosCAD Component".equalsIgnoreCase(strType)){
							showData=util.checkInternalUserAcess(sUserlicense,strAutocadClassFied);
						}else{
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
						
						if(slHIRTypes.contains(strType)) {
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}else {
							showData=true;
						}
						
					}*/
					//commented by Ganesh for security impl----->end
					//modified by Ganesh for security impl----->start
					showData = util.checkHasAccess(context, sUserType, strId);
					//modified by Ganesh for security impl----->end
					
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						//temporary fix to prevent users from downloading a Physical product(VPMReference)
						if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
							sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
						}else {
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
							/*String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
							//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
						}
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					}

					
				}

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
				mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
				mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			}

		} catch (FrameworkException e) {
			LOGGER.error("Exception in IPPBO getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}
   
    
    /**
     * Method Name 			: getMasterSpecs
     * Method Description 	:
     * @param context
     * @param sObjectId
     * @return
     */
    public Map<String, String> getMasterSpecs(Context context, String sObjectId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpMasterSpecs = new HashMap<String, String>();
		String sMasterObjectId = ConstantsUtil.EMPTY_STRING;
		String sMasterObjectClassfiedItem = ConstantsUtil.EMPTY_STRING;
		try {
			DomainObject domChild = new DomainObject(sObjectId);
			sMasterObjectId = domChild.getInfo(context, ConstantsUtil.STR_MASTER_ID);

			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtil.STR_MASTER_ID);
			slSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			Map mp = domChild.getInfo(context, slSelects);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domChild.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			if (!mp.isEmpty()) {
				sMasterObjectId = validator.getStringEquivalentForStringList(mp.get(ConstantsUtil.STR_MASTER_ID));
				sMasterObjectClassfiedItem = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME));
			}

			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			if (UIUtil.isNotNullAndNotEmpty(sMasterObjectId)) {
				mpMasterSpecs = getMasterPartSpecifications(context, sMasterObjectId, sMasterObjectClassfiedItem);
			} else {
				return new HashMap();
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : IPPBO Method :getMasterSpecs " + e);
			return new HashMap();
		}
		return mpMasterSpecs;
	}
    
    
    /**
     * Method Name 			: getMasterPartSpecifications
     * Method Description 	:
     * @param context
     * @param sObjectID
     * @param sMasterObjectClassfiedItem
     * @return
     * @throws Exception
     */
    public Map<String, String> getMasterPartSpecifications(Context context, String sObjectID,
			String sMasterObjectClassfiedItem) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringBuilder sbMasterPartName = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION + "," + ConstantsUtil.REL_PG_INHERITED_CAD_SPEC,
					ConstantsUtil.SYMBL_ASTERISK, slPartSpecSelects, null, false, true, (short) 1, sWhere,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String sIpClass =validator.getStringEquivalentForStringList((mpEachObj.get(ConstantsUtil.STR_IPCLASS)));

				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				
				String strMasterPartName = ConstantsUtil.EMPTY_STRING;
				String strMasterPart = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.strPARTSPEC));
				if(strMasterPart.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART)) {
					strMasterPartName = strMasterPart;
				}
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;

				if (util.isModificatinRequired())
				{
                 //commented by Ganesh for security impl------start
					/*if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) 
					{
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
							}
						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = util.updateReferences(context, strId);
								LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
								}
							}
						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else 
					{
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							String strPhase = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);

						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}

					}*/
					//commented by Ganesh for security impl------end
					//modified by Ganesh for security impl------start
					bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
					if (bHasOwnerShip) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						String strPhase = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);

					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					}
					//modified by Ganesh for security impl------end
				}else if(sct.isStaffAUGUser()) {
                     //commented by Ganesh for security impl----->start
					/*if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,sIpClass);*/
					 //commented by Ganesh for security impl----->end
					 //modified by Ganesh for security impl----->start
					showData = util.checkHasAccess(context, sUserType, strId);
					 //modified by Ganesh for security impl----->end
						
						if (showData) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					//}
				} else {
					//commented by Ganesh for security impl----->start
					/*if (sIPClassfication.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED)) {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						if (null != sUserlicense && null != strClassFied && !sUserlicense.contains(strClassFied.trim())) {
							showData = false;
						}

						if (showData) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {

						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
					}*/
					//commented by Ganesh for security impl----->end
					//modified by Ganesh for security impl----->start
					showData = util.checkHasAccess(context, sUserType, strId);
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					}
					//modified by Ganesh for security impl----->end
				}

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			mpFinalList.put(ConstantsUtil.MASTERPARTNAME, sbMasterPartName.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Exception in IPPBO getMasterPartSpecifications: " + e);
			return new HashMap();
		}
		return util.filterMapList(mpFinalList);
	}

    

        
    /**
	 * Method Name 			: updateSecurity
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> updateSecurity(Map objectMap) {
		
		Map<String, String> mpSecurity = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			String sName=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME));
			String sLibrary=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME));
			String sCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE));
			String sType=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE));
			String sDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC));
			String Name[]=sName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			String Library[]=sLibrary.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			String Type[]=sType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			
			StringBuilder sbHasAccess = new StringBuilder();
			
			if(!sType.isEmpty()){

				for (int i = 0; i < Type.length; i++)
				{
					/*
					if(UIUtil.isNotNullAndNotEmpty(Name[i]) && UIUtil.isNotNullAndNotEmpty(Library[i]))
					{
						sbSecurityClasspath.append(Library[i]).append(ConstantsUtil.SYMBL_ARROW).append(Name[i]);
						mpSecurity.put(ConstantsUtil.CLASSPATH, sbSecurityClasspath.toString());
					}else
					{
						sbSecurityClasspath.append(ConstantsUtil.EMPTY_STRING);
					}
					*/
					if (UIUtil.isNotNullAndNotEmpty(Type[i])) {
						if ((sType).equalsIgnoreCase(ConstantsUtil.TYPE_SECURITYCONTROLCLASS)) {
							sbHasAccess.append("TRUE");
							
						}
						else {
							sbHasAccess.append("FALSE");
						}
					}
				}
			} 
			
			mpSecurity.put(ConstantsUtil.TYPE, sType);
			mpSecurity.put(ConstantsUtil.NAME, sName);
			mpSecurity.put(ConstantsUtil.STATE, sCurrent);
			mpSecurity.put(ConstantsUtil.DESCRIPTION, sDesc);
			//mpSecurity.put(ConstantsUtil.LIBRARY, sLibrary);
			mpSecurity.put(ConstantsUtil.HASCLASSACCESS, sbHasAccess.toString());
		
		}catch(Exception e){
			LOGGER.error("Error from IPPBO: updateSecurity"+e);
			return new HashMap();
		}
		return  mpSecurity;
	}
	
	
	/**
     * Method Name 			: parseSubstitute
     * Method Description 	: Fetching "Substitute" details
     * @param context
     * @param mapList
     * @return
     * @throws Exception 
     */
    public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
	{
    	StringValidatorUtil validator = new StringValidatorUtil();
    	//SPEC: <01.05.2020>: Added or modified for Req :36032 by Sumit #(BOM Expansion)# --START
    	Map<String,String> mpEBOMResult = null;
    	Map mpFinal = new HashMap();
		//SPEC: <01.05.2020>: Added or modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
    	try {
			Iterator objectListItr = mapList.iterator();			
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
			//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --START
			//int j=0;
			//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS

			mpEBOMResult = new HashMap<String,String>();
			StringBuilder sbEBOMName = new StringBuilder();
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentRev = new StringBuilder();
			StringBuilder sbEBOMParentTitle = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			StringBuilder sbEBOMRefDoc= new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMCommnts = new StringBuilder();
			StringBuilder sbEBOMSubType= new StringBuilder();
			StringBuilder sbEBOMEffectDate= new StringBuilder();
			StringBuilder sbEBOMUntilDate= new StringBuilder();
			StringBuilder sbEBOMCobNum= new StringBuilder();
			StringBuilder sbEBOMChildRev= new StringBuilder();
			StringBuilder sbEBOMRevRelDt= new StringBuilder();
			StringBuilder sbEBOMSubFor= new StringBuilder();
			StringBuilder sbEBOMParentType = new StringBuilder();
			StringBuilder sbEBOMChg = new StringBuilder();
			StringBuilder sbEBOMSFSubType= new StringBuilder();
			StringBuilder sbRF = new StringBuilder();
			StringBuilder sbEBOMFunction = new StringBuilder();
			//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --ENDS
			//Added by Subhajit for Req 46464 - Start
			StringBuilder sbRelRestriction = new StringBuilder();
			StringBuilder sbRelRestrictionComment = new StringBuilder();
			//Added by Subhajit for Req 46464 - End
			while(objectListItr.hasNext())
			{
				
				Map objectMap = (Map) objectListItr.next();
				boolean showData = false;
				boolean bHasOwnership=false;
				
				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
				if(null!=objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
	
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
					//String
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
						//Added by Subhajit for Req 46464 - Start
						String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
						String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
						//Added by Subhajit for Req 46464 - End
						String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						
						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//	String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						String sChildTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
						
						String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						
						//Modified for Defect# 37591 -- START
						//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
						String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
						//Modified for Defect# 37591 -- END
						
						String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
						String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
						//String sEffectvityDate =validator.getStringEquivalentForStringList(validator.DateFormatter((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY)));
						//String sUntilDate=validator.getStringEquivalentForStringList(validator.DateFormatter((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
						String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  						String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END
					
						String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
						sOC = util.replaceSpecialSymbols(sOC);
						String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
						
						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
						String strRF =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RF));
						//String sFunction =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
						// Added By Satyam for the defect 51177 -- START
						String sFunction = DomainConstants.EMPTY_STRING;
						if(ConstantsUtil.tRMP.equalsIgnoreCase(sChildType)) {
							sFunction =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMATERIALFUNCTIONGLOBAL);
						} else {
							sFunction =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMATERIALFUNCTION);
						}
						// Added By Satyam for the defect 51177 -- END
						//SPEC: 11/04/2020: Added for 18x.5 DEV DEFECTS-- START
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START
						//	boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
						//Access was corrected by Chandra but for EBP columns has to be confirmed which can be shown
  						boolean bChildHasAccess = util.checkHasAccess(context,null,sChildId);
						
						if(!bChildHasAccess) {
							sChildId    = ConstantsUtil.NO_ACCESS;
							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
							sChg = ConstantsUtil.NO_ACCESS;
							//sChildTitle = ConstantsUtil.NO_ACCESS;
							//sChildRev = ConstantsUtil.NO_ACCESS;
							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
						}
						
						
						//Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
 						 showData = util.checkHasAccess(context,null,sParentID);
 						
						//SPEC: 11/04/2020: Added for 18x.5 DEV DEFECTS-- END
						
						
						//SPEC: 11/04/2020: Modified for 18x.5 DEV DEFECTS-- START
						/*if(util.isModificatinRequired())
						{
							SecurityService sec = new SecurityService();
							String sComp = sec.getUserCauthorities();
							StringList slUserOwnership=util.filterOwnerShip(sComp);
							
							String sFormulaPropagate = sParentID;
							if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
							}
							
							if(!sFormulaPropagate.isEmpty()) {
								bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
							}	
							
							if(!bHasOwnership)
							{
								sParentType = ConstantsUtil.NO_ACCESS;
								sParentID = ConstantsUtil.NO_ACCESS;
								sChildId    = ConstantsUtil.NO_ACCESS;
								sParentName = ConstantsUtil.NO_ACCESS;
								sParentRev = ConstantsUtil.NO_ACCESS;
								sParentTitle = ConstantsUtil.NO_ACCESS;
								sCombinationNum = ConstantsUtil.NO_ACCESS;
								sChildTitle = ConstantsUtil.NO_ACCESS;
								sSUBType = ConstantsUtil.NO_ACCESS;
								sEffectvityDate = ConstantsUtil.NO_ACCESS;
								sRevRelease = ConstantsUtil.NO_ACCESS;
								sUntilDate = ConstantsUtil.NO_ACCESS;
								sRDOC = ConstantsUtil.NO_ACCESS;
								sQTY = ConstantsUtil.NO_ACCESS;
								sBASEUOM = ConstantsUtil.NO_ACCESS;
								sChildRev = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								sSFSubType = ConstantsUtil.NO_ACCESS;
								strRF = ConstantsUtil.NO_ACCESS;
								sFunction = ConstantsUtil.NO_ACCESS;
						    }
						}else if(sct.isStaffAUGUser()) {
							
							if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}
						}else {
							StringList slHIRTypes = new StringList();
							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
							slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
							
							if(slHIRTypes.contains(sParentType)) {
								if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
								}
							}else {
								showData=true;
							}
						}*/
						//SPEC: 11/04/2020: Commented for 18x.5 DEV DEFECTS-- END
 						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END
						if(!showData){
							sParentID = ConstantsUtil.NO_ACCESS;
							
							//SPEC: 11/04/2020: Commented for 18x.5 DEV DEFECTS-- START
							//sChildId    = ConstantsUtil.NO_ACCESS;
							//SPEC: 11/04/2020: Commented for 18x.5 DEV DEFECTS-- END
							
							/*sParentType = ConstantsUtil.NO_ACCESS;
							sParentID = ConstantsUtil.NO_ACCESS;
							sChildId    = ConstantsUtil.NO_ACCESS;
							//sParentName = ConstantsUtil.NO_ACCESS;
							//sParentRev = ConstantsUtil.NO_ACCESS;
							sParentTitle = ConstantsUtil.NO_ACCESS;
							sCombinationNum = ConstantsUtil.NO_ACCESS;
							sChildTitle = ConstantsUtil.NO_ACCESS;
							sSUBType = ConstantsUtil.NO_ACCESS;
							sEffectvityDate = ConstantsUtil.NO_ACCESS;
							sRevRelease = ConstantsUtil.NO_ACCESS;
							sUntilDate = ConstantsUtil.NO_ACCESS;
							sRDOC = ConstantsUtil.NO_ACCESS;
							sComments = ConstantsUtil.NO_ACCESS;*/
						}
					
						sChildType = util.mapType(sChildType);
						//SPEC: Added by Jwala for the defect 42681 -- START
						sParentType = util.mapType(sParentType);
						//SPEC: Added by Jwala for the defect 42681 -- END
	
						util.formatData(sbEBOMName,sChildName);
						util.formatData(sbEBOMType,sChildType);
						util.formatData(sbEBOMQTY,sQTY);
						util.formatData(sbEBOMBuom,sBASEUOM);
						util.formatData(sbEBOMChildRev,sChildRev);
	
						util.formatData(sbEBOMParentType,sParentType);
						util.formatData(sbEBOMParentId,sParentID);
						util.formatData(sbEBOMId,sChildId);
						util.formatData(sbEBOMParentName,sParentName);
						util.formatData(sbEBOMParentRev,sParentRev);
						util.formatData(sbEBOMParentTitle,sParentTitle);
						util.formatData(sbEBOMCobNum,sCombinationNum);
						util.formatData(sbEBOMTitle,sChildTitle);
						util.formatData(sbEBOMSubType,sSUBType);
						util.formatData(sbEBOMRevRelDt,sRevRelease);
						util.formatData(sbEBOMEffectDate,validator.DateFormatter(sEffectvityDate));
						util.formatData(sbEBOMUntilDate,validator.DateFormatter(sUntilDate));
						util.formatData(sbEBOMRefDoc,sRDOC);
						util.formatData(sbEBOMCommnts,sComments);
						util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
						
						util.formatData(sbEBOMChg,sChg);
						util.formatData(sbEBOMSFSubType,sSFSubType);
						util.formatData(sbRF,strRF);
						util.formatData(sbEBOMFunction,sFunction);
						//Added by Subhajit for Req 46464 - Start
						util.formatData(sbRelRestriction,sRelRestriction);
						util.formatData(sbRelRestrictionComment,sRelRestrictionComment);
						//Added by Subhajit for Req 46464 - End
					//}
					}
				}else {
					//StringList
					String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
					//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
					//String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
					String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					
					 //Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
						 showData = util.checkHasAccess(context,null,sParentID);
						
					//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
				
					String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
					String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						for(int i =0; i<slChildId.size(); i++) {
							String sEachChildId = slChildId.getElement(i);
							
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
//							DomainObject doEachChild = new DomainObject(sEachChildId);
//							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//							StringList slSelect = new StringList();
//							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//							Map mpIpClass = doEachChild.getInfo(context, slSelect);
//							StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//							StringsIpClass = doEachChild.getInfo(contexts"to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
//							DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
							
							StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
							String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
							
							
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START
							//Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
							//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
  							boolean 	bChildHasAccess = util.checkHasAccess(context,null,sEachChildId);
  	  						
  	  						
							
							/*if(util.isModificatinRequired())
							{
								SecurityService sec = new SecurityService();
								String sComp = sec.getUserCauthorities();
								StringList slUserOwnership=util.filterOwnerShip(sComp);
								
								String sFormulaPropagate = sParentID;
								if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
								}
								
								if(!sFormulaPropagate.isEmpty()) {
									bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
								}
								
								if(bHasOwnership)
								{
									showData=true;
							    }
							}else if(sct.isStaffAUGUser()) {
								if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
								}
								
							}else {
								StringList slHIRTypes = new StringList();
								slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
								slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
								slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
								if(slHIRTypes.contains(slChildType.getElement(i))) {
									if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
										showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
									}else {
										showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
									}
								}else {
									showData=true;
								}
								
							}
							*/
							
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
							/*if(!showData) {
								sEachChildId=ConstantsUtil.NO_ACCESS;
							}*/
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
							
  	  						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
							
							
							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							
							//Modified for Defect# 37591 -- START
							//StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
							//Modified for Defect# 37591 -- END
							
							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
							StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
							//StringList slEffectvityDate =validator.getStringListEquivalentForString((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
							//StringList slUntilDate=validator.getStringListEquivalentForString((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
							String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = slRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
							
							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
							//SPEC: <02.01.2021>: Modified for Defect: 38724 by Sumit --START
							//StringList sSFSubType = (StringList) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							String sSFSubType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							//SPEC: <02.01.2021>: Modified for Defect: 38724 by Sumit --ENDS
							//Added by Subhajit for Req 46464 - Start
							StringList slRelRestriction =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR));
  							StringList slRelRestrictionComment =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC));
							//String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
							//String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
							//Added by Subhajit for Req 46464 - End
							
							StringList strRF =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RF);
							//SPEC: <02.01.2021>: Modified for Defect: 38724 by Sumit --STARTS
							//StringList sFunction =(StringList)objectMap.get(ConstantsUtil.EMPTY_STRING);
							//String sFunction = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
							//SPEC: <02.01.2021>: Modified for Defect: 38724 by Sumit --ENDS
							// Added By Satyam for the defect 51177 -- START
							StringList slFunction = new StringList();
							String sFunction = DomainConstants.EMPTY_STRING;
							if(ConstantsUtil.tRMP.equalsIgnoreCase(slChildType.get(i))) {
								slFunction =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMATERIALFUNCTIONGLOBAL);
								sFunction = slFunction.get(i);
							} else {
								slFunction =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMATERIALFUNCTION);
								sFunction = slFunction.get(i);
							}
							// Added By Satyam for the defect 51177 -- END
							
							//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
							if(bChildHasAccess) {
								String sChildType = util.mapType(slChildType.get(i));
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMId,sEachChildId);
								util.formatData(sbEBOMTitle,slChildTitle.get(i));
								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
  								util.formatData(sbEBOMChg,sChg.get(i));
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
  								//Added by Ketan for Req. no. 46464 - START
  								util.formatData(sbRelRestriction,slRelRestriction.get(i));
  								util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
  								//Added by Ketan for Req. no. 46464 - END
							}
							else
							{
								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
								
								/*//String sChildType = util.mapType(slChildType.get(i));
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMChildRev,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);*/
							
								String sChildType = util.mapType(slChildType.get(i));
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMChildRev,slChildRev.get(i));
								//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41590-- START
								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 29, 2021 for Defect# 41590-- END
								util.formatData(sbEBOMTitle,slChildTitle.get(i));
  								util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
  								//Added by Ketan for Req. no. 46464 - START
  								util.formatData(sbRelRestriction,slRelRestriction.get(i));
  								util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
  								//Added by Ketan for Req. no. 46464 - END
  						
  								
							}
							
							//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
							
							
							if(showData) {
								//String sChildType = util.mapType(slChildType.get(i));
//								util.formatData(sbEBOMName,slChildName.get(i));
//								util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMQTY,slQTY.get(i));
								util.formatData(sbEBOMBuom,slBASEUOM.get(i));
								//util.formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMParentType,sParentType);
								util.formatData(sbEBOMParentId,sParentID);
								//SPEC: Release SR18x.6.0 - Commented by Sumit on Mar 29, 2021 for Defect# 41590-- START
								//util.formatData(sbEBOMId,sEachChildId);
								//SPEC: Release SR18x.6.0 - Commented by Sumit on Mar 29, 2021 for Defect# 41590-- END
								util.formatData(sbEBOMParentName,sParentName);
								util.formatData(sbEBOMParentRev,sParentRev);
								util.formatData(sbEBOMParentTitle,sParentTitle);
								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
								//util.formatData(sbEBOMTitle,slChildTitle.get(i));
								util.formatData(sbEBOMSubType,slSUBType.get(i));
								util.formatData(sbEBOMRevRelDt,sRevRelease);
								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
								util.formatData(sbEBOMUntilDate,validator.DateFormatter(slUntilDate.get(i)));
								util.formatData(sbEBOMRefDoc,sRDOC);
								util.formatData(sbEBOMCommnts,slComments.get(i));
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								//SPEC: <02.01.2021>: Modified for Defect: 38724 by Sumit --START
								//util.formatData(sbEBOMSFSubType,sSFSubType.get(i));
								//util.formatData(sbEBOMFunction,sFunction.get(i));
								util.formatData(sbEBOMSFSubType,sSFSubType);
								util.formatData(sbEBOMFunction,sFunction);
								//SPEC: <02.01.2021>: Modified for Defect: 38724 by Sumit --ENDS
								
								util.formatData(sbRF,strRF.get(i));
							}else {
								//String sChildType = util.mapType(slChildType.get(i));
								//util.formatData(sbEBOMName,slChildName.get(i));
								//util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMQTY,slQTY.get(i));
								util.formatData(sbEBOMBuom,slBASEUOM.get(i));
								//util.formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMParentType,sParentType);
								util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
								//util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMParentName,sParentName);
								util.formatData(sbEBOMParentRev,sParentRev);
								/*util.formatData(sbEBOMParentTitle,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMCobNum,ConstantsUtil.NO_ACCESS);*/
								
								util.formatData(sbEBOMParentTitle,sParentTitle);
								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
								//util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
								/*util.formatData(sbEBOMSubType,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMRevRelDt,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMEffectDate,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMUntilDate,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMRefDoc,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMCommnts,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								util.formatData(sbEBOMSFSubType,ConstantsUtil.NO_ACCESS);
								util.formatData(sbRF,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMFunction,ConstantsUtil.NO_ACCESS);*/
								util.formatData(sbEBOMSubType,slSUBType.get(i));
								util.formatData(sbEBOMRevRelDt,sRevRelease);
								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
								util.formatData(sbEBOMUntilDate,validator.DateFormatter(slUntilDate.get(i)));
								util.formatData(sbEBOMRefDoc,sRDOC);
								util.formatData(sbEBOMCommnts,slComments.get(i));
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								//SPEC: <02.01.2021>: Modified for Defect: 38724 by Sumit --START
								//util.formatData(sbEBOMSFSubType,sSFSubType.get(i));
								//util.formatData(sbEBOMFunction,sFunction.get(i));
								util.formatData(sbEBOMSFSubType,sSFSubType);
								util.formatData(sbEBOMFunction,sFunction);
								//SPEC: <02.01.2021>: Modified for Defect: 38724 by Sumit --ENDS
								
								util.formatData(sbRF,strRF.get(i));
								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END	
							}
						}
					}
				}
				}

				//SPEC: <01.05.2020>: Commented for Req :36032 by Sumit #(BOM Expansion)# --START
				//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --START
				}
				//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --ENDS
			
				//SPEC: <01.05.2020>: Commented for Req :36032 by Sumit #(BOM Expansion)# --ENDS
				mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
				mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
				mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
				mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
				mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
				mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
				mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbRF.toString());
				mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbEBOMFunction.toString());
				//Added by Subhajit for Req 46464 - Start
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
				//Added by Subhajit for Req 46464 - End
				//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
				//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --START
				/*if(!(util.filterMapList(mpEBOMResult)).isEmpty()) {
					mpFinal.put(j, mpEBOMResult);
					j++;
				}
			}*/
    		//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --ENDS
			//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS
    	}catch(Exception e) {
    		LOGGER.error("EXCEPTION IN IPPBO : parseSubstitute: "+e);
    		//SPEC: <12.30.2020>: Added Or  modified for Req :36032 by Sumit #(BOM Expansion)# --START
    		return new HashMap();
		}
    	//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --START
		//return mpFinal;
		return util.filterMapList(mpEBOMResult);
		//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --ENDS
		//SPEC: <12.30.2020>: Added Or  modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
	}
    
    
    /**
     * Method Name 			: getIpClass
     * Method Description 	: Get IP Classification
     * @param context
     * @param doFormObj  - domain object of part
     * @param slIpSelects - Selectable
     */
    public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
    	MapList mlIPCLass;
		try {
			mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
					null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			Iterator itr = mlIPCLass.iterator();
			Map mpIpClass = new HashMap();
			StringBuilder sbIpName = new StringBuilder();
			StringBuilder sbHasClassAccess = new StringBuilder();
			StringBuilder sbIpType = new StringBuilder();
			StringBuilder sbIpDesc = new StringBuilder();
			StringBuilder sbIpState = new StringBuilder();
			StringBuilder sbIpLibrary = new StringBuilder();
			StringBuilder sbIpClassPath = new StringBuilder();
			
			while(itr.hasNext()) {
				mpIpClass = (Map)itr.next();
				String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
				sbIpName.append(sIpClassName);
				sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
				sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
				sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
				String strIpClass="";
				if(sIpClassName.contains(ConstantsUtil.HIR)) {
					strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
					sbIpLibrary.append(strIpClass);
				} else {
					strIpClass= ConstantsUtil.BUSINESS_USE;
					sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
				}
				if(!strIpClass.isEmpty()) {
					StringBuilder sbIpClassTemp = new StringBuilder();
					sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
					sbIpClassPath.append(sbIpClassTemp.toString());
				}
				
				//Compare user classification against IPName
				sbHasClassAccess.append("TRUE");
				
				if(itr.hasNext()) {
					sbIpName.append("|");
					sbIpType.append("|");
					sbIpDesc.append("|");
					sbIpState.append("|");
					sbIpLibrary.append("|");
					sbIpClassPath.append("|");
					sbHasClassAccess.append("|");
				}
			}
			mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
			mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
			mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
			mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
			//mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
			//mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
			mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
		} catch (FrameworkException e) {
			e.printStackTrace();
			LOGGER.error("Error from IPPBO: getIpClass" + e);
		}
		return mpIpSecuritySetting;
    }
    
    
    /**
	 * Method Name 			: updateNotes
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> updateNotes(Context context, Map objectMap) 
	{
		StringValidatorUtil validator = new StringValidatorUtil();

		Map<String,String> mpNotes = new HashMap<String,String>();
		StringBuilder sbNum = new StringBuilder();
		StringBuilder sbDes = new StringBuilder();

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);

		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

		try
		{
			String sContextObjectId = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_ID))?(String)objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			DomainObject dom = new DomainObject(sContextObjectId);
			MapList mlNotes = dom.getRelatedObjects(context,"Extended Data", ConstantsUtil.QUERY_WILDCARD, busSelect,
					relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dom.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			mlNotes.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE, "ascending", "string");

			Iterator objectListItr = mlNotes.iterator();
			while(objectListItr.hasNext())
			{
				Map mpTemp = (Map) objectListItr.next();
				String strType = (String)mpTemp.get(ConstantsUtil.SELECT_TYPE);
				if (strType.equals(ConstantsUtil.TYPE_NOTES_CHAR))
				{
					String strDes= (String)mpTemp.get(ConstantsUtil.SELECT_DESCRIPTION);
					String strNum = (String)mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

					util.formatData(sbDes,strDes);
					util.formatData(sbNum,strNum);
				}
			}
			
			mpNotes.put(ConstantsUtil.NUMBER, sbNum.toString());
			mpNotes.put(ConstantsUtil.NOTES, sbDes.toString());
			
		} catch(Exception ex){
			LOGGER.error("Unable to updateNotes : Program IPPBO "+ex);
			return new HashMap();
		}
		return mpNotes;

	}
	
	
	/**
	 * Method Name 			: getSapBOMasFed
	 * Method Description 	: It will return the connected SAP BOM
	 * @param context
	 * @param sID
	 * @return
	 */
	public Map getSapBOMasFed(Context context ,String sID){
		
		CalculateBOM clBom = new CalculateBOM();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mapSapBomAsFedResult = new HashMap();
		
		SecurityService sct = new SecurityService();
		boolean isStaffAUg = sct.isStaffAUGUser();
		
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbSapType = new StringBuilder();
		StringBuilder sbSpecSubType = new StringBuilder();
		StringBuilder sbSpecGroup = new StringBuilder();
		StringBuilder sbBOMQTY = new StringBuilder();
		StringBuilder sbBuom = new StringBuilder();
		StringBuilder sbComnt = new StringBuilder();
		StringBuilder sbSAPDesc = new StringBuilder();
		StringBuilder sbAuthorized = new StringBuilder();
		StringBuilder sbAuthorizedToUse = new StringBuilder();
		StringBuilder sbAuthorizedToProduce = new StringBuilder();
		StringBuilder sbOC = new StringBuilder();
		StringBuilder sbTU = new StringBuilder();
		StringBuilder sbMaxQTY = new StringBuilder();
		StringBuilder sbMinQTY = new StringBuilder();
		
		StringBuilder sbTUType = new StringBuilder();
		StringBuilder sbTUName = new StringBuilder();
		StringBuilder sbTUId = new StringBuilder();
		
		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		try
		{
			ArrayList alSapBom = performDataReadFromEnovia(context,sID);
			MapList ml = getTableData(context,alSapBom);
			
			sbSpecSubType = clBom.getSpecificationSubtype(context ,ml);
			Iterator objectListItr = ml.iterator();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sId =(String)objectMap.get(ConstantsUtil.MAP_KEY_ID);
				String sName =(String)objectMap.get(ConstantsUtil.NAME);
				String sTitle =(String)objectMap.get(ConstantsUtil.DESCRIPTION);
				String sType =(String)objectMap.get(ConstantsUtil.TYPE);
				String sSapType =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPTYPE);
				String sSpecGroup =(String)objectMap.get(ConstantsUtil.MAP_KEY_SUBSTITUTE);
				String sQty =(String)objectMap.get(ConstantsUtil.MAP_KEY_BOMQTY);
				String sBuom =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPUOM);
				String strClassFied = (String)objectMap.get(ConstantsUtil.SECURITY);
				String strControlClass = (String)objectMap.get(ConstantsUtil.OBJECTSECURITYCLASS);
				String strComment = (String)objectMap.get(ConstantsUtil.ATTRIBUTE_COMMENT);
				String strSAPDesc = (String)objectMap.get(ConstantsUtil.SAPDESCRIPTION);
				/*String strAuthorized = (String)objectMap.get(ConstantsUtil.AUTHORIZED);
				String strAuthorizedToUse = (String)objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE);
				String strAuthorizedToProduce = (String)objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE);
				String strOC = (String)objectMap.get(ConstantsUtil.OC);*/
				
				
				String strOC = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.OC));
				String strAuthorizedToProduce =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE));
				String strAuthorizedToUse = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE));
				String strAuthorized = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZED));
				
				String strTUType = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_TYPE);
				String strTUName = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_NAME);
				String strTUId = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_ID);
				
				
				String strMaxQTY = (String)objectMap.get(ConstantsUtil.MAX);
				String strMinQTY = (String)objectMap.get(ConstantsUtil.MIN);
				
				boolean bHasOwnership = false;
				String sUserlicense = sct.getUserLicense();
				String sFormulaPropagate = sId;
				
				
				if(sType.equals(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT) || sType.equals(ConstantsUtil.TYPE_FORMULA_CARD))
				{
					sId =ConstantsUtil.NO_ACCESS;
					sTitle =ConstantsUtil.NO_ACCESS;
					//sSapType =ConstantsUtil.NO_ACCESS;
					//sSpecGroup =ConstantsUtil.NO_ACCESS;
					//sQty =ConstantsUtil.NO_ACCESS;
					//sBuom =ConstantsUtil.NO_ACCESS;
					//strComment=ConstantsUtil.NO_ACCESS;
					
					strAuthorized=ConstantsUtil.NO_ACCESS;
					strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
					strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
					
					
			}
			else
			{	
				if(util.isModificatinRequired())
				{
					//commented by Ganesh for security impl---->start
					/*SecurityService sec = new SecurityService();
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);

					//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sId);
					}
					
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}*/
					//commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl---->start
					bHasOwnership = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl---->end
					if(!bHasOwnership)
					{
						sTitle = ConstantsUtil.NO_ACCESS;
						sId =ConstantsUtil.NO_ACCESS;
						sTitle =ConstantsUtil.NO_ACCESS;
						sSapType =ConstantsUtil.NO_ACCESS;
						sSpecGroup =ConstantsUtil.NO_ACCESS;
						sQty =ConstantsUtil.NO_ACCESS;
						sBuom =ConstantsUtil.NO_ACCESS;
						strComment=ConstantsUtil.NO_ACCESS;
						strSAPDesc=ConstantsUtil.NO_ACCESS;
						strAuthorized=ConstantsUtil.NO_ACCESS;
						strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
						strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
						strOC=ConstantsUtil.NO_ACCESS;
						strMaxQTY=ConstantsUtil.NO_ACCESS;
						strMinQTY=ConstantsUtil.NO_ACCESS;
					}
				}else if(isStaffAUg)
				{
					boolean showData = true;
					//commented by Ganesh for security impl----->start
					/*String sFormulaClassif =strControlClass;
					
						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}
						
						showData= util.checkLicenses(sUserlicense,sFormulaClassif);*/
					//commented by Ganesh for security impl----->end
					//modified by Ganesh for security impl----->start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl----->end
						if(!showData)
						{
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}
							
						}
					
				}else{
					
					boolean showData = true;
					//commented by Ganesh for security impl--->start
					/*if(slHIRTypes.contains(sType) )
					{
						String sFormulaClassif =strClassFied;
							if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) 
							{
									sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							}
								showData= util.checkLicenses(sUserlicense,sFormulaClassif);
					}*/
					//commented by Ganesh for security impl--->end
					//modified by Ganesh for security impl--->start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl--->end

						if(!showData){
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}
						}
					}
				}
				
				util.formatData(sbId,sId);
				util.formatData(sbName,sName);
				util.formatData(sbTitle,sTitle);
				util.formatData(sbType,util.mapType(sType));
				util.formatData(sbSapType,sSapType);
				util.formatData(sbSpecGroup,sSpecGroup);
				util.formatData(sbBOMQTY,sQty);
				util.formatData(sbBuom,sBuom);
				util.formatData(sbComnt,strComment);
				util.formatData(sbSAPDesc,strSAPDesc);
				util.formatData(sbAuthorized,strAuthorized);
				util.formatData(sbAuthorizedToUse,strAuthorizedToUse);
				util.formatData(sbAuthorizedToProduce,strAuthorizedToProduce);
				util.formatData(sbOC,strOC);
				util.formatData(sbMaxQTY,strMaxQTY);
				util.formatData(sbMinQTY,strMinQTY);
				
				util.formatData(sbTUType,strTUType);
				util.formatData(sbTUName,strTUName);
				util.formatData(sbTUId,strTUId);
				
			}

			mapSapBomAsFedResult.put(ConstantsUtil.NAME, sbName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.ID, sbId.toString());
			//mapSapBomAsFedResult.put(ConstantsUtil.TITLE, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TYPE, sbType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPTYPE, sbSapType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONGROUP, sbSpecGroup.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BOMQUANTITY, sbBOMQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbBuom.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.COMMENTS, sbComnt.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPDESCRIPTION, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZED, sbAuthorized.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOUSE, sbAuthorizedToUse.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, sbAuthorizedToProduce.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.OC,sbOC.toString());
			
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_NAME,sbTUName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_TYPE,sbTUType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_ID,sbTUId.toString());
			//mapSapBomAsFedResult.put(ConstantsUtil.MAX,sbMaxQTY.toString());
			//mapSapBomAsFedResult.put(ConstantsUtil.MIN,sbMinQTY.toString());

		}catch(Exception e){
			LOGGER.error("Exception in program IPPBO :getSapBOMasFed ");
		}
		return mapSapBomAsFedResult;
	}
	
	
	/**
	 * Method Name 			: performDataReadFromEnovia
	 * Method Description 	: 
	 * @param context
	 * @param sPartObjectID
	 * @return
	 * @throws Exception
	 */
	public synchronized ArrayList performDataReadFromEnovia(Context context,String sPartObjectID) throws Exception {

		Map 	mapPartDetails				= new HashMap();

		ArrayList alPartRelatedObjects 		= new ArrayList();
		String strSpecSubType = DomainConstants.EMPTY_STRING;
		String strFormulationType = DomainConstants.EMPTY_STRING;

		StringValidatorUtil BusinessUtil= new StringValidatorUtil();
		CalculateBOM clBom = new CalculateBOM();
		
		try {

			if(BusinessUtil.isNotNullOrEmpty(sPartObjectID)){

				DomainObject doPart = DomainObject.newInstance(context,sPartObjectID);
				StringList slBusSelect = new StringList(12);
				slBusSelect.add(DomainConstants.SELECT_TYPE);
				slBusSelect.add(DomainConstants.SELECT_NAME);
				slBusSelect.add(DomainConstants.SELECT_ID);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slBusSelect.add(ConstantsUtil.STR_IPCLASS);

				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slBusSelect.add("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
				slBusSelect.add("next.id");
				mapPartDetails = doPart.getInfo(context, slBusSelect);

				if(null != mapPartDetails && mapPartDetails.size()>0) {

					strSpecSubType = (String) mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					Object OFormulationType = (Object)mapPartDetails.get("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);

					StringList slFormulationType = new StringList();

					if (null != OFormulationType) {
						if (OFormulationType instanceof StringList) {
							slFormulationType = (StringList) OFormulationType;
						} else if (OFormulationType instanceof String) {
							slFormulationType.add(OFormulationType.toString());
						}
					}								
					if(clBom.doProdUsageCheckForeDelivery(context,mapPartDetails)) {

						String strPartType	=	(String)mapPartDetails.get(DomainConstants.SELECT_TYPE);

						if(BusinessUtil.isNotNullOrEmpty(strPartType)) {

							if(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equalsIgnoreCase(strPartType)) {

								alPartRelatedObjects = clBom.getPartObjectsFromEBOM(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_FORMULATIONPART.equalsIgnoreCase(strPartType) && !slFormulationType.isEmpty() && !slFormulationType.contains(ConstantsUtil.THIRD_PARTY_FORMULA) ) {
								alPartRelatedObjects = clBom.getObjectsForFOPFromFormulaIngredient(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(strPartType) || (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strPartType) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromIntermediateBOM(context,sPartObjectID);
							} else if(ConstantsUtil.TYPE_FABRICATEDPART.equalsIgnoreCase(strPartType) ||   ConstantsUtil.TYPE_INTERMEDIATEPRODUCTPART.equalsIgnoreCase(strPartType) || ((ConstantsUtil.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strPartType)) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromBOM(context,sPartObjectID);
							}
						}
					}
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return alPartRelatedObjects;
	}
	
	
	/**
	 * Method Name 			: getTableData
	 * Method Description 	: 
	 * @param context
	 * @param alPartObjectsWithGroupAndQty
	 * @return
	 * @throws Exception
	 */
	public MapList getTableData(Context context, ArrayList alPartObjectsWithGroupAndQty) throws Exception {
		MapList mpReturnList = new MapList();
		boolean isContextPushed = false;
		int OBJECT_ID = 27;
		int SUBSTITUTE_FLAG = 14;
		int QUANTITY = 10;
		int FC_MIN_QTY = 23;
		int FC_MAX_QTY = 25;
		int SORT_STRING = 13;
		int TUP_ID = 28;
		int OPT_COMPONENT = 29;
		
		//SPEC 11/05/2020 added for defect:37077 ##--START
		int INDEX_TPU_TYPE = 34;
		int INDEX_TPU_NAME = 35;
		//SPEC 11/05/2020 added for defect: 37077##--END
		
		try {
			StringList slPartSelect = new StringList(7);
			slPartSelect.addElement(DomainConstants.SELECT_NAME);
			slPartSelect.addElement(DomainConstants.SELECT_TYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slPartSelect.addElement(ConstantsUtil.STR_IPCLASS);
			slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
			//slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
			
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_IPCLASS);
			ContextUtil.pushContext(context);
			isContextPushed = true;
			if(null != alPartObjectsWithGroupAndQty) 
			{
				int alsize=alPartObjectsWithGroupAndQty.size();
				StringValidatorUtil validator = new StringValidatorUtil();
				String strObjID = null;
				String strSubstitute=null;
				String strBOMQuantity = null;
				String strMin = null;
				String strMax = null;
				String strPosInd = null;
				String strObjectType = null;
				String strSAPUOM = null;
				String strSAPType = null;
				String strPGCSSType = null;
				String strTUPObjID = null;
				String strIPClass = null;
				String strOptComponent = null;
				//String strAuthorized = null;
				//String strOC = null;
				//	String strAuthorizedToUse = null;
				//String strAuthorizedToProduce = null;
				String strTransportUnit = null;
				DomainObject domObject = null;
				Map mpPartObjectInfo = null;
				int COMMENT = 30;
				String strComment = DomainConstants.EMPTY_STRING; 
				String strName = DomainConstants.EMPTY_STRING; 
				String strDescription = DomainConstants.EMPTY_STRING; 
				
				String strTUPObjName = DomainConstants.EMPTY_STRING; 
				String strTUPObjType = DomainConstants.EMPTY_STRING;
				
				//SPEC 11/05/2020 added for defect: ##--START
				CalculateBOM clBom = new CalculateBOM();
				
				StringList slRelSelect = new StringList();
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
				//SPEC 11/05/2020 added for defect: ##--END
				
				HashMap hmTemp = null;
				for (int i=0; i<alsize; i++) {
					String [] satemp = (String[]) alPartObjectsWithGroupAndQty.get(i);
					strObjID = satemp[OBJECT_ID];
					strSubstitute= satemp[SUBSTITUTE_FLAG];
					strBOMQuantity = satemp[QUANTITY];
					strMin = satemp[FC_MIN_QTY];
					strMax = satemp[FC_MAX_QTY];
					strPosInd = satemp[SORT_STRING];
					strTUPObjID = satemp[TUP_ID];
					String sqty = satemp[ConstantsUtil.INDEX_TARGET] ;	
					strOptComponent = satemp[OPT_COMPONENT];
					domObject = DomainObject.newInstance(context,strObjID);
					mpPartObjectInfo = domObject.getInfo(context, slPartSelect);
					strObjectType = (String)mpPartObjectInfo.get(DomainConstants.SELECT_TYPE);
					strSAPUOM = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					strSAPType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
					strPGCSSType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
					strComment = satemp[COMMENT];
					strName = (String)mpPartObjectInfo.get(DomainConstants.SELECT_NAME);
					strDescription = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					/*strAuthorized = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					strAuthorizedToUse = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					strAuthorizedToProduce =  validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					strTransportUnit =  validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));*/
					//strOC = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
					strIPClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.STR_IPCLASS));
					String strIPControlClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
					
					
					//SPEC 11/05/2020 added for defect: 37077##--START
					strTUPObjID = validator.getStringEquivalentForStringList(satemp[TUP_ID]);
					strTUPObjName = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_NAME]);
					strTUPObjType = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_TYPE]);
					//SPEC 11/05/2020 added for defect: 37077##--END
					
					boolean bTUPAccess=false;
					if(UIUtil.isNotNullAndNotEmpty(strTUPObjID)){
					 bTUPAccess = clBom.checkHasAccess(context,strTUPObjID);
					}
					
					if(!bTUPAccess){
						strTUPObjID=ConstantsUtil.NO_ACCESS;
					}
					
					//SPEC 11/05/2020 added for defect: ##--START
					MapList mlParentPlantList = clBom.getConnectedPlantList(context, strObjID, slRelSelect, null);
					
					
					StringList	slAVPlantList = new StringList();
					StringList	slAUPlantList = new StringList();
					StringList	slAPPlantList = new StringList();
					if(mlParentPlantList!=null && mlParentPlantList.size()>0)
					{
						for(int ip=0;ip<mlParentPlantList.size();ip++)
						{
							Map mapSAPBOMComponent = (Map)mlParentPlantList.get(ip);
							String	sAVAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
							String	sAUAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
							String	sAPAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
							String	sSAPBOMComponentPlantName = (String)mapSAPBOMComponent.get(DomainObject.SELECT_NAME);
							
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAVAttributeValue) && strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAVPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAUAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAUPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAPAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAPPlantList.add(sSAPBOMComponentPlantName);
							}
						}
					}
					
					String	strAVPlantList = DomainConstants.EMPTY_STRING;
					String	strAUPlantList = DomainConstants.EMPTY_STRING;
					String	strAPPlantList = DomainConstants.EMPTY_STRING;
					
					if(slAVPlantList!= null && slAVPlantList.size()>0)
					{
						strAVPlantList = FrameworkUtil.join(slAVPlantList, "&&&");
					}

					if(slAUPlantList!= null && slAUPlantList.size()>0)
					{
						strAUPlantList = FrameworkUtil.join(slAUPlantList, "&&&");
					}
					
					if(slAPPlantList!= null && slAPPlantList.size()>0)
					{
						strAPPlantList = FrameworkUtil.join(slAPPlantList, "&&&");
					}
					
					//SPEC 11/05/2020 added for defect: ##--END
					
					
					hmTemp = new  HashMap();
					hmTemp.put("id",strObjID);  
					hmTemp.put("type",strObjectType);  
					hmTemp.put("substitute",strSubstitute);
					hmTemp.put("BOMQty",strBOMQuantity);
					hmTemp.put("Min",strMin);
					hmTemp.put("Max",strMax);
					hmTemp.put("PosInd",strPosInd);
					hmTemp.put("SAPUOM",strSAPUOM);
					hmTemp.put("SAPType",strSAPType);
					hmTemp.put("SSType",strPGCSSType);
					hmTemp.put("dispId", strObjID);
					hmTemp.put("OptComponent", strOptComponent);
					hmTemp.put(ConstantsUtil.ATTRIBUTE_COMMENT, strComment);
					hmTemp.put(DomainConstants.SELECT_NAME, strName);
					hmTemp.put(DomainConstants.SELECT_DESCRIPTION, strDescription);
					hmTemp.put(ConstantsUtil.SECURITY, strIPClass);
					hmTemp.put(ConstantsUtil.OBJECTSECURITYCLASS, strIPControlClass);
					hmTemp.put(ConstantsUtil.AUTHORIZED, strAVPlantList);
					hmTemp.put(ConstantsUtil.OC, strOptComponent);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOUSE, strAUPlantList);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, strAPPlantList);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_TYPE, strTUPObjType);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_NAME, strTUPObjName);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_ID, strTUPObjID);
					
					mpReturnList.add(hmTemp);
				}
			}
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(isContextPushed) {
				ContextUtil.popContext(context);
				isContextPushed = false;
			}
		}
		return mpReturnList;
	}
	
	
	public Map updatePerformCharcteristic(Context context, MapList mlFinalList, Map resultMap) {

		StringValidatorUtil validator = new StringValidatorUtil();
		String sType = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.SELECT_TYPE))
				? (String) resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

				StringBuilder schg = new StringBuilder();
				StringBuilder sCharcteristic = new StringBuilder();
				StringBuilder sbPathId = new StringBuilder();
				StringBuilder sbPathType = new StringBuilder();
				StringBuilder sCharSpec = new StringBuilder();
				StringBuilder sPath = new StringBuilder();
				StringBuilder sTMNActual = new StringBuilder();
				StringBuilder sTMNActualID = new StringBuilder();
				StringBuilder sTMNActualType = new StringBuilder();
				StringBuilder sTMName = new StringBuilder();
				StringBuilder sTMLogic = new StringBuilder();
				StringBuilder sMethodOrigin = new StringBuilder();
				StringBuilder sMethodNumber = new StringBuilder();
				StringBuilder sMethodSpecific = new StringBuilder();
				StringBuilder sTMNameID = new StringBuilder();
				StringBuilder sTMNameType = new StringBuilder();
				StringBuilder sSampling = new StringBuilder();
				StringBuilder sSubGroup = new StringBuilder();

				StringBuilder sPlantTesting = new StringBuilder();
				StringBuilder sPlantRetesting = new StringBuilder();
				StringBuilder sTestingUOM = new StringBuilder();

				StringBuilder sLowerSpecLimit = new StringBuilder();
				StringBuilder sLowerRoutineReleaseLimit = new StringBuilder();
				StringBuilder sPGLowerTarget = new StringBuilder();
				StringBuilder sPGTarget = new StringBuilder();
				StringBuilder sPGUpperTarget = new StringBuilder();
				StringBuilder sUpperRoutineRL = new StringBuilder();
				StringBuilder sPGUpperSpecLimit = new StringBuilder();

				StringBuilder sUnitOfMeasure = new StringBuilder();
				StringBuilder sPGReportNear = new StringBuilder();
				StringBuilder sPGReportType = new StringBuilder();
				StringBuilder sReleseCriteria = new StringBuilder();

				StringBuilder sPGACtionRequired = new StringBuilder();
				StringBuilder sCriticalFactor = new StringBuilder();
				StringBuilder sPGBasis = new StringBuilder();

				StringBuilder sPTestGroup = new StringBuilder();
				StringBuilder sPApplication = new StringBuilder();
				StringBuilder sPMTitle = new StringBuilder();

				Iterator objectListItr = mlFinalList.iterator();
				Map<String, String> mpFinal = new HashMap<String, String>();
				SecurityService sct = new SecurityService();
				String sUserType = util.getUserType();
				String sUserlicense = sct.getUserLicense();
				/*
				 * if(mlFinalList.size()==0) { return new HashMap(); }
				 */

				try {

					while (objectListItr.hasNext()) {
						Map objectMap = (Map) objectListItr.next();
						String sPchg = validator
								.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE))
								? ((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE))
										: ConstantsUtil.EMPTY_STRING;
								String sPCharcteristic = validator
										.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC))
										? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC)
												: ConstantsUtil.EMPTY_STRING;
										String sPCharSpec = validator.isNotNullOrEmpty(
												(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS))
												? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS)
														: ConstantsUtil.EMPTY_STRING;
												String sPPath = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.PATH))
														? (String) objectMap.get(ConstantsUtil.PATH)
																: ConstantsUtil.EMPTY_STRING;

														String sPTMName = ConstantsUtil.EMPTY_STRING;
														String sPTMNameActual = ConstantsUtil.EMPTY_STRING;
														String sPTMNameID = ConstantsUtil.EMPTY_STRING;
														String sPTMNameActualID = ConstantsUtil.EMPTY_STRING;
														String sPTMNameActualType = ConstantsUtil.EMPTY_STRING;
														String sPTMType = ConstantsUtil.EMPTY_STRING;

														boolean sClass = objectMap.containsKey(ConstantsUtil.SELECT_REF_DOC_TONAME);
														boolean sClassTo = objectMap.containsKey(ConstantsUtil.SELECT_REF_DOC_NAME);
														
														
														if (sClass) {
															String sClassName = objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME).getClass().getSimpleName();
															
															if (sClassName.equals(ConstantsUtil.STRING))
															{
																if (util.isModificatinRequired())
																{
																	sPTMName = validator
																			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
																			? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
																					: ConstantsUtil.EMPTY_STRING;
																			sPTMType = validator
																					.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
																					? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
																							: ConstantsUtil.EMPTY_STRING;
																					String sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap
																							.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS))
																							? (String) objectMap
																									.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS)
																									: ConstantsUtil.EMPTY_STRING;
																									sPTMNameID = validator
																											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
																											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
																													: ConstantsUtil.EMPTY_STRING;
																											//For TM Check With EBP
																											if ((sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)))
																											{

																												boolean bHasOwnership =util.checkOwnerShip(context,sPTMNameID);
																												if(bHasOwnership)
																												{
																													if (ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) 
																													{
																														util.formatData(sTMName, sPTMName);
																														util.formatData(sTMNameID, sPTMNameID);
																														util.formatData(sTMNameType, sPTMType);
																													} else {
																														util.formatData(sTMName, sPTMName);
																														util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																														util.formatData(sTMNameType, sPTMType);
																													}
																												}else
																												{
																													util.formatData(sTMName, sPTMName);
																													util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																													util.formatData(sTMNameType, sPTMType);
																												}
																											}
																											//For SOP Check With EBP
																											if (sPTMType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)) 
																											{
																												sPTMNameActual = validator
																														.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
																														? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
																																: ConstantsUtil.EMPTY_STRING;
																														sPTMNameActualType = validator
																																.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
																																? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
																																		: ConstantsUtil.EMPTY_STRING;
																																sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap
																																		.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS))
																																		? (String) objectMap.get(
																																				ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS)
																																				: ConstantsUtil.EMPTY_STRING;
																																				sPTMNameActualID = validator
																																						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
																																						? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
																																								: ConstantsUtil.EMPTY_STRING;
																																						//modified by Ganesh for security impl------start
																																						//boolean bHasOwnership =util.checkOwnerShip(context,sPTMNameID);
																																						boolean bHasOwnership=util.checkHasAccess(context, sUserType, sPTMNameID);
																																						//modified by Ganesh for security impl------end
																																						if(bHasOwnership)
																																						{
																																							if (ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) {
																																								util.formatData(sTMNActual, sPTMName);
																																								util.formatData(sTMNActualID, sPTMNameActual);
																																								util.formatData(sTMNActualType, sPTMType);
																																							} else {
																																								util.formatData(sTMNActual, sPTMName);
																																								util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																																								util.formatData(sTMNActualType, sPTMType);
																																							}

																																						}else {
																																							util.formatData(sTMNActual, sPTMName);
																																							util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																																							util.formatData(sTMNActualType, sPTMType);
																																						}
																											}
																} else 
																{
																	sPTMType = validator
																			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
																			? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
																					: ConstantsUtil.EMPTY_STRING;
																			boolean showData=false;
																			if (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION))
																			{
																				if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																					String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_REF_DOC_IPCLASS)));
																					//modified by Ganesh for security impl----->start
																					//showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
																					showData =util.checkHasAccess(context, sUserType, sPTMNameID);
																					//modified by Ganesh for security impl----->start
																				}
																				
																					sPTMName = validator
																							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
																							? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
																									: ConstantsUtil.EMPTY_STRING;
																							sPTMNameID = validator
																									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
																									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
																											: ConstantsUtil.EMPTY_STRING;
																				if(showData) {
																					util.formatData(sTMName, sPTMName);
																					util.formatData(sTMNameID, sPTMNameID);
																					util.formatData(sTMNameType, sPTMType);
																				}else {
																					util.formatData(sTMName, sPTMName);
																					util.formatData(sTMNameID, ConstantsUtil.NO_ACCESS);
																					util.formatData(sTMNameType, sPTMType);
																				}
																				
																			} else 
																			{
																				if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																					String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_REF_DOC_IPCLASS)));
																					//modified by Ganesh for security impl---->start
																					//showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
																					showData = util.checkHasAccess(context, sUserType, sPTMNameActualID);
																					//modified by Ganesh for security impl---->end
																				}
																				
																					sPTMNameActual = validator
																							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
																							? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
																									: ConstantsUtil.EMPTY_STRING;
																							sPTMNameActualType = validator
																									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
																									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
																											: ConstantsUtil.EMPTY_STRING;
																									sPTMNameActualID = validator
																											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
																											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
																													: ConstantsUtil.EMPTY_STRING;
																				if(showData) {
																					util.formatData(sTMNActual, sPTMNameActual);
																					util.formatData(sTMNActualID, sPTMNameActualID);
																					util.formatData(sTMNActualType, sPTMNameActualType);
																				}else {
																					util.formatData(sTMNActual, sPTMNameActual);
																					util.formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
																					util.formatData(sTMNActualType, sPTMNameActualType);
																				}
																				
																			}
																}
															} else {

																StringList slTMName = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME);
																StringList slTMType = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
																StringList slsChildObjectID = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID);
																StringList slTMHasSharedAccess = (StringList) objectMap
																		.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);

																boolean showData=false;
																boolean bHasOwnership = false;
																if (util.isModificatinRequired()) {
																	Map<String, StringList> mpTemp = new HashMap<String, StringList>();
																	mpTemp.put(ConstantsUtil.TYPE, slTMType);
																	mpTemp.put(ConstantsUtil.NAME, slTMName);
																	mpTemp.put(ConstantsUtil.SECURITY, slTMHasSharedAccess);
																	mpTemp.put(ConstantsUtil.ID, slsChildObjectID);

																	Map mpTemp1 = util.showOrHideSOPAndTM(context, mpTemp);

																	SecurityService sec = new SecurityService();
																							String sComp = sec.getUserCauthorities();
																							StringList slUserOwnership=util.filterOwnerShip(sComp);
																							
																							slTMName = (StringList) mpTemp1.get(ConstantsUtil.NAME);
																							slTMType = (StringList) mpTemp1.get(ConstantsUtil.TYPE);
																							slsChildObjectID = (StringList) mpTemp1.get(ConstantsUtil.ID);

																							int iSize = slsChildObjectID.size();
																							
																							for(int i=0;i<iSize;i++){
																								String strOID = slsChildObjectID.get(i);
																								//modified by Ganesh for security impl ---->start
																								//bHasOwnership = util.checkOwnerShip(context, slUserOwnership, strOID);
																								bHasOwnership = util.checkHasAccess(context, sUserType, strOID);
																								//modified by Ganesh for security impl ---->start
																								if(bHasOwnership){
																									showData=true;
																								}else{
																									showData = false;
																									strOID =ConstantsUtil.NO_ACCESS;
																								}
																								slsChildObjectID.add(strOID);
																							}

																						}else {
																
																//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 30, 2021 for Defect 41630 , 41861 -- START
																							/*
																							if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																			String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_REF_DOC_IPCLASS)));
																			//modified by Ganesh for security impl------>start
																			//showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
																			int iSize = slsChildObjectID.size();
																			for(int i=0;i<iSize;i++){
																				String strOID = slsChildObjectID.get(i);
																			showData = util.checkHasAccess(context, sUserType,strOID );
																			}
																			//modified by Ganesh for security impl------>start
																	}else {
																		showData=true;
																	}
																}
																*/
																//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 30, 2021 for Defect 41630 , 41861 -- END
																							
																Map mpTemp2 = util.removeTestMethod(context,slTMName, slTMType, slsChildObjectID);

																StringList slTMFilteredName = (StringList) mpTemp2.get(ConstantsUtil.TMFILNAME);
																StringList slTMFilterID = (StringList) mpTemp2.get(ConstantsUtil.TMFILID);
																StringList slTMFilterType = (StringList) mpTemp2.get(ConstantsUtil.TMFILTYPE);

																slTMType = (StringList) mpTemp2.get(ConstantsUtil.BASETYPE);
																slTMName = (StringList) mpTemp2.get(ConstantsUtil.BASENAME);
																slsChildObjectID = (StringList) mpTemp2.get(ConstantsUtil.BASEID);

																sPTMName = validator.isNotNullOrEmpty(slTMName.toString()) ? slTMName.toString()
																		: ConstantsUtil.EMPTY_STRING;
																sPTMName = sPTMName.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 30, 2021 for Defect 41630 , 41861 -- START
																/*
																sPTMNameID = validator.isNotNullOrEmpty(slsChildObjectID.toString())
																		? slsChildObjectID.toString()
																				: ConstantsUtil.EMPTY_STRING;
																		sPTMNameID = sPTMNameID.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																		sPTMType = validator.isNotNullOrEmpty(slTMType.toString()) ? slTMType.toString()
																				: ConstantsUtil.EMPTY_STRING;
																		sPTMType = sPTMType.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																		if(!showData) {
																			util.formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
																		}else {
																			util.formatData(sTMNActualID, sPTMNameID);
																		}
																		util.formatData(sTMNActual, sPTMName);
																		util.formatData(sTMNActualType, sPTMType);

																		sPTMNameActual = validator.isNotNullOrEmpty(slTMFilteredName.toString())
																				? slTMFilteredName.toString()
																						: ConstantsUtil.EMPTY_STRING;
																				sPTMNameActual = sPTMNameActual
																						.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																				sPTMNameActualID = validator.isNotNullOrEmpty(slTMFilterID.toString()) ? slTMFilterID.toString()
																						: ConstantsUtil.EMPTY_STRING;
																				sPTMNameActualID = sPTMNameActualID
																						.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																				sPTMNameActualType = validator.isNotNullOrEmpty(slTMFilterType.toString())
																						? slTMFilterType.toString()
																								: ConstantsUtil.EMPTY_STRING;
																						sPTMNameActualType = sPTMNameActualType
																								.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																								.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																								.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
																						
																						if(!showData) {
																							util.formatData(sTMNameID, ConstantsUtil.NO_ACCESS);
																						}else {
																							util.formatData(sTMNameID, sPTMNameActualID);
																						}
																						util.formatData(sTMName, sPTMNameActual);
																						//formatData(sTMNameID, sPTMNameActualID);
																						util.formatData(sTMNameType, sPTMNameActualType);
																						*/
																
																// Security added for Staff AUG
																StringList slTMSecurityCheck = new StringList();
																if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																	int iSize = slsChildObjectID.size();
																	for (int i = 0; i < iSize; i++) {
																		String strOID = slsChildObjectID.get(i);
																		showData = util.checkHasAccess(context, sUserType, strOID);
																		
																		if (showData) {
																			slTMSecurityCheck.add(strOID);
																		} else {
																			slTMSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																		}
																	}
																} else {
																	int iSize = slsChildObjectID.size();
																	for (int i = 0; i < iSize; i++) {
																		String strOID = slsChildObjectID.get(i);
																		showData = util.checkHasAccess(context, sUserType, strOID);
																		
																		if (showData) {
																			slTMSecurityCheck.add(strOID);
																		} else {
																			slTMSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																		}
																	}
																}

																// Security has to check for multiple objects
																sPTMNameID = validator.isNotNullOrEmpty(slTMSecurityCheck.toString())
																		? slTMSecurityCheck.toString() : ConstantsUtil.EMPTY_STRING;

																sPTMNameID = sPTMNameID.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																sPTMType = validator.isNotNullOrEmpty(slTMType.toString()) ? slTMType.toString()
																		: ConstantsUtil.EMPTY_STRING;
																sPTMType = sPTMType.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																util.formatData(sTMNActualID, sPTMNameID);
																util.formatData(sTMNActual, sPTMName);
																util.formatData(sTMNActualType, sPTMType);

																sPTMNameActual = validator.isNotNullOrEmpty(slTMFilteredName.toString())
																		? slTMFilteredName.toString() : ConstantsUtil.EMPTY_STRING;
																sPTMNameActual = sPTMNameActual
																		.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																StringList slTMActualSecurityCheck = new StringList();
																if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																	int iSize = slTMFilterID.size();
																	for (int i = 0; i < iSize; i++) {
																		String strOID = slTMFilterID.get(i);
																		showData = util.checkHasAccess(context, sUserType, strOID);
																		
																		if (showData) {
																			slTMActualSecurityCheck.add(strOID);
																		} else {
																			slTMActualSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																		}
																	}
																} else {
																	int iSize = slTMFilterID.size();
																	for (int i = 0; i < iSize; i++) {
																		String strOID = slTMFilterID.get(i);
																		showData = util.checkHasAccess(context, sUserType, strOID);
																		
																		if (showData) {
																			slTMActualSecurityCheck.add(strOID);
																		} else {
																			slTMActualSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																		}
																	}
																}

																sPTMNameActualID = validator.isNotNullOrEmpty(slTMActualSecurityCheck.toString())
																		? slTMActualSecurityCheck.toString() : ConstantsUtil.EMPTY_STRING;

																sPTMNameActualID = sPTMNameActualID
																		.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																sPTMNameActualType = validator.isNotNullOrEmpty(slTMFilterType.toString())
																		? slTMFilterType.toString() : ConstantsUtil.EMPTY_STRING;
																sPTMNameActualType = sPTMNameActualType
																		.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																util.formatData(sTMName, sPTMNameActual);
																util.formatData(sTMNameID, sPTMNameActualID);
																util.formatData(sTMNameType, sPTMNameActualType);
																}
																//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 30, 2021 for Defect 41630 , 41861 -- END
															}

														} 
														/*
														else {
															boolean showData=false;
															if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_REF_DOC_IPCLASS)));
																showData=checkInternalUserAcess(sUserlicense,strClassFied);
															}
															if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF) && !showData) {
																formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
																formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
															}else {
																formatData(sTMNameID, sPTMNameActualID);
																formatData(sTMNActualID, sPTMNameID);
															}
															formatData(sTMName, sPTMNameActual);
															formatData(sTMNameType, sPTMNameActualType);
															formatData(sTMNActual, sPTMName);
															formatData(sTMNActualType, sPTMType);
															
														}
														*/
														
										
														else if (sClassTo) {
															String sClassName = objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME).getClass().getSimpleName();

															if (sClassName.equals(ConstantsUtil.STRING))
															{
																if (util.isModificatinRequired())
																{
																	sPTMName = validator
																			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME))
																			? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME)
																					: ConstantsUtil.EMPTY_STRING;
																			sPTMType = validator
																					.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE))
																					? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE)
																							: ConstantsUtil.EMPTY_STRING;
																					String sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap
																							.get(ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS))
																							? (String) objectMap
																									.get(ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS)
																									: ConstantsUtil.EMPTY_STRING;
																									sPTMNameID = validator
																											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID))
																											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID)
																													: ConstantsUtil.EMPTY_STRING;
																											//For TM Check With EBP
																											if ((sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)))
																											{
                                                                                                              //modified by Ganesh for security impl ---->start
																												//boolean bHasOwnership =util.checkOwnerShip(context,sPTMNameID);
																												boolean bHasOwnership = util.checkHasAccess(context, sUserType, sPTMNameID);
																												//modified by Ganesh for security impl ---->end
																												if(bHasOwnership)
																												{
																													if (ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) 
																													{
																														util.formatData(sTMName, sPTMName);
																														util.formatData(sTMNameID, sPTMNameID);
																														util.formatData(sTMNameType, sPTMType);
																													} else {
																														util.formatData(sTMName, sPTMName);
																														util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																														util.formatData(sTMNameType, sPTMType);
																													}
																												}else
																												{
																													util.formatData(sTMName, sPTMName);
																													util.formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																													util.formatData(sTMNameType, sPTMType);
																												}
																											}
																											//For SOP Check With EBP
																											if (sPTMType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)) 
																											{
																												sPTMNameActual = validator
																														.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME))
																														? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME)
																																: ConstantsUtil.EMPTY_STRING;
																														sPTMNameActualType = validator
																																.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE))
																																? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE)
																																		: ConstantsUtil.EMPTY_STRING;
																																sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap
																																		.get(ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS))
																																		? (String) objectMap.get(
																																				ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS)
																																				: ConstantsUtil.EMPTY_STRING;
																																				sPTMNameActualID = validator
																																						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID))
																																						? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID)
																																								: ConstantsUtil.EMPTY_STRING;
																																						//modified by Ganesh for security impl----start
																																						//boolean bHasOwnership =util.checkOwnerShip(context,sPTMNameID);
																																						boolean bHasOwnership = util.checkHasAccess(context, sUserType, sPTMNameID);
																																						//modified by Ganesh for security impl----end
																																						if(bHasOwnership)
																																						{
																																							if (ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) {
																																								util.formatData(sTMNActual, sPTMName);
																																								util.formatData(sTMNActualID, sPTMNameActual);
																																								util.formatData(sTMNActualType, sPTMType);
																																							} else {
																																								util.formatData(sTMNActual, sPTMName);
																																								util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																																								util.formatData(sTMNActualType, sPTMType);
																																							}

																																						}else {
																																							util.formatData(sTMNActual, sPTMName);
																																							util.formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																																							util.formatData(sTMNActualType, sPTMType);
																																						}
																											}
																} else 
																{
																	sPTMType = validator
																			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE))
																			? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE)
																					: ConstantsUtil.EMPTY_STRING;
																			boolean showData=false;
																			if (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION))
																			{
																				if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																					String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_REF_DOC_FROMIPCLASS)));
																					//modified by Ganesh for security impl----->start
																					//showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
																					showData = util.checkHasAccess(context, sUserType, sPTMNameID);
																					//modified by Ganesh for security impl----->end
																				}
																				
																					sPTMName = validator
																							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME))
																							? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME)
																									: ConstantsUtil.EMPTY_STRING;
																							sPTMNameID = validator
																									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID))
																									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID)
																											: ConstantsUtil.EMPTY_STRING;
																				
						
																				if(showData) {
																					util.formatData(sTMName, sPTMName);
																					util.formatData(sTMNameID, sPTMNameID);
																					util.formatData(sTMNameType, sPTMType);
																				}else {
																					util.formatData(sTMName, sPTMName);
																					util.formatData(sTMNameID, ConstantsUtil.NO_ACCESS);
																					util.formatData(sTMNameType, sPTMType);
																				}
																				
																			
																				
																			} else 
																			{
																				if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																					String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_REF_DOC_FROMIPCLASS)));
																					//modified by Ganesh for security impl---->start
																					//showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
																					showData = util.checkHasAccess(context, sUserType, sPTMNameActualID);
																					//modified by Ganesh for security impl---->end
																				}
																				
																					sPTMNameActual = validator
																							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME))
																							? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME)
																									: ConstantsUtil.EMPTY_STRING;
																							sPTMNameActualType = validator
																									.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE))
																									? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE)
																											: ConstantsUtil.EMPTY_STRING;
																									sPTMNameActualID = validator
																											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID))
																											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID)
																													: ConstantsUtil.EMPTY_STRING;
																				if(showData) {
																					util.formatData(sTMNActual, sPTMNameActual);
																					util.formatData(sTMNActualID, sPTMNameActualID);
																					util.formatData(sTMNActualType, sPTMNameActualType);
																				}else {
																					util.formatData(sTMNActual, sPTMNameActual);
																					util.formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
																					util.formatData(sTMNActualType, sPTMNameActualType);
																				}

																			}
																}
															} else {

																StringList slTMName = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_NAME);
																StringList slTMType = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TYPE);
																StringList slsChildObjectID = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_ID);
																StringList slTMHasSharedAccess = (StringList) objectMap
																		.get(ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS);

																boolean showData=false;
																boolean bHasOwnership =false;
																if (util.isModificatinRequired()) {
																	Map<String, StringList> mpTemp = new HashMap<String, StringList>();
																	mpTemp.put(ConstantsUtil.TYPE, slTMType);
																	mpTemp.put(ConstantsUtil.NAME, slTMName);
																	mpTemp.put(ConstantsUtil.SECURITY, slTMHasSharedAccess);
																	mpTemp.put(ConstantsUtil.ID, slsChildObjectID);

																	Map mpTemp1 = util.showOrHideSOPAndTM(context, mpTemp);

																	SecurityService sec = new SecurityService();
																	String sComp = sec.getUserCauthorities();
																	StringList slUserOwnership=util.filterOwnerShip(sComp);

																	slTMName = (StringList) mpTemp1.get(ConstantsUtil.NAME);
																	slTMType = (StringList) mpTemp1.get(ConstantsUtil.TYPE);
																							slsChildObjectID = (StringList) mpTemp1.get(ConstantsUtil.ID);

																							for(int i=0;i<slsChildObjectID.size();i++){
																								String strOID = slsChildObjectID.get(i);
																								//modified by Ganesh for security impl--->start
																								//bHasOwnership = util.checkOwnerShip(context, slUserOwnership, strOID);
																								bHasOwnership =util.checkHasAccess(context, sUserType, strOID);
																								//modified by Ganesh for security impl--->start
																								if(bHasOwnership){
																									showData=true;
																								}else{
																									showData = false;
																									strOID =ConstantsUtil.NO_ACCESS;
																								}
																								slsChildObjectID.add(strOID);
																							}
																							slTMName = (StringList) mpTemp1.get(ConstantsUtil.NAME);
																							slTMType = (StringList) mpTemp1.get(ConstantsUtil.TYPE);
																							slsChildObjectID = (StringList) mpTemp1.get(ConstantsUtil.ID);

																						}else{

																//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 30, 2021 for Defect 41630 , 41861 -- START
																							/*
																							if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																			String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_REF_DOC_FROMIPCLASS)));
																			//modified by Ganesh for security impl----->start
																			//showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
																			for(int i=0;i<slsChildObjectID.size();i++){
																				String strOID = slsChildObjectID.get(i);
																			showData =util.checkHasAccess(context, sUserType, strOID);
																			}
																			//modified by Ganesh for security impl----->start
																	}else {
																		showData=true;
																	}
																}
																*/
																//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 30, 2021 for Defect 41630 , 41861 -- END
																Map mpTemp2 = util.removeTestMethod(context,slTMName, slTMType, slsChildObjectID);

																StringList slTMFilteredName = (StringList) mpTemp2.get(ConstantsUtil.TMFILNAME);
																StringList slTMFilterID = (StringList) mpTemp2.get(ConstantsUtil.TMFILID);
																StringList slTMFilterType = (StringList) mpTemp2.get(ConstantsUtil.TMFILTYPE);

																slTMType = (StringList) mpTemp2.get(ConstantsUtil.BASETYPE);
																slTMName = (StringList) mpTemp2.get(ConstantsUtil.BASENAME);
																slsChildObjectID = (StringList) mpTemp2.get(ConstantsUtil.BASEID);

																sPTMName = validator.isNotNullOrEmpty(slTMName.toString()) ? slTMName.toString()
																		: ConstantsUtil.EMPTY_STRING;
																sPTMName = sPTMName.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 30, 2021 for Defect 41630 , 41861 -- START
																/*
																sPTMNameID = validator.isNotNullOrEmpty(slsChildObjectID.toString())
																		? slsChildObjectID.toString()
																				: ConstantsUtil.EMPTY_STRING;
																		sPTMNameID = sPTMNameID.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																		sPTMType = validator.isNotNullOrEmpty(slTMType.toString()) ? slTMType.toString()
																				: ConstantsUtil.EMPTY_STRING;
																		sPTMType = sPTMType.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																		if(!showData) {
																			util.formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
																		}else {
																			util.formatData(sTMNActualID, sPTMNameID);
																		}
																		util.formatData(sTMNActual, sPTMName);
																		util.formatData(sTMNActualType, sPTMType);
																		
				
																		sPTMNameActual = validator.isNotNullOrEmpty(slTMFilteredName.toString())
																				? slTMFilteredName.toString()
																						: ConstantsUtil.EMPTY_STRING;
																				sPTMNameActual = sPTMNameActual
																						.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																				sPTMNameActualID = validator.isNotNullOrEmpty(slTMFilterID.toString()) ? slTMFilterID.toString()
																						: ConstantsUtil.EMPTY_STRING;
																				sPTMNameActualID = sPTMNameActualID
																						.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																				sPTMNameActualType = validator.isNotNullOrEmpty(slTMFilterType.toString())
																						? slTMFilterType.toString()
																								: ConstantsUtil.EMPTY_STRING;
																						sPTMNameActualType = sPTMNameActualType
																								.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																								.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																								.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
																						
														
																						if(!showData) {
																							util.formatData(sTMNameID, ConstantsUtil.NO_ACCESS);
																						}else {
																							util.formatData(sTMNameID, sPTMNameActualID);
																						}
																						util.formatData(sTMName, sPTMNameActual);
																						//formatData(sTMNameID, sPTMNameActualID);
																						util.formatData(sTMNameType, sPTMNameActualType);
																						*/
																// Security added for Staff AUG
																StringList slTMSecurityCheck = new StringList();
																if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																	int iSize = slsChildObjectID.size();
																	for (int i = 0; i < iSize; i++) {
																		String strOID = slsChildObjectID.get(i);
																		showData = util.checkHasAccess(context, sUserType, strOID);
																		
																		if (showData) {
																			slTMSecurityCheck.add(strOID);
																		} else {
																			slTMSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																		}
																	}
																} else {
																	int iSize = slsChildObjectID.size();
																	for (int i = 0; i < iSize; i++) {
																		String strOID = slsChildObjectID.get(i);
																		showData = util.checkHasAccess(context, sUserType, strOID);
																		
																		if (showData) {
																			slTMSecurityCheck.add(strOID);
																		} else {
																			slTMSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																		}
																	}
																}

																// Security has to check for multiple objects
																sPTMNameID = validator.isNotNullOrEmpty(slTMSecurityCheck.toString())
																		? slTMSecurityCheck.toString() : ConstantsUtil.EMPTY_STRING;

																sPTMNameID = sPTMNameID.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																sPTMType = validator.isNotNullOrEmpty(slTMType.toString()) ? slTMType.toString()
																		: ConstantsUtil.EMPTY_STRING;
																sPTMType = sPTMType.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																util.formatData(sTMNActualID, sPTMNameID);
																util.formatData(sTMNActual, sPTMName);
																util.formatData(sTMNActualType, sPTMType);

																sPTMNameActual = validator.isNotNullOrEmpty(slTMFilteredName.toString())
																		? slTMFilteredName.toString() : ConstantsUtil.EMPTY_STRING;
																sPTMNameActual = sPTMNameActual
																		.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																StringList slTMActualSecurityCheck = new StringList();
																if (sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																	int iSize = slTMFilterID.size();
																	for (int i = 0; i < iSize; i++) {
																		String strOID = slTMFilterID.get(i);
																		showData = util.checkHasAccess(context, sUserType, strOID);
																		
																		if (showData) {
																			slTMActualSecurityCheck.add(strOID);
																		} else {
																			slTMActualSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																		}
																	}
																} else {
																	int iSize = slTMFilterID.size();
																	for (int i = 0; i < iSize; i++) {
																		String strOID = slTMFilterID.get(i);
																		showData = util.checkHasAccess(context, sUserType, strOID);
																		
																		if (showData) {
																			slTMActualSecurityCheck.add(strOID);
																		} else {
																			slTMActualSecurityCheck.add(ConstantsUtil.NO_ACCESS);
																		}
																	}
																}

																sPTMNameActualID = validator.isNotNullOrEmpty(slTMActualSecurityCheck.toString())
																		? slTMActualSecurityCheck.toString() : ConstantsUtil.EMPTY_STRING;

																sPTMNameActualID = sPTMNameActualID
																		.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																sPTMNameActualType = validator.isNotNullOrEmpty(slTMFilterType.toString())
																		? slTMFilterType.toString() : ConstantsUtil.EMPTY_STRING;
																sPTMNameActualType = sPTMNameActualType
																		.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																util.formatData(sTMName, sPTMNameActual);
																util.formatData(sTMNameID, sPTMNameActualID);
																util.formatData(sTMNameType, sPTMNameActualType);
																}
																//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 30, 2021 for Defect 41630 , 41861 -- END
															}

														} else {
															boolean showData=false;
															if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF)) {
																String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_REF_DOC_FROMIPCLASS)));
																//modified by Ganesh for security impl---->start
																//showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
																showData = util.checkHasAccess(context, sUserType,sPTMNameID );
																//modified by Ganesh for security impl---->end
															}
															if(sUserType.equalsIgnoreCase(ConstantsUtil.PGSTAFF) && !showData) {
																util.formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
																util.formatData(sTMNActualID, ConstantsUtil.NO_ACCESS);
															}else {
																util.formatData(sTMNameID, sPTMNameActualID);
																util.formatData(sTMNActualID, sPTMNameID);
															}
															util.formatData(sTMName, sPTMNameActual);
															util.formatData(sTMNameType, sPTMNameActualType);
															util.formatData(sTMNActual, sPTMName);
															util.formatData(sTMNActualType, sPTMType);
															
														}

														String sPathId = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_ID));
														//modified by for Defect 38256 Release 18x.5.2---->start
														boolean showData = util.checkHasAccess(context, sUserType, sPathId);
														if(!showData)
														{
														 sPathId = ConstantsUtil.NO_ACCESS;
														}
														//modified by for Defect 38256 Release 18x.5.2---->end
														String sPathType = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_TYPE));

									String sPTMLogic = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC));
									String sPMethodOrigin = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN));
									String sPMethodNumber = validator
											.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER));
									String sPMethodSpecific = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS));
									sPMethodSpecific = sPMethodSpecific.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_AND);
									
									//SPEC Added on 12-Dec-2020 by Chandra for Defect 37732 ##--START
									
									
									String sPSampling = validator.getStringEquivalentForSubstituteString(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING));
									
									//SPEC Added on 12-Dec-2020 by Chandra for Defect 37754 ##--START
									/*String sPSubGroup = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP));*/
									
									String sPSubGroup = validator
											.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP));
									//SPEC Added on 12-Dec-2020 by Chandra for Defect 37754 ##--END
									
									/*
									String sPSampling = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING));
									String sPSubGroup = validator	.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP));
									
									//SPEC : 12/03/2020 : added for defect#37732 by Madhana --START
									String sPPlantTesting = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_EXTENDED_DATA_PGPLANTTESTING));
									//SPEC : 12/03/2020 : added for defect#37732 by Madhana --END

									String sPPlantRetesting = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING));
									//SPEC : 12/03/2020 : added for defect#37732 by Madhana --START
									String sPTestingUOM = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_EXTENDED_DATA_PGRETESTINGUOM));
									//SPEC : 12/03/2020 : added for defect#37732 by Madhana --END
*/
									
								
									String sPPlantTesting = validator
											.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING));
									String sPPlantRetesting = validator.getStringEquivalentForSubstituteString(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING));
									String sPTestingUOM = validator
											.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM));
									//SPEC Added on 12-Dec-2020 by Chandra for Defect 37732 ##--END
									
									
									String sPLowerSpecLimit = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT));
									String sPLowerRoutineReleaseLimit = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT));
									String sPPGLowerTarget = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET));
									String sPPGTarget = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET));
									String sPPGUpperTarget = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET));
									String sPUpperRoutineRL = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT));
									String sPPGUpperSpecLimit = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT));
									String sPUnitOfMeasure = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE));
									String sPPGReportNear = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST));
									String sPPGReportType = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE));
									String sPReleseCriteria = validator.getStringEquivalentForSubstituteString(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA));
									String sPPGACtionRequired = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED));
									String sPCriticalFactor = validator.getStringEquivalentForStringList(
											objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR));
									String sPPGBasis = validator
																						.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS));
									
									//SPEC: Release SR18x.6.0 - Added by Amman on Mar 26, 2021 for Defect 41225 -- START
									//String sTestGroup = validator
									//		.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP));
									String sTestGroup = validator
											.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP));
									//SPEC: Release SR18x.6.0 - Added by Amman on Mar 26, 2021 for Defect 41225 -- END
									
									String sApplication = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION));
														
									//SPEC: Release SR18x.6.0 - Added  by Manikanta for defect 41917 on Date 31/03/2021 -- START
														String sTitle = ConstantsUtil.EMPTY_STRING;
														
														boolean bPresent = objectMap.containsKey(ConstantsUtil.PERFORMCHAR_MPT_TITLE);
														if (bPresent) {
															String sObjectId = (String)resultMap.get(ConstantsUtil.SELECT_ID);
															String sFromId = (String)objectMap.get(ConstantsUtil.PERFORMCHAR_ID);
															if(!sObjectId.equals(sFromId)){
																sTitle=util.GetPerformCharcteristicMPT(context, sObjectId);
															}
															/*sTitle = validator
																	.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_MPT_TITLE));*/
														} /*else {
															sTitle = validator
																	.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
														}
														
									String sTitle = validator
											.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));*/
								 //SPEC: Release SR18x.6.0 - Added  by Manikanta for defect 41917 on Date 31/03/2021 -- END
									
														util.formatData(sbPathId, sPathId);
														util.formatData(sbPathType, sPathType);
														util.formatData(sPath, sPPath);

														util.formatData(schg, sPchg);
														util.formatData(sCharcteristic, sPCharcteristic);
														util.formatData(sCharSpec, sPCharSpec);

														util.formatData(sTMLogic, sPTMLogic);
														util.formatData(sMethodOrigin, sPMethodOrigin);
														util.formatData(sMethodNumber, sPMethodNumber);
														util.formatData(sMethodSpecific, sPMethodSpecific);

														util.formatData(sSampling, sPSampling);
														util.formatData(sSubGroup, sPSubGroup);

														util.formatData(sPlantTesting, sPPlantTesting);
														util.formatData(sPlantRetesting, sPPlantRetesting);
														util.formatData(sTestingUOM, sPTestingUOM);

														util.formatData(sLowerSpecLimit, sPLowerSpecLimit);
														util.formatData(sLowerRoutineReleaseLimit, sPLowerRoutineReleaseLimit);
														util.formatData(sPGLowerTarget, sPPGLowerTarget);
														util.formatData(sPGTarget, sPPGTarget);
														util.formatData(sPGUpperTarget, sPPGUpperTarget);
														util.formatData(sUpperRoutineRL, sPUpperRoutineRL);
														util.formatData(sPGUpperSpecLimit, sPPGUpperSpecLimit);

														util.formatData(sUnitOfMeasure, sPUnitOfMeasure);
														util.formatData(sPGReportNear, sPPGReportNear);
														util.formatData(sPGReportType, sPPGReportType);
														util.formatData(sReleseCriteria, sPReleseCriteria);
														util.formatData(sPGACtionRequired, sPPGACtionRequired);
														util.formatData(sCriticalFactor, sPCriticalFactor);
														util.formatData(sPGBasis, sPPGBasis);

														util.formatData(sPTestGroup, sTestGroup);
														util.formatData(sPApplication, sApplication);
														util.formatData(sPMTitle, sTitle);

					}
					mpFinal.put(ConstantsUtil.CHG, schg.toString());
					mpFinal.put(ConstantsUtil.CHARACTERISTICCH, sCharcteristic.toString());
					mpFinal.put(ConstantsUtil.CS, sCharSpec.toString());

					//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
					mpFinal.put(ConstantsUtil.CHARP, sPath.toString());
					/*if ((sType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)
							|| sType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) && isModificatinRequired()) {
						mpFinal.put(ConstantsUtil.CHARP, sPath.toString());
					} else if (!sType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)
							&& !sType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) {
						mpFinal.put(ConstantsUtil.CHARP, sPath.toString());
					}*/
					//SPEC: 10/09/2020: Modified for 18x.5 DEV -- END

					mpFinal.put(ConstantsUtil.REF, sTMNActual.toString());
					mpFinal.put(ConstantsUtil.REFID, sTMNActualID.toString());
					mpFinal.put(ConstantsUtil.REFTYPE, sTMNActualType.toString());

					mpFinal.put(ConstantsUtil.PATH_ID, sbPathId.toString());
					mpFinal.put(ConstantsUtil.PATH_TYPE, sbPathType.toString());

					mpFinal.put(ConstantsUtil.TMTYPE, sTMNameType.toString());
					mpFinal.put(ConstantsUtil.TESTMETHODNAME, sTMName.toString());
					mpFinal.put(ConstantsUtil.TESTMETHODNAMEID, sTMNameID.toString());

					mpFinal.put(ConstantsUtil.TML, sTMLogic.toString());
					mpFinal.put(ConstantsUtil.ORIGIN, sMethodOrigin.toString());
					mpFinal.put(ConstantsUtil.TM, sMethodNumber.toString());
					mpFinal.put(ConstantsUtil.SP, sMethodSpecific.toString());

					mpFinal.put(ConstantsUtil.SAMPLINGSM, sSampling.toString());
					mpFinal.put(ConstantsUtil.SG, sSubGroup.toString());

					mpFinal.put(ConstantsUtil.PLANTTESTING, sPlantTesting.toString());
					mpFinal.put(ConstantsUtil.RT, sPlantRetesting.toString());
					mpFinal.put(ConstantsUtil.UOM, sTestingUOM.toString());

					mpFinal.put(ConstantsUtil.LOWERSPECLIMIT, sLowerSpecLimit.toString());
					mpFinal.put(ConstantsUtil.LRRL, sLowerRoutineReleaseLimit.toString());
					mpFinal.put(ConstantsUtil.LTGT, sPGLowerTarget.toString());
					mpFinal.put(ConstantsUtil.TGT, sPGTarget.toString());
					mpFinal.put(ConstantsUtil.UTGT, sPGUpperTarget.toString());
					mpFinal.put(ConstantsUtil.URRL, sUpperRoutineRL.toString());
					mpFinal.put(ConstantsUtil.USL, sPGUpperSpecLimit.toString());

					mpFinal.put(ConstantsUtil.UNITOF, sUnitOfMeasure.toString());
					mpFinal.put(ConstantsUtil.RTN, sPGReportNear.toString());
					mpFinal.put(ConstantsUtil.RTT, sPGReportType.toString());
					mpFinal.put(ConstantsUtil.RELEASECRITERIA, sReleseCriteria.toString());

					mpFinal.put(ConstantsUtil.ACTIONREQUIRED, sPGACtionRequired.toString());
					mpFinal.put(ConstantsUtil.CAPSCR, sCriticalFactor.toString());
					mpFinal.put(ConstantsUtil.BA, sPGBasis.toString());

					mpFinal.put(ConstantsUtil.TESTGROUP, sPTestGroup.toString());
					mpFinal.put(ConstantsUtil.AP, sPApplication.toString());
					mpFinal.put(ConstantsUtil.MPT, sPMTitle.toString());

				} catch (Exception e) {
					LOGGER.error("Exception from IPPBO:  updatePerformCharcteristic" + e);
					return new HashMap();
				}
				return mpFinal = util.filterMapList(mpFinal);
				
	}
	
	
	/**
	 * 
	 * @param sbData
	 * @return
	 */
	public StringBuilder MapSlType(StringBuilder sbData){
		StringBuilder sbMapType = new StringBuilder();
		String[] saData = sbData.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		String sType = DomainConstants.EMPTY_STRING;
		for(int i=0 ;i<saData.length;i++){

			sType = saData[i].trim();

			if(sType.equals("Approve")){

				sType= sType.replace("Approve", "Approved");

			}else if(sType.equalsIgnoreCase("ignore")){
				sType= sType.replace("Ignore", "Ignored");
				
			}else if(sType.equals("None"))
				sType= sType.replace("None", "Approved");
			
			sbMapType.append(sType).append(ConstantsUtil.SYMBL_PIPE);
		}

		return sbMapType;
	}
	//SPEC: <10.10.2020>: Added for req 18x.5 ## -- END
	
	 //SPEC: 11/04/2020: Added for 18x.5 DEV -- START
    public boolean checkSubstituteHasAccess(Context context, Map objectMap) {
    	
		StringBuilder  sbReturnVal = new StringBuilder();
		boolean showData = false;
		try
		{
			StringValidatorUtil validator = new StringValidatorUtil();
			
			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership=util.filterOwnerShip(sComp);
			
		if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))
			{
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
				{
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
					String strSubPartId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
					
					DomainObject doEachChild = new DomainObject(strSubPartId);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					StringList slSelect = new StringList();
					slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					Map mpIpClass = doEachChild.getInfo(context, slSelect);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doEachChild.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					//commented by Ganesh for security impl------>start
					/*if(util.isModificatinRequired())
					{
						//For EBP User
						showData = util.checkOwnerShip(context, slUserOwnership, strSubPartId);
						
					}else if(sct.isStaffAUGUser())
					{
						//For Staff Aug USer check 
						if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							//Validation for Hir checks on Formulation
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else
						{
							//Validation for Hir checks for other than Formulation
							showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
						}
					}else 
					{
						//For Internal User check
						if(slHIRTypes.contains(strSubPartType)) 
						{
							//Validation for Hir checks on Formulation
							if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else 
							{
								//Validation for Hir checks for other than Formulation
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
						}else 
						{
							//If it is Non-Hir we can show without checks for internal user
							showData=true;
						}
					}*/
					//commented by Ganesh for security impl------>end
					//modified by Ganesh for security impl------>start
					showData = util.checkHasAccess(context, null, strSubPartId);
					//modified by Ganesh for security impl------>end
					
//						
				}
				}else
			{	//If no Substitue found
				return showData;
			}
			
		}catch(Exception e){
			
			LOGGER.error("Error from IPPBO :  checkSubstituteHasAccess" + e);
			return showData;
		}
		return showData;
	}
	//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
}
