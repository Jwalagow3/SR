package com.pg.us.specanywhere_enovia.service;

import java.util.List;

import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.util.FrameworkException;
import com.pg.us.specanywhere_enovia.bo.SearchBO;

public interface EnoviaSearchService {

	public List<SearchBO> getSearchResult(String strName, Environment env) throws FrameworkException, Exception; 
}
