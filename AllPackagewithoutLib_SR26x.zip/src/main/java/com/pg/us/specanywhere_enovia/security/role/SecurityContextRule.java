package com.pg.us.specanywhere_enovia.security.role;

public class SecurityContextRule {
	
	
	
 /**
  * User must have two roles to access the application
 * @param role
 * @return
 */
	public boolean validateMandatoryRules(String role) {
		boolean flag = false;
		if (role.contains(SecurityConstants.MANDATORY_SECURITY_ROLE_ONE)
				&& role.contains(SecurityConstants.MANDATORY_SECURITY_ROLE_TWO)) {
			flag = true;
		}

		return flag;

	}
	
	 /**
	  * User License must match Object IP Classification
	 * @param role
	 * @return
	 */
		public boolean validateUsersObjectAccess(String role) {
			boolean flag = false;
			if (role.contains(SecurityConstants.MANDATORY_SECURITY_ROLE_ONE)
					&& role.contains(SecurityConstants.MANDATORY_SECURITY_ROLE_TWO)) {
				flag = true;
			}

			return flag;

		}

}
