package com.pg.us.specanywhere_enovia.security.role;

public class SecurityConstants {
	
	public static String SECURITYAUTHORITY="SAuthorities";
	public static String LICENSEAUTHORITY="LAuthorities";
	
	public static String COMPANYAUTHORITY="CAuthorities";
	public static String DEPARTMENTAUTHORITY="DAuthorities";
	
	public static int ROLELENGTH=12;
	
	public static String SEPARATOR="|";
	
	public static String MANDATORY_SECURITY_ROLE_ONE="Restricted Product Data User.";
	public static String MANDATORY_SECURITY_ROLE_TWO="Library User.";
	
	public static String COMPANY_PG="PG";
	public static String COMPANY_STAFF_PG="PG Staff Augmentation";
	public static String RESTRICTED="Restricted";
	public static String HIGHLYRESTRICTED="Highly Restricted";
	
	

}
