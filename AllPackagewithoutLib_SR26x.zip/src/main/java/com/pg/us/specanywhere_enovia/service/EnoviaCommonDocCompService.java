package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaCommonDocCompService {
	public HashMap<String, HashMap<String, Map<String, String>>> getDocCompdata(String objId, Environment env, String sType);
}
