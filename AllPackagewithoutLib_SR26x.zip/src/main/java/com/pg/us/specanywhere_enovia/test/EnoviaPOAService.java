package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaPOAService
{

	public static void  main(String[] args)	throws Exception 
	{
		//String objId = "20336.41905.32768.1354";
		String objId = "20336.41905.32768.206";
		
		String sType="";
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
		Logger LOGGER = Logger.getLogger(EnoviaPOAService.class);
		
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		EnoviaConnectionPool pool = new EnoviaConnectionPool();
	    Context context = pool.checkOut();
	    swContext.stop();
		LOGGER.info("COMMON DOC SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());

	
		CommonDocBO cdoc = new CommonDocBO();
		try 
		{
			/*
			 * User Profile Section
			 * */
			String sUserType = BbUtil.getUserType();
			if(null==sUserType) {
				LOGGER.info("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
			}
			
			boolean isExternal = false;
			boolean isInternal = true;
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM) || sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP)){
				isExternal=true;
				isInternal=false;
			}
			
			sUserType="";
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpPartSpecResult = new HashMap<String,String>();
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpOrganization = new HashMap<String, String>();
			Map<String,String> mpMarketsApproved = new HashMap<String, String>();
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			cdoc.addMultiList();
			Map<String, StringList> BusinessObjectSelectableMap = cdoc.getDefaultPartSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			
			DomainObject dobCdoc = new DomainObject(objId);
			StopWatch swInfo = new StopWatch();
			swInfo.start();
			Map resultMaps = dobCdoc.getInfo(context, slContextSelects);
			swInfo.stop();
			cdoc.removeMultiList();
			LOGGER.info("POA SERVICE GETINFO ELAPSED TIME : "+swInfo.getTime());
			
			/*
			 * LOAD HEADER CONTENT SECTION
			 * */
			mpHeaderContent.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
			mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 

			
			//Organizations
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME))));
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME))));
			
			
			//ATTRIBUTE SECTION
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			mpAttribResult.put(ConstantsUtil.ID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID))));
			String sDocType = util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE)));
			mpAttribResult.put(ConstantsUtil.TYPE, sDocType);
			mpAttribResult.put(ConstantsUtil.NAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME))));
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION))));
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_OWNER))));
			mpAttribResult.put(ConstantsUtil.STATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT))));
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR))));
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))));
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION))));
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))));
			mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT))));
			mpAttribResult.put(ConstantsUtil.SAPTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))));
			mpAttribResult.put(ConstantsUtil.RELEASEPHASE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE))));
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE))));
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE))));
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE))));
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE))));
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE))));
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION))));
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT))));
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE))));
			mpAttribResult.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME))));
			mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER))));
			mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_TEMPLATE))));

			
			String sClassifictaion = util.getClassification(resultMaps);
			mpAttribResult.put(ConstantsUtil.SECURITY, (sClassifictaion));
			swAttributes.stop();
			LOGGER.info("POA SERVICE GET ATTRIBUTE ELAPSED TIME : "+swAttributes.getTime());

			mpMarketsApproved.put(ConstantsUtil.MARKETSAPPROVED, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)));
			
			StopWatch swSpecs = new StopWatch();
			swSpecs.start();
			StringList slBusSelects = cdoc.getContextObjectBusSelectable(context);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION,
					"Document", slBusSelects, new StringList(), false, true, (short) 1,
					"current!=Obsolete", ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			if ((sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM) || sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP))){
				
				mlRelatedSpecs=util.filterPhase(mlRelatedSpecs);
			}
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType=new StringBuilder();
			StringBuilder sbRev=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbTitle=new StringBuilder();
			StringBuilder sbRelesPhase = new StringBuilder();
			StringBuilder sbOriginSource =new StringBuilder();
			StringBuilder sbSubType =new StringBuilder();
			StringBuilder sbOriginator =new StringBuilder();
			
				while(objectListItr.hasNext()) 
				{
					Map objectMap = (Map) objectListItr.next();
					String strType = (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sShareWithSupplier = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS);
					if ((sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM) || sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP)
							&& (strType.equalsIgnoreCase(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)
									|| strType.equalsIgnoreCase(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE))
							&& "false".equalsIgnoreCase(sShareWithSupplier))) {
						continue;
					}
					util.formatData(sbId,(String)objectMap.get(ConstantsUtil.SELECT_ID));
					util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
					strType=util.mapType(strType);
					util.formatData(sbType,strType);
					util.formatData(sbRev,(String)objectMap.get(ConstantsUtil.SELECT_REVISION));
					util.formatData(sbTitle,(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					util.formatData(sbOriginSource,(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE));
					util.formatData(sbSubType,(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE));
					util.formatData(sbCurrent,(String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
					util.formatData(sbOriginator,(String)objectMap.get(ConstantsUtil.SELECT_ORIGINATOR));
					
					
				}
				mpPartSpecResult.put(ConstantsUtil.ID, sbId.toString());
				mpPartSpecResult.put(ConstantsUtil.NAME, sbName.toString());
				mpPartSpecResult.put(ConstantsUtil.TYPE, sbType.toString());
				mpPartSpecResult.put(ConstantsUtil.REVISION, sbRev.toString());
				mpPartSpecResult.put(ConstantsUtil.TITLE, sbTitle.toString());
				mpPartSpecResult.put(ConstantsUtil.SOURCE, sbOriginSource.toString());
				mpPartSpecResult.put(ConstantsUtil.SPEC_SUB_TYPE, sbSubType.toString());
				mpPartSpecResult.put(ConstantsUtil.STATE, sbCurrent.toString());
				mpPartSpecResult.put(ConstantsUtil.ORIGINATOR, sbOriginator.toString());
				
				mpPartSpecResult=util.filterMapList(mpPartSpecResult);
				
				swSpecs.stop();
				LOGGER.info("POA SERVICE GET RELATED SPECIFICATIONS ELAPSED TIME : "+swSpecs.getTime());
				
				/*
				 * LOAD REFERENCE DOCS SECTION
				 * */
			
				StopWatch swReferenceDoc= new StopWatch();
				swReferenceDoc.start();
				MasterCOPBO mcop = new MasterCOPBO();
				mapReferenceDocs = cdoc.updateRefDocs(context, resultMaps,false);
				mapReferenceDocs=util.filterMapList(mapReferenceDocs);
				swReferenceDoc.stop();
				LOGGER.info("POA SERVICE  REFERENCE DOCS ELAPSED TIME : "+swReferenceDoc.getTime());
				
				//Mandatory outputs
				hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
				hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONS, mpOrganization);
				hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
				hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
				
			LOGGER.info("CommonDocument MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "POA SERVICE OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			
				
				System.out.println("hmAttrib---------->"+hmAttrib);
				pool.checkIn(context);
			LOGGER.info("CommonDocument MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "COMMON DOC SERVICE OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		}catch (Exception e) {
			LOGGER.error("Exception in getCommonDocdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		//Subhajit Added for Memory Leakage Analysis - Start
		if(null!=context) {
		context.close();
		}
		//Subhajit Added for Memory Leakage Analysis - End
	}
}
