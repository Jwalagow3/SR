/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaFPPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaCardBO;
import com.pg.us.specanywhere_enovia.bo.IRMSBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.MasterSpecs;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.bo.SapBomAsFed;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import jakarta.servlet.http.HttpServletRequest;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class EnoviaFPPServiceImpl implements EnoviaFPPService {

	private static Logger LOGGER = Logger.getLogger(EnoviaFPPServiceImpl.class);

	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Autowired
	private EnoviaConnectionPool pool;

	@Override
	public HashMap<String, Map<String,String>> getFPPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		Context context = null;
		try {

			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			ContextUtil.startTransaction(context, true);
			swContext.stop();
			LOGGER.info("FPP CONTEXT ELAPSED TIME : "+swContext.getTime());
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			
			
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			if (UIUtil.isNotNullAndNotEmpty(sUserType))
			{
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BObjutil.getUserView(context, objId);
				}
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			}
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bManufacturerView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			FinishedProductPartBO fppBO = new FinishedProductPartBO();	
			//DomainObject doFPP = new DomainObject(objId);
			DomainObject doFPP = DomainObject.newInstance(context,objId);
			String sState = doFPP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			//SPEC: Modified by Ajay for Req. no. 78405 START
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (sState.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR IN FPP: "+hmAttrib);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!sState.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(sState.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}
			else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC: Modified by Ajay for Req. no. 78405 END
			MasterCOPBO mcop = new MasterCOPBO();
			CommonBusUtilBO commonBO = new CommonBusUtilBO();
			Map BusinessObjectSelectableMap = fppBO.getFinishedProductPartSelectableMap(context);

			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mapAttribResult = new HashMap<String,String>();
			Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
			Map<String,String> mapBomResult = new HashMap<String,String>();
			Map<String,String> mapPlantResult = new HashMap<String,String>();
			Map<String,String> mapWnDResult = new HashMap<String,String>();
			Map<String,String> mapSapBomAsFedResult = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mapCosResult = new HashMap<String,String>();
			Map<String,String> mapWarehouseClassResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mapPartSpecification = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mapTupBomResult = new HashMap<String,String>();
			Map<String,String> mapPackagingUnitResult = new HashMap<String,String>();
			Map<String,String> mapTransportUnitResult = new HashMap<String,String>();
			Map<String,String> mpBomMcupResult = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpEBOMMasterInnerPack = new HashMap<String,String>();
			Map<String,String> mpPerformChar= new HashMap<String,String>();
			Map<String,String> mpDangerousGoodsClf = new HashMap<String,String>();
			Map<String,String> mpGlobalHarStandard = new HashMap<String,String>();
			Map<String,String> mpUniqFormulaIdentifier= new HashMap<String,String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mpStability = new HashMap<String,String>();
			Map<String,String> mpTUPSubstituteResult = new HashMap<String,String>();
			Map<String,String> mpMcupSubstituteResult = new HashMap<String,String>();
			Map<String,String> mpMIPackSubstituteResult = new HashMap<String,String>();
			Map<String,String> mpBomMcopResult = new HashMap<String,String>();
			Map<String,String> mpMcopSubstituteResult = new HashMap<String,String>();
			Map<String,String> mapCertifications = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
			Map<String,String> mpDerivedToResult = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpBomCupResult = new HashMap<String,String>();
			Map<String,String> mpBomCopResult = new HashMap<String,String>();
			Map<String,String> mpBomIpResult = new HashMap<String,String>();
			Map<String,String> mpBomSubstituteResult = new HashMap<String,String>();
			Map<String,String> mpBomIpSubstituteResult = new HashMap<String,String>();
			Map<String,String> mpBomCopSubstituteResult = new HashMap<String,String>();
			//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
			Map<String,String> mpSmartLabel = new HashMap<String,String>();
			Map<String,String> mpRelatedIngredient = new HashMap<String,String>();
			Map<String,String> mpBatteryRollUp = new HashMap<String,String>();
			Map<String,String> mpBatteryCalc = new HashMap<String,String>();
			Map<String,String> mpCUPArtwork = new HashMap<String,String>();
			Map<String,String> mpRegistrationDetails = new HashMap<String,String>();
			Map<String,String> mpLocalProductName = new HashMap<String,String>();
			
			//JwALA COmpare-- START
			Map<String,String> mapCompareBomResult = new HashMap<String,String>();
			Map<String,String> mapCompareSubstituteResult = new HashMap<String,String>();
			//JwALA COmpare-- END
			
			//SPEC: <02.24.2021>: Added for req 18x.6 ## -- END
			Map mpGTIN = new HashMap();
			
			//SPEC: <12.02.2020>: Added for req 18x.5 by Amman ## -- START
			Map<String,String> mpBaseCodeDetails = new HashMap<String,String>();
			Map<String,String> mpSubstituteBaseCodeDetails = new HashMap<String,String>();
			//SPEC: <12.02.2020>: Added for req 18x.5 by Amman ## -- END
			
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 6, 2021 -- START
			Map<String,String> mpBaseCodeDetailsUpdate = new HashMap<String,String>();
			Map mpGTINUpdate = new HashMap();
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 6, 2021 -- END
			
			//SPEC: <10.12.2020>: Added for req 18x.5 ## -- START
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			//SPEC: <10.12.2020>: Added for req 18x.5 ## -- END
			Map<String,String> mpPackCert = new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			
			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- START
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slSelects.add(ConstantsUtil.ATL_STATE);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- END
			Map BusinessObjectRelSelectableMap = fppBO.getFppRelatedObjsSelectableMap(context);
			StringList slEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slRelEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.REL_SELECTS);


			StopWatch swAttributes = new StopWatch();
			//SPEC: Release SR18x.5.2 - Added for Defect# 39452  by gaikwad.tg on Date 11 Feb 2021 -- START
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FORMAT_FILE);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_CAPTURED);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_SIZE);
			//SPEC: Release SR18x.5.2 - Added for Defect# 39452  by gaikwad.tg on Date 11 Feb 2021 -- END
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- START
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.ATL_STATE);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- END
		
			swAttributes.start();
			//Map resultMap= null;
			//SPEC: <20.05.2022>: Guna Modified for Req 41754 22x Release  -- START
			//Map resultMap = doFPP.getInfo(context, slSelects,fppBO.getPlantBusSelectable(context));
			Map resultMap = doFPP.getInfo(context, slSelects,fppBO.addMultiList());
			//SPEC: <20.05.2022>: Guna Modified for Req 41754 22x Release  -- END
			swAttributes.stop();
			//SPEC: Release SR18x.5.2 - Added for Defect# 39452  by gaikwad.tg on Date 11 Feb 2021 -- START
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
			//SPEC: Release SR18x.5.2 - Added for Defect# 39452  by gaikwad.tg on Date 11 Feb 2021 -- END
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- START
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_STATE);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- END

			LOGGER.info("FPP GETINFO ELAPSED TIME : "+swAttributes.getTime());

			boolean bHIRComplaint = busUtil.getHIRComplaintForSupplier(context,doFPP,resultMap);

			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			//Added by Jwala for PDF VIews requrement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requrement 34055 2022x Development -- END
			
			//Get Type Name
			String sType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			String sID = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sName = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sRev = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			//String sCreatedDate = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ORIGINATED))?(String)resultMap.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING;
			String sCreatedDate = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_EFFECTIVITY_DATE))?(String)resultMap.get(ConstantsUtil.SELECT_EFFECTIVITY_DATE) : ConstantsUtil.EMPTY_STRING;

			if(bAllInfoView || bManufacturerView){

				/**
				 * LOAD IP CLASSES SECTION
				 */
				//SPEC: <10.19.2020>: Added for req 18x.5 ## -- START
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIpSecuritySetting =fppBO.getIpClass(context, doFPP, slIpSelects);
				//SPEC: <10.19.2020>: Added for req 18x.5 ## -- END
				
				/**
				 * FILES SECTION
				 */
				
				
				String FileCapturedFieNew = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormatsNew = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileNameNew = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.STR_FILE_NAME));
				String FileSizeNew = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.STR_FILE_SIZE));
				
				
				
				StringList SlFileCapturedFie =FrameworkUtil.split(FileCapturedFieNew, ",");
				StringList SlFileFormats =FrameworkUtil.split(FileFormatsNew, ",");
				StringList SlFileName =FrameworkUtil.split(FileNameNew, ",");
				StringList SlFileSize =FrameworkUtil.split(FileSizeNew, ",");
				
				StringBuilder sbFileCapturedFie = new StringBuilder();
				StringBuilder sbFileFormats = new StringBuilder();
				StringBuilder sbFileName = new StringBuilder();
				StringBuilder sbFileSize = new StringBuilder();
				
				String RenderingFormat = PropertyUtil.getSchemaProperty("format_JView");
				String FORMAT_GENERIC = PropertyUtil.getSchemaProperty(context, "format_generic");
				String strCurrent = (validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.SELECT_CURRENT)))
						? (String) resultMap.get(ConstantsUtil.SELECT_CURRENT)
						: ConstantsUtil.EMPTY_STRING;
				String fileFormat = null;
				String fileSize = null;
				String fileCapturedFie = null;
				for (int index = 0; index < SlFileName.size(); index++) 
				{
					String fileName = (String)SlFileName.get(index);
					fileFormat = "";
					fileSize = "";
					fileCapturedFie = "";
					if (fileName != null && fileName.trim().length() > 0) 
					{
						if (index != -1 && SlFileFormats != null && SlFileFormats.size() >= index)
						fileFormat = (String)SlFileFormats.get(index);
						if (index != -1 && SlFileSize != null && SlFileSize.size() >= index)
						fileSize = (String)SlFileSize.get(index);
						if (index != -1 && SlFileCapturedFie != null && SlFileCapturedFie.size() >= index)
						fileCapturedFie = (String)SlFileCapturedFie.get(index);
						
						if (!fileFormat.equals(RenderingFormat) && ((!"Release".equals(strCurrent) && !"Complete".equals(strCurrent)) || !FORMAT_GENERIC.equals(fileFormat))) 
						{
							busUtil.formatData(sbFileCapturedFie, fileCapturedFie);
							busUtil.formatData(sbFileFormats, fileFormat);
							busUtil.formatData(sbFileName, fileName);
						} 
					} 
				}
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
				if(validator.isNotNullOrEmpty(fileSize)) {
					String[] strFileSize=fileSize.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					for (int i = 0; i < strFileSize.length; i++) {
						String strEachFileSize = strFileSize[i];
						double dFileSize = Double.parseDouble(strEachFileSize);
						dFileSize = dFileSize/1024;
						strEachFileSize=Double.toString(dFileSize).format("%.2f", dFileSize);
						sbFileSize.append(strEachFileSize).append(" KB").append(ConstantsUtil.SYMBL_PIPE);
					}
				}	
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
				
				mpFiles.put(ConstantsUtil.ACTION, sbFileCapturedFie.toString().trim());
				mpFiles.put(ConstantsUtil.FILESFORMAT, sbFileFormats.toString().trim());
				mpFiles.put(ConstantsUtil.FILESNAMES, sbFileName.toString().trim());
				mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString().trim());
				
				//SAP PO Call For GTIN
				if(!sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT))
				{
					//ExecutorService service = Executors.newFixedThreadPool(1);
					//Future<Map> normalFuture=service.submit(new GTINTextsExecutor(context,sID, sType,sName,env));
					BusExtractUtil util = new BusExtractUtil();
					Map normalFuture =  util.getGTINFromSoapPO(context, sID,sType,sName,env);
					 mpGTIN =normalFuture;
				}
				
				/**
				 * Sap Bom As Fed Section 
				 */

				SapBomAsFed sapBom = new SapBomAsFed();
				mapSapBomAsFedResult = sapBom.getSapBOMasFed(context,sID);
				//SPEC: <02.23.2021>: Commented/Added for req 18x.6 ## -- START

				if (mapSapBomAsFedResult.containsKey(ConstantsUtil.AUTHORIZED)) {
					mapSapBomAsFedResult.remove(ConstantsUtil.AUTHORIZED);
				}
				if (mapSapBomAsFedResult.containsKey(ConstantsUtil.AUTHORIZEDTOUSE)) {
					mapSapBomAsFedResult.remove(ConstantsUtil.AUTHORIZEDTOUSE);
				}
				if (mapSapBomAsFedResult.containsKey(ConstantsUtil.AUTHORIZEDTOPRODUCE)) {
					mapSapBomAsFedResult.remove(ConstantsUtil.AUTHORIZEDTOPRODUCE);
				}
				if (mapSapBomAsFedResult.containsKey(ConstantsUtil.MIN)) {
					mapSapBomAsFedResult.remove(ConstantsUtil.MIN);
				}
				if (mapSapBomAsFedResult.containsKey(ConstantsUtil.MAX)) {
					mapSapBomAsFedResult.remove(ConstantsUtil.MAX);
				}
				
				//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- END
				/**
				 * LOAD Main BOM SECTION
				 * */
				StopWatch swBom = new StopWatch();
				swBom.start();
				//SPEC: <31.05.2022>: Guna Modified for Req 41754 22x Release  -- START
				MapList mlEBOMList = busUtil.getExpandedBOM(context, doFPP, ConstantsUtil.RELATIONSHIP_EBOM, 
						ConstantsUtil.TYPE_PGPHASE, fppBO.getBomBusSelect(context), fppBO.getBomRelSelect(context), ConstantsUtil.SELECT_NAME+"=~~PCT*", "PCT");
				//SPEC: <31.05.2022>: Guna Modified for Req 41754 22x Release  -- END
				swBom.stop();
				LOGGER.info("FPP BOM ELAPSED TIME : "+swBom.getTime());

				//Main BOM Section
				//Added by Jwala for the requirement FPP Compare 78495 -- START
				if(mlEBOMList.size()!=0){
					if(sComp.equalsIgnoreCase(ConstantsUtilIRM.FPP_COMPARE) || sComp.equalsIgnoreCase(ConstantsUtilIRM.COMPARE)) {
						mapCompareBomResult  =	fppBO.parsePGPhaseCompareBOM(context,mlEBOMList, resultMap);
						for(Map.Entry entry : mapCompareBomResult.entrySet() ) {
							String key = (String) entry.getKey();
							Map innerMap = (Map) entry.getValue();
							if((ConstantsUtil.BILLOFMATERIALS).equalsIgnoreCase(key)) {
								hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, innerMap);
							}else if((ConstantsUtil.SUBSTITUTEPARTS).equalsIgnoreCase(key)) {
								hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, innerMap);
							}
						}
					} else {
						//SPEC: <02.10.2021>: Modified for Defect #39277 by Sumit  --START
						mapBomResult =	fppBO.parsePGPhaseBOMMaplist(context,mlEBOMList, resultMap);
						//SPEC: <02.10.2021>: Modified for Defect #39277 by Sumit  --ENDS
					}
				}
				//Added by Jwala for the requirement FPP Compare 78495 -- END
				StopWatch swTUP = new StopWatch();
				swTUP.start();
				MapList mlTUPFromFPP = doFPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGTRANSPORTUNIT,
						ConstantsUtil.TYPE_PGTRANSPORTUNITPART, slEBOMSelects, slRelEBOMSelects, false, true, (short) 1,
						null, null, 0);
				
				//Removing non released parts from manufacturer
				if(bManufacturerView){
					mlTUPFromFPP=busUtil.filterPhase(mlTUPFromFPP);
				}
				
				swTUP.stop();
				LOGGER.info("FPP TUP BOM  ELAPSED TIME : "+swTUP.getTime());
				
				//Tup BOM and TUP Substitute
				
				//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- START
				//mapTupBomResult = busUtil.getTupBom(context, mlTUPFromFPP, slEBOMSelects, slRelEBOMSelects,mpTUPSubstituteResult);
				mapTupBomResult = fppBO.getTupBom(context, mlTUPFromFPP, slEBOMSelects, slRelEBOMSelects,mpTUPSubstituteResult);
				//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- END
				
				MapList mlRelatedObjects = new MapList();
				StringList slRelSelects = new StringList(ConstantsUtil.SELECT_PARTFAMILYREF_PGDIMENSIONUOM);
				try {
					StopWatch swRelatedObj = new StopWatch();
					swRelatedObj.start();

					Pattern sbTypePattern = new Pattern(ConstantsUtil.TYPE_PGTRANSPORTUNITCHARACTERISTIC);
					sbTypePattern.addPattern(ConstantsUtil.TYPE_PGPACKINGUNITCHARACTERISTIC);

					mlRelatedObjects = doFPP.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_CHARACTERISTIC,
							sbTypePattern.getPattern(),
							slSelects,
							slRelSelects,
							false,
							true,
							(short) 1,
							null,
							null,
							0);
					swRelatedObj.stop();
					
					if(bManufacturerView){
						mlRelatedObjects=busUtil.filterPhase(mlRelatedObjects);
					}
					
					LOGGER.info("FPP TUP RELATED OBJS ELAPSED TIME : "+swRelatedObj.getTime());
				}catch(Exception e) {
					LOGGER.error("Exception From FPP Service IMPL Class "+e);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					throw e;
				}

				StopWatch swClassItem = new StopWatch();
				swClassItem.start();

				/**
				 * Packaging Weight Characteristics section
				 */
				if(!sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT)) {
					MapList mlPackingChars = fppBO.getPackingUnitWeightsAndDiamensionsData(context,sID);
					//	mapPackagingUnitResult  =fppBO.getPackagingDimensions(context, mlPackingChars,mapPackagingUnitResult);
					mapPackagingUnitResult  =fppBO.getPackagingDimensions(context, mlPackingChars,mapPackagingUnitResult,sID,sType,sName,mpGTIN);
				}
				else {
					mapPackagingUnitResult =  fppBO.UpdatePackagingChar(context, resultMap);
				}
				swClassItem.stop();
				
				//SPEC: <11.17.2020>: Added for Defect #36999 & Defect #37000  & Defect #37388 & Defect #37340 -- START		
				
				Pattern sbTypePattern = new Pattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
				sbTypePattern.addPattern(ConstantsUtil.TYPE_PGINNERPACKUNITPART);
				sbTypePattern.addPattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
				
				
						StringList slSubstitutes = new StringList((fppBO.addUnitSelects(fppBO.getMasterBusEbom())));
						StringList slRelSubstitutes = new StringList(fppBO.getMasterRelEbom());

				/**
				 * Get Master Parts
				 */
				MapList ebomPgCustPartList = doFPP.getRelatedObjects(context,
						DomainObject.RELATIONSHIP_EBOM,                  //Rel Pattern
						sbTypePattern.getPattern(),                      // Type Pattern
						fppBO.addUnitSelects(fppBO.getMasterBusEbom()),  //Object Select
						fppBO.getMasterRelEbom(), 						 //rel Select
						false,											 //get To
						true,											 //get From
						(short)0,										 //recurse level
						ConstantsUtil.EMPTY_STRING,												 //where Clause
						null,											 //relationshipWhere Clause
						0);
						
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doFPP.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END	
						if (!ebomPgCustPartList.isEmpty())
						{
							mpBomMcupResult = busUtil.getMasterCopCupIpBom(context, ebomPgCustPartList, slSelects, slRelEBOMSelects,"CUP");
							mpMcupSubstituteResult = busUtil.getMasterCopCupIpSubstitutes(context, ebomPgCustPartList,slSelects, slRelEBOMSelects,"CUP");//Mofified by Ketan for Defect no. 52855
							
							mpBomMcopResult = busUtil.getMasterCopCupIpBom(context, ebomPgCustPartList, slSelects, slRelEBOMSelects,"COP");
							mpEBOMMasterInnerPack = busUtil.getMasterCopCupIpBom(context, ebomPgCustPartList, slSelects, slRelEBOMSelects,"IP");
							//SPEC: 07/04/2021: Modified for 18x.6 Defect #42196 by Bala-- START
							//mpMcopSubstituteResult = busUtil.getMasterCopCupIpSubstitutes(context, ebomPgCustPartList,slSubstitutes, slRelSubstitutes,"COP");
							mpMcopSubstituteResult = busUtil.getMasterCopCupIpSubstitutes(context, ebomPgCustPartList,slSelects, slRelEBOMSelects,"COP");
							//SPEC: 07/04/2021: Modified for 18x.6 Defect #42196 by Bala-- END
							mpMIPackSubstituteResult = busUtil.getMasterCopCupIpSubstitutes(context, ebomPgCustPartList,slSelects, slRelEBOMSelects,"IP");//Mofified by Ketan for Defect no. 52855
							

							ebomPgCustPartList.addSortKey(ConstantsUtil.TYPE, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.STRING);//Sorting necessary to populate Packaging Unit Table in order (CUP/COP)
							ebomPgCustPartList.sort();

						}

				//SPEC: <11.17.2020>: Added for Defect #36999 & Defect #37000 & Defect #37388 & Defect #37340-- END

				/**
				 * Get the LifeCycle Section
				 * 
				 */
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				//if(bAllInfoView){
				
					//SPEC: <10.09.2020>: Modified for req 18x.5 ## -- START
					mpLifeCycleApproval = busUtil.getCOName(context, changeargs);
					//mpLifeCycleApproval = fppBO.getCOName(context, changeargs);
					//SPEC: <10.09.2020>: Modified for req 18x.5 ## -- START
					
				//}
				swLifecycle.stop();
				LOGGER.info("FPP LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

				/**
				 * LOAD HEADER SECTION
				 * */
				mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)))?busUtil.mapType((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);		
				//mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: Release SR18x.6.0.1 - Modified by Amman on Apr 26, 2021 for Defect raised by Internal Testing Team -- START
				mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty(validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE))))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0.1 - Modified by Amman on Apr 26, 2021 for Defect raised by Internal Testing Team -- END
				
				mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: Release SR18x.6.0.1 - Modified by Amman on Apr 26, 2021 for Defect raised by Internal Testing Team -- START
				mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty(validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE))))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0.1 - Modified by Amman on Apr 26, 2021 for Defect raised by Internal Testing Team -- END
				
				String sClassification = busUtil.getClassification(resultMap);
				mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
				mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				String masterId = validator
						.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtil.SELECT_MASTERPARTID));
				if (UIUtil.isNotNullAndNotEmpty(masterId)) {
					//DomainObject obj = new DomainObject(masterId);
					DomainObject obj = DomainObject.newInstance(context,masterId);
					String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					obj.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
					boolean showData = busUtil.checkHasAccess(context, sUserType, masterId);
					if (!showData) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
				}
				mpHeaderResult.put(ConstantsUtil.MASTERPARTID, masterId);
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
				
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 25, 2021 for Defect 41567 -- START
				String pgSapType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
				if(sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT) && pgSapType.equalsIgnoreCase("HALB")) 
				{
					mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtilIRM.SELECT_MASTERPARTNAME_FP_HALB))));
					mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtilIRM.SELECT_MASTERPARTTYPE_FP_HALB))));
					
					String mastersId = validator
							.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtilIRM.SELECT_MASTERPARTID_FP_HALB));
					
					if (UIUtil.isNotNullAndNotEmpty(mastersId)) {
						//DomainObject object = new DomainObject(mastersId);
						DomainObject object = DomainObject.newInstance(context,mastersId);
						String mastersState = object.getInfo(context, ConstantsUtil.SELECT_CURRENT);
						if (!mastersState.equals(ConstantsUtil.RELEASE) && !mastersState.equals(ConstantsUtil.RELEASED)) {
							mastersId = ConstantsUtil.NO_ACCESS;
						}
						boolean showData = busUtil.checkHasAccess(context, sUserType, mastersId);
						if (!showData) {
							mastersId = ConstantsUtil.NO_ACCESS;
						}
					}
					mpHeaderResult.put(ConstantsUtil.MASTERPARTID, mastersId);
				}
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 25, 2021 for Defect 41567 -- END
				
				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				mapAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID)))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - #Defect41563 Added  by gaikwad.tg on Date 24 March 2021 -- START
				//mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : "Finished Product");
				//SPEC: Release SR18x.6.0 - #Defect41563 Added  by gaikwad.tg on Date 24 March 2021 -- END
				mapAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.TYPE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 18, 2021 -- START
				String SAPtype = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
				//SPEC: <01.04.2022>: Guna Modified for 22x REQ 33479 Dev  -- START
				if(SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB) || bManufacturerView || bAllInfoView) {
					mapAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMap.get(ConstantsUtil.SELECT_OWNER)));
				}
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 18, 2021 -- END
				
				mapAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMap.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMap.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: Release 18x.5.2: Modified for Defect 39278 by Amman on 11th Feb,2021## -- START
				mapAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.ORIGINATED)))?validator.DateFormatterParse((String)resultMap.get(ConstantsUtil.ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release 18x.5.2: Modified for Defect 39278 by Amman on 11th Feb,2021## -- END
				
				mapAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: <01.04.2022>: Guna Modified for 22x Dev 33479  -- START
				if(SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB) || bManufacturerView || bAllInfoView) {
					mapAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 18, 2021 -- END
				
				mapAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
				
				mapAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				//Added by Subhajit for Req 46464 - Start
				mapAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				//Added by Subhajit for Req 46464 - End
				
				//SPEC: <01.04.2022>: Guna Modified for 22x Dev  -- START
				if(!bManufacturerView) {
				mapAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: <01.04.2022>: Guna Modified for 22x Dev  -- END
				String strBrand = busUtil.getBrandInformationValue(context,sID);
				
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mapAttribResult.put(ConstantsUtil.BRAND, strBrand);
				//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 16, 2021 for Defect#40802 -- START
				mapAttribResult.put(ConstantsUtil.REPLACEDPRODUCTNAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGREPLACEDPRODUCTNAME)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGREPLACEDPRODUCTNAME) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 16, 2021 for Defect#40802 -- END
				mapAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 18, 2021 -- START
				if(!SAPtype.equalsIgnoreCase("HALB")) {
					mapAttribResult.put(ConstantsUtil.CUSTOMIZATIONTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 18, 2021 -- END
				
				mapAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				
				
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 18, 2021 -- START
				if(!SAPtype.equalsIgnoreCase("HALB")) {
					mapAttribResult.put(ConstantsUtil.STATISTICALUNIT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_STATISTICALUNIT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_STATISTICALUNIT) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 18, 2021 -- END
				
				mapAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.strPGPDTTOPGPLIREFUN)))?(String)resultMap.get(ConstantsUtil.strPGPDTTOPGPLIREFUN) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <10.19.2020>: Added for req 18x.5 ## -- START
				//SPEC: <18.08.2022>: Pooja Modified for Defect 50199 22x Release  -- START
				if(bManufacturerView && SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB)){
						mapAttribResult.remove(ConstantsUtil.ORIGINATOR); 
				}
				//SPEC: <18.08.2022>: Pooja Modified for Defect 50199 22x Release  -- END
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 24, 2021 for Defect 41565 -- START
				String pgSAPType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 24, 2021 for Defect 41565 --- END
				
				mapAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REL_OWNINGPRODUCTLINE)))?(String)resultMap.get(ConstantsUtil.SELECT_REL_OWNINGPRODUCTLINE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.STRSEGMENT)))?(String)resultMap.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Added by Amman on Apr 7, 2021 for Defect 42199 , 42193 -- END
				
				//SPEC: Release SR18x.6.0.1 - Added by Amman on June 24, 2021 for Defect 43827 -- START
				if(sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT) && pgSAPType.equalsIgnoreCase("HALB")) {
					mapAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x.6.0.1 - Added by Amman on June 24, 2021 for Defect 43827 -- END
				
				mapAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQ, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 18, 2021 -- START
				if(!SAPtype.equalsIgnoreCase("HALB")) {
					mapAttribResult.put(ConstantsUtil.RETAILERPUBLICATIONREADY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RETAILERPUBLICATIONREADY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RETAILERPUBLICATIONREADY) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 18, 2021 -- END
				
				mapAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: <11.07.2020>: Added for req 18x.5 ## -- START
				mapAttribResult.put(ConstantsUtil.PRIMARYPACKAGINGTYPE,validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.PRIMARY_PACKAGING_TYPE)));
				//SPEC: <11.07.2020>: Added for req 18x.5 ## -- END
				
			//	mapAttribResult.put(ConstantsUtil.PRIMARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SECONDARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
				if(SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB)) {
				mapAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- END
				
				//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- START
				if(!SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB)) {
					StringList supportDocIdtemp = validator.isNotNullOrEmpty((StringList)resultMap.get(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC_ID));		
					String supportDocId = fppBO.checkSupportDocAccess(context,supportDocIdtemp);
					
					mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDVALEXCP)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDVALEXCP) : ConstantsUtil.EMPTY_STRING);
					mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTIONCOMMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDEXCPCMT)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDEXCPCMT) : ConstantsUtil.EMPTY_STRING);
					mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTIONSUPPORTDOC, (validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC))));
					mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTIONSUPPORTDOCTYPE, (validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC_TYPE))));
					mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTIONSUPPORTDOCID, supportDocId);
					}
				//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- END
				/**
				 * LOAD STORAGE AND LABEL SECTION
				 * */
				
				mapStorageAndLabelResult.put(ConstantsUtil.UNNUMBER, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.PROPERSHIPPINGNAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.HAZARDCLASS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.PACKINGGROUP, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP) : ConstantsUtil.EMPTY_STRING);
				
				mapStorageAndLabelResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.UNIQUEFORMULAIDENTIFIER, (validator.isNotNullOrEmpty(fppBO.getUniqueFormulaIdentifierforFPP(context, sContextObjectId))) ? fppBO.getUniqueFormulaIdentifierforFPP(context, sContextObjectId) : ConstantsUtil.EMPTY_STRING);
				
				mapStorageAndLabelResult = busUtil.filterMapList(mapStorageAndLabelResult);
				
				/**
				 * LOAD WAREHOUSE SECTION
				 * */
				mapWarehouseClassResult.put(ConstantsUtil.CORROSIVE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVE) : ConstantsUtil.EMPTY_STRING);
				String sWareHouse = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.RELATIONSHIP_WAREHOUSE_NAME));
				mapWarehouseClassResult.put(ConstantsUtil.WAREHOUSINGCLASSIFICATION, sWareHouse);

				//SPEC: Added for Defect #39454 -- START
				mapWarehouseClassResult = busUtil.filterMapList(mapWarehouseClassResult);
				//SPEC: Added for Defect #39454 -- END
				
				/**
				 * LOAD PART SPECIFICATION SECTION
				 * */
				mapPartSpecification = busUtil.updatePartSpec(context, resultMap);
				
				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				
				String sys = busUtil.getUserType();
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMap);
				swReference.stop();
				LOGGER.info("FPP REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());
				

				/**
				 * LOAD MASTER SPECIFICATION SECTION
				 * */
				StopWatch swMasterSpec = new StopWatch();
				swMasterSpec.start();
				MasterSpecs masterSpec = new MasterSpecs();
				MapList mlMasterSpecs =masterSpec.getMasterSpecifications(context, objId,ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION);
				mpMasterSpecs = fppBO.getFPPMasterSpecifications(context, mlMasterSpecs);
				
				swMasterSpec.stop();
				LOGGER.info("FPP MASTER SPEC ELAPSED TIME : "+swMasterSpec.getTime());

				/**
				 * LOAD DERIVED DATA(RELATED PARTS) SECTION
				 * */
				StopWatch swDerived = new StopWatch();
				swDerived.start();
				IRMSBO irmsbo = new IRMSBO();
				if(bAllInfoView){
					mpDerivedFromResult = irmsbo.updateDerivedDataInfo(context,sName, sRev,sType,sID, sCreatedDate, doFPP,true,false);
					mpDerivedToResult = irmsbo.updateDerivedDataInfo(context,sName, sRev,sType,sID, sCreatedDate, doFPP,false,true);
					
					mpDerivedFromResult = busUtil.filterMapList(mpDerivedFromResult);
					mpDerivedToResult = busUtil.filterMapList(mpDerivedToResult);
				}
				swDerived.stop();
				LOGGER.info("FPP Derived ELAPSED TIME : "+swDerived.getTime());

				/**
				 * Load All Bom Sections
				 */

				int i;
				Map<String, String> mp = null;
				StringList slObjID = new StringList();
				
				Pattern sbBOMTypePattern = new Pattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
				sbBOMTypePattern.addPattern(ConstantsUtil.TYPE_PGINNERPACKUNITPART);
				sbBOMTypePattern.addPattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
				
				StopWatch swFppToAll = new StopWatch();
				swFppToAll.start();
				
				mlEBOMList = doFPP.getRelatedObjects(context,//Context
													ConstantsUtil.RELATIONSHIP_EBOM,//relPattern
													sbBOMTypePattern.getPattern(),//typePattern
													slSelects,//objectSelects
													slRelEBOMSelects,// relationshipSelects
													false,//getTo - Get Parent Data
													true,//getFrom - Get Child Data
													(short) 0,//Expand level to all
													ConstantsUtil.EMPTY_STRING,//objectWhere
													ConstantsUtil.EMPTY_STRING,//relationshipWhere
													0);
				
				swFppToAll.stop();
				//LOGGER.info("FPP CUP BOM ELAPSED TIME : "+swFppToAll.getTime());
				
				//LOGGER.info("Expanding FPP resurse to all " + mlEBOMList);
				
				slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
				slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
				slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
				slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
				slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
				//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- START
				slRelEBOMSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
				if(slRelEBOMSelects.contains(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)) {
					slRelEBOMSelects.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
				}
				slRelEBOMSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				
				MapList mlFinalCup = new MapList();
				MapList mlFinalIp = new MapList();
				MapList mlFinalCop = new MapList();
				
				for(i=0;i<mlEBOMList.size();i++) 
				{
					mp = (Map<String, String>) mlEBOMList.get(i);
					String name = mp.get(ConstantsUtil.SELECT_NAME).toString();
					String type = mp.get(ConstantsUtil.SELECT_TYPE).toString();
					String strOid = mp.get(ConstantsUtil.SELECT_ID);
					String rev = mp.get(ConstantsUtil.SELECT_REVISION);
					
					
					if(type.equalsIgnoreCase(ConstantsUtil.TYPE_PGCUSTOMERUNITPART) && !slObjID.contains(strOid))
					{
					//SPEC: Release SR18x.6.0.1 - Added for Defect #43151 #43249 #43260 #35345 by Madhan on Date June/04/2021 -- END
						slObjID.add(strOid);
						if (!strOid.isEmpty()) 
						{
							DomainObject doCup = DomainObject.newInstance(context, strOid);
							
							//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- END
							StopWatch swCup = new StopWatch();
							swCup.start();
							
							MapList mlCup = doCup.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slSelects,
									slRelEBOMSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
							swCup.stop();
							//LOGGER.info("FPP CUP BOM ELAPSED TIME : "+swCup.getTime());
							mlCup.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING,
									ConstantsUtil.INTEGER);
							Map<String, String> mCup = null;
							for(int j=0; j < mlCup.size();j++) {
								mCup = (Map<String, String>) mlCup.get(j);
								mCup.put(ConstantsUtilIRM.PARENT_NAME, name);
								mCup.put(ConstantsUtilIRM.PARENT_ID, strOid);
								mCup.put(ConstantsUtilIRM.PARENT_REVISION, rev);
								mCup.put(ConstantsUtilIRM.PARENT_TYPE, type);
								mlFinalCup.add(mCup);
							}
						}
					} 
					//END of CUP Block
					else if((type.equalsIgnoreCase(ConstantsUtil.TYPE_PGINNERPACKUNITPART) || type.equalsIgnoreCase(ConstantsUtil.INNERPACKUNITPAT)) && !slObjID.contains(strOid)) {
						//SPEC: Release SR18x.6.0.1 - Added for Defect #43151 #43249 #43260 #35345 by Madhan on Date June/04/2021 -- END
						slObjID.add(strOid);
						if (!strOid.isEmpty()) 
						{
							DomainObject doIp = DomainObject.newInstance(context, strOid);
							
							StopWatch swIp = new StopWatch();
							swIp.start();
							
							MapList mlIp = doIp.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slSelects,
									slRelEBOMSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
							swIp.stop();
							//LOGGER.info("FPP CUP BOM ELAPSED TIME : "+swIp.getTime());
							mlIp.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING,
									ConstantsUtil.INTEGER);
							Map<String, String> mIp = null;
							for(int j=0; j < mlIp.size();j++) {
								mIp = (Map<String, String>) mlIp.get(j);
								mIp.put(ConstantsUtilIRM.PARENT_NAME, name);
								mIp.put(ConstantsUtilIRM.PARENT_ID, strOid);
								mIp.put(ConstantsUtilIRM.PARENT_REVISION, rev);
								mIp.put(ConstantsUtilIRM.PARENT_TYPE, type);
								mlFinalIp.add(mIp);
							}
						}
					}
					//End of IP block
					else if((type.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNITPART) || type.equalsIgnoreCase(ConstantsUtil.TYPE_CUSTOMERUNITPART)) && !slObjID.contains(strOid)) {
						//SPEC: Release SR18x.6.0.1 - Added for Defect #43151 #43249 #43260 #35345 by Madhan on Date June/04/2021 -- END
						slObjID.add(strOid);
						if (!strOid.isEmpty()) 
						{
							DomainObject doCop = DomainObject.newInstance(context, strOid);
							
							StopWatch swCOPBom = new StopWatch();
							swCOPBom.start();
							
							MapList mlCop = doCop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slSelects,
									slRelEBOMSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
							swCOPBom.stop();
							//LOGGER.info("FPP CUP BOM ELAPSED TIME : "+swCOPBom.getTime());
							mlCop.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING,
									ConstantsUtil.INTEGER);
							
							Map<String, String> mCop = null;
							for(int j=0; j < mlCop.size();j++) {
								mCop = (Map<String, String>) mlCop.get(j);
								mCop.put(ConstantsUtilIRM.PARENT_NAME, name);
								mCop.put(ConstantsUtilIRM.PARENT_ID, strOid);
								mCop.put(ConstantsUtilIRM.PARENT_REVISION, rev);
								mCop.put(ConstantsUtilIRM.PARENT_TYPE, type);
								mlFinalCop.add(mCop);
							}
						}
					}
				

					//COP-BOM

					if(name.contains(ConstantsUtil.CUP) || name.contains(ConstantsUtil.COP) || type.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
						continue;
					}
				}
				
				if(mlFinalCup.size()!=0)
				{
					/**
					 * Get CUP BOM
					 */
					//Map mpBomCupRslt =	fppBO.parseMaplist(context,mlFinalCup);
					Map mpBomCupRslt =	fppBO.parseMaplist(context,mlFinalCup, true);
					mpBomCupResult.putAll(mpBomCupRslt);
					//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- END
					
					/**
					 * Get CUP Substitute 
					 */
					//mpBomSubstituteResult = busUtil.getCOPCUPIPSubstitutes(context, mlCup);
					Map mpBomSubstituteRslt =  commonBO.parseSubstitute(context,mlFinalCup);
					mpBomSubstituteResult.putAll(mpBomSubstituteRslt);
				}
				
				if(mlFinalIp.size()!=0)
				{
					/**
					 * Get IP BOM
					 */
					//Map mpBomIpRslt =	fppBO.parseMaplist(context,mlFinalIp);
					Map mpBomIpRslt =	fppBO.parseMaplist(context,mlFinalIp, true);
					mpBomIpResult.putAll(mpBomIpRslt);
					//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- END
					
					/**
					 * Get IP Substitute 
					 */
					Map mpBomIpSubstituteRslt = commonBO.parseSubstitute(context, mlFinalIp);
					mpBomIpSubstituteResult.putAll(mpBomIpSubstituteRslt);
					
				}
				
				if(mlFinalCop.size()!=0)
				{
					/**
					 * Get COP BOM
					 */
					//Map mpBomCopRslt =	fppBO.parseBomCopMaplist(context,mlFinalCop);
					Map mpBomCopRslt =	fppBO.parseBomCopMaplist(context,mlFinalCop, true);
					mpBomCopResult.putAll(mpBomCopRslt);
					//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- END
					
					/**
					 * Get COP Substitute 
					 */
					Map mpBomCopSubstituteRslt = commonBO.parseSubstitute(context, mlFinalCop);
					mpBomCopSubstituteResult.putAll(mpBomCopSubstituteRslt);
				}

				//Transport Unit
				StopWatch swTup = new StopWatch();
				swTup.start();
				if(sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT))
				{
					//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 24, 2021 for Defect #43804 -- START
					if(bAllInfoView) {
						mapTransportUnitResult= fppBO.UpdateTransportChar(context, resultMap);
					}
					
					if(bManufacturerView) {
						mapTransportUnitResult= fppBO.getTransportUnitDetails(context, resultMap);
					}
					//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 24, 2021 for Defect #43804 -- END
				} else {
					//mapTransportUnitResult = fppBO.parseTransMaplist(mlTUPFromFPP);
					
					mapTransportUnitResult  =fppBO.parseTransMaplist(context, mlTUPFromFPP,sID,sType,sName,mpGTIN);
				}
				swTup.stop();
				LOGGER.info("FPP TUP ELAPSED TIME : "+swTup.getTime());

				/**
				 * Load Performance CHaracteristic Section
				 */
				Map paramMap = new HashMap();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				PefromChar perform = new PefromChar();

				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				//SPEC: <12.11.2021>: Guna Added for  Defect 45692 18x.6.0.2   -- START
				if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_PGFINISHEDPRODUCT)) {
					mlPerformChar =fppBO.getExcludedSharedTable(context, mlPerformChar);
				}
				//SPEC: <12.11.2021>: Guna Added for  Defect 45692 18x.6.0.2   -- END
				int jj = mlPerformChar.size();
				if(!mlPerformChar.isEmpty())
				{
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					//SPEC: Release SR18x.5.2 - Added for Defect# 40011  by gaikwad.tg on Date 19 Feb 2021 -- START
					//SPEC: Release SR18x.6.0 - Added/Modified  by Sumit on Date 15 March 2021 -- START
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
						//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
						//mpPerformChar =busUtil.updatePerformCharcteristic(context,mlPerformAttrib,resultMap);
						mpPerformChar =busUtil.updatePerformCharcteristic(context,mlPerformAttrib,resultMap,objId);
						//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
						
					} else {
					FormulaCardBO fcBO = new FormulaCardBO();
					mpPerformChar =  fcBO.updatePerformCharcteristic(context,mlPerformAttrib,resultMap);
					}
					//SPEC: Release SR18x.6.0 - Added/Modified  by Sumit on Date 15 March 2021 -- START
					//SPEC: Release SR18x.5.2 - Added for Defect# 40011  by gaikwad.tg on Date 19 Feb 2021 -- END
				}
				//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- START
				mpPerformChar.remove(ConstantsUtil.CPS);
				mpPerformChar.remove(ConstantsUtil.CPSNAME);
				mpPerformChar.remove(ConstantsUtil.CPSID);
				//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- END
				swPerfChar.stop();
				LOGGER.info("FPP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());


				/**
				 * LOAD DANGEROUS GOODS CLASSIFICATION SECTION
				 * */

				//SPEC: <10.19.2020>: Modified for req 18x.5 ## -- START
				//mpDangerousGoodsClf=busUtil.getDangerousProdcutValue(context,resultMap);
				
				//SPEC: Release SR18x.6.0 - Added by Amman on Apr 9, 2021 for Defect 42253 -- START
				//mpDangerousGoodsClf=fppBO.getDangerousProdcutValue(context,resultMap);
				mpDangerousGoodsClf=fppBO.getDangerousGoodsClassification(context,resultMap);
				//SPEC: Release SR18x.6.0 - Added by Amman on Apr 9, 2021 for Defect 42253 -- END
				
				//SPEC: <10.19.2020>: Modified for req 18x.5 ## -- END
				
				if(bManufacturerView) {
					mpDangerousGoodsClf=busUtil.filterPhase(mpDangerousGoodsClf);
				}
				
				/**
				 * LOAD GLOBAL HARMONIZED STANDARD SECTION
				 * */
				
				mpGlobalHarStandard = busUtil.getGHSProdcutValue(context,resultMap);

				if(bManufacturerView) {
					mpGlobalHarStandard=busUtil.filterPhase(mpGlobalHarStandard);
				}


				/**
				 * Load Unique Formula Section
				 */
				mpUniqFormulaIdentifier.put(ConstantsUtil.UNIQUE_FORMULA_IDENTIFIER, (validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER))));
				mpUniqFormulaIdentifier.put(ConstantsUtil.UNIQUE_FORMULA_IDENTIFIER_OBJECT, (validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER))));
				mpUniqFormulaIdentifier = busUtil.filterMapList(mpUniqFormulaIdentifier);
				
				/**
				 * LOAD NOTES SECTION
				 * */
				mpNotes=mcop.updateNotes(context, resultMap);
				
				/**
				 * LOAD STABILITY SECTION
				 * */
				
				mpStability = fppBO.getStabilityDoc(context,resultMap);

				/**
				 * LOAD CERTIFICATIONS SECTION
				 * */
				
				
				//SPEC: <11.18.2020>: Added for Defect:37341  ## -- START
				MapList mlCertifications = busUtil.getRequiredData(context, objId, ConstantsUtil.TYPE_PGPLIMATERIALCERTIFICATIONS,ConstantsUtil.RELATIONSHIP_PGROLLEDUPMATERIALCERTIFICATION);
				mapCertifications=fppBO.getCerifications(context,mlCertifications);
				//SPEC: <11.18.2020>: Added for Defect:37341  ## -- END
				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=busUtil.getRelatedAts(context, doFPP);
				
				mpRelatedATS=busUtil.filterMapList(mpRelatedATS);
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- START
				//SPEC: <26.05.2022>: Guna Modified for Req 43515 22x Release  -- START
				String sHasATSAttrVal = busUtil.checkHasATSForSIS(context,resultMap);
				mpHeaderResult.put(ConstantsUtil.HASATS, sHasATSAttrVal);
				String sHasATSBOM = fppBO.getATSFromBOM(context,doFPP);
				mpHeaderResult.put(ConstantsUtilIRM.HASATSBOM, sHasATSBOM);	
				//SPEC: <26.05.2022>: Guna Modified for Req 43515 22x Release  -- END
				
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- END
				
				if(bManufacturerView) {
					mpRelatedATS=busUtil.filterPhase(mpRelatedATS);
				}
				
				swAts.stop();
				LOGGER.info("FPP ATS ELAPSED TIME : "+swAts.getTime());
				
				//SPEC: <02.24.2021>: Added for req 18x.6 by Sumit ## -- START
				/**
				 * LOAD SMART LABEL ROLLUP
				 * */
				StopWatch swSmart = new StopWatch();
				swSmart.start();
				mpSmartLabel=fppBO.getSmartLabelRollUp(context, doFPP);
				mpSmartLabel=busUtil.filterMapList(mpSmartLabel);
				swSmart.stop();
				LOGGER.info("FPP SMART LABEL ROLLUP ELAPSED TIME : "+swSmart.getTime());
				
				
				if(bAllInfoView) {
					/**
					 * LOAD INGREDIENT STATEMENT
					 * */
					StopWatch swIS = new StopWatch();
					swIS.start();
					mpRelatedIngredient=fppBO.getRelatedIngredient(context, doFPP);
					mpRelatedIngredient=busUtil.filterMapList(mpRelatedIngredient);
					swIS.stop();
					LOGGER.info("FPP INGREDIENT STATEMENT ELAPSED TIME : "+swIS.getTime());
				}
				
				/**
				 * LOAD BATTERY ROLLUP
				 * */
				StopWatch swBatteryRU = new StopWatch();
				swBatteryRU.start();
				mpBatteryRollUp=fppBO.getBatteryRollUp(context, doFPP);
				mpBatteryRollUp=busUtil.filterMapList(mpBatteryRollUp);
				swBatteryRU.stop();
				LOGGER.info("FPP BATTERY ROLLUP ELAPSED TIME : "+swBatteryRU.getTime());
				
				/**
				 * LOAD BATTERY CALCULATION
				 * */
				StopWatch swBatteryCalc = new StopWatch();
				swBatteryCalc.start();
				
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 14, 2021 -- START
				//mpBatteryCalc.put(ConstantsUtilIRM.AREBATTERIESINCLUDED, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGAREBATTERIESINCLUDED)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGAREBATTERIESINCLUDED) : ConstantsUtil.EMPTY_STRING);
				mpBatteryCalc.put(ConstantsUtilIRM.AREBATTERIESINCLUDED, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_AREBATTERIESINCLUDED)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_AREBATTERIESINCLUDED) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Modified by Amman on Mar 14, 2021 -- END
				
				mpBatteryCalc.put(ConstantsUtil.AREBATTERIESREQUIRED, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAREBATTERIESREQUIRED)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAREBATTERIESREQUIRED) : ConstantsUtil.EMPTY_STRING);
				mpBatteryCalc.put(ConstantsUtilIRM.AREBATTERIESBUILTIN, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGAREBATTERIESBUILTIN)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGAREBATTERIESBUILTIN) : ConstantsUtil.EMPTY_STRING);
				mpBatteryCalc=busUtil.filterMapList(mpBatteryCalc);
				swBatteryCalc.stop();
				LOGGER.info("FPP BATTERY CALCULATION ELAPSED TIME : "+swBatteryCalc.getTime());
				
				/**
				 * LOAD CUP ARTWORK
				 * */
				StopWatch swcupArt = new StopWatch();
				swcupArt.start();
				mpCUPArtwork=fppBO.getCUPArtworkObjects(context, doFPP);
				mpCUPArtwork=busUtil.filterMapList(mpCUPArtwork);
				swcupArt.stop();
				LOGGER.info("FPP CUP ARTWORK ELAPSED TIME : "+swcupArt.getTime());
				
				/**
				 * LOAD REGISTRATION DETAILS
				 * */
				StopWatch swRegD = new StopWatch();
				swRegD.start();
				CommonBusUtilBO commonBo = new CommonBusUtilBO();
				mpRegistrationDetails=commonBo.getRegistrationDetails(context, objId);
				mpRegistrationDetails=busUtil.filterMapList(mpRegistrationDetails);
				swRegD.stop();
				LOGGER.info("FPP REGISTRATION DETAILS ELAPSED TIME : "+swRegD.getTime());
				//SPEC: <02.24.2021>: Added for req 18x.6 by Sumit ## -- END
			}
			//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
			if(bAllInfoView || bManufacturerView) {
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- END
				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
				if( bManufacturerView) {
					//SPEC: <02.24.2021>: Added for req 18x.6 ## -- END

					mapAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
					mapAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);

					// Modified by Jwala for the defect 44013 -- START 
					//mapAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM) : ConstantsUtil.EMPTY_STRING);
					mapAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REL_OWNINGPRODUCTLINE)))?(String)resultMap.get(ConstantsUtil.SELECT_REL_OWNINGPRODUCTLINE) : ConstantsUtil.EMPTY_STRING);
					// Modified by Jwala for the defect 44013 -- END

					//SPEC: <11.07.2020>: Added for req 18x.5 ## -- START
					mapAttribResult.put(ConstantsUtil.PRIMARYPACKAGINGTYPE,validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.PRIMARY_PACKAGING_TYPE)));
					//SPEC: <11.07.2020>: Added for req 18x.5 ## -- END
					//	mapAttribResult.put(ConstantsUtil.PRIMARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
					mapAttribResult.put(ConstantsUtil.SECONDARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
					mapAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
					mapAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);

					//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
				}
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- END

				//Added by Jwala for the requirement 38899 - START
				if(!(ConstantsUtilIRM.FPP_CSSTYPE).equalsIgnoreCase(sType)) {
					mpBaseCodeDetails  = fppBO.getBaseCodeDetails(context,sID);

					if(mpBaseCodeDetails!=null && mpBaseCodeDetails.containsKey(ConstantsUtil.ID)) 
					{
						String baseCodeID = mpBaseCodeDetails.get(ConstantsUtil.ID);
						String baseCodeName = mpBaseCodeDetails.get(ConstantsUtil.NAME);
						String baseCodeType = mpBaseCodeDetails.get(ConstantsUtil.TYPE);
						String baseCodeState = mpBaseCodeDetails.get(ConstantsUtil.STATE);
						String baseCodeIDs = mpBaseCodeDetails.get(ConstantsUtil.STRING_OBJECTID);

						/**
						 * LOAD BASE-CODE DETAILS SECTION
						 */
						StopWatch bcReference= new StopWatch();
						bcReference.start();
						mpBaseCodeDetailsUpdate  = fppBO.getBaseCodeDetails(context, baseCodeID, baseCodeType, baseCodeName, sType, baseCodeIDs, env);
						bcReference.stop();
						LOGGER.info("FPP BASE-CODE DETAILS ELAPSED TIME : "+bcReference.getTime());

						/**
						 * LOAD SUBSTITUTE BASE-CODE DETAILS SECTION
						 */
						StopWatch sbcReference= new StopWatch();
						sbcReference.start();
						mpSubstituteBaseCodeDetails =  fppBO.getSubstituteBaseCodeDetails(context,baseCodeID,baseCodeName,baseCodeType,baseCodeState);
						sbcReference.stop();
						LOGGER.info("FPP SUBSTITUTE BASE-CODE DETAILS ELAPSED TIME : "+sbcReference.getTime());
					}
				}
			}
			
			//SPEC: <12.02.2020>: Modified for req 18x.5 by Amman ## -- START
			if(bAllInfoView || bManufacturerView) {
			//SPEC: <12.02.2020>: Modified for req 18x.5 by Amman ## -- END
				
				/**
				 * LOAD ORGANIZATION DATA SECTION
				 * */
				//SPEC: <07-28-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
				//mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				//mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				if (resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {
				
					if (resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} 
					else 
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
				}
				
				if (resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {
				
					if (resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
					{
						mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
					} else 
					{
						mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					}
				}
				//SPEC: <07-28-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
				
					mpOrganization = busUtil.filterMapList(mpOrganization);

				/**
				 * LOAD MARKETS OF SALE SECTION
				 * */
				
				
				String strCosDateAndTime = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE));
				FabricatedPartBO FABBO = new FabricatedPartBO();
				mapCosResult = FABBO.getMarketOfSale(context,sContextObjectId);
				mapCosResult.put(ConstantsUtil.DATEANDTIMEOFLASTMOSCALC, strCosDateAndTime);
				
				mapCosResult = busUtil.filterMapList(mapCosResult);
				
				
			
				//SPEC: <12.02.2020>: Modified for req 18x.5 by Amman ## -- START
				if(bAllInfoView) {
					/**
					 * LOAD PLANTS SECTION
					 * */
					mapPlantResult = busUtil.updatePlantInfo(resultMap);
				}
				//SPEC: <12.02.2020>: Modified for req 18x.5 by Amman ## -- END
				
				/**
				 * LOAD WND SECTION
				 * */
				mapWnDResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
				mapWnDResult.put(ConstantsUtil.UNITOFMEASURESYSTEM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM) : ConstantsUtil.EMPTY_STRING);
				mapWnDResult = busUtil.filterMapList(mapWnDResult);

				//SPEC: <12.02.2020>: Modified for req 18x.5 by Amman ## -- START
				if(bAllInfoView) {
					/**
					 * LOAD OWNERSHIP SECTION
					 * */
					//SPEC: <08-11-2021>: Manikanta Modified in SR18x.6.0.2 for  Defect 45644  -- START
					//mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
					String sOriginator = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ORIGINATOR))?(String)resultMap.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING;
					String strOriginatorName = busUtil.getUserName(context, sOriginator,ldapuser,ldappwd);
					mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, strOriginatorName);
					//SPEC: <08-11-2021>: Manikanta Modified in SR18x.6.0.2 for  Defect 45644  -- END
					//SPEC: <01.04.2022>: Guna Modified for 22x Dev  -- START
					mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.STRSEGMENT)))?(String)resultMap.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
					//SPEC: <01.04.2022>: Guna Modified for 22x Dev  -- END
					//SPEC: Release SR18x.6.0 - Added by Amman on Mar 24, 2021 for Defect 41565 --- END
					
					mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult = busUtil.filterMapList(mapOwnerShipResult);
				}
				//SPEC: <12.02.2020>: Modified for req 18x.5 by Amman ## -- END
				
				/**
				 * LOAD SECURITY SECTION
				 * */
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO bo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =bo.updateSecurity(context,resultMap);
				swSecurity.stop();
				LOGGER.info("FPP Security ELAPSED TIME : "+swSecurity.getTime());
				//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- START
				if (mpSecurity.containsKey(ConstantsUtil.HASCLASSACCESS)) {
					mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				}
				//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- END
			}
			
			//SPEC: <07.06.2022>: Guna Added for req 41754 22x Release  -- START
			/**
			 * LOAD PACKAGING CERTIFICATIONS
			 * */
			
			StopWatch swPkgCert = new StopWatch();
			swPkgCert.start();
			mpPackCert =fppBO.getPackagingCertData(context,objId,sName,sType,sUserType);
			swPkgCert.stop();
			LOGGER.info("FPP PACKAGING CERTIFICATIONS ELAPSED TIME : "+swPkgCert.getTime());
			//SPEC: <07.06.2022>: Guna Added for req 41754 22x Release  -- END
			
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			
			//SPEC: Added by Ajay for Req. no. 86912 START
			/**
			 * LOCAL PRODUCT NAME SECTION
			 */
			StopWatch swLPName = new StopWatch();
			swLPName.start();
			mpLocalProductName = fppBO.getLocalProductName(context, objId);
			swLPName.stop();
			
			LOGGER.info("FPP LOCAL PRODUCT NAME ELAPSED TIME : " + swLPName.getTime());
			
			
			
			//For Consolidate Packing View below columns has to remove as per the template
			if(bManufacturerView) 
			{
				hmAttrib.put(ConstantsUtil.TRANSPORTUNIT, mapTransportUnitResult);
				if(!sComp.equalsIgnoreCase(ConstantsUtilIRM.FPP_COMPARE) && !sComp.equalsIgnoreCase(ConstantsUtilIRM.COMPARE)){
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mapBomResult);
				}
				//SPEC: <12.30.2020>: Commented for Req :36032 by Sumit #(BOM Expansion)# --START
				//hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
				//SPEC: <12.30.2020>: Commented for Req :36032 by Sumit #(BOM Expansion)# --ENDS
			}

			if(bAllInfoView) 
			{
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERCUSTOMERUNIT, mpBomMcupResult);
				hmAttrib.put(ConstantsUtil.SUBSTITUTESMASTERCUSTOMERUNIT, mpMcupSubstituteResult);
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERINNERPACK, mpEBOMMasterInnerPack);
				hmAttrib.put(ConstantsUtil.SUBSTITUTESMASTERINNERPACK, mpMIPackSubstituteResult);
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERCONSUMERUNIT, mpBomMcopResult);
				hmAttrib.put(ConstantsUtil.SUBSTITUTESMASTERCONSUMERUNIT, mpMcopSubstituteResult);
				hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
				if(!sComp.equalsIgnoreCase(ConstantsUtilIRM.FPP_COMPARE) && !sComp.equalsIgnoreCase(ConstantsUtilIRM.COMPARE)){
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mapBomResult);
				}
				//SPEC: <12.30.2020>: Commented for Req :36032 by Sumit #(BOM Expansion)# --START
				//hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
				//SPEC: <12.30.2020>: Commented for Req :36032 by Sumit #(BOM Expansion)# --ENDS
				hmAttrib.put(ConstantsUtil.TRANSPORTUNIT, mapTransportUnitResult);
			}
			
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALSCUSTOMERUNIT, mpBomCupResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTESCUSTOMERUNIT, mpBomSubstituteResult);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALSINNERPACK, mpBomIpResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTESINNERPACK, mpBomIpSubstituteResult);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALSCONSUMERUNIT, mpBomCopResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTESCONSUMERUNIT, mpBomCopSubstituteResult);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALSTRANSPORTUNIT, mapTupBomResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTESTRANSPORTUNIT, mpTUPSubstituteResult);
			hmAttrib.put(ConstantsUtil.SAPBOMASFED, mapSapBomAsFedResult);
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mapAttribResult);
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			//SPEC: <04.04.2022>: Guna Modified for 22x Dev  -- START
			if(!bManufacturerView){
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: <04.04.2022>: Guna Modified for 22x Dev  -- END
			hmAttrib.put(ConstantsUtil.DANGEROUSGOODCLASSIFICATION, mpDangerousGoodsClf);

			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- START
			String SAPType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
			if(!SAPType.equalsIgnoreCase("HALB")) {
				hmAttrib.put(ConstantsUtil.GLABALHARMONIZEDSTANDARD, mpGlobalHarStandard);
			}
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- END
			
			hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATAOBJECT, mapStorageAndLabelResult);
			
			//SPEC: <10.19.2020>: Commented for req 18x.5 ## -- START
			//hmAttrib.put(ConstantsUtil.UNIQUEFORMULAIDENTIFIER, mpUniqFormulaIdentifier);
			//SPEC: <10.19.2020>: Commented for req 18x.5 ## -- END
			
			hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			hmAttrib.put(ConstantsUtil.STABILITYRESULTS, mpStability);
			hmAttrib.put(ConstantsUtil.WAREHOUSECLASSIFICATION, mapWarehouseClassResult);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- START
			if(!SAPType.equalsIgnoreCase("HALB")) {
				hmAttrib.put(ConstantsUtil.MARKETOFSALE, mapCosResult);
			}
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- END
			
			hmAttrib.put(ConstantsUtil.CERTIFICATIONS, mapCertifications);
			
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- START
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.PLANTS, mapPlantResult);
			}
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- END
			
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			
			
			
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- START
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.OWNERSHIPOBJECT, mapOwnerShipResult);
			}
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- END
			//SPEC: <04.04.2022>: Guna Modified for 22x Dev  -- START
			if(!bManufacturerView){
			hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			}
			//SPEC: <04.04.2022>: Guna Modified for 22x Dev  -- END
			hmAttrib.put(ConstantsUtil.WEIGHTSDIMENSIONSOBJECT, mapWnDResult);
			hmAttrib.put(ConstantsUtil.PACKINGUNIT, mapPackagingUnitResult);
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mapPartSpecification);
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			hmAttrib.put(ConstantsUtilIRM.PGLPN,mpLocalProductName);
			//SPEC: <10.19.2020>: Added for req 18x.5 ## -- START
			//SPEC: <04.04.2022>: Guna Modified for 22x Dev  -- START
			if(!bManufacturerView){
			hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
			}
			//SPEC: <04.04.2022>: Guna Modified for 22x Dev  -- END
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.FILES, mpFiles);	
				//SPEC: <02.24.2021>: Added for req 18x.6 by Sumit ## -- START
				if(!SAPType.equalsIgnoreCase("HALB")) {
					hmAttrib.put(ConstantsUtilIRM.SMARTLABELROLLUPDATA, mpSmartLabel);
				}
				hmAttrib.put(ConstantsUtilIRM.INGREDIENTSTMT, mpRelatedIngredient);
				hmAttrib.put(ConstantsUtilIRM.BATTERYROLLUP, mpBatteryRollUp);
				hmAttrib.put(ConstantsUtilIRM.BATTERYCALCOBJECTDATA, mpBatteryCalc);
				hmAttrib.put(ConstantsUtilIRM.CUPARTWORK, mpCUPArtwork);
				if(!SAPType.equalsIgnoreCase("HALB")) {
					hmAttrib.put(ConstantsUtilIRM.REGISTRATIONDETAILS, mpRegistrationDetails);
				}
				//SPEC: <02.24.2021>: Added for req 18x.6 by Sumit ## -- END
			}
			//SPEC: <10.19.2020>: Added for req 18x.5 ## -- END
			
			//SPEC: <02.24.2021>: Modified for req 18x.6 ## -- START
			if(bAllInfoView || bManufacturerView) {
				if(!(ConstantsUtilIRM.FPP_CSSTYPE).equalsIgnoreCase(sType)) {
					hmAttrib.put(ConstantsUtil.BASECODEDETAILS, mpBaseCodeDetailsUpdate);
					hmAttrib.put(ConstantsUtil.SUBSTITUTEBASECODEDETAILS, mpSubstituteBaseCodeDetails);
				}
			}
			
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- START
			if(bManufacturerView) {
				hmAttrib.put(ConstantsUtilIRM.BATTERYROLLUP, mpBatteryRollUp);
				hmAttrib.put(ConstantsUtilIRM.BATTERYCALCOBJECTDATA, mpBatteryCalc);
				hmAttrib.put(ConstantsUtilIRM.CUPARTWORK, mpCUPArtwork);
				
				if(!SAPType.equalsIgnoreCase("HALB")) {
					hmAttrib.put(ConstantsUtilIRM.SMARTLABELROLLUPDATA, mpSmartLabel);
					hmAttrib.put(ConstantsUtilIRM.REGISTRATIONDETAILS, mpRegistrationDetails);
				}
			}
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 11, 2021 -- END
			//SPEC: <07.06.2022>: Guna Added for req 41754 22x Release  -- START
            if(bAllInfoView || (SAPType.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB) && !bManufacturerView) || (!SAPType.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB) && bManufacturerView)) {
            	hmAttrib.put(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS, mpPackCert);	
			}
          //SPEC: <07.06.2022>: Guna Added for req 41754 22x Release  -- END
			ContextUtil.abortTransaction(context);
			pool.checkIn(context);
			sp.stop();
			LOGGER.info("FPP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "FPP OBJECT NAME::"+resultMap.get(ConstantsUtil.SELECT_NAME));
			
		} catch (IOException e) {
			LOGGER.error("IOException from FPP "+e);
		} catch (MatrixException e) {
			LOGGER.error("MatrixException from FPP "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		//LOGGER.info("FPP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		if(sComp.equals(ConstantsUtilIRM.FPP)) {
			context.close();
		}
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		
		return hmAttrib;
	}
	
}
