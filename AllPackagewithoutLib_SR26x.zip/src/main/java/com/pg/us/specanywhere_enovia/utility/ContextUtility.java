/*package com.pg.us.specanywhere_enovia.utility;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.util.ContextUtil;

import matrix.db.Context;
import matrix.util.MatrixException;

public class ContextUtility {

	private static String VAULT = "eService Production";
	public static Context context;
	private static Logger LOGGER = Logger.getLogger(ContextUtility.class);
	
	public static Context getEnoviaContext() throws IOException, MatrixException {
		try {
			context = new Context("");
			context.setUser(USER);
			context.setPassword(PASS);
			context.setVault(VAULT);
			context.connect();
			return context;

		} catch (MatrixException ex) {
			LOGGER.info("Unable to retrieve EnoviaContext ");
			throw ex;
		}
	}

	public static Context getApplicationUserEnoviaContext(String sApplicationUser, String sApplicationUserPass)
			throws Exception {

		Context context = null;
		try {
			String sUser = sApplicationUser;
			context = ContextUtility.getEnoviaContext();
			ContextUtil.pushContext(context, sUser, null, null);

		} catch (Exception e) {
			LOGGER.info("Unable to retrieve ApplicationUserEnoviaContext ");
			throw e;
		}
		return context;
	}
}
*/