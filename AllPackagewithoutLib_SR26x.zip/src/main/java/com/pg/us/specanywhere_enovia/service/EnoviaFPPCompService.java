package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaFPPCompService {
	public HashMap<String, HashMap<String, Map<String, String>>> getFPPPartCompData(String sObjectId, Environment env);

}
