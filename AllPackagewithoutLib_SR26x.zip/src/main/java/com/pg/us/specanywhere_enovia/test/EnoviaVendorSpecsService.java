package com.pg.us.specanywhere_enovia.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaVendorSpecsService {

	private static String USER;
	private static String PASS;
	private static String VAULT;
	private static Logger LOGGER = Logger.getLogger(EnoviaVendorSpecsService.class);
	
	public static void main(String[] args) throws Exception {
		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		String sCompany="20336.41905.20384.51593";
		String sView="Pending";
		try {
			StopWatch swContext = new StopWatch();
			swContext.start();
			EnoviaConnectionPool pool = new EnoviaConnectionPool();
			Context context = pool.checkOut();
			swContext.stop();
			LOGGER.info("VENDOR SPECS SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());

			/*SecurityService sct = new SecurityService();
			boolean isExternalUser = sct.isExternalUser();*/
			boolean isExternalUser = true;
			HashMap<String, Map<String, String>> hmVendorSpecs = new HashMap<String, Map<String, String>>();
			if(isExternalUser) {
				 
				StringList slObjectSelects = new StringList();
				slObjectSelects.add(ConstantsUtil.SELECT_ID);
				StringList slPartSelects = new StringList();
				slPartSelects.add(ConstantsUtil.SELECT_NAME);
				slPartSelects.add(ConstantsUtil.SELECT_ID);
				slPartSelects.add(ConstantsUtil.SELECT_TYPE);
				slPartSelects.add(ConstantsUtil.SELECT_POLICY);
				slPartSelects.add(ConstantsUtil.SELECT_REVISION);
				slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP);
				slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION);
				slPartSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
				BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
				
				String sWhereClause=null;
				if(!sView.equalsIgnoreCase(ConstantsUtil.SPECIFICATION) && !sView.equalsIgnoreCase(ConstantsUtil.ARCHIVED)) {
					sWhereClause = "current=="+sView;
				}
				
				DomainObject doObj = new DomainObject(sCompany);
				StopWatch swSummary = new StopWatch();
				swSummary.start();
				MapList mapList = doObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGPLANTORSUPPLIERTOSUMMARY,
						ConstantsUtil.TYPE_PGEBPSUMMARY, slObjectSelects, null, false, true, (short) 1,
						sWhereClause, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				swSummary.stop();
				LOGGER.info("VENDOR SPECS SUMMARY COUNT FOR VIEW = "+sView+" : "+mapList.size());
				LOGGER.info("VENDOR SPECS GET SUMMARY  ELAPSED TIME : "+swSummary.getTime());
				
				StringBuilder sbName = new StringBuilder();
				StringBuilder sbType = new StringBuilder();
				StringBuilder sbRev = new StringBuilder();
				StringBuilder sbSubType = new StringBuilder();
				StringBuilder sbRelDate = new StringBuilder();
				StringBuilder sbId = new StringBuilder();
				StringBuilder sbSapDesc = new StringBuilder();
				
				if(!sView.equalsIgnoreCase(ConstantsUtil.ARCHIVED)) {
					sWhereClause = "current!=Obsolete";
				}else{
					sWhereClause = "current==Obsolete";
				}
				
				StopWatch swSpecs = new StopWatch();
				swSpecs.start();
				for(int i=0;i<mapList.size();i++) {
					Map mpSummary = (Map) mapList.get(i);
					String sOid = (String) mpSummary.get(ConstantsUtil.SELECT_ID);
					
					DomainObject doSummary = new DomainObject(sOid);
					MapList mlPart = doSummary.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA,
							ConstantsUtil.SYMBL_ASTERISK, slPartSelects, null, false, true, (short) 1,
							sWhereClause, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
					//System.out.println("mlPart=========>"+mlPart.size());
					if (mlPart.size() > 0) {
						Map mpPart = (Map) mlPart.get(0);
						formatData(sbName,(String)mpPart.get(ConstantsUtil.SELECT_NAME));
						String sType = (String)mpPart.get(ConstantsUtil.SELECT_TYPE);
						sType=busUtil.mapType(sType);
						formatData(sbType, sType);
						formatData(sbRev, (String)mpPart.get(ConstantsUtil.SELECT_REVISION));
						formatData(sbSubType, (String)mpPart.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP));
						formatData(sbSapDesc, (String)mpPart.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION));
						formatData(sbRelDate, (String)mpPart.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
						formatData(sbId, (String)mpPart.get(ConstantsUtil.SELECT_ID));
					}
				}
				swSpecs.stop();
				LOGGER.info("VENDOR SPECS GET SPECS  ELAPSED TIME : "+swSpecs.getTime());
				
				Map<String, String> mpPartTemp = new HashMap<String, String>();
				mpPartTemp.put(ConstantsUtil.NAME, sbName.toString());
				mpPartTemp.put(ConstantsUtil.TYPE, sbType.toString());
				mpPartTemp.put(ConstantsUtil.REVISION, sbRev.toString());
				mpPartTemp.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
				mpPartTemp.put(ConstantsUtil.SAPDESCRIPTION, sbSapDesc.toString());
				mpPartTemp.put(ConstantsUtil.RELEASEDATE, sbRelDate.toString());
				mpPartTemp.put(ConstantsUtil.ID, sbId.toString());
				hmVendorSpecs.put(ConstantsUtil.VENDORSPECS, mpPartTemp);
			}
			System.out.println("hmVendorSpecs=========>"+hmVendorSpecs);
			
			pool.checkIn(context);
			//Subhajit Added for Memory Leakage Analysis - Start
			context.close();
			//Subhajit Added for Memory Leakage Analysis - End
			sp.stop();
			LOGGER.info("VENDOR SPECS SERVICE MESSAGE ELAPSED TIME : "+sp.getTime());
		} catch (IOException e) {
			LOGGER.error("IOException from VENDOR SPECS "+e);
		} catch (MatrixException e) {
			LOGGER.error("MatrixException from VENDOR SPECS "+e);
		}
	}
	
	
	public static void formatData(StringBuilder sbData, String sData) {
		sbData.append(sData);
		sbData.append(ConstantsUtil.SYMBL_PIPE);
	}
}
