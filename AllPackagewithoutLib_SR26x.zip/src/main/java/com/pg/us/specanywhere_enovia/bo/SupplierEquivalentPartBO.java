/**
 * Project 		: SpecsAnywhere
 * Program 		: SupplierEquivalentPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;

import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class SupplierEquivalentPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(SupplierEquivalentPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	public SupplierEquivalentPartBO() {
		// empty constructor
	}

	public SupplierEquivalentPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getSepBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getSepBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getSepDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public DomainObject getSepDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getSupplierEquivalentPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getSupplierEquivalentPartSelectables(Context context) {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));
		
		//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
		busSelect.addAll(getSubstanceSelectables(context));
		//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
		
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
		
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGILMARCHIVALSTATUS);
		busSelect.add(ConstantsUtilIRM.SELECT_POLICYCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_POLICY);
		busSelect.add(ConstantsUtilIRM.SELECTABLE_ATTRIBUTE_PG_POA_IMPACT_CONFIRMATION);
		busSelect.add(ConstantsUtilIRM.SELECTABLE_RELATIONSHIP_PGMATERIALTOPGPLIENVCLASS);
		busSelect.add(ConstantsUtilIRM.SELECT_SUPPLIEREQUIVALENT_FROM_TYPE);
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 21 April 2021 -- START (FOr Internal Defect)
		busSelect.add(ConstantsUtilIRM.SELECT_MANUFACTURINGEQUIVALENT_TO_TYPE);
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 21 April 2021 -- START (FOr Internal Defect)
		
		//SPEC: Release SR18x.6.0 - Defect#41364,41363 Added  by gaikwad.tg on Date 23 Mar 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER);
		//SPEC: Release SR18x.6.0 - Defect#41364,41363 Added  by gaikwad.tg on Date 23 Mar 2021 -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getRefDocBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getRefDocBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		//SPEC: <16.06.2021>: Guna Added for 43645 Defect  Dev 18x.6.0.1   -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		//SPEC: <16.06.2021>: Guna Added for 43645 Defect  Dev 18x.6.0.1   -- END
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getSepRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getSepRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}
	

	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		
		
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
	
		//Added for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
	

		return relSelect;
	}

	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE); 
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);  
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_DIMENSTION_UOM);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGMEPTOPGPLIVENDORTYPEFORMEP);

		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMATERIALLAYER);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPGMINIMUMPERCENTWEIGHTBYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMAXIMUMPERCENTWEIGHTBYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_FN);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_STATE);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TITLE);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMATERIALLEGACYENVCLASS);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPOSTCOSUMERRECYCLEDCONTENT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_MANUFACTURER);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_MANUFACTURER);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_PGSEQUENCE);
		busSelect.add(ConstantsUtil.COMP_REVS);
		busSelect.add(ConstantsUtil.COMP_DESC);
		busSelect.add(ConstantsUtil.COMP_STATE);
		busSelect.add(ConstantsUtil.COMP_CASNUM);
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);
		busSelect.add(ConstantsUtil.SELECT_DRYWEGHT);
		
		//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
		
		
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--END
		//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
		return busSelect;

	}
	

	/**
	 * Method Name 			: updateDerivedToDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedToDataInfo(Context context ,String sSourceName, String sSourceRev, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map mpDerived = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();

		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.QUERY_WILDCARD, slBusSelects , slRelSelects, getTo, getFrom, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, 0);
			if (mlDerivedList.isEmpty()) {
				return new HashMap();
			}
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization=(String)objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;

				util.formatData(sbDerivedName,sDerivedName);
				util.formatData(sbSourceName,sSourceName);
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.ORIGINATED, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : SupplierEquivalentPartBO Method :updateDerivedToDataInfo "+e);
			return new HashMap();
		}
		return mpDerived;
	}

	
	/**
	 * Method Name 			: updateRefDocs
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> updateRefDocs(Context context,Map objectMap) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpRefDoc = new HashMap();
		StringBuffer sLangBuffer = new StringBuffer();

		try 
		{
			String sName    =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_NAME));
			String sCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_STATE));
			String sRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_REV));
			String sDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_DESC));
			String sTitle=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_TITLLE));
			String sId=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_ID));
			String sType=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_TYPE));
			String sLang=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_PGLANGUAGE));
			sType = util.mapType(sType);

			mpRefDoc.put(ConstantsUtil.NAME, sName);
			mpRefDoc.put(ConstantsUtil.TITLE, sTitle);
			mpRefDoc.put(ConstantsUtil.SOURCE, ConstantsUtil.EMPTY_STRING);
			mpRefDoc.put(ConstantsUtil.TYPE, sType);
			mpRefDoc.put(ConstantsUtil.STATE, sCurrent);
			mpRefDoc.put(ConstantsUtil.DESCRIPTION, sDesc);
			mpRefDoc.put(ConstantsUtil.ID, sId);
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sLang);
			mpRefDoc.put(ConstantsUtil.REVISION, sRev);

		} catch (Exception e) {
			LOGGER.error("Exception in Program : SupplierEquivalentPartBO Method :updateRefDocs "+e);
			return new HashMap();
		}

		return mpRefDoc;
	}
	
	
	/**
	 * Method Name 			: addMultiSelects
	 * Method Description 	:
	 */
	public StringList addMultiSelects() {
		
		StringList slMultiSelects = new StringList();

		slMultiSelects.add(ConstantsUtil.PRIMARYORGANIZATION);
		slMultiSelects.add(ConstantsUtil.SECONDARYORGANIZATION);

		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		slMultiSelects.add(ConstantsUtil.CERTIFICATION_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		slMultiSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGMEPTOPGPLIVENDORTYPEFORMEP);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);//Added by Pooja for 22x Defect 50409
		//Added by Ajay for Defect 22243  -- START
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS);
		//Added by Ajay for Defect 22243  -- END
		return slMultiSelects;
	}

	
	/**
	 * Method Name 			: removeMultiselects
	 * Method Description 	:
	 */
	public void removeMultiselects()
	{
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRIMARYORGANIZATION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SECONDARYORGANIZATION);

		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END
		// Guna Added for Defect 38531  18x.5.2 Release -- START
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
				// Guna Added for Defect 38531  18x.5.2 Release -- END
	}
	
	
	//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	: Fetching "Substances" related data 
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) 
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID); 
		busSelect.add(ConstantsUtil.COMP_NAME);
		busSelect.add(ConstantsUtil.COMP_SUBNAME);
		busSelect.add(ConstantsUtil.COMP_TITLE);
		busSelect.add(ConstantsUtil.COMP_MAXHGHT);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT);
		busSelect.add(ConstantsUtil.COMP_QUOM);
		busSelect.add(ConstantsUtil.COMP_QTY);
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);
		busSelect.add(ConstantsUtil.COMP_CASNUM);
		busSelect.add(ConstantsUtil.COMP_STATE);
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC);
		busSelect.add(ConstantsUtil.COMP_DRYWEIGHT);
		busSelect.add(ConstantsUtil.COMP_FUNCTIONS);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_CURRENT);
		
		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		 
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		try
		{
			String sType    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REVS));
			
			String sDesc	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sTitle	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_TITLE));
			
			String sCurrent =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_STATE));
			sCurrent=sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			
			String sCAS 	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			
			String sSub 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SUBNAME));
			String sQTS 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QSTCOMPOSITE));
			String sCont    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_ISCONTAM));
			String sQTY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE));
			String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE));
			String sQUOM    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));	

			String sMlLgc   =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			
			String sMFR     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String sCMT     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sTrN     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sDRY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DRYWEIGHT));
			
			String sFunctions =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_FUNCTIONS));
			
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String sQTYtype = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sUF = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.EMPTY_STRING));
			
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);

			sType = util.mapType(sType);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.REV,sRev);
			mpSubStanceResult.put(ConstantsUtil.STATE,sCurrent);
			mpSubStanceResult.put(ConstantsUtil.CAS,sCAS);
			mpSubStanceResult.put(ConstantsUtil.QSTARGET,sQTS);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			mpSubStanceResult.put(ConstantsUtil.IP,sCont);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.UOM,sQUOM);

			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sDRY);
			mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sFunctions);
			mpSubStanceResult.put(ConstantsUtil.PHASE, strPhase);
			mpSubStanceResult.put(ConstantsUtil.UF, sUF);

		}catch(Exception e){

			LOGGER.error("Error from SupplierEquivalentPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	/**
     * Method Name 			: getIpClass
     * Method Description 	: Get IP Classification
     * @param context
     * @param doFormObj  - domain object of part
     * @param slIpSelects - Selectable
     */
    public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
    	MapList mlIPCLass;
		try {
			mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
					null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			Iterator itr = mlIPCLass.iterator();
			Map mpIpClass = new HashMap();
			StringBuilder sbIpName = new StringBuilder();
			StringBuilder sbHasClassAccess = new StringBuilder();
			StringBuilder sbIpType = new StringBuilder();
			StringBuilder sbIpDesc = new StringBuilder();
			StringBuilder sbIpState = new StringBuilder();
			StringBuilder sbIpLibrary = new StringBuilder();
			StringBuilder sbIpClassPath = new StringBuilder();
			
			while(itr.hasNext()) {
				mpIpClass = (Map)itr.next();
				String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
				sbIpName.append(sIpClassName);
				sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
				sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
				sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
				String strIpClass="";
				if(sIpClassName.contains(ConstantsUtil.HIR)) {
					strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
					sbIpLibrary.append(strIpClass);
				} else {
					strIpClass= ConstantsUtil.BUSINESS_USE;
					sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
				}
				if(!strIpClass.isEmpty()) {
					StringBuilder sbIpClassTemp = new StringBuilder();
					sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
					sbIpClassPath.append(sbIpClassTemp.toString());
				}
				
				//Compare user classification against IPName
				sbHasClassAccess.append("TRUE");
				
				if(itr.hasNext()) {
					sbIpName.append("|");
					sbIpType.append("|");
					sbIpDesc.append("|");
					sbIpState.append("|");
					sbIpLibrary.append("|");
					sbIpClassPath.append("|");
					sbHasClassAccess.append("|");
				}
			}
			mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
			mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
			mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
			mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
			mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
		} catch (FrameworkException e) {
			e.printStackTrace();
			LOGGER.error("Error from SupplierEquivalentPartBO: getIpClass" + e);
		}
		return mpIpSecuritySetting;
    }
	//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
    
    
    //SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
	public static StringList getSecuritySelects(Context context) {
		
		StringList slIpSelects = new StringList();
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		
		return slIpSelects;
	}
	//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
	
	/**
	 * Due to performance issue this was copied from commonbusutil by Chandra on 24/02/2021
	 * @param context
	 * @param strObjectID
	 * @return
	 * @throws Exception
	 */
	   public MapList getCertifications (Context context,String strObjectID,Map mpHeaderResult)throws Exception
	    {
	      MapList relatedPartList = new MapList();
	      boolean isContextPushed = false;
	      try
	      {
			if(UIUtil.isNotNullAndNotEmpty(strObjectID))
			{
				DomainObject domObj =  DomainObject.newInstance(context, strObjectID) ;
				
				String strPolicy = domObj.getInfo(context, DomainConstants.SELECT_POLICY);
				  boolean bToDir = false;
				  boolean bFromDir = true;
				  if(UIUtil.isNotNullAndNotEmpty(strPolicy) && (ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT.equals(strPolicy) || ConstantsUtil.POLICY_SUPPLIEREQUIVALENT.equals(strPolicy))){
					  bToDir = true;
					  bFromDir = false;
				  }
					String sWhere = ConstantsUtil.EMPTY_STRING;
					if (strPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT)) {
						if (util.isModificatinRequired()) {
							sWhere = ConstantsUtilIRM.CURRENT_RELEASE;
						} else {
							sWhere = ConstantsUtilIRM.CURRENTNOTOBSOLETE;
						}
					} else {
						sWhere = ConstantsUtilIRM.CURRENT_RELEASE;
					}
				  
				StringList selectStmts = new StringList(); // putting elements to StringList
				selectStmts.addElement(ConstantsUtil.SELECT_ID);
				selectStmts.addElement(ConstantsUtil.SELECT_NAME);
				selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
				selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
				selectStmts.addElement(ConstantsUtil.SELECT_DESCRIPTION);
				selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);
				selectStmts.addElement(ConstantsUtil.SELECT_MANUFACTURINGRESPONSIBILITY_NAME);
				selectStmts.addElement(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_NAME);
				
				StringList selectRelStmts = new StringList();
				selectRelStmts.addElement(ConstantsUtil.SELECT_CERTIFICATION_VALUE);
				selectRelStmts.addElement(ConstantsUtil.SELECT_CERTIFICATION_EXPIRATION_DATE);
				selectRelStmts.addElement(ConstantsUtil.SELECT_CERTIFICATION_STATUS);
				//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- START
    			selectRelStmts.add(ConstantsUtilIRM.SELECT_CERTIFICATION_SOURCE);
    			//SPEC: <22.04.2022>: Guna Added for Req 41754 22x Release  -- END
    			
				// Retrieving related item
				Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT);
				relPattern.addPattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
				
				isContextPushed = true;
				
				relatedPartList = domObj.getRelatedObjects(context, relPattern.getPattern(),
						  ConstantsUtil.QUERY_WILDCARD, selectStmts, selectRelStmts, bToDir, bFromDir, (short) 1,
						  sWhere, ConstantsUtil.EMPTY_STRING, 500);
				  
				int size = relatedPartList.size();
				if (size == 500) {
					//Added by Ketan for Defect no. 54123 -- START
					String[] sError = ConstantsUtilIRM.E109.split(ConstantsUtil.SYMBL_COLON);
					mpHeaderResult.put(ConstantsUtil.ERROR, sError[1].toString());
					//Added by Ketan for Defect no. 54123 -- END
				}
				 
				  
				
	          }
	      }
	      catch(Exception e)
	      {
	            LOGGER.error("Error from SupplierEquivalentPartBO: getCertificationClaims" + e);
				return new MapList();
	      }
	      return relatedPartList ;
	    }
	 // 
	   
}