package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.FormulaCardBO;
import com.pg.us.specanywhere_enovia.bo.MPSBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPSService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaMPSServiceImpl implements EnoviaMPSService {

	private static Logger LOGGER = Logger.getLogger(EnoviaMPSServiceImpl.class);
	
	@Autowired
	private EnoviaConnectionPool pool;

	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String,String>> getMPSdata(String objId, Environment env) throws Exception {
		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		try {

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- START
			/*StopWatch swContext = new StopWatch();
			swContext.start();
			//EnoviaConnectionPool pool = new EnoviaConnectionPool(USER,PASS,VAULT);
			Context context = pool.checkOut();
			swContext.stop();*/
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- END
			LOGGER.info("MPS CONTEXT ELAPSED TIME : "+swContext.getTime());
			String sUserType = sct.getUserType();
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpReferenceDocs = new HashMap<String,String>();
			Map<String,String> mpHasATS = new HashMap<String,String>();
			Map<String,String> mpISATS = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			
			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			
			MPSBO mpsBO = new MPSBO();
			Map BusinessObjectSelectableMap = mpsBO.getMPSSelectableMap(context);
			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			
			DomainObject doMPS = mpsBO.getMpsDO(context, objId);
			if (null == doMPS) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();			
			//Map resultMap = doMPS.getInfo(context, slSelects);
			Map resultMap = doMPS.getInfo(context, slSelects,mpsBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("MPS GETINFO ELAPSED TIME : "+swAttributes.getTime());
			Map BusinessObjectRelSelectableMap = mpsBO.getMpsRelatedObjsSelectableMap(context);
			
			String sID = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sCSSAttrib = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE) : ConstantsUtil.EMPTY_STRING;
			
			
			if (sCSSAttrib.equals("MPS")) {
				
				LOGGER.info("MPS Objects is Unstructured : "+objId);
				EnoviaMPSUnstructured mpsNonStrct= new EnoviaMPSUnstructured();
				hmAttrib = mpsNonStrct.getMPSUnstructureddata(context,objId,strPDFView);
				pool.checkIn(context);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;

			}
			
			
			
			String sIsATS = "";
			String sATSCurrent = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.REL_ATS_STATE));
			String sATSName = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.REL_ATS_NAME));
			sIsATS =busUtil.checkIsATSAttribute(sATSName,sATSCurrent);
			
			
			/**
			 * LIFECYCLE SECTION for APPROVERs
			 */
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			if(bAllInfoView){
				mpLifeCycleApproval = busUtil.getCOName(context, changeargs);
			}
			swLifecycle.stop();
			LOGGER.info("MPS  LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
			
			
			/**
			 * LOAD HEADER SECTION
			 * */
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)))?busUtil.mapType((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderContent.put(ConstantsUtil.ISATS, sIsATS);
			mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, validator.DateFormatter(validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, validator.DateFormatter(validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING));
			String sClassification = busUtil.getClassification(resultMap);
			mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, (sClassification));
			mpHeaderContent.put(ConstantsUtil.ISSTRUCTURED, ConstantsUtil.SYMBL_TRUE);
			
		
			
			
			/**
			 * ATTRIBUTE SECTION
			 */
			
			if(bSupplierView || bAllInfoView || bManufacturerView){
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, validator.DateFormatter(validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.WAREHOUSINGCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				if(!bManufacturerView){
					mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, validator.DateFormatter(validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING));
				}
			
				if(bAllInfoView){
					mpAttribResult.put(ConstantsUtil.RELEASEDATE, validator.DateFormatter(validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING));
					mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PGASLALLOCATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, validator.DateFormatter(validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING));
					mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				}
			}
			
			
			/**
			 * HasATS
			 */
			mpHasATS = busUtil.checkHasATS(context,resultMap);
			if(!mpHasATS.isEmpty()){
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
			}else{
				//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.5.2: Modified for Defect 38162 by Jwala -- START
			}
			
			/**
			 * IsATS
			 */
			mpISATS = busUtil.checkIsATS(context,resultMap);
			
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- START
			if(bManufacturerView || bSupplierView) {
				mpISATS=busUtil.filterPhase(mpISATS);
			}
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- END
			
			
			/**
			 * ORGANIZATION SECTION
			 */
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = busUtil.filterMapList(mpOrganization);
			
			/**
			 * REFERENCE DOCUMENTS SECTION
			 */
			StopWatch swReference= new StopWatch();
			swReference.start();
			mpReferenceDocs = mpsBO.updateRefDocs(context, resultMap, true);
			swReference.stop();
			LOGGER.info("MPS REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());
			
			
			FormulaCardBO fcBO = new FormulaCardBO();
			
			/**
			 * LOAD SECURITY SECTION
			 * */
			StopWatch swSecurity = new StopWatch();
			swSecurity.start();
			mpSecurity =fcBO.getSecurityClass(context,sID,ConstantsUtil.TYPE_SECURITYCONTROLCLASS);
			swSecurity.stop();
			LOGGER.info("MPS  Security ELAPSED TIME : "+swSecurity.getTime());
			
			
			/**
			 * IP Security Classes
			 */
			
			mpIPClass =fcBO.getSecurityClass(context,sID,ConstantsUtil.TYPE_IPCONTROLCLASS);
			
			if(bSupplierView || bAllInfoView || bManufacturerView){
				
				hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent); 
				hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);  
				hmAttrib.put(ConstantsUtil.ISATS, mpISATS);
			
				if(bAllInfoView){
				
					hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
					hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mpReferenceDocs);
					hmAttrib.put(ConstantsUtil.HASATS, mpHasATS);
					hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
					hmAttrib.put(ConstantsUtil.IPSECURITY, mpIPClass);
				}
			}
			ContextUtil.popContext(context);
			pool.checkIn(context);
			sp.stop();
		} catch (IOException e) {
			LOGGER.error("IOException from MPS "+e);
		} catch (MatrixException e) {
			LOGGER.error("MatrixException from MPS "+e);
		}
		//LOGGER.info("MPS Structured RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		context.close();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmAttrib;
	}
}
