package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaDSSearchService {
	public HashMap<String, Map<String, String>> getDSSearchData(Environment env, String sType, Map<String, Object> mName) throws Exception;
}
