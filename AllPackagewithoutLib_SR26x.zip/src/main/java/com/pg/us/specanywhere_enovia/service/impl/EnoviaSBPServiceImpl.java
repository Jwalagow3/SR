package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.SoftwareBuildPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaSBPService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;


public class EnoviaSBPServiceImpl implements EnoviaSBPService {

	
	private static Logger LOGGER = Logger.getLogger(EnoviaSBPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	@Override
	public HashMap<String, Map<String, String>> getSBPdata(String objId, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		Context context = null;
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		context = pool.checkOut();
		swContext.stop();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		try
		{
			
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			LOGGER.info("SBP CONTEXT ELAPSED TIME : "+swContext.getTime());
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			
			if(null==sUserType || sUserType.isEmpty()) {
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				throw new Exception("Error in Log-In User Profile");
			}

			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;

			switch (sUserType) {
			case ConstantsUtil.PG:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PGSTAFF:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PG_CM:
				bManufacturerView = true;
				break;

			case ConstantsUtil.PG_SP:
				bSupplierView = true;
				break;
			}

			BusObjectAttribUtil util = new BusObjectAttribUtil();
			BusExtractUtil busutil = new BusExtractUtil();
			StringValidatorUtil validator = new StringValidatorUtil();
			
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			
			
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpGenInfo = new HashMap<String,String>();
			Map<String,String> mpProdEfefctivity = new HashMap<String,String>();
			Map<String,String> mpPartInfo = new HashMap<String,String>();
			Map<String,String> mpCustomerInfo = new HashMap<String,String>();
			Map<String,String> mpAccessControl = new HashMap<String,String>();
			Map<String,String> mpShippingInfo = new HashMap<String,String>();
			Map<String,String> mpDistributions = new HashMap<String,String>();
			
			SoftwareBuildPartBO SBPBo = new SoftwareBuildPartBO();
			StringList slContextSelects = SBPBo.getContextPartSelectables(context);
			
			DomainObject doSBP =  SBPBo.getSBPDO(context, objId);
			if(null==doSBP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doSBP.getInfo(context, slContextSelects);
			Map resultMaps = doSBP.getInfo(context, slContextSelects,SBPBo.addMultiValue());
			swAttributes.stop();
			LOGGER.info("SBP GETINFO ELAPSED TIME : "+swContext.getTime());
			//Added by Ajay for Defect no. 21451 -- START
			String strCurrent = (String)resultMaps.get(ConstantsUtil.SELECT_CURRENT);
			if(UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE) || strCurrent.equals(ConstantsUtil.STATE_COMPLETE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;

				} 
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE) && !strCurrent.equals(ConstantsUtil.STATE_COMPLETE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}
			//Added by Ajay for Defect no. 21451 -- START
		
		 
		//HeaderContent
		mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put(ConstantsUtil.STATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING));

		mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
	
		//General Info
		mpGenInfo.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpGenInfo.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
		String user = (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)));
		String soriginator = PersonUtil.getFullName(context,user);
		mpGenInfo.put(ConstantsUtil.ORIGINATOR, soriginator);
		mpGenInfo.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpGenInfo.put(ConstantsUtilIRM.STR_PRODUCT_BUILD_TYPE,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.PRODUCT_BUILD_TYPE)));
		mpGenInfo.put(ConstantsUtilIRM.STR_PRODUCT_BUILD_NAME,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.PRODUCT_BUILD_NAME)));
		String sprodBuildId =validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.PRODUCT_BUILD_ID));
		if(!util.checkHasAccess(context,null,sprodBuildId)){
			sprodBuildId=ConstantsUtil.NO_ACCESS;
		}
		 mpGenInfo.put(ConstantsUtilIRM.STR_PRODUCT_BUILD_ID,sprodBuildId);
		
		mpGenInfo.put(ConstantsUtilIRM.STR_PRODUCT_CONFIGURATION_TYPE,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.PRODUCT_CONFIGURATION_TYPE)));
		mpGenInfo.put(ConstantsUtilIRM.STR_PRODUCT_CONFIGURATION_NAME,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.PRODUCT_CONFIGURATION_NAME)));
		String sprodConfId =validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.PRODUCT_CONFIGURATION_ID));
		if(!util.checkHasAccess(context,null,sprodConfId)){
			sprodConfId=ConstantsUtil.NO_ACCESS;
		}
		mpGenInfo.put(ConstantsUtilIRM.STR_PRODUCT_CONFIGURATION_ID,sprodConfId);
		
		mpGenInfo.put(ConstantsUtil.RELATEDSOFTWAREBUILD_BUILDPATH,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBUILDPATH)));
		
		mpGenInfo.put(ConstantsUtilIRM.STR_ASSIGNED_PART_TYPE,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.REL_ASSIGNED_PART_TYPE)));
		mpGenInfo.put(ConstantsUtilIRM.STR_ASSIGNED_PART_NAME,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.REL_ASSIGNED_PART_NAME)));
		String sAssgnedPart =validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.REL_ASSIGNED_PART_ID));
		if(!util.checkHasAccess(context,null,sAssgnedPart)){
			sAssgnedPart=ConstantsUtil.NO_ACCESS;
		}
		mpGenInfo.put(ConstantsUtilIRM.STR_ASSIGNED_PART_ID,sAssgnedPart);
		mpGenInfo.put(ConstantsUtilIRM.STR_ASSIGNED_PART_REV,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.REL_ASSIGNED_PART_REV)));
		
		//Product Effectivity
		mpProdEfefctivity.put(ConstantsUtilIRM.STR_DESIGN_RESPONSIBILITY,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE)));
		
		//As - Part Designed Information
		mpPartInfo.put(ConstantsUtilIRM.BUILD_UNIT_NUM,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_BUILD_UNIT_NUM)));
		mpPartInfo.put(ConstantsUtilIRM.BUILD_PLANNED_DATE,validator.DateFormatter(validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PLANNED_BUILD_DATE))));
		mpPartInfo.put(ConstantsUtilIRM.BUILD_SHORTHAND_NOTATION,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SHORTH_HAND_NOTATION)));
		mpPartInfo.put(ConstantsUtilIRM.BUILD_SERIAL_NUM,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_BUILD_SERIAL_NUM)));
		mpPartInfo.put(ConstantsUtilIRM.BUILD_DATE_SHIPPED,validator.DateFormatter(validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_DATE_SHIPPED))));
		
		//Customer Information
		mpCustomerInfo.put(ConstantsUtilIRM.BUILD_ACTUAL_DATE,validator.DateFormatter(validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ACTUAL_BUILD_DATE))));
		mpCustomerInfo.put(ConstantsUtilIRM.STR_CUSTOMER_TYPE,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.REL_CUSTOMER_TYPE)));
		mpCustomerInfo.put(ConstantsUtilIRM.STR_CUSTOMER_NAME,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.REL_CUSTOMER_NAME)));
		String sCustomID =validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.REL_CUSTOMER_ID));
		if (UIUtil.isNotNullAndNotEmpty(sCustomID)) {
		if(!util.checkHasAccess(context,null,sCustomID)){
			sCustomID=ConstantsUtil.NO_ACCESS;
		}
		}
		mpCustomerInfo.put(ConstantsUtilIRM.STR_CUSTOMER_ID,sCustomID);
		
		//Access Control
		mpAccessControl.put(ConstantsUtilIRM.STR_MANUF_PLANT_NAME,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.REL_MANUFACTURING_PLANT_NAME)));
		
		//Building-Planning /Shipping Information
		mpShippingInfo.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
		
		//Distributions
		//Added by Ajay for Req 21324 -- START
		mpDistributions=SBPBo.GetDistributionInfo(context, objId);
		//Added by Ajay for Req 21324 -- END
		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtilIRM.GENINFO, mpGenInfo);
		hmAttrib.put(ConstantsUtilIRM.PRODUCTEFECTIVITY, mpProdEfefctivity);
		hmAttrib.put(ConstantsUtilIRM.PARTINFO, mpPartInfo);
		hmAttrib.put(ConstantsUtilIRM.CUSTOMERINFO, mpCustomerInfo);
		hmAttrib.put(ConstantsUtil.PLANTS, mpAccessControl);
		hmAttrib.put(ConstantsUtil.SHIPPINGINFORMATION, mpShippingInfo);
		hmAttrib.put(ConstantsUtilIRM.DISTRIBUTIONS, mpDistributions);//Added by Ajay for Req 21324
		
		
		pool.checkIn(context);
		sp.stop();
		LOGGER.info("SBP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "SBP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));


		} catch (IOException e) {
			LOGGER.error("Exception in getSBPdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		} catch (MatrixException e) {
			LOGGER.error("Exception in getSBPdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		//LOGGER.info("SBP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		if(null != context){
			context.close();
		}
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmAttrib;
	}

}
