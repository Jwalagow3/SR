/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaSMLServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */
package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.SmartLabelBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaSMLService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaSMLServiceImpl implements EnoviaSMLService {
	private static Logger LOGGER = Logger.getLogger(EnoviaSMLServiceImpl.class);
	@Autowired
	private  EnoviaConnectionPool pool;

	@Override
	public HashMap<String, Map<String, String>> getSMLdata(String objId, Environment env){
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		Context context = null;

		StopWatch swContext = new StopWatch();
		swContext.start();
		context = pool.checkOut();
		swContext.stop();
		LOGGER.info("SML CONTEXT ELAPSED TIME : "+swContext.getTime());

		try
		{
			SecurityService sct = new SecurityService();
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			//SPEC: <08-13-2021>: Guna Modified for Stress Testing Defect 44365  -- START
			if (UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BObjutil.getUserView(context, objId);
				}
			}
			//SPEC: <08-13-2021>: Guna Modified for Stress Testing Defect 44365  -- END
			if(null==sUserType || sUserType.isEmpty()) {
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				throw new Exception("Error in Log-In User Profile");
			}

			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;

			switch (sUserType) {
			case ConstantsUtil.PG:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PGSTAFF:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PG_CM:
				bManufacturerView = true;
				break;

			case ConstantsUtil.PG_SP:
				bSupplierView = true;
				break;
			}


			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpProperties = new HashMap<String,String>();
			Map<String,String> mpSmartLabelRow = new HashMap<String,String>();
			SmartLabelBO smlBO = new SmartLabelBO();
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			StringValidatorUtil validator = new StringValidatorUtil();
			Map<String, StringList> BusinessObjectSelectableMap = smlBO.getSMLSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context,ConstantsUtil.USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);
			DomainObject doSML =  smlBO.getSMLDO(context, objId);
			if(null==doSML) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			Map resultMaps = doSML.getInfo(context, slContextSelects);
			swAttributes.stop();
			LOGGER.info("SML GETINFO ELAPSED TIME : "+swAttributes.getTime());
			ContextUtil.popContext(context);

			/**
			 * LOAD HEADER CONTENT SECTION
			 * */
			// Added by Jwala to send role info to Integration
			mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			// Added by Jwala to send role info to Integration

			mpHeaderContent.put(ConstantsUtilIRM.SMARTLABELNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			//SPEC: <25.03.2021>: Guna Modified for Defect 41522 Dev 18x.6   -- START
			/*mpHeaderContent.put(ConstantsUtil.NAME, validator
								.getStringEquivalentForStringList(resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_PGSMARTLABEL+"].from."+ConstantsUtil.SELECT_NAME))); */
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING); 
			//SPEC: <25.03.2021>: Guna Modified for Defect 41522 Dev 18x.6   -- END
			mpHeaderContent.put(ConstantsUtil.REVISION, validator
					.getStringEquivalentForStringList(resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_PGSMARTLABEL+"].from."+ConstantsUtil.SELECT_REVISION)));
			mpHeaderContent.put(ConstantsUtil.STATE, validator
					.getStringEquivalentForStringList(resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_PGSMARTLABEL+"].from."+ConstantsUtil.SELECT_CURRENT)));
			mpHeaderContent.put(ConstantsUtil.ID, validator
					.getStringEquivalentForStringList(resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_PGSMARTLABEL+"].from."+ConstantsUtil.SELECT_ID)));
			/**
			 * LOAD PROPERTIES SECTION
			 * */
			mpProperties.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			String strSubType =(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSMARTLABELSUBTYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSMARTLABELSUBTYPE) : ConstantsUtil.EMPTY_STRING);
			mpProperties.put(ConstantsUtil.SUBTYPE, util.mapType(strSubType));
			mpProperties.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING));
			/**
			 * LOAD SMART LABEL ROW SECTION
			 * */
			mpSmartLabelRow =smlBO.getConnectedSmartLabelRows(context, objId,strSubType);
			//SPEC: <24.03.2021>: Guna Added for Defect 41522 Dev 18x.6   -- START
			mpSmartLabelRow =util.filterMapList(mpSmartLabelRow);
			//SPEC: <24.03.2021>: Guna Added for Defect 41522 Dev 18x.6   -- END  

			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtilIRM.PROPERTIES, mpProperties);
			hmAttrib.put(ConstantsUtilIRM.SMARTLABELROW, mpSmartLabelRow);

			pool.checkIn(context);
			sp.stop();
		}
		catch (Exception e) {
			LOGGER.error("Unable to getSMLdetails "+e);
		}
		//LOGGER.info("SML RESPONSE MESSAGE:: \n" + hmAttrib);
		context.close();
		return hmAttrib;
	}

}
