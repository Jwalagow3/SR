package com.pg.us.specanywhere_enovia.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.pg.us.specanywhere_enovia.security.JwtAuthenticationEntryPoint;
import com.pg.us.specanywhere_enovia.security.JwtAuthenticationFilter;

import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true, jsr250Enabled = true, prePostEnabled = true)
public class SecurityConfig {
	 
    @Autowired
    private JwtAuthenticationEntryPoint unauthorizedHandler;
 
    @Bean
    public JwtAuthenticationFilter jwtAuthenticationFilter() {
        return new JwtAuthenticationFilter();
    }
 
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // Enable CORS with default settings
            .cors(Customizer.withDefaults())
            
            // Disable CSRF protection
            .csrf(csrf -> csrf.disable())
            
            // Handle unauthorized access exceptions
            .exceptionHandling(exception -> exception
                .authenticationEntryPoint(unauthorizedHandler)
            )
            
            // Set session management to stateless (common for JWT-based auth)
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )
            
            // Define path authorization rules
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    "/",
                    "/favicon.ico",
                    "/**/*.png",
                    "/**/*.gif",
                    "/**/*.svg",
                    "/**/*.jpg",
                    "/**/*.html",
                    "/**/*.css",
                    "/**/*.js"
                ).permitAll()
                // If you have APIs that should be public, add them here, e.g.:
                // .requestMatchers("/api/auth/**").permitAll()
                .anyRequest().authenticated()
            );
 
        // Add your custom JWT token filter before the standard username/password filter
        http.addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);
 
        return http.build();
    }
}
