package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaPackagingAssemblyPartCompService {
	public HashMap<String, HashMap<String, Map<String, String>>> getPAPPartCompData(String sObjectId, Environment env);

}
