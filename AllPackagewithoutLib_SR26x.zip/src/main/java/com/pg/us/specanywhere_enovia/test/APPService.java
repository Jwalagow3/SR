package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.bo.IRMSBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.TransportUnitBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class APPService {

	private static Logger LOGGER = Logger.getLogger(APPService.class);

	
	public static void main(String[] args) throws Exception {

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		String objId = "20336.41905.41127.40598"; // Highly Restricted

		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
		Context context = pool.checkOut();

		/*
		 * User Profile
		 * 
		SecurityService sct = new SecurityService();
		String sUserType = sct.getUserType();
		if(null==sUserType || sUserType.isEmpty()) {
			throw new Exception("Error in Log-In User Profile");
		}*/

		boolean bAllInfoView = true;
		boolean bSupplierView = true;
		boolean bManufacturerView = true;

		/*switch (sUserType) {
		case ConstantsUtil.PG:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PGSTAFF:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PG_CM:
			bManufacturerView = true;
			break;

		case ConstantsUtil.PG_SP:
			bSupplierView = true;
			break;
		}*/

		Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
		Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mapWeightCharResult = new HashMap<String,String>();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Map<String,String> mpSubstitute = new HashMap<String,String>();
		Map<String,String> mpPlantResult = new HashMap<String,String>();
		Map<String,String> mpSubStanceResult = new HashMap<String,String>();
		Map<String,String> mapCountryClearanceResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mapPartSpecification = new HashMap<String,String>(); 
		Map<String,String> mpDangerousGoodsClf = new HashMap<String,String>();
		Map<String,String> mpGlobalHarStandard = new HashMap<String,String>();
		Map<String,String> mpNotes = new HashMap<String,String>();
		Map<String,String> mpStability = new HashMap<String,String>();
		Map<String,String> mpPerformChar = new HashMap<String,String>();
		Map<String,String> mpMaterialProduced = new HashMap<String,String>();
		Map<String,String> mpRelatedATS = new HashMap<String,String>();
		Map<String,String> mpMasterSpecs = new HashMap<String,String>();
		Map<String,String> mpMasterAttributes = new HashMap<String,String>();
		Map<String,String> mapCertifications = new HashMap<String,String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
		Map<String,String> mpDerivedToResult = new HashMap<String,String>();
		Map<String,String> mpSecurity = new HashMap<String,String>();


		APPBO APPBO = new APPBO();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		FormulaPartBO formulationPartBO = new FormulaPartBO();
		RawMaterialPartBO RawBO = new RawMaterialPartBO();
		DeviceProductPartBO DPPBO = new DeviceProductPartBO();
		CommonBusUtilBO commonBO = new CommonBusUtilBO();
		Map<String, StringList> BusinessObjectSelectableMap = APPBO.getAPPSelectableMap(context);
		Map<String, StringList> ChilsObjectSelectableMap = APPBO.getAPPRelatedObjsSelectableMap(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
		StringValidatorUtil validator = new StringValidatorUtil();
		ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context,ConstantsUtil.USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);
		DomainObject doAPP =  APPBO.getAppDO(context, objId);

		/*if(null==doAPP) {
			HashMap<String,String> errorMap = new HashMap<String,String>();
			String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
			errorMap.put(sError[0], sError[1]);
			hmAttrib.put(ConstantsUtil.ERROR, errorMap);
			return hmAttrib;
		}*/

		APPBO.addMultiSelects();
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doAPP.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("APP GETINFO ELAPSED TIME : "+swAttributes.getTime());

		APPBO.removeMultiSelects();

		boolean bGendocView = false;
		boolean bAuthorizedtoUse  = true;
		//boolean bAuthorizedtoUse = util.getAuthorizedtoUse(context,doAPP,resultMaps);
		if(!bAuthorizedtoUse) {
			bGendocView=true;
		}

		String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;
		String sClassifictaion = util.getClassification(resultMaps);
		//Common usage Variables 
		String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		
		ContextUtil.popContext(context);

		if(bAllInfoView || bManufacturerView) {
			/**
			 * LOAD BASIC ATTRIBUTES SECTION
			 * */
			mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE) : ConstantsUtil.EMPTY_STRING);
			
			if(!bGendocView){
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			}
			
			mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
			
			//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
			String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String strBrand = util.getBrandInformationValue(context,sID);
			if(strBrand.isEmpty()) {
				strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
			}
			mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
			
			mpAttribResult.put(ConstantsUtil.PROD_VARIANNT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ONSHELFPRODDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPLACE_PROD_ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PROD_SIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.UNIQUE_FORMULA_IDENTIFIER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			
			
			/**
			 * LOAD HEADER CONTENT SECTION
			 * */
			mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
			mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 

			mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
			mpHeaderContent.put(ConstantsUtil.PDF_VIEW, util.getPdfViewtype(bAllInfoView, bGendocView, bSupplierView));
			
			/**
			 * LOAD STORAGE AND LABEL SECTION
			 * */
			mapStorageAndLabelResult.put(ConstantsUtil.TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.PRODUCTMARKETEDASCHILDREN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.PGDOESCILDSAFEDESIGN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.PRODUCT_EXPOSED_CHILD, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.EVAPORATION_RATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.RESERVE_ACIDITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.RESERVE_ALKANITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.PROPERSHIPPINGNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.HAZARDCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.INTENDED_MARKET, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.UNSPECIFICATIONPACKAGINGMATERIALREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
			if(!bGendocView) {
			mapStorageAndLabelResult.put(ConstantsUtil.DANGEROUSGOODSCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
			}
			mapStorageAndLabelResult.put(ConstantsUtil.CUSTOMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.CONSUMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.UNNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER) : ConstantsUtil.EMPTY_STRING);
			
			
			/**
			 * LOAD DANGEROUS GOODS CLASSIFICATION SECTION
			 * */
			
			mpDangerousGoodsClf=util.getDangerousProdcutValue(context,resultMaps);
			/*mpDangerousGoodsClf.put(ConstantsUtil.PPN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.PPR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.PPT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			*/
			mpDangerousGoodsClf.put(ConstantsUtil.DGD, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.UNN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.PSN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.HC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.PGGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.SHIPPINGQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.CON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.OPR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.CUST, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.SDGCUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.SDGCOP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE) : ConstantsUtil.EMPTY_STRING);
			if(bManufacturerView) {
				mpDangerousGoodsClf=util.filterPhase(mpDangerousGoodsClf);
			}
			
			/**
			 * LOAD GLOBAL HARMONIZED STANDARD SECTION
			 * */
			/*mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTREVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTTITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			*/
			mpGlobalHarStandard = util.getGHSProdcutValue(context,resultMaps);
			mpGlobalHarStandard.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.MARKETS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.LANGUAGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE) : ConstantsUtil.EMPTY_STRING);
			if(bManufacturerView) {
				mpGlobalHarStandard=util.filterPhase(mpGlobalHarStandard);
			}
			
			
			/**
			 * LOAD STABILITY SECTION
			 * */
			/*mpStability.put(ConstantsUtil.MASTERPRODUCTPARTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.MASTERPRODUCTPARTREV,  (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.MASTERPRODUCTPARTTITLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE) : ConstantsUtil.EMPTY_STRING);
			
			*/
			
			mpStability =util.getWeightProdcutValue(context,resultMaps);
			mpStability.put(ConstantsUtil.PRODUCTEXPDATEREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.TOTALSHELFLIFEDAYS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.TEMPERATUREGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.HUMIDITYGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.TRANSPORTHEATPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.BOUNDARYCONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.STABILITYREPORTLINK, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE) : ConstantsUtil.EMPTY_STRING);

			/**
			 * LOAD NOTES SECTION
			 * */ 
			
			MasterCOPBO mcop = new MasterCOPBO();
			mpNotes=mcop.updateNotes(context, resultMaps);

			/**
			 * LOAD PERFORMANCE CHAR SECTION
			 * */ 
			Map paramMap = new HashMap();
			paramMap.put(ConstantsUtil.OBJECT_ID, objId);
			paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
			paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
			paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

			PerformanceCharcteristics perform = new PerformanceCharcteristics();
			StopWatch swPerfChar = new StopWatch();
			swPerfChar.start();
			MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
			if(!mlPerformChar.isEmpty())
			{
				FinishedProductPartBO fppBO = new FinishedProductPartBO();
				MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
				//mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
				swPerfChar.stop();
				LOGGER.info("APP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
			}

			/**
			 * LOAD WEIGHT CHARACTERISTICS SECTION
			 * */ 
			StopWatch swWeightCharacteristics = new StopWatch();
			swWeightCharacteristics.start();
			mapWeightCharResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mapWeightCharResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
			mapWeightCharResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mapWeightCharResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mapWeightCharResult.put(ConstantsUtil.TYPE,  util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mapWeightCharResult = util.filterMapList(mapWeightCharResult);
			swWeightCharacteristics.stop();
			LOGGER.info("APP GET swWeightCharacteristics ELAPSED TIME : "+swWeightCharacteristics.getTime());
			
			
			/**
			 * LOAD MATERIALS PRODUCED SECTION
			 * */ 
			StopWatch swMaterial = new StopWatch();
			swMaterial.start();
			mpMaterialProduced = DPPBO.getMaterialProduced(context,sContextObjectId);
			if(bManufacturerView || bGendocView) {
				mpMaterialProduced=util.filterPhase(mpMaterialProduced);
			}
			mpMaterialProduced = util.filterMapList(mpMaterialProduced);
			swMaterial.stop();
			LOGGER.info("DPP MATERIALS ELAPSED TIME : "+swMaterial.getTime());
			
			
			/**
			 * LOAD RELATED ATS SECTION
			 * */ 
			mpRelatedATS.put(ConstantsUtil.ATS_NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_NAME)))?(String)resultMaps.get(ConstantsUtil.ATL_NAME) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TYPE)))?(String)resultMaps.get(ConstantsUtil.ATL_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TITLE)))?(String)resultMaps.get(ConstantsUtil.ATL_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_STATE)))?(String)resultMaps.get(ConstantsUtil.ATL_STATE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_ORGNSOURCE)))?(String)resultMaps.get(ConstantsUtil.ATL_ORGNSOURCE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.ATL_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			
			if(bManufacturerView) {
				mpRelatedATS=util.filterPhase(mpRelatedATS);
			}
			mpRelatedATS = util.filterMapList(mpRelatedATS);
			
			/**
			 * LOAD PART SPECIFICATION SECTION
			 * */ 
			//mapPartSpecification = util.updatePartSpec(context,resultMaps);
			if(bGendocView) {
				mapPartSpecification.remove(ConstantsUtil.STATE);
			}
			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */
			StopWatch swReference= new StopWatch();
			swReference.start();
			//mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
			swReference.stop();
			LOGGER.info("APP  Reference ELAPSED TIME : "+swReference.getTime());
			
			if(!bGendocView) {	
			/**
			 * MASTER SPECIFICATION
			 * */
			StopWatch swmpMasterSpecs = new StopWatch();
			swmpMasterSpecs.start();
			mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
			mpMasterSpecs = util.filterMapList(mpMasterSpecs);
			swmpMasterSpecs.stop();
			LOGGER.info("APP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());
			
			/**
			 * LOAD MASTER ATTRIBUTE DATA SECTION
			 * */
			
			StopWatch swMasterAttrib = new StopWatch();
			swMasterAttrib.start();
			mpMasterAttributes = util.getMasterAttributes(context,sContextObjectId,"APP");
			if(bManufacturerView) {
				mpMasterAttributes=util.filterPhase(mpMasterAttributes);
			}
			mpMasterAttributes = util.filterMapList(mpMasterAttributes);
			swMasterAttrib.stop();
			LOGGER.info("APP GET MASTER ATTRIB ELAPSED TIME : "+swMasterAttrib.getTime());
			}

		}

		if(bManufacturerView) {
			/**
			 * LOAD BASIC ATTRIBUTES SECTION
			 * */
			mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
			
		}
		if(bGendocView){
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PROD_SIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		}
		if(bAllInfoView) {
			/**
			 * LOAD BASIC ATTRIBUTES SECTION
			 * */
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.WAREHOUSEPALLETSTAKMAXGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PROD_DENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ENTRYBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ATS_NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_NAME)))?(String)resultMaps.get(ConstantsUtil.ATL_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ATS_TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TYPE)))?(String)resultMaps.get(ConstantsUtil.ATL_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ATS_TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TITLE)))?(String)resultMaps.get(ConstantsUtil.ATL_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ATS_STAGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_STAGE)))?(String)resultMaps.get(ConstantsUtil.ATL_STAGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.FORMULATIONTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGPRODUCTFORM)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGPRODUCTFORM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
			//mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));
			
			
			/**
			 * LOAD ORGANIZATION DATA SECTION
			 * */
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = util.filterMapList(mpOrganization);

			/**
			 * LOAD LIFECYCLE SECTION
			 * */
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			mpLifeCycleApproval = util.getCOName(context, changeargs);
			swLifecycle.stop();
			LOGGER.info("APP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

			/**
			 * LOAD SUBSTANCES SECTION
			 * */
			mpSubStanceResult = RawBO.getSubstances(resultMaps);
			//mpSubStanceResult =util.verifyOwnership(context,mpSubStanceResult);
			mpSubStanceResult = util.filterMapList(mpSubStanceResult);
			
			
			/**
			 * LOAD PLANTS SECTION
			 * */
			mpPlantResult=util.updatePlantInfo(resultMaps);
			mpPlantResult = util.filterMapList(mpPlantResult);
			
			
			/**
			 * LOAD COUNTRY CLEARANCE SECTION
			 * */
			mapCountryClearanceResult.put(ConstantsUtil.COUNTRY_NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(  ConstantsUtil.STR_COUNTRY_NAME)))?(String)resultMaps.get(  ConstantsUtil.STR_COUNTRY_NAME) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_CT_NUM)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_CT_NUM) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.GPS_APPROVAL, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.MANU_SITE, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_MANU_SITE)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_MANU_SITE) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.PACK_SITE, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PACK_SITE)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PACK_SITE) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.CLEAR_COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.PLANT_REST, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PLANT_REST)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PLANT_REST) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_REG_DATE)))?validator.DateFormatter((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_REG_DATE)) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_REG_STATUS)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_REG_STATUS) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.COUNTRY_PROD_NUM, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PROD_REG_NUM)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PROD_REG_NUM) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtil.PROD_REG_CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS) : ConstantsUtil.EMPTY_STRING);
			mapCountryClearanceResult = util.filterMapList(mapCountryClearanceResult);
			mapCountryClearanceResult = util.filterMapList(mapCountryClearanceResult);
			
			
			/**
			 * LOAD CERTIFICATIONS SECTION
			 * */
			mapCertifications.put(ConstantsUtil.CERTIFICATIONCLAIM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_MATERIAL_CERTIFICATIONS_CERTIFICATIONCLAIM)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_MATERIAL_CERTIFICATIONS_CERTIFICATIONCLAIM) : ConstantsUtil.EMPTY_STRING);
			mapCertifications.put(ConstantsUtil.MARKETS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS) : ConstantsUtil.EMPTY_STRING);
			mapCertifications = util.filterMapList(mapCertifications);
			
			/**
			 * LOAD DERIVED DATA(RELATED PARTS) SECTION
			 * */
			StopWatch swDerived = new StopWatch();
			swDerived.start();
			String sDName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING;
			String sCreator = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING;
			
			//mpDerivedFromResult = APPBO.updateDerivedDataInfo(context,sDName, sRev, sCreatedDate, sCreator,doAPP,true,false);
			//mpDerivedToResult = APPBO.updateDerivedDataInfo(context,sDName, sRev, sCreatedDate, sCreator,doAPP,false,true);
			mpDerivedFromResult = util.filterMapList(mpDerivedFromResult);
			mpDerivedToResult = util.filterMapList(mpDerivedToResult);
			swDerived.stop();
			LOGGER.info("APP  Derived ELAPSED TIME : "+swDerived.getTime());
			
			/**
			 * LOAD SECURITY SECTION
			 * */
			StopWatch swSecurity = new StopWatch();
			CommonBusUtilBO bo = new CommonBusUtilBO();
			swSecurity.start();
			mpSecurity =bo.updateSecurity(context,resultMaps);
			mpSecurity = util.filterMapList(mpSecurity);
			swSecurity.stop();
			LOGGER.info("APP  Security ELAPSED TIME : "+swSecurity.getTime());
			
			/**
			 * LOAD OWNERSHIP SECTION
			 * */
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);

			/**
			 * LOAD SAP BOM SECTION
			 * */
			
			StopWatch swSapBomAsFed = new StopWatch();
			swSapBomAsFed.start();
			CalculateBOM clBom = new CalculateBOM();
            mpSapBomAsFedcResult = clBom.getSapBOMasFed(context,sContextObjectId);
			mpSapBomAsFedcResult = util.filterMapList(mpSapBomAsFedcResult);
			swSapBomAsFed.stop();
			LOGGER.info("APP GET SapBomAsFed ELAPSED TIME : "+swSapBomAsFed.getTime());

		}
		
		/**
		 * LOAD BOM SECTION
		 * 
		 *if the user is CM and Plant AuthoriseToUse true he should not have access to BOM - 33221*/
		
		
		if (bGendocView || bAllInfoView ){
			StopWatch swBom = new StopWatch();
			swBom.start();
			MapList mapList = doAPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
					ConstantsUtil.SYMBL_ASTERISK, slChildBusSelects, slChildRelSelects, false, true, (short)1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			if(bManufacturerView) {
				mapList=util.filterPhase(mapList);
			}
			
			//Maplist size
			if(mapList.size()!=0){
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --START
				//mpEBOMResult =	APPBO.parseMaplist(context,mapList);
				mpEBOMResult =	APPBO.parseMaplist(context,mapList, false);
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
				mpSubstitute =  commonBO.getSubstitute(context,mapList);
			}
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
			swBom.stop();
			LOGGER.info("APP BOM ELAPSED TIME : "+swBom.getTime());
		}
		
		if(!bGendocView) {
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.MASTERATTRIBUTES, mpMasterAttributes);
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
		}
		
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATAOBJECT, mapStorageAndLabelResult);
		hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mapWeightCharResult);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mapPartSpecification);
		hmAttrib.put(ConstantsUtil.DANGEROUSGOODCLASSIFICATION, mpDangerousGoodsClf);
		hmAttrib.put(ConstantsUtil.GLABALHARMONIZEDSTANDARD, mpGlobalHarStandard);
		hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
		hmAttrib.put(ConstantsUtil.STABILITYRESULTS, mpStability);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.MATERIALPRODUCED, mpMaterialProduced);
		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpSubStanceResult);
		hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
		hmAttrib.put(ConstantsUtil.COUNTRYCLEARENCE, mapCountryClearanceResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO,mpDerivedToResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
		hmAttrib.put(ConstantsUtil.CERTIFICATIONS, mapCertifications);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
		
		sp.stop();
		LOGGER.info("APP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "APP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));


		LOGGER.info("RESULT:: \n" + mpEBOMResult);
		
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End


	}// main method

}//End of Class
