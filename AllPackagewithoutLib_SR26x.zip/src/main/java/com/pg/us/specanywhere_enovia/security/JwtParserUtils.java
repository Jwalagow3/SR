package com.pg.us.specanywhere_enovia.security;

import java.nio.charset.StandardCharsets;
import javax.crypto.SecretKey;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import io.jsonwebtoken.io.Decoders;

public class JwtParserUtils {
 
	public static Jws<Claims> parseJWTToken(String secretKey, String token) {
	    // Decode Base64 string into actual bytes before creating the HMAC key
	    byte[] keyBytes = Decoders.BASE64.decode(secretKey);
	    SecretKey key = Keys.hmacShaKeyFor(keyBytes);
	 
	    return Jwts.parser()
	               .verifyWith(key)
	               .build()
	               .parseSignedClaims(token);
	}
    
    public static DecodedJWT parseJWTTokenPNG(String token) {
        return JWT.decode(token);
    }
 
}