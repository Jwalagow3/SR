package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaVendorSpecsService {

	public HashMap<String, Map<String, String>> getVendorSpecs(String sCompany, String sView, Environment env) throws Exception;
}
