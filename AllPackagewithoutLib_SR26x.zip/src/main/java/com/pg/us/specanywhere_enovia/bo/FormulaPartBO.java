/**
 * Project 		: SpecsAnywhere
 * Program 		: FormulaPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.mxType;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.fop.FormulationAttribute;
import com.pg.us.specanywhere_enovia.fop.FormulationRelationship;
import com.pg.us.specanywhere_enovia.fop.FormulationSubstituteConstants;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.SAPBOMConstants;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

import matrix.util.Pattern;
import matrix.util.SelectList;

public class FormulaPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(FormulaPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();

	public FormulaPartBO() {
		// empty constructor
	}

	
	/**
	 * Method Name 			: getMaterialProduced
	 * Method Description 	: Fetching "Materials Produced" information
	 * @param context
	 * @param strObjId
	 * @returns materials Produced
	 */
	public Map getMaterialProduced(Context context,String strObjId)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		
		StringBuilder sbId=new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbRevision=new StringBuilder();
		StringBuilder sbOwner=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		//SPEC: Release SR18x.6. Added by Dominic for Defect 41740 on Date 29/03/2021 --START
		boolean showData = false;
		String sUserType = util.getUserType();
		//SPEC: Release SR18x.6. Added by Dominic for Defect 41740 on Date 29/03/2021 --END
		//SPEC: Release SR18x.6.0.3 Added by Bala for Defect #45839 on Date 30/12/2021 -- START
		StringBuilder sbMaterialWhere = new StringBuilder();
		sbMaterialWhere.append(DomainConstants.SELECT_CURRENT).append(SAPBOMConstants.CONST_SYMBOL_EQUAL).append(ConstantsUtil.STATE_RELEASE);
		//SPEC: Release SR18x.6.0.3 Added by Bala for Defect #45839 on Date 30/12/2021 -- END
		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strObjId))
				{
					DomainObject contextObj = DomainObject.newInstance(context,strObjId);
					StringList selectStmts = new StringList(5);                     
					selectStmts.addElement(ConstantsUtil.SELECT_ID);
					selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
					selectStmts.addElement(ConstantsUtil.SELECT_NAME);
					selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
					selectStmts.addElement(ConstantsUtil.SELECT_DESCRIPTION);
					selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);		
					selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);	
					
					Pattern typePattern = new Pattern(ConstantsUtil.TYPE_RAWMATERIALPART);
					typePattern.addPattern(ConstantsUtil.TYPE_PGRAWMATERIAL);
					//SPEC: Release SR18x.6.0.3 Added by Bala for Defect #45839 on Date 30/12/2021 -- START
					MapList mlRelatedIAPSList = contextObj.getRelatedObjects
											(context, //MatrixContex
											ConstantsUtil.RELATIONSHIP_PGDEFINESMATERIAL, //relationshipPattern
											typePattern.getPattern(), //typePattern
											selectStmts, //objectSelects            
											null, //relationshipSelects          
											false, //getTo                      
											true, //getFrom                     
											(short)1, //recurseToLevel                   
											sbMaterialWhere.toString(), //objectWhere                       
											null, //relationshipWhere
											0); //limit
					//SPEC: Release SR18x.6.0.3 Added by Bala for Defect #45839 on Date 30/12/2021 -- END					
					Iterator objectListItr = mlRelatedIAPSList.iterator();
					
					while(objectListItr.hasNext())
					{
						Map resultMaps = (Map) objectListItr.next();
						
						String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.TYPE));
						String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ID));
						String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.NAME));
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
						String strDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.DESCRIPTION));
						String strTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
						String strRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
						String strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
						String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
						
						//modified by Ganesh for defect 38188----->start
						//SPEC: 01/09/2021: Modified for 18x.6.0.2 Defect# 42886 by Manikanta-- START
						strState=util.mapType(strState);
						strType=util.mapType(strType);
						
						if (UIUtil.isNotNullAndNotEmpty(strID)) {
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41740 on Date 29/03/2021 --START
							showData = util.checkHasAccess(context, sUserType, strID);
							if (!strState.equals(ConstantsUtil.RELEASE) &&  !strState.equals(ConstantsUtil.RELEASED)) {
								strID=ConstantsUtil.NO_ACCESS;
								
							}
						//SPEC: 01/09/2021: Modified for 18x.6.0.2 Defect# 42886 by Manikanta-- END
							if (!showData) {
								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- START
								if(util.isModificatinRequired())
								continue;
								else
								{
									formatData(sbType,strType);
									formatData(sbName,strName);
									formatData(sbDesc,ConstantsUtil.NO_ACCESS);
									formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
									formatData(sbId,ConstantsUtil.NO_ACCESS);
									formatData(sbRevision,strRev);
									formatData(sbPhase,ConstantsUtil.NO_ACCESS);
									formatData(sbTitle,ConstantsUtil.NO_ACCESS);
								}
								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- START
							}
							else {
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41740 on Date 29/03/2021 --END	
								formatData(sbType,strType);
								formatData(sbName,strName);
								formatData(sbDesc,strDesc);
								formatData(sbCurrent,strState);
								formatData(sbId,strID);
								formatData(sbRevision,strRev);
								formatData(sbPhase,strPhase);
								formatData(sbTitle,strTitle);
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41740 on Date 29/03/2021 --START
							}
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41740 on Date 29/03/2021 --END
						}
						//modified by Ganesh for defect 38188----->end
					}
						
					mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString());
					//SPEC: Release SR18x.5.2 - Added for Defect# 38188  by Ganesh on Date 2/12/2021 -- START
					//mpSubStanceResult.put(ConstantsUtil.TITLE,sbDesc.toString());
					mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString());
					//SPEC: Release SR18x.5.2 - Added for Defect# 38188  by Ganesh on Date 2/12/2021 -- END
					mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString());
					mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString());
					mpSubStanceResult.put(ConstantsUtil.REV,sbRevision.toString());
					mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString());
					mpSubStanceResult.put(ConstantsUtil.PHASE, sbPhase.toString());
					mpSubStanceResult.put(ConstantsUtil.ID, sbId.toString());
			}

		}catch(Exception e){

			LOGGER.error("Error from FormulaPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return util.filterMapList(mpSubStanceResult);
	}
	
	
	public FormulaPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getFopBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getFopBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getFopDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getFopDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getFopSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getFopSelectables(Context context) {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getWeightCharacterSelectable(context));
		busSelect.addAll(getChemicalPhysicalSelectable(context));
		busSelect.addAll(getStorageTrasportSelectable(context));
		busSelect.addAll(getSapBomAsFedBusSelectable(context));
		busSelect.addAll(getPlantBusSelectable(context));
		busSelect.addAll(getOrgSelects(context));
		busSelect.addAll(getRelAtsSelects(context));
		busSelect.addAll(getCountryClearanceSelectable(context));
		busSelect.addAll(getBusSelects(context));
		busSelect.addAll(getDangerousgoodsSpecSelects(context));
		busSelect.addAll(getGlobalHarmonizedStandard(context));
		busSelect.addAll(getStabilityResults(context));
		busSelect.addAll(getIPClassSelect(context));
		busSelect.addAll(getFileSelects(context));
		relSelect.addAll(getRelSelects(context));
		
		//SPEC: 10.11.2020: Added for req 18x.5 ## -- START
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getSubstanceSelectables(context));
		//SPEC: 10.11.2020: Added for req 18x.5 ## -- END
		
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;
	}
	
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	
	
	
	/**
	 * Method Name 			: getRelAtsSelects
	 * Method Description 	: Fetching "Related ATS" information
	 * @param context
	 * @return
	 */
	public StringList getRelAtsSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_ID);
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_TITLE);

		return busSelect;
	}
	/**
	 * Method Name 			: getCountryClearanceSelectable
	 * Method Description 	: Fetching "Country" related data
	 * @param context
	 * @return
	 */
	public static StringList getCountryClearanceSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.STR_COUNTRY_NAME); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_CT_NUM); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS); 	
		busSelect.add(ConstantsUtil.STR_COUNTRY_MANU_SITE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PACK_SITE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PLANT_REST); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_REG_DATE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_REG_STATUS); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE);
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY);
		busSelect.add(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME);
		
		//SPEC:11/23/2020: Added for defect 37522 by Amman ## -- START
		busSelect.add(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALLEADTIME);
		busSelect.add(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALSTATUS);
		//SPEC:11/23/2020: Added for defect 37522 by Amman ## -- END
		
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- START
		busSelect.add(ConstantsUtilIRM.STR_COUNTRY_PGMARKETAPPROVALHOLDER);
		busSelect.add(ConstantsUtilIRM.STR_COUNTRY_PGLEGELENTITY);
		busSelect.add(ConstantsUtilIRM.STR_COUNTRY_PGBUSINESSCHANNEL);
		busSelect.add(ConstantsUtilIRM.STR_COUNTRY_PGPACKSIZEUOM);
		busSelect.add(ConstantsUtilIRM.STR_COUNTRY_PGPACKSIZE);
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- END
		
		return busSelect;
	}

	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.STRPGBRAND);
		busSelect.add(ConstantsUtil.STRKEYFORMULATIONTYPE);
		busSelect.add(ConstantsUtil.STRKEYFORMULATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.STRPGPDTTOPGPLICLASS);
		busSelect.add(ConstantsUtil.STRPGPDTTOPGPLIREFUN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.STR_SELECT_PARTSPECIFICATION_NAME);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_STATE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_SUBTYPE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_TYPE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_TITLE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.STR_FORMULATION_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_FOPPROCESS_ID);

		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE);
		busSelect.add(ConstantsUtil.COMP_STATE);
		busSelect.add(ConstantsUtil.COMP_REVS);
		busSelect.add(ConstantsUtil.COMP_DESC);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_ID);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		
		
		busSelect.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		busSelect.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		
		//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTPLATFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTPLATFORMREV);//Added by Ketan for defect no. 53059
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTANDARDCOST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPGPPRODUCTDILUTEDFORUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PERCENTCONCENTRATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPERCENTWATER_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSREADY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS);
		
		busSelect.add(ConstantsUtil.SELECT_FOPCERTIFICATIONS);
		
		//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END
		//Added for defect id:37482
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER);
				
		//SPEC: <11.20.2020>: Chandra Added for Defect :35734 ## --START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		//SPEC: <11.20.2020>: Chandra Added for Defect :35734 ## --END
		
		//Added for Defect #37478 -- START
		busSelect.add(ConstantsUtil.RELATIONSHIP_OWNINGPRODUCTLINE_PGPLIPRODUCTFORM_NAME);
		//Added for Defect #37478 -- END
		
		//SPEC:12/04/2020: Added for Defect comma issue by Chandra  ## -- START
		busSelect.add(ConstantsUtil.strIntendedMarket);
		//SPEC:12/04/2020: Added for Defect comma issue by Chandra  ## -- END
		// Guna Added for Defect 38904  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		// Guna Added for Defect 38904  18x.5.2 Release -- END
		busSelect.add(ConstantsUtilIRM.FORMULATION_ID);

		//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_SMARTLABENREADY);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC);
		//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- END
		//Added by Subhajit for Req 46464 - Start
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - End

		return busSelect;

	}

	
	/**
	 * Method Name 			: getDangerousgoodsSpecSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getDangerousgoodsSpecSelects(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);
		
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getGlobalHarmonizedStandard
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getGlobalHarmonizedStandard(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		
		// Guna modified for Defect 37202  18x.5.2 Release -- START
		/*busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE);*/
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID);
		// Guna modified for Defect 37202  18x.5.2 Release -- END
		

		return busSelect;
	}

	
	/**
	 * Method Name 			: getStabilityResults
	 * Method Description 	: Fetching "Stability" related data
	 * @param context
	 * @return
	 */
	public static StringList getStabilityResults(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_NAME);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ID);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS);

		return busSelect;
	}


	/**
	 * Method Name 			: getIPClassSelect
	 * Method Description 	: Fetching "IPClassification" details
	 * @param context
	 * @return
	 */
	public static StringList getIPClassSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getOrgSelects
	 * Method Description 	: Fetching "Organization" related information
	 * @param context
	 * @return
	 */
	public static StringList getOrgSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		return busSelect;
	}


	/**
	 * Method Name 			: getWeightCharacterSelectable
	 * Method Description 	: Fetching "Weight Characteristics" data
	 * @param context
	 * @return
	 */
	public StringList getWeightCharacterSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ID);
		return busSelect;
	}

	
	/**
	 * Method Name 			: getRelSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getRelSelects(Context context) {
		StringList relSelects = new StringList();
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID);
		relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelects.add(ConstantsUtil.SELECT_FBOMSUBSTITUTE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);


		relSelects.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelects.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_UNITSVALUE);
		relSelects.add(ConstantsUtil.SELECT_FBOMSUBSTITUTE);
		
		//SPEC: <11.07.2020>: Added for Defect 37161 ## -- START
		relSelects.add(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_NAME);
		relSelects.add(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_TYPE);
		relSelects.add(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_ID);
		//SPEC: <11.07.2020>: Added for Defect 37161 ## -- END

		//Added for Defect# 37591 -- START
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
		
		//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- START
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_FOPCERTIFICATIONS);
		//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END
		//SPEC: <02.04.2021>: Modified for Defect #38991 by Sumit  --START
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET);
		//SPEC: <02.04.2021>: Modified for Defect #38991 by Sumit  --ENDS
		//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- START
		relSelects.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelects.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelects.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		relSelects.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		//SPEC: Added by Pooja for req no. 45642 on 11.18.2022 -- END
		return relSelects;

	}

	
	/**
	 * Method Name 			: getRelFormulaIngredients
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getRelFormulaIngredients(Context context) {
		StringList relSelects = new StringList();
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID);
		relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelects.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		//relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
		relSelects.add(ConstantsUtil.REPORTED_FUNCTION);
		
		//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- START
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_FOPCERTIFICATIONS);
		//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END

		return relSelects;
	}
	
	
	/**
	 * Method Name 			: getFormulaIngredients
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getFormulaIngredients(Context context){
		StringList busSelects = new StringList();

		busSelects.add(ConstantsUtil.SEQUENCENUMBER);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE);
		busSelects.add(ConstantsUtil.SELECT_SUBSTITUTE);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		
		//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- START
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_INPUTVALUE);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_INPUTVALUE);
		busSelects.add(ConstantsUtil.SELECT_FOPCERTIFICATIONS);
		//SPEC: Release 18x.5.2: Modified for Defect 36223 by Amman ## -- END
		//Added by Pooja for the req 41754,34415 -- START
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		//Added by Pooja for the req 41754,34415 -- END
		return busSelects;

	}

	
	/**
	 * Method Name 			: getChemicalPhysicalSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getChemicalPhysicalSelectable (Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIGNITIONDISTANCE_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENCLOSEDSPACEIGNITION_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFOAMFLAMMABILITY); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTENTCONDUCTIVITY_INPUT_VALUE); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINTVALUE_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVETOMETALS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUSTAINCOMBUSTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOXIDIZER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAVAILABLEOXYGEN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBYVOLUME_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBYWEIGHT_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPELLANTEMULSIFIEDPRODUCT_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPELLANTNONFLAMMABLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVAPORPRESSURE_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWTPARAMETERIZED_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBURNRATE_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION_INPUT_VALUE); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSELFACCELDECOMTEMP_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGKSTDUSTDEFLAGRATIONINDEX_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPMAXEXPLOSIONPRESSURE_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_AVAILABILITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_LIQUID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTOXIDIZER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_TECHNICAL_CTM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_DILUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VAPOUR_DENSITY_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOLTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_CAN_CONSTRUCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_COLOR_INTENSITY_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOLOR_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_AVAILABLE_OXYGEN_CONTENT_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONDUCTIVITYOFTHELIQUID_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_BOILINGPOINTVALUE_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEDURATION_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEHEIGHT_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_ORGANIC_PEROXIDE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE_INPUT_VALUE);
		
		//SPEC: <10.13.2020>: ADDED for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTHELIQUIDANAQUEOUSSOL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPHDATAAVAILABLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMIN_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMAX_INPUT_VALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYTITRATIONENDPOINT_INPUT_VALUE);
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 16 Mar 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH);
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 16 Mar 2021 -- END
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 17 Mar 2021 -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPOTENTIALTOINCREASEBURNINGRATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_COLOR_INTENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_LIQUID_CORROSIVE_TO_METAL);
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 17 Mar 2021 -- END
		//SPEC: <10.13.2020>: ADDED for req 18x.5 ## -- END
		//SPEC: <29.12.2021>: Guna Added for 42883 Defect  Dev 18x.6.0.3   -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE_INPUTVALUE);
		//SPEC: <29.12.2021>: Guna Added for 42883 Defect  Dev 18x.6.0.3   -- END
		//SPEC: 21-06-2022: Satyam Added for Internal Defect -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISTHELIQUIDANAQEOUSSOLUTION);
		//SPEC: 21-06-2022: Satyam Added for Internal Defect -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCTSUSTAINCOMBUSTION);//Added by Ketan for Defect no. 54744
		
		//SPEC: 07.04.2022: Jwala Added for Req 11640 Release  -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMELTINGPOINTTARGET);
		busSelect.add(ConstantsUtilIRM.SELECT_AATTRIBUTE_PGMELTINGPOINTMIN);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMELTINGPOINTMAX);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPTARGET);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPMIN);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPMAX);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_DUSTEXPLOSIVITY);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGKST);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMAX);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PARTITIONCOEFFICIENT);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_WATERSOLUBILITY);
		//SPEC: 07.04.2022: Jwala Added for Req 11640 Release  -- END
		//Added By Ajay for the Req 14570 : START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYTMAX);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYTMIN);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITYMAX);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITYMIN);
		//Added By Ajay for the Req 14570 : END
		return busSelect;
	}


	/**
	 * Method Name 			: getStorageTrasportSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getStorageTrasportSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN );
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTANDARDCOST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGHAZARDCLASSIFICATION);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		
		
		
		

		return busSelect;
	}


	/**
	 * Method Name 			: getBusSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBusSelects(Context context) {
		StringList objectSelects = new StringList();
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		objectSelects.add(ConstantsUtil.SELECT_NAME);
		objectSelects.add(ConstantsUtil.SELECT_TYPE);
		objectSelects.add(ConstantsUtil.SELECT_ID);
		objectSelects.add(ConstantsUtil.SELECT_REVISION);
		objectSelects.add(ConstantsUtil.SELECT_CURRENT);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		//Added by Ajay for Req 7790 - START
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION);
		//Added by Ajay for Req 7790 - END
		return objectSelects;

	}

	
	/**
	 * Method Name 			: getPlantBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getPlantBusSelectable(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		return busSelect;
	}


	/**
	 * Method Name 			: getMaterialFunction
	 * Method Description 	:
	 * @param context
	 * @param strRelId
	 * @return
	 * @throws Exception
	 */
	public String getMaterialFunction(Context context, String strRelId) throws Exception {
		String sApplication 		= DomainConstants.EMPTY_STRING;
		String sMatFun 				= DomainConstants.EMPTY_STRING;
		StringList sAppList   		= null;
		StringList sAppMatIds 		= null;
		String[] sValueArray  		= null;
		MapList mApplications   	= null;
		Map objMap   				= null;
		Map mData   				= null;
		StringBuilder strBuilder	= null;
		StringList selectList 		= new StringList(1);
		selectList.add(DomainConstants.SELECT_NAME);
		try{

			ContextUtil.pushContext(context, ConstantsUtil.PERSON_USER_AGENT , ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING);
			if(UIUtil.isNotNullAndNotEmpty(strRelId)){
				DomainRelationship domainRelationship = DomainRelationship.newInstance(context, strRelId);
				sApplication = domainRelationship.getAttributeValue(context,ConstantsUtil.ATTRIBUTE_APPLICATION);
				if(UIUtil.isNotNullAndNotEmpty(sApplication)){
					sAppList 	= new StringList(FrameworkUtil.split(sApplication, ConstantsUtil.SYMBL_COMMA));
					sAppMatIds 	= new StringList();
					Iterator iAppItr = sAppList.iterator();
					while (iAppItr.hasNext()) {
						sAppMatIds.add(((String)iAppItr.next()).trim());
					}
					sValueArray =  (String[])sAppMatIds.toArray(new String []{});
					mApplications = DomainObject.getInfo(context, sValueArray, selectList);
					strBuilder = new StringBuilder();
					Iterator it = mApplications.iterator();
					while(it.hasNext()){
						objMap = (Map) it.next();
						strBuilder.append(objMap.get(DomainConstants.SELECT_NAME));
						if(it.hasNext())
							strBuilder.append(ConstantsUtil.SYMBL_COMMA);
					}
					sMatFun = strBuilder.toString();
				}
			}
		}
		catch(Exception exception){
			LOGGER.error("Unable to get data in FormulaPartBO : getMaterialFunction "+exception.getMessage());
			return  ConstantsUtil.EMPTY_STRING;
		} finally {
			ContextUtil.popContext(context);
		}
		return sMatFun;
	}


	/**
	 * Method Name 			: getSapBomAsFedBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getSapBomAsFedBusSelectable(Context context) {

		StringList busSelect = new StringList(8);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_NAME);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_CURRENT);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_TYPE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_SAPSUBTYPE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_TITLE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_BOMQTY);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_BUOM);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE);


		return busSelect;
	}

	
	/**
	 * Method Name 			: calculateBOMQty
	 * Method Description 	:
	 * @param slData
	 * @return
	 */
	public String calculateBOMQty(StringList slData){
		StringBuffer sbbomQuantity = new StringBuffer();
		String sQty = DomainConstants.EMPTY_STRING;
		for(int i=0 ;i<slData.size();i++){
			sQty = slData.get(i);
			float sQuantity = Float.parseFloat(sQty);
			sQuantity*=10;
			sbbomQuantity.append(sQuantity);
			sbbomQuantity.append(ConstantsUtil.SYMBL_PIPE);
		}
		return sbbomQuantity.toString();

	}


	/**
	 * Method Name 			: getSapBomAsFed
	 * Method Description 	:
	 * @param objectMap
	 * @return
	 */
	public Map getSapBomAsFed(Map objectMap){
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String,String> mpPartSpecs = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try {


			String sType    =   validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_TYPE));
			String sName    =   validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_NAME));
			String sState   =   validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_CURRENT));
			String sRelPhase	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_RELEASE_PHASE));
			String sSapType		=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE));
			String sSapSubType		=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE));
			String sBomQty	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_BOMQTY));
			String[] saBomQty=sBomQty.split(ConstantsUtil.SYMBL_PIPE);
			StringList	slBomQty=util.MapsType(saBomQty);
			sBomQty =calculateBOMQty(slBomQty);
			String sBuom	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_BUOM));
			String sDSO	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE));
			String[] saDSO=sDSO.split(ConstantsUtil.SYMBL_PIPE);
			StringList	slDSO=util.MapsType(saDSO);

			StringList	slSapSubType=getSubTYpe(slDSO);
			sSapSubType = validator.isNotNullOrEmpty(slSapSubType.toString()) ? slSapSubType.toString(): ConstantsUtil.EMPTY_STRING;
			String sTitle	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_TITLE));


			//MAP SUBTYPE from its short form to Full Description
			String[] aSubType = sType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			StringBuffer sbSubType = new StringBuffer();
			for(String subType: aSubType) {
				sType = util.mapType(subType);
				sbSubType.append(sType).append(ConstantsUtil.SYMBL_PIPE);	
			}
			mpPartSpecs.put(ConstantsUtil.TYPE, sbSubType.toString());
			mpPartSpecs.put(ConstantsUtil.NAME, sName);
			mpPartSpecs.put(ConstantsUtil.SPECIFICATIONSUBTYPE, util.replaceSpecialSymbols(sSapSubType));
			mpPartSpecs.put(ConstantsUtil.TITLE, sTitle);
			mpPartSpecs.put(ConstantsUtil.SAPTYPE, sSapType);
			mpPartSpecs.put(ConstantsUtil.BOMQUANTITY, sBomQty);
			mpPartSpecs.put(ConstantsUtil.BASEUNITOFMEASURE, sBuom);
			mpPartSpecs.put(ConstantsUtil.SUBSTITUTIONGROUPING, ConstantsUtil.EMPTY_STRING);
			mpPartSpecs.put(ConstantsUtil.PHASE, sRelPhase);
			mpPartSpecs.put(ConstantsUtil.STATE, sState);

		} catch (Exception e) {
			LOGGER.error("Exception in: Program : FormulaPartBO Method :getSapBomAsFed "+e);
			return new HashMap();
		}
		return mpPartSpecs;
	}


	/**
	 * Method Name 			: addMultiValueConstants
	 * Method Description 	:
	 */
	@SuppressWarnings("unchecked")
	public StringList addMultiValueConstants(){
		
		StringList slMultiSelects = new StringList();

		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_NAME);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_CURRENT);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_TITLE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_TYPE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_SAPSUBTYPE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_BOMQTY);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_BUOM);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_RELEASE_PHASE);

		slMultiSelects.add(ConstantsUtil.SELECT_COMP_MATERIAL_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE);
		slMultiSelects.add(ConstantsUtil.COMP_STATE);
		slMultiSelects.add(ConstantsUtil.COMP_REVS);
		slMultiSelects.add(ConstantsUtil.COMP_DESC);
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_ID);

		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_NAME); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_CT_NUM); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS); 	
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_MANU_SITE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PACK_SITE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PLANT_REST); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REG_DATE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REG_STATUS); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME);

		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);

		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALLEADTIME);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALSTATUS);
		slMultiSelects.add(ConstantsUtil.strIntendedMarket);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);

		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);

		slMultiSelects.add(ConstantsUtilIRM.STR_COUNTRY_PGMARKETAPPROVALHOLDER);
		slMultiSelects.add(ConstantsUtilIRM.STR_COUNTRY_PGLEGELENTITY);
		slMultiSelects.add(ConstantsUtilIRM.STR_COUNTRY_PGBUSINESSCHANNEL);
		slMultiSelects.add(ConstantsUtilIRM.STR_COUNTRY_PGPACKSIZEUOM);
		slMultiSelects.add(ConstantsUtilIRM.STR_COUNTRY_PGPACKSIZE);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		slMultiSelects.add(ConstantsUtil.CERTIFICATION_NAME);
		
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR);
		
		return slMultiSelects;
	}


	/**
	 * Method Name 			: removeMultiValueConstants
	 * Method Description 	:
	 */
	public void removeMultiValueConstants(){

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_SAPSUBTYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_BOMQTY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_BUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_RELEASE_PHASE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COMP_MATERIAL_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_NAME); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_CT_NUM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS); 	
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_MANU_SITE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PACK_SITE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PLANT_REST); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REG_DATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REG_STATUS); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);
// Guna commented for Defect 37202  18x.5.2 Release -- START
		/*DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE);
*/
// Guna commented for Defect 37202  18x.5.2 Release -- END
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		
		//SPEC:11/23/2020: Added for defect 37522 by Amman ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALLEADTIME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALSTATUS);
		//SPEC:11/23/2020: Added for defect 37522 by Amman ## -- END
		

		//SPEC:12/04/2020: Added for Defect comma issue by Chandra  ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.strIntendedMarket);
		//SPEC:12/04/2020: Added for Defect comma issue by Chandra  ## -- END
		// Guna modified for Defect 37202  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID);
		// Guna modified for Defect 37202  18x.5.2 Release -- END
		// Guna Added for Defect 38531  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		// Guna Added for Defect 38531  18x.5.2 Release -- END

		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Jwala -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Jwala -- END
		
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 03 March 2021 -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.STR_COUNTRY_PGMARKETAPPROVALHOLDER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.STR_COUNTRY_PGLEGELENTITY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.STR_COUNTRY_PGBUSINESSCHANNEL);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.STR_COUNTRY_PGPACKSIZEUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.STR_COUNTRY_PGPACKSIZE);
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 03 March 2021 -- END
		//SPEC: <29.03.2021>: Guna Added for Defect 41220 Dev 18x.6   -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS);
		//SPEC: <29.03.2021>: Guna Added for Defect 41220 Dev 18x.6   -- END
	}


	/**
	 * Method Name 			: getSubstitute
	 * Method Description 	:
	 * @param mapList
	 * @return
	 */
	public Map<String, String> getSubstitute(MapList mapList) 
	{

		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();

		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentRev = new StringBuilder();
		StringBuilder sbEBOMParentTitle = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMRefDoc= new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMSubType= new StringBuilder();
		StringBuilder sbEBOMEffectDate= new StringBuilder();
		StringBuilder sbEBOMUntilDate= new StringBuilder();
		StringBuilder sbEBOMCobNum= new StringBuilder();
		StringBuilder sbEBOMChildRev= new StringBuilder();
		StringBuilder sbEBOMTupName= new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			String sChildExists=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
			if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)){
				String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
				String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
				String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
				String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				sChildType = util.mapType(sChildType);
				
				//Modified for Defect# 37591 -- START
				//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
				String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
				//Modified for Defect# 37591 -- END

				String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
				String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
				String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
				String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
				String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
				String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));

				String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
				String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);


				formatData(sbEBOMParentType,sParentType);
				formatData(sbEBOMParentId,sParentID);
				formatData(sbEBOMId,sChildId);

				formatData(sbEBOMParentName,sParentName);
				formatData(sbEBOMParentRev,sParentRev);
				formatData(sbEBOMParentTitle,sParentTitle);
				formatData(sbEBOMName,sChildName);
				formatData(sbEBOMChildRev,sChildRev);
				formatData(sbEBOMCobNum,sCombinationNum);
				formatData(sbEBOMTitle,sChildTitle);
				formatData(sbEBOMType,sChildType);
				formatData(sbEBOMSubType,sSUBType);
				formatData(sbEBOMQTY,sQTY);
				formatData(sbEBOMBuom,sBASEUOM);
				formatData(sbEBOMEffectDate,sEffectvityDate);
				formatData(sbEBOMUntilDate,sUntilDate);
				formatData(sbEBOMRefDoc,sRefDoc);
				formatData(sbEBOMCommnts,sComments);

			}
		}

		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
		mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
		mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
		mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
		mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());

		return mpEBOMResult;

	}
	/**
	 * Method Name 			: getCountryClearanceResult
	 * Method Description 	: 
	 * @param resultMaps
	 * @return
	 */
	public Map getCountryClearanceResult(Map resultMaps)
	{

		Map<String, String> mapCountryClearanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{

			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 04 Mar 2021 -- START
			//Replacing all getEquivalentString with new method getEquivalentStringFromMapValue
			String strMarketName    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_NAME));
			String strClearanceNum    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_CT_NUM));
			String strOveralClearence    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE));
			String strGPSApproval   =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS));
			String strManuSite    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_MANU_SITE));
			String strPackSite    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_PACK_SITE));
			String strComments    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT));
			String strRestrictions    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_PLANT_REST));
			String strRegExpDate    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REG_DATE));
			String strRegStatus    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REG_STATUS));
			String strMPDTNumber    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM));
			String strPRODRegClass    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS));
			
			//SPEC:11/23/2020: Commented for defect 37522 by Amman ## -- START
			//String strRegrewlleadTime    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE));
			//String strRegirewlStatus    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY));
			//SPEC:11/23/2020: Commented for defect 37522 by Amman ## -- END
			
			String strRegProductName    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME));

			//SPEC:11/23/2020: Added for defect 37522 by Amman ## -- START
			String strRegrewlleadTime    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALLEADTIME));
			String strRegirewlStatus    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTRATIONRENEWALSTATUS));
			//SPEC:11/23/2020: Added for defect 37522 by Amman ## -- END
			
			
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- START
			String strMarketApprovalHolder    =  validator.getEquivalentString(resultMaps.get(ConstantsUtilIRM.STR_COUNTRY_PGMARKETAPPROVALHOLDER));
			String strLegalEntity    =  validator.getEquivalentString(resultMaps.get(ConstantsUtilIRM.STR_COUNTRY_PGLEGELENTITY));
			String strBusinessChannel    =  validator.getEquivalentString(resultMaps.get(ConstantsUtilIRM.STR_COUNTRY_PGBUSINESSCHANNEL));
			String strPackSize    =  validator.getEquivalentString(resultMaps.get(ConstantsUtilIRM.STR_COUNTRY_PGPACKSIZE));
			String strPackSizeUOM    =  validator.getEquivalentString(resultMaps.get(ConstantsUtilIRM.STR_COUNTRY_PGPACKSIZEUOM));
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 04 Mar 2021 -- START
			
			mapCountryClearanceResult.put(ConstantsUtilIRM.MARKET_APPROVAL_HOLDER, UIUtil.isNotNullAndNotEmpty(strMarketApprovalHolder)? strMarketApprovalHolder : DomainConstants.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtilIRM.LEGEL_ENTITY, UIUtil.isNotNullAndNotEmpty(strLegalEntity)? strLegalEntity : DomainConstants.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtilIRM.BUSINESS_CHANNEL, UIUtil.isNotNullAndNotEmpty(strBusinessChannel)? strBusinessChannel : DomainConstants.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtilIRM.PACK_SIZE, UIUtil.isNotNullAndNotEmpty(strPackSize)? strPackSize : DomainConstants.EMPTY_STRING);
			mapCountryClearanceResult.put(ConstantsUtilIRM.PACK_SIZE_UOM, UIUtil.isNotNullAndNotEmpty(strPackSizeUOM)? strPackSizeUOM : DomainConstants.EMPTY_STRING);
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- END
			mapCountryClearanceResult.put(ConstantsUtil.MARKET_NAME, strMarketName);
			mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, strClearanceNum);
			mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, strOveralClearence);
			mapCountryClearanceResult.put(ConstantsUtil.GPS_APPROVAL, strGPSApproval);
			mapCountryClearanceResult.put(ConstantsUtil.MANU_SITE, strManuSite);
			mapCountryClearanceResult.put(ConstantsUtil.PACK_SITE, strPackSite);
			mapCountryClearanceResult.put(ConstantsUtil.COMMENTS, strComments);
			mapCountryClearanceResult.put(ConstantsUtil.RESTRICTIONS, strRestrictions);
			mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, strRegExpDate);
			mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, strRegStatus);
			mapCountryClearanceResult.put(ConstantsUtil.MARKETPRODUCTNUMBER, strMPDTNumber);
			mapCountryClearanceResult.put(ConstantsUtil.PROD_REG_CLASS, strPRODRegClass);
			mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALLEADTIME, strRegrewlleadTime);
			mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALSTATUS, strRegirewlStatus);
			mapCountryClearanceResult.put(ConstantsUtil.REGISTEREDPRODUCTNAME, strRegProductName);

		}catch(Exception e){

			LOGGER.error("Error from FormulaPartBO:  getCountryClearanceResult"+e);
			return new HashMap();
		}
		return mapCountryClearanceResult;
	}
	
	/**
	 * Method Name 			: formatData
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}

	
	/**
	 * Method Name 			: getSubTYpe
	 * Method Description 	:
	 * @param slData
	 * @return
	 */
	private StringList getSubTYpe(StringList slData) {
		StringList slMapType = new StringList();
		String sType = ConstantsUtil.SPEC_SUB_TYPE;
		for(int i=0 ;i<slData.size();i++){
			String sDType = slData.get(i);
			if(!ConstantsUtil.DSO.equals(sDType)){
				slMapType.add(sType);
			}else{
				slMapType.add(ConstantsUtil.EMPTY_STRING);
			}

		}

		return slMapType;
	}
	

	//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	: Fetching "Substances" related data 
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) 
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID); 
		busSelect.add(ConstantsUtil.COMP_NAME);
		busSelect.add(ConstantsUtil.COMP_SUBNAME);
		busSelect.add(ConstantsUtil.COMP_TITLE);
		busSelect.add(ConstantsUtil.COMP_MAXHGHT);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT);
		busSelect.add(ConstantsUtil.COMP_QUOM);
		busSelect.add(ConstantsUtil.COMP_QTY);
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);
		busSelect.add(ConstantsUtil.COMP_CASNUM);
		busSelect.add(ConstantsUtil.COMP_STATE);
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC);
		busSelect.add(ConstantsUtil.COMP_DRYWEIGHT);
		busSelect.add(ConstantsUtil.COMP_FUNCTIONS);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_CURRENT);
		
		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		 
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related information
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	
	
	/**
     * Method Name 			: getCOName
     * Method Description 	: 
     * @param context
     * @param changeargs
     * @return
     * @throws Exception
     */
	/*// SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- START
    public Map getCOName(Context context, String[]changeargs) throws Exception{
		Map mpLifecycle= new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();

		StringList slObjectSelects = new StringList();
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_NAME);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_ID);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_TITLE);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_APPROVER);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_STATUS);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_COMPL_DATE);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVER_NAME);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_STATUS);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_DATE);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_TITLE);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_COMMENTS);

		StringBuilder sbCOName= new StringBuilder();
		StringBuilder sbTaskName = new StringBuilder();			
		StringBuilder sbTaskApprover = new StringBuilder();
		StringBuilder sbTaskApproverFullName = new StringBuilder();
		StringBuilder sbTaskTitle = new StringBuilder();			
		StringBuilder sbTaskStatus = new StringBuilder();			
		StringBuilder sbTaskCompletionDate = new StringBuilder();
		StringBuilder sbTaskId = new StringBuilder();
		StringBuilder sbTaskComments = new StringBuilder();

		String sCAName = ConstantsUtil.EMPTY_STRING;
		String sCAId = ConstantsUtil.EMPTY_STRING;
		String sCOName = ConstantsUtil.EMPTY_STRING;
		try {
			if (UIUtil.isNullOrEmpty(changeargs[1])) {
				return new HashMap();
			}
			String sQuery =BusExtractUtil.createQueryPath(changeargs[1]);
			String sQueryResult =BusExtractUtil.executeTempQuery(context,sQuery);

			if(UIUtil.isNullOrEmpty(sQueryResult)){
				return new HashMap();
			}
			String[] sQueResult = sQueryResult.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

			if (sQueResult.length > 2) {
				sCAName = sQueResult[1];
				sCAId = sQueResult[2];
			}

			if (sQueResult.length > 3) {
				sCOName = sQueResult[3];
			}

			if (UIUtil.isNotNullAndNotEmpty(sCAId)) {

				DomainObject domChangeAction = new DomainObject(sCAId);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_NAME);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_ID);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_TITLE);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_APPROVER);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_STATUS);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_COMPL_DATE);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_COMMENTS);

				Map mapCAInfo = domChangeAction.getInfo(context, slObjectSelects);

				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_NAME);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_ID);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_TITLE);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_APPROVER);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_STATUS);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_COMPL_DATE);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_COMMENTS);

				if (mapCAInfo.isEmpty()) {
					return new HashMap();
				}
				sbTaskName
				.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_NAME)));
				sbTaskId.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_ID)));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
				//sbTaskTitle.append(
				//		validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_TITLE)));
				sbTaskTitle.append(
						validator.getEquivalentString(mapCAInfo.get(ConstantsUtil.REL_TASK_TITLE)));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
				
				sbTaskStatus.append(
						validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_STATUS)));
				sbTaskApprover.append(
						validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_APPROVER)));
				
				//SPEC: <11.19.2020>: Added by Guna for Defect:37488  ## -- START
				sbTaskComments.append(
						validator.getStringEquivalentForStringListWithComma(mapCAInfo.get(ConstantsUtil.REL_TASK_COMMENTS)));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
				//sbTaskComments.append(util.getLifeCycleComment(mapCAInfo));
				sbTaskComments.append(
						validator.getEquivalentString(mapCAInfo.get(ConstantsUtil.REL_TASK_COMMENTS)));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
				
				//SPEC: <11.19.2020>: Added by Guna  for Defect:37488  ## -- END
				
				
				
				String sApproverName = validator
						.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVER_NAME));
				String sApprovalStatus = validator
						.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_STATUS));

				if (sApprovalStatus.equalsIgnoreCase(ConstantsUtil.TRUE)
						|| sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
					sApprovalStatus = ConstantsUtil.APPROVED;
				} else if (sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_FALSE)
						|| sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
					sApprovalStatus = ConstantsUtil.IGNORED;
				} else {
					sApprovalStatus = "";

				}
				//Added for 37475 defect -- START
			
				String strApprover =validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_APPROVER));
               strApprover = strApprover.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
               //Added for 37475 defect -- END
               String sApprovedDate = validator
						.isNotNullOrEmpty((String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_DATE))
						? (String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_DATE) : ConstantsUtil.EMPTY_STRING;
						
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
						//String sApprovalTitle = validator
						//		.isNotNullOrEmpty((String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE))
						//		? (String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE) : ConstantsUtil.EMPTY_STRING;
						String sApprovalTitle = validator
								.getEquivalentString(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE));
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
								
								sbTaskName.append(ConstantsUtil.SYMBL_PIPE);
								sbTaskName.append(ConstantsUtil.SO_APPROVAL_SIGNATURE);

								sbTaskStatus.append(ConstantsUtil.SYMBL_PIPE);
								sbTaskStatus.append(sApprovalStatus);
								sbTaskTitle.append(ConstantsUtil.SYMBL_PIPE);
								sbTaskTitle.append(sApprovalTitle);

								// For eliminating the SO Approver name in Ownership
								mpLifecycle.put(ConstantsUtil.APPROVER_FULLNAME, strApprover);

								sbTaskApprover.append(ConstantsUtil.SYMBL_PIPE);
								sbTaskApprover.append(sApproverName);

								StringList slTaskApproverFullName = util.getPersonFullName(context, sbTaskApprover);

								// slTaskApprover.remove(sApproverName);
								StringBuilder sbTaskStatusRendered = util.MapSlType(sbTaskStatus);

								StringList slTaskCompletionDate = validator
										.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_COMPL_DATE));
								slTaskCompletionDate.add(sApprovedDate);

								String strTaskApproverFullName = validator.isNotNullOrEmpty(slTaskApproverFullName.toString())
										? slTaskApproverFullName.toString() : ConstantsUtil.EMPTY_STRING;
										String strTaskCompletionDate = validator.isNotNullOrEmpty(slTaskCompletionDate.toString())
												? slTaskCompletionDate.toString() : ConstantsUtil.EMPTY_STRING;
												strTaskApproverFullName = util.replaceSpecialSymbols(strTaskApproverFullName);
												strTaskCompletionDate = util.replaceSpecialSymbols(strTaskCompletionDate);
												
												//SPEC: 15/01/2021: Added for 18x.5 DEV -- START
												String strApprovalFinalDueDate = ConstantsUtil.EMPTY_STRING;
												String strApprovalDueDate = ConstantsUtil.EMPTY_STRING;
												StringList slTaskApprovalDueDate = new StringList();
												if (UIUtil.isNotNullAndNotEmpty(strTaskCompletionDate)) {
													if (strTaskCompletionDate.contains(ConstantsUtil.SYMBL_PIPE)) {
														slTaskApprovalDueDate = FrameworkUtil.split(strTaskCompletionDate, ConstantsUtil.SYMBL_PIPE);	
														for (int k = 0; k < slTaskApprovalDueDate.size(); k++) {
															strApprovalDueDate = (String) slTaskApprovalDueDate.get(k);																
															strApprovalDueDate = validator.DateFormatter(strApprovalDueDate);																
															strApprovalFinalDueDate += strApprovalDueDate+ConstantsUtil.SYMBL_PIPE;
														}															
														strApprovalFinalDueDate = strApprovalFinalDueDate.replace(ConstantsUtil.SYMBL_PIPE + ConstantsUtil.EMPTY_STRING, ConstantsUtil.SYMBL_PIPE);
														mpLifecycle.put(ConstantsUtil.APPROVALDATE, strApprovalFinalDueDate);	
													}
													else {
														strTaskCompletionDate = validator.DateFormatter(strTaskCompletionDate);
														mpLifecycle.put(ConstantsUtil.APPROVALDATE, strTaskCompletionDate);															
													}
												}
												//SPEC: 15/01/2021: Added for 18x.5 DEV -- END	

												mpLifecycle.put(ConstantsUtil.NAME, sbTaskName.toString());
												mpLifecycle.put(ConstantsUtil.APPROVER, strTaskApproverFullName);

												mpLifecycle.put(ConstantsUtil.TITLE, sbTaskTitle.toString());
												mpLifecycle.put(ConstantsUtil.APPROVALSTATUS, sbTaskStatusRendered.toString());
												//mpLifecycle.put(ConstantsUtil.APPROVALDATE, strTaskCompletionDate);
												mpLifecycle.put(ConstantsUtil.CO, sCOName.trim() + ConstantsUtil.SYMBL_PIPE + sCAName.trim());
												mpLifecycle.put(ConstantsUtil.COMMENTS, sbTaskComments.toString());
			}

		} catch (Exception e) {
			LOGGER.info("Error in InnerPackBO method getCOName " + e);
			return new HashMap();
		}
		return mpLifecycle;
	}
 // SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- END
*/    
    /**
     * Method Name 			: getMasterSpecs
     * Method Description 	:
     * @param context
     * @param sObjectId
     * @return
     */
    public Map<String, String> getMasterSpecs(Context context, String sObjectId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpMasterSpecs = new HashMap<String, String>();
		String sMasterObjectId = ConstantsUtil.EMPTY_STRING;
		String sMasterObjectClassfiedItem = ConstantsUtil.EMPTY_STRING;
		try {
			DomainObject domChild = new DomainObject(sObjectId);
			sMasterObjectId = domChild.getInfo(context, ConstantsUtil.STR_MASTER_ID);

			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtil.STR_MASTER_ID);
			slSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			Map mp = domChild.getInfo(context, slSelects);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domChild.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			if (!mp.isEmpty()) {
				sMasterObjectId = validator.getStringEquivalentForStringList(mp.get(ConstantsUtil.STR_MASTER_ID));
				sMasterObjectClassfiedItem = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME));
			}

			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			if (UIUtil.isNotNullAndNotEmpty(sMasterObjectId)) {
				mpMasterSpecs = getMasterPartSpecifications(context, sMasterObjectId, sMasterObjectClassfiedItem);
			} else {
				return new HashMap();
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FormulaPartBO Method :getMasterSpecs " + e);
			return new HashMap();
		}
		return mpMasterSpecs;
	}
    
    
    /**
     * Method Name 			: getMasterPartSpecifications
     * Method Description 	:
     * @param context
     * @param sObjectID
     * @param sMasterObjectClassfiedItem
     * @return
     * @throws Exception
     */
    public Map<String, String> getMasterPartSpecifications(Context context, String sObjectID,
			String sMasterObjectClassfiedItem) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringBuilder sbMasterPartName = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION + "," + ConstantsUtil.REL_PG_INHERITED_CAD_SPEC,
					ConstantsUtil.SYMBL_ASTERISK, slPartSpecSelects, null, false, true, (short) 1, sWhere,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String sIpClass =validator.getStringEquivalentForStringList((mpEachObj.get(ConstantsUtil.STR_IPCLASS)));

				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				
				String strMasterPartName = ConstantsUtil.EMPTY_STRING;
				String strMasterPart = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.strPARTSPEC));
				if(strMasterPart.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART)) {
					strMasterPartName = strMasterPart;
				}
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;

				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}
				
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END	
			
				
				if (util.isModificatinRequired())
				{   
					//commented by Ganesh for security impl------>start

					/*if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) 
					{
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								
								//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
								String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
								
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
							}
						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = util.updateReferences(context, strId);
								LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
									String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
									//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
								}
							}
						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {*/
						// bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
					//commented by Ganesh for security impl------>end
						// Added by Ganesh 1.0.2 Release start
						bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
						// Added by Ganesh 1.0.2 Release start
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
							/*String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
							//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
							String strPhase = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);

						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}

					//}
				}else if(sct.isStaffAUGUser()) {

					/*
					 * if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) ||
					 * strType.equalsIgnoreCase("Formulation Part")){ String sFormulaClassif =
					 * util.getFormulaPropagateClassification(context, strId);
					 * showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif); }else {
					 * showData=util.checkInternalUserAcess(sUserlicense,sIpClass); }
					 */
					// Added by Ganesh 1.0.2 Release start
					showData = util.checkHasAccess(context, sUserType, strId);
					// Added by Ganesh 1.0.2 Release End

					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
						/*String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
						//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					}

				} else {
					if (sIPClassfication.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED)) {
						// showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						// Added by Ganesh 1.0.2 Release start
						showData = util.checkHasAccess(context, sUserType, strId);
						// Added by Ganesh 1.0.2 Release End
						/*
						 * if (null != sUserlicense && null != strClassFied &&
						 * !sUserlicense.contains(strClassFied.trim())) { showData = false; }
						 */

						if (showData) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
							/*String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
							//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {

						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
						/*String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
						//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
					}

				}

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			mpFinalList.put(ConstantsUtil.MASTERPARTNAME, sbMasterPartName.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Exception in FormulaPartBO getMasterPartSpecifications: " + e);
			return new HashMap();
		}
		return util.filterMapList(mpFinalList);
	}
    
    
    /**
     * Method Name 			: updatePartSpec
     * Method Description 	:
     * @param context
     * @param objectMap
     * @return
     */
    public Map updatePartSpec(Context context, Map objectMap) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

							mpPartSpecs = getPartSpecifications(context, sType, sID);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FormulaPartBO Method :updatePartSpec " + e);
			return new HashMap();

		}
		return util.filterMapList(mpPartSpecs);
	}
    
    
    /**
     * Method Name 			: getPartSpecifications
     * Method Description 	:
     * @param context
     * @param sParentType
     * @param sObjectID
     * @return
     * @throws Exception
     */
    public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		boolean showData = false;
		
		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;
		
		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
			sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		}

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
					slPartSpecSelects, null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}
				
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END	
			
				if (util.isModificatinRequired()) {
					if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {
                        //modified by Ganesh for security impl----->start
						//bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
						//modified by Ganesh for security impl----->end
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								
								//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
								//String strTitle = validator.getStringEquivalentForStringList(
								//		mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								String strTitle = validator.getStringEquivalentForSubstituteString(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
								
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
								/*String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
								//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							}

						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

						}

					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
						//modified by Ganesh for security impl---->start
						bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
						//modified by Ganesh for security impl---->end
						//bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = util.updateReferences(context, strId);
								LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
									//String strTitle = validator.getStringEquivalentForStringList(
									//		mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									String strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
									/*String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
									//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

								}
							}
						}else
						{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {
						//modified by Ganesh for security impl----------->start
						//bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						bHasOwnerShip = util.checkHasAccess(context, null, strId);
						//modified by Ganesh for security impl----------->end
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
							//String strTitle = validator.getStringEquivalentForStringList(
							//		mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
							/*String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
							//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					}

				} else {
					//commented by Ganesh for security impl----start
					/*if(sct.isStaffAUGUser()) {
						
						if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else if("ArtiosCAD Component".equalsIgnoreCase(strType)){
							showData=util.checkInternalUserAcess(sUserlicense,strAutocadClassFied);
						}else{
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
						
						if(slHIRTypes.contains(strType)) {
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}else {
							showData=true;
						}
						
					}*/
					//commented by Ganesh for security impl----end
					//modified by Ganesh for security impl----start
					showData = util.checkHasAccess(context, sUserType, strId);
					//modified by Ganesh for security impl----end
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- START
						//String strTitle = validator.getStringEquivalentForStringList(
						//		mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman-- END
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						//temporary fix to prevent users from downloading a Physical product(VPMReference)
						if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
							sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
						}else {
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
							/*String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
							//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
						}
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					}
				}
			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
				mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
				mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			}

		} catch (FrameworkException e) {
			LOGGER.error("Exception in FormulaPartBO getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}
    
    
    /**
	 * Method Name 			: updateSecurity
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
	/*public Map<String, String> updateSecurity(Map objectMap) {
		
		Map<String, String> mpSecurity = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			String sName=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME));
			String sLibrary=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME));
			String sCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE));
			String sType=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE));
			String sDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC));
			String Name[]=sName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			String Library[]=sLibrary.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			String Type[]=sType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			
			StringBuilder sbHasAccess = new StringBuilder();
			
			if(!sType.isEmpty()){
				
				for (int i = 0; i < Type.length; i++)
				{
					
					if(UIUtil.isNotNullAndNotEmpty(Name[i]) && UIUtil.isNotNullAndNotEmpty(Library[i]))
					{
						sbSecurityClasspath.append(Library[i]).append(ConstantsUtil.SYMBL_ARROW).append(Name[i]);
						mpSecurity.put(ConstantsUtil.CLASSPATH, sbSecurityClasspath.toString());
					}else
					{
						sbSecurityClasspath.append(ConstantsUtil.EMPTY_STRING);
					}
					
					if (UIUtil.isNotNullAndNotEmpty(Type[i])) {
						if ((sType).equalsIgnoreCase(ConstantsUtil.TYPE_SECURITYCONTROLCLASS)) {
							sbHasAccess.append("TRUE");
							
						}
						else {
							sbHasAccess.append("FALSE");
						}
					}
				}
			} 
			
			mpSecurity.put(ConstantsUtil.TYPE, sType);
			mpSecurity.put(ConstantsUtil.NAME, sName);
			mpSecurity.put(ConstantsUtil.STATE, sCurrent);
			mpSecurity.put(ConstantsUtil.DESCRIPTION, sDesc);
			mpSecurity.put(ConstantsUtil.HASCLASSACCESS, sbHasAccess.toString());
			//mpSecurity.put(ConstantsUtil.LIBRARY, sLibrary);
		
		}catch(Exception e){
			LOGGER.error("Error from InnerPackBO: updateSecurity"+e);
			return new HashMap();
		}
		return  mpSecurity;
	}*/
	
// New method written to get Security Clasess  by Jwala for Defect #41638 & 41608
    /**
	 * Method Name 			: updateSecurity
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
    public Map<String, String> updateSecurity(Context context, String strFormulationID) {

    	Map<String, String> mpSecurity = new HashMap<String, String>();
    	StringValidatorUtil validator = new StringValidatorUtil();
    	try
    	{
    		if(UIUtil.isNotNullAndNotEmpty(strFormulationID)){
    			DomainObject domFOPId = DomainObject.newInstance(context,strFormulationID);

    			StringList slSelects = new StringList();

    			slSelects.addElement(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
    			slSelects.addElement(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
    			slSelects.addElement(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
    			slSelects.addElement(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);

    			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
    			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
    			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
    			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);

    			Map objectMap = domFOPId.getInfo(context, slSelects);

    			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
    			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
    			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
    			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);

    			String sName=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME));
    			String sCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE));
    			String sType=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE));
    			String sDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC));

    			mpSecurity.put(ConstantsUtil.TYPE, sType);
    			mpSecurity.put(ConstantsUtil.NAME, sName);
    			mpSecurity.put(ConstantsUtil.STATE, sCurrent);
    			mpSecurity.put(ConstantsUtil.DESCRIPTION, sDesc);
    		}
    	}catch(Exception e){
    		LOGGER.error("Error from InnerPackBO: updateSecurity"+e);
    		return new HashMap();
    	}
    	return  mpSecurity;
    }

	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		try
		{
			
			//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
			
			/*String sType    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REVS));
			String sDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sCurrent =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_STATE));
			sCurrent=sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String sCAS 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			String sSub 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SUBNAME));
			String sQTS 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QSTCOMPOSITE));
			String sCont    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_ISCONTAM));
			String sQTY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE));
			String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE));
			String sQUOM    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));	

			String sMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			String sMFR     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sTrN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sDRY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DRYWEIGHT));
			String sFunctions =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_FUNCTIONS));
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String sQTYtype = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sUF = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.EMPTY_STRING));*/
			
			
			String sType    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_ID));
			String sName	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sRev	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_REVS));
			String sDesc	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sTitle	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sCurrent =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_STATE));
			sCurrent=sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String sCAS 	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			String sSub 	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_SUBNAME));
			String sQTS 	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_QSTCOMPOSITE));
			String sCont    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_ISCONTAM));
			String sQTY     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sMAXWt   =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE));
			String sMInWt   =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE));
			String sQUOM    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_QUOM));	

			String sMlLgc   =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sPCED    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			String sMFR     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String sCMT     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sTrN     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sFN      =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			String sMLyr    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sDRY     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_DRYWEIGHT));
			String sFunctions =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_FUNCTIONS));
			String strPhase	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String sQTYtype = validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sUF = validator.getEquivalentString(resultMaps.get(ConstantsUtil.EMPTY_STRING));
			
			
			//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
			
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);

			sType = util.mapType(sType);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.REV,sRev);
			mpSubStanceResult.put(ConstantsUtil.STATE,sCurrent);
			mpSubStanceResult.put(ConstantsUtil.CAS,sCAS);
			//mpSubStanceResult.put(ConstantsUtil.SUBSTANCENAME,sSub);
			mpSubStanceResult.put(ConstantsUtil.QSTARGET,sQTS);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			//mpSubStanceResult.put(ConstantsUtil.IC,sCont);
			mpSubStanceResult.put(ConstantsUtil.IP,sCont);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.UOM,sQUOM);

			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sDRY);
			mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sFunctions);
			mpSubStanceResult.put(ConstantsUtil.PHASE, strPhase);
			//mpSubStanceResult.put(ConstantsUtil.QUANTITYTYPE, sQTS);
			mpSubStanceResult.put(ConstantsUtil.UF, sUF);

		}catch(Exception e){

			LOGGER.error("Error from FormulaPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	/**
	 * Method Name 			: getSapBOMasFed
	 * Method Description 	: It will return the connected SAP BOM
	 * @param context
	 * @param sID
	 * @return
	 */
	public Map getSapBOMasFed(Context context ,String sID){
		
		CalculateBOM clBom = new CalculateBOM();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		Map mapSapBomAsFedResult = new HashMap();
		
		SecurityService sct = new SecurityService();
		boolean isStaffAUg = sct.isStaffAUGUser();
		
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbSapType = new StringBuilder();
		StringBuilder sbSpecSubType = new StringBuilder();
		StringBuilder sbSpecGroup = new StringBuilder();
		StringBuilder sbBOMQTY = new StringBuilder();
		StringBuilder sbBuom = new StringBuilder();
		StringBuilder sbComnt = new StringBuilder();
		StringBuilder sbSAPDesc = new StringBuilder();
		StringBuilder sbAuthorized = new StringBuilder();
		StringBuilder sbAuthorizedToUse = new StringBuilder();
		StringBuilder sbAuthorizedToProduce = new StringBuilder();
		StringBuilder sbOC = new StringBuilder();
		StringBuilder sbTU = new StringBuilder();
		StringBuilder sbMaxQTY = new StringBuilder();
		StringBuilder sbMinQTY = new StringBuilder();
		

		StringBuilder sbTUType = new StringBuilder();
		StringBuilder sbTUName = new StringBuilder();
		StringBuilder sbTUId = new StringBuilder();
		
		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		
		try
		{
			ArrayList alSapBom = performDataReadFromEnovia(context,sID);
			MapList ml = getTableData(context,alSapBom);
			
			sbSpecSubType = clBom.getSpecificationSubtype(context ,ml);
			Iterator objectListItr = ml.iterator();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sId =(String)objectMap.get(ConstantsUtil.MAP_KEY_ID);
				String sName =(String)objectMap.get(ConstantsUtil.NAME);
				String sTitle =(String)objectMap.get(ConstantsUtil.DESCRIPTION);
				String sType =(String)objectMap.get(ConstantsUtil.TYPE);
				String sSapType =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPTYPE);
				String sSpecGroup =(String)objectMap.get(ConstantsUtil.MAP_KEY_SUBSTITUTE);
				String sQty =(String)objectMap.get(ConstantsUtil.MAP_KEY_BOMQTY);
				String sBuom =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPUOM);
				String strClassFied = (String)objectMap.get(ConstantsUtil.SECURITY);
				String strControlClass = (String)objectMap.get(ConstantsUtil.OBJECTSECURITYCLASS);
				String strComment = (String)objectMap.get(ConstantsUtil.ATTRIBUTE_COMMENT);
				String strSAPDesc = (String)objectMap.get(ConstantsUtil.SAPDESCRIPTION);
				
				/*String strAuthorized = (String)objectMap.get(ConstantsUtil.AUTHORIZED);
				String strAuthorizedToUse = (String)objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE);
				String strAuthorizedToProduce = (String)objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE);
				String strOC = (String)objectMap.get(ConstantsUtil.OC);*/
				
				String strTUType = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_TYPE);
				String strTUName = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_NAME);
				String strTUId = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_ID);
				
				
				String strMaxQTY = (String)objectMap.get(ConstantsUtil.MAX);
				String strMinQTY = (String)objectMap.get(ConstantsUtil.MIN);
				
				String strOC = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.OC));
				String strAuthorizedToProduce =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE));
				String strAuthorizedToUse = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE));
				String strAuthorized = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZED));
				
				boolean bHasOwnership = false;
				String sUserlicense = sct.getUserLicense();
				String sFormulaPropagate = sId;
				
				if(sType.equals(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT) || sType.equals(ConstantsUtil.TYPE_FORMULA_CARD))
				{
					sId =ConstantsUtil.NO_ACCESS;
					sTitle =ConstantsUtil.NO_ACCESS;
					//sSapType =ConstantsUtil.NO_ACCESS;
					//sSpecGroup =ConstantsUtil.NO_ACCESS;
					//sQty =ConstantsUtil.NO_ACCESS;
					//sBuom =ConstantsUtil.NO_ACCESS;
					//strComment=ConstantsUtil.NO_ACCESS;
					
					strAuthorized=ConstantsUtil.NO_ACCESS;
					strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
					strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
					
					
			}
			else
			{
				if(util.isModificatinRequired())
				{
					//commented by Ganesh for security impl---->start
					/*SecurityService sec = new SecurityService();
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);

					//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sId);
					}
					
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}*/
					//commented by Ganesh for security impl---->end
					//commented by Ganesh for security impl---->start
					bHasOwnership = util.checkHasAccess(context, null, sId);
					//commented by Ganesh for security impl---->end
					if(!bHasOwnership)
					{
						sTitle = ConstantsUtil.NO_ACCESS;
						sId =ConstantsUtil.NO_ACCESS;
						sTitle =ConstantsUtil.NO_ACCESS;
						sSapType =ConstantsUtil.NO_ACCESS;
						sSpecGroup =ConstantsUtil.NO_ACCESS;
						sQty =ConstantsUtil.NO_ACCESS;
						sBuom =ConstantsUtil.NO_ACCESS;
						strComment=ConstantsUtil.NO_ACCESS;
						strSAPDesc=ConstantsUtil.NO_ACCESS;
						strAuthorized=ConstantsUtil.NO_ACCESS;
						strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
						strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
						strOC=ConstantsUtil.NO_ACCESS;
						strMaxQTY=ConstantsUtil.NO_ACCESS;
						strMinQTY=ConstantsUtil.NO_ACCESS;
					}
				}else if(isStaffAUg)
				{
					boolean showData = true;
					//commented by Ganesh for security impl----->start
					/*String sFormulaClassif =strControlClass;
					
						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}
						
						showData= util.checkLicenses(sUserlicense,sFormulaClassif);*/
					//commented by Ganesh for security impl----->end
					//Modified by Ganesh for security impl----->start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl----->end
						if(!showData)
						{
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}
							
						}
					
				}else{
			

					boolean showData = true;
					//commented by Ganesh for security impl----->start
					/*if(slHIRTypes.contains(sType) )
					{
						String sFormulaClassif =strClassFied;
						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) 
						{
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}
						showData= util.checkLicenses(sUserlicense,sFormulaClassif);
					}*/	
					//commented by Ganesh for security impl----->end
					//modified by Ganesh for security impl----->start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl----->end
						
						if(!showData)
						{
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}

					}
				}
			}
				util.formatData(sbId,sId);
				util.formatData(sbName,sName);
				util.formatData(sbTitle,sTitle);
				util.formatData(sbType,util.mapType(sType));
				util.formatData(sbSapType,sSapType);
				util.formatData(sbSpecGroup,sSpecGroup);
				util.formatData(sbBOMQTY,sQty);
				util.formatData(sbBuom,sBuom);
				util.formatData(sbComnt,strComment);
				util.formatData(sbSAPDesc,strSAPDesc);
				util.formatData(sbAuthorized,strAuthorized);
				util.formatData(sbAuthorizedToUse,strAuthorizedToUse);
				util.formatData(sbAuthorizedToProduce,strAuthorizedToProduce);
				util.formatData(sbOC,strOC);
				util.formatData(sbMaxQTY,strMaxQTY);
				util.formatData(sbMinQTY,strMinQTY);
				
				util.formatData(sbTUType,strTUType);
				util.formatData(sbTUName,strTUName);
				util.formatData(sbTUId,strTUId);
			}

			mapSapBomAsFedResult.put(ConstantsUtil.NAME, sbName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.ID, sbId.toString());
			//mapSapBomAsFedResult.put(ConstantsUtil.TITLE, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TYPE, sbType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPTYPE, sbSapType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONGROUP, sbSpecGroup.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BOMQUANTITY, sbBOMQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbBuom.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.COMMENTS, sbComnt.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPDESCRIPTION, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZED, sbAuthorized.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOUSE, sbAuthorizedToUse.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, sbAuthorizedToProduce.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.OC,sbOC.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT,sbTU.toString());
			
			mapSapBomAsFedResult.put(ConstantsUtil.MAX,sbMaxQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.MIN,sbMinQTY.toString());

			
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_NAME,sbTUName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_TYPE,sbTUType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_ID,sbTUId.toString());
			
		}catch(Exception e){
			LOGGER.error("Exception in program FabricatedPartBO :getSapBOMasFed ");
		}
		return mapSapBomAsFedResult;
	}
	
	
	/**
	 * Method Name 			: performDataReadFromEnovia
	 * Method Description 	: 
	 * @param context
	 * @param sPartObjectID
	 * @return
	 * @throws Exception
	 */
	public synchronized ArrayList performDataReadFromEnovia(Context context,String sPartObjectID) throws Exception {

		Map 	mapPartDetails				= new HashMap();

		ArrayList alPartRelatedObjects 		= new ArrayList();
		String strSpecSubType = DomainConstants.EMPTY_STRING;
		String strFormulationType = DomainConstants.EMPTY_STRING;

		StringValidatorUtil BusinessUtil= new StringValidatorUtil();
		CalculateBOM clBom = new CalculateBOM();
		
		try {

			if(BusinessUtil.isNotNullOrEmpty(sPartObjectID)){

				DomainObject doPart = DomainObject.newInstance(context,sPartObjectID);
				StringList slBusSelect = new StringList(12);
				slBusSelect.add(DomainConstants.SELECT_TYPE);
				slBusSelect.add(DomainConstants.SELECT_NAME);
				slBusSelect.add(DomainConstants.SELECT_ID);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slBusSelect.add(ConstantsUtil.STR_IPCLASS);

				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slBusSelect.add("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
				slBusSelect.add("next.id");
				mapPartDetails = doPart.getInfo(context, slBusSelect);

				if(null != mapPartDetails && mapPartDetails.size()>0) {

					strSpecSubType = (String) mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					Object OFormulationType = (Object)mapPartDetails.get("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);

					StringList slFormulationType = new StringList();

					if (null != OFormulationType) {
						if (OFormulationType instanceof StringList) {
							slFormulationType = (StringList) OFormulationType;
						} else if (OFormulationType instanceof String) {
							slFormulationType.add(OFormulationType.toString());
						}
					}								
					if(clBom.doProdUsageCheckForeDelivery(context,mapPartDetails)) {

						String strPartType	=	(String)mapPartDetails.get(DomainConstants.SELECT_TYPE);

						if(BusinessUtil.isNotNullOrEmpty(strPartType)) {

							if(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equalsIgnoreCase(strPartType)) {

								alPartRelatedObjects = clBom.getPartObjectsFromEBOM(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_FORMULATIONPART.equalsIgnoreCase(strPartType) && !slFormulationType.isEmpty() && !slFormulationType.contains(ConstantsUtil.THIRD_PARTY_FORMULA) ) {
								alPartRelatedObjects = clBom.getObjectsForFOPFromFormulaIngredient(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(strPartType) || (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strPartType) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromIntermediateBOM(context,sPartObjectID);
							} else if(ConstantsUtil.TYPE_FABRICATEDPART.equalsIgnoreCase(strPartType) ||   ConstantsUtil.TYPE_INTERMEDIATEPRODUCTPART.equalsIgnoreCase(strPartType) || ((ConstantsUtil.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strPartType)) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromBOM(context,sPartObjectID);
							}
						}
					}
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return alPartRelatedObjects;
	}
	
	
	/**
	 * Method Name 			: getTableData
	 * Method Description 	: 
	 * @param context
	 * @param alPartObjectsWithGroupAndQty
	 * @return
	 * @throws Exception
	 */
	public MapList getTableData(Context context, ArrayList alPartObjectsWithGroupAndQty) throws Exception {
		MapList mpReturnList = new MapList();
		boolean isContextPushed = false;
		int OBJECT_ID = 27;
		int SUBSTITUTE_FLAG = 14;
		int QUANTITY = 10;
		int FC_MIN_QTY = 23;
		int FC_MAX_QTY = 25;
		int SORT_STRING = 13;
		int TUP_ID = 28;
		int OPT_COMPONENT = 29;
		
		//SPEC 11/05/2020 added for defect:37077 ##--START
			int INDEX_TPU_TYPE = 34;
			int INDEX_TPU_NAME = 35;
		//SPEC 11/05/2020 added for defect: 37077##--END
		
		try {
			StringList slPartSelect = new StringList(7);
			slPartSelect.addElement(DomainConstants.SELECT_NAME);
			slPartSelect.addElement(DomainConstants.SELECT_TYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slPartSelect.addElement(ConstantsUtil.STR_IPCLASS);
			slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			
			//slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
			//slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
			
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_IPCLASS);
			ContextUtil.pushContext(context);
			isContextPushed = true;
			if(null != alPartObjectsWithGroupAndQty) 
			{
				int alsize=alPartObjectsWithGroupAndQty.size();
				StringValidatorUtil validator = new StringValidatorUtil();
				String strObjID = null;
				String strSubstitute=null;
				String strBOMQuantity = null;
				String strMin = null;
				String strMax = null;
				String strPosInd = null;
				String strObjectType = null;
				String strSAPUOM = null;
				String strSAPType = null;
				String strPGCSSType = null;
				String strTUPObjID = null;
				String strIPClass = null;
				String strOptComponent = null;
				//String strAuthorized = null;
				//String strOC = null;
				//String strAuthorizedToUse = null;
				//String strAuthorizedToProduce = null;
				String strTransportUnit = null;
				DomainObject domObject = null;
				Map mpPartObjectInfo = null;
				int COMMENT = 30;
				String strComment = DomainConstants.EMPTY_STRING; 
				String strName = DomainConstants.EMPTY_STRING; 
				String strDescription = DomainConstants.EMPTY_STRING; 
				HashMap hmTemp = null;
				
				//SPEC 11/05/2020 added for defect: ##--START
				CalculateBOM clBom = new CalculateBOM();
				
				StringList slRelSelect = new StringList();
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
				//SPEC 11/05/2020 added for defect: ##--END
				
				String strTUPObjName = DomainConstants.EMPTY_STRING; 
				String strTUPObjType = DomainConstants.EMPTY_STRING;
				
				for (int i=0; i<alsize; i++) {
					String [] satemp = (String[]) alPartObjectsWithGroupAndQty.get(i);
					strObjID = satemp[OBJECT_ID];
					strSubstitute= satemp[SUBSTITUTE_FLAG];
					strBOMQuantity = satemp[QUANTITY];
					strMin = satemp[FC_MIN_QTY];
					strMax = satemp[FC_MAX_QTY];
					strPosInd = satemp[SORT_STRING];
					
					//SPEC 11/05/2020 added for defect: 37077##--START
					strTUPObjID = validator.getStringEquivalentForStringList(satemp[TUP_ID]);
					strTUPObjName = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_NAME]);
					strTUPObjType = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_TYPE]);
					//SPEC 11/05/2020 added for defect: 37077##--END
					String sqty = satemp[ConstantsUtil.INDEX_TARGET] ;	
					strOptComponent = satemp[OPT_COMPONENT];
					domObject = DomainObject.newInstance(context,strObjID);
					mpPartObjectInfo = domObject.getInfo(context, slPartSelect);
					strObjectType = (String)mpPartObjectInfo.get(DomainConstants.SELECT_TYPE);
					strSAPUOM = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					strSAPType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
					strPGCSSType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
					strComment = satemp[COMMENT];
					strName = (String)mpPartObjectInfo.get(DomainConstants.SELECT_NAME);
					strDescription = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					
					/*strAuthorized = (String)mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
					strAuthorizedToUse = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					strAuthorizedToProduce =  validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					strTransportUnit =  validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));*/
					//strOC = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
					
					strIPClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.STR_IPCLASS));
					String strIPControlClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
					
					//SPEC 11/05/2020 added for defect: ##--START
					MapList mlParentPlantList = clBom.getConnectedPlantList(context, strObjID, slRelSelect, null);
					
					boolean bTUPAccess=false;
					if(UIUtil.isNotNullAndNotEmpty(strTUPObjID)){
					 bTUPAccess = clBom.checkHasAccess(context,strTUPObjID);
					}
					
					if(!bTUPAccess){
						strTUPObjID=ConstantsUtil.NO_ACCESS;
					}
					
					StringList	slAVPlantList = new StringList();
					StringList	slAUPlantList = new StringList();
					StringList	slAPPlantList = new StringList();
					if(mlParentPlantList!=null && mlParentPlantList.size()>0)
					{
						for(int ip=0;ip<mlParentPlantList.size();ip++)
						{
							Map mapSAPBOMComponent = (Map)mlParentPlantList.get(ip);
							String	sAVAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
							String	sAUAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
							String	sAPAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
							String	sSAPBOMComponentPlantName = (String)mapSAPBOMComponent.get(DomainObject.SELECT_NAME);
							
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAVAttributeValue) && strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAVPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAUAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAUPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAPAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAPPlantList.add(sSAPBOMComponentPlantName);
							}
						}
					}
					
					String	strAVPlantList = DomainConstants.EMPTY_STRING;
					String	strAUPlantList = DomainConstants.EMPTY_STRING;
					String	strAPPlantList = DomainConstants.EMPTY_STRING;
					
					if(slAVPlantList!= null && slAVPlantList.size()>0)
					{
						strAVPlantList = FrameworkUtil.join(slAVPlantList, "&&&");
					}

					if(slAUPlantList!= null && slAUPlantList.size()>0)
					{
						strAUPlantList = FrameworkUtil.join(slAUPlantList, "&&&");
					}
					
					if(slAPPlantList!= null && slAPPlantList.size()>0)
					{
						strAPPlantList = FrameworkUtil.join(slAPPlantList, "&&&");
					}
					
					//SPEC 11/05/2020 added for defect: ##--END
					
					hmTemp = new  HashMap();
					hmTemp.put("id",strObjID);  
					hmTemp.put("type",strObjectType);  
					hmTemp.put("substitute",strSubstitute);
					hmTemp.put("BOMQty",strBOMQuantity);
					hmTemp.put("Min",strMin);
					hmTemp.put("Max",strMax);
					hmTemp.put("PosInd",strPosInd);
					hmTemp.put("SAPUOM",strSAPUOM);
					hmTemp.put("SAPType",strSAPType);
					hmTemp.put("SSType",strPGCSSType);
					hmTemp.put("dispId", strObjID);
					hmTemp.put("OptComponent", strOptComponent);
					hmTemp.put(ConstantsUtil.ATTRIBUTE_COMMENT, strComment);
					hmTemp.put(DomainConstants.SELECT_NAME, strName);
					hmTemp.put(DomainConstants.SELECT_DESCRIPTION, strDescription);
					hmTemp.put(ConstantsUtil.SECURITY, strIPClass);
					hmTemp.put(ConstantsUtil.OBJECTSECURITYCLASS, strIPControlClass);
					
					hmTemp.put(ConstantsUtil.AUTHORIZED, strAVPlantList);
					hmTemp.put(ConstantsUtil.OC, strOptComponent);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOUSE, strAUPlantList);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, strAPPlantList);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_TYPE, strTUPObjType);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_NAME, strTUPObjName);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_ID, strTUPObjID);
					mpReturnList.add(hmTemp);
				}
			}
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(isContextPushed) {
				ContextUtil.popContext(context);
				isContextPushed = false;
			}
		}
		return mpReturnList;
	}
	
	
	/**
	 * 
	 * @param context
	 * @param resultMaps
	 * @return
	 */

	public Map getDangerousProdcutValue(Context context,Map resultMaps)
	{
		Map mpDangerousProdcut = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();	

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();

		String strRev = ConstantsUtil.EMPTY_STRING;
		String strName = ConstantsUtil.EMPTY_STRING;
		String strTitle = ConstantsUtil.EMPTY_STRING;
		String strId = ConstantsUtil.EMPTY_STRING;
		String strTyp = ConstantsUtil.EMPTY_STRING;
		String strState = ConstantsUtil.EMPTY_STRING;
		String strPhase = ConstantsUtil.EMPTY_STRING;

		StringBuilder sbDGD = new StringBuilder();
		StringBuilder sbUNN = new StringBuilder();
		StringBuilder sbPSN = new StringBuilder();
		StringBuilder sbHC = new StringBuilder();
		StringBuilder sbPgroup = new StringBuilder();
		StringBuilder sbShipqty = new StringBuilder();
		StringBuilder sbCON = new StringBuilder();
		StringBuilder sbOPR = new StringBuilder();
		StringBuilder sbUSPGreq = new StringBuilder();
		StringBuilder sbCust = new StringBuilder();
		StringBuilder sbGCUP = new StringBuilder();
		StringBuilder sbGCOP = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbTN1 = new StringBuilder();
		StringBuilder sbTN2 = new StringBuilder();
		StringBuilder sbNo = new StringBuilder();
		
		StringList slProductSelects = new StringList();
		slProductSelects.add(ConstantsUtil.SELECT_NAME);
		slProductSelects.add(ConstantsUtil.SELECT_TYPE);
		slProductSelects.add(ConstantsUtil.SELECT_CURRENT);
		slProductSelects.add(ConstantsUtil.SELECT_REVISION);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		
		//SPEC: 10/29/2020: Added for 18x.5 DEV -- START
		
		slProductSelects.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		String sComp = sct.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		
		
		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		
		
		//SPEC: 10/29/2020: Added for 18x.5 DEV -- END
		
		StringList slHCPGSelects = new StringList();
		slHCPGSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC);
		slHCPGSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP);

		String strIdsObjectId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID));

		StringList slsObjectId = FrameworkUtil.split(strIdsObjectId, ConstantsUtil.SYMBL_PIPE);
		try
		{
			for(String strID:slsObjectId){

				String sObjectId = strID.trim();

				if(UIUtil.isNotNullAndNotEmpty(sObjectId))
				{
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- START
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- END
					DomainObject doProductPart = new DomainObject(sObjectId);
					Map mpTemp = doProductPart.getInfo(context, slProductSelects);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doProductPart.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- START
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- END
					strRev = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
					strName = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
					strTitle = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					strId = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ID));
					strTyp = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
					strState = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_CURRENT));
					strPhase = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
					
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- START
					String sIpClass = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
					
					boolean bHasOwnership =false;
					boolean showData =true;
					
					if(util.isModificatinRequired())
					{
						//bHasOwnership = util.checkOwnerShip(context, slUserOwnership, strId);
						//modified by Ganesh for security impl----->start
						bHasOwnership = util.checkHasAccess(context, null, strId);
						//modified by Ganesh for security impl----->end
						if(!bHasOwnership)
						{
							strId = ConstantsUtil.NO_ACCESS;
					    }
					}//commented by Ganesh for security impl----->start
					/*else if(sct.isStaffAUGUser()) 
					{
						if(strTyp.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strTyp.equalsIgnoreCase("Formulation Part") ) {
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else {
							showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
						}
					}else 
					{
						if(slHIRTypes.contains(strTyp)) 
						{
							if(strTyp.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)|| strTyp.equalsIgnoreCase("Formulation Part")) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}
						}else {
							showData=true;
						}
					}*/
					//commented by Ganesh for security impl----->end
					//modified by Ganesh for security impl----->start
					else {
					showData = util.checkHasAccess(context, null, strId);
					}
					//modified by Ganesh for security impl----->end
					
					if(!showData){
						strId = ConstantsUtil.NO_ACCESS;
					}
				
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- END	
					
					formatData(sbName, strName);
					formatData(sbRev, strRev);
					formatData(sbTitle, strTitle);
					formatData(sbId, strId);
					formatData(sbType, strTyp);
					formatData(sbState, strState);
					formatData(sbPhase, strPhase);
				}
			}
			
			String strDGD = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION));
			String strUNN = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER));
			String strPSN = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN));
			String strShipqty = validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY));
			String strCON = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON));
			String strOPR = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR));
			String strUSPGreq = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZE));
			String strCUST = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST));
			String strSDgcup = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP));
			String strSDgcop = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP));
			String strHC  = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC));
			String strPGGroup = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP));
			String strTN1 = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1));
			String strTN2 = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2));
			String strNo = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NO));
			
			StringList slHCValues = FrameworkUtil.split(strHC,ConstantsUtil.SYMBL_PIPE);
			StringList slPGGroupValues = FrameworkUtil.split(strPGGroup,ConstantsUtil.SYMBL_PIPE);
			
			String strHCFInal = ConstantsUtil.EMPTY_STRING;
			String strPGFInal = ConstantsUtil.EMPTY_STRING;
			
			for(int i=0;i<slHCValues.size();i++){
				
				String sHC = slHCValues.get(i);
				String sPGGroup = slPGGroupValues.get(i);
				
				if(i%2 == 0){
					strHCFInal += sHC+ConstantsUtil.SYMBL_COMMA;
					strPGFInal += sPGGroup+ConstantsUtil.SYMBL_COMMA;
				} else{
					strHCFInal += sHC+ConstantsUtil.SYMBL_PIPE;
					strPGFInal += sPGGroup+ConstantsUtil.SYMBL_PIPE;
				}
			}
			
			formatData(sbHC, strHCFInal);
			formatData(sbPgroup, strPGFInal);
			formatData(sbDGD, strDGD);
			formatData(sbUNN, strUNN);
			formatData(sbPSN, strPSN);
			formatData(sbShipqty, strShipqty);
			formatData(sbCON, strCON);
			formatData(sbOPR, strOPR);
			formatData(sbUSPGreq, strUSPGreq);
			formatData(sbCust, strCUST);
			formatData(sbGCUP, strSDgcup);
			formatData(sbGCOP, strSDgcop);
			formatData(sbTN1, strTN1);
			formatData(sbTN2, strTN2);
			formatData(sbNo, strNo);

			//mpDangerousProdcut.put(ConstantsUtil.PPN, sbName.toString());
			mpDangerousProdcut.put(ConstantsUtil.ID, sbId.toString());
			mpDangerousProdcut.put(ConstantsUtil.TYPE, sbType.toString());
			//mpDangerousProdcut.put(ConstantsUtil.PPR,sbRev.toString());
			//mpDangerousProdcut.put(ConstantsUtil.PPT,sbTitle.toString());
			mpDangerousProdcut.put(ConstantsUtil.DGD,sbDGD.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNN,sbUNN.toString());
			mpDangerousProdcut.put(ConstantsUtil.PSN,sbPSN.toString());
			mpDangerousProdcut.put(ConstantsUtil.HC,sbHC.toString());
			mpDangerousProdcut.put(ConstantsUtil.PGGROUP,sbPgroup.toString());
			mpDangerousProdcut.put(ConstantsUtil.SHIPPINGQTY,sbShipqty.toString());
			mpDangerousProdcut.put(ConstantsUtil.CON,sbCON.toString());
			mpDangerousProdcut.put(ConstantsUtil.OPR,sbOPR.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNSPECPACKGGREQUIRED,sbUSPGreq.toString());
			mpDangerousProdcut.put(ConstantsUtil.CUST,sbCust.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCUP,sbGCUP.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCOP,sbGCOP.toString());
			mpDangerousProdcut.put(ConstantsUtil.PHASE,sbPhase.toString());
			mpDangerousProdcut.put(ConstantsUtil.STATE,sbState.toString());
			mpDangerousProdcut.put(ConstantsUtil.TN1,sbTN1.toString());
			mpDangerousProdcut.put(ConstantsUtil.TN2,sbTN2.toString());
			mpDangerousProdcut.put(ConstantsUtil.NO,sbNo.toString());

		}catch(Exception e){
			LOGGER.error("Error from FormulaPartBO:  getDangerousProdcutValue"+e);
			return new HashMap();
		}
		return mpDangerousProdcut;
	}
	
    
	/**
	 * Method Name 			: getMasterPartStabilityDoc
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getMasterPartStabilityDoc(Context context,Map resultMaps) 
	{
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTREVISION);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
		
		boolean bHasOwnerShip = false;
		
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		
		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		//Modified for Defect #37346 shashank -- START
		String sMasterObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID) : ConstantsUtil.EMPTY_STRING;
		//String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE) : ConstantsUtil.EMPTY_STRING;
		//Modified for Defect #37346 shashank -- END
		
		//SPEC: <04.10.2021>: Guna Added for Defect 44122 Dev 18x.6.0.2   -- START
		boolean bHasMasterPartAccess = false;
		//SPEC: <04.10.2021>: Guna Added for Defect 44122 Dev 18x.6.0.2   -- END
		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			//Modified for Defect #37346 shashank -- START
			//SPEC: <14-09-2021>: Guna Added for Stress Testing (2nd Round) -- START
			MapList mlRefDocs = new MapList();			
			if(UIUtil.isNotNullAndNotEmpty(sMasterObjectId)){
			DomainObject doMasterObjId = new DomainObject(sMasterObjectId);
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 17 March 2021 -- START
				mlRefDocs = doMasterObjId.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
						ConstantsUtil.TYPE_PGPKGSTABILITYREPORT.concat(",").concat(ConstantsUtil.TYPE_PGTECHNICALRATIONAL), busSelect, new StringList(), false, true, (short) 1,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 17 March 2021 -- END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doMasterObjId.close(context);
			}
			//SPEC: <14-09-2021>: Guna Added for Stress Testing (2nd Round) -- END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			//Modified for Defect #37346 shashank -- END
			String sUser = util.getUserType();
			//SPEC: <06.05.2021>: Guna Commented for Internal Defect  Dev 18x.6.0.1   -- START
			/*if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}*/
			//SPEC: <06.05.2021>: Guna Commented for Internal Defect  Dev 18x.6.0.1   -- END
			if(util.isModificatinRequired()) 
			{
				mlRefDocs=util.filterPhase(mlRefDocs);
			}
			Iterator objectListItr = mlRefDocs.iterator();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbMasterProductPartName = new StringBuilder();
			StringBuilder sbMasterProductPartRevision = new StringBuilder();
			StringBuilder sbMasterProductPartTitle =new StringBuilder();
			StringBuilder sbProductExpirationDataRequired=new StringBuilder();
			StringBuilder sbTotalShelfLifeDays=new StringBuilder();
			StringBuilder sbTemperatureGroup=new StringBuilder();
			StringBuilder sbHumidityGroup=new StringBuilder();
			StringBuilder sbTransportFreezeProtection = new StringBuilder();
			StringBuilder sbTransportHeatProtection = new StringBuilder();
			StringBuilder sbBoundaryConditions = new StringBuilder();
			StringBuilder sbStabilityDocument = new StringBuilder();
			//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
			StringBuilder sbMasterProductPartId = new StringBuilder();
			//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
			//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
			StringBuilder sbMasterProductPartType = new StringBuilder();
			StringBuilder sbStabilityDocumentType = new StringBuilder();
			//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
			//SPEC: 16/04/2021: Modified for 18x.6 Defect #41022 & Req #38398 by Bala-- START
			//Added for Requirement #38398 by Manikanta -- START
			/*boolean bHasMasterPartAccess = false;
			bHasMasterPartAccess = util.checkHasAccess(context, null, sMasterObjectId);*/
			//Added for Requirement #38398 by Manikanta -- END
			//SPEC: 16/04/2021: Modified for 18x.6 Defect #41022 & Req #38398 by Bala-- END
			//SPEC: <04.10.2021>: Guna Added for Defect 44122 Dev 18x.6.0.2   -- START
			bHasMasterPartAccess = util.checkHasAccess(context, null, sMasterObjectId);
			//SPEC: <04.10.2021>: Guna Added for Defect 44122 Dev 18x.6.0.2   -- END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sId    =  (String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	 =	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));

				String sMasterProductPartName    =  validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartRevision    =   validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTREVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTREVISION) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartTitle		=	validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTITLE))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTITLE) : ConstantsUtil.EMPTY_STRING;
				String sProductExpirationDataRequired	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
				String sTotalShelfLifeDays		=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
				String sTemperatureGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
				String sHumidityGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
				String sTransportFreezeProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
				String sTransportHeatProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
				String sBoundaryConditions = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
				String sStabilityDocument = (String)objectMap.get(ConstantsUtil.SELECT_NAME);
				//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
				String sStabilityDocumentType = (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sMasterProductPartType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE) : ConstantsUtil.EMPTY_STRING;
				//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
				StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				boolean bNonReleased = false;

				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}

				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					String sLangBuffer =ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;
					//SPEC: <29.03.2021>: Guna Modified for Defect 41653 Dev 18x.6   -- START
					/*if (util.isModificatinRequired()) 
				{
					//bHasOwnerShip = util.checkOwnerShip(sbCompany,slEachOwnership);
					//Added by Ganesh Start
					bHasOwnerShip = util.checkHasAccess(context, null, sId);
					//Added by Ganesh Stop
					//SPEC: <29.03.2021>: Guna Modified for Defect 41653 Dev 18x.6   -- START
					//if(sCurrent!=ConstantsUtil.RELEASE) {
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
						bHasOwnerShip=false;
					}
					//SPEC: <29.03.2021>: Guna Modified for Defect 41653 Dev 18x.6   -- START
					if(bHasOwnerShip) 
					{
						util.formatData(sbId,sId);
						util.formatData(sbMasterProductPartName,sMasterProductPartName);
						util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
						//Modified for Requirement #38398 by Manikanta -- START
						if(!bHasMasterPartAccess) {
							util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
						}else {
							util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
						}
						//Modified for Requirement #38398 by Manikanta -- END
						util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						util.formatData(sbTemperatureGroup,sTemperatureGroup);
						util.formatData(sbHumidityGroup,sHumidityGroup);
						util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						util.formatData(sbBoundaryConditions,sBoundaryConditions);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
						util.formatData(sbMasterProductPartId,sMasterObjectId);
						//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
						//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
						util.formatData(sbMasterProductPartType,sMasterProductPartType);
						util.formatData(sbStabilityDocumentType,sStabilityDocumentType);
						//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
					}
				}else if(sct.isStaffAUGUser()) {
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							bNonReleased=true;
						}
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

						if(slHIRTypes.contains(sType)) {
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}else {
							showData=true;
						}
				   {
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							bNonReleased=true;
						}
						//Added by Ganesh start
						showData = util.checkHasAccess(context, null, sId);
						//Added by Ganesh stop
					}	
					 */
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
						bNonReleased=true;
					}
					showData = util.checkHasAccess(context, null, sId);
					//SPEC: <03.06.2021>: Guna Commented for 39652 Req  Dev 18x.6.0.1   -- START
					//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
					/*if(!showData && util.isModificatinRequired()){
						continue;
					}*/
					//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END
					//SPEC: <03.06.2021>: Guna Commented for 39652 Req  Dev 18x.6.0.1   -- END
					if(showData) 
					{
						// SPEC <17/03/2021>Guna Commented for Defect 41089 18x.6 Release -- START
						//util.formatData(sbId,sId);
						// SPEC <17/03/2021>Guna Commented for Defect 41089  18x.6 Release -- END
						util.formatData(sbMasterProductPartName,sMasterProductPartName);
						util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
						//SPEC: 16/04/2021: Modified for 18x.6 Defect #41022 & Req #38398 by Bala-- START
						//Modified for Requirement #38398 by Manikanta -- START
						/*if(!bHasMasterPartAccess) {
						util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
					}else {*/
						util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
						//}
						//Modified for Requirement #38398 by Manikanta -- END
						//SPEC: 16/04/2021: Modified for 18x.6 Defect #41022 & Req #38398 by Bala-- END
						util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						util.formatData(sbTemperatureGroup,sTemperatureGroup);
						util.formatData(sbHumidityGroup,sHumidityGroup);
						util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						util.formatData(sbBoundaryConditions,sBoundaryConditions);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
						util.formatData(sbMasterProductPartId,sMasterObjectId);
						//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
						//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
						util.formatData(sbMasterProductPartType,sMasterProductPartType);
						util.formatData(sbStabilityDocumentType,sStabilityDocumentType);
						//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
						//This is a temporary addition to block IRM documents. This will be removed during Release 1.1
						/*if (sType.equals(ConstantsUtil.TYPE_PKDIPLATFORM)
								|| sType.equals(ConstantsUtil.TYPE_PGPKGSTUDYPROTOCOL)
								|| sType.equals(ConstantsUtil.TYPE_PGCONSUMERRESEARCH)
								|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONPROTOCOL)
								|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONOTHER)
								|| sType.equals(ConstantsUtil.TYPE_PGTECHNICALRATIONAL)
								|| sType.equals(ConstantsUtil.TYPE_PGPKGSTABILITYREPORT)
								|| sType.equals(ConstantsUtil.TYPE_PGSTABILITYOUTOFSPECREPORT)
								|| sType.equals(ConstantsUtil.TYPE_PGSTABILITYOTHER)
								|| sType.equals(ConstantsUtil.TYPE_PGRTAGENERICDOCUMENT)
								|| sType.equals(ConstantsUtil.TYPE_PGPKGDEVELOPMENTOTHER)
								|| sType.equals(ConstantsUtil.TYPE_PGCOREINNOVATIONRECORD)
								|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONREPORT)
								|| sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)
								|| sType.equalsIgnoreCase("pgPKGValidationReport")){
							sId = ConstantsUtil.EMPTY_STRING;
							util.formatData(sbId,sId);
						}else {*/
						if(bNonReleased) {
							sId = ConstantsUtil.NO_ACCESS;
							util.formatData(sbId,sId);
						}else {
							util.formatData(sbId,sId);
						}
						//}
					}/*else{
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						util.formatData(sbTemperatureGroup,sTemperatureGroup);
						util.formatData(sbHumidityGroup,sHumidityGroup);
						util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						util.formatData(sbBoundaryConditions,sBoundaryConditions);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
						util.formatData(sbMasterProductPartId,ConstantsUtil.NO_ACCESS);
						//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
						//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
						util.formatData(sbMasterProductPartType,sMasterProductPartType);
						util.formatData(sbStabilityDocumentType,sStabilityDocumentType);
						//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
					}
				}*/else
				{ 	//SPEC: Modified for Defect 43678 by Jwala -- START
					if(util.isModificatinRequired()){
						//SPEC: <04.10.2021>: Guna Modified for Defect 44122 Dev 18x.6.0.2   -- START
						if(!bHasMasterPartAccess){
							util.formatData(sbMasterProductPartName,ConstantsUtil.NO_ACCESS);
							util.formatData(sbMasterProductPartRevision,ConstantsUtil.NO_ACCESS);
							util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
							util.formatData(sbMasterProductPartType,ConstantsUtil.NO_ACCESS);
							util.formatData(sbMasterProductPartId,ConstantsUtil.NO_ACCESS);
						}else{
							util.formatData(sbMasterProductPartName,sMasterProductPartName);
							util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
							util.formatData(sbMasterProductPartType,sMasterProductPartType);
							util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
							util.formatData(sbMasterProductPartId,sMasterObjectId);
						}
						/*util.formatData(sbMasterProductPartName,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartRevision,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartType,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartId,ConstantsUtil.NO_ACCESS);*/
						//SPEC: <04.10.2021>: Guna Modified for Defect 44122 Dev 18x.6.0.2   -- END
						
						util.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
						util.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
						util.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbStabilityDocumentType,ConstantsUtil.NO_ACCESS);
						util.formatData(sbStabilityDocument,sStabilityDocument);
					}else{
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
						//SPEC: 16/04/2021: Modified for 18x.6 Defect #41022 & Req #38398 by Bala-- START
						//util.formatData(sbMasterProductPartName,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartName,sMasterProductPartName);
						//util.formatData(sbMasterProductPartRevision,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
						//util.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
						util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						//util.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						//util.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTemperatureGroup,sTemperatureGroup);
						//util.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
						util.formatData(sbHumidityGroup,sHumidityGroup);
						//util.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						//util.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						//util.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
						util.formatData(sbBoundaryConditions,sBoundaryConditions);
						//util.formatData(sbStabilityDocument,ConstantsUtil.NO_ACCESS);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						//SPEC: 16/04/2021: Modified for 18x.6 Defect #41022 & Req #38398 by Bala-- END
						//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
						util.formatData(sbMasterProductPartId,ConstantsUtil.NO_ACCESS);
						//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
						//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
						util.formatData(sbMasterProductPartType,sMasterProductPartType);
						util.formatData(sbStabilityDocumentType,sStabilityDocumentType);
						//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
					}
					//SPEC: Modified for Defect 43678 by Jwala -- END
				}
				}
			}
			//SPEC: <29.03.2021>: Guna Modified for Defect 41653 Dev 18x.6   -- END
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTNAME, sbMasterProductPartName.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTREV, sbMasterProductPartRevision.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTTITLE, sbMasterProductPartTitle.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTEXPDATEREQ, sbProductExpirationDataRequired.toString());
			mpRefDoc.put(ConstantsUtil.TOTALSHELFLIFEDAYS, sbTotalShelfLifeDays.toString());
			mpRefDoc.put(ConstantsUtil.TEMPERATUREGROUP, sbTemperatureGroup.toString());
			mpRefDoc.put(ConstantsUtil.HUMIDITYGROUP, sbHumidityGroup.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, sbTransportFreezeProtection.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTHEATPROTECTION, sbTransportHeatProtection.toString());
			mpRefDoc.put(ConstantsUtil.BOUNDARYCONDITIONS, sbBoundaryConditions.toString());
			mpRefDoc.put(ConstantsUtil.STABILITYDOCUMENT, sbStabilityDocument.toString());
			//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
			mpRefDoc.put(ConstantsUtil.MASTERPARTID, sbMasterProductPartId.toString());
			//SPEC: <22.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
			//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- START
			mpRefDoc.put(ConstantsUtil.MASTERPARTTYPE, sbMasterProductPartType.toString());
			mpRefDoc.put(ConstantsUtilIRM.STABILITYTYPE, sbStabilityDocumentType.toString());
			//SPEC: <24.03.2021>: Guna Added for Defect 41333 Dev 18x.6   -- END
			
		}catch(Exception e){

			LOGGER.error("Exception in Program : FormulaPartBO Method :getMasterPartStabilityDoc "+e);
			return new HashMap();
		}
		//return util.filterMapList(mpRefDoc);
		return mpRefDoc;
	}
    
	
	/**
	 * Method Name 			: getProductPartStabilityDoc
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getProductPartStabilityDoc(Context context,Map resultMaps) 
	{
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.STR_IPCLASS);

		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTREVISION);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);

		boolean bHasOwnerShip = false;

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();

		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;


		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			DomainObject doFOP = new DomainObject(sObjectId);
			//SPEC: Release SR18x5.2- modified for Defect #39390 by Govind on Date 14/02/2021 start
			/*MapList mlRefDocs = doFOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);*/
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 17 March 2021 -- START
			MapList mlRefDocs = doFOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.TYPE_PGPKGSTABILITYREPORT.concat(",").concat(ConstantsUtil.TYPE_PGTECHNICALRATIONAL), busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doFOP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 17 March 2021 -- END
			//SPEC: Release SR18x5.2- modified for Defect #39390 by Govind on Date 14/02/2021 end
			String sUser = util.getUserType();
			//SPEC: <06.05.2021>: Guna Commented for Internal Defect  Dev 18x.6.0.1   -- START
			/*if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}*/
			//SPEC: <06.05.2021>: Guna Commented for Internal Defect  Dev 18x.6.0.1   -- END
			if(util.isModificatinRequired()) 
			{
				mlRefDocs=util.filterPhase(mlRefDocs);
			}
			Iterator objectListItr = mlRefDocs.iterator();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbMasterProductPartName = new StringBuilder();
			StringBuilder sbMasterProductPartRevision = new StringBuilder();
			StringBuilder sbMasterProductPartTitle =new StringBuilder();
			StringBuilder sbProductExpirationDataRequired=new StringBuilder();
			StringBuilder sbTotalShelfLifeDays=new StringBuilder();
			StringBuilder sbTemperatureGroup=new StringBuilder();
			StringBuilder sbHumidityGroup=new StringBuilder();
			StringBuilder sbTransportFreezeProtection = new StringBuilder();
			StringBuilder sbTransportHeatProtection = new StringBuilder();
			StringBuilder sbBoundaryConditions = new StringBuilder();
			StringBuilder sbStabilityDocument = new StringBuilder();
			// Guna Added for Defect 38534  18x.5.2 Release -- START
			StringBuilder sbStabilityDocumentType = new StringBuilder();
			// Guna Added for Defect 38534  18x.5.2 Release -- END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sId    =  (String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	 =	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));

				String sProductExpirationDataRequired	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
				String sTotalShelfLifeDays		=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
				String sTemperatureGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
				String sHumidityGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
				String sTransportFreezeProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
				String sTransportHeatProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
				String sBoundaryConditions = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
				String sStabilityDocument = (String)objectMap.get(ConstantsUtil.SELECT_NAME);

				StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				boolean bNonReleased = false;

				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}

				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					String sLangBuffer =ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;
					//SPEC: Release SR18x.6.0 - Defect#41151 Added  by gaikwad.tg on Date 23 Mar 2021 -- START
					/*if (util.isModificatinRequired()) 
					{
						//bHasOwnerShip = util.checkOwnerShip(sbCompany,slEachOwnership);
						//Added by Ganesh Start
						bHasOwnerShip = util.checkHasAccess(context, null, sId);
						//Added by Ganesh stop
						if(sCurrent!=ConstantsUtil.RELEASE) {
							bHasOwnerShip=false;
						}
						if(bHasOwnerShip) 
						{
							util.formatData(sbId,sId);
							util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
							util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
							util.formatData(sbTemperatureGroup,sTemperatureGroup);
							util.formatData(sbHumidityGroup,sHumidityGroup);
							util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
							util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
							util.formatData(sbBoundaryConditions,sBoundaryConditions);
							util.formatData(sbStabilityDocument,sStabilityDocument);
							// Guna Added for Defect 38534  18x.5.2 Release -- START
							util.formatData(sbStabilityDocumentType,sType);
							// Guna Added for Defect 38534  18x.5.2 Release -- END
						}
					}else {if(sct.isStaffAUGUser()) {
						if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
							String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else {
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							bNonReleased=true;
						}
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

						if(slHIRTypes.contains(sType)) {
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}else {
							showData=true;
						}
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							bNonReleased=true;
						}
					}	
						//Added by Ganesh Start
						showData=util.checkHasAccess(context, null, sId);
						//Added by Ganesh Stop
					}

					if(showData) 
					{
						util.formatData(sbId,sId);
						util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						util.formatData(sbTemperatureGroup,sTemperatureGroup);
						util.formatData(sbHumidityGroup,sHumidityGroup);
						util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						util.formatData(sbBoundaryConditions,sBoundaryConditions);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						// Guna Added for Defect 38534  18x.5.2 Release -- START
						util.formatData(sbStabilityDocumentType,sType);
						// Guna Added for Defect 38534  18x.5.2 Release -- END
						//This is a temporary addition to block IRM documents. This will be removed during Release 1.1
						if (sType.equals(ConstantsUtil.TYPE_PKDIPLATFORM)
								|| sType.equals(ConstantsUtil.TYPE_PGPKGSTUDYPROTOCOL)
								|| sType.equals(ConstantsUtil.TYPE_PGCONSUMERRESEARCH)
								|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONPROTOCOL)
								|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONOTHER)
								|| sType.equals(ConstantsUtil.TYPE_PGTECHNICALRATIONAL)
								|| sType.equals(ConstantsUtil.TYPE_PGPKGSTABILITYREPORT)
								|| sType.equals(ConstantsUtil.TYPE_PGSTABILITYOUTOFSPECREPORT)
								|| sType.equals(ConstantsUtil.TYPE_PGSTABILITYOTHER)
								|| sType.equals(ConstantsUtil.TYPE_PGRTAGENERICDOCUMENT)
								|| sType.equals(ConstantsUtil.TYPE_PGPKGDEVELOPMENTOTHER)
								|| sType.equals(ConstantsUtil.TYPE_PGCOREINNOVATIONRECORD)
								|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONREPORT)
								|| sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)
								|| sType.equalsIgnoreCase("pgPKGValidationReport")){
							sId = ConstantsUtil.EMPTY_STRING;
							util.formatData(sbId,sId);
						}else {
						if(bNonReleased) {
							sId = ConstantsUtil.EMPTY_STRING;
							util.formatData(sbId,sId);
						}else {
							util.formatData(sbId,sId);
						}
						//}
					}else{
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						util.formatData(sbTemperatureGroup,sTemperatureGroup);
						util.formatData(sbHumidityGroup,sHumidityGroup);
						util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						util.formatData(sbBoundaryConditions,sBoundaryConditions);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						// Guna Added for Defect 38534  18x.5.2 Release -- START
						util.formatData(sbStabilityDocumentType,sType);
						// Guna Added for Defect 38534  18x.5.2 Release -- END
					}*/
					
					showData = util.checkHasAccess(context, null, sId);
					//SPEC: <03.06.2021>: Guna Commented for 39652 Req  Dev 18x.6.0.1   -- START
					//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
				/*	if(!showData && util.isModificatinRequired()){
						continue;
					}*/
					//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END
					//SPEC: <03.06.2021>: Guna Commented for 39652 Req  Dev 18x.6.0.1   -- END
					//SPEC: 03-29-2021: Added for 18x.6 for Defect# 41505 by Chandu -- START
					//Added by Ganesh stop
					//if(sCurrent!=ConstantsUtil.RELEASE)
					if(!sCurrent.equals(ConstantsUtil.RELEASE)){
						showData=false;
					}
					//SPEC: 03-29-2021: Added for 18x.6 for Defect# 41505 by Chandu -- END
					if(!showData){
						// Jwala Modified for Defect 43678  18x.6 Release -- START
						sId = ConstantsUtil.NO_ACCESS;
						sProductExpirationDataRequired = ConstantsUtil.NO_ACCESS;
						sTotalShelfLifeDays = ConstantsUtil.NO_ACCESS;
						sTemperatureGroup= ConstantsUtil.NO_ACCESS;
						sHumidityGroup= ConstantsUtil.NO_ACCESS;
						sTransportFreezeProtection= ConstantsUtil.NO_ACCESS;
						sTransportHeatProtection= ConstantsUtil.NO_ACCESS;
						sBoundaryConditions= ConstantsUtil.NO_ACCESS;
						// Jwala Modified for Defect 43678  18x.6 Release -- END
					}
					
				}else
				{
					sId = ConstantsUtil.NO_ACCESS;
					/*util.formatData(sbId,ConstantsUtil.NO_ACCESS);
					util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
					util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
					util.formatData(sbTemperatureGroup,sTemperatureGroup);
					util.formatData(sbHumidityGroup,sHumidityGroup);
					util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
					util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
					util.formatData(sbBoundaryConditions,sBoundaryConditions);
					util.formatData(sbStabilityDocument,sStabilityDocument);
					// Guna Added for Defect 38534  18x.5.2 Release -- START
					util.formatData(sbStabilityDocumentType,sType);*/
					// Guna Added for Defect 38534  18x.5.2 Release -- END
				}
				
				util.formatData(sbId,sId);
				util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
				util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
				util.formatData(sbTemperatureGroup,sTemperatureGroup);
				util.formatData(sbHumidityGroup,sHumidityGroup);
				util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
				util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
				util.formatData(sbBoundaryConditions,sBoundaryConditions);
				util.formatData(sbStabilityDocument,sStabilityDocument);
				util.formatData(sbStabilityDocumentType,sType);
				//SPEC: Release SR18x.6.0 - Defect#41151 Added  by gaikwad.tg on Date 23 Mar 2021 -- END
			}
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTEXPDATEREQ, sbProductExpirationDataRequired.toString());
			mpRefDoc.put(ConstantsUtil.TOTALSHELFLIFEDAYS, sbTotalShelfLifeDays.toString());
			mpRefDoc.put(ConstantsUtil.TEMPERATUREGROUP, sbTemperatureGroup.toString());
			mpRefDoc.put(ConstantsUtil.HUMIDITYGROUP, sbHumidityGroup.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, sbTransportFreezeProtection.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTHEATPROTECTION, sbTransportHeatProtection.toString());
			mpRefDoc.put(ConstantsUtil.BOUNDARYCONDITIONS, sbBoundaryConditions.toString());
			mpRefDoc.put(ConstantsUtil.STABILITYDOCUMENT, sbStabilityDocument.toString());
			// Guna Added for Defect 38534  18x.5.2 Release -- START
			mpRefDoc.put(ConstantsUtil.TYPE, sbStabilityDocumentType.toString());
			// Guna Added for Defect 38534  18x.5.2 Release -- END
		}catch(Exception e){

			LOGGER.error("Exception in Program : FormulaPartBO Method :getProductPartStabilityDoc "+e);
			return new HashMap();
		}
		//return util.filterMapList(mpRefDoc);
		return mpRefDoc;
	}
	
	
	/**
	 * Bus Selects
	 * @return
	 */

	private StringList objectSelects() {
		StringList objectSelects = new StringList();

		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_TYPE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_NAME);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_ID);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_TITLE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_MIN_WEIGHT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_QUANTITY);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_MAX_WEIGHT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_TARGET_WEIGHT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MIN_ACTUAL_PERCENT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MAX_ACTUAL_PERCENT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_QUATITY_ADJUSTMENT);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_VALID_DATE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_PROCESSING_NOTE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_CHG);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_PHASE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_REVISION);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_FUNCTION);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_REPORTEDFUNCTION);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_VALIDSTARTDATE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_VALIDUNTILDATE);
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_COMMENTS);
		objectSelects.add(ConstantsUtil.STR_IPCLASS);
		objectSelects.add(ConstantsUtil.STR_RF);
		
		//SPEC: <11.20.2020>: Modified for Defect 37430 by Amman## -- START
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_PGARCHIVECOMMENTS);
		//SPEC: <11.20.2020>: Modified for Defect 37430 by Amman## -- END
		
		//SPEC: <11.20.2020>: Added for Defect 37472 by Chandra## -- START
		objectSelects.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_APPLICATION);
		//SPEC: <11.20.2020>: Added for Defect 37472 by Chandra## -- END
		return objectSelects;
	}
	
	
	/**
	 * Substitute Bus Selects
	 * @return
	 */
	public StringList getSubstituteBusSelects(){

		StringList objectSelects = new StringList();

		objectSelects.add(ConstantsUtil.SELECT_NAME);
		objectSelects.add(ConstantsUtil.SELECT_ID);
		objectSelects.add(ConstantsUtil.SELECT_TYPE);
		objectSelects.add(ConstantsUtil.SELECT_REVISION);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		//objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTIONGLOBAL);
		objectSelects.add("from[pgPDTemplatestopgPLIReportedFunction].to.name");
		objectSelects.add("to[FBOM Substitute].fromrel.attribute[Find Number]");
		objectSelects.add(ConstantsUtil.ATTRIBUTE_PGMATERIALFUNCTION);
		
		//SPEC: <11.20.2020>: Modified for Defect 37430 by Amman## -- START
		//objectSelects.add(ConstantsUtil.ATTRIBUTE_PGMATERIALFUNCTION);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		//SPEC: <11.20.2020>: Modified for Defect 37430 by Amman## -- END
		

		return objectSelects;
	}
	
	
	/**
	 * Substitute Selects
	 * 
	 * @return
	 */
	private StringList getSubstituteRelSelects() {

		StringList relSelects = new StringList();
		relSelects.add(ConstantsUtil.STR_FROM_ID);
		relSelects.add(DomainRelationship.SELECT_ID);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_ADJUSTMENT_VALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_NEEDS_UPDATE_VALUE);
		relSelects.add(ConstantsUtil.ATTRIBUTE_MIN_INPUT);
		relSelects.add(ConstantsUtil.ATTRIBUTE_MAX_INPUT);
		relSelects.add(ConstantsUtil.ATTRIBUTE_TARGET_WET_WEIGHT_INPUT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE_VALUE);
		relSelects.add(ConstantsUtil.ATTRIBUTE_PROCESS_NOTE_INPUT);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET);
		
		//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --START
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
		//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --END
		
		
		
		
		

		return relSelects;
	}
	
	
	/**
	 * Get Formulation Substitutes
	 * @param context
	 * @param partId
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getFormulationSubstituteDetails(Context context, String partId) throws Exception {
		BusObjectAttribUtil utill = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpProces = new TreeMap();

		String sPId = ConstantsUtil.EMPTY_STRING;
		String sPType = ConstantsUtil.EMPTY_STRING;
		String sPName = ConstantsUtil.EMPTY_STRING;
		String sPtitle = ConstantsUtil.EMPTY_STRING;
		String sPMin = ConstantsUtil.EMPTY_STRING;
		String sPMax = ConstantsUtil.EMPTY_STRING;
		String sPWet = ConstantsUtil.EMPTY_STRING;
		String strWW = ConstantsUtil.EMPTY_STRING;
		String sPMinWet = ConstantsUtil.EMPTY_STRING;
		String sPMaxWet = ConstantsUtil.EMPTY_STRING;
		String sPTargetWet = ConstantsUtil.EMPTY_STRING;
		String sPDiff = ConstantsUtil.EMPTY_STRING;
		String sPDate = ConstantsUtil.EMPTY_STRING;
		String sPProcessNotes = ConstantsUtil.EMPTY_STRING;
		String sCertficate = ConstantsUtil.EMPTY_STRING;
		String sChg = ConstantsUtil.EMPTY_STRING;
		String sPhase = ConstantsUtil.EMPTY_STRING;
		String sRevision = ConstantsUtil.EMPTY_STRING;
		String sFunction = ConstantsUtil.EMPTY_STRING;
		String sReportedFunction = ConstantsUtil.EMPTY_STRING;
		String sValidStartDate = ConstantsUtil.EMPTY_STRING;
		String sValidUntilDate = ConstantsUtil.EMPTY_STRING;
		String sComments = ConstantsUtil.EMPTY_STRING;
		String sSequence = ConstantsUtil.EMPTY_STRING;
		String strRF = ConstantsUtil.EMPTY_STRING;
		
		try {
			DomainObject domObj = new DomainObject(partId);
			String objName = (String) domObj.getInfo(context, ConstantsUtil.SELECT_NAME);
			StringList relsel = new StringList();

			relsel.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ID);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_TO_ID);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_TO_TYPE);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INST);

			StringList strObjList = new StringList(6);
			strObjList.add(DomainConstants.SELECT_ID);
			strObjList.add(DomainConstants.SELECT_TYPE);
			strObjList.add(DomainConstants.SELECT_NAME);
			strObjList.add(DomainConstants.SELECT_REVISION);

			MapList substituteList = domObj.getRelatedObjects(context, ConstantsUtil.REL_FBOM,
					ConstantsUtil.TYPE_RAWMATERIALPART.concat(",").concat(ConstantsUtil.TYPE_FORMULATIONPHASE)
					.concat(",").concat(ConstantsUtil.TYPE_FORMULATIONPART).concat(",")
					.concat(ConstantsUtil.TYPE_PGRAWMATERIAL).concat(",")
					.concat(ConstantsUtil.TYPE_PGMASTERRAWMATERIAL).concat(",")
					.concat(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART),
					strObjList, relsel, false, true, (short) 0, "", "", 0);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domObj.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator itr1 = substituteList.iterator();
			MapList ll = new MapList();
			int i = 0;
			while (itr1.hasNext()) {
				
				int integerPlaces = ConstantsUtil.ZERO_LEVEL;
				int decimalPlaces = ConstantsUtil.ZERO_LEVEL;
				DecimalFormat decimalformatter = new DecimalFormat(ConstantsUtil.PATTERN_DECIMALFORMAT);

				StringList slRemoveDuplicate =new StringList();
				

				Map relmap = (Map) itr1.next();
				String sobjType = (String) relmap.get(DomainConstants.SELECT_TYPE);
				if (sobjType.equals(ConstantsUtil.TYPE_PGRAWMATERIAL)
						|| sobjType.equals(ConstantsUtil.TYPE_RAWMATERIALPART)
						|| mxType.isOfParentType(context, sobjType, ConstantsUtil.TYPE_FORMULATIONPART)
						|| mxType.isOfParentType(context, sobjType, ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART)
						|| sobjType.equals(ConstantsUtil.TYPE_PGMASTERRAWMATERIAL)) {

					String strsubsPartId = validator.getStringEquivalentForStringList(
							(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_TO_ID)));

					
					//SPEC: 11.18.2020: Commented for Defect #37398 -- START		
					
					
				/*	//Chandra
					String ssubsDesc = validator.getStringEquivalentForStringList(
							(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC)));
					String sInst = validator.getStringEquivalentForStringList(
							(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INST)));
							
			//SPEC: 11.18.2020: Commented for Defect #37398 -- END		*/	
					
			//SPEC: 11.18.2020: Modified for Defect #37398 -- START	
					
					String ssubsDesc =ConstantsUtil.EMPTY_STRING;
					String sInst =ConstantsUtil.EMPTY_STRING;
					
					StringBuilder sbDescReturn = new StringBuilder();
					StringBuilder sbInstReturn = new StringBuilder();
					
					try 
					{
						//For Description
						if (relmap.containsKey((ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC))) 
						{
							
							String sClass =relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC).getClass().getSimpleName();
							
							if (sClass.equals(ConstantsUtil.STRING)) {
								ssubsDesc     =  validator.getStringEquivalentForStringListWithComma(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC));
								ssubsDesc=ssubsDesc.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							}else
							{
								String sReturnValue =ConstantsUtil.EMPTY_STRING;
								StringList slTempSubsDesc = validator.isNotNullOrEmpty((StringList) relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC));
								for (int count = 0; i < slTempSubsDesc.size(); i++) 
								{
									sReturnValue =slTempSubsDesc.get(i);
									sReturnValue.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
									formatData(sbDescReturn, sReturnValue);
								}
								ssubsDesc=sbDescReturn.toString();
							}
						}
						
						//For Inst
						if (relmap.containsKey((ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INST))) 
						{
							
							String sClass =relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INST).getClass().getSimpleName();
							
							if (sClass.equals(ConstantsUtil.STRING)) {
								sInst     =  validator.getStringEquivalentForStringListWithComma(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INST));
								sInst=sInst.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							}else
							{
								String sReturnValue =ConstantsUtil.EMPTY_STRING;
								StringList slTempSubsInst = validator.isNotNullOrEmpty((StringList) relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INST));
								for (int count = 0; count < slTempSubsInst.size(); count++) 
								{
									sReturnValue =slTempSubsInst.get(count);
									sReturnValue.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
									formatData(sbInstReturn, sReturnValue);
								}
								sInst=sbInstReturn.toString();
							}
						}
						
						
					}catch(Exception e)
					{
						LOGGER.error("Exception in Program : FormulaPartBO Method :getFormulationSubstituteDetails  " + e);
						return new HashMap();
					}
				//SPEC: 11.18.2020: Modified for Defect #37398 -- END	
					
					//Chandra
					StringList slsubsDesc = FrameworkUtil.split(ssubsDesc, ConstantsUtil.SYMBL_PIPE);
					StringList slsInst = FrameworkUtil.split(sInst, ConstantsUtil.SYMBL_PIPE);


					String subsType = validator.getStringEquivalentForStringList(
							(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_TO_TYPE)));

					//SPEC: 10.26.2020: Added for Defect #36663 -- START
					StringList slsObjectId = FrameworkUtil.split(strsubsPartId, ConstantsUtil.SYMBL_PIPE);
					//SPEC: 10.26.2020: Added for Defect #36663 -- END

					//SPEC: 10.26.2020: Modified for Defect #36663 -- START
					//String sOID[] = { strsubsPartId };
					//for(String strID:slsObjectId)
					//	{
					//String sObjectId =strID.trim();


					for(int ij=0 ;ij<=slsObjectId.size()-1;ij++)	{
						
						Map<String, String> mpSubstitutes = new HashMap<String, String>();
						String sObjectId = slsObjectId.get(ij);

						if (!slRemoveDuplicate.contains(sObjectId)) {
							slRemoveDuplicate.add(sObjectId);
						}else{
							continue;
						}
						
				//SPEC: 11.18.2020: Commented for Defect #37398 -- START		
					/*	String strsubsInst = slsInst.get(ij);
						String	 strsubsDesc = slsubsDesc.get(ij);*/
				//SPEC: 11.18.2020: Commented for Defect #37398 -- END	
						
				//SPEC: 11.18.2020: modified for Defect #37398 -- START			
						
						String strsubsDesc=ConstantsUtil.EMPTY_STRING;
						String strsubsInst=ConstantsUtil.EMPTY_STRING;
						
						try
						{
						 strsubsDesc = slsubsDesc.get(ij);
						}catch(Exception e){
							strsubsDesc=ConstantsUtil.EMPTY_STRING;
						}

						try
						{
							 strsubsInst = slsInst.get(ij);
						}catch(Exception e){
							strsubsInst=ConstantsUtil.EMPTY_STRING;
						}
					
				//SPEC: 11.18.2020: modified for Defect #37398 -- END
						 
						StringBuilder sbTitle = new StringBuilder();
						StringBuilder sbPName = new StringBuilder();
						StringBuilder sbPId = new StringBuilder();
						StringBuilder sbPType = new StringBuilder();
						StringBuilder sbPRev = new StringBuilder();
						StringBuilder sbPCurrent = new StringBuilder();
						StringBuilder sbPDescription = new StringBuilder();
						StringBuilder sbPMin = new StringBuilder();
						StringBuilder sbPMax = new StringBuilder();
						StringBuilder sbPWet = new StringBuilder();

						StringBuilder sbPMinWt = new StringBuilder();
						StringBuilder sbPMaxWt = new StringBuilder();
						StringBuilder sbPWetWt = new StringBuilder();
						StringBuilder sbPDiff = new StringBuilder();
						StringBuilder sbPDate = new StringBuilder();
						StringBuilder sbPProces = new StringBuilder();
						StringBuilder sbPCert = new StringBuilder();

						StringBuilder sbFName = new StringBuilder();
						StringBuilder sbFId = new StringBuilder();
						StringBuilder sbFType = new StringBuilder();

						StringBuilder sbFTitle = new StringBuilder();
						StringBuilder sbFWetWt = new StringBuilder();

						StringBuilder sbHeader = new StringBuilder();
						StringBuilder sbInst = new StringBuilder();
						StringBuilder sbDec = new StringBuilder();
						
						StringBuilder sbChg = new StringBuilder();
						StringBuilder sbSPPhase = new StringBuilder();
						StringBuilder sbSFPhase = new StringBuilder();
						StringBuilder sbSPRevision = new StringBuilder();
						StringBuilder sbSFRevision = new StringBuilder();
						StringBuilder sbFunction = new StringBuilder();
						StringBuilder sbReportedFunction = new StringBuilder();
						StringBuilder sbValidStartDate = new StringBuilder();
						StringBuilder sbValidUntilDate = new StringBuilder();
						StringBuilder sbComments = new StringBuilder();
						StringBuilder sbSequence = new StringBuilder();
						StringBuilder sbRF = new StringBuilder();
						
						DomainObject subsObj = new DomainObject(sObjectId);

						if (subsType.contains(ConstantsUtil.TYPE_PARENTSUB)) 
						{
							MapList mlSubstitutes = subsObj.getRelatedObjects(context, ConstantsUtil.REL_FBOM, ConstantsUtil.QUERY_WILDCARD,
									getSubstituteBusSelects(), getSubstituteRelSelects(), false, true, (short) 1, null,
									null, 0);
							

							Iterator itrSubstitutes = mlSubstitutes.iterator();
							
							SecurityService sct = new SecurityService();
							String sUserlicense = sct.getUserLicense();

							while (itrSubstitutes.hasNext()) {

								Map mpSubstituteFor = (Map) itrSubstitutes.next();
								sPId = validator.getStringEquivalentForStringList(mpSubstituteFor.get(ConstantsUtil.ID));
								sPType = validator.getStringEquivalentForStringList(mpSubstituteFor.get(ConstantsUtil.TYPE));
								sPName = validator.getStringEquivalentForStringList(mpSubstituteFor.get(ConstantsUtil.NAME));
								sPtitle = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sPMin = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.ATTRIBUTE_MIN_INPUT));
								sPMax = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.ATTRIBUTE_MAX_INPUT));
								sPWet = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE));
								strWW = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE));
								sPTargetWet = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT));
								sPMinWet = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET));
								if(sPMinWet.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)){
									sPMinWet = ConstantsUtil.EMPTY_STRING;
								}
								sPMaxWet = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET));
								if(sPMaxWet.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)){
									sPMaxWet = ConstantsUtil.EMPTY_STRING;
								}
								sPDiff = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_ADJUSTMENT_VALUE));
								sPDate = validator
										.getStringEquivalentForStringList(mpSubstituteFor.get(ConstantsUtil.ATTRIBUTE_VALID_DATE));
								sPProcessNotes = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE_VALUE));

								sPhase = (String) domObj.getInfo(context, ConstantsUtil.FORMULAPHASE);
								/*sPhase = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get("from[Planned For].to.from[FBOM].to.name"));
								 */
								sRevision = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get(ConstantsUtil.SELECT_REVISION));
								
								Map mpSeq = new HashMap();
								StringList slSeq = new StringList();
								slSeq.addElement(ConstantsUtil.SELECT_REVISION);
								slSeq.addElement("to[FBOM Substitute].fromrel.attribute[Find Number]");
								mpSeq = (Map) subsObj.getInfo(context, slSeq);
								sSequence = (String)mpSeq.get("to[FBOM Substitute].fromrel.attribute[Find Number]");
								String strRev = (String)mpSeq.get(ConstantsUtil.SELECT_REVISION);
								
								sSequence = "1."+sSequence;
								
								/*sSequence = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get("to[FBOM Substitute].fromrel.attribute[Find Number]"));*/
								String sIpClass =validator.getStringEquivalentForStringList((mpSubstituteFor.get(ConstantsUtil.STR_IPCLASS)));

								strRF = validator.getStringEquivalentForStringList(
										mpSubstituteFor.get("from[pgPDTemplatestopgPLIReportedFunction].to.name"));
								
								//SPEC: <11.20.2020>: Modified for Defect 37430 by Amman## -- START
								//sFunction = validator.getStringEquivalentForStringList(mpSubstituteFor
								//		.get(ConstantsUtil.ATTRIBUTE_PGMATERIALFUNCTION));
								
								
								
								//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --START
								
								//sFunction = validator.getStringEquivalentForStringList(mpSubstituteFor
										//.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION));
								
								 sFunction =(String)mpSubstituteFor.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
								
								try
								{
									if (UIUtil.isNotNullAndNotEmpty(sFunction)) 
									{
										sFunction=util.getIdFromPhysicalIdFunction(context,sFunction);
										
									}
									}catch(Exception e){
										sFunction=ConstantsUtil.EMPTY_STRING;
									}
								//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --END
								
								
								sComments = validator.getStringEquivalentForStringList(mpSubstituteFor
										.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT));
								//SPEC: <11.20.2020>: Modified for Defect 37430 by Amman## -- END
								
								boolean showData = false;
								//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --START
								/*boolean bHasOwnership=false;

								if(util.isModificatinRequired())
								{
									SecurityService sec = new SecurityService();
									String sComp = sec.getUserCauthorities();
									StringList slUserOwnership=util.filterOwnerShip(sComp);

									bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sPId);

									if(!bHasOwnership)
									{
										sPName = ConstantsUtil.NO_ACCESS;
										sPType = ConstantsUtil.NO_ACCESS;
										sPId    = ConstantsUtil.NO_ACCESS;
										sPtitle = ConstantsUtil.NO_ACCESS;
										sPMin = ConstantsUtil.NO_ACCESS;
										sPMax = ConstantsUtil.NO_ACCESS;
										sPWet = ConstantsUtil.NO_ACCESS;
										sPMinWet = ConstantsUtil.NO_ACCESS;
										sPMaxWet = ConstantsUtil.NO_ACCESS;
										sPTargetWet = ConstantsUtil.NO_ACCESS;
										sPDiff = ConstantsUtil.NO_ACCESS;
										sPDate = ConstantsUtil.NO_ACCESS;
										sPProcessNotes = ConstantsUtil.NO_ACCESS;
										sCertficate = ConstantsUtil.NO_ACCESS;
										sPhase = ConstantsUtil.NO_ACCESS;
										sRevision = ConstantsUtil.NO_ACCESS;
										sChg = ConstantsUtil.NO_ACCESS;
										sSequence = ConstantsUtil.NO_ACCESS;
										strRF = ConstantsUtil.NO_ACCESS;
								    }
								} else if(sct.isStaffAUGUser()) {
										
										if(sPType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
											String sFormulaClassif = util.getFormulaPropagateClassification(context, sPId);
											showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
										}else {
											showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
										}
									}else {
										StringList slHIRTypes = new StringList();
										slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
										slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
										slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
										slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
										slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
										
										if(slHIRTypes.contains(sPType)) {
											showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
										}else {
											showData=true;
										}
										
									}*/
								showData= util.checkHasAccess(context, null, sPId);
								
								//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --END
								
									if(!showData){
										sPId = ConstantsUtil.NO_ACCESS;
									}
								
								formatData(sbPName, sPName);
								formatData(sbPType, util.mapType(sPType));
								formatData(sbPId, sPId);
								formatData(sbPDescription, sPtitle);

								formatData(sbPMin, sPMin);
								formatData(sbPMax, sPMax);
								formatData(sbPWet, sPWet);

								formatData(sbPMinWt, sPMinWet);
								formatData(sbPMaxWt, sPMaxWet);
								formatData(sbPWetWt, sPTargetWet);

								formatData(sbPDiff, sPDiff);
								formatData(sbPDate, sPDate);
								formatData(sbPProces, sPProcessNotes);
								formatData(sbPCert, sCertficate);

								formatData(sbSFPhase,sPhase);
								formatData(sbSFRevision, sRevision);
								formatData(sbFunction, sFunction);
								formatData(sbSequence, sSequence);
								formatData(sbReportedFunction, strRF);
								
								//SPEC: <11.20.2020>: Added for Defect 37430 by Amman## -- START
								formatData(sbComments, sComments);
								//SPEC: <11.20.2020>: Added for Defect 37430 by Amman## -- END
							}
							
							//SPEC: 10.26.2020: Modified for Defect #36663 -- START

							Map mpSubPartsFor = subsObj.getInfo(context, objectSelects());
							
							MapList mlSubPartsFor = new MapList();
							mlSubPartsFor.add(mpSubPartsFor);

							//MapList mlSubPartsFor = (MapList) subsObj.getInfo(context, sOID,objectSelects());
							
							//SPEC: 10.26.2020: Modified for Defect #36663 -- END

							Iterator itrSubPartsFor = mlSubPartsFor.iterator();
							while (itrSubPartsFor.hasNext()) {
								Map mpSubstitutePart = (Map) itrSubPartsFor.next();
								sPId = validator.getStringEquivalentForStringList(
										mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_ID));
								sPType = validator.getStringEquivalentForStringList(
										mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_TYPE));
								sPName = validator.getStringEquivalentForStringList(
										mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_NAME));
								sPtitle = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_TITLE));
								sPMin = validator.getStringEquivalentForStringList(
										mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MIN_ACTUAL_PERCENT));
								sPMax = validator.getStringEquivalentForStringList(
										mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_MAX_ACTUAL_PERCENT));
								sPWet = validator.getStringEquivalentForStringList(
										mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_QUANTITY));

								sPTargetWet = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_TARGET_WEIGHT));
								sPMinWet = validator.getStringEquivalentForStringList(mpSubstitutePart.get(
										ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_MIN_ACTUAL_WEIGHT));
								sPMaxWet = validator.getStringEquivalentForStringList(mpSubstitutePart.get(
										ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_ATTRIBUTE_MAX_ACTUAL_WEIGHT));
								sPDiff = validator.getStringEquivalentForStringList(
										mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_QUATITY_ADJUSTMENT));
								sPDate = validator.getStringEquivalentForStringList(
										mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_VALID_DATE));
								sPProcessNotes = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_PROCESSING_NOTE));

								sChg = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_CHG));
								//sPhase = validator.getStringEquivalentForStringList(mpSubstitutePart
										//.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_PHASE));
								sRevision = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_REVISION));
								
								
								//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --START
								
								/*sFunction = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_FUNCTION));*/
								
								String strMFObjId =(String)mpSubstitutePart.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_APPLICATION);
								
								try
								{
									if (UIUtil.isNotNullAndNotEmpty(strMFObjId)) 
									{
										sFunction=util.getIdFromPhysicalIdFunction(context,strMFObjId);
									}
									}catch(Exception e){
										sFunction=ConstantsUtil.EMPTY_STRING;
									}
								//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --END
								/*sReportedFunction = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_REPORTEDFUNCTION));*/
								sReportedFunction = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.STR_RF));
								sValidStartDate = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_VALIDSTARTDATE));
								sValidUntilDate = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_VALIDUNTILDATE));
								
								//SPEC: <11.20.2020>: Modified for Defect 37430 by Amman## -- START
								//sComments = validator.getStringEquivalentForStringList(mpSubstitutePart
								//		.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_COMMENTS));
								sComments = validator.getStringEquivalentForStringList(mpSubstitutePart
										.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_PGARCHIVECOMMENTS));
								//SPEC: <11.20.2020>: Modified for Defect 37430 by Amman## -- END
								
								String sfPhase = (String) domObj.getInfo(context, ConstantsUtil.FORMULAPHASE);
								
								String sIpClass =validator.getStringEquivalentForStringList((mpSubstitutePart.get(ConstantsUtil.STR_IPCLASS)));

								//SPEC: <11.19.2020>: Modified for Defect 37430 by Amman ## -- START
								String sSPWET = ConstantsUtil.EMPTY_STRING;
								if(!(sPDiff.equals(ConstantsUtil.EMPTY_STRING))) {
									sSPWET = sPDiff;
								}
								//SPEC: <11.19.2020>: Modified for Defect 37430 by Amman ## -- END
								
								if(validator.isNotNullOrEmpty(sPDiff))
								{
									integerPlaces = sPDiff.indexOf(ConstantsUtil.SYMBL_SIGLEDOT);
									decimalPlaces = sPDiff.length() - integerPlaces - 1;
									sPDiff = String.valueOf(decimalformatter.format(Double.parseDouble(sPDiff)));
								}
								else
									sPDiff = ConstantsUtil.EMPTY_STRING;
								
								
								boolean showData = false;
								boolean bHasOwnership=false;
								
								//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --START	
								showData= util.checkHasAccess(context, null, sPId);
								
								/*if(util.isModificatinRequired())
								{
									SecurityService sec = new SecurityService();
									String sComp = sec.getUserCauthorities();
									StringList slUserOwnership=util.filterOwnerShip(sComp);
			
									bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sPId);
								
									if(!bHasOwnership)
									{
										sPName = ConstantsUtil.NO_ACCESS;
										sPType = ConstantsUtil.NO_ACCESS;
										sPId    = ConstantsUtil.NO_ACCESS;
										sPtitle = ConstantsUtil.NO_ACCESS;
										sPMin = ConstantsUtil.NO_ACCESS;
										sPMax = ConstantsUtil.NO_ACCESS;
										sPWet = ConstantsUtil.NO_ACCESS;
										sPMinWet = ConstantsUtil.NO_ACCESS;
										sPMaxWet = ConstantsUtil.NO_ACCESS;
										sPTargetWet = ConstantsUtil.NO_ACCESS;
										sPDiff = ConstantsUtil.NO_ACCESS;
										sPDate = ConstantsUtil.NO_ACCESS;
										sPProcessNotes = ConstantsUtil.NO_ACCESS;
										sCertficate = ConstantsUtil.NO_ACCESS;
										sfPhase = ConstantsUtil.NO_ACCESS;
										sRevision = ConstantsUtil.NO_ACCESS;
										sChg = ConstantsUtil.NO_ACCESS;
										sSequence = ConstantsUtil.NO_ACCESS;
										strRF = ConstantsUtil.NO_ACCESS;
								    }
								} else if(sct.isStaffAUGUser()) {
										
										if(sPType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
											String sFormulaClassif = util.getFormulaPropagateClassification(context, sPId);
											showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
										}else {
											showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
										}
									}else {
										StringList slHIRTypes = new StringList();
										slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
										slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
										slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
										slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
										slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
										
										if(slHIRTypes.contains(sPType)) {
											showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
										}else {
											showData=true;
										}
										
									}
									*/
								
								//SPEC: <11.21.2020>: Chandra Commented for Defect :37472 ## --END
								//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
								subsObj.close(context);
								//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
									if(!showData){
										sPId = ConstantsUtil.NO_ACCESS;
									}

								formatData(sbPName, sPName);
								formatData(sbPType, util.mapType(sPType));
								formatData(sbPId, sPId);
								formatData(sbPDescription, sPtitle);

								formatData(sbPMin, sPMin);
								formatData(sbPMax, sPMax);
								formatData(sbPWet, sPWet);

								formatData(sbPMinWt, sPMinWet);
								formatData(sbPMaxWt, sPMaxWet);
								formatData(sbPWetWt, sPTargetWet);

								formatData(sbPDiff, sPDiff);
								formatData(sbPDate, sPDate);
								formatData(sbPProces, sPProcessNotes);
								formatData(sbPCert, sCertficate);

								formatData(sbFName,sPName);
								formatData(sbFType,util.mapType(sPType));
								formatData(sbFId,sPId);
								formatData(sbFTitle,sPtitle);
								
								//SPEC: <11.19.2020>: Modified for Defect 37430 by Amman ## -- START
								//formatData(sbFWetWt,strWW);
								formatData(sbFWetWt,sSPWET);
								//SPEC: <11.19.2020>: Modified for Defect 37430 by Amman ## -- END

								formatData(sbChg,sChg);
								formatData(sbSFPhase, sfPhase);
								formatData(sbSPRevision, sRevision);
								formatData(sbFunction, sFunction);
								formatData(sbReportedFunction, sReportedFunction);
								formatData(sbValidStartDate, sValidStartDate);
								formatData(sbValidUntilDate, sValidUntilDate);
								formatData(sbComments, sComments);
							}

							mpSubstitutes.put(ConstantsUtil.SP_ID, sbPId.toString());
							mpSubstitutes.put(ConstantsUtil.SP_TYPE, sbPType.toString());
							mpSubstitutes.put(ConstantsUtil.SP_NAME, sbPName.toString());
							//mpSubstitutes.put(ConstantsUtil.SP_TITLE, sbPDescription.toString());
							mpSubstitutes.put(ConstantsUtil.MIN, sbPMin.toString());
							mpSubstitutes.put(ConstantsUtil.MAX, sbPMax.toString());
							mpSubstitutes.put(ConstantsUtil.SP_WET, sbPWet.toString());
							mpSubstitutes.put(ConstantsUtil.TWW, sbPWetWt.toString());
							mpSubstitutes.put(ConstantsUtil.WEM, sbPMaxWt.toString());
							mpSubstitutes.put(ConstantsUtil.WWM, sPMinWet.toString());
							mpSubstitutes.put(ConstantsUtil.DIFF, sbPDiff.toString());
							mpSubstitutes.put(ConstantsUtil.DATE, sbPDate.toString());
							mpSubstitutes.put(ConstantsUtil.PROCESS, sbPProces.toString());
							mpSubstitutes.put(ConstantsUtil.CERT, sbPCert.toString());
							//mpSubstitutes.put(ConstantsUtil.SF_TITLE, sbFTitle.toString());
							mpSubstitutes.put(ConstantsUtil.SF_ID, sbFId.toString());
							mpSubstitutes.put(ConstantsUtil.SF_TYPE, sbFType.toString());
							mpSubstitutes.put(ConstantsUtil.SF_NAME, sbFName.toString());
							mpSubstitutes.put(ConstantsUtil.SF_WET, sbFWetWt.toString());
							mpSubstitutes.put(ConstantsUtil.DESCRIPTION, strsubsInst.toString());
							mpSubstitutes.put(ConstantsUtil.INSTRUCTIONS, strsubsDesc.toString());
							mpSubstitutes.put(ConstantsUtil.CHG, sbChg.toString());
							mpSubstitutes.put(ConstantsUtil.SF_RAWMATERIALNAME, sbFTitle.toString());
							mpSubstitutes.put(ConstantsUtil.SP_RAWMATERIALNAME, sbPDescription.toString());
							//mpSubstitutes.put(ConstantsUtil.SP_PHASE, sbSPPhase.toString());
							mpSubstitutes.put(ConstantsUtil.PHASE, sbSFPhase.toString());
							mpSubstitutes.put(ConstantsUtil.SP_REVISION, sbSFRevision.toString());
							mpSubstitutes.put(ConstantsUtil.SF_REVISION, sbSPRevision.toString());
							mpSubstitutes.put(ConstantsUtil.FUNCTIONS, sbFunction.toString());
							mpSubstitutes.put(ConstantsUtil.SF_REPORTEDFUNCTION, sbReportedFunction.toString());
							mpSubstitutes.put(ConstantsUtil.VALIDSTARTDATE, sbValidStartDate.toString());
							mpSubstitutes.put(ConstantsUtil.VALIDUNTILDATE, sbValidUntilDate.toString());
							mpSubstitutes.put(ConstantsUtil.COMMENT, sbComments.toString());
							mpSubstitutes.put(ConstantsUtil.SEQUENCENUMBER, sbSequence.toString());
							mpSubstitutes.put(ConstantsUtil.SF_WEM, sbPMinWt.toString());
							mpSubstitutes.put(ConstantsUtil.SF_WWM, sbPMaxWt.toString());

							mpProces.put(i, mpSubstitutes);
							i++;
						}
					}

				}
			}
			return mpProces;
		} catch (Exception e) {
			LOGGER.error("Error from program FormulaPartBO:  getFormulationSubstituteDetails"+e.getMessage());
			e.printStackTrace();
			return new HashMap();
		}
	}

	//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END
	
	
	/**
	 * This method will verify the substitute Ownership.
	 * SPEC: 10/29/2020: Added for 18x.5 DEV -- START
	 * @param context
	 * @param objectMap
	 * @return
	 */
	
	public String checkFormulaIngredHasAccess(Context context, Map objectMap) {
	
		StringBuilder  sbReturnVal = new StringBuilder();
		boolean showData = true;
		boolean bHasOwnership=false;
		
		String sFinalChildId= ConstantsUtil.EMPTY_STRING;
		try
		{
			StringValidatorUtil validator = new StringValidatorUtil();
			
			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership=util.filterOwnerShip(sComp);
			
		if(objectMap.containsKey(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_ID))
			if(null!=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_ID))) 
			{
				String sClassName = objectMap.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_ID).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
				{
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_TYPE));
					String strSubPartId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_ID));
					
					DomainObject doEachChild = new DomainObject(strSubPartId);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					StringList slSelect = new StringList();
					slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					Map mpIpClass = doEachChild.getInfo(context, slSelect);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doEachChild.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					//commented by Ganesh for security impl----->start
					/*if(util.isModificatinRequired())
					{
						//For EBP User
						showData = util.checkOwnerShip(context, slUserOwnership, strSubPartId);
						
					}else if(sct.isStaffAUGUser())
					{
						//For Staff Aug USer check 
						if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							//Validation for Hir checks on Formulation
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else
						{
							//Validation for Hir checks for other than Formulation
							showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
						}
					}else 
					{
						//For Internal User check
						if(slHIRTypes.contains(strSubPartType)) 
						{
							//Validation for Hir checks on Formulation
							if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else 
							{
								//Validation for Hir checks for other than Formulation
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
						}else 
						{
							//If it is Non-Hir we can show without checks for internal user
							showData=true;
						}
					}*/
					//commented by Ganesh for security impl----->end
					//modified by Ganesh for security impl----->start
					showData = util.checkHasAccess(context, null, strSubPartId);
					//modified by Ganesh for security impl----->end
					
					if(!showData) {
						strSubPartId=ConstantsUtil.NO_ACCESS;
					}
					
					sbReturnVal.append(strSubPartId);
				}else
				{
					//For Multi Substitutes
					StringList slSubPartType = (StringList)objectMap.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_TYPE);
					StringList slSubPartId = (StringList)objectMap.get(ConstantsUtil.SELECT_FBOM_SUBSTITUTE_ID);
					
					for(int i =0; i<slSubPartId.size(); i++) 
					{
						String sEachChildId = slSubPartId.getElement(i);
						DomainObject doEachChild = new DomainObject(sEachChildId);
						DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
						StringList slSelect = new StringList();
						slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
						Map mpIpClass = doEachChild.getInfo(context, slSelect);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
						doEachChild.close(context);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						//StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
						DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
						//commented by Ganesh for security impl----->start
						/*if(util.isModificatinRequired())
						{
							//For EBP User
							showData = util.checkOwnerShip(context, slUserOwnership, sEachChildId);
							
						}else if(sct.isStaffAUGUser())
						{
							//For Staff Aug USer check 
							if(slSubPartType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								//Validation for Hir checks on Formulation
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sEachChildId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else
							{
								//Validation for Hir checks for other than Formulation
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
						}else 
						{
							//For Internal User check
							if(slHIRTypes.contains(slSubPartType.getElement(i))) 
							{
								//Validation for Hir checks on Formulation
								if(slSubPartType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sEachChildId);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else 
								{
									//Validation for Hir checks for other than Formulation
									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
								}
							}else 
							{
								//If it is Non-Hir we can show without checks for internal user
								showData=true;
							}
						}*/
						//commented by Ganesh for security impl----->end
						//commented by Ganesh for security impl----->start
						showData = util.checkHasAccess(context, null, sEachChildId);
						//commented by Ganesh for security impl----->end
	
						
						if(!showData) {
							sEachChildId=ConstantsUtil.NO_ACCESS;
						}
						util.formatDataWithAndSymbol(sbReturnVal,sEachChildId);
				}//End For loop
					
			  }//End of Class Name	
			
			}else
			{	//If no Substitue found
				return ConstantsUtil.EMPTY_STRING;
			}
			
		}catch(Exception e){
			
			LOGGER.error("Error from FormulaPartBO :  checkFormulaIngredHasAccess" + e);
			return ConstantsUtil.EMPTY_STRING;
		}
		return sbReturnVal.toString();
	}
	
	
	//shashank
	
	public Map getSubstituteDetails(Context context, String sFormulationProcess, String sTargetPercConsumed) throws Exception
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbPName = new StringBuilder();
		StringBuilder sbPId = new StringBuilder();
		StringBuilder sbPType = new StringBuilder();
		StringBuilder sbPRev = new StringBuilder();
		StringBuilder sbPCurrent = new StringBuilder();
		StringBuilder sbPDescription = new StringBuilder();
		StringBuilder sbPMin = new StringBuilder();
		StringBuilder sbPMax = new StringBuilder();
		StringBuilder sbPWet = new StringBuilder();

		StringBuilder sbPMinWt = new StringBuilder();
		StringBuilder sbPMaxWt = new StringBuilder();
		StringBuilder sbPWetWt = new StringBuilder();
		StringBuilder sbPDiff = new StringBuilder();
		StringBuilder sbPDate = new StringBuilder();
		StringBuilder sbPProces = new StringBuilder();
		StringBuilder sbPCert = new StringBuilder();

		StringBuilder sbFName = new StringBuilder();
		StringBuilder sbFId = new StringBuilder();
		StringBuilder sbFType = new StringBuilder();

		StringBuilder sbFTitle = new StringBuilder();
		StringBuilder sbFWetWt = new StringBuilder();
		StringBuilder sbFMaxWt = new StringBuilder();
		StringBuilder sbFMinWt = new StringBuilder();

		StringBuilder sbHeader = new StringBuilder();
		StringBuilder sbInst = new StringBuilder();
		StringBuilder sbDec = new StringBuilder();
		
		StringBuilder sbChg = new StringBuilder();
		StringBuilder sbSPPhase = new StringBuilder();
		StringBuilder sbSFPhase = new StringBuilder();
		StringBuilder sbSPRevision = new StringBuilder();
		StringBuilder sbSFRevision = new StringBuilder();
		StringBuilder sbFunction = new StringBuilder();
		StringBuilder sbReportedFunction = new StringBuilder();
		StringBuilder sbSFReportedFunction = new StringBuilder();
		StringBuilder sbValidStartDate = new StringBuilder();
		StringBuilder sbValidUntilDate = new StringBuilder();
		StringBuilder sbComments = new StringBuilder();
		StringBuilder sbSequence = new StringBuilder();
		StringBuilder sbRF = new StringBuilder();
		StringBuilder sbDescription = new StringBuilder();
		Map mpProces = new TreeMap();
		StringList slAvoidDuplicate = new StringList();
		
		try
		{
			int k=0;
			boolean showData=false;
			MapList _substitutePartList = new MapList();
			MapList _finalsubstitutePartList        = new MapList();
			Set<String> virtualIntermediateList = new HashSet<String>();
			Map targetPercentConsumedMap = new HashMap();
    		String isVIFromFormulation="true";

			DomainObject domObj = new DomainObject(sFormulationProcess);
			String objName				= (String) domObj.getInfo(context, ConstantsUtil.SELECT_NAME);
			StringList slEBOMSubs                   = null;
			StringList relsel                       = new StringList();

			relsel.add(DomainRelationship.SELECT_ID);
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_INPUTVALUE);
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_INPUTVALUE);
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET);
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET);
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE_VALUE);
			relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC);
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTITUTEINSTRUCTIONS);

			StringList strObjList = new StringList(5);
			strObjList.add(ConstantsUtil.SELECT_ID);
			strObjList.add(ConstantsUtil.SELECT_TYPE);
			strObjList.add(ConstantsUtil.SELECT_NAME);
			strObjList.add(ConstantsUtil.SELECT_REVISION);
			strObjList.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			strObjList.add(ConstantsUtil.REPORTED_FUNCTION);
			strObjList.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_VALIDSTARTDATE);
			strObjList.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVALIDUNTILDATE);
			strObjList.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
			strObjList.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTITUTEINSTRUCTIONS);
			strObjList.add(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
			strObjList.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			relsel.add("to.fromrel.from.name");
			relsel.add("to[FBOM Substitute].fromrel.attribute[Find Number]");
			//sanjeeva
			relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			relsel.add("to.name");
			//Sanjeeva -end
			MapList substituteList = domObj.getRelatedObjects(context,
					ConstantsUtil.REL_FBOM,
					ConstantsUtil.TYPE_RAWMATERIALPART.concat(",").concat(ConstantsUtil.TYPE_FORMULATIONPHASE)
							.concat(",").concat(ConstantsUtil.TYPE_FORMULATIONPART).concat(",")
							.concat(ConstantsUtil.TYPE_PGRAWMATERIAL).concat(",")
							.concat(ConstantsUtil.TYPE_PGMASTERRAWMATERIAL).concat(",")
							.concat(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART),
					strObjList,
					relsel,
					false,
					true,
					(short)0,
					"",
					"",
					0);
			//Sanjeeva-start
			Boolean findNumberIsNotEmpty = true;
			String strType = ConstantsUtil.EMPTY_STRING;
			String strName = ConstantsUtil.EMPTY_STRING;
			String strState = ConstantsUtil.EMPTY_STRING;;
			String strRev = ConstantsUtil.EMPTY_STRING;
			String strSequenceNum = ConstantsUtil.EMPTY_STRING;
			String strSortSequence = ConstantsUtil.EMPTY_STRING;
			String strSequenceNum2 = ConstantsUtil.EMPTY_STRING;
			String strSortSequence1 = ConstantsUtil.EMPTY_STRING;
			String strFindNum = ConstantsUtil.EMPTY_STRING;
			HashMap mpSFSeq = new HashMap ();
			Map mpFormulaIngredients = new HashMap();
			String strSubKey = new String();

			
			for (int i = 0; i <substituteList.size(); i++){
				mpFormulaIngredients = (Map) substituteList.get(i);
				strFindNum = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				
				if(!validator.isNotNullOrEmpty(strFindNum) || strFindNum.equalsIgnoreCase("NaN"))
				{
					strFindNum = ConstantsUtil.GEN_NUM_ZERO;
					findNumberIsNotEmpty=false;
				}
				strType = (String) mpFormulaIngredients.get(ConstantsUtil.SELECT_TYPE);
				if(strType.equals(ConstantsUtil.TYPE_FORMULATIONPHASE)){
					strSequenceNum  = strFindNum;
					strSequenceNum2 = strSequenceNum;
				}
				else {
					strSequenceNum =strSequenceNum2.concat(ConstantsUtil.SYMBL_DOT).concat(strFindNum);
				}
				
				String strTempName = (String)mpFormulaIngredients.get("to.name");
				if (strTempName !="" && !strTempName.isEmpty()) {
					mpSFSeq.put(strTempName, strSequenceNum);
				}
				
			}
			/////Sanjeeva-end
			
			String sPhase = (String) domObj.getInfo(context, ConstantsUtil.FORMULAPHASE);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domObj.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator itr1 = substituteList.iterator();
			Map tempmap1 = null;
			StringList sIDList = new StringList();
			while (itr1.hasNext())
				{
					Map relmap                  = (Map) itr1.next();
					String sEBOMID              = (String)relmap.get("id[connection]");
					String strMin = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_INPUTVALUE);
					String strMax = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_INPUTVALUE);
					String strApplication = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
					String strWetPerc = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					String strSubInst = validator.getStringEquivalentForStringList(relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTITUTEINSTRUCTIONS));
					String strProcessingNote = validator.getStringEquivalentForStringListWithComma(relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE_VALUE));
					String sComments = validator.getStringEquivalentForStringListWithComma(relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
					//Update Substitute Parts
					String sSubForName  = (String)relmap.get(ConstantsUtil.SELECT_NAME);
					String sSubForId  = (String)relmap.get(ConstantsUtil.SELECT_ID);
					String sSubForRmn  = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sSubForRevision  = (String)relmap.get(ConstantsUtil.SELECT_REVISION);
					String sSubForType  = (String)relmap.get(ConstantsUtil.SELECT_TYPE);
					String sSubForPhase  = sPhase;
					String sSubForSq  = (String)relmap.get("to[FBOM Substitute].fromrel.attribute[Find Number]");
					String sSubForInstruction="";
					if(null!=relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC)) {
						String objectType = relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC).getClass().getSimpleName();
						if(objectType.equalsIgnoreCase("String")) {
							sSubForInstruction  = validator.getStringEquivalentForStringListWithComma(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC));
						}else {
							StringList slSubForInst = (StringList)relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC);
							sSubForInstruction = slSubForInst.get(0);
						}
					}
					
					String strTargetWeightWet = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
					String strMinWeightWet = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET);
					String strMaxWeightWet = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET);
					String sSubForRF  = (String)relmap.get(ConstantsUtil.REPORTED_FUNCTION);
					String sStartDate  = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_VALIDSTARTDATE);
					String sEndDate  = (String)relmap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVALIDUNTILDATE);
					String sSubCertification  = (String)relmap.get(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
					String sFunction = "";
					if (UIUtil.isNotNullAndNotEmpty(strApplication))
					{
						sFunction=util.getIdFromPhysicalIdFunction(context,strApplication);
					}else
					{
						sFunction=ConstantsUtil.EMPTY_STRING;
					}
					
					String strCommand           = "print connection $1 select $2 dump $3";
					String strMessage = MqlUtil.mqlCommand(context, strCommand, sEBOMID,
							"frommid[".concat(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE).concat("].id"), "|");
	
					slEBOMSubs                  = FrameworkUtil.split(strMessage,"|");
					String sTargetPercent="";
					if(UIUtil.isNullOrEmpty(strMessage)){
						DomainRelationship domEBOMRel = new DomainRelationship(sEBOMID);
				        Map attributeMap = domEBOMRel.getAttributeMap(context, true);
				    	String viPhysicalId =(String) attributeMap.get(ConstantsUtil.SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID);
				    	if(UIUtil.isNotNullAndNotEmpty(viPhysicalId)){
				    		virtualIntermediateList.add(viPhysicalId);
				    		String quantityInVI = (String) attributeMap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_SELECT_ATTRIBUTE_TARGET_PERCENT_WET_IN_VIRTUAL_INTERMEDIATE);
				    		String currentQuantity = (String) attributeMap.get(ConstantsUtil.QUANTITY);
				    		double targetPercent = Double.parseDouble(currentQuantity)/Double.parseDouble(quantityInVI)*100.0;
				    		sTargetPercent = Double.toString(targetPercent);
				    	}
	
	     			}
					
					
					/*String strCommand2 = "print connection $1 select $2 dump $3";
					String strMessage2 = MqlUtil.mqlCommand(context,strCommand2,sEBOMID,"attribute[Comment].value","|");
					StringList slEBOMSubs2                  = FrameworkUtil.split(strMessage,"|");
					Iterator ebomsubsItr2        = slEBOMSubs2.iterator();
					String strVUD="";
					while(ebomsubsItr2.hasNext())
					{
						strVUD =  (String) ebomsubsItr2.next();
					}*/
					
					//attribute[Processing Note].value
					
					
					Iterator ebomsubsItr        = slEBOMSubs.iterator();
					String sEBOMSubstituteRelid = "";
					StringList slSubstituteForParentList = new StringList();
					
					//shashank
					String subRelId 		= null;
					String subId 			= null;
					int counter 			= 0 ;
					//shashank
					
					while(ebomsubsItr.hasNext())
					{
						//shashank
						sEBOMSubstituteRelid            = (String) ebomsubsItr.next();
						String sCommand  		= "print connection $1 select $2 $3 dump $4";
					    String strResult = MqlUtil.mqlCommand(context,sCommand,sEBOMSubstituteRelid,"fromrel.id","fromrel.from.id","|");
				    	StringList subIdAndPhaseId = FrameworkUtil.split(strResult,"|");
	    			    subId           	 		= subIdAndPhaseId.get(0);
	    			    MapList mresultList =  new MapList();
						Map mapDetails = new HashMap();
						StringList slrelselects = new StringList(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
						mresultList = DomainRelationship.getInfo(context, new String[]{subId}, slrelselects);
	                	                mapDetails = (Map) mresultList.get(0);
	                	                String strAttributeValue = (String)mapDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
    	                
    	                //if(ConstantsUtil.ATTRIBUTE_FIND_NUMBER.equals(sAttribute)){
	    			    	//StringList slrelselects = new StringList(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
                    		String sPhaseId = subIdAndPhaseId.get(1);
                    		DomainObject phaseObj = new DomainObject(sPhaseId);                		
                    		StringList sObjectSelects  = StringList.create(DomainConstants.SELECT_ID, DomainConstants.SELECT_TYPE,
    								DomainConstants.SELECT_NAME, DomainConstants.SELECT_REVISION);
                    		StringList slRelSelects 	= StringList.create(DomainRelationship.SELECT_ID, 
    			  					  "attribute[".concat(ConstantsUtil.ATTRIBUTE_FIND_NUMBER).concat("].value"));
                    		
                    		MapList phaseInHierarchy = phaseObj.getRelatedObjects(context,
                    				ConstantsUtil.RELATIONSHIP_FBOM,
                    				ConstantsUtil.TYPE_FORMULATIONPROCESS.concat(",").concat(ConstantsUtil.TYPE_FORMULATIONPHASE),
                    				sObjectSelects,
    								slRelSelects,
    								true,
    								false,
    								(short)0,
    								"",
    								"",
                                    0); 
                			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
                    		phaseObj.close(context);
                			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
                    		
                    		phaseInHierarchy.sort("level", "descending", "integer");
                    		Iterator phaseItr = phaseInHierarchy.iterator();
                    			String strFindNumber ="";
                    				while(phaseItr.hasNext()){
                    					Map mp = (Hashtable)phaseItr.next();
                    					String realFindNumber =(String)mp.get("attribute[".concat(ConstantsUtil.ATTRIBUTE_FIND_NUMBER).concat("].value"));
                    					strFindNumber = strFindNumber.concat(realFindNumber).concat(".");
                    				}                		
                    		strAttributeValue = strFindNumber.concat(strAttributeValue);
                    	//}
						//shashank
						
						
						StringList slSubstituteForList = new StringList();
						StringList slSubForList = new StringList();
						tempmap1   = new HashMap();
						tempmap1.put("EBOM ID",sEBOMID);
						//EBOM Substitute Id
						//sEBOMSubstituteRelid            = (String) ebomsubsItr.next();
						tempmap1.put("id[connection]",sEBOMSubstituteRelid);
						SelectList resultSelects        = new SelectList(1);
						String[] RelIdArray             = new String[1];
						RelIdArray[0]                   = sEBOMSubstituteRelid;
						resultSelects.add("to.".concat(DomainObject.SELECT_ID));
						resultSelects.add("fromrel.to.".concat(DomainObject.SELECT_ID));
						resultSelects.add("fromrel.from.".concat(DomainObject.SELECT_ID));
						resultSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
						resultSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET);
						resultSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET);
						resultSelects.add(DomainObject.getAttributeSelect(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
						MapList resultList              = DomainRelationship.getInfo(context,
								RelIdArray,
								resultSelects);
						Iterator itr                    = resultList.iterator();
						Map map = (Map) itr.next();
						String strsubsPartId            = (String)map.get("to.id");
	    				if(UIUtil.isNotNullAndNotEmpty(isVIFromFormulation)){
							/*tempmap1.put("disableSelection",isVIFromFormulation);
							tempmap1.put("targetPercentConsumed","");*/
						}
	    				
	    				if(!slAvoidDuplicate.contains(strsubsPartId)){
	    					slAvoidDuplicate.add(strsubsPartId);
	    				}else {
	    					k--;
	    				}
	    				
						DomainObject subsObj = new DomainObject(strsubsPartId);
						String subsType = (String) subsObj.getInfo(context, ConstantsUtil.SELECT_TYPE);
						if (!subsType.equals((String)PropertyUtil.getSchemaProperty(context, "type_ParentSub")))
						{
							_finalsubstitutePartList.add((Map)tempmap1);
						}
						else
						{
							Map mpSubstitutes = new HashMap();
							if(sIDList.contains(strsubsPartId))
							{
								//mpSubstitutes = new HashMap();
								util.formatData(sbPName, sSubForName);
								showData= util.checkHasAccess(context, null, sSubForId);
								if(showData) {
									util.formatData(sbPId, sSubForId);
								}
								else {
									util.formatData(sbPId, ConstantsUtil.NO_ACCESS);
								}
								util.formatData(sbPType, sSubForType);
								util.formatData(sbPDescription, sSubForRmn);
								util.formatData(sbPRev, sSubForRevision);
								util.formatData(sbSPPhase, sSubForPhase);
								util.formatData(sbPWetWt, strTargetWeightWet);
								util.formatData(sbPMinWt, strMinWeightWet);
								util.formatData(sbPMaxWt, strMaxWeightWet);
								util.formatData(sbPWet, strWetPerc);
								util.formatData(sbPDiff, validator.isNotNullOrEmpty(strWetPerc)?String.format("%.6f", new BigDecimal(strWetPerc)):ConstantsUtil.EMPTY_STRING);
								util.formatData(sbReportedFunction, sSubForRF);
								util.formatData(sbValidStartDate, sStartDate);
								util.formatData(sbValidUntilDate, sEndDate);
								util.formatData(sbPCert, sSubCertification);
								util.formatData(sbFunction, sFunction);
								util.formatData(sbSequence, strAttributeValue);
								util.formatData(sbComments, sComments);
								util.formatData(sbPMin, strMin);
								util.formatData(sbPMax, strMax);
								util.formatData(sbPProces, strProcessingNote);
								slSubstituteForParentList.add((String)map.get("fromrel.from.id")); 
							}
							else
							{
								//mpSubstitutes = new HashMap();
								sbDescription=new StringBuilder();
								sbFName=new StringBuilder();
								sbFId=new StringBuilder();
								sbFType=new StringBuilder();
								sbSFRevision=new StringBuilder();
								sbFWetWt=new StringBuilder();
								sbFMaxWt=new StringBuilder();
								sbFMinWt=new StringBuilder();
								sbFTitle=new StringBuilder();
								sbPName=new StringBuilder();
								sbPId=new StringBuilder();
								sbPType=new StringBuilder();
								sbPDescription=new StringBuilder();
								sbPRev=new StringBuilder();
								sbSPPhase=new StringBuilder();
								sbPWetWt=new StringBuilder();
								sbPMinWt=new StringBuilder();
								sbPMaxWt=new StringBuilder();
								sbPWet=new StringBuilder();
								sbInst=new StringBuilder();
								sbPDiff=new StringBuilder();
								sbReportedFunction=new StringBuilder();
								sbSFReportedFunction=new StringBuilder();
								sbPProces=new StringBuilder();
								sbPCert=new StringBuilder();
								sbFunction=new StringBuilder();
								sbSequence=new StringBuilder();
								sbComments=new StringBuilder();
								sbPMin=new StringBuilder();
								sbPMax=new StringBuilder();
								sbPProces= new StringBuilder();
								
								//util.formatData(sbPName, sSubForName);
								showData= util.checkHasAccess(context, null, sSubForId);
								if(showData) {
									util.formatData(sbPId, sSubForId);
								}
								else {
									util.formatData(sbPId, ConstantsUtil.NO_ACCESS);
								}
								
								util.formatData(sbPType, sSubForType);
								util.formatData(sbPDescription, sSubForRmn);
								util.formatData(sbPRev, sSubForRevision);
								util.formatData(sbSPPhase, sSubForPhase);
								util.formatData(sbPWetWt, strTargetWeightWet);
								util.formatData(sbPMinWt, strMinWeightWet);
								util.formatData(sbPMaxWt, strMaxWeightWet);
								util.formatData(sbPWet, strWetPerc);
								util.formatData(sbReportedFunction, sSubForRF);
								util.formatData(sbFunction, sFunction);
								util.formatData(sbComments, sComments);
								util.formatData(sbPMin, strMin);
								util.formatData(sbPMax, strMax);
								util.formatData(sbPProces, strProcessingNote);
								util.formatData(sbPDiff, validator.isNotNullOrEmpty(strWetPerc)?String.format("%.6f", new BigDecimal(strWetPerc)):ConstantsUtil.EMPTY_STRING);
								
								slSubstituteForParentList.add((String)map.get("fromrel.from.id"));
								sIDList.add(strsubsPartId);
								StringList objectSelects = new StringList();
								StringList relSelects = new StringList();
								objectSelects.add(ConstantsUtil.SELECT_NAME);
								objectSelects.add(ConstantsUtil.SELECT_ID); 
								objectSelects.add(ConstantsUtil.SELECT_TYPE);
								objectSelects.add(ConstantsUtil.SELECT_REVISION);
								objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
								objectSelects.add(ConstantsUtil.ATTRIBUTE_MIN_INPUT);
								objectSelects.add(ConstantsUtil.ATTRIBUTE_MIN_INPUT);
								objectSelects.add(ConstantsUtil.REPORTED_FUNCTION);
								objectSelects.add(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
								objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
								relSelects.add("from.".concat(DomainObject.SELECT_ID));	        			 	        			 
								relSelects.add(DomainRelationship.SELECT_ID);
								relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
								relSelects.add(ConstantsUtil.ATTRIBUTE_MIN);
								relSelects.add(ConstantsUtil.ATTRIBUTE_MAX);
								relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
								relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET);
								relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET);
								relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE);
								relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
								relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET);
								relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET);
								relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_ADJUSTMENT);
								relSelects.addElement(DomainObject.getAttributeSelect(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
								
	
								MapList subInFBOM = subsObj.getRelatedObjects(context,
										ConstantsUtil.REL_FBOM,
										"*",
										objectSelects,
										relSelects,
										false,
										true,
										(short) 1,
										null,
										null,
										0);
								//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
								subsObj.close(context);
								//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
								//System.out.println("subInFBOM---->"+subInFBOM);
								
								//Update Substitute Part
								if(subInFBOM.size()>0) {
									
									Iterator itrSubPart = subInFBOM.iterator();
									while(itrSubPart.hasNext()) {
										Map mSubPart                  = (Map) itrSubPart.next();
										//Update Substitute For
										String sSubPartName  = (String)mSubPart.get(ConstantsUtil.SELECT_NAME);
										String sSubPartId  = (String)mSubPart.get(ConstantsUtil.SELECT_ID);
										String sSubPartRmn  = validator.getStringEquivalentForStringList(mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
										String sSubPartType  = (String)mSubPart.get(ConstantsUtil.SELECT_TYPE);
										String sSubPartPhase  = sPhase;
										String sSubPartRev  = (String)mSubPart.get(ConstantsUtil.SELECT_REVISION);
										String sSubPartMinPerc  = (String)mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET);
										String sSubPartWetPerc  = (String)mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
										String sSubPartMaxPerc  = (String)mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET);
										String sSubPartTww  = (String)mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
										String sSubPartWME  = (String)mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET);
										String sSubPartWMM  = (String)mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET);
										String sSubPartWD  = (String)mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_ADJUSTMENT);
										String sSubPartRFunction  = validator.getStringEquivalentForStringList(mSubPart.get(ConstantsUtil.REPORTED_FUNCTION));
										String sSubStartDate = validator.getStringEquivalentForStringList(mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_VALIDSTARTDATE));
										String sSubEndDate = validator.getStringEquivalentForStringList(mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVALIDUNTILDATE));
										String sCertification = validator.getStringEquivalentForStringList(mSubPart.get(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME));
										String sSubComments = validator.getStringEquivalentForStringList(mSubPart.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT));

										showData= util.checkHasAccess(context, null, sSubPartId);
										if(showData) {
											util.formatData(sbPId, sSubPartId);
										}
										else {
											util.formatData(sbPId, ConstantsUtil.NO_ACCESS);
										}
										util.formatData(sbPName, sSubPartName);
										util.formatData(sbPDescription, sSubPartRmn);
										util.formatData(sbPRev, sSubPartRev);
										util.formatData(sbPType, sSubPartType);
										util.formatData(sbSPPhase, sSubForPhase);
										//util.formatData(sbSPSeq, sSubForSq);
										//util.formatData(sbSPInst, sSubForInstruction);
										util.formatData(sbPWetWt, sSubPartWetPerc);
										util.formatData(sbPMinWt, sSubPartWME);
										util.formatData(sbPMaxWt, sSubPartWMM);
										if(sTargetPercent.equals("")) {
											util.formatData(sbPWet, "0.0");
										}else {
											util.formatData(sbPWet, sSubPartWetPerc);
										}
										util.formatData(sbReportedFunction, sSubPartRFunction);
										util.formatData(sbDescription, sSubPartRmn);
										util.formatData(sbValidStartDate, sSubStartDate);
										util.formatData(sbValidUntilDate, sSubEndDate);
										util.formatData(sbPCert, sCertification);
										util.formatData(sbComments, sSubComments);
										util.formatData(sbPDiff, validator.isNotNullOrEmpty(sSubPartWD)?String.format("%.6f", new BigDecimal(sSubPartWD)):ConstantsUtil.EMPTY_STRING);
									}
								}
								
								
								
								String sSubInEBOMSize = String.valueOf(subInFBOM.size());
								tempmap1.put("SubInEBOMSize",sSubInEBOMSize);
								
								
								String strCommand1  	= "print bus $1 select $2 $3 $4 $5 $6 $7 $8 $9 $10 $11 $12 $13 $14 $15 $16 $17 $18 dump $19";
								String phaseId = MqlUtil.mqlCommand(context, strCommand1, strsubsPartId,
										"to.fromrel.to.type",
										"to.fromrel.to.name", 
										"to.fromrel.to.revision", 
										"to.fromrel.to.id",
										"to.".concat(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY),
										"to.".concat(ConstantsUtil.SELECT_ATTRIBUTE_NEEDS_UPDATE_VALUE),
										"to.fromrel." + ConstantsUtil.SELECT_ATTRIBUTE_MAX,
										"to.fromrel." + ConstantsUtil.SELECT_ATTRIBUTE_MIN,
										"to.fromrel." + ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION,
										"to.fromrel." + ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE + "].value",
										"to.fromrel." + ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT,
										"to." + ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET,
										"to." + ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET,
										new StringBuilder("to.").append(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_PGCHANGE)).toString(),
										"to.".concat(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_ADJUSTMENT),
										"to.fromrel.to."+ConstantsUtil.REPORTED_FUNCTION,
										"to.fromrel.".concat(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY),
										"|");
								StringList slSubForDetails = FrameworkUtil.split(phaseId, "|");
								
								
								int size = slSubForDetails.size();
								int iNoOfIterations = (size / 17);
								int iCounter = 0;
								int iNameCounter 	= 1*iNoOfIterations;
								int iTypeCounter 	= iNoOfIterations;
								int iRevCounter 	= 2*iNoOfIterations;
								int iIdCounter 		= 3*iNoOfIterations;
								int iQtyCounter 	= 4*iNoOfIterations;
								int iNeedsUpdateCounter = 5*iNoOfIterations;
								int iMaxCounter 	= 6*iNoOfIterations;
								int iMinCounter 	= 7*iNoOfIterations;
								int iAppCounter 	= 8*iNoOfIterations;
								int iProcessingNoteCounter 	= 9*iNoOfIterations;
								int iTargetweightWetCounter 	= 10*iNoOfIterations;
								int iMinWeightWetCounter 	= 11*iNoOfIterations;
								int iMaxWeightWetCounter = 12*iNoOfIterations;
								int iChgCounter = 13*iNoOfIterations;
								int iQtyAdjCounter = 14*iNoOfIterations;
								int iReportedFunction = 15*iNoOfIterations;
								int iSFQtyCounter = 16*iNoOfIterations;
								while(iCounter < iNoOfIterations)
								{
									String sSubForId2 = ((String) slSubForDetails.get(iIdCounter)).trim();
									String sSubForType2 = ((String) slSubForDetails.get(iCounter)).trim();
									String sSubForName2 =((String) slSubForDetails.get(iTypeCounter)).trim();
									String sSubForRev2 = ((String) slSubForDetails.get(iRevCounter)).trim();
									String sSubForMax =((String) slSubForDetails.get(iMaxCounter)).trim();
									String sSubForMin =((String) slSubForDetails.get(iMinCounter)).trim();
									String sSubForMaxWetWt =((String) slSubForDetails.get(iMaxWeightWetCounter)).trim();
									String sSubForMinWetwt =((String) slSubForDetails.get(iMinWeightWetCounter)).trim();
									String sSubForTargWt =((String) slSubForDetails.get(iTargetweightWetCounter)).trim();
									String sSubForQtyWt =((String) slSubForDetails.get(iQtyCounter)).trim();
									String sSubForNeedsUpdate =((String) slSubForDetails.get(iNeedsUpdateCounter)).trim();
									String sSubForQtyAdjWt =((String) slSubForDetails.get(iQtyAdjCounter)).trim();
									String sSubForRepFunc =((String) slSubForDetails.get(iReportedFunction)).trim();
									String sSubForProcNote =((String) slSubForDetails.get(iProcessingNoteCounter)).trim();
									String sSubForWetPerc =((String) slSubForDetails.get(iSFQtyCounter)).trim();
									
									util.formatData(sbFName, sSubForName2);
									util.formatData(sbPName, sSubForName2);
									//Sanjeeva -start
									//util.formatData(sbSequence, strAttributeValue);
									util.formatData(sbSequence, (String)mpSFSeq.get(sSubForName2));
									//Sanjeeva -end
									
									util.formatData(sbFType, sSubForType2);
									//util.formatData(sbFWetWt, strWetPerc);
									showData= util.checkHasAccess(context, null, sSubForId2);
									if(showData) {
										util.formatData(sbFId, sSubForId2);
									}
									else {
										util.formatData(sbFId, ConstantsUtil.NO_ACCESS);
									}
									
									util.formatData(sbSFRevision, sSubForRev2);
									util.formatData(sbSFPhase, sPhase);
									util.formatData(sbFWetWt, sSubForWetPerc);
									util.formatData(sbFMaxWt, sSubForMaxWetWt);
									util.formatData(sbFMinWt, sSubForMinWetwt);
									if(sbInst.toString().length()<1) {
										util.formatData(sbInst, sSubForInstruction);
									}
									util.formatData(sbFTitle, sSubForRmn);
									util.formatData(sbPWetWt, sSubForTargWt);
									//util.formatData(sbPDiff, validator.isNotNullOrEmpty(sSubForQtyAdjWt)?String.format("%.6f", new BigDecimal(sSubForQtyAdjWt)):ConstantsUtil.EMPTY_STRING);
									util.formatData(sbSFReportedFunction, sSubForRepFunc);
									util.formatData(sbPProces, sSubForProcNote);
									
									
									/*
									String[] arraySFNameSize = sbFName.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] arraySFIdSize = sbFId.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] arraySFTypeSize = sbFType.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] arraySFRevSize = sbSFRevision.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] arraySFWWSize = sbFWetWt.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] arraySFRMNSize = sbFTitle.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] arraySFPhaseSize = sbSFPhase.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] arraySFRFSize = sbSFReportedFunction.toString().split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									int sizeOfArraySF = arraySFNameSize.length;
									int token = -1;*/
									/*if(sizeOfArraySF>1) {
										for(int i=0;i<sizeOfArraySF; i++) {
											if(null!=arraySFNameSize[i]) {
												String sSF = arraySFNameSize[i].toString();
												if(!sbPName.toString().contains(sSF)) {
													util.formatData(sbPName, sSF);
													
													String sId = arraySFIdSize.length>i?arraySFIdSize[i]:ConstantsUtil.EMPTY_STRING;
													if(validator.isNotNullOrEmpty(sId)) {
														showData= util.checkHasAccess(context, null, sId);
														if(showData) {
															util.formatData(sbPId, sId);
														}
														else {
															util.formatData(sbPId, ConstantsUtil.NO_ACCESS);
														}
													}else {
														util.formatData(sbPId, ConstantsUtil.EMPTY_STRING);
													}
													util.formatData(sbPType, arraySFTypeSize.length>i?arraySFTypeSize[i]:ConstantsUtil.EMPTY_STRING);
													util.formatData(sbPRev, arraySFRevSize.length>i?arraySFRevSize[i]:ConstantsUtil.EMPTY_STRING);
													util.formatData(sbPWet, arraySFWWSize.length>i?arraySFWWSize[i]:ConstantsUtil.EMPTY_STRING);
													util.formatData(sbPDescription, arraySFRMNSize.length>i?arraySFRMNSize[i]:ConstantsUtil.EMPTY_STRING);
													util.formatData(sbSPPhase, arraySFPhaseSize.length>i?arraySFPhaseSize[i]:ConstantsUtil.EMPTY_STRING);
													util.formatData(sbReportedFunction, sSubForRF);
													token=i;
												}
											}
										}
										
									}*/
									iCounter++;
									iTypeCounter++;
									iNameCounter++;
									iRevCounter++;
									iIdCounter++;
									iQtyAdjCounter++;
									iNeedsUpdateCounter++;
									iMaxCounter++;
									iMinCounter++;
									iAppCounter++;
									iProcessingNoteCounter++;
									iTargetweightWetCounter++;
									iMinWeightWetCounter++;
									iMaxWeightWetCounter++;
									iChgCounter++;
								}
								//System.out.println("sbFName:::"+sbFName);
								//System.out.println("sbPName:::"+sbPName);
								
								
								
							}
							mpSubstitutes.put(ConstantsUtil.SP_ID, sbPId.toString());
							mpSubstitutes.put(ConstantsUtil.SP_TYPE, sbPType.toString());
							mpSubstitutes.put(ConstantsUtil.SP_NAME, sbPName.toString());
							mpSubstitutes.put(ConstantsUtil.MIN, sbPMin.toString());
							mpSubstitutes.put(ConstantsUtil.MAX, sbPMax.toString());
							mpSubstitutes.put(ConstantsUtil.SP_WET, sbPWet.toString());
							mpSubstitutes.put(ConstantsUtil.TWW, "");//tobefixed
							mpSubstitutes.put(ConstantsUtil.WEM, sbPMinWt.toString());
							mpSubstitutes.put(ConstantsUtil.WWM, sbPMaxWt.toString());
							mpSubstitutes.put(ConstantsUtil.DIFF, sbPDiff.toString());
							mpSubstitutes.put(ConstantsUtil.DATE, sbPDate.toString());
							mpSubstitutes.put(ConstantsUtil.PROCESS, sbPProces.toString());
							mpSubstitutes.put(ConstantsUtil.CERT, sbPCert.toString());
							mpSubstitutes.put(ConstantsUtil.SF_ID, sbFId.toString());
							mpSubstitutes.put(ConstantsUtil.SF_TYPE, sbFType.toString());
							mpSubstitutes.put(ConstantsUtil.SF_NAME, sbFName.toString());
							mpSubstitutes.put(ConstantsUtil.SF_WET, sbFWetWt.toString());
							mpSubstitutes.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
							mpSubstitutes.put(ConstantsUtil.INSTRUCTIONS, sbInst.toString());
							mpSubstitutes.put(ConstantsUtil.CHG, sbChg.toString());
							mpSubstitutes.put(ConstantsUtil.SF_RAWMATERIALNAME, sbFTitle.toString());
							mpSubstitutes.put(ConstantsUtil.SP_RAWMATERIALNAME, sbPDescription.toString());
							mpSubstitutes.put(ConstantsUtil.SP_PHASE, sbSPPhase.toString());
							mpSubstitutes.put(ConstantsUtil.PHASE, sbSFPhase.toString());
							mpSubstitutes.put(ConstantsUtil.SP_REVISION, sbPRev.toString());
							mpSubstitutes.put(ConstantsUtil.SF_REVISION, sbSFRevision.toString());
							mpSubstitutes.put(ConstantsUtil.FUNCTIONS, sbFunction.toString());
							mpSubstitutes.put(ConstantsUtil.SF_REPORTEDFUNCTION, sbReportedFunction.toString());
							mpSubstitutes.put(ConstantsUtil.VALIDSTARTDATE, sbValidStartDate.toString());
							mpSubstitutes.put(ConstantsUtil.VALIDUNTILDATE, sbValidUntilDate.toString());
							mpSubstitutes.put(ConstantsUtil.COMMENT, sbComments.toString());
							mpSubstitutes.put(ConstantsUtil.SEQUENCENUMBER, sbSequence.toString());
							mpSubstitutes.put(ConstantsUtil.SF_WEM, sbFMinWt.toString());
							mpSubstitutes.put(ConstantsUtil.SF_WWM, sbPMaxWt.toString());
							
							mpProces.put(k, mpSubstitutes);
							k++;
							slSubstituteForParentList = new StringList();
						}
					}
				}
			System.out.println("mpProces---->"+mpProces);
			//System.out.println("_finalsubstitutePartList---->"+_finalsubstitutePartList);
			return mpProces;
		}// end of try
		catch (Exception e)
		{
			e.printStackTrace();
			ContextUtil.abortTransaction(context);
			throw new FrameworkException(e);
		}
	}
	
	
	//shashank
	
	/**
	 * 
	 * @param context
	 * @param sobjId
	 * @return
	 */
	public String getCertification(Context context,String sobjId) 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbRF = new StringBuilder();
		String sSForCertificatins=ConstantsUtil.EMPTY_STRING;
		try
		{
			DomainObject dob = new DomainObject(sobjId);
			 sSForCertificatins=	validator.getStringEquivalentForStringList(dob.getInfo(context, ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME));
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			 dob.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if(UIUtil.isNotNullAndNotEmpty(sSForCertificatins)) 
			{
				sSForCertificatins = ConstantsUtil.SYMBL_YES;
			}else 
			{
				sSForCertificatins = ConstantsUtil.SYMBL_NO;
			}
										
		}catch(Exception e)
		{
			LOGGER.error("Error from FOPBO:  getCertification"+e);
			return ConstantsUtil.EMPTY_STRING;
		}
		return sSForCertificatins;
		}
		
	
	public String getReportedFunction(Context context, String sbFId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		String sRF = new String();
		try
		{
				DomainObject dob = new DomainObject(sbFId);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REPORTED_FUNCTION);
				 sRF=	validator.getStringEquivalentForStringListWithComma(dob.getInfo(context, ConstantsUtil.REPORTED_FUNCTION));
				sRF=sRF.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REPORTED_FUNCTION);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				dob.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				
		}catch(Exception e)
		{
			LOGGER.error("Error from FOPBO:  getReportedFunction"+e);
		}
		return sRF;
		}
		
		
	/**
	 * 
	 * @param context
	 * @param sobjId
	 * @return
	 */
	public String getAttributeValue(Context context,String sobjId,String selectable) 
	{
		String sReturnVal ="";
		try
		{
				DomainObject dob = new DomainObject(sobjId);
				sReturnVal=dob.getInfo(context, selectable);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				dob.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		}catch(Exception e)
		{
			LOGGER.error("Error from FOPBO:  getAttributeValue"+e);
		}
		return sReturnVal;
	}

	public String getMinMaxColumnDataForDSO(Context context, 	Map mapObjectData  ,String strAttributeName) throws Exception
	{
		Vector vcVUDData = new Vector();
		String strAttrValue = "";
		try 
		{			
				strAttributeName = PropertyUtil.getSchemaProperty(context,"attribute_"+strAttributeName);
					if(mapObjectData.containsKey("attribute["+strAttributeName+"].inputvalue"))
					{
						strAttrValue = (String)mapObjectData.get("attribute["+strAttributeName+"].inputvalue");
						//Commented by Ketan for Req. no. 47948
						/*if (UIUtil.isNotNullAndNotEmpty(strAttrValue))
						{
						strAttrValue = util.getFormatedDecimalValue(strAttrValue, FormulationSubstituteConstants.FORMAT_DECIMAL_SIX); 
						 }*/
					
					}
					else
					{
						strAttrValue = (String)mapObjectData.get("attribute["+strAttributeName+"].value");
						//Commented by Ketan for Req. no. 47948
						/*if (UIUtil.isNotNullAndNotEmpty(strAttrValue))
						{
					    strAttrValue = util.getFormatedDecimalValue(strAttrValue, FormulationSubstituteConstants.FORMAT_DECIMAL_SIX); 
						}*/
						
					}
			
		} catch(Exception e)
		{
			throw e;
		}
		return strAttrValue;
	}
	
	
	/**
	 * Method Name 			: getMaterialCompositionAndSubstance
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getMaterialCompositionAndSubstance(Context context, Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String sRawMatId = (String) resultMaps.get(ConstantsUtil.SELECT_ID);
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID	 =  new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbCAS = new StringBuilder();
		StringBuilder sbCont = new StringBuilder();
		StringBuilder sbMAXWt = new StringBuilder();
		StringBuilder sbMInWt = new StringBuilder();
		StringBuilder sbQUOM = new StringBuilder();
		StringBuilder sbDRY = new StringBuilder();
		StringBuilder sbFunctions = new StringBuilder();
		StringBuilder sbtrClassFied = new StringBuilder();
		StringBuilder sbIPClassfication = new StringBuilder();
		
		//Added for Defect #37436 by Amman on 11/19/2020 -- START
		StringBuilder sbQTS = new StringBuilder();
		StringBuilder sbUF = new StringBuilder();
		StringBuilder sbFN = new StringBuilder();
		//Added for Defect #37436 by Amman on 11/19/2020 -- END
		StringBuilder sbParentName = new StringBuilder();//Added by Ajay for 22x.06 Req.9264
		
		try
		{
			DomainObject doObj = new DomainObject(sRawMatId);
			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slBusSelects.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slBusSelects.add(ConstantsUtil.COMP_CLASSIITEM);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
			//START :: gaikwad.tg :: Defect#37283
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME);
			//END :: gaikwad.tg :: Defect#37283
			
			StringList slRelSelects = new StringList();
			//Modified for Defect #37311 -- START
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			
			//Added for Defect #37436 by Amman on 11/19/2020 -- START
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_USAGE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
			//Added for Defect #37436 by Amman on 11/19/2020 -- END
			//Modified for Defect #37311 -- END
			
			 //SPEC : Modified by Ganesh on 6-Jan-2021 for  Requirement 38258 --START
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_NAME);
			//START :: gaikwad.tg
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
			slRelSelects.add("from.name");
			slRelSelects.add("from.id");
			//END :: gaikwad.tg
			
			
			//SPEC: Modified for Defect #38257 by Chandra on 01/25/2021 -- START
			
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
			
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			
			SecurityService sec = new SecurityService();
			boolean bIsComplainceEngineer =sec.isComplainceEngineer();
			
			//SPEC: Modified for Defect #38257 by Chandra on 01/25/2021 -- END
			
			
			
			Pattern objType = new Pattern(ConstantsUtil.TYPE_MATERIAL);
            objType.addPattern(ConstantsUtil.TYPE_SUBSTANCE); 

            Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL);
            relType.addPattern(ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE);
            relType.addPattern(ConstantsUtil.RELATIONSHIP_SECURE_COMPONENT_SUBSTANCE);
            
			/*MapList mlComponentsAnMaterials = doObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, true, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);*/
			
			
			MapList mlComponentsAnMaterials = doObj.getRelatedObjects(context, relType.getPattern(),
					objType.getPattern(), slBusSelects, slRelSelects, false, true, (short) 0,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doObj.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			ARMPBO armpbo = new ARMPBO();
			//SPEC: Modified for Defect #38257 by Chandra on 01/25/2021 -- START
			//mlComponentsAnMaterials=armpbo.getUsageFlags(mlComponentsAnMaterials);
			mlComponentsAnMaterials = util.getUsageFlags(context, mlComponentsAnMaterials);
			//SPEC: Modified for Defect #38257 by Chandra on 01/25/2021 -- END
			//START :: gaikwad.tg
			mlComponentsAnMaterials = util.getSortedMaplistWithSequence(context, mlComponentsAnMaterials, sRawMatId);
			//END :: gaikwad.tg
			//mlComponentsAnMaterials.sort(ConstantsUtil.SELECT_RELATIONSHIP_NAME,ConstantsUtil.ASCENDING,ConstantsUtil.STRING);
			
			String pType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
			String pName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
			String pID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
			String pRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
			String pDesc = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
			String pCurrent1 = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
			//START :: gaikwad.tg :: Defect#37283
			String pTitle = validator.getStringEquivalentForSubstituteStringTitle(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
			//END :: gaikwad.tg :: Defect#37283
			//START :: gaikwad.tg
			if(mlComponentsAnMaterials!=null && mlComponentsAnMaterials.size()>0)
			{
				util.formatData(sbType, util.mapType(pType));
				util.formatData(sbName, pName);
				util.formatData(sbID, pID);
				util.formatData(sbRev, pRev);
				util.formatData(sbDesc, pDesc);
				//START :: gaikwad.tg :: Defect#37283
				util.formatData(sbTitle, pTitle);
				//START :: gaikwad.tg :: Defect#37283
				util.formatData(sbCurrent, pCurrent1);
				util.formatData(sbCAS, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbQTS, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbUF, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbCont, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbMAXWt, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbMInWt, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbDRY, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbQUOM,ConstantsUtil.EMPTY_STRING);
				util.formatData(sbFunctions, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbtrClassFied, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbIPClassfication, ConstantsUtil.EMPTY_STRING);
				//util.formatData(sbFN, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbParentName, ConstantsUtil.EMPTY_STRING);//Added by Ajay for 22x.06 Req.9264
			}
			//END :: gaikwad.tg
			//SPEC : Modified by Ganesh on 6-Jan-2021 for  Requirement 38258 -END
			Iterator objectListItr = mlComponentsAnMaterials.iterator();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				////SPEC : Modified by Ganesh on 6-Jan-2021 for  Requirement 38258 --START
                String relName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_NAME));
				
				if(relName.equals(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL)) {
				
				//strValue	 = (qsComposite.equalsIgnoreCase("TRUE"))? CPNUIUtil.getProperty(context, "emxCPN.Range.QSComposite"):
				//(isTargetMaterial.equalsIgnoreCase("TRUE"))? CPNUIUtil.getProperty(context, "emxCPN.Range.TargetMaterial") : "";
				String sType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
				String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String strID	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sDesc = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sDesc = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sTitle = validator.getStringEquivalentForSubstituteStringTitle(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sCurrent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sCAS = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
				String sCAS = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sCont = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
				
				String sMAXWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
				String sMInWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
				String sQUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
				String sDRY = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
				String sParentName	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME));//Added by Ajay for 22x.06 Req.9264


				
				String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION));
				if (UIUtil.isNotNullAndNotEmpty(sFunctions)) 
				{
					sFunctions=util.getIdFromPhysicalIdFunction(context,sFunctions);
				}
				//SPEC: Modified for Defect #38263 by Chandra on 01/25/2021 -- END
				
				
				String strClassFied = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.COMP_CLASSIITEM));
				String sIPClassfication = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				
				
				String sQTS = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL));
				String sUF	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.FLAGS));
				String isTargetMaterial = (String) objectMap.get(FormulationAttribute.IS_TARGET_MATERIAL.getAttributeSelect(context));
				String sFill = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
				String rel = (String) objectMap.get("relationship");
				
				
				if(UIUtil.isNotNullAndNotEmpty(rel) && !bIsComplainceEngineer && rel.equalsIgnoreCase(FormulationRelationship.SECURE_COMPONENT_SUBSTANCE.getRelationship(context)) ){
					sQTS="";;
				}else
				{
					if(UIUtil.isNotNullAndNotEmpty(sFill) && UIUtil.isNotNullAndNotEmpty(isTargetMaterial)){
						sQTS	 = (sFill.equalsIgnoreCase("TRUE"))? ConstantsUtil.QS:
								(isTargetMaterial.equalsIgnoreCase("TRUE"))? ConstantsUtil.TARGET_COMPONENT : "";
					}
				}
				//SPEC: Modified for Defect #38257 by Chandra on 01/26/2021 -- END	
				
				
				
				//START :: gaikwad.tg
				String sFN      =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));
				//START :: gaikwad.tg

				//START :: gaikwad.tg
				util.formatData(sbFN,sFN);
				//END :: gaikwad.tg
				
				util.formatData(sbType, util.mapType(sType));
				util.formatData(sbName, sName);
				util.formatData(sbID, strID);
				util.formatData(sbRev, sRev);
				util.formatData(sbDesc, sDesc);
				util.formatData(sbTitle, sTitle);
				util.formatData(sbCurrent, sCurrent);
				util.formatData(sbCAS, sCAS);
				
				//Added for Defect #37436 by Amman on 11/19/2020 -- START
				util.formatData(sbQTS, sQTS);
				util.formatData(sbUF, sUF);
				//Added for Defect #37436 by Amman on 11/19/2020 -- END
				util.formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
				
				//Modified for Defect #37311 -- START
				if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
					sCont = ConstantsUtil.SYMBL_CAPTRUE;
				} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
					sCont = ConstantsUtil.SYMBL_CAPFALSE;
				}
				
				util.formatData(sbCont, sCont);
				
				if(!validator.isNotNullOrEmpty(sMInWt) || sMInWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sMInWt = ConstantsUtil.EMPTY_SPACE;
				}
				if(!validator.isNotNullOrEmpty(sDRY) || sDRY.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					//START :: gaikwad.tg :: Defect#37283
					//sDRY = ConstantsUtil.EMPTY_SPACE;
					sDRY = "0";
					//START :: gaikwad.tg :: Defect#37283
				}
				if(!validator.isNotNullOrEmpty(sMAXWt) || sMAXWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sMAXWt = ConstantsUtil.EMPTY_SPACE;
				}
				//Modified for Defect #37311 -- END
				
				util.formatData(sbMAXWt, sMAXWt);
				util.formatData(sbMInWt, sMInWt);
				
			
				
				//Added for Defect #37436 by Amman on 11/24/2020 -- START
				//Reason/Logic : With the Substance(s) now added to the IMP, enter a Dry % (w/w) for each. These values must add up to 100.
				if(sDRY.equalsIgnoreCase("1.0")) {
					sDRY="100.0";
				}
				//Added for Defect #37436 by Amman on 11/24/2020 -- END
				//SPEC: <01.09.2021>: Guna Modified for 42904 Defect  Dev 18x.6.0.2   -- START
				DomainObject domContextPart = DomainObject.newInstance(context, strID);
				String strTotalQuantytites = ConstantsUtil.EMPTY_STRING;
				BigDecimal dQuantites = new BigDecimal(0.0D);
				StringList slQuantities = DomainConstants.EMPTY_STRINGLIST;
				slQuantities = util.getNonContaminantQuantities(context, domContextPart);
				domContextPart.close(context);
				slQuantities.sort();
				for (int j = 0; j < slQuantities.size(); j++)
				{
					dQuantites = dQuantites.add(new BigDecimal((String)slQuantities.get(j)));
				}
				if (dQuantites.compareTo(new BigDecimal(0.0D)) != 0)
				{
					strTotalQuantytites = dQuantites.toPlainString();
				} 
				//SPEC: <11.11.2021>: Manikanta Modified for Defect 45711  Dev 18x.6.0.2   -- START
				else {
					strTotalQuantytites = sDRY;
				}
				//SPEC: <11.11.2021>: Manikanta Modified for Defect 45711  Dev 18x.6.0.2   -- END
				//util.formatData(sbDRY, sDRY);
				util.formatData(sbDRY, strTotalQuantytites);
				//SPEC: <01.09.2021>: Guna Modified for 42904 Defect  Dev 18x.6.0.2   -- END
				//Added for Defect #37311 -- START
				util.formatData(sbQUOM,sQUOM);
				//Added for Defect #37311 -- END
				
				util.formatData(sbFunctions, sFunctions);
				util.formatData(sbtrClassFied, strClassFied);
				util.formatData(sbIPClassfication, sIPClassfication);
				}else {
				//DomainObject doComponent = new DomainObject(strID);
				slBusSelects = new StringList();
				slBusSelects.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
				slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME);
				slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
				slBusSelects.add(ConstantsUtil.COMP_CLASSIITEM);
				
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
				
				//Added for Defect #37436 by Amman on 11/25/2020 -- START
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_USAGE);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
				//Added for Defect #37436 by Amman on 11/25/2020 -- END
				
				//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- START
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
				slRelSelects.add(ConstantsUtilIRM.SELECT_EBOM_NAME);//Added by Ajay for 22x.06 Req.9264

					Map objectMap2 = objectMap;//(Map) objectListItr2.next();
					String sType = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_TYPE));
					String sName = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_NAME));
					String strID	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ID));
					String sRev = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_REVISION));
					String sParentName	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtilIRM.SELECT_EBOM_NAME));//Added by Ajay for 22x.06 Req.9264

					String sDesc = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_DESCRIPTION));
					String sTitle = validator.getStringEquivalentForSubstituteStringTitle(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME));
					
					
					String sCurrent = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_CURRENT));
					sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
					
					String sCAS = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
					
					String sCont = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
					String sMAXWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
					String sMInWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
					String sQUOM = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
					String sDRY = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
					
					String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION));
					if (UIUtil.isNotNullAndNotEmpty(sFunctions)) 
					{
						sFunctions=util.getIdFromPhysicalIdFunction(context,sFunctions);
					}
					//SPEC: Modified for Defect #38263 by Chandra on 01/25/2021 -- END
					
					String strClassFied = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.COMP_CLASSIITEM));
					String sIPClassfication = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
					
					//Modified for Defect #37436 by Amman on 11/25/2020 -- START
					String sQTS = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL));
					//SPEC: Modified for Defect#37618 1.0.2 Release - Jwala -- START
					//sUF = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_USAGE));
					String sUF	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.FLAGS));
					//SPEC: Modified for Defect#37618 1.0.2 Release - Jwala -- START
					
					String sTarget = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL));
					
					//SPEC: Modified for Defect #38257 by Chandra on 01/25/2021 --START
					
					String isTargetMaterial = (String) objectMap2.get(FormulationAttribute.IS_TARGET_MATERIAL.getAttributeSelect(context));
					String sFill = (String)objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
					String rel = (String) objectMap2.get("relationship");
					
					
					if(UIUtil.isNotNullAndNotEmpty(rel) && !bIsComplainceEngineer && rel.equalsIgnoreCase(FormulationRelationship.SECURE_COMPONENT_SUBSTANCE.getRelationship(context)) ){
						sQTS="";;
					}else
					{
						if(UIUtil.isNotNullAndNotEmpty(sFill) && UIUtil.isNotNullAndNotEmpty(isTargetMaterial)){
							sQTS	 = (sFill.equalsIgnoreCase("TRUE"))? ConstantsUtil.QS:
									(isTargetMaterial.equalsIgnoreCase("TRUE"))? ConstantsUtil.TARGET_COMPONENT : "";
						}
					}
					//START :: gaikwad.tg
					String sFN      =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));
					//START :: gaikwad.tg

					//START :: gaikwad.tg
					util.formatData(sbFN,sFN);
					//END :: gaikwad.tg
					util.formatData(sbType, util.mapType(sType));
					util.formatData(sbName, sName);
					util.formatData(sbID, strID);
					util.formatData(sbRev, sRev);
					util.formatData(sbDesc, sDesc);
					util.formatData(sbTitle, sTitle);
					util.formatData(sbCurrent, sCurrent);
					util.formatData(sbCAS, sCAS);
					
					//Added for Defect #37436 by Amman on 11/19/2020 -- START
					util.formatData(sbQTS, sQTS);
					util.formatData(sbUF, sUF);
					//Added for Defect #37436 by Amman on 11/19/2020 -- END
					
					//Modified for Defect #37311 -- START
					if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
						sCont = ConstantsUtil.SYMBL_CAPTRUE;
					} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
						sCont = ConstantsUtil.SYMBL_CAPFALSE;
					}
					
					util.formatData(sbCont, sCont);
					
					if(!validator.isNotNullOrEmpty(sMInWt) || sMInWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
						sMInWt = ConstantsUtil.EMPTY_SPACE;
					}
					if(!validator.isNotNullOrEmpty(sDRY) || sDRY.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
						//START :: gaikwad.tg :: Defect#37283
						//sDRY = ConstantsUtil.EMPTY_SPACE;
						sDRY = "0";
						//START :: gaikwad.tg :: Defect#37283
					}
					if(!validator.isNotNullOrEmpty(sMAXWt) || sMAXWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
						sMAXWt = ConstantsUtil.EMPTY_SPACE;
					}
					//Modified for Defect #37311 -- END
					
					//Modified for Defect #37436 by Amman on 11/24/2020-- START
					//util.formatData(sbMAXWt, sMAXWt);
					if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPTRUE)) {
						util.formatData(sbMAXWt, sDRY);
					} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPFALSE)) {
						util.formatData(sbMAXWt, sMAXWt);
					}
					//Modified for Defect #37436 by Amman on 11/24/2020 -- END
					
					util.formatData(sbMInWt, sMInWt);
					
					
					//Modified for Defect #37436 by Amman on 11/24/2020 -- START
					//util.formatData(sbDRY, sDRY);
					if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPTRUE)) {
						util.formatData(sbDRY, sMAXWt);
					} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPFALSE)) {
						util.formatData(sbDRY, sDRY);
					}
					//Modified for Defect #37436 by Amman on 11/24/2020 -- END
					
					//Added for Defect #37311 -- START
					util.formatData(sbQUOM,sQUOM);
					//Added for Defect #37311 -- END
					util.formatData(sbFunctions, sFunctions);
					util.formatData(sbtrClassFied, strClassFied);
					util.formatData(sbIPClassfication, sIPClassfication);
					util.formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
				//}
				}
			}
			mpSubStanceResult.put(ConstantsUtil.SECURITY, sbtrClassFied.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sbIPClassfication.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.REV,sbRev.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.CAS,sbCAS.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.IP,sbCont.toString().trim());
			
			mpSubStanceResult.put(ConstantsUtil.MAX,sbMAXWt.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.MIN,sbMInWt.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.UOM,sbQUOM.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sbDRY.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sbFunctions.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.ID, sbID.toString().trim());
			
			//Added for Defect #37436 by Amman on 11/19/2020 -- START
			mpSubStanceResult.put(ConstantsUtil.QSTARGET,sbQTS.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.UF, sbUF.toString().trim());
			//START :: gaikwad.tg
			mpSubStanceResult.put(ConstantsUtil.SEQ,sbFN.toString());
			mpSubStanceResult.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString().trim());//Added by Ajay for 22x.06 Req.9264
			//START :: gaikwad.tg
			//Added for Defect #37436 by Amman on 11/19/2020 -- END

		}catch(Exception e){

			LOGGER.error("Error from FormulaPartBO:  getMaterialCompositionAndSubstance"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- START
		/**
		 * Method Name 			: getCountryClearanceResult
		 * Method Description 	: 
		 * @param resultMaps
		 * @return
		 */
		public Map getCountryClearanceResult(Context context, Map resultMaps)
		{

			Map<String, String> mapCountryClearanceResult = new HashMap<String, String>();
			StringValidatorUtil validator = new StringValidatorUtil();
			
		StringBuilder sbPackSizeUOM = new StringBuilder();
			StringBuilder sbMarketName = new StringBuilder();
			StringBuilder sbClearanceNum = new StringBuilder();
			StringBuilder sbOveralClearence = new StringBuilder();
			StringBuilder sbGPSApproval = new StringBuilder();
			StringBuilder sbManuSite = new StringBuilder();
			StringBuilder sbPackSite = new StringBuilder();
			StringBuilder sbComments = new StringBuilder();
			StringBuilder sbRestrictions = new StringBuilder();
			StringBuilder sbRegExpDate = new StringBuilder();
			
			StringBuilder sbRegStatus = new StringBuilder();
			StringBuilder sbMPDTNumber = new StringBuilder();
			StringBuilder sbPRODRegClass = new StringBuilder();
			StringBuilder sbRegProductName = new StringBuilder();
			StringBuilder sbRegrewlleadTime = new StringBuilder();
			StringBuilder sbRegirewlStatus = new StringBuilder();
			StringBuilder sbMarketApprovalHolder = new StringBuilder();
			StringBuilder sbLegalEntity = new StringBuilder();
			StringBuilder sbBusinessChannel = new StringBuilder();
			StringBuilder sbPackSize = new StringBuilder();
			
		StringList slRelSelectsTup = new StringList();
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER);
			//slRelSelectsTup.add(ConstantsUtil.SELECT_NAME);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT);
			
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALLEADTIME);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS);
			
			slRelSelectsTup.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMARKETAPPROVALHOLDER);
			slRelSelectsTup.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLEGELENTITY);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZEUOM);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZE);
			slRelSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS);
			
			StringList slSelectsTup = new StringList();
			slSelectsTup.add(ConstantsUtil.SELECT_NAME);


			try
			{
				String sParentID = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
				if(UIUtil.isNotNullAndNotEmpty(sParentID))
				{
					DomainObject doParent = DomainObject.newInstance(context, sParentID);
					
					MapList mlCountryCl = doParent.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE,
							ConstantsUtil.QUERY_WILDCARD, slSelectsTup, slRelSelectsTup, false, true,
							(short) 0, "", "", 0);
					
					if (mlCountryCl.isEmpty()) {
						return new HashMap();
					}
					Iterator objectListItr = mlCountryCl.iterator();
					while (objectListItr.hasNext()) 
					{
						Map objectMap = (Map) objectListItr.next();
				String strMarketName    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_NAME));
				String strClearanceNum    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER));
				String strOveralClearence    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS));
				String strGPSApproval   =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS));
				String strManuSite    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE));
				String strPackSite    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE));
				String strComments    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT));
				String strRestrictions    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION));
				String strRegExpDate    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE));
				String strRegStatus    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS));
				String strMPDTNumber    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER));
				String strPRODRegClass    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION));
				
				//SPEC:11/23/2020: Commented for defect 37522 by Amman ## -- START
				//String strRegrewlleadTime    =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE));
				//String strRegirewlStatus    =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY));
				//SPEC:11/23/2020: Commented for defect 37522 by Amman ## -- END
				
				String strRegProductName    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME));

				//SPEC:11/23/2020: Added for defect 37522 by Amman ## -- START
				String strRegrewlleadTime    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALLEADTIME));
				String strRegirewlStatus    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS));
				//SPEC:11/23/2020: Added for defect 37522 by Amman ## -- END
				
				
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 25 Feb 2021 -- START
				String strMarketApprovalHolder    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMARKETAPPROVALHOLDER));
				String strLegalEntity    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLEGELENTITY));
				String strBusinessChannel    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL));
				String strPackSize    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZE));
				String strPackSizeUOM    =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZEUOM));
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41661 on Date 12/04/2021 --START
				int iSize = 0;
				for(int i = 0; i < strClearanceNum.length(); i++) {
				    if(strClearanceNum.charAt(i) == ',') iSize++;
				}
				strClearanceNum    =  strClearanceNum.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strGPSApproval   =  strGPSApproval.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strManuSite    =  strManuSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSite    =  strPackSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strComments    =  strComments.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRestrictions    =  strRestrictions.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegExpDate    =  strRegExpDate.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegStatus    =  strRegStatus.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strMPDTNumber    =  strMPDTNumber.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPRODRegClass    =  strPRODRegClass.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegProductName    =  strRegProductName.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegrewlleadTime    =  strRegrewlleadTime.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegirewlStatus    =  strRegirewlStatus.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strMarketApprovalHolder    =  strMarketApprovalHolder.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strLegalEntity    =  strLegalEntity.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strBusinessChannel    =  strBusinessChannel.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSize    =  strPackSize.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSizeUOM    =  strPackSizeUOM.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				for (int i = 0; i <= iSize; i++) {
					formatData(sbMarketName, strMarketName);
					formatData(sbOveralClearence, strOveralClearence);
				}
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41661 on Date 12/04/2021 --END

						//formatData(sbMarketName, strMarketName);
						formatData(sbClearanceNum, strClearanceNum);
						//formatData(sbOveralClearence, strOveralClearence);
						formatData(sbGPSApproval, strGPSApproval);
						formatData(sbManuSite, strManuSite);
						formatData(sbPackSite, strPackSite);
						formatData(sbComments, strComments);
						formatData(sbRestrictions, strRestrictions);
						formatData(sbRegExpDate, strRegExpDate);
						formatData(sbRegStatus, strRegStatus);
						formatData(sbMPDTNumber, strMPDTNumber);
						formatData(sbPRODRegClass, strPRODRegClass);
						formatData(sbRegProductName, strRegProductName);
						formatData(sbRegrewlleadTime, strRegrewlleadTime);
						formatData(sbRegirewlStatus, strRegirewlStatus);
						formatData(sbMarketApprovalHolder, strMarketApprovalHolder);
						formatData(sbLegalEntity, strLegalEntity);
						formatData(sbBusinessChannel, strBusinessChannel);
						formatData(sbPackSize, strPackSize);
						formatData(sbPackSizeUOM, strPackSizeUOM);
					}
					
				mapCountryClearanceResult.put(ConstantsUtilIRM.MARKET_APPROVAL_HOLDER, sbMarketApprovalHolder.toString());
				mapCountryClearanceResult.put(ConstantsUtilIRM.LEGEL_ENTITY, sbLegalEntity.toString());
				mapCountryClearanceResult.put(ConstantsUtilIRM.BUSINESS_CHANNEL,sbBusinessChannel.toString());
				mapCountryClearanceResult.put(ConstantsUtilIRM.PACK_SIZE,sbPackSize.toString());
				mapCountryClearanceResult.put(ConstantsUtilIRM.PACK_SIZE_UOM,sbPackSizeUOM.toString());
				mapCountryClearanceResult.put(ConstantsUtil.MARKET_NAME, sbMarketName.toString());
				mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, sbClearanceNum.toString());
				mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, sbOveralClearence.toString());
				mapCountryClearanceResult.put(ConstantsUtil.GPS_APPROVAL, sbGPSApproval.toString());
				mapCountryClearanceResult.put(ConstantsUtil.MANU_SITE, sbManuSite.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PACK_SITE, sbPackSite.toString());
				mapCountryClearanceResult.put(ConstantsUtil.COMMENTS, sbComments.toString());
				mapCountryClearanceResult.put(ConstantsUtil.RESTRICTIONS, sbRestrictions.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, sbRegExpDate.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, sbRegStatus.toString());
				mapCountryClearanceResult.put(ConstantsUtil.MARKETPRODUCTNUMBER, sbMPDTNumber.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PROD_REG_CLASS, sbPRODRegClass.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALLEADTIME, sbRegrewlleadTime.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALSTATUS, sbRegirewlStatus.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTEREDPRODUCTNAME, sbRegProductName.toString());
				}
			}
			catch(Exception e){

				LOGGER.error("Error from FormulaPartBO:  getCountryClearanceResult"+e);
				return new HashMap();
			}
			return mapCountryClearanceResult;
		}
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 12 March 2021 -- END
}