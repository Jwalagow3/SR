package com.pg.us.specanywhere_enovia.sapbom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.fop.FormulationAttribute;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaFPPServiceImpl;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.SAPBOMConstants;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import ch.qos.logback.classic.Level;
import matrix.db.AccessConstants;
import matrix.db.Attribute;
import matrix.db.BusinessObject;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectItr;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class Sapbom {

	private static Logger LOGGER = Logger.getLogger(Sapbom.class);

	public static final StringList SL_OBJECT_INFO_SELECT 			= 	getObjectSelects();
	public static final StringList SL_RELATION_INFO_SELECT_EBOM		=	getRelationshipSelectsEBOM();
	public static final StringList SL_RELATION_INFO_SELECT_OTHERS	=	getRelationshipSelectsOthers();
	public static final StringList SL_FOP_OBJECT_INFO_SELECT 		= 	getFOPObjectSelects();
	private boolean bExecuteRFC 									= 	true;
	private boolean bSitesListActive 								= 	false;
	private String strDesignatedSites 								= 	DomainConstants.EMPTY_STRING;
	private static String strSuccess				 						= 	"BOM Successfully Processed";
	public static final String PATTERN_DECIMALFORMAT = "##.###";
	public static final String TYPE_INTERMEDIATEPRODUCTPART = PropertyUtil.getSchemaProperty("type_pgIntermediateProductPart");
	public static final int OPT_COMPONENT = 24;
	public static final int BOM_ARRAY_SIZE = 26;
	public static final int COMMENT = 25;	
	public static final int OBJECT_ID = 22;
	public static final int DISPLAY_OBJECT_ID = 23;
	public static final String PGPHASE_EXPAND_TYPES = "pgFinishedProduct,pgFormulatedProduct,pgRawMaterial,pgPackingMaterial,pgPackingSubassembly";
	
	public static final String ALTERNATE_ALLOWED_TYPES = pgV3Constants.TYPE_RAWMATERIALPART+","+pgV3Constants.TYPE_PGRAWMATERIAL+","+pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART+","+pgV3Constants.TYPE_FABRICATEDPART+","+pgV3Constants.TYPE_PACKAGINGMATERIALPART+","+pgV3Constants.TYPE_PACKAGINGASSEMBLYPART;
	public static final String COP_BULK_ALTERNATES_ALLOWED_TYPES = pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART+","+pgV3Constants.TYPE_PACKAGINGASSEMBLYPART;
	
	public String strParentRev = "";
	public ArrayList alBOMFC = new ArrayList();
	public String _AbortReason = "";
	public String _ParentMatlNumber = "";
	private boolean bCreatingSubsRows = false;
	private String strSubsDispId = "";
	
	public String strFirstlevelObjId = "";
	public String strFirstlevelObjIdCopy = "";
	HashMap hmParentObjects = new HashMap();
	HashMap hmChildObjects = new HashMap();
	int iChildObjCount =0;

	private String strParentBUOM = DomainConstants.EMPTY_STRING;
	private String strParentType = DomainConstants.EMPTY_STRING;

	
	StringValidatorUtil validator = new StringValidatorUtil();
	
	 public Object getTableData(Context context, String strObjectID) throws Exception {
			MapList mpReturnList = new MapList();
			boolean isContextPushed = false;
			int OBJECT_ID = 27;
			int SUBSTITUTE_FLAG = 14;
			int QUANTITY = 10;
			int FC_MIN_QTY = 23;
			int FC_MAX_QTY = 25;
			int SORT_STRING = 13;
			int TUP_ID = 28;
			int OPT_COMPONENT = 29;
	        
	        Set tupIDSet = new HashSet();
	        
			
			try {

					StringList slPartSelect = new StringList(7);
					slPartSelect.addElement(DomainConstants.SELECT_NAME);
					slPartSelect.addElement(DomainConstants.SELECT_TYPE);
					slPartSelect.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					slPartSelect.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
					slPartSelect.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
					slPartSelect.addElement(pgV3Constants.SELECT_ATTRIBUTE_TITLE);
					
					StringList slPlantRelSelects = new StringList(3);
					slPlantRelSelects.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
					slPlantRelSelects.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
					slPlantRelSelects.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
					
					//SuperUser Context
					ContextUtil.pushContext(context);
					isContextPushed = true;
					//Getting BOM Feed Data 
					
					ArrayList alPartObjectsWithGroupAndQty =performDataReadFromEnovia(context, strObjectID);
					if(null != alPartObjectsWithGroupAndQty) 
					{
						int alsize=alPartObjectsWithGroupAndQty.size();
						String strObjID = null;
						String strSubstitute=null;
						String strBOMQuantity = null;
						String strMin = null;
						String strMax = null;
						String strPosInd = null;
						String strObjectType = null;
						String strSAPUOM = null;
						String strSAPType = null;
						String strPGCSSType = null;
						String strTUPObjID = null;
						String strOptComponent = null;
						DomainObject domObject = null;
						Map mpPartObjectInfo = null;
						
						int COMMENT = 30;
						String strComment = DomainConstants.EMPTY_STRING; 
						String strName = DomainConstants.EMPTY_STRING; 
						String strDescription = DomainConstants.EMPTY_STRING; 
						
						HashMap hmTemp = null;
						Map mapSAPBOMComponent = new HashMap();
						MapList mlSAPBOMComponentPlantList = new MapList();
						String sAVAttributeValue =DomainConstants.EMPTY_STRING;
						String sAUAttributeValue =DomainConstants.EMPTY_STRING;
						String sAPAttributeValue =DomainConstants.EMPTY_STRING;
						String sSAPBOMComponentPlantName =DomainConstants.EMPTY_STRING;
						String strAVPlantList = DomainConstants.EMPTY_STRING;
						String strAUPlantList = DomainConstants.EMPTY_STRING;
						String strAPPlantList = DomainConstants.EMPTY_STRING;
						
						StringList slAVPlantList = new StringList();
						StringList slAUPlantList = new StringList();
						StringList slAPPlantList = new StringList();
						
						
						//SPEC 11/05/2020 added for defect: 37077##--START
						String strTUPObjName = DomainConstants.EMPTY_STRING; 
						String strTUPObjType = DomainConstants.EMPTY_STRING;
						//SPEC 11/05/2020 added for defect: 37077##--END
						
						StringList parentPlantList = new StringList();
         
						for (int i=0; i<alsize; i++) {
							String [] satemp = (String[]) alPartObjectsWithGroupAndQty.get(i);
							strObjID = satemp[OBJECT_ID];
							strSubstitute= satemp[SUBSTITUTE_FLAG];
							strBOMQuantity = satemp[QUANTITY];
							strMin = satemp[FC_MIN_QTY];
							strMax = satemp[FC_MAX_QTY];
							strPosInd = satemp[SORT_STRING];
							strTUPObjID = satemp[TUP_ID];
							
							strOptComponent = satemp[OPT_COMPONENT];
							
							domObject = DomainObject.newInstance(context,strObjID);
							mpPartObjectInfo = domObject.getInfo(context, slPartSelect);
							
							strObjectType = (String)mpPartObjectInfo.get(DomainConstants.SELECT_TYPE);
							strSAPUOM = (String)mpPartObjectInfo.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
							strSAPType = (String)mpPartObjectInfo.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
							strPGCSSType = (String)mpPartObjectInfo.get(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
							
							strComment = satemp[COMMENT];
							strName = (String)mpPartObjectInfo.get(DomainConstants.SELECT_NAME);
							
							strDescription = (String)mpPartObjectInfo.get(pgV3Constants.SELECT_ATTRIBUTE_TITLE);
							
							hmTemp = new  HashMap();	
							
							if (UIUtil.isNotNullAndNotEmpty(strTUPObjID)) {
		                           tupIDSet.add(strTUPObjID);
		                        }
							
						     Map<String, String> tupColumnData = getTUPColumnData(context, tupIDSet);
						       
						     //SPEC 11/05/2020 added for defect: 37077##--START
							strTUPObjID = validator.getStringEquivalentForStringList(tupColumnData.get(SAPBOMConstants.TRANSPORTUNIT_ID));
							strTUPObjName = validator.getStringEquivalentForStringList(tupColumnData.get(SAPBOMConstants.TRANSPORTUNIT_NAME));
							strTUPObjType = validator.getStringEquivalentForStringList(tupColumnData.get(SAPBOMConstants.TRANSPORTUNIT_TYPE));
							 //SPEC 11/05/2020 added for defect: 37077##--END
							
							
							hmTemp.put("id",strObjID);  
							hmTemp.put("type",strObjectType);  
	 						hmTemp.put("substitute",strSubstitute);
							hmTemp.put("BOMQty",strBOMQuantity);
							hmTemp.put("Min",strMin);
							hmTemp.put("Max",strMax);
							hmTemp.put("PosInd",strPosInd);
							hmTemp.put("SAPUOM",strSAPUOM);
							hmTemp.put("SAPType",strSAPType);
							hmTemp.put("SSType",strPGCSSType);
							hmTemp.put("dispId", strObjID);
							hmTemp.put("TUP_ID", strTUPObjID);
                            
                            if (UIUtil.isNotNullAndNotEmpty(strTUPObjID)) {
                                tupIDSet.add(strTUPObjID);
                             }
                            
							hmTemp.put("OptComponent", strOptComponent);
							
							hmTemp.put(pgV3Constants.ATTRIBUTE_COMMENT, strComment);
							hmTemp.put(DomainConstants.SELECT_NAME, strName);
							hmTemp.put(DomainConstants.SELECT_DESCRIPTION, strDescription);
							
							hmTemp.put("AVPlantDetails", strAVPlantList);
							hmTemp.put("AUPlantDetails", strAUPlantList);
							hmTemp.put("APPlantDetails", strAPPlantList);
							
							hmTemp.put("ParentPlantDetails", parentPlantList);
							
							hmTemp.put(ConstantsUtil.TRANSPORTUNIT_TYPE, strTUPObjType);
							hmTemp.put(ConstantsUtil.TRANSPORTUNIT_NAME, strTUPObjName);
							hmTemp.put(ConstantsUtil.TRANSPORTUNIT_ID, strTUPObjID);
							
							
							mpReturnList.add(hmTemp);
						}
					}
				} catch(Exception e) {
					e.printStackTrace();
				} finally {
					if(isContextPushed) {
						ContextUtil.popContext(context);
						isContextPushed = false;
					}
				}
	         return mpReturnList;
		}

	 public Map<String, String> getTUPColumnData(Context context, Set sObjectIDs) throws FrameworkException {
	        Map<String, String> tupColumnDataMap = new HashMap<>();
	    	BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
	        String[] arrOIDs = new String[sObjectIDs.size()];
	        sObjectIDs.toArray(arrOIDs);
	        StringList busSelects = new StringList();
	        busSelects.addElement(DomainConstants.SELECT_ID);
	        busSelects.addElement(DomainConstants.SELECT_NAME);
	        busSelects.addElement(DomainConstants.SELECT_TYPE);
	        MapList tupMapList = DomainObject.getInfo(context, arrOIDs, busSelects);

	        Iterator tupItr = tupMapList.iterator();
	        String sBusName;
	        String sBusID;
	        String sBusType;
	        Map<?,?> tempMap;
	        while (tupItr.hasNext())
	        {
	            tempMap = (Map<?,?>) tupItr.next();
	            sBusName = (String) tempMap.get(DomainConstants.SELECT_NAME);
	            sBusID = (String) tempMap.get(DomainConstants.SELECT_ID);
	            sBusType = (String) tempMap.get(DomainConstants.SELECT_TYPE);
	            
	            boolean bTUPAccess=false;
				
				if(UIUtil.isNotNullAndNotEmpty(sBusID))
				{
				 bTUPAccess = Bbutil.checkHasAccess(context,null,sBusID);
				}
				if(!bTUPAccess)
				{
					sBusID=ConstantsUtil.NO_ACCESS;
				}
				
				
	            tupColumnDataMap.put(ConstantsUtil.TRANSPORTUNIT_ID, sBusID);
	            tupColumnDataMap.put(ConstantsUtil.TRANSPORTUNIT_NAME, sBusName);
	            tupColumnDataMap.put(ConstantsUtil.TRANSPORTUNIT_TYPE, sBusType);
	            
	        }
	        return tupColumnDataMap;
	    }
		
	  	
	  public synchronized ArrayList performDataReadFromEnovia(Context context,String sPartObjectID) throws Exception {
			Map mapPartDetails = new HashMap();
			ArrayList alPartRelatedObjects = new ArrayList();
			
			String strSpecSubType = DomainConstants.EMPTY_STRING;
			String strFormulationType = DomainConstants.EMPTY_STRING;
			String strPartType = DomainConstants.EMPTY_STRING;
			
			DomainObject doPart = null;
			StringList slBusSelect = new StringList(13);
			slBusSelect.add(DomainConstants.SELECT_TYPE);
			slBusSelect.add(DomainConstants.SELECT_NAME);
			slBusSelect.add(DomainConstants.SELECT_ID);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_STATUS);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_RELEASE_PHASE);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
			slBusSelect.add("to["+pgV3Constants.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+pgV3Constants.SELECT_ATTRIBUTE_FORMULATIONTYPE);
			slBusSelect.add("next.id");
			
			
			try {

				if(validator.isNotNullOrEmpty(sPartObjectID)){
	
					doPart = DomainObject.newInstance(context,sPartObjectID);
					mapPartDetails = doPart.getInfo(context, slBusSelect);

					
					if(null != mapPartDetails && mapPartDetails.size()>0) {
						strSpecSubType = (String) mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
						
						Object OFormulationType = (Object)mapPartDetails.get("to["+pgV3Constants.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+pgV3Constants.SELECT_ATTRIBUTE_FORMULATIONTYPE);
															
						StringList slFormulationType = new StringList();
													
						if (null != OFormulationType) {
							if (OFormulationType instanceof StringList) {
								slFormulationType = (StringList) OFormulationType;
							} else if (OFormulationType instanceof String) {
								slFormulationType.add(OFormulationType.toString());
							}
						}								
						
						
						if(doProdUsageCheckForeDelivery(context,mapPartDetails)) {
						
							/*
							 *	Get the EBOM, Substitute and Alternates for the given Object. 
							 *  For each EBOM components/Substitute/Alternate , check the Eligibility to process the BOM for eDelivery.
							 */
							strPartType	=	(String)mapPartDetails.get(DomainConstants.SELECT_TYPE);

							if(validator.isNotNullOrEmpty(strPartType)) {

								if(pgV3Constants.TYPE_PGFORMULATEDPRODUCT.equalsIgnoreCase(strPartType) || pgV3Constants.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase(strPartType) || pgV3Constants.TYPE_PGPACKINGSUBASSEMBLY.equalsIgnoreCase(strPartType)) {

									/*
									 *	Uses existing CSS JAR to fetch the data. 
									 *  
									 */
									
									alPartRelatedObjects = getPartObjectsFromEBOM(context,mapPartDetails);
									
									
								} else if(pgV3Constants.TYPE_FORMULATIONPART.equalsIgnoreCase(strPartType) && !slFormulationType.isEmpty() && !slFormulationType.contains(pgV3Constants.THIRD_PARTY_FORMULA)) {
									
									
									
									alPartRelatedObjects = getObjectsForFOPFromFormulaIngredient(context,mapPartDetails);
									
								} else if(pgV3Constants.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(strPartType) || (pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strPartType) && !pgV3Constants.THIRD_PARTY.equals(strSpecSubType))) {
									
									alPartRelatedObjects = getPartObjectsFromIntermediateBOM(context,sPartObjectID);
									

								} else if(pgV3Constants.TYPE_FABRICATEDPART.equalsIgnoreCase(strPartType) ||   TYPE_INTERMEDIATEPRODUCTPART.equalsIgnoreCase(strPartType) || ((pgV3Constants.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strPartType) || pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strPartType)) && !pgV3Constants.THIRD_PARTY.equals(strSpecSubType))) {
									
									
									
									alPartRelatedObjects = getPartObjectsFromBOM(context,sPartObjectID);
								
								}
							}
						}
					}
				}
			}
			catch(Exception e) {
				e.printStackTrace();
				//throw new Exception(e.getMessage());
			}
			return alPartRelatedObjects;
		}
		
		private double parseValue(String strValue) {

			double dValue					= 1;
			try { 
				dValue				= Double.parseDouble(strValue);
			}catch(Exception e) {
				dValue				= 1;
			}
			if(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED.equalsIgnoreCase(strValue)) {
				dValue = -9.99;
			}
			dValue				   =	(double)Math.round(dValue*1000)/1000;
			return dValue;
		
		}

		private String parseQuantityValue(String strValue) {

			double dValue					= -9.99;
			try { 

				if(validator.isNotNullOrEmpty(strValue)){
					dValue				= Double.parseDouble(strValue);

					if(dValue<0) {

						strValue = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
						dValue = -9.99;
					}

				} else {
					strValue = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
					dValue = -9.99;
				}
			}catch(Exception e) {
				dValue				= -9.99;
			}
			if(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED.equalsIgnoreCase(strValue)) {
				dValue = -9.99;
			}

			return dValue + DomainConstants.EMPTY_STRING;

		
		}

		private double parseFOPQuantityValue(String strValue) {

			double dValue					= 1;
			if(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED.equalsIgnoreCase(strValue)) {
				dValue = -9.99;
			}else{
				try { 
					dValue				= Double.parseDouble(strValue);
					
				}catch(Exception e) {
					dValue				= 1;
				}
			}
			return dValue;	
		}
		
		/**
		 * This Method is use for Global Object selectables
		 * 
		 * @return StringList
		 * @throws Exception 
		 */
		public static StringList getObjectSelects() {
			StringList slEBOMTarget = new StringList(16);
			try{


				slEBOMTarget.add(DomainConstants.SELECT_TYPE);
				slEBOMTarget.add(DomainConstants.SELECT_NAME);
				slEBOMTarget.add(DomainConstants.SELECT_REVISION);
				slEBOMTarget.add(DomainConstants.SELECT_ID);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_TITLE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_STATUS); 
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_ID);
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_TYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_NAME);
				slEBOMTarget.add("frommid["+pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE+"]");
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
				slEBOMTarget.add("from["+pgV3Constants.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION+"].to.name");
				slEBOMTarget.add("from["+pgV3Constants.RELATIONSHIP_PGMASTER+"].to.name");
				slEBOMTarget.addElement(DomainConstants.SELECT_LEVEL);
				
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED);
				
			}catch(Exception ex) {
				ex.printStackTrace();		
			}

			return slEBOMTarget;
		}

		/**
		 * This Method is use for Global Object selectables
		 * 
		 * @return StringList
		 * @throws Exception 
		 */

		public static StringList getFOPObjectSelects() {

			StringList slEBOMTarget = new StringList(25);
			try{

				slEBOMTarget.add(DomainConstants.SELECT_TYPE);
				slEBOMTarget.add(DomainConstants.SELECT_NAME);
				slEBOMTarget.add(DomainConstants.SELECT_REVISION);
				slEBOMTarget.add(DomainConstants.SELECT_ID);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_TITLE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);			
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_ACTUAL_WEIGHT_DRY);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_ACTUAL_PERCENT_DRY);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_ACTUAL_WEIGHT_WET);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_ACTUAL_PERCENT_WET);
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_ID);
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_NAME);
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_TYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_EFFECTIVITY_DATE);
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_BASE_UOM);
				
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_PGASSEMBLYTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ALTERNATE_PGSAPTYPE);
				
				slEBOMTarget.add("to["+pgV3Constants.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+pgV3Constants.SELECT_ATTRIBUTE_FORMULATIONTYPE);
			}catch(Exception ex) {
				ex.printStackTrace();
			}
			return slEBOMTarget;
		}

		/**
		 * This Method is use for Relationship selectables
		 * 
		 * @return StringList
		 */


		public static StringList getRelationshipSelectsEBOM(){
			StringList slEBOMRel = new StringList(33);
			try{

				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGMINQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGMAXQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
				slEBOMRel.add(DomainConstants.SELECT_RELATIONSHIP_ID);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_REL_ID);
				slEBOMRel.add("frommid["+pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE+"]");
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_TYPE);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_NAME);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_REVISION);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_CURRENT);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_PG_BOM_BASEQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGSAPTYPE);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_EFFECTIVITY_DATE);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR); 
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_COMMENT);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_COMMENT);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_MIN_QUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_MAX_QUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
				
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
				slEBOMRel.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
				
				
			}catch(Exception ex) {
				ex.printStackTrace();

			}		
			return slEBOMRel;
		}


		/**
		 * This Method is use for Relationship selectables
		 * 
		 * @return StringList
		 */


		public static StringList getRelationshipSelectsOthers() {
			StringList slEBOMRel = new StringList(25);
			try{			
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGMINQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGMAXQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
				slEBOMRel.add(DomainConstants.SELECT_RELATIONSHIP_ID);			
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT); 		
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_LOSS);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);			
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_PGISACTIVATED);
				slEBOMRel.add(pgV3Constants.SELECT_FBOM_SUBSTITUTE_TYPE);
				slEBOMRel.add(pgV3Constants.SELECT_FBOM_SUBSTITUTE_NAME);
				slEBOMRel.add(pgV3Constants.SELECT_FBOM_SUBSTITUTE_ID);
				slEBOMRel.add(pgV3Constants.SELECT_FBOM_SUBSTITUTE_REL_ID);
				slEBOMRel.add(pgV3Constants.SELECT_FBOM_SUBSTITUTE_BASE_UOM);
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				slEBOMRel.add(pgV3Constants.SELECT_FBOM_SUBSTITUTE_EFFECTIVITY_DATE);
				slEBOMRel.add(pgV3Constants.SELECT_FBOM_SUBSTITUTE_FORMULATION_TYPE);
				
				slEBOMRel.add(pgV3Constants.SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID);
				
			}catch(Exception ex) {
				ex.printStackTrace();

			}		
			return slEBOMRel;
		}


		/**
		 * converts ArrayList To Array
		 * 
		 * @param ArrayList
		 * @param int
		 * @return String[][]
		 */
		private String[][] convertArrayListToArray(ArrayList alGeneric, int iArraySize) throws Exception {
			String[][] saReturn = new String[1][1];
			try {
				if (alGeneric != null) {
					Iterator itr = alGeneric.iterator();

					saReturn = new String[alGeneric.size()][iArraySize];
					int i = 0;
					while (itr.hasNext()) {
						String[] saTemp = (String[]) itr.next();
						saReturn[i] = saTemp;
						i++;
					}
				}else {
					saReturn = new String[1][1];
				}
			} catch (Exception e) {
				e.printStackTrace();
				saReturn = new String[1][1];
			}

			return saReturn;
		}
		
		
		
		
		/** 
		 * 
		 * Checks the validity of the Production Stage.
		 * BOM eDelivery shall be done only for Production Stage with Usage 3.
		 * @param context the eMatrix <code>Context</code> object	 
		 * @param Map
		 * @return boolean
		 * @throws Exception
		 */

		public synchronized boolean doProdUsageCheckForeDelivery(Context context,Map mapPartDetails) throws Exception {

			boolean bProdStage3 = false;
			String strStage		= DomainConstants.EMPTY_STRING;
			String strStatus	= DomainConstants.EMPTY_STRING;
			try {

				if(null != mapPartDetails && mapPartDetails.size()>0) {
					strStatus = (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_STATUS);
					strStage = (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_RELEASE_PHASE);

					if(validator.isNotNullOrEmpty(strStatus) && !"Unknown".equalsIgnoreCase(strStatus) && !pgV3Constants.RANGE_ATTRIBUTE_STATUS_PLANNING.equalsIgnoreCase(strStatus) && !pgV3Constants.RANGE_ATTRIBUTE_PGBOMBASEQUANTITY_EXPERIMENTAL.equalsIgnoreCase(strStatus) ) {

						bProdStage3 = true;
					}
					
					if(!bProdStage3 && validator.isNotNullOrEmpty(strStage) && !pgV3Constants.RANGE_ATTRIBUTE_STATUS_PLANNING.equalsIgnoreCase(strStage) && !pgV3Constants.RANGE_ATTRIBUTE_PGBOMBASEQUANTITY_EXPERIMENTAL.equalsIgnoreCase(strStage) ) {

						bProdStage3 = true;
					}
				}
			}catch(Exception ex) {
				ex.printStackTrace();
				//throw new Exception(ex.getMessage());
			}
			return bProdStage3;
		}

		
		
		/** 
		 * 
		 * Get the EBOM, Substitute and Alternates for types Formula card, Finished Product and Packing Subassembly.
		 * @param context the eMatrix <code>Context</code> object
		 * @param Map
		 * @return ArrayList
		 * @throws Exception
		 */

		public synchronized ArrayList getPartObjectsFromEBOM(Context context,Map mapPartDetails) throws Exception {

			MapList mlPartObjects 				= new MapList();
			ArrayList alPartRelatedObjects 		= new ArrayList();		

			String strType 							= 	DomainConstants.EMPTY_STRING;
			String strName 							= 	DomainConstants.EMPTY_STRING;
			String strRev 							= 	DomainConstants.EMPTY_STRING;
			String strFindNumb						=	DomainConstants.EMPTY_STRING;
			String strEffectivityDate				=	DomainConstants.EMPTY_STRING;
			String strParentEffectivityDate			=	DomainConstants.EMPTY_STRING;
			String sChildName						=	DomainConstants.EMPTY_STRING;
			String sQuantity						=	DomainConstants.EMPTY_STRING;
			String strMax							=	DomainConstants.EMPTY_STRING;
			String sTarget							=	DomainConstants.EMPTY_STRING;
			String strMin							=	DomainConstants.EMPTY_STRING;
			String strPosInd						=	DomainConstants.EMPTY_STRING;
			String strFILBaseQty					=	DomainConstants.EMPTY_STRING;
			String strSubstitute 					= 	DomainConstants.EMPTY_STRING;		
			String strBOMQuantity 					= 	DomainConstants.EMPTY_STRING;
			String strSAPName 						= 	DomainConstants.EMPTY_STRING;
			String id 								= 	DomainConstants.EMPTY_STRING;
			String strObjectType					= 	DomainConstants.EMPTY_STRING;
			String strTempSAPType					= 	DomainConstants.EMPTY_STRING;
			String strObjID							= 	DomainConstants.EMPTY_STRING;
			String strChildID						= 	DomainConstants.EMPTY_STRING;
			String strpgPhaseBOMQty					=	DomainConstants.EMPTY_STRING;
			String strOptComponent					=	DomainConstants.EMPTY_STRING;
			String strComment						=	DomainConstants.EMPTY_STRING;
			String strParentBOMBaseQty 				= 	DomainConstants.EMPTY_STRING;

			try {


				if(null != mapPartDetails && mapPartDetails.size()>0) {

					strType 						= (String)mapPartDetails.get(DomainConstants.SELECT_TYPE);
					strName 						= (String)mapPartDetails.get(DomainConstants.SELECT_NAME);
					strRev 							= (String)mapPartDetails.get(DomainConstants.SELECT_REVISION);
					strParentEffectivityDate		= (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
					strParentBOMBaseQty 			= (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);

					HashMap mpPartDataMap 			= new HashMap(); 
					DomainObject dChildObj 			= DomainObject.newInstance(context); 
					Map mAllData					= new HashMap();
					
					String arrOutput[][] 			= getBOMData(context, mapPartDetails);
					

					StringList slPartInfo			= new StringList(8);
					slPartInfo.addElement(DomainConstants.SELECT_TYPE);
					slPartInfo.addElement(DomainConstants.SELECT_DESCRIPTION);
					slPartInfo.addElement(DomainConstants.SELECT_NAME);
					slPartInfo.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					slPartInfo.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
					slPartInfo.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
					slPartInfo.addElement(pgV3Constants.SELECT_ATTRIBUTE_TITLE);
					slPartInfo.addElement(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);

					if(null != arrOutput && arrOutput.length > 0)
					{
						for(int i=0;i<arrOutput.length;i++)
						{

							mpPartDataMap  			= new HashMap();
							id 						= arrOutput[i][23];
							strSubstitute 			= arrOutput[i][14];		
							strBOMQuantity 			= arrOutput[i][10];
							mpPartDataMap.put(pgV3Constants.MAP_KEY_BOM_TARGET,arrOutput[i][18]);
							
							strMin 					= arrOutput[i][19];
							strMax 					= arrOutput[i][17];
							strPosInd 				= arrOutput[i][13];
							strSAPName 				= arrOutput[i][9];


							mpPartDataMap.put(pgV3Constants.MAP_KEY_ID,arrOutput[i][23]);
							mpPartDataMap.put(pgV3Constants.MAP_KEY_SUBSTITUTE,strSubstitute);
							mpPartDataMap.put(pgV3Constants.MAP_KEY_BOMQTY,strBOMQuantity);
							mpPartDataMap.put(pgV3Constants.MAP_KEY_MIN,strMin);
							mpPartDataMap.put(pgV3Constants.MAP_KEY_MAX,strMax);
							mpPartDataMap.put(pgV3Constants.MAP_KEY_POSINDEX,strPosInd);
							mpPartDataMap.put(pgV3Constants.MAP_KEY_SAPNAME,strSAPName);
							mpPartDataMap.put(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT,arrOutput[i][24]);
							mpPartDataMap.put(pgV3Constants.SELECT_ATTRIBUTE_COMMENT,arrOutput[i][25]);

							if(BusinessUtil.isNotNullOrEmpty(id)) {

								dChildObj = DomainObject.newInstance(context,id);

								mAllData	= dChildObj.getInfo(context,slPartInfo);

								if(null != mAllData && mAllData.size()>0) {


									strTempSAPType = (String)mAllData.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
									strObjectType = (String)mAllData.get(DomainConstants.SELECT_TYPE);
									strEffectivityDate = (String)mAllData.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
									mpPartDataMap.put(pgV3Constants.MAP_KEY_EFFECTIVITYDATE,strEffectivityDate);
									mpPartDataMap.put(DomainConstants.SELECT_TYPE,strObjectType);
									mpPartDataMap.put(DomainConstants.SELECT_DESCRIPTION,(String)mAllData.get(DomainConstants.SELECT_DESCRIPTION));
									mpPartDataMap.put(pgV3Constants.MAP_KEY_CHILD, (String)mAllData.get(DomainConstants.SELECT_NAME));
									mpPartDataMap.put(pgV3Constants.MAP_KEY_SAPUOM,(String)mAllData.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
									mpPartDataMap.put(pgV3Constants.MAP_KEY_SAPTYPE,(String)mAllData.get(strTempSAPType));
									mpPartDataMap.put(pgV3Constants.MAP_KEY_SSTYPE,pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
									mpPartDataMap.put(pgV3Constants.MAP_KEY_SAPDESC,(String)mAllData.get(pgV3Constants.SELECT_ATTRIBUTE_TITLE));

									mpPartDataMap.put(pgV3Constants.MAP_KEY_dISPLAYID, arrOutput[i][23]);

									mpPartDataMap.put(pgV3Constants.MAP_KEY_CHILD_ID, id);

									/*	Masters components will not be included in BOM eDelivery
									Any component of SAP type as "DOC" will not be eDelivered. 
									 */

									if(!pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strTempSAPType) && !strObjectType.contains(pgV3Constants.TYPE_MASTER))  {

										mlPartObjects.add(mpPartDataMap);									

									}
								}
							}
						}
					}

					if(BusinessUtil.isNotNullOrEmpty(mlPartObjects)) { 

						int iSizeFlatBOM				=	mlPartObjects.size();
						Map mpBOM					=	new HashMap();

						String[] arrBOM				=	new String[pgV3Constants.INDEX_BOM_ARRAY_SIZE];

						for(int i=0;iSizeFlatBOM>i;i++) {

							mpBOM=(Map)mlPartObjects.get(i);


							strEffectivityDate		= (String)mpBOM.get(pgV3Constants.MAP_KEY_EFFECTIVITYDATE);
							sChildName 				= (String)mpBOM.get(pgV3Constants.MAP_KEY_CHILD);
							sQuantity 				= (String)mpBOM.get(pgV3Constants.MAP_KEY_BOMQTY);
							sTarget 				= (String)mpBOM.get(pgV3Constants.MAP_KEY_BOM_TARGET);
							strMin 					= (String)mpBOM.get(pgV3Constants.MAP_KEY_MIN);
							strMax 					= (String)mpBOM.get(pgV3Constants.MAP_KEY_MAX);
							strPosInd 				= (String)mpBOM.get(pgV3Constants.MAP_KEY_POSINDEX);
							strObjID				= (String)mpBOM.get(DomainObject.SELECT_ID);
							strChildID				= (String)mpBOM.get(pgV3Constants.MAP_KEY_CHILD_ID);
							strOptComponent			= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
							strComment			= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_COMMENT);
							
							// To get the necessary information of the child objects.
			
							arrBOM = buildBOMArray ( strName,  strFindNumb,strEffectivityDate,sChildName,  sQuantity,strMax,  sTarget,  strMin, strParentEffectivityDate, strParentBOMBaseQty,  strPosInd, strFILBaseQty, strpgPhaseBOMQty, (String)mpBOM.get(pgV3Constants.MAP_KEY_SUBSTITUTE),strObjID, strOptComponent,strComment,"","","", "");
							alPartRelatedObjects.add(arrBOM);
						}
					}		

				}
			}catch(Exception ex) {
				ex.printStackTrace();
				//throw new Exception(ex.getMessage());
			}
			return alPartRelatedObjects;
		}

		

		/**
		 * 
		 * getObjectsForFOPFromFormulaIngredient- Method is used to get the Child for Formulation Part
		 * Get the PLBOM, Substitute and Alternates for Formulation part.
		 * @param context the eMatrix <code>Context</code> object
		 * @param sPartObjectID
		 * @return ArrayList
		 * @throws Exception
		 */
		public synchronized ArrayList getObjectsForFOPFromFormulaIngredient(Context context,Map mapPartDetails) throws Exception {


			String[] saPLBOMArray = new String[pgV3Constants.INDEX_BOM_ARRAY_SIZE];

			ArrayList alPartObjects = new ArrayList();

			Map mpPLBOMData 						= new HashMap();
			DomainObject domPhaseObjectChild 		= null;
			DomainObject doAlternateObj 			= null;

			String 	strName 						= DomainConstants.EMPTY_STRING;

			String 	strID 							= DomainConstants.EMPTY_STRING;
			String 	strBOMBaseQty 					= DomainConstants.EMPTY_STRING;
			String 	strParentEffectivDate			= DomainConstants.EMPTY_STRING;
			String 	RELATIONSHIP_PLANNEDFOR 		= pgV3Constants.RELATIONSHIP_PLANNEDFOR;
			String 	TYPE_FORMULATIONPROCESS 		= pgV3Constants.TYPE_FORMULATIONPROCESS;
			String 	TYPE_FORMULATIONPHASE 			= pgV3Constants.TYPE_FORMULATIONPHASE;
			char 		cAltItem1 					= pgV3Constants.ALT_ITEM_NINE;		
			char 		cAltItem2 					= pgV3Constants.ALT_ITEM_A;

			String 	strChildType					= DomainConstants.EMPTY_STRING;
			String 	strChildID						= DomainConstants.EMPTY_STRING;
			String[] 	saChild 					= new String[1]; 

			String strFormulationChildType 			= DomainConstants.EMPTY_STRING;
			String strFormulationChildId 			= DomainConstants.EMPTY_STRING;
			String strFormPhaseChildType 			= DomainConstants.EMPTY_STRING;
			MapList mpListChildren					= new MapList();
			String strParentName					= DomainConstants.EMPTY_STRING;
			String strFindNumber					= DomainConstants.EMPTY_STRING;
			String strEffectivityDateChild			= DomainConstants.EMPTY_STRING;
			String strObjectName					= DomainConstants.EMPTY_STRING;
			String strQuantity						= DomainConstants.EMPTY_STRING;
			String strMax							= DomainConstants.EMPTY_STRING;
			String strTargetQuantity				= DomainConstants.EMPTY_STRING;
			String strMin							= DomainConstants.EMPTY_STRING;
			String strPosInd						= DomainConstants.EMPTY_STRING;
			String strFILBaseQty					= DomainConstants.EMPTY_STRING;
			String strpgPhaseBOMQty					= DomainConstants.EMPTY_STRING;
			String id								= DomainConstants.EMPTY_STRING;
			String strSAPType						= DomainConstants.EMPTY_STRING;
			String strObjectType					= DomainConstants.EMPTY_STRING;
			String strAlternate						= DomainConstants.EMPTY_STRING;
			String strPLBOMRelId 					= DomainConstants.EMPTY_STRING;
			String strSubstitue						= DomainConstants.EMPTY_STRING;
			String strTSName 						= DomainConstants.EMPTY_STRING;
			String strTSType 						= DomainConstants.EMPTY_STRING;
			String strValidFromDateSub 				= DomainConstants.EMPTY_STRING;
			String strQty			 				= DomainConstants.EMPTY_STRING;
			String strGroup			 				= DomainConstants.EMPTY_STRING;
			String sChildFormulationType 			= DomainConstants.EMPTY_STRING;
			String strChildSubFormulationType 		= DomainConstants.EMPTY_STRING;
			String[][] saSubs						= new String[1][1];		
			StringList slQtyValues 					= new StringList(1);		
			StringList slSubstituteGroupValues 		= new StringList(1);
			MapList mpListIngredients				= new MapList();

			String strAlternateBaseUOM 				= DomainConstants.EMPTY_STRING;
			String 	strChildEffectivDate			= DomainConstants.EMPTY_STRING;
			String strFOPName			 			= DomainConstants.EMPTY_STRING;
			String strAltId 						= DomainConstants.EMPTY_STRING;
			String strAltName 						= DomainConstants.EMPTY_STRING;
			String strAltEffDate 					= DomainConstants.EMPTY_STRING;
			String strSubQuantity 					= DomainConstants.EMPTY_STRING;
			String strSubMaxQty 					= DomainConstants.EMPTY_STRING;
			String strSubMinQty 					= DomainConstants.EMPTY_STRING;
			String strAlternateMin 					= DomainConstants.EMPTY_STRING;
			String strAlternateMax 					= DomainConstants.EMPTY_STRING;
			String strAlternateQTY 					= DomainConstants.EMPTY_STRING;
			
			String strPriAlternateAssemblyType		= DomainConstants.EMPTY_STRING;
			String strPriAlternateSAPType			= DomainConstants.EMPTY_STRING;
			String strSubAlternateAssemblyType		= DomainConstants.EMPTY_STRING;
			String strSubAlternateSAPType			= DomainConstants.EMPTY_STRING;
			
			
			
			String strTempSpecSubType = DomainConstants.EMPTY_STRING;
			

			//For Grouping Identifier
			int iCounter = 0;
			//For BaseUOM Validation
			String strBaseUOMChild 					= DomainConstants.EMPTY_STRING;
			String strBaseUOMParent 				= DomainConstants.EMPTY_STRING;
			String strBaseUOMSub 					= DomainConstants.EMPTY_STRING;
			String strSubRelID 						= DomainConstants.EMPTY_STRING;
			String strFOPNextRev 					= DomainConstants.EMPTY_STRING;
			
			Map mpTempChildData 			= new HashMap();
			Map phaseInfo 					= new HashMap();
			DomainObject domObjectChild 	= null;

			MapList mlPLBOMParts 			= new MapList();
			MapList mlPhases 				= new MapList();

			
			DomainObject domPhase = null;
			String strActualWeightDry				= DomainConstants.EMPTY_STRING;
			String strActualPercentDry				= DomainConstants.EMPTY_STRING;
			String strActualWeightWet				= DomainConstants.EMPTY_STRING;
			String strActualPercentWet				= DomainConstants.EMPTY_STRING;
			String strLoss2							= DomainConstants.EMPTY_STRING;
			String phaseId 							= DomainConstants.EMPTY_STRING;
			
			
			String phaseVIPercentConsumed 			= DomainConstants.EMPTY_STRING;
			
			double dTotal_Dry_Weight 			= 0.0;
			double dFOP_Percent 				= 100;
			double dFOP_Loss					= 0.0;
			double dFOP_Actual_Weight_Wet    	= 0.0;
			double dFOP_Loss_Percent    		= 0.0;
			
			
			boolean isTargetPercentAsConsumedFixed = false;
			
			
			//Sub Selectable
			String strNONGCASTYPE = "pgPhase,pgCustomerUnitPart,pgInnerPackUnitPart,pgConsumerUnitPart,pgAncillaryPackagingMaterialPart,pgAncillaryRawMaterialPart,pgMasterConsumerUnitPart,pgMasterCustomerUnitPart,pgMasterInnerPackUnitPart,pgMasterPackagingAssemblyPart,pgMasterPackagingMaterialPart,pgMasterRawMaterialPart,pgMasterProductPart,Cosmetic Formulation,Virtual Intermediate,Formulation Phase";
			String strObjectWhere = new StringBuffer(DomainObject.SELECT_CURRENT).append( " != ").append(pgV3Constants.STATE_PART_OBSOLETE).toString();
			
			MapList mlSubAlts = null;
			int iAltsSize = 0;
			
			try {
				if(null != mapPartDetails && mapPartDetails.size()>0) {
					strID 				= (String)mapPartDetails.get(DomainConstants.SELECT_ID);
					strFOPName 			= (String)mapPartDetails.get(DomainConstants.SELECT_NAME);
					strBOMBaseQty 		= (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
					strParentEffectivDate	= (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
					strBaseUOMParent	= (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					if(BusinessUtil.isNotNullOrEmpty(strID)) {
						strFOPNextRev	= (String)mapPartDetails.get("next.id");
						mpListChildren = getValidFormulationProcess(context, strID, strFOPNextRev);
									
						if(null != mpListChildren && mpListChildren.size()>0) {

							int iChildrenSize 				= mpListChildren.size();
		
							for (int i=0;i<iChildrenSize;i++) {

								mpTempChildData = (Map)mpListChildren.get(i);
								strChildType 	= (String) mpTempChildData.get(DomainConstants.SELECT_TYPE);
								strChildID 		= (String) mpTempChildData.get(DomainConstants.SELECT_ID);

								if(TYPE_FORMULATIONPROCESS.equalsIgnoreCase(strChildType)){

									strActualWeightDry 	= (String) mpTempChildData.get(pgV3Constants.SELECT_ATTRIBUTE_ACTUAL_WEIGHT_DRY);
									strActualPercentDry = (String) mpTempChildData.get(pgV3Constants.SELECT_ATTRIBUTE_ACTUAL_PERCENT_DRY);
									strActualWeightWet 	= (String) mpTempChildData.get(pgV3Constants.SELECT_ATTRIBUTE_ACTUAL_WEIGHT_WET);
									strActualPercentWet = (String) mpTempChildData.get(pgV3Constants.SELECT_ATTRIBUTE_ACTUAL_PERCENT_WET);

									if(BusinessUtil.isNotNullOrEmpty(strChildID)) {

										domObjectChild = DomainObject.newInstance(context, strChildID);
										
										String strSumOfDryweight= getTotalDryweight(context,domObjectChild);
										

										if(null != domObjectChild) {
											mlPhases =  domObjectChild.getRelatedObjects(context,
													pgV3Constants.RELATIONSHIP_PLBOM, 	//relationshipPattern
													//pgV3Constants.SYMBOL_STAR, 			//typePattern
													DomainConstants.QUERY_WILDCARD,		// type pattern
													false, 								//getTo
													true, 								//getFrom
													(short)ConstantsUtilIRM.FIRST_LVL, 	//recurseToLevel
													SL_FOP_OBJECT_INFO_SELECT, 			//objectSelects
													SL_RELATION_INFO_SELECT_OTHERS, 	//relationshipSelects
													strObjectWhere, 					//objectWhere
													null, 								//relationshipWhere
													null,								//PostRelPattern
													null,			//PostTypePattern
													null);
											
											if(mlPhases != null && mlPhases.size()>0) {
												
													Collections.sort(mlPhases, new Comparator() {					
															public int compare(Object first,
																		Object second) {
																		Map firstMap = (Map) first;
																		Map secondMap = (Map) second;
																		String firstValue = (String) (firstMap.get(DomainConstants.SELECT_NAME));
																		String secondValue = (String) secondMap.get(DomainConstants.SELECT_NAME);
																		
																		return firstValue.compareTo(secondValue);
																			}
																		} );
														
												for(int l=0; l<mlPhases.size();l++) {
													phaseInfo = (Map) mlPhases.get(l);
													phaseId = (String) phaseInfo.get(DomainConstants.SELECT_ID);
													domPhase = DomainObject.newInstance(context, phaseId);
													mlPLBOMParts =  domPhase.getRelatedObjects(context,
															pgV3Constants.RELATIONSHIP_PLBOM, 	//relationshipPattern
															//pgV3Constants.SYMBOL_STAR, 			//typePattern
															DomainConstants.QUERY_WILDCARD,		// type pattern
															false, 								//getTo
															true, 								//getFrom
															(short)ConstantsUtilIRM.SECOND_LVL, 	//recurseToLevel
															SL_FOP_OBJECT_INFO_SELECT, 			//objectSelects
															SL_RELATION_INFO_SELECT_OTHERS, 	//relationshipSelects
															strObjectWhere, 					//objectWhere
															null, 								//relationshipWhere
															null,								//PostRelPattern
															null,			//PostTypePattern
															null);
													// Expanding till level 3 to get all the required data for all the types at once. Confirm Level Once
													if(null != mlPLBOMParts && mlPLBOMParts.size()>0) {
														
														int iPLBOMSize = mlPLBOMParts.size();
														
														String strMaxWet = DomainConstants.EMPTY_STRING;
														String strMinWet = DomainConstants.EMPTY_STRING;
														String strLoss = DomainConstants.EMPTY_STRING;
														String strQty2 = DomainConstants.EMPTY_STRING;
														String strFindNumber2 = DomainConstants.EMPTY_STRING;
														String strFindNumb = DomainConstants.EMPTY_STRING;
														String sChildName = DomainConstants.EMPTY_STRING;
														String strTempSAPType = DomainConstants.EMPTY_STRING;
														String sQuantity = DomainConstants.EMPTY_STRING;
														String sTarget = DomainConstants.EMPTY_STRING;
														String strQtyTmp = DomainConstants.EMPTY_STRING;
														String strGroupTmp = DomainConstants.EMPTY_STRING;
														String strFOPChildID = DomainConstants.EMPTY_STRING;
														String strFOPChildType = DomainConstants.EMPTY_STRING;
														String strTargetDryWeight = DomainConstants.EMPTY_STRING;
														String strTargetWetWeight = DomainConstants.EMPTY_STRING;
														
														String strVIPhysicalID = DomainConstants.EMPTY_STRING;
														
														
														String strBOMType = "";
														String strBOMName = "";
														
														Object oSubstituteId				= null;
														Object oSubstituteType 				= null;
														Object oSubstituteName				= null;
														Object oSubstituteBaseUOM 			= null;
														Object substituteEffectivityDate	= null;
														Object oSubstituteRelID 			= null;
														Object substituteFormulationType 	= null;
														Object oAlternateId 				= null;
														Object oAlternateType				= null;
														Object oAlternateName 				= null;
														Object oAlternateEffDate			= null;
														Object oAlternateBaseUOM  			= null;
														
														DomainObject doRMP = DomainObject.newInstance(context);
														MapList mpListBOMChildren = new MapList();

														Map mpReturned = null; 
														
														Map mapVISUbs = new HashMap();
														
			
														StringList  slAltType = new StringList(1);
														StringList slAltName = new StringList(1);
														StringList slAltID = new StringList(1);
														for(int j=0;j<iPLBOMSize;j++) {
															strMaxWet 		= DomainConstants.EMPTY_STRING;
															strMinWet 		= DomainConstants.EMPTY_STRING;
															strLoss 		= DomainConstants.EMPTY_STRING;
															strQty2 		= DomainConstants.EMPTY_STRING;
															strFindNumber2 	= DomainConstants.EMPTY_STRING;
															mpPLBOMData = (Map)mlPLBOMParts.get(j);
															strTempSAPType			= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
															
															strTempSpecSubType			= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
															
															
															strFormulationChildType = (String) mpPLBOMData.get(DomainConstants.SELECT_TYPE);
															
															//sChildFormulationType 	= (String)mpPLBOMData.get("to["+pgV3Constants.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+pgV3Constants.SELECT_ATTRIBUTE_FORMULATIONTYPE);
															Object OChildFormulationType = (Object)mpPLBOMData.get("to["+pgV3Constants.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+pgV3Constants.SELECT_ATTRIBUTE_FORMULATIONTYPE);
															
															StringList slChildFormulationType = new StringList();
												
															if (null != OChildFormulationType) {
																if (OChildFormulationType instanceof StringList) {
																	slChildFormulationType = (StringList) OChildFormulationType;
																} else if (OChildFormulationType instanceof String) {
																	slChildFormulationType.add(OChildFormulationType.toString());
																}
															}
															
															
															if((!(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strTempSAPType)) && !(strNONGCASTYPE.contains(strFormulationChildType)) && !strTempSpecSubType.equalsIgnoreCase(pgV3Constants.THIRD_PARTY)) && (!pgV3Constants.TYPE_FORMULATIONPART.equals(strFormulationChildType) || (pgV3Constants.TYPE_FORMULATIONPART.equals(strFormulationChildType) && !slChildFormulationType.isEmpty() && !slChildFormulationType.contains(pgV3Constants.THIRD_PARTY_FORMULA)))) {
															
																strFormulationChildId	= (String) mpPLBOMData.get(DomainConstants.SELECT_ID);
																strChildEffectivDate	= (String) mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
																strFindNumb				= (String)mpPLBOMData.get(DomainConstants.SELECT_ATTRIBUTE_FIND_NUMBER);
																strEffectivityDateChild	= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
																sChildName				= (String)mpPLBOMData.get(DomainConstants.SELECT_NAME);
																sQuantity				= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGQUANTITY);
																strMax					= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGMAXQUANTITY);
																strMin					= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGMINQUANTITY);
																sTarget					= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
																strPosInd				= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
																strFILBaseQty			= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
																strID 					= (String)mpPLBOMData.get(DomainObject.SELECT_ID); 
																strBaseUOMChild			= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
																strQtyTmp  				= strQty2;
																strPLBOMRelId 			= (String)mpPLBOMData.get(DomainRelationship.SELECT_ID);												
																strBOMType = "";
																strBOMName = "";
																strTargetDryWeight 		= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
																strTargetWetWeight 		= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
																
																strVIPhysicalID 		= (String)mpPLBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID);
																
																if (BusinessUtil.isNotNullOrEmpty(strVIPhysicalID)) {
																	 
																	 DomainObject dobVirtual = new DomainObject(strVIPhysicalID);
																		String sValue =	dobVirtual.getInfo(context, SAPBOMConstants.IS_TARGET_PERCENT_WET_IN_VIRTUAL_INTERMEDIATE);
																		//SPEC: 11/06/2020: Added for Defect:37257 -- START
																		//VirtualIntermediate virtualObj = new VirtualIntermediate(context,strVIPhysicalID);
																		 //isTargetPercentAsConsumedFixed=virtualObj.isTargetPercentAsConsumedFixed();				
																		 isTargetPercentAsConsumedFixed= UIUtil.isNotNullAndNotEmpty(sValue) ? Boolean.parseBoolean(sValue) : false;
																		 phaseVIPercentConsumed = (String)getVITargetPercentConsumed(context,isTargetPercentAsConsumedFixed,strPLBOMRelId);
																			//SPEC: 11/06/2020: Added for Defect:37257 -- END
													
																		 
																}
																
																if(BusinessUtil.isNotNullOrEmpty(strFormulationChildId)) {
			
																	//Include the Substitute of Component
																	oSubstituteId  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_ID);
																	StringList slSubstituteId = new StringList();
																	if (null != oSubstituteId) {
																		//Refactoring - InstanceList - 49
																		slSubstituteId = getInstanceList(oSubstituteId);
																	}
																	oSubstituteType  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_TYPE);
																	StringList slSubstituteType = new StringList();
																	if (null != oSubstituteType) {
																		//Refactoring - InstanceList - 50
																		slSubstituteType = getInstanceList(oSubstituteType);
																	}
																	oSubstituteName  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_NAME);
																	StringList slSubstituteName = new StringList();
																	if (null != oSubstituteName) {
																		//Refactoring - InstanceList - 51
																		slSubstituteName = getInstanceList(oSubstituteName);
																	}
																	oSubstituteBaseUOM  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_BASE_UOM);
																	StringList slSubstituteBaseUOM = new StringList();
																	if (null != oSubstituteBaseUOM) {
																		//Refactoring - InstanceList - 52
																		slSubstituteBaseUOM = getInstanceList(oSubstituteBaseUOM);
																	}
						
																	substituteEffectivityDate = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_EFFECTIVITY_DATE);
																	StringList slSubstituteEffectivityDate = new StringList();
																	if (null != substituteEffectivityDate) {
																		//Refactoring - InstanceList - 53
																		slSubstituteEffectivityDate = getInstanceList(substituteEffectivityDate);
																	} 
						
																	oSubstituteRelID  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_REL_ID);
																	StringList slSubstituteRelID = new StringList();
																	if (null != oSubstituteRelID) {
																		//Refactoring - InstanceList - 54
																		slSubstituteRelID = getInstanceList(oSubstituteRelID);
																	}
						
																	substituteFormulationType = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_FORMULATION_TYPE);
																	StringList slSubstituteFormulationType = new StringList();
																	if (null != substituteFormulationType) {
																		//Refactoring - InstanceList - 55
																		slSubstituteFormulationType = getInstanceList(substituteFormulationType);
																	} 
																	
																	
																	if (BusinessUtil.isNotNullOrEmpty(strVIPhysicalID)) {
																		mapVISUbs =(Map)getVISubstituteDetails(context,strVIPhysicalID,strFormulationChildId);
																																																			
																		if(mapVISUbs!=null && !mapVISUbs.isEmpty()) { 										
																			slSubstituteId.addAll((StringList)mapVISUbs.get("slSubstituteId"));
																			slSubstituteType.addAll((StringList)mapVISUbs.get("slSubstituteType"));
																			slSubstituteName.addAll((StringList)mapVISUbs.get("slSubstituteName"));
																			slSubstituteBaseUOM.addAll((StringList)mapVISUbs.get("slSubstituteBaseUOM"));
																			slSubstituteEffectivityDate.addAll((StringList)mapVISUbs.get("slSubstituteEffectivityDate"));
																			slSubstituteRelID.addAll((StringList)mapVISUbs.get("slSubstituteRelID"));
																			slSubstituteFormulationType.addAll((StringList)mapVISUbs.get(slSubstituteFormulationType));
																		}
																		
																	}		
																	
																	//Include the Alternates of Component
																	oAlternateId = (Object) mpPLBOMData.get(pgV3Constants.SELECT_ALTERNATE_ID);
																	StringList slAlternateId = new StringList();
																	if (null != oAlternateId) {
																		//Refactoring - InstanceList - 56
																		slAlternateId = getInstanceList(oAlternateId);
																	}
																	oAlternateType = (Object) mpPLBOMData.get(pgV3Constants.SELECT_ALTERNATE_TYPE);
																	StringList slAlternateType = new StringList();
																	if (null != oAlternateType) {
																		//Refactoring - InstanceList - 57
																		slAlternateType = getInstanceList(oAlternateType);
																	}
																	oAlternateName = (Object) mpPLBOMData.get(pgV3Constants.SELECT_ALTERNATE_NAME);
																	StringList slAlternateName = new StringList();
																	if (null != oAlternateName) {
																		//Refactoring - InstanceList - 58
																		slAlternateName = getInstanceList(oAlternateName);													
																	}
																	
																	oAlternateEffDate = (Object) mpPLBOMData.get(pgV3Constants.SELECT_ALTERNATE_EFFECTIVITY_DATE);
																	StringList slAlternateEffDate = new StringList();
																	if (null != oAlternateEffDate) {
																		//Refactoring - InstanceList - 59
																		slAlternateEffDate = getInstanceList(oAlternateEffDate);
																	}
																	
																	oAlternateBaseUOM  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_ALTERNATE_BASE_UOM);
																	StringList slAlternateBaseUOM = new StringList();
																	if (null != oAlternateBaseUOM) {
																		//Refactoring - InstanceList - 60
																		slAlternateBaseUOM = getInstanceList(oAlternateBaseUOM);												
																	}
																	
																	Object oAlternateSpecSubType  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_ALTERNATE_PGASSEMBLYTYPE);
																	StringList slAlternateAssemblyType = new StringList();
																	if (null != oAlternateSpecSubType) {
																		slAlternateAssemblyType = getInstanceList(oAlternateSpecSubType);
																	}
																	
																	Object oAlternateSAPType  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_ALTERNATE_PGASSEMBLYTYPE);
																	StringList slAlternateSAPType = new StringList();
																	if (null != oAlternateSAPType) {
																		slAlternateSAPType = getInstanceList(oAlternateSAPType);												
																	}
																	

																	//If Part has Substitute/Alternate then set Grouping Identifier
																	//Note: Include the alternate validation as well once code is written to include Alternate Part
																	if((null != slSubstituteId && slSubstituteId.size()>0) || (null != slAlternateId && slAlternateId.size()>0)) {
																		if(iCounter > 0) {
																			if (cAltItem2 == 'Z') {
																				cAltItem2 = 'A';
																				cAltItem1--;
																			} else {
																				cAltItem2++;
																			}
																		}
																		iCounter++ ;
																		strGroupTmp = cAltItem1 + "" + cAltItem2;
																	} else {
																		strGroupTmp = DomainConstants.EMPTY_STRING;
																	}
																	
																	StringList slMinMaxQty_Primary = calculateMaxMinQtyForFOPChild(context,strPLBOMRelId,strBOMBaseQty,strBaseUOMParent, strBaseUOMChild,false,strSumOfDryweight,DomainConstants.EMPTY_STRING);
																	
																	saPLBOMArray=	buildBOMArray(strFOPName , strFindNumber,strEffectivityDateChild, sChildName, (String)slMinMaxQty_Primary.get(2),(String)slMinMaxQty_Primary.get(1), "",(String)slMinMaxQty_Primary.get(0), strParentEffectivDate, strBOMBaseQty,"", "","",strGroupTmp,strFormulationChildId,"","", strTargetWetWeight,strTargetDryWeight, "True", "");
																	//Modified by DSM - for 2018x.1 requirement #25043 - Ends
																	alPartObjects.add(saPLBOMArray);
																	
																	if(null != slAlternateId) {
																		String strAlternateType = DomainConstants.EMPTY_STRING;
																		String strAlternateName = DomainConstants.EMPTY_STRING;
																		String strAlternateID = DomainConstants.EMPTY_STRING;
																		String strAlternateEffDate = DomainConstants.EMPTY_STRING;
																		for(int kk=0;kk<slAlternateId.size();kk++) {
																			
																			strPriAlternateAssemblyType = (String)slAlternateAssemblyType.get(kk);		
																			strPriAlternateSAPType = (String)slAlternateSAPType.get(kk);
																			if (!strPriAlternateAssemblyType.equalsIgnoreCase(pgV3Constants.THIRD_PARTY) && !pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strPriAlternateSAPType)) {
																				strAlternateType= (String)slAlternateType.get(kk);
																				strAlternateName = (String)slAlternateName.get(kk); 
																				strAlternateID = (String)slAlternateId.get(kk); 
																				strAlternateEffDate = (String)slAlternateEffDate.get(kk);		
																						
																				String[] saTemp2 = new String[pgV3Constants.INDEX_BOM_ARRAY_SIZE]; 
																				strAlternateBaseUOM = (String)slAlternateBaseUOM.get(kk);	
																				if(BusinessUtil.isNotNullOrEmpty(strBaseUOMParent) && BusinessUtil.isNotNullOrEmpty(strAlternateBaseUOM) &&    ((strBaseUOMParent.equalsIgnoreCase(strAlternateBaseUOM))|| (strBaseUOMParent.equalsIgnoreCase(pgV3Constants.BUOM_EACH) && strAlternateBaseUOM.equalsIgnoreCase(pgV3Constants.BUOM_KILOGRAM)) )) {	
																					strAlternateMin = (String)slMinMaxQty_Primary.get(0);
																					strAlternateMax = (String)slMinMaxQty_Primary.get(1);
																					strAlternateQTY = (String)slMinMaxQty_Primary.get(2);
																				}
																				
																				else if(BusinessUtil.isNullOrEmpty(strBaseUOMParent) || BusinessUtil.isNullOrEmpty(strAlternateBaseUOM) || !(strBaseUOMParent.equalsIgnoreCase(strAlternateBaseUOM)))
																				{
																					strAlternateMin = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
																					strAlternateMax = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
																					strAlternateQTY = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
																				}
																				
																				saTemp2=	buildBOMArray(strFOPName , strFindNumber,strAlternateEffDate, strAlternateName, strAlternateQTY,strAlternateMax, "",strAlternateMin, strParentEffectivDate, strBOMBaseQty,"", "","",strGroupTmp,strAlternateID,"","", "", "","", "");
																				
																				alPartObjects.add(saTemp2);
																			}
																			
																		}
																	}
															
																	if(null != slSubstituteId) {
																		int iFormulationTypeSize=slSubstituteFormulationType.size();
																		int iCounterFormulation=0;
																		for(int pp=0;pp<slSubstituteId.size();pp++) {
																			strBOMType = (String)slSubstituteType.get(pp);	
																			if(pgV3Constants.TYPE_FORMULATIONPART.equals(strBOMType) && (iCounterFormulation<iFormulationTypeSize)){
																				strChildSubFormulationType = (String) slSubstituteFormulationType.get(iCounterFormulation);
																				iCounterFormulation++;
																			}
																			else 
																				strChildSubFormulationType = DomainConstants.EMPTY_STRING;

																			if(!pgV3Constants.TYPE_FORMULATIONPART.equals(strBOMType) || (pgV3Constants.TYPE_FORMULATIONPART.equals(strBOMType) && UIUtil.isNotNullAndNotEmpty(strChildSubFormulationType) && !pgV3Constants.THIRD_PARTY_FORMULA.equals(strChildSubFormulationType))){
																				strBOMName = (String)slSubstituteName.get(pp); 
																				strBaseUOMSub = (String)slSubstituteBaseUOM.get(pp);
																				strEffectivityDateChild = (String)slSubstituteEffectivityDate.get(pp);
																				strSubRelID = (String)slSubstituteRelID.get(pp); 
																				String strBOMIdName = (String)slSubstituteId.get(pp);
					
																				String[] saTemp = new String[pgV3Constants.INDEX_BOM_ARRAY_SIZE]; 
																				
																				StringList slMinMaxQty = calculateMaxMinQtyForFOPChild(context,strSubRelID,strBOMBaseQty,strBaseUOMParent, strBaseUOMSub,true,DomainConstants.EMPTY_STRING,phaseVIPercentConsumed);
																				
																				strSubQuantity = (String)slMinMaxQty.get(2);
																				strSubMaxQty = (String)slMinMaxQty.get(1);
																				strSubMinQty = (String)slMinMaxQty.get(0);
																				
																				saTemp=	buildBOMArray(strFOPName , strFindNumber,strEffectivityDateChild, strBOMName, strSubQuantity,strSubMaxQty, "",strSubMinQty, strParentEffectivDate, strBOMBaseQty,"", "","",strGroupTmp,strBOMIdName,"","", "", "","", "");
																				
																				
																				alPartObjects.add(saTemp);
																				
																				if(UIUtil.isNotNullAndNotEmpty(strBOMType) && ALTERNATE_ALLOWED_TYPES.contains(strBOMType)){
																					mlSubAlts= getAlternates(context,
			 																		 strBOMIdName);
																					iAltsSize = mlSubAlts.size();
																					for(int k=0;k<iAltsSize;k++){
																						Map mpAltMap = (Map) mlSubAlts.get(k);
																						
																						strSubAlternateAssemblyType = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
																						strSubAlternateSAPType = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
																						if (!strSubAlternateAssemblyType.equalsIgnoreCase(pgV3Constants.THIRD_PARTY) && !pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubAlternateSAPType)) {
																							strAltId = (String) mpAltMap.get(DomainConstants.SELECT_ID);
																							strAltName = (String) mpAltMap.get(DomainConstants.SELECT_NAME);
																							strAltEffDate = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
																							strAlternateBaseUOM = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
																								
																							if(BusinessUtil.isNotNullOrEmpty(strBaseUOMParent) && BusinessUtil.isNotNullOrEmpty(strAlternateBaseUOM) &&    ((strBaseUOMParent.equalsIgnoreCase(strAlternateBaseUOM))|| (strBaseUOMParent.equalsIgnoreCase(pgV3Constants.BUOM_EACH) && strAlternateBaseUOM.equalsIgnoreCase(pgV3Constants.BUOM_KILOGRAM)) ))
																							{
																								strAlternateMin = strSubMinQty;
																								strAlternateMax = strSubMaxQty;
																								strAlternateQTY = strSubQuantity;
																							} else if(BusinessUtil.isNullOrEmpty(strBaseUOMParent) || BusinessUtil.isNullOrEmpty(strAlternateBaseUOM) || !(strBaseUOMParent.equalsIgnoreCase(strAlternateBaseUOM)))
																							{
																								strAlternateMin = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
																								strAlternateMax = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
																								strAlternateQTY = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
																							}
																							
																							saTemp = new String[pgV3Constants.INDEX_BOM_ARRAY_SIZE];
																							//Modified by DSM - for 2018x.1 requirement #25043 - Starts
																							saTemp=	buildBOMArray(strFOPName , strFindNumber,strAltEffDate, strAltName, strAlternateQTY,strAlternateMax, "",strAlternateMin, strParentEffectivDate, strBOMBaseQty,"", "","",strGroupTmp,strAltId,"","", "", "","", "");
																							//Modified by DSM - for 2018x.1 requirement #25043 - Ends
																							alPartObjects.add(saTemp);
																						}
																						
																					}
																				}
																			}
																		}
																	}															
																}
															}
														} // End of for loop of child objects
														
													}//end phase loop
		
												} // End of if (phase null check)
											}// End of if null check
										}	
									}
								}
							}
						}
					}
				}
			}catch(Exception ex) {
				ex.printStackTrace();
				//throw new Exception(ex.getMessage());
			}
			return alPartObjects;
		} // end of method getObjectsForFOPFromFormulaIngredient

		
		

		/**
		 * getBOMData- Method is used get BOM data of FC, FP, PSUB to be send to SAP. 
		 * @param context the eMatrix <code>Context</code> object
		 * @param Map with parent object details
		 * @return String[][] of BOM object details
		 * @throws Exception 
		 */
		public String[][] getBOMData(Context context, Map mapPartDetails) {
			
			String[][] saBOM = null;
			String strValidFromDate = DomainConstants.EMPTY_STRING;
			String strBOMBaseQty = DomainConstants.EMPTY_STRING;
			String strStatus = DomainConstants.EMPTY_STRING;
			String strBOMUsage = DomainConstants.EMPTY_STRING;
			String strObjectID = DomainConstants.EMPTY_STRING;
			String strObjectName = DomainConstants.EMPTY_STRING;
			String strObjectRev = DomainConstants.EMPTY_STRING;
			String strChildType = DomainConstants.EMPTY_STRING;
			String strChildName = DomainConstants.EMPTY_STRING;
			String strChildRev = DomainConstants.EMPTY_STRING;
			String strPgFPC = DomainConstants.EMPTY_STRING;
			String strChildObjID = DomainConstants.EMPTY_STRING;
			String strFindNumber = DomainConstants.EMPTY_STRING;
			String strRelId = DomainConstants.EMPTY_STRING;
			String strQuantity = DomainConstants.EMPTY_STRING;
			String strTarget = DomainConstants.EMPTY_STRING;
			String strLowerLim = DomainConstants.EMPTY_STRING;
			String strUpperLim = DomainConstants.EMPTY_STRING;
			String strPosIndicator = DomainConstants.EMPTY_STRING;
			String strOptComponent = DomainConstants.EMPTY_STRING;
			String strComment = DomainConstants.EMPTY_STRING;
			String strValidFromDateComp = DomainConstants.EMPTY_STRING;
			String strSubstFlag = DomainConstants.EMPTY_STRING;
			String strBOMNumber = DomainConstants.EMPTY_STRING;
			String strComponentNumber = DomainConstants.EMPTY_STRING;
			String strPhaseName = DomainConstants.EMPTY_STRING;
			String strPhaseObjID = DomainConstants.EMPTY_STRING;
			DomainObject dObjPhase = null;
			MapList mlPhaseChildObjList = null;
			MapList mlFirstLevelData = null;
			Map hmPhaseMap = null;
			Map hmPhaseChildMap = null;
			String strChildBUOM = DomainConstants.EMPTY_STRING;
			DomainObject dObjForTopNodePart = null;

			try {
				strObjectName = (String)mapPartDetails.get(DomainConstants.SELECT_NAME);
				strObjectRev = (String)mapPartDetails.get(DomainConstants.SELECT_REVISION);
				strObjectID = (String)mapPartDetails.get(DomainConstants.SELECT_ID);
				dObjForTopNodePart = DomainObject.newInstance(context, strObjectID);
				
				strBOMBaseQty = (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				strStatus = (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_STATUS);
				strParentBUOM = (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				strParentType = (String)mapPartDetails.get(DomainConstants.SELECT_TYPE);	
				
				if (strStatus.equals(pgV3Constants.RANGE_ATTRIBUTE_STATUS_PLANNING))
					strBOMUsage = "2";
				else if (!strStatus.equals(pgV3Constants.RANGE_ATTRIBUTE_PGBOMBASEQUANTITY_EXPERIMENTAL)) 
					strBOMUsage = "3";
				
				strValidFromDate = (String)mapPartDetails.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				//strValidFromDate = DateUtil.convertPLMDateToSAP(strValidFromDate);
				strValidFromDate = convertPLMDateToSAP(strValidFromDate);

				_ParentMatlNumber = strObjectName;
				//strParentGCAS = strObjectName;
				strParentRev = strObjectRev;
		
				StringList slPhaseBusSelect = new StringList(2);
				slPhaseBusSelect.add(DomainConstants.SELECT_NAME);
				slPhaseBusSelect.add(DomainConstants.SELECT_ID);
				
				mlFirstLevelData = dObjForTopNodePart.getRelatedObjects(context,
						pgV3Constants.RELATIONSHIP_EBOM, 	// rel pattern
						pgV3Constants.TYPE_PGPHASE,         // type pattern
						//SL_OBJECT_INFO_SELECT,         	// object select
						slPhaseBusSelect,
						//SL_RELATION_INFO_SELECT_EBOM,   // rel select
						null,
						false,                  			// to side
						true,                   			// from side 
						(short)ConstantsUtilIRM.FIRST_LVL,     // recursion level
						DomainConstants.EMPTY_STRING,       // object where clause
						DomainConstants.EMPTY_STRING,0); 
				Iterator itr = mlFirstLevelData.iterator();
				String[] saBOMRow = null;
				// Expand from the TS to get the pgPhase object
				while (itr.hasNext()) {
					
					hmPhaseMap = (Hashtable) itr.next();
					
					strPhaseName = (String)hmPhaseMap.get(DomainConstants.SELECT_NAME);
					strPhaseObjID = (String)hmPhaseMap.get(DomainConstants.SELECT_ID);
					dObjPhase = DomainObject.newInstance(context, strPhaseObjID);
					
					Pattern pgPhaseExpTypePattern = new Pattern(pgV3Constants.TYPE_PGFINISHEDPRODUCT);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_PGFORMULATEDPRODUCT);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_PGRAWMATERIAL);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_PGPACKINGMATERIAL);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_PGPACKINGSUBASSEMBLY);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_FINISHEDPRODUCTPART);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_PACKAGINGASSEMBLYPART);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_FORMULATIONPART);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_DEVICEPRODUCTPART);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_PACKAGINGMATERIALPART);
					pgPhaseExpTypePattern.addPattern(pgV3Constants.TYPE_RAWMATERIALPART);
					
					StringList slPhaseChildBusSelect = new StringList(6);
					slPhaseChildBusSelect.add(DomainConstants.SELECT_TYPE);
					slPhaseChildBusSelect.add(DomainConstants.SELECT_NAME);
					slPhaseChildBusSelect.add(DomainConstants.SELECT_REVISION);
					slPhaseChildBusSelect.add(DomainConstants.SELECT_ID);
					slPhaseChildBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
					slPhaseChildBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
					slPhaseChildBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					
					
					StringList slPhaseChildRelSelect = new StringList(7);
					slPhaseChildRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
					slPhaseChildRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER);
					slPhaseChildRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
					slPhaseChildRelSelect.add(DomainConstants.SELECT_RELATIONSHIP_ID);
					slPhaseChildRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
					slPhaseChildRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
					slPhaseChildRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
					slPhaseChildRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_COMMENT);

					mlPhaseChildObjList = dObjPhase.getRelatedObjects(context,
						pgV3Constants.RELATIONSHIP_EBOM, 		// rel pattern
						pgPhaseExpTypePattern.getPattern(), 	// type pattern
						//SL_OBJECT_INFO_SELECT,         		// object select
						slPhaseChildBusSelect,
						//SL_RELATION_INFO_SELECT_EBOM,    		// rel select
						slPhaseChildRelSelect,
						false,                  				// to side
						true,                   				// from side 
						(short)ConstantsUtilIRM.FIRST_LVL,   		// recursion level
						DomainConstants.EMPTY_STRING,           // object where clause
						DomainConstants.EMPTY_STRING,0); 
					
					Iterator pgPhaseItr = mlPhaseChildObjList.iterator();
					
					while (pgPhaseItr.hasNext()) {
						
						hmPhaseChildMap = (Hashtable)pgPhaseItr.next();
						
						strChildType = (String) hmPhaseChildMap.get(DomainConstants.SELECT_TYPE);
						strChildName = (String) hmPhaseChildMap.get(DomainConstants.SELECT_NAME);
						strChildRev = (String) hmPhaseChildMap.get(DomainConstants.SELECT_REVISION);
						strPgFPC = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
						strChildObjID = (String) hmPhaseChildMap.get(DomainConstants.SELECT_ID);						
						strFindNumber = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER);
						strChildBUOM = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					
						strComponentNumber = strChildName;
		
						//For Substitutes
						strRelId = (String) hmPhaseChildMap.get(DomainConstants.SELECT_RELATIONSHIP_ID);					
						strQuantity = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
						strTarget = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
						strLowerLim = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
						strUpperLim = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
						strPosIndicator = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
						strOptComponent = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
						strComment = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_COMMENT);
						strValidFromDateComp = (String) hmPhaseChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
						strValidFromDateComp = convertPLMDateToSAP(strValidFromDateComp);
						
						if(!strFirstlevelObjId.equals(""))
							hmParentObjects.put(strFirstlevelObjId,iChildObjCount);
						strFirstlevelObjId = strChildObjID;
						iChildObjCount = 1;
						
						if (strChildType.equals(pgV3Constants.TYPE_PGBASEFORMULA)) {
							getBaseFormulaRows(context, strChildName, strChildRev, 
									strFindNumber,strPhaseName,strObjectName,  strValidFromDate, strBOMBaseQty,
									strBOMUsage, strChildObjID);
						} else {
							
							if (strChildType.startsWith(pgV3Constants.PGMASTER)) {
								
								//Add the indidivuals as subs
								getIndividualsFromMaster(context,strObjectName, strValidFromDate, strBOMBaseQty, 
										strPhaseName, strFindNumber, strBOMNumber, strChildType,
										strChildName, strChildRev, strBOMUsage, strQuantity, strUpperLim,
										strTarget, strLowerLim, strValidFromDateComp, strPosIndicator, true, strChildObjID);							
								buildFCBOMArray(context, strPhaseName, strFindNumber,
									strObjectName, strBOMUsage, strValidFromDate,
									strComponentNumber, strQuantity, strSubstFlag,
									strUpperLim, strTarget, strLowerLim,
									strValidFromDateComp, strBOMNumber, strBOMBaseQty,
									strPosIndicator, strRelId, strChildName, strChildRev, true, strChildObjID, "","", strChildBUOM);
							} else{										
								buildFCBOMArray(context, strPhaseName, strFindNumber,
										strObjectName, strBOMUsage, strValidFromDate,
										strComponentNumber, strQuantity, strSubstFlag,
										strUpperLim, strTarget, strLowerLim,
										strValidFromDateComp, strBOMNumber, strBOMBaseQty,
										strPosIndicator, strRelId, strChildName, strChildRev, false, strChildObjID, strOptComponent,strComment, strChildBUOM);			
							}
						}
					}
				}
				hmParentObjects.put(strFirstlevelObjId,iChildObjCount);
				
				alBOMFC = getBOMAlternateSubstituteGrouping(context, alBOMFC);				
				saBOM = convertArrayListToArray(alBOMFC, BOM_ARRAY_SIZE);
			} catch (Exception e) {
				e.printStackTrace();
			}

			if (saBOM != null){			
				
				//Arrays.sort(saBOM, new BOMArrayComparator());			
				Arrays.sort(saBOM, new Comparator(){
					public int compare(Object obj1, Object obj2)
					{
						int result = 0;

						String[] str1 = (String[]) obj1;
						String[] str2 = (String[]) obj2; 


						/* Sort on first element of each array (last name) */
						if ((result = str1[pgV3Constants.INDEX_PHASE_NAME].compareTo(str2[pgV3Constants.INDEX_PHASE_NAME])) == 0)
						{
							/* If same last name, sort on second element (first name) */
							Float in1 = null;
							if(UIUtil.isNotNullAndNotEmpty(str1[pgV3Constants.INDEX_FIND_NUMBER]) && !(str1[pgV3Constants.INDEX_FIND_NUMBER].contains("#DENIED!")))
							{
								 in1=Float.valueOf(str1[pgV3Constants.INDEX_FIND_NUMBER]);
							}
							Float in2 = null;
							if(UIUtil.isNotNullAndNotEmpty(str2[pgV3Constants.INDEX_FIND_NUMBER]) && !(str2[pgV3Constants.INDEX_FIND_NUMBER].contains("#DENIED!")))
							{
								 in2=Float.valueOf(str2[pgV3Constants.INDEX_FIND_NUMBER]);
							}
							if(null != in1 && null != in2)
								result = in1.compareTo(in2);
						}					
						return result;
					}
					
				}); 
			}		
			return saBOM;
		}
		
		/**
		 * getBaseFormulaRows- Method is used get BOM data of Base Formula to be send to SAP. 
		 * @param context the eMatrix <code>Context</code> object
		 * @param *
		 * @return ArrayList of BOM object details
		 * @throws Exception 
		 */
		public ArrayList getBaseFormulaRows(Context context, String strBSFName, String strBSFRev, 
				String strFindNumber, String strPgPhaseName, String strParentName, String strParentEffectiveDate, 
				String strParentBOMBaseQty, String strBOMUsage, String strTSID) {
			String[][] saReturn = null;
			String strType = DomainConstants.EMPTY_STRING;
			String strName = DomainConstants.EMPTY_STRING;
			String strRev = DomainConstants.EMPTY_STRING;
			String strRelId = DomainConstants.EMPTY_STRING;
			String strChildObjId = DomainConstants.EMPTY_STRING;
			String strRowFindNumber = DomainConstants.EMPTY_STRING;
			String strComponentNumber = DomainConstants.EMPTY_STRING;
			String strQuantity = DomainConstants.EMPTY_STRING;
			String strTarget = DomainConstants.EMPTY_STRING;
			String strLowerLim = DomainConstants.EMPTY_STRING;
			String strUpperLim = DomainConstants.EMPTY_STRING;
			String strPosIndicator = DomainConstants.EMPTY_STRING;
			String strOptComponent = DomainConstants.EMPTY_STRING;
			String strComment = DomainConstants.EMPTY_STRING;
			String strValidFromDateComp = DomainConstants.EMPTY_STRING;
			String strBOMNumber = DomainConstants.EMPTY_STRING;
			String strSubstFlag = DomainConstants.EMPTY_STRING;
			String strChildBUOM = DomainConstants.EMPTY_STRING;
			DomainObject domBSF = null;
			
			StringList slBusSelect = new StringList(7);
			slBusSelect.add(DomainConstants.SELECT_TYPE);
			slBusSelect.add(DomainConstants.SELECT_NAME);
			slBusSelect.add(DomainConstants.SELECT_REVISION);
			slBusSelect.add(DomainConstants.SELECT_ID);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			
			StringList slRelSelect = new StringList(8);
			slRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
			slRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER);
			slRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
			slRelSelect.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			slRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
			slRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
			slRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
			slRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_COMMENT);
			
			MapList mlBSFChildObjList = new MapList();

			try {
				domBSF = DomainObject.newInstance(context, strTSID);
			
				mlBSFChildObjList = domBSF.getRelatedObjects(context,
							pgV3Constants.RELATIONSHIP_EBOM, 	// rel pattern
							pgV3Constants.TYPE_PRODUCTDATA,     // type pattern
							//SL_OBJECT_INFO_SELECT,         	// object select
							slBusSelect,
							//SL_RELATION_INFO_SELECT_EBOM,   // rel select
							slRelSelect,
							false,                  			// to side
							true,                   			// from side 
							(short)ConstantsUtilIRM.FIRST_LVL,   	// recursion level
							DomainConstants.EMPTY_STRING,       // object where clause
							DomainConstants.EMPTY_STRING,0); 
				
				Iterator bsfChildItr = mlBSFChildObjList.iterator();
				
				while (bsfChildItr.hasNext()) {
					
					Map hmChildMap = (HashMap) bsfChildItr.next();
					
					strType = (String) hmChildMap.get(DomainConstants.SELECT_TYPE);
					strName = (String) hmChildMap.get(DomainConstants.SELECT_NAME);
					strRev = (String) hmChildMap.get(DomainConstants.SELECT_REVISION);
					strRelId = (String) hmChildMap.get(DomainConstants.SELECT_RELATIONSHIP_ID);
					strChildObjId = (String) hmChildMap.get(DomainConstants.SELECT_ID);
					strRowFindNumber = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER);
					strQuantity = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
					strTarget = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
					strLowerLim = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
					strUpperLim = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
					strPosIndicator = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
					strOptComponent = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
					strComment = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_COMMENT);
					strChildBUOM = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);	
					strValidFromDateComp = (String) hmChildMap.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
					strValidFromDateComp = convertPLMDateToSAP(strValidFromDateComp);
					
					if (strType.startsWith(pgV3Constants.PGMASTER)) {
						buildFCBOMArray(context, strPgPhaseName, strRowFindNumber,
								strParentName, strBOMUsage, strParentEffectiveDate,
								strComponentNumber, strQuantity, strSubstFlag,
								strUpperLim, strTarget, strLowerLim,
								strValidFromDateComp, strBOMNumber, strParentBOMBaseQty,
								strPosIndicator, strRelId, strName, strRev, false, strChildObjId, "","", strChildBUOM);
						//Add the indidivuals as subs
						getIndividualsFromMaster(context, strParentName,strParentEffectiveDate, strParentBOMBaseQty, 
								strPgPhaseName, strFindNumber, strBOMNumber, strType,
								strName, strRev, strBOMUsage, strQuantity, strUpperLim,
								strTarget, strLowerLim, strValidFromDateComp, strPosIndicator, true, strChildObjId);
					} else {
						buildFCBOMArray(context, strPgPhaseName, strRowFindNumber,
								strParentName, strBOMUsage, strParentEffectiveDate,
								strComponentNumber, strQuantity, strSubstFlag,
								strUpperLim, strTarget, strLowerLim,
								strValidFromDateComp, strBOMNumber, strParentBOMBaseQty,
								strPosIndicator, strRelId, strName, strRev, false, strChildObjId, strOptComponent,strComment, strChildBUOM);			
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return alBOMFC;
		}
		/**
		 * 
		 * buildFCBOMArray- Method is used build array for FC BOM data. 
		 * @param context the eMatrix <code>Context</code> object
		 * @param *
		 * @return 
		 * @throws Exception 
		 */

		public void buildFCBOMArray(Context context, String strPgPhase, String strFindNumber,
					String strName, String strBomUsage, String strValidFromDate,
					String strComponentName, String strQuantity, String strSubstituteFlag,
					String strUpperLimit, String strTarget, String strLowerLimit,
					String strValidFromDateComponent, String strBOMNumber,
					String strBOMBaseQuantity, String strPositionIndicator, String strRelId,
					String strGCAS, String strVersion, boolean bOnlySendChildren, String strTSID, String strOptComponent,String strComment, String strChildBUOM) {

			boolean bIgnoreBlankTarget = false;
			if (strTarget.equals("")) {
				_AbortReason = "Aborting BOM because target is null for " + strComponentName;
				bIgnoreBlankTarget = true;
			}
			
			String[] saTemp = new String[BOM_ARRAY_SIZE];
			String[][] saSubs = null;
			String strTSName = DomainConstants.EMPTY_STRING;	
			String strTSType = DomainConstants.EMPTY_STRING;	
			String strTSRev  = DomainConstants.EMPTY_STRING;
			String strValidFromDateSub = DomainConstants.EMPTY_STRING;
			String strSubComponentNumber = DomainConstants.EMPTY_STRING;

			// Set the constant value fields
			saTemp[pgV3Constants.INDEX_ALT_BOM] = pgV3Constants.VALUE_ALT_BOM;
			saTemp[pgV3Constants.INDEX_BOM_STATUS] = pgV3Constants.VALUE_BOM_STATUS;
			saTemp[pgV3Constants.INDEX_ITEM_CATEGORY] = pgV3Constants.VALUE_ITEM_CATEGORY;
			//saTemp[pgV3Constants.INDEX_BOM_TEXT] = strParentGCAS + "." + strParentRev;	
			saTemp[pgV3Constants.INDEX_BOM_TEXT] = _ParentMatlNumber + "." + strParentRev;	
			saTemp[pgV3Constants.INDEX_ALT_BOM_TEXT] = pgV3Constants.VALUE_ALT_BOM_TEXT;

			// Set the variable fields
			if (!strSubstituteFlag.equals("")) {
				saTemp[pgV3Constants.INDEX_SUBSTITUTE_FLAG] = strSubstituteFlag;
				saTemp[pgV3Constants.INDEX_USAGE_PROBABILITY] = pgV3Constants.VALUE_USAGE_PROBABILITY;
			} else {
				saTemp[pgV3Constants.INDEX_SUBSTITUTE_FLAG] = "";
				saTemp[pgV3Constants.INDEX_USAGE_PROBABILITY] = "";
			}

			saTemp[pgV3Constants.INDEX_MATERIAL_NUMBER] = _ParentMatlNumber;
			saTemp[pgV3Constants.INDEX_BOM_USAGE] = strBomUsage;
			saTemp[pgV3Constants.INDEX_VALID_FROM_DATE_PARENT] = strValidFromDate;
			saTemp[pgV3Constants.INDEX_COMPONENT_NAME] = strComponentName;

			if(strParentType.equalsIgnoreCase(pgV3Constants.TYPE_PGFORMULATEDPRODUCT) && !strChildBUOM.equalsIgnoreCase(strParentBUOM)) {
				
				saTemp[pgV3Constants.INDEX_QUANTITY] = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
				saTemp[pgV3Constants.INDEX_UPPER_LIMIT] = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
				saTemp[pgV3Constants.INDEX_LOWER_LIMIT] = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
			} else {
			
				saTemp[pgV3Constants.INDEX_QUANTITY] = strQuantity;
				saTemp[pgV3Constants.INDEX_UPPER_LIMIT] = strUpperLimit;
				saTemp[pgV3Constants.INDEX_LOWER_LIMIT] = strLowerLimit;
			}		
			
			if(bIgnoreBlankTarget || (strParentType.equalsIgnoreCase(pgV3Constants.TYPE_PGFINISHEDPRODUCT) && !strChildBUOM.equalsIgnoreCase(strParentBUOM))) {
				
				saTemp[pgV3Constants.INDEX_TARGET] = "-9.99";
			} else {
				saTemp[pgV3Constants.INDEX_TARGET] = strTarget;	
			}			
			saTemp[pgV3Constants.INDEX_FIND_NUMBER] = strFindNumber;
			saTemp[pgV3Constants.INDEX_VALID_FROM_DATE_CHILD] = strValidFromDateComponent;
			saTemp[pgV3Constants.INDEX_PHASE_NAME] = strPgPhase;
			saTemp[pgV3Constants.INDEX_CONFIRMED_QUANTITY] = strBOMBaseQuantity;
			saTemp[pgV3Constants.INDEX_SORT_STRING] = strPositionIndicator;
			saTemp[OPT_COMPONENT] = strOptComponent;
			saTemp[COMMENT] = strComment;
			saTemp[pgV3Constants.INDEX_BOM_ITEM_NUMBER] = strBOMNumber;
			saTemp[OBJECT_ID] = strTSID;
			if(bCreatingSubsRows) {
				saTemp[DISPLAY_OBJECT_ID] = strSubsDispId;
			} else {
				saTemp[DISPLAY_OBJECT_ID] = strTSID;	
			}
			if (saTemp[pgV3Constants.INDEX_UPPER_LIMIT] == null || saTemp[pgV3Constants.INDEX_UPPER_LIMIT].equals("")) {
				saTemp[pgV3Constants.INDEX_RANGE_FLAG] = "";
			} else 
				saTemp[pgV3Constants.INDEX_RANGE_FLAG] = pgV3Constants.VALUE_RANGE_FLAG;
			
			//Need to see if this Row has subs for it. If it does. set the Alt_Item_Group for this
			//Row to the same value as the subs use
			saSubs = getSubs(context, strRelId);
			
			if (saSubs!=null) {
				saTemp[pgV3Constants.INDEX_SUBSTITUTE_FLAG] = "";
				saTemp[pgV3Constants.INDEX_USAGE_PROBABILITY] = pgV3Constants.VALUE_USAGE_PROBABILITY;
			}
			
			if (!bOnlySendChildren){
				alBOMFC.add(saTemp);
				if(strFirstlevelObjIdCopy.equals(""))
					strFirstlevelObjIdCopy = strFirstlevelObjId;
				else if(!strFirstlevelObjIdCopy.equals(strFirstlevelObjId))
					strFirstlevelObjIdCopy = strFirstlevelObjId;
				else
					iChildObjCount++;
				
				hmChildObjects.put(saTemp[DISPLAY_OBJECT_ID],strFirstlevelObjId);
			}
			
			boolean bIncrementAltItem = true;
			if (saSubs!=null) {			
				for (int i=0; i<saSubs.length; i++) {
					bCreatingSubsRows = true;
					strSubsDispId = saSubs[i][13];							
					strTSName = saSubs[i][6];				
					strTSType = saSubs[i][7];				
					strTSRev = saSubs[i][11];
					//strValidFromDateSub = saSubs[i][10];
					//strValidFromDateSub = DateUtil.convertPLMDateToSAP(saSubs[i][10]);
					strValidFromDateSub = convertPLMDateToSAP(saSubs[i][10]);	
					strChildBUOM = saSubs[i][17];
				
					if (strTSType.startsWith(pgV3Constants.PGMASTER)) {
						try {
							strTarget = saSubs[i][2];
							bCreatingSubsRows = false;
							getIndividualsFromMaster(context, strName, strValidFromDate, strBOMBaseQuantity, strPgPhase,
								strFindNumber, strBOMNumber, strTSType,strTSName, strTSRev, 
								strBomUsage, strQuantity, strUpperLimit, strTarget, strLowerLimit,
								strValidFromDateComponent,strPositionIndicator, false, strTSID);
						} catch (Exception ex) {
							ex.printStackTrace();
						}
						bIncrementAltItem = false;
					} else {
						
						strSubComponentNumber = strTSName;					
						buildFCBOMArray(context, strPgPhase, strFindNumber,
							strName, strBomUsage, strValidFromDate,
							strSubComponentNumber, saSubs[i][2], saSubs[i][5],
							saSubs[i][3], saSubs[i][2], saSubs[i][1],
							strValidFromDateSub, strBOMNumber,
							strBOMBaseQuantity, saSubs[i][0], "", strGCAS, strVersion, false, strTSID, saSubs[i][14],saSubs[i][15], strChildBUOM);
					}
					
					if(i == saSubs.length - 1) {
						bCreatingSubsRows = false;
						strSubsDispId = "";
					}

				}
			}
		}
		
		
		

		/**
		 * 
		 * getPartObjectsFromIntermediateBOM- Method is used to get EBOM, Substitute and Alternate for Finished Product Part and Packing Assembly Part .
		 * @param context the eMatrix <code>Context</code> object
		 * @param String
		 * @return ArrayList
		 * @throws Exception
		 */

		public ArrayList getPartObjectsFromIntermediateBOM(Context context, String IPSId) throws Exception {

			
			ArrayList alBOM						= new ArrayList();
			
			StringList vc = new StringList();
			StringList strListQty				= new StringList(1);
			StringList slSubstituteGroupValues	= new StringList(1);
			StringList slSubIntermediate 		= new StringList();
			StringList slSubstituteInterIdReshipper = new StringList();
			StringList slChildCOPConnectedFPPQTY = new StringList(1);
			StringList slReleaseFPPQTY = new StringList(1);
			StringList slCOPSubstituteIds 	= new StringList();
			
			StringList slCOPSubstituteQuantities 	= new StringList();
			
			Map mpAltMap 						= new HashMap();
			Map mpChildMap 						= new HashMap();
			Map mpBOM							= new HashMap();
			Map tmpMap 							= new HashMap();
			Map mapTemp 						= new HashMap();
			Map tempMap 						= new HashMap();
			Map mpNodeDeatails					= new HashMap();
			Map mpConnectedFPPToChildCOP		= new HashMap();
			
			MapList mlIntermediateChildData 	= new MapList();
			MapList mlSubInterFirstLevelData	= new MapList();
			MapList mlConnectedInterChildData 	= new MapList();
			MapList mlSubAlts 					= new MapList();
			MapList mlFlatBOM 					= new MapList();
			MapList mpTUPDATA 					= new MapList();
			MapList mlChildCOPConnectedFPP 		= new MapList();
			MapList mlReleasedFPP 				= new MapList();
			MapList masterList					= new MapList();
			
			MapList mlPAPCOPBulk				= new MapList();
			
			DomainObject dObjForTopNodePart 	= null;
			DomainObject dObjIntermediate 		= null;
			DomainObject dobjAlternate 			= null;
			DomainObject dObjInter 				= null;
			DomainObject dmaster				= null;
			
			DomainObject doBase = null;
			DomainObject doAlternate = null;
			String sBOMComponentCurrent 		= DomainConstants.EMPTY_STRING;
			String sAuthoringApplication 		= DomainConstants.EMPTY_STRING;
			String strRelationship				= DomainConstants.EMPTY_STRING; 
			boolean sCATIAAPPDeliver 			= true;
			Map mpAlternateDetails 				= new HashMap(); 
			StringList slAlternateSelects 		= new StringList(2);
		  	slAlternateSelects.add(DomainConstants.SELECT_CURRENT);
		  	slAlternateSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION);
			
			String strSubstituteInterType 		= DomainConstants.EMPTY_STRING;
			String strSubstituteType 			= DomainConstants.EMPTY_STRING;
			String strTopNodeType 				= DomainConstants.EMPTY_STRING;
			String strTopNodeName 				= DomainConstants.EMPTY_STRING;
			String strTopNodeEffeDate 			= DomainConstants.EMPTY_STRING;
			String strTopNodeBOMQty 			= DomainConstants.EMPTY_STRING;
			String strReshipperLevel 			= DomainConstants.EMPTY_STRING;
			String strID 						= DomainConstants.EMPTY_STRING;
			String strObjectType 				= DomainConstants.EMPTY_STRING;
			String strSAPType 					= DomainConstants.EMPTY_STRING;
			String strName 						= DomainConstants.EMPTY_STRING;
			String strRev 						= DomainConstants.EMPTY_STRING;
			String strLevel 					= DomainConstants.EMPTY_STRING;
			String strType				 		= DomainConstants.EMPTY_STRING;
			String strInterID 					= DomainConstants.EMPTY_STRING;
			String strFindNumb					= DomainConstants.EMPTY_STRING;
			String strEffectivityDateChild		= DomainConstants.EMPTY_STRING;
			String sChildName					= DomainConstants.EMPTY_STRING;
			String sQuantity					= DomainConstants.EMPTY_STRING;
			String strMax						= DomainConstants.EMPTY_STRING; 
			String sTarget						= DomainConstants.EMPTY_STRING;
			String strMin						= DomainConstants.EMPTY_STRING;
			String strPosInd					= DomainConstants.EMPTY_STRING;
			String strFILBaseQty				= DomainConstants.EMPTY_STRING;
			String strpgPhaseBOMQty				= DomainConstants.EMPTY_STRING;
			String strQtyTmp					= DomainConstants.EMPTY_STRING;
			String strGroupTmp					= DomainConstants.EMPTY_STRING;
			String strOptComponent				= DomainConstants.EMPTY_STRING;
			String strComment					= DomainConstants.EMPTY_STRING;
			String strIntermediateLevel			= DomainConstants.EMPTY_STRING;
		    
			String strExpandBOMonSAPBOMasFed = DomainConstants.EMPTY_STRING;
			
			
			
			//String strNONGCASTYPE = EnoviaResourceBundle.getProperty (context, "emxCPN", context.getLocale(), "emxCPN.SAPBOM.DSM.NONGCASTypes");
			String strNONGCASTYPE = "pgPhase,pgCustomerUnitPart,pgInnerPackUnitPart,pgConsumerUnitPart,pgAncillaryPackagingMaterialPart,pgAncillaryRawMaterialPart,pgMasterConsumerUnitPart,pgMasterCustomerUnitPart,pgMasterInnerPackUnitPart,pgMasterPackagingAssemblyPart,pgMasterPackagingMaterialPart,pgMasterRawMaterialPart,pgMasterProductPart,Cosmetic Formulation,Virtual Intermediate,Formulation Phase";//EnoviaResourceBundle.getProperty (context, "emxCPN", context.getLocale(), "emxCPN.SAPBOM.DSM.NONGCASTypes");
			
			
			String strBUOM						= DomainConstants.EMPTY_STRING;
			
			String strTopNodeSpecSubType		= DomainConstants.EMPTY_STRING;
			
			String strValidUntilDate			= DomainConstants.EMPTY_STRING;
			String strSpecSubType				= DomainConstants.EMPTY_STRING;
			String strInterSpecSubType			= DomainConstants.EMPTY_STRING;
			String strChildQuantity				= DomainConstants.EMPTY_STRING;
			String strInterMedLevel				= DomainConstants.EMPTY_STRING;
			String strIntermediateObjectQty 	= DomainConstants.EMPTY_STRING;	
			String strCOPToCOPQuantity 			= DomainConstants.EMPTY_STRING;
			String strSubstituteId				= DomainConstants.EMPTY_STRING;
			String strMasterID					= DomainConstants.EMPTY_STRING;
			String strExpandID					= DomainConstants.EMPTY_STRING;
			
			String strAlternateCUPSpecSubType	= DomainConstants.EMPTY_STRING;
			String strAlternateCUPSAPType		= DomainConstants.EMPTY_STRING;
			String strAlternateCOPSpecSubType	= DomainConstants.EMPTY_STRING;
			String strAlternateCOPSAPType		= DomainConstants.EMPTY_STRING;
			String strsubsCOPQuantity			= DomainConstants.EMPTY_STRING;
			String strsubsCUPQuantity			= DomainConstants.EMPTY_STRING;
			String strChildCOPAltQuantity		= DomainConstants.EMPTY_STRING;
			String strChildCUPAltQuantity		= DomainConstants.EMPTY_STRING;
			
			
			String strPriAlternateCUPSpecSubType	= DomainConstants.EMPTY_STRING;
			String strPriAlternateCOPSpecSubType	= DomainConstants.EMPTY_STRING;
			
			
			
			String strPAPChildSpecSubType = DomainConstants.EMPTY_STRING;
			String strPriAltSpecSubType = DomainConstants.EMPTY_STRING;
			String strSubAltSpecSubType = DomainConstants.EMPTY_STRING;
			
			
			
			String strExpandFABSubsAltSpecSubType = DomainConstants.EMPTY_STRING;
			
			
			Object COPSubstituteId				= null;
			Object substituteInterId			= null;
			Object substituteInterType 			= null;
			Object substituteSpecificationType	= null;
			Object substituteId 				= null;
			Object substituteSAPType			= null;
			Object substituteName				= null;
			Object substituteType				= null;
			Object substituteRev				= null;
			Object substituteState				= null;
			Object substituteRelID				= null;
			Object substituteEffectivityDate	= null;
			Object substituteValidUntilDate		= null;
			Object substituteOptComponent		= null;
			Object substituteComment			= null;
			Object oSubSpecSubType				= null;
			Object oAlternateIds				= null;
			Object substituteQuantity			= null;
			
			Object oReshipperPrimaryAlternateIds = null;
			
			
			Object oCOPSubtituteQuantities = null;
			
			int iAltsSize = 0;
			
			// Modified by Subhajit for Defect 51896 - Starts
	        String strComponentQuantity = DomainConstants.EMPTY_STRING;
	        String strMasterComponentQuantity = DomainConstants.EMPTY_STRING;
	        String strPrimaryQuantity = DomainConstants.EMPTY_STRING;
	        // Modified by Subhajit for Defect 51896 - Ends
			
			String[] arrBOM;

			char cAltItem1					= pgV3Constants.ALT_ITEM_NINE, cAltItem2	=	pgV3Constants.ALT_ITEM_A;
			String strIntermediateTypes		= pgV3Constants.TYPE_PGCUSTOMERUNITPART+","+pgV3Constants.TYPE_PGINNERPACKUNITPART+","+pgV3Constants.TYPE_PGCONSUMERUNITPART;
			
			//String strDONOTINCLUDETYPE 		= EnoviaResourceBundle.getProperty (context, "emxCPN", context.getLocale(), "emxCPN.SAPBOM.DSM.DONOTINCLUDETYPE");
			String strDONOTINCLUDETYPE 		= "pgPhase,pgCustomerUnitPart,pgInnerPackUnitPart,pgConsumerUnitPart,pgAncillaryPackagingMaterialPart,pgPromotionalItemPart";
			String objectWhere 				= DomainObject.SELECT_CURRENT+ " != " + DomainConstants.STATE_PART_OBSOLETE;
			
			Pattern pIntermediateObjectType = new Pattern(pgV3Constants.TYPE_PGCONSUMERUNITPART);
			pIntermediateObjectType.addPattern(pgV3Constants.TYPE_PGCUSTOMERUNITPART);
			pIntermediateObjectType.addPattern(pgV3Constants.TYPE_PGINNERPACKUNITPART);
			
			boolean isReshipperSub = false;
			float fChildSAPQty = 1;
			float fIntermediateSAPQty = 1;			
			BigDecimal bdIntermediateObjectQty = new BigDecimal("1");	
			
			// Modified by Subhajit for Defect 51896 - Starts
	        StringList substituteReshipper = new StringList();
	        int processIdLevel = 0;
	        String keyIsComplexBOM = SAPViewConstant.KEY_IS_SELF_COMPLEX_BOM.getValue();
	        String keyIsParentComplexBOM = SAPViewConstant.KEY_IS_PARENT_COMPLEX_BOM.getValue();
	        String keyParenID = SAPViewConstant.KEY_PARENT_ID.getValue();
	        String keyParentType = SAPViewConstant.KEY_PARENT_TYPE.getValue();
	        // Modified by Subhajit for Defect 51896 - Ends
				
			try {
				if (BusinessUtil.isNotNullOrEmpty(IPSId)) {

					dObjForTopNodePart 			= DomainObject.newInstance(context, IPSId);					
					// Check the top level part type
					mpNodeDeatails 			= dObjForTopNodePart.getInfo(context,SL_OBJECT_INFO_SELECT);
					strTopNodeType 				= (String) mpNodeDeatails.get(DomainConstants.SELECT_TYPE);
					strTopNodeName 				= (String) mpNodeDeatails.get(DomainConstants.SELECT_NAME);
					strTopNodeEffeDate 			= (String) mpNodeDeatails.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
					strTopNodeBOMQty 			= (String) mpNodeDeatails.get(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
					strBUOM						= (String) mpNodeDeatails.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					
					strTopNodeSpecSubType		= (String) mpNodeDeatails.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					
				
				
				if ((pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strTopNodeType))) {
				
					MapList mlFPPChildData = dObjForTopNodePart.getRelatedObjects(context,
							pgV3Constants.RELATIONSHIP_EBOM, 	// relationship pattern
							pIntermediateObjectType.getPattern(), // Type pattern
							SL_OBJECT_INFO_SELECT,        		// object selects
							SL_RELATION_INFO_SELECT_EBOM,  		 	// rel selects 
							false,                 				// to side
							true,                  				// from side
							(short)ConstantsUtil.ZERO_LEVEL,  	// recursion level
							objectWhere,           				// object where clause
							null,0);                    			// rel where clause
					//Get first level child for CUP, COP and IP
					if (null != mlFPPChildData && mlFPPChildData.size() > 0) {
						
						// Modified by Subhajit for Defect 51896 - Starts
                        ISAPBOM iSAPBOM = new SAPBOMS();
			            mlFPPChildData = iSAPBOM.getBOMInfoList(context, IPSId, mlFPPChildData);
			            
			            
                        boolean isSelfComplexBOM = false;
                        // Modified by Subhajit for Defect 51896 - Ends

						int iSizeOfChildData	= mlFPPChildData.size();
						Map mpPreviousLevelChildType = new HashMap();

						for (int i=0;i<iSizeOfChildData;i++) {

							tempMap 			= (Map)mlFPPChildData.get(i);
							strLevel 			= (String)(tempMap).get(DomainConstants.SELECT_LEVEL);
							
							// Modified by Subhajit for Defect 51896 - Starts
                            isSelfComplexBOM = false;
                            if(tempMap.containsKey(keyIsComplexBOM)) {
                                isSelfComplexBOM = (Boolean) (tempMap).get(keyIsComplexBOM);
                            }
                            // Modified by Subhajit for Defect 51896 - Ends

							// to avoid the child intermediate parts of reshipper CUP							
                            // Modified by Subhajit for Defect 51896 - Starts
							if(processIdLevel!=0 && processIdLevel!=parseValue(strLevel)){
								//Uncommented by Subhajit for Defect 52840
								continue;
							} else if(processIdLevel==parseValue(strLevel)){
								processIdLevel=0;
							}
							// Modified by Subhajit for Defect 51896 - Ends
                            if ((BusinessUtil.isNotNullOrEmpty(strLevel))
                                    && (BusinessUtil.isNotNullOrEmpty(strReshipperLevel))
                                    && (parseValue(strLevel) > parseValue(strReshipperLevel))) {
                                continue;
                            } else if ((BusinessUtil.isNotNullOrEmpty(strLevel))
                                    && (BusinessUtil.isNotNullOrEmpty(strReshipperLevel))
                                    && (parseValue(strLevel) <= parseValue(strReshipperLevel))) {
								strReshipperLevel = DomainConstants.EMPTY_STRING;
							}
							strID 				= (String)(tempMap).get(DomainConstants.SELECT_ID);
							strObjectType 		= (String)(tempMap).get(DomainConstants.SELECT_TYPE);
							strName 			= (String)(tempMap).get(DomainConstants.SELECT_NAME);
							strRev 				= (String)(tempMap).get(DomainConstants.SELECT_REVISION);
							
							strSpecSubType    = (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							
		
							mpPreviousLevelChildType.put(parseValue(strLevel),strObjectType);
							mpPreviousLevelChildType.put(strLevel, strID);
							// Modified by Subhajit for Defect 51896 - Starts
                            
							substituteReshipper = getStringListFromMap(tempMap,pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
							
                            //if Type is Customer Part and don't have RESHIPPER or type is Consumer part and Customer Part and Level should be greater that 1

							
							 if (((pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strObjectType)
										&& !substituteReshipper.contains("Reshipper"))
	                                    || pgV3Constants.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(strObjectType)
	                                    || pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType))
	                                    && parseValue(strLevel) > 1) {
								// Modified by Subhajit for Defect 51896 - Ends
	                                
								String strPreviousTypeToSecondLevelCOP = (String)mpPreviousLevelChildType.get(parseValue(strLevel)-1);
								String strPreviousTypeToThirdLevelCOP = (String)mpPreviousLevelChildType.get(parseValue(strLevel)-2);
								
								 
                                String sPreviousLevel = String.valueOf(Integer.parseInt(strLevel) - 1);
                                String strPreviousObjectId = (String) mpPreviousLevelChildType.get(sPreviousLevel);
                                
                             // Modified by Subhajit for Defect 51896 - Starts

                                boolean isThirdLevelCOP = pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToSecondLevelCOP);
                                boolean isCOPSpecialCase = isThirdLevelCOP
                                			&& !pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToThirdLevelCOP);

                                if ((isSelfComplexBOM && !isThirdLevelCOP) || isCOPSpecialCase) {
                                	// Modified by Subhajit for Defect 51896 - Ends
                                   
									for(int j=iSizeOfChildData - 1;j>0;j--){
										mpChildMap = (Map)mlFPPChildData.get(j-1);
										strIntermediateLevel 			= (String)(mpChildMap).get(DomainConstants.SELECT_LEVEL);
										if(parseValue(strIntermediateLevel) < parseValue(strLevel))
										{
											strIntermediateObjectQty = (String)(mpChildMap).get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
											bdIntermediateObjectQty = bdIntermediateObjectQty.multiply(new BigDecimal(strIntermediateObjectQty));
										}
									}								
									strCOPToCOPQuantity 		= (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
									// Modified by Subhajit for Defect 51896 - Starts
                                    
                                    slCOPSubstituteIds = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
                                    
                                    oCOPSubtituteQuantities = (Object) (tempMap).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
                                    
                                    slCOPSubstituteQuantities = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
                                    
                                 // Modified by Subhajit for Defect 51896 - Ends

                                    // get where-used FPPs
                                    mpConnectedFPPToChildCOP = getFPPObjectsForChildCOPInCOP(context,
                                            strID, strCOPToCOPQuantity, IPSId, slCOPSubstituteIds,
                                            strTopNodeBOMQty,
                                            bdIntermediateObjectQty,
                                            strBUOM,
                                            strTopNodeSpecSubType,
                                            strSpecSubType,
                                            slCOPSubstituteQuantities);
                                  
									bdIntermediateObjectQty = new BigDecimal("1");
									mlChildCOPConnectedFPP = (MapList)mpConnectedFPPToChildCOP.get("mlReleasedFPP");
									slChildCOPConnectedFPPQTY = (StringList)mpConnectedFPPToChildCOP.get("strListQtyValues");
									//Modified by Subhajit for Defect 52840 - Start
									if(!mlChildCOPConnectedFPP.isEmpty() && !slChildCOPConnectedFPPQTY.isEmpty())
									{
										mlReleasedFPP.addAll(mlChildCOPConnectedFPP);
										slReleaseFPPQTY.addAll(slChildCOPConnectedFPPQTY);
									}
									//Modified by Subhajit for Defect 52840 - End
									// To Skip COP child GCAS Components
									// Modified by Subhajit for Defect 51896 - Starts
                                    // if where-used is found then continue.
                                    if (!mlChildCOPConnectedFPP.isEmpty() && isSelfComplexBOM) {
                                        processIdLevel = Integer.parseInt(strLevel);
                                        continue;

                                    } else {
                                        // if where-used is not found - then continue.
                                        if (isSelfComplexBOM) {
                                        	processIdLevel = Integer.parseInt(strLevel);
                                            continue;
                                        }
                                    }
                                    if (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType)) {

                                        continue;
                                    }
								//Below check is to skip 3rd level COP child objects
								}else if(pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToSecondLevelCOP))
								{
									continue;
								}
							}
							strSpecSubType 		= (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							if ((pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strObjectType)
                                    || pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType))
                                    && pgV3Constants.THIRD_PARTY.equals(strSpecSubType)) {
								break;
							}
							if(strIntermediateTypes.contains(strObjectType)){
								String strIntermediateObjQty = (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
								if(UIUtil.isNotNullAndNotEmpty(strBUOM) && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM)) && UIUtil.isNotNullAndNotEmpty(strIntermediateObjQty))
								{
									
									BigDecimal bdIntermediateSAPQty = BigDecimal.valueOf(fIntermediateSAPQty);
									//fIntermediateSAPQty = Float.valueOf(strIntermediateObjQty) * fIntermediateSAPQty;
									bdIntermediateSAPQty = new BigDecimal(strIntermediateObjQty).multiply(bdIntermediateSAPQty);
									fIntermediateSAPQty = bdIntermediateSAPQty.floatValue();
									
								}
							}	
							// get substitute parts for Intermediate parts
							//Check if intermediate object has substitute itself - Start	
							// Modified by Subhajit for Defect 51896 - Starts
                            StringList substituteInterIds = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
                            slSubstituteInterIdReshipper = substituteInterIds;
                            StringList substituteInterTypes = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_TYPE); // Intermediate parts substitute parts types
                            StringList slSubstituteSpecificationTypes = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE); // Intermediate part substitute specification Type
                            // Modified by Subhajit for Defect 51896 - Ends
							//If types is intermediate type, add to sub stringlist
							if (null != substituteInterIds && substituteInterIds.size() > 0) {

								for(int iSubInter=0;iSubInter < substituteInterIds.size();iSubInter++) {
									strSubstituteInterType = (String)substituteInterTypes.get(iSubInter);
									strSpecSubType = (String)slSubstituteSpecificationTypes.get(iSubInter);
									if(((pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strSubstituteInterType)) || (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strSubstituteInterType)) && !pgV3Constants.THIRD_PARTY.equals(strSpecSubType)) ||(pgV3Constants.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(strSubstituteInterType))) {
										slSubIntermediate.addElement((String)substituteInterIds.get(iSubInter));
									}
								}
							}

							//Check if intermediate object has substitute itself - End
							// Now for each Intermediate object find its child	
							// avoid adding child parts for CUP which has Reshipper as a specification sub type						
							if ((strObjectType.equalsIgnoreCase(pgV3Constants.TYPE_PGCUSTOMERUNITPART)) && (slSubstituteSpecificationTypes.indexOf(pgV3Constants.RESHIPPER_ASS_TYPE_VAL) != -1) && (strTopNodeType.equalsIgnoreCase(pgV3Constants.TYPE_FINISHEDPRODUCTPART))) {

								strReshipperLevel = strLevel;
								isReshipperSub=true;
								continue;
							}

							dObjIntermediate 		= DomainObject.newInstance(context, strID);
							mlIntermediateChildData = dObjIntermediate.getRelatedObjects(context,
									pgV3Constants.RELATIONSHIP_EBOM, // rel pattern
									//pgV3Constants.SYMBOL_STAR,       // type pattern
									DomainConstants.QUERY_WILDCARD,  // type pattern
									SL_OBJECT_INFO_SELECT,           // object select
									SL_RELATION_INFO_SELECT_EBOM,    //  rel select 
									false,                           // to side
									true,                            //  from side
									(short)ConstantsUtilIRM.FIRST_LVL,   // recursion level
									objectWhere,                     //  object where clause  
									null,0);                         //  rel where clause 

							if (null != mlIntermediateChildData && mlIntermediateChildData.size() > 0) {

								mlIntermediateChildData.sort(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");

								int iSizeOfIntermediateChild=mlIntermediateChildData.size();

								for (int iCount=0;iCount<iSizeOfIntermediateChild;iCount++) {

									tmpMap 	= (Map)mlIntermediateChildData.get(iCount);
									strType = (String)(tmpMap).get(DomainConstants.SELECT_TYPE);
									
									// Modified by Subhajit for Defect 51896 - Starts
                                    float fQtyMultiplier = 0;
                                    strPrimaryQuantity = DomainConstants.EMPTY_STRING;
                                    strComponentQuantity = (String) tmpMap.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
                                    // Modified by Subhajit for Defect 51896 - Ends
									boolean bExpandFAB = false;
									if(UIUtil.isNotNullAndNotEmpty(strType) && strType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART)) 
									{
									  strExpandBOMonSAPBOMasFed = (String)(tmpMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED);
										if((UIUtil.isNotNullAndNotEmpty(strExpandBOMonSAPBOMasFed) &&  strExpandBOMonSAPBOMasFed.equalsIgnoreCase("TRUE")))
										{
											bExpandFAB = true;  
										} 
									}
									
									if(strObjectType.equals(pgV3Constants.TYPE_PGCONSUMERUNITPART) && strType.equals(pgV3Constants.TYPE_PGCONSUMERUNITPART))
									{
									continue;
									}
									strSpecSubType = (String)(tmpMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
									if(pgV3Constants.THIRD_PARTY.equals(strSpecSubType)){
										continue;	
									}
									if (!(strDONOTINCLUDETYPE.contains(strType))) {
										(tmpMap).put("IntermediateName", strName+"."+strRev);
										(tmpMap).put("IntermediateID", strID);
										(tmpMap).put("IntermediateType", strObjectType);
										(tmpMap).put("IntermediateLevel", strLevel);
										(tmpMap).put("IsDirectComponent", "true");
										
										// Modified by Subhajit for Defect 51896 - Starts
                                        strPrimaryQuantity = getReshipperQuantityValue(context, dObjIntermediate, isReshipperSub, strComponentQuantity, strTopNodeBOMQty, strBUOM, fQtyMultiplier);
                                        // Modified by Subhajit for Defect 51896 - Ends
									
										
										//if(strType.contains(pgV3Constants.TYPE_MASTER)) {	
										if(strType.contains(pgV3Constants.TYPE_MASTER) || (UIUtil.isNotNullAndNotEmpty(strType) && strType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART) && bExpandFAB))
										{	
											
											
											//return (new MapList());
											strMasterID = (String)(tmpMap).get(DomainConstants.SELECT_ID);
											dmaster = DomainObject.newInstance(context,strMasterID );
											masterList = dmaster.getRelatedObjects(context,
													pgV3Constants.RELATIONSHIP_EBOM, // rel pattern
													//pgV3Constants.SYMBOL_STAR,       // type pattern
													DomainConstants.QUERY_WILDCARD,  // type pattern
													SL_OBJECT_INFO_SELECT,           // object select
													SL_RELATION_INFO_SELECT_EBOM,    //  rel select 
													false,                           // to side
													true,                            //  from side
													(short)ConstantsUtilIRM.FIRST_LVL,    // recursion level
													DomainConstants.EMPTY_STRING,    //  object where clause  
													null,0);  
											
											int masterComp = masterList.size();
											for(int k=0; k<masterComp; k++){	
												
												tempMap 		= (Map)masterList.get(k);
												strExpandID		= (String)(tempMap).get(DomainConstants.SELECT_ID);
												strObjectType 	= (String)(tempMap).get(DomainConstants.SELECT_TYPE);
												strName 		= (String)(tempMap).get(DomainConstants.SELECT_NAME);
												strRev 			= (String)(tempMap).get(DomainConstants.SELECT_REVISION);
												
												String strSAPChildType 		= (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
											    String strSpecSubChildType 	= (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
											    
											    strMasterComponentQuantity = (String) tmpMap.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);

											    // Modified by Subhajit for Defect 51896 - Starts
                                                strPrimaryQuantity = DomainConstants.EMPTY_STRING;
                                                strPrimaryQuantity = getReshipperQuantityValue(context, dmaster, isReshipperSub, strMasterComponentQuantity, strTopNodeBOMQty, strBUOM, fQtyMultiplier);
                                                // Modified by Subhajit for Defect 51896 - Ends
												if(UIUtil.isNotNullAndNotEmpty(strType) && strType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART))
												{
												  if(!(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSAPChildType)) && !(strNONGCASTYPE.contains(strObjectType)) && !(pgV3Constants.THIRD_PARTY).equals(strSpecSubChildType))  
												   {
														
														(tempMap).put("IntermediateName", strName+"."+strRev);
														(tempMap).put("IntermediateType", strObjectType);
														(tempMap).put("IntermediateLevel", strLevel);
														
														(tempMap).put("IntermediateID", strID);
														(tempMap).put("IsDirectComponent", "true");
														 mlFlatBOM.add(tempMap);
														 
														// Modified by Subhajit for Defect 51896 - Starts
	                                                        strListQty.add(strPrimaryQuantity);
	                                                     // Modified by Subhajit for Defect 51896 - Ends
											       }
												}
												else {
													mlFlatBOM.add(tempMap);
													// Modified by Subhajit for Defect 51896 - Starts
                                                    strListQty.add(strPrimaryQuantity);
                                                    // Modified by Subhajit for Defect 51896 - Ends
													 
												}
												if(UIUtil.isNotNullAndNotEmpty(strType)&& strType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART))
												{
													// Modified by Subhajit for Defect 51896 - Starts
													StringList substituteIds = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
                                                    StringList substituteSAPTypes = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGSAPTYPE);
                                                    StringList substituteNames = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_NAME);
                                                    StringList substituteTypes = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_TYPE);
                                                    StringList slsubstituteRev = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REVISION);
                                                    StringList slsubstituteCurrent = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_CURRENT);
                                                    StringList slsubstituteRelID = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REL_ID);
                                                    // Modified by Subhajit for Defect 51896 - Ends
                                                    
                                                    //Modified START_EFFECTIVITY to EFFECTIVITY_DATE
                                                    
                                                    // Modified by Subhajit for Defect 51896 - Starts
                                                    StringList slSubstituteEffectivityDate = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_EFFECTIVITY_DATE);
                                                    StringList slSubstituteValidUntilDate = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
                                                    StringList slSubstituteOptComponent = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
                                                    StringList slSubstituteComment = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_COMMENT);
                                                    StringList slSubSpecSubType = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
                                                    // Modified by Subhajit for Defect 51896 - Ends
													
													//Include the Alternates of Component
													if (!(strDONOTINCLUDETYPE.contains(strType))) {
														
														// Modified by Subhajit for Defect 51896 - Starts
                                                        StringList slAlternateIds = getStringListFromMap(tempMap, pgV3Constants.SELECT_ALTERNATE_ID);
                                                        // Modified by Subhajit for Defect 51896 - Ends

														for (Object oAlternateId : slAlternateIds) {

															dobjAlternate 	= DomainObject.newInstance(context, (String) oAlternateId);
															Map mpAlternate = dobjAlternate.getInfo(context,SL_OBJECT_INFO_SELECT);
															
															if(!pgV3Constants.THIRD_PARTY.equalsIgnoreCase((String) mpAlternate.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE))){
															
															(mpAlternate).put(DomainConstants.SELECT_RELATIONSHIP_ID,(String) tempMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
															(mpAlternate).put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
															(mpAlternate).put("IntermediateName", strName+"."+strRev);
															(mpAlternate).put("IntermediateID", strID);
															(mpAlternate).put("IntermediateType", strObjectType);
															(mpAlternate).put("IntermediateLevel", strLevel);
															mlFlatBOM.add(mpAlternate);
															// Modified by Subhajit for Defect 51896 - Starts
                                                            strListQty.add(strPrimaryQuantity);
                                                            // Modified by Subhajit for Defect 51896 - Ends
															}
														}

													}
						
													if (null != substituteIds && substituteIds.size() > 0) {

														int iSizeOfSubstitutes = substituteIds.size();

														for (int iSub = 0; iSub < iSizeOfSubstitutes; iSub++) {
															//Add Fabricated Part as SAP BOM Component
															String strSubstitutepgSAPType=(String)substituteSAPTypes.get(iSub);
															if (!(strDONOTINCLUDETYPE.contains((String)substituteTypes.get(iSub))) && !(pgV3Constants.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))) {
																mapTemp = new HashMap();
																
																strSubstituteId = (String)substituteIds.get(iSub);
																strSubstituteType = (String)substituteTypes.get(iSub);
																
																mapTemp.put("name", (String)substituteNames.get(iSub));
																mapTemp.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
																mapTemp.put("relationship", pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE);
																//mapTemp.put(DomainConstants.SELECT_ID, (String)substituteIds.get(iSub));
																mapTemp.put(DomainConstants.SELECT_ID, strSubstituteId);
																//mapTemp.put(DomainConstants.SELECT_TYPE, (String)substituteTypes.get(iSub));
																mapTemp.put(DomainConstants.SELECT_TYPE, strSubstituteType);
																
																mapTemp.put("IntermediateName", strName+"."+strRev);
																mapTemp.put("IntermediateID", strID);
																mapTemp.put("IntermediateType", strObjectType);
																mapTemp.put(DomainConstants.SELECT_REVISION, (String)slsubstituteRev.get(iSub));
																mapTemp.put(DomainConstants.SELECT_CURRENT, (String)slsubstituteCurrent.get(iSub));
																mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE, (String)slSubstituteEffectivityDate.get(iSub));
																
																mapTemp.put(pgV3Constants.ATTRIBUTE_PGVALIDUNTILDATE, (String)slSubstituteValidUntilDate.get(iSub));
															
																mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT, (String)slSubstituteOptComponent.get(iSub));
																mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_COMMENT, (String)slSubstituteComment.get(iSub));
																mapTemp.put("IntermediateLevel", strLevel);
																mlFlatBOM.add(mapTemp);
																// Modified by Subhajit for Defect 51896 - Starts
                                                                strPrimaryQuantity = DomainConstants.EMPTY_STRING;
                                                                String strChildSubQuantity = (String) mapTemp.get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
                                                                strPrimaryQuantity = getReshipperQuantityValue(context, dmaster, isReshipperSub, strChildSubQuantity, strTopNodeBOMQty, strBUOM, fQtyMultiplier);
                                                                strListQty.add(strPrimaryQuantity);
                                                                // Modified by Subhajit for Defect 51896 - Ends
																
																if(UIUtil.isNotNullAndNotEmpty(strSubstituteType) && ALTERNATE_ALLOWED_TYPES.contains(strSubstituteType)){
																	mlSubAlts= getAlternates(context, strSubstituteId);
																	iAltsSize = mlSubAlts.size();
																	for(int j=0;j<iAltsSize;j++){
																		mpAltMap = (Map) mlSubAlts.get(j);
																		
																		strExpandFABSubsAltSpecSubType = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
																		if(!strExpandFABSubsAltSpecSubType.equalsIgnoreCase(pgV3Constants.THIRD_PARTY)) {
																		
																			mpAltMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
																			mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
																			mpAltMap.put("IntermediateName", strName+"."+strRev);
																			mpAltMap.put("IntermediateID", strID);
																			mpAltMap.put("IntermediateType", strObjectType);
																			mpAltMap.put("IntermediateLevel", strLevel);
																			mlFlatBOM.add(mpAltMap);
																			// Modified by Subhajit for Defect 51896 - Starts
                                                                            strListQty.add(strPrimaryQuantity);
                                                                            // Modified by Subhajit for Defect 51896 - Ends
                                                                        
																		}
																	}
																}
																							
															} 
															
															/*else {
																slSubIntermediate.addElement((String)substituteIds.get(iSub));
															}*/
															
														}
													}		
												}				
											}
											
										}
												
											
										if(UIUtil.isNotNullAndNotEmpty(strType) && !(strType.contains(pgV3Constants.TYPE_MASTER)) && !(strType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART) && bExpandFAB))
										{
											// Modified by Subhajit for Defect 51896 - Starts
                                            mlFlatBOM.add(tmpMap);
                                            strListQty.add(strPrimaryQuantity);
                                            // Modified by Subhajit for Defect 51896 - Ends
										}
											
									}
									//Check if there is substitute
									//Find substitute for child object	
																	
									//Skip primary FAB and its Substitutes if "Expand BOM on SAP BOM as Fed" is set to Yes
									
									if (UIUtil.isNotNullAndNotEmpty(strType) && !(strType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART) && bExpandFAB))
									{
										// Modified by Subhajit for Defect 51896 - Starts
                                        StringList substituteIds = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
                                        StringList substituteSAPTypes = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGSAPTYPE);
                                        StringList substituteNames = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_NAME);
                                        StringList substituteTypes = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_TYPE);
                                        StringList slsubstituteRev = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REVISION);
                                        StringList slsubstituteCurrent = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_CURRENT);
                                        StringList slsubstituteRelID = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REL_ID);
                                        // Modified by Subhajit for Defect 51896 - Ends
                                        
                                        
                                        StringList slSubstituteEffectivityDate = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_EFFECTIVITY_DATE);
                                        
                                        StringList slSubstituteValidUntilDate = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
                                        
                                        StringList slSubstituteOptComponent = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
                                        StringList slSubstituteComment = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_COMMENT);
                                        // Modified by Subhajit for Defect 51896 - Starts
										StringList slsubstituteQuantity = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
										
                                        StringList slSubSpecSubType = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
                                        // Modified by Subhajit for Defect 51896 - Ends
						
									//Include the Alternates of Component
									if (!(strDONOTINCLUDETYPE.contains(strType))) {
										// Modified by Subhajit for Defect 51896 - Starts
                                        StringList slAlternateIds = getStringListFromMap(tmpMap, pgV3Constants.SELECT_ALTERNATE_ID);
                                        // Modified by Subhajit for Defect 51896 - Ends

										for (Object oAlternateId : slAlternateIds) {

											dobjAlternate 	= DomainObject.newInstance(context, (String) oAlternateId);
											Map mpAlternate = dobjAlternate.getInfo(context,SL_OBJECT_INFO_SELECT);
											if(!pgV3Constants.THIRD_PARTY.equals((String) mpAlternate.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE))){
											(mpAlternate).put(DomainConstants.SELECT_RELATIONSHIP_ID,(String) tmpMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
											(mpAlternate).put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
											(mpAlternate).put("IntermediateName", strName+"."+strRev);
											(mpAlternate).put("IntermediateID", strID);
											(mpAlternate).put("IntermediateType", strObjectType);
											(mpAlternate).put("IntermediateLevel", strLevel);
											mlFlatBOM.add(mpAlternate);
											// Modified by Subhajit for Defect 51896 - Starts
                                            strListQty.add(strPrimaryQuantity);
                                            // Modified by Subhajit for Defect 51896 - Ends
											}
										}

									}
									
									if (null != substituteIds && substituteIds.size() > 0) {

										int iSizeOfSubstitutes = substituteIds.size();

										for (int iSub = 0; iSub < iSizeOfSubstitutes; iSub++) {
											//Add Fabricated Part as SAP BOM Component
											String strSubstitutepgSAPType=(String)substituteSAPTypes.get(iSub);
											
											if (!(pgV3Constants.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))) {
												mapTemp = new HashMap();
												strSubstituteId = (String)substituteIds.get(iSub);
												strSubstituteType = (String)substituteTypes.get(iSub);
												
												mapTemp.put("name", (String)substituteNames.get(iSub));
												mapTemp.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
												mapTemp.put("relationship", pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE);
												//mapTemp.put(DomainConstants.SELECT_ID, (String)substituteIds.get(iSub));
												mapTemp.put(DomainConstants.SELECT_ID, strSubstituteId);
												//mapTemp.put(DomainConstants.SELECT_TYPE, (String)substituteTypes.get(iSub));
												mapTemp.put(DomainConstants.SELECT_TYPE, strSubstituteType);
												mapTemp.put("IntermediateName", strName+"."+strRev);
												mapTemp.put("IntermediateID", strID);
												mapTemp.put("IntermediateType", strObjectType);
												mapTemp.put(DomainConstants.SELECT_REVISION, (String)slsubstituteRev.get(iSub));
												mapTemp.put(DomainConstants.SELECT_CURRENT, (String)slsubstituteCurrent.get(iSub));
												mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE, (String)slSubstituteEffectivityDate.get(iSub));
												
												mapTemp.put(pgV3Constants.ATTRIBUTE_PGVALIDUNTILDATE, (String)slSubstituteValidUntilDate.get(iSub));
																							
												mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT, (String)slSubstituteOptComponent.get(iSub));
												mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_COMMENT, (String)slSubstituteComment.get(iSub));
												mapTemp.put("IntermediateLevel", strLevel);
												// Modified by Subhajit for Defect 51896 - Starts
												//mapTemp.put(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY, slsubstituteQuantity.get(iSub)); //raj.kr.1 - commented for error
												// Modified by Subhajit for Defect 51896 - Ends
											
											
											if ((pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strSubstituteType)) && UIUtil.isNotNullAndNotEmpty(slSubSpecSubType.get(iSub)) && (pgV3Constants.BULK_INTERMEDIATE_UNIT.equalsIgnoreCase(slSubSpecSubType.get(iSub)))) {
												mlFlatBOM.addAll(getFPPObjectsForCOPBulk(context,mapTemp));
											}
											
																						
											if (!(strDONOTINCLUDETYPE.contains((String)substituteTypes.get(iSub))) && !(pgV3Constants.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))) {
												
												mlFlatBOM.add(mapTemp);
												// Modified by Subhajit for Defect 51896 - Starts
                                                strPrimaryQuantity = DomainConstants.EMPTY_STRING;
                                                String strChildSubQuantity = (String) mapTemp.get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
												strPrimaryQuantity = getReshipperQuantityValue(context, dObjIntermediate, isReshipperSub, strChildSubQuantity, strTopNodeBOMQty, strBUOM, fQtyMultiplier);
                                                strListQty.add(strPrimaryQuantity);
                                                // Modified by Subhajit for Defect 51896 - Ends
                                                
												
												if(UIUtil.isNotNullAndNotEmpty(strSubstituteType) && ALTERNATE_ALLOWED_TYPES.contains(strSubstituteType)){
													mlSubAlts= getAlternates(context, strSubstituteId);
													iAltsSize = mlSubAlts.size();
													for(int j=0;j<iAltsSize;j++){
														mpAltMap = (Map) mlSubAlts.get(j);
														
														String strFPPSubsAltSpecSubType = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
														if(!strFPPSubsAltSpecSubType.equalsIgnoreCase(pgV3Constants.THIRD_PARTY)) {
															mpAltMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
															mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
															mpAltMap.put("IntermediateName", strName+"."+strRev);
															mpAltMap.put("IntermediateID", strID);
															mpAltMap.put("IntermediateType", strObjectType);
															mpAltMap.put("IntermediateLevel", strLevel);
															mlFlatBOM.add(mpAltMap);
															// Modified by Subhajit for Defect 51896 - Starts
                                                            strListQty.add(strPrimaryQuantity);
                                                            // Modified by Subhajit for Defect 51896 - Ends
                                                       
														}
														
													}
												}
																			
											} 
											// Modified by Subhajit for Defect 51896 - Starts
											/*else {
												slSubIntermediate.addElement((String)substituteIds.get(iSub));
											} */
											// Modified by Subhajit for Defect 51896 - Ends
											}
										}
									}
									
								}
							}
							}
							}
						}
					
					}
					
					
					// Now we have stringlist which contains substitutes of type intermediate
					//Expand strlinglist for Sub intermediate objects and get the data.
					// These are for substitute data processing when its an intermediate type of part
					if (null != slSubIntermediate && slSubIntermediate.size() > 0) {	
						// Modified by Subhajit for Defect 51896 - Starts
	                    strPrimaryQuantity = DomainConstants.EMPTY_STRING;
	                    // Modified by Subhajit for Defect 51896 - Ends

						int iSizeOfSubInterm = slSubIntermediate.size();
						float fQtyMultiplier = 0;
						for (int iSubInter=0; iSubInter < iSizeOfSubInterm; iSubInter++) {

							strInterID = (String)slSubIntermediate.get(iSubInter);
							dObjInter = DomainObject.newInstance(context, strInterID);
							
							
							
							//Now, expand substitute intermediate object and get the connected data
							
							mlSubInterFirstLevelData = dObjInter.getRelatedObjects(context,
							//mlSubInterFirstLevelData = dObjIntermediate.getRelatedObjects(context,
							
									pgV3Constants.RELATIONSHIP_EBOM, 	// rel pattern
									//pgV3Constants.SYMBOL_STAR,     		// type pattern
									DomainConstants.QUERY_WILDCARD,		// type pattern
									SL_OBJECT_INFO_SELECT,         		// object select
									SL_RELATION_INFO_SELECT_EBOM,    	// rel select
									false,                  			// to side
									true,                   			// from side 
									(short)ConstantsUtilIRM.FIRST_LVL,               			// recursion level
									objectWhere,            			// object where clause
									"",0);                    			// rel where clause

							if (null != mlSubInterFirstLevelData && mlSubInterFirstLevelData.size() > 0) {

								mlSubInterFirstLevelData.sort(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");

								int iSizeOfSubInterFirstLevel = mlSubInterFirstLevelData.size();

								for(int iCount=0;iCount<iSizeOfSubInterFirstLevel;iCount++) {

									tempMap = (Map)mlSubInterFirstLevelData.get(iCount);
									strType = (String)(tempMap).get(DomainConstants.SELECT_TYPE);
									strLevel = (String)(tempMap).get(DomainConstants.SELECT_LEVEL);
									strChildQuantity	= (String)tempMap.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
									strInterSpecSubType = (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
									String strPrimarySAPType = (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
									(tempMap).put("IntermediateLevel", strLevel);
									(tempMap).put("IsDirectComponent", "true");
									//Add Fabricated Part as BOM Component
									strInterSpecSubType = (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				
									//Modified by Subhajit for the Defect 52840
									if(!(strDONOTINCLUDETYPE.contains(strType)) && !pgV3Constants.THIRD_PARTY.equals(strInterSpecSubType) && isReshipperSub) {
										mlFlatBOM.add(tempMap);
										
										//if (!(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strPrimarySAPType))) {
											
										// Modified by Subhajit for Defect 51896 - Starts
	                                    strPrimaryQuantity = DomainConstants.EMPTY_STRING;
	                                    // Modified by Subhajit for Defect 51896 - Ends
										 strPrimaryQuantity =getReshipperQuantityValue(context,dObjInter,isReshipperSub,strChildQuantity,strTopNodeBOMQty,strBUOM,fQtyMultiplier);
											//String strPrimaryQuantity =getReshipperQuantityValue(context,dObjIntermediate,isReshipperSub,strChildQuantity,strTopNodeBOMQty,strBUOM,fQtyMultiplier);
											
											strListQty.add(strPrimaryQuantity);						
											
											
										// CUP Reshipper Primary Alternate
										if (!strDONOTINCLUDETYPE.contains(strType)) {
											oReshipperPrimaryAlternateIds 		= (Object) (tempMap).get(pgV3Constants.SELECT_ALTERNATE_ID);
											StringList slAlternateIds 	= new StringList();
											Map mpAlternate  = null;
											if (null != oReshipperPrimaryAlternateIds) {
												slAlternateIds = getInstanceList(oReshipperPrimaryAlternateIds);
											}
											for(Object oAlternateId : slAlternateIds) {
												dobjAlternate = DomainObject.newInstance(context, (String) oAlternateId);
												mpAlternate = dobjAlternate.getInfo(context,SL_OBJECT_INFO_SELECT);
												strPriAlternateCUPSpecSubType = (String) mpAlternate.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
												(mpAlternate).put(DomainConstants.SELECT_RELATIONSHIP_ID,(String) tempMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
												(mpAlternate).put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
												(mpAlternate).put("level", strLevel);
												(mpAlternate).put("IntermediateName", strName+"."+strRev);
												(mpAlternate).put("IntermediateID", strID);
												(mpAlternate).put("IntermediateType", strObjectType);
												(mpAlternate).put("IntermediateLevel", strLevel);
												if (!(pgV3Constants.THIRD_PARTY.equals(strPriAlternateCUPSpecSubType))) {
													mlFlatBOM.add(mpAlternate);
													strListQty.add(strPrimaryQuantity);
												}
											}
										}	
										
										
										//}
										
										/*if(isReshipperSub && !(pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM))){										
											strChildQuantity	= (String)tempMap.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
											if(UIUtil.isNotNullAndNotEmpty(strTopNodeBOMQty) && UIUtil.isNotNullAndNotEmpty(strChildQuantity))
													{
											fChildSAPQty = (Float.valueOf(strTopNodeBOMQty)).floatValue() * (Float.valueOf(strChildQuantity)).floatValue();
											strListQty.add(String.valueOf(fChildSAPQty));
											}*/	
										if(isReshipperSub) {//raj.kr.1 - change needed may be
											// Modified by Subhajit for Defect 51896 - Starts
	                                        StringList substituteIds = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
	                                        StringList substituteSAPTypes = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGSAPTYPE);
	                                        StringList substituteNames = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_NAME);
	                                        StringList substituteTypes = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_TYPE);
	                                        StringList slsubstituteRev = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REVISION);
	                                        StringList slsubstituteCurrent = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_CURRENT);
	                                        StringList slsubstituteRelID = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REL_ID);
	                                        // Modified by Subhajit for Defect 51896 - Ends
	                                        
	                                     // Modified by Subhajit for Defect 51896 - Starts
	                                        StringList slSubstituteEffectivityDate = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_EFFECTIVITY_DATE);
	                                        StringList slSubstituteValidUntilDate = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
	                                        StringList slSubstituteOptComponent = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
	                                        StringList slSubstituteComment = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_COMMENT);
	                                        StringList slSubSpecSubType = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
	                                        StringList slsubstituteQuantity = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
	                                     // Modified by Subhajit for Defect 51896 - Ends
											
											
											if (null != substituteIds && substituteIds.size() > 0) {

												int iSizeOfSubstitutes = substituteIds.size();
												for (int iSub = 0; iSub < iSizeOfSubstitutes; iSub++) {
													String strSubstitutepgSAPType=(String)substituteSAPTypes.get(iSub);
													
													if (!(pgV3Constants.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))) {
													
													
														mapTemp = new HashMap();
														strSubstituteId = (String)substituteIds.get(iSub);
														strSubstituteType = (String)substituteTypes.get(iSub);
														
														mapTemp.put("name", (String)substituteNames.get(iSub));
														mapTemp.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
														mapTemp.put("relationship", pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE);
														mapTemp.put(DomainConstants.SELECT_ID, strSubstituteId);									
														mapTemp.put(DomainConstants.SELECT_TYPE, strSubstituteType);
														mapTemp.put("IntermediateName", strName+"."+strRev);
														mapTemp.put("IntermediateID", strID);
														mapTemp.put("IntermediateType", strObjectType);
														mapTemp.put(DomainConstants.SELECT_REVISION, (String)slsubstituteRev.get(iSub));
														mapTemp.put(DomainConstants.SELECT_CURRENT, (String)slsubstituteCurrent.get(iSub));
														mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE, (String)slSubstituteEffectivityDate.get(iSub));
														mapTemp.put(pgV3Constants.ATTRIBUTE_PGVALIDUNTILDATE, (String)slSubstituteValidUntilDate.get(iSub));
														mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT, (String)slSubstituteOptComponent.get(iSub));
														mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_COMMENT, (String)slSubstituteComment.get(iSub));
														mapTemp.put(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY,(String)slsubstituteQuantity.get(iSub));
														mapTemp.put("IntermediateLevel", strLevel);
														
														
														if ((pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strSubstituteType)) && UIUtil.isNotNullAndNotEmpty(slSubSpecSubType.get(iSub)) && (pgV3Constants.BULK_INTERMEDIATE_UNIT.equalsIgnoreCase(slSubSpecSubType.get(iSub)))) {
														
															MapList mlCUPComponents = getFPPObjectsForCOPBulk(context,mapTemp);
															Map mapCUPComponents=null;
															
															int mlCUPComponentsSize = mlCUPComponents.size();
															
															for(int jj=0;jj<mlCUPComponentsSize;jj++){
																mapCUPComponents = (Map) mlCUPComponents.get(jj);
																if(mapCUPComponents!=null && !mapCUPComponents.isEmpty()) {
																	String strsubsCUPPFPPQuantity = getReshipperQuantityValue(context,dObjInter,isReshipperSub,(String) mapCUPComponents.get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY),strTopNodeBOMQty,strBUOM,fQtyMultiplier);
																			
																	mlFlatBOM.add(mapCUPComponents);
																	strListQty.add(strsubsCUPPFPPQuantity);
																}
															}
														}
																					
														
														if (!(strDONOTINCLUDETYPE.contains((String)substituteTypes.get(iSub))) && !(pgV3Constants.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))) {	
															
															mlFlatBOM.add(mapTemp);
															
															String strChildSubQuantity = (String) mapTemp.get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
															
															strsubsCUPQuantity=getReshipperQuantityValue(context,dObjInter,isReshipperSub,strChildSubQuantity,strTopNodeBOMQty,strBUOM,fQtyMultiplier);
														
															
															strListQty.add(strsubsCUPQuantity);
															
															if(UIUtil.isNotNullAndNotEmpty(strSubstituteType) && ALTERNATE_ALLOWED_TYPES.contains(strSubstituteType)) {
																mlSubAlts= getAlternates(context, strSubstituteId);
																iAltsSize = mlSubAlts.size();
																if(null != mlSubAlts && iAltsSize > 0) {
																	for(int j=0;j<iAltsSize;j++){
																		mpAltMap = (Map) mlSubAlts.get(j);
																		strAlternateCUPSpecSubType = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
																		strAlternateCUPSAPType = (String)mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
																		mpAltMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
																		mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
																		mpAltMap.put("IntermediateName", strName+"."+strRev);
																		mpAltMap.put("IntermediateID", strID);
																		mpAltMap.put("IntermediateType", strObjectType);
																		mpAltMap.put("IntermediateLevel", strLevel);
																		if(!strAlternateCUPSpecSubType.contains(pgV3Constants.THIRD_PARTY) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strAlternateCUPSAPType))) {
																			mlFlatBOM.add(mpAltMap);
																			strChildCUPAltQuantity = strsubsCUPQuantity;
																			strListQty.add(strChildCUPAltQuantity);
																		}
																	}
																}
															}
																	
														} else {
															slSubIntermediate.addElement((String)substituteIds.get(iSub));
														}
													}
													
												}
			
											}	
												
										}
									}
								}
							
							}
							
							mlIntermediateChildData = dObjInter.getRelatedObjects(context,
									pgV3Constants.RELATIONSHIP_EBOM,   // rel pattern
									pIntermediateObjectType.getPattern(),  // type pattern
									SL_OBJECT_INFO_SELECT,             // object selects
									SL_RELATION_INFO_SELECT_EBOM,           //  rel selects 
									false,                             // to side
									true,                              // from side
									(short)ConstantsUtil.ZERO_LEVEL,                          //  recursion level
									objectWhere,                       // object where clause
									null,0);                             //  rel where clause
							fQtyMultiplier = 1;
							String strTemplevel = DomainConstants.EMPTY_STRING;
							
							//Get first level child for CUP, COP and IP
							if (null != mlIntermediateChildData && mlIntermediateChildData.size() > 0) {
								//mlIntermediateChildData.sort(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");

								// Modified by Subhajit for Defect 51896 - Starts
	                            ISAPBOM reshipperBOM = new SAPReshipperBOM();
	                            mlIntermediateChildData = reshipperBOM.getBOMInfoList(context, strInterID, mlIntermediateChildData);
	                            boolean isSelfComplexBOM;
	                            boolean isParentComplexBOM;
	                            processIdLevel = 0;
	                         // Modified by Subhajit for Defect 51896 - Ends

								int iSizeOfInterChild = mlIntermediateChildData.size();								
								Map mpPreviousLevelSubstituteType = new HashMap();

								for (int i=0;i<iSizeOfInterChild;i++) {

									tempMap 		= (Map)mlIntermediateChildData.get(i);
									strID 			= (String)(tempMap).get(DomainConstants.SELECT_ID);
									strObjectType 	= (String)(tempMap).get(DomainConstants.SELECT_TYPE);
									strLevel 		= (String)(tempMap).get(DomainConstants.SELECT_LEVEL);
									
									strSpecSubType    = (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
									
									mpPreviousLevelSubstituteType.put(parseValue(strLevel),strObjectType);
									// Modified by Subhajit for Defect 51896 - Starts
	                                isSelfComplexBOM = false;
	                                if(tempMap.containsKey(keyIsComplexBOM)) {
	                                    isSelfComplexBOM = (Boolean) (tempMap).get(keyIsComplexBOM);
	                                }
	                                
	                                if (processIdLevel != 0 && processIdLevel != parseValue(strLevel)) {
	                                    continue;
	                                } else if (processIdLevel == parseValue(strLevel)) {
	                                    processIdLevel = 0;
	                                }
	                             // Modified by Subhajit for Defect 51896 - Ends
									
	                                if (pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strObjectType)
	                                        || (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType)
	                                        && parseValue(strLevel) > 1)) {
											String strPreviousTypeToScndLevelCOPSubstitute = (String)mpPreviousLevelSubstituteType.get(parseValue(strLevel)-1);
											String strPreviousTypeToThirdLevelSubsctituteCOP = (String)mpPreviousLevelSubstituteType.get(parseValue(strLevel)-2);
											boolean isThirdLevelCOP = pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToScndLevelCOPSubstitute);
											boolean isCOPSpecialCase = isThirdLevelCOP
													&& !pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToThirdLevelSubsctituteCOP);
											if ((isSelfComplexBOM && !isThirdLevelCOP) || isCOPSpecialCase) {
		                                        
											for(int j=iSizeOfInterChild - 1;j>0;j--){
												mpChildMap = (Map)mlIntermediateChildData.get(j-1);
												strIntermediateLevel 			= (String)(mpChildMap).get(DomainConstants.SELECT_LEVEL);
												if(parseValue(strIntermediateLevel) < parseValue(strLevel))
												{
													strIntermediateObjectQty = (String)(mpChildMap).get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
													bdIntermediateObjectQty = bdIntermediateObjectQty.multiply(new BigDecimal(strIntermediateObjectQty));
												}
											}								
																		
											strCOPToCOPQuantity 	= (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
											// Modified by Subhajit for Defect 51896 - Starts
	                                        slCOPSubstituteIds = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
	                                        slCOPSubstituteQuantities = getStringListFromMap(tempMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
	                                     // Modified by Subhajit for Defect 51896 - Ends
											
											mpConnectedFPPToChildCOP = getFPPObjectsForChildCOPInCOP(context,strID,strCOPToCOPQuantity,IPSId,slCOPSubstituteIds,strTopNodeBOMQty,bdIntermediateObjectQty, strBUOM,strTopNodeSpecSubType,strSpecSubType,slCOPSubstituteQuantities);
											
											bdIntermediateObjectQty = new BigDecimal("1");
											mlChildCOPConnectedFPP = (MapList)mpConnectedFPPToChildCOP.get("mlReleasedFPP");
											slChildCOPConnectedFPPQTY = (StringList)mpConnectedFPPToChildCOP.get("strListQtyValues");
											//Modified by Subhajit for Defect 52840 - Start
											if(!mlChildCOPConnectedFPP.isEmpty() && !slChildCOPConnectedFPPQTY.isEmpty())
											{
												mlReleasedFPP.addAll(mlChildCOPConnectedFPP);
												slReleaseFPPQTY.addAll(slChildCOPConnectedFPPQTY);
											}
											//Modified by Subhajit for Defect 52840 - End
											// Modified by Subhajit for Defect 51896 - Starts
	                                        //Stop to get GCAS Component
	                                        // if Child Part has where used FPP stop Traverse to the BOM
	                                        if (!mlChildCOPConnectedFPP.isEmpty() && isSelfComplexBOM) {
	                                            processIdLevel = Integer.parseInt(strLevel);
	                                            continue;
	                                        } else {
	                                            // if where-used is not found - then continue.
	                                            if (isSelfComplexBOM) {
							                        processIdLevel = Integer.parseInt(strLevel);
	                                                continue;
	                                            }
	                                        }
	                                        if (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType)) {
	                                        	// Modified by Subhajit for Defect 51896 - Ends
	                                            continue;
	                                        }


	                                    } else if (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToScndLevelCOPSubstitute)) {
	                                        continue;
										}
									}
									strInterSpecSubType = (String)(tempMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
									if((pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strObjectType) || pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType)) && pgV3Constants.THIRD_PARTY.equals(strInterSpecSubType)){
										break;
									}
									strName 		= (String)(tempMap).get(DomainConstants.SELECT_NAME);
									strRev 			= (String)(tempMap).get(DomainConstants.SELECT_REVISION);
									strInterMedLevel = (String)(tempMap).get(DomainConstants.SELECT_LEVEL);
									if((!pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strObjectType) || !pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType)) && strInterMedLevel.equals("1")){
										fQtyMultiplier = 1;
									}
									String strInterQuantity	= (String)tempMap.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
									if(!strTemplevel.equals(strInterMedLevel) && UIUtil.isNotNullAndNotEmpty(strInterQuantity)){
										//fQtyMultiplier = fQtyMultiplier * (Float.valueOf(strInterQuantity)).floatValue();
										
										BigDecimal bdQtyMultiplier = BigDecimal.valueOf(fQtyMultiplier);
										bdQtyMultiplier = bdQtyMultiplier.multiply(new BigDecimal(strInterQuantity)); 
										fQtyMultiplier = bdQtyMultiplier.floatValue();
										
										strTemplevel = strInterMedLevel;
									}
												
									dObjIntermediate= DomainObject.newInstance(context, strID);
									
									mlConnectedInterChildData = dObjIntermediate.getRelatedObjects(context,
									
									//mlConnectedInterChildData = dObjInter.getRelatedObjects(context,
									
											pgV3Constants.RELATIONSHIP_EBOM,// rel pattern
											//pgV3Constants.SYMBOL_STAR,     	// type pattern
											DomainConstants.QUERY_WILDCARD, // type pattern
											SL_OBJECT_INFO_SELECT,         	// object select
											SL_RELATION_INFO_SELECT_EBOM,  	// rel select
											false,                  		// to side
											true,                   		// from side 
											(short)ConstantsUtilIRM.FIRST_LVL,               		// recursion level
											objectWhere,            		// object where clause
											DomainConstants.EMPTY_STRING,0);// rel where clause

									if (null != mlConnectedInterChildData && mlConnectedInterChildData.size() > 0) {

										mlConnectedInterChildData.sort(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");
										strType = DomainConstants.EMPTY_STRING;

										for(int iCount=0;iCount<mlConnectedInterChildData.size();iCount++) {

											tmpMap 	= (Map)mlConnectedInterChildData.get(iCount);
											strType = (String)(tmpMap).get(DomainConstants.SELECT_TYPE);
											strInterSpecSubType = (String)(tmpMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
											strChildQuantity = (String)(tmpMap).get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
											String strPrimarySAPType = (String)(tmpMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
											//Modified by Subhajit for Defect 52840
											if(!(strDONOTINCLUDETYPE.contains(strType)) && !pgV3Constants.THIRD_PARTY.equals(strInterSpecSubType) && isReshipperSub) {
												(tmpMap).put("IntermediateName", strName+"."+strRev);
												(tmpMap).put("IntermediateID", strID);
												(tmpMap).put("IntermediateType", strObjectType);
												(tmpMap).put("IsDirectComponent", "true");
												
												if(isReshipperSub && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM) || (UIUtil.isNotNullAndNotEmpty(strTopNodeSpecSubType) && pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strTopNodeSpecSubType)))) 
												
												{
													int iLevel = Integer.parseInt(strLevel);
													iLevel++;
													(tmpMap).put("IntermediateLevel", String.valueOf(iLevel));
												}else{
													(tmpMap).put("IntermediateLevel", strLevel);
												}
												
												//if (!(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strPrimarySAPType))) {
												// Modified by Subhajit for Defect 51896 - Starts
	                                            strPrimaryQuantity = DomainConstants.EMPTY_STRING;
	                                            // Modified by Subhajit for Defect 51896 - Ends
												 strPrimaryQuantity = getReshipperQuantityValue(context,dObjIntermediate,isReshipperSub,strChildQuantity,strTopNodeBOMQty,strBUOM,fQtyMultiplier);
													//String strPrimaryQuantity = getReshipperQuantityValue(context,dObjInter,isReshipperSub,strChildQuantity,strTopNodeBOMQty,strBUOM,fQtyMultiplier);
													
													strListQty.add(strPrimaryQuantity);
												//}
												
												/*if(isReshipperSub && !(pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM))){	
													strChildQuantity	= (String)tmpMap.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
													if(UIUtil.isNotNullAndNotEmpty(strTopNodeBOMQty) && UIUtil.isNotNullAndNotEmpty(strChildQuantity))
													{
													fChildSAPQty = (Float.valueOf(strTopNodeBOMQty)).floatValue() * fQtyMultiplier * (Float.valueOf(strChildQuantity)).floatValue();
													strListQty.add(String.valueOf(fChildSAPQty));
													}
												}*/
												mlFlatBOM.add(tmpMap);
									
												
												// CUP Reshipper Primary Alternate
												if (!strDONOTINCLUDETYPE.contains(strType)) {
													oReshipperPrimaryAlternateIds 		= (Object) (tmpMap).get(pgV3Constants.SELECT_ALTERNATE_ID);
													StringList slAlternateIds 	= new StringList();
													Map mpAlternate  = null;
													if (null != oReshipperPrimaryAlternateIds) {
														slAlternateIds = getInstanceList(oReshipperPrimaryAlternateIds);
													}
													for(Object oAlternateId : slAlternateIds) {
														dobjAlternate = DomainObject.newInstance(context, (String) oAlternateId);
														mpAlternate = dobjAlternate.getInfo(context,SL_OBJECT_INFO_SELECT);
														strPriAlternateCOPSpecSubType = (String) mpAlternate.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
														(mpAlternate).put(DomainConstants.SELECT_RELATIONSHIP_ID,(String) tmpMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
														(mpAlternate).put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
														(mpAlternate).put("level", strLevel);
														(mpAlternate).put("IntermediateName", strName+"."+strRev);
														(mpAlternate).put("IntermediateID", strID);
														(mpAlternate).put("IntermediateType", strObjectType);
														
														if(isReshipperSub && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM) || (UIUtil.isNotNullAndNotEmpty(strTopNodeSpecSubType) && pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strTopNodeSpecSubType))))
														{
															int iLevel = Integer.parseInt(strLevel);
															iLevel++;
															(mpAlternate).put("IntermediateLevel", String.valueOf(iLevel));
														} else {
															(mpAlternate).put("IntermediateLevel", strLevel);
														}
														
														if (!(pgV3Constants.THIRD_PARTY.equals(strPriAlternateCOPSpecSubType))) {
															mlFlatBOM.add(mpAlternate);
															strListQty.add(strPrimaryQuantity);
														}
													}
												}
												
												if (isReshipperSub) {
													// Modified by Subhajit for Defect 51896 - Starts
	                                                StringList substituteIds = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
	                                                StringList substituteSAPTypes = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGSAPTYPE);
	                                                StringList substituteNames = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_NAME);
	                                                StringList substituteTypes = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_TYPE);
	                                                StringList slsubstituteRev = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REVISION);
	                                                StringList slsubstituteCurrent = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_CURRENT);
	                                                StringList slsubstituteRelID = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REL_ID);
	                                                
	                                                StringList slSubstituteEffectivityDate = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_EFFECTIVITY_DATE);
	                                                StringList slSubstituteValidUntilDate = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
	                                                StringList slSubstituteOptComponent = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
	                                                StringList slSubstituteComment = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_COMMENT);
	                                                StringList slSubSpecSubType = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
	                                                StringList slsubstituteQuantity = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
	                                                // Modified by Subhajit for Defect 51896 - Ends
													
													if (null != substituteIds && substituteIds.size() > 0) {

														int iSizeOfSubstitutes = substituteIds.size();

														for (int iSub = 0; iSub < iSizeOfSubstitutes; iSub++) {
															String strSubstitutepgSAPType=(String)substituteSAPTypes.get(iSub);
															
															if (!(pgV3Constants.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))) {
															
															
																mapTemp = new HashMap();
																strSubstituteId = (String)substituteIds.get(iSub);
																strSubstituteType = (String)substituteTypes.get(iSub);
																mapTemp.put("name", (String)substituteNames.get(iSub));
																mapTemp.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
																mapTemp.put("relationship", pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE);
																mapTemp.put(DomainConstants.SELECT_ID, strSubstituteId);									
																mapTemp.put(DomainConstants.SELECT_TYPE, strSubstituteType);
																mapTemp.put("IntermediateName", strName+"."+strRev);
																mapTemp.put("IntermediateID", strID);
																mapTemp.put("IntermediateType", strObjectType);
																mapTemp.put(DomainConstants.SELECT_REVISION, (String)slsubstituteRev.get(iSub));
																mapTemp.put(DomainConstants.SELECT_CURRENT, (String)slsubstituteCurrent.get(iSub));
																mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE, (String)slSubstituteEffectivityDate.get(iSub));
																mapTemp.put(pgV3Constants.ATTRIBUTE_PGVALIDUNTILDATE, (String)slSubstituteValidUntilDate.get(iSub));
																mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT, (String)slSubstituteOptComponent.get(iSub));
																mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_COMMENT, (String)slSubstituteComment.get(iSub));
																mapTemp.put(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY,(String)slsubstituteQuantity.get(iSub));
																
																
																if(isReshipperSub && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM) || (UIUtil.isNotNullAndNotEmpty(strTopNodeSpecSubType) && pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strTopNodeSpecSubType))))
																{
																	int iLevel = Integer.parseInt(strLevel);
																	iLevel++;
																	(mapTemp).put("IntermediateLevel", String.valueOf(iLevel));
																}else{
																	(mapTemp).put("IntermediateLevel", strLevel);
																}
																
																if ((pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strSubstituteType)) && UIUtil.isNotNullAndNotEmpty(slSubSpecSubType.get(iSub)) && (pgV3Constants.BULK_INTERMEDIATE_UNIT.equalsIgnoreCase(slSubSpecSubType.get(iSub)))) {
																
																	MapList mlCOPComponents = getFPPObjectsForCOPBulk(context,mapTemp);
																	Map mapCOPComponents = null;
																	String strsubsCOPFPPQuantity = DomainConstants.EMPTY_STRING;
																	int mlCOPComponentsSize = mlCOPComponents.size();
																
																		for(int jj=0;jj<mlCOPComponentsSize;jj++){
																		
																			mapCOPComponents = (Map) mlCOPComponents.get(jj);
																			 if(mapCOPComponents!=null && !mapCOPComponents.isEmpty()) {
																				strsubsCOPFPPQuantity = getReshipperQuantityValue(context,dObjIntermediate,isReshipperSub,(String) mapCOPComponents.get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY),strTopNodeBOMQty,strBUOM,fQtyMultiplier);
																			
																				mlFlatBOM.add(mapCOPComponents);
																				strListQty.add(strsubsCOPFPPQuantity);
																			}
																		}
																}
															
															if (!(strDONOTINCLUDETYPE.contains((String)substituteTypes.get(iSub))) && !(pgV3Constants.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))) {	
																mlFlatBOM.add(mapTemp);
																
																String strChildSubQuantity = (String) mapTemp.get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
																
																strsubsCOPQuantity = getReshipperQuantityValue(context,dObjIntermediate,isReshipperSub,strChildSubQuantity,strTopNodeBOMQty,strBUOM,fQtyMultiplier);
																//strsubsCOPQuantity = getReshipperQuantityValue(context,dObjInter,isReshipperSub,strChildSubQuantity,strTopNodeBOMQty,strBUOM,fQtyMultiplier);
																
																strListQty.add(strsubsCOPQuantity);
																
																if(UIUtil.isNotNullAndNotEmpty(strSubstituteType) && ALTERNATE_ALLOWED_TYPES.contains(strSubstituteType)) {
																	mlSubAlts= getAlternates(context, strSubstituteId);
																	iAltsSize = mlSubAlts.size();
																	if(null != mlSubAlts && iAltsSize > 0) {
																		for(int j=0;j<iAltsSize;j++){
																			mpAltMap = (Map) mlSubAlts.get(j);
																			strAlternateCOPSpecSubType = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
																			strAlternateCOPSAPType = (String)mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
																			mpAltMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
																			mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
																			mpAltMap.put("IntermediateName", strName+"."+strRev);
																			mpAltMap.put("IntermediateID", strID);
																			mpAltMap.put("IntermediateType", strObjectType);
																			
																			if(isReshipperSub && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM) || (UIUtil.isNotNullAndNotEmpty(strTopNodeSpecSubType) && pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strTopNodeSpecSubType))))
																			{
																				int iLevel = Integer.parseInt(strLevel);
																				iLevel++;
																				(mpAltMap).put("IntermediateLevel", String.valueOf(iLevel));
																			}else{
																				(mpAltMap).put("IntermediateLevel", strLevel);
																			}
																			
																			if(!strAlternateCOPSpecSubType.contains(pgV3Constants.THIRD_PARTY) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strAlternateCOPSAPType))) {
																				mlFlatBOM.add(mpAltMap);
																				strChildCOPAltQuantity = strsubsCOPQuantity;
																				strListQty.add(strChildCOPAltQuantity);
																			}
																		}
																	}
																}
																													
															} else {
																slSubIntermediate.addElement((String)substituteIds.get(iSub));
															}
															}
														}
					
													}
												
												}
												
											}
										}
									}
								}
							}
						}
					}

					//Expand FPP and get first level parts apart from CUP, COP and IP
					MapList mlFPPFirstLevelData = dObjForTopNodePart.getRelatedObjects(context,
							pgV3Constants.RELATIONSHIP_EBOM, 	// rel pattern
							//pgV3Constants.SYMBOL_STAR,         	// type pattern
							DomainConstants.QUERY_WILDCARD,		// type pattern
							SL_OBJECT_INFO_SELECT,         		// object select
							SL_RELATION_INFO_SELECT_EBOM,    	// rel select
							false,                  			// to side
							true,                   			// from side 
							(short)ConstantsUtilIRM.FIRST_LVL,               			// recursion level
							objectWhere,            			// object where clause
							DomainConstants.EMPTY_STRING,0);    // rel where clause

					if (null != mlFPPFirstLevelData && mlFPPFirstLevelData.size() > 0) {

						mlFPPFirstLevelData.sort(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");

						int iSizeOfFirstLevelData = mlFPPFirstLevelData.size();

						for (int iCount=0;iCount<iSizeOfFirstLevelData;iCount++) {

							tmpMap 		= (Map)mlFPPFirstLevelData.get(iCount);
							strType 	= (String)(tmpMap).get(DomainConstants.SELECT_TYPE);
							strLevel 	= (String)(tmpMap).get(DomainConstants.SELECT_LEVEL);
							strPAPChildSpecSubType 	= (String)(tmpMap).get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							
							//COP BULK in Direct Components of PAP
							if(pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strType) && pgV3Constants.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(strTopNodeType) && UIUtil.isNotNullAndNotEmpty(strPAPChildSpecSubType) && pgV3Constants.BULK_INTERMEDIATE_UNIT.equalsIgnoreCase(strPAPChildSpecSubType)) {
								(tmpMap).put("IsDirectComponent", "true");
								mlPAPCOPBulk = getFPPObjectsForCOPBulk(context,tmpMap);
									
								if(!mlPAPCOPBulk.isEmpty()) { 
									mlFlatBOM.addAll(mlPAPCOPBulk);
								}
							}
							
							if(!(strDONOTINCLUDETYPE.contains(strType)) && !pgV3Constants.THIRD_PARTY.equals(strPAPChildSpecSubType)) {
								(tmpMap).put("IsDirectComponent", "true");

								//If BOM contain master then no object will be displayed on SAP BOM as Fed 
								if (strType.contains(pgV3Constants.TYPE_MASTER)) {

									return (new MapList());
								}
								mlFlatBOM.add(tmpMap);
							}
							if((!pgV3Constants.THIRD_PARTY.equals(strPAPChildSpecSubType) && !(strDONOTINCLUDETYPE.contains(strType))) || (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strType) && (pgV3Constants.BULK_INTERMEDIATE_UNIT.equals(strPAPChildSpecSubType)) && !mlPAPCOPBulk.isEmpty())) {
								//Check if there is substitute
								// Modified by Subhajit for Defect 51896 - Starts
	                            StringList substituteIds = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
	                            StringList substituteSAPTypes = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGSAPTYPE);
	                            StringList substituteNames = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_NAME);
	                            StringList substituteTypes = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_TYPE);
	                            StringList substituteRevs = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REVISION);
	                            StringList slsubstituteCurrent = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_CURRENT);
	                            StringList slsubstituteRelID = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_REL_ID);
	                            
	                            StringList slSubstituteEffectivityDate = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_EFFECTIVITY_DATE);
	                            
	                            StringList slSubstituteValidUntilDate = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
	                            StringList slSubstituteOptComponent = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
	                            StringList slSubstituteComment = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_COMMENT);
	                            StringList slSubSpecSubType = getStringListFromMap(tmpMap, pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
	                            // Modified by Subhajit for Defect 51896 - Ends
								//Include the Alternates of Component
								if (!(strDONOTINCLUDETYPE.contains(strType))) {
									// Modified by Subhajit for Defect 51896 - Starts
	                                StringList slAlternateIds = getStringListFromMap(tmpMap, pgV3Constants.SELECT_ALTERNATE_ID);
	                                // Modified by Subhajit for Defect 51896 - Ends
									for(Object oAlternateId : slAlternateIds) {
										dobjAlternate = DomainObject.newInstance(context, (String) oAlternateId);
										Map mpAlternate = dobjAlternate.getInfo(context,SL_OBJECT_INFO_SELECT);
										
										//COP BULK - Primary Component Alternate PAP
										strPriAltSpecSubType = (String) mpAlternate.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
										if(!strPriAltSpecSubType.equalsIgnoreCase(pgV3Constants.THIRD_PARTY)) {	
											(mpAlternate).put(DomainConstants.SELECT_RELATIONSHIP_ID,(String) tmpMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
											(mpAlternate).put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
											(mpAlternate).put("level", strLevel);
											mlFlatBOM.add(mpAlternate);
										}
										
									}
								}
								
								if (null != substituteIds && substituteIds.size() > 0) {
									int iSizeOfSubstitutes = substituteIds.size();
									for(int iSub = 0; iSub < iSizeOfSubstitutes; iSub++) {
										strSubstituteType = (String)substituteTypes.get(iSub);
										//Add Fabricated Part as BOM Component
										String strSubstitutepgSAPType=(String)substituteSAPTypes.get(iSub);
											
										
										//COP BULK - Substitute PAP
										if(!(pgV3Constants.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))){
										
											mapTemp = new HashMap();
											strSubstituteId = (String)substituteIds.get(iSub);
											
											mapTemp.put("name", (String)substituteNames.get(iSub));
											mapTemp.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
											mapTemp.put("relationship", pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE);
											//mapTemp.put(DomainConstants.SELECT_ID, (String)substituteIds.get(iSub));
											mapTemp.put(DomainConstants.SELECT_ID, strSubstituteId);
											//mapTemp.put(DomainConstants.SELECT_TYPE, (String)substituteTypes.get(iSub));
											mapTemp.put(DomainConstants.SELECT_TYPE, strSubstituteType);
											mapTemp.put(DomainConstants.SELECT_REVISION, (String)substituteRevs.get(iSub));
											mapTemp.put(DomainConstants.SELECT_CURRENT, (String)slsubstituteCurrent.get(iSub));
											mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE, (String)slSubstituteEffectivityDate.get(iSub));
											mapTemp.put(pgV3Constants.ATTRIBUTE_PGVALIDUNTILDATE, (String)slSubstituteValidUntilDate.get(iSub));
											
											mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT, (String)slSubstituteOptComponent.get(iSub));
											mapTemp.put(pgV3Constants.SELECT_ATTRIBUTE_COMMENT, (String)slSubstituteComment.get(iSub));
											mapTemp.put("level", strLevel);
											
											//COP BULK - Substitute PAP
											if ((pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strSubstituteType)) && UIUtil.isNotNullAndNotEmpty(slSubSpecSubType.get(iSub)) && (pgV3Constants.BULK_INTERMEDIATE_UNIT.equalsIgnoreCase(slSubSpecSubType.get(iSub)))) {
												mlFlatBOM.addAll(getFPPObjectsForCOPBulk(context,mapTemp));
											}
											
											
											if(!(strDONOTINCLUDETYPE.contains(strSubstituteType)) && !(pgV3Constants.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))){
												mlFlatBOM.add(mapTemp);
												
												if(UIUtil.isNotNullAndNotEmpty(strSubstituteType) && ALTERNATE_ALLOWED_TYPES.contains(strSubstituteType)){
													mlSubAlts= getAlternates(context, strSubstituteId);
													iAltsSize = mlSubAlts.size();
													for(int i=0;i<iAltsSize;i++){
														mpAltMap = (Map) mlSubAlts.get(i);
														
														//Subtitute Alternate of PAP
														strSubAltSpecSubType = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
														if(!strSubAltSpecSubType.equalsIgnoreCase(pgV3Constants.THIRD_PARTY)) {	
															mpAltMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
															mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
															mpAltMap.put("IntermediateName", strName+"."+strRev);
															mpAltMap.put("IntermediateID", strID);
															mpAltMap.put("IntermediateType", strObjectType);
															mpAltMap.put("IntermediateLevel", strLevel);
															mlFlatBOM.add(mpAltMap);
														}
														
													}
												}
											}
										}
									}
								}
							}		
						}
					}
					if (pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strTopNodeType)) {
						mpTUPDATA = getPartBOMFEEDData(context,IPSId,strTopNodeType);
					}

					//calculate BOM Quantitiy
					Map mParamList = new  HashMap();
					mParamList.put("objectId", IPSId);
					Map hmArgMapParams = new HashMap();		
					hmArgMapParams.put("objectList", mlFlatBOM); 
					hmArgMapParams.put("paramList", mParamList);
					String strCalcQTY = null;


					if((null!=mlFlatBOM && mlFlatBOM.size()>0) || (null!=mlReleasedFPP && mlReleasedFPP.size()>0)) {
						
						
						if (pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strTopNodeType) && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM) || (UIUtil.isNotNullAndNotEmpty(strTopNodeSpecSubType) && pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strTopNodeSpecSubType)))) {
						
							Map mpBOMQTY = getBOMQTYDataFPP(context,hmArgMapParams,isReshipperSub,slSubstituteInterIdReshipper,strBUOM);
							fIntermediateSAPQty = (float) mpBOMQTY.get("fIntermediateSAPQty");
							strListQty = (StringList)mpBOMQTY.get("strListQtyValues");
						}else if(!isReshipperSub){
							strListQty = getQuantityValue(context,IPSId,mlFlatBOM);
						}
						
						if (null!=mpTUPDATA && mpTUPDATA.size()>0) {
							mlFlatBOM.addAll(mpTUPDATA);
							strListQty.addAll(getTUPBOMQTYData(context,IPSId,mpTUPDATA,fIntermediateSAPQty,strBUOM));
						}
						
						if(null!=mlReleasedFPP && mlReleasedFPP.size()>0){
							mlFlatBOM.addAll(mlReleasedFPP);
							strListQty.addAll(slReleaseFPPQTY);
						}
						slSubstituteGroupValues = getSubstituteGroupValue(context,IPSId,mlFlatBOM);
						
					} else if (null!=mpTUPDATA && mpTUPDATA.size()>0) {
						strListQty = getTUPBOMQTYData(context,IPSId,mpTUPDATA,fIntermediateSAPQty,strBUOM);
						//Substitute grouping is done for TUP
						slSubstituteGroupValues = getSubstituteGroupValue(context,IPSId,mpTUPDATA);
						mlFlatBOM = mpTUPDATA;
					}
					if(null != mlFlatBOM) {
						int iSizeFlatBOM	= mlFlatBOM.size();
						if(null != strListQty && iSizeFlatBOM == strListQty.size()) {
							for (int i=0;iSizeFlatBOM>i;i++) {
								
								mpAlternateDetails = new HashMap();
								sCATIAAPPDeliver = true;
								
								mpBOM			= (Map)mlFlatBOM.get(i);
								strType			= (String)mpBOM.get(DomainObject.SELECT_TYPE);
								//Add Fabricated Part as BOM Component
								if(!(strDONOTINCLUDETYPE.contains(strType))) {
									strFindNumb				= (String)mpBOM.get(DomainConstants.SELECT_ATTRIBUTE_FIND_NUMBER);
									strEffectivityDateChild	= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
									
									strValidUntilDate	= (String)mpBOM.get(pgV3Constants.ATTRIBUTE_PGVALIDUNTILDATE);
									
									sChildName				= (String)mpBOM.get(DomainConstants.SELECT_NAME);
									sQuantity				= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGQUANTITY);
									strMax					= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGMAXQUANTITY);
									strMin					= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGMINQUANTITY);
									sTarget					= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
									strPosInd				= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
									strFILBaseQty			= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
									strID 					= (String)mpBOM.get(DomainObject.SELECT_ID); 
									strObjectType 			= (String)mpBOM.get(DomainConstants.SELECT_TYPE);
									strSAPType				= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
									strQtyTmp  				= (String)strListQty.get(i); 
									//Added by Subhajit for Defect 52947 - Start
									if( i < slSubstituteGroupValues.size()) {
										strGroupTmp  		= (String)slSubstituteGroupValues.get(i);
									} else {
										strGroupTmp = "";
									}
									//Added by Subhajit for Defect 52947 - End
									String strRelID 		= (String)mpBOM.get(DomainConstants.SELECT_RELATIONSHIP_ID); 
									strOptComponent			= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
									strComment				= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_COMMENT);
									strRelationship			= (String)mpBOM.get("relationship");

									
									if (UIUtil.isNotNullAndNotEmpty(strID) && UIUtil.isNotNullAndNotEmpty(strObjectType) && UIUtil.isNotNullAndNotEmpty(strRelationship) && pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strObjectType) && (DomainConstants.RELATIONSHIP_ALTERNATE.equalsIgnoreCase(strRelationship))) {
									
										doAlternate = DomainObject.newInstance(context, strID);
			
										mpAlternateDetails = doAlternate.getInfo(context, slAlternateSelects);
										sBOMComponentCurrent = (String)mpAlternateDetails.get(DomainConstants.SELECT_CURRENT);
										sAuthoringApplication = (String)mpAlternateDetails.get(pgV3Constants.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION);
										
										if(UIUtil.isNotNullAndNotEmpty(sAuthoringApplication) && pgV3Constants.RANGE_PGAUTHORINGAPPLICATION_LPD.equalsIgnoreCase(sAuthoringApplication) && !(pgV3Constants.STATE_RELEASE.equalsIgnoreCase(sBOMComponentCurrent))) {

											sCATIAAPPDeliver = false;
										}
									}
										
									if(!pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSAPType) && !strObjectType.contains(pgV3Constants.TYPE_MASTER) && sCATIAAPPDeliver)  {
										
										arrBOM 					= buildBOMArray ( strTopNodeName,  strFindNumb,
												strEffectivityDateChild,
												sChildName,  strQtyTmp,
												strMax,  sTarget,  strMin,
												strTopNodeEffeDate, 
												strTopNodeBOMQty,  strPosInd, strFILBaseQty, strpgPhaseBOMQty, strGroupTmp,strID,strOptComponent,strComment,
												"","","", strValidUntilDate);
										
										arrBOM[pgV3Constants.INDEX_TPU_ID] = (String)mpBOM.get("TUP_ID");
										alBOM.add(arrBOM);
									}
								}
							}
						}
					}	
			 
			}
			}catch(Exception ex) {
				ex.printStackTrace();
				//throw new Exception(ex.getMessage());
			}
			return alBOM;
		}


		
		/**
		 * Gets EBOM, Substitutes and Alternate of Fabricated Part, Assembled Product Part and Devise Product Part.
		 * @param context
		 * @param strObjectID: Object Id
		 * @arg object details
		 * @return Maplist of BOM FEED
		 * @throws Exception
		 */
		public ArrayList getPartObjectsFromBOM(Context context, String  strObjectID) throws Exception {
			ArrayList alBOM = new ArrayList();
			MapList mlMinMaxQtyValues = new MapList();
			MapList mlFlatBOM = new MapList();
			Map mpMinMaxQty = null;
			StringList slSubstituteGroupValues = new StringList(1);
			
			String strFindNumb				= DomainConstants.EMPTY_STRING;
			String strEffectivityDateChild	= DomainConstants.EMPTY_STRING;
			
			String strValidUntilDate		= DomainConstants.EMPTY_STRING;
			
			String sChildName				= DomainConstants.EMPTY_STRING;
			String sQuantity				= DomainConstants.EMPTY_STRING;
			String strMax					= DomainConstants.EMPTY_STRING;
			String strMin					= DomainConstants.EMPTY_STRING;
			String sTarget					= DomainConstants.EMPTY_STRING;
			String strPosInd				= DomainConstants.EMPTY_STRING;
			String strFILBaseQty			= DomainConstants.EMPTY_STRING;
			String strID 					= DomainConstants.EMPTY_STRING;
			String strQtyTmp  				= DomainConstants.EMPTY_STRING;
			String strGroupTmp  			= DomainConstants.EMPTY_STRING;
			String strRelID 				= DomainConstants.EMPTY_STRING;
			String strTopNodeType 			= DomainConstants.EMPTY_STRING;
			String strTopNodeName 			= DomainConstants.EMPTY_STRING;
			String strTopNodeEffeDate 		= DomainConstants.EMPTY_STRING;
			String strTopNodeBOMQty 		= DomainConstants.EMPTY_STRING;
			String strpgPhaseBOMQty			= DomainConstants.EMPTY_STRING;
			String strSAPType				= DomainConstants.EMPTY_STRING;
			String strObjectType			= DomainConstants.EMPTY_STRING;
			String strOptComponent			= DomainConstants.EMPTY_STRING;
			String strComment				= DomainConstants.EMPTY_STRING;
			Map mpBOM = null;
			Map mpNodeDeatails = null;
			String[] arrBOM;
			DomainObject dObjForTopNodePart = null;
			
			DomainObject doBase = null;
			DomainObject doAlternate= null;
			String sBOMComponentCurrent 		= DomainConstants.EMPTY_STRING;
			String sAuthoringApplication 		= DomainConstants.EMPTY_STRING;
			String strRelationship				= DomainConstants.EMPTY_STRING;
			boolean sCATIAAPPDeliver 		= true;
			Map mpAlternateDetails = new HashMap();
			StringList slAlternateSelects = new StringList(2);
		  	slAlternateSelects.add(DomainConstants.SELECT_CURRENT);
		  	slAlternateSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION);
			
			try {
				if(BusinessUtil.isNotNullOrEmpty(strObjectID)) {
					dObjForTopNodePart = DomainObject.newInstance(context, strObjectID);
					//Check the top level part type
					mpNodeDeatails 				= dObjForTopNodePart.getInfo(context,SL_OBJECT_INFO_SELECT);
					strTopNodeType 				= (String) mpNodeDeatails.get(DomainConstants.SELECT_TYPE);
					strTopNodeName 				= (String) mpNodeDeatails.get(DomainConstants.SELECT_NAME);
					strTopNodeEffeDate 			= (String) mpNodeDeatails.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
					strTopNodeBOMQty 			= (String) mpNodeDeatails.get(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
					//To get BOM components of the respective types
					mlFlatBOM = getPartBOMFEEDData(context, strObjectID,strTopNodeType);
					int iSizeFlatBOM = mlFlatBOM.size();
					if(null!=mlFlatBOM && iSizeFlatBOM>0) {
						mlMinMaxQtyValues = getPartBOMQTYData(context,strObjectID,mlFlatBOM);
						slSubstituteGroupValues = getSubstituteGroupValue(context,strObjectID,mlFlatBOM);

						if(null != mlMinMaxQtyValues && iSizeFlatBOM == mlMinMaxQtyValues.size()) {
							for (int i=0;iSizeFlatBOM>i;i++) {
									
								mpAlternateDetails = new HashMap();
								sCATIAAPPDeliver = true;
									
								mpBOM = (Map)mlFlatBOM.get(i);
								strFindNumb				= (String)mpBOM.get(DomainConstants.SELECT_ATTRIBUTE_FIND_NUMBER);
								strEffectivityDateChild	= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
								
								strValidUntilDate		= (String)mpBOM.get(pgV3Constants.ATTRIBUTE_PGVALIDUNTILDATE);
								
								sChildName				= (String)mpBOM.get(DomainConstants.SELECT_NAME);
								sQuantity				= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGQUANTITY);
								mpMinMaxQty = (Map)mlMinMaxQtyValues.get(i);
								strMax					= (String)mpMinMaxQty.get("MaxQty");
								strMin					= (String)mpMinMaxQty.get("MinQty");
								sTarget					= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);;
								strPosInd				= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
								strFILBaseQty			= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
								strID 					= (String)mpBOM.get(DomainObject.SELECT_ID); 
								strObjectType 			= (String)mpBOM.get(DomainConstants.SELECT_TYPE);
								strSAPType				= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
								strOptComponent			= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
								strComment				= (String)mpBOM.get(pgV3Constants.SELECT_ATTRIBUTE_COMMENT);
								strQtyTmp  				= (String)mpMinMaxQty.get("Qty");					
								strGroupTmp  			= (String)slSubstituteGroupValues.get(i);
								strRelationship			= (String)mpBOM.get("relationship");

														
								if (UIUtil.isNotNullAndNotEmpty(strID) && UIUtil.isNotNullAndNotEmpty(strObjectType) && UIUtil.isNotNullAndNotEmpty(strRelationship) && pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strObjectType) && (DomainConstants.RELATIONSHIP_ALTERNATE.equalsIgnoreCase(strRelationship))) {
									
									doAlternate = DomainObject.newInstance(context, strID);
		
									mpAlternateDetails = doAlternate.getInfo(context, slAlternateSelects);
									sBOMComponentCurrent = (String)mpAlternateDetails.get(DomainConstants.SELECT_CURRENT);
									sAuthoringApplication = (String)mpAlternateDetails.get(pgV3Constants.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION);
									
									if(UIUtil.isNotNullAndNotEmpty(sAuthoringApplication) && pgV3Constants.RANGE_PGAUTHORINGAPPLICATION_LPD.equalsIgnoreCase(sAuthoringApplication) && !(pgV3Constants.STATE_RELEASE.equalsIgnoreCase(sBOMComponentCurrent))) {

										sCATIAAPPDeliver = false;
									}
								}						
								
								if(!pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSAPType) && !strObjectType.contains(pgV3Constants.TYPE_MASTER) && sCATIAAPPDeliver)  {
									
								arrBOM 					= buildBOMArray ( strTopNodeName,  strFindNumb,
										strEffectivityDateChild,
										sChildName,  strQtyTmp,
										strMax,  sTarget,  strMin,
										strTopNodeEffeDate, 
										strTopNodeBOMQty,  strPosInd, strFILBaseQty, strpgPhaseBOMQty, strGroupTmp,strID, strOptComponent,strComment
										,"","","",strValidUntilDate);
									
								arrBOM[pgV3Constants.INDEX_TPU_ID] = (String)mpBOM.get("TUP_ID");
								alBOM.add(arrBOM);
							}
						
						}
					}
				}
			} 
			}catch(Exception ex) {
				ex.printStackTrace();
			}
			return alBOM;
		}

		
		public String[] buildBOMArray (String strParentName, String strFindNumber,
				String strEffectivityDateChild,
				String sComponentName, String sQuantity,
				String strMax, String sTarget, String strMin,
				String strEffectivDateParent, 
				String sBOMBaseQuantity, String strPosInd,String strFILBaseQty,String strpgPhaseBOMQty,String strSubFlag,
				String strID, String strOptComponent, String strComment, String strTargetWetWeight, String strTargetDryWeight, String strIsPrimaryComponent, String strValidUntilDate) {
		//Modified by DSM - for 2018x.1 requirement #25043 - Ends
			String[] saTemp = new String[pgV3Constants.INDEX_BOM_ARRAY_SIZE]; 

			try {
				
				String sFinalQuantity = DomainConstants.EMPTY_STRING;
				
				if(BusinessUtil.isNullOrEmpty(sQuantity))
					sQuantity="1";
				if(BusinessUtil.isNullOrEmpty(strMax))
					strMax=pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
				if(BusinessUtil.isNullOrEmpty(strMin))
					strMin=pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
				if(BusinessUtil.isNullOrEmpty(sBOMBaseQuantity))
					sBOMBaseQuantity="1";
				if(BusinessUtil.isNullOrEmpty(strFILBaseQty))
					strFILBaseQty="1";
				if(BusinessUtil.isNullOrEmpty(strpgPhaseBOMQty))
					strpgPhaseBOMQty="1";
				if(BusinessUtil.isNullOrEmpty(sTarget))
					sTarget="1";

				double dFil 					= 1;
				double dMinQty					= 1;
				double dPgPhaseBOMQty			= 1;
				double dBOMBaseQty				= 1;
				double dTargetQty				= 1;
				double dMaxQty					= 1;
				double dFilBaseQty				= 1;
				double dPCTBase					= 1;
				double dQuantity				= 1;
				double dFormula_Card_Minimum_Quantity = parseValue(strMin);
				
				if (dFormula_Card_Minimum_Quantity<=0)
				{
					dFormula_Card_Minimum_Quantity= -9.99;
				}
				
				double dFormula_Card_Maximum_Quantity = parseValue(strMax);
				
				if (dFormula_Card_Maximum_Quantity<=0)
				{
					dFormula_Card_Maximum_Quantity= -9.99;
				}
				
				double dFormula_Card = 1;
				double dIPS_Quantity = 1;

				dMinQty 			= parseValue(strMin);
				
				if (dMinQty<=0)
				{
					dMinQty= -9.99;
				}
				
				dPgPhaseBOMQty		= parseValue(strpgPhaseBOMQty);
				dBOMBaseQty			= parseValue(sBOMBaseQuantity);				
				dTargetQty			= parseValue(sTarget);
				dMaxQty				= parseValue(strMax);
				
				if (dMaxQty<=0)
				{
					dMaxQty= -9.99;
				}
				
				dFilBaseQty			= parseValue(parseQuantityValue(strFILBaseQty));
				dPCTBase			= dFilBaseQty;
				dQuantity			= parseValue(parseQuantityValue(sQuantity));
				
				if (dQuantity<=0)
				{
					dQuantity= -9.99;
				} else {
					
					BigDecimal bdQuantity = new BigDecimal(sQuantity);
					sFinalQuantity = bdQuantity.toPlainString();
					
				}
				
				
				strMin				= dMinQty+DomainConstants.EMPTY_STRING;
				strpgPhaseBOMQty	= dPgPhaseBOMQty+DomainConstants.EMPTY_STRING;
				sBOMBaseQuantity	= dBOMBaseQty+DomainConstants.EMPTY_STRING;
				sTarget				= dTargetQty+DomainConstants.EMPTY_STRING;
				strMax				= dMaxQty+DomainConstants.EMPTY_STRING;
				strFILBaseQty		= dFilBaseQty+DomainConstants.EMPTY_STRING;
				
				if (dQuantity<=0)
				{
				sQuantity			= dQuantity+DomainConstants.EMPTY_STRING;
				} else {
					sQuantity = sFinalQuantity;
				}
				
				if (BusinessUtil.isNotNullOrEmpty(strEffectivityDateChild))
					strEffectivityDateChild = convertPLMDateToSAP(strEffectivityDateChild);
				
						
				if (BusinessUtil.isNotNullOrEmpty(strValidUntilDate))
					strValidUntilDate = convertPLMDateToSAP(strValidUntilDate);
				
				
				if (BusinessUtil.isNotNullOrEmpty(strEffectivDateParent))
					strEffectivDateParent = convertPLMDateToSAP(strEffectivDateParent);

				if(BusinessUtil.isNotNullOrEmpty(sTarget) && !pgV3Constants.STR_DEFAULT_QTY_IF_FAILED.equals(sTarget)) {
					dFormula_Card  				 = 	dBOMBaseQty /(dFilBaseQty  * dTargetQty);
					dFormula_Card				 =	(double)Math.round(dFormula_Card*1000)/1000;
				}else {

					dFormula_Card = parseValue(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED) ;
				}

				if(BusinessUtil.isNotNullOrEmpty(sQuantity) && !pgV3Constants.STR_DEFAULT_QTY_IF_FAILED.equals(sQuantity)) {
					dIPS_Quantity 				  = dBOMBaseQty /(dPCTBase * dQuantity);
					dIPS_Quantity				  =	(double)Math.round(dIPS_Quantity*1000)/1000;
				}else {
					dIPS_Quantity = parseValue(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED) ;
				}
				
	            if (UIUtil.isNotNullAndNotEmpty(strSubFlag)) {
					saTemp[pgV3Constants.INDEX_USAGE_PROBABILITY] = pgV3Constants.VALUE_USAGE_PROBABILITY;
			    } else {
					saTemp[pgV3Constants.INDEX_USAGE_PROBABILITY] = "";
			    }
	            
				saTemp[pgV3Constants.INDEX_ALT_BOM] 				= pgV3Constants.VALUE_ALT_BOM;
				saTemp[pgV3Constants.INDEX_BOM_STATUS] 				= pgV3Constants.VALUE_BOM_STATUS;
				saTemp[pgV3Constants.INDEX_ITEM_CATEGORY] 			= pgV3Constants.VALUE_ITEM_CATEGORY;
				saTemp[pgV3Constants.INDEX_BOM_TEXT] 				= strParentName ;
				saTemp[pgV3Constants.INDEX_ALT_BOM_TEXT] 			= pgV3Constants.VALUE_ALT_BOM_TEXT;
				saTemp[pgV3Constants.INDEX_MATERIAL_NUMBER] 		= strParentName;
				saTemp[pgV3Constants.INDEX_BOM_USAGE] 				= pgV3Constants.VALID_CODE;
				saTemp[pgV3Constants.INDEX_VALID_FROM_DATE_PARENT] 	= strEffectivDateParent;
				saTemp[pgV3Constants.INDEX_COMPONENT_NAME] 			= sComponentName;
				saTemp[pgV3Constants.INDEX_QUANTITY] 				= sQuantity;
				saTemp[pgV3Constants.INDEX_UPPER_LIMIT] 			= strMax;
				saTemp[pgV3Constants.INDEX_TARGET] 					= sQuantity;
				saTemp[pgV3Constants.INDEX_LOWER_LIMIT] 			= strMin;
				saTemp[pgV3Constants.INDEX_FIND_NUMBER] 			= strFindNumber;
				saTemp[pgV3Constants.INDEX_VALID_FROM_DATE_CHILD] 	= strEffectivityDateChild;
						
				saTemp[pgV3Constants.INDEX_VALID_UNTIL_DATE] 		= strValidUntilDate;
						
				saTemp[pgV3Constants.INDEX_PHASE_NAME] 				= DomainConstants.EMPTY_STRING;
				saTemp[pgV3Constants.INDEX_CONFIRMED_QUANTITY] 		= sBOMBaseQuantity;
				saTemp[pgV3Constants.INDEX_SORT_STRING] 			= strPosInd;
				saTemp[pgV3Constants.INDEX_BOM_ITEM_NUMBER] 		= DomainConstants.EMPTY_STRING;
				saTemp[pgV3Constants.INDEX_SUBSTITUTE_FLAG] 		= strSubFlag;
				saTemp[pgV3Constants.INDEX_FC_MIN_QTY] 				= dFormula_Card_Minimum_Quantity+DomainConstants.EMPTY_STRING;
				saTemp[pgV3Constants.INDEX_FORMULA_CARD] 			= dFormula_Card+DomainConstants.EMPTY_STRING;
				saTemp[pgV3Constants.INDEX_FC_MAX_QTY] 				= dFormula_Card_Maximum_Quantity+DomainConstants.EMPTY_STRING;
				saTemp[pgV3Constants.INDEX_IPS_QTY] 				= dIPS_Quantity+DomainConstants.EMPTY_STRING;
				saTemp[pgV3Constants.INDEX_OPT_COMPONENT] 			= strOptComponent;
				saTemp[pgV3Constants.INDEX_COMMENT] 				= strComment;
				saTemp[pgV3Constants.INDEX_TARGETWETWEIGHT] 		= strTargetWetWeight;
				saTemp[pgV3Constants.INDEX_TARGETDRYWEIGHT] 		= strTargetDryWeight;
				saTemp[pgV3Constants.INDEX_ISPRIMARYCOMPONENT] 		= strIsPrimaryComponent;
				saTemp[pgV3Constants.INDEX_OBJECT_ID] 				= strID;

				if (saTemp[pgV3Constants.INDEX_UPPER_LIMIT] == null || saTemp[pgV3Constants.INDEX_UPPER_LIMIT].equals("")) {
					saTemp[pgV3Constants.INDEX_RANGE_FLAG] = DomainConstants.EMPTY_STRING;
				} else
					saTemp[pgV3Constants.INDEX_RANGE_FLAG] = pgV3Constants.VALUE_RANGE_FLAG;


			}catch(Exception e) {		
				e.printStackTrace();
				//Not throwing exception here as the calling method is expecting String Array.
				//In this case Blank String array would be returned which is being handled properly by calling method.
				//throw e;
			}		
			return saTemp;
		
		}

		
		
		public MapList getValidFormulationProcess(Context context, String strID, String strFOPNextRev) throws Exception{
			DomainObject doTS = null;
			MapList mpListChildFP = new MapList();
			String sLastFormulationProcessID = DomainConstants.EMPTY_STRING;
			String strFPObjWhere = DomainConstants.EMPTY_STRING;
			try{			
				if(BusinessUtil.isNotNullOrEmpty(strID)) {
					doTS = DomainObject.newInstance(context, strID);
					if(UIUtil.isNotNullAndNotEmpty(strFOPNextRev)){
						strFPObjWhere = "(current==Release && (revision==last||next.current!= Release))";
					} else{
						strFPObjWhere = "revision == last";						
					}
					mpListChildFP = doTS.getRelatedObjects(context,pgV3Constants.RELATIONSHIP_PLANNEDFOR, pgV3Constants.TYPE_FORMULATIONPROCESS, SL_OBJECT_INFO_SELECT, SL_RELATION_INFO_SELECT_OTHERS, false, true,(short) ConstantsUtilIRM.FIRST_LVL, strFPObjWhere, "", 0);
					
					 
					//int mpListChildFPSize = mpListChildFP.size();
				
					if(mpListChildFP.size()== 0) {
					
						sLastFormulationProcessID = getFinalFormulationProcessDetails(context,strID);
						strFPObjWhere = (new StringBuilder()).append(DomainConstants.SELECT_ID).append("==").append(sLastFormulationProcessID).toString();
						mpListChildFP = doTS.getRelatedObjects(context,pgV3Constants.RELATIONSHIP_PLANNEDFOR, pgV3Constants.TYPE_FORMULATIONPROCESS, SL_OBJECT_INFO_SELECT, SL_RELATION_INFO_SELECT_OTHERS, false, true,(short) ConstantsUtilIRM.FIRST_LVL, strFPObjWhere, "", 0);
						
					}
					 
				}	
				
			}catch(Exception ex){
				throw ex;	
			}
			return mpListChildFP;
		}
		
		
		
		private String getTotalDryweight(Context context,DomainObject doPart) throws Exception
		{
			
			double dDryWeight =0.0;
			
			BigDecimal bdSumofDryWeights = BigDecimal.ZERO;
			StringList slTotalDryWeight = new StringList();
			String strSumOfDryweight = DomainConstants.EMPTY_STRING;
			String SELECT_TARGET_DRY_WEIGHT = new StringBuffer("from[").append(pgV3Constants.RELATIONSHIP_PLBOM).append("].to.from[").append(pgV3Constants.RELATIONSHIP_PLBOM).append("].").append(pgV3Constants.SELECT_ATTRIBUTE_TARGETWEIGHTDRY).toString();
			
			slTotalDryWeight =  doPart.getInfoList(context, SELECT_TARGET_DRY_WEIGHT);
			
			if (!slTotalDryWeight.isEmpty()) {
				for (String strTargetDryWeight : slTotalDryWeight) {
					BigDecimal bdDryWeight = BigDecimal.ZERO;
					if (UIUtil.isNotNullAndNotEmpty(strTargetDryWeight)) {
						dDryWeight 	= Double.parseDouble(strTargetDryWeight);
						bdDryWeight	= BigDecimal.valueOf(dDryWeight);
					}
					if (bdDryWeight.compareTo(BigDecimal.ZERO) > 0 ) {								
						bdSumofDryWeights = bdSumofDryWeights.add(bdDryWeight);	
					}
					strSumOfDryweight= String.valueOf(bdSumofDryWeights);
				}	
			}
			return strSumOfDryweight;
		}
		
		
		/**
		 * getInstanceList- Method is used to get dynamically string/string list values . 
		 * @param context the eMatrix <code>Context</code> object
		 * @param input - object
		 * @return String List - Final Value.
		 */
		public StringList getInstanceList(Object input) {
			StringList returnList 	= new StringList();
			if(null != input) {

				if (input instanceof StringList) {

					returnList = (StringList) input;
				} else {

					returnList.add(input.toString());
				}
			}
			return returnList;
		}
		
		
		/**
		 * Method returns the alternates connected to an object.
		 * 
		 * @param context
		 * @param strObjectId : Object Id of the parent.
		 * @throws Exception when operation fails
		 */
		public MapList getAlternates(Context context, String strObjectId) throws Exception{
			
			MapList mlAltsList = null;
			StringList slAltObjSelects = new StringList(6);
			slAltObjSelects.add(DomainConstants.SELECT_ID);
			slAltObjSelects.add(DomainConstants.SELECT_NAME);
			slAltObjSelects.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			slAltObjSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slAltObjSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
			
			slAltObjSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
			
			
			StringList slAltRelSelects = new StringList(1);
			slAltRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			
			DomainObject doParentObj = null; 
			
			try{
				if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				
				    doParentObj = DomainObject.newInstance(context, strObjectId);
		
					mlAltsList = doParentObj.getRelatedObjects(context,
											DomainConstants.RELATIONSHIP_ALTERNATE, 	// rel pattern
											//"*",     									// type pattern
											DomainConstants.QUERY_WILDCARD, 			// type pattern
											slAltObjSelects,							// obj selects
											slAltRelSelects,							// rel selects
											false,                  					// to side
											true,                   					// from side 
											(short)ConstantsUtilIRM.FIRST_LVL,               					// recursion level
											DomainConstants.EMPTY_STRING,       							// object where clause
											DomainConstants.EMPTY_STRING,0); 
				}
			}catch(Exception ex){
				ex.printStackTrace();
			}		
			return mlAltsList;
		}


		public static String convertPLMDateToSAP(String strDate) {		
	       /* String strSAPDate = DomainConstants.EMPTY_STRING;;
	        Date dMatrixDate = null;
			SimpleDateFormat formatter = null;
			SimpleDateFormat sapFormatter = null;
	        try
	        {
				if (UIUtil.isNotNullAndNotEmpty(strDate)){
					formatter = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat());			
					sapFormatter = new SimpleDateFormat(pgV3Constants.SAP_DATE_FORMAT);							
					dMatrixDate = formatter.parse(strDate);
					strSAPDate = sapFormatter.format(dMatrixDate);
				}
	        }catch (Exception e){
	            //System.out.println(e.toString());
	            //e.printStackTrace();
	        }	*/	
	        return(strDate);
		}

		
		/**
		* getFPPObjectsForChildCOPInCOP- This method returns Released FPP object connected to the Second level COP in FPP BOM Structure. 
		* @param *
		* @return Map
		* @throws Exception 
		**/	
		
		public Map getFPPObjectsForChildCOPInCOP(Context context,String strID,String strCOPToCOPQuantity,String strContextFPPId,StringList slCOPSubstituteIds, String strBOMBaseQuantity, BigDecimal bdIntermediateObjectQty, String strContextFPPBUOM,String strTopNodeSpecSubType,String sChildCOPSpecSubType,StringList slCOPSubsQuantities) throws Exception
		
		{
			Map mpReturn = new HashMap();
			String strCOPId = strID;
			DomainObject doObjectCOP 	= null;
	        // Modified by Subhajit for Defect 52840 - Start
			DomainObject doObjectContextFPP 	= null;
			// Modified by Subhajit for Defect 52840 - End
			MapList mlConnectedFPPs = null;
			
			StringList slObjectSelects = new StringList(6);
			slObjectSelects.add(DomainConstants.SELECT_ID);
			slObjectSelects.add(DomainConstants.SELECT_NAME);
			slObjectSelects.add(DomainConstants.SELECT_CURRENT);
			slObjectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			slObjectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slObjectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
			
			//Added by Jwala for 22x.06 Requirement 8277 - START
			slObjectSelects.add("attribute["+pgV3Constants.ATTRIBUTE_PGCUSTOMIZATIONTYPE+"]");
			//Added by Jwala for 22x.06 Requirement 8277 - END
			
			
			StringList slRelSelects = new StringList(3);
			slRelSelects.add(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
			slRelSelects.add(DomainRelationship.SELECT_ID);
			slRelSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
			
			String strCOPCUPITQuantity = DomainConstants.EMPTY_STRING;
			Pattern pIntermediateTypesForCOPToCOP = new Pattern(pgV3Constants.TYPE_FINISHEDPRODUCTPART);
			pIntermediateTypesForCOPToCOP.addPattern(pgV3Constants.TYPE_PGCUSTOMERUNITPART);
			pIntermediateTypesForCOPToCOP.addPattern(pgV3Constants.TYPE_PGINNERPACKUNITPART);
			Map mpFPPObjects = new HashMap();
			String strFPPId = DomainConstants.EMPTY_STRING;
			String strFPPCurrent = DomainConstants.EMPTY_STRING;
			String strFPPType = DomainConstants.EMPTY_STRING;
			Map mpsubstituteFPPObjects = new HashMap();
			String strSubstituteFPPId = DomainConstants.EMPTY_STRING;
			String strSubstituteFPPCurrent = DomainConstants.EMPTY_STRING;
			String strSubstituteFPPType = DomainConstants.EMPTY_STRING;		
			MapList mlReleasedFPP = new MapList();
			StringList strListQtyValues = new StringList(1);
			String strObjWhere = "current=="+pgV3Constants.STATE_RELEASE+"";		
			String strReleasedFPPBUOM = DomainConstants.EMPTY_STRING;
			
			String strReleasedFPPSpecSubType = DomainConstants.EMPTY_STRING;
			String strReleasedSubFPPSpecSubType = DomainConstants.EMPTY_STRING;
			
			String strIntermediateObjQty = DomainConstants.EMPTY_STRING;
			String strConnectedFPPLevel = DomainConstants.EMPTY_STRING;
			BigDecimal bdDenominator = new BigDecimal("1");
			BigDecimal bdNumerator = new BigDecimal("1");
			BigDecimal bdBOMQty = new BigDecimal("1");
			BigDecimal bdBOMQuantityCheck=new BigDecimal("9999999999.999");

			// Modified by Subhajit for Defect 52840 - Start
			StringList primaryCUPwhereUsedFPP = new StringList();
			boolean isPrimaryCupHasWhereUsedFPP=true;
			// Modified by Subhajit for Defect 52840 - End
			
			//Added by Jwala for 22x.06 Requirement 8277 - START
			boolean isForSAPBOMAsFedView=false;
			//Added by Jwala for 22x.06 Requirement 8277 - END

	        String strBUoMITBPMP = pgV3Constants.BASEUNITOFMEASURE_IT + "|" + pgV3Constants.BASEUNITOFMEASURE_MP + "|" + pgV3Constants.BASEUNITOFMEASURE_BP;
	        try {
	            doObjectCOP = DomainObject.newInstance(context, strCOPId);

	         // Modified by Subhajit for Defect 52840 - Start
	            String strgetRelProcessType = doObjectCOP.getInfo(context, DomainConstants.SELECT_TYPE);
	            short expandLevelVal = 0;
	            String expansionTypes = DomainConstants.EMPTY_STRING;
	            //if type is Customer Part expand level should be one to get immediate where used FPP
	            if (pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strgetRelProcessType)) {
	                expandLevelVal = 1;
	                expansionTypes = pgV3Constants.TYPE_FINISHEDPRODUCTPART;
	            }
	            if (pgV3Constants.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(strgetRelProcessType)) {
	                expandLevelVal = 2;
	                expansionTypes = pgV3Constants.TYPE_PGCUSTOMERUNITPART + "," + pgV3Constants.TYPE_FINISHEDPRODUCTPART;
	            }
	            if (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strgetRelProcessType)) {
	                expandLevelVal = 0;
	                expansionTypes = pgV3Constants.TYPE_FINISHEDPRODUCTPART + "," + pgV3Constants.TYPE_PGCUSTOMERUNITPART + "," + pgV3Constants.TYPE_PGINNERPACKUNITPART;
	            }
	         // Modified by Subhajit for Defect 52840 - End
	            //Get all Released FPPs linked to child COP
	            mlConnectedFPPs = doObjectCOP.getRelatedObjects(context,
	                    pgV3Constants.RELATIONSHIP_EBOM,    // relationship pattern
	                    expansionTypes, // Type pattern  //Modified by Subhajit for Defect 52840
	                    slObjectSelects,                // object selects
	                    slRelSelects,            // rel selects
	                    true,                                // to side
	                    false,                                // from side
	                    expandLevelVal,                // recursion level
	                    strObjWhere,                        // object where clause
	                    null, 0);                                // rel where clause
	            int mlConnectedFPPSize = mlConnectedFPPs.size();
	            bdNumerator = new BigDecimal(strCOPToCOPQuantity);
	            for (int i = 0; i < mlConnectedFPPSize; i++) {
	                bdBOMQty = new BigDecimal("1");
	                mpFPPObjects = (Map) mlConnectedFPPs.get(i);
	                //Setting the COPinCOP key value with COP Id for substitute grouping
	                
	                mpFPPObjects.put(pgV3Constants.MAP_KEY_SUBSTITUTE_FLAG_COP_IN_COP, strCOPId);
	               
	                strFPPId = (String) mpFPPObjects.get(DomainConstants.SELECT_ID);
	                strFPPCurrent = (String) mpFPPObjects.get(DomainConstants.SELECT_CURRENT);
	                strFPPType = (String) mpFPPObjects.get(DomainConstants.SELECT_TYPE);
	                strConnectedFPPLevel = (String) mpFPPObjects.get(DomainConstants.SELECT_LEVEL);
	                
	                //Added by Jwala for 22x.06 Requirement 8277 - START
					if(UIUtil.isNotNullAndNotEmpty(strFPPType) && strFPPType.equalsIgnoreCase(pgV3Constants.TYPE_FINISHEDPRODUCTPART)) {
						isForSAPBOMAsFedView=isFPPForSAPBOMAsFedView(context, mpFPPObjects);
						if(!isForSAPBOMAsFedView){
							continue;
						}
					}
					//Added by Jwala for 22x.06 Requirement 8277 - END
					
	                if (parseValue(strConnectedFPPLevel) == 1) {
	                    bdDenominator = new BigDecimal("1");
	                }
	             // Modified by Subhajit for Defect 52840 - Start
	                // if type is consumer part and where used FPP at level 3 and same level if primary cup have where used fpp  ignoring primary CUP where used FPP
	                if (parseValue(strConnectedFPPLevel) == 3 && (pgV3Constants.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(strgetRelProcessType))) {
	                    doObjectContextFPP = DomainObject.newInstance(context, strContextFPPId);
	                    primaryCUPwhereUsedFPP = doObjectContextFPP.getInfoList(context, "from[" + DomainConstants.RELATIONSHIP_EBOM + "].to.to[" + DomainConstants.RELATIONSHIP_EBOM + "].from.to[" + DomainConstants.RELATIONSHIP_EBOM + "].from.id");
	                    if (null != primaryCUPwhereUsedFPP && !primaryCUPwhereUsedFPP.isEmpty()) {
	                        if (primaryCUPwhereUsedFPP.contains(strFPPId)) {
	                            isPrimaryCupHasWhereUsedFPP = false;
	                        } else {
	                            isPrimaryCupHasWhereUsedFPP = true;
	                        }
	                    }
	                } // Modified by Subhajit for Defect 52840 - End
	               
	             // Modified by Subhajit for Defect 52840 - Start
	                // type should be FPP and level should have below or equal to 3
	                if (pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strFPPType)
	                        && isPrimaryCupHasWhereUsedFPP && parseValue(strConnectedFPPLevel) <= 3) {
	                	// Modified by Subhajit for Defect 52840 - End
	

	                    strReleasedFPPBUOM = (String) mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

	                    strReleasedFPPSpecSubType = (String) mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);

	                }
	                strIntermediateObjQty = (String) mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
	                if (UIUtil.isNotNullAndNotEmpty(strIntermediateObjQty)) {
	                    bdDenominator = bdDenominator.multiply(new BigDecimal(strIntermediateObjQty));
	                }


	             // Modified by Subhajit for Defect 52840 - Start
	                if ((pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strFPPType)
	                        && !strFPPId.equalsIgnoreCase(strContextFPPId)
	                        && isPrimaryCupHasWhereUsedFPP
	                        && parseValue(strConnectedFPPLevel) <= 3)) {
	                	// Modified by Subhajit for Defect 52840 - End
	                    
	                    mlReleasedFPP.add(mpFPPObjects);

	                    //If the context FPP Base Unit of Measure is SP/SW or if the Base Unit Measure of FPP linked to child COP is SP/SW, then final quantity will be -9.99
	                    if (pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strContextFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strContextFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strReleasedFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strReleasedFPPBUOM)) {
	                        strListQtyValues.add(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED);
	                        continue;
	                    }
	                    //If the context FPP Base Unit of Measure is anything other than IT/BP/MP and if the Base Unit Measure of FPP linked to child COP is anything other than IT/BP/MP
	                    if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM)
	                            && !strBUoMITBPMP.contains(strContextFPPBUOM))
	                            && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM)
	                            && !strBUoMITBPMP.contains(strReleasedFPPBUOM))) {
	                        //System.out.println("bdDenominator>>>" + bdDenominator);
	                        if (bdDenominator.compareTo(BigDecimal.ZERO) != 0)
	                            bdBOMQty = bdNumerator.divide(bdDenominator, 6, RoundingMode.HALF_UP);
	                        bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));
	                        bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty).setScale(3, BigDecimal.ROUND_HALF_UP);
	                        //If the context FPP Base Unit of Measure is anything other than IT/BP/MP and if the Base Unit Measure of FPP linked to child COP is IT/BP/MP
	                    } else if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM)
	                            && !strBUoMITBPMP.contains(strContextFPPBUOM))
	                            && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM)
	                            && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))) {
	                        bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));
	                        //bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty);

	                     // Modified by Subhajit for Defect 52840 - Start
	                        BigDecimal interMediateQuantity = getIntermediateQuantity(context, doObjectCOP, bdIntermediateObjectQty);
	                        if (pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strgetRelProcessType)
	                                || pgV3Constants.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(strgetRelProcessType)) {
	                            bdBOMQty = bdBOMQty.multiply(interMediateQuantity);
	                        } else {
	                            bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty);
	                        }
	                        bdBOMQty = bdBOMQty.multiply(bdNumerator).setScale(3, BigDecimal.ROUND_HALF_UP);
							if (!pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strgetRelProcessType)) {
								bdBOMQty = bdBOMQty.divide(bdDenominator, 3, RoundingMode.HALF_UP);
							}
							// Modified by Subhajit for Defect 52840 - End

	                        //If the context FPP Base Unit of Measure is IT/BP/MP and if the Base Unit Measure of FPP linked to child COP is anything other than IT/BP/MP
	                    } else if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM)
	                            && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM)))
	                            && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM)
	                            && !strBUoMITBPMP.contains(strReleasedFPPBUOM))) {
	                        if (bdDenominator.compareTo(BigDecimal.ZERO) != 0)
	                            bdBOMQty = bdNumerator.divide(bdDenominator, 6, RoundingMode.HALF_UP);
	                        bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);

	                        //If the context FPP Base Unit of Measure is IT/BP/MP and if the Base Unit Measure of FPP linked to child COP is IT/BP/MP
	                    } else if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM)
	                            && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM)))
	                            && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM)
	                            && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM)
	                            || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))) {
	                        bdBOMQty = bdNumerator.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);
	                    }

	                    
	                    if ((UIUtil.isNotNullAndNotEmpty(strTopNodeSpecSubType)
	                            && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strTopNodeSpecSubType)))
	                            || (UIUtil.isNotNullAndNotEmpty(strReleasedFPPSpecSubType)
	                            && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strReleasedFPPSpecSubType)))) {
	                        bdBOMQty = new BigDecimal("1");
	                        if (UIUtil.isNotNullAndNotEmpty(strTopNodeSpecSubType)
	                                && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strTopNodeSpecSubType))) {
	                            //Context FPP-Shippable HALB  and Linked FPP-Shippable HALB or FPP- Non Shippable HALB with IT/BP/MP
	                            if ((UIUtil.isNotNullAndNotEmpty(strReleasedFPPSpecSubType)
	                                    && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strReleasedFPPSpecSubType)))
	                                    || (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM)
	                                    && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM)
	                                    || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM)
	                                    || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))) {
	                                bdBOMQty = bdNumerator.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);

	                            } else {

	                                //Context FPP-Shippable HALB  and Linked FPP- Not Shippable HALB and BUOM other than IT
	                                if (bdDenominator.compareTo(BigDecimal.ZERO) != 0)
	                                    bdBOMQty = bdNumerator.divide(bdDenominator, 6, RoundingMode.HALF_UP);
	                                bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);
	                            }

	                        } else {

	                            //Context FPP- Non Shippable HALB and BUOM is IT and Linked FPP is Shippable HALB
	                            if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM)
	                                    && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM)
	                                    || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM)
	                                    || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM)))) {
	                                if (UIUtil.isNotNullAndNotEmpty(strReleasedFPPSpecSubType)
	                                        && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strReleasedFPPSpecSubType))) {
	                                    //Context FPP- Not Shippable HALB but IT and Linked FPP-Shippable HALB
	                                    bdBOMQty = bdNumerator.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);
	                                }
	                            } else {
	                                //Context FPP NON IT - NON SHIPPABLE HALB / Linked FPP Shippable HALB
	                                if (UIUtil.isNotNullAndNotEmpty(strReleasedFPPSpecSubType)
	                                        && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strReleasedFPPSpecSubType))) {
	                                    //Context FPP- Not Shippable HALB but IT and Linked FPP-Shippable HALB
	                                    bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));
	                                    bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty);
	                                    bdBOMQty = bdBOMQty.multiply(bdNumerator).setScale(3, BigDecimal.ROUND_HALF_UP);
	                                }
	                            }
	                        }
	                    }
	                   

	                    //If the calculated quantity is zero or if it is greater than 9999999999.999, then final quantity will be -9.99
	                    if (bdBOMQty.compareTo(BigDecimal.ZERO) == 0 || bdBOMQty.compareTo(bdBOMQuantityCheck) > 0) {
	                        bdBOMQty = new BigDecimal(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED);
	                    }
	                    strListQtyValues.add(bdBOMQty.toString());
	                }
	            }
	            int slSubstituteIdSize = slCOPSubstituteIds.size();
	            
	            Map mapCOPBulkSubstitutes = null;
	            Map mapCOPBulkSubsAlternates = null;
	            
	            if (!slCOPSubstituteIds.isEmpty()) {
	                for (int iCOPSubstitute = 0; iCOPSubstitute < slSubstituteIdSize; iCOPSubstitute++) {
	                    String strSubstituteId = (String) slCOPSubstituteIds.get(iCOPSubstitute);
	                    
	                    String strSubstituteQuantity = (String) slCOPSubsQuantities.get(iCOPSubstitute);
	                    
	                    DomainObject doSubstituteId = DomainObject.newInstance(context, strSubstituteId);
	                    MapList mlSubstituteConnectedFPP = doSubstituteId.getRelatedObjects(context,
	                            pgV3Constants.RELATIONSHIP_EBOM,    // relationship pattern
	                            pgV3Constants.TYPE_FINISHEDPRODUCTPART + "," + pgV3Constants.TYPE_PGCUSTOMERUNITPART + "," + pgV3Constants.TYPE_PGINNERPACKUNITPART, // Type pattern
	                            slObjectSelects,                // object selects
	                            slRelSelects,            // rel selects
	                            true,                                // to side
	                            false,                                // from side
	                            (short) ConstantsUtil.ZERO_LEVEL,                            // recursion level
	                            strObjWhere,                        // object where clause
	                            null, 0);                                // rel where clause
	                    int imlSubstituteConnectedFPP = mlSubstituteConnectedFPP.size();
	                    for (int iSubstituteConnectedFPP = 0; iSubstituteConnectedFPP < imlSubstituteConnectedFPP; iSubstituteConnectedFPP++) {
	                        bdBOMQty = new BigDecimal("1");
	                        mpsubstituteFPPObjects = (Map) mlSubstituteConnectedFPP.get(iSubstituteConnectedFPP);
	                        //Setting the COPinCOP key value with COP Id for substitute grouping
	                    
	                        mpsubstituteFPPObjects.put(pgV3Constants.MAP_KEY_SUBSTITUTE_FLAG_COP_IN_COP, strCOPId);
	                    
	                        strSubstituteFPPId = (String) mpsubstituteFPPObjects.get(DomainConstants.SELECT_ID);
	                        strSubstituteFPPCurrent = (String) mpsubstituteFPPObjects.get(DomainConstants.SELECT_CURRENT);
	                        strSubstituteFPPType = (String) mpsubstituteFPPObjects.get(DomainConstants.SELECT_TYPE);
	                        strConnectedFPPLevel = (String) mpsubstituteFPPObjects.get(DomainConstants.SELECT_LEVEL);
	                        
	                        //Added by Jwala for 22x.06 Requirement 8277 - START
	                        if(UIUtil.isNotNullAndNotEmpty(strSubstituteFPPType) && strSubstituteFPPType.equalsIgnoreCase(pgV3Constants.TYPE_FINISHEDPRODUCTPART)) {
								isForSAPBOMAsFedView=isFPPForSAPBOMAsFedView(context, mpsubstituteFPPObjects);
								if(!isForSAPBOMAsFedView){
									continue;
								}
							}
	                        //Added by Jwala for 22x.06 Requirement 8277 - END
	                        
	                        if (pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strSubstituteFPPType) && (parseValue(strConnectedFPPLevel) == 2 || parseValue(strConnectedFPPLevel) == 3)) {
	                     
	                            strReleasedFPPBUOM = (String) mpsubstituteFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
	                            
	                            strReleasedSubFPPSpecSubType = (String) mpsubstituteFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
	                            
	                        }
	                        strIntermediateObjQty = (String) mpsubstituteFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);


	                        if (parseValue(strConnectedFPPLevel) == 1)
	                            bdDenominator = new BigDecimal("1");

	                        if (UIUtil.isNotNullAndNotEmpty(strIntermediateObjQty)) {
	                            bdDenominator = bdDenominator.multiply(new BigDecimal(strIntermediateObjQty));
	                        }

	                        if (pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strSubstituteFPPType) && !strFPPId.equalsIgnoreCase(strContextFPPId) && (parseValue(strConnectedFPPLevel) == 2 || parseValue(strConnectedFPPLevel) == 3)) {
	                          
	                            mlReleasedFPP.add(mpsubstituteFPPObjects);

	                            bdNumerator = new BigDecimal(strSubstituteQuantity);

	                            //If the context FPP Base Unit of Measure is SP/SW or if the Base Unit Measure of FPP linked to child COP is SP/SW, then final quantity will be -9.99
	                            if (pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strContextFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strContextFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strReleasedFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strReleasedFPPBUOM)) {
	                                strListQtyValues.add(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED);
	                                continue;
	                            }

	                            //If the context FPP Base Unit of Measure is anything other than IT/BP/MP and if the Base Unit Measure of FPP linked to child COP is anything other than IT/BP/MP
	                            if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && !strBUoMITBPMP.contains(strContextFPPBUOM)) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && !strBUoMITBPMP.contains(strReleasedFPPBUOM))) {
	                                if (bdDenominator.compareTo(BigDecimal.ZERO) != 0)
	                                    bdBOMQty = bdNumerator.divide(bdDenominator, 6, RoundingMode.HALF_UP);
	                                bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));
	                                bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty).setScale(3, BigDecimal.ROUND_HALF_UP);

	                                //If the context FPP Base Unit of Measure is anything other than IT/BP/MP and if the Base Unit Measure of FPP linked to child COP is IT/BP/MP
	                            } else if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && !strBUoMITBPMP.contains(strContextFPPBUOM)) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))) {
	                                bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));
	                                bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty);
	                                bdBOMQty = bdBOMQty.multiply(bdNumerator).setScale(3, BigDecimal.ROUND_HALF_UP);

	                                //If the context FPP Base Unit of Measure is IT/BP/MP and if the Base Unit Measure of FPP linked to child COP is anything other than IT/BP/MP
	                            } else if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM))) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && !strBUoMITBPMP.contains(strReleasedFPPBUOM))) {
	                                if (bdDenominator.compareTo(BigDecimal.ZERO) != 0)
	                                    bdBOMQty = bdNumerator.divide(bdDenominator, 6, RoundingMode.HALF_UP);
	                                bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);

	                                //If the context FPP Base Unit of Measure is IT/BP/MP and if the Base Unit Measure of FPP linked to child COP is IT/BP/MP
	                            } else if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM))) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))) {
	                                bdBOMQty = bdNumerator.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);
	                            }


	                            if ((UIUtil.isNotNullAndNotEmpty(strTopNodeSpecSubType) && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strTopNodeSpecSubType))) || (UIUtil.isNotNullAndNotEmpty(strReleasedSubFPPSpecSubType) && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strReleasedSubFPPSpecSubType)))) {
	                                bdBOMQty = new BigDecimal("1");
	                                if (UIUtil.isNotNullAndNotEmpty(strTopNodeSpecSubType) && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strTopNodeSpecSubType))) {
	                                    //Context FPP-Shippable HALB  and Linked FPP-Shippable HALB or FPP- Non Shippable HALB with IT/BP/MP

	                                    if ((UIUtil.isNotNullAndNotEmpty(strReleasedSubFPPSpecSubType) && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strReleasedSubFPPSpecSubType))) || (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))) {

	                                        bdBOMQty = bdNumerator.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);

	                                    } else {

	                                        //Context FPP-Shippable HALB  and Linked FPP- Not Shippable HALB and BUOM other than IT
	                                        if (bdDenominator.compareTo(BigDecimal.ZERO) != 0)
	                                            bdBOMQty = bdNumerator.divide(bdDenominator, 6, RoundingMode.HALF_UP);
	                                        bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);
	                                    }

	                                } else {

	                                    if ((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && (pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM)))) {

	                                        if (UIUtil.isNotNullAndNotEmpty(strReleasedSubFPPSpecSubType) && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strReleasedSubFPPSpecSubType))) {
	                                            //Context FPP- Not Shippable HALB but IT and Linked FPP-Shippable HALB
	                                            bdBOMQty = bdNumerator.multiply(new BigDecimal(strBOMBaseQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);
	                                        }
	                                    } else {
	                                        //Context FPP- Not Shippable HALB but IT and Linked FPP-Shippable HALB
	                                        if (UIUtil.isNotNullAndNotEmpty(strReleasedSubFPPSpecSubType) && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strReleasedSubFPPSpecSubType))) {
	                                            bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));
	                                            bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty);
	                                            bdBOMQty = bdBOMQty.multiply(bdNumerator).setScale(3, BigDecimal.ROUND_HALF_UP);
	                                        }
	                                    }
	                                }
	                            }



	                            //If the calculated quantity is zero or if it is greater than 9999999999.999, then final quantity will be -9.99
	                            if (bdBOMQty.compareTo(BigDecimal.ZERO) == 0 || bdBOMQty.compareTo(bdBOMQuantityCheck) > 0) {
	                                bdBOMQty = new BigDecimal(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED);
	                            }
	                            strListQtyValues.add(bdBOMQty.toString());

	                        }
	                    }
	   
	                    if (pgV3Constants.BULK_INTERMEDIATE_UNIT.equalsIgnoreCase(sChildCOPSpecSubType)) {
	                        mapCOPBulkSubstitutes = getCOPBulkSubstitutes(context, strID, strSubstituteId, strBOMBaseQuantity, bdIntermediateObjectQty, strContextFPPBUOM, strTopNodeSpecSubType, strSubstituteQuantity);
	                        if (null != mapCOPBulkSubstitutes && mapCOPBulkSubstitutes.size() > 0) {
	                            mlReleasedFPP.add(mapCOPBulkSubstitutes);
	                            strListQtyValues.add((String) mapCOPBulkSubstitutes.get(pgV3Constants.MAP_KEY_COP_BULK_SUBS_QUANTITY));

	                            mapCOPBulkSubsAlternates = getCOPBulkSubstitutesAlternates(context, mapCOPBulkSubstitutes);
	                            if (null != mapCOPBulkSubsAlternates && mapCOPBulkSubsAlternates.size() > 0) {

	                                mlReleasedFPP.addAll((MapList) mapCOPBulkSubsAlternates.get("finalMapList"));
	                                strListQtyValues.addAll((StringList) mapCOPBulkSubsAlternates.get("slCOPBulkAltsQtyValues"));
	                            }

	                        }
	                    }
	                    
	                }
	            }
	            mpReturn.put("strListQtyValues", strListQtyValues);
	            mpReturn.put("mlReleasedFPP", mlReleasedFPP);
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	        return mpReturn;
	    }
		
		/**
	    Added by Subhajit for Defect 52840- Start
	     *
	     * @param context
	     * @param strProcessDOB
	     * @param bdIntermediateObjectQty
	     * @return
	     * @throws FrameworkException
	     */
	    private BigDecimal getIntermediateQuantity(Context context, DomainObject strProcessDOB, BigDecimal bdIntermediateObjectQty) throws FrameworkException {

	        MapList childObjConnectedFPP = new MapList();
	        StringList slObjectSelects = new StringList();
	        StringList slRelSelects = new StringList();
	        String strPartQuantity = DomainConstants.EMPTY_STRING;
	        String strPartLevel = DomainConstants.EMPTY_STRING;
	        String strPartType = DomainConstants.EMPTY_STRING;
	        String strPartID = DomainConstants.EMPTY_STRING;
	        String previousLeve = DomainConstants.EMPTY_STRING;

	        slRelSelects.add(DomainConstants.SELECT_ATTRIBUTE_QUANTITY);
	        BigDecimal bdBOMQty = new BigDecimal("1");
	        BigDecimal toSideBOMQty = new BigDecimal("1");

	        DomainObject dobTOSideObject;
	        Pattern pIntermediateObjectType = new Pattern(pgV3Constants.TYPE_PGCONSUMERUNITPART);
	        pIntermediateObjectType.addPattern(pgV3Constants.TYPE_PGCONSUMERUNITPART);
	        pIntermediateObjectType.addPattern(pgV3Constants.TYPE_PGINNERPACKUNITPART);

	        StringList slFPPchildObjList = new StringList();
	        Map mpTemp = new HashMap();
	        childObjConnectedFPP = strProcessDOB.getRelatedObjects(context,
	                pgV3Constants.RELATIONSHIP_EBOM,    // relationship pattern
	                pIntermediateObjectType.getPattern(), // Type pattern
	                slObjectSelects,                // object selects
	                slRelSelects,            // rel selects
	                false,                                // to side
	                true,                                // from side
	                (short) ConstantsUtil.ZERO_LEVEL,                            // recursion level
	                null,                        // object where clause
	                null, 0);
	        if (!childObjConnectedFPP.isEmpty() && childObjConnectedFPP.size() > 0) {
	            Map mpPreviousLevelChildType = new HashMap();
	            for (int i = 0; i < childObjConnectedFPP.size(); i++) {
	                mpTemp = (Map) childObjConnectedFPP.get(i);
	                strPartLevel = (String) mpTemp.get(DomainConstants.SELECT_LEVEL);
	                strPartQuantity = (String) mpTemp.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
	                strPartType = (String) mpTemp.get(DomainConstants.SELECT_TYPE);
	                if (UIUtil.isNotNullAndNotEmpty(strPartQuantity)) {
	                    toSideBOMQty = toSideBOMQty.multiply(new BigDecimal(strPartQuantity));
	                }
	                if (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPartType)) {
	                    break;
	                }
	            }
	            bdBOMQty = bdIntermediateObjectQty.multiply(toSideBOMQty);
	        } else {
	            bdBOMQty = bdIntermediateObjectQty;
	        }
	        return bdBOMQty;
	    }
	    //Added by Subhajit for Defect 52840 - End
		
		/**
		 * getCOPBulkSubstitutesAlternates- Method is used to get APP Alternates Quantities Connected as Substitutes to COP BULK 
		 * @param Context,Map
		 * @return Map - Final Value.
		 * @throws Exception
		 */
		
		
		public Map getCOPBulkSubstitutesAlternates(Context context,Map mCOPBulkSubstituteMap) throws Exception{
			
			StringList slCOPBulkAltsQtyValues = new StringList();
			Map mpAltMap = new HashMap();
			Map mpFinalAltMap = new HashMap();
			MapList finalMapList = new MapList();
			MapList mlSubAlts = new MapList();
			String strSubAltSpecSubType = DomainConstants.EMPTY_STRING;
			try {
				
				String sCOPSubsType = (String)mCOPBulkSubstituteMap.get(DomainConstants.SELECT_TYPE);
				String sCOPSubsID = (String)mCOPBulkSubstituteMap.get(DomainConstants.SELECT_ID);
				String sCOPSubsQty = (String)mCOPBulkSubstituteMap.get(pgV3Constants.MAP_KEY_COP_BULK_SUBS_QUANTITY);
				String sCOPinCOPID = (String)mCOPBulkSubstituteMap.get(pgV3Constants.MAP_KEY_SUBSTITUTE_FLAG_COP_IN_COP);
				
				if(UIUtil.isNotNullAndNotEmpty(sCOPSubsType) && COP_BULK_ALTERNATES_ALLOWED_TYPES.contains(sCOPSubsType)){
				
					mlSubAlts= getAlternates(context,sCOPSubsID);
					for(int i=0;i<mlSubAlts.size();i++){
						mpAltMap = (Map) mlSubAlts.get(i);
						strSubAltSpecSubType = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
						if(!pgV3Constants.THIRD_PARTY.equalsIgnoreCase(strSubAltSpecSubType)) {	
							mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
							mpAltMap.put(pgV3Constants.MAP_KEY_COP_BULK_SUBS_QUANTITY, sCOPSubsQty);
							mpAltMap.put(pgV3Constants.MAP_KEY_SUBSTITUTE_FLAG_COP_IN_COP,sCOPinCOPID);
							finalMapList.add(mpAltMap);
							slCOPBulkAltsQtyValues.add(sCOPSubsQty);
						}
					}
					mpFinalAltMap.put("slCOPBulkAltsQtyValues",slCOPBulkAltsQtyValues);
					mpFinalAltMap.put("finalMapList",finalMapList);
				}
			} catch (Exception e){
				e.printStackTrace();
			}
			return mpFinalAltMap;
		}
		
			/**
		 * getFPPObjectsForCOPBulk- Method is used to get FPP Details of COP BULK 
		 * @param Context,Map
		 * @return MapList - Final Value.
		 * @throws Exception
		 */
		
		
		public MapList getFPPObjectsForCOPBulk(Context context, Map mapCOPDetails) throws Exception
		{
			String strCOPId = (String)mapCOPDetails.get(DomainConstants.SELECT_ID);
			DomainObject doObjectCOP 	= null;
			MapList mlConnectedFPPs = new MapList();
			MapList mlConnectedFPPsCOP = new MapList();
		
			Map mpFPPObjects = new HashMap();
			Map mpTemp = new HashMap();
			String strFPPType = DomainConstants.EMPTY_STRING;
			String strFPPSpecSubType = DomainConstants.EMPTY_STRING;
			
			String strConnectedFPPLevel = DomainConstants.EMPTY_STRING;
			
			String strObjWhere = "current=="+pgV3Constants.STATE_RELEASE+"";			
			
			StringList slEBOMTarget = new StringList(16);
				slEBOMTarget.add(DomainConstants.SELECT_TYPE);
				slEBOMTarget.add(DomainConstants.SELECT_NAME);
				slEBOMTarget.add(DomainConstants.SELECT_REVISION);
				slEBOMTarget.add(DomainConstants.SELECT_ID);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_TITLE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_STATUS); 
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
				slEBOMTarget.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);


			try
			{
				doObjectCOP = DomainObject.newInstance(context, strCOPId);
				//Get all Released FPPs linked to child COP
				mlConnectedFPPs = doObjectCOP.getRelatedObjects(context,
								pgV3Constants.RELATIONSHIP_EBOM, 	// relationship pattern
								pgV3Constants.TYPE_FINISHEDPRODUCTPART+","+pgV3Constants.TYPE_PGCUSTOMERUNITPART+","+pgV3Constants.TYPE_PGINNERPACKUNITPART, // Type pattern
								slEBOMTarget,// object selects
								null,// rel selects 
								true,// to side
								false,// from side
								(short)ConstantsUtil.ZERO_LEVEL,// recursion level
								strObjWhere,// object where clause
								null,0);// rel where clause 

				int mlConnectedFPPsSize = mlConnectedFPPs.size();
				for(int i=0;i<mlConnectedFPPsSize;i++)
				{
					mpTemp = new HashMap();
					mpFPPObjects = (Map)mlConnectedFPPs.get(i);
					strFPPType = (String)mpFPPObjects.get(DomainConstants.SELECT_TYPE);
					strFPPSpecSubType = (String)mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					
					strConnectedFPPLevel = (String)mpFPPObjects.get(DomainConstants.SELECT_LEVEL);
					
					if(pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strFPPType) && (pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(strFPPSpecSubType)) && (parseValue(strConnectedFPPLevel)==2 || parseValue(strConnectedFPPLevel)==3))
					{
					
						mpTemp.putAll(mapCOPDetails);
						mpTemp.put(DomainConstants.SELECT_ID,(String)mpFPPObjects.get(DomainConstants.SELECT_ID));
						mpTemp.put(DomainConstants.SELECT_TYPE,(String)mpFPPObjects.get(DomainConstants.SELECT_TYPE));
						mpTemp.put(DomainConstants.SELECT_NAME,(String)mpFPPObjects.get(DomainConstants.SELECT_NAME));
						mpTemp.put(DomainConstants.SELECT_REVISION,(String)mpFPPObjects.get(DomainConstants.SELECT_REVISION));
						mpTemp.put(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE,(String)mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE));
						mpTemp.put(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE,(String)mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE));
						mpTemp.put(pgV3Constants.SELECT_ATTRIBUTE_TITLE,(String)mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_TITLE));
						mpTemp.put(pgV3Constants.SELECT_ATTRIBUTE_STATUS,(String)mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_STATUS));
						mpTemp.put(pgV3Constants.SELECT_ATTRIBUTE_RELEASE_PHASE,(String)mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_RELEASE_PHASE));
						mpTemp.put(pgV3Constants.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE,(String)mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
						mpTemp.put(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE,(String)mpFPPObjects.get(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE));
							
						mlConnectedFPPsCOP.add(mpTemp);
					}
				}
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			
			return mlConnectedFPPsCOP;
		}
		

		
		/**
		 * getIndividualsFromMaster- Method is used to get individuals connected to master. 
		 * @param context the eMatrix <code>Context</code> object
		 * @param *
		 * @return
		 * @throws Exception 
		 */
		public void getIndividualsFromMaster(Context context, String TSName, String strValidFromDate, String strBOMBaseQty,String strPgPhaseName, String strFindNumber, String strBOMNumber, String strMasterTSType, String strMasterTSName, String strMasterTSRev, String strBOMUsage, String strQuantity, String strUpperLim, String strTarget, String strLowerLim, String strValidFromDateComp, String strPosIndicator, boolean bIncrementAltItem,String strTSID) throws Exception {
					
			String strComponentNumber = DomainConstants.EMPTY_STRING;				
			String strIndSubFlag = DomainConstants.EMPTY_STRING;				
			String strMasterObjectId = DomainConstants.EMPTY_STRING;
			String strRelId = DomainConstants.EMPTY_STRING;
			String strIndObjectId = DomainConstants.EMPTY_STRING;
			String strIndType = DomainConstants.EMPTY_STRING;
			String strIndName = DomainConstants.EMPTY_STRING;
			String strIndRev = DomainConstants.EMPTY_STRING;
			StringList slIndNames= new StringList();
			Map hmMasterDetails = null;
			Map hmIndDetails = null;
			MapList mlIndividuals = null;
			int iIndObjCount=0;
			MapList mlMasterObjectList = null;	
			DomainObject domMaster = null;
			String strChildBUOM = DomainConstants.EMPTY_STRING;
			
			StringList slBusSelect = new StringList(5);
			slBusSelect.add(DomainConstants.SELECT_TYPE);
			slBusSelect.add(DomainConstants.SELECT_NAME);
			slBusSelect.add(DomainConstants.SELECT_REVISION);
			slBusSelect.add(DomainConstants.SELECT_ID);
			slBusSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);


			try{
				
				String strMQLStmt = "temp query bus $1 $2 $3 select $4 dump $5";			
				String strMqlRes = MqlUtil.mqlCommand(context, strMQLStmt, strMasterTSType, strMasterTSName, DomainConstants.QUERY_WILDCARD, DomainObject.SELECT_ID, "|");
				StringList strlResult = new StringList();
				StringList slMasterIds =FrameworkUtil.split(strMqlRes,"\n");
				Iterator itrMasters=slMasterIds.iterator();
				while(itrMasters.hasNext())
				{
					String strMaster=(String)itrMasters.next();
					strlResult = FrameworkUtil.split(strMaster,"|");
					strMasterObjectId=(String)strlResult.get(3);
						
						if (BusinessUtil.isNotNullOrEmpty(strMasterObjectId)) {
							domMaster = DomainObject.newInstance(context,strMasterObjectId);
													
							mlIndividuals = domMaster.getRelatedObjects(context,
											pgV3Constants.RELATIONSHIP_PGMASTER,
											DomainConstants.QUERY_WILDCARD,
											true, 						//getTo
											true, 						//getFrom
											(short)ConstantsUtilIRM.FIRST_LVL, 					// recursionLevel
											//SL_OBJECT_INFO_SELECT, 	//objectSelects
											slBusSelect,
											new StringList(DomainObject.SELECT_RELATIONSHIP_ID), 							//relSelects
											null, 						// busWhereClause,
											null, 						// relWhereClause,
											null, 						// postRelPattern,
											null, 						//postTypePattern
											null);
							
							Iterator itrIndiv = mlIndividuals.iterator();
							while(itrIndiv.hasNext()){
								hmIndDetails = (Hashtable) itrIndiv.next();
								strRelId = (String) hmIndDetails.get(DomainConstants.SELECT_RELATIONSHIP_ID);
								strIndObjectId = (String) hmIndDetails.get(DomainConstants.SELECT_ID);
								strIndType = (String) hmIndDetails.get(DomainConstants.SELECT_TYPE);
								strIndName = (String) hmIndDetails.get(DomainConstants.SELECT_NAME);
								strIndRev = (String) hmIndDetails.get(DomainConstants.SELECT_REVISION);
								strChildBUOM = (String) hmIndDetails.get(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
								strComponentNumber = strIndName;	
								//SPEC : In SR It is not required--START
								//strValidFromDateComp = convertPLMDateToSAP(getEffDateForLatestInd(context, strIndType, strIndName, strMasterTSName));
								//SPEC : In SR It is not required--END
								if (BusinessUtil.isNotNullOrEmpty(strValidFromDateComp)){ 
									if (!slIndNames.contains(strIndName)) {
										buildFCBOMArray(context, strPgPhaseName, strFindNumber, TSName, strBOMUsage, strValidFromDate, strComponentNumber, strQuantity, strIndSubFlag, strUpperLim, strTarget, strLowerLim, strValidFromDateComp, strBOMNumber, strBOMBaseQty, strPosIndicator, strRelId, strMasterTSName, strMasterTSRev, false, strIndObjectId, "","", strChildBUOM);
										slIndNames.add(strIndName);
									}
								}
								iIndObjCount++;
							}
								
						}						
					//}
					
				}
				if (iIndObjCount == 0) {
					_AbortReason = "Aborting because there are no individuals connected to Master " + strMasterTSName + " " + strMasterTSRev;
				}
			}catch(Exception ex){
				
				ex.printStackTrace();
			}
		}
		
		
		
		/**
		 * getSubstitutes- Method is used to get Sustitutes connected to relationship. 
		 * @param context the eMatrix <code>Context</code> object
		 * @param *
		 * @return String[][]
		 * @throws Exception 
		 */
		public String[][] getSubs(Context context, String strRelId) {
			String[][] saReturn = null;
			String strSubsCommand = DomainConstants.EMPTY_STRING; 
			String strMQLSubResult = DomainConstants.EMPTY_STRING; 
			String strSapType = DomainConstants.EMPTY_STRING; 
			String strType = DomainConstants.EMPTY_STRING; 
			String strATS = DomainConstants.EMPTY_STRING; 
			String[] saParts = null;
			String strMQLStmt = DomainConstants.EMPTY_STRING;
			String strMqlRes = DomainConstants.EMPTY_STRING;
			ArrayList<String[]> alSubRows = new ArrayList<String[]>();
			String[] saIds = null;
			
			if (strRelId.equals(""))
				return saReturn;
			try {
				
				strMQLStmt = "print connection $1 select $2 dump $3";			
				strMqlRes = MqlUtil.mqlCommand(context, strMQLStmt, strRelId, "frommid[EBOM Substitute].id", "|");			
				
				if (!strMqlRes.equals("")) {
					saIds = (strMqlRes.trim().split("\\|", -1));
					if (!saIds[0].equals("")) {
						for (int i = 0; i < saIds.length; i++) {						
							strSubsCommand = "print connection $1 select $2 $3 $4 $5 $6 $7 $8 $9 $10 $11 $12 $13 $14 $15 $16 $17 $18 $19 dump $20";
							strMQLSubResult = MqlUtil.mqlCommand(context, strSubsCommand, saIds[i], pgV3Constants.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR, pgV3Constants.SELECT_ATTRIBUTE_PGMINCALCQUANTITY, pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY, pgV3Constants.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY, pgV3Constants.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE, pgV3Constants.SELECT_ATTRIBUTE_PGSUBSTITUTECOMBINATIONNUMBER, "to.name", "to.type", "to."+pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE, "to."+pgV3Constants.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE, "to."+pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE, "to.revision", "to."+pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE, "to.id", "to.from["+pgV3Constants.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION+"]", pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT,pgV3Constants.SELECT_ATTRIBUTE_COMMENT,"to."+pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE,"|");
							
							saParts = (strMQLSubResult.trim().split("\\|", -1));
							strSapType = saParts[12];
							strType = saParts[7];
							//if (saParts.length == 16 )							
								strATS = saParts[14];
							if (strType.startsWith(pgV3Constants.PGMASTER)||(!strSapType.equalsIgnoreCase(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC) && (pgV3Constants.ATTRIBUTE_PGCOSCALCULATE_FALSE.equals(strATS))))
								alSubRows.add(saParts);
						}
					}
					if (alSubRows.size()>0) {
						saReturn = convertArrayListToArray(alSubRows, 17);
						Arrays.sort(saReturn, new Comparator(){
							public int compare(Object obj1, Object obj2)
							{
								int result = 0;

								String[] str1 = (String[]) obj1;
								String[] str2 = (String[]) obj2; 

								/* Sort on Substitute Combination Number */
								Float in1 = Float.valueOf(str1[5]);
								Float in2 = Float.valueOf(str2[5]);
								result = in1.compareTo(in2);

								return result;
							}						
						}); 

						for (int i=0; i<saReturn.length; i++) {
							saReturn[i][5]="";
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
					
			return saReturn;
		}
		
		
		/**
		 * This method returns Maplist of BOM Component for SAP BOM FEED
		 * Gets EBOM, Substitute and Alternates of TUP, APP and DPP.
		 * @param context
		 * @param strObjectID: Object Id
		 * @arg object details
		 * @return Maplist of BOM FEED
		 * @throws Exception
		 */
		public MapList getPartBOMFEEDData(Context context, String strObjectID,String strTopNodeType) throws Exception {
			
			MapList mlFlatBOM = new MapList();
			String strTUPID = DomainConstants.EMPTY_STRING;
			String strPartType = DomainConstants.EMPTY_STRING;
			String strRelWhere = DomainConstants.EMPTY_STRING;
			
			Map mapSub = null;
			Map mpAlternate  = null;
			Map mpCompPart = null;
			
			MapList mlTUPPart = null;
			MapList mlPartChildData = null;
			
			Object substituteId 			= null;
			Object substituteName			= null;
			Object substituteType			= null;
			Object substituteRev			= null;
			Object substituteState			= null;
			Object substituteEffectivityDate= null;
			Object SubstituteValidUntilDate = null;
			Object substituteOptComponent   = null;
			Object substituteRelID    		= null;
			Object substituteComment		= null;
			Object substituteSpecSubType	= null;
			
			Object substituteSAPType	= null;
			
			Object substituteMinQty			= null;
			Object substituteMaxQty			= null;
			Object substituteQty			= null;
			Object oAlternateIds			= null;

			MapList mlSubAlts = null;
			int iAltsSize = 0;
			Map mpAltMap = null;
			
			//String strNONGCASTYPE = EnoviaResourceBundle.getProperty (context, "emxCPN", context.getLocale(), "emxCPN.SAPBOM.DSM.NONGCASTypes");
			String strNONGCASTYPE = "pgPhase,pgCustomerUnitPart,pgInnerPackUnitPart,pgConsumerUnitPart,pgAncillaryPackagingMaterialPart,pgAncillaryRawMaterialPart,pgMasterConsumerUnitPart,pgMasterCustomerUnitPart,pgMasterInnerPackUnitPart,pgMasterPackagingAssemblyPart,pgMasterPackagingMaterialPart,pgMasterRawMaterialPart,pgMasterProductPart,Cosmetic Formulation,Virtual Intermediate,Formulation Phase";//EnoviaResourceBundle.getProperty (context, "emxCPN", context.getLocale(), "emxCPN.SAPBOM.DSM.NONGCASTypes");
			
			try {
				if(BusinessUtil.isNotNullOrEmpty(strObjectID)) {
					DomainObject dObjPart = DomainObject.newInstance(context, strObjectID);				
					if(pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strTopNodeType)) {
						strRelWhere = new StringBuffer(pgV3Constants.SELECT_ATTRIBUTE_PGISPRIMARY).append("==TRUE").toString();
						mlTUPPart = dObjPart.getRelatedObjects(context,
								pgV3Constants.RELATIONSHIP_PGTRANSPORTUNIT,  // Rel Pattern
								pgV3Constants.TYPE_PGTRANSPORTUNITPART,		// Type Pattern
								SL_OBJECT_INFO_SELECT,                  	// bus select
								null,										// Rel select
								false,										// to side
								true,										// from side
								(short)ConstantsUtilIRM.FIRST_LVL,									// recursion level
								null,										// Object Where Clause
								strRelWhere,								// Rel Where Clause
								0);
						if(null != mlTUPPart && mlTUPPart.size() > 0) {
							Map mapTUPData = (Map)mlTUPPart.get(0);
							strTUPID = (String)mapTUPData.get(DomainConstants.SELECT_ID);
						}
						//To get the child of TUP
						mlPartChildData = getTUPBOMData(context,strTUPID);
					} else if (pgV3Constants.TYPE_FABRICATEDPART.equalsIgnoreCase(strTopNodeType) || pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strTopNodeType) || pgV3Constants.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strTopNodeType) || TYPE_INTERMEDIATEPRODUCTPART.equalsIgnoreCase(strTopNodeType)) {
						
						mlPartChildData = getEBOMData(context,strObjectID,strTopNodeType);
						
						//To get the child of FAB, APP and DPP
					}
					if(null != mlPartChildData && mlPartChildData.size() > 0) {
						mlPartChildData.sort(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");
						int isizePartData = mlPartChildData.size();
						StringList slSubstituteIds = null;
						for(int iCount=0;iCount<isizePartData;iCount++) {
							mpCompPart = (Map)mlPartChildData.get(iCount);
							(mpCompPart).put("IsDirectComponent", "true");
							(mpCompPart).put("TUP_ID",strTUPID);
							//Adding the Primary Part
							mlFlatBOM.add(mpCompPart);
							//Include the Substitute of Component
							substituteId  = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
							slSubstituteIds = new StringList();
							if (null != substituteId) {
								//Refactoring - InstanceList - 34
								slSubstituteIds = getInstanceList(substituteId);
							}
							substituteName = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_NAME);
							StringList slSubstituteNames = new StringList();
							if (null != substituteName) {
								//Refactoring - InstanceList - 35
								slSubstituteNames = getInstanceList(substituteName);
							}
							substituteType = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_TYPE);
							StringList slSubstituteTypes = new StringList();
							if (null != substituteType) {
								//Refactoring - InstanceList - 36
								slSubstituteTypes = getInstanceList(substituteType);
							}
							substituteRev = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_REVISION);
							StringList slSubstituteRevs = new StringList();
							if (null != substituteRev) {
								//Refactoring - InstanceList - 37
								slSubstituteRevs = getInstanceList(substituteRev);
							}
							substituteState = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_CURRENT);
							StringList slSubstituteCurrent = new StringList();
							if (null != substituteState) {
								//Refactoring - InstanceList - 38
								slSubstituteCurrent = getInstanceList(substituteState);
							}
							
							//Modified START_EFFECTIVITY to EFFECTIVITY_DATE 
						    substituteEffectivityDate = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_EFFECTIVITY_DATE);
						    
						    StringList slSubstituteEffectivityDate = new StringList();
							if (null != substituteEffectivityDate) {
								//Refactoring - InstanceList - 39
								slSubstituteEffectivityDate = getInstanceList(substituteEffectivityDate);
							}
																			
							
							SubstituteValidUntilDate = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
							StringList slSubstituteValidUntilDate = new StringList();
							if (null != SubstituteValidUntilDate) {
								//Refactoring - InstanceList - 40
								slSubstituteValidUntilDate = getInstanceList(SubstituteValidUntilDate);
							}
							
																		
						    substituteOptComponent = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
							StringList slSubstituteOptComponent = new StringList();
							if (null != substituteOptComponent) {
								//Refactoring - InstanceList - 41
								slSubstituteOptComponent = getInstanceList(substituteOptComponent);
							}
							
							
							substituteRelID = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_REL_ID);
							StringList slSubstituteRelID = new StringList();
							if (null != substituteRelID) {
								//Refactoring - InstanceList - 42
								slSubstituteRelID = getInstanceList(substituteRelID);
							}
							
							substituteComment = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_COMMENT);
							StringList slSubstituteComment = new StringList();
							if (null != substituteComment) {
								//Refactoring - InstanceList - 43
								slSubstituteComment = getInstanceList(substituteComment);
							}else
							{	
								
								int isizeOfSubstituteComponents = slSubstituteRelID.size();
								for(int iSubstitute = 0; iSubstitute < isizeOfSubstituteComponents; iSubstitute++) 
								{
									String strSubstituteRelId = (String)slSubstituteRelID.get(iSubstitute);
									String strComment = DomainRelationship.getAttributeValue(context,strSubstituteRelId,pgV3Constants.ATTRIBUTE_COMMENT);
									if(BusinessUtil.isNullOrEmpty(strComment))
									{
										slSubstituteComment.add(DomainConstants.EMPTY_STRING);
									}
								}
							}
							
							substituteSpecSubType = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
							StringList slSubSpecSubTypes = new StringList();
							if (null != substituteSpecSubType) {
								//Refactoring - InstanceList - 44
								slSubSpecSubTypes = getInstanceList(substituteSpecSubType);
							}
							String strSpecSubType = DomainConstants.EMPTY_STRING;
							
							
							substituteSAPType = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGSAPTYPE);
							StringList slSubSAPTypes = new StringList();
							if (null != substituteSAPType) {
								//Refactoring - InstanceList - 44
								slSubSAPTypes = getInstanceList(substituteSAPType);
							}
							String strSAPType = DomainConstants.EMPTY_STRING;
							
							
							
							substituteMinQty = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_MIN_QUANTITY);
							StringList slSubstituteMinQty = new StringList();
							if (null != substituteMinQty) {
								//Refactoring - InstanceList - 45
								slSubstituteMinQty = getInstanceList(substituteMinQty);
							}
							substituteMaxQty = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_MAX_QUANTITY);
							StringList slSubstituteMaxQty = new StringList();
							if (null != substituteMaxQty) {
								//Refactoring - InstanceList - 46
								slSubstituteMaxQty = getInstanceList(substituteMaxQty);
								/*
								if (substituteMaxQty instanceof StringList) {
									slSubstituteMaxQty = (StringList) substituteMaxQty;
								} else {
									slSubstituteMaxQty.add(substituteMaxQty.toString());
								} */
							}

							substituteQty = (Object) (mpCompPart).get(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
							StringList slSubstituteQty = new StringList();
							if (null != substituteQty) {
								//Refactoring - InstanceList - 47
								slSubstituteQty = getInstanceList(substituteQty);
							}
						
							//Include the Alternates of Component
							oAlternateIds = (Object) (mpCompPart).get(pgV3Constants.SELECT_ALTERNATE_ID);
							StringList slAlternateIds = new StringList();
							if (null != oAlternateIds) {
								//Refactoring - InstanceList - 48
								slAlternateIds = getInstanceList(oAlternateIds);
							}
							for(Object oAlternateId : slAlternateIds) {
								DomainObject dobjAlternate = DomainObject.newInstance(context, (String) oAlternateId);
								mpAlternate = dobjAlternate.getInfo(context,SL_OBJECT_INFO_SELECT);
								
								String strPriAlternateSpecSubType = (String) mpAlternate.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
								if (!(pgV3Constants.THIRD_PARTY.equalsIgnoreCase(strPriAlternateSpecSubType))) {	
								
									(mpAlternate).put(DomainRelationship.SELECT_ID,(String) mpCompPart.get(DomainConstants.SELECT_RELATIONSHIP_ID));
									(mpAlternate).put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
									(mpAlternate).put(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY,(String) mpCompPart.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY));
									(mpAlternate).put("TUP_ID",strTUPID);
									//Adding Alternate Part
									mlFlatBOM.add(mpAlternate);
								}
							}
							
							
							
							if (null != slSubstituteIds) {
								int isizeOfSubstitutes = slSubstituteIds.size();
								for(int iSub = 0; iSub < isizeOfSubstitutes; iSub++) {
									strSpecSubType =  (String)slSubSpecSubTypes.get(iSub);
									
									strSAPType =  (String)slSubSAPTypes.get(iSub);
																	
									String strSubstituteType = (String)slSubstituteTypes.get(iSub);
									
									if(!(pgV3Constants.THIRD_PARTY.equalsIgnoreCase(strSpecSubType)) && (!strSAPType.equalsIgnoreCase(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC))){
									
									
									
										mapSub = new HashMap();
										String strSubstituteId = (String) slSubstituteIds.get(iSub);
										mapSub.put(DomainConstants.SELECT_NAME, (String)slSubstituteNames.get(iSub));
										mapSub.put(DomainRelationship.SELECT_ID, (String)slSubstituteRelID.get(iSub));
										//mapSub.put(DomainConstants.SELECT_ID, (String)slSubstituteIds.get(iSub));
										mapSub.put(DomainConstants.SELECT_ID, strSubstituteId);
										//mapSub.put(DomainConstants.SELECT_TYPE, (String)slSubstituteTypes.get(iSub));
										mapSub.put(DomainConstants.SELECT_TYPE, strSubstituteType);
										mapSub.put(DomainConstants.SELECT_REVISION, (String)slSubstituteRevs.get(iSub));
										mapSub.put(DomainConstants.SELECT_CURRENT, (String)slSubstituteCurrent.get(iSub));
										mapSub.put(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE, (String)slSubstituteEffectivityDate.get(iSub));
										
										mapSub.put(pgV3Constants.ATTRIBUTE_PGVALIDUNTILDATE, (String)slSubstituteValidUntilDate.get(iSub));
										
										mapSub.put(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT, (String)slSubstituteOptComponent.get(iSub));
										mapSub.put(pgV3Constants.SELECT_ATTRIBUTE_COMMENT, (String)slSubstituteComment.get(iSub));
										mapSub.put("relationship", pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE);
										mapSub.put("TUP_ID",strTUPID);
										//Adding the Substitute Part
										mapSub.put(pgV3Constants.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET, (String)slSubstituteMinQty.get(iSub));
										mapSub.put(pgV3Constants.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET, (String)slSubstituteMaxQty.get(iSub));
										mapSub.put(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY, (String)slSubstituteQty.get(iSub));
										
										//COP BULK - Substitute
										if ((pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strSubstituteType)) && UIUtil.isNotNullAndNotEmpty(strSpecSubType) && (pgV3Constants.BULK_INTERMEDIATE_UNIT.equalsIgnoreCase(strSpecSubType))) {
											mlFlatBOM.addAll(getFPPObjectsForCOPBulk(context,mapSub));
										}
										
										if(!(pgV3Constants.THIRD_PARTY.equalsIgnoreCase(strSpecSubType)) && (!strSAPType.equalsIgnoreCase(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC)) && !(strNONGCASTYPE.contains(strSubstituteType))){
										
											mlFlatBOM.add(mapSub);
											
											if(UIUtil.isNotNullAndNotEmpty(strSubstituteType) && ALTERNATE_ALLOWED_TYPES.contains(strSubstituteType)){
												mlSubAlts= getAlternates(context,strSubstituteId);
												iAltsSize = mlSubAlts.size();
												for(int i=0;i<iAltsSize;i++){
													mpAltMap = (Map) mlSubAlts.get(i);
													
													String strSubAltSpecSubType = (String) mpAltMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
													if(!strSubAltSpecSubType.equalsIgnoreCase(pgV3Constants.THIRD_PARTY)) {
																				
														mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
														mpAltMap.put(pgV3Constants.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET, (String)slSubstituteMinQty.get(iSub));
														mpAltMap.put(pgV3Constants.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET, (String)slSubstituteMaxQty.get(iSub));
														mpAltMap.put(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY, (String)slSubstituteQty.get(iSub));
														mpAltMap.put("TUP_ID",strTUPID);
														mlFlatBOM.add(mpAltMap); 
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			} catch(Exception ex) {
				ex.printStackTrace();
				//throw ex;
			}
			return mlFlatBOM;
		}
		
		//CUP Reshipper Quantity Calculation
		private String getReshipperQuantityValue(Context context,DomainObject doObject,boolean isReshipperSub,String strChildQuantity,String strTopNodeBOMQty,String strBUOM, float fQtyMultiplier) throws Exception {
			
			float fChildSAPQty = 1;
			String strListQty	= DomainConstants.EMPTY_STRING;
			String strType  = DomainConstants.EMPTY_STRING;
			try {
				if(doObject != null){
					strType	=doObject.getType(context);
				}
				// Modified by Subhajit for Defect 52877 - Start
	            if (strType.equalsIgnoreCase(pgV3Constants.TYPE_PGCUSTOMERUNITPART)
	                    || strType.equalsIgnoreCase(pgV3Constants.TYPE_PGCONSUMERUNITPART)
	                    || strType.equalsIgnoreCase(pgV3Constants.TYPE_PGINNERPACKUNITPART)) {
	                fQtyMultiplier = 1;
	            }
	         // Modified by Subhajit for Defect 52877 - End

	         // Modified by Subhajit for Defect 52877 - Start
	            if (!(pgV3Constants.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM))) {
	            	// Modified by Subhajit for Defect 52877 - End	
					if(UIUtil.isNotNullAndNotEmpty(strTopNodeBOMQty) && UIUtil.isNotNullAndNotEmpty(strChildQuantity))
					{
						BigDecimal bdfChildSAPQty = BigDecimal.valueOf(fChildSAPQty);
						bdfChildSAPQty = bdfChildSAPQty.multiply(new BigDecimal(strTopNodeBOMQty)).multiply(BigDecimal.valueOf(fQtyMultiplier)).multiply(new BigDecimal(strChildQuantity)).setScale(3, BigDecimal.ROUND_HALF_UP);
						strListQty = String.valueOf(bdfChildSAPQty);
					}
				}

			}catch (Exception e){

				e.printStackTrace();

			}
			return strListQty;
		}	
		
		
		
		/**
		 * 
		 * getSubstituteGroupValue- Method is used to get the Substitute Group value for the given object
		 * @param context the eMatrix <code>Context</code> object
		 * @param String
		 * @param MapList
		 * @return StringList
		 * @throws Exception
		 */

		private StringList getSubstituteGroupValue(Context context, String strObjectID,MapList mpListChildren) throws Exception {

			String strGroup = DomainConstants.EMPTY_STRING;
			float fQTY = 0;

			StringList slGroupValues = new StringList(1);

			try {

				Map mParamList = new  HashMap();
				mParamList.put("objectId", strObjectID);
				
				Map hmArgMapParams = new HashMap();		
				hmArgMapParams.put("objectList", mpListChildren); 
				hmArgMapParams.put("paramList", mParamList);
				
				String[] strArrArgsSubInput= JPO.packArgs(hmArgMapParams);

				// Instead of re-writing the logic, calling the existing method which is being used by the table pgIPMFlatBOMViewTable
				//Vector vBOMGroupData = (Vector) JPO.invoke(context, "pgIPMProductData", null, "getSubstituteFlag", strArrArgsSubInput, Vector.class);
				Vector vBOMGroupData = getSubstituteFlag(context,strArrArgsSubInput);
				if(null != vBOMGroupData && vBOMGroupData.size()>0) {

					for(int k=0;k<vBOMGroupData.size();k++) {

						strGroup = (String)vBOMGroupData.get(k);
						if(BusinessUtil.isNullOrEmpty(strGroup)) {
							strGroup	 = DomainConstants.EMPTY_STRING;
						}
						slGroupValues.add(strGroup);
					}

				}		

			}catch (Exception e) {

				e.printStackTrace();
				slGroupValues = new StringList();
			}		
			return slGroupValues ;
		}

		/**
		 * 
		 * getQuantityValue-Method is used to get the Quantity value for the given object
		 * @param context the eMatrix <code>Context</code> object
		 * @param String
		 * @param Maplist
		 * @return StringList
		 * @throws Exception
		 */

		private StringList getQuantityValue(Context context, String strObjectID,MapList mpListChildren) throws Exception {

			String strQTY = DomainConstants.EMPTY_STRING;
			float fQTY = 0;

			StringList strListQtyValues = new StringList(1);

			try {

				Map mParamList = new  HashMap();
				mParamList.put(pgV3Constants.OBJECT_ID, strObjectID);
				Map hmArgMapParams = new HashMap();		
				hmArgMapParams.put("objectList", mpListChildren); 
				hmArgMapParams.put("paramList", mParamList);
				String[] argsArrQtyInput= JPO.packArgs(hmArgMapParams);

				// Instead of re-writing the logic, calling the existing method which is being used by the table pgIPMFlatBOMViewTable
				//Vector BOMQuantityData = (Vector) JPO.invoke(context, "pgIPMProductData", null, "getBOMQTYData", argsArrQtyInput, Vector.class);
				Vector BOMQuantityData = (Vector)getBOMQTYData(context,argsArrQtyInput);
				if(null != BOMQuantityData && BOMQuantityData.size()>0) {

					for(int k=0;k<BOMQuantityData.size();k++) {

						strQTY = (String)BOMQuantityData.get(k);
						if(BusinessUtil.isNullOrEmpty(strQTY)) {
							strQTY	 = DomainConstants.EMPTY_STRING;
						}
						strListQtyValues.add(strQTY);
					}

				}	

			}catch (Exception e) {

				e.printStackTrace();

			}

			return strListQtyValues ;
		}

		
		/**
		 * 
		 * getBOMQTYDataFPP- Method is used to get the Quantity values for FPP when BUOM is IT. 
		 * @param context the eMatrix <code>Context</code> object
		 * @param Map
		 * @return StringList
		 * @throws Exception
		 * Added as per defect # 10187 
		 */
		public Map getBOMQTYDataFPP(Context context, Map FPPmap,boolean isReshipperSub,StringList slSubstituteInterIdReshipper,String strBUOM) throws Exception
		{
			 
			BigDecimal bdBOMBaseQty = BigDecimal.ZERO;
			BigDecimal bdInterObjRelAttrQty = BigDecimal.ZERO;
			BigDecimal bdBOMQuantityCheck = new BigDecimal("9999999999.999");
			Map mpReturn = new HashMap();
			float fIntermediateSAPQty = 1;
			Vector vc = new Vector();
			StringList strListQtyValues = new StringList(1);
			String strCalcQTY = null;
			DomainObject doCUPObjInter = null;
			DomainObject dObjFPP = null;
			
			StringList slObjectSelect = new StringList(5);
			slObjectSelect.addElement(DomainConstants.SELECT_ID);
			slObjectSelect.addElement(DomainConstants.SELECT_NAME);
			slObjectSelect.addElement(DomainConstants.SELECT_TYPE);
			slObjectSelect.addElement(DomainConstants.SELECT_REVISION);
			slObjectSelect.addElement(DomainConstants.SELECT_LEVEL);
			
			StringList relationshipSelects = new StringList(2);
			relationshipSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			relationshipSelects.add(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
			
			MapList mlFPPChildData = new MapList();
			boolean bFlatReshipper = false;
			String strInterCUPID = DomainConstants.EMPTY_STRING;
			
			try {

				MapList objectList = (MapList)FPPmap.get("objectList");
				HashMap paramList = (HashMap)FPPmap.get("paramList");
				String  strFPPID          = (String) paramList.get("objectId");
				dObjFPP = DomainObject.newInstance(context,strFPPID);

				if(isReshipperSub && slSubstituteInterIdReshipper.size() > 0)
				{
								
					int iSizeOfSubInterm = slSubstituteInterIdReshipper.size();
					for (int iSubInter=0; iSubInter < iSizeOfSubInterm; iSubInter++) {
						strInterCUPID = (String)slSubstituteInterIdReshipper.get(iSubInter);
						doCUPObjInter = DomainObject.newInstance(context, strInterCUPID);
						StringList slIntermediateObjectReshipperType = doCUPObjInter.getInfoList(context,"from[EBOM].to.type");
						if(slIntermediateObjectReshipperType.contains(pgV3Constants.TYPE_PGCONSUMERUNITPART) || slIntermediateObjectReshipperType.contains(pgV3Constants.TYPE_PGINNERPACKUNITPART)) {
							mlFPPChildData = doCUPObjInter.getRelatedObjects(context,
									pgV3Constants.RELATIONSHIP_EBOM,   // rel pattern
									pgV3Constants.TYPE_PGCONSUMERUNITPART+","+pgV3Constants.TYPE_PGCUSTOMERUNITPART+","+pgV3Constants.TYPE_PGINNERPACKUNITPART ,  // type pattern
									slObjectSelect,             // object selects
									relationshipSelects,           //  rel selects 
									false,                             // to side
									true,                              // from side
									(short)ConstantsUtil.ZERO_LEVEL,                          //  recursion level
									null,                       // object where clause
									null);                             //  rel where clause
							}else{
								bFlatReshipper = true;
								
								mlFPPChildData = dObjFPP.getRelatedObjects(context,
								pgV3Constants.RELATIONSHIP_EBOM,  // Rel Pattern

								pgV3Constants.TYPE_PGCONSUMERUNITPART+","+pgV3Constants.TYPE_PGCUSTOMERUNITPART+","+pgV3Constants.TYPE_PGINNERPACKUNITPART ,              //Type Pattern

								slObjectSelect,                  //  bus select

								relationshipSelects,             //   Rel select

								false,							 // to side

								true,                           // from side

								(short)ConstantsUtil.ZERO_LEVEL,					   //  recursion level

								null,						  // Object Where Clause

								null);                       // Rel Where Clause
							}
								
						}
					
					}else{
						mlFPPChildData = dObjFPP.getRelatedObjects(context,
						pgV3Constants.RELATIONSHIP_EBOM,  // Rel Pattern

						pgV3Constants.TYPE_PGCONSUMERUNITPART+","+pgV3Constants.TYPE_PGCUSTOMERUNITPART+","+pgV3Constants.TYPE_PGINNERPACKUNITPART ,              //Type Pattern

						slObjectSelect,                  //  bus select

						relationshipSelects,             //   Rel select

						false,							 // to side

						true,                           // from side

						(short)ConstantsUtil.ZERO_LEVEL,					   //  recursion level

						null,						  // Object Where Clause

						null);                       // Rel Where Clause
					}
				float fltBCF = 0;
				StringList slBCF = new StringList(1);
				slBCF.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);

				Map mapBCF = (Map)dObjFPP.getInfo(context,slBCF);

				float flBOMBaseQty = 0;
				float flPCTBaseQty = 0;

				String strBOMBaseQty = (String)mapBCF.get(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
	            bdBOMBaseQty = new BigDecimal(strBOMBaseQty);

				if(null != objectList && objectList.size() > 0)
				{
				    BigDecimal bdBOMQty = BigDecimal.ZERO;
					String strBOMQty 				= "";
					String strObjectID 				= "";
					String strConnectionID = null;
					String strChildName = null;
					String strChildID = null;
					String strChildType = null;
					String strInterObjRelAttrQty = null;
					String strInterQTY = null;
					String strLevel = null;
					String level = null;
					String strDenominator=null;
					float flNumber 					= 0.0f;
					float fdenominator 				= 0.0f;
					BigDecimal bdNumerator 			= BigDecimal.ZERO;
					BigDecimal bdDenominator        = BigDecimal.ZERO;
					int sizeOfChildData 			= mlFPPChildData.size();
					Map mapTempInter 				= null;
					Map mapTemp 					= null;
					int denoLevel 					= 0;
					float fTemp 					= 1.0f;
					float fTemp1 					= 1.0f;
					int iSizeOfChildDataCOP = sizeOfChildData;
					Map mpTempInterExcludingCOPToCOP 				= null;
					MapList mlFPPChildDataExcludingCOPTOCOP = new MapList();
					Map mpPreviousLevelChildType = new HashMap();
					for(int i=0; i < iSizeOfChildDataCOP; i++)
					{
						mapTempInter = (Map)mlFPPChildData.get(i);
						String strRelAttrQty = (String)mapTempInter.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);				
						String strObjectType = (String)mapTempInter.get(DomainConstants.SELECT_TYPE);	
						String strObjectId = (String)mapTempInter.get(DomainConstants.SELECT_ID);
						mpPreviousLevelChildType.put(i+1,strObjectType);
						if(pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType))
						{
							String strPreviousLevelType = (String)mpPreviousLevelChildType.get(i);
							if(pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousLevelType))
							{
								sizeOfChildData--;
								continue;
							}
						}
						mlFPPChildDataExcludingCOPTOCOP.add(mapTempInter);
					}
					float[] floatArrQTY 			= null;
					float[] floatArrDenominator 	= null;
					String[] strArrLevel 			= null;
					if(isReshipperSub && !bFlatReshipper)
					{
						floatArrQTY 			= new float[sizeOfChildData+1];
						floatArrDenominator 	= new float[sizeOfChildData+1];
						strArrLevel 			= new String[sizeOfChildData+1];
					}else
					{
						floatArrQTY 			= new float[sizeOfChildData];
						floatArrDenominator 	= new float[sizeOfChildData];
						strArrLevel 			= new String[sizeOfChildData];
					}
					int iFPPChildDataCOPTOCOPRelSize = mlFPPChildDataExcludingCOPTOCOP.size();
					for(int i=0; i < iFPPChildDataCOPTOCOPRelSize; i++)
					{
						mpTempInterExcludingCOPToCOP = (Map)mlFPPChildDataExcludingCOPTOCOP.get(i);
						String strRelAttrQty = (String)mpTempInterExcludingCOPToCOP.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
						if(isReshipperSub && !bFlatReshipper)
						{
							floatArrQTY[0] = 1.0f;
							int iSizeOfChildData = sizeOfChildData+1;
							strArrLevel[sizeOfChildData] = String.valueOf(iSizeOfChildData);
							floatArrQTY[i+1] = (Float.valueOf(strRelAttrQty)).floatValue();
							strArrLevel[i] = (String)mpTempInterExcludingCOPToCOP.get("level");
						}else{
							floatArrQTY[i] = (Float.valueOf(strRelAttrQty)).floatValue();
							strArrLevel[i] = (String)mpTempInterExcludingCOPToCOP.get("level");
						}

					}

					//calculate denominator & prepare map for key level & corresponding denominator value 
					int iCount = 0;
					
					if(isReshipperSub && !bFlatReshipper)
					{
						iCount = sizeOfChildData;
					}
					else{
						iCount = sizeOfChildData -1;
					}
					Map denominatorMap = new HashMap();
					String strKey = null;
					for(int i = 0; i<floatArrQTY.length; i++)
					{
						fTemp = 1.0f;
						for(int j=iCount; j>i; j--){
							fTemp1 = floatArrQTY[j] * fTemp;
							fTemp = fTemp1;
						}
						floatArrDenominator[i] = fTemp;				
						strKey = "level"+strArrLevel[i];
						denominatorMap.put(strKey, floatArrDenominator[i]);
					}
					fIntermediateSAPQty = (float) denominatorMap.get("level1");
					for(int i=0; i<objectList.size(); i++)
					{
						strBOMQty = "";
						
						bdBOMQty = BigDecimal.ZERO;
						
						if(pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM))
						{
							strBOMQty = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
						}else{
							mapTemp = (Map)objectList.get(i);
							strConnectionID = (String)mapTemp.get("id[connection]");
							strChildName = (String)mapTemp.get("name");
							strChildID = (String)mapTemp.get("id");
							strChildType = (String)mapTemp.get("type");
							strInterObjRelAttrQty = DomainRelationship.getAttributeValue(context,strConnectionID,pgV3Constants.ATTRIBUTE_QUANTITY);
							strLevel = (String)mapTemp.get("IntermediateLevel");
							
	                        bdInterObjRelAttrQty = new BigDecimal(strInterObjRelAttrQty);
							
							if(null != strChildID && strChildID.length() > 0 && bdInterObjRelAttrQty.compareTo(BigDecimal.ZERO)!=0)
							{
								bdNumerator = bdBOMBaseQty.multiply(bdInterObjRelAttrQty);
								
								if(UIUtil.isNotNullAndNotEmpty(strLevel)){
							    fdenominator=(float) denominatorMap.get("level"+strLevel);
								}
								
							    strDenominator=String.valueOf(fdenominator);
								//calculate BOM Quantity
							    bdDenominator = new BigDecimal(strDenominator);
								if(bdDenominator.compareTo(BigDecimal.ZERO)!=0)
								{
								bdBOMQty = bdNumerator.divide(bdDenominator,3,RoundingMode.HALF_UP);
								}
							}

						strBOMQty = String.valueOf(bdBOMQty);
						if((bdBOMQty.compareTo(BigDecimal.ZERO)==0) || (bdBOMQty.compareTo(bdBOMQuantityCheck)>0))
						{
							strBOMQty = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
						}
						}
						vc.add(strBOMQty);
					}	
				}

				if(null != vc && vc.size()>0) {


					for(int k=0;k<vc.size();k++) {
						strCalcQTY = (String)vc.get(k);
						if(BusinessUtil.isNullOrEmpty(strCalcQTY)) {
							strCalcQTY	 = DomainConstants.EMPTY_STRING;
						}
						strListQtyValues.add(strCalcQTY);
					}

				}


			} catch(Exception ex)
			{
				ex.printStackTrace();
			}

			mpReturn.put("strListQtyValues",strListQtyValues);
			mpReturn.put("fIntermediateSAPQty",fIntermediateSAPQty);
			//return strListQtyValues; 
			return mpReturn;

		}
		

		/**
		 * This method returns Vector of BOM quantity data for TUP Components
		 * @param context
		 * @param strObjectID: Object Id
		 * @param mpListChildren: BOM Feed Data
		 * @arg object details
		 * @return StringList of BOM Quantity
		 * @throws Exception
		 */
		public StringList getTUPBOMQTYData(Context context, String strObjectID,MapList mpListChildren, Float fIntermediateSAPQty,String strBUOM) throws Exception {
			StringList slQtyValues = new StringList(1);
			try {
				
				//float flMCUPQty = 0;
				BigDecimal bdCUPQty = BigDecimal.ZERO;
				//float flBOMBaseQty = 0;
				BigDecimal bdBOMBaseQty = BigDecimal.ZERO;
				BigDecimal bdIntermediateSAPQty=BigDecimal.valueOf(fIntermediateSAPQty); 
				BigDecimal bdBOMQuantityCheck = new BigDecimal("9999999999.999"); 
				//float flNumber = 0;
				BigDecimal bdNumber = BigDecimal.ZERO;
				//float flBOMQty = 0;
				BigDecimal bdBOMQty = BigDecimal.ZERO;
				
				String strCUPQty 		= DomainConstants.EMPTY_STRING;
				String strBOMBaseQty 	= DomainConstants.EMPTY_STRING;
				String strTUPID 		= DomainConstants.EMPTY_STRING;
				String strRelWhere = new StringBuffer(pgV3Constants.SELECT_ATTRIBUTE_PGISPRIMARY).append("==TRUE").toString();
				
				DomainObject dObjFPP = null;
				
				String strCompQty		= null;
				String strBOMQty 		= null;
				String strConnectionID 	= null;
				
				Map mapTemp = null;
				
				MapList mlPart 			= new MapList();
				MapList mlTUPChildData 	= new MapList();
				
				StringList relationshipSelects = new StringList(1);
				relationshipSelects.add(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
				if (BusinessUtil.isNotNullOrEmpty(strObjectID)) {				
					
					dObjFPP = DomainObject.newInstance(context,strObjectID);
					strBOMBaseQty = dObjFPP.getInfo(context,pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);

					// Modified for both are marked as true 
						mlPart = dObjFPP.getRelatedObjects(context,
							pgV3Constants.RELATIONSHIP_PGTRANSPORTUNIT, // Rel Pattern
							pgV3Constants.TYPE_PGTRANSPORTUNITPART,     // Type Pattern
							SL_OBJECT_INFO_SELECT,                  	// Bus select
							null,             							// Rel select
							false,							 			// to side
							true,                           			// from side
							(short)ConstantsUtilIRM.FIRST_LVL,					   				// recursion level
							null,						  				// Object Where Clause
							strRelWhere,0);  							// Rel Where Clause		

					if(null != mlPart && mlPart.size() > 0) {
						Map mapTUPData = (Map)mlPart.get(0);
						strTUPID = (String)mapTUPData.get(DomainConstants.SELECT_ID);
					}
					if (BusinessUtil.isNotNullOrEmpty(strTUPID) ) {
						DomainObject dObjTUP = DomainObject.newInstance(context,strTUPID);
						mlTUPChildData = dObjTUP.getRelatedObjects(context,
								pgV3Constants.RELATIONSHIP_EBOM,  				// Rel Pattern
								pgV3Constants.TYPE_PGMASTERCUSTOMERUNITPART, 	// Type Pattern
								null,                  							// Bus select
								relationshipSelects,             				// Rel select
								false,											// to side
								true,                           				// from side
								(short)ConstantsUtil.ZERO_LEVEL,					   					// recursion level
								null,						  					// Object Where Clause
								null);  										// Rel Where Clause
						if(null != mlTUPChildData && mlTUPChildData.size() > 0) {
							Map mapCUPData = (Map)mlTUPChildData.get(0);
							strCUPQty = (String)mapCUPData.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
						}					
						//Converting Quantity to the float
						//coverting String To BigDecimal
						try {
							if(BusinessUtil.isNotNullOrEmpty(strBOMBaseQty)) {
								//flBOMBaseQty = (Float.valueOf(strBOMBaseQty)).floatValue();
								bdBOMBaseQty = new BigDecimal(strBOMBaseQty);
							}
							if(BusinessUtil.isNotNullOrEmpty(strCUPQty)) {
								//flMCUPQty = (Float.valueOf(strCUPQty)).floatValue();
								bdCUPQty = new BigDecimal(strCUPQty);
							}
						} catch(Exception ex) {
							ex.printStackTrace();
						}
						if(null != mpListChildren) {
							int iObjSize = mpListChildren.size();
							
							for(int i=0;i<iObjSize;i++) {
								if(pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM)){
									strBOMQty = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
								}else{
									//flBOMQty = 0;
									bdBOMQty = BigDecimal.ZERO;
									strBOMQty = "";
									mapTemp = (Map)mpListChildren.get(i);
									strConnectionID = (String)mapTemp.get(DomainRelationship.SELECT_ID);							
									strCompQty = DomainRelationship.getAttributeValue(context,strConnectionID,pgV3Constants.ATTRIBUTE_QUANTITY);

									if(BusinessUtil.isNotNullOrEmpty(strCompQty)) {
										//flNumber = (Float.valueOf(strCompQty)).floatValue();
										bdNumber = new BigDecimal(strCompQty);
									}
									//BOM Quantity Calculation
									//if(flMCUPQty != 0)
									if(bdCUPQty.compareTo(BigDecimal.ZERO)!=0)
										//flBOMQty = (flBOMBaseQty / flMCUPQty) * flNumber;
										bdBOMQty = bdBOMBaseQty.divide(bdCUPQty,5,RoundingMode.HALF_UP);
										bdBOMQty = bdBOMQty.multiply(bdNumber);
									//if(fIntermediateSAPQty > 0)
										//flBOMQty = flBOMQty / fIntermediateSAPQty;
										bdBOMQty = bdBOMQty.divide(bdIntermediateSAPQty,5,RoundingMode.HALF_UP);
									//Convert this float to String
									//strBOMQty = String.valueOf(flBOMQty);
									strBOMQty = String.valueOf(bdBOMQty);
									//if(flBOMQty == 0 || flBOMQty > 9999999999.999) {
									if((bdBOMQty.compareTo(BigDecimal.ZERO)==0) || (bdBOMQty.compareTo(bdBOMQuantityCheck)>0)) {
										strBOMQty = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
									}
									
								}
								slQtyValues.add(strBOMQty);
							}
						}
					}
				}
			} catch(Exception ex) {
				ex.printStackTrace();
				//throw ex;
			}
			return slQtyValues;
		}
		

		/**
		 * This method returns Vector of BOM quantity data for APP/DPP/FAB Components
		 * @param context
		 * @param strObjectID: Object Id
		 * @param mpListChildren: BOM Feed Data
		 * @arg object details
		 * @return MapList of BOM Quantity,Min and Max
		 * @throws Exception
		 */

		public MapList getPartBOMQTYData(Context context, String strObjectID,MapList mpListChildren) throws Exception {
			
			//float flSAPBOMBaseQty = 0;
			BigDecimal bdSAPBOMBaseQty = BigDecimal.ZERO;
			//float flBOMBaseQty = 1;
			BigDecimal bdBOMBaseQty = new BigDecimal("1");
			BigDecimal bdBOMQuantityCheck = new BigDecimal("9999999999.999");
			StringList slBCF = new StringList(2);
			slBCF.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			slBCF.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
			MapList mlMinMaxQtyValues = new MapList();
			DomainObject dObjFPP = null;
			Map mapBCF = null;
			Map mapTemp = null;
			
			String strSAPBOMBaseQty = null;
			String strBOMBaseQty = null;
			String strMinQty = null;
			String strMaxQty = null;
			String strMinVal = null;
			String strMaxVal = null;
			String strBOMQty = null;
			String strQuantityVal = null;
			
			//float fltMinQty = 0;
			BigDecimal bdMinQty = BigDecimal.ZERO;
			//float fltMaxQty = 0;
			BigDecimal bdMaxQty = BigDecimal.ZERO;
			//float flMinQuantity = 0;
			BigDecimal bdMinQuantity = BigDecimal.ZERO;
			//float flMaxQuantity = 0;
			BigDecimal bdMaxQuantity = BigDecimal.ZERO;
			//float fltBOMQty = 0;
			BigDecimal bdBOMQty = BigDecimal.ZERO;
			//float flQuantity = 0;
			BigDecimal bdQuantity = BigDecimal.ZERO;
			try {
		
				if (BusinessUtil.isNotNullOrEmpty(strObjectID)) {
					dObjFPP = DomainObject.newInstance(context,strObjectID);
					mapBCF = (Map)dObjFPP.getInfo(context,slBCF);
					strSAPBOMBaseQty = (String)mapBCF.get(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
					strBOMBaseQty = (String)mapBCF.get(pgV3Constants.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
					if(BusinessUtil.isNotNullOrEmpty(strSAPBOMBaseQty)) {
						//flSAPBOMBaseQty = (Float.valueOf(strSAPBOMBaseQty)).floatValue();
						bdSAPBOMBaseQty = new BigDecimal(strSAPBOMBaseQty);
					}
					if(BusinessUtil.isNotNullOrEmpty(strBOMBaseQty)) {
						//flBOMBaseQty = (Float.valueOf(strBOMBaseQty)).floatValue();
						bdBOMBaseQty = new BigDecimal(strBOMBaseQty);   
					}
					if(null != mpListChildren) {

						for(int i=0;i<mpListChildren.size();i++) {
							mapTemp = (Map)mpListChildren.get(i);
							strQuantityVal 	= (String)mapTemp.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
							strMinVal      	= (String)mapTemp.get(pgV3Constants.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
							strMaxVal		 	= (String)mapTemp.get(pgV3Constants.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
							if(BusinessUtil.isNotNullOrEmpty(strQuantityVal)) {
								//flQuantity = (Float.valueOf(strQuantityVal)).floatValue();
								bdQuantity = new BigDecimal(strQuantityVal);
							}
							//BOM Quantity Calculation
							//if(flBOMBaseQty != 0) {
							if(bdBOMBaseQty.compareTo(BigDecimal.ZERO)!=0) {
								//fltBOMQty = (flSAPBOMBaseQty/flBOMBaseQty)*flQuantity;
								bdBOMQty = bdSAPBOMBaseQty.divide(bdBOMBaseQty,5,RoundingMode.HALF_UP);
								
								bdBOMQty = (bdBOMQty.multiply(bdQuantity)).setScale(3,RoundingMode.HALF_UP);
								
							}
							//Convert this float to String
							//strBOMQty = String.valueOf(fltBOMQty);
							strBOMQty = String.valueOf(bdBOMQty);
							//if(fltBOMQty == 0 || fltBOMQty > 9999999999.999) {
							if((bdBOMQty.compareTo(BigDecimal.ZERO)==0) || (bdBOMQty.compareTo(bdBOMQuantityCheck)>0))
							{
								strBOMQty = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
							}
							if(BusinessUtil.isNotNullOrEmpty(strMinVal)) {
								//flMinQuantity = (Float.valueOf(strMinVal)).floatValue();
								bdMinQuantity = new BigDecimal(strMinVal);
							}
							//BOM Min Calculation
							//if(flBOMBaseQty != 0) {
							if(bdBOMBaseQty.compareTo(BigDecimal.ZERO)!=0) {
								//fltMinQty = (flSAPBOMBaseQty/flBOMBaseQty)*flMinQuantity;
								bdMinQty = bdSAPBOMBaseQty.divide(bdBOMBaseQty,5,RoundingMode.HALF_UP);
								
								bdMinQty = bdMinQty.multiply(bdMinQuantity).setScale(3,RoundingMode.HALF_UP);
								
							}
							//Convert this float to String
							//strMinQty = String.valueOf(fltMinQty);
							strMinQty = String.valueOf(bdMinQty);
							//if(fltMinQty == 0 || fltMinQty > 9999999999.999) {
							if((bdMinQty.compareTo(BigDecimal.ZERO)==0) || (bdMinQty.compareTo(bdBOMQuantityCheck)>0)) {
								strMinQty = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
							}
							if(BusinessUtil.isNotNullOrEmpty(strMaxVal)) {
								//flMaxQuantity = (Float.valueOf(strMaxVal)).floatValue();
								bdMaxQuantity = new BigDecimal(strMaxVal);
							}
							//BOM Max Calculation
							//if(flBOMBaseQty != 0) {
							if(bdBOMBaseQty.compareTo(BigDecimal.ZERO)!=0) {
								//fltMaxQty = (flSAPBOMBaseQty/flBOMBaseQty)*flMaxQuantity;
								bdMaxQty = bdSAPBOMBaseQty.divide(bdBOMBaseQty,5,RoundingMode.HALF_UP);
								
								bdMaxQty = bdMaxQty.multiply(bdMaxQuantity).setScale(3,RoundingMode.HALF_UP);
								
							}
							//Convert this float to String
							//strMaxQty = String.valueOf(fltMaxQty);
							strMaxQty  = String.valueOf(bdMaxQty);
							//if(fltMaxQty == 0 || fltMaxQty > 9999999999.999) {
							if((bdMaxQty.compareTo(BigDecimal.ZERO)==0) || (bdMaxQty.compareTo(bdBOMQuantityCheck)>0)) {
								strMaxQty = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
							}
							Map mpMinMaxQtyValue = new HashMap();
							mpMinMaxQtyValue.put("Qty",strBOMQty);
							mpMinMaxQtyValue.put("MinQty",strMinQty);
							mpMinMaxQtyValue.put("MaxQty",strMaxQty);
							mlMinMaxQtyValues.add(mpMinMaxQtyValue);
							//fltBOMQty = 0;
							bdBOMQty = BigDecimal.ZERO;
							//flQuantity = 0;
							bdQuantity = BigDecimal.ZERO;
							//fltMaxQty = 0;
							bdMaxQty = BigDecimal.ZERO;
							//flMinQuantity = 0;
							bdMinQuantity = BigDecimal.ZERO;
							//flMaxQuantity = 0;
							bdMaxQuantity = BigDecimal.ZERO;
							strBOMQty = DomainConstants.EMPTY_STRING;
							strMinQty = DomainConstants.EMPTY_STRING;
							strMaxQty = DomainConstants.EMPTY_STRING;
							}
							
						}
					}
			} catch(Exception ex) {
				ex.printStackTrace();
				//throw ex;
			}
			return mlMinMaxQtyValues;
		}
		
		
		
		/**
		 * 
		 * calculateMaxMinQtyForFOPChild- Method is used to get the values for Max Min and Qty of Child for Formulation Part.
		 * @param context the eMatrix <code>Context</code> object
		 * @param String,String,String,String
		 * @return StringList
		 * @throws Exception
		 */
		
		private StringList calculateMaxMinQtyForFOPChild(Context context,String strPLBOMRelId, String strSAPBOMBaseQty,String strBaseUOMParent,String strBaseUOMChild,boolean bSubstitute,String SumofDryWeight,String sTargetPercentConsumed) {
		 
			StringList slReturn = new StringList(3);
			final String ATTRIBUTE_TOTAL= PropertyUtil.getSchemaProperty("attribute_Total");
			
			final String SELECT_ATTRIBUTE_TOTAL = "attribute[" + ATTRIBUTE_TOTAL + "].inputvalue";
			
			String strMin = DomainConstants.EMPTY_STRING;
			String strMax = DomainConstants.EMPTY_STRING;
			String strQty = DomainConstants.EMPTY_STRING;
			final String  ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT  = "Maximum Actual Percent Wet";
			final String ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT = "Minimum Actual Percent Wet";

			final String SELECT_ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT = "attribute[" + ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT + "]";
			final String SELECT_ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT = "attribute[" + ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT + "]";
			
			BigDecimal ONE_HUNDRED = new BigDecimal(100);
			
			boolean bProcessingLoss100Percent = false;
			
			boolean bSAPQty = false;
			
			boolean isVISubs = false;
			
			double dBaseQty =  100;
			double dSAPBOMBaseQty =  1000;
			double dPercentWet = 0;
			double dMinimumPercentWet = 0;
			double dMaximumPercentWet = 0;
			double dLoss = 0;
			double dDryPercent = 0;
			double dWeightWeightSAP = 0;
			double dDryWeight = 0;
			
			double dTargetPercentConsumed = 0;
			double dDefaultValue = -9.99;
			double dSubsPrimaryComponentsSubstitutedWetPercentage = 0;
			
			double dSumofDryWeight=0;
			
			double dTargetWeightWet = 0;
			
			DecimalFormat decimalformatter = new DecimalFormat(PATTERN_DECIMALFORMAT);
			
			StringList slSubsPrimaryComponents = new StringList();
			StringList slSubsPrimaryComponentsSubstitutedWetPercent = new StringList();
			StringList slSubsFromType = new StringList();
			
			StringList slBusSelect = new StringList(2);
			slBusSelect.add(DomainConstants.SELECT_ID);
			slBusSelect.add(DomainConstants.SELECT_NAME);
			
			StringList slRelSelect = new StringList(10);
			
			slRelSelect.add("attribute["+pgV3Constants.ATTRIBUTE_QUANTITY+"].inputvalue");
			
			slRelSelect.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			slRelSelect.add(SELECT_ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT);
			slRelSelect.add(SELECT_ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT);
			slRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_LOSS);
			slRelSelect.add(SELECT_ATTRIBUTE_TOTAL);
			slRelSelect.add(pgV3Constants.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
			
			slRelSelect.add(pgV3Constants.SELECT_SUBSTITUTE_PRIMARY_COMPONENTS);
			slRelSelect.add(pgV3Constants.SELECT_PRIMARY_COMPONENT_SUBSTITUTED_WET_PERCENT);
			slRelSelect.add(pgV3Constants.SELECT_SUBSTITUTE_FROM_TYPE);
			
			String strTargetWetValue = DomainConstants.EMPTY_STRING;
			String strTempPhaseName = DomainConstants.EMPTY_STRING;
			String PercentWet = DomainConstants.EMPTY_STRING;
			String MinimumPercentWet = DomainConstants.EMPTY_STRING;
			String MaximumPercentWet = DomainConstants.EMPTY_STRING;
			String strTempLossValue = DomainConstants.EMPTY_STRING;
			String strDryPercentValue = DomainConstants.EMPTY_STRING;
			
			Object objSubsPrimaryComponents	= null;
			Object objSubsFromType	= null;
			String strSubsPrimaryComponentsSubstitutedWetPercentage	= DomainConstants.EMPTY_STRING;
			
			Map mpTempData = null;
			MapList mlPLBOMSub = null;
			StringList slDefaultQTY = new StringList(3);
			slDefaultQTY.add(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED); //BOM Minimum QTY
			slDefaultQTY.add(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED);	//BOM Maximum QTY
			slDefaultQTY.add(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED);	//BOM QTY
			//Base UOM Validation
			/*if(BusinessUtil.isNullOrEmpty(strBaseUOMParent) || BusinessUtil.isNullOrEmpty(strBaseUOMChild) || !strBaseUOMChild.equalsIgnoreCase(strBaseUOMParent) ) {
				return slDefaultQTY;
			}*/
			
			
			if(BusinessUtil.isNullOrEmpty(strBaseUOMParent) || BusinessUtil.isNullOrEmpty(strBaseUOMChild)){

				return slDefaultQTY;
			} else if (BusinessUtil.isNotNullOrEmpty(strBaseUOMParent) && BusinessUtil.isNotNullOrEmpty(strBaseUOMChild) && ((strBaseUOMChild.equalsIgnoreCase(strBaseUOMParent)) || (pgV3Constants.BUOM_EACH.equalsIgnoreCase(strBaseUOMParent) && strBaseUOMChild.equalsIgnoreCase(pgV3Constants.BUOM_KILOGRAM)))) {
				
				bSAPQty = true;	
			} 
			else {
				return slDefaultQTY;
			}
			
			
			if(BusinessUtil.isNotNullOrEmpty(strSAPBOMBaseQty)) {
				dSAPBOMBaseQty = parseValue(strSAPBOMBaseQty);
			}
			
			if(BusinessUtil.isNotNullOrEmpty(SumofDryWeight)) {
				dSumofDryWeight = parseValue(SumofDryWeight);
			}
			BigDecimal bdTotalDryweight = BigDecimal.valueOf(dSumofDryWeight);
			
			if(BusinessUtil.isNotNullOrEmpty(sTargetPercentConsumed)) {
				dTargetPercentConsumed = parseValue(sTargetPercentConsumed);
			}
			BigDecimal bdTargetPercentConsumed =new BigDecimal(dTargetPercentConsumed);
			
		
			if (bSAPQty) {
				try {
					
					if(null != strPLBOMRelId) {
						String sArrRelId[] = new String[1];
						sArrRelId[0] = strPLBOMRelId;
						mlPLBOMSub = (MapList)DomainRelationship.getInfo(context, sArrRelId, slRelSelect);
						if(null != mlPLBOMSub && mlPLBOMSub.size() > 0) {
							mpTempData 		= (Map) mlPLBOMSub.get(0);
							
							PercentWet 			= (String)mpTempData.get("attribute["+pgV3Constants.ATTRIBUTE_QUANTITY+"].inputvalue");
							
							MinimumPercentWet 	= (String)mpTempData.get(SELECT_ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT);
							MaximumPercentWet 	= (String)mpTempData.get(SELECT_ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT);
							strTempLossValue 	= (String)mpTempData.get(pgV3Constants.SELECT_ATTRIBUTE_LOSS);
							strDryPercentValue 	= (String)mpTempData.get(SELECT_ATTRIBUTE_TOTAL);
							strTargetWetValue	= (String)mpTempData.get(pgV3Constants.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
							
							if (bSubstitute) {
								objSubsFromType = (Object)mpTempData.get(pgV3Constants.SELECT_SUBSTITUTE_FROM_TYPE);
								
								if (null != objSubsFromType) {
									slSubsFromType = getInstanceList(objSubsFromType);
								}
								
								if (!slSubsFromType.isEmpty() && slSubsFromType.contains(pgV3Constants.TYPE_VIRTUALINTERMEDIATE)) {
									
									isVISubs = true;
								
								}
							}
							
						
							if(BusinessUtil.isNotNullOrEmpty(PercentWet)) {
								dPercentWet = parseFOPQuantityValue(PercentWet);
							}
							if(BusinessUtil.isNotNullOrEmpty(MinimumPercentWet)) {
								dMinimumPercentWet = parseFOPQuantityValue(MinimumPercentWet);
							}
							if(BusinessUtil.isNotNullOrEmpty(MaximumPercentWet)) {
								dMaximumPercentWet = parseFOPQuantityValue(MaximumPercentWet);
							}
							if(BusinessUtil.isNotNullOrEmpty(strTempLossValue)) {
								dLoss = parseFOPQuantityValue(strTempLossValue);
								
								if(dLoss == 100.0)
								{
									bProcessingLoss100Percent = true;
								}
								
							}
							if(BusinessUtil.isNotNullOrEmpty(strDryPercentValue)) {
								dDryPercent = parseFOPQuantityValue(strDryPercentValue);
							}
							
							if(BusinessUtil.isNotNullOrEmpty(strTargetWetValue)) {
								dTargetWeightWet = parseFOPQuantityValue(strTargetWetValue);
							}
							
						}
				
						BigDecimal bdBaseQTY = BigDecimal.valueOf(dBaseQty);
						BigDecimal bdLoss 	= BigDecimal.valueOf((100-dLoss));
						
						BigDecimal bdTargetWeightWet = BigDecimal.valueOf(dTargetWeightWet);
						

						if(dMinimumPercentWet>0) {
							BigDecimal bdMinQuantityVal=BigDecimal.valueOf(dMinimumPercentWet);
							bdMinQuantityVal = bdMinQuantityVal.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
							if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
								bdMinQuantityVal = (BigDecimal)divideBigDecimalValues(bdMinQuantityVal,bdBaseQTY);
							}
							dMinimumPercentWet = bdMinQuantityVal.doubleValue();
						}
						if(dMaximumPercentWet>0) {
							BigDecimal bdMaxQuantityVal=BigDecimal.valueOf(dMaximumPercentWet);
							bdMaxQuantityVal = bdMaxQuantityVal.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
							if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
								bdMaxQuantityVal = (BigDecimal)divideBigDecimalValues(bdMaxQuantityVal,bdBaseQTY);
							}
							dMaximumPercentWet = bdMaxQuantityVal.doubleValue();
						}

						if(dPercentWet>0) {
							
							BigDecimal bdWeightWeightSAP = BigDecimal.valueOf(dPercentWet);
							
							if (isVISubs) {
								
								bdWeightWeightSAP = bdWeightWeightSAP.multiply(bdTargetPercentConsumed).divide(ONE_HUNDRED);	
								
							}
						   
							if(dLoss == 100.0)
							{
								
								bdWeightWeightSAP = BigDecimal.valueOf(dSAPBOMBaseQty);
								if(bdTotalDryweight.compareTo(BigDecimal.ZERO)!=0) {
									bdWeightWeightSAP = (BigDecimal)divideBigDecimalValues(bdWeightWeightSAP,bdTotalDryweight);
									bdWeightWeightSAP = bdTargetWeightWet.multiply(bdWeightWeightSAP);
								}
								
								else {
									
									bdWeightWeightSAP = BigDecimal.valueOf(dPercentWet);
									bdWeightWeightSAP =  bdWeightWeightSAP.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
									if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
										bdWeightWeightSAP = (BigDecimal)divideBigDecimalValues(bdWeightWeightSAP,bdBaseQTY);
									}
									 
								}
								
								/*
								
								bdWeightWeightSAP = BigDecimal.valueOf(parseFOPQuantityValue(PercentWet));
								
								 */
							}else if(dLoss>0.0){
								if(bdLoss.compareTo(BigDecimal.ZERO)!=0) {
									bdWeightWeightSAP =  bdWeightWeightSAP.multiply(bdLoss);
									bdWeightWeightSAP = (BigDecimal)divideBigDecimalValues(bdWeightWeightSAP,bdLoss);
								}
								bdWeightWeightSAP =  bdWeightWeightSAP.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
								if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
									bdWeightWeightSAP = (BigDecimal)divideBigDecimalValues(bdWeightWeightSAP,bdBaseQTY);
								}	
							}
							else{
								bdWeightWeightSAP =  bdWeightWeightSAP.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
								if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
									bdWeightWeightSAP = (BigDecimal)divideBigDecimalValues(bdWeightWeightSAP,bdBaseQTY);
								}
							}
							dWeightWeightSAP =  bdWeightWeightSAP.doubleValue();
						}
						
						if(dDryPercent>0 && !bProcessingLoss100Percent) {
						
							BigDecimal bdDryWeightSAP = BigDecimal.valueOf(dDryPercent);
							bdDryWeightSAP =  bdDryWeightSAP.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
							if(bdLoss.compareTo(BigDecimal.ZERO)!=0) {
							bdDryWeightSAP = (BigDecimal)divideBigDecimalValues(bdDryWeightSAP,bdLoss);
							}
							dWeightWeightSAP =  bdDryWeightSAP.doubleValue();
						}
						
						if (bSubstitute) {
							
							objSubsPrimaryComponents = (Object)mpTempData.get(pgV3Constants.SELECT_SUBSTITUTE_PRIMARY_COMPONENTS);
							if (null != objSubsPrimaryComponents) {
								slSubsPrimaryComponents = getInstanceList(objSubsPrimaryComponents);
							}
									
							if (slSubsPrimaryComponents.size()>1) {
								dWeightWeightSAP = dDefaultValue;
								dMaximumPercentWet = dDefaultValue;
								dMinimumPercentWet = dDefaultValue;
								
							} else {
								strSubsPrimaryComponentsSubstitutedWetPercentage = (String)mpTempData.get(pgV3Constants.SELECT_PRIMARY_COMPONENT_SUBSTITUTED_WET_PERCENT);
								if(BusinessUtil.isNotNullOrEmpty(strSubsPrimaryComponentsSubstitutedWetPercentage)) {
									dSubsPrimaryComponentsSubstitutedWetPercentage = parseFOPQuantityValue(strSubsPrimaryComponentsSubstitutedWetPercentage);
								}
								BigDecimal bdSubsPrimaryComponentsSubstitutedWetPercentage = BigDecimal.valueOf(dSubsPrimaryComponentsSubstitutedWetPercentage);
								if (bdSubsPrimaryComponentsSubstitutedWetPercentage.compareTo(BigDecimal.ZERO) != 0) {
									
									dWeightWeightSAP = dDefaultValue;
									dMaximumPercentWet = dDefaultValue;
									dMinimumPercentWet = dDefaultValue;
									
								} else {
								
									if(BusinessUtil.isNotNullOrEmpty(strTargetWetValue)) {
									
										if(bdBaseQTY.compareTo(BigDecimal.ZERO) > 0) {
											dTargetWeightWet = parseFOPQuantityValue(strTargetWetValue);
											BigDecimal bdWeightWeightSAP = BigDecimal.valueOf(dSAPBOMBaseQty);
											bdWeightWeightSAP = bdWeightWeightSAP.divide(bdBaseQTY);
											bdWeightWeightSAP = (bdWeightWeightSAP.multiply(BigDecimal.valueOf(dTargetWeightWet))).setScale(3,RoundingMode.HALF_UP);
											dWeightWeightSAP =  bdWeightWeightSAP.doubleValue();
										}
									}
								}							
							}
						}
						
						if(dMinimumPercentWet <= 0 || dMinimumPercentWet > 9999999999.999) {
							strMin = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
						} else {
							strMin = String.valueOf(decimalformatter.format(dMinimumPercentWet));
						}
						if(dMaximumPercentWet <= 0 || dMaximumPercentWet > 9999999999.999) {
							strMax = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
						} else {
							strMax = String.valueOf(decimalformatter.format(dMaximumPercentWet));
						}
						if(dWeightWeightSAP <= 0 || dWeightWeightSAP > 9999999999.999) {
							strQty = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
						} else {
							strQty = String.valueOf(decimalformatter.format(dWeightWeightSAP));
						}
						slReturn.add(strMin);
						slReturn.add(strMax);
						slReturn.add(strQty);
					}
					//Dry Wt for SAP BOM Base Qty = Dry % * SAP BOM Base Qty
					//Wet Weight for SAP BOM Base Qty= Dry Weight for SAP BOM Base Qty/ ( 1- % Loss)
				} catch(Exception e) {
					e.printStackTrace();
					//Sent the default QTY data
					return slDefaultQTY;
				}
				
			}
			return slReturn;
		}

		/**
		 * getCOPBulkSubstitutes- Method is used to get APP/DPP/PAP Details Connected as Substitutes to COP BULK 
		 * @param *
		 * @return Map - Final Value.
		 * @throws Exception
		 */
		
		
		public Map getCOPBulkSubstitutes (Context context,String strID,String strSubstituteId, String strBOMBaseQuantity, BigDecimal bdIntermediateObjectQty,String sContextFPPBUOM,String sTopNodeSpecSubType,String strSubstituteQuantity) throws Exception {
			
			String sQuantity = DomainConstants.EMPTY_STRING;
			String sCOPSubsType = DomainConstants.EMPTY_STRING;
			String sCOPSubsSpecSubType = DomainConstants.EMPTY_STRING;
			String strIntermediateObjQty = DomainConstants.EMPTY_STRING;
			
			BigDecimal bdSubsQuantity = new BigDecimal("1");
			Map mapDetailsCOPCub = new HashMap();
		
			
			StringList slObjectSelects = new StringList(8);
				slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainConstants.SELECT_NAME);
				slObjectSelects.add(DomainConstants.SELECT_CURRENT);
				slObjectSelects.add(DomainConstants.SELECT_TYPE);
				slObjectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slObjectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slObjectSelects.add(pgV3Constants.SELECT_COP_BULK_SUBSTITUTE_QUANTITY);
				slObjectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
			try {
				
				DomainObject doObjectCOPSub = DomainObject.newInstance(context, strSubstituteId);
				if (doObjectCOPSub != null) {
					mapDetailsCOPCub = doObjectCOPSub.getInfo(context, slObjectSelects);
					sCOPSubsType = (String)mapDetailsCOPCub.get(DomainConstants.SELECT_TYPE);
					sCOPSubsSpecSubType = (String)mapDetailsCOPCub.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					
					//strIntermediateObjQty = (String)mapDetailsCOPCub.get(pgV3Constants.SELECT_COP_BULK_SUBSTITUTE_QUANTITY);
					strIntermediateObjQty = strSubstituteQuantity;
					
					if(UIUtil.isNotNullAndNotEmpty(strIntermediateObjQty)){					
						bdSubsQuantity = bdSubsQuantity.multiply(new BigDecimal(strIntermediateObjQty));
					}
					
					if ((pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(sCOPSubsType) || pgV3Constants.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(sCOPSubsType) || pgV3Constants.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(sCOPSubsType)) && !(pgV3Constants.THIRD_PARTY.equalsIgnoreCase(sCOPSubsSpecSubType))) {
					
						sQuantity = getCOPBulkSubstitutesQuantity(bdSubsQuantity,bdIntermediateObjectQty,sContextFPPBUOM,strBOMBaseQuantity,sTopNodeSpecSubType);
							
						mapDetailsCOPCub.put(pgV3Constants.MAP_KEY_COP_BULK_SUBS_QUANTITY,sQuantity);
						mapDetailsCOPCub.put(pgV3Constants.MAP_KEY_SUBSTITUTE_FLAG_COP_IN_COP,strID);
						mapDetailsCOPCub.put("relationship", pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE);
					} else {
						mapDetailsCOPCub = new HashMap();	
					}
				}
			} catch (Exception e){
				e.printStackTrace();
			}
			return mapDetailsCOPCub;
		}
		
		
		/**
		 * getCOPBulkSubstitutesQuantity- Method is used to get APP/DPP/PAP Quantities Connected as Substitutes to COP BULK 
		 * @param *
		 * @return String - Final Value.
		 * @throws Exception
		 */
		
		
		public String getCOPBulkSubstitutesQuantity(BigDecimal bdSubsQuantity,BigDecimal bdIntermediateObjectQty,String sContextFPPBUOM,String strBOMBaseQuantity,String sTopNodeSpecSubType) throws Exception {
			String strBUoMITBPMP = pgV3Constants.BASEUNITOFMEASURE_IT + "|" + pgV3Constants.BASEUNITOFMEASURE_MP + "|" + pgV3Constants.BASEUNITOFMEASURE_BP;
			String sQuantity = DomainConstants.EMPTY_STRING;
			BigDecimal bdBOMQty = new BigDecimal("1");
			BigDecimal bdBOMQuantityCheck = new BigDecimal("9999999999.999");
			try {
				if(pgV3Constants.BASEUNITOFMEASURE_SW.equalsIgnoreCase(sContextFPPBUOM) || pgV3Constants.BASEUNITOFMEASURE_SP.equalsIgnoreCase(sContextFPPBUOM))
				{
					sQuantity = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
				} else if (strBUoMITBPMP.contains(sContextFPPBUOM) || pgV3Constants.SHIPPABLE_HALB.equalsIgnoreCase(sTopNodeSpecSubType)) {
					//Formula IT/BP/MP or Shippable HALB: SAP BOM Quantity = (BOM Base Quantity * Substitute Quantity)
					bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));
					bdBOMQty = bdBOMQty.multiply(bdSubsQuantity).setScale(3, BigDecimal.ROUND_HALF_UP);
					
				} else {
					//Formula CS& Others : SAP BOM Quantity = (BOM Base Quantity * Substitute Quantity * Intermediate Quantity)
					bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));
					bdBOMQty = bdBOMQty.multiply(bdSubsQuantity);
					bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty).setScale(3, BigDecimal.ROUND_HALF_UP);
				}
				
				if((bdBOMQty.compareTo(BigDecimal.ZERO)==0) || (bdBOMQty.compareTo(bdBOMQuantityCheck)>0))
				{
					sQuantity = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
				}
				
				if (!sQuantity.equalsIgnoreCase(pgV3Constants.STR_DEFAULT_QTY_IF_FAILED)) {
					sQuantity = bdBOMQty.toPlainString();
				}
			} catch (Exception e){
				e.printStackTrace();
			}
			return sQuantity;
		}
		
		
		/**
		 * getFinalFormulationProcessDetails- Method is used to get Formulation Process Data 
		 * @param context the eMatrix <code>Context</code> object
		 * @param input - String
		 * @return String - Final Value : Object ID.
		 */
		 
		public String getFinalFormulationProcessDetails (Context context,String strID) throws Exception {
				
				int iRevisionIndex;
				boolean isAllvaluesProd = false;
				
				Map mpFormulationProcessDetails	= new HashMap();
						
				Object oFormulationProcessID		= null;
				Object oRelOriginated				= null;
				Object oReleasePhaseValue			= null;
				Object oFormulationProcessRevision	= null;
				
				String strFinalFormulationProcessID = DomainConstants.EMPTY_STRING;
						
				StringList slFormulationProcessObjectSelects = new StringList(4);	
					slFormulationProcessObjectSelects.addElement(pgV3Constants.SELECT_FORMULATION_PROCESS_ID);	
					slFormulationProcessObjectSelects.addElement(pgV3Constants.SELECT_FORMULATION_PROCESS_REVISION);
					slFormulationProcessObjectSelects.addElement(pgV3Constants.SELECT_FORMULATION_PROCESS_RELEASE_PHASE);
					slFormulationProcessObjectSelects.addElement(pgV3Constants.SELECT_FORMULATION_PROCESS_ORIGINATED);
			try {
				
				mpFormulationProcessDetails = getInfoList(context, strID, slFormulationProcessObjectSelects);
		
				oFormulationProcessID = (mpFormulationProcessDetails).get(pgV3Constants.SELECT_FORMULATION_PROCESS_ID);
				StringList slFormulationProcessID 	= new StringList();
						
				if (null != oFormulationProcessID) {
					slFormulationProcessID = getInstanceList(oFormulationProcessID);
				}
						
				oRelOriginated = (Object) (mpFormulationProcessDetails).get(pgV3Constants.SELECT_FORMULATION_PROCESS_ORIGINATED);
				StringList slRelOriginated	= new StringList();

				if (null != oRelOriginated) {
					slRelOriginated = getInstanceList(oRelOriginated);
				}
						
				oReleasePhaseValue = (Object) (mpFormulationProcessDetails).get(pgV3Constants.SELECT_FORMULATION_PROCESS_RELEASE_PHASE);
				StringList slReleasePhaseValues	= new StringList();

				if (null != oReleasePhaseValue) {
					slReleasePhaseValues = getInstanceList(oReleasePhaseValue);
				}
				
				oFormulationProcessRevision	= (Object) (mpFormulationProcessDetails).get(pgV3Constants.SELECT_FORMULATION_PROCESS_REVISION);
				
				StringList slFormulationProcessRevision = new StringList();

				if (null != oFormulationProcessRevision) {
					slFormulationProcessRevision = getInstanceList(oFormulationProcessRevision);			
				}

				int iSizeOfFormulationProcess = slFormulationProcessID.size();
						
				if (null != slFormulationProcessID && iSizeOfFormulationProcess > 0) {
					
					isAllvaluesProd = Collections.frequency(slReleasePhaseValues, pgV3Constants.ATTRIBUTE_STAGE_PRODUCTION_VALUE) == slReleasePhaseValues.size();			
								
					for (int iF = 0; iF < iSizeOfFormulationProcess; iF++) {				
						strFinalFormulationProcessID = (String)slFormulationProcessID.get(iF);
					}	
							
					if (isAllvaluesProd && iSizeOfFormulationProcess > 1) {
						iRevisionIndex = getIndexHighestRevisionConnected(slFormulationProcessRevision);
						strFinalFormulationProcessID = (String)slFormulationProcessID.get(iRevisionIndex);
					}
				}
			
			} catch (Exception e){

				e.printStackTrace();
			}
			return strFinalFormulationProcessID;
		}
		 
		

		
		 
		public int getIndexHighestRevisionConnected (StringList slFormulationProcessRevision) throws Exception {
			
			int maxVal;
			int maxIdx = -1;
			
			try {
				ArrayList<Integer> intList = new ArrayList<Integer>();
				for(String s : slFormulationProcessRevision) {
					intList.add(Integer.valueOf(s));
				}
				
				if (!intList.isEmpty()) {
					maxVal = Collections.max(intList); // should return 7
					maxIdx = intList.indexOf(maxVal); // should return 2 (position of the value 7)
				}
				
			} catch (Exception e){
				e.printStackTrace();
			}
			return maxIdx;
		}
		
		
		/**
		 * getVITargetPercentConsumed- Method is used to get VI Percentage 
		 * @param context the eMatrix <code>Context</code> object
		 * @param input - boolean
		 * @param input - String
		 * @return String - Final Value
		*/
		
		
		public String getVITargetPercentConsumed (Context context,boolean isFixed,String SRelID) throws Exception {
			String sPercent = DomainConstants.EMPTY_STRING;
			String quantityInVI = DomainConstants.EMPTY_STRING;
			String currentQuantity = DomainConstants.EMPTY_STRING;
			DomainObject domVI = null;
			try {
				DomainRelationship domEBOMRel = new DomainRelationship(SRelID);
				Map attributeMap = domEBOMRel.getAttributeMap(context, true);
				String viPhysicalId =(String) attributeMap.get(FormulationAttribute.VIRTUAL_INTERMEDIATE_PHYSICAL_ID.getAttribute(context));
				
				if(UIUtil.isNotNullAndNotEmpty(viPhysicalId)){
					
					if (!isFixed) {
						
						quantityInVI = (String) attributeMap.get(FormulationAttribute.TARGET_PERCENT_WET_IN_VIRTUAL_INTERMEDIATE.getAttribute(context));
						currentQuantity = (String) attributeMap.get(FormulationAttribute.QUANTITY.getAttribute(context));
						double dQuantityInVI = Double.parseDouble(quantityInVI);
						if (dQuantityInVI > 0) {
							double targetPercent = (Double.parseDouble(currentQuantity)/dQuantityInVI)*100.0;
							sPercent = Double.toString(targetPercent);
						}
					} else {
						domVI = DomainObject.newInstance(context, viPhysicalId);	
						sPercent = domVI.getInfo(context,pgV3Constants.SELECT_ATTRIBUTE_TARGET_PERCENT_AS_CONSUMED);
					}
				}
			} catch (Exception e){
				e.printStackTrace();
			}
			
			return sPercent;
		}
		
		/**
		 * This method returns Maplist of BOM Component for SAP BOM FEED
		 * @param context
		 * @param strObjectID: Object Id
		 * @arg object details
		 * @return Maplist of BOM FEED
		 * @throws Exception
		 */
		public MapList getEBOMData(Context context, String strObjectID,String strTopNodeType) throws Exception {
			MapList mlBOM = new MapList();
			MapList mlEBOMTemp = new MapList();
			
			MapList mlAPPDPPCOPBulk = new MapList();
			
			
			DomainObject dObjPart = null;
			//String strNONGCASTYPE = EnoviaResourceBundle.getProperty (context, "emxCPN", context.getLocale(), "emxCPN.SAPBOM.DSM.NONGCASTypes");
			String strNONGCASTYPE = "pgPhase,pgCustomerUnitPart,pgInnerPackUnitPart,pgConsumerUnitPart,pgAncillaryPackagingMaterialPart,pgAncillaryRawMaterialPart,pgMasterConsumerUnitPart,pgMasterCustomerUnitPart,pgMasterInnerPackUnitPart,pgMasterPackagingAssemblyPart,pgMasterPackagingMaterialPart,pgMasterRawMaterialPart,pgMasterProductPart,Cosmetic Formulation,Virtual Intermediate,Formulation Phase";
			String strObjectWhere = new StringBuffer(DomainObject.SELECT_CURRENT).append( " != ").append(pgV3Constants.STATE_PART_OBSOLETE).toString();
			String strSpecSubType = DomainConstants.EMPTY_STRING;
			String strSAPType 	  = DomainConstants.EMPTY_STRING;
			String strChildType   = DomainConstants.EMPTY_STRING;
			
			String strChildPartSpecSubType = DomainConstants.EMPTY_STRING;
			
			String strExpandBOMonSAPBOMasFed = DomainConstants.EMPTY_STRING;
			
			
			Map mpBOMData = null;
			
			try {
				if(BusinessUtil.isNotNullOrEmpty(strObjectID)) {
					dObjPart = DomainObject.newInstance(context, strObjectID);
					mlEBOMTemp =  dObjPart.getRelatedObjects(context,
							pgV3Constants.RELATIONSHIP_EBOM, 	//relationshipPattern
							//pgV3Constants.SYMBOL_STAR, 			//typePattern
							DomainConstants.QUERY_WILDCARD,		//typePattern
							false, 								//getTo
							true, 								//getFrom
							(short)ConstantsUtilIRM.FIRST_LVL, 							//recurseToLevel
							SL_OBJECT_INFO_SELECT, 				//objectSelects
							SL_RELATION_INFO_SELECT_EBOM, 		//relationshipSelects
							strObjectWhere, 					//objectWhere
							null, 								//relationshipWhere
							null,								//PostRelPattern
							null,								//PostTypePattern
							null);
				//Code to exclude NON-GCAS Parts
				if(null !=mlEBOMTemp) {
					int iMLBOMSize = mlEBOMTemp.size();
					for(int j=0;j<iMLBOMSize;j++) {
						mpBOMData = (Map)mlEBOMTemp.get(j);
						strSAPType = (String)mpBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
						strChildType = (String)mpBOMData.get(DomainConstants.SELECT_TYPE);
						String strChildID = (String)mpBOMData.get(DomainConstants.SELECT_ID);
						
						//COP BULK - BOM COmponent APP/DPP/FAB
						strChildPartSpecSubType = (String)mpBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
						if ((pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strTopNodeType) || pgV3Constants.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strTopNodeType)) && pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strChildType) && UIUtil.isNotNullAndNotEmpty(strChildPartSpecSubType) && pgV3Constants.BULK_INTERMEDIATE_UNIT.equalsIgnoreCase(strChildPartSpecSubType)) {	
							
							mlAPPDPPCOPBulk = getFPPObjectsForCOPBulk(context,mpBOMData);
							if (!mlAPPDPPCOPBulk.isEmpty()){
								mlBOM.addAll(mlAPPDPPCOPBulk);
							}
						}
						
						boolean bExpandFAB = false;
						if(UIUtil.isNotNullAndNotEmpty(strChildType)&& strChildType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART))
						{
							strExpandBOMonSAPBOMasFed = (String)mpBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED);
							if (UIUtil.isNotNullAndNotEmpty(strExpandBOMonSAPBOMasFed)&& strExpandBOMonSAPBOMasFed.equalsIgnoreCase("TRUE")) {
								bExpandFAB = true;	
							}
						}
						
						strSpecSubType = (String)mpBOMData.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
						if(!(strNONGCASTYPE.contains(strChildType)) && !(pgV3Constants.THIRD_PARTY).equals(strSpecSubType)) {
						
						if ( UIUtil.isNotNullAndNotEmpty(strChildType) && !(strChildType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART)&& bExpandFAB)) {
							mlBOM.add(mpBOMData);
						}
						else {
							dObjPart = DomainObject.newInstance(context, strChildID);
							MapList mlEBOMChildTemp =  dObjPart.getRelatedObjects(context,
									pgV3Constants.RELATIONSHIP_EBOM, 	//relationshipPattern
									//pgV3Constants.SYMBOL_STAR, 			//typePattern
									DomainConstants.QUERY_WILDCARD,		//typePattern
									false, 								//getTo
									true, 								//getFrom
									(short)ConstantsUtilIRM.FIRST_LVL, 							//recurseToLevel
									SL_OBJECT_INFO_SELECT, 				//objectSelects
									SL_RELATION_INFO_SELECT_EBOM, 		//relationshipSelects
									strObjectWhere, 					//objectWhere
									null, 								//relationshipWhere
									null,								//PostRelPattern
									null,								//PostTypePattern
									null);
							int imlEBOMChildTempSize = mlEBOMChildTemp.size();
							for(int o=0;o<imlEBOMChildTempSize;o++) 
							{
									Map mpBOMChildData = (Map)mlEBOMChildTemp.get(o);
									String strSAPChildType = (String)mpBOMChildData.get(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
									String strSpecSubChildType = (String)mpBOMChildData.get(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
									String strFABChildType = (String)mpBOMChildData.get(DomainConstants.SELECT_TYPE);
									if(!(pgV3Constants.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSAPChildType)) && !(strNONGCASTYPE.contains(strFABChildType)) && !(pgV3Constants.THIRD_PARTY).equals(strSpecSubChildType))  
									{
										mlBOM.add(mpBOMChildData);		
									}
							 }
							
						}
						
							} 
						}
					}
				}
			} catch(Exception ex) {
				ex.printStackTrace();
				throw ex;
			}
			return mlBOM;
		}
		
		

		/**
		 * getBOMAlternateSubstituteGrouping- Method is used to get Alternate and Substitutes grouping. 
		 * @param context the eMatrix <code>Context</code> object
		 * @param ArrayList of all BOM components
		 * @return ArrayList of all BOM components updated with proper substitute grouping.
		 * @throws Exception 
		 */
		public ArrayList getBOMAlternateSubstituteGrouping(Context ctx, ArrayList alBOM){		
			
			ArrayList tempAllBOM = new ArrayList();
			String strParentObjId = "";
			String strObjId = "";
			int ichildObjCount = 0;
			String strTempId="";
			boolean bIncGrouping = true;		
			char _cAltItem1 = '9';
			char _cAltItem2 = 'A';
			if (alBOM != null) {			
				Iterator itr = alBOM.iterator();			
				while (itr.hasNext()) {
					String[] saTempBOM = (String[]) itr.next();
					strObjId = saTempBOM[DISPLAY_OBJECT_ID];
					strParentObjId = (String)hmChildObjects.get(strObjId);
					ichildObjCount = (int)hmParentObjects.get(strParentObjId);
					if(ichildObjCount>1){
						if(!bIncGrouping && !strTempId.equals(strParentObjId)){
							if (_cAltItem2 == 'Z') {
								_cAltItem2 = 'A';
								_cAltItem1--;
							} else {
								_cAltItem2++;				
							}
						}
						bIncGrouping=false;
						saTempBOM[pgV3Constants.INDEX_SUBSTITUTE_FLAG]=_cAltItem1 + "" + _cAltItem2;
						saTempBOM[pgV3Constants.INDEX_USAGE_PROBABILITY] = pgV3Constants.VALUE_USAGE_PROBABILITY;
					}else{
						saTempBOM[pgV3Constants.INDEX_SUBSTITUTE_FLAG]="";
						saTempBOM[pgV3Constants.INDEX_USAGE_PROBABILITY] ="";
					}
					tempAllBOM.add(saTempBOM);
					strTempId=strParentObjId;
				}
			}
			return tempAllBOM;		
		}
		
		/**
		 * This method returns Maplist of TUP BOM Component for SAP BOM FEED
		 * @param context
		 * @param strObjectID: Object Id
		 * @arg object details
		 * @return Maplist of BOM FEED
		 * @throws Exception
		 */
		public MapList getTUPBOMData(Context context, String strObjectID) throws Exception {
			MapList mlBOM = new MapList();
			String strObjectWhere = new StringBuffer(DomainObject.SELECT_CURRENT).append( " != ").append(pgV3Constants.STATE_PART_OBSOLETE).toString();
			DomainObject dObjTUP = null;
			Pattern pObjectType = new Pattern(pgV3Constants.TYPE_RAWMATERIALPART);
			pObjectType.addPattern(pgV3Constants.TYPE_PACKAGINGMATERIALPART);
			pObjectType.addPattern(pgV3Constants.TYPE_PGRAWMATERIAL);
			pObjectType.addPattern(pgV3Constants.TYPE_PGPACKINGMATERIAL);
			try {
				if(BusinessUtil.isNotNullOrEmpty(strObjectID)) {
					dObjTUP = DomainObject.newInstance(context,strObjectID);
					mlBOM =  dObjTUP.getRelatedObjects(context,
							pgV3Constants.RELATIONSHIP_EBOM, 	//relationshipPattern
							//"*", 								//typePattern
							DomainConstants.QUERY_WILDCARD, 	//typePattern
							false, 								//getTo
							true, 								//getFrom
							(short)ConstantsUtil.ZERO_LEVEL, 							//recurseToLevel
							SL_OBJECT_INFO_SELECT, 				//objectSelects
							SL_RELATION_INFO_SELECT_EBOM, 		//relationshipSelects
							strObjectWhere, 					//objectWhere
							null, 								//relationshipWhere
							null,								//PostRelPattern
							pObjectType.getPattern(),			//PostTypePattern
							null);
				}
			} catch(Exception ex) {
				ex.printStackTrace();
				//throw ex;
			}
			return mlBOM;
		}
		
		public BigDecimal divideBigDecimalValues(BigDecimal bdNum , BigDecimal bdDen) {	
		      try{
					if(bdDen.compareTo(BigDecimal.ZERO)!=0) {
						bdNum = bdNum.divide(bdDen,3,RoundingMode.HALF_UP);
					}
				}
				catch(ArithmeticException ae){
					bdNum = bdNum.divide(bdDen,3,RoundingMode.HALF_UP);
				}
				return bdNum;
			}
		
		public static Map getInfoList(Context var0, String var1, StringList var2) throws FrameworkException {
			MapList var3 = getInfoList(var0, StringList.create(new String[]{var1}), var2);
			return (Map) (var3.size() > 0 ? (Map) var3.get(0) : new HashMap());
		}
		
	
		public static MapList getInfoList(Context var0, StringList var1, StringList var2) throws FrameworkException {
			new MapList();

			try {
				String[] var4 = toStringArray(var1);
				MapList var3 = toMapList(BusinessObject.getSelectBusinessObjectData(var0, var4, var2), var2);
				return var3;
			} catch (MatrixException var5) {
				throw new FrameworkException(var5);
			}
		}
		
		public static String[] toStringArray(Collection var0) {
			return (String[]) ((String[]) var0.toArray(new String[0]));
		}

		
		private static MapList toMapList(BusinessObjectWithSelectList var0, StringList var1) {
			MapList var2 = new MapList(var0.size());
			StringList var3 = isNullOrEmpty((List) var1) ? new StringList() : var1;
			BusinessObjectWithSelectItr var4 = new BusinessObjectWithSelectItr(var0);

			while (var4.next()) {
				BusinessObjectWithSelect var5 = var4.obj();
				HashMap var6 = new HashMap(var5.getHashtable().size());
				Iterator var7 = var5.getHashtable().keySet().iterator();

				while (var7.hasNext()) {
					String var8 = (String) var7.next();
					var6.put(var8, var3.contains(var8) ? var5.getSelectDataList(var8) : var5.getSelectData(var8));
				}

				var2.add(var6);
			}

			return var2;
		}
		
		public static boolean isNullOrEmpty(List var0) {
			return var0 == null || var0.isEmpty();
		}
		
		
		/**
		* getVISubstituteDetails- Method is used to get VI Substitutes 
		* @param context the eMatrix <code>Context</code> object
		* @param input - String
		* @param input - String
		* @return Map - Final Value
		*/
		
		public Map getVISubstituteDetails (Context context , String sVIObjID , String strIngredientId) throws Exception {

			DomainObject domVIObj 		= new DomainObject(sVIObjID);
			Map mapVISubstituteDetails 	= new HashMap();
			Map mpTempChildData 		= new HashMap();
			Map mpPLBOMData 			= new HashMap();
			Map phaseVIInfo 			= new HashMap();
			
			DomainObject domObjectChild 	= null;
			DomainObject domVIPhase 		= null;

			MapList mlVIPLBOMParts 			= new MapList();
			MapList mlVIPhases 				= new MapList();
			
			String phaseVIId = DomainConstants.EMPTY_STRING;
			String strFormulationChildId = DomainConstants.EMPTY_STRING;
			
			
			String strObjectWhere = new StringBuffer(DomainObject.SELECT_CURRENT).append( " != ").append(pgV3Constants.STATE_PART_OBSOLETE).toString();
			
			StringList slSubstituteId 				= new StringList();
			StringList slSubstituteType 			= new StringList();
			StringList slSubstituteName 			= new StringList();
			StringList slSubstituteBaseUOM 			= new StringList();
			StringList slSubstituteEffectivityDate 	= new StringList();
			StringList slSubstituteRelID 			= new StringList();
			StringList slSubstituteFormulationType 	= new StringList();

			
			try {
				
			if(null != domVIObj) {
			
				mlVIPhases =  domVIObj.getRelatedObjects(context,
							pgV3Constants.RELATIONSHIP_PLBOM, 	//relationshipPattern
							//pgV3Constants.SYMBOL_STAR, 			//typePattern
							DomainConstants.QUERY_WILDCARD,		// type pattern
							false, 								//getTo
							true, 								//getFrom
							(short)ConstantsUtilIRM.FIRST_LVL, 							//recurseToLevel
							SL_FOP_OBJECT_INFO_SELECT, 			//objectSelects
							SL_RELATION_INFO_SELECT_OTHERS, 	//relationshipSelects
							strObjectWhere, 					//objectWhere
							null, 								//relationshipWhere
							null,								//PostRelPattern
							null,			//PostTypePattern
							null);

				if(mlVIPhases != null && mlVIPhases.size()>0) {
													
					Collections.sort(mlVIPhases, new Comparator() {					
							public int compare(Object first,Object second) {
								Map firstMap = (Map) first;
								Map secondMap = (Map) second;
								String firstValue = (String) (firstMap.get(DomainConstants.SELECT_NAME));
								String secondValue = (String) secondMap.get(DomainConstants.SELECT_NAME);
								return firstValue.compareTo(secondValue);
							}
						} );
															
					for(int l=0; l<mlVIPhases.size();l++) {
					
						phaseVIInfo = (Map) mlVIPhases.get(l);
						phaseVIId = (String) phaseVIInfo.get(DomainConstants.SELECT_ID);
													
						domVIPhase = DomainObject.newInstance(context, phaseVIId);

							mlVIPLBOMParts =  domVIPhase.getRelatedObjects(context,
								pgV3Constants.RELATIONSHIP_PLBOM, 	//relationshipPattern
								//pgV3Constants.SYMBOL_STAR, 			//typePattern
								DomainConstants.QUERY_WILDCARD,		// type pattern
								false, 								//getTo
								true, 								//getFrom
								(short)ConstantsUtilIRM.SECOND_LVL, 							//recurseToLevel
								SL_FOP_OBJECT_INFO_SELECT, 			//objectSelects
								SL_RELATION_INFO_SELECT_OTHERS, 	//relationshipSelects
								strObjectWhere, 					//objectWhere
								null, 								//relationshipWhere
								null,								//PostRelPattern
								null,			//PostTypePattern
								null);
														
							if(null != mlVIPLBOMParts && mlVIPLBOMParts.size()>0) {
						
								int iPLBOMSize = mlVIPLBOMParts.size();
													
								Object oSubstituteId				= null;
								Object oSubstituteType 				= null;
								Object oSubstituteName				= null;
								Object oSubstituteBaseUOM 			= null;
								Object substituteEffectivityDate	= null;
								Object oSubstituteRelID 			= null;
								Object substituteFormulationType 	= null;
					
								
								for(int j=0;j<iPLBOMSize;j++) {
																
									mpPLBOMData = (Map)mlVIPLBOMParts.get(j);
									strFormulationChildId	= (String) mpPLBOMData.get(DomainConstants.SELECT_ID);
																
									if(BusinessUtil.isNotNullOrEmpty(strFormulationChildId) && BusinessUtil.isNotNullOrEmpty(strIngredientId) && strIngredientId.equalsIgnoreCase(strFormulationChildId)) {
				
										oSubstituteId  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_ID);
										slSubstituteId = new StringList();
										if (null != oSubstituteId) {
											slSubstituteId = getInstanceList(oSubstituteId);
										}
										
										oSubstituteType  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_TYPE);
										slSubstituteType = new StringList();
										if (null != oSubstituteType) {
											slSubstituteType = getInstanceList(oSubstituteType);
										}
										
										oSubstituteName  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_NAME);
										slSubstituteName = new StringList();
										if (null != oSubstituteName) {
											slSubstituteName = getInstanceList(oSubstituteName);
										}
										
										oSubstituteBaseUOM  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_BASE_UOM);
										slSubstituteBaseUOM = new StringList();
										if (null != oSubstituteBaseUOM) {
											slSubstituteBaseUOM = getInstanceList(oSubstituteBaseUOM);
										}
								
										substituteEffectivityDate = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_EFFECTIVITY_DATE);
										slSubstituteEffectivityDate = new StringList();
										if (null != substituteEffectivityDate) {
											slSubstituteEffectivityDate = getInstanceList(substituteEffectivityDate);
										} 
								
										oSubstituteRelID  = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_REL_ID);
										slSubstituteRelID = new StringList();
										if (null != oSubstituteRelID) {
											slSubstituteRelID = getInstanceList(oSubstituteRelID);
										}
								
										substituteFormulationType = (Object) mpPLBOMData.get(pgV3Constants.SELECT_FBOM_SUBSTITUTE_FORMULATION_TYPE);
										slSubstituteFormulationType = new StringList();
										if (null != substituteFormulationType) {
											slSubstituteFormulationType = getInstanceList(substituteFormulationType);
										}
										
										mapVISubstituteDetails.put("slSubstituteId",slSubstituteId);
										mapVISubstituteDetails.put("slSubstituteType",slSubstituteType);
										mapVISubstituteDetails.put("slSubstituteName",slSubstituteName);
										mapVISubstituteDetails.put("slSubstituteBaseUOM",slSubstituteBaseUOM);
										mapVISubstituteDetails.put("slSubstituteEffectivityDate",slSubstituteEffectivityDate);
										mapVISubstituteDetails.put("slSubstituteRelID",slSubstituteRelID);
										mapVISubstituteDetails.put("slSubstituteFormulationType",slSubstituteFormulationType);
									}
								}
							}
						}
					}
				}
			} catch (Exception e){
				e.printStackTrace();
			}
			return mapVISubstituteDetails;
		}
		
		
		/**
		   * This method returns the value for Substitute column
		   * 
		   * @param context
		   * @param args
		   * @return: Vector containing substitute grouping column data
		   * @throws Exception
		   */
		public Vector getSubstituteFlag(Context context, String args[])
		{
			Vector vc = new Vector();
			char cAltItem1 = '9';
			char cAltItem2 = 'A';
			
			try {
				Map paramMap = (Map)JPO.unpackArgs(args);
				MapList objectList = (MapList)paramMap.get("objectList");
				if(objectList != null)
				{
					int objectListSize = objectList.size();
					Map mtempMap = null;
					int iCounter = 0;
					String strRelName = null;
					
					String strFPPGroupingId = "";
					String strCOPinCOP = "";
					String strFPPId = "";
					String strCOPIdentical = "";
					StringList slCOPInCOP =  new StringList(1);
					int iCOPInCOP = 0;
					
					for(int i=0;i<objectListSize;i++)
					{
						mtempMap = (Map)objectList.get(i);
						Object substituteInterId = (Object) (mtempMap).get("frommid["+pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE+"].to.id");
						
						Object oAlternateIds = (Object) (mtempMap).get("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to.id");
						String strIsDirectComp = (String) (mtempMap).get("IsDirectComponent");
						
						strRelName = (String) (mtempMap).get("relationship");
						
						strCOPinCOP = (String) (mtempMap).get("COPinCOP");
						strFPPId = (String) (mtempMap).get("id");
						//Added condition for not to process repeatative COP's
						if(UIUtil.isNotNullAndNotEmpty(strCOPinCOP) && !slCOPInCOP.contains(strCOPinCOP))
						{
						slCOPInCOP.add(strCOPinCOP);
							if(iCounter > 0)
								{
									if (cAltItem2 == 'Z') {
										cAltItem2 = 'A';
										cAltItem1--;
									} else {
										cAltItem2++;
									}
								}
						String strSubCOP = cAltItem1 + "" + cAltItem2;
						iCOPInCOP = 0;
						//Processing and Grouping for FPP's connected to same COP's
							for(int m=0;m<objectListSize;m++)
							{
							Map mptempMap = (Map)objectList.get(m);
							strCOPIdentical = (String) (mptempMap).get("COPinCOP");
							strFPPGroupingId = (String) (mptempMap).get("id");
							if((!strFPPId.equals(strFPPGroupingId)) && strCOPinCOP.equals(strCOPIdentical))
								{
								vc.add(strSubCOP);
									if(iCOPInCOP>0)
									{
									iCounter++ ;
									}
									iCOPInCOP++;
								}
							}
							//If COP connected to more than 1 FPP do Grouping else mark as empty
							if(iCOPInCOP>0){
								vc.add(strSubCOP);
								//Added by Subhajit for Defect 52840 - Start
								iCounter++ ;
								//Added by Subhajit for Defect 52840 - End
							}
							else{
								vc.add("");
								//Added by Subhajit for Defect 52840 - Start
								iCounter = 0;
								//Added by Subhajit for Defect 52840 - End
							}
						//Continue for FPP connected to already Processed COP
						}else if(UIUtil.isNotNullAndNotEmpty(strCOPinCOP) && slCOPInCOP.contains(strCOPinCOP)){
						continue;
						
						}else{
						
						if((null != substituteInterId && "true".equals(strIsDirectComp)) || (!(DomainConstants.RELATIONSHIP_ALTERNATE.equals(strRelName)) && null != oAlternateIds && "true".equals(strIsDirectComp))) {
							if(iCounter > 0)
							{
								if (cAltItem2 == 'Z') {
									cAltItem2 = 'A';
									cAltItem1--;
								} else {
									cAltItem2++;				
								}
							}
							vc.add(cAltItem1 + "" + cAltItem2);
							iCounter++ ;
						} else {
							if(pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE.equals(strRelName) || DomainConstants.RELATIONSHIP_ALTERNATE.equals(strRelName)) {
								vc.add(cAltItem1 + "" + cAltItem2);
							} else {
								vc.add(" ");
								continue;
							}
						}
						
						}
					}
				}
			} catch(Exception e)
			{
				e.printStackTrace();
			}
			return vc;
		}
		
		
		/**
		* This method returns Vector of BOM quantity data
		* @param context
		* @arg object details
		* @return Vector
		* @throws Exception
		*/
		public Vector getBOMQTYData(Context context, String[] args) throws Exception
		{
			Vector vc = new Vector();
			try {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			
			BigDecimal bdBOMBaseQty=BigDecimal.ZERO;
			BigDecimal bdBOMQuantity=BigDecimal.ZERO;
			BigDecimal bdBOMFinalQuantity=BigDecimal.ZERO;
			BigDecimal bdBOMQuantityCheck=new BigDecimal("9999999999.999");
			
			
			MapList objectList = (MapList)programMap.get("objectList");
			HashMap paramList = (HashMap)programMap.get("paramList");
			String  strFPPID          = (String) paramList.get("objectId");
			DomainObject dObjFPP = DomainObject.newInstance(context,strFPPID);
			//Expand the FPP and get intermediate types
			
			StringList slObjectSelect = new StringList(5);
			slObjectSelect.addElement(DomainConstants.SELECT_ID);
			slObjectSelect.addElement(DomainConstants.SELECT_NAME);
			slObjectSelect.addElement(DomainConstants.SELECT_TYPE);
			slObjectSelect.addElement(DomainConstants.SELECT_REVISION);
			
			slObjectSelect.addElement(DomainConstants.SELECT_LEVEL);
			
			StringList relationshipSelects = new StringList(4);

			relationshipSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			relationshipSelects.add(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);

			//Modified by DSM-2015x.1 for SAP BOM As Fed(Req ID-7099,7540,7541,7542) on 12-Jan-2016 - Starts
			MapList mlFPPChildData = dObjFPP.getRelatedObjects(context,
																pgV3Constants.RELATIONSHIP_EBOM,  // Rel Pattern

																pgV3Constants.TYPE_PGCONSUMERUNITPART+","+pgV3Constants.TYPE_PGCUSTOMERUNITPART+","+pgV3Constants.TYPE_PGINNERPACKUNITPART + "," + pgV3Constants.TYPE_FABRICATEDPART,              //Type Pattern

																slObjectSelect,                  //  bus select

																relationshipSelects,             //   Rel select

																false,							 // to side

																true,                           // from side

																(short)ConstantsUtil.ZERO_LEVEL,					   //  recursion level

																null,						  // Object Where Clause

																null);                       // Rel Where Clause

			 //Get BCF with the formula - BOM Calculation Factor = SAP BOM Base QTY / Design BOM Base QTY
			// float fltBCF = 0;
			StringList slBCF = new StringList(2);
			slBCF.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			//slBCF.addElement("from[pgPDTemplatestopgPLIPCTBaseQuantity].to.name");
			Map mapBCF = (Map)dObjFPP.getInfo(context,slBCF);
			// float flBOMBaseQty = 0;
			// float flPCTBaseQty = 0;
			String strBOMBaseQty = (String)mapBCF.get(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			//String strPCTBaseQty = (String)mapBCF.get("from[pgPDTemplatestopgPLIPCTBaseQuantity].to.name");
			try {
				if(null !=strBOMBaseQty && !"".equals(strBOMBaseQty))
				{
					//flBOMBaseQty = (Float.valueOf(strBOMBaseQty)).floatValue();
					//Modified by DSM-2015x.5.1 for SAP BOM As Fed(Defect ID-19175)
				      bdBOMBaseQty=new BigDecimal(strBOMBaseQty);
				
					//flPCTBaseQty = (Float.valueOf(strPCTBaseQty)).floatValue();
				}
			} catch(Exception ex)
			{
				System.out.println("Exception in converting to BigDecimal "+ex.getMessage());
			}catch(Error ex)
			{
				System.out.println("Error in converting to BigDecimal "+ex.getMessage());
			}
			//fltBCF = flBOMBaseQty;
			
			if(null != objectList && objectList.size() > 0)
			{
				//float fltBOMQty = 0;
				String strBOMQty = "";
				String strObjectID = null;

				String strConnectionID = null;

				String strItermediate = null;

				String strItermediateID = null;

				String strIntermediateType = null;

				String sAttrVal = null;

				Map mapTemp = null;

				//float flNumber = 0;
                //Modified by DSM-2015x.5.1 for SAP BOM As Fed(Defect ID-19175)  - Starts
				for(int i=0;i<objectList.size();i++)
				{
					//fltBOMQty = 0;
					strBOMQty = "";
					//Modified by DSM-2015x.1 for SAP BOM As Fed for implementation of code review comment on 18-Feb-2016 - Starts

					mapTemp = (Map)objectList.get(i);
					strObjectID = (String)mapTemp.get("id");
					strConnectionID = (String)mapTemp.get("id[connection]");
					strItermediate = (String)mapTemp.get("IntermediateName");
					strItermediateID = (String)mapTemp.get("IntermediateID");
					
					strIntermediateType = (String)mapTemp.get("IntermediateType");
					
					//Get quantity on EBOM relationship
					sAttrVal = DomainRelationship.getAttributeValue(context,strConnectionID,pgV3Constants.ATTRIBUTE_QUANTITY);
					//Modified by DSM-2015x.1 for SAP BOM As Fed for implementation of code review comment on 18-Feb-2016 - Ends
					

					if(null != sAttrVal && !"".equals(sAttrVal))
					{
						//flNumber = (Float.valueOf(sAttrVal)).floatValue();
						bdBOMQuantity=new BigDecimal(sAttrVal);
						
					}
					//Iterate mlFPPChildData and get the itermediate id. From there, traverse up and get the required values
					if(null != strItermediateID && strItermediateID.length() > 0 && bdBOMQuantity.compareTo(BigDecimal.ZERO)!=0)
					{
					//	fltBOMQty = fltBCF * flNumber;
						bdBOMFinalQuantity=bdBOMBaseQty.multiply(bdBOMQuantity).setScale(3, BigDecimal.ROUND_HALF_UP);
						String strLevel = "";
						
						String strIterType = DomainConstants.EMPTY_STRING;
						int sizeOfChildData = mlFPPChildData.size();
						
						Stack tempStack = null;
						int stackTopData;
						int currentLevel;
						
						for(int iCount=0; iCount < sizeOfChildData; iCount++)
						{
							Map mapTemp1 = (Map)mlFPPChildData.get(iCount);
							if(((String)mapTemp1.get("id")).equals(strItermediateID))
							{
								tempStack = new Stack();
								//As we have got intermediate object, traverse back till level 1 and calculate BOM Qty
								for(int iChild = iCount;iChild >= 0;iChild--)
								{
									Map mapTempInter = (Map)mlFPPChildData.get(iChild);
									strLevel = (String)mapTempInter.get("level");
									
									currentLevel = Integer.parseInt(strLevel);
									if(iChild == iCount){
										tempStack.push(currentLevel);
									}
									else {			
										stackTopData = (int)tempStack.peek();
										if(currentLevel >= stackTopData)
											continue;
										else
											tempStack.push(currentLevel);
									}
									
									strIterType = (String)mapTempInter.get(DomainConstants.SELECT_TYPE);
									//If the current type is FAB then skip. Also if the component intermediate type is FAB and current type is COP then only consider for calculation.
									if((UIUtil.isNotNullAndNotEmpty(strIterType)) && (
									(strIterType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART)) ||
									((UIUtil.isNotNullAndNotEmpty(strIntermediateType)) && (strIntermediateType.equalsIgnoreCase(pgV3Constants.TYPE_FABRICATEDPART)) && !(strIterType.equalsIgnoreCase(pgV3Constants.TYPE_PGCONSUMERUNITPART))))){
											continue;
									}
									
									String strIterQty = (String)mapTempInter.get(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
									if(UIUtil.isNotNullAndNotEmpty(strIterQty))
									{
										//flNumber = (Float.valueOf(strIterQty)).floatValue();
										bdBOMQuantity=new BigDecimal(strIterQty);
										bdBOMFinalQuantity=bdBOMFinalQuantity.multiply(bdBOMQuantity).setScale(3, BigDecimal.ROUND_HALF_UP);
									}
									//Check if level 1 is reached, if yes, break the loop
									if("1".equals(strLevel))
									{
										break;
									}
								}
								if("1".equals(strLevel))
									{
										break;
									}
							}
						}
					}
					else // else part means object is directly connected to FPP or PAP
					{
						
                        bdBOMFinalQuantity= bdBOMBaseQty.multiply(bdBOMQuantity).setScale(3, BigDecimal.ROUND_HALF_UP);
						//fltBOMQty = fltBCF * flNumber;
					}
					
					//Convert this float to String
					strBOMQty = String.valueOf(bdBOMFinalQuantity);
					if((bdBOMFinalQuantity.compareTo(BigDecimal.ZERO)==0) || (bdBOMFinalQuantity.compareTo(bdBOMQuantityCheck)>0))
					{
						strBOMQty = pgV3Constants.STR_DEFAULT_QTY_IF_FAILED;
					}
					vc.add(strBOMQty);
				}
				//Modified by DSM-2015x.5.1 for SAP BOM As Fed(Defect ID-19175)  - Ends
			}
			
			} catch(Exception ex)
			{
				ex.printStackTrace();
			}
			return vc;
		}
		
		/**
	     * @param objectMap
	     * @param selectable
	     * @return
	     */
	    private StringList getStringListFromMap(Map<Object, Object> objectMap, String selectable) {
	        StringList retList = new StringList();
	        Object resList = (objectMap).get(selectable);
	        if (null != resList) {
	            if (resList instanceof StringList) {
	                retList = (StringList) resList;
	            } else {
	                retList.add(resList.toString());
	            }
	        }
	        return retList;
	    }
	 // Added by Subhajit for Defect 51896 - Starts
	    /**
	     * @param type
	     * @param hasComponent
	     * @param componentTypes
	     * @return
	     */
	    private boolean whenTypeIsConsumerUnitPart(String type, boolean hasComponent, List<String> componentTypes) {
	        boolean isComplex = Boolean.FALSE;
	        if (type.equalsIgnoreCase(pgV3Constants.TYPE_PGCONSUMERUNITPART)) { // case when type is: COP
	            if (hasComponent) {
	                if (componentTypes.contains(pgV3Constants.TYPE_PGCONSUMERUNITPART)) { // if COP has more than one COP
	                    if (componentTypes.stream().filter(t -> t.equalsIgnoreCase(pgV3Constants.TYPE_PGCONSUMERUNITPART)).count() > 1) {
	                        isComplex = Boolean.TRUE;
	                    }
	                }
	            }
	        }
	        return isComplex;
	    }

	    /**
	     * @param type
	     * @param hasComponent
	     * @param componentTypes
	     * @return
	     */
	    private boolean whenTypeIsInnerUnitPart(String type, boolean hasComponent, List<String> componentTypes) {
	        boolean isComplex = Boolean.FALSE;
	        if (type.equalsIgnoreCase(pgV3Constants.TYPE_PGINNERPACKUNITPART)) { // case when type is: IP
	            if (hasComponent) {
	                if (componentTypes.contains(pgV3Constants.TYPE_PGINNERPACKUNITPART)) { // if IP has atleast one IP
	                    isComplex = Boolean.TRUE;
	                } else if (componentTypes.contains(pgV3Constants.TYPE_PGCONSUMERUNITPART)) { // if IP has more than one COP
	                    if (componentTypes.stream().filter(t -> t.equalsIgnoreCase(pgV3Constants.TYPE_PGCONSUMERUNITPART)).count() > 1) {
	                        isComplex = Boolean.TRUE;
	                    }
	                }
	            }
	        }
	        return isComplex;
	    }

	    /**
	     * @param type
	     * @param hasComponent
	     * @param componentTypes
	     * @return
	     */
	    public boolean whenTypeIsCustomerUnitPart(String type, boolean hasComponent, List<String> componentTypes) {
	        boolean isComplex = Boolean.FALSE;
	        if (type.equalsIgnoreCase(pgV3Constants.TYPE_PGCUSTOMERUNITPART)) { // case when type is: CUP
	            if (hasComponent) {
	                if (componentTypes.contains(pgV3Constants.TYPE_PGCUSTOMERUNITPART)) { // if CUP has atleast one CUP
	                    isComplex = Boolean.TRUE;
	                } else if (componentTypes.contains(pgV3Constants.TYPE_PGCONSUMERUNITPART)) { // if CUP has more than one COP
	                    if (componentTypes.stream().filter(t -> t.equalsIgnoreCase(pgV3Constants.TYPE_PGCONSUMERUNITPART)).count() > 1) {
	                        isComplex = Boolean.TRUE;
	                    }
	                } else if (componentTypes.contains(pgV3Constants.TYPE_PGINNERPACKUNITPART)) { // if CUP has more than one IP
	                    if (componentTypes.stream().filter(t -> t.equalsIgnoreCase(pgV3Constants.TYPE_PGINNERPACKUNITPART)).count() > 1) {
	                        isComplex = Boolean.TRUE;
	                    }
	                }
	            }
	        }
	        return isComplex;
	    }
	    /**
	     * @param context
	     * @param objectOid
	     * @return
	     * @throws com.matrixone.apps.domain.util.FrameworkException
	     */
	    public MapList getFirstLevelIntermediates(Context context, String objectOid) throws FrameworkException {

	        DomainObject domainObject = DomainObject.newInstance(context, objectOid);
	        final String type = domainObject.getInfo(context, DomainConstants.SELECT_TYPE);
	        StringBuilder typeBuilder = new StringBuilder();
	        typeBuilder.append(pgV3Constants.TYPE_PGCONSUMERUNITPART);
	        typeBuilder.append(pgV3Constants.SYMBOL_COMMA);
	        typeBuilder.append(pgV3Constants.TYPE_PGCUSTOMERUNITPART);
	        typeBuilder.append(pgV3Constants.SYMBOL_COMMA);
	        typeBuilder.append(pgV3Constants.TYPE_PGINNERPACKUNITPART);

	        String types = typeBuilder.toString();

	        StringList objectSelects = new StringList();
	        objectSelects.addElement(DomainConstants.SELECT_ID);
	        objectSelects.addElement(DomainConstants.SELECT_TYPE);
	        objectSelects.addElement(DomainConstants.SELECT_NAME);
	        objectSelects.addElement(DomainConstants.SELECT_REVISION);
	        objectSelects.addElement(DomainConstants.SELECT_LEVEL);
	        objectSelects.addElement(DomainConstants.SELECT_CURRENT);

	        String objectWhere = DomainObject.SELECT_CURRENT + " != " + DomainConstants.STATE_PART_OBSOLETE;
	        return domainObject.getRelatedObjects(
	                context,                             // Context
	                DomainConstants.RELATIONSHIP_EBOM,   // String
	                types,                               // String
	                false,                            // boolean
	                true,                            // boolean
	                ConstantsUtilIRM.FIRST_LVL,         // Recurse Level
	                objectSelects,                       // StringList
	                DomainConstants.EMPTY_STRINGLIST,    // StringList
	                objectWhere,                            // String
	                DomainConstants.EMPTY_STRING,        // String
	                0,                                // int
	                DomainConstants.EMPTY_STRING,        // String
	                types,                               // String post type pattern
	                null);// Map
	    }

	    /**
	     * @param context
	     * @param objectOid
	     * @return
	     * @throws FrameworkException
	     */
	    public MapList getFirstLevelCustomerUnitPart(Context context, String objectOid) throws FrameworkException {

	        DomainObject domainObject = DomainObject.newInstance(context, objectOid);
	        final String type = domainObject.getInfo(context, DomainConstants.SELECT_TYPE);
	        StringList objectSelects = new StringList();
	        objectSelects.addElement(DomainConstants.SELECT_ID);
	        objectSelects.addElement(DomainConstants.SELECT_TYPE);
	        objectSelects.addElement(DomainConstants.SELECT_NAME);
	        objectSelects.addElement(DomainConstants.SELECT_REVISION);
	        objectSelects.addElement(DomainConstants.SELECT_LEVEL);
	        objectSelects.addElement(DomainConstants.SELECT_CURRENT);

	        String objectWhere = DomainObject.SELECT_CURRENT + " != " + DomainConstants.STATE_PART_OBSOLETE;
	        return domainObject.getRelatedObjects(
	                context,                             // Context
	                DomainConstants.RELATIONSHIP_EBOM,   // String
	                pgV3Constants.TYPE_PGCUSTOMERUNITPART, // String
	                false,                            // boolean
	                true,                            // boolean
	                ConstantsUtilIRM.FIRST_LVL,         // Recurse Level
	                objectSelects,                       // StringList
	                DomainConstants.EMPTY_STRINGLIST,    // StringList
	                objectWhere,                            // String
	                DomainConstants.EMPTY_STRING,        // String
	                0,                                // int
	                DomainConstants.EMPTY_STRING,        // String
	                pgV3Constants.TYPE_PGCUSTOMERUNITPART, // String post type pattern
	                null);// Map
	    }

	    /**
	     * @param context
	     * @param objectId
	     * @return
	     * @throws FrameworkException
	     */
	    public MapList getCustomerUnitFirstLevelIntermediates(Context context, String objectId) throws FrameworkException {
	        return getFirstLevelIntermediates(context, objectId);
	    }

	    /**
	     * @param context
	     * @param objectOid
	     * @return
	     * @throws FrameworkException
	     */
	    public List<String> getFirstLevelIntermediateTypes(Context context, String objectOid) throws FrameworkException {
	        List<String> typeList = new ArrayList<>();
	        MapList objectList = getFirstLevelIntermediates(context, objectOid);
	        if (null != objectList && !objectList.isEmpty()) {
	            typeList = (List<String>) objectList.stream().map(map -> ((String) ((Map<Object, Object>) map).get(DomainConstants.SELECT_TYPE))).collect(Collectors.toList());
	        }
	        return typeList;
	    }

	    /**
	     * @param objectList
	     * @return
	     * @throws FrameworkException
	     */
	    public List<String> getFirstLevelIntermediateTypes(MapList objectList) throws FrameworkException {
	        List<String> typeList = new ArrayList<>();
	        if (null != objectList && !objectList.isEmpty()) {
	            typeList = (List<String>) objectList.stream().map(map -> ((String) ((Map<Object, Object>) map).get(DomainConstants.SELECT_TYPE))).collect(Collectors.toList());
	        }
	        return typeList;
	    }
	    /**
	     * @return
	     */
	    public static StringList getBusSelects() {
	        StringList objectSelects = new StringList(16);
	        objectSelects.add(DomainConstants.SELECT_TYPE);
	        objectSelects.add(DomainConstants.SELECT_NAME);
	        objectSelects.add(DomainConstants.SELECT_REVISION);
	        objectSelects.add(DomainConstants.SELECT_ID);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGSAPTYPE);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_TITLE);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_STATUS);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_RELEASE_PHASE);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
	        objectSelects.add(pgV3Constants.SELECT_ALTERNATE_ID);
	        objectSelects.add(pgV3Constants.SELECT_ALTERNATE_TYPE);
	        objectSelects.add(pgV3Constants.SELECT_ALTERNATE_NAME);
	        objectSelects.add("frommid[" + pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE + "]");
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
	        objectSelects.add("from[" + pgV3Constants.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION + "].to.name");
	        objectSelects.add("from[" + pgV3Constants.RELATIONSHIP_PGMASTER + "].to.name");
	        objectSelects.addElement(DomainConstants.SELECT_LEVEL);
	    
	        objectSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED);
	        
	        return objectSelects;
	    }

	    /**
	     * @return StringList
	     */
	    public static StringList getRelSelects() {
	        StringList relSelects = new StringList(33);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGQUANTITY);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGMINQUANTITY);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGMAXQUANTITY);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGCALCQUANTITY);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_FINDNUMBER);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
	        relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_REL_ID);
	        relSelects.add("frommid[" + pgV3Constants.RELATIONSHIP_EBOMSUBSTITUTE + "]");
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_ID);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_TYPE);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_NAME);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_REVISION);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_CURRENT);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_PG_BOM_BASEQUANTITY);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGSAPTYPE);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_EFFECTIVITY_DATE);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_COMMENT);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_COMMENT);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_MIN_QUANTITY);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_MAX_QUANTITY);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_QUANTITY);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
	        relSelects.add(pgV3Constants.SELECT_ATTRIBUTE_QUANTITY);
	        
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
	        relSelects.add(pgV3Constants.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
	        
	        return relSelects;
	    }
	   
	  
	    public enum IntermediateParts {
	        TYPE_PGCUSTOMERUNITPART {
	            @Override
	            public boolean isComplexBOM(Map<Object, Object> objectMap) {
	                boolean isComplex = Boolean.FALSE;
	                // get component info starts
	                boolean hasComponent = (objectMap.containsKey(SAPViewConstant.KEY_HAS_COMPONENT.getValue())) ? (Boolean) objectMap.get(SAPViewConstant.KEY_HAS_COMPONENT.getValue()) : Boolean.FALSE;
	                List<String> componentTypes = new ArrayList<>();
	                if (hasComponent) { // if has component. initialize components types list.
	                    componentTypes = (objectMap.containsKey(SAPViewConstant.KEY_COMPONENT_TYPES_LIST.getValue())) ? (List<String>) objectMap.get(SAPViewConstant.KEY_COMPONENT_TYPES_LIST.getValue()) : componentTypes;
	                    if (componentTypes.isEmpty()) {
	                        //logger.log(Level.WARNING, "Error - (CUP) Component Type List is empty");
	                    }
	                    if (componentTypes.contains(pgV3Constants.TYPE_PGCUSTOMERUNITPART)) { // if CUP has atleast one CUP
	                        isComplex = Boolean.TRUE;
	                    } else if (componentTypes.contains(pgV3Constants.TYPE_PGCONSUMERUNITPART)) { // if CUP has more than one COP
	                        if (componentTypes.stream().filter(t -> t.equalsIgnoreCase(pgV3Constants.TYPE_PGCONSUMERUNITPART)).count() > 1) {
	                            isComplex = Boolean.TRUE;
	                        }
	                    } else if (componentTypes.contains(pgV3Constants.TYPE_PGINNERPACKUNITPART)) { // if CUP has more than one IP
	                        if (componentTypes.stream().filter(t -> t.equalsIgnoreCase(pgV3Constants.TYPE_PGINNERPACKUNITPART)).count() > 1) {
	                            isComplex = Boolean.TRUE;
	                        }
	                    }
	                } // get component info ends
	                return isComplex;
	            }
	        },
	        TYPE_PGINNERPACKUNITPART {
	            @Override
	            public boolean isComplexBOM(Map<Object, Object> objectMap) {
	                boolean isComplex = Boolean.FALSE;
	                // get component info starts
	                boolean hasComponent = (objectMap.containsKey(SAPViewConstant.KEY_HAS_COMPONENT.getValue())) ? (Boolean) objectMap.get(SAPViewConstant.KEY_HAS_COMPONENT.getValue()) : Boolean.FALSE;
	                List<String> componentTypes = new ArrayList<>();
	                if (hasComponent) { // if has component. initialize components types list.
	                    componentTypes = (objectMap.containsKey(SAPViewConstant.KEY_COMPONENT_TYPES_LIST.getValue())) ? (List<String>) objectMap.get(SAPViewConstant.KEY_COMPONENT_TYPES_LIST.getValue()) : componentTypes;
	                    if (componentTypes.isEmpty()) {
	                        //logger.log(Level.WARNING, "Error - (IP) Component Type List is empty");
	                    }
	                    if (componentTypes.contains(pgV3Constants.TYPE_PGINNERPACKUNITPART)) { // if IP has atleast one IP
	                        isComplex = Boolean.TRUE;
	                    } else if (componentTypes.contains(pgV3Constants.TYPE_PGCONSUMERUNITPART)) { // if IP has more than one COP
	                        if (componentTypes.stream().filter(t -> t.equalsIgnoreCase(pgV3Constants.TYPE_PGCONSUMERUNITPART)).count() > 1) {
	                            isComplex = Boolean.TRUE;
	                        }
	                    }
	                }
	                return isComplex;
	            }
	        },
	        TYPE_PGCONSUMERUNITPART {
	            @Override
	            public boolean isComplexBOM(Map<Object, Object> objectMap) {
	                boolean isComplex = Boolean.FALSE;
	                // get component info starts
	                boolean hasComponent = (objectMap.containsKey(SAPViewConstant.KEY_HAS_COMPONENT.getValue())) ? (Boolean) objectMap.get(SAPViewConstant.KEY_HAS_COMPONENT.getValue()) : Boolean.FALSE;
	                List<String> componentTypes = new ArrayList<>();
	                if (hasComponent) { // if has component. initialize components types list.
	                    componentTypes = (objectMap.containsKey(SAPViewConstant.KEY_COMPONENT_TYPES_LIST.getValue())) ? (List<String>) objectMap.get(SAPViewConstant.KEY_COMPONENT_TYPES_LIST.getValue()) : componentTypes;
	                    if (componentTypes.isEmpty()) {
	                        //logger.log(Level.WARNING, "Error - (COP) Component Type List is empty");
	                    }
	                    if (componentTypes.contains(pgV3Constants.TYPE_PGCONSUMERUNITPART)) { // if COP has more than one COP
	                        if (componentTypes.stream().filter(t -> t.equalsIgnoreCase(pgV3Constants.TYPE_PGCONSUMERUNITPART)).count() > 1) {
	                            isComplex = Boolean.TRUE;
	                        }
	                    }
	                }
	                return isComplex;
	            }
	        };

	        /**
	         * @param objectMap
	         * @return
	         */
	        public abstract boolean isComplexBOM(Map<Object, Object> objectMap);

	        /**
	         * @param context
	         * @param objectMap
	         * @return
	         * @throws com.matrixone.apps.domain.util.FrameworkException
	         */
	        public static boolean isComplexBOM(Context context, Map<Object, Object> objectMap) throws FrameworkException {
	            boolean isComplex = false;
	            String type = (String) (objectMap).get(DomainConstants.SELECT_TYPE);
	            String typeSymbolicName = FrameworkUtil.getAliasForAdmin(context, DomainConstants.SELECT_TYPE, type, false);
	            IntermediateParts intermediateParts = IntermediateParts.valueOf(typeSymbolicName.toUpperCase());
	            if (null != intermediateParts) {
	                isComplex = intermediateParts.isComplexBOM(objectMap);
	            }
	            return isComplex;
	        }
	    }
	 // Added by Subhajit for Defect 51896 - Ends
	    
	    /**
		 * Added by Jwala for 22x.06 Requirement 8277 - START.
		 * This method returns all FPP If that child-FPP's SAP Attribute of...
		 * "CUST_TYPE" (blank/null), "Special Pack" ,"Assortment/Count Change","Tray Display","Direct To Consumer" and "Shelf Ready Packaging"
		 * proceed with including it in the parent-FPP SAP BOM as Fed view.
		 * @param mpFPPObjects : Containing all child Release FPP.
		 * @return boolean.
		 * @throws Exception.
		 */
		public boolean isFPPForSAPBOMAsFedView(Context context, Map<String,String> mpFPPObjects)throws Exception {
			boolean isForSAPBOMAsFedView=false;
			String strCustTypeValue = DomainConstants.EMPTY_STRING;
			StringList slCustTypeValues = new StringList();
			if(null != mpFPPObjects && mpFPPObjects.size() > 0) {
				String strType = (String) mpFPPObjects.get(DomainConstants.SELECT_TYPE);
				if(pgV3Constants.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strType)) {
					String strFPPAttrCustTypeValue = (String) mpFPPObjects.get("attribute["+pgV3Constants.ATTRIBUTE_PGCUSTOMIZATIONTYPE+"]");
					try {
						BusinessObject boBOMConfig = new BusinessObject(pgV3Constants.TYPE_PGCONFIGURATIONADMIN, pgV3Constants.CONFIG_OBJECT_PGBOMEDELIVERYCONFIG, pgV3Constants.SYMBOL_HYPHEN, pgV3Constants.VAULT_ESERVICEPRODUCTION);
						if(boBOMConfig.exists(context)) {
							Attribute attrCustType = boBOMConfig.getAttributeValues(context, pgV3Constants.ATTRIBUTE_PGCUSTOMIZATIONTYPE);
							if(null != attrCustType) {
								String strCustTypeValues = attrCustType.getValue();
								if(UIUtil.isNotNullAndNotEmpty(strCustTypeValues)) {
									slCustTypeValues = FrameworkUtil.split(strCustTypeValues, pgV3Constants.SYMBOL_PIPE);
									if(UIUtil.isNullOrEmpty(strFPPAttrCustTypeValue) || slCustTypeValues.contains(strFPPAttrCustTypeValue)) {
										isForSAPBOMAsFedView=true;
									}
								}
							}
						} else {
							LOGGER.info("isFPPForSAPBOMAsFedView :: BOM Delivery Configuration Object does not exist. Please create pgBOMeDeliveryConfiguration object to continue BOM Delivery Configuration job....");
						}
					} catch (Exception e) {
						LOGGER.info("Exception while getting SAP BOM As Fed View in method isFPPForSAPBOMAsFedView() :: ", e);
					}
				}
			}
			return isForSAPBOMAsFedView;
		}
		//Added by Jwala for 22x.06 Requirement 8277 - END
}
