/*package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.MPSBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.Pattern;
import matrix.util.StringList;

public class MPSService {
	private static Logger LOGGER = Logger.getLogger(MPSService.class);

	public static void main(String[] args) throws Exception {
	
		
		//String objId = "20336.41905.64265.10790";
		
		//String objId = "20336.41905.32768.31498"; //for overall
		
		String objId = "20336.41905.770.21980"; //for CPS
		
		//String objId = "20336.41905.27400.5680"; //for CPS
		
		//String objId = "20336.41905.35073.17152"; // for Req. 35939
		
		
		boolean bAllInfoView = false;
		boolean bSupplierView = false;
		boolean bManufacturerView = false;
		boolean bConsolidatedPackingView = false;
		
		Context context = pool.checkOut();
		
			HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
			StopWatch sp = new StopWatch();
			sp.start();
			
				Map<String,String> mpHeaderContent = new HashMap<String,String>();
				Map<String,String> mpAttribResult = new HashMap<String,String>();
				Map<String,String> mpOrganization = new HashMap<String,String>();
				Map<String,String> mpOwnershipResult = new HashMap<String,String>();
				Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
				Map<String,String> mpReferenceDocs = new HashMap<String,String>();
				Map<String,String> mpSpecResult = new HashMap<String,String>();
				Map<String,String> mpTransportUnitResult = new HashMap<String,String>();
				Map<String,String> mpPackingUnit = new HashMap<String,String>();
				Map<String,String> mpWnDResult = new HashMap<String,String>();
				Map<String,String> mpPerformChar= new HashMap<String,String>();
				Map<String,String> mpNotes = new HashMap<String,String>();
				//Map<String,String> mpSubstitute = new HashMap<String,String>();
				Map<String,String> mpBOMResult = new HashMap<String,String>();
				Map<String,String> mpHasATS = new HashMap<String,String>();
				Map<String,String> mpISATS = new HashMap<String,String>();
				Map<String,String> mpTechnicalSupersedes = new HashMap<String,String>();
				Map<String,String> mpTechnicalSupersedesBy = new HashMap<String,String>();
				Map<String,String> mpSecurity = new HashMap<String,String>();
				Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
				Map<String,String> mpIPClass = new HashMap<String, String>();
				
				BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
				StringValidatorUtil validator = new StringValidatorUtil();
			
				ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);

			

				MPSBO mpsBO = new MPSBO();
				Map BusinessObjectSelectableMap = mpsBO.getMPSSelectableMap(context);
				StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
				
				DomainObject doMPS = mpsBO.getMpsDO(context, objId);
				if (null == doMPS) {
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.info("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
					//return hmAttrib;
				}

				StopWatch swAttributes = new StopWatch();
				swAttributes.start();	
				mpsBO.addMultiList();
				Map resultMap = doMPS.getInfo(context, slSelects);
				swAttributes.stop();
				LOGGER.info("MPS GETINFO ELAPSED TIME : "+swAttributes.getTime());
				mpsBO.removeMultiList();
				
				Map BusinessObjectRelSelectableMap = mpsBO.getMpsRelatedObjsSelectableMap(context);
				StringList slEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.BUS_SELECTS);
				StringList slRelEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.REL_SELECTS);
				
				
				*//**
				 * PERFORMANCE CHARACTERISTICS SECTION
				 *//*
				
				
				mpsBO.getPerformanceSpecifications(context, objId);
				
					String sRevision = (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
				    String sPCName = (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
				    MapList    mlPerformAttrib = busUtil.getExtendedPerformChar(context,doMPS,sRevision,sPCName,resultMap);
				    
				    mpPerformChar =  busUtil.updatePerformCharcteristicforMPS(context,mpsBO.getPerformChars(context, objId),resultMap);
			
				    System.out.println("mpPerformChar----------Finalised oen-----------------------"+mpPerformChar);
				
				
				
				String sCSSAttrib = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE) : ConstantsUtil.EMPTY_STRING;
				
				
				if (!sCSSAttrib.equals("MP")) {
					
					LOGGER.info("Formula Card Objects is Unstructured : "+objId);
					FormulaCardUnStructured fcNonStrct= new FormulaCardUnStructured();
					fcNonStrct.getFormulaCardData(context,objId);
					pool.checkIn(context);

				}
			
			
				
				*//**
				 * LIFECYCLE SECTION for APPROVERs
				 *//*
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				if(bAllInfoView){
					mpLifeCycleApproval = busUtil.getCOName(context, changeargs);
				}
				swLifecycle.stop();
				LOGGER.info("MPS  LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				
				
				
				
				*//**
				 * LOAD HEADER SECTION
				 * *//*
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)))?busUtil.mapType((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);		
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.ISATS, ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
				String sClassification = busUtil.getClassification(resultMap);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, (sClassification));
				
				
				
				*//**
				 * ATTRIBUTE SECTION
				 *//*
					mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.WAREHOUSINGCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.RERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.RERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.STRSEGMENT)))?(String)resultMap.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING)); 
					mpAttribResult.put(ConstantsUtil.PGASLALLOCATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				
					
					String sHasATS = "";
					String sIsATS = "";
					
					
					String sCurrent = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.ATL_STATE));
					String sName = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.ATL_NAME));
					sHasATS =busUtil.checkIsATSAttribute(sName,sCurrent);
					
					
					String sATSCurrent = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.REL_ATS_STATE));
					String sATSName = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.REL_ATS_NAME));
					sIsATS =busUtil.checkIsATSAttribute(sATSName,sATSCurrent);
					
				*//**
				 * HasATS
				 *//*
				mpHasATS = busUtil.checkHasATS(context,resultMap);
				
				
				*//**
				 * IsATS
				 *//*
				mpISATS = busUtil.checkIsATS(context,resultMap);
				
				
				*//**
				 * Technical Supersedes 
				 *//*
				mpTechnicalSupersedes=busUtil.getTechnicalSupersedes(context, resultMap);
				
				
				*//**
				 * Technical SupersedesBy 
				 *//*
				mpTechnicalSupersedesBy=busUtil.getTechnicalSupersedesBy(context, resultMap);
				
				
				
				*//**
				 * ORGANIZATION SECTION
				 *//*
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = busUtil.filterMapList(mpOrganization);
				
				
				*//**
				 * OWNERSHIP SECTION
				 *//*
				mpOwnershipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpOwnershipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpOwnershipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS) : ConstantsUtil.EMPTY_STRING);
				mpOwnershipResult.put(ConstantsUtil.OSO, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMap.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
				mpOwnershipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
				mpOwnershipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mpOwnershipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
				StopWatch swGetEDL = new StopWatch();
				swGetEDL.start();
				String sEDList =mpsBO.getEDList(resultMap);
				swGetEDL.stop();
				LOGGER.info("MPS GET EDL ELAPSED TIME : "+swGetEDL.getTime());
				mpOwnershipResult.put(ConstantsUtil.EDL, sEDList);
				mpOwnershipResult.put(ConstantsUtil.ODL, busUtil.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST) : ConstantsUtil.EMPTY_STRING));
				mpOwnershipResult = busUtil.filterMapList(mpOwnershipResult);
				
				
				*//**
				 * REFERENCE DOCUMENTS SECTION
				 *//*
				
				String sys = busUtil.getUserType();
				System.out.println(sys);
				StopWatch swReference= new StopWatch();
				swReference.start();
				mpReferenceDocs = mpsBO.updateRefDocs(context, resultMap);
				swReference.stop();
				LOGGER.info("MPS  REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());
				
				
				
				*//**
				 * SPECIFICATIONS SECTION
				 *//*
				mpSpecResult = busUtil.updatePartSpecforMPS(context, resultMap, true);
				
				
				*//**
				 * TRANSPORT UNIT SECTION
				 *//*
				StopWatch swTup = new StopWatch();
				swTup.start();
				mpTransportUnitResult= mpsBO.UpdateTransportChar(context, resultMap);
				swTup.stop();
				LOGGER.info("MPS TUP ELAPSED TIME : "+swTup.getTime());
				
				
				*//**
				 * PACKING UNIT SECTION
				 *//*
				StopWatch swPup = new StopWatch();
				swPup.start();
				mpPackingUnit =  mpsBO.UpdatePackagingChar(context, resultMap);
				swPup.stop();
				LOGGER.info("MPS Packing Unit ELAPSED TIME : "+swTup.getTime());
				Pattern sbTypePattern = new Pattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
				sbTypePattern.addPattern(ConstantsUtil.TYPE_PGINNERPACKUNITPART);
				sbTypePattern.addPattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
				sbTypePattern.addPattern(ConstantsUtil.TYPE_PGMASTERFINISHEDPRODUCT);
				
				
				*//**
				 * WEIGHTS AND DIMENTIONS SECTION
				 *//*
				mpWnDResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
				mpWnDResult.put(ConstantsUtil.UNITOFMEASURESYSTEM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM) : ConstantsUtil.EMPTY_STRING);
				mpWnDResult = busUtil.filterMapList(mpWnDResult);
				
				
				*//**
				 * NOTES SECTION
				 *//*
					mpNotes=mpsBO.updateNotes(context, resultMap);
				
				
				*//**
				 * BILL OF MATERIALS (BOM) and SUBSTITUTES SECTION
				 *//*
					StopWatch swBom = new StopWatch();
					swBom.start();
								
					MapList mlEBOMList = doMPS.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
							"pgPhase", slEBOMSelects, slRelEBOMSelects, false, true, (short)1,
							ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
					
					Map  mpPhaseBom =mpsBO.getPhaseBOM(context,mlEBOMList,resultMap);
					if(mpPhaseBom.size()>0) {
						mpBOMResult=mpPhaseBom;
					}
					
					
				*//**
				 * LOAD SECURITY SECTION
				 * *//*
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO bo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =bo.updateSecurity(context,resultMap);
				swSecurity.stop();
				LOGGER.info("MPS  Security ELAPSED TIME : "+swSecurity.getTime());
				
					
				*//**
				 * IP Security Classes
				 *//*
				DomainObject doMps=mpsBO.getMpsDO(context, objId);
				CommonBusUtilBO commonBo = new CommonBusUtilBO();
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIPClass =commonBo.getIpClass(context, doMps, slIpSelects);
				
				
					hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);  
					hmAttrib.put(ConstantsUtil.ISATS, mpISATS);
					hmAttrib.put(ConstantsUtil.TECHSUPERSEDES, mpTechnicalSupersedes);
					hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
					hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
					hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpSpecResult);
					hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent); 
					hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
					hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mpReferenceDocs);
					hmAttrib.put(ConstantsUtil.TRANSPORTUNIT, mpTransportUnitResult);
					hmAttrib.put(ConstantsUtil.PACKINGUNIT, mpPackingUnit);
					hmAttrib.put(ConstantsUtil.WEIGHTSDIMENSIONSOBJECT, mpWnDResult);
					//hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
					hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpBOMResult);
					hmAttrib.put(ConstantsUtil.HASATS, mpHasATS);
					hmAttrib.put(ConstantsUtil.TECHSUPERSEDESBY, mpTechnicalSupersedesBy);
					hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
					hmAttrib.put(ConstantsUtil.IPSECURITY, mpIPClass);
					hmAttrib.put(ConstantsUtil.OWNERSHIPOBJECT, mpOwnershipResult);
				
				System.out.println("hmAttrib------------------------"+hmAttrib);
				ContextUtil.popContext(context);
				pool.checkIn(context);
				sp.stop();
				System.out.println("Execution TIME::" + sp.getTime());
	}
}
*/