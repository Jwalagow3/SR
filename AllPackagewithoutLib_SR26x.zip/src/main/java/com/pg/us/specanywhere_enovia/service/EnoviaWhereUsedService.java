package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaWhereUsedService {

	HashMap<String, Map<String, String>> getWhereUsedData(String sObjectID, Environment env);

}
