package com.pg.us.specanywhere_enovia.utility;

import com.matrixone.apps.domain.util.FrameworkUtil;

import matrix.util.StringList;

public class Example {

	public static void main(String[] args) {

		String subtype = "|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|No Access|TM|TM|TM|TM|TM|TM|TM|TM|TM|No Access|TM|TM|ANALYTICAL|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|ANALYTICAL|TM||TM|TM|TM|TM|TM|TM|TM|TM|ANALYTICAL|No Access|TM||TM|TM|TM|TM|TM||TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|ANALYTICAL|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|ANALYTICAL|TM|TM|TM|TM|TM|TM|ANALYTICAL|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|TM|ANALYTICAL|TM|ANALYTICAL|TM|TM|TM|ANALYTICAL|TM|TM|TM|TM|TM|TM|ANALYTICAL|TM|TM|TM|TM|TM|TM|TM|TM|TM|ANALYTICAL|TM||TM|TM|ANALYTICAL|";
		String type = "Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Standard Operating Procedure|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|Test Method Specification|";
		
		StringList st = FrameworkUtil.split(subtype, ConstantsUtil.SYMBL_PIPE);
		StringList t = FrameworkUtil.split(type, ConstantsUtil.SYMBL_PIPE);
		System.out.println(st.size());
		System.out.println(t.size());
		
		String[] a = subtype.split("//|");
		System.out.println(a.length);
		String[] b = type.split("//|");
		System.out.println(b.length);
	}

}
