package com.pg.us.specanywhere_enovia.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.pg.us.specanywhere_enovia.bo.PDFBO;
import com.pg.us.specanywhere_enovia.utility.PDFView;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaPDFService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

import matrix.db.Context;

public class EnoviaPDFServiceImpl implements EnoviaPDFService {
	
	private static Logger LOGGER = Logger.getLogger(EnoviaPDFServiceImpl.class);

	@Autowired
	private EnoviaConnectionPool pool;
	
	@Override
	public HashMap<String, Object> getPDFdata(Environment env, PDFView pdfView) throws Exception {
		
		HashMap<String, Object> hmAttrib = new HashMap<String, Object>();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		
		try {
		StopWatch swDetails = new StopWatch();
		swDetails.start();
		PDFBO pdfbo = new PDFBO();
		hmAttrib = pdfbo.getPDFdetails(context, pdfView);
		swDetails.stop();
		LOGGER.info("PDF EXTERNAL VIEW SERVICE DETAILS ELAPSED TIME : "+swDetails.getTime());
		} catch(Exception e) {
			LOGGER.error("Unable to getPDFdata "+e);
		}
		context.close();
		return hmAttrib;
	}

}
