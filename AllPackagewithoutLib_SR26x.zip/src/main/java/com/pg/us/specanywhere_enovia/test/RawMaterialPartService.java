/*package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.MRMPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class RawMaterialPartService {

	private static Logger LOGGER = Logger.getLogger(RawMaterialPartService.class);

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();

		String objId = "20336.41905.54400.45883"; //60820208-Rev005
		//String objId = "20336.41905.33491.47275";//98667162
		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
		Context context = pool.checkOut();

		boolean bAllInfoView = true;
		boolean bSupplierView = true;
		boolean bManufacturerView = true;

		
		 * User Profile
		 * 
	    SecurityService sct = new SecurityService();
	    String sUserType = sct.getUserType();
	    boolean bAllInfoView = false;
	    boolean bSupplierView = false;
	    boolean bManufacturerView = false;

	    switch (sUserType) {
	    	case ConstantsUtil.PG:
	    		bAllInfoView = true;
	    		break;

	    	case ConstantsUtil.PGSTAFF:
	    		bAllInfoView = true;
	    		break;

	    	case ConstantsUtil.PG_CM:
	    		bManufacturerView = true;
	    		break;

	    	case ConstantsUtil.PG_SP:
	    		bSupplierView = true;
	    		break;
	    }


		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpPlantResult = new HashMap<String,String>();
		Map<String,String> mpProfileIdResult = new HashMap<String,String>();
		Map<String,String> mpChemClassResult = new HashMap<String,String>();
		Map<String,String> mpPhysicalPropResult = new HashMap<String,String>();
		Map<String,String> mpPerfumeResult = new HashMap<String,String>();
		Map<String,String> mpChemMoleculeResult = new HashMap<String,String>();
		Map<String,String> mpCDetergentResult = new HashMap<String,String>();
		Map<String,String> mpReachtResult = new HashMap<String,String>();
		Map<String,String> mpWeightResult = new HashMap<String,String>();
		Map<String,String> mpMEPResult = new HashMap<String,String>();
		Map<String,String> mpSEPResult = new HashMap<String,String>();
		Map<String,String> mpPartSpecResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mpMasterAttribute = new HashMap<String,String>();
		Map<String,String> mpMasterSpecs = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mpPerformChar = new HashMap<String,String>();			
		Map<String,String> mpRegSafety = new HashMap<String,String>();
		Map<String,String> mpSpecifications = new HashMap<String,String>();
		Map<String,String> mpNotes = new HashMap<String,String>();
		Map<String,String> mpStartingMaterials = new HashMap<String,String>();
		Map<String,String> mpAlternates = new HashMap<String,String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
		Map<String,String> mpDerivedToResult = new HashMap<String,String>();
		Map<String,String> mpSecurity = new HashMap<String,String>();
		Map<String,String> mpCertification = new HashMap<String,String>();
		Map<String,String> mpProducingFarmula = new HashMap<String,String>();
		Map<String,String> mpRelatedATS = new HashMap<String,String>();

		Map mpSubStanceResult = new HashMap();
		RawMaterialPartBO RawBO = new RawMaterialPartBO();
		BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
		CommonBusUtilBO commonBo = new CommonBusUtilBO();


		Map<String, StringList> BusinessObjectSelectableMap = RawBO.getRMPPartSelectables(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringValidatorUtil validator = new StringValidatorUtil();

		
		 * Get Attribute Info
		 * 
		DomainObject doRMP =  RawBO.getRmpDO(context, objId);
		RawBO.addMultiList();
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doRMP.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("RMP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		RawBO.removeMultiValueList();

		StringList slHistoryInfo = (StringList)resultMaps.get(ConstantsUtil.SELECT_HISTORY);
		String lastUpdatedUser = BbUtil.getLastUpdateUser(slHistoryInfo);

		String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		
		if(bManufacturerView || bAllInfoView || bSupplierView) {

			
			 * LOAD HEADER SECTION
			 * 
			mpHeaderContent.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);

			
			 * LOAD MASTER ATTRIBUTE INFO
			 * 
			//Contract Manufacturer View && All Info View
			String sMasterID= (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID) : ConstantsUtil.EMPTY_STRING);
			if(validator.isNotNullOrEmpty(sMasterID)){
				StopWatch swMasterAttrib = new StopWatch();
				swMasterAttrib.start();
				mpMasterAttribute = RawBO.getMasterAttributeData(context,sMasterID);
				swMasterAttrib.stop();
				LOGGER.info("RMP GET MASTER ATTRIB ELAPSED TIME : "+swMasterAttrib.getTime());
			}

			
			 * LOAD ATTRIBUTE SECTION
			 * 
			//Contract Manufacturer View && All Info View
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_TEMPLATE)))?(String)resultMaps.get(ConstantsUtil.STR_TEMPLATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SHELFLIFE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);


			
			 * LOAD PROFILE SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpProfileIdResult.put(ConstantsUtil.INCINAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INCINAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INCINAME) : ConstantsUtil.EMPTY_STRING);
			mpProfileIdResult.put(ConstantsUtil.CHEMICALNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICALNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICALNAME) : ConstantsUtil.EMPTY_STRING);
			mpProfileIdResult.put(ConstantsUtil.EMPERICALFORMULA, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EMPIRICALFORMULA)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EMPIRICALFORMULA) : ConstantsUtil.EMPTY_STRING);
			mpProfileIdResult.put(ConstantsUtil.STANDARDCOSTPERKG, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STANDARDCOSTPERKG)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STANDARDCOSTPERKG) : ConstantsUtil.EMPTY_STRING);
			mpProfileIdResult.put(ConstantsUtil.COLORINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLORINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLORINDEX) : ConstantsUtil.EMPTY_STRING);
			mpProfileIdResult.put(ConstantsUtil.CISPRO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMCISPRONUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMCISPRONUMBER) : ConstantsUtil.EMPTY_STRING);
			mpProfileIdResult.put(ConstantsUtil.EXPERIMENTALNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPERIMENTALNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPERIMENTALNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpProfileIdResult.put(ConstantsUtil.PREFERREDMATERIAL, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING));
			mpProfileIdResult.put(ConstantsUtil.MATERIALUSAGEGUIDANCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALUSAGEGUIDANCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALUSAGEGUIDANCE) : ConstantsUtil.EMPTY_STRING);
			mpProfileIdResult = BbUtil.filterMapList(mpProfileIdResult);


			
			 * LOAD CHEMICAL CLASSIFICATION SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpChemClassResult.put(ConstantsUtil.CAS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpChemClassResult.put(ConstantsUtil.EINECSNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EINECSNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EINECSNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpChemClassResult.put(ConstantsUtil.MATERIALFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_MATERIAL_FUNCTIONALITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_MATERIAL_FUNCTIONALITY) : ConstantsUtil.EMPTY_STRING);
			mpChemClassResult.put(ConstantsUtil.CHEMICALGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP) : ConstantsUtil.EMPTY_STRING);
			mpChemClassResult.put(ConstantsUtil.INGREDIENTCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS) : ConstantsUtil.EMPTY_STRING);
			mpChemClassResult = BbUtil.filterMapList(mpChemClassResult);


			
			 * LOAD PHYSICAL PROP SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpPhysicalPropResult.put(ConstantsUtil.APPEARANCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_APPEARANCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_APPEARANCE) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.COLOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLOR) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.SPECIFICGRAVITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SPECIFICGRAVITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SPECIFICGRAVITY) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.MELTINGPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MELTINGPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MELTINGPOINT) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.BOILINGPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_BOILINGPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_BOILINGPOINT) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.VISCOSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VISCOSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VISCOSITY) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.FORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.VAPORPRESSURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.GRADE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GRADE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GRADE) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.AQUEOUSSOLUBILITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMAQUEOUSSOLUBILITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRMAQUEOUSSOLUBILITY) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.AUTOIGNITIONTEMP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPERATURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPERATURE) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult.put(ConstantsUtil.FLASHPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FLASHPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FLASHPOINT) : ConstantsUtil.EMPTY_STRING);
			mpPhysicalPropResult = BbUtil.filterMapList(mpPhysicalPropResult);


			
			 * LOAD PERFUME SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpPerfumeResult.put(ConstantsUtil.ODORFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGODORFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGODORFAMILY) : ConstantsUtil.EMPTY_STRING);
			mpPerfumeResult.put(ConstantsUtil.PRIMARYODORDESCRIPTOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYODORDESCRIPTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYODORDESCRIPTOR) : ConstantsUtil.EMPTY_STRING);
			mpPerfumeResult.put(ConstantsUtil.SECONDARYODORDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYODORDESCRIPTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYODORDESCRIPTOR) : ConstantsUtil.EMPTY_STRING);
			mpPerfumeResult.put(ConstantsUtil.ODORDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGODORDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGODORDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpPerfumeResult = BbUtil.filterMapList(mpPerfumeResult);


			
			 * LOAD CHEMICAL MOLECULE SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpChemMoleculeResult.put(ConstantsUtil.HLBVALUE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE) : ConstantsUtil.EMPTY_STRING);
			mpChemMoleculeResult.put(ConstantsUtil.SAPONIFICATIONVALUE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPONIFICATIONVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPONIFICATIONVALUE) : ConstantsUtil.EMPTY_STRING);
			mpChemMoleculeResult.put(ConstantsUtil.HYDROPHILICINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHYDROPHILICINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHYDROPHILICINDEX) : ConstantsUtil.EMPTY_STRING);
			mpChemMoleculeResult.put(ConstantsUtil.HYDROXLVALUE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HYDROXYLVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HYDROXYLVALUE) : ConstantsUtil.EMPTY_STRING);
			mpChemMoleculeResult.put(ConstantsUtil.REACTIVITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACTIVITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACTIVITY) : ConstantsUtil.EMPTY_STRING);
			mpChemMoleculeResult.put(ConstantsUtil.IUSPERGRAM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_IUSPERGRAM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_IUSPERGRAM) : ConstantsUtil.EMPTY_STRING);
			mpChemMoleculeResult.put(ConstantsUtil.ALKANITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ALKALINITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ALKALINITY) : ConstantsUtil.EMPTY_STRING);
			mpChemMoleculeResult.put(ConstantsUtil.ANIMALDERIVED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ISANIMALDERIVED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ISANIMALDERIVED) : ConstantsUtil.EMPTY_STRING);
			mpChemMoleculeResult.put(ConstantsUtil.ANIMALDERIVED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PHVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PHVALUE) : ConstantsUtil.EMPTY_STRING);
			mpChemMoleculeResult = BbUtil.filterMapList(mpChemMoleculeResult);


			
			 * LOAD DETERGENT SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpCDetergentResult.put(ConstantsUtil.CATSO3CONTRIBUTOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SO3CONTRIBUTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SO3CONTRIBUTOR) : ConstantsUtil.EMPTY_STRING);
			mpCDetergentResult = BbUtil.filterMapList(mpCDetergentResult);

			
			 * LOAD REACH
			 * 
			//Contract Manufacturer View & All Info View
			mpReachtResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS) : ConstantsUtil.EMPTY_STRING);
			mpReachtResult.put(ConstantsUtil.REGISTRATIONNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpReachtResult = BbUtil.filterMapList(mpReachtResult);

			
			 * LOAD PERFORMANCE CHAR SECTION
			 * 
			//Contract Manufacturer View & All Info View
			String sRevision = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sName = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			StopWatch swPerfChar = new StopWatch();
			swPerfChar.start();
			//mpPerformChar = BbUtil.getExtendedPerformChar(context,doRMP,sRevision,sName,resultMaps);
			swPerfChar.stop();
			mpPerformChar = BbUtil.filterMapList(mpPerformChar);
			LOGGER.info("RMP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());


			
			 * LOAD WEIGHT SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpWeightResult.put(ConstantsUtil.TYPE, BbUtil.mapType(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpWeightResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_NAME) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_GROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_GROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_GROSSWEIGHTUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_GROSSWEIGHTUOM) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_COMMENTS) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult = BbUtil.filterMapList(mpWeightResult);

			
			 * LOAD PART-SPEC SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpPartSpecResult = BbUtil.updatePartSpec(context,resultMaps);

			
			 * LOAD MASTER SPECS SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpMasterSpecs.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID) : ConstantsUtil.EMPTY_STRING);
			mpMasterSpecs.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpMasterSpecs.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME) : ConstantsUtil.EMPTY_STRING);
			mpMasterSpecs.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpMasterSpecs = BbUtil.filterMapList(mpMasterSpecs);

			
			 * LOAD NOTES
			 * 
			MasterCOPBO mcop = new MasterCOPBO();
			mpNotes=mcop.updateNotes(context,resultMaps);

			
			 * STARTING MATERIALS
			 * 
			mpStartingMaterials.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpStartingMaterials.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_NAME) : ConstantsUtil.EMPTY_STRING);
			mpStartingMaterials.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpStartingMaterials.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_PHASE) : ConstantsUtil.EMPTY_STRING);
			mpStartingMaterials.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_TITLE)  : ConstantsUtil.EMPTY_STRING);
			mpStartingMaterials.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_STATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_STATE) : ConstantsUtil.EMPTY_STRING);		

			
			 * ALTERNATES
			 * 
			mpAlternates.put(ConstantsUtil.ALTERNATEPARTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAlternates.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpAlternates.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_TITLE)  : ConstantsUtil.EMPTY_STRING);
			mpAlternates.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpAlternates.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_BASE_UOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ALTERNATE_BASE_UOM) : ConstantsUtil.EMPTY_STRING);
			//mpAlternates = util.filterMapList(mpAlternates);
			
			
			 * RELATED ATS
			 * 
			mpRelatedATS.put(ConstantsUtil.ATS_NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_NAME)))?(String)resultMaps.get(ConstantsUtil.ATL_NAME) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TYPE)))?(String)resultMaps.get(ConstantsUtil.ATL_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TITLE)))?(String)resultMaps.get(ConstantsUtil.ATL_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_STATE)))?(String)resultMaps.get(ConstantsUtil.ATL_STATE) : ConstantsUtil.EMPTY_STRING);

		}

		if(bManufacturerView || bAllInfoView ) {
			
			 * LOAD MEP SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpMEPResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTYPE) : ConstantsUtil.EMPTY_STRING);
			mpMEPResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMNAME) : ConstantsUtil.EMPTY_STRING);
			mpMEPResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMREVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMREVISION) : ConstantsUtil.EMPTY_STRING);
			mpMEPResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMCURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMCURRENT) : ConstantsUtil.EMPTY_STRING);
			mpMEPResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpMEPResult.put(ConstantsUtil.MANUFACTURER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME)  : ConstantsUtil.EMPTY_STRING);
			mpMEPResult = BbUtil.filterMapList(mpMEPResult);


			
			 * LOAD SEP SECTION
			 * 
			//Contract Manufacturer View & All Info View
			mpSEPResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPTYPE) : ConstantsUtil.EMPTY_STRING);
			mpSEPResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPNAME) : ConstantsUtil.EMPTY_STRING);
			mpSEPResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPREVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPREVISION) : ConstantsUtil.EMPTY_STRING));
			mpSEPResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPCURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPCURRENT) : ConstantsUtil.EMPTY_STRING);
			mpSEPResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpSEPResult.put(ConstantsUtil.SUPPLIER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME) : ConstantsUtil.EMPTY_STRING);
			mpSEPResult = BbUtil.filterMapList(mpSEPResult);

			
			 * LOAD CERTIFICATIONS SECTION
			 * 
			MapList mlCertifications = commonBo.getCertificationClaims(context, objId);
			Iterator itrCerts = mlCertifications.iterator();
			StringBuilder sbCertName = new StringBuilder();
			StringBuilder sbCertRev = new StringBuilder();
			StringBuilder sbCertType = new StringBuilder();
			StringBuilder sbCertDesc = new StringBuilder();
			StringBuilder sbCertState = new StringBuilder();
			StringBuilder sbCertifications = new StringBuilder();
			StringBuilder sbStatus = new StringBuilder();
			StringBuilder sbCExpirationDate = new StringBuilder();

			while (itrCerts.hasNext()) {
				Map objectMap = (Map) itrCerts.next();
				formatData(sbCertName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
				formatData(sbCertRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
				formatData(sbCertType, BbUtil.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
				formatData(sbCertDesc, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION)));
				formatData(sbCertState, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
				formatData(sbCertifications, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS)));
				formatData(sbStatus, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)));
				formatData(sbStatus, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)));
			}
			mpCertification.put(ConstantsUtil.NAME, sbCertName.toString());
			mpCertification.put(ConstantsUtil.REVISION, sbCertRev.toString());
			mpCertification.put(ConstantsUtil.TYPE, sbCertType.toString());
			mpCertification.put(ConstantsUtil.DESCRIPTION, sbCertDesc.toString());
			mpCertification.put(ConstantsUtil.STATE, sbCertState.toString());
			mpCertification.put(ConstantsUtil.CERTIFICATION, sbCertifications.toString());
			mpCertification.put(ConstantsUtil.STATUS, sbStatus.toString());
			mpCertification.put(ConstantsUtil.EXPIRATIONDATE, sbCExpirationDate.toString());
		}
		
		if(bManufacturerView) {
			
			 * LOAD REACH
			 * 
			//Contract Manufacturer View & All Info View
			mpReachtResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS) : ConstantsUtil.EMPTY_STRING);
			mpReachtResult.put(ConstantsUtil.REGISTRATIONNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpReachtResult = BbUtil.filterMapList(mpReachtResult);

		}


		if(bAllInfoView) {
			//All Info View
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_VAULT)))?(String)resultMaps.get(ConstantsUtil.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ALTERNATIVEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
			String sClassifictaion = BbUtil.getClassification(resultMaps);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
			mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.SHIPRECEIVEINFO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PGASLALLOCATION, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.RERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.RERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ISBATTERY, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty(ConstantsUtil.SPEC_SUB_TYPE))?ConstantsUtil.SPEC_SUB_TYPE : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);


			
			 * LOAD LIFECYCLE SECTION
			 * 
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			mpLifeCycleApproval= BbUtil.getCOName(context, changeargs);
			swLifecycle.stop();
			LOGGER.info("RMP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
			mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);


			
			 * LOAD ORGANIZATION SECTION
			 
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = BbUtil.filterMapList(mpOrganization);


			
			 * LOAD SUBSTANCES SECTION
			 * 
			mpSubStanceResult = RawBO.getSubstances(resultMaps);

			
			 * LOAD PLANT SECTION
			 * 
			mpPlantResult = BbUtil.updatePlantInfo(resultMaps);


			
			 * LOAD OWNERSHIP SECTION
			 * 
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.MODIFIED)))?(String)resultMaps.get(ConstantsUtil.MODIFIED) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.OSO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
			StopWatch swGetEDL = new StopWatch();
			swGetEDL.start();
			String sEDList =RawMaterialPartBO.getEDList(resultMaps);
			swGetEDL.stop();
			LOGGER.info("RMP GET EDL ELAPSED TIME : "+swGetEDL.getTime());
			mapOwnerShipResult.put(ConstantsUtil.EDL, sEDList);
			mapOwnerShipResult.put(ConstantsUtil.ODL, BbUtil.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST) : ConstantsUtil.EMPTY_STRING));
			mapOwnerShipResult = BbUtil.filterMapList(mapOwnerShipResult);


			
			 * LOAD SAFETY SECTION
			 * 
			mpRegSafety.put(ConstantsUtil.CIN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLOR_INDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COLOR_INDEX) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.VALENCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVALENCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVALENCE) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.CR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICAL_REACTIVITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICAL_REACTIVITY) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.CAS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.EEN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEINECSELINCSNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEINECSELINCSNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.MO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIAL_ORIGIN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIAL_ORIGIN) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.MF, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.CG, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.MOF, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MOLECULAR_FORMULA)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MOLECULAR_FORMULA) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.IC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.RPH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_RPHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_RPHASE) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.SPH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SPHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SPHASE) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.SS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAFETYSYMBOL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAFETYSYMBOL) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety.put(ConstantsUtil.DC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGERCATEGORY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGERCATEGORY) : ConstantsUtil.EMPTY_STRING);
			mpRegSafety = BbUtil.filterMapList(mpRegSafety);

			
			 * LOAD SPECIFICATION SECTION
			 * 
			mpSpecifications.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ID) : ConstantsUtil.EMPTY_STRING);
			mpSpecifications.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME) : ConstantsUtil.EMPTY_STRING);
			mpSpecifications.put(ConstantsUtil.TYPE, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpSpecifications.put(ConstantsUtil.SAPDES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpSpecifications.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
			mpSpecifications.put(ConstantsUtil.SELECT_CURRENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT) : ConstantsUtil.EMPTY_STRING);

			
			 * LOAD REFERENCE DOCS SECTION
			 * 
			StopWatch swReference= new StopWatch();
			swReference.start();
			MRMPBO mrmpbo = new MRMPBO();
			MasterCOPBO mcop = new MasterCOPBO();
			mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
			swReference.stop();
			LOGGER.info("RMP  Reference ELAPSED TIME : "+swReference.getTime());
			//mapReferenceDocs = BbUtil.filterMapList(mapReferenceDocs);

			*//**
			 * DERIVED PARTS (RELATED PARTS)
			 * *//*
			StopWatch swDerived = new StopWatch();
			swDerived.start();
			String sDName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING;
			//mpDerivedFromResult = RawBO.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doRMP,true,false);
			//mpDerivedToResult = RawBO.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doRMP,false,true);

			mpDerivedFromResult = BbUtil.filterMapList(mpDerivedFromResult);
			mpDerivedToResult = BbUtil.filterMapList(mpDerivedToResult);
			LOGGER.info("RMP  Derived ELAPSED TIME : "+swDerived.getTime());

			
			 * SECURITY
			 * 
			StopWatch swSecurity = new StopWatch();
			swSecurity.start();
			mpSecurity =commonBo.updateSecurity(context,resultMaps);
			swSecurity.stop();
			LOGGER.info("RMP  Security ELAPSED TIME : "+swSecurity.getTime());
			
			
			 * PRODUCING FORMULA
			 * 
			mpProducingFarmula.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpProducingFarmula.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpProducingFarmula.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpProducingFarmula.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpProducingFarmula.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)  : ConstantsUtil.EMPTY_STRING);
			mpProducingFarmula.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);

		}

		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.PROFILEIDENTIFICATION, mpProfileIdResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.CHEMICALCLASSIFICATION, mpChemClassResult);
		hmAttrib.put(ConstantsUtil.PHYSICALPROPERTIES, mpPhysicalPropResult);
		hmAttrib.put(ConstantsUtil.PERFUMEPROPERTIES, mpPerfumeResult);
		hmAttrib.put(ConstantsUtil.CHEMICALMOLECULARPROPERTIES, mpChemMoleculeResult);
		hmAttrib.put(ConstantsUtil.DETERGENTSURFACTANTPROPERTIES, mpCDetergentResult);
		hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
		hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpSubStanceResult); 
		hmAttrib.put(ConstantsUtil.STARTINGMATERIALS, mpStartingMaterials);
		hmAttrib.put(ConstantsUtil.ALTERNATES, mpAlternates);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
		hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO,mpDerivedToResult);
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
		hmAttrib.put(ConstantsUtil.REACH, mpReachtResult);  
		hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
		hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult); 
		hmAttrib.put(ConstantsUtil.REGULARSAFETY, mpRegSafety);
		hmAttrib.put(ConstantsUtil.SPECIFICATIONS, mpSpecifications);
		hmAttrib.put(ConstantsUtil.CERTIFICATION, mpCertification);
		hmAttrib.put(ConstantsUtil.PRODUCINGFORMULA, mpProducingFarmula);
		hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
		hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
		hmAttrib.put(ConstantsUtil.MASTERATTRIBUTES, mpMasterAttribute);

		System.out.println("hmAttrib--------------->>>"+hmAttrib);
		pool.checkIn(context);
		sp.stop();
		System.out.println("Execution TIME::" + sp.getTime());
		System.out.println("RESULT:: \n" + mpHeaderContent);
		context.disconnect();

	}// main method
	public static void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}

}//End of Class
*/