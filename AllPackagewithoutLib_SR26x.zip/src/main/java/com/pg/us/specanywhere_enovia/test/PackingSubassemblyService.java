/*package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaCardBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PackingSubassemblyBO;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.Pattern;
import matrix.util.StringList;

public class PackingSubassemblyService {

	private static Logger LOGGER = Logger.getLogger(PackingSubassemblyService.class);

	public static void main(String[] args) throws Exception {
		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
		LOGGER.info("Enter Packing Subassembly Class");
		StopWatch sp = new StopWatch();
		sp.start();

		//String objId = "20336.41905.32642.36931";
		//String objId = "20336.41905.57154.50819";
		String objId = "20336.41905.19072.10562";
		
		LOGGER.info("PSUB CONTEXT SET ELAPSED TIME : "+sp.getTime());

		Context context = pool.checkOut();

		LOGGER.info("PSUB CONTEXT SET ELAPSED TIME ::: "+sp.getTime());
		
		boolean bAllInfoView = true;
		boolean bSupplierView = true;
		boolean bManufacturerView = true;

		PackingSubassemblyBO psubbo = new PackingSubassemblyBO();
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		Map BusinessObjectSelectableMap = psubbo.getPackingSubassemblySelectableMap(context);

		Map<String,String> mpHeaderResult = new HashMap<String,String>();
		Map<String,String> mapAttribResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mpHasATS = new HashMap<String,String>();
		Map<String,String> mpIsATS = new HashMap<String,String>();
		Map<String,String> mpTechnicalSupersedes = new HashMap<String,String>();
		Map<String,String> mpTechnicalSupersedesBy = new HashMap<String,String>();
		Map<String,String> mpNotes = new HashMap<String,String>();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Map<String,String> mpPerformChar= new HashMap<String,String>();
		Map<String,String> mapWnDResult = new HashMap<String,String>();
		Map<String,String> mapPackagingUnitResult = new HashMap<String,String>();
		Map<String,String> mapTransportUnitResult = new HashMap<String,String>();
		Map<String,String> mapPartSpecification = new HashMap<String,String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mapCosResult = new HashMap<String,String>();
		Map<String,String> mapPlantResult = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mpSecurity = new HashMap<String,String>();
		Map<String,String> mpIPClass = new HashMap<String, String>();

		StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		Map BusinessObjectRelSelectableMap = psubbo.getPSUBRelatedObjsSelectableMap(context);
		StringList slEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slRelEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.REL_SELECTS);

		StringValidatorUtil validator = new StringValidatorUtil();
		DomainObject doPSUB = psubbo.getPSUBDO(context, objId);
		MasterCOPBO mcop = new MasterCOPBO();
		FinishedProductPartBO fppBO = new FinishedProductPartBO();

		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		psubbo.addMultiList();
		Map resultMap = doPSUB.getInfo(context, slSelects);
		swAttributes.stop();
		LOGGER.info("PSUB GETINFO ELAPSED TIME : "+swAttributes.getTime());
		psubbo.removeMultiList();

		//Get Type Name
		String sType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
		String sID = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		*//**
		 * LOAD HEADER SECTION
		 * *//*
		mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.TYPE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)))?busUtil.mapType((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);		
		mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
		String sClassification = busUtil.getClassification(resultMap);
		mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));

		*//**
		 * Get the LifeCycle Section
		 * 
		 *//*
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={objId,sPhysicalId};
		StopWatch swLifecycle = new StopWatch();
		swLifecycle.start();
		//if(bAllInfoView){
		mpLifeCycleApproval = busUtil.getCOName(context, changeargs);
		//}
		swLifecycle.stop();
		LOGGER.info("PSUB  LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

		if(bAllInfoView || bManufacturerView || bSupplierView){
			*//**
			 * LOAD BASIC ATTRIBUTES SECTION
			 * *//*
			String strSAPname = (String)resultMap.get(ConstantsUtil.SELECT_SAP_NAME);
			mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID)))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
			if(strSAPname!=null){
				strSAPname = strSAPname+ConstantsUtil.SYMBL_DOT+(String)resultMap.get(ConstantsUtil.SELECT_SAP_REVISION);
				mapAttribResult.put(ConstantsUtil.NAME,strSAPname);
				mapAttribResult.put(ConstantsUtil.ONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_SAP_CURRENT)))?(String)resultMap.get(ConstantsUtil.SELECT_SAP_CURRENT) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			}
			mapAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.WAREHOUSECLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.REERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.REERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
			String sClassifictaion = busUtil.getClassification(resultMap);
			mapAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));

			*//**
			 * Is ATS
			 *//*
			//mpIsATS = busUtil.checkIsATS(context,resultMap);

			*//**
			 * Technical Supersedes 
			 *//*

			//mpTechnicalSupersedes=busUtil.getTechnicalSupersedes(context, resultMap);

			*//**
			 * LOAD PART SPECIFICATION SECTION
			 * *//*
			//mapPartSpecification = busUtil.updatePartSpecforPSUB(context, resultMap);

			*//**
			 * LOAD BOM SECTION
			 * 
			 *//*

			StopWatch swBom = new StopWatch();
			swBom.start();
			
			MapList mlEBOMList = doPSUB.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
					ConstantsUtil.TYPE_PGPHASE, slEBOMSelects, slRelEBOMSelects, false, true, (short)0,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			Map  mpPhaseBom =psubbo.getPhaseBOM(context,mlEBOMList,resultMap);
			if(mpPhaseBom.size()>0) {
				mpEBOMResult=mpPhaseBom;
			}
			
		}
		if(bAllInfoView || bSupplierView){
			mapAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);

		}
		if(bManufacturerView || bSupplierView){
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		}
		if(bManufacturerView || bAllInfoView){
			
			mapAttribResult.put(ConstantsUtil.PGASLALLOCATION, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING));
			
			*//**
			 * LOAD WND SECTION
			 * *//*
			mapWnDResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
			mapWnDResult.put(ConstantsUtil.UNITOFMEASURESYSTEM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM) : ConstantsUtil.EMPTY_STRING);
			//mapWnDResult = busUtil.filterMapList(mapWnDResult);


			*//**
			 * Packaging Weight Characteristics section
			 *//*

			if(!sType.equals(ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY)){
				MapList sl = fppBO.getPackingUnitWeightsAndDiamensionsData(context,sID);
				//mapPackagingUnitResult  =fppBO.getPackagingDimensions(context, sl,mapPackagingUnitResult);

			}else 
			{
				mapPackagingUnitResult =  fppBO.UpdatePackagingChar(context, resultMap);
			}

			MapList mlTUPFromFPP = doPSUB.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGTRANSPORTUNIT,
					ConstantsUtil.TYPE_PGTRANSPORTUNITPART, slEBOMSelects, slRelEBOMSelects, false, true, (short) 1,
					null, null, 0);

			//Removing non released parts from manufacturer
			if(bManufacturerView){
			mlTUPFromFPP=busUtil.filterPhase(mlTUPFromFPP);
			}
			//Transport Unit
			StopWatch swTup = new StopWatch();
			swTup.start();
			if(sType.equals(ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY))
			{
				mapTransportUnitResult= fppBO.UpdateTransportChar(context, resultMap);
			} else {
			//	mapTransportUnitResult = fppBO.parseTransMaplist(mlTUPFromFPP);
			}
			swTup.stop();
			LOGGER.info("PSUB TUP ELAPSED TIME : "+swTup.getTime());

			*//**
			 * LOAD MARKETS OF SALE SECTION
			 * *//*
			StringList slCos=(validator.isNotNullOrEmpty((StringList)resultMap.get(ConstantsUtil.SELECT_COS_NAME)));
			String strCos = slCos.toString();
			strCos = strCos.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
			mapCosResult.put(ConstantsUtil.COUNTRIESOFSALE, strCos);
			String strCosDateAndTime = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE));
			mapCosResult.put(ConstantsUtil.DATEANDTIMEOFLASTCOSCALC, strCosDateAndTime);
			StringList slCosRestriction = (validator.isNotNullOrEmpty((StringList)resultMap.get(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION)));
			String strCosRestriction = slCosRestriction.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
			mapCosResult.put(ConstantsUtil.COUNTRIESOFSALERESTRICTIONS,strCosRestriction);
			mapCosResult = busUtil.filterMapList(mapCosResult);
		}


		if(bAllInfoView){

			mapAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING));
			mapAttribResult.put(ConstantsUtil.ISBATTERY, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
			mapAttribResult.put(ConstantsUtil.DOESTHEPRODUCTCONTAINBATTERY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CONTAINSBATTERY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CONTAINSBATTERY) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.CUSTOMIZATIONTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);

			*//**
			 * Has ATS
			 *//*
			mpHasATS = busUtil.checkHasATS(context,resultMap);

			*//**
			 * Technical SupersedesBy 
			 *//*

			mpTechnicalSupersedesBy=busUtil.getTechnicalSupersedesBy(context, resultMap);

			*//**
			 * LOAD ORGANIZATION DATA SECTION
			 * *//*
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = busUtil.filterMapList(mpOrganization);

			*//**
			 * LOAD NOTES SECTION
			 * *//*
			mpNotes=mcop.updateNotes(context, resultMap);

			*//**
			 * LOAD PERFORMANCE CHAR SECTION
			 * *//*
					
			String sRevision = (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sPCName = (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			MapList	mlPerformAttrib = busUtil.getExtendedPerformChar(context,doPSUB,sRevision,sPCName,resultMap);
			//mpPerformChar =  busUtil.updatePerformCharcteristic(context,mlPerformAttrib,resultMap);
			
			*//**
			 * LOAD REFERENCE DOCS SECTION
			 * *//*
			
			StopWatch swReference= new StopWatch();
			swReference.start();
			FormulaCardBO fcBO = new FormulaCardBO();
			mapReferenceDocs = fcBO.updateRefDocs(context, resultMap);
			swReference.stop();
			LOGGER.info("PSUB  REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());

			*//**
			 * LOAD PLANTS SECTION
			 * *//*
			mapPlantResult = busUtil.updatePlantInfo(resultMap);

			*//**
			 * LOAD OWNERSHIP SECTION
			 * *//*
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.OSO, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMap.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
			//mapOwnerShipResult = busUtil.filterMapList(mapOwnerShipResult);
			StopWatch swGetEDL = new StopWatch();
			swGetEDL.start();
			String sEDList =psubbo.getEDList(resultMap);
			swGetEDL.stop();
			LOGGER.info("PSUB GET EDL ELAPSED TIME : "+swGetEDL.getTime());
			mapOwnerShipResult.put(ConstantsUtil.EDL, sEDList);
			mapOwnerShipResult.put(ConstantsUtil.ODL, busUtil.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST) : ConstantsUtil.EMPTY_STRING));
			mapOwnerShipResult = busUtil.filterMapList(mapOwnerShipResult);
			
			*//**
			 * LOAD SECURITY SECTION
			 * *//*
			StopWatch swSecurity = new StopWatch();
			CommonBusUtilBO bo = new CommonBusUtilBO();
			swSecurity.start();
			mpSecurity =bo.updateSecurity(context,resultMap);
			swSecurity.stop();
			LOGGER.info("PSUB  Security ELAPSED TIME : "+swSecurity.getTime());

			//IP Class
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			StringList slIpSelects = new StringList();
			slIpSelects.add(ConstantsUtil.SELECT_NAME);
			slIpSelects.add(ConstantsUtil.SELECT_ID);
			slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
			slIpSelects.add(ConstantsUtil.SELECT_TYPE);
			slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			mpIPClass =commonBo.getIpClass(context, doPSUB, slIpSelects);
		}
		
		hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mapAttribResult);
		hmAttrib.put(ConstantsUtil.HASATS, mpHasATS);
		hmAttrib.put(ConstantsUtil.ISATS, mpIsATS);
		hmAttrib.put(ConstantsUtil.TECHSUPERSEDES, mpTechnicalSupersedes);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
		hmAttrib.put(ConstantsUtil.WEIGHTSDIMENSIONSOBJECT, mapWnDResult);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.PACKINGUNIT, mapPackagingUnitResult);
		hmAttrib.put(ConstantsUtil.TRANSPORTUNIT, mapTransportUnitResult);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mapPartSpecification);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		hmAttrib.put(ConstantsUtil.MARKETOFSALE, mapCosResult);
		hmAttrib.put(ConstantsUtil.PLANTS, mapPlantResult);
		hmAttrib.put(ConstantsUtil.OWNERSHIPOBJECT, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
		hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
		hmAttrib.put(ConstantsUtil.TECHSUPERSEDESBY, mpTechnicalSupersedesBy);
		
		System.out.println("hmAttrib :: RESPONCE \n"+hmAttrib);

		System.out.println("SESSION ID :::"+context.getSession().getSessionId());
		pool.checkIn(context);
		sp.stop();
		LOGGER.info("PSUB MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "PSUB OBJECT NAME::"+resultMap.get(ConstantsUtil.SELECT_NAME));

	}
	
	
}
*/