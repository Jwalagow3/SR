/**
 * Project 		: SpecsAnywhere
 * Program 		: RawMaterialPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.springframework.util.SystemPropertyUtils;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.fop.FormulationAttribute;
import com.pg.us.specanywhere_enovia.fop.FormulationRelationship;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class RawMaterialPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(RawMaterialPartBO.class);
	static StringValidatorUtil validator = new StringValidatorUtil();
	static BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
	public RawMaterialPartBO() {
		// empty constructor
	}

	public RawMaterialPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getRmpBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getRmpBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getRmpDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public DomainObject getRmpDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	
	
	/**
	 * Method Name 			: getRMPPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getRMPPartSelectables(Context context) {
		StringList busSelect = new StringList(150);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getProfileIdentificationSelectables(context));
		busSelect.addAll(getOrgSelects(context));
		busSelect.addAll(getChemicalClassficationsSelectables(context));
		busSelect.addAll(getPhysicalPropertiesSelectables(context));
		busSelect.addAll(getPerfumePropertiesSelectables(context));
		busSelect.addAll(getChemicalMolecularSelectables(context));
		busSelect.addAll(getDetergentSurfactantSelectables(context));
		busSelect.addAll(getReachSelectables(context));
		busSelect.addAll(getSubstanceSelectables(context));
		busSelect.addAll(getStartingMaterialsSelectables(context));
		busSelect.addAll(getWeightCharSelectables(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getAlternateSelects(context));
		busSelect.addAll(getRegSafetySelectables());
		busSelect.addAll(getStabilityResults(context));
		busSelect.addAll(getFileSelects(context));
		busSelect.addAll(getIpSelects());
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	//SPEC: <13.10.2020>: Added for the Release 18x5 -- START--
	/**
	 * Method Name 			: getStabilityResults
	 * Method Description 	: Fetching "Stability" related data
	 * @param context
	 * @return
	 */
	public StringList getStabilityResults(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS);

		return busSelect;
	}
	
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	
	public static StringList getIpSelects() {
		
		StringList slIpSelects = new StringList();
		slIpSelects.add(ConstantsUtil.SELECT_NAME);
		slIpSelects.add(ConstantsUtil.SELECT_ID);
		slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
		slIpSelects.add(ConstantsUtil.SELECT_TYPE);
		slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		
		return slIpSelects;

	}
	//SPEC: <13.10.2020>: Added for the Release 18x5 -- END�--
	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACH_EXEMPT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);

		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.STR_TEMPLATE);
		
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.ATL_ORGNSOURCE);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSHELFLIFEDAYS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);

		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		busSelect.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		
		busSelect.add(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		// Guna Added for Defect 38533  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		// Guna Added for Defect 38533  18x.5.2 Release -- END
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE);//Added by Ketan for Req. no. 48322
		return busSelect;

	}

	
	/**
	 * Method Name 			: getProfileIdentificationSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getProfileIdentificationSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INCINAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICALNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EMPIRICALFORMULA);
		//SPEC: 23/02/2021: Modified for 18x.6 DEV by Bala-- START
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STANDARDCOSTPERKG);
		//SPEC: 23/02/2021: Modified for 18x.6 DEV by Bala-- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COLORINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRMCISPRONUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPERIMENTALNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALUSAGEGUIDANCE);
		//SPEC: 23/02/2021: Added by Jwala  for 18x.6.o Defect 40841 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: 23/02/2021: Added by Jwala  for 18x.6.o Defect 40841 -- START
		
		
		return busSelect;
	}

	
	/**
	 * Method Name 			: getOrgSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getOrgSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		return busSelect;

	}
	
	/**
	 * Method Name 			: getChemicalClassficationsSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getChemicalClassficationsSelectables (Context context) {
		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EINECSNUMBER);
		//Added for Defect #37134 -- START
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTIONGLOBAL);
		busSelect.add(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL);
		//Added for Defect #37134 -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAVORCLUSTERRANK);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getRegSafetySelectables
	 * Method Description 	:
	 * @return
	 */
	public static StringList getRegSafetySelectables () {
		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIAL_ORIGIN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COLOR_INDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVALENCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICAL_REACTIVITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEINECSELINCSNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MOLECULAR_FORMULA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_RPHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_SPHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAFETYSYMBOL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGERCATEGORY);
		return busSelect;
	}

	
	/**
	 * Method Name 			: getPhysicalPropertiesSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getPhysicalPropertiesSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_APPEARANCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COLOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SPECIFICGRAVITY_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MELTINGPOINT_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_BOILINGPOINT_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VISCOSITY_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_GRADE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRMAQUEOUSSOLUBILITY_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPERATURE_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FLASHPOINT_INPUTVALUE);
		return busSelect;
	}


	/**
	 * Method Name 			: getPerfumePropertiesSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getPerfumePropertiesSelectables(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGODORFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYODORDESCRIPTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYODORDESCRIPTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGODORDESCRIPTION);
		return busSelect;

	}

	
	/**
	 * Method Name 			: getChemicalMolecularSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getChemicalMolecularSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SAPONIFICATIONVALUE_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHYDROPHILICINDEX_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HYDROXYLVALUE_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACTIVITY_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_IUSPERGRAM_INPUTVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ALKALINITY_INPUTVALUE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ANIMALDERIVED);//Modified by Ajay for Req no 36979
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PHVALUE_INPUTVALUE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getDetergentSurfactantSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getDetergentSurfactantSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SO3CONTRIBUTOR);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getReachSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getReachSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getStartingMaterialsSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getStartingMaterialsSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_TYPE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_REVISION);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_PHASE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_TITLE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_STATE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_ORIGIN_SOURCE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_ID);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) 
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID); 
		busSelect.add(ConstantsUtil.COMP_NAME);
		busSelect.add(ConstantsUtil.COMP_SUBNAME);
		busSelect.add(ConstantsUtil.COMP_TITLE);
		busSelect.add(ConstantsUtil.COMP_MAXHGHT); 
		busSelect.add(ConstantsUtil.COMP_MINHGHT);
		busSelect.add(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE);
		busSelect.add(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE);  		
		busSelect.add(ConstantsUtil.COMP_QUOM);
		busSelect.add(ConstantsUtil.COMP_QTY);
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);
		busSelect.add(ConstantsUtil.COMP_CASNUM);
		busSelect.add(ConstantsUtil.COMP_STATE);
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC);
		busSelect.add(ConstantsUtil.COMP_DRYWEIGHT);
		busSelect.add(ConstantsUtil.COMP_FUNCTIONS);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_CURRENT);
		 
		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getWeightCharSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_TYPE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		return busSelect;
	}


	/**
	 * Method Name 			: getLifeCycleSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getLifeCycleSelectables (Context context) {
		StringList busSelect = new StringList();
		return busSelect;
	}

	
	/**
	 * Method Name 			: getMEPS
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getMEPS(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURER_NAME);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_ORIGINSOURCE);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_RELEASE_PHASE);
		
		return busSelect;
	}

	
	/**
	 * Method Name 			: getSEPS
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getSEPS(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME); 
		busSelect.add(ConstantsUtil.SELECT_SUPPLIER_NAME);
		busSelect.add(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_ORIGINSOURCE);
		
		return busSelect;
	}


	/**
	 * Method Name 			: getAlternateSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getAlternateSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_BASE_UOM);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE__RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE__ORIGIN_SOURCE);
		//SPEC: <13.10.2020>: Added for the Release 18x5 -- START
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_CERTIFICATIONS);
		//SPEC: <13.10.2020>: Added for the Release 18x5 -- END
		
		//SPEC: Added for Defect#37664 1.0.2 Release - Jwala -- START
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_ID);
		//SPEC: Added for Defect#37664 1.0.2 Release - Jwala -- END

		return busSelect;
	}


	/**
	 * Method Name 			: getRMPConnectedObjectBusPerformanceSpecs
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getRMPConnectedObjectBusPerformanceSpecs(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			String sType    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REVS));
			String sDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sCurrent =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_STATE));
			sCurrent=sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String sCAS 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			String sSub 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SUBNAME));
			String sQTS 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QSTCOMPOSITE));
			String sCont    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_ISCONTAM));
			String sQTY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE));
			String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE));
			String sQUOM    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));	

			String sMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			String sMFR     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sTrN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sDRY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DRYWEIGHT));
			String sFunctions =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_FUNCTIONS));
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String sQTYtype = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);

			sType = util.mapType(sType);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.REV,sRev);
			mpSubStanceResult.put(ConstantsUtil.STATE,sCurrent);
			mpSubStanceResult.put(ConstantsUtil.CAS,sCAS);
			mpSubStanceResult.put(ConstantsUtil.SUBSTANCENAME,sSub);
			mpSubStanceResult.put(ConstantsUtil.QSTARGET,sQTS);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			mpSubStanceResult.put(ConstantsUtil.IC,sCont);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.UOM,sQUOM);

			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sDRY);
			mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sFunctions);
			mpSubStanceResult.put(ConstantsUtil.PHASE, strPhase);
			mpSubStanceResult.put(ConstantsUtil.QUANTITYTYPE, sQTS);
			


		}catch(Exception e){

			LOGGER.error("Error from RawMaterialPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	
	/**
	 * Method Name 			: getMaterialCompositionAndSubstance
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getMaterialCompositionAndSubstance(Context context, Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String sRawMatId = (String) resultMaps.get(ConstantsUtil.SELECT_ID);
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID	 =  new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbCAS = new StringBuilder();
		StringBuilder sbCont = new StringBuilder();
		StringBuilder sbMAXWt = new StringBuilder();
		StringBuilder sbMInWt = new StringBuilder();
		StringBuilder sbQUOM = new StringBuilder();
		StringBuilder sbDRY = new StringBuilder();
		StringBuilder sbFunctions = new StringBuilder();
		StringBuilder sbtrClassFied = new StringBuilder();
		StringBuilder sbIPClassfication = new StringBuilder();

		//Added for Defect #37436 by Amman on 11/19/2020 -- START
		StringBuilder sbQTS = new StringBuilder();
		StringBuilder sbUF = new StringBuilder();
		StringBuilder sbFN = new StringBuilder();
		StringBuilder sbParentName = new StringBuilder();//Added by Ajay for 22x.06 Req.9264
		//Added for Defect #37436 by Amman on 11/19/2020 -- END
		//SPEC: Release SR18x.5.2 - Added for Defect# 39605  by gaikwad.tg on Date 18 Feb 2021 -- START
		DecimalFormat decimalformatter = new DecimalFormat(ConstantsUtil.PATTERN_DECIMALFORMAT);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39605  by gaikwad.tg on Date 18 Feb 2021 -- END
		try
		{
			//DomainObject doObj = new DomainObject(sRawMatId);
			DomainObject doObj = DomainObject.newInstance(context, sRawMatId);

			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slBusSelects.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slBusSelects.add(ConstantsUtil.COMP_CLASSIITEM);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
			//START :: gaikwad.tg :: Defect#37283
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME);
			//END :: gaikwad.tg :: Defect#37283
			//START :: gaikwad.tg :: Defect#39069
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
			//END :: gaikwad.tg :: Defect#39069

			StringList slRelSelects = new StringList();
			//Modified for Defect #37311 -- START
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

			//Added for Defect #37436 by Amman on 11/19/2020 -- START
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_USAGE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
			//Added for Defect #37436 by Amman on 11/19/2020 -- END
			//Modified for Defect #37311 -- END

			//SPEC : Modified by Ganesh on 6-Jan-2021 for  Requirement 38258 --START
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_NAME);
			//START :: gaikwad.tg
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
			slRelSelects.add("from.name");
			slRelSelects.add("from.id");


			//SPEC: Modified for Defect #38257 by Chandra on 01/25/2021 -- START

			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
			//added for Defect: 38263
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);

			SecurityService sec = new SecurityService();
			boolean bIsComplainceEngineer =sec.isComplainceEngineer();

			//SPEC: Modified for Defect #38257 by Chandra on 01/25/2021 -- END



			//END :: gaikwad.tg
			Pattern objType = new Pattern(ConstantsUtil.TYPE_MATERIAL);
			objType.addPattern(ConstantsUtil.TYPE_SUBSTANCE); 

			Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL);
			relType.addPattern(ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE);
			relType.addPattern(ConstantsUtil.RELATIONSHIP_SECURE_COMPONENT_SUBSTANCE);

			MapList mlComponentsAnMaterials = doObj.getRelatedObjects(context, relType.getPattern(),
					objType.getPattern(), slBusSelects, slRelSelects, false, true, (short) 0,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			if(mlComponentsAnMaterials.size() !=0){
				Map mObjectMap=doObj.getInfo(context, slBusSelects);
				doObj.close(context);
				mlComponentsAnMaterials.add(mObjectMap);
				mlComponentsAnMaterials = util.getSortedMaplistWithSequence(context, mlComponentsAnMaterials, sRawMatId);

				ARMPBO armpbo = new ARMPBO();
				mlComponentsAnMaterials = util.getUsageFlags(context, mlComponentsAnMaterials);

				String pType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
				String pName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
				String pID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
				String pRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
				String pDesc = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
				String pCurrent1 = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
				String pTitle = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

				boolean isSupplierOrSP = false;
				if(resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER)) {
					isSupplierOrSP = (boolean) resultMaps.get(ConstantsUtilIRM.IS_SUPPLIER);
				}
				if(mlComponentsAnMaterials!=null && mlComponentsAnMaterials.size()>0)
				{
					if((resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && isSupplierOrSP) || (resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && !isSupplierOrSP) || !resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER)) {
						util.formatData(sbType, util.mapType(pType));
						util.formatData(sbName, pName);
						util.formatData(sbID, pID);
						util.formatData(sbRev, pRev);
						util.formatData(sbDesc, pDesc);
						//START :: gaikwad.tg :: Defect#37283
						util.formatData(sbTitle, pTitle);

						util.formatData(sbCurrent, pCurrent1.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) ? ConstantsUtil.RELEASED : pCurrent1);
						//END :: gaikwad.tg :: Defect#38532
						util.formatData(sbCAS, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbQTS, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbUF, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbCont, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbMAXWt, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbMInWt, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbDRY, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbQUOM,ConstantsUtil.EMPTY_STRING);
						util.formatData(sbFunctions, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbtrClassFied, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbIPClassfication, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbParentName, ConstantsUtil.EMPTY_STRING);//Added by Ajay for 22x.06 Req.9264
						//util.formatData(sbFN, ConstantsUtil.EMPTY_STRING);
					}
					//Modified by Ketan for Req. no. 6045 -- END
				}
				//END :: gaikwad.tg

				Iterator objectListItr = mlComponentsAnMaterials.iterator();

				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					//SPEC: Release SR18x.6- Added by Manikanta for EBP Req# 33248- START
					String sObjID	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43165 on Date 26/05/2021 --START
					//Added by Ajay for 22x.06 Req.9264 - START
					String sObjType	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
					String sParentName	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME));

					String relName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_NAME));

					if(relName.equals(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL)) {

						String sType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
						String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String strID	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));

						String sDesc = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
						//String sTitle = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sTitle = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

						String sCurrent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
						sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
						sCurrent = sCurrent.replace(ConstantsUtil.DEVELOPMENT, ConstantsUtil.STATE_INWORK);
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
						//String sCAS = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
						String sCAS = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

						String sCont = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
						String sMAXWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
						String sMInWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
						String sQUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
						String sDRY = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));

						sMAXWt = getMaxQuantity(context, sCont, sMAXWt, sDRY, relName);


						String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION));
						if (UIUtil.isNotNullAndNotEmpty(sFunctions)) 
						{
							sFunctions=util.getIdFromPhysicalIdFunction(context,sFunctions);

						}
						//SPEC: Modified for Defect #38263 by Chandra on 01/25/2021 -- END

						String strClassFied = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.COMP_CLASSIITEM));
						String sIPClassfication = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));

						String sQTS ="" ;
						String sUF	 =  validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.FLAGS));

						String isTargetMaterial = (String) objectMap.get(FormulationAttribute.IS_TARGET_MATERIAL.getAttributeSelect(context));
						String sFill = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
						String rel = (String) objectMap.get("relationship");


						if(UIUtil.isNotNullAndNotEmpty(rel) && !bIsComplainceEngineer && rel.equalsIgnoreCase(FormulationRelationship.SECURE_COMPONENT_SUBSTANCE.getRelationship(context)) ){
							sQTS="";;
						}else
						{
							if(UIUtil.isNotNullAndNotEmpty(sFill) && UIUtil.isNotNullAndNotEmpty(isTargetMaterial)){
								sQTS	 = (sFill.equalsIgnoreCase("TRUE"))? ConstantsUtil.QS:
									(isTargetMaterial.equalsIgnoreCase("TRUE"))? ConstantsUtil.TARGET_COMPONENT : "";
							}
						}

						String sFN      =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));

						if((resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && isSupplierOrSP && sType.equalsIgnoreCase(ConstantsUtilIRM.EXTERNAL_MATERIAL)) || (resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && !isSupplierOrSP) || !resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER)) {
							util.formatData(sbType, util.mapType(sType));
							util.formatData(sbName, sName);
							util.formatData(sbID, strID);
							util.formatData(sbRev, sRev);
							util.formatData(sbDesc, sDesc);
							util.formatData(sbTitle, sTitle);
							util.formatData(sbCurrent, sCurrent);
							util.formatData(sbCAS, sCAS);
							//START :: gaikwad.tg
							util.formatData(sbFN,sFN);
							//END :: gaikwad.tg

							//Added for Defect #37436 by Amman on 11/19/2020 -- START
							util.formatData(sbQTS, sQTS);
							util.formatData(sbUF, sUF);
							util.formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
							//Added for Defect #37436 by Amman on 11/19/2020 -- END

							//Modified for Defect #37311 -- START
							if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
								sCont = ConstantsUtil.SYMBL_CAPTRUE;
							} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
								sCont = ConstantsUtil.SYMBL_CAPFALSE;
							}

							util.formatData(sbCont, sCont);

							if(!validator.isNotNullOrEmpty(sMInWt) || sMInWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
								sMInWt = ConstantsUtil.EMPTY_SPACE;
							}

							String strTempDry = util.getDryValueToDisplay(context, objectMap);
							strTempDry = util.formattingDryValueToDisplay(context,strTempDry);
							//START :: gaikwad.tg :: Defect#39069
							//Modified by Ganesh for defect 41512 & 41792 on Date <26/Mar/2021>---->start
							if(UIUtil.isNotNullAndNotEmpty(strTempDry))
							{
								if(strTempDry.equalsIgnoreCase("100"))
									strTempDry="100.0";

							}
							//modified by Ganesh for defect 41512 & 41792 on Date <26/Mar/2021>---->END
							if(!validator.isNotNullOrEmpty(sMAXWt) || sMAXWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
								sMAXWt = ConstantsUtil.EMPTY_SPACE;
							}

							//Modified for Defect #37311 -- END

							util.formatData(sbMAXWt, sMAXWt);
							util.formatData(sbMInWt, sMInWt);
							util.formatData(sbDRY, strTempDry);
							util.formatData(sbQUOM,sQUOM);

							util.formatData(sbFunctions, sFunctions);
							util.formatData(sbtrClassFied, strClassFied);
							util.formatData(sbIPClassfication, sIPClassfication);
						}
					}else if(relName.equalsIgnoreCase("Component Substance")|| relName.equalsIgnoreCase("Secure Component Substance")){
						slBusSelects = new StringList();
						slBusSelects.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
						slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME);
						slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
						slBusSelects.add(ConstantsUtil.COMP_CLASSIITEM);

						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);

						//Added for Defect #37436 by Amman on 11/25/2020 -- START
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_USAGE);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
						//Added for Defect #37436 by Amman on 11/25/2020 -- END

						//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- START
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
						slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
						slRelSelects.add("from.name");
						slRelSelects.add("from.id");

						Map objectMap2 =objectMap;// (Map) objectListItr2.next();
						String sType = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_TYPE));
						String sName = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_NAME));
						String strID	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ID));
						String sRev = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_REVISION));

						//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
						//sDesc = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_DESCRIPTION));
						String sDesc = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_DESCRIPTION));
						String sTitle = (String) objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME);
						String sCurrent = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_CURRENT));
						sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
						String sCAS = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
						String sCont = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
						String sMAXWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
						String sMInWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
						String sQUOM = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
						String sDRY = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
						String	strTempMAXWt = getMaxQuantity(context, sCont, sMAXWt, sDRY, relName);
						if(!validator.isNotNullOrEmpty(strTempMAXWt) || strTempMAXWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
							strTempMAXWt = ConstantsUtil.EMPTY_SPACE;
						}
						if(UIUtil.isNotNullAndNotEmpty(strTempMAXWt)  && !strTempMAXWt.equalsIgnoreCase("0.0"))
							strTempMAXWt = String.valueOf(decimalformatter.format(Double.parseDouble(strTempMAXWt)));

						util.formatData(sbMAXWt, strTempMAXWt);

						String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION));
						if (UIUtil.isNotNullAndNotEmpty(sFunctions)) 
						{
							sFunctions=util.getIdFromPhysicalIdFunction(context,sFunctions);
						}
						//SPEC: Modified for Defect #38263 by Chandra on 01/25/2021 -- END

						String strClassFied = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.COMP_CLASSIITEM));
						String sIPClassfication = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));

						//Modified for Defect #37436 by Amman on 11/25/2020 -- START
						String sQTS = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL));

						String sUF	 =  validator.getStringEquivalentForStringListWithComma(objectMap2.get(ConstantsUtil.FLAGS));

						//SPEC: Modified for Defect#37618 1.0.2 Release - Jwala -- END
						String sTarget = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL));

						//SPEC: Modified for Defect #38257 by Chandra on 01/25/2021 --START

						String isTargetMaterial = (String) objectMap2.get(FormulationAttribute.IS_TARGET_MATERIAL.getAttributeSelect(context));
						String sFill = (String)objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
						String rel = (String) objectMap2.get("relationship");


						if(UIUtil.isNotNullAndNotEmpty(rel) && !bIsComplainceEngineer && rel.equalsIgnoreCase(FormulationRelationship.SECURE_COMPONENT_SUBSTANCE.getRelationship(context)) ){
							sQTS="";;
						}else
						{
							if(UIUtil.isNotNullAndNotEmpty(sFill) && UIUtil.isNotNullAndNotEmpty(isTargetMaterial)){
								sQTS	 = (sFill.equalsIgnoreCase("TRUE"))? ConstantsUtil.QS:
									(isTargetMaterial.equalsIgnoreCase("TRUE"))? ConstantsUtil.TARGET_COMPONENT : "";
							}
						}
						//SPEC: Modified for Defect #38257 by Chandra on 01/25/2021 -- END	

						//START :: gaikwad.tg
						String sFN      =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));
						//START :: gaikwad.tg

						//START :: gaikwad.tg
						util.formatData(sbFN,sFN);

						if((resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && isSupplierOrSP && sType.equalsIgnoreCase(ConstantsUtilIRM.EXTERNAL_MATERIAL)) || (resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && !isSupplierOrSP) || !resultMaps.containsKey(ConstantsUtilIRM.IS_SUPPLIER)) {
							util.formatData(sbType, util.mapType(sType));
							util.formatData(sbName, sName);
							util.formatData(sbID, strID);
							util.formatData(sbRev, sRev);
							util.formatData(sbDesc, sDesc);
							util.formatData(sbTitle, sTitle);
							util.formatData(sbCurrent, sCurrent);
							util.formatData(sbCAS, sCAS);
							util.formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264

							//Added for Defect #37436 by Amman on 11/19/2020 -- START
							util.formatData(sbQTS, sQTS);
							util.formatData(sbUF, sUF);
							//Added for Defect #37436 by Amman on 11/19/2020 -- END

							//Modified for Defect #37311 -- START
							if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
								sCont = ConstantsUtil.SYMBL_CAPTRUE;
							} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
								sCont = ConstantsUtil.SYMBL_CAPFALSE;
							}

							util.formatData(sbCont, sCont);
							if(!validator.isNotNullOrEmpty(sMInWt)) { //Modified by Ketan for Defect no. 54178
								//SPEC: <07.09.2021>: Bala Modified for 39605 Defect  Dev 18x.6.0.2   -- END
								sMInWt = ConstantsUtil.EMPTY_SPACE;
							}

							String strTempDry = util.getDryValueToDisplay(context, objectMap);
							strTempDry = util.formattingDryValueToDisplay(context,strTempDry);

							if(UIUtil.isNotNullAndNotEmpty(sMInWt)) {
								sMInWt = String.valueOf(decimalformatter.format(Double.parseDouble(sMInWt)));
							}

							util.formatData(sbMInWt, sMInWt);

							if(UIUtil.isNotNullAndNotEmpty(strTempDry)  && !strTempDry.equalsIgnoreCase("0.0"))
							{
								if(strTempDry.equalsIgnoreCase("100"))
									strTempDry="100";

								else	
									strTempDry = String.valueOf(decimalformatter.format(Double.parseDouble(strTempDry)));
							}
							//modified by Ganesh for defect 41512 & 41792 on Date <26/Mar/2021>---->END
							util.formatData(sbDRY, strTempDry);
							//END :: gaikwad.tg :: Defect#39069
							//Modified for Defect #37436 by Amman on 11/24/2020 -- END

							//Added for Defect #37311 -- START
							util.formatData(sbQUOM,sQUOM);
							//Added for Defect #37311 -- END
							util.formatData(sbFunctions, sFunctions);
							util.formatData(sbtrClassFied, strClassFied);
							util.formatData(sbIPClassfication, sIPClassfication);
						}
						//Modified by Ketan for Req. no. 6045 -- END
					}
				}
				mpSubStanceResult.put(ConstantsUtil.SECURITY, sbtrClassFied.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sbIPClassfication.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.REV,sbRev.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.CAS,sbCAS.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.IP,sbCont.toString().trim());
				//Modified for Defect #37436 by Amman on 11/19/2020 -- END

				mpSubStanceResult.put(ConstantsUtil.MAX,sbMAXWt.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.MIN,sbMInWt.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.UOM,sbQUOM.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sbDRY.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sbFunctions.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.ID, sbID.toString().trim());

				//Added for Defect #37436 by Amman on 11/19/2020 -- START
				mpSubStanceResult.put(ConstantsUtil.QSTARGET,sbQTS.toString().trim());
				mpSubStanceResult.put(ConstantsUtil.UF, sbUF.toString().trim());
				mpSubStanceResult.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString().trim());//Added by Ajay for 22x.06 Req.9264
				mpSubStanceResult.put(ConstantsUtil.SEQ,sbFN.toString());
			}
		}catch(Exception e){

			LOGGER.error("Error from RawMaterialPartBO:  getMaterialCompositionAndSubstance"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	
	/**
	 * Method Name 			: getMaterialComposition
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getMaterialComposition(Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REVS));
			String sDesc = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sTitle = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_STATE));
			sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String sCAS = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			String sCont = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ISCONTAM));
			//SPEC: <13.10.2020>: Commented for the Release 18x5 -- START--
			//String sSub = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SUBNAME));
			//String sQTY = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			//SPEC: <13.10.2020>: Commented for the Release 18x5 -- END --
			String sMAXWt = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT));
			String sMInWt = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT));
			String sQUOM = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));
			String sDRY = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DRYWEIGHT));
			String sFunctions = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_FUNCTIONS));
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));

			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);
			
			sType=util.mapType(sType);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.REV,sRev);
			mpSubStanceResult.put(ConstantsUtil.STATE,sCurrent);
			mpSubStanceResult.put(ConstantsUtil.CAS,sCAS);
			//SPEC: <13.10.2020>: Commented for the Release 18x5 -- START--
			//mpSubStanceResult.put(ConstantsUtil.SUBSTANCENAME,sSub);
			//mpSubStanceResult.put(ConstantsUtil.QUANTITYTYPE,sQTY);
			//SPEC: <13.10.2020>: Commented for the Release 18x5 -- END--
			mpSubStanceResult.put(ConstantsUtil.IC,sCont);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.UOM,sQUOM);
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sDRY);
			mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sFunctions);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			mpSubStanceResult.put(ConstantsUtil.PHASE, strPhase);


		}catch(Exception e){

			LOGGER.error("Error from RawMaterialPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	/**
	 * Method Name 			: getManufacturerEquivalents
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getManufacturerEquivalents(Map resultMaps)
	{

		Map<String, String> mpManufacturerEquivalents = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			
			
			String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_ID));
			String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_TYPE));
			String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_NAME));
			String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_REVISION));
			String sDesc = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_DESCRIPTION));
			String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_CURRENT));
			sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String strMfr = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURER_NAME));
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_RELEASE_PHASE));
			
			sType=util.mapType(sType);
			mpManufacturerEquivalents.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpManufacturerEquivalents.put(ConstantsUtil.ID,sId);
			mpManufacturerEquivalents.put(ConstantsUtil.TYPE,sType);
			mpManufacturerEquivalents.put(ConstantsUtil.NAME,sName);
			mpManufacturerEquivalents.put(ConstantsUtil.REV,sRev);
			mpManufacturerEquivalents.put(ConstantsUtil.STATE,sCurrent);
			mpManufacturerEquivalents.put(ConstantsUtil.MANUFACTURER,strMfr);
			mpManufacturerEquivalents.put(ConstantsUtil.PHASE, strPhase);
			
		}catch(Exception e){

			LOGGER.error("Error from RawMaterialPartBO:  getManufacturerEquivalents"+e);
			return new HashMap();
		}
		return mpManufacturerEquivalents;
	}
	
	
	/**
	 * Method Name 			: getSupplierEquivalents
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getSupplierEquivalents(Map resultMaps)
	{

		Map<String, String> mpSupplierEquivalents = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			
			String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_TYPE));
			String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_ID));
			String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_NAME));
			String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_REVISION));
			String sDesc = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_DESCRIPTION));
			String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_CURRENT));
			sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String strSupplier = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIER_NAME));
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_RELEASE_PHASE));
			
			sType=util.mapType(sType);
			mpSupplierEquivalents.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSupplierEquivalents.put(ConstantsUtil.ID,sId);
			mpSupplierEquivalents.put(ConstantsUtil.TYPE,sType);
			mpSupplierEquivalents.put(ConstantsUtil.NAME,sName);
			mpSupplierEquivalents.put(ConstantsUtil.REV,sRev);
			mpSupplierEquivalents.put(ConstantsUtil.STATE,sCurrent);
			mpSupplierEquivalents.put(ConstantsUtil.SUPPLIER,strSupplier);
			mpSupplierEquivalents.put(ConstantsUtil.PHASE, strPhase);
			
		}catch(Exception e){

			LOGGER.error("Error from RawMaterialPartBO:  getSupplierEquivalents"+e);
			return new HashMap();
		}
		return mpSupplierEquivalents;
	}
	
	
	/**
	 * Method Name 			: getMasterAttributeData
	 * Method Description 	:
	 * @param context
	 * @param sMasterID
	 * @return
	 * @throws Exception
	 */
	public Map getMasterAttributeData(Context context, String sMasterID) throws Exception {

		Map<String, Object> mpAttribResult = new HashMap<String, Object>();
		StringList busSelect = new StringList();	
		//DomainObject doRMP =  getRmpDO(context, sMasterID);
		DomainObject doRMP = DomainObject.newInstance(context, sMasterID);
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		Map resultMaps = doRMP.getInfo(context,busSelect);
		//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- START
		doRMP.close(context);
		//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- END
		StringValidatorUtil validator = new StringValidatorUtil();
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE ,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_TEMPLATE)))?(String)resultMaps.get(ConstantsUtil.STR_TEMPLATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		
		//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
		String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String strBrand = util.getBrandInformationValue(context,sID);
		if(strBrand.isEmpty()) {
			strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
		}
		mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
		
		mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_VAULT)))?(String)resultMaps.get(ConstantsUtil.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ALTERNATIVEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);

		return mpAttribResult;
	}


	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList(){
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.COMP_TYPE); 
		slMultiSelects.add(ConstantsUtil.COMP_ID); 
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE); 
		slMultiSelects.add(ConstantsUtil.COMP_CURRENT); 
		slMultiSelects.add(ConstantsUtil.COMP_NAME);  
		slMultiSelects.add(ConstantsUtil.COMP_REVS);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC); 
		slMultiSelects.add(ConstantsUtil.COMP_TITLE); 
		slMultiSelects.add(ConstantsUtil.COMP_STATE); 
		slMultiSelects.add(ConstantsUtil.COMP_CASNUM);  		
		slMultiSelects.add(ConstantsUtil.COMP_SUBNAME);  		
		slMultiSelects.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		slMultiSelects.add(ConstantsUtil.COMP_ISCONTAM);  		
		slMultiSelects.add(ConstantsUtil.COMP_QTY);  			
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT);  	
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE);  	
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		
		slMultiSelects.add(ConstantsUtil.SELECT_ALTERNATE_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_ALTERNATE_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_ALTERNATE_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_ALTERNATE_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_ALTERNATE_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_ALTERNATE_BASE_UOM);
		slMultiSelects.add(ConstantsUtil.SELECT_ALTERNATE__RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_ALTERNATE__ORIGIN_SOURCE);
		slMultiSelects.add(ConstantsUtil.SELECT_ALTERNATE_DESCRIPTION);
		
		slMultiSelects.add(ConstantsUtil.SELECT_STARTINGMATERIAL_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_STARTINGMATERIAL_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_STARTINGMATERIAL_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_STARTINGMATERIAL_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_STARTINGMATERIAL_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_STARTINGMATERIAL_STATE);
		slMultiSelects.add(ConstantsUtil.SELECT_STARTINGMATERIAL_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_STARTINGMATERIAL_ORIGIN_SOURCE);
		
		
		slMultiSelects.add(ConstantsUtil.ATL_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_TYPE);
		slMultiSelects.add(ConstantsUtil.ATL_TITLE);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		slMultiSelects.add(ConstantsUtil.ATL_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.ATL_ORGNSOURCE);
		
		slMultiSelects.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		slMultiSelects.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		
		slMultiSelects.add(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
		
		slMultiSelects.add(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		//Added by Ajay for Req. no. 99576 - START
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEPHARMACOPEIA);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSMATERIALGRADE);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEFREETEXT);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSFREETEXT);
		//Added by Ajay for Req. no. 99576 - END
		return slMultiSelects;
	}
	//Added by Ajay for Defect 12042 - START
	public StringList addMultiList1(){
		StringList slMultiSelects = new StringList();
		slMultiSelects.add(ConstantsUtil.PRODUCING_FORMULA_NAME);
		slMultiSelects.add(ConstantsUtil.PRODUCING_FORMULA_TYPE);
		slMultiSelects.add(ConstantsUtil.PRODUCING_FORMULA_ID);
		slMultiSelects.add(ConstantsUtil.PRODUCING_FORMULA_REVISON);
		slMultiSelects.add(ConstantsUtil.PRODUCING_FORMULA_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.PRODUCING_FORMULA_STATE);
		slMultiSelects.add(ConstantsUtil.PRODUCING_FORMULA_ATTRIBUTE_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
		return slMultiSelects;
	}
	//Added by Ajay for Defect 12042 - END
	


	/**
	 * Method Name 			: removeMultiValueList
	 * Method Description 	:
	 */
	public void removeMultiValueList() 
	{
		 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SUBNAME);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QSTCOMPOSITE);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ISCONTAM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);  	
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT_INPUT_VALUE);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT_INPUT_VALUE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CURRENT); 

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		//SPEC: Added for Defect#37664 1.0.2 Release - Jwala -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_ID);
		//SPEC: Added for Defect#37664 1.0.2 Release - Jwala -- END
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_BASE_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE__RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE__ORIGIN_SOURCE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_ORGNSOURCE);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_STARTINGMATERIAL_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_STARTINGMATERIAL_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_STARTINGMATERIAL_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_STARTINGMATERIAL_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_STARTINGMATERIAL_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_STARTINGMATERIAL_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_STARTINGMATERIAL_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_STARTINGMATERIAL_ORIGIN_SOURCE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ALTERNATE_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		
		//SPEC: Release SR18x.5.2 - Added for Defect 38216 by Amman ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_PGMATERIALFUNCTIONGLOBAL);
		//SPEC: Release SR18x.5.2 - Added for Defect 38216 by Amman ## -- END
		
		// Guna Added for Defect 38531  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		// Guna Added for Defect 38531  18x.5.2 Release -- END
		// Guna Added for Defect 38533  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		// Guna Modified for Defect 38533  18x.5.2 Release -- END
		
		
		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Chandra -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Chandra -- END
				
	}

	
	/**
	 * Method Name 			: getEDList
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public static String getEDList(Map resultMaps,String ldapuser,String ldappwd) {
		String sAttrVal =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION) : ConstantsUtil.EMPTY_STRING;
		String strAttrValue=ConstantsUtil.EMPTY_STRING;
		String strValue=ConstantsUtil.EMPTY_STRING;
		StringTokenizer newValues=null;
		StringList strList=new StringList();

		if (sAttrVal != null && sAttrVal.trim().length() > 0) {
			newValues=new StringTokenizer(sAttrVal,ConstantsUtil.SYMBL_PIPE);
			while(newValues.hasMoreTokens())
			{
				strAttrValue=newValues.nextToken();
				if(null!=strAttrValue && (!strAttrValue.isEmpty())){
					strAttrValue = BbUtil.getLDAPInfo(strAttrValue.trim(), true,ldapuser,ldappwd);
					strList.addElement(strAttrValue);
					strList.sort();
					strValue = FrameworkUtil.join(strList, ConstantsUtil.SYMBL_PIPE);
				}
			}

		}
		return strValue;

	}
	
	
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sType, String sID, String sCreatedDate, DomainObject dob, String sSourceOwner, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		
		StringList slRelSelects = new StringList();

		MapList mlDerivedList = new MapList();
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, getTo, getFrom, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();
			
			StringBuilder sbDerivedType = new StringBuilder();
			StringBuilder sbSourceType=new StringBuilder();
			
			StringBuilder sbDerivedId = new StringBuilder();
			StringBuilder sbSourceId=new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				StringValidatorUtil validator = new StringValidatorUtil();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDerivedId=(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sDerivedType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=util.mapType((String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String sRev=(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				if (UIUtil.isNullOrEmpty(sOrganization)) {
					sOrganization=ConstantsUtil.EMPTY_STRING;
				}
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);
					
					util.formatData(sbDerivedType,sType);
					util.formatData(sbSourceType,sDerivedType);
					
					util.formatData(sbDerivedId,sID);
					util.formatData(sbSourceId,sDerivedId);
					
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);
					
					util.formatData(sbDerivedType,sDerivedType);
					util.formatData(sbSourceType,sType);
					
					util.formatData(sbDerivedId,sDerivedId);
					util.formatData(sbSourceId,sID);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				//util.formatData(sbRevision,sSourceRev);
				util.formatData(sbRevision,sRev);
				util.formatData(sbOwner,sSourceOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			
			mpDerived.put(ConstantsUtil.SOURCETYPE, sbSourceType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDTYPE, sbDerivedType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDID, sbDerivedId.toString());
			mpDerived.put(ConstantsUtil.SOURCEID, sbSourceId.toString());
			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : RawMaterialPartBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return mpDerived;
	}

	
	/**
	 * This Method is for getting the SEPS and MEPS
	 * 
	 * @param context
	 * @param sRelationShip
	 * @param objectMap
	 * @param bMEP
	 * @return
	 * @throws Exception
	 */

	public Map<String, String> getEquivalents(Context context, Map objectMap, boolean bMEP, String sRelationShip) {

		Map<String, String> mpEquivalents = new HashMap<String, String>();

		MapList mlList = new MapList();

		String sContextObjectId = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
				? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		if (UIUtil.isNullOrEmpty(sContextObjectId)) {

			return new HashMap();
		}
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		slBusSelects.addElement(ConstantsUtil.STR_IPCLASS);
		slBusSelects.add(ConstantsUtil.OWNERSHIP);
		if (bMEP) {
			slBusSelects.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
		} else {
			slBusSelects.add(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME);
		}

		StringList slRelSelects = new StringList();
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRDESCRIPTION);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATUS);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRCOMMENTS);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRPLANTS);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRPCP);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRBA);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRID);
		
		try {

			boolean bHasOwnerShip = false;
			String sWhere = ConstantsUtil.EMPTY_STRING;
			String sUserType = BbUtil.getUserType();
			SecurityService sct = new SecurityService();
			
			if (BbUtil.isModificatinRequired() || sct.isStaffAUGUser()) {
				sWhere = "current==Release";
			}

			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			String[] aCompany = sUserCompanies.split(",");
			StringBuilder sbCompany = new StringBuilder();

			if (aCompany.length > -1) {
				for (int i = 0; i < aCompany.length; i++) {
					if (null != aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					}
				}
			}

			//DomainObject dob = new DomainObject(sContextObjectId);
			DomainObject dob = DomainObject.newInstance(context, sContextObjectId);
			
			mlList = dob.getRelatedObjects(context, sRelationShip, DomainConstants.QUERY_WILDCARD, slBusSelects, slRelSelects,
					false, true, (short) 0, sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- START
			dob.close(context);
			//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- END
			Iterator objectListItr = mlList.iterator();

			StringList slParentOwnerShip = new StringList();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbDescription = new StringBuilder();
			StringBuilder sbManuf = new StringBuilder();
			StringBuilder sbSupp = new StringBuilder();
			StringBuilder sbPQRName = new StringBuilder();
			StringBuilder sbPQRState = new StringBuilder();
			StringBuilder sbPQRRevision = new StringBuilder();
			StringBuilder sbPQRDescription = new StringBuilder();
			StringBuilder sbPQRStatus = new StringBuilder();
			StringBuilder sbPQRComments = new StringBuilder();
			StringBuilder sbPQRPlants = new StringBuilder();
			StringBuilder sbPQRPCP = new StringBuilder();
			StringBuilder sbPQRBA = new StringBuilder();
			StringBuilder sbPQRID = new StringBuilder();
			
			String strSplier = DomainConstants.EMPTY_STRING;
			String strMfr = DomainConstants.EMPTY_STRING;
			
			//StringList strSplierList = new StringList();
			//StringList strMfrList = new StringList();

			while (objectListItr.hasNext()) {
				Map resultMaps = (Map) objectListItr.next();


				String sClassId = resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID).getClass().getSimpleName();
				if(sClassId.equalsIgnoreCase(ConstantsUtil.STRING)) {
				
					String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
					String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
					String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
					String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
					String sDesc = validator
							.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
					String sCurrent = validator
							.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
					sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
					if (bMEP) {
						strMfr = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
					} else {
						strSplier = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
					}
	
					String sPartOwnership = validator
							.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.OWNERSHIP)));
					String strClassFied = validator
							.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_IPCLASS));
					String sIPClassfication = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
					
					String sPQRName = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME));
					String sPQRState = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE));
					String sPQRRevision = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION));
					String sPQRDescription = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRDESCRIPTION));
					String sPQRStatus = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATUS));
					String sPQRComments = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRCOMMENTS));
					String sPQRPlants = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRPLANTS));
					String sPQRPCP = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRPCP));
					String sPQRBA = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRBA));
					String sPQRID = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
	
					BbUtil.formatData(sbName, sName);
					BbUtil.formatData(sbType, BbUtil.mapType(sType));

					if (BbUtil.isModificatinRequired()) {
						//modified by Ganesh for security impl------->start
						/*StringList slEachOwnership = BbUtil.filterOwnerShip(sPartOwnership);
						bHasOwnerShip = BbUtil.checkOwnerShip(sbCompany, slEachOwnership);*/
						bHasOwnerShip = BbUtil.checkHasAccess(context, sUserType, sId);
						//modified by Ganesh for security impl------->end
	
						if (bHasOwnerShip) {
							BbUtil.formatData(sbId, sId);
							BbUtil.formatData(sbRev, sRev);
							BbUtil.formatData(sbCurrent, sCurrent);
							BbUtil.formatData(sbDescription, sDesc);
							BbUtil.formatData(sbManuf, strMfr);
							BbUtil.formatData(sbSupp, strSplier);
							BbUtil.formatData(sbPQRName, sPQRName);
							BbUtil.formatData(sbPQRState, sPQRState);
							BbUtil.formatData(sbPQRRevision, sPQRRevision);
							BbUtil.formatData(sbPQRDescription, sPQRDescription);
							BbUtil.formatData(sbPQRStatus, sPQRStatus);
							BbUtil.formatData(sbPQRComments, sPQRComments);
							BbUtil.formatData(sbPQRPlants, sPQRPlants);
							BbUtil.formatData(sbPQRPCP, sPQRPCP);
							BbUtil.formatData(sbPQRBA, sPQRBA);
							BbUtil.formatData(sbPQRID, sPQRID);
						} else {
							BbUtil.formatData(sbId, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbRev, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRDescription, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRStatus, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRComments, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRPlants, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRPCP, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRBA, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRID, ConstantsUtil.NO_ACCESS);
						}
					} else {
						boolean showData = true;
						
						showData=BbUtil.checkHasAccess(context, null, sId);
						
						if (showData) {
							BbUtil.formatData(sbId, sId);
							BbUtil.formatData(sbRev, sRev);
							BbUtil.formatData(sbCurrent, sCurrent);
							BbUtil.formatData(sbDescription, sDesc);
							BbUtil.formatData(sbManuf, strMfr);
							BbUtil.formatData(sbSupp, strSplier);
							BbUtil.formatData(sbPQRName, sPQRName);
							BbUtil.formatData(sbPQRState, sPQRState);
							BbUtil.formatData(sbPQRRevision, sPQRRevision);
							BbUtil.formatData(sbPQRDescription, sPQRDescription);
							BbUtil.formatData(sbPQRStatus, sPQRStatus);
							BbUtil.formatData(sbPQRComments, sPQRComments);
							BbUtil.formatData(sbPQRPlants, sPQRPlants);
							BbUtil.formatData(sbPQRPCP, sPQRPCP);
							BbUtil.formatData(sbPQRBA, sPQRBA);
							BbUtil.formatData(sbPQRID, sPQRID);
						} else {
							BbUtil.formatData(sbId, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbRev, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRDescription, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRStatus, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRComments, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRPlants, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRPCP, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRBA, ConstantsUtil.NO_ACCESS);
							BbUtil.formatData(sbPQRID, ConstantsUtil.NO_ACCESS);
						}
						//modified by Ganesh for security impl--------->end
					 }
					
				}
	
				else 
				{
					   
					String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
					String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
					String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
					String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
					String sDesc = validator
							.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
					String sCurrent = validator
							.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
					sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
					if (bMEP) {
						strMfr = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
					} else {
						strSplier = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
					}
	
					String sPartOwnership = validator
							.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.OWNERSHIP)));
					String strClassFied = validator
							.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_IPCLASS));
					String sIPClassfication = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
					
					String sPQRPlants = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRPLANTS));
					String sPQRPCP = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRPCP));
					String sPQRBA = validator.getStringEquivalentForStringList(
							resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRBA));
					
					StringList slChildId = (StringList)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID);

					   for(int i =0; i<slChildId.size(); i++) {
						   String sEachChildId = slChildId.getElement(i);
						    
						   	StringList sPQRName = (StringList)(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME));
							StringList sPQRState = (StringList)(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE));
							StringList sPQRRevision = (StringList)(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION));
							StringList sPQRDescription = (StringList)(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRDESCRIPTION));
							StringList sPQRStatus = (StringList)(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATUS));
							StringList sPQRComments = (StringList)(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRCOMMENTS));
							StringList sPQRID = (StringList)(
									resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
						   
							BbUtil.formatData(sbName, sName);
							BbUtil.formatData(sbType, BbUtil.mapType(sType));
						 
						   if (BbUtil.isModificatinRequired()) {
							   //modified by Ganesh for security impl------->start
								/*StringList slEachOwnership = BbUtil.filterOwnerShip(sPartOwnership);
								bHasOwnerShip = BbUtil.checkOwnerShip(sbCompany, slEachOwnership);*/
							   bHasOwnerShip = BbUtil.checkHasAccess(context, sUserType, sId);
								//modified by Ganesh for security impl------->end
			
								if (bHasOwnerShip) {
									BbUtil.formatData(sbId, sId);
									BbUtil.formatData(sbRev, sRev);
									BbUtil.formatData(sbCurrent, sCurrent);
									BbUtil.formatData(sbDescription, sDesc);
									BbUtil.formatData(sbManuf, strMfr);
									BbUtil.formatData(sbSupp, strSplier);
									BbUtil.formatData(sbPQRName, sPQRName.get(i));
									BbUtil.formatData(sbPQRState, sPQRState.get(i));
									BbUtil.formatData(sbPQRRevision, sPQRRevision.get(i));
									BbUtil.formatData(sbPQRDescription, sPQRDescription.get(i));
									BbUtil.formatData(sbPQRStatus, sPQRStatus.get(i));
									BbUtil.formatData(sbPQRComments, sPQRComments.get(i));
									BbUtil.formatData(sbPQRPlants, sPQRPlants);
									BbUtil.formatData(sbPQRPCP, sPQRPCP);
									BbUtil.formatData(sbPQRBA, sPQRBA);
									BbUtil.formatData(sbPQRID, sPQRID.get(i));
			
								} else {
									BbUtil.formatData(sbId, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbRev, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRDescription, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRStatus, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRComments, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRPlants, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRPCP, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRBA, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRID, ConstantsUtil.NO_ACCESS);
								}
							} else {
								boolean showData = true;
								
								//modified by Ganesh for security impl------>start
								showData=BbUtil.checkHasAccess(context, sUserType, sId);
								
								if (showData) {
									BbUtil.formatData(sbId, sId);
									BbUtil.formatData(sbRev, sRev);
									BbUtil.formatData(sbCurrent, sCurrent);
									BbUtil.formatData(sbDescription, sDesc);
									BbUtil.formatData(sbManuf, strMfr);
									BbUtil.formatData(sbSupp, strSplier);
									BbUtil.formatData(sbPQRName, sPQRName.get(i));
									BbUtil.formatData(sbPQRState, sPQRState.get(i));
									BbUtil.formatData(sbPQRRevision, sPQRRevision.get(i));
									BbUtil.formatData(sbPQRDescription, sPQRDescription.get(i));
									BbUtil.formatData(sbPQRStatus, sPQRStatus.get(i));
									BbUtil.formatData(sbPQRComments, sPQRComments.get(i));
									BbUtil.formatData(sbPQRPlants, sPQRPlants);
									BbUtil.formatData(sbPQRPCP, sPQRPCP);
									BbUtil.formatData(sbPQRBA, sPQRBA);
									BbUtil.formatData(sbPQRID, sPQRID.get(i));
								} else {
									BbUtil.formatData(sbId, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbRev, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRDescription, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRStatus, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRComments, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRPlants, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRPCP, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRBA, ConstantsUtil.NO_ACCESS);
									BbUtil.formatData(sbPQRID, ConstantsUtil.NO_ACCESS);
								}
								//modified by Ganesh for security impl------>end
							}
							
					   }
				   }
			}
			mpEquivalents.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpEquivalents.put(ConstantsUtil.ID, sbId.toString());
			mpEquivalents.put(ConstantsUtil.TYPE, sbType.toString());
			mpEquivalents.put(ConstantsUtil.NAME, sbName.toString());
			mpEquivalents.put(ConstantsUtil.REV, sbRev.toString());
			mpEquivalents.put(ConstantsUtil.STATE, sbCurrent.toString());
			if (bMEP) {
				mpEquivalents.put(ConstantsUtil.MANUFACTURER, sbManuf.toString());
			} else {
				mpEquivalents.put(ConstantsUtil.SUPPLIER, sbSupp.toString());
			}
			mpEquivalents.put(ConstantsUtil.PQRNAME, sbPQRName.toString());
			mpEquivalents.put(ConstantsUtil.PQRSTATE, sbPQRState.toString());
			mpEquivalents.put(ConstantsUtil.PQRREVISION, sbPQRRevision.toString());
			mpEquivalents.put(ConstantsUtil.PQRDESCRIPTION, sbPQRDescription.toString());
			mpEquivalents.put(ConstantsUtil.PQRSTATUS, sbPQRStatus.toString());
			mpEquivalents.put(ConstantsUtil.PQRCOMMENTS, sbPQRComments.toString());
			mpEquivalents.put(ConstantsUtil.PQRPLANTS, sbPQRPlants.toString());
			mpEquivalents.put(ConstantsUtil.PQRPCP, sbPQRPCP.toString());
			mpEquivalents.put(ConstantsUtil.PQRBA, sbPQRBA.toString());
			mpEquivalents.put(ConstantsUtil.PQRID, sbPQRID.toString());

		} catch (Exception e) {

			LOGGER.error("Error from RawMaterialPartBO:  getEquivalents" + e);
			return new HashMap();
		}
		return BbUtil.filterMapList(mpEquivalents);
	}
	
	//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
	public static StringList getSecuritySelects(Context context) {
		
		StringList slIpSelects = new StringList();
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		
		return slIpSelects;

	}
	//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
	
	
	
	public String getMaxQuantity(Context context, String strIsContaminant, String strMaxWeight, String strQuantity, String strRelName) throws Exception {
		//START :: gaikwad.tg :: Defect#38791
		//String strWgtQty = ConstantsUtil.EMPTY_STRING;
		String strWgtQty = strMaxWeight;
		//END :: gaikwad.tg :: Defect#38791
		try {
		     //MODIFIED from TRUE to Yes :: gaikwad.tg :: Defect#38791
	         if ("Yes".equalsIgnoreCase(strIsContaminant))
	         {
	           if (UIUtil.isNullOrEmpty(strMaxWeight) || "0.0".equals(strMaxWeight)) {
	             
	             strWgtQty = strQuantity;
	           } else {
	             strWgtQty = strMaxWeight;
	           } 
	         }
	         /*if (MaterialCompositionServices.checkAccessOnSecureComposition(context, strRelName)) {
	        	 strWgtQty = ConstantsUtil.EMPTY_STRING;
	         }*/
	     } catch (Exception e) {
	    	 LOGGER.error("Error from RawMaterialPartBO:  getMaxQuantity" + e);
	     } 
	     return strWgtQty;
	   }
	//SPEC: Release SR18x.5.2 - Added for Defect# 39549  by Guna on Date 17/02/2021 -- START
	public Map getStabilityDocumentsonRM(Context context, String objId) throws Exception {
		MapList mlConnectedObjects = new MapList();
		Map rtnStabilityMap = new HashMap();
		//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- START
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- END
		try {
			
			if (UIUtil.isNotNullAndNotEmpty(objId)) {
				
				StringList slObjectSelect = new StringList(15);
				slObjectSelect.add(DomainConstants.SELECT_NAME);
				slObjectSelect.add(DomainConstants.SELECT_REVISION);
				slObjectSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				slObjectSelect.add(DomainConstants.SELECT_DESCRIPTION);
				slObjectSelect.add(DomainConstants.SELECT_ID);
				slObjectSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
				slObjectSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
				slObjectSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
				slObjectSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
				slObjectSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
				slObjectSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
				slObjectSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
				slObjectSelect.add("from[" + ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT + "].to.id");
				slObjectSelect.add("from[" + ConstantsUtil.RELATIONSHIP_PGSTABILITYTOTEMPGRP + "].to.name");
				slObjectSelect.add("from[" + ConstantsUtil.RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP + "].to.name");
				
				StringList slRelSelect = new StringList(6);
				slRelSelect.add("from."+ConstantsUtil.SELECT_ID);
				slRelSelect.add("from."+ConstantsUtil.SELECT_NAME);
				slRelSelect.add("from."+ConstantsUtil.SELECT_REVISION);
				slRelSelect.add("from."+ConstantsUtil.SELECT_TYPE);
				slRelSelect.add("from." + ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				slRelSelect.add("from."+ConstantsUtil.SELECT_CURRENT);
				
				//SPEC: Release SR18x.6.0 - Added for Defect# 42766  by gaikwad.tg on April 26, 2021 -- START :: Added extra type pattern
				String strTypePattern = ConstantsUtil.TYPE_PGPKGSTABILITYREPORT + "," + ConstantsUtil.TYPE_PGTECHNICALRATIONAL;
				//SPEC: Release SR18x.6.0 - Added for Defect# 42766  by gaikwad.tg on April 26, 2021 -- END
				String strRelPattern = ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT;
				String strPostTypePattern = ConstantsUtil.EMPTY_STRING;
				//SPEC: 08/03/2021: Modified for 18x.6 DEV by Bala-- START 
				StringBuilder sbPartName = new StringBuilder();
				StringBuilder sbPartType = new StringBuilder();
				StringBuilder sbPartRevision = new StringBuilder();
				StringBuilder sbPartID = new StringBuilder();
				StringBuilder sbPartTitle = new StringBuilder();
				StringBuilder sbStabilityName = new StringBuilder();
				StringBuilder sbStabilityId = new StringBuilder();
				//SPEC: Release SR18x.5.2 - Added for Defect# 40037  by Amman on Feb 19, 2021 -- START
				StringBuilder sbStabilityType = new StringBuilder();
				//SPEC: Release SR18x.5.2 - Added for Defect# 40037  by Amman on Feb 19, 2021 -- END
				StringBuilder sbProdExpDate = new StringBuilder();
				StringBuilder sbTotalShelfLife = new StringBuilder();
				StringBuilder sbStabTempGp = new StringBuilder();
				StringBuilder sbStabHMDGp = new StringBuilder();
				StringBuilder sbTranFreeze = new StringBuilder();
				StringBuilder sbTranHeat = new StringBuilder();
				StringBuilder sbBoudaryCond = new StringBuilder();
				String strObjWhere = "current ==Release";
				DomainObject domObj = DomainObject.newInstance(context,objId);
				//As we need to fetch objects from two different relationships with different direction we have updated both to & from side as "true"
			
				MapList mlproductparts = domObj.getRelatedObjects(context, // MatrixContext
										ConstantsUtil.RELATIONSHIP_PGDEFINESMATERIAL, // Relationship Pattern
										ConstantsUtilIRM.Stability_Document_AllowedParts, // Type Pattern
										true, // getTo
										false, // getFrom
										(short) 1, // Recurse to Level
										new StringList (DomainConstants.SELECT_CURRENT), // Object selectables
										DomainConstants.EMPTY_STRINGLIST, // Relationship selectables
										DomainConstants.EMPTY_STRING, // Object Where clause
										DomainConstants.EMPTY_STRING, // Relationship Where clause
										0, // get objects
										null, // Post Relationship Pattern
										null, // Post Type Pattern
										null);
				LOGGER.info("IRMS  Reference ELAPSED TIME : "+mlproductparts);
				
				//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- START
				domObj.close(context);
				//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- END
				Map objectMap;
				String oID = DomainConstants.EMPTY_STRING;
				String currentState = DomainConstants.EMPTY_STRING;
				if(mlproductparts.size() > 0) {
					int NumberOfpart = mlproductparts.size();
					DomainObject domProductPartObj = null;
				
					for(int i=0; i< NumberOfpart ;i++) {
						objectMap = (Map)mlproductparts.get(i);
						oID = (String) objectMap.get(DomainConstants.SELECT_ID);
						currentState = (String) objectMap.get(DomainConstants.SELECT_CURRENT);
						
						if (UIUtil.isNotNullAndNotEmpty(oID) && currentState.equals(ConstantsUtil.RELEASE))
							{
							domProductPartObj = DomainObject.newInstance(context,oID);
							mlConnectedObjects = domProductPartObj.getRelatedObjects(context, // MatrixContext
																strRelPattern, // Relationship Pattern
																strTypePattern, // Type Pattern
																false, // getTo
																true, // getFrom
																(short) 1, // Recurse to Level
																slObjectSelect, // Object selectables
																slRelSelect, // Relationship selectables
																strObjWhere, // Object Where clause
																DomainConstants.EMPTY_STRING, // Relationship Where clause
																0, // get objects
																null, // Post Relationship Pattern
																strPostTypePattern, // Post Type Pattern
																null);
															
							LOGGER.info("IRMS  Reference ELAPSED TIME : "+mlConnectedObjects);
							//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- START
							domProductPartObj.close(context);
							//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- END
							if(mlConnectedObjects.size() !=0 ) {
								for(Object quantObj:mlConnectedObjects) {
									Map quantObjMap = (Map)quantObj;
									String sStabilityId =(String)quantObjMap.get(ConstantsUtil.SELECT_ID);
									//SPEC: Release SR18x.5.2 - Added for Defect# 40037  by Amman on Feb 19, 2021 -- START
									String sStabilityType =(String)quantObjMap.get(ConstantsUtil.SELECT_TYPE);
									//Added by Jwala for defect 43958 -- START
									String strStabilityName =(String)quantObjMap.get(ConstantsUtil.SELECT_NAME);
									//Added by Jwala for defect 43958 -- END
									//SPEC: Release SR18x.5.2 - Added for Defect# 40037  by Amman on Feb 19, 2021 -- END
									String strStabTemGp =validator.getStringEquivalentForSubstituteString(quantObjMap.get("from[" + ConstantsUtil.RELATIONSHIP_PGSTABILITYTOTEMPGRP + "].to.name"));
									String strStabHMDGp =validator.getStringEquivalentForSubstituteString(quantObjMap.get("from[" + ConstantsUtil.RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP + "].to.name"));
									
									boolean showData = BbUtil.checkHasAccess(context, null, sStabilityId);
									
									//Commented by Jwala for defect 43958 -- START
									//SPEC: Added for 18x.6.0.1 ALM Defect 43393 by Jwala-- START
									/*if(!showData && BbUtil.isModificatinRequired()){
										continue;
									}*/
									//SPEC: Added for 18x.6.0.1 ALM Defect 43393 by Jwala-- END
									//Commented by Jwala for defect 43958 -- END
									
									// Added by Jwala for the defect 43393 -- START
									String strParentOid = (String)quantObjMap.get("from."+ConstantsUtil.SELECT_ID);
									String strParentState = (String)quantObjMap.get("from."+ConstantsUtil.SELECT_CURRENT);
									String strParentTitle = (String)quantObjMap.get("from."+ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
									String strParentName = (String)quantObjMap.get("from."+ConstantsUtil.SELECT_NAME);
									
									//Added by Jwala for defect 43958 -- START
									String strParentType = (String)quantObjMap.get("from."+ConstantsUtil.SELECT_TYPE);
									String strParentRev = (String)quantObjMap.get("from."+ConstantsUtil.SELECT_REVISION);
									String strProdExpDate = (String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
									String strTotalShelfLife = (String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
									String strTranFreeze = (String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
									String strTranHeat = (String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
									String strBoudaryCond = (String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
									//Added by Jwala for defect 43958 -- END
									
									boolean showParentData = BbUtil.checkHasAccess(context, null, strParentOid);
									
									if (!showData) 
									{
										//SPEC: <03.06.2021>: Bala Modified for External Requirement 33248 Revert Back changes Dev 18x.6.0.1-- START
										 //SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- START
										//if(util.isModificatinRequired())
										//continue;
										//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 07 May 2021 -- END
										//SPEC: <03.06.2021>: Bala Modified for External Requirement 33248 Revert Back changes Dev 18x.6.0.1-- END
										sStabilityId  = ConstantsUtil.NO_ACCESS;
										strStabTemGp= ConstantsUtil.NO_ACCESS;
										strStabHMDGp =ConstantsUtil.NO_ACCESS;
										
										// Added by Jwala for defect 43958 -- START
										strProdExpDate = ConstantsUtil.NO_ACCESS;
										strTotalShelfLife = ConstantsUtil.NO_ACCESS;
										strTranFreeze = ConstantsUtil.NO_ACCESS;
										strTranHeat = ConstantsUtil.NO_ACCESS;
										strBoudaryCond = ConstantsUtil.NO_ACCESS;
										// Added by Jwala for defect 43958 -- END
							
									}
									
									//Commented by Jwala for defect 43958 -- START
									//SPEC: Added for 18x.6.0.1 ALM Defect 43393 by Jwala-- START
									/*if(!showParentData && BbUtil.isModificatinRequired()){
										continue;
									}*/
									//SPEC: Added for 18x.6.0.1 ALM Defect 43393 by Jwala-- END
									//Commented by Jwala for defect 43958 -- END
									
									if(!showParentData || !strParentState.equalsIgnoreCase("Release")){
										strParentOid = ConstantsUtil.NO_ACCESS;
										strParentTitle = ConstantsUtil.NO_ACCESS;
										strParentName = ConstantsUtil.NO_ACCESS;
										strParentType = ConstantsUtil.NO_ACCESS;
										strParentRev = ConstantsUtil.NO_ACCESS;
										
										//Commented by Jwala for defect 43958 -- START
										/*strProdExpDate = ConstantsUtil.NO_ACCESS;
										strTotalShelfLife = ConstantsUtil.NO_ACCESS;
										strProdExpDate = ConstantsUtil.NO_ACCESS;
										strTranFreeze = ConstantsUtil.NO_ACCESS;
										strTranHeat = ConstantsUtil.NO_ACCESS;
										strBoudaryCond = ConstantsUtil.NO_ACCESS;*/
										//Commented by Jwala for defect 43958 -- END
									}
									
									BbUtil.formatData(sbPartID, (strParentOid));
									BbUtil.formatData(sbPartTitle, strParentTitle);
									BbUtil.formatData(sbPartName, strParentName);
									// Added by Jwala for the defect 43393 -- END
									BbUtil.formatData(sbPartType, strParentType);
									BbUtil.formatData(sbPartRevision, strParentRev);
									//BbUtil.formatData(sbStabilityName, (validator.isNotNullOrEmpty((String)quantObjMap.get(ConstantsUtil.SELECT_NAME)))?(String)quantObjMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
									BbUtil.formatData(sbStabilityName, strStabilityName);
									BbUtil.formatData(sbStabilityId, sStabilityId);
									//SPEC: Release SR18x.5.2 - Added for Defect# 40037  by Amman on Feb 19, 2021 -- START
									BbUtil.formatData(sbStabilityType, sStabilityType);
									//SPEC: Release SR18x.5.2 - Added for Defect# 40037  by Amman on Feb 19, 2021 -- END
									
									//Modified by Jwala for defect 43958 -- START
									//BbUtil.formatData(sbProdExpDate, (validator.isNotNullOrEmpty((String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE)))?(String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE) : ConstantsUtil.EMPTY_STRING);
									//BbUtil.formatData(sbTotalShelfLife, (validator.isNotNullOrEmpty((String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE)))?(String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE) : ConstantsUtil.EMPTY_STRING);
									
									BbUtil.formatData(sbProdExpDate, strProdExpDate);
									BbUtil.formatData(sbTotalShelfLife, strTotalShelfLife);
									//Modified by Jwala for defect 43958 -- END
									BbUtil.formatData(sbStabTempGp, strStabTemGp);
									BbUtil.formatData(sbStabHMDGp, strStabHMDGp);
									//Modified by Jwala for defect 43958 -- START
									//BbUtil.formatData(sbTranFreeze, (validator.isNotNullOrEmpty((String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION)))?(String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION) : ConstantsUtil.EMPTY_STRING);
									//BbUtil.formatData(sbTranHeat, (validator.isNotNullOrEmpty((String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION)))?(String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION) : ConstantsUtil.EMPTY_STRING);
									//BbUtil.formatData(sbBoudaryCond, (validator.isNotNullOrEmpty((String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS)))?(String)quantObjMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS) : ConstantsUtil.EMPTY_STRING);
									BbUtil.formatData(sbTranFreeze, strTranFreeze);
									BbUtil.formatData(sbTranHeat, strTranHeat);
									BbUtil.formatData(sbBoudaryCond, strBoudaryCond);
									//Modified by Jwala for defect 43958 -- END
						
								}
								rtnStabilityMap.put(ConstantsUtil.PRODUCTPARTNAME, sbPartName.toString());
								rtnStabilityMap.put(ConstantsUtil.ID, sbPartID.toString());
								rtnStabilityMap.put(ConstantsUtil.TYPE, sbPartType.toString());
								rtnStabilityMap.put(ConstantsUtil.PRODUCTPARTREVISION, sbPartRevision.toString());
						        rtnStabilityMap.put(ConstantsUtil.PRODUCTPARTTITLE, sbPartTitle.toString());
						        rtnStabilityMap.put(ConstantsUtil.PRODUCTEXPDATEREQ, sbProdExpDate.toString());
						        rtnStabilityMap.put(ConstantsUtil.TOTALSHELFLIFEDAYS, sbTotalShelfLife.toString());
						        rtnStabilityMap.put(ConstantsUtil.TEMPERATUREGROUP,sbStabTempGp.toString()); 
						        rtnStabilityMap.put(ConstantsUtil.HUMIDITYGROUP, sbStabHMDGp.toString());
						        rtnStabilityMap.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, sbTranFreeze.toString());
						        rtnStabilityMap.put(ConstantsUtil.TRANSPORTHEATPROTECTION, sbTranHeat.toString());
						        rtnStabilityMap.put(ConstantsUtil.BOUNDARYCONDITIONS, sbBoudaryCond.toString());
								rtnStabilityMap.put(ConstantsUtil.STABILITYREPORTLINK, sbStabilityName.toString());
								rtnStabilityMap.put(ConstantsUtil.STABILITYREPORTID, sbStabilityId.toString());
								//SPEC: Release SR18x.5.2 - Added for Defect# 40037  by Amman on Feb 19, 2021 -- START
								rtnStabilityMap.put(ConstantsUtil.STABILITYREPORTTYPE, sbStabilityType.toString());
								//SPEC: Release SR18x.5.2 - Added for Defect# 40037  by Amman on Feb 19, 2021 -- END
								//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 17 March 2021 -- START
								rtnStabilityMap.put(ConstantsUtil.PRODUCTPARTID, sbPartID.toString());
								//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 17 March 2021 -- END
								LOGGER.info("rtnStabilityMap : "+rtnStabilityMap);
							}
						}
					}
				}
				//SPEC: 08/03/2021: Modified for 18x.6 DEV by Bala-- END
			}
		} catch (Exception ex) {
			throw ex;
		}
		return rtnStabilityMap;
	}
	//SPEC: Release SR18x.5.2 - Added for Defect# 39549  by Guna on Date 17/02/2021 -- END
	//SPEC: 24/02/2021: Modified for 18x.6 DEV by Bala-- START
	public static StringList getBatteryDetailsSelects(Context context) {
			
		StringList busSelect = new StringList();
		
		busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIBATTERYCHEMISTRY);
		busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIBATTERYSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYLITHUM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTLIUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYWHRATING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYENRUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYVOLTAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYVOLUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCELLS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCAPACITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYTCUOM);
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTHEPRODUCTABATTERY);
		busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIYESNO);

		return busSelect;
	}	
	
	public Map getBatteryTypeFields(Context context, String strIfYesselectbatterytype) throws Exception

    {
		String strBatSize=ConstantsUtil.EMPTY_STRING;
		String strBatComp=ConstantsUtil.EMPTY_STRING;
		Map mRMBatterDetails = new HashMap();
		try
        {
			if(strIfYesselectbatterytype!=null && !strIfYesselectbatterytype.equals(ConstantsUtil.EMPTY_STRING)) {
				StringList slObjectSelects = getBatteryDetailsSelects (context);			
	
				MapList mlPickListObjects = DomainObject.findObjects(context, ConstantsUtil.TYPE_PGPLIBATTERYTYPE,
						strIfYesselectbatterytype, ConstantsUtil.SYMBL_DASH, DomainConstants.QUERY_WILDCARD,
						ConstantsUtil.VAULT_ESERVICEPRODUCTION, null, true, slObjectSelects);
				if(mlPickListObjects != null && ! mlPickListObjects.isEmpty())
				{
					Map mapPickListObj = (Map) mlPickListObjects.get(0);
					mRMBatterDetails.put(ConstantsUtil.BATTERYCHEMICALCOMPOSITION, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIBATTERYCHEMISTRY)))?(String)mapPickListObj.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIBATTERYCHEMISTRY) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.BATTERYSIZE, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIBATTERYSIZE)))?(String)mapPickListObj.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIBATTERYSIZE) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.LITHUMBATTERYVOLTAGEUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYVOLUOM)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYVOLUOM) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.BATTERYWEIGHT, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHT)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHT) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.BATTERYWEIGHTUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTUOM)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTUOM) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.TYPICALCAPACITYUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYTCUOM)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYTCUOM) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.BATTERYLITHUMUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTLIUOM)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTLIUOM) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.LITHUMBATTERYVOLTAGE, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYVOLTAGE)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYVOLTAGE) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.LITHUMBATTERYENERGY, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYWHRATING)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYWHRATING) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.BATTERYLITHUM, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYLITHUM)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYLITHUM) : ConstantsUtil.EMPTY_STRING); 
					mRMBatterDetails.put(ConstantsUtil.LITHUMBATTERYENERGYUOM, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYENRUOM)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYENRUOM) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.NUMBEROFCELLS, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCELLS)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCELLS) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.TYPICALCAPACITY, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCAPACITY)))?(String)mapPickListObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCAPACITY) : ConstantsUtil.EMPTY_STRING);
					mRMBatterDetails.put(ConstantsUtil.ISABUTTON, (validator.isNotNullOrEmpty((String)mapPickListObj.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIYESNO)))?(String)mapPickListObj.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIYESNO) : ConstantsUtil.EMPTY_STRING);
					//SPEC: 08/03/2021: Modified for 18x.6 DEV by Bala-- START
					//mRMBatterDetails.put(ConstantsUtil.ISTHEPRODUCTABATTERY, ConstantsUtil.SYMBL_YES);
					mRMBatterDetails.put(ConstantsUtil.BATTERYTYPE, strIfYesselectbatterytype);
					//SPEC: 08/03/2021: Modified for 18x.6 DEV by Bala-- END
				}
			//SPEC: 31/08/2021: Modified for 18x.6.0.2 Defect#42909 by Manikanta-- START
			//SPEC: Modified by Ajay for Defect. no. 66352 START
			} /*else {
				mRMBatterDetails.put(ConstantsUtil.BATTERYCHEMICALCOMPOSITION, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.BATTERYSIZE, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.LITHUMBATTERYVOLTAGEUOM, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.BATTERYWEIGHT, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.BATTERYWEIGHTUOM, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.TYPICALCAPACITYUOM, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.BATTERYLITHUMUOM, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.LITHUMBATTERYVOLTAGE, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.LITHUMBATTERYENERGY, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.BATTERYLITHUM, ConstantsUtil.EMPTY_STRING); 
				mRMBatterDetails.put(ConstantsUtil.LITHUMBATTERYENERGYUOM, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.NUMBEROFCELLS, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.TYPICALCAPACITY, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.ISABUTTON, ConstantsUtil.EMPTY_STRING);
				mRMBatterDetails.put(ConstantsUtil.BATTERYTYPE, ConstantsUtil.EMPTY_STRING);
			}*/
			//SPEC: 31/08/2021: Modified for 18x.6.0.2 Defect#42909 by Manikanta-- END
	    }
	    catch (Exception ex)
	    {
	        throw ex;
	    }
	    return mRMBatterDetails;
    }
	//SPEC: 24/02/2021: Modified for 18x.6 DEV by Bala-- END
	//SPEC: 19/03/2021: Added for 18x.6 DEV by Bala-- START
	public String getReleasedState(Context context, String sCurrent) throws Exception {
		if((null!=sCurrent && sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE))) {
			sCurrent=ConstantsUtil.RELEASED;
		}
		return sCurrent;
	}
	//SPEC: 19/03/2021: Added for 18x.6 DEV by Bala-- END
	//SPEC: Added by Ajay for Defect no. 44930 START
	public MapList getPerformanceCharCompare(matrix.db.Context context, String[] args) throws Exception {

		MapList objList = new MapList();
		
		try {
			if (args.length == 0) {
				throw new IllegalArgumentException();
			}
			String strCharInheritanceType = "";
			String partType = null;
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_CURRENT);
			objectSelects.add(DomainObject.SELECT_NAME);
			objectSelects.add(DomainObject.SELECT_TYPE);
			objectSelects.add(DomainObject.SELECT_POLICY);
			objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
			objectSelects.add(ConstantsUtil.ATTR_REFERENCE_TYPE);

			StringList relSelects = new StringList();
			relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
			relSelects.add(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_INHERITED_FROM_PLATFORM);
			//START :: gaikwad.tg
			relSelects.add("id[connection]");
			relSelects.add("from.name");
			relSelects.add("to.name");
			relSelects.add("relationship");
			//END :: gaikwad.tg
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) paramMap.get(ConstantsUtil.OBJECT_ID);
			String addNewRow = (String) paramMap.get(ConstantsUtil.ADDROW);
			String strSwitchMode = (String) paramMap.get(ConstantsUtil.SWITCHMODE);
			
			//START :: gaikwad.tg
			String relPattern = ConstantsUtil.RELATIONSHIP_EXTENDEDDATA + "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE + "," + ConstantsUtil.RELATIONSHIP_SHAREDCHARACTERISTIC+ "," + "Extended Data";

			String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + "," + ConstantsUtil.TYPE__PERFORMANCE_CHAR;
			
			
			if (UIUtil.isNotNullAndNotEmpty(objectId)) {
				
				DomainObject doObj = DomainObject.newInstance(context, objectId);
				boolean isShared = Boolean.valueOf(doObj.getInfo(context, "relationship[" + ConstantsUtil.RELATIONSHIP_SHARED_TABLE + "]")).booleanValue();
				//END :: gaikwad.tg
				String strSelectedTable = (String) paramMap.get(ConstantsUtil.SELECTEDTABLE);
				strSelectedTable = strSelectedTable.substring(strSelectedTable.lastIndexOf(ConstantsUtil.SYMBL_CHARTILDA) + 1,
						strSelectedTable.length());
				boolean isContextPushed = false;
				ContextUtil.pushContext(context, PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),
						DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
				isContextPushed = true;
				StringList selStmt = new StringList();
				selStmt.add(ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);

				selStmt.add(ConstantsUtil.STR_CLASSI_REFERENCE_ID);
				selStmt.add(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT);
				selStmt.add(ConstantsUtil.SELECT_CURRENT);
				Map partInfoMap = doObj.getInfo(context, selStmt);
				MapList conextObjectList = new MapList();
				String strContextRefType = (String) partInfoMap.get(ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);
				String masterCurState = "";
				String strConnectedRefId = ConstantsUtil.EMPTY_STRING;
				if (partInfoMap
						.containsKey(ConstantsUtil.STR_CLASSI_REFERENCE_ID)) {
					strConnectedRefId = (String) partInfoMap
							.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID);
					
					masterCurState = (String) partInfoMap
							.get(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT);
					
				}

				final String derivedFilterSelection = (String) paramMap.get(ConstantsUtil.PGVPDPERMANCECHARFILTER);
				String rangeAll = ConstantsUtil.ALL;
				String rangeLocal = ConstantsUtil.STR_LOCAL;
				String rangeReferenced = ConstantsUtil.STR_REFERENCED;
				if (ConstantsUtil.STR_R.equals(strContextRefType) && UIUtil.isNotNullAndNotEmpty(strConnectedRefId)) {
					
					
					if (isShared) {
						conextObjectList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
								false, true, (short) 2, null, null, 0);
					}
					 else {
						 conextObjectList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
									false, true, (short) 1, null, null, 0);
					}
					
					doObj.setId(strConnectedRefId);
				}


				if (ConstantsUtil.STR_R.equals(strContextRefType) && UIUtil.isNotNullAndNotEmpty(strConnectedRefId)
						&& !(ConstantsUtil.STATE_OBSOLETE.equals(masterCurState)
								|| ConstantsUtil.STATE_COMPLETE.equals(masterCurState))) {
					if (rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {
						return new MapList();
					} else {
						return conextObjectList;
					}
				}

				if (rangeAll.equalsIgnoreCase(derivedFilterSelection)) {
					
					
					StringBuffer typeWhere = new StringBuffer();
					typeWhere.append(ConstantsUtil.STR_NOTTYPE).append(ConstantsUtil.TYPE_PG_STABILITY_RESULTS);
					
					if (isShared) {
						objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
								false, true, (short) 2, null, null, 0);
					}
					 else {
						 objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
									false, true, (short) 1, null, null, 0);
					}
					

					MapList charObjList = new MapList();
					Iterator objListItr = objList.iterator();
					String strCharacteristicType = ConstantsUtil.EMPTY_STRING;

					while (objListItr.hasNext()) {
						Map ObjMap = (Map) objListItr.next();
						if (ObjMap != null && !ObjMap.isEmpty()) {
							strCharacteristicType = (String) ObjMap.get(DomainConstants.SELECT_TYPE);
							strCharInheritanceType = (String) ObjMap.get(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
							
								 if (rangeAll.equalsIgnoreCase(derivedFilterSelection)
										&& (ConstantsUtil.STR_R.equals(strContextRefType) && strCharInheritanceType.equals(ConstantsUtil.STR_LOCAL)
												&& !(ConstantsUtil.STATE_OBSOLETE.equals(masterCurState)
														|| ConstantsUtil.STATE_COMPLETE.equals(masterCurState)))) {
									charObjList.add(ObjMap);
								}
						}
					}
					
					if (!charObjList.isEmpty()
							&& !(ConstantsUtil.STR_R.equals(strContextRefType) && UIUtil.isNullOrEmpty(strConnectedRefId))) {
						objList.removeAll(charObjList);
					}
					
					Map mpTemp = new HashMap();
					MapList mlTemp = new MapList();
					for (int x = objList.size() - 1; x >= 0; x--) {
						mpTemp = (Map) objList.get(x);
						String strType = (String) mpTemp.get(DomainConstants.SELECT_TYPE);
						if (strType != null && strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) {
							String strCharType = (String) mpTemp
									.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
					
							if (strCharType != null && strCharType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC)) {
								objList.remove(x);
							}
						}
					}
					objList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.CONST_INTERGER);
					if (addNewRow != null && addNewRow.equals(ConstantsUtil.TRUE)
							&& (strSwitchMode == null || ConstantsUtil.EMPTY_STRING.equals(strSwitchMode))) {
						HashMap m = new HashMap();
						m.put(ConstantsUtil.SELECT_ID, ConstantsUtil.BLANK);
						objList.add(m);
					}

					MapList mlTempList = new MapList();
					for (int iSeq = 0; iSeq < objList.size(); iSeq++) {
						Map mpTempList = (Map) objList.get(iSeq);
						mpTempList.put(ConstantsUtil.STR_SEQUENCE, Integer.toString(iSeq + 1));
						mlTempList.add(mpTempList);
					}
					objList.clear();
					objList.addAll(mlTempList);

				}

				String strReferenceType = (String) doObj.getInfo(context, ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);
				if (rangeAll.equalsIgnoreCase(derivedFilterSelection)
						|| rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {

					if (UIUtil.isNotNullAndNotEmpty(strReferenceType)) {

						
						MapList charList = new MapList();
						if (isShared) {
							charList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
									false, true, (short) 2, null, null, 0);
						}
						 else {
							 charList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
										false, true, (short) 1, null, null, 0);
						}
						
						Iterator charListItrtr = charList.iterator();
						while (charListItrtr.hasNext()) {
							Map charMap = (Map) charListItrtr.next();
							if (charMap != null && !charMap.isEmpty()) {
								String strType = (String) charMap.get(DomainConstants.SELECT_TYPE);
								strCharInheritanceType = (String) charMap
										.get(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
								if (rangeAll.equalsIgnoreCase(derivedFilterSelection)) {
									if (UIUtil.isNotNullAndNotEmpty(strType)
											&& (strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)
													|| strType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC))) {
										String strCharType = (String) charMap.get(
												ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
										if (UIUtil.isNotNullAndNotEmpty(strCharType) && strCharType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC)
												&& ((ConstantsUtil.STR_M.equals(strContextRefType) || (ConstantsUtil.STR_R.equals(strContextRefType)
														&& (ConstantsUtil.STATE_OBSOLETE.equals(masterCurState)
																|| ConstantsUtil.STATE_COMPLETE
																		.equals(masterCurState)))))) {
											objList.add(charMap);

										}

									}
								} else if (rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {
									if (UIUtil.isNotNullAndNotEmpty(strType)
											&& (strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)
													|| strType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC))) {
										String strCharType = (String) charMap.get(
												ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
										if ((UIUtil.isNotNullAndNotEmpty(strCharType) && strCharType.equals(ConstantsUtil.TYPE_PGPERFORMANCECHARACTERISTIC))
												|| ConstantsUtil.STR_REFERENCED.equals(strCharInheritanceType)
												|| (ConstantsUtil.STR_R.equals(strContextRefType) && (ConstantsUtil.STATE_OBSOLETE
														.equals(masterCurState)
														|| ConstantsUtil.STATE_COMPLETE.equals(masterCurState))))
										{
											objList.add(charMap);

										}
									}
								}
							}
						}
					}
				}

				partType = doObj.getInfo(context, DomainConstants.SELECT_TYPE);
				if (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(partType) 
						&& (rangeAll.equalsIgnoreCase(derivedFilterSelection)
								|| rangeReferenced.equalsIgnoreCase(derivedFilterSelection))) {
					objList = getEbomPartsCharacterstics(context, paramMap, doObj, objList, derivedFilterSelection);
					return objList;
				}

				if (ConstantsUtil.STR_R.equals(strContextRefType) && conextObjectList != null && !conextObjectList.isEmpty()
						&& !rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {
					objList.addAll(conextObjectList);
				}
				if (ConstantsUtil.STR_R.equals(strContextRefType) && rangeLocal.equalsIgnoreCase(derivedFilterSelection)
						&& strCharInheritanceType.equals(ConstantsUtil.STR_LOCAL)) {
					return objList;
				}
				if (ConstantsUtil.STR_R.equals(strContextRefType) && rangeLocal.equalsIgnoreCase(derivedFilterSelection)) {
					objList = conextObjectList;
				}
				if (isContextPushed)
					ContextUtil.popContext(context);
			}
		} catch (Exception ex) {
			LOGGER.error("Error from PerformanceCharcteristics:  getPerformanceChar"+ex);
			return new MapList();
		}	
		return objList;
	}
	private MapList getEbomPartsCharacterstics(Context context, Map paramMap, DomainObject finishedPartDO,
			MapList objList, String derivedFilterSelection) throws Exception {
		MapList ebomCharList = new MapList();
		MapList returnList = new MapList();
		PerformanceCharcteristics pefChar = new PerformanceCharcteristics();
		String[] newArguments = null;
		StringList strlObjectSelectable = new StringList(3);
		strlObjectSelectable.add(DomainConstants.SELECT_ID);
		strlObjectSelectable.add(DomainConstants.SELECT_TYPE);
		strlObjectSelectable.add(DomainConstants.SELECT_NAME);

		StringList strlRelSelectable = new StringList(3);
		strlRelSelectable.add(DomainRelationship.SELECT_FROM_TYPE);
		strlRelSelectable.add(DomainRelationship.SELECT_TO_TYPE);
		strlRelSelectable.add(DomainRelationship.SELECT_FROM_ID);

		String ebomPartId = null;
		String ebomPartName = null;
		String strDerivedPath = null;
		String relFromType = null;
		String relToType = null;
		String relFromId = null;
		String rangeAll = ConstantsUtil.ALL;

		if (objList != null && objList.size() > 0 && rangeAll.equalsIgnoreCase(derivedFilterSelection)) {
			returnList.addAll(objList);
		}

		MapList conectedEBOMPartList = finishedPartDO.getRelatedObjects(context, DomainObject.RELATIONSHIP_EBOM,
				ConstantsUtil.TYPE_PG_CUSTOMERUNIT + "," + ConstantsUtil.TYPE_PGINNERPACKUNITPART + ","
						+ ConstantsUtil.TYPE_PGCONSUMERUNITPART,
				strlObjectSelectable, strlRelSelectable, false, true, (short) 0, "", null, 0);
		
		Iterator ebomItr = conectedEBOMPartList.iterator();
		while (ebomItr.hasNext()) {
			Map partMap = (Map) ebomItr.next();
			ebomPartId = (String) partMap.get(DomainConstants.SELECT_ID);
			ebomPartName = (String) partMap.get(DomainConstants.SELECT_NAME);
			relFromType = (String) partMap.get(DomainRelationship.SELECT_FROM_TYPE);
			relToType = (String) partMap.get(DomainRelationship.SELECT_TO_TYPE);
			relFromId = (String) partMap.get(DomainRelationship.SELECT_FROM_ID);
			
			if (ConstantsUtil.TYPE_PG_CUSTOMERUNIT.equals(relFromType) && ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(relToType)) {
				returnList.clear();
				ebomPartId = relFromId;
				if (UIUtil.isNotNullAndNotEmpty(ebomPartId)) {
					ebomPartName = new DomainObject(ebomPartId).getInfo(context, DomainConstants.SELECT_NAME);
				}
			}
			paramMap.put(ConstantsUtil.STRING_OBJECTID, ebomPartId);
			paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, rangeAll);
			newArguments = JPO.packArgs(paramMap);
			ebomCharList.addAll(pefChar.getMicroChar(context, newArguments));

			if (relFromType.equals(ConstantsUtil.TYPE_PG_CUSTOMERUNIT) && relToType.equals(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
				break;
			}
		}
			return ebomCharList;
	}
	//SPEC: Added by Ajay for Defect no. 44930 END
}
