/**
 * Project 		: SpecsAnywhere
 * Program 		: PackagingMaterialPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.fop.FormulationRelationship;
import com.pg.us.specanywhere_enovia.fop.FormulationSubstituteConstants;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class PackagingMaterialPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(PackagingMaterialPartBO.class);
	BusObjectAttribUtil UTIL = new BusObjectAttribUtil();
	StringValidatorUtil VALIDATOR = new StringValidatorUtil();
	
	
	public PackagingMaterialPartBO() {
		// empty constructor
	}

	public PackagingMaterialPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getPmpBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getPmpBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getPmpDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public DomainObject getPmpDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize DomainObject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getPackagingMaterialPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getPackagingMaterialPartSelectables(Context context) {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		busSelect.addAll(getPlantBusSelectable(context));
		busSelect.addAll(getWndBusSelectable(context));
		busSelect.addAll(getCosSelectable(context));
		busSelect.addAll(getManufEquivSelectable(context));
		busSelect.addAll(getFileSelects(context));
		busSelect.addAll(getWeightCharacterSelectable(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		
		busSelect.addAll(getSubstanceSelectables(context));
		
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
		
		return mapSelecables;
	}
	

	
	//SPEC: <11.06.2020>: Added for req 18x.5 ## -- START
		/**
		 * Method Name 			: getSubstanceSelectables
		 * Method Description 	: 
		 * @param context
		 * @return
		 */
		public static StringList getSubstanceSelectables (Context context) {
			StringList busSelect = new StringList(24);
			busSelect.add(ConstantsUtil.SELECT_TYPE); 
			busSelect.add(ConstantsUtil.SELECT_ID); 
			busSelect.add(ConstantsUtil.SELECT_NAME);  
			busSelect.add(ConstantsUtil.SELECT_DESCRIPTION); 
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE); 
			busSelect.add(ConstantsUtil.SELECT_CURRENT); 
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS); 
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT); 
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);  		
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME);  	
			//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			
			busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
			busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
			busSelect.add("from[pgMaterialtopgPLIEnvironmentalClass].to.name"); // added for 37260
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_SUBSTANCENAME);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
			return busSelect;
		}
	
	
	
	/**
	 * Method Name 			: getWeightCharacterSelectable
	 * Method Description 	: Fetching "Weight Characteristics" related data
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharacterSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		return busSelect;
	}
	
	/**
	 * Method Name 			: getPMPRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getPMPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBusSelects(context));
		relSelect.addAll(getRelSelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}
	
	
	public static StringList getIpSelects() {
		
		StringList slIpSelects = new StringList();
		slIpSelects.add(ConstantsUtil.SELECT_NAME);
		slIpSelects.add(ConstantsUtil.SELECT_ID);
		slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
		slIpSelects.add(ConstantsUtil.SELECT_TYPE);
		slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		
		return slIpSelects;

	}
	
	
	
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	
	/**
	 * Method Name 			: getBusSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBusSelects(Context context) {
		StringList objectSelects = new StringList();
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		objectSelects.add(ConstantsUtil.SELECT_NAME);
		objectSelects.add(ConstantsUtil.SELECT_TYPE);
		objectSelects.add(ConstantsUtil.SELECT_ID);
		objectSelects.add(ConstantsUtil.SELECT_REVISION);
		objectSelects.add(ConstantsUtil.SELECT_CURRENT);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		//SPEC: <11-10-2020>: Added for 18x5 Release -- START --
		objectSelects.add(ConstantsUtil.SELECT_HISTORY);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHASMULTIPLEGTINS);
		objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOAIMPACTCONFIRMATION);
		//SPEC: <11-10-2020>: Added for 18x5 Release -- END --

		return objectSelects;

	}
	
	
	/**
	 * Method Name 			: getRelSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getRelSelects(Context context) {
		StringList relSelects = new StringList();
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID);
		relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelects.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelects.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelects.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
		
		//Added for Defect# 37591 -- START
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
		
		
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --START
		relSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --END
		return relSelects;

	}
	
	
	/**
	 * Method Name 			: addMultiValueConstants
	 * Method Description 	:
	 */
	public StringList addMultiValueConstants(){
		
		StringList slMultiSelects =  new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);  
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);  
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		
		slMultiSelects.add(ConstantsUtil.COMP_TYPE);
		slMultiSelects.add(ConstantsUtil.COMP_ID);
		slMultiSelects.add(ConstantsUtil.COMP_NAME);  
		slMultiSelects.add(ConstantsUtil.COMP_REVS);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC); 
		slMultiSelects.add(ConstantsUtil.COMP_TITLE);
		slMultiSelects.add(ConstantsUtil.COMP_QTY);
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT);
		slMultiSelects.add(ConstantsUtil.COMP_METALENVCLASS); 
		slMultiSelects.add(ConstantsUtil.COMP_POSTCONSUMER);
		slMultiSelects.add(ConstantsUtil.COMP_MANUF);  		
		slMultiSelects.add(ConstantsUtil.COMP_COMENT);
		slMultiSelects.add(ConstantsUtil.COMP_MARKETNAME);  	
		slMultiSelects.add(ConstantsUtil.COMP_SEQUENCE);  		
		slMultiSelects.add(ConstantsUtil.COMP_MATELAYER);
		slMultiSelects.add(ConstantsUtil.COMP_CURRENT); 
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_POSTINDUSTRIAL);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		
		return slMultiSelects;
		
	}
	
	
	/**
	 * Method Name 			: removeMultiValueConstants
	 * Method Description 	:
	 */
	public void removeMultiValueConstants(){
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_METALENVCLASS); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_POSTCONSUMER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MANUF);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_COMENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MARKETNAME);  	
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SEQUENCE);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MATELAYER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CURRENT); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_POSTINDUSTRIAL);
		
	}
	
	
	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.STRPRINTINGPROSS);
		busSelect.add(ConstantsUtil.LEGACYENVCLASSNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSECURITYSTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGUNIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPARTCOLOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDECORATIONDETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_CONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM);
		busSelect.add(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);

		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_ID);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);

		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END	
		
		//SPEC: 04/11/2020: Added for 18x.5 Defect 37084 -- START
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: 04/11/2020: Added for 18x.5 Defect 37084 -- END

		
		
		//SPEC: <11.20.2020>: Chandra Added for Defect :37506 ## --START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHASMULTIPLEGTINS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOAIMPACTCONFIRMATION);
		//SPEC: <11.20.2020>: Chandra Added for Defect :37506 ## --END
		
		//SPEC: Release SR18x.5.2: Modified related to Defect 37289 by Amman ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY);
		//SPEC: Release SR18x.5.2: Modified related to Defect 37289 by Amman ## -- END
		
		//SPEC: Modified for Defect#37755 1.0.2 Release - Jwala -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		//SPEC: Modified for Defect#37755 1.0.2 Release - Jwala -- END
		// Guna Added for Defect 39147  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.PSUB_PGMASTER);
		busSelect.add(ConstantsUtil.PSUB_PGMASTERID);
		busSelect.add(ConstantsUtil.PSUB_PGMASTERTYPE);
		// Guna Added for Defect 39147  18x.5.2 Release -- END
		//SPEC: <06.03.2023>: Satyam Added for Req 46464 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENTPACKFAMILY1);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENTPACKFAMILY2);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENTPACKFAMILY3);
		//SPEC: <06.03.2023>: Satyam Added for Req 46464 -- END
		return busSelect;
	}


	/**
	 * Method Name 			: getManufEquivSelectable
	 * Method Description 	: Fetching "Manufacturing Equivalent" data
	 * @param context
	 * @return
	 */
	public StringList getManufEquivSelectable(Context context) {
			
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_NAME);
			busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_ID);
			busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_REVISION);
			busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_TYPE);
			busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_DESCRIPTION);
			busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_CURRENT);
			return busSelect;
		}
	
	
	/**
	 * Method Name 			: getSupplierEquivSelectable
	 * Method Description 	: Fetching "Supplier Equivalent" data
	 * @param context
	 * @return
	 */
	public StringList getSupplierEquivSelectable(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_ID);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_CURRENT);
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getCosSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public StringList getCosSelectable(Context context) {
		
		StringList busSelect = new StringList();
		return busSelect;
	}

	
	/**
	 * Method Name 			: getWndBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public StringList getWndBusSelectable(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getMasterAttributeData
	 * Method Description 	:
	 * @param context
	 * @param sMasterID
	 * @return
	 * @throws Exception
	 */
	public Map getMasterAttributeData(Context context, String sMasterID) throws Exception {
		Map<String, Object> mpAttribResult = new HashMap<String, Object>();
		StringList busSelect = new StringList();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		DomainObject doPmp =  getPmpDO(context, sMasterID);


		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getCommonDataBusSelectable(context));
		Map resultMaps = doPmp.getInfo(context,busSelect);
		//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- START
		doPmp.close(context);
		//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- END
		StringValidatorUtil validator = new StringValidatorUtil();
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
		mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		
		//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION) : ConstantsUtil.EMPTY_STRING);
		String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String strBrand = util.getBrandInformationValue(context,sID);
		if(strBrand.isEmpty()) {
			strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
		}
		mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
		
		mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONHEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONDEPTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.INNERWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.INNERLENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.INNERHEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DIMENSIONUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRINTINGPROCESS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRPRINTINGPROSS)))?(String)resultMaps.get(ConstantsUtil.STRPRINTINGPROSS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DECORATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);		
		mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		String sClassifictaion = util.getClassification(resultMaps);
		mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
		
		return mpAttribResult;
	}
	
	
	/**
	 * Method Name 			: getPlantBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public StringList getPlantBusSelectable(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sType, String sID, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		
		StringList slRelSelects = new StringList();

		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, getTo, getFrom, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();
			
			StringBuilder sbDerivedType = new StringBuilder();
			StringBuilder sbSourceType=new StringBuilder();
			
			StringBuilder sbDerivedId = new StringBuilder();
			StringBuilder sbSourceId=new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				StringValidatorUtil validator = new StringValidatorUtil();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDerivedId=(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sDerivedType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=util.mapType((String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				if (UIUtil.isNullOrEmpty(sOrganization)) {
					sOrganization=ConstantsUtil.EMPTY_STRING;
				}
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);
					
					util.formatData(sbDerivedType,sType);
					util.formatData(sbSourceType,sDerivedType);
					
					util.formatData(sbDerivedId,sID);
					util.formatData(sbSourceId,sDerivedId);
					
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);
					
					util.formatData(sbDerivedType,sDerivedType);
					util.formatData(sbSourceType,sType);
					
					util.formatData(sbDerivedId,sDerivedId);
					util.formatData(sbSourceId,sID);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);

			}
			
			mpDerived.put(ConstantsUtil.SOURCETYPE, sbSourceType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDTYPE, sbDerivedType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDID, sbDerivedId.toString());
			mpDerived.put(ConstantsUtil.SOURCEID, sbSourceId.toString());
			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : PackagingMaterialPartBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return mpDerived;
	}
	
	/**
	 * Method Name 			: getSubstanceRelSelectables
	 * Method Description 	: New Method has been added for 18x.5 to get Substance Rel Selectables
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceRelSelectables (Context context) 
	{
		StringList relSelects = new StringList();
		
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);  		
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER);
		relSelects.add("attribute[Comment]");
		//START gaikwad.tg
		relSelects.add("from.name");
		relSelects.add("from.id");
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT);  		
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT);
		//END :: gaikwad.tg
		
		//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for Internal Defect on 05/18/2021 - START
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE);
		//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for Internal Defect on 05/18/2021 - END
		
		relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
		
		return relSelects;
		
	}
	/**
	 * Method Name 			: formatData
	 * Method Description 	: New Method has been added for 18x.5 to formatData
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	
	//SPEC: 10/12/2020: Modified for Defect #37525 -- Start
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	: 
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	//SPEC : Modified by Chandra on 05-Jan-2021 for  Requirement 38258  --START
	//public Map getSubstances(Context context, String mpContextObjectId)
	public Map getSubstances(Context context, Map mpContextObject)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId=new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbPCID=new StringBuilder();
		StringBuilder sbDesc=new StringBuilder();
		StringBuilder sbPCED=new StringBuilder();
		StringBuilder sbCMT = new StringBuilder();
		StringBuilder sbMaxWt = new StringBuilder();
		StringBuilder sbMinWt = new StringBuilder();
		StringBuilder sbQOM=new StringBuilder();
		StringBuilder sbQTY=new StringBuilder();
		StringBuilder sbMLyr=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		StringBuilder sbFN = new StringBuilder();
		StringBuilder sbMFR = new StringBuilder();
		StringBuilder sbTrn = new StringBuilder();
		StringBuilder sbMlLgc = new StringBuilder();
		StringBuilder sbNSPCG = new StringBuilder();
		StringBuilder sbParentName = new StringBuilder();//Added by Ajay for 22x.06 Req.9264
		// Guna Added for Defect 37743  18x.5.2 Release -- START
		BigDecimal dDefaultValue = BigDecimal.valueOf(0.0);
		// Guna Added for Defect 37743  18x.5.2 Release -- END
		try
		{
			
			String sContextObjectId	 =  validator.getStringEquivalentForStringList(mpContextObject.get(ConstantsUtil.SELECT_ID));
			String sContextName	 =  validator.getStringEquivalentForStringList(mpContextObject.get(ConstantsUtil.SELECT_NAME));
			String sContextType	 =  validator.getStringEquivalentForStringList(mpContextObject.get(ConstantsUtil.SELECT_TYPE));
			String sContextDesc	 =  validator.getStringEquivalentForSubstituteString(mpContextObject.get(ConstantsUtil.SELECT_DESCRIPTION));
			String sContextTitle	 =  validator.getStringEquivalentForSubstituteString(mpContextObject.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
			String sContextCurrent	 =  validator.getStringEquivalentForString(mpContextObject.get(ConstantsUtil.SELECT_CURRENT));
			//SPEC : Modified for Defect #38200 by Chandra on 01/22/2021 -- START
			String sLegacyValue = util.getLegacyName(context,sContextObjectId,ConstantsUtil.LEGACYENVCLASSNAME);
			//SPEC : Modified for Defect #38200 by Chandra on 01/22/2021 -- END
			if(UIUtil.isNotNullAndNotEmpty(sContextObjectId))
			{
				DomainObject contextObj = DomainObject.newInstance(context,sContextObjectId);

				SecurityService sec= new SecurityService();
				String sUserType =sec.getUserType();
				String sWhere=ConstantsUtil.EMPTY_STRING;
				
				if (sUserType.equals(ConstantsUtil.PG_CM) || sUserType.equals(ConstantsUtil.PG_SP)) {
					//SPEC: Modified by Jwala for 18x.6 External Dev -- START
					//sWhere=(String)ConstantsUtil.RELEASED;
					//SPEC: <11.05.2021>: Bala Added for 33248 External Req  Dev 18x.6.0.1   -- START
					//sWhere=ConstantsUtil.STATE_APPROVED ;
					//SPEC: <06.09.2022>: Satyam Modified for Defect 50106 -- START
					StringBuilder sCurrent = new StringBuilder();
					sCurrent.append("current==");
					sCurrent.append(ConstantsUtil.STATE_APPROVED + " || current==");
					sCurrent.append(ConstantsUtil.STATE_RELEASE + " || current==");
					sCurrent.append(ConstantsUtil.RELEASED + " || current==");
					sCurrent.append(ConstantsUtilIRM.STATE_ACTIVE);
					sWhere = sCurrent.toString();
					//SPEC: <06.09.2022>: Satyam Modified for Defect 50106 -- END
					//SPEC: Modified by Jwala for 18x.6 External Dev -- END
				}
				
				//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 06 May 2021 -- START
				boolean isExternal=util.isModificatinRequired();
				

				//Added by Pooja for 22x Defect 50271 -- START
				Pattern objType = new Pattern(ConstantsUtil.TYPE_MATERIAL);
				objType.addPattern(ConstantsUtil.TYPE_SUBSTANCE);

				Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL);
				relType.addPattern(ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE);
				relType.addPattern(ConstantsUtil.RELATIONSHIP_SECURE_COMPONENT_SUBSTANCE);
				
				MapList mlRelatedIMPSList = contextObj.getRelatedObjects(context, 
						relType.getPattern(),
						objType.getPattern(), 
						getSubstanceSelectables(context), 
						getSubstanceRelSelectables(context), 
						false, 
						true, 
						(short)0, //Expand level to all 
						sWhere,
						ConstantsUtil.EMPTY_STRING,
						ConstantsUtil.ZERO_LEVEL);
				//Added by Pooja for 22x Defect 50271 -- END	
				contextObj.close(context);
				//SPEC: 29-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50169-- START
				if(sContextType.equals(ConstantsUtil.TYPE_DEVICEPRODUCTPART))
				{
				//SPEC: 29-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50169-- END
				//SPEC: <04.03.2022>: Guna Added for 46847 Defect  Dev 18x.6.0.3   -- START
					mlRelatedIMPSList =getSortedSequence(context,mlRelatedIMPSList);
				//SPEC: <04.03.2022>: Guna Added for 46847 Defect  Dev 18x.6.0.3   -- END
				}
				else {
					mlRelatedIMPSList = util.getSortedMaplistWithSequence(context, mlRelatedIMPSList, sContextObjectId);
				}	
				
				String strTempPostConsumerRecycled = DomainConstants.EMPTY_STRING;
				String strTempPostIndustrialRecycled = DomainConstants.EMPTY_STRING;
				boolean isSupplierOrSP = false;
				if(mpContextObject.containsKey(ConstantsUtilIRM.IS_SUPPLIER)) {
					isSupplierOrSP = (boolean) mpContextObject.get(ConstantsUtilIRM.IS_SUPPLIER);
				}
				if(mlRelatedIMPSList!=null && mlRelatedIMPSList.size()>0) 
				{	
					
					strTempPostConsumerRecycled = UTIL.getPostRecycledContent(context, mlRelatedIMPSList, ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT);
					strTempPostIndustrialRecycled = UTIL.getPostRecycledContent(context, mlRelatedIMPSList, ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
					String sType = UTIL.getPostRecycledContent(context, mlRelatedIMPSList, ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
					if((mpContextObject.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && isSupplierOrSP && sType.equalsIgnoreCase(ConstantsUtilIRM.EXTERNAL_MATERIAL)) || (mpContextObject.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && !isSupplierOrSP) || !mpContextObject.containsKey(ConstantsUtilIRM.IS_SUPPLIER)) {
						util.formatData(sbType,util.mapType(sContextType));
						formatData(sbName,sContextName);
						formatData(sbDesc,sContextDesc);
						formatData(sbCurrent,util.mapType(sContextCurrent));
						formatData(sbId,sContextObjectId);
						formatData(sbTitle,sContextTitle);
						formatData(sbMaxWt,ConstantsUtil.EMPTY_STRING);
						formatData(sbMinWt,ConstantsUtil.EMPTY_STRING);
						formatData(sbQOM,ConstantsUtil.EMPTY_STRING);
						formatData(sbMFR,ConstantsUtil.EMPTY_STRING);
						formatData(sbFN,ConstantsUtil.EMPTY_STRING);
						formatData(sbTrn,ConstantsUtil.EMPTY_STRING);
						formatData(sbMlLgc,sLegacyValue);
						formatData(sbMLyr,ConstantsUtil.EMPTY_STRING);
						formatData(sbQTY,ConstantsUtil.EMPTY_STRING);
						formatData(sbPCED,strTempPostConsumerRecycled);
						formatData(sbPCID,strTempPostIndustrialRecycled);
						formatData(sbCMT,ConstantsUtil.EMPTY_STRING);
						formatData(sbPhase,ConstantsUtil.EMPTY_STRING);
						formatData(sbNSPCG,DomainConstants.EMPTY_STRING);
						formatData(sbParentName, ConstantsUtil.EMPTY_STRING);//Added by Ajay for 22x.06 Req.9264
					}
				}
				if(mlRelatedIMPSList.size()>0) {
					Iterator objectListItr = mlRelatedIMPSList.iterator();
					while(objectListItr.hasNext()) {

						Map resultMaps = (Map) objectListItr.next();

						String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
						String sType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
						String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
						//Guna Modified for Defect 38160 18x.5.2 Release --START 
						boolean bHasAccess =false;

						//Guna Modified for Defect 38138 18x.5.2 Release --START 
						if(!sType.equals(ConstantsUtil.TYPE_SUBSTANCE) && !sType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL)){
							//Guna Modified for Defect 38138 18x.5.2 Release --END 
							bHasAccess = util.checkHasAccess(context, null, strID);
						}else{
							bHasAccess =true;
						}
						//Guna Modified for Defect 38160 18x.5.2 Release --END
						if (!bHasAccess) {

							strID=ConstantsUtil.NO_ACCESS;
						}
						String sDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
						String sTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sQTY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY_INPUTVALUE));
						String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT));
						String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT));
						String sMlLgc   =  validator.getStringEquivalentForSubstituteString(resultMaps.get("from[pgMaterialtopgPLIEnvironmentalClass].to.name"));
						String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT));
						String sMFR     =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER));
						String sCMT     =  validator.getStringEquivalentForSubstituteString(resultMaps.get("attribute[Comment]"));
						String sTrN     =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME));
						String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));
						String sMLyr    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER));
						String sPCID    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT));
						String sPhase   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
						String strCurrent	 =  validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
						String strNSPCG	 =  validator.getStringEquivalentForString(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG));
						String sParentName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_EBOM_NAME));

						strCurrent=strCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
						if(sType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL)){
							if(strCurrent.equals(ConstantsUtil.DEVELOPMENT)){
								strCurrent =ConstantsUtil.STATE_INWORK;
							}
						}
						//Added by Pooja for 22x Defect 50271 -- START
						if(sType.equals(ConstantsUtil.TYPE_SUBSTANCE) ||  sType.equals(ConstantsUtilIRM.TYPE_PPMSUBSTANCE)){
							sTitle	 =  validator.getStringEquivalentForSubstituteStringTitle(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCENAME));
						}
						//Added by Pooja for 22x Defect 50271 -- END
						if(sType.equals(ConstantsUtilIRM.TYPE_PPMSUBSTANCE)){
							sQTY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGETPERCENTAGEWEIGHTBYWEIGHT));
						}
						String sQTYuom	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));

						String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.CLASSIFIED_ITEM));
						String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
						//Added by Pooja for 22x Defect 50271 -- START
                         if(UIUtil.isNotNullAndNotEmpty(sPCED) && UIUtil.isNotNullAndNotEmpty(sPCID)) {
						sPCED =UTIL.getPostRecycledContent(new BigDecimal(sPCED),dDefaultValue);
						sPCID =UTIL.getPostRecycledContent(new BigDecimal(sPCID),dDefaultValue);
                         }
                       //Added by Pooja for 22x Defect 50271 -- END
						mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
						mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);
						//SPEC: Release SR18x.5.2 - Added for Defect# 38791  by gaikwad.tg on Date 14 Feb 2021 -- START
						if (!strCurrent.equals(ConstantsUtil.RELEASE) && !strCurrent.equals(ConstantsUtil.RELEASED)){
							if(!(sType.equals(ConstantsUtilIRM.TYPE_EXTERNAL_MATERIAL) && strCurrent.equals(ConstantsUtilIRM.STATE_ACTIVE))) {
								strID=ConstantsUtil.NO_ACCESS;
							}
						}
						//Added by Pooja for 22x Defect 50271 -- START
						if(isExternal && (strID.equalsIgnoreCase(ConstantsUtil.NO_ACCESS) && !(sType.equals(ConstantsUtil.TYPE_SUBSTANCE))&& !(sType.equals(ConstantsUtilIRM.TYPE_PPMSUBSTANCE))))
							continue;
						//Added by Pooja for 22x Defect 50271 -- END
						
						if((mpContextObject.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && isSupplierOrSP && sType.equalsIgnoreCase(ConstantsUtilIRM.EXTERNAL_MATERIAL)) || (mpContextObject.containsKey(ConstantsUtilIRM.IS_SUPPLIER) && !isSupplierOrSP) || !mpContextObject.containsKey(ConstantsUtilIRM.IS_SUPPLIER)) {
							formatData(sbType,util.mapType(sType));
							formatData(sbName,sName);
							formatData(sbDesc,sDesc);
							formatData(sbCurrent,strCurrent);
							formatData(sbId,strID);
							formatData(sbTitle,sTitle);
							formatData(sbMaxWt,sMAXWt);
							formatData(sbMinWt,sMInWt);
							formatData(sbQOM,sQTYuom);
							formatData(sbMFR,sMFR);
							formatData(sbFN,sFN);
							formatData(sbTrn,sTrN);
							formatData(sbMlLgc,sMlLgc);
							formatData(sbMLyr,sMLyr);
							formatData(sbQTY,sQTY);
							formatData(sbPCED,sPCED);
							formatData(sbPCID,sPCID);
							formatData(sbCMT,sCMT);
							formatData(sbPhase,sPhase);
							formatData(sbNSPCG,strNSPCG);
							formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
						}

					}
				}
				mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString());
				mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString());
				mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString());
				mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString());
				mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sbMFR.toString());
				mpSubStanceResult.put(ConstantsUtil.SEQ,sbFN.toString());
				mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sbTrn.toString());
				mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sbMlLgc.toString());
				mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sbMLyr.toString());
				mpSubStanceResult.put(ConstantsUtil.MIN,sbMinWt.toString());
				mpSubStanceResult.put(ConstantsUtil.TW,sbQTY.toString());
				mpSubStanceResult.put(ConstantsUtil.MAX,sbMaxWt.toString());
				mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sbPCED.toString());
				mpSubStanceResult.put(ConstantsUtil.POST_INDUSTRIAL,sbPCID.toString());
				mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sbCMT.toString());
				mpSubStanceResult.put(ConstantsUtil.PHASE,sbPhase.toString());
				mpSubStanceResult.put(ConstantsUtil.STATE, sbCurrent.toString());
				mpSubStanceResult.put(ConstantsUtil.ID, sbId.toString());
				mpSubStanceResult.put(ConstantsUtil.QUANTITYUOM, sbQOM.toString());
				mpSubStanceResult.put(ConstantsUtilIRM.NSPCG, sbNSPCG.toString());
				mpSubStanceResult.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString().trim());//Added by Ajay for 22x.06 Req.9264

			}
		}catch(Exception e){
			LOGGER.error("Error from PackagingMaterialPartBo:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	//SPEC: 11/18/2020: Added for Defect 37047 -- START
	public Map updatePartSpec(Context context, Map objectMap) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

							mpPartSpecs = getPartSpecifications(context, sType, sID);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : PackagingMaterialPartBO Method :updatePartSpec " + e);
			return new HashMap();

		}
		return util.filterMapList(mpPartSpecs);
	}
	
	
	public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		HashMap mpFinalList = new HashMap();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbDescription = new StringBuilder();
		StringBuilder sbArtworkPrimary = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		boolean showData = false;
		
		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;
		
		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
			sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		}

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		StringList slRelSelects = new StringList();
		slRelSelects.addElement(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
					slPartSpecSelects, null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);

			//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-13-2021>: Bala Added for Stress Testing Defect 44365  -- END
			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				//Added for defect #37081 -- START
				String strOriginatingSrc = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE));
				String strPolicy  = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.POLICY));
				//Added for defect #37081 -- END
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strDescription = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_DESCRIPTION));
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
				
				//SPEC: 10/30/2020: Added for Defect 36711  -- START
				if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)){
					strDescription = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYDESCRIPTION));
				}
				//SPEC: 10/30/2020: Added for Defect 36711  -- END
				
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				String sArtworkPrimary = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTR_PG_ARTWORK_PRIMARY));
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				
				if(sArtworkPrimary.isEmpty()){
					sArtworkPrimary = "No";
				}
				
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END	
			
				
				if (util.isModificatinRequired()) {
					if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {
                        //modified by Ganesh for security impl------>start
						//bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
						//modified by Ganesh for security impl------>end
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
								sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteString(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
								/*String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
								//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							}

						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

						}

					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
						//modified by Ganesh for security impl------>start
						//bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
						//modified by Ganesh for security impl------>end
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = util.updateReferences(context, strId);
								LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
									sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									
									//SPEC: 10/30/2020: Added for Defect 36711  -- START
									if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)){
										strTitle = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
									}
									//SPEC: 10/30/2020: Added for Defect 36711  -- END
									
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
									/*String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
									//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
									//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

								}
							}
						}else
						{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {
						//commented by Ganesh for security impl------->start
						//bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
						//commented by Ganesh for security impl------->end
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
							/*String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
							//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					}

				} else {//commented by Ganesh for security impl-------->start
					/*if(sct.isStaffAUGUser()) {
						
						if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else if("ArtiosCAD Component".equalsIgnoreCase(strType)){
							showData=util.checkInternalUserAcess(sUserlicense,strAutocadClassFied);
						}else{
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}
						
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
						
						if(slHIRTypes.contains(strType)) {
							if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}
							else {
								showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
							}
							// Added for Defect #37081 Rev-- START
						}else if( strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)){ 
							if (strOriginatingSrc.equalsIgnoreCase(ConstantsUtil.DSO) || (strType.equalsIgnoreCase(ConstantsUtil.TYPE_TECHNICALSPECIFICATION) && strOriginatingSrc.equalsIgnoreCase(ConstantsUtil.DSO) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGAUTHORIZEDTEMPORARYSTANDARD)&& !strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATECHNICALSPEC) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGAUTHORIZEDCONFIGURATIONSTANDARD) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_TESTMETHOD) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGTESTMETHOD) && !strPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_SUPPLIEREQUIVALENT) && !strPolicy.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT) && !strType.equalsIgnoreCase(ConstantsUtil.TYPE_PRODUCTDATAPART))) {
							// Added for Defect #37081 Rev-- END
							showData=true;
							}
						}
						//SPEC: 11/18/2020: Modified for Defect 37047 -- START
						else {
							showData=true;
						}
						//SPEC: 11/18/2020: Modified for Defect 37047 -- END
					}*///commented by Ganesh for security impl-------->end
					//modified by Ganesh for security impl-------->start
					showData = util.checkHasAccess(context, sUserType, strId);
					//modified by Ganesh for security impl-------->end
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
						sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC: 10/30/2020: Added for Defect 36711  -- START
						if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)){
							strTitle = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
						}
						//SPEC: 10/30/2020: Added for Defect 36711  -- END
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						//temporary fix to prevent users from downloading a Physical product(VPMReference)
						if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
							sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
						}else {
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
							/*String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
							//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
							//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
						}
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
						// Modified for Defect #37081 -- START
						//sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						// Modified for Defect #37081 -- START
						sbDescription.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbArtworkPrimary.append(sArtworkPrimary).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					}
					
				}

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			mpFinalList.put(ConstantsUtil.ARTWORKPRIMARY, sbArtworkPrimary.toString());
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//}
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END

		} catch (FrameworkException e) {
			LOGGER.error("Exception in PackagingMaterialPartBO getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}
	//SPEC: 11/18/2020: Added for Defect 37047 -- END
	
	
	//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
	public static StringList getSecuritySelects(Context context) {
		
		StringList slIpSelects = new StringList();
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		
		return slIpSelects;

	}
	//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
	
	//SPEC: <04.03.2022>: Guna Added for 46847 Defect  Dev 18x.6.0.3   -- START
	/**
	 * Method Name 			: getSortedSequence
	 * Method Description 	: Getting sorted maplist based on sequence
	 * @param context 
	 * @param strPersnId
	 * @return MapList - Send the list of connected Substance Objects.
	 * @throws Exception If operation fails. 
	 */
	@SuppressWarnings("unchecked")
	public MapList getSortedSequence(Context context, MapList mlRelatedIMPSList) {
		// TODO Auto-generated method stub
		MapList mlTempList = new MapList();
		MapList sortedList = new MapList();
		//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- START
		mlRelatedIMPSList.sort(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE,ConstantsUtil.ASCENDING,ConstantsUtil.INTEGER);
		StringBuilder sbName = new StringBuilder();
		//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- END
		try {
			Iterator objectListItrN = mlRelatedIMPSList.iterator();
			int iVal =0;	
			while (objectListItrN.hasNext()) {
				Map resultMapsTemp = (Map) objectListItrN.next();
				String strId =(String) resultMapsTemp.get(ConstantsUtil.SELECT_ID);
				String sLevel = (String) (resultMapsTemp.get(ConstantsUtil.SELECT_LEVEL));
				//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- START
				String sName = (String) (resultMapsTemp.get(ConstantsUtil.SELECT_NAME));
				boolean isTrue=false;
				//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- END
				if(UIUtil.isNotNullAndNotEmpty(sLevel)){
					iVal = Integer.parseInt(sLevel);
					if(iVal == 1) {
						mlTempList.add(resultMapsTemp);
						//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- START
						if(sbName.toString().contains(sName)) {
							isTrue=true;
						}else {
							sbName.append(ConstantsUtilIRM.BLANK_SPACE);
							sbName.append(sName);
						}
						//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- END
						sortedList =filterMapListBySequence(context,mlRelatedIMPSList,strId);
						if(sortedList.size() !=0) {
							sortedList.sort(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE,ConstantsUtil.ASCENDING,ConstantsUtil.INTEGER);
							//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- START
							if(!mlTempList.containsAll(sortedList)||isTrue) {
							//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- END
								mlTempList.addAll(sortedList);
							//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- START
							}
							//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- END
						}
					}else {
						continue;
					}
					
				  }
			}
		}catch (Exception e) {
			// TODO: handle exception
			LOGGER.error("Exception in PackagingMaterialPartBO getSortedSequence: " + e);
		}
		return mlTempList;
	}
	
	@SuppressWarnings("unchecked")
	private MapList filterMapListBySequence(Context context, MapList mlRelatedIMPSList, String strId) {
		// TODO Auto-generated method stub
		MapList rtnList =new MapList();
		//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- START
		int iVal =0;
		//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- END
		try {
			for(int j=0;j<mlRelatedIMPSList.size();j++) {
				Map sortMap =(Map)mlRelatedIMPSList.get(j);
				String strFromId =(String)sortMap.get(DomainConstants.SELECT_FROM_ID);
				//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- START
				String sLevel = (String) (sortMap.get(ConstantsUtil.SELECT_LEVEL));
				if(UIUtil.isNotNullAndNotEmpty(sLevel)){
					iVal = Integer.parseInt(sLevel);
					if(strFromId.equals(strId)&&!(rtnList.contains(sortMap))) {
					//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- END
						rtnList.add(sortMap);
					//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- START
					}else if(iVal>2&&!(rtnList.contains(sortMap))){
						rtnList.add(sortMap);
					}
					//SPEC: 18-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 49941-- END
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			LOGGER.error("Exception in PackagingMaterialPartBO filterMapListBySequence: " + e);
		}
		return rtnList;
	}
	//SPEC: <04.03.2022>: Guna Added for 46847 Defect  Dev 18x.6.0.3   -- END
}
