package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaMEPService {
	public HashMap<String, Map<String, String>> getMEPdata(String objId, String sComp, Environment env) throws Exception;
}
