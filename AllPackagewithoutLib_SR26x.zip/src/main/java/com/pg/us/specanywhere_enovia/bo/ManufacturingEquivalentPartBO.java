/**
 * Project 		: SpecsAnywhere
 * Program 		: ManufacturingEquivalentPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class ManufacturingEquivalentPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(ManufacturingEquivalentPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	
	public ManufacturingEquivalentPartBO() {
		// empty constructor
	}

	public ManufacturingEquivalentPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getMepBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getMepBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getMepDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getMepDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getManufacturingEquivalentPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getManufacturingEquivalentPartSelectables(Context context) {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGILMARCHIVALSTATUS);
		busSelect.add(ConstantsUtilIRM.SELECT_POLICYCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_POLICY);
		busSelect.add(ConstantsUtilIRM.SELECTABLE_ATTRIBUTE_PG_POA_IMPACT_CONFIRMATION);
		busSelect.add(ConstantsUtilIRM.SELECTABLE_RELATIONSHIP_PGMATERIALTOPGPLIENVCLASS);
		busSelect.add(ConstantsUtilIRM.SELECT_MANUFACTURINGEQUIVALENT_FROM_TYPE);
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
		
		//SPEC: Release SR18x.6.0 - Defect#41364,41363 Added  by gaikwad.tg on Date 23 Mar 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER);
		//SPEC: Release SR18x.6.0 - Defect#41364,41363 Added  by gaikwad.tg on Date 23 Mar 2021 -- END
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEPHARMACOPEIA);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSMATERIALGRADE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEFREETEXT);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSFREETEXT);
				
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getMepRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getMepRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}
	
	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getRefDocBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getRefDocBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPOSTCOSUMERRECYCLEDCONTENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
	
		

		return relSelect;
	}

	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID); 

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE); 
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);  
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_DIMENSTION_UOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMEASISSUEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOPACKMATERIALTYPE);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE);
		busSelect.add(ConstantsUtil.COMP_SUBNAME);
		busSelect.add(ConstantsUtil.COMP_QTY);
		busSelect.add(ConstantsUtil.FUNCTIONS);
		busSelect.add(ConstantsUtil.SELECT_DRYWEGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPGMINIMUMPERCENTWEIGHTBYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMAXIMUMPERCENTWEIGHTBYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMATERIALLAYER);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_FN);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_STATE);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39069  by gaikwad.tg on Date 10 Feb 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_ISRESTRICTED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39069  by gaikwad.tg on Date 10 Feb 2021 -- END
		
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TITLE);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMATERIALLEGACYENVCLASS);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPOSTCOSUMERRECYCLEDCONTENT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_MANUFACTURER);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_MANUFACTURER);
		
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_PGSEQUENCE);
		busSelect.add(ConstantsUtil.COMP_REVS);
		busSelect.add(ConstantsUtil.COMP_DESC);
		busSelect.add(ConstantsUtil.COMP_ID);
		busSelect.add(ConstantsUtil.COMP_STATE);
		busSelect.add(ConstantsUtil.COMP_CASNUM);
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);
		busSelect.add(ConstantsUtil.SELECT_DRYWEGHT);
		
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_ORIGINSOURCE);
		
	
		busSelect.add(ConstantsUtil.OWNERSHIP);
		
		//SPEC: <10.19.2020>: Added for the Defect ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		busSelect.add(ConstantsUtil.COMP_QSTCOMPOSITE);
		//SPEC: <10.19.2020>: Added for the Defect ## -- END
		
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--END
		//SPEC: <18.04.2022>: Guna Added for Req 41754 22x Release  -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//SPEC: <18.04.2022>: Guna Added for Req 41754 22x Release  -- END
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDERIVED);
		
		return busSelect;

	}
	

	/**
	 * Method Name 			: updateDerivedToDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedToDataInfo(Context context ,String sSourceName, String sSourceRev, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map mpDerived = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();

		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.QUERY_WILDCARD, slBusSelects , slRelSelects, getTo, getFrom, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, 0);
			if (mlDerivedList.isEmpty()) {
				return new HashMap();
			}
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization=(String)objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;

				util.formatData(sbDerivedName,sDerivedName);
				util.formatData(sbSourceName,sSourceName);
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.ORIGINATED, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : ManufacturingEquivalentPartBO Method :updateDerivedToDataInfo "+e);
			return new HashMap();
		}
		return mpDerived;
	}

	
	/**
	 * Method Name 			: addMultiSelects
	 * Method Description 	:
	 */
	public StringList addMultiSelects() {

		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.PRIMARYORGANIZATION);
		slMultiSelects.add(ConstantsUtil.SECONDARYORGANIZATION);
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOPACKMATERIALTYPE);
		slMultiSelects.add(ConstantsUtil.CERTIFICATION_NAME);
		
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- START
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- END
		//Added by Ajay for Defect 22243  -- START
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS);
		//Added by Ajay for Defect 22243  -- END
		//Added by Ajay for Req. no. 99576 - START
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEPHARMACOPEIA);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSMATERIALGRADE);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSFREETEXT);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEFREETEXT);
		//Added by Ajay for Req. no. 99576 - END
		return slMultiSelects;
	}

	
	/**
	 * Method Name 			: removeMultiselects
	 * Method Description 	:
	 */
	public void removeMultiselects()
	{
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRIMARYORGANIZATION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SECONDARYORGANIZATION);

		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END
		//SPEC: Release SR18x.6.0 - Added for Defect 41819  by Manikanta on Date 29/03/2021 -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGTOPACKMATERIALTYPE);
		//SPEC: Release SR18x.6.0 - Added for Defect 41819  by Manikanta on Date 29/03/2021 -- END

	}
	
	//SPEC: <10.19.2020>: Added for req 18x.5 ## -- Start
	 public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
	    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
	    	MapList mlIPCLass;
			try {
				mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
						null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
						ConstantsUtil.ZERO_LEVEL);
				Iterator itr = mlIPCLass.iterator();
				Map mpIpClass = new HashMap();
				StringBuilder sbIpName = new StringBuilder();
				StringBuilder sbHasClassAccess = new StringBuilder();
				StringBuilder sbIpType = new StringBuilder();
				StringBuilder sbIpDesc = new StringBuilder();
				StringBuilder sbIpState = new StringBuilder();
				StringBuilder sbIpLibrary = new StringBuilder();
				StringBuilder sbIpClassPath = new StringBuilder();
				
				while(itr.hasNext()) {
					mpIpClass = (Map)itr.next();
					String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
					sbIpName.append(sIpClassName);
					sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
					sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
					sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
					String strIpClass="";
					if(sIpClassName.contains(ConstantsUtil.HIR)) {
						strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
						sbIpLibrary.append(strIpClass);
					} else {
						strIpClass= ConstantsUtil.BUSINESS_USE;
						sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
					}
					if(!strIpClass.isEmpty()) {
						StringBuilder sbIpClassTemp = new StringBuilder();
						sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
						sbIpClassPath.append(sbIpClassTemp.toString());
					}
					
					//Compare user classification against IPName
					sbHasClassAccess.append("TRUE");
					
					if(itr.hasNext()) {
						sbIpName.append("|");
						sbIpType.append("|");
						sbIpDesc.append("|");
						sbIpState.append("|");
						sbIpLibrary.append("|");
						sbIpClassPath.append("|");
						sbHasClassAccess.append("|");
					}
				}
				mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
				mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
				mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
				mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
				//mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
				//mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
				mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
			} catch (FrameworkException e) {
				e.printStackTrace();
				LOGGER.error("Error from ManufacturingEquivalentPartBO: getIpClass" + e);
			}
			return mpIpSecuritySetting;
	    }
		//SPEC: <10.19.2020>: Added for req 18x.5 ## -- END
	 
	 public Map<String, String> getPQREquivalents(Context context, Map objectMap, boolean bMEP, String sRelationShip) {
			
			StringValidatorUtil validator = new StringValidatorUtil();
			Map<String, String> mpEquivalents = new HashMap<String, String>();

			MapList mlList = new MapList();

			String sContextObjectId = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			if (UIUtil.isNullOrEmpty(sContextObjectId)) {

				return new HashMap();
			}
			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_NAME);
			slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
			slBusSelects.add(ConstantsUtil.SELECT_TYPE);
			slBusSelects.add(ConstantsUtil.SELECT_REVISION);
			slBusSelects.add(ConstantsUtil.SELECT_ID);
			slBusSelects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
			slBusSelects.addElement(ConstantsUtil.STR_IPCLASS);
			slBusSelects.add(ConstantsUtil.OWNERSHIP);
			if (bMEP) {
				slBusSelects.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
			} else {
				slBusSelects.add(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME);
			}

			StringList slRelSelects = new StringList();
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION);
			
			try {

				boolean bHasOwnerShip = false;
				String sWhere = ConstantsUtil.EMPTY_STRING;
				String sUserType = util.getUserType();
				SecurityService sct = new SecurityService();
				
				if (util.isModificatinRequired() || sct.isStaffAUGUser()) {
					sWhere = "current==Release";
				}

				SecurityService ss = new SecurityService();
				String sUserCompanies = ss.getUserCauthorities();
				String[] aCompany = sUserCompanies.split(",");
				StringBuilder sbCompany = new StringBuilder();

				if (aCompany.length > -1) {
					for (int i = 0; i < aCompany.length; i++) {
						if (null != aCompany[i]) {
							String Company = aCompany[i].toString();
							sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
						}
					}
				}

				DomainObject dob = new DomainObject(sContextObjectId);
				
				mlList = dob.getRelatedObjects(context, sRelationShip, ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects,
						false, true, (short) 0, sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				dob.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				Iterator objectListItr = mlList.iterator();

				StringList slParentOwnerShip = new StringList();
				StringBuilder sbName = new StringBuilder();
				StringBuilder sbId = new StringBuilder();
				StringBuilder sbType = new StringBuilder();
				StringBuilder sbRev = new StringBuilder();
				StringBuilder sbCurrent = new StringBuilder();
				StringBuilder sbDescription = new StringBuilder();
				StringBuilder sbManuf = new StringBuilder();
				StringBuilder sbSupp = new StringBuilder();
				StringBuilder sbPQRName = new StringBuilder();
				StringBuilder sbPQRState = new StringBuilder();
				StringBuilder sbPQRRevision = new StringBuilder();

				
				String strSplier = "";
				String strMfr = "";
				
				StringList strSplierList = new StringList();
				StringList strMfrList = new StringList();

				while (objectListItr.hasNext()) {
					Map resultMaps = (Map) objectListItr.next();
					
					String sClassId = ConstantsUtil.EMPTY_STRING;
					String sPQRObjectId = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID);
				
					if(sPQRObjectId!=null) {
						sClassId = resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID).getClass().getSimpleName();
					}
					if(sClassId.equalsIgnoreCase(ConstantsUtil.STRING)||sClassId.equalsIgnoreCase(ConstantsUtil.EMPTY_STRING)) {
					
						String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
						String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
						String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
						String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
						String sDesc = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
						String sCurrent = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
						sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
						if (bMEP) {
							strMfr = validator.getStringEquivalentForStringList(
									resultMaps.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
						} else {
							strSplier = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
						}
		
						String sPartOwnership = validator
								.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.OWNERSHIP)));
						String strClassFied = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_IPCLASS));
						String sIPClassfication = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
						
						String sPQRName = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME));
						String sPQRState = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE));
						String sPQRRevision = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION));

		
						util.formatData(sbName, sName);
						util.formatData(sbType, util.mapType(sType));

						if (util.isModificatinRequired()) {
							StringList slEachOwnership = util.filterOwnerShip(sPartOwnership);
							//modified by Ganesh for security impl------>start
							//bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
							bHasOwnerShip = util.checkHasAccess(context, sUserType, sId);
							//modified by Ganesh for security impl------>end
							if (bHasOwnerShip) {
								util.formatData(sbId, sId);
								util.formatData(sbRev, sRev);
								util.formatData(sbCurrent, sCurrent);
								util.formatData(sbDescription, sDesc);
								util.formatData(sbManuf, strMfr);
								util.formatData(sbSupp, strSplier);
								util.formatData(sbPQRName, sPQRName);
								util.formatData(sbPQRState, sPQRState);
								util.formatData(sbPQRRevision, sPQRRevision);

							} else {
								util.formatData(sbId, ConstantsUtil.NO_ACCESS);
								util.formatData(sbRev, ConstantsUtil.NO_ACCESS);
								util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
								util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
								util.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
								util.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
								util.formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
								util.formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
								util.formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);
							}
						} else {
							//commented by Ganesh for security impl------->start
							
							//modified by Ganesh for security impl------->start
							boolean showData =util.checkHasAccess(context, sUserType, sId);
							if (showData) {
								util.formatData(sbId, sId);
								util.formatData(sbRev, sRev);
								util.formatData(sbCurrent, sCurrent);
								util.formatData(sbDescription, sDesc);
								util.formatData(sbManuf, strMfr);
								util.formatData(sbSupp, strSplier);
								util.formatData(sbPQRName, sPQRName);
								util.formatData(sbPQRState, sPQRState);
								util.formatData(sbPQRRevision, sPQRRevision);

							} else {
								util.formatData(sbId, ConstantsUtil.NO_ACCESS);
								util.formatData(sbRev, ConstantsUtil.NO_ACCESS);
								util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
								util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
								util.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
								util.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
								util.formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
								util.formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
								util.formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);

							}
							//modified by Ganesh for security impl------->end
						 }
						
					}
					else 
					{   
						String sId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
						String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
						String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
						String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
						String sDesc = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
						String sCurrent = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
						sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
						if (bMEP) {
							strMfr = validator.getStringEquivalentForStringList(
									resultMaps.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
						} else {
							strSplier = validator
									.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
						}
		
						String sPartOwnership = validator
								.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.OWNERSHIP)));
						String strClassFied = validator
								.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_IPCLASS));
						String sIPClassfication = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
						
						String sPQRPlants = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRPLANTS));
						String sPQRPCP = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRPCP));
						String sPQRBA = validator.getStringEquivalentForStringList(
								resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRBA));
						
						StringList slChildId = (StringList)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID);

						   for(int i =0; i<slChildId.size(); i++) {
							   String sEachChildId = slChildId.getElement(i);
							    
							   	StringList sPQRName = (StringList)(
										resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME));
								StringList sPQRState = (StringList)(
										resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE));
								StringList sPQRRevision = (StringList)(
										resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION));
							   
								util.formatData(sbName, sName);
								util.formatData(sbType, util.mapType(sType));
							 
							   if (util.isModificatinRequired()) {
									StringList slEachOwnership = util.filterOwnerShip(sPartOwnership);
									//modified by Ganesh for security impl ------->start
									//bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
									bHasOwnerShip = util.checkHasAccess(context, sUserType, sId);
									//modified by Ganesh for security impl ------->end
				
									if (bHasOwnerShip) {
										util.formatData(sbId, sId);
										util.formatData(sbRev, sRev);
										util.formatData(sbCurrent, sCurrent);
										util.formatData(sbDescription, sDesc);
										util.formatData(sbManuf, strMfr);
										util.formatData(sbSupp, strSplier);
										util.formatData(sbPQRName, sPQRName.get(i));
										util.formatData(sbPQRState, sPQRState.get(i));
										util.formatData(sbPQRRevision, sPQRRevision.get(i));

				
									} else {
										util.formatData(sbId, ConstantsUtil.NO_ACCESS);
										util.formatData(sbRev, ConstantsUtil.NO_ACCESS);
										util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
										util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
										util.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
										util.formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
										util.formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
										util.formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);

									}
								} else {
									boolean showData = true;
									//commented by Ganesh for security impl --->start
									showData = util.checkHasAccess(context, sUserType, sId);
									if (showData) {
										util.formatData(sbId, sId);
										util.formatData(sbRev, sRev);
										util.formatData(sbCurrent, sCurrent);
										util.formatData(sbDescription, sDesc);
										util.formatData(sbManuf, strMfr);
										util.formatData(sbSupp, strSplier);
										util.formatData(sbPQRName, sPQRName.get(i));
										util.formatData(sbPQRState, sPQRState.get(i));
										util.formatData(sbPQRRevision, sPQRRevision.get(i));

									} else {
										util.formatData(sbId, ConstantsUtil.NO_ACCESS);
										util.formatData(sbRev, ConstantsUtil.NO_ACCESS);
										util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
										util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
										util.formatData(sbManuf, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSupp, ConstantsUtil.NO_ACCESS);
										util.formatData(sbPQRName, ConstantsUtil.NO_ACCESS);
										util.formatData(sbPQRState, ConstantsUtil.NO_ACCESS);
										util.formatData(sbPQRRevision, ConstantsUtil.NO_ACCESS);

									}
									//commented by Ganesh for security impl --->end
						    }
					    }
					}
				}
				mpEquivalents.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
				mpEquivalents.put(ConstantsUtil.ID, sbId.toString());
				mpEquivalents.put(ConstantsUtil.TYPE, sbType.toString());
				mpEquivalents.put(ConstantsUtil.NAME, sbName.toString());
				mpEquivalents.put(ConstantsUtil.REV, sbRev.toString());
				mpEquivalents.put(ConstantsUtil.STATE, sbCurrent.toString());
				if (bMEP) {
					mpEquivalents.put(ConstantsUtil.MANUFACTURER, sbManuf.toString());
				} else {
					mpEquivalents.put(ConstantsUtil.SUPPLIER, sbSupp.toString());
				}
				mpEquivalents.put(ConstantsUtil.PQRNAME, sbPQRName.toString());
				mpEquivalents.put(ConstantsUtil.PQRSTATE, sbPQRState.toString());
				mpEquivalents.put(ConstantsUtil.PQRREVISION, sbPQRRevision.toString());


			} catch (Exception e) {

				LOGGER.error("Error from ManufacturingEquivalentPartBO:  getPQREquivalents" + e);
				return new HashMap();
			}
			return util.filterMapList(mpEquivalents);
		}

	//SPEC: <09.06.2022>: Guna Added for Req 33476 and 41754 22x Release  -- START
	public MapList getPackagingCertificationsList(Context context, String objId, String strName, String strType, String strPolicy) {
		MapList rtnMapList =new MapList();
		try {
			 StringList selectStmts = new StringList(4);
		      selectStmts.add(DomainConstants.SELECT_ID);
		      selectStmts.add(DomainConstants.SELECT_TYPE);
		      selectStmts.add(DomainConstants.SELECT_NAME);
		      selectStmts.add(DomainConstants.SELECT_CURRENT);
		      selectStmts.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		      StringList strRelSelList = new StringList(1);
		      strRelSelList.add(ConstantsUtilIRM.SELECT_CONNECTION_TYPE);
		      boolean isFrom = true;
		      boolean isTo = false;
		      if (ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT.equals(strPolicy) || ConstantsUtil.POLICY_SUPPLIEREQUIVALENT.equals(strPolicy)) {
		        isFrom = false;
		        isTo = true;
		      } 
		      StringBuilder sbWhere =new StringBuilder();
		      sbWhere.append("(");
		      sbWhere.append(DomainConstants.SELECT_CURRENT);
		      sbWhere.append("==");
		      sbWhere.append(ConstantsUtil.STATE_RELEASE);
		      sbWhere.append(" || "+DomainConstants.SELECT_CURRENT+"=="+ConstantsUtil.RELEASED+")");
		      Pattern relationshipPattern = new Pattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
		      relationshipPattern.addPattern(ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT);
		      relationshipPattern.addPattern(ConstantsUtil.RELATIONSHIP_ALTERNATE);
		      DomainObject domObj =DomainObject.newInstance(context,objId);
		      
		    //SPEC: <12.08.2022>: Guna Modified for 49943 Defect   Dev 22x    -- START
		      MapList listMEPsSEPs = domObj.getRelatedObjects(context, //context
		    	relationshipPattern.getPattern(), // relationshipPattern
		          DomainConstants.TYPE_PART, // typePattern
		          selectStmts, // objectSelects
		          strRelSelList, // relationshipSelects
		          isTo, // getTo
		          isFrom, // getFrom
		          (short)1, // recurseToLevel
		          sbWhere.toString(), // objectWhere
		          null, // relationshipWhere
		          500); //limit
		      int size=listMEPsSEPs.size();
			  if (size==500) {
					return new MapList();
			 }
			//SPEC: <12.08.2022>: Guna Modified for 49943 Defect   Dev 22x    -- END
		      Iterator<?> itr = listMEPsSEPs.iterator();
		      Map<?, ?> mEquivalentInfo = null;
		      DomainObject domEqvPart = null;
		      MapList mlCertification = getRelatedPackagingCertifications(context, domObj,strName,objId,strType);
		      rtnMapList.addAll((Collection)mlCertification);
		      while (itr.hasNext()) {
		        mEquivalentInfo = (Map<?, ?>)itr.next();
		        String  strRelType = (String)mEquivalentInfo.get("type[connection]");
		        String strPartId = (String)mEquivalentInfo.get(DomainConstants.SELECT_ID);
		        String sName = (String)mEquivalentInfo.get(DomainConstants.SELECT_NAME);
		        String sType = (String)mEquivalentInfo.get(DomainConstants.SELECT_TYPE);
		        if (UIUtil.isNotNullAndNotEmpty(strPartId)) {
		          domEqvPart = DomainObject.newInstance(context, strPartId);
		          MapList mlCertifications = getRelatedPackagingCertifications(context, domEqvPart,sName,strPartId,sType);
		          rtnMapList.addAll((Collection)mlCertifications);
		          if (!DomainConstants.RELATIONSHIP_ALTERNATE.equals(strRelType)) {
		            mlCertifications = getMCPRelatedPackagingCertifications(context, domEqvPart);
		            rtnMapList.addAll((Collection)mlCertifications);
		            mlCertifications = getAlternatePartRelatedPackagingCertifications(context, domEqvPart);
		            rtnMapList.addAll((Collection)mlCertifications);
		            continue;
		          } 
		          if(DomainConstants.RELATIONSHIP_ALTERNATE.equals(strRelType)) {
		        	  mlCertifications = getPackagingCertificationsList(context, strPartId, sName, objId, strPolicy);
		        	  rtnMapList.addAll((Collection)mlCertifications);
		          }
		        }
		        }
		    //SPEC: <22.07.2022>: Guna Added for Req 42583 22x Release  -- START
		      MapList mlMCPCert = getMCPRelatedPackagingCertifications(context, domObj);
		      rtnMapList.addAll(mlMCPCert);
		      domObj.close(context);
		    //SPEC: <22.07.2022>: Guna Added for Req 42583 22x Release  -- END
		} catch (Exception e) {
			LOGGER.error("Error from ManufacturingEquivalentPartBO:  getPackagingCertificationsList" + e);
		}
		rtnMapList = new MapList(new HashSet((Collection<?>)rtnMapList));
		return rtnMapList;
	}

	public Map getCertificationDetails(Context context, MapList mlCertification, String strName, DomainObject doMEP, String strCtxType) {
		Map pkgCertMap =new HashMap<>();
	    try {
	    	StringValidatorUtil validatorUtil=new StringValidatorUtil();
	    	StringBuilder sbName = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbCertSourceId = new StringBuilder();
			StringBuilder sbCertSourceType = new StringBuilder();
			StringBuilder sbCertSourceName = new StringBuilder();
			StringBuilder sbCertName = new StringBuilder();
			StringBuilder sbCertComments = new StringBuilder();
			StringBuilder sbExpDate = new StringBuilder();
			StringBuilder sbDocsName = new StringBuilder();
			StringBuilder sbDocsType = new StringBuilder();
			StringBuilder sbDocsId = new StringBuilder();
			FinishedProductPartBO fppBo =new FinishedProductPartBO();
			String ctxId =doMEP.getId(context);
			StringList slAttributeValueList = doMEP.getInfoList(context,ConstantsUtilIRM.SELECT_ATTR_PG_PACKAGING_MATERIAL_CERTIFICATIONS);
			for(int j=0;j<mlCertification.size();j++) {
	    		  Map mpCert =(Map) mlCertification.get(j);
	    		  Map mpCertDocs =new HashMap();
	    		  StringList docsList =validatorUtil.getStringListEquivalentForString(mpCert.get(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_ID));
	    		  if(!docsList.isEmpty()) {
	    			  mpCertDocs =fppBo.getCertificationDocs(context, docsList);
	    		  }
	    		  util.formatData(sbName, strName);
	    		//SPEC: <22.07.2022>: Guna Added for Req 42583 22x Release  -- START
	    		  String certComments =(String)mpCert.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
	    		  certComments= certComments.replaceAll("[\n\r]", " ");
	    		  util.formatData(sbCertComments, certComments);
	    		//SPEC: <22.07.2022>: Guna Added for Req 42583 22x Release  -- END
	    		  util.formatData(sbExpDate, validatorUtil.DateFormatter((String)mpCert.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)));
	    		  util.formatData(sbCertName, (String)mpCert.get(DomainConstants.SELECT_NAME));
	    		  util.formatData(sbType,  util.mapType(strCtxType));
	    		  util.formatData(sbId, ctxId);
	    			 String strCertId =(String) mpCert.get(ConstantsUtilIRM.SOURCEID);
	    			 boolean showData =util.checkHasAccess(context, null, strCertId);
	    			 if(!showData) {
	    				 strCertId =ConstantsUtil.NO_ACCESS;
	    			 }
	    			  util.formatData(sbCertSourceId, strCertId);
		    		  util.formatData(sbCertSourceType, util.mapType((String) mpCert.get(ConstantsUtilIRM.SOURCETYPE)));
		    		  util.formatData(sbCertSourceName, (String) mpCert.get(ConstantsUtilIRM.CERTIFICATIONSOURCE));
		    		  
	    		  	if(!mpCertDocs.isEmpty()) {
	    			  util.formatData(sbDocsId, (String) mpCertDocs.get(DomainConstants.SELECT_ID));
		    		  util.formatData(sbDocsName, (String) mpCertDocs.get(DomainConstants.SELECT_NAME));
		    		  util.formatData(sbDocsType, (String) mpCertDocs.get(DomainConstants.SELECT_TYPE));
	    		  }else {
	    			  util.formatData(sbDocsId, ConstantsUtil.EMPTY_STRING);
		    		  util.formatData(sbDocsName, ConstantsUtil.EMPTY_STRING);
		    		  util.formatData(sbDocsType, ConstantsUtil.EMPTY_STRING);
	    		  }
	    		  
	    	  }
			  String strIntdCert=validatorUtil.getStringEquivalentForSubstituteString(slAttributeValueList);
			  //Added by Subhajit for Defect no. 7701
			  if(UIUtil.isNotNullAndNotEmpty(sbId.toString())){
				  pkgCertMap.put(ConstantsUtilIRM.PARTNAME, sbName.toString());  
		    	  pkgCertMap.put(ConstantsUtilIRM.PARTTYPE, sbType.toString());
		    	  pkgCertMap.put(ConstantsUtilIRM.PARTID, sbId.toString());
		    	  pkgCertMap.put(ConstantsUtilIRM.CERTIFICATENAME, sbCertName.toString());
		    	  pkgCertMap.put(ConstantsUtil.EXPIRATIONDATE, sbExpDate.toString());
		    	  pkgCertMap.put(ConstantsUtilIRM.CERTCOMMENTS, sbCertComments.toString());
		    	  pkgCertMap.put(ConstantsUtil.SOURCENAME, sbCertSourceName.toString());
		    	  pkgCertMap.put(ConstantsUtilIRM.SOURCEID, sbCertSourceId.toString());
		    	  pkgCertMap.put(ConstantsUtilIRM.SOURCETYPE, sbCertSourceType.toString());
		    	  pkgCertMap.put(ConstantsUtilIRM.SUPPORTDOCS, sbDocsName.toString());
		    	  pkgCertMap.put(ConstantsUtilIRM.SUPPORTDOCSID, sbDocsId.toString());
		    	  pkgCertMap.put(ConstantsUtilIRM.SUPPORTDOCSTYPE, sbDocsType.toString());
		    	  pkgCertMap.put(ConstantsUtilIRM.INTENDEDPACKAGINGMATERIALCERTIFICATION, strIntdCert);
			  }
	    	  
			
	    }catch (Exception e) {
	    	LOGGER.error("Error from ManufacturingEquivalentPartBO:  getCertificationDetails" + e);
		}
		
		return pkgCertMap;
	}

	private MapList getRelatedPackagingCertifications(Context context, DomainObject domEqvPart, String strName, String objId, String strType) {
		MapList mlReturn = new MapList();
	    try {
	      StringList selectStmts = new StringList(3);
	      selectStmts.add(DomainConstants.SELECT_ID);
	      selectStmts.add(DomainConstants.SELECT_NAME);
	      selectStmts.add(DomainConstants.SELECT_TYPE);
	      StringList selectRelStmts = new StringList(4);
	      selectRelStmts.add(ConstantsUtil.SELECT_CONNECTION_ID);
	      selectRelStmts.add(ConstantsUtilIRM.SELECT_CONNECTION_NAME);
	      selectRelStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
	      selectRelStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
	      selectRelStmts.add(ConstantsUtilIRM.STR_SEL_CERTIFICATION_DOC_ID);
	      Pattern relPattern = new Pattern(ConstantsUtilIRM.RELATIONSHIP_PG_PLI_PACKAGING_CERTIFICATIONS);
	      Pattern typePattern = new Pattern(ConstantsUtilIRM.TYPE_PG_PLI_PACKAGING_MATERIAL_CERTIFICATION);
	    MapList  mlCert = domEqvPart.getRelatedObjects(context, relPattern
	          .getPattern(), typePattern
	          .getPattern(), selectStmts, selectRelStmts, false, true, (short)1, null, null, 0);
	      if(!mlCert.isEmpty()) {
	    	  for(int k=0;k<mlCert.size();k++) {
	    		  Map mCertificationInfo =(Map)mlCert.get(k);
	    		  mCertificationInfo.put(ConstantsUtilIRM.SOURCEID, objId);
	    		  mCertificationInfo.put(ConstantsUtilIRM.CERTIFICATIONSOURCE, strName);
	    		  mCertificationInfo.put(ConstantsUtilIRM.SOURCETYPE, strType);
	    		  mlReturn.add(mCertificationInfo);
	    	  }
	      }
	      
	    }catch (Exception e) {
	    	LOGGER.error("Error from ManufacturingEquivalentPartBO:  getRelatedPackagingCertifications" + e);
		}
		return mlReturn;
	}
	public MapList getMCPRelatedPackagingCertifications(Context context, DomainObject domObj)  {
	    MapList mlReturn = new MapList();
	    try {
	      StringList selectStmts = new StringList(4);
	      selectStmts.add(DomainConstants.SELECT_ID);
	      selectStmts.add(DomainConstants.SELECT_NAME);
	      selectStmts.add(DomainConstants.SELECT_TYPE);
	      selectStmts.add(DomainConstants.SELECT_CURRENT);
	      MapList listMCPs = domObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL, ConstantsUtil.TYPE_INTERNAL_MATERIAL, selectStmts, null, false, true, (short)1, null, null, 0);
	      Iterator<?> itr = listMCPs.iterator();
	      DomainObject domMCP = null;
	      while (itr.hasNext()) {
	    	  Map<?, ?> mMCPInfo  = (Map<?, ?>)itr.next();
	        String strMCPId = (String)mMCPInfo.get(DomainConstants.SELECT_ID);
	        String strMCPType =(String)mMCPInfo.get(DomainConstants.SELECT_TYPE);
	        String strMCPTName =(String)mMCPInfo.get(DomainConstants.SELECT_NAME);
	        String strMCPTCurrent =(String)mMCPInfo.get(DomainConstants.SELECT_CURRENT);
	        
	        if (UIUtil.isNotNullAndNotEmpty(strMCPId) && (strMCPTCurrent.equals(ConstantsUtil.RELEASED)|| strMCPTCurrent.equals(ConstantsUtil.STATE_RELEASE) || strMCPTCurrent.equals(ConstantsUtil.STATE_APPROVED))) {
	          domMCP = DomainObject.newInstance(context, strMCPId);
	          MapList mlCertifications = getRelatedPackagingCertifications(context, domMCP, strMCPTName, strMCPId,strMCPType);
	          mlReturn.addAll((Collection)mlCertifications);
	        } 
	      } 
	    } catch (Exception ex) {
	    	LOGGER.error("Error from ManufacturingEquivalentPartBO:  getMCPRelatedPackagingCertifications" + ex);
	    } 
	    return mlReturn;
	  }
	 private MapList getAlternatePartRelatedPackagingCertifications(Context context, DomainObject domObj)  {
		    MapList mlReturn = new MapList();
		    try {
		      StringList selectStmts = new StringList(4);
		      selectStmts.add(DomainConstants.SELECT_ID);
		      selectStmts.add(DomainConstants.SELECT_TYPE);
		      selectStmts.add(DomainConstants.SELECT_NAME);
		      selectStmts.add(DomainConstants.SELECT_CURRENT);
		      StringList strRelSelList = new StringList(1);
		      strRelSelList.add(ConstantsUtilIRM.SELECT_CONNECTION_TYPE);
		      Pattern relationshipPattern = new Pattern(DomainConstants.RELATIONSHIP_ALTERNATE);
		      StringBuilder sbWhere =new StringBuilder();
		      sbWhere.append("(");
		      sbWhere.append(DomainConstants.SELECT_CURRENT);
		      sbWhere.append("==");
		      sbWhere.append(ConstantsUtil.STATE_RELEASE);
		      sbWhere.append(" || "+DomainConstants.SELECT_CURRENT+"=="+ConstantsUtil.RELEASED+")");
		      MapList listAlternates = domObj.getRelatedObjects(context, relationshipPattern
		          .getPattern(), DomainConstants.TYPE_PART, selectStmts, strRelSelList, false, true, (short)1, sbWhere.toString(), null, 0);
		      Iterator<?> itr = listAlternates.iterator();
		      MapList mlCertifications = null;
		      Map<?, ?> mEquivalentInfo = null;
		      String strPartId = null;
		      String strName = null;
		      DomainObject domAltPart = null;
		      while (itr.hasNext()) {
		        mEquivalentInfo = (Map<?, ?>)itr.next();
		        strPartId = (String)mEquivalentInfo.get(DomainConstants.SELECT_ID);
		        strName = (String)mEquivalentInfo.get(DomainConstants.SELECT_NAME);
		        String strType =(String)mEquivalentInfo.get(DomainConstants.SELECT_TYPE);
		        if (UIUtil.isNotNullAndNotEmpty(strPartId)) {
		          domAltPart = DomainObject.newInstance(context, strPartId);
		          mlCertifications = getRelatedPackagingCertifications(context, domAltPart, strName, strPartId,strType);
		          mlReturn.addAll((Collection)mlCertifications);
		        } 
		      } 
		    } catch (Exception ex) {
		    	LOGGER.error("Error from ManufacturingEquivalentPartBO:  getAlternatePartRelatedPackagingCertifications" + ex);
		    } 
		    return mlReturn;
		  }
		//SPEC: <09.06.2022>: Guna Added for Req 33476 and 41754 22x Release  -- END
}