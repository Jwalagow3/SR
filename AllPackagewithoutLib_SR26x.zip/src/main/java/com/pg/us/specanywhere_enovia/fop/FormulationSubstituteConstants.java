package com.pg.us.specanywhere_enovia.fop;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.PropertyUtil;
public interface FormulationSubstituteConstants extends DomainConstants
{

		// Attribute Definition
		public static final String ATTRIBUTE_RELEASE_DATE = PropertyUtil.getSchemaProperty("attribute_ReleaseDate");
		public static final String ATTRIBUTE_IS_TEMPLATE_APPLIED = PropertyUtil.getSchemaProperty("attribute_IsTemplateApplied");
		//Modified for 2018x Upgrade - Stage attribute is replaced by Release Phase attribute in 18x OOTB - START. 
		//public static final String ATTRIBUTE_STAGE = PropertyUtil.getSchemaProperty("attribute_Stage");
		public static final String ATTRIBUTE_STAGE = PropertyUtil.getSchemaProperty("attribute_ReleasePhase");
		//Modified for 2018x Upgrade - Stage attribute is replaced by Release Phase attribute in 18x OOTB - ENDS. 
		public static final String SELECT_ATTRIBUTE_STAGE = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_STAGE).append("].value").toString();
		public static final String ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE = PropertyUtil.getSchemaProperty("attribute_SharedTableCharacteristicSequence");
		public static final String SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE).append("]").toString();
		public static final String ATTRIBUTE_ISRESTRICTED = PropertyUtil.getSchemaProperty("attribute_IsRestricted");
		public static final String ATTR_PG_ORIGINATINGSOURCE = PropertyUtil.getSchemaProperty("attribute_pgOriginatingSource");
		public static final String ATTR_PG_UNARCHIVEREASON = PropertyUtil.getSchemaProperty("attribute_pgUnarchiveReason");
		public static final String ATTR_PG_SAPTYPE = PropertyUtil.getSchemaProperty("attribute_pgSAPType");
		public static final String ATTR_PG_STATISTICALUNIT = PropertyUtil.getSchemaProperty("attribute_PGC_SU");
		public static final String ATTR_PG_UNITSIZE = PropertyUtil.getSchemaProperty("attribute_PGC_UnitSize");
		public static final String ATTR_PG_MARKETINGSIZE = PropertyUtil.getSchemaProperty("attribute_pgMarketingSize");
		public static final String ATTR_PG_VALIDSTARTDATE = PropertyUtil.getSchemaProperty("attribute_pgValidStartDate");
		public static final String ATTR_PGISAUTHORIZEDTO_USE = PropertyUtil.getSchemaProperty("attribute_pgIsAuthorizedtoUse");
		public static final String ATTR_PGISAUTHORIZEDTO_PRODUCE = PropertyUtil.getSchemaProperty("attribute_pgIsAuthorizedtoProduce");
		public static final String ATTR_PGIS_ACTIVATED = PropertyUtil.getSchemaProperty("attribute_pgIsActivated");
		public static final String ATTR_PG_UNOBOSOLETEDATE = PropertyUtil.getSchemaProperty("attribute_pgUnarchiveDate");
		public static final String ATTR_PG_OBOSOLETEDATE = PropertyUtil.getSchemaProperty("attribute_pgArchiveDate");
		public static final String ATTR_PG_OBSOLETECOMMENT = PropertyUtil.getSchemaProperty("attribute_pgArchiveComment");
		public static final String ATTR_PG_PREVIOUS_REVISION_OBSOLETE_DATE = PropertyUtil.getSchemaProperty("attribute_pgPreviousRevisionObsoleteDate");
		public static final String ATTR_AUTHORIZED_TEMPORARY_SPECIFICATION = PropertyUtil.getSchemaProperty("attribute_AuthorizedTemporarySpecification");
		public static final String ATTR_COMMENT = PropertyUtil.getSchemaProperty("attribute_Comment");
		public static final String ATTR_IMPACTED_TYPE = PropertyUtil.getSchemaProperty("attribute_pgImpactedType");
		public static final String ATTR_PG_LIFECYCLESTATUS = PropertyUtil.getSchemaProperty("attribute_pgLifeCycleStatus");
		public static final String ATTR_PG_PALLETTYPE = PropertyUtil.getSchemaProperty("attribute_pgPalletType");
		public static final String ATTR_PG_TMLOGIC = PropertyUtil.getSchemaProperty("attribute_pgTMLogic");
		public static final String ATTR_PG_ALTERNATEUOM = PropertyUtil.getSchemaProperty("attribute_pgAlternateUnitOfMeasure");
		public static final String ATTR_REFERENCE_TYPE = PropertyUtil.getSchemaProperty("attribute_ReferenceType");
		public static final String ATTR_ACTION_REQUIRED = PropertyUtil.getSchemaProperty("attribute_pgActionRequired"); 
		public static final String ATTR_PGISAUTHORIZEDTO_VIEW = PropertyUtil.getSchemaProperty("attribute_pgIsAuthorizedtoView");
		public static final String ATTR_EXPIRATION_DATE = PropertyUtil.getSchemaProperty("attribute_ExpirationDate");
		public static final String ATTR_RESPONSIBLEDESIGNENGINEER=PropertyUtil.getSchemaProperty("attribute_ResponsibleDesignEngineer");
		public static final String ATTR_RESPONSIBLEMANUFACTURINGENGINEER=PropertyUtil.getSchemaProperty("attribute_ResponsibleManufacturingEngineer");
		public static final String ATTR_PG_GCAS_MAGAZINELOCK = PropertyUtil.getSchemaProperty("attribute_pgGCASMagazineLock");
		public static final String ATTR_PG_GCAS_CODES = PropertyUtil.getSchemaProperty("attribute_pgGCASCodes");
		public static final String ATTR_PG_GCAS_COUNT = PropertyUtil.getSchemaProperty("attribute_pgGCASCount");
		public static final String ATTR_PGPLAUTHORIZEDONLY = PropertyUtil.getSchemaProperty("attribute_pgPLAuthorizedOnly");
		public static final String ATTR_PG_IsBattery = PropertyUtil.getSchemaProperty("attribute_pgIsBattery");
		public static final String ATTR_PG_BOMBASEQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgBOMBaseQuantity");
		public static final String ATTR_PG_ContainsBattery = PropertyUtil.getSchemaProperty("attribute_pgContainsBattery");
		public static final String ATTR_PG_BASEUOM = PropertyUtil.getSchemaProperty("attribute_pgBaseUnitOfMeasure");
		public static final String ATTR_PG_CUSTOMIZATIONTYPE = PropertyUtil.getSchemaProperty("attribute_pgCustomizationType");
		public static final String ATTR_PG_ASSEMBLY_TYPE = PropertyUtil.getSchemaProperty("attribute_pgAssemblyType");
		public static final String ATTR_PG_LANGUAGE = PropertyUtil.getSchemaProperty("attribute_pgLanguage");
		public static final String ATTR_PG_ERRORCLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pgErrorClassification");
		public static final String ATTRIBUTE_CUSTOMER_UNITS_PRELAYER=PropertyUtil.getSchemaProperty("attribute_pgCustomerUnitsPerLayerInteger");
		public static final String ATTRIBUTE_LAYERS_PERTRANSPORTUNIT 	= PropertyUtil.getSchemaProperty("attribute_pgLayersPerTransportUnitInteger");
		public static final String ATTRIBUTE_MARKETING_NAME = PropertyUtil.getSchemaProperty("attribute_MarketingName");
		public static final String ATTR_PG_CLAIMEDDATE = PropertyUtil.getSchemaProperty("attribute_pgClaimedDate");
		public static final String ATTR_VALID_UNTIL_DATE = PropertyUtil.getSchemaProperty("attribute_pgValidUntilDate");
		public static final String ATTR_PG_PHYSICALOID = PropertyUtil.getSchemaProperty("attribute_pidPOID");
		public static final String ATTR_PG_SEQUENCENUMBER = PropertyUtil.getSchemaProperty("attribute_pgSequenceNumber");
		public static final String ATTR_PG_GROSSWEIGHTREAL = PropertyUtil.getSchemaProperty("attribute_pgGrossWeightReal");
		public static final String ATTR_PG_GROSS_WEIGHT_UOM = PropertyUtil.getSchemaProperty("attribute_pgGrossWeightUnitOfMeasure");
		public static final String ATTR_PG_WDVALIDATIONSTATUS = PropertyUtil.getSchemaProperty("attribute_pgWDValidationStatus");
		public static final String ATTR_PG_LEGACYWEIGHTFACTORUOM = PropertyUtil.getSchemaProperty("attribute_pgLegacyWeightFactorUoM");
		public static final String ATTR_PG_LEGACYWEIGHTFACTOR = PropertyUtil.getSchemaProperty("attribute_pgLegacyWeightFactor");
		public static final String ATTR_PG_NET_WEIGHT_IN_CONSUMERUNIT = PropertyUtil.getSchemaProperty("attribute_pgNetWeightOfProductInConsumerUnitReal");
		public static final String ATTR_PG_NET_WEIGHT_IN_CONSUMERUNIT_UOM = PropertyUtil.getSchemaProperty("attribute_pgNetWeightOfProductInConsumerUnitUoM");
		public static final String ATTR_PG_NETWEIGHT = PropertyUtil.getSchemaProperty("attribute_pgNetWeight");
		public static final String ATTR_PG_NETWEIGHT_UOM = PropertyUtil.getSchemaProperty("attribute_pgNetWeightUnitOfMeasure");
		public static final String ATTR_PALLETWEIGHT = PropertyUtil.getSchemaProperty("attribute_PalletWeight");
		public static final String ATTR_PALLETLENGTH = PropertyUtil.getSchemaProperty("attribute_pgPLPalletLength");
		public static final String ATTR_PALLETWIDTH = PropertyUtil.getSchemaProperty("attribute_PalletWidth");
		public static final String ATTR_PALLETHEIGHT = PropertyUtil.getSchemaProperty("attribute_PalletHeight");
		public static final String ATTR_GROSSWEIGHTPALLETREAL = PropertyUtil.getSchemaProperty("attribute_pgGrossWeightWithPalletReal");
		public static final String ATTR_GROSSWEIGHTWITHOUTPALLETREAL = PropertyUtil.getSchemaProperty("attribute_pgGrossWeightWithoutPalletReal");
		public static final String ATTR_OUTER_DIMENSION_LENGTH = PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionLength");
		public static final String ATTR_OUTER_DIMENSION_WIDTH = PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionWidth");
		public static final String ATTR_PG_OVERHANG_MAX_DEPTH = PropertyUtil.getSchemaProperty("attribute_pgOverhangMaxLength");
		public static final String ATTR_PG_OVERHANG_MAX_WIDTH = PropertyUtil.getSchemaProperty("attribute_pgOverhangMaxWidth");
		public static final String ATTRIBUTE_PG_OUTERDIMENSIONHEIGHT 	= PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionHeight");
		public static final String ATTRIBUTE_PG_OUTERDIMENSIONLENGTH 	= PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionLength");
		public static final String ATTRIBUTE_PG_OUTERDIMENSIONWIDTH 	= PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionWidth");
		public static final String ATTRIBUTE_PG_OUTERDIMENSIONHEIGHT_ORIGINAL 	= PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionHeightOriginal");
		public static final String ATTRIBUTE_PG_OUTERDIMENSIONLENGTH_ORIGINAL 	= PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionLengthOriginal");
		public static final String ATTRIBUTE_PG_OUTERDIMENSIONWIDTH_ORIGINAL 	= PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionWidthOriginal");
		public static final String ATTRIBUTE_PG_INNERDIMENSIONHEIGHT 	= PropertyUtil.getSchemaProperty("attribute_pgInnerDimensionHeight");
		public static final String ATTRIBUTE_PG_INNERDIMENSIONLENGTH 	= PropertyUtil.getSchemaProperty("attribute_pgInnerDimensionLength");
		public static final String ATTRIBUTE_PG_INNERDIMENSIONWIDTH 	= PropertyUtil.getSchemaProperty("attribute_pgInnerDimensionWidth");
		public static final String ATTRIBUTE_PG_DIMENSTION_UOM 	= PropertyUtil.getSchemaProperty("attribute_pgDimensionUoM");
		public static final String ATTRIBUTE_PG_DIMENSTION_UOM_ORIGINAL 	= PropertyUtil.getSchemaProperty("attribute_pgDimensionUoMOriginal");
		public static final String ATTRIBUTE_PG_COMPONENTWEIGHT_UOM 	= PropertyUtil.getSchemaProperty("attribute_pgComponentWeightUoM");
		public static final String ATTRIBUTE_PG_COMPONENTWEIGHT_UOM_ORIGINAL 	= PropertyUtil.getSchemaProperty("attribute_pgComponentWeightUoMOriginal");
		public static final String ATTRIBUTE_PG_COMPONENTNETWEIGHT 	= PropertyUtil.getSchemaProperty("attribute_pgComponentNetWeight");
		public static final String ATTRIBUTE_PG_COMPONENTNETWEIGHT_ORIGINAL 	= PropertyUtil.getSchemaProperty("attribute_pgComponentNetWeightOriginal");
		public static final String ATTRIBUTE_PG_SHAREDTABLE_CHARACTERISTICSEQUENCE 	= PropertyUtil.getSchemaProperty("attribute_SharedTableCharacteristicSequence");
		public static final String ATTRIBUTE_PG_PARTONEBOM  = PropertyUtil.getSchemaProperty("attribute_pgPartOnEBOM");
		public static final String ATTRIBUTE_PG_WDVALIDATION_STATUS = PropertyUtil.getSchemaProperty("attribute_pgWDValidationStatus");
		public static final String ATTRIBUTE_PG_WD_STATUS = PropertyUtil.getSchemaProperty("attribute_pgWDStatius");
		public static final String ATTRIBUTE_ESERVICE_NAME_PREFIX = PropertyUtil.getSchemaProperty("attribute_eServiceNamePrefix");
		public static final String ATTRIBUTE_PG_SHORT_CODE = PropertyUtil.getSchemaProperty("attribute_pgShortCode");
		public static final String ATTR_PRODUCT_FORM = PropertyUtil.getSchemaProperty("attribute_ProductForm");
		public static final String ATTR_UNDER_HANG_ACTUAL_LENGTH = PropertyUtil.getSchemaProperty ("attribute_pgUnderhangActualLength");
		public static final String ATTR_UNDER_HANG_ACTUAL_WIDTH  = PropertyUtil.getSchemaProperty ("attribute_pgUnderhangActualWidth");
		public static final String ATTR_OVER_HANG_ACTUAL_LENGTH = PropertyUtil.getSchemaProperty ("attribute_pgOverhangActualLength");
		public static final String ATTR_OVER_HANG_ACTUAL_WIDTH = PropertyUtil.getSchemaProperty ( "attribute_pgOverhangActualWidth");
		public static final String ATTR_AREA_EFFICIENCY = PropertyUtil.getSchemaProperty ( "attribute_pgAreaEffeciency");
		public static final String ATTR_OBJECT_TYPE = PropertyUtil.getSchemaProperty("attribute_pgObjectType");
		public static final String ATTR_PG_STACKING_PATTERN_TYPE = PropertyUtil.getSchemaProperty ("attribute_pgStackingPatternType");
		public static final String ATTR_PG_CUBE_EFFECIENCY = PropertyUtil.getSchemaProperty ("attribute_pgCubeEffeciency");
		public static final String ATTR_ESERVICE_NAME_PREFIX = PropertyUtil.getSchemaProperty ("attribute_eServiceNamePrefix");
		public static final String ATTR_PG_CONSUMERUNIT_IN_CUSTOMERUNIT = PropertyUtil.getSchemaProperty("attribute_pgNumberOfConsumerUnitsInCustomerUnit");
		public static final String ATTR_PG_SEQUENCE = PropertyUtil.getSchemaProperty("attribute_pgSequence");
		public static final String ATTR_PG_GEOMETRICSHAPE = PropertyUtil.getSchemaProperty("attribute_pgGeometryShape");
		public static final String ATTR_PG_BODYSHAPE = PropertyUtil.getSchemaProperty("attribute_pgBodyShape");
		public static final String ATTR_PG_TOPSATTR_IN_CONSISTENCYFLAG = PropertyUtil.getSchemaProperty("attribute_pgTOPSAttrInconsistencyFlag");
		public static final String ATTR_PG_FAILED_REASON = PropertyUtil.getSchemaProperty("attribute_pgFailedReason");
		public static final String ATTR_PG_SPS_ORIGINATION = PropertyUtil.getSchemaProperty("attribute_pgSPSOrigination");
		public static final String ATTR_DESIGN_PURCHASE = PropertyUtil.getSchemaProperty("attribute_DesignPurchase");
		public static final String ATTR_PG_ERROR_DATE = PropertyUtil.getSchemaProperty("attribute_pgErrorDate");
		public static final String ATTR_PG_MATERIAL_GROUP = PropertyUtil.getSchemaProperty("attribute_pgMaterialGroup");
		public static final String ATTR_ESKO_VIEWABLE_FILE_NAME = PropertyUtil.getSchemaProperty("attribute_EskoViewableFileName");
		public static final String ATTRIBUTE_PGPLI_APPROVER_ROLE = PropertyUtil.getSchemaProperty("attribute_pgPLIApproverRole");
		public static final String ATTRIBUTE_PG_DIAMETER = PropertyUtil.getSchemaProperty("attribute_pgDiameter");
		public static final String ATTRIBUTE_PG_TOPDIAMETER = PropertyUtil.getSchemaProperty("attribute_pgTopDiameter");
		public static final String ATTRIBUTE_PG_BOTTOMDIAMETER = PropertyUtil.getSchemaProperty("attribute_pgBottomDiameter");
		public static final String ATTRIBUTE_PG_PITCH = PropertyUtil.getSchemaProperty("attribute_pgPitch");
		public static final String ATTRIBUTE_PG_TOPDEPTH = PropertyUtil.getSchemaProperty("attribute_pgTopDepth");
		public static final String ATTRIBUTE_PG_TOPWIDTH = PropertyUtil.getSchemaProperty("attribute_pgTopWidth");
		public static final String ATTRIBUTE_PG_BOTTOMWIDTH = PropertyUtil.getSchemaProperty("attribute_pgBottomWidth");
		public static final String ATTRIBUTE_PG_BODYDIAMETER = PropertyUtil.getSchemaProperty("attribute_pgBodyDiameter");
		public static final String ATTRIBUTE_PG_NECKDIAMETER = PropertyUtil.getSchemaProperty("attribute_pgNeckDiameter");
		public static final String ATTRIBUTE_PG_NECKHEIGHT = PropertyUtil.getSchemaProperty("attribute_pgNeckHeight");
		public static final String ATTRIBUTE_PG_SHOULDERHEIGHT = PropertyUtil.getSchemaProperty("attribute_pgShoulderHeight");
		public static final String ATTRIBUTE_PG_BODYDEPTH = PropertyUtil.getSchemaProperty("attribute_pgBodyDepth");
		public static final String ATTRIBUTE_PG_BODYWIDTH = PropertyUtil.getSchemaProperty("attribute_pgBodyWidth");
		public static final String ATTRIBUTE_PG_TOPINDENT = PropertyUtil.getSchemaProperty("attribute_pgTopIndent");
		public static final String ATTRIBUTE_PG_BOTTOMINDENT = PropertyUtil.getSchemaProperty("attribute_pgBottomIndent");
		public static final String ATTRIBUTE_PG_SIDEINDENT = PropertyUtil.getSchemaProperty("attribute_pgSideIndent");
		public static final String ATTRIBUTE_PGCOSRUNDATE = PropertyUtil.getSchemaProperty("attribute_pgCOSRunDate");
		public static final String ATTR_PG_HASART = PropertyUtil.getSchemaProperty("attribute_pgHasArt");
		public static final String ATTR_PG_INHERITANCE_LEVEL = PropertyUtil.getSchemaProperty("attribute_pgInheritanceLevel");
		public static final String ATTR_PG_INHERITANCE_STATUS = PropertyUtil.getSchemaProperty("attribute_pgInheritanceStatus");
		public static final String ATTR_PG_INHERITANCE_TYPE = PropertyUtil.getSchemaProperty("attribute_pgPFInheritanceType");
		public static final String ATTR_PG_PF_CHANGE = PropertyUtil.getSchemaProperty("attribute_pgPFChange");
		public static final String ATTR_PG_IP_CLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pgIPClassification");
		public static final String ATTR_PG_IP_PROJECT_SECURITY = PropertyUtil.getSchemaProperty("attribute_pgIPProjectSecurity");
		public static final String ATTRIBUTE_E_PGENTPRTNUMBER = PropertyUtil.getSchemaProperty("attribute_pngComponent.pngEnterprisePartNumber");
		public static final String ATTRIBUTE_pngSECURITYCATEGORY = PropertyUtil.getSchemaProperty("attribute_pngComponent.pngSecurityCategory");
		public static final String ATTRIBUTE_pngPROJECTSECURITYCLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pngComponent.pngProjectSecurityClassification");
		public static final String ATTRIBUTE_PGIPCLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pgIPClassification");
		public static final String ATTRIBUTE_PGIPPROJECTSECURITY = PropertyUtil.getSchemaProperty("attribute_pgIPProjectSecurity");
		public static final String ATTRIBUTE_pngSECURITYCATEGORYCLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pngComponent.pngSecurityCategoryClassification");	
		public static final String ATTRIBUTE_ISVPLMCONTROLLED = PropertyUtil.getSchemaProperty("attribute_PLMReference.V_isVPLMControlled");
		public static final String ATTRIBUTE_VERSIONCOMMENT = PropertyUtil.getSchemaProperty("attribute_PLMReference.V_versionComment");
		//Modified for the Upgrade from 2015x to 2018x 
		public static final String ATTRIBUTE_CADDESIGNORIGINATION = PropertyUtil.getSchemaProperty("attribute_pngiDesignPart.pngCADDesignOrigination");
		public static final String ATTR_PG_REPORTTYPE = PropertyUtil.getSchemaProperty("attribute_pgReportType");
		public static final String ATTR_PG_LOWERSPECIFICATIONLIMIT = PropertyUtil.getSchemaProperty("attribute_pgLowerSpecificationLimit");
		public static final String ATTR_PG_LOWERROUTINERELEASELIMIT = PropertyUtil.getSchemaProperty("attribute_pgLowerRoutineReleaseLimit");
		public static final String ATTR_PG_LOWERTARGET = PropertyUtil.getSchemaProperty("attribute_pgLowerTarget");
		public static final String ATTR_PG_TARGET = PropertyUtil.getSchemaProperty("attribute_pgTarget");
		public static final String ATTR_PG_UPPERTARGET = PropertyUtil.getSchemaProperty("attribute_pgUpperTarget");
		public static final String ATTR_PG_UPPERROUTINERELEASELIMIT = PropertyUtil.getSchemaProperty("attribute_pgUpperRoutineReleaseLimit");
		public static final String ATTR_PG_UPPERSPECIFICATIONLIMIT = PropertyUtil.getSchemaProperty("attribute_pgUpperSpecificationLimit");
		public static final String ATTR_PG_CHARACTERISTIC = PropertyUtil.getSchemaProperty("attribute_pgCharacteristic"); 
		public static final String ATTR_PG_RELEASECRITERIA = PropertyUtil.getSchemaProperty("attribute_pgReleaseCriteria");
		public static final String ATTR_PG_ROUTINERELEASECRITERIA = PropertyUtil.getSchemaProperty("attribute_pgRoutineReleaseCriteria");
		public static final String ATTR_PG_VENDORTYPE = PropertyUtil.getSchemaProperty("attribute_pgVendorType");
		public static final String ATTR_PG_PLANTTESTINGTEXT = PropertyUtil.getSchemaProperty("attribute_pgPlantTestingText");
		public static final String ATTR_PG_PLANTTESTINGRETESTING = PropertyUtil.getSchemaProperty("attribute_pgPlantTestingRetesting");
		public static final String ATTR_PG_REQUESTEDCHANGE = PropertyUtil.getSchemaProperty("attribute_RequestedChange");
		// DSM (DS) 2015x.1 - Fix for Defect 7495 - blocking sync operation if the security category selected is not available for classification - Start
			public static final String ATTR_PG_IPCLASSAVAILABLEFORCALSSIFICATION  = PropertyUtil.getSchemaProperty("attribute_pgIPClassAvailableForClassification");
		// DSM (DS) 2015x.1 - Fix for Defect 7495 - blocking sync operation if the security category selected is not available for classification - End
		public static final String ATTR_PG_ISLEAFLEVEL = PropertyUtil.getSchemaProperty("attribute_pgIsLeafLevel");
		//DSM (DS) 2015x.1.2  Defect #7536 - Add field for tracking primary Transport unit for .2 Bom as Fed -start
		public static final String ATTR_PG_IS_PRIMARY = PropertyUtil.getSchemaProperty("attribute_pgIsPrimary");
		//DSM (DS) 2015x.1.2  Defect #7536 - Add field for tracking primary Transport unit for .2 Bom as Fed -ends
		public static final String ATTR_PG_LEGACYPRODUCTWT = PropertyUtil.getSchemaProperty("attribute_pgLegacyProductWeight");
		public static final String ATTR_PRIMARY_IMAGE = PropertyUtil.getSchemaProperty("attribute_PrimaryImage");
		//Added by DSM (DS) for ALM 9584 STARTS
		public static final String ATTR_ENGINUITYAUTHORED = PropertyUtil.getSchemaProperty("attribute_EnginuityAuthored");
		//Added by DSM (DS) for ALM 9584 ENDS
		//DSM(DS) 2015x.4 - To include Enginuity Formula reference on Formulation Process - START
		public static final String ATTRIBUTE_PGFORMULATIONPROCESSNUMBER = PropertyUtil.getSchemaProperty("attribute_pgFormulationProcessNumber");
		//DSM(DS) 2015x.4 - To include Enginuity Formula reference on Formulation Process - END
		//DSM(DS) 2015x.4 - Approver Role validation - START
		public static final String ATTRIBUTE_PG_APPROVER_ROLE = PropertyUtil.getSchemaProperty("attribute_pgApproverRole");
		//DSM(DS) 2015x.4 - Approver Role validation - END
		public static final String ATTR_PG_DOESPRODUCTREQCHILDSAGEDESIGN = PropertyUtil.getSchemaProperty("attribute_pgDoestheProductRequireChildSafeDesign");
		public static final String ATTR_PG_ISTHEDESIGNCHILDSAFE = PropertyUtil.getSchemaProperty("attribute_pgIstheDesignChildSafe");
		
		//DSM(DS) 2015x.5.1 - Stability Results Characteristic Table - START
		public static final String ATTR_PG_EXPIRATIONDATEFORSTABILITYRESULT = PropertyUtil.getSchemaProperty("attribute_pgExpirationDateForStabilityResults");
		public static final String ATTR_PG_TOTALSHELFLIFE = PropertyUtil.getSchemaProperty("attribute_pgTotalShelfLife");
		public static final String ATTR_PG_TEMPERATUREGROUP = PropertyUtil.getSchemaProperty("attribute_pgTemparatureGroup");
		public static final String ATTR_PG_HUMIDITYGROUP = PropertyUtil.getSchemaProperty("attribute_pgHumidityGroup");
		public static final String ATTR_PG_TRANSPORTFREEZEPROTECTION = PropertyUtil.getSchemaProperty("attribute_pgTransportFreezeProtection");
		public static final String ATTR_PG_TRANSPORTHEATPROTECTION = PropertyUtil.getSchemaProperty("attribute_pgTransportHeatProtection");
		//DSM(DS) 2015x.5.1 - Stability Results Characteristic Table - END
		//DSM(DS) 2018x.1.1  - Req 25900 - Change field Product Category Platform Mandatory for Pilot and Production Phase - START
		public static final String ATTRIBUTE_PG_PLATFORM_TYPE = PropertyUtil.getSchemaProperty("attribute_pgPlatformType");
		//DSM(DS) 2018x.1.1  - Req 25900 - Change field Product Category Platform Mandatory for Pilot and Production Phase - END
		
		//DSM(DS) 2015x5 - ALM 15849 - eCOA template not being accepted due to most recent error message about characteristics not matching - Starts
		public static final String STRING_ACTIONREQUIREDCOLUMNHEADER = "Action Required";
		//DSM(DS) 2015x5 - ALM 15849 - eCOA template not being accepted due to most recent error message about characteristics not matching - Ends
		// Type Definition
		public static final String TYPE_SHARED_TABLE = PropertyUtil.getSchemaProperty("type_SharedTable");
		public static final String TYPE_RAWMATERIAL_PART = PropertyUtil.getSchemaProperty("type_RawMaterial");
		public static final String TYPE_PACKAGINGMATERIAL_PART = PropertyUtil.getSchemaProperty("type_PackagingMaterialPart");
		public static final String TYPE_FORMULATION_FAMILY = PropertyUtil.getSchemaProperty("type_FormulationFamily");
		public static final String TYPE_FORMULATION = PropertyUtil.getSchemaProperty("type_Formulation");
		public static final String TYPE_FORMULATION_PART = PropertyUtil.getSchemaProperty("type_FormulationPart");
		public static final String TYPE_FORMULATED_PRODUCT = PropertyUtil.getSchemaProperty("type_pgFormulatedProduct");
		public static final String TYPE_FORMULATION_PROPAGATE = PropertyUtil.getSchemaProperty("type_FormulationPropagate");
		public static final String TYPE_FORMULATION_PROCESS = PropertyUtil.getSchemaProperty("type_FormulationProcess");
		public static final String TYPE_FORMULATION_PHASE = PropertyUtil.getSchemaProperty("type_FormulationPhase");
		public static final String TYPE_FORMULATION_PROCESS_INSTRUCTIONS = PropertyUtil.getSchemaProperty("type_ProcessingInstruction");
		public static final String TYPE_PGSIGNUPFORM = PropertyUtil.getSchemaProperty("type_pgSignupForm");
		public static final String TYPE_PART = PropertyUtil.getSchemaProperty("type_Part");
		public static final String TYPE_TECHNICAL_SPECIFICATION = PropertyUtil.getSchemaProperty("type_TechnicalSpecification");
		public static final String TYPE_FINISHEDPRODUCT_PART = PropertyUtil.getSchemaProperty("type_FinishedProductPart");
		public static final String TYPE_PG_CONSUMERUNIT = PropertyUtil.getSchemaProperty("type_pgConsumerUnitPart");
		public static final String TYPE_PG_TRANSPORTUNIT = PropertyUtil.getSchemaProperty("type_pgTransportUnitPart");
		public static final String TYPE_PG_CUSTOMERUNIT = PropertyUtil.getSchemaProperty("type_pgCustomerUnitPart");
		public static final String TYPE_PG_MASTERCUSTOMERUNIT = PropertyUtil.getSchemaProperty("type_pgMasterCustomerUnitPart");
		public static final String TYPE_PG_GLOBALFORM = PropertyUtil.getSchemaProperty("type_pgGlobalForm");
		public static final String TYPE_PG_PLIGLOBALFORM = PropertyUtil.getSchemaProperty("type_pgPLIGlobalForm");
		public static final String TYPE_PG_AffectedFPPLIST = PropertyUtil.getSchemaProperty("type_pgDSOAffectedFPPList");
		public static final String TYPE_PG_CATEGORY = PropertyUtil.getSchemaProperty("type_pgCategory");
		public static final String TYPE_PRODUCTDATAPART = PropertyUtil.getSchemaProperty("type_ProductDataPart");
		public static final String TYPE_SEGMENT = PropertyUtil.getSchemaProperty("type_Segment");
		public static final String TYPE_PG_PLICONSUMERUNIT = PropertyUtil.getSchemaProperty("type_pgPLIConsumerUnit");
		public static final String TYPE_PG_PLICUSTOMERUNIT = PropertyUtil.getSchemaProperty("type_pgPLICustomerUnit");
		public static final String TYPE_PG_PLIINNERPACK = PropertyUtil.getSchemaProperty("type_pgPLIWDInnerPack");
		public static final String TYPE_PG_PLIPALLETTYPE = PropertyUtil.getSchemaProperty("type_pgPLIPalletType");
		public static final String TYPE_PG_MASTERCONSUMERUNIT = PropertyUtil.getSchemaProperty("type_pgMasterConsumerUnitPart");
		public static final String TYPE_PG_MASTERINNERPACKUNIT = PropertyUtil.getSchemaProperty("type_pgMasterInnerPackUnitPart");
		public static final String TYPE_PG_AUTHORIZEDTEMPORARYSTANDARD = PropertyUtil.getSchemaProperty("type_pgAuthorizedTemporarySpecification");
		public static final String TYPE_PG_AUTHORIZEDTEMPORARYSPECIFICATION = PropertyUtil.getSchemaProperty("type_pgAuthorizedTemporarySpecification");
		public static final String TYPE_PG_FINISHEDPRODUCTPART = PropertyUtil.getSchemaProperty("type_FinishedProductPart");
		public static final String TYPE_PG_TECHNICALSPECIFICATION = PropertyUtil.getSchemaProperty("type_TechnicalSpecification");
		public static final String TYPE_PG_ANCILLARYPACKAGINGMATERIALPART = PropertyUtil.getSchemaProperty("type_pgAncillaryPackagingMaterialPart");
		public static final String TYPE_PG_PROMOTIONALITEMPART = PropertyUtil.getSchemaProperty("type_pgPromotionalItemPart");
		public static final String TYPE_PG_INNERPACK  = PropertyUtil.getSchemaProperty("type_pgInnerPackUnitPart");
		public static final String TYPE_PGPACKINGSUBASSEMBLY  = PropertyUtil.getSchemaProperty("type_pgPackingSubassembly");
		public static final String TYPE_PGPACKINGMATERIAL  = PropertyUtil.getSchemaProperty("type_pgPackingMaterial");
		public static final String TYPE_FINISHEDPRODUCT  = PropertyUtil.getSchemaProperty("type_pgFinishedProduct");
		public static final String TYPE_PGPACKINGINSTRUCTION = PropertyUtil.getSchemaProperty("type_pgPackingInstructions");
		public static final String TYPE_PGPLILIFECYCLESTATUS  = PropertyUtil.getSchemaProperty("type_pgPLILifeCycleStatus");
		public static final String TYPE_PG_PLIBUOM = PropertyUtil.getSchemaProperty("type_pgPLIBUOM");
		public static final String TYPE_PG_STACKINGPATTERN = PropertyUtil.getSchemaProperty("type_pgStackingPattern");
		public static final String TYPE_DOCUMENTS = PropertyUtil.getSchemaProperty("type_DOCUMENTS");
		public static final String TYPE_PACKAGINGMATERIALPART = PropertyUtil.getSchemaProperty("type_PackagingMaterialPart");
		public static final String TYPE_PACKAGINGASSEMBLYPART = PropertyUtil.getSchemaProperty("type_PackagingAssemblyPart");
		public static final String TYPE_PG_ONLINEPRINTINGPART= PropertyUtil.getSchemaProperty("type_pgOnlinePrintingPart");
		public static final String TYPE_PG_GCASMAGAZINE   = PropertyUtil.getSchemaProperty("type_pgGCASMagazine");
		public static final String TYPE_PGMASTERPACKAGINGMATERIALPART = PropertyUtil.getSchemaProperty("type_pgMasterPackagingMaterialPart");
		public static final String TYPE_PGMASTERPACKAGINGASSEMBLYPART = PropertyUtil.getSchemaProperty("type_pgMasterPackagingAssemblyPart");
		public static final String TYPE_PG_CONSOLIDATEDWEIGHT = PropertyUtil.getSchemaProperty("type_pgConsolidatedWeight");
		public static final String TYPE_PG_PDPWEIGHT = PropertyUtil.getSchemaProperty("type_pgProductDataPartWeight");
		public static final String TYPE_PG_TUPWEIGHT = PropertyUtil.getSchemaProperty("type_pgTransportUnitPartWeight");
		public static final String TYPE_PG_COPWEIGHT = PropertyUtil.getSchemaProperty("type_pgConsumerUnitPartWeight");
		public static final String TYPE_PG_ASSYWEIGHT = PropertyUtil.getSchemaProperty("type_pgAssemblyWeight");
		public static final String TYPE_PG_SECTOR = PropertyUtil.getSchemaProperty("type_pgSector");
		public static final String TYPE_PG_SUB_SECTOR = PropertyUtil.getSchemaProperty("type_pgSubSector");
		public static final String TYPE_ESERVICE_OBJECT_GENERATOR = PropertyUtil.getSchemaProperty("type_eServiceObjectGenerator");
		public static final String TYPE_GENERIC_DOCUMENT = PropertyUtil.getSchemaProperty("type_GenericDocument");
		public static final String TYPE_SUPPLIER = PropertyUtil.getSchemaProperty("type_pgSupplier");
		public static final String TYPE_CLASS = PropertyUtil.getSchemaProperty("type_pgPLIClass");
		public static final String TYPE_SUB_CLASS = PropertyUtil.getSchemaProperty("type_pgPLISubClass");
		public static final String TYPE_REPORTED_FUNCTION = PropertyUtil.getSchemaProperty("type_pgPLIReportedFunction");
		public static final String TYPE_ENV_CLASS = PropertyUtil.getSchemaProperty("type_pgPLIEnvironmentalClass");
		public static final String TYPE_MATERIAL_LIBRARY = PropertyUtil.getSchemaProperty("type_pgMaterialLibrary");
		public static final String TYPE_MATERIAL_FAMILY = PropertyUtil.getSchemaProperty("type_pgMaterialFamily");
		public static final String TYPE_PGIPMDOCUMENT = PropertyUtil.getSchemaProperty("type_pgIPMDocument");
		public static final String TYPE_PG_APPROVED_SUPPLIER_LIST = PropertyUtil.getSchemaProperty("type_pgApprovedSupplierList");
		public static final String TYPE_ART_WORK = PropertyUtil.getSchemaProperty("type_pgArtwork");
		public static final String TYPE_MATERIAL = PropertyUtil.getSchemaProperty("type_Material");
		public static final String TYPE_WORKSPACE_VAULT = PropertyUtil.getSchemaProperty("type_ProjectVault");
		public static final String TYPE_PROJECT_SPACE = PropertyUtil.getSchemaProperty("type_ProjectSpace");
		public static final String TYPE_MATERIAL_GROUP = PropertyUtil.getSchemaProperty("type_pgMaterialGroup");
		public static final String TYPE_ARTIOSCAD_COMPONENT = PropertyUtil.getSchemaProperty("type_ArtiosCADComponent");
		public static final String TYPE_POA = PropertyUtil.getSchemaProperty("type_POA");
		public static final String TYPE_PG_MASTERPACKAGINGASSEMBLYPART = PropertyUtil.getSchemaProperty("type_pgMasterPackagingAssemblyPart");
		public static final String TYPE_VPLMTYP_PGPKG_REF = PropertyUtil.getSchemaProperty("type_VPLMtyp@pgPKG_Ref");
		public static final String TYPE_PG_PERFORMANCECHARACTERISTICS = PropertyUtil.getSchemaProperty("type_pgPerformanceCharacteristic");
		public static final String TYPE_PG_ILLUSTRATION = PropertyUtil.getSchemaProperty("type_pgIllustration");
		public static final String TYPE_PG_PKGVPMPART = PropertyUtil.getSchemaProperty("type_pgPKGVPMPart");
		public static final String TYPE_PG_PLICHARACTERISTIC = PropertyUtil.getSchemaProperty("type_pgPLICharacteristic");
		public static final String TYPE_PG_PLICHARSPECIFICS = PropertyUtil.getSchemaProperty("type_pgPLICharacteristicSpecifics");
		public static final String TYPE_INTERNAL_MATERIAL = PropertyUtil.getSchemaProperty("type_InternalMaterial");
		public static final String TYPE_PG_PLI_SEGMENT = PropertyUtil.getSchemaProperty("type_pgPLISegment");
		public static final String TYPE_IP_CONTROL_CLASS = PropertyUtil.getSchemaProperty("type_IPControlClass");
		public static final String TYPE_SECURITY_CONTROL_CLASS = PropertyUtil.getSchemaProperty("type_SecurityControlClass");
		public static final String TYPE_CA = PropertyUtil.getSchemaProperty("type_ChangeAction");
		public static final String TYPE_PG_QUALITY_SPECIFICATION = PropertyUtil.getSchemaProperty("type_pgQualitySpecification");
		public static final String TYPE_PG_SUPPLIER_INFORMATION_SHEET = PropertyUtil.getSchemaProperty("type_pgSupplierInformationSheet");
		public static final String TYPE_PG_STANDARD_OPERATING_PROCEDURE = PropertyUtil.getSchemaProperty("type_pgStandardOperatingProcedure");
		public static final String TYPE_PG_PLI_ORGANIZATION_CHANGE_MANAGEMENT = PropertyUtil.getSchemaProperty("type_pgPLIOrganizationChangeManagement");
		public static final String TYPE_FABRICATED_PART = PropertyUtil.getSchemaProperty("type_pgFabricatedPart");
		public static final String TYPE_PG_TMRD_TYPES = PropertyUtil.getSchemaProperty("type_pgQualitySpecification")+","+PropertyUtil.getSchemaProperty("type_pgStandardOperatingProcedure")+","+PropertyUtil.getSchemaProperty("type_pgIllustration");
		public static final String TYPE_PGPLI_UOMWD = PropertyUtil.getSchemaProperty("type_pgPLIUnitofMeasureWD");
		public static final String TYPE_PGPLI_VENDORTYPE = PropertyUtil.getSchemaProperty("type_pgPLIVendorType");
		public static final String TYPE_PGPLSUBSETLIST = PropertyUtil.getSchemaProperty("type_pgPLSubsetList");
		public static final String TYPE_ARTIOSCAD_VERSION_COMPONENT = PropertyUtil.getSchemaProperty("type_ArtiosCADVersionedComponent");
		//DSM(DS) - Fix for ALM 20777 - Unable to Promote CA to In Approval State - START
		public static final String TYPE_PGCONFIGURATION = PropertyUtil.getSchemaProperty("type_VPMReference");
		//DSM(DS) - Fix for ALM 20777 - Unable to Promote CA to In Approval State - END
		public static final String TYPE_IPCONTROLCLASS = PropertyUtil.getSchemaProperty("type_IPControlClass");
		public static final String TYPE_SECURITYCONTROLCLASS = PropertyUtil.getSchemaProperty("type_SecurityControlClass");
		public static final String TYPE_PG_TEST_METHOD = PropertyUtil.getSchemaProperty("type_pgTestMethod");
		public static final String TYPE_DRAWING = PropertyUtil.getSchemaProperty("type_Drawing");
		public static final String TYPE_TEST_METHOD = PropertyUtil.getSchemaProperty("type_TestMethod");
		public static final String TYPE_PG_PLIDOCUMENTSUBTYPE = PropertyUtil.getSchemaProperty("type_pgPLIDocumentSubType");
		public static final String TYPE_PG_MASTER_PRODUCT_PART = PropertyUtil.getSchemaProperty("type_pgMasterProductPart");
		public static final String TYPE_PG_MASTER_RAW_MATERIAL_PART = PropertyUtil.getSchemaProperty("type_pgMasterRawMaterialPart");
		public static final String TYPE_COSMETIC_FORMULATION = PropertyUtil.getSchemaProperty("type_CosmeticFormulation");
		public static final String TYPE_TEMPLATE = PropertyUtil.getSchemaProperty("type_Template");	
		public static final String TYPE_PARENT_SUB = PropertyUtil.getSchemaProperty("type_ParentSub");
		public static final String TYPE_PG_MAKING_INSTRUCTIONS  = PropertyUtil.getSchemaProperty("type_pgMakingInstructions");
		public static final String TYPE_TRANSLATION_DOC  = PropertyUtil.getSchemaProperty("type_pgPKGTranslationFile");
		public static final String TYPE_3DSHAPE  = PropertyUtil.getSchemaProperty("type_3DShape");
		public static final String TYPE_PG_LABORATORY_INDEX_SPECIFICATION = PropertyUtil.getSchemaProperty("type_pgLaboratoryIndexSpecification");
		//DSM(DS) 2015x.5.1 - Stability Results Characteristic Table - START
		public static final String TYPE_PG_STABILITY_RESULTS = PropertyUtil.getSchemaProperty("type_pgStabilityResults");
		public static final String TYPE_PG_IRM_DOC_TYPES = PropertyUtil.getSchemaProperty("type_pgPKGStabilityReport")+","+PropertyUtil.getSchemaProperty("type_ProductStabilityReport");
		//DSM(DS) 2015x.5.1 - Stability Results Characteristic Table - END
		//DSM(DS) 2018x.2 - Changes for FSD_GHS Req.28913 - THE SYSTEM SHALL DISPLAY GLOBAL HARMONIZED STANDARD TABLE ON APP, DPP & FOP & FPP - START
		public static final String TYPE_COPYLIST = PropertyUtil.getSchemaProperty("type_CopyList");
		//DSM(DS) 2018x.2 - Changes for FSD_GHS Req.28913 - THE SYSTEM SHALL DISPLAY GLOBAL HARMONIZED STANDARD TABLE ON APP, DPP & FOP & FPP - END
		//DSM(DS) 2015x.5.1 - Software Part and Software Build - START
		public static final String TYPE_PG_SOFTWARE_PART = PropertyUtil.getSchemaProperty("type_pgSoftwarePart");
		public static final String TYPE_SOFTWARE_BUILD = PropertyUtil.getSchemaProperty("type_SoftwareBuild");
		public static final String STATE_PLAN = "Plan";
		//DSM(DS) 2015x.5.1 - Software Part and Software Build - END
		// State Definition
		public static final String STATE_RELEASE = "Release";
		public static final String STATE_COMPLETE = "Complete";
		public static final String STATE_APPROVED = "Approved";
		public static final String STATE_OBSOLETE = "Obsolete";
		public static final String STATE_PRELIMINARY = "Preliminary";
		public static final String STATE_REVIEW = "Review";
		public static final String STATE_ACTIVE = "Active";
		public static final String STATE_INACTIVE = "Inactive";
		public static final String STATE_LOCKED = "Locked";
		public static final String STATE_PRODUCTION = "Production";
		public static final String STATE_ASSIGNED = "Assigned";
		
		//Interface Definition
		public static final String INTERFACE_PART_FAMILY_REFERENCE = PropertyUtil.getSchemaProperty("interface_PartFamilyReference");
		
		// Vault Definition
		public static final String VAULT_ESERVICE_PRODUCTION = "eService Production";
		
		// Relationship Definition
		public static final String RELATIONSHIP_COOWNED = PropertyUtil.getSchemaProperty("relationship_CoOwned");
		public static final String RELATIONSHIP_ADDITIONAL_BRAND = PropertyUtil.getSchemaProperty("relationship_AdditionalBrand");
		public static final String RELATIONSHIP_SUPPLIER_EQUIVALENT = PropertyUtil.getSchemaProperty("relationship_SupplierEquivalent");
		public static final String RELATIONSHIP_COMPONENT_SUBSTANCE = PropertyUtil.getSchemaProperty("relationship_ComponentSubstance");
		public static final String RELATIONSHIP_APPROVINGORGANIZATION = PropertyUtil.getSchemaProperty("relationship_ApprovingOrganization");
		public static final String RELATIONSHIP_SHARED_CHARACTERISTIC = PropertyUtil.getSchemaProperty("relationship_SharedCharacteristic");
		public static final String TYPE_PG_APPROVEDSUPPLIERLIST = PropertyUtil.getSchemaProperty("relationship_pgApprovedSupplierList");
		public static final String RELATIONSHIP_EBOM_SUBSTITUTE = PropertyUtil.getSchemaProperty("relationship_EBOMSubstitute");
		public static final String RELATIONSHIP_OWNING_PRODUCTLINE = PropertyUtil.getSchemaProperty("relationship_OwningProductLine");
		public static final String RELATIONSHIP_SHARED_TABLE = PropertyUtil.getSchemaProperty("relationship_SharedTable");
		public static final String REL_PG_AffectedFPPLIST = PropertyUtil.getSchemaProperty("relationship_pgDSOAffectedFPPList");
		public static final String REL_PG_REGIONSHARED = PropertyUtil.getSchemaProperty("relationship_pgRegionShared");
		public static final String REL_PG_SECURITY_ASSETTOPROJECTSECURITYGROUP = PropertyUtil.getSchemaProperty("relationship_pgSecurityAssetToProjectSecurityGroup");
		public static final String REL_PG_BRAND_PICKLIST = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgBrand");
		public static final String REL_PG_SEGMENT_PICKLIST = PropertyUtil.getSchemaProperty("relationship_OwningProductLine");
		public static final String REL_PG_CUSTOMIZATIONTYPE_PICKLIST = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLICustomizationType");
		public static final String REL_PG_GLOBALFORM_PICKLIST = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLIGlobalForm");
		public static final String REL_PG_PDTEMPLATES_TO_PGLIFECYCLESTATUS = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLILifeCycleStatus");
		public static final String REL_PG_TRANSPORT_UNIT = PropertyUtil.getSchemaProperty("relationship_pgTransportUnit");
		public static final String REL_PG_PALLETTYPE_PICKLIST = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLIPalletType");
		public static final String REL_PARTFAMILYREFERENCE = PropertyUtil.getSchemaProperty("relationship_PartFamilyReference");
		public static final String REL_PG_UNITSIZE_PICKLIST = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLIUnitSize");
		public static final String REL_PG_PDTEMPLATES_TO_PGPLIBUOM = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLIBUOM");
		public static final String REL_CLASSIFIED_ITEM = PropertyUtil.getSchemaProperty("relationship_ClassifiedItem");
		public static final String REL_AUTHORISEDTEMPORARYSPECIFICATION  = PropertyUtil.getSchemaProperty("relationship_AuthorizedTemporarySpecification");
		public static final String REL_DERIVED  = PropertyUtil.getSchemaProperty("relationship_Derived");
		public static final String REL_PG_SECURITY_ASSETTOSECURITYGROUP = PropertyUtil.getSchemaProperty("relationship_pgSecurityAssetToSecurityGroup");
		public static final String REL_PG_COOWNED = PropertyUtil.getSchemaProperty("relationship_CoOwned");
		public static final String REL_PG_PDTEMPLATES_TO_PGPLILANGUAGE = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLILanguage");
		public static final String REL_PG_PDTEMPLATES_TO_GROSSWTUOM = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestoGrossWeightUnitOfMeasure");
		public static final String REL_PG_PDTEMPLATES_TO_NETWTOFPRODUCTINCOPUOM = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestoNetWeightOfProductInConsumerUnitUoM");
		public static final String REL_PG_AffectedFPPLISTTOCHANGE = PropertyUtil.getSchemaProperty("relationship_pgDSOAffectedFPPListtoChange");
		public static final String REL_REPORTEDAGAINSTCHANGE = PropertyUtil.getSchemaProperty("relationship_ReportedAgainstChange");
		public static final String REL_PG_REGION_TO_CHANGE = PropertyUtil.getSchemaProperty("relationship_pgRegionToChange");
		public static final String REL_PG_REGION_TO_ROUTE_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_pgRegionToRouteTemplate");
		public static final String REL_PG_APPROVEDSUPPLIERLIST = PropertyUtil.getSchemaProperty("relationship_pgApprovedSupplierList");
		public static final String REL_Subclass = PropertyUtil.getSchemaProperty("relationship_Subclass");
		public static final String REL_SUB_PRODUCT_LINES = PropertyUtil.getSchemaProperty("relationship_SubProductLines");
		public static final String REL_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_Template");
		public static final String REL_PG_CONSOLIDATEDWEIGHT = PropertyUtil.getSchemaProperty("relationship_pgConsolidatedWeight");
		public static final String REL_PG_PDPWEIGHT = PropertyUtil.getSchemaProperty("relationship_pgProductDataPartWeight");
		public static final String REL_PG_SHAREDWEIGHTCHARACTERISTICS = PropertyUtil.getSchemaProperty("relationship_pgConsolidatedWeightTopgProductDataPartWeight");
		public static final String REL_PART_SPECIFICATION=PropertyUtil.getSchemaProperty("relationship_PartSpecification");
		public static final String REL_REFERENCE_DOCUMENT = PropertyUtil.getSchemaProperty("relationship_ReferenceDocument");
		public static final String REL_MATERIAL_TO_SUPPLIER = PropertyUtil.getSchemaProperty("relationship_pgMaterialtopgSupplier");
		public static final String REL_MATERIAL_TO_CLASS = PropertyUtil.getSchemaProperty("relationship_pgMaterialtopgPLIClass");
		public static final String REL_MATERIAL_TO_SUB_CLASS = PropertyUtil.getSchemaProperty("relationship_pgMaterialtopgPLISubClass");
		public static final String REL_MATERIAL_TO_REPORTED_FUNCTION = PropertyUtil.getSchemaProperty("relationship_pgMaterialtopgPLIReportedFunction");
		public static final String REL_MATERIAL_TO_ENV_CLASS = PropertyUtil.getSchemaProperty("relationship_pgMaterialtopgPLIEnvironmentalClass");
		public static final String REL_PG_PDTEMPLATES_TO_PGPLIASSEMBLYTYPE = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLIAssemblyType");
		public static final String REL_PG_CHARS_TO_PGLICHARACTERISTIC = PropertyUtil.getSchemaProperty("relationship_pgPCharstopgPLICharacteristic");
		public static final String REL_PG_CHARS_TO_PGLICHARACTERISTICSPECIFICS = PropertyUtil.getSchemaProperty("relationship_pgPCharstopgPLICharacteristicSpecifics");
		public static final String REL_VAULTED_DOCUMENT_REV2 = PropertyUtil.getSchemaProperty("relationship_VaultedDocumentsRev2");
		public static final String REL_PG_REGIONOWNS = PropertyUtil.getSchemaProperty("relationship_pgRegionOwns");
		public static final String REL_COMPONENT_MATERIAL = PropertyUtil.getSchemaProperty("relationship_ComponentMaterial");
		public static final String REL_DATA_VAULTS = PropertyUtil.getSchemaProperty("relationship_ProjectVaults");
		public static final String REL_PG_PRODUCTLINE_TO_SECURITYGROUP = PropertyUtil.getSchemaProperty("relationship_pgProductLineToSecurityGroup");
		public static final String REL_PG_IPM_SUMMARY_TO_PRODUCTDATA = PropertyUtil.getSchemaProperty("relationship_pgIPMSummaryToProductData");
		public static final String RELATIONSHIP_PGMATERIALTOCOMPANY = PropertyUtil.getSchemaProperty("relationship_pgMaterialToCompany");
		public static final String RELATIONSHIP_LATEST_VERSION = PropertyUtil.getSchemaProperty("relationship_LatestVersion");
		public static final String RELATIONSHIP_ESKO_VIEWABLE_OF = PropertyUtil.getSchemaProperty("relationship_EskoViewableOf");
		public static final String REL_PG_CHANGE_AFFECTED_ITEM = PropertyUtil.getSchemaProperty("relationship_ChangeAffectedItem");
		public static final String REL_PG_IMPLEMENTED_ITEM = PropertyUtil.getSchemaProperty("relationship_ImplementedItem");
		public static final String RELATIONSHIP_PGINTENDEDORGANIZATION = PropertyUtil.getSchemaProperty("relationship_pgIntendedOrganization");
		public static final String RELATIONSHIP_PGPDTEMPLATES_TO_PGPLISEGMENT = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLISegment");
		//DSM(DS) 2018x.0 - Fix for ALM  20607 - [TC] SO approver approval status is still in pending after CA claimed - START
		public static final String REL_SENIOR_TECH_ASSIGNEE = PropertyUtil.getSchemaProperty("relationship_ChangeReviewer");
		//DSM(DS) 2018x.0 - Fix for ALM  20607 - [TC] SO approver approval status is still in pending after CA claimed - END
		public static final String REL_CHANGE_ACTION = PropertyUtil.getSchemaProperty("relationship_ChangeAction");
		public static final String REL_RESPONSIBLE_ORGANIZATION = PropertyUtil.getSchemaProperty("relationship_ResponsibleOrganization");
		public static final String REL_CHANGE_AFFECTED_ITEM = PropertyUtil.getSchemaProperty("relationship_ChangeAffectedItem");
		public static final String REL_REGION_OWNS = PropertyUtil.getSchemaProperty("relationship_RegionOwns");
		public static final String REL_CHARACTERISTIC = PropertyUtil.getSchemaProperty("relationship_Characteristic");
		public static final String REL_PG_SECONDARY_ORGANIZATION = PropertyUtil.getSchemaProperty("relationship_pgSecondaryOrganization");
		public static final String REL_PG_PRIMARY_ORGANIZATION = PropertyUtil.getSchemaProperty("relationship_pgPrimaryOrganization");
		public static final String RELATIONSHIP_EMPLOYEE = PropertyUtil.getSchemaProperty("relationship_Employee");
		public static final String RELATIONSHIP_ARTIOSCAD_IPCONTROLCLASS = PropertyUtil.getSchemaProperty("relationship_pgArtiosCADToIPControlClass");
		public static final String RELATIONSHIP_PGPLRELATEDDATA = PropertyUtil.getSchemaProperty("relationship_pgPLRelatedData");
		public static final String RELATIONSHIP_ACTIVE_VERSION = PropertyUtil.getSchemaProperty("relationship_ActiveVersion");
		public static final String REL_PG_INHERITED_CAD_SPEC = PropertyUtil.getSchemaProperty("relationship_pgInheritedCADSpecification");
		public static final String REL_FORMULATION_PROPAGATE = PropertyUtil.getSchemaProperty("relationship_FormulationPropagate");
		public static final String REL_FORMULATION_PROCESS = PropertyUtil.getSchemaProperty("relationship_FormulationProcess");
		public static final String REL_PG_MASTER = PropertyUtil.getSchemaProperty("relationship_pgMaster");
		public static final String REL_PG_PRODUCT_COMPOSITION = PropertyUtil.getSchemaProperty("relationship_pgProductComposition");
		//DSM (DS) 2015x.2.1 ALM 11614 and ALM 11202 - Added key for Material Function on EBOM page - START
		public static final String REL_MATERIAL_FUNCTIONALITY = PropertyUtil.getSchemaProperty("relationship_MaterialFunctionality");
		public static final String REL_PG_TO_MATERIAL_FUNCTION = PropertyUtil.getSchemaProperty("relationship_pgToMaterialFunctionGlobal");
		public static final String ORIGINATINGSOURCE_CSS = "CSS INTEGRATION - ";
		//DSM (DS) 2015x.2.1 ALM 11614 and ALM 11202 - Added key for Material Function on EBOM page - END
		
		public static final String TYPE_VPLMREPINSTANCE = PropertyUtil.getSchemaProperty("relationship_VPMRepInstance");
		
		//DSM(DS) 2015x.4 -ALM 14016 - PQR Qualified Equivalents has the same SEP listed twice and linking to the Obsolete SEP -START
		public static final String RELATIONSHIP_MANUFACTURER_EQUIVALENT = PropertyUtil.getSchemaProperty("relationship_ManufacturerEquivalent");
		public static final String RELATIONSHIP_QUALIFICATION = PropertyUtil.getSchemaProperty("relationship_Qualification");
		//DSM(DS) 2015x.4 -ALM 14016 - PQR Qualified Equivalents has the same SEP listed twice and linking to the Obsolete SEP -END
		//DSM (DS) 2018x.1.1 - PDT Requirement 25900 - Change field Product Category Platform Mandatory for Pilot and Production Phase - START
		public static final String REL_PG_DOCUMENTTOPLATFORM = PropertyUtil.getSchemaProperty("relationship_pgDocumentToPlatform");
		//DSM (DS) 2018x.1.1 - PDT Requirement 25900 - Change field Product Category Platform Mandatory for Pilot and Production Phase - END
		//DSM(DS) 2018x.2 - Change for FSD_GHS Req 28370, 28371 - GHS-COPY / CLONE OF A PRODUCT PART(APP,DPP,FOP) SHALL RETAIN THE GHS FROM ITS ORIGINAL PART - START
		public static final String REL_PG_GLOBAL_HARMONIZED_STANDARD = PropertyUtil.getSchemaProperty("relationship_pgGlobalHarmonizedStandard");
		public static final String REL_COPY_LIST_COUNTRY  = PropertyUtil.getSchemaProperty("relationship_CopyListCountry");
		//DSM(DS) 2018x.2 - Change for FSD_GHS Req 28370, 28371 - GHS-COPY / CLONE OF A PRODUCT PART(APP,DPP,FOP) SHALL RETAIN THE GHS FROM ITS ORIGINAL PART - END	
		
		// Policy Definition
		public static final String POLICY_PG_AFFECTEDFPPLIST= PropertyUtil.getSchemaProperty("policy_pgDSOAffectedFPPList");
		public static final String POLICY_IPM_SPECIFICATION = PropertyUtil.getSchemaProperty("policy_IPMSpecification");
		public static final String POLICY_PG_CONSOLIDATEDWEIGHT= PropertyUtil.getSchemaProperty("policy_pgConsolidatedWeight");
		public static final String POLICY_PG_PDPWEIGHT= PropertyUtil.getSchemaProperty("policy_pgProductDataPartWeight");
		public static final String POLICY_PG_CONSOLIDATEDWEIGHTEXPERIMENTAL= PropertyUtil.getSchemaProperty("policy_pgConsolidatedWeightExperimental");
		public static final String POLICY_EXPERIMENTAL_PRODUCTDATA= PropertyUtil.getSchemaProperty("policy_ExperimentalProductData");
		public static final String POLICY_TEMPLATE= PropertyUtil.getSchemaProperty("policy_Template");
		public static final String POLICY_EXPERIMENTAL_PRODUCT_DATA = PropertyUtil.getSchemaProperty("policy_ExperimentalProductData");
		public static final String POLICY_PILOT_PRODUCT_DATA = PropertyUtil.getSchemaProperty("policy_PilotProductData");
		public static final String POLICY_INTERNAL_MATERIAL = PropertyUtil.getSchemaProperty("policy_InternalMaterial");
		public static final String POLICY_PRODUCT_DATA_TEMPLATE = PropertyUtil.getSchemaProperty("policy_ProductDataTemplate");
		public static final String POLICY_IPM_PART = PropertyUtil.getSchemaProperty("policy_IPMPart");
		public static final String POLICY_PRODUCTION_PRODUCT_DATA = PropertyUtil.getSchemaProperty("policy_IPMPart");
		public static final String POLICY_SUPPLIER_EQUIVALENT = PropertyUtil.getSchemaProperty("policy_SupplierEquivalent");
		public static final String POLICY_ARTIOSCAD_VERSION_DESIGN = PropertyUtil.getSchemaProperty("policy_ArtiosCADVersionedDesign");
		//DSM (DS) 2015x.2 - After promting VI to Review the promotion button disappears - START
		public static final String POLICY_VIRTUAL_INTERMEDIATE = PropertyUtil.getSchemaProperty("policy_VirtualIntermediate");
		//DSM (DS) 2015x.2 - After promting VI to Review the promotion button disappears - END
		//DSM(DS)2015x.2 - Added constants for Formulation Policy - Start

		public static final String POLICY_PRODUCTION_FORMULATION = PropertyUtil.getSchemaProperty("policy_ProductionFormulation");
		public static final String POLICY_PILOT_FORMULATION = PropertyUtil.getSchemaProperty("policy_PilotFormulation");
		//DSM 2015x.2 - To configure Change Management for Formulation Types - START
		public static final String POLICY_PRODUCTION_FORMULATION_PART = PropertyUtil.getSchemaProperty("policy_IPMRestrictedPart");
		public static final String POLICY_EXPERIMENTAL_FORMULATION = PropertyUtil.getSchemaProperty("policy_ExperimentalFormulation");
		public static final String POLICY_EXPERIMENTAL_FORMULATION_PART = PropertyUtil.getSchemaProperty("policy_ExperimentalFormulationPart");
		public static final String POLICY_EXPERIMENTAL_FORMULATION_PROCESS = PropertyUtil.getSchemaProperty("policy_ExperimentalFormulationProcess");
		public static final String POLICY_HYPOTHETICAL_PRIVATE_FORMILATION = PropertyUtil.getSchemaProperty("policy_HypotheticalPrivateFormulation");
		public static final String POLICY_HYPOTHETICAL_PRIVATE_FORMILATION_PART = PropertyUtil.getSchemaProperty("policy_HypotheticalPrivateFormulationPart");
		public static final String POLICY_HYPOTHETICAL_PRIVATE_FORMILATION_PROCESS = PropertyUtil.getSchemaProperty("policy_HypotheticalPrivateFormulationProcess");
		
		public static final String POLICY_HYPOTHETICAL_PUBLIC_FORMILATION = PropertyUtil.getSchemaProperty("policy_HypotheticalPublicFormulation");
		public static final String POLICY_HYPOTHETICAL_PUBLIC_FORMILATION_PART = PropertyUtil.getSchemaProperty("policy_HypotheticalPublicFormulationPart");
		public static final String POLICY_HYPOTHETICAL_PUBLIC_FORMILATION_PROCESS = PropertyUtil.getSchemaProperty("policy_HypotheticalPublicFormulationProcess");
		//DSM 2015x.2 - To configure Change Management for Formulation Types - END
		public static final String POLICY_PILOT_FORMULATION_PART = PropertyUtil.getSchemaProperty("policy_PilotFormulationPart");
		public static final String POLICY_PRODUCTION_FORMULATION_PROCESS = PropertyUtil.getSchemaProperty("policy_ProductionFormulationProcess");
		public static final String POLICY_PILOT_FORMULATION_PROCESS = PropertyUtil.getSchemaProperty("policy_PilotFormulationProcess");
			
		//DSM(DS)2015x.2 - Added constants for Formulation Policy - End
		//SJV4-Added for SmartScope development :: START
		public static final String RELATIONSHIP_PGPRODUCTPLATFORMMATERIAL = PropertyUtil.getSchemaProperty("relationship_pgProductPlatformRawMaterial");
		//SJV4-Added for SmartScope development :: END
		// State Defination
		public static final String STATE_IPM_PART_OBSOLETE = PropertyUtil.getSchemaProperty("policy", POLICY_IPM_PART, "state_Obsolete");
		public static final String STATE_INTERNAL_MATERIAL_DEVELOPMENT = PropertyUtil.getSchemaProperty("policy", POLICY_INTERNAL_MATERIAL, "state_Development");    
		public static final String STATE_PRODUCT_DATA_TEMPLATE_RELEASED = PropertyUtil.getSchemaProperty("policy", POLICY_PRODUCT_DATA_TEMPLATE, "state_Release");
		public static final String STATE_PRODUCT_DATA_TEMPLATE_PRELIMINARY = PropertyUtil.getSchemaProperty("policy", POLICY_PRODUCT_DATA_TEMPLATE, "state_Preliminary");
		
		// Vaults Definition
		public static final String VAULT_ADMINISTRATION = PropertyUtil.getSchemaProperty("vault_eServiceAdministration");
		public static final String VAULT_PRODUCTION = PropertyUtil.getSchemaProperty("vault_eServiceProduction");
		
		//Roles Definition
		public static final String ROLE_GSO = PropertyUtil.getSchemaProperty("role_pgStandardsOffice");
		public static final String ROLE_PRODUCTDATAUSER = PropertyUtil.getSchemaProperty("role_IPMUser");
		public static final String ROLE_SENIORMANUFACTURINGENGINEER = PropertyUtil.getSchemaProperty("role_SeniorManufacturingEngineer");
		public static final String ROLE_PRODUCTDATAORIGINATOR = PropertyUtil.getSchemaProperty("role_IPMOriginator");
		public static final String ROLE_MANUFACTURINGENGINEER = PropertyUtil.getSchemaProperty("role_ManufacturingEngineer");
		public static final String ROLE_ARTIOSCAD_USER = PropertyUtil.getSchemaProperty("role_ArtiosCADUser");
		public static final String ROLE_LIBRARIAN = PropertyUtil.getSchemaProperty("role_Librarian");
		public static final String ROLE_RESTRICTED_MATERIALS_MANAGER = PropertyUtil.getSchemaProperty("role_RestrictedMaterialsManager");
		public static final String ROLE_APPROVAL_TEMPLATE_MANAGER = PropertyUtil.getSchemaProperty("role_pgApprovalTemplateManager");
		public static final String ROLE_SENIOR_COMPLIANCE_ENGINEER = PropertyUtil.getSchemaProperty("role_SeniorComplianceEngineer");
		
		//DSM(DS) 2015x.2 - Modified to consolidate roles to RPDU and RPDO - Start	
		public static final String ROLE_RESTRICTEDPRODUCTDATAUSER = PropertyUtil.getSchemaProperty("role_IPMRestrictedUser");
		public static final String ROLE_RESTRICTEDPRODUCTDATAORIGINATOR = PropertyUtil.getSchemaProperty("role_IPMRestrictedOriginator");	
		//DSM(DS) 2015x.2 - Modified to consolidate roles to RPDU and RPDO - End
		// Other Strings
		public static final String PATH_EDIT_IMAGE = "../common/images/page_white_edit.png"; 
		public static final String PERSON_AGENT = PropertyUtil.getSchemaProperty("person_UserAgent");
		public static final String OBJECTLIST = "objectList";
		public static final String TABLE_OBJECTLIST = "ObjectList";
		public static final String STRING_OBJECTID = "objectId";
		public static final String STRING_REQUESTMAP = "requestMap";
		public static final String STRING_PARAMMAP = "paramMap";
		public static final String STRING_COLUMNMAP = "columnMap";
		public static final String STRING_FIELDMAP = "fieldMap";
		public static final String STRING_RELID = "relId";
		public static final String STRING_SMALL_SETTINGS = "settings";
		public static final String STRING_GROUP_HEADER = "Group Header";
		public static final String STRING_HEADER_MASTER = "Master";
		public static final String STRING_ACCESS_MODIFY = "modify";
		public static final String STRING_PARENTOID = "parentOID";
		public static final String STRING_OLD_OID = "Old OID";
		public static final String STRING_ROOT_NODE = "Root Node";
		public static final String STRING_TABLEDATA = "tableData";
		public static final String STRING_NEWOID = "New OID";
		public static final String STRING_NEWVALUE = "New Value";
		public static final String STRING_CPNFIELDTYPE_SETTING = "CPNFieldType";
		public static final String STRING_ISROOTNODE = "strIsRootNode";
		public static final String PARAM_LIST = "paramList";
		public static final String NEWLINE = "\n";
		public static final String HTML_NEWLINE = "<br>";
		public static final String HTML_DOUBLE_NEWLINE = "<br><br>";
		public static final String HTML_DOUBLE_NEWLINE_SMALL = "<br><br>";
		public static final String HTML_DOUBLE_NEWLINE_CAPS = "<BR><BR>";
		public static final String ALL_SMALL_YES = "yes";
		public static final String INIT_CAPS_NO = "No";
		public static final String INIT_CAPS_YES = "Yes";
		public static final String ALL_SMALL_NO = "no";
		public static final String RANGE_VALUE_TRUE = "TRUE";
		public static final String RANGE_VALUE_FALSE = "FALSE";
		public static final String RANGE_VALUE_THOUSAND = "1000";
		public static final String RANGE_VALUE_SMALL_TRUE = "true";
		public static final String RANGE_VALUE_SMALL_FALSE = "false";
		public static final String ORIGINATINGSOURCE_DSO = "DSO";
		public static final String ORIGINATINGSOURCE_ENGINUITY = "Enginuity";
		public static final String CONSTANT_STRING_CUSTOMERUNIT = "Customer Unit Part";
		public static final String CONSTANT_STRING_MASTERCUSTOMERUNIT = "Master Customer Unit Part";
		public static final String CONSTANT_STRING_HYPHEN = "-";
		public static final String CONSTANT_STRING_COMMA = ",";
		public static final String CONSTANT_STRING_EMPTY = "";
		public static final String CONSTANT_STRING_ARD = "ard";
		public static final String CONSTANT_STRING_FIRSTREVISION = "1";
		public static final String CONSTANT_STRING_FPCCODE = "FPCCode";
		public static final String CONSTANT_STRING_Y = "Y";
		public static final String CONSTANT_STRING_NOTDEFINED = "-Not Defined-";
		public static final String CONSTANT_STRING_STRUCTUREFAIL = "StructureFail";
		public static final String CONSTANT_STRING_PIPE = "|";
		public static final String CONSTANT_STRING_FERT_MATERIALTYPE = "FERT";
		public static final String STRING_CONSUMERUNIT = "ConsumerUnit";
		public static final String STRING_CUSTOMERUNIT = "CustomerUnit";
		public static final String STRING_INNERPACK = "InnerPack";
		public static final String STRING_PALLETTYPE = "PalletType";
		public static final String CONSTANT_STRING_DOC = "DOC";
		public static final String CONSTANT_STRING_NOTAPPLICABLE = "N/A";
		public static final String SELECT_LAST_REVISION = "last.revision";
		public static final String ROUTE_STATUS_STARTED = "Started";
		public static final String ROUTE_STATUS_FINISHED = "Finished";
		public static final String ROUTE_STATUS_STOPPED = "Stopped";
		public static final String ROUTE_STATUS_NOTSTARTED = "Not Started";
		public static final String ROUTE_BASE_PURPOSE_APPROVAL = "Approval";
		public static final String ORIGINATING_SOURCE_DSO = "DSO";
		public static final String CONSTANT_STRING_ROH = "ROH";
		public static final String CONSTANT_STRING_UNBW = "UNBW";
		public static final String CONSTANT_STRING_HALB = "HALB";
		public static final String MFD_STATUS_EXPERIMENTAL = "EXPERIMENTAL";
		public static final String MFD_STATUS_PLANNING = "PLANNING";
		public static final String MFD_STATUS_PILOT = "PILOT";
		public static final String MFD_STATUS_PRODUCTION = "PRODUCTION";
		public static final String CUSTOMER_UNIT_OVERHANG_MAX_DEPTH  = "1397"; //Customer Unit Overhang Depth must be defined (55 inches or 1397 mm)
		public static final String CUSTOMER_UNIT_OVERHANG_MAX_WIDTH  = "1270"; //Customer Unit Overhang Max Width (50 inches or 1270 mm)
		//DSM (DS) 2015x.2.1 CalculationsandRollups : ALM_11902 - STARTS
		//DSM (DS) 2015x.5 ALM 16242 - The TUP Max Tolerance Parameter increased to 1000 mm. - STARTS
		public static final String TUP_HEIGHT_MIN_TOLERANCE = "1000"; //Treat it as milliMeter
		//DSM (DS) 2015x.5 ALM 16242 - The TUP Max Tolerance Parameter increased to 1000 mm. - ENDS
		//DSM (DS) 2015x.2.1 CalculationsandRollups : ALM_11902 - ENDS
		public static final String TUP_HEIGHT_MIN_TOLERANCE_UOM = "millimeter"; //Treat it as milliMeter
		//DSM (DS) 2015x.2  ALM-11063 Transportation Unit Height Validation - Maximum fails -STARTS
		//DSM (DS) 2015x.2.1 CalculationsandRollups : ALM_11902 - STARTS
		public static final String TUP_HEIGHT_MAX_TOLERANCE = "500"; //Treat it as milliMeter
		//DSM (DS) 2015x.2.1 CalculationsandRollups : ALM_11902 - ENDS
		//DSM (DS) 2015x.2  ALM-11063 Transportation Unit Height Validation - Maximum fails -ENDS
		public static final String TUP_HEIGHT_MAX_TOLERANCE_UOM = "millimeter"; //Treat it as milliMeter
		public static final String PALLET_WEIGHT = "100"; //Treat it as milliMeter
		public static final String PALLET_WEIGHT_UOM = "Kilogram"; //Treat it as milliMeter
		public static final String TUP_MIN_TOLERANCE = "4"; //Treat it as Kg
		public static final String TUP_MIN_TOLERANCE_UOM = "Kilogram"; //Treat it as Kg
		public static final String NON_U1_TUP_MAX_TOLERANCE = "11"; //Kg
		public static final String NON_U1_TUP_MAX_TOLERANCE_UOM = "Kilogram"; //Kg
		public static final String PG_LAYERS_PER_TUP_UOM = "Centimeter"; //Kg
		public static final String PG_OVERHANG_MAX_DEPTH_UOM = "millimeter"; //Kg
		public static final String PG_OVERHANG_MAX_WIDTH_UOM = "millimeter"; //Kg
		public static final String PG_OVERHANG_U1_MAX_WIDTH = "1270"; //mm
		public static final String PG_OVERHANG_U1_MAX_DEPTH = "1473.2"; //mm
		public static final String U1_TUP_MAX_TOLERANCE = "8.72"; //Kg
		public static final String CASE_MAX_TOLERANCE = "3.632"; //Kg
		public static final String CASE_MAX_TOLERANCE_UOM = "Kilogram"; //Treat it as Kg
		public static final boolean enableWND = true;
		public static final String CONSTANT_TOPS_TRANSPORTUNIT = "Transport Unit";
		public static final String CONSTANT_TOPS_MASTER_CUSTOMERUNIT = "Master Customer Unit";
		public static final String CONSTANT_TOPS_MASTER_INTERMEDIATEUNIT = "Master Intermediate Unit";
		public static final String CONSTANT_TOPS_MASTER_CONSUMERUNIT = "Master Consumer Unit";
		public static final String CONSTANT_TOPS_CUSTOMERUNIT = "Customer Unit";
		public static final String CONSTANT_TOPS_CONSUMERUNIT = "Consumer Unit";
		public static final String CONSTANT_TOPS_INTERMEDIATEUNIT = "Intermediate Unit";
		public static final String CONSTANT_STRING_NOT_APPLICABLE = "Not Applicable";
		public static final String RENDITION = "Rendition";
		public static final String CONSTANT_TOPS_SHIPPER = "Shipper";
		public static final String CONSTANT_WD_FPP = "FPP";
		public static final String CONSTANT_WD_WT = "WT";
		public static final String SYM_ATTR_PG_LOWERROUTINE_RELEASELIMIT = "attribute_pgLowerRoutineReleaseLimit";
		public static final String SYM_ATTR_PG_UPPERROUTINE_RELEASELIMIT = "attribute_pgUpperRoutineReleaseLimit";
		public static final String UNIT_OF_MEASURE = "Unit of Measure";
		public static final String SYM_STATE_PRELIMINARY = "state_Preliminary";
		public static final String SYM_STATE_LOCKED = "state_Locked";
		public static final String SYM_STATE_RELEASE = "state_Release";
		public static final String SYM_STATE_COMPLETE = "state_Complete";
		public static final String REFERENCE_DESIGNATOR = "Reference Designator";
		public static final String PG_BASEUOM_PICKLIST = "pgBaseUnitOfMeasurePickList";
		public static final String PG_BASEUOM = "pgBaseUnitOfMeasure";
		public static final String PG_ORIGINATINGSOURCE = "pgOriginatingSource";
		public static final String STRING_NEW = "New";
		public static final String RANGE_VALUE_MANUAL = "Manual";
		public static final String RANGE_VALUE_SYSTEM_GENERATED = "System Generated";
		public static final String STR_CURRENT = "Current";
		public static final String STR_NOTCURRENT = "Not Current";
		public static final String STR_PL_TRADER = "Trader";
		public static final String STR_PL_DISTRIBUTOR = "Distributor";
		public static final String STR_LOCAL = "Local";
		public static final String STR_REFERENCED = "Referenced";
		public static final String CLASSIFICATION_RANGE_EPADEX ="ePADEx";
		public static final String CLASSIFICATION_RANGE_INTEGRATION = "Integration";
		public static final String CLASSIFICATION_RANGE_ISSUANCE = "Issuance";
		public static final String CLASSIFICATION_RANGE_MATERIAL_ACIVATION = "Material Activation";
		public static final String CLASSIFICATION_RANGE_RENDITION = "Rendition";
		//DSM(DS) - Fix for ALM 20777 - Unable to Promote CA to In Approval State - START
		public static final String STATE_SHARED	= "RELEASED";
		//DSM(DS) - Fix for ALM 20777 - Unable to Promote CA to In Approval State - END
		public static final String STATE_PRIVATE = "PRIVATE";
		public static final String STATE_IN_WORK = "IN_WORK";
		//DSM(DS) - Fix for ALM 20777 - Unable to Promote CA to In Approval State - START
		public static final String STATE_WAITAPP = "FROZEN";
		//DSM(DS) - Fix for ALM 20777 - Unable to Promote CA to In Approval State - END
		public static final String CONSTANT_RESTRICTED = "Restricted";
		public static final String CONSTANT_HIGHLY_RESTRICTED = "Highly Restricted";
		public static final String CONSTANT_INTERNAL_USE = "Internal Use";
		public static final String CONSTANT_R = "R";
		public static final String CONSTANT_HiR = "HiR";
		public static final String CONSTANT_IU = "IU";
		public static final String CONSTANT_SYSTEM = "System";
		public static final String CONSTANT_FINISHED_PRODUCT = "Finished Product";
		public static final String PERSON_USER_AGENT = PropertyUtil.getSchemaProperty("person_UserAgent");
		public static final String RANGE_VALUE_VARIABLE = "VARIABLE";
		public static final String RANGE_VALUE_ATTRIBUTE = "ATTRIBUTE";
		public static final String RANGE_VALUE_REPORT = "REPORT";
		public static final String RANGE_VALUE_SUMMARY = "SUMMARY";
		public static final String SYMB_M = "M";
		public static final String SYMB_ATTR_PG_ERROR_CLASSIFICATION = "attribute_pgErrorClassification";
		public static final String RANGE_VALUE_TMLOGIC_ANY = "ANY";
		public static final String RANGE_VALUE_TMLOGIC_ALL = "ALL";
		public static final String CONSTANT_STRING_REBLEND= "Reblend";
		public static final String CONSTANT_STRING_MATERIAL_PRODUCED= "Material Produced";
		public static final String BLANK_SPACE = " ";
		public static final String CONSTANT_ASSIGNED_MASTER = "assignedMaster";
		public static final String CONSTANT_UNASSIGNED_MASTER = "unassignedMaster";
		public static final String CONSTANT_REMOVED_MASTER = "removeMaster";
		public static final String CONSTANT_RELEASED_MASTER = "releasedMaster";
		//DSM (DS) 2015x.5 - ALM : 16345 - System is not updating inheritance when upper level Master is obsoleted - Start
		public static final String CONSTANT_OBSOLETE_MASTER = "obsoleteMaster";
		//DSM (DS) 2015x.5 - ALM : 16345 - System is not updating inheritance when upper level Master is obsoleted - end
		public static final String CONSTANT_SUCCEEDED = "Succeeded";
		
		//Dimension Constants
		public static final String UoM_MILLIMETER = "Millimeter";
		public static final String UoM_CENTIMETER = "Centimeter";
		public static final String UoM_MILLIMETERS = "Millimeters";
		public static final String UoM_Inches = "Inches";
		public static final String UoM_Inch = "Inch";
		public static final String UoM_METER = "Meter";
		public static final String UoM_mm = "mm";
		public static final String UoM_in = "in";
		public static final String UoM_cm = "cm";
		public static final String UoM_m = "m";
		
		//Weight Constants
		public static final String UoM_GRAM = "Gram";
		public static final String UoM_g = "g";
		public static final String UoM_KILOGRAM = "Kilogram";
		public static final String UoM_KG = "kg";
		public static final String UoM_POUND = "Pound";
		public static final String UoM_POUND_US = "Pound(US)";
		public static final String UoM_lb = "lb";
		public static final String UoM_FEET = "Feet";  
		public static final String UoM_ft = "ft";
		
		//GCAS NAME Prefix
		public static final String pgGCASMagazineObject = "pgGCASMagazineObject";
		public static final String CONSTANT_NUMBEROFGCASCODE = "50";
		public static final String GMDB_type_PackagingMaterialPart = "PACK MATERIAL PART-PLM GCAS DEFAULT";
		public static final String GMDB_type_FinishedProductPart = "PACKED FORMULA";
		public static final String GMDB_type_pgPromotionalItemPart = "PACKAGING - DISPLAY";
		public static final String GMDB_type_PackagingAssemblyPart = "PACKAGE INTERMEDIATE";
		public static final String CONSTANT_MATERIAL_GROUP_MAPPING = "type_FinishedProductPart|PACKED FORMULA,type_PackagingAssemblyPart|PACKAGE INTERMEDIATE,type_PackagingMaterialPart|PACK MATERIAL PART-PLM GCAS DEFAULT,type_pgPromotionalItemPart|PACKAGING - DISPLAY";
		public static final String Policy_Experimental_ProductData_MAPPING = "policy_ExperimentalProductData";
		public static final String Policy_Pilot_ProductData_MAPPING = "policy_ExperimentalProductData|policy_PilotProductData";
		// DSM (DS) 2015x.2 : Added Mapping for New Types
		// DSM (DS) 2015x.4 : FSD_Part_Family_Structure - STARTS
		// DSM DS - 2018x Upgrade - replaced RMP with Raw Material type - START
		public static final String CONSTANT_PARTMASTER_MAPPING = "type_pgCustomerUnitPart|type_pgMasterCustomerUnitPart,type_pgConsumerUnitPart|type_pgMasterConsumerUnitPart,type_pgIPart|type_pgMasterConsumerUnitPart,type_pgInnerPackUnitPart|type_pgMasterInnerPackUnitPart,type_PackagingAssemblyPart|type_pgMasterPackagingAssemblyPart,type_PackagingMaterialPart|type_pgMasterPackagingMaterialPart,type_pgAncillaryPackagingMaterialPart|type_pgMasterPackagingMaterialPart,type_pgOnlinePrintingPart|type_pgMasterPackagingMaterialPart,type_pgFabricatedPart|type_pgMasterPackagingMaterialPart,type_pgDeviceProductPart|type_pgMasterProductPart,type_FormulationPart|type_pgMasterProductPart,type_pgAssembledProductPart|type_pgMasterProductPart,type_pgFabricatedPart|type_pgMasterRawMaterialPart,type_RawMaterial|type_pgMasterRawMaterialPart,type_pgRawMaterial|type_pgMasterRawMaterialPart,type_pgAncillaryRawMaterialPart|type_pgMasterRawMaterialPart,type_pgIntermediateProductPart|type_pgMasterProductPart";
		// DSM DS - 2018x Upgrade - replaced RMP with Raw Material type - END
		// DSM (DS) 2015x.4 : FSD_Part_Family_Structure - ENDS
		public static final String ATTR_REQUESTEDCHG_OBSOLESCENCE_VALUE = "For Obsolescence";
		public static final String ATTR_REQUESTEDCHG_REVISE_VALUE = "For Revise";
		public static final String REF_TYPE_M = "M";
		public static final String REF_TYPE_R = "R";
		//DSM(DS) 2015x.4 Dec Downtime ALM 14794 [INC0519246] - start
		public static final String REF_TYPE_U = "U";
		//DSM(DS) 2015x.4 Dec Downtime ALM 14794 [INC0519246] - end
		public static final String ProductData_SETCOS_AllowedTypes = "type_FinishedProductPart,type_PackagingAssemblyPart" ;
		public static final String STATE_CA_INWORK = "In Work";
		//DSM(DS) 2018x: CA State changes -  START 
		//public static final String STATE_CA_PENDING = "Pending";
		//DSM(DS) 2018x: CA State changes -  END 
		public static final String STATE_IN_APPROVAL = "In Approval";
		public static final String APPROVAL = "Approval";
		public static final String SIGNATURE = "Signature";
		public static final String APPROVE = "approve";
		public static final String REJECT = "reject";
		public static final String STRING_RESHIPPER = "Reshipper";
		public static final String FOR_RELEASE = "For Release";
		public static final String FOR_OBSOLESCENCE = "For Obsolescence";
		public static final String ATTR_EMPLOYEETYPE_INTERNALPG = "Employee";
		public static final String ATTR_EMPLOYEETYPE_EBP = "EBP";
		public static final String ATTR_EMPLOYEETYPE_AUGSTAFF = "Non-Emp";
		public static final String COMPANY_PG = "PG";
		public static final String TRIGGER_TYPE = "eService Trigger Program Parameters";
		public static final String EBOM_CHECK_REL_TRIGGER_NAME = "RelationshipEBOMCreateCheck";
		public static final String EBOM_CHECK_REL_TRIGGER_REV = "checkDSOBOMRules";
		public static final String TRIGGER_ARG_9 = "eService Program Argument 9";
		public static final String STR_EBOMMARKUP = "EBOMMARKUP";
		public static final String SECURITYCLASS_LIST = "type_SecurityControlClass,type_IPControlClass,type_ExportControlClass";
		//DSM 2015x.1 Global Actions Markup - END
		
		public static final String STR_CURRENT_VIEW = "CurrentView";
		public static final String EBOM_WITH_SUBSTITUTES = "EBOM with Substitutes";
		public static final String REQUESTED_CHANGE_NONE = "None";
		public static final String STANDARD = "Standard";
		public static final String DSM_SUPPLIERMANUFACTURER = "DSM-SupplierManufacturer";
		public static final String DSM_SUPPLIERTRADERDISTRIBUTOR = "DSM-SupplierTraderDistributor";
		public static final String EVENT_DEMOTE = "Demote";
		public static final String CONSTANT_TYPE_MATERIAL="type_Material";
		
		//Added for 2015x.2(DS) for connecting ACS to FTS - Starts
		public static final String TYPE_PG_AUTHORIZED_CONFIGURATION_STANDARD = PropertyUtil.getSchemaProperty("type_pgAuthorizedConfigurationStandard");
		public static final String TYPE_INTERMEDIATE_ASSEMBLED_PRODUCT_SEPCIFICATION = PropertyUtil.getSchemaProperty("type_FormulaTechnicalSpecification");
		public static final String TYPE_PG_RAWMATERIAL = PropertyUtil.getSchemaProperty("type_pgRawMaterial");
		//public static final String REL_PG_RELATED_ACS = PropertyUtil.getSchemaProperty("relationship_pgRelatedACS");
		public static final String REL_PG_RELATED_ACS = PropertyUtil.getSchemaProperty("relationship_pgAuthorizedConfigurationStandard");
		public static final String REL_PG_DEFINES_MATERIAL = PropertyUtil.getSchemaProperty("relationship_pgDefinesMaterial");
		public static final String REL_PLANNED_FOR = PropertyUtil.getSchemaProperty("relationship_PlannedFor");
		public static final String REL_ASSOCIATED_PLANTS = PropertyUtil.getSchemaProperty("relationship_AssociatedPlants");	
		public static final String TYPE_PG_ANCILLARY_RAW_MATERIAL_PART = PropertyUtil.getSchemaProperty("type_pgAncillaryRawMaterialPart");
		public static final String TYPE_PG_PROCESSSTANDARD = PropertyUtil.getSchemaProperty("type_pgProcessStandard");
		//Added for 2015x.2(DS) for connecting ACS to FTS - Ends

		//DSM (DS) 2015x.2 - Updated code for Material Composition - STARTS
		public static final String ATTRIBUTE_INTERNAL_MATERIAL_FOR = PropertyUtil.getSchemaProperty("attribute_pgInternalMaterialFor");
		public static final String REL_STARTING_MATERIAL = PropertyUtil.getSchemaProperty("relationship_pgStartingMaterial");
		public static final String TYPE_EXTERNAL_MATERIAL = PropertyUtil.getSchemaProperty("type_ExternalMaterial");
		public static final String POLICY_EXTERNAL_MATERIAL = PropertyUtil.getSchemaProperty("policy_ExternalMaterial");
		public static final String CONSTANT_PRODUCT = "Product";
		public static final String CONSTANT_PACKAGING = "Packaging";
		public static final String CONSTANT_INTERNALMATERIALFOR = "InternalMaterialFor";
		public static final String CONSTANT_RELNAME = "relName";
		public static final String CONSTANT_MCP_PREFIX = "MCP-";
		public static final String CONSTANT_IMP_PREFIX = "IMP-";
		public static final String CONSTANT_MATERIAL_REV = "A";
		public static final String TYPE_ESERVICE_NUMBER_GENERATOR = PropertyUtil.getSchemaProperty( "type_eServiceNumberGenerator");
		public static final String ATTRIBUTE_ESERVICE_NEXT_NUMBER = PropertyUtil.getSchemaProperty("attribute_eServiceNextNumber");
		//DSM (DS) 2015x.2 - Updated code for Material Composition - ENDS

		//DSM (DS) 2015x.2 - Added for W&D Validations - STARTS
		public static final String TYPE_DEVICE_PRODUCT_PART = PropertyUtil.getSchemaProperty("type_pgDeviceProductPart");
		public static final String TYPE_ASSEMBLED_PRODUCT_PART = PropertyUtil.getSchemaProperty("type_pgAssembledProductPart");
		//DSM (DS) 2015x.2 - Added for W&D Validations - ENDS

		//DSM (DS) 2015x1.2 - ALM#7002: MEP policy declaration - START
		public static final String POLICY_MANUFACTURER_EQUIVALENT = PropertyUtil.getSchemaProperty("policy_ManufacturerEquivalent");
		//DSM (DS) 2015x1.2 - ALM#7002: MEP policy declaration - End
		//DSM (DS) 2015x.2 - Added for Formulation - START
		public static final String STRING_FORMULATION_PART_TEMPLATE = "Formulation Part Template";
		public static final String ATTRIBUTE_FORMULATION_TYPE = PropertyUtil.getSchemaProperty("attribute_FormulationType");
		//DSM (DS) 2015x.2 - Added for Formulation - END
		//DSM (DS) 2015x.2 - Added for Divestiture Security - STARTS
		public static final String ATTRIBUTE_PG_DIVESTITURE = PropertyUtil.getSchemaProperty("attribute_pgDivestiture");
		public static final String COLL_SPACE_DIVESTITURE_PG = "Divestiture_PG";
		//DSM (DS) 2015x.2 - Added for Divestiture Security - ENDS
		//DSM (DS) 2015x.2 - Updated for PLBOM Substitute relationship - START
		public static final String RELATIONSHIP_PLBOM_SUBSTITUTE = PropertyUtil.getSchemaProperty("relationship_FBOMSubstitute");
		//DSM (DS) 2015x.2 - Updated for PLBOM Substitute relationship - END
		//DSM (DS) 2015X.1.2 - ALM# 7166: The new/modified value of Net Weight of COP should be sent to SAP when new rev of COP is connected to the EBOM of a FPP. -START
		public static final String CONST_TYPE_PACKAGING_ASSEMBLY_PART = "type_PackagingAssemblyPart";
		public static final String CONST_TYPE_CONSUMER_UNI_PART = "type_pgConsumerUnitPart";
		public static final String CONST_TYPE_FABRICATED_PART = "type_pgFabricatedPart";
		//DSM (DS) 2015X.1.2 - ALM# 7166: The new/modified value of Net Weight of COP should be sent to SAP when new rev of COP is connected to the EBOM of a FPP. -START
		
		//DSM (DS) 2015X.1.2 - ALM# 7992: The added "Add Remove" access originator cannot add existing part to leaf level part family. -START
		public static final String ROLE_PARTFAMILYCOORDINATOR = PropertyUtil.getSchemaProperty("role_PartFamilyCoordinator");
		//DSM (DS) 2015X.1.2 - ALM# 7992: The added "Add Remove" access originator cannot add existing part to leaf level part family. -END
		//DSM (DS) 2015x.2 - Added for Cyclic Altenate connection check - STARTS
		public static final short sPrimaryCheckRecurseLevel = 100;
		//DSM (DS) 2015x.2 - Added for Cyclic Altenate connection check - ENDS
		//DSM (DS) 2015x.1.2  - Column Function for getting Title of the Derived Master -ends
		public static final String STR_PG_VPD_PERFORMANCE_CHARACTERISTIC_TABLE = "pgVPDPerformanceCharacteristicTable";
		//DSM(DS) 2018x.0 - Upgrade enhancement -Move Weight Characteristics attributes to Properties page- start
		public static final String STR_PG_WEIGHT_CHARACTERISTIC_TABLE = "pgWeightCharacteristic";
		public static final String STR_CHARACTERISTIC_TABLE_NAMES = "Characteristic Table Names";
		//DSM(DS) 2018x.0 - Upgrade enhancement -Move Weight Characteristics attributes to Properties page- end
		public static final String STR_PG_VPD_APP_DOCUMENTSUMMARY = "pgVPDAPPDocumentSummary";
		public static final String STR_APP_DOCUMENTSUMMARY = "APPDocumentSummary";
		// Modified 2018x PNGUPGRADE FD02 START
		public static final String STR_ENC_DOCUMENTSUMMARY = "ENCDocumentSummary";
		// Modified 2018x PNGUPGRADE FD02 END
		//DSM (DS) 2015x.1.2  - Column Function for getting Title of the Derived Master -ends
		//DSM (DS) 2015x.1.2 5796 - Final Approvers are having to wait to long after they enter username and password  -start
		public static final String STRING_GLOBAL_SUBSCRIPTION_OBJECT = "Global Subscription Object";
		//DSM (DS) 2015x.1.2 5796 - Final Approvers are having to wait to long after they enter username and password  -ends
		
		
		//DSM (DS) 2015X.1.2 - ALM#7320: W&D Status Attribute on FPP needs to be Maintainable to support SMO Work Process - START
		public static final String STR_PRODUCTION_VERIFIED = "Production Verified";
		//DSM (DS) 2015X.1.2 - ALM#7320: W&D Status Attribute on FPP needs to be Maintainable to support SMO Work Process - END
		//Added by DSM (DS) 2015X.2 - Global Actions ADD -START
		public static final String ATTRIBUTE_PG_MAXIMUM_ACTUAL_PERCENT_WET = PropertyUtil.getSchemaProperty("attribute_pgMaxActualPercenWet");
		public static final String ATTRIBUTE_PG_MINIMUM_ACTUAL_PERCENT_WET = PropertyUtil.getSchemaProperty("attribute_pgMinActualPercenWet");
		public static final String STR_SCHEMA_TYPE = "Type";
		//Added by DSM (DS) 2015X.2 - Global Actions ADD -END
		//Added by DSM (DS) 2015X.2 - Added code for remove PACKAGING value-START
		public static final String CONSTANT_ANALYTICAL = "ANALYTICAL";
		public static final String CONSTANT_QTY = "Quantity";
		public static final String CONSTANT_SUBSTITUTE_FOR = "SubstituteFor";
		public static final String CONSTANT_SUBSTITUTE_PART = "SubstitutePart";
		public static final String CONSTANT_EDIT_PLBOM_SUBS_TABLE = "EditPLBOMSubstitutesTable";
		public static final String CONSTANT_VALID_UNTIL_DATE = "Valid Until Date";
		public static final String CONST_PRIMARY_REPLACEMENT = "Primary Replacement Ingredient";
		public static final String CONST_TRUE = "TRUE";
		public static final String CONST_QTY_ADJUSTMENT = "Quantity Adjustment";
		public static final String CONST_ONE = "1.0";
		public static final String CONST_MIN = "Min";
		public static final String CONST_MAX = "Max";
		//Added by DSM (DS) 2015X.2 - Added code for remove PACKAGING value-END	
		// DSM (DS) 2015x.2 To enable associating R&D Labs to RMPs - START
		public static final String REL_RD_SITE = PropertyUtil.getSchemaProperty("relationship_RDSite");
		// DSM (DS) 2015x.2 To enable associating R&D Labs to RMPs - END
		// Added by DSM (DS) 2015X.2 - :The sum of the Target % Weight of all the Substances within an Internal Material (IMP) needs to add up to 100% - START
		public static final String ATTR_QUANTITY = PropertyUtil.getSchemaProperty ("attribute_Quantity");
		public static final String ATTR_IS_CONTAMINANT = PropertyUtil.getSchemaProperty ("attribute_IsContaminant");
		public static final String TYPE_SUBSTANCE = PropertyUtil.getSchemaProperty("type_Substance");
		// Added by DSM (DS) 2015X.2  :The sum of the Target % Weight of all the Substances within an Internal Material (IMP) needs to add up to 100% - END

		//DSM (DS) 2015x.2 DSM15X2-534 - OOTB Material Function for RMPs-starts
		public static final String TYPE_MATERIAL_FUNCTIONALITY = PropertyUtil.getSchemaProperty("type_MaterialFunctionality");
		//DSM (DS) 2015x.2 DSM15X2-534 - OOTB Material Function for RMPs-ends
		
		//DSM (DS) 2015x.2 ALM 8334 It looks like the general search page is loading forever when click Add Existing Formulation Part command -starts
		public static final String STR_STANDARD_FORMULA = "Standard Formula";
		 //DSM (DS) 2015x.2 ALM 8334 It looks like the general search page is loading forever when click Add Existing Formulation Part command -ends
		 
		 //DSM (DS) 2015x.2 Added two constants to show the values for Alternate column on EBOM page-Start
		public static final String VALUE_TRUE = "True";
		public static final String VALUE_FALSE = "False";
		//DSM (DS) 2015x.2 Added two constants to show the values for Alternate column on EBOM page -End
		public static final String REL_PLBOM = PropertyUtil.getSchemaProperty("relationship_FBOM");
		//DSM (DS) 2015x.2 Added two constants to show the default value for APP,DPP&FOP for Base Quantity -Start
		public static final String CONST_VALUE_HUNDRED = "100";
		public static final String CONST_VALUE_ONE = "1";
		public static final String ATTR_PG_ENTRYBASEQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgEntryBaseQuantity");
		//DSM (DS) 2015x.2 Added two constants to show the default value for APP,DPP&FOP for Base Quantity -End
		//DSM (DS) 2015x.2 -  Manufacturing Status values blank for Hypothetical Stage in Formulation -STRAT
		public static final String HYPOTHETICAL_PRIVATE = "Hypothetical-Private";
		public static final String HYPOTHETICAL_PUBLIC = "Hypothetical-Public";
		//Modified for 2018x Upgrade - Phase Experimental is changed to Development - START. 
		//public static final String EXPERIMENTAL = "Experimental";
		public static final String EXPERIMENTAL = "Development";
		//Modified for 2018x Upgrade - Phase Experimental is changed to Development - END. 
		//DSM (DS) 2015x.2 -  Manufacturing Status values blank for Hypothetical Stage in Formulation -END
		//DSM (DS) 2015x.2 ALM 9656 - Assigning master part of FOP can't be found -starts
		public static final String Policy_Experimental_FormulationPart_MAPPING = "policy_ExperimentalFormulationPart";
		public static final String Policy_Pilot_FormulationPart_MAPPING = "policy_ExperimentalFormulationPart|policy_PilotFormulationPart";
		public static final String Policy_Hypothetical_FormulationPart_MAPPING = "policy_HypotheticalPrivateFormulationPart|policy_HypotheticalPublicFormulationPart";
		//DSM (DS) 2015x.2 ALM 9656 - Assigning master part of FOP can't be found -ends
		
		//DSM (DS) 2015x.2 - Added constant for Weight UoM -Start
		public static final String FORMULATION_WEIGHT_UOM = "Kilogram";
		public static final String CONST_INTERMEDIATE_FORMULATION_TYPE = "Intermediate Formula";
		public static final String CONST_STANDARD_FORMULATION_TYPE = "Standard Formula";
		//DSM (DS) 2015x.2 - Added constant for Weight UoM -End
		//DSM (DS) 2015x.2 - ALM #10762 - Experimental RMPs created from CISPro do not get GCAS on upstage - START
		public static final String PRODUCTION = "Production";
		//DSM (DS) 2015x.2 - ALM #10762 - Experimental RMPs created from CISPro do not get GCAS on upstage - END
		//DSM 2018x Upgrade : Release Phase change -Start
		public static final String PILOT = "Pilot";
		//DSM 2018x Upgrade : Release Phase change -End
		//Added by DSM (DS) 2015x.2 - ALM:10139/10140 : Class and Reported Function Default Setting - Start
		public static final String ATTR_PG_CLASS = PropertyUtil.getSchemaProperty("attribute_pgClass");
		//public static final String CONST_PRODUCT = "Product";
		//public static final String CONST_INTERMEDIATE = "Intermediate";
		public static final String ZZ_USE_ONLY_FOR_PRODUCT_PARTS = "ZZUse Only for Product Parts";
		public static final String REL_PG_PLI_REPORTED_FUNCTION = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgPLIReportedFunction");
		//Added by DSM (DS) 2015x.2 - ALM:10139/10140 : Class and Reported Function Default Setting - End
		//Added by DSM (DS) for 2015x.2 ALM 10816 STARTS - Substitute Wet % is not checked/validated for Fixed VI
		public static final String CONST_NEEDS_UPDATE = "Needs Update";
		public static final String CONST_IS_FIXED_VI = "Is Target Percent As Consumed Fixed";
		//Added by DSM (DS) for 2015x.2 ALM 10816 ENDS
		
		//Added by DSM (DS) for 2015x.2.1 ALM 10239 STARTS
		public static final String CONST_CTX_CATIADESIGNER_PG = "ctx::CATIADesigner.PG.Internal_PG";
		public static final String CONST_ROLE_CATIADESIGNER_PG = "CATIADesigner.PG.Internal_PG";
		public static final String CONST_CTX_RPDO_PG = "ctx::Restricted Product Data Originator.PG.Internal_PG";
		public static final String CONST_ROLE_RPDO_PG = "Restricted Product Data Originator.PG.Internal_PG";
		//Added by DSM (DS) for 2015x.2.1 ALM 10239 ENDS
		
		//DSM (DS) 2015x.4 - Implementing CA Promotion through Background Job - START
		public static final boolean ENABLE_CA_BATCH_PROCESS = true;
		public static final String RELATIONSHIP_PENDING_JOB = PropertyUtil.getSchemaProperty("relationship_PendingJob");
		public static final String STATE_COMPLETED = "Completed";
		public static final String STATE_ARCHIVED = "Archived";
		public static final String STR_COMMON_BATCH_EXCEPTION = "Exception occurred in the method";
		public static final String CONST_PG_CA_BATCH_PROCESS = "pgCABatchProcess";
		public static final String SIGNATURE_SOAPPROVAL = "SOApproval";
		//DSM (DS) 2015x.4 - Implementing CA Promotion through Background Job - START
		public static final String SELECT_PREVIOUS_REVISION_ID					= "previous.id";
		//DSM (DS) 2015x.4 Structure Release Criteria  - starts
		public static final String ATTR_PG_STRUCTURED_RELEASE_CRITERIA_REQUIRED = PropertyUtil.getSchemaProperty ("attribute_pgStructuredReleaseCriteriaRequired");
		public static final String STR_SETTINGS = "SETTINGS";
		public static final String STR_ATTRIBUTENAME = "AttributeName";
		public static final String STR_PG_STRUCTURE_RELEASE_CRITERIA_2 = "pgStructuredReleaseCriteria2";
		public static final String STR_PG_STRUCTURE_RELEASE_CRITERIA = "pgStructuredReleaseCriteria";
		public static final String STR_ATTRIBUTE_CAPABILITY_RELEASE_PLAN = "AttributeCapabilityReleasePlan";
		public static final String STR_ATTRIBUTE_ACCEPTANCE_SAMPLING_PLAN = "AttributeAcceptanceSamplingPlan";
		public static final String STR_ATTRIBUTE_AQL_VALUES = "AttributeAQLValues";
		public static final String STR_VARIABLE_CAPABILITY_RELEASE_PLAN = "VariableCapabilityReleasePlan";
		public static final String STR_VARIABLE_ACCEPTANCE_SAMPLING_PLAN = "VariableAcceptanceSamplingPlan";
		public static final String STR_VARIABLE_AQL_VALUES = "VariableAQLValues";
		//DSM (DS) 2015x.4 Structure Release Criteria  - ends
		//DSM (DS) 2015x.4 - Added for Mass Sync on Leaf Level Masters from CA context through Background Job - START
		public static final String TYPE_PGCONFIGURATIONADMIN =  PropertyUtil.getSchemaProperty("type_pgConfigurationAdmin");
		public static final String CONST_PG_PART_FAMILY_BATCH_PROCESS = "pgPartFamilyBatchProcess";
		public static final String CONST_MASS_SYNC = "MassSync";
		public static final String CONST_ON = "On";
		public static final String CONST_OFF = "Off";
		public static final String ATTRIBUTE_PGCONFIGCOMMONATTR =  PropertyUtil.getSchemaProperty("attribute_pgConfigCommonAttr");
		//DSM (DS) 2015x.4 - Added for Mass Sync on Leaf Level Masters from CA context through Background Job - END
		//DSM(DS)2018x.1.1 - FSD 25339 - Change Management Release Process - CM Sync Master modified to Background Job - END
		public static final String ATTRIBUTE_PGMASSSYNCJOBWAITTIME =  PropertyUtil.getSchemaProperty("attribute_pgMassSyncJobWaitTime");
		//DSM(DS)2018x.1.1 - FSD 25339 - Change Management Release Process - CM Sync Master modified to Background Job - END
		//DSM (DS) 2015x.4 - Change Management Release Process 15X.4_2.0 - START
		public static final String ATTRIBUTE_PARALLELNODEPROCESSIONRULE =  PropertyUtil.getSchemaProperty("attribute_ParallelNodeProcessionRule");
		//DSM (DS) 2015x.4 - Change Management Release Process 15X.4_2.0 - END
		
		//DSM (DS) 2015x.4 : Added for new type Intermediate Product Part - START
		public static final String TYPE_PG_INTERMEDIATE_PRODUCT_PART = PropertyUtil.getSchemaProperty("type_pgIntermediateProductPart");
		//DSM (DS) 2015x.4 : Added for new type Intermediate Product Part - END
		//P&G DSM CONFIGMGMT:Req.Id :14569 - Added for Change Summary functionality - Start
		public static final String TYPE_PG_CHANGE_SUMMARY	= PropertyUtil.getSchemaProperty("type_pgChangeSummary");
		public static final String POLICY_PG_CHANGE_SUMMARY	= PropertyUtil.getSchemaProperty("policy_pgChangeSummary");
		public static final String STATE_PG_CHANGE_SUMMARY_PRELIMINARY = PropertyUtil.getSchemaProperty("policy", POLICY_PG_CHANGE_SUMMARY, "state_Preliminary");
		public static final String STATE_PG_CHANGE_SUMMARY_ACTIVE = PropertyUtil.getSchemaProperty("policy", POLICY_PG_CHANGE_SUMMARY, "state_Active");
		public static final String STATE_PG_CHANGE_SUMMARY_OBSOLETE = PropertyUtil.getSchemaProperty("policy", POLICY_PG_CHANGE_SUMMARY, "state_Obsolete");
		//P&G DSM CONFIGMGMT:Req.Id :14569 - Added for Change Summary functionality - End
		
		//DSM (DS) 2015x.4 : Added for new type Raw Material Plant Instruction - START
		public static final String TYPE_PG_RAW_MATERIAL_PLANT_INSTRUCTION = PropertyUtil.getSchemaProperty("type_pgRawMaterialPlantInstruction");
		//DSM (DS) 2015x.4 : Added for new type Raw Material Plant Instruction - END
		//DSM (DS) 2015x.4 : Added for Qualification - START
		public static final String TYPE_QUALIFICATION = PropertyUtil.getSchemaProperty("type_Qualification");
		public static final String POLICY_QUALIFICATION = PropertyUtil.getSchemaProperty("policy_Qualification");
		public static final String STATE_FROZEN = "Frozen";
		public static final String STATE_QUALIFIED = "Qualified";
		public static final String SELECT_PREVIOUS_CURRENT = "previous.current";
		//DSM (DS) 2015x.4 : Added for Qualification - END
		// DSM (DS) 2015x.4 - Changes for PQR revise - START
		public static final String MEP_PQR_TREEMENU = "CPCQualificationMenuMEP";
		public static final String SEP_PQR_TREEMENU = "CPCQualificationMenu";
		// DSM (DS) 2015x.4 - Changes for PQR revise - END
		//DSM (DS) 2015x.4 -Added  for 6 digits decimal format for numeric numbers-Start
		public static final String FORMAT_DECIMAL_SIX = "0.000000";
		public static final String ATTRIBUTE_PROCESSING_NOTE = PropertyUtil.getSchemaProperty("attribute_ProcessingNote");
		//DSM (DS) 2015x.4 -Added  for 6 digits decimal format for numeric numbers-End
		
		//DSM (DS) 2015x.4 REQT 14696 - Product Data Part Templates -starts
		public static final String TYPE_PG_MATERIAL_FUNCTION = PropertyUtil.getSchemaProperty("attribute_pgMaterialFunction");
		public static final String TYPE_PG_PLI_MATERIALFUNCTION_GLOBAL = PropertyUtil.getSchemaProperty("type_pgPLIMaterialFunctionGlobal");
		public static final String TABLE_CPNENCEBOMINDENETED_SUMMARY = "CPNENCEBOMIndentedSummary";
		public static final String TABLE_ENCSUBSTITUTEPART_SUMMARY = "ENCSubstitutePartSummary";
		public static final String TABLE_CPNFORMULABOMINDENETED_SUMMARY = "CPNFormulaBOMIndentedSummary";
		public static final String TABLE_CPNFORMULASUBSTITUTE_TABLE = "CPNFormulaSubstitutesTable";
		public static final String FRAME_ENCSUBSTITUTE_PARTSIN = "ENCSubstitutePartsIn";
		public static final String FRAME_ENCBOM = "ENCBOM";
		public static final String FRAME_FORMULATIONPROCESSFORMULA_BOMVIEW = "FormulationProcessFormulaBOMView";
		public static final String FRAME_CONTENT = "content";
		public static final String FRAME_DETAILS_DISPLAY = "detailsDisplay";
		public static final String TABLE_EDIT_PLBOMSUBSTITUTES_TABLE = "EditPLBOMSubstitutesTable";
		public static final String FRAME_CPN_SUBSTITUTES_EDIT_DETAILS = "CPNSubstitutesEditDetails";
		//DSM (DS) 2015x.4 REQT 14696 - Product Data Part Templates -ends
		//Added by DSM(DS) for 2015x.4 ALM 2487 STARTS
		public static final String RELATIONSHIP_DERIVED_OUTPUT = PropertyUtil.getSchemaProperty("relationship_DerivedOutput");
		//Added by DSM(DS) for 2015x.4 ALM 2487 ENDS
		//DSM (DS) 2015x.4 - added for Technical Standard File Format - Start
		public static final String FORMAT_NOT_RENDERABLE = "Not Renderable";
		public static final String ATTRIBUTE_ORIGINATOR = PropertyUtil.getSchemaProperty("attribute_Originator");
		//DSM (DS) 2015x.4 - added for Technical Standard File Format - End
		
		//DSM (DS) 2015x.4 ALM 10943 - Automatic GCAS Load process reads from a properties file on Linux server - Start
		public static final String PG_GCAS_CONFIG_NAME ="pgGCASSAPPropertiesConfig";
		public static final String PG_GCAS_CONFIG_REV ="-";
		public static final String ATTRIBUTE_PG_GCASSAP_CLIENT = PropertyUtil.getSchemaProperty("attribute_pgGCASSAP_client");
		public static final String ATTRIBUTE_PG_GCAS_USERID = PropertyUtil.getSchemaProperty("attribute_pgGCASgcas_userid");
		public static final String ATTRIBUTE_PG_GCAS_PWD = PropertyUtil.getSchemaProperty("attribute_pgGCASgcas_password");
		public static final String ATTRIBUTE_PG_GCASLANG = PropertyUtil.getSchemaProperty("attribute_pgGCASlanguage");
		public static final String ATTRIBUTE_PG_GCASHOST_NAME = PropertyUtil.getSchemaProperty("attribute_pgGCAShost_name");
		public static final String ATTRIBUTE_PG_GCASSYSTEM_NUMBER = PropertyUtil.getSchemaProperty("attribute_pgGCASsystem_number");
		public static final String ATTRIBUTE_PG_GCASLOG_DIR = PropertyUtil.getSchemaProperty("attribute_pgGCASlog_dir");
		public static final String ATTRIBUTE_PG_GCASTHRESHOLD = PropertyUtil.getSchemaProperty("attribute_pgGCASThreshold");
		public static final String ATTRIBUTE_PG_GCASRELOADQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgGCASReloadQuantity");
		public static final String ATTRIBUTE_PG_GCASMAXNOOFTRY = PropertyUtil.getSchemaProperty("attribute_pgGCASMaxNoOfTry");
		
		//DSM (DS) 2015x.4 ALM 10943 - Automatic GCAS Load process reads from a properties file on Linux server - End
		//DSM (DS) 2015x.4 - Implementing CA Promotion through Background Job - START
		public static final String CONST_SAP = "SAP";
		//DSM (DS) 2015x.4 - Implementing CA Promotion through Background Job - END
		//DSM(DS) 2015x.4 -ALM : 12197 W&D status reset to Pending on TUP - START
		public static final String ATTRIBUTE_RANGE_PENDING = "Pending";
		//DSM(DS) 2015x.4 -ALM : 12197 W&D status reset to Pending on TUP - END
		
		//DSM(DS) 2015x.4 - ALM 12195 : MPMP - Changes to Brand field in not being saved - START
		public static final String INPUT_TYPE_LISTBOX = "listbox";
		public static final String RANGE_BLANK = " <BLANK>";
		public static final String RANGE_VALUE_BLANK = "BLANK";
		//DSM(DS) 2015x.4 - ALM 12195 : MPMP - Changes to Brand field in not being saved - END
		
		//DSM (DS) 2015x.4  ALM 11698 - Route Template with ANY not restarting -starts
		public static final String SYMB_STATE_INWORK = "state_InWork";
		//DSM (DS) 2015x.4  ALM 11698 - Route Template with ANY not restarting -ends
		
		//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - Starts
		public static final String ATTRIBUTE_TITLE = PropertyUtil.getSchemaProperty("attribute_Title");
		//Modified for DSM(DS) 2015x.4 ALM 13484 added ttile and name - ends
		//DSM(DS) 2015x.4 ALM 13511 - CA owner(dsmdivest019.im) cannot promote CA from "In Approval" to "Complete" for pilot part - STRAT
		public static final String COMMENT_MULTIPLE_OWNERSHIP_GRANTED_DIVESTED_USER = "Multiple ownership added to grant read access to divested user by system";
		//DSM(DS) 2015x.4 ALM 13511 - CA owner(dsmdivest019.im) cannot promote CA from "In Approval" to "Complete" for pilot part - END
		//DSM(DS) 2015x.4 ALM 13801 - Setting Material Function values on Add - start
		public static final String STR_MATERIAL_FUNCTION = "Material Function";
		//DSM(DS) 2015x.4 ALM 13801 - Setting Material Function values on Add - end
		//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - START
		public static final String CONST_NOTES = "Notes";
		//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - END
		
		//DSM(DS) 2015x.4 - ALM#13979 - Final approval not promoting CA to complete - Start
		public static final String CONST_PROMOTE_CONNECTED_OBJECT = "Promote Connected Object";
		public static final String ATTRIBUTE_ROUTE_COMPLETIONACTION = PropertyUtil.getSchemaProperty("attribute_RouteCompletionAction");
		public static final String SYMB_STATE_INAPPROVAL = "state_InApproval";
		//DSM(DS) 2015x.4 - ALM#13979 - Final approval not promoting CA to complete - End

	        //DSM (DS) 2015X.4 - ALM 14669 - Copied Route Templates do not show up in Pending View - STARTS
		public static final String ATTRIBUTE_PG_CLAIMED_DATE = PropertyUtil.getSchemaProperty("attribute_pgClaimedDate");
		//DSM (DS) 2015X.4 - ALM 14669 - Copied Route Templates do not show up in Pending View - ENDS

		
		//DSM(DS) 2015x.4.1 - EBOM Mass Update - START
		public static final String CONST_TITLE = "Title";
		public static final String CONST_DESCRIPTION = "Description";
		public static final String CONST_REASON_FOR_CHANGE = "ReasonForChange";
		public static final String STRING_MASTER_ATTRIBUTE = "Master_attribute";
		public static final String STRING_TYPEAHEADMAP = "typeAheadMap";
		public static final String STRING_ROW_OBJECT_ID = "rowObjectId";
		public static final String STRING_EMXCPNSTRINGRESOURCE = "emxCPNStringResource";
		public static final String STRING_PARTFAMILY = "Part Family";
		public static final String STRING_TYPE = "type";
		public static final String STRING_SYMB_ATTR_QUANTITY = "attribute_Quantity";
		public static final String PARENT_ID = "id[parent]";
		public static final String STRING_GRP_HEADER_WEIGHTS = "Weights";
		public static final String STRING_GRP_HEADER_DIMENSIONS = "Dimensions";
		public static final String STRING_SETTING_COLUMNNAME = "ColumnName";
		public static final String STRING_MASTER_ATTRIBUTES = "MasterAttributes";
		//DSM(DS) 2015x.4.1 - EBOM Mass Update - END
		//DSM(DS) 2015x.4.1 - Extended Structure Copy - START
		public static final String MASTER_TABLE_DATA = "structureCopyMasterTableData1";
		public static final String CONST_DENIED = "#DENIED!";
		//DSM(DS) 2015x.4.1 - Extended Structure Copy - END

		
		//DSM (DS) 2015x.4 ALM 14408 - Perf Spec Copy: When copy from existing part code is connecting latest vs latest released for performance specs -START
		public static final String SELECT_LAST_PREVIOUS_ID = "last.previous.id";
		public static final String SELECT_LAST_PREVIOUS_CURRENT = "last.previous.current";
		public static final String SELECT_LAST_CURRENT = "last.current";
		//DSM (DS) 2015x.4 ALM 14408 - Perf Spec Copy: When copy from existing part code is connecting latest vs latest released for performance specs -END

		//DSM(DS) 2015x.4.1 - ALM 14437 Non-Encrypted Password in pgDSOConfiguration Config Object - Start
		public static final String PG_DSO_CONFIGURATION ="pgDSOConfiguration";
		public static final String ATTRIBUTE_PG_SAP_INTEG_FPC_WEBSERVICE_URL = PropertyUtil.getSchemaProperty("attribute_pgSAPIntegrationFPCWebServiceURL");
		public static final String ATTRIBUTE_PG_SAP_INTEG_FPC_WEBSERVICE_USERNAME = PropertyUtil.getSchemaProperty("attribute_pgSAPIntegrationFPCWebServiceUsername");
		public static final String ATTRIBUTE_PG_SAP_INTEG_FPC_WEBSERVICE_PASSWORD = PropertyUtil.getSchemaProperty("attribute_pgSAPIntegrationFPCWebServicePassword");
		//DSM(DS) 2015x.4.1 - ALM 14437 Non-Encrypted Password in pgDSOConfiguration Config Object - End
		//DSM(DS) 2015x.4.1 -  Copy TUP from Context of FPP TUP TrasnportUnit tab -starts
		public static final String TUPID = "TUPId";
		public static final String FPPID = "FPPId";
		public static final String TUP_SOURCE_ID = "TUPSourceId";
		public static final String ATTR_PG_GTIN = PropertyUtil.getSchemaProperty("attribute_pgGTIN");
		//DSM(DS) 2015x.4.1 -  Copy TUP from Context of FPP TUP TrasnportUnit tab -ends
		
		//DSM(DS) 2015x.4 - ALM#14517 -[DM] Value of <Intented Market> & <Shipping Hazard Classification> doesn't Carry Over after Copy from DSM Part- Start
		public static final String RELATIONSHIP_PGTOSHIPPING_HAZARD_CLASSIFICATION = PropertyUtil.getSchemaProperty("relationship_pgToShippingHazardClasssification");
		public static final String RELATIONSHIP_PGINTENTED_MARKETS = PropertyUtil.getSchemaProperty("relationship_pgIntendedMarkets");
		public static final String TYPE_PG_PLI_SHIPPING_HAZARD_CLASSIFICATION = PropertyUtil.getSchemaProperty("type_pgPLIShippingHazardClasssification");
		public static final String TYPE_PG_INTENDEDMARKETS = PropertyUtil.getSchemaProperty("type_Country");
		public static final String TYPE_PG_BRAND  = PropertyUtil.getSchemaProperty("type_pgBrand");
		//DSM(DS) 2015x.4 - ALM#14517 -[DM] Value of <Intented Market> & <Shipping Hazard Classification> doesn't Carry Over after Copy from DSM Part- End
		//DSM(DS) 2015x.4.1 - Structure Copy-Setting the description on newly created CO - starts
		public static final String CONST_CO_DESCRIPTION = "CODescription";
		//DSM(DS) 2015x.4.1 - Structure Copy-Setting the description on newly created CO - ends
		//DSM (DS) 2015x.4 ALM 14660- Large CAs are taking hours/days to complete the release process -START
		public static final String TYPE_PGPHASE = PropertyUtil.getSchemaProperty("type_pgPhase");
		//DSM (DS) 2015x.4 ALM 14660- Large CAs are taking hours/days to complete the release process -END
		//DSM (DS) 2015x.4.1 ALM 15128 -INC0636918 Changes made to Formulation part to the CSS Formula Card when modification are made- start
		public static final String ATTRIBUTE_TARGETWEIGHT_WET = PropertyUtil.getSchemaProperty("attribute_TargetWeightWet");
		public static final String ATTRIBUTE_TARGETWEIGHT_DRY = PropertyUtil.getSchemaProperty("attribute_TargetWeightDry");
		//DSM (DS) 2015x.4.1 ALM 15128 -INC0636918 Changes made to Formulation part to the CSS Formula Card when modification are made- End
		//DSM (DS) 2015x.5 - ALM-14188 - INC0363746 : User reported that he revised a MEP and released this MEP 2 without input "Reason For Change" - Start
		public static final String ATTRIBUTE_PG_PACKAGING_MATERIAL_TYPE = PropertyUtil.getSchemaProperty("attribute_pgPackagingMaterialType");
		public static final String CONST_PACKAGING_MATERIAL_TYPE = "Packaging Material Type";
		//DSM (DS) 2015x.5 - ALM-14188 - INC0363746 : User reported that he revised a MEP and released this MEP 2 without input "Reason For Change" - End
	    //DSM (DS) 2015x.5 : Added for GPS Assessment Task FSD - Start
		public static final String REL_PGRI_TASK_INPUTS = PropertyUtil.getSchemaProperty("relationship_pgRITaskInputs");
		public static final String POLICY_GPSASSESSMENTTASK = PropertyUtil.getSchemaProperty("policy_pgGPSAssessmentTask");
		public static final String TYPE_GPSASSESSMENTTASK = PropertyUtil.getSchemaProperty("type_pgGPSAssessmentTask");
		public static final String CONST_A5 = "A5";
		public static final String CONST_A6 = "A6";
		public static final String CONST_A7 = "A7";
		public static final String CONST_A8 = "A8";
		public static final String CONST_A9 = "A9";
		public static final String CONST_PGASSESSMENTA5A6INTERFACE = "pgAssessmentTaskA5ToA6Interface";
		public static final String CONST_PGASSESSMENTA7ToA9INTERFACE = "pgAssessmentTaskA7ToA9Interface";
		public static final String ATTRIBUTE_PGGPSASSESSMENTID = PropertyUtil.getSchemaProperty("attribute_pgGPSAssessmentID");
		public static final String PGASSESSMENTSUBMISSIONDATE = PropertyUtil.getSchemaProperty("attribute_pgAssessmentSubmissionDate");
		public static final String ATTRIBUTE_PGGPSASSESSMENTCATEGORY = PropertyUtil.getSchemaProperty("attribute_pgGPSAssessmentCategory");
		public static final String ATTRIBTE_PGGPSASSESSMENTURL = PropertyUtil.getSchemaProperty("attribute_pgGPSAssessmentURL");
		public static final String ATTRIBTE_PGGPSSTATUS = PropertyUtil.getSchemaProperty("attribute_pgGPSStatus");
		public static final String ATTRIBTE_PGGPSSUMMARY = PropertyUtil.getSchemaProperty("attribute_pgGPSSummary");
		public static final String ATTRIBTE_PGGPSDEPOTROOT = PropertyUtil.getSchemaProperty("attribute_pgGPSDepotRoot");
		public static final String CONST_HTTPS = "https://";

		public static final String REL_PGGPSASSESSMENTTASK_INPUTS = PropertyUtil.getSchemaProperty("relationship_pgGPSAssessmentTaskInputs");
		public static final String REL_PGGPSASSESSMENTTASK_INPUTS_COUNTRIES = PropertyUtil.getSchemaProperty("relationship_pgCountriesToBeCleared");
		public static final String ATTRIBUTE_TASK_ESTIMATED_START_DATE = PropertyUtil.getSchemaProperty("attribute_TaskEstimatedStartDate");

		public static final String REL_PGGPSTASKASSESSMENTCOUNTRY = PropertyUtil.getSchemaProperty("relationship_pgGPSTaskAssessmentCountry");
		public static final String TYPE_COUNTRY = PropertyUtil.getSchemaProperty("type_Country");
		public static final String PERSON_PGGPS_INTEGRATION_SYSTEMUSER = "pgGPSIntegrationSystemUser";
		public static final String ATTRIBUTE_PGFORECASTANNUALSALESVOLUMES = PropertyUtil.getSchemaProperty("attribute_pgForecastAnnualSalesVolumes");
		public static final String ATTRIBUTE_PGEXPECTEDREGULATORYPRODUCTCLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pgExpectedRegulatoryProductClassification");
		public static final String CONSTANT_EXPECTEDREGULATORYPRODUCTCLASSIFICATION = "ExpectedRegulatoryProductClassification";
		public static final String CONSTANT_FORECASTANNUALSALESVOLUMES = "ForecastAnnualSalesVolumes";
		public static final String CONSTANT_ADDAFPP = "addAFPP";
		public static final String CONSTANT_PGGPSASSESSMENTADMIN = "pgGPSAssessmentAdmin";
		public static final String CONSTANT_PG_PARALLEL_CLONE_ADMIN = "pgParallelCloneAdmin";
		public static final String CONSTANT_PGPLI = "pgPLI";
		public static final String CONSTANT_PG = "pg";
		public static final String STATE_CREATE = "Create";
		public static final String STATE_CANCEL = "Cancel";
		public static final String CONSTANT_GOTOCANCEL = "GoToCancel";
		public static final String CONSTANT_CANCELLED = "Cancelled";
		public static final String ATTRIBUTE_BRANCHTO = PropertyUtil.getSchemaProperty("attribute_BranchTo");
		public static final String CONSTANT_SECONDLEVEL = "2";
		public static final String GPS_TASK_DURATION_UNITS_HOUR = "h";
		public static final String GPS_TASK_DURATION_UNITS_DAY = "d";
		public static final String GPS_INPUT_PART_ORIGINATINGSOURCE_CSS = "CSS";
		//DSM (DS) 2015x.5 : Added for GPS Assessment Task FSD - End
		//DSM (DS) 2015x.5 - Added for Shared Collections FSD - START
		public static final String CONST_PROPERTY_SHARED_COLLECTION_LIST = "property[pgSharedCollectionNameList].value";
		public static final String CONST_SHARED_COLLECTION_LIST  = "pgSharedCollectionNameList";
		public static final String MENU_PG_SHARED_COLLECTION_MENU = PropertyUtil.getSchemaProperty("menu_pgAEFSharedCollectionMenu");
		public static final String CONST_REMOVE = "remove";
		//DSM (DS) 2015x.5 - Added for Shared Collections FSD - END
		//DSM (DS) 2015x.5 - Added for PDT FSD - START
		public static final String CONST_IN_ASSESSMENT = "IN ASSESSMENT";
		public static final String ATTRIBUTE_PG_LIFECYCLESTATUS = PropertyUtil.getSchemaProperty("attribute_pgLifeCycleStatus");
		public static final String ATTRIBUTE_PG_ISACTIVATED = PropertyUtil.getSchemaProperty("attribute_pgIsActivated");
		//DSM (DS) 2015x.5 - Added for PDT FSD - END
		//DSM DS 2015x.5 - Added the part of code to show blank and Third Party values for types ARMP,APMP,COP,APP,DPP - Start
		public static final String CONSTANT_STRING_THIRD_PARTY= "Third Party";
		//DSM DS 2015x.5 - Added the part of code to show blank and Third Party values for types ARMP,APMP,COP,APP,DPP - End
		// DSM(DS) Production Fix : Added for TOPS Reqt 18569 - Start
		public static final String CONSTANT_PALLET_U1 = "U1";
		// DSM(DS) Production Fix : Added for TOPS Reqt 18569 - End
		//DSM(DS) 2015x.4.1 Feb ALM 15323 -User is unable to add a substitute part within a DPP BOM- start
		public static final String CONST_PGORIGINATINGSOURCE_CSS = "CSS";
		//DSM(DS) 2015x.4.1 Feb ALM 15323 -User is unable to add a substitute part within a DPP BOM- end
		// DSM (DS) 2015x.5 - Added for PDT FSD - START
		public static final String ATTRIBUTE_PG_ISPRODUCT_CERTIFICATION_OR_STANDARDS_COMPLIANCESTATEMENT = PropertyUtil.getSchemaProperty("attribute_pgIsProductCertificationorLocalStandardsComplianceStatementRequired");
		// DSM (DS) 2015x.5 - Added for PDT FSD - END
		//DSM (DS) 2015x.5 - Security change Restricted to "Business Use", Also Removal of "Internal Use" value - Start
		public static final String CONSTANT_BU = "BU";
		//DSM (DS) 2015x.5 - Security change Restricted to "Business Use", Also Removal of "Internal Use" value - End
		//DSM (DS) 2015x.5 - Added for new Attribute PDT-FSD : START
		public static final String ATTRIBUTE_PG_POWER_SOURCE = PropertyUtil.getSchemaProperty("attribute_pgPowerSource");
		public static final String CONSTANT_NON_POWERED = "Non-Powered";
		//DSM (DS) 2015x.5 - Added for new Attribute PDT-FSD : END
		//DSM (DS) 2015x.5 : Added for GPS Assessment Task FSD - starts
		public static final String  STR_A3A = "A3a";
		//DSM (DS) 2018x.1.1 : Added for new GPS category - GPS Assessment Task FSD - START
		public static final String  STR_A3A1 = "A3a1";
		public static final String  STR_A3A2 = "A3a2";
		//DSM (DS) 2018x.1.1 : Added for new GPS category - GPS Assessment Task FSD - END
		public static final String  STR_A3C = "A3c";
		public static final String  STR_A5 = "A5";
		public static final String  STR_A6 = "A6";
		public static final String  STR_A7A = "A7a";
		public static final String  STR_A7B = "A7b";
		public static final String  STR_A8 = "A8";
		public static final String  GPS_ASSESSMENT = "IN ASSESSMENT";
		public static final String CONST_USERNAME = "username";
		public static final String CONST_INHERITEDACCESS = "inheritedAccess";
		public static final String CONST_ACCESS = "access";
		public static final String CONST_EP = "EP";
		public static final String CONST_MEP = "MEP";
		public static final String CONST_SEP = "SEP";
		public static final String CONST_MCP = "MCP";
		public static final String CONST_LINK = "link";
		public static final String CONST_MEP_SEP = "MEPorSEP";
		public static final String CONST_MEP_IS_EP = "MEP=EP";
		public static final String CONST_MEPTOEP = "MEPtoEP";
		public static final String CMD_NAME = "Command_Name";
		public static final String CONSTANT_COMMEMTS = "Comments";
		public static final String TYPE_PG_PKG_STUDY_PROTOCOL = PropertyUtil.getSchemaProperty("type_pgPKGStudyProtocol");

		//DSM (DS) 2015x.5 : Added for GPS Assessment Task FSD - End
		//DSM (DS) 2015x.5 : Added for   PDT-FSD  - START
		public static final String TYPE_PG_COMPETITIVE_PRODUCT_PART = PropertyUtil.getSchemaProperty("type_pgCompetitiveProductPart");
		public static final String ATTRIBUTE_PG_TIER = PropertyUtil.getSchemaProperty("attribute_pgTier");
		public static final String CONST_BASE = "Base";
		public static final String CONST_NOT_POWERED = "Not Powered";
		public static final String CONSTANT_STRING_FINISHED_PRODUCT= "Finished Product Part";
		//DSM (DS) 2015x.5 : Added for   PDT-FSD  - End
		//DSM (DS) 2015x.5 : Added for No Structured FSD - Start
		public static final String TYPE_PF_BASE_FORMULA = PropertyUtil.getSchemaProperty("type_pgBaseFormula");
		public static final String TYPE_PF_URTGENERALFORMULATION = PropertyUtil.getSchemaProperty("type_pgURTGeneralFormulation");
		public static final String ATTR_PG_IMPACTED_TYPE = PropertyUtil.getSchemaProperty("attribute_pgImpactedType");
		public static final String ATTR_PG_REVISEDTOTYPE = PropertyUtil.getSchemaProperty("attribute_pgRevisedToType");
		//DSM (DS) 2015x.5 : Added for No Structured FSD - End
		//DSM (DS) 2015x.5 : Added for GPS Assessment Task Parallel Cloning  FSD - starts
		public static final String POLICY_PG_GPSPRODUCTDATA= PropertyUtil.getSchemaProperty("policy_pgGPSProductData");
		public static final String REL_PG_GPSCLONETO= PropertyUtil.getSchemaProperty("relationship_pgGPSCloneTo");
		public static final String STR_C_HIPHEN= "C-";
		public static final String REL_DISTRIBUTION_LIST = PropertyUtil.getSchemaProperty("relationship_DistributionList");
		public static final String REL_PLANT_COST_OVERRIDE = PropertyUtil.getSchemaProperty("relationship_PlantCostOverride");
		public static final String STR_PARALLEL_CLONE = "parallelClone";
		public static final String ATTRIBUTE_PGEMPTYPE = PropertyUtil.getSchemaProperty("attribute_pgSecurityEmployeeType");
		public static final String POLICY_PG_PARALLEL_CLONE_PDP = PropertyUtil.getSchemaProperty("policy_pgParallelCloneProductDataPart");
		public static final String ATTRIB_PGGPSCLONED_SEQUENCENUMBER = PropertyUtil.getSchemaProperty("attribute_pgParallelCloneNextNumber");
		public static final String REL_PG_GPSTOCONFIGOBJECT = PropertyUtil.getSchemaProperty("relationship_pgParallelCloneToConfigObject");
		public static final String POLICY_PG_CONFIGURATION_ADMIN = PropertyUtil.getSchemaProperty("policy_pgConfigurationAdmin");
		public static final String INTERFACE_PG_PARALLEL_CLONE_INTERFACE = PropertyUtil.getSchemaProperty("interface_pgParallelCloneInterface");
		public static final String STRING_ATTRIBUTE_MAP = "AttributesMap";
		public static final String STRING_SEGMENT = "Segment";
		public static final String STRING_DISTRIBUTIONLIST = "DistributionList";
		public static final String STRING_REGION = "Region";
		public static final String STRING_TEMPLATE = "Template";
		public static final String STRING_ON = "on";
		public static final String STRING_ALLRELS = "AllRels";
		public static final String STRING_ALLRELS1 = "AllRels1";
		public static final String STRING_ALLRELS2 = "AllRels2";
		public static final String STRING_ALLRELS3 = "AllRels3";
		public static final String STRING_ALLRELS4 = "AllRels4";
		public static final String STRING_ALLRELS5 = "AllRels5";
		public static final String STRING_REFERENCE_DOCUMENTS = "Reference Documents";
		public static final String STRING_RELATED_SPEC = "Related Specifications";
		public static final String STRING_PLANTS = "Plants";
		public static final String STRING_SPECTYPE = "specType";
		public static final String STRING_ATTRIBUTELIST = "attributeList";
		public static final String STRING_PRODUCTDATANAME = "productDataName";
		public static final String STRING_POLICY = "policy";
		public static final String STRING_GPSMODE = "GPSMode";
		public static final String STRING_REVISION = "revision";
		public static final String STRING_RELATEDOBJ_LIST = "relatedObjList";
		public static final String STRING_SPECAUTONAME = "specAutoName";
		public static final String STRING_STR_NO_OF_COPIES = "strNumberOfCopies";
		public static final String STRING_VAULTNAME = "vaultName";
		public static final String STRING_TEMPLATE_ID = "templateId";
		public static final String STRING_CHANGETEMPLATE = "changeTemplate";
		public static final String STRING_CO = "CO";
		public static final String STRING_RDOID= "rdoId";
		public static final String STRING_MAP_HMREQ= "hmReq";
		public static final String STRING_ASCENDING= "ascending";
		public static final String STR_STRING= "string";
		public static final String STRING_EMXCPN = "emxCPN";
		public static final String STRING_CAP_POLICY = "Policy";
		public static final String STRING_CAP_REVISION = "Revision";
		public static final String STRING_RENDER_LANGUAGE = "RenderLanguage";
		public static final String STRING_DISTRIBUTIONLIST_OID = "DistributionListOID";
		public static final String STRING_OWNERREGION_OID = "OwningRegionOID";
		public static final String STRING_EXPIRATION_DATE = "ExpirationDate";
		public static final String STRING_NO_OF_COPIES = "NoOfCopies";
		public static final String STRING_CONTEXTOWNER = "ContextOwner";
		public static final String STRING_COPYTYPE = "CopyType";
		public static final String STRING_ALLRELS_COPY_REF_DOC = "AllRels_copy_relationship_ReferenceDocument";
		//DSM (DS) 2018x.0 : ALM 21991 : Substitutes dropped on Clone of the Formulation - START
		//public static final String STRING_ALLRELS_COPY_PLBOM = "AllRels_copy_relationship_PLBOM";
		public static final String STRING_ALLRELS_COPY_PLBOM = "AllRels_copy_relationship_FBOM";
		//DSM (DS) 2018x.0 : ALM 21991 : Substitutes dropped on Clone of the Formulation - END
		public static final String STRING_ALLRELS_COPY_PLANTCOSTOVERRIDE = "AllRels_copy_relationship_PlantCostOverride";
		public static final String STRING_ALLRELS_COPY_FILEFORMAT = "AllRels_copy_type_FileFormat";
		public static final String STRING_FILE_FORMAT = "File Format";
		public static final String STRING_ALLRELS_REF_DOC ="AllRels_copy_relationship_ReferenceDocument";
		public static final String STRING_ALLRELS_ASSOCIATED_PLANTS ="AllRels_copy_relationship_AssociatedPlants";
		//DSM (DS) 2018x.0 : ALM 21991 : Substitutes dropped on Clone of the Formulation - START
		//public static final String STRING_ALLRELS_PLBOM_SUB ="AllRels_copy_relationship_FBOMSubstitute";
		public static final String STRING_ALLRELS_PLBOM_SUB ="AllRels_copy_relationship_FBOMSubstitute";
		//DSM (DS) 2018x.0 : ALM 21991 : Substitutes dropped on Clone of the Formulation - END
		public static final String STRING_CLONE_MODE ="clonemode";
		public static final String STRING_ORGANIZATOIN ="organization";
		public static final String STRING_PROJECT ="Project";
		public static final String STRING_COMMENT ="Comment";
		public static final String CONST_SUCCESS = "SUCCESS";
		public static final String CONST_ERROR = "ERROR";
		public static final String TYPE_PGPARALLELCLONE_CONFIGURATIONADMIN =  PropertyUtil.getSchemaProperty("type_pgParallelCloneConfigurationAdmin");
		public static final String POLICY_PGPARALLELCLONE_CONFIGURATIONADMIN =  PropertyUtil.getSchemaProperty("policy_pgParallelCloneConfigurationAdmin");
		public static final String STRING_LATEST_FORMULAITONID ="LatestFormulationId";
		public static final String STRING_MODE_PC_COPY ="ParallelCloningCopy";
		public static final String STRING_DIRECTION_FROM ="from";
		public static final String STRING_DIRECTION_TO ="to";
		public static final String ATTR_PG_PARALLELCLONEPHYSICALID = PropertyUtil.getSchemaProperty("attribute_pgParallelClonePhysicalId");
		//DSM (DS) 2015x.5 : Added for GPS Assessment Task Parallel Cloning  FSD - ends
		
		//Code Added By DH Team for 2015x.5 : To capture the "Review to Cancel" action and send message to GPS - START
		public static final String PROMOTE = "Promote";
		public static final String POLICY_PROJECT_TASK_STATE_REVIEW_PROMOTE_ACTION = "PolicyProjectTaskStateReviewPromoteAction";
		public static final String PG_SEND_ESB_MESSAGE = "pgSendESBMessage";
			public static final String PG_CO_OWNER_FULL = "FULL";
		//Code Added By DH Team for 2015x.5 : To capture the "Review to Cancel" action and send message to GPS - END
		
		//Code Added By DH Team for 2015x.5 : ALM REQ#20449 : To capture the Clone part transfer to base product part and send message to GPS - START
		public static final String TRANSFER = "Transfer";
		//Code Added By DH Team for 2015x.5 : ALM REQ#20449 : To capture the Clone part transfer to base product part and send message to GPS - END
		
			//DSM(DS)-2015x.5 - Fix for 15522 - System allows adding of Product Data with Segment - NotApplicable - START
		public static final String CONSTANT_STRING_DOT_NOT_APPLICABLE = ".Not Applicable";
		//DSM(DS)-2015x.5 - Fix for 15522 - System allows adding of Product Data with Segment - NotApplicable - END
		//DSM DS 2015x.5 ALM 15564 - Expected Frequency of Use UoM field is not using the correct subset values - STARTS
		public static final String ATTRIBUTE_PG_EXPECTED_FREQUENCY_OF_USE_UOM = PropertyUtil.getSchemaProperty("attribute_pgExpectedFrequencyofUseUoM");
		//DSM DS 2015x.5 ALM 15564 - Expected Frequency of Use UoM field is not using the correct subset values - ENDS
		
		//DSM (DS) 2015X.5 ALM-15656 - CA which has 200 objects cannot be promoted to In Approval with limited number items error - Start
		public static final String CHANGE_AFFECTED_ITEM = "Change Affected Item";
		public static final String CONST_RELATIONSHIP = "relationship";
		//DSM (DS) 2015X.5 ALM-15656 - CA which has 200 objects cannot be promoted to In Approval with limited number items error - End
		//DSM (DS) 2015x.5 : Added for GPS Assessment Task Parallel Cloning  Countries Cleared Requirement - starts
		public static final String REL_PGPRODUCTCOUNTRYCLEARANCE = PropertyUtil.getSchemaProperty("relationship_pgProductCountryClearance");
		//public static final String ATTRIBUTE_PGOVERALLCLEARANCESTATUS = PropertyUtil.getSchemaProperty("attribute_pgOverallClearanceStatus");
		//public static final String RANGE_NOT_CLEARED = "Not Cleared";
		//DSM (DS) 2015x.5 : Added for GPS Assessment Task Parallel Cloning  Countries Cleared Requirement - ends
		
		//DSM(DS) 2015x.5 - Fix for ALM 15646 - Validation Error - Assiging A5 GPS Task - START
		public static final String CONST_ARTWORK_PROJECT = "Artwork Project";
		//DSM(DS) 2015x.5 - Fix for ALM 15646 - Validation Error - Assiging A5 GPS Task - END
		//DSM (DS) 2015x.5 ALM-15438 IRM Documents State Validation Check on promotion of GPS Assessment Task - Starts
		public static final String POLICY_PG_PKGSIGNATUREREFERENCEDOC= PropertyUtil.getSchemaProperty("policy_pgPKGSignatureReferenceDoc");
		//DSM (DS) 2015x.5 ALM-15438 IRM Documents State Validation Check on promotion of GPS Assessment Task - Ends
		//DSM (DS) 2015x.5 ALM 15473 - The Chg Column is not editable on the BOM. Further more it matches any values put in the Change Column with no validation - START
		public static final String STR_CHG = "Chg";
		public static final String ATTR_PG_CHANGE = PropertyUtil.getSchemaProperty("attribute_pgChange");
		//DSM (DS) 2015x.5 ALM 15473 - The Chg Column is not editable on the BOM. Further more it matches any values put in the Change Column with no validation - END
		//DSM(DS) 2015x.5 ALM 16244 Make plant activation a deferred transaction - start
		public static final String STR_MODE_CHANGEACTION = "changeaction";
		public static final String STR_EVENT_MODIFYATTRIBUTE = "modifyattribute";
		public static final String STR_EVENT_DELETE = "delete";
		//DSM(DS) 2015x.5 ALM 16244 Make plant activation a deferred transaction - End
		//DSM (DS) 2015x.5 ALM 16146 - A3 - Estimated Product segment should be multi select - STARTS
		public static final String STR_SETTING_REQUIRED = "Required";
		//DSM (DS) 2015x.5 ALM 16146 - A3 - Estimated Product segment should be multi select - ENDS
		//DSM(DS) 2015x.5 ALM 16531 - MCUP/MIP Revise Process Issue - STRAT
		public static final String CONST_MODIFY_TO = "ModifyTo";
		//DSM(DS) 2015x.5 ALM 16531 - MCUP/MIP Revise Process Issue - END
		//DSM (DS) 2015x.5 ALM 16434 - CPP Manufacture Picklist is not linked to the Brand - Starts
		public static final String TYPE_PGPLICOMPETITIVEMANUFACTURER = PropertyUtil.getSchemaProperty("type_pgPLICompetitiveManufacturer");	
		public static final String CONST_RELATIONSHIPNAME = "RelationshipName";
		public static final String CONST_MANUFACTURERNAME = "ManufacturerName";
		public static final String CONST_MODE = "mode";
		public static final String CONST_RELATEDFIELD = "RelatedField";
		public static final String CONST_RELATEDFIELDTYPE = "RelatedFieldType";
		public static final String CONST_CONNECTEDRELFORONCHANGE = "ConnectedRelForOnChange";
		public static final String CONST_PGPICKLISTNAME = "pgPicklistName";
		public static final String CONST_EDIT = "edit";
		//DSM (DS) 2015x.5 ALM 16434 - CPP Manufacture Picklist is not linked to the Brand - Ends
		//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - Starts
		public static final String STR_PG_DSO_MASTERPART_DETAILS_TABLE = "pgDSOMasterPartDetails";
		//DSM (DS) 2015x.4.1 March Downtime ALM - 16403 - Performance of FPC related specs screen is to slow - ends
		
		//DSM (DS) 2015x.5 - ALM 16739 - Product Form field for FOP, APP, and DPP should be the ENOVIA Product Form picklist - START
		public static final String TYPE_PG_PLIPRODUCTFORM = PropertyUtil.getSchemaProperty("type_pgPLIProductForm");
		public static final String CONST_PRODUCTFORMFORPRODUCT = "ProductFormForProduct";
		//DSM (DS) 2015x.5 - ALM 16739 - Product Form field for FOP, APP, and DPP should be the ENOVIA Product Form picklist - END
		//DSM (DS) 2015x.5 ALM 15111 - Reclassify not working - STARTS
		public static final String SELECT_PREV_ATTR_REFERENCE_TYPE = "previous.attribute["+ ATTR_REFERENCE_TYPE +"].value";
		//DSM (DS) 2015x.5 ALM 15111 - Reclassify not working - ENDS
		//DSM (DS) 2015x.5 ALM 17062 - CATIA Synched Enterprise Part Upstage/Revise issue due to thumbnail existing on previous Obsolete revs - STARTS
		public static final String TYPE_PLMDERVOBJREP = PropertyUtil.getSchemaProperty("type_PLMDerivedObjRepresentation");
		public static final String ATTRIBUTE_PLMDERVOBJREP_DERVOF = PropertyUtil.getSchemaProperty("attribute_PLMDerivedObjRepresentation.V_DerivedOf");
		//DSM (DS) 2015x.5 ALM 17062 - CATIA Synched Enterprise Part Upstage/Revise issue due to thumbnail existing on previous Obsolete revs - ENDS
		// DSM(DS) Upgrade -JIRA:JPO-2: CA Signature ignored in In Approval state: Start
		public static final String STR_RELEASE_PHASE = PropertyUtil.getSchemaProperty("attribute_ReleasePhase");
		public static final String ATTRIBUTE_PG_INHERITED_FROMPLATFORM = PropertyUtil.getSchemaProperty("attribute_pgInheritedFromPlatform");
		
		// DSM(DS) Upgrade -JIRA:JPO-2: CA Signature ignored in In Approval state: End
		//Added for 2018x Upgrade Starts - Stage attribute is replaced by Relese Phase. Hence added this line to select the Release phase value.
		public static final String SELECT_ATTRIBUTE_RELEASE_PHASE  = (new StringBuilder()).append("attribute[").append(STR_RELEASE_PHASE).append("].value").toString();
		public static final String SCHEMA_POLICY_EC_PART  = "policy_ECPart";	
		//Added for 2018x Upgrade Ends  - Stage attribute is replaced by Relese Phase. Hence added this line to select the Release phase value.
		//DSM (DS) 2018.0 FD02 Relationship change PLBOM to FBOM -starts
		public static final String REL_FBOM = PropertyUtil.getSchemaProperty("relationship_FBOM");
		public static final String RELATIONSHIP_FBOM_SUBSTITUTE = PropertyUtil.getSchemaProperty("relationship_FBOMSubstitute");
		public static final String RELATIONSHIP_FBOM_PENDING = PropertyUtil.getSchemaProperty("relationship_FBOMPending");
		public static final String RELATIONSHIP_FBOM_HISTORY = PropertyUtil.getSchemaProperty("relationship_FBOMHistory");
		//DSM (DS) 2018.0 FD02 Relationship change PLBOM to FBOM -ends
		//Modified for 2018x Upgrade - Experimental Phase renamed to Development for Release Phase attribute - STARTS
		public static final String DEVELOPMENT = "Development";
		public static final String SELECT_ATTRIBUTE_REQUESTED_CHANGE = (new StringBuilder()).append("attribute[").append(ATTR_PG_REQUESTEDCHANGE).append("]").toString();
		public static final String TYPE_CHANGE_ACTION_SELECT = "type_ChangeAction";
		public static final String POLICY_CHANGE_ACTION_SELECT = "policy_ChangeAction";
		public static final String VAULT_PRODUCTION_SELECT = "eService Production";
		//Modified for 2018x Upgrade - Experimental Phase renamed to Development for Release Phase attribute - ENDS
		//Modified for 2018x Upgrade - Test Method is replaced by Test Method Specification in 18x OOTB - Starts
		public static final String TYPE_TEST_METHOD_SPECIFICATION = PropertyUtil.getSchemaProperty("type_TestMethodSpecification");
		public static final String TYPE_TEST_METHOD_SPECIFICATION_R = "type_TestMethodSpecification";
		public static final String TEST_METHOD_SPECIFICATION = "Test Method Specification";
		//Modified for 2018x Upgrade - Test Method is replaced by Test Method Specification in 18x OOTB - Ends
		//DSM (DS) 2018x JIRA: D18X-277 - User Doesn't Allow add Technical Specification Under "Packaging Material Part"- START
		public static final String CONST_CREATEPRODUCTDATASPEC = "CreateProductDataSpec";
		//DSM (DS) 2018x JIRA: D18X-277 - User Doesn't Allow add Technical Specification Under "Packaging Material Part"- END
		
		//DSM (DS) 2015x.5.1 MASS MEP SEP Creation - STARTS
		public static final String CONSTANT_CREATE_NEW = "Create New";
		public static final String CONSTANT_REVISE = "Revise";
		public static final String CONSTANT_CREATE_REVISE = "Create Revise";
		public static final String CONSTANT_COLOR_INPUT_GREY = "ResourcePlanningGreyBackGroundColor";
		public static final String REL_SUPPLIER_EQUIVALENT = PropertyUtil.getSchemaProperty("relationship_SupplierEquivalent");
		public static final String REL_SUPPLIER_RESPONSIBILITY = PropertyUtil.getSchemaProperty("relationship_SupplyResponsibility");
		public static final String STR_EXISTING_MEP_NAME_LIST = "ExistingMEPNameList";
		public static final String STR_EXISTING_MEP_ID = "ExistingMEPIdList";
		public static final String STR_EXISTING_SEP_NAME_LIST = "ExistingSEPNameList";
		public static final String STR_EXISTING_SEP_ID = "ExistingSEPIdList";
		public static final String MANUFACTURER_ID = "manufacturerId";
		public static final String FIELD_DISPLAY_CHOICES = "field_display_choices";
		public static final String FIELD_CHOICES = "field_choices";
		public static final String STRING_EXISTING_MEP = "ExistingMEP";
		public static final String STRING_MEP_ACTIONS = "MEPActions";
		public static final String STRING_SEP_ACTIONS = "SEPActions";
		public static final String SYMB_EQUALS_TO = "=";
		public static final String CONST_ORGANIZATION = "Organization";
		public static final String CONST_MEP_CELLEDITABLE = "MEPCellEditable";
		public static final String CONST_SEP_CELLEDITABLE = "SEPCellEditable";
		public static final String CONST_SUPPLIER_OID = "SupplierOID";
		public static final String CONST_MANUFACTURER = "Manufacturer";
		public static final String CONST_ORGANIZATION_OID = "OrganizationOID";
		public static final String CONST_FIELDS = "fields";
		public static final String CAP_NAME = "Name";
		public static final String CONST_AUTONAME = "autoName";
		public static final String CONST_NAMEMODE = "nameMode";
		public static final String CONST_AUTONAMESERIES = "AutoNameSeries";
		public static final String CONST_TYPE_ACTUAL = "TypeActual";
		public static final String CONST_LOCALE_OBJ = "localeObj";
		public static final String CONST_VAULT = "Vault";
		public static final String CONST_OWNER = "Owner";
		public static final String CAP_OBJECTID = "ObjectId";
		public static final String SELECT_ID_LEVEL = "id[level]";
		public static final String CONST_ROWID = "rowId";
		public static final String CONST_COLUMNS = "columns";
		public static final String CONST_XMLDOC = "XMLDoc";
		public static final String CONST_RELBUSOBJLIST = "relBusObjList";
		//DSM (DS) 2015x.5.1 MASS MEP SEP Creation - ENDS
		//DSM(DS) 2015x.5.1 - Stability Results Characteristic Table - START
		public static final String STABILITYRESULT_TABLE = "pgStabilityResultsTable";
		public static final String STR_PG_STABILITY_RESULTS_VIEW_TABLES = "pgStabilityResultsViewTables";
		//DSM(DS) 2015x.5.1 - Stability Results Characteristic Table - END
		//DSM (DS) 2015X.5.1 - ALM #17272 - unable to promote an Route Template to Production due to error message thrown - Start
		public static final String STR_ICON_MAIL="iconMail";
		public static final String STR_EMAIL="email";
		public static final String STR_BOTH="both";
		//DSM (DS) 2015X.5.1 - ALM #17272 - unable to promote an Route Template to Production due to error message thrown - End
		
		//DSM(DS) 2015x.5.1 - Relationship Matrix - 18578 - START 
		public static final String CONST_THIRDPARTY_FORMULATION_TYPE = "Third Party Formula";
		//DSM(DS) 2015x.5.1 - Relationship Matrix - 18578 - END
		//DSM (DS) 2015x.5.1 - GPS Assessment FSD - START
		public static final String ATTRIBUTE_PG_ORIGINAL_TASK = PropertyUtil.getSchemaProperty("attribute_pgOriginalTaskName");
		public static final String STR_A4 = "A4";
		public static final String STR_A1 = "A1";
		public static final String TYPE_GENERAL_INNOVATION_RECORD = PropertyUtil.getSchemaProperty("type_pgPKGDevelopmentOther");
		public static final String CONST_MATERIAL_INQUIRY = "Material Inquiry";
		public static final String RELATIONSHIP_PG_DOCUMENT_TO_SUBTYPE = PropertyUtil.getSchemaProperty("relationship_pgDocumentToSubType");
		//DSM (DS) 2015x.5.1 - GPS Assessment FSD - END

		//DH 2015x.5 - Changes for Deferring DH Publishing Functionality - Starts
		public static final String POLICY_PRODUCTION_PRODUCT_DATA_STATE_APPROVED_PROMOTE_ACTION = "PolicyProductionProductDataStateApprovedPromoteAction";
		public static final String POLICY_PRODUCTION_FORMULATION_PART_STATE_APPROVED_PROMOTE_ACTION = "PolicyProductionFormulationPartStateApprovedPromoteAction";
		//DH 2015x.5 - Changes for Deferring DH Publishing Functionality - Ends
		
		//DSM(DS) 2015x.5.1 - Part BOM Management - START
		public static final String ATTRIBUTE_PG_SUBSTITUTE_FOR = PropertyUtil.getSchemaProperty("attribute_pgCOPSubstituteFlag");
		public static final String ATTRIBUTE_FPP_RELEASE = PropertyUtil.getSchemaProperty("attribute_pgFPPReleaseFlag");
		//DSM(DS) 2015x.5.1 - Part BOM Management - End
		
		//DSM (DS) 2015x.5.1 - Change Management FSD - START
		public static final String TYPE_PG_MASTER_FINISHED_PRODUCT = PropertyUtil.getSchemaProperty("type_pgMasterFinishedProduct");
		public static final String TYPE_PG_MASTER_PACKING_MATERIAL = PropertyUtil.getSchemaProperty("type_pgMasterPackingMaterial");
		public static final String TYPE_PG_MASTER_RAW_MATERIAL = PropertyUtil.getSchemaProperty("type_pgMasterRawMaterial");
		public static final String TYPE_RAWMATERIAL = PropertyUtil.getSchemaProperty("type_RawMaterial");
		//DSM (DS) 2015x.5.1 - Change Management FSD - END
		
		//DSM(DS) 2015x.5.1 - IOT FSD - Build path hyperlink- START 
		public static final String ATTRIBUTE_PGBUILDPATH =  PropertyUtil.getSchemaProperty("attribute_pgBuildPath");
		//DSM(DS) 2015x.5.1 - IOT FSD - Build path hyperlink- END 
		//DSM (DS) 2015x.5.1 - PDT FSD - START
		public static final String CONSTANT_STRING_RAW = "Raw";
		//DSM (DS) 2015x.5.1 - PDT FSD- END
		//DSM (DS) 2015x.5.1 - Comments to be editable on PLBOM Substitute - START
		public static final String ATTR_COMMENTS = PropertyUtil.getSchemaProperty("attribute_Comments");
		public static final String ATTRIBUTE_TOTAL = PropertyUtil.getSchemaProperty("attribute_Total");
		public static final String ATTRIBUTE_LOSS = PropertyUtil.getSchemaProperty("attribute_Loss");
		//DSM (DS) 2015x.5.1 - Comments to be editable on PLBOM Substitute - END
		//DSM (DS) 2015x.5.1 - Supplier Approval added for DPP and IPP- STARTS
		public static final String ATTR_PG_HIR_COMPLAINT = PropertyUtil.getSchemaProperty("attribute_pgHiRCompliant");
		//DSM (DS) 2015x.5.1 - Supplier Approval added for DPP and IPP - ENDS
		//DSM(DS) 2015x.5.1 ALM 17893 - Default value is Neither for SO3Contributor - Start
		public static final String ATTRIBUTE_SO3_CONTRIBUTOR  = PropertyUtil.getSchemaProperty("attribute_SO3Contributor");
		public static final String CONSTANT_STRING_NEITHER = "Neither";
		//DSM(DS) 2015x.5.1 ALM 17893 - Default value is Neither for SO3Contributor - End
		//DSM (DS) 2015x.5.1- ALM 17486 - Gross Weight UOM can be overridded in custom BOM scren - starts
		public static final String ATTR_PG_PACKAGINGSIZE_UOM = PropertyUtil.getSchemaProperty("attribute_pgPackagingSizeUOM");
		//DSM (DS) 2015x.5.1- ALM 17486 - Gross Weight UOM can be overridded in custom BOM scren - ends
		
		//Added by DSM(DS) 2015X.5.1 - ALM 17212 : INC0972866 - DSM - Functionality - Product Parts - START
		public static final String SELECT_FIRST_REVISION = "first.revision";
		//Added by DSM(DS) 2015X.5.1 - ALM 17212 : INC0972866 - DSM - Functionality - Product Parts - END
		
		//DSM (DS) 2015x.5.1 : 15044 : PDT	Segment Attribute is not populating - START
		public static final String STR_EVENTDELETE = "Delete";
		public static final String STR_EVENT_MODIFYFROM = "ModifyFrom";
		public static final String ATTR_PG_SEGMENT = PropertyUtil.getSchemaProperty("attribute_pgSegment");
		//DSM (DS) 2015x.5.1 : 15044 : PDT	Segment Attribute is not populating - END
		//DSM (DS) 2018x.1.1 Change for Requirement 27572 - Target Wet Weight of Substitutes shall be editable - START
		public static final String COLUMN_TARGETWEIGHT_WET = "Target Wet Weight";
		//DSM (DS) 2018x.1.1 Change for Requirement 27572 - Target Wet Weight of Substitutes shall be editable - END
		//DSM (DS) 2015x.5.1- CR - PDT - Add additional 3 columsn to display Target Wet Weight, Wet WeightsMin and Wet Weight Max - START
		public static final String CONST_TARGETWEIGHT_WET = "TargetWeightWet";
		public static final String CONST_MIN_ACTUAL_WEIGHT_WET = "pgMinimumActualWeightWet";
		public static final String CONST_MAX_ACTUAL_WEIGHT_WET = "pgMaximumActualWeightWet";
		public static final String CONST_MIN_WEIGHT_WET = "WeightWetMin";
		public static final String CONST_MAX_WEIGHT_WET = "WeightWetMax";
		public static final String ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET = PropertyUtil.getSchemaProperty("attribute_pgMinimumActualWeightWet");
		public static final String ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET = PropertyUtil.getSchemaProperty("attribute_pgMaximumActualWeightWet");
		//DSM (DS) 2015x.5.1- CR - PDT - Add additional 3 columsn to display Target Wet Weight, Wet Weight Min and Wet Weight Max - End
		//DSM(DS) 2015x.5.1 - ALM#19831 - EBOMComments doesn't exit error message is displayed when user trying to add a new COP to an existing revised CUP - Start
		public static final String CONST_EBOMCOMMENT = "EBOMComment";
		//DSM(DS) 2015x.5.1 - ALM#19831 - EBOMComments doesn't exit error message is displayed when user trying to add a new COP to an existing revised CUP - End

		//Modified for 2018x Upgrade - All Product data types is using EC Part policy in 18x OOTB. - Start
		public static final String POLICY_EC_PART  = PropertyUtil.getSchemaProperty(SCHEMA_POLICY_EC_PART);
		//Modified for 2018x Upgrade - All Product data types is using EC Part policy in 18x OOTB. - END. 
	 	//DSM (DS) ALM 18991 - unable to Save Rev 002 BOM on PAP -starts
		public static final String ATTR_CHANGE_ID  = PropertyUtil.getSchemaProperty("attribute_ChangeId");
		public static final String INTERFACE_CHANGE_CONTROL  = PropertyUtil.getSchemaProperty("interface_ChangeControl");
		//DSM (DS) ALM 18991 - unable to Save Rev 002 BOM on PAP -ends
		
		//DSM (DS) 2018x.0 FD04 - Added for Pending and Failure View Search Page - Starts
		public static final String REL_PROPOSEDACTIVITIES = PropertyUtil.getSchemaProperty("relationship_ProposedActivities");
		public static final String STR_EQUALS = "Equals";
		public static final String STR_GREATER = "Greater";
		public static final String STR_LESS = "Less";
		public static final String STR_BETWEEN = "Between";
		public static final String FORM_PG_DSM_FAILUREVIEWSEARCHWEBFORM = "pgDSMFailureViewSearchWebForm";
		public static final String CONST_MODIFIED = "modified";
		//DSM (DS) 2018x.0 FD04 - Added for Pending and Failure View Search Page - ENDS
		//Added for 18x Upgrade: Rel Senior Technical Assignee replaced with Change Reviewer STARTS 
		public static final String REL_CHANGE_REVIEWER = PropertyUtil.getSchemaProperty("relationship_ChangeReviewer");
		//Added for 18x Upgrade ENDS
		//DSM(DS) 2018x.0 ALM 20680 Empty list for Manufacturing status when Release Phase is Development - STARTS
		public static final String MANUFACTURING_STATUS_EXPERIMENTAL = "Experimental";
		//DSM(DS) 2018x.0 ALM 20680 - ENDS
		//DSM (DS) 2018x.0 20878 -We are not able to add PLANT on any part. Getting error"The Company on the MEP or SEP should be HiR Complaint. -Start
		public static final String TYPE_PLANT = PropertyUtil.getSchemaProperty("type_Plant");
		//DSM (DS) 2018x.0 20878 -We are not able to add PLANT on any part. Getting error"The Company on the MEP or SEP should be HiR Complaint. -End

		//DH 2018x - Changes for Merging "Production Product Data" policy to "EC Part" Policy - Starts
		public static final String POLICY_EC_PART_STATE_APPROVED_PROMOTE_ACTION = "PGDSMPolicyECPartStateApprovedPromoteAction";
		//DH 2018x - Changes for Merging "Production Product Data" policy to "EC Part" Policy - Ends
		//DSM(DS) 2018x.0 ALM- 21578 The value of Characteristic Specifics column for PC table cannot be selected- start
		public static final String REL_CHARACTERISTICTOCHARACTERISTICSPECIFICS = PropertyUtil.getSchemaProperty("relationship_pgCharateristicToCharateristicSpecifics");
		//DSM(DS) 2018x.0 ALM- 21578 The value of Characteristic Specifics column for PC table cannot be selected- End
		//DSM (DS) 2018x.0 FD05 ALM 22763 - Fail to create new SEP using Mass Create MEP SEP with same Vendor - STARTS
		public static final String STRING_CONST_ISMASSMEPSEP = "isMassMEPSEP";
		//DSM (DS) 2018x.0 FD05 ALM 22763 - Fail to create new SEP using Mass Create MEP SEP with same Vendor - ENDS
		//Added by DSM(Sogeti) for 2015x.5.1 Nov (Defect #22442) - Starts
		public static final String TYPE_RDLAB = PropertyUtil.getSchemaProperty("type_RDLab");
		public static final String RELATIONSHIP_ALLOCATIONRESPONSIBILITY = PropertyUtil.getSchemaProperty("relationship_AllocationResponsibility");
		//Added by DSM(Sogeti) for 2015x.5.1 Nov (Defect #22442) - Ends
		//DSM (DS) 2018x.0 ALM 23273 - Cannot stage RMP fields on BOM when first added - start
		public static final String STR_PG_MAX_ACTUAL_PERCENT_WET = "pgMaxActualPercenWet";
		public static final String STR_PG_MIN_ACTUAL_PERCENT_WET = "pgMinActualPercenWet";
		public static final String STR_PG_NET_WEIGHT_UOM = "pgNetWeightUnitOfMeasure";
		//DSM (DS) 2018x.0 ALM 23273 - Cannot stage RMP fields on BOM when first added - ends
		//DSM(DS) 2018x.0 - Fix for ALM 23425 - [TC] CA's owner changed back to originator not the transferred owner after CA task was rejected by SO - START
		public static final String RELATIONSHIP_TECHNICAL_OWNER = PropertyUtil.getSchemaProperty("relationship_pgTechnicalOwner");
		//DSM(DS) 2018x.0 - Fix for ALM 23425 - [TC] CA's owner changed back to originator not the transferred owner after CA task was rejected by SO - END
		//DSM (DS) 2018x.0  FD05 ALM 24018 - user unable  to delete CUP number - starts
		public static final String CONST_APPEND_OR = " OR : ";
		//DSM (DS) 2018x.0  FD05 ALM 24018 - user unable  to delete CUP number - ends
		//DSM (DS) 2018x.0 ALM 24138 - Not able to add the FOP under COP -starts
		public static final String FORMULATION_PART_EXPERIMENTAL_RELEASEPHASE = "Experimental";
		//DSM (DS) 2018x.0 ALM 24138 - Not able to add the FOP under COP -Ends
		//DSM (DS) 2018x.0 ALM 24428 - Clone transfer to Formulation failed -starts
		public static final String REL_REALIZEDACTIVITIES = PropertyUtil.getSchemaProperty("relationship_RealizedActivities");
		//DSM (DS) 2018x.0 ALM 24428 - Clone transfer to Formulation failed -ends
		
		public static final String STR_BASEUOM = "BaseUOM";
		
		//DSM (DS) 2018x.1 Added for PDT FSD - REQ#21958 - Multiple TDs-DSM:The System shall enable the User to select the Related Specification containing the Technical Drawing file for the BVE on the PMP/OPP  - Start
		public static final String ATTR_PG_ARTWORK_PRIMARY = PropertyUtil.getSchemaProperty("attribute_pgArtworkPrimary");
		//DSM (DS) 2018x.1 Added for PDT FSD - REQ#21958 - Multiple TDs-DSM:The System shall enable the User to select the Related Specification containing the Technical Drawing file for the BVE on the PMP/OPP - End
		//DSM (DS) 2018x.1 FD05 GPS Assessment SMART EXIT - starts
		public static final String PO_BABY_CARE_GLOBAL = "Baby Care~GLOBAL";
		public static final String PO_FEMININE_CARE_GLOBAL = "Feminine Care~GLOBAL";
		public static final String CONST_CERTIFICATION = "Certification";
		public static final String CONST_AEROSOL = "Aerosol";
		public static final String CONST_SPRAY = "Spray";
		public static final String CONST_PARTICLE_SIZE_DISTRIBUTION_DATA = "Particle Size Distribution"; 
		public static final String ATTR_PG_PKG_DEVELOPMENTTYPE = PropertyUtil.getSchemaProperty("attribute_pgPKGDevelopmentType");;
		public static final String REL_PG_LEG_PROCESS = PropertyUtil.getSchemaProperty("relationship_pgLegProcess");
		public static final String REL_PG_STUDY_LEG = PropertyUtil.getSchemaProperty("type_pgStudyLeg");
		public static final String REL_PG_LEG_INPUT = PropertyUtil.getSchemaProperty("relationship_pgLegInput");
		public static final String ATTR_PG_ALTERNATEDOSAGEAPPLICABLE = PropertyUtil.getSchemaProperty("attribute_pgAlternateDosageapplicable");
		public static final String CONST_ALTERNATE_USAGE_INSTRUCTIONS = "Alternate Usage Instructions";
		public static final String CONST_DOM_GPSTASKOBJ = "domGPSTaskObj";
		public static final String CONST_SUBTYPE = "SubType";
		public static final String FORMAT_MX_MEDIUM_IMAGE = PropertyUtil.getSchemaProperty("format_mxMediumImage");
		public static final String FORMAT_RENDERING = PropertyUtil.getSchemaProperty("format_JView");
			public static final String CONSTANT_SALESQUANTITYUOM = "SalesQuantityUoM";
			public static final String CONSTANT_SIMILARANDCLEAREDPRODUCT = "SimilarAndClearedProduct";
			public static final String ATTRIBUTE_PGSALESQUANTITYUOM = PropertyUtil.getSchemaProperty("attribute_pgSalesQuantityUoM");
			public static final String ATTRIBUTE_PGSIMILARANDCLEAREDPRODUCT = PropertyUtil.getSchemaProperty("attribute_pgSimilarAndClearedProduct");
			public static final String ATTRIBUTE_PG_PACKAGESIZE_SAMEAS_CURRENTMARKET = PropertyUtil.getSchemaProperty("attribute_pgPackageSizeSameAsCurrentMarket");
			
			public static final String ATTR_MANUFACTURER = PropertyUtil.getSchemaProperty("attribute_Manufacturer");
			public static final String CONST_NO_SUPPLIER_SPECIFIED = "No Supplier Specified";
			public static final String  STR_A3B = "A3b";
			public static final String CONST_VIEW_CAPS = "View";
			public static final String CONST_EDIT_CAPS = "Edit";
			public static final String STR_FIELDNAME = "fieldName";
		//DSM (DS) 2018x.1 FD05 GPS Assessment SMART EXIT - ends
		//DSM (DS) 2018x.1 Req 27241 - Replace Product By Product ID field - STARTS
		public static final String ATTRIBUTE_PGREPLACEDBYPRODUCTID = PropertyUtil.getSchemaProperty("attribute_pgReplacedByProductID"); 
		//DSM (DS) 2018x.1 Req 27241 - Replace Product By Product ID field - END
		//DSM(DS) 2018x.1 - Req 25896 Product Form Set as Mandatory Attribute for Prodn and pilot release phase - start
		public static final String CONST_PRODUCTFORMFORFOPPRODN = "ProductFormForFOPProd";
		public static final String CONST_PRODUCTFORMFORFOPEXP = "ProductFormForFOPExp";
		public static final String CONST_PRODUCTFORM = "ProductForm";
		public static final String CONST_PLATFORM = "Platform";
		//DSM(DS) 2018x.1 - Req 25896 Product Form Set as Mandatory Attribute for Prodn and pilot release phase - end
		//DSM (DS) 2018x.1 Req 26725,25920 - Business Area in storage page for PDP - START
		public static final String CONST_BUSINESSAREA = "BusinessArea";
		public static final String CONST_PRODUCTCATEGORYPLATFORM = "Product Category Platform";
	    public static final String RELATIONSHIP_PGDOCUMENT_TO_BUSINESSAREA = PropertyUtil.getSchemaProperty("relationship_pgDocumentToBusinessArea");
	    public static final String TYPE_PG_PLI_BUSINESSAREA=PropertyUtil.getSchemaProperty("type_pgPLIBusinessArea");
		//DSM (DS) 2018x.1 Req 26725,25920 - Business Area in storage page for PDP - END
		//DSM(DS) 2018x.0 ALM 24555 - Critical Issue - To show Shared collections in Search refinements - start
		public static final String STRING_SHARED = "SHARED";
		//DSM(DS) 2018x.0 ALM 24555 - Critical Issue - To show Shared collections in Search refinements - End
		//DSM(DS) 2018x.1 - ALM 24537 - Disconnect Implemented Items from Change Action - Start
		public static final String SELECT_PREVIOUS_REVISION_PHYSICALID = "previous.physicalid";
		public static final String ATTRIBUTE_PROPOSED_OPERATION = PropertyUtil.getSchemaProperty("attribute_ProposedOperation");
		public static final String ATTRIBUTE_PROPOSED_ACTIVITY_STATUS = PropertyUtil.getSchemaProperty("attribute_ProposedActivityStatus");
		public static final String INTERACE_CHANGE_CONTROL = PropertyUtil.getSchemaProperty("interface_ChangeControl");
		public static final String PATH_REALIZED_ACTIVITY_AFTER = "Realized Activity.After" ;
		public static final String PATH_PROPOSED_ACTIVITY_WHERE = "Proposed Activity.Where" ;
		public static final String CMD_CA_IMPLEMENTED_ITEMS = PropertyUtil.getSchemaProperty("command_ECMCAImplementedItems") ;
		//DSM(DS) 2018x.1 - ALM 24537 - Disconnect Implemented Items from Change Action - End
		
		public static final String CONSTANT_STRING_TYPE_ARTIOSCADCOMPONENT = "type_ArtiosCADComponent";
	    public static final String CONSTANT_STRING_TYPE_VPMREFERENCE = "type_VPMReference";
	  //DSM (DS) 2018x.1 - ALM 22933 - All copies should have only one CO - START
	    public static final String CONSTANT_STRING_CREATENEWCO = "Create New CO";
	    public static final String CONSTANT_STRING_ADDEXISTINGCO = "Add Existing CO";
	  //DSM (DS) 2018x.1 - ALM 22933 - All copies should have only one CO - END
	  //DSM (DS) 2018x.1 ALM 25863 GPS Task Input IRM docs that are Preliminary State can be submitted to GPS. - STARTS
		public static final String POLICY_PG_SELFAPPROVALDOC= PropertyUtil.getSchemaProperty("policy_pgSelfApproval");
		//DSM (DS) 2018x.1 ALM 25863 GPS Task Input IRM docs that are Preliminary State can be submitted to GPS. - ENDS
		//DSM(DS) 2018x.1.1 - UFI Attribute reset on copy needs to be transferred from Clone to Base Part - Start
		public static final String ATTRIBUTE_PG_UNIQUE_FORMULA_IDENTIFIER = PropertyUtil.getSchemaProperty("attribute_pgUniqueFormulaIdentifier");
		//DSM(DS) 2018x.1.1 - UFI Attribute reset on copy needs to be transferred from Clone to Base Part - End
		
		//DSM(DS) 2018x.1.1  - Req 25900 - Change field Product Category Platform Mandatory for Pilot and Production Phase - START
		public static final String CONST_PGPLATFORMCATEGORY_PRODUCTCATEGORYPLATFORM = "Product Category Platform";
		//DSM(DS) 2018x.1.1  - Req 25900 - Change field Product Category Platform Mandatory for Pilot and Production Phase - END
		//DSM(DS)2018x.1.1 - 25041,25042 FSD - Parallel Clone - clone owner is missing access on new base part when transfer is initiated from coowner of clone - START
	    public static final String STRING_PRJ = "_PRJ";
	    public static final String STRING_ALL = "All";
	  //DSM(DS)2018x.1.1 - 25041,25042 FSD - Parallel Clone - clone owner is missing access on new base part when transfer is initiated from coowner of clone - END
	  
	  // Added by DSM(Sogeti) 2018x.1.1 for Product Structure Copy --- Starts
	  	public static final String RELATIONSHIP_RELATED_PROJECTS = PropertyUtil.getSchemaProperty("relationship_RelatedProjects");
	  // Added by DSM(Sogeti) 2018x.1.1 for Product Structure Copy --- Ends
	  	// DSM (DS) 2018x.1.1 ALM 27007 User is able to edit "Artwork Primary" flag on the "Master Specifications" tab of the reference part - START
	  	public static final String TABLE_MASTER_SPEC = PropertyUtil.getSchemaProperty("table_pgVPDAPPDocumentSummary");
	 // DSM (DS) 2018x.1.1 ALM 27007 User is able to edit "Artwork Primary" flag on the "Master Specifications" tab of the reference part - ENDS
	 //DSM (DS) 2018x.1.1 - Req 28651 - Formulation Formulation Process Part revision check - START
	  	public static final String CONST_AND = "and";
	  	public static final String WHERE_REVISION_LAST = "revision==last";
	  	//DSM (DS) 2018x.1.1 - Req 28651 - Formulation Formulation Process Part revision check - END
		//DSM (DS) 2018x.1.1 - 26821 - Allow non editable field for pgPreviousRevisionObsoleteDate - START
	  	public static final String CONSTANT_EXPERIMENTAL_FIRST_REV = "A";
	  	public static final String CONSTANT_PRODUCTION_FIRST_REV = "001";
	  	//DSM (DS) 2018x.1.1 - 26821 - Allow non editable field for pgPreviousRevisionObsoleteDate - END
	  //DSM (DS) 2018x1.1 ALM 27481 INC3616342 - Parts/Specs with 3 CAs caused the released parts to be demoted instead of revising them - STARTS
	  	public static final String ATTR_REQUESTEDCHG_UPDATE_VALUE = "For Update";
	  //DSM (DS) 2018x1.1 ALM 27481 INC3616342 - Parts/Specs with 3 CAs caused the released parts to be demoted instead of revising them - ENDS
	  	//DSM(DS) 2018x.2.0 FSD - Smart label - The system shall have an object called Smart Label - Start
	  	public static final String ATTR_PG_SMARTLABEL_SUBTYPE = PropertyUtil.getSchemaProperty("attribute_pgSmartLabelSubType");
	  	public static final String REL_PG_SMART_LABEL  = PropertyUtil.getSchemaProperty("relationship_pgSmartLabel");
	  	public static final String TYPE_PG_SMART_LABEL = PropertyUtil.getSchemaProperty("type_pgSmartLabel");
	  	public static final String REL_PG_SMART_LABEL_ROW  = PropertyUtil.getSchemaProperty("relationship_pgSmartLabelRow");
	  	public static final String TYPE_PG_SMART_LABEL_ROW = PropertyUtil.getSchemaProperty("type_pgSmartLabelRow");
	  	//DSM(DS) 2018x.2.0 FSD - Smart label - The system shall have an object called Smart Label - End
	//DSM(DS) 2018x.2.0 FSD - PDT REQId 25589 - DG-Dangerous Goods Classification shall be linked only to APP,DPP and FOP - Start
	  //DSM(DS) 2018x.2.0 FSD - PDT REQId 25589 - DG-Dangerous Goods Classification shall be linked only to APP,DPP and FOP - End
	  //DSM(DS) 2018x.2 - Material Certification FSD - Certification Claims on Product - START
	  	public static final String REL_PG_PLI_MATERIAL_CERTIFICATIONS = PropertyUtil.getSchemaProperty("relationship_pgPLIMaterialCertifications");
	  	public static final String TYPE_PG_PLI_MATERIAL_CERTIFICATIONS = PropertyUtil.getSchemaProperty("type_pgPLIMaterialCertifications");
		public static final String REL_PG_MEP_SEP_CERTIFICATION = PropertyUtil.getSchemaProperty("relationship_pgMEPSEPCertification");
	  	public static final String REL_PG_COUNTRIESCERTIFICATIONCLAIMED = PropertyUtil.getSchemaProperty("relationship_pgCountriesCertificationClaimed");
	  	public static final String TYPE_PG_PLICOUNTRY = PropertyUtil.getSchemaProperty("type_pgPLICountry");
	  //DSM(DS) 2018x.2 - Material Certification FSD - Certification Claims on Product - START
	  //DSM(DS) 2018x.2 : Material Composition FSD - Req 14811 - added constant for trigger copy event -Start
		public static final String STRING_CAP_COPY = "Copy";
	  //DSM(DS) 2018x.2 : Material Composition FSD - Req 14811 - added constant for trigger copy event -End
	  //DSM(DS) 2018x.2.0 FSD - PDT REQId 25589 - DG-Dangerous Goods Classification shall be linked only to APP,DPP and FOP - Start
	  	public static final String REL_PG_DANGEROUS_GOODS  = PropertyUtil.getSchemaProperty("relationship_pgDangerousgoods");
	  	public static final String TYPE_PG_DANGEROUS_GOODS = PropertyUtil.getSchemaProperty("type_pgDangerousgoods");
	  	public static final String ATTR_PG_SHIPMENT_LIMITED_QUANTITY = PropertyUtil.getSchemaProperty("attribute_pgShipmentLimitedQuantity");
	  	public static final String ATTR_PG_CONSUMER_WEIGHT_VOLUME = PropertyUtil.getSchemaProperty("attribute_pgConsumerWeightVolume");
	  	public static final String ATTR_PG_CUSTOMER_WEIGHT_VOLUME = PropertyUtil.getSchemaProperty("attribute_pgCustomerWeightVolume");
	  	public static final String ATTR_PG_DG_LABEL_REQUIREMENTS = PropertyUtil.getSchemaProperty("attribute_pgDGLabelRequirements");
	  	public static final String ATTR_PG_DG_LABELCOP_REQUIREMENT = PropertyUtil.getSchemaProperty("attribute_pgDGCOPLabelRequired");
	  	public static final String ATTR_PG_DG_LABELCUP_REQUIREMENT = PropertyUtil.getSchemaProperty("attribute_pgDGCUPLabelRequired");
	  	public static final String REL_PG_HAZARD_CLASS  = PropertyUtil.getSchemaProperty("relationship_pgHazardClass");
	  	public static final String REL_PG_PACKING_GROUP  = PropertyUtil.getSchemaProperty("relationship_pgPackingGroup");
	  	public static final String TYPE_PG_PLI_HAZARD_CLASS = PropertyUtil.getSchemaProperty("type_pgPLIHazardClass");
	  	public static final String TYPE_PG_PLI_PACKING_GROUP = PropertyUtil.getSchemaProperty("type_pgPLIPackingGroup");
	  //DSM(DS) 2018x.2.0 FSD - PDT REQId 25589 - DG-Dangerous Goods Classification shall be linked only to APP,DPP and FOP - End  
	  //DSM(DS) 2018x.2 - Req 26671 - Warehouse classification for DPP with flammable liquid - START
	  	public static final String ATTRIBUTE_PG_DOESDEVICECONTAINFLAMMABLELIQUID = PropertyUtil.getSchemaProperty("attribute_pgDoesDeviceContainFlammableLiquid");
	  	public static final String RANGE_VALUE_LIQUIDWITHFLASHPOINTLT93 = "Liquid with Flashpoint  <93 deg C (200 deg F)";
	  	public static final String RANGE_VALUE_NOSPECIALSTORAGEREQUIRED = "No Special Storage Required";
	  	//DSM(DS) 2018x.2 -  PDT FSD Replace Product Form name with picklist attribute value - START
	  	public static final String ATTRIBUTE_PG_PRODUCTFORMPROPERTY = PropertyUtil.getSchemaProperty("attribute_pgProductFormProperty");
	  	//DSM(DS) 2018x.2 -  PDT FSD Replace Product Form name with picklist attribute value - END
	  	//DSM(DS) 2018x.2 - Req 26671 - Warehouse classification for DPP with flammable liquid - END
	  	//DSM (DS) 2018x.2 - Req 26663,26665,26667,26761,28997 - Condition to set warehouse classification on FOP -  Age Condition Material Rules - START
	  	public static final String ATTRIBUTE_PG_CANCONSTURCTION = PropertyUtil.getSchemaProperty("attribute_pgCanConstruction");
	  	public static final String ATTRIBUTE_PG_HEATOFCOMBUSTION = PropertyUtil.getSchemaProperty("attribute_pgHeatOfCombustion");
	  	public static final String ATTRIBUTE_PG_FLAMMABLEORNONFLAMMABLE = PropertyUtil.getSchemaProperty("attribute_pgFlammableOrNonFlammable");
	  	public static final String ATTRIBUTE_PG_DOESTHEBASEPRODUCTCONTAINETHANOLPLUSISOPROPANOL = PropertyUtil.getSchemaProperty("attribute_pgDoesTheBaseProductContainEthanolPlusISOPropanol");
	  	public static final String ATTRIBUTE_PG_DOESBASEPRODUCTSUSTAINCOMBUSTION = PropertyUtil.getSchemaProperty("attribute_pgDoesBaseProductSustainCombustion");
	  	public static final String ATTRIBUTE_PG_DOESBASEPRODUCTHAVEAFIREPOINT = PropertyUtil.getSchemaProperty("attribute_pgDoesBaseProductHaveAFirePoint");
	  	public static final String ATTRIBUTE_PG_DOESBASEPRODUCTCONTAINEMULSIFIEDLIQUEFIEDNONFLAMMABLEGASPROPELLANT = PropertyUtil.getSchemaProperty("attribute_pgDoesBaseProductContainEmulsifiedLiquefiedNonFlammableGasPropellant");
	  	public static final String ATTRIBUTE_PG_PERCENTBYWEIGHTOFFLAMMABLEPROPELLANTINAEROSOLCONTAINER = PropertyUtil.getSchemaProperty("attribute_pgPercentByWeightOfFlammablePropellantInAerosolContainer");
	  	public static final String ATTRIBUTE_PG_DOESBASEPRODUCTCONTAINBYVOLUMEWATERMISCIBLEALCOHOLS = PropertyUtil.getSchemaProperty("attribute_pgDoesBaseProductContainByVolumeWaterMiscibleAlcohols");
	  	public static final String ATTRIBUTE_PG_DOESBASEPRODUCTCONTAINEMULSIFIEDLIQUEFIEDFLAMMABLEGASPROPELLANT = PropertyUtil.getSchemaProperty("attribute_pgDoesBaseProductContainEmulsifiedLiquefiedFlammableGasPropellant");
	  	public static final String ATTRIBUTE_PG_CLOSEDCUPFLASHPOINT = PropertyUtil.getSchemaProperty("attribute_pgClosedCupFlashpoint");
	  	//DSM (DS) 2018x.2 - Req 26663,26665,26667,26761,28997 - Condition to set warehouse classification on FOP -  Age Condition Material Rules - END
		//DSM(DS) 2018x.2 -  PDT FSD - Chemical Properties Page Changes - START
		public static final String ATTRIBUTE_PG_DOESTHISDEVICECONTAINFLAMMABLELIQUID = PropertyUtil.getSchemaProperty("attribute_pgDoesThisDeviceContainFlammableLiquid");
	  	public static final String ATTRIBUTE_PG_WAREHOUSINGCLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pgWarehousingClassification");
	  	//DSM(DS) 2018x.2 - Req 26671 - Warehouse classification for DPP with flammable liquid - END
		//DSM(DS) 2018x.2 - Req 28955,28958 -The RMP Product Category Platform attribute value shall default to "See Assessment in GPS System".  The RMP Function attribute shall have default value "See Assessment in GPS System" for all Part Phases- START
		public static final String TYPE_PG_PLI_PLATFORM = PropertyUtil.getSchemaProperty("type_pgPLIPlatform");
		public static final String RANGE_VALUE_SEE_ASSESSMENT_IN_GPS = "See Assessment in GPS System";
		//DSM(DS) 2018x.2 - Req 28955,28958 -The RMP Product Category Platform attribute value shall default to "See Assessment in GPS System".  The RMP Function attribute shall have default value "See Assessment in GPS System" for all Part Phases- END
	  	//DSM (DS) 2018x.2 - Req 26663,26665,26667,26761,28997 - Condition to set warehouse classification on FOP -  Age Condition Material Rules - START
	  	public static final String ATTRIBUTE_PG_CLOSEDCUPFLASHPOINTVALUE = PropertyUtil.getSchemaProperty("attribute_pgClosedCupFlashpointValue");
	  	public static final String CONST_LIQUID = "Liquid";
	  	public static final String CONST_SOLID = "Solid";
	  	public static final String CONST_METAL = "Metal";
	  	public static final String CONST_PLASTIC = "Plastic";
	  	public static final String CONST_UNKNOWN = "Unknown";
	  	public static final String STRING_FLAMMABLE = "flammable";
	  	public static final String STRING_NONFLAMMABLE = "nonflammable";
	  	public static final String STRING_OTHER = "Other";
	  	public static final String STRING_NOFLASHTOBOIL= "No Flash To Boil";
		//DSM(DS) 2018x.2 - ALM - 28952 - [26761]WC set to FOP is not 'No Special Storage Required - Starts
	  	//public static final String STRING_GREATERTHAN93C = ">93 C";
		public static final String STRING_GREATERTHAN93C = "> 93 C";
		//DSM(DS) 2018x.2 - ALM - 28952 - [26761]WC set to FOP is not 'No Special Storage Required -  Ends 
	  	public static final String RANGE_VALUE_LEVELONEAEROSOL = "Level 1 Aerosol";
	  	public static final String RANGE_VALUE_LEVELTWOAEROSOL = "Level 2 Aerosol";
	  	public static final String RANGE_VALUE_LEVELTHREEAEROSOL = "Level 3 Aerosol";
	  	public static final String RANGE_VALUE_PLASTICAEROSOLONE = "Plastic Aerosol 1";
	  	public static final String RANGE_VALUE_PLASTICAEROSOLTHREE = "Plastic Aerosol 3";
	  	public static final String RANGE_VALUE_PLASTICAEROSOLX = "Plastic Aerosol X";
	  	public static final String TYPE_PL_WAREHOUSECLASSIFICATION = PropertyUtil.getSchemaProperty("type_pgPLIWarehousingClassification");
	  	public static final String REL_PL_WAREHOUSECLASSIFICATION = PropertyUtil.getSchemaProperty("relationship_pgToWarehousingClassification");
			public static final String ATTRIBUTE_PG_BOILINGPOINT = PropertyUtil.getSchemaProperty("attribute_pgBoilingPoint");
		    public static final String ATTRIBUTE_PG_PRODUCTOXIDIZER = PropertyUtil.getSchemaProperty("attribute_pgProductOxidizer");
		    public static final String ATTRIBUTE_PG_OXIDIZERSODIUMPERCORBONATE = PropertyUtil.getSchemaProperty("attribute_pgOxidizerSodiumPerCarbonate");
		    public static final String ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE = PropertyUtil.getSchemaProperty("attribute_pgOxidizerHydrogenPeroxide");
		    public static final String ATTRIBUTE_PG_ORGANICPEROXIDE = PropertyUtil.getSchemaProperty("attribute_pgOrganicPeroxide");
		    public static final String ATTRIBUTE_PG_PHAVALABILITY = PropertyUtil.getSchemaProperty("attribute_pgPHAvailability");
		    public static final String STRING_VALUE_AVAILABLE = "Value available";
		    public static final String ATTRIBUTE_PG_PH = PropertyUtil.getSchemaProperty("attribute_pgPH");
		    public static final String ATTRIBUTE_PG_AEROSOLCANCORROSIVETOMETAL = PropertyUtil.getSchemaProperty("attribute_pgAerosolCanCorrosiveToMetals");
		    public static final String ATTRIBUTE_PG_FLAMMABLELIQUIDABSORBEDORCONTAINEDWITHSOLID = PropertyUtil.getSchemaProperty("attribute_pgFlammableLiquidAbsorbedOrContainedWithInTheSolid");
		    public static final String ATTRIBUTE_PG_PRODUCTHAVEANYSELFREACTIVEPROPERTIES = PropertyUtil.getSchemaProperty("attribute_pgProductHaveAnySelfReactiveProperties");
		    public static final String PG_LIQUIDCORROSIVETOMETAL = PropertyUtil.getSchemaProperty("attribute_pgLiquidCorrosiveToMetal");
		    public static final String PG_ISAEROSOLTESTDATANEEDED = PropertyUtil.getSchemaProperty("attribute_pgIsAerosolTestDataNeeded");
		    public static final String PG_AEROSOLTYPE = PropertyUtil.getSchemaProperty("attribute_pgAerosolType");
		  	public static final String RANGE_VALUE_YESALLOTHERS = "Yes, All Others";
		  	public static final String RANGE_VALUE_FOAM = "Foam";
		  	public static final String RANGE_VALUE_SPRAY = "Spray";
		  	public static final String CONST_PRODUCTTECHNOLOGYPLATFORM = "Product Technology Platform";
		  	public static final String STRING_HOMECARE = "Home Care";
		  	public static final String STRING_AIRCARECONTINUOUS = "Air Care - Continuous";
		  	public static final String STRING_WICKS = "Wicks";
		  	public static final String STRING_MEMBRANE = "Membrane";
		    public static final String ATTRIBUTE_PG_COLOR = PropertyUtil.getSchemaProperty("attribute_pgColor");
		    public static final String ATTRIBUTE_PG_PHVALUE = PropertyUtil.getSchemaProperty("attribute_pgPHValue");
		    public static final String ATTRIBUTE_PG_VAPORPRESSURE = PropertyUtil.getSchemaProperty("attribute_VaporPressure");
		  	public static final String CONST_ATTR_PG_COLOR = "attribute_pgColor";
		  	public static final String CONST_ATTR_PG_COLORINTENSITY = "attribute_pgColorIntensity";
		  	public static final String CONST_ATTR_PG_RELATIVEDENSITYSPECIFICGRAVITY = "attribute_pgRelativeDensity/SpecificGravity";
		  	public static final String CONST_ATTR_PG_ODOUR = "attribute_Odour";
		  	public static final String CONST_ATTR_PG_PH = "attribute_pgPH";
		  	public static final String CONST_ATTR_PG_PHAVAILABILITY = "attribute_pgPHAvailability";
		  	public static final String CONST_ATTR_PG_PRODUCTOXIDIZER = "attribute_pgProductOxidizer";
		  	public static final String CONST_ATTR_PG_OXIDIZERSODIUMPERCARBONATE = "attribute_pgOxidizerSodiumPerCarbonate";
		  	public static final String CONST_ATTR_PG_RESERVEALKALINITY = "attribute_pgReserveAlkalinity";
		  	public static final String CONST_ATTR_PG_RESERVEACIDITY = "attribute_pgReserveAcidity";
		  	public static final String CONST_ATTR_PG_HEATOFCOMBUSTION = "attribute_pgHeatOfCombustion";
		  	public static final String CONST_ATTR_PG_GAUGEPRESSURE = "attribute_pgGaugePressure";
		  	public static final String CONST_ATTR_PG_AEROSOLTYPE = "attribute_pgAerosolType";
		  	public static final String CONST_ATTR_PG_ISAEROSOLTESTDATANEEDED = "attribute_pgIsAerosolTestDataNeeded";
		  	public static final String CONST_ATTR_VAPORDENSITY = "attribute_VaporDensity";
		  	public static final String CONST_ATTR_PG_AEROSOLCANCORROSIVETOMETALS = "attribute_pgAerosolCanCorrosiveToMetals";
		  	public static final String CONST_ATTR_PG_AEROSOLCONDUCTIVITYOFTHECONTENTS = "attribute_pgAerosolConductivityOfTheContents";
		  	public static final String CONST_ATTR_PG_TECHNICALBASISFORTHECORROSIVETOMETALS = "attribute_pgTechnicalBasisForTheCorrosiveToMetals";
		  	public static final String CONST_ATTR_PG_DOESBASEPRODUCTCONTAINEMULSIFIEDLIQUEFIEDFLAMMABLEGASPROPELLANT = "attribute_pgDoesBaseProductContainEmulsifiedLiquefiedFlammableGasPropellant";
		  	public static final String CONST_ATTR_PG_DOESBASEPRODUCTCONTAINEMULSIFIEDLIQUEFIEDNONFLAMMABLEGASPROPELLANT = "attribute_pgDoesBaseProductContainEmulsifiedLiquefiedNonFlammableGasPropellant";
		  	public static final String CONST_ATTR_PG_DOESBASEPRODUCTHAVEAFIREPOINT = "attribute_pgDoesBaseProductHaveAFirePoint";
		  	public static final String CONST_ATTR_PG_DOESBASEPRODUCTSUSTAINCOMBUSTION = "attribute_pgDoesBaseProductSustainCombustion";
		  	public static final String CONST_ATTR_PG_PGDOESTHEBASEPRODUCTCONTAINETHANOLPLUSISOPROPANOL = "attribute_pgDoesTheBaseProductContainEthanolPlusISOPropanol";
		  	public static final String CONST_ATTR_PG_DOESBASEPRODUCTCONTAINBYVOLUMEWATERMISCIBLEALCOHOLS = "attribute_pgDoesBaseProductContainByVolumeWaterMiscibleAlcohols";
		  	public static final String CONST_ATTR_PG_PERCENTBYWEIGHTOFFLAMMABLEPROPELLANTINAEROSOLCONTAINER = "attribute_pgPercentByWeightOfFlammablePropellantInAerosolContainer";
		  	public static final String CONST_ATTR_PG_FLAMMABLEORNONFLAMMABLE = "attribute_pgFlammableOrNonFlammable";
		  	public static final String CONST_ATTR_PG_FLAMEDURATION = "attribute_pgFlameDuration";
		  	public static final String CONST_ATTR_PG_FLAMEHEIGHT = "attribute_pgFlameHeight";
		  	public static final String CONST_ATTR_PG_IGNITIONDISTANCE = "attribute_pgIgnitionDistance";
		  	public static final String CONST_ATTR_PG_ENCLOSEDSPACEIGNITION = "attribute_pgEnclosedSpaceIgnition";
		  	public static final String CONST_ATTR_PG_VAPORPRESSURE = "attribute_VaporPressure";
		  	public static final String CONST_ATTR_PG_BOILINGPOINT = "attribute_pgBoilingPoint";
		  	public static final String CONST_ATTR_PG_CLOSEDCUPFLASHPOINT = "attribute_pgClosedCupFlashpoint";
		  	public static final String CONST_ATTR_PG_KINEMATICVISCOSITY = "attribute_pgKinematicViscosity";
		  	public static final String CONST_ATTR_PG_LIQUIDCORROSIVETOMETAL = "attribute_pgLiquidCorrosiveToMetal";
		  	public static final String CONST_ATTR_PG_EVAPORATIONRATE = "attribute_pgEvaporationRate";
		  	public static final String CONST_ATTR_PG_CLOSEDCUPFLASHPOINTVALUE = "attribute_pgClosedCupFlashpointValue";
		  	public static final String CONST_ATTR_PG_BOILINGPOINTVALUE = "attribute_pgBoilingPointValue";
		  	public static final String CONST_ATTR_PG_PRODUCTSUSTAINCOMBUSTION = "attribute_pgProductSustainCombustion";
		  	public static final String CONST_ATTR_PG_FLAMMABLELIQUIDABSORBEDORCONTAINEDWITHINTHESOLID = "attribute_pgFlammableLiquidAbsorbedOrContainedWithInTheSolid";
		  	public static final String CONST_ATTR_PG_PRODUCTHAVEANYSELFREACTIVEPROPERTIES = "attribute_pgProductHaveAnySelfReactiveProperties";
		  	public static final String CONST_ATTR_PG_BURNRATE = "attribute_pgBurnRate";
		  	public static final String CONST_ATTR_PG_HEATOFDECOMPOSITION = "attribute_pgHeatofDecomposition";
		  	public static final String CONST_ATTR_PG_SELFACCELERATINGDECOMPOSITIONTEMPERATURE = "attribute_pgSelfAcceleratingDecompositionTemperature";
		  	public static final String CONST_ATTR_PG_PHVALUE = "attribute_PHValue";
		  	public static final String CONST_ATTR_PG_OXIDIZERHYDROGENPEROXIDE = "attribute_pgOxidizerHydrogenPeroxide";
		  	public static final String CONST_ATTR_PG_PRODUCTPOTENTIALTOINCREASEBURNINGRATE = "attribute_pgProductPotentialToIncreaseBurningRate";
		  	public static final String CONST_ATTR_PG_ORGANICPEROXIDE = "attribute_pgOrganicPeroxide";
		  	public static final String CONST_ATTR_PG_AVAILABLEOXYGENCONTENT = "attribute_pgAvailableOxygenContent";
		  	public static final String CONST_ATTR_PG_PHDILUTION = "attribute_pgPHDilution";
		  	//DSM(DS) 2018x.2 -  PDT FSD - Chemical Properties Page Changes - END
		  	
		  	
		  	public static final String ATTRIBUTE_PG_BOILINGPOINTVALUE = PropertyUtil.getSchemaProperty("attribute_pgBoilingPointValue");
		  	public static final String ATTRIBUTE_PG_PRODUCTSUSTAINCOMBUSTION = PropertyUtil.getSchemaProperty("attribute_pgProductSustainCombustion");
		  	public static final String ATTRIBUTE_PG_PRODUCTPOTENTIALTOINCREASEBURNINGRATE = PropertyUtil.getSchemaProperty("attribute_pgProductPotentialToIncreaseBurningRate");
		  	public static final String ATTRIBUTE_PG_AVAILABLEOXYGENCONTENT = PropertyUtil.getSchemaProperty("attribute_pgAvailableOxygenContent");
		  	public static final String ATTRIBUTE_PG_PHDILUTION = PropertyUtil.getSchemaProperty("attribute_pgPHDilution");
		  	public static final String ATTRIBUTE_PG_RESERVEALKALINITY = PropertyUtil.getSchemaProperty("attribute_pgReserveAlkalinity");
		  	public static final String ATTRIBUTE_PG_RESERVEACIDITY = PropertyUtil.getSchemaProperty("attribute_pgReserveAcidity");
		  	public static final String ATTRIBUTE_PG_TECHNICALBASISFORTHECORROSIVETOMETALS = PropertyUtil.getSchemaProperty("attribute_pgTechnicalBasisForTheCorrosiveToMetals");
		  	public static final String ATTRIBUTE_PG_HEATOFDECOMPOSITION = PropertyUtil.getSchemaProperty("attribute_pgHeatofDecomposition");
		  	public static final String ATTRIBUTE_PG_SELFACCELERATINGDECOMPOSITIONTEMPERATURE = PropertyUtil.getSchemaProperty("attribute_pgSelfAcceleratingDecompositionTemperature");
		  	public static final String ATTRIBUTE_PG_ENCLOSEDSPACEIGNITION = PropertyUtil.getSchemaProperty("attribute_pgEnclosedSpaceIgnition");
		  	public static final String ATTRIBUTE_PG_FLAMEDURATION = PropertyUtil.getSchemaProperty("attribute_pgFlameDuration");
		  	public static final String ATTRIBUTE_PG_FLAMEHEIGHT = PropertyUtil.getSchemaProperty("attribute_pgFlameHeight");
		  	public static final String ATTRIBUTE_PG_AEROSOLCONDUCTIVITYOFTHECONTENTS = PropertyUtil.getSchemaProperty("attribute_pgAerosolConductivityOfTheContents");
		  	public static final String ATTRIBUTE_VAPORDENSITY = PropertyUtil.getSchemaProperty("attribute_VaporDensity");
		  	public static final String ATTRIBUTE_PG_COLORINTENSITY = PropertyUtil.getSchemaProperty("attribute_pgColorIntensity");
		  	public static final String ATTRIBUTE_PG_VAPORDENSITY = PropertyUtil.getSchemaProperty("attribute_pgVaporDensity");
		  	public static final String CONST_FORMULATIONPART = "FormulationPart";
			//DSM (DS) 2018x.2 - Change Management FSD - Req 24430 - Revision of Formulation, Formulation Part, Formulation Process - START
	  	public static final String CONSTANT_UPSTAGE = "Upstage";
	  	//DSM (DS) 2018x.2 - Change Management FSD - Req 24430 - Revision of Formulation, Formulation Part, Formulation Process - END
		//DSM (DS) 2018x.2 - Req 27574 :Valid Start Date on Formulation Process Substitute Table- START
		public static final String ATTR_VALID_START_DATE = PropertyUtil.getSchemaProperty("attribute_pgValidStartDate");
		public static final String CONSTANT_VALID_START_DATE = "Valid Start Date";
	  	//DSM (DS) 2018x.2 - Req 27574 :Valid Start Date on Formulation Process Substitute Table- END
		
		//DSM(DS) 2018x.2.0 FSD - PDT REQId 27770, 27771, 27772, 27773, 27774 - Certifications column placed after 'EBOM Comments' column on EBOM of FOP, APP, and DPP- Start
	  	public static final String CONSTANT_STRING_CERTIFICATIONS = "Certifications";
	  	public static final String CONSTANT_STRING_REPORTEDFUNCTION = "ReportedFunction";
	  	public static final String CONSTANT_STRING_SUBINFBOM = "SubInFBOM";
		//DSM(DS) 2018x.2.0 FSD - PDT REQId 27770, 27771, 27772, 27773, 27774 - Certifications column placed after 'EBOM Comments' column on EBOM of FOP, APP, and DPP- End
	//DSM (DS) 2018x.2 PDT FSD - Maintainable only for Experimental & Pilot stage parts - STARTS
		public static final String CONSTANT_STRING_STANDARD_COSTPERKG = "Standard CostPerKg";
		//DSM (DS) 2018x.2 PDT FSD - Maintainable only for Experimental & Pilot stage parts - ENDS
		public static final String CONST_ATTR_PG_CANCONSTRUCTION = "attribute_pgCanConstruction";
		//DSM(DS) 2018x.2 - PDT FSD - Chemical Properties Page Changes to reset attributes - START
			public static final String ATTRIBUTE_PG_IGNITIONDISTANCE = PropertyUtil.getSchemaProperty("attribute_pgIgnitionDistance");
		  	public static final String ATTRIBUTE_PG_BURNRATE = PropertyUtil.getSchemaProperty("attribute_pgBurnRate");
		//DSM(DS) 2018x.2 - PDT FSD - Chemical Properties Page Changes to reset attributes - ENDS
		//DSM (DS) 2018x.1.1 ALM 27595 INC3678905 : Duplicate sequence numbers in Performance CHaracteristics row - STARTS
	    public static final String REL_EXTENDED_DATA = PropertyUtil.getSchemaProperty("relationship_Characteristic");
	    //DSM (DS) 2018x.1.1 ALM 27595 INC3678905 : Duplicate sequence numbers in Performance CHaracteristics row - ENDS
		//DSM (DS) 2018x.2 GPS Assessment FSD REQID#29424, 29191 - GPS Assessment PDT - Starts	
	  	public static final String CONSTANT_PG_TO_BE_ASSESSED_BS_IF_DIFFERENT_THAN_PART_EDIT = "pgToBeAssessedBusinessAreaIfDifferentThanPartEdit";
	  	public static final String CONSTANT_PG_TO_BE_ASSESSED_BS_IF_DIFFERENT_THAN_PART_VIEW = "pgToBeAssessedBusinessAreaIfDifferentThanPartView";
	  	//DSM (DS) 2018x.2 GPS Assessment FSD REQID#29424, 29191 - GPS Assessment PDT - Ends
		public static final String ATTRIBUTE_PHVALUE = PropertyUtil.getSchemaProperty("attribute_PHValue");
		public static final String CONST_ATTR_PHVALUE = "attribute_PHValue";
		// DSM (DS) 2018x.2 ALM 28043 GPS Assessment A8 - Reset Selected Value when Saved in Edit Mode - STARTS
		public static final String ATTRIBUTE_PG_PACKAGESHAPECOMPOSITION = PropertyUtil.getSchemaProperty("attribute_pgPackageShapeCompositonSameAsCurrentMarket");
		// DSM (DS) 2018x.2 ALM 28043 GPS Assessment A8 - Reset Selected Value when Saved in Edit Mode - ENDS
		//DSM(DS) 2018x.2 - Added for Smart Label Migration - START
		public static final String ATTRIBUTE_PG_INGREDIENT = PropertyUtil.getSchemaProperty("attribute_pgIngredient");
		public static final String ATTRIBUTE_PG_PURPOSE = PropertyUtil.getSchemaProperty("attribute_pgPurpose");
		public static final String ATTRIBUTE_PG_LAYER = PropertyUtil.getSchemaProperty("attribute_pgLayer");
		public static final String CONST_PG_TYPE_SMART_LABEL = "type_pgSmartLabel";
		public static final String CONST_PG_POLICY_SMART_LABEL = "policy_pgSmartLabel";
		//DSM(DS) 2018x.2 - Added for Smart Label Migration - END
		//DSM(DS) 2018x.2 - 27492 - System is allowing user to edit all levels of the FOP description and title from a CA - START
		public static final String STRING_EXPIRATIONDATE = "Expiration Date";
		public static final String STRING_EFFECTIVE_DATE = "Effective Date";
		public static final String STRING_PREVIOUS_REVISION_OBSOLETE_DATE = "Previous Revision Obsolete Date";
		//DSM(DS) 2018x.2 - 27492 - System is allowing user to edit all levels of the FOP description and title from a CA - END
		//DSM (DS) 2018x.2 REQ 29485 Product Category Platform is added to maintainable page - START
		public static final String STR_PRODUCTCATEGORYPLATFORM = "ProductCategoryPlatform";
		//DSM (DS) 2018x.2 REQ 29485 Product Category Platform is added to maintainable page - END
		//DSM (DS) 2018x.2 REQ 29547 - promote check trigger to block promotion if attribute Expand BOM on SAP BOM as Fed set to Yes and has a Substitute defined for FAB - START
		public static final String ATTRIBUTE_PG_EXPANDBOMONSAPBOMASFED = PropertyUtil.getSchemaProperty("attribute_pgExpandBOMonSAPBOMAsFed");
		//DSM (DS) 2018x.2 REQ 29547 - promote check trigger to block promotion if attribute Expand BOM on SAP BOM as Fed set to Yes and has a Substitute defined for FAB - END
		//DSM (DS) 2018x.2 :  Added for GPS Assessment Task FSD CR Implementation BA and PCP field - Start
		public static final String CONSTANT_PG_TO_BE_ASSESSED_PCP_IF_DIFFERENT_THAN_PART_EDIT = "pgToBeAssessedPCPIfDifferentThanPartEdit";
		public static final String CONSTANT_PG_TO_BE_ASSESSED_PCP_IF_DIFFERENT_THAN_PART_VIEW = "pgToBeAssessedPCPIfDifferentThanPartView";
		//DSM (DS) 2018x.2 :  Added for GPS Assessment Task FSD CR Implementation BA and PCP field - End
		//DSM (DS) 2018X.2 FSD Product_Data_Part_Templates To display pgChemicalPropertiesForm fields based on Product Form - START
		public static final String ATTRIBUTE_PG_ODOUR = PropertyUtil.getSchemaProperty(CONST_ATTR_PG_ODOUR);
		public static final String ATTRIBUTE_PG_RELATIVEDENSITYSPECIFICGRAVITY = PropertyUtil.getSchemaProperty(CONST_ATTR_PG_RELATIVEDENSITYSPECIFICGRAVITY);
		public static final String ATTRIBUTE_PG_KINEMATICVISCOSITY = PropertyUtil.getSchemaProperty(CONST_ATTR_PG_KINEMATICVISCOSITY);
		public static final String ATTRIBUTE_PG_EVAPORATIONRATE = PropertyUtil.getSchemaProperty(CONST_ATTR_PG_EVAPORATIONRATE);
		public static final String ATTRIBUTE_PG_CONTENTCONDUCTIVITY = PropertyUtil.getSchemaProperty("attribute_pgContentConductivity");
		public static final String ATTRIBUTE_PG_CORROSIVETOMETALS = PropertyUtil.getSchemaProperty("attribute_pgCorrosivetoMetals");
		public static final String ATTRIBUTE_PG_SUSTAINCOMBUSTION = PropertyUtil.getSchemaProperty("attribute_pgSustainCombustion");
		public static final String ATTRIBUTE_PG_OXIDIZER = PropertyUtil.getSchemaProperty("attribute_pgOxidizer");
		public static final String ATTRIBUTE_PG_BYVOLUME = PropertyUtil.getSchemaProperty("attribute_pgbyVolume");
		public static final String ATTRIBUTE_PG_BYWEIGHT = PropertyUtil.getSchemaProperty("attribute_pgbyWeight");
		public static final String ATTRIBUTE_PG_PROPELLANTEMULSIFIEDFORLIFEOFPRODUCT = PropertyUtil.getSchemaProperty("attribute_pgPropellantemulsifiedforlifeofproduct");
		public static final String ATTRIBUTE_PG_PROPELLANTISNONFLAMMABLE = PropertyUtil.getSchemaProperty("attribute_pgPropellantisnonflammable");
		public static final String ATTRIBUTE_PG_WTPARAMETERIZED = PropertyUtil.getSchemaProperty("attribute_pgWTParameterized");
		public static final String ATTRIBUTE_PG_KSTDUSTDEFLAGRATIONINDEX = PropertyUtil.getSchemaProperty("attribute_pgKstDustDeflagrationIndex");
		public static final String ATTRIBUTE_PG_MAXMAXEXPLOSIONPRESSURE = PropertyUtil.getSchemaProperty("attribute_pgpmaxmaxexplosionpressure");
		public static final String ATTRIBUTE_PG_GAUGEPRESSURE = PropertyUtil.getSchemaProperty("attribute_pgGaugePressure");
		//DSM (DS) 2018X.2 FSD Product_Data_Part_Templates To display pgChemicalPropertiesForm fields based on Product Form - END
		//DSM (DS) 2018x.2 ALM 29158 UAT Issue: PTP PTC field values disappeared after promotion - STARTS
		public static final String REL_PG_DOCUMENTTOCHASSIS = PropertyUtil.getSchemaProperty("relationship_pgDocumentToChassis");
		public static final String ATTRIBUTE_PG_CHASSIS_TYPE = PropertyUtil.getSchemaProperty("attribute_pgChassisType");
		public static final String TYPE_PG_PLI_CHASSIS = PropertyUtil.getSchemaProperty("type_pgPLIChassis");
		public static final String TYPE_PG_PLI_FRANCHCHISE_PLATFORM = PropertyUtil.getSchemaProperty("type_pgPLIFranchisePlatform");
		//DSM (DS) 2018x.2 ALM 29158 UAT Issue: PTP PTC field values disappeared after promotion - ENDS	
		//DSM(DS) 2018x.2 ALM - 29085 - copy product form relationship to revised object - START
		public static final String ATTRIBUTE_PG_ENGPRODUCTFORM = PropertyUtil.getSchemaProperty("attribute_pgEngProductForm");
		//DSM(DS) 2018x.2 ALM - 29085 - copy product form relationship to revised object - END
		// DSM (DS) 2018x.2 ALM 27316 CA promotion takes time which cause JVM instability . -STARTS
		public static final String TYPE_JOB = PropertyUtil.getSchemaProperty("type_Job");
		public static final String STATE_SUBMITTED = PropertyUtil.getSchemaProperty("policy", TYPE_JOB, "state_Submitted");
		// DSM (DS) 2018x.2 ALM 27316 CA promotion takes time which cause JVM instability . -ENDS
		//DSM(DS) 2018x.2.1 ALM -29504 - When an FOP is copied the Substances under it's IMP default to 0.0 instead of blank - START
		public static final String ATTR_MAXIMUM_WEIGHT = PropertyUtil.getSchemaProperty("attribute_MaximumWeight");
		public static final String ATTR_MINIMUM_WEIGHT = PropertyUtil.getSchemaProperty("attribute_MinimumWeight");
		//DSM(DS) 2018x.2.1 ALM -29504 - When an FOP is copied the Substances under it's IMP default to 0.0 instead of blank - END

}
