package com.pg.us.specanywhere_enovia.utility;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.pg.us.specanywhere_enovia.sapbom.pgV3Constants;

public interface ConstantsUtilIRM extends DomainConstants{

	// SPEC: Added for 18x.5.2 DEV --Shashank -- START
	public static final String RELATIONSHIP_TASKDELIVERABLE = PropertyUtil.getSchemaProperty("relationship_TaskDeliverable");
	public static final String RELATIONSHIP_PROJECTKEYACCESS = PropertyUtil.getSchemaProperty("relationship_ProjectAccessKey");
	public static final String RELATIONSHIP_PROJECTACCESSLIST = PropertyUtil.getSchemaProperty("relationship_ProjectAccessList");
	public static final String RELATIONSHIP_PROJECTDOCUMENT = PropertyUtil.getSchemaProperty("relationship_pgProjectDocument");
	public static final String SELECT_RELATIONSHIP_PROJECTDOCUMENT_NAME = "to["+RELATIONSHIP_PROJECTDOCUMENT+"].from.name";
	public static final String ATTRIBUTE_PGPKGPROJECTID = PropertyUtil.getSchemaProperty("attribute_pgPKGProjectID");
	public static final String SELECT_ATTRIBUTE_PGPKGPROJECTID = "attribute[" + ATTRIBUTE_PGPKGPROJECTID + "]";
	public static final String SELECT_PROJECTSPACE_PROJECTID = "to[" +RELATIONSHIP_PROJECTDOCUMENT + "].from." +SELECT_ATTRIBUTE_PGPKGPROJECTID;
	public static final String SELECT_IRM_PROJECT_ID = "to["+RELATIONSHIP_TASKDELIVERABLE+"].from.to["+RELATIONSHIP_PROJECTKEYACCESS+"].from.from["+RELATIONSHIP_PROJECTACCESSLIST+"].to." +SELECT_ATTRIBUTE_PGPKGPROJECTID;
	public static final String SELECT_IRM_PROJECT_NAME = "to["+RELATIONSHIP_TASKDELIVERABLE+"].from.to["+RELATIONSHIP_PROJECTKEYACCESS+"].from.from["+RELATIONSHIP_PROJECTACCESSLIST+"].to.name";
	public static final String ATTRIBUTE_PGPKGVALIDATIONSTEP = PropertyUtil.getSchemaProperty("attribute_pgPKGValidationStep");
	public static final String ATTRIBUTE_PGPKGVALIDATIONSYSTEM = PropertyUtil.getSchemaProperty("attribute_pgPKGValidatedSystem");
	public static final String ATTRIBUTE_PGPKGSITE = PropertyUtil.getSchemaProperty("attribute_pgPKGSite");
	public static final String ATTRIBUTE_PGPRTYPE = PropertyUtil.getSchemaProperty("attribute_pgPRType");
	public static final String ATTRIBUTE_PGCRTYPE = PropertyUtil.getSchemaProperty("attribute_pgCRType");
	public static final String ATTRIBUTE_PGCSTABILITYTYPE = PropertyUtil.getSchemaProperty("attribute_pgStabilityType");
	public static final String ATTRIBUTE_PGPKGSTUDYTYPE = PropertyUtil.getSchemaProperty("attribute_pgPKGStudyType");
	public static final String ATTRIBUTE_PGPKGCONSUMERSTUDYLEG = PropertyUtil.getSchemaProperty("attribute_pgPKGConsumerStudyLeg");
	public static final String ATTRIBUTE_PGPKGGPSCLEARANCE = PropertyUtil.getSchemaProperty("attribute_pgPKGGPSClearanceTrackingNo");
	public static final String ATTRIBUTE_PGCRPNUMBER = PropertyUtil.getSchemaProperty("attribute_pgPKGCRPNumber");
	public static final String ATTRIBUTE_PGPRODUCTSIZE = PropertyUtil.getSchemaProperty("attribute_pgProductSize");
	public static final String ATTRIBUTE_PGPKGDEVELOPMENTAREA = PropertyUtil.getSchemaProperty("attribute_pgPKGDevelopmentArea");
	public static final String ATTRIBUTE_PGPKGDEVELOPMENTTYPE = PropertyUtil.getSchemaProperty("attribute_pgPKGDevelopmentType");
	public static final String ATTRIBUTE_PGVALIDATIOnTYPE = PropertyUtil.getSchemaProperty("attribute_pgValidationType");
	public static final String ATTRIBUTE_PGPKGINITIATIVE = PropertyUtil.getSchemaProperty("attribute_pgPKGInitiative");
	public static final String ATTRIBUTE_PGPKGCHANGEMANAGEMENTCONTROLNUMBER = PropertyUtil.getSchemaProperty("attribute_pgPKGChangeManagementControlNumber");

	public static final String ATTRIBUTE_PGIRMSUCCESSCRITERIA = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMSuccessCriteria");
	public static final String ATTRIBUTE_PGIRMPURPOSE = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMPurpose");
	public static final String ATTRIBUTE_PGBALANCINGCRITERIA = PropertyUtil.getSchemaProperty(null,"attribute_pgBalancingCriteria");
	public static final String ATTRIBUTE_PGIRMACTION = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMAction");
	public static final String ATTRIBUTE_PGIRMBACKGROUND = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMBackground");
	public static final String ATTRIBUTE_PGIRMSTUDYTYPEFORMAT = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMStudyTypeFormat");
	public static final String ATTRIBUTE_PGTYPEOFRESEARCH = PropertyUtil.getSchemaProperty(null,"attribute_pgTypeOfResearch");
	public static final String ATTRIBUTE_PGIRMCONFIDENCELEVELSIGNIFICANCETESTING = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMConfidenceLevelSignificanceTesting");
	public static final String ATTRIBUTE_PGIRMTOTALNUMBEROFPANELISTS = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMTotalNoOfPanelists");
	public static final String ATTRIBUTE_PGNOTIFYPATENTOFFICE = PropertyUtil.getSchemaProperty(null,"attribute_pgNotifyPatentOffice");
	public static final String ATTRIBUTE_PGIRMSTUDYCLASS = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMStudyClass");
	public static final String ATTRIBUTE_PGIRMDATAUSE = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMDataUse");
	public static final String ATTRIBUTE_PGPRODUCTUSEDFORRND = PropertyUtil.getSchemaProperty(null,"attribute_pgProductUsedForRnD");
	public static final String ATTRIBUTE_PGSTUDYPROTOCOLTOADDITIONALSERVICE = PropertyUtil.getSchemaProperty(null,"attribute_pgStudyProtocolToAdditionalServices");
	public static final String ATTRIBUTE_PGIRMREGULATORYCLASSIFICATIONSTUDY = PropertyUtil.getSchemaProperty(null,"attribute_pgIRMRegulatoryClassificationStudy");
	public static final String ATTRIBUTE_PGSKINLAB = PropertyUtil.getSchemaProperty(null,"attribute_pgStudySkinLab");

	public static final String SELECT_ATTRIBUTE_PGSKINLAB = "attribute[" + ATTRIBUTE_PGSKINLAB + "]";
	public static final String SELECT_ATTRIBUTE_PGPRODUCTUSEDFORRND = "attribute[" + ATTRIBUTE_PGPRODUCTUSEDFORRND + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMSUCCESSCRITERIA = "attribute[" + ATTRIBUTE_PGIRMSUCCESSCRITERIA + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMPURPOSE = "attribute[" + ATTRIBUTE_PGIRMPURPOSE + "]";
	public static final String SELECT_ATTRIBUTE_PGBALANCINGCRITERIA = "attribute[" + ATTRIBUTE_PGBALANCINGCRITERIA + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMACTION = "attribute[" + ATTRIBUTE_PGIRMACTION + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMBACKGROUND = "attribute[" + ATTRIBUTE_PGIRMBACKGROUND + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMSTUDYBACKGROUND = "attribute[" + ATTRIBUTE_PGIRMSTUDYTYPEFORMAT + "]";
	public static final String SELECT_ATTRIBUTE_PGTYPEOFRESEARCH = "attribute[" + ATTRIBUTE_PGTYPEOFRESEARCH + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMCONFIDENCELEVELSIGNIFICANCETESTING = "attribute[" + ATTRIBUTE_PGIRMCONFIDENCELEVELSIGNIFICANCETESTING + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMTOTALNUMBEROFPANELISTS = "attribute[" + ATTRIBUTE_PGIRMTOTALNUMBEROFPANELISTS + "]";
	public static final String SELECT_ATTRIBUTE_PGNOTIFYPATENTOFFICE = "attribute[" + ATTRIBUTE_PGNOTIFYPATENTOFFICE + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMSTUDYCLASS= "attribute[" + ATTRIBUTE_PGIRMSTUDYCLASS + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMDATAUSE= "attribute[" + ATTRIBUTE_PGIRMDATAUSE + "]";
	public static final String SELECT_ATTRIBUTE_PGSTUDYPROTOCOLTOADDITIONALSERVICE= "attribute[" + ATTRIBUTE_PGSTUDYPROTOCOLTOADDITIONALSERVICE + "]";
	public static final String SELECT_ATTRIBUTE_PGIRMREGULATORYCLASSIFICATIONSTUDY = "attribute[" + ATTRIBUTE_PGIRMREGULATORYCLASSIFICATIONSTUDY + "]";

	public static final String SELECT_ATTRIBUTE_PGPKGVALIDATIONSTEP = "attribute[" + ATTRIBUTE_PGPKGVALIDATIONSTEP + "]";
	public static final String SELECT_ATTRIBUTE_PGPKGVALIDATIONSYSTEM = "attribute[" + ATTRIBUTE_PGPKGVALIDATIONSYSTEM + "]";
	public static final String SELECT_ATTRIBUTE_PGPKGSITE = "attribute[" + ATTRIBUTE_PGPKGSITE + "]";
	public static final String SELECT_ATTRIBUTE_PGPRTYPE = "attribute[" + ATTRIBUTE_PGPRTYPE + "]";
	public static final String SELECT_ATTRIBUTE_PGCRTYPE = "attribute[" + ATTRIBUTE_PGCRTYPE + "]";
	public static final String SELECT_ATTRIBUTE_PGCSTABILITYTYPE = "attribute[" + ATTRIBUTE_PGCSTABILITYTYPE + "]";
	public static final String SELECT_ATTRIBUTE_PGPKGSTUDYTYPE = "attribute[" + ATTRIBUTE_PGPKGSTUDYTYPE + "]";
	public static final String SELECT_ATTRIBUTE_PGPKGCONSUMERSTUDYLEG = "attribute[" + ATTRIBUTE_PGPKGCONSUMERSTUDYLEG + "]";
	public static final String SELECT_ATTRIBUTE_PGPKGGPSCLEARANCE = "attribute[" + ATTRIBUTE_PGPKGGPSCLEARANCE + "]";
	public static final String SELECT_ATTRIBUTE_PGCRPNUMBER = "attribute[" + ATTRIBUTE_PGCRPNUMBER + "]";
	public static final String SELECT_ATTRIBUTE_PGPRODUCTSIZE = "attribute[" + ATTRIBUTE_PGPRODUCTSIZE + "]";
	public static final String SELECT_ATTRIBUTE_PGPKGDEVELOPMENTAREA = "attribute[" + ATTRIBUTE_PGPKGDEVELOPMENTAREA + "]";
	public static final String SELECT_ATTRIBUTE_PGPKGDEVELOPMENTTYPE = "attribute[" + ATTRIBUTE_PGPKGDEVELOPMENTTYPE + "]";
	public static final String SELECT_ATTRIBUTE_PGVALIDATIONTYPE = "attribute[" + ATTRIBUTE_PGVALIDATIOnTYPE + "]";
	public static final String SELECT_ATTRIBUTE_PGPKGINITIATIVE = "attribute[" + ATTRIBUTE_PGPKGINITIATIVE + "]";
	public static final String SELECT_ATTRIBUTE_PGPKGCHANGEMANAGEMENTCONTROLNUMBER = "attribute[" + ATTRIBUTE_PGPKGCHANGEMANAGEMENTCONTROLNUMBER + "]";
	public static final String PROJECTNAME = "projectName";
	public static final String REGION = "region";
	public static final String VALIDATIONSTEP = "validationStep";
	public static final String VALIDATIONSYSTEM = "validationSystem";
	public static final String SITE = "site";
	public static final String INITIATIVE = "initiative";
	public static final String CHANGEMANAGEMENTCONTROLNUMBER = "changeManagementControlNumber";
	public static final String VALIDATIONSUBTYPE = "validationSubtype";
	public static final String GENERALINNOVATIONRECORDSUBTYPE = "generalInnovationRecordSubtype";
	public static final String COREINNOVATIONRECORDSUBTYPE = "coreInnovationRecordSubtype";
	public static final String DEVELOPMENTAREA = "developmentArea";
	public static final String CONSUMERRESEARCHSUBTYPE = "consumerResearchSubtype";
	public static final String CRPNUMBER = "crpNumber";
	public static final String GPSCLEARANCETRACKINGNUMBER = "gpsClearanceTrackingNo";
	public static final String CONSUMERSTUDYLEG = "consumerStudyLeg";
	public static final String STUDYTYPE = "studyType";
	public static final String STABILITYTYPE = "stabilityType";
	public static final String PRODUCTSIZE = "productSize";
	public static final String PRODUCTEXPIRATIONDATEREQUIRED = "productExpirationDateRequired";
	public static final String TEMPERATUREFREEZEPROTECTION = "temperatureFreezeProduction";
	public static final String TEMPERATUREHEATPROTECTION = "temperatureHeatProtection";
	public static final String RELATIONSHIP_ACTIVEVERSION = PropertyUtil.getSchemaProperty("relationship_ActiveVersion");
	public static final String SELECT_IRMDOC_FILE_NAME = "from[" +RELATIONSHIP_ACTIVEVERSION + "].to." +SELECT_ATTRIBUTE_TITLE;
	public static final String SELECT_IRMDOC_FILE_VERSION = "from[" +RELATIONSHIP_ACTIVEVERSION + "].to." +SELECT_REVISION;
	public static final String SELECT_IRMDOC_FILE_ORIGINATED = "from[" +RELATIONSHIP_ACTIVEVERSION + "].to." +SELECT_ORIGINATED;
	public static final String SELECT_IRMDOC_FILE_ORIGINATOR = "from[" +RELATIONSHIP_ACTIVEVERSION + "].to." +SELECT_ORIGINATOR;
	public static final String ATTRIBUTE_FILESIZE = PropertyUtil.getSchemaProperty("attribute_FileSize");
	public static final String SELECT_ATTRIBUTE_FILESIZE = "attribute[" + ATTRIBUTE_FILESIZE + "]";
	public static final String SELECT_IRMDOC_FILE_SIZE = "from[" +RELATIONSHIP_ACTIVEVERSION + "].to." +SELECT_ATTRIBUTE_FILESIZE;
	public static final String ATTRIBUTE_CHECKIN_REASON = PropertyUtil.getSchemaProperty("attribute_CheckinReason");
	public static final String SELECT_ATTRIBUTE_CHECKIN_REASON = "attribute[" + ATTRIBUTE_CHECKIN_REASON + "]";
	public static final String SELECT_IRMDOC_FILE_COMMENT = "from[" +RELATIONSHIP_ACTIVEVERSION + "].to." +SELECT_ATTRIBUTE_CHECKIN_REASON;
	public static final Object FILENAME = "fileName";
	public static final Object VERSION = "version";
	public static final Object FORMAT = "format";
	public static final Object FILESIZE = "fileSize";
	public static final Object FILEPATH = "filePath";
	public static final String GENDOC = "gendoc";
	public static final String ATTRIBUTE_PGPRODUCTCODEPANELISTS = PropertyUtil.getSchemaProperty("attribute_pgProductCodePanelists");
	public static final String ATTRIBUTE_PGSITEIFOTHERSELECTED = PropertyUtil.getSchemaProperty("attribute_pgSiteIfOtherSelected");
	public static final String ATTRIBUTE_PGNUMBEROFUNITSPERBAG = PropertyUtil.getSchemaProperty("attribute_pgNumberofUnitsperBag");
	public static final String ATTRIBUTE_PGRELPACKINGSITE = PropertyUtil.getSchemaProperty("attribute_pgRelPackingSite");
	public static final String ATTRIBUTE_PGMICROMCT = PropertyUtil.getSchemaProperty("attribute_pgMicroMCT");
	public static final String ATTRIBUTE_PGUNITSTOLABEL = PropertyUtil.getSchemaProperty("attribute_pgUnitsToLabel");
	public static final String ATTRIBUTE_PGLABELING = PropertyUtil.getSchemaProperty("attribute_pgLabeling");
	public static final String ATTRIBUTE_PGPANELISTSCOMPLETES = PropertyUtil.getSchemaProperty("attribute_pgPanelistsCompletes");
	public static final String ATTRIBUTE_PGPRFREQUENCYSAMEASCURRENTMARKETPRODUCT = PropertyUtil.getSchemaProperty("attribute_pgFrequencySameAsCurrentMarketProduct");
	public static final String ATTRIBUTE_PGISPRODUCTREPACKAGED = PropertyUtil.getSchemaProperty("attribute_pgIsProductRepackaged");
	public static final String ATTRIBUTE_PGUNITWEIGHT = PropertyUtil.getSchemaProperty("attribute_pgUnitWeight");
	public static final String SELECT_ATTRIBUTE_PGPRFREQUENCYSAMEASCURRENTMARKETPRODUCT = "attribute[" + ATTRIBUTE_PGPRFREQUENCYSAMEASCURRENTMARKETPRODUCT + "]";
	public static final String SELECT_ATTRIBUTE_PGPRODUCTCODEPANELISTS = "attribute[" + ATTRIBUTE_PGPRODUCTCODEPANELISTS + "]";
	public static final String SELECT_ATTRIBUTE_PGSITEIFOTHERSELECTED = "attribute[" + ATTRIBUTE_PGSITEIFOTHERSELECTED + "]";
	public static final String SELECT_ATTRIBUTE_PGNUMBEROFUNITSPERBAG = "attribute[" + ATTRIBUTE_PGNUMBEROFUNITSPERBAG + "]";
	public static final String SELECT_ATTRIBUTE_PGRELPACKINGSITE = "attribute[" + ATTRIBUTE_PGRELPACKINGSITE + "]";
	public static final String SELECT_ATTRIBUTE_PGMICROMCT = "attribute[" + ATTRIBUTE_PGMICROMCT + "]";
	public static final String SELECT_ATTRIBUTE_PGPANELISTSCOMPLETES = "attribute[" + ATTRIBUTE_PGPANELISTSCOMPLETES + "]";
	public static final String SELECT_ATTRIBUTE_PGUNITSTOLABEL = "attribute[" + ATTRIBUTE_PGUNITSTOLABEL + "]";
	public static final String SELECT_ATTRIBUTE_PGLABELING = "attribute[" + ATTRIBUTE_PGLABELING + "]";
	public static final String SELECT_ATTRIBUTE_PGUNITWEIGHT= "attribute[" + ATTRIBUTE_PGUNITWEIGHT + "]";
	public static final String SELECT_ATTRIBUTE_PGISPRODUCTREPACKAGED= "attribute[" + ATTRIBUTE_PGISPRODUCTREPACKAGED + "]";
	public static final String RELATIONSHIP_PG_MANUFACTURINGRESPONSIBILITY_LEG =  PropertyUtil.getSchemaProperty("relationship_pgManufacturingResponsibilityLeg");
	public static final String SELECT_LEG_PLANTNAME = "tomid[" + RELATIONSHIP_PG_MANUFACTURINGRESPONSIBILITY_LEG + "].from.name";
	public static final String LEGDETAILS = "legDetails";
	public static final String TOTALNUMBEROFPANELSINLEG = "totalNumberOfPanelistsInLeg";
	public static final String NUMBEROFPRODUCTCODESPANELISTSWILLRECEIVE = "numberOfProductCodesPanelistWillReceive";
	public static final String SITEOFOTHER = "SiteIfOther";
	public static final String SITEFORPRODUCTMANUFACTURING = "SiteForProductManufacturing";
	public static final String NUMBEROFUNITSPERPANELISTS = "numberOfUnitsPerPanelist";
	public static final String PACKAGINGSITE = "packingSite";
	public static final String WASHOUTTIMEBETWEENPRODUCTS = "washoutTimeBetweenProducts";
	public static final String PROVIDESPECIFICMCT = "provideSpecificMicroInformationBasedOnBuWorkProcess";
	public static final String NUMBEROFPANELISTCOMPLETES = "ofPanelistCompletes";
	public static final String NUMBEROFPANELISTSPLACEMENTS = "ofPanelistPlacements";
	public static final String NUMBEROFUNITSTOLABEL = "unitsToLabel";
	public static final String LABELDESCRIPTION = "labelDescription";
	public static final String STABILITYSAMPLECOUNT = "stabilitySampleCount";
	public static final String ANALYTICALSAMPLECOUNT = "analyticalSampleCount";
	public static final String NUMBEROFUNITSTOSHIP = "numberOfUnitsToShip";
	public static final String NETSAMPLECOUNT = "netSampleCount";
	public static final String UNITWEIGHTORVOLUME = "unitWeightOrVolume";
	public static final String ISPRODUCTREPACKAGED = "isProductRepackaged";
	public static final String PRODUCTCODE = "productCode";
	public static final String LEGPLANTNAME = "legPlantName";
	public static final String FREQUENCYMARKETPRODUCT = "usageFrequencySameAsCurrentMarketProduct";
	public static final String FREQUENCYOFTESTPRODUCT = "usageFrequencyOfTestProductIfNoEnterDetailsOrAttachFile";
	public static final String SELECTALLENTRIES = "selectAllEntriesWhereAnEbpWillBeUtilizedInTheExecutionOfTheStudy";
	public static final String RDSAMPLECOUNT = "rdTeamSampleCount";
	public static final String RDRETAINS = "rdRetains";
	public static final String PART = "part";
	public static final String BATCHMANUFLOT ="batchManufacturerLot";
	public static final String STR_ZERO = "0";
	public static final String STR_ONE = "1";
	public static final String COLLABORATIVESPACEUSERGRP = "collaborativeSpaceUserUserGroups";
	public static final String INHERITEDFROM = "inHeritedFrom";
	public static final String ACCESS = "access";
	public static final String INHERITEDACCESS = "inHeritedAccess";
	public static final String FRANCHISEPLATFORM = "franchisePlatform";
	public static final String MATERIALPLATFORM = "materialPlatform";
	public static final String TECHNICALBUILDINGBLOCKS = "technicalBuildingBlocks";
	public static final String PACKAGEPLATFORM = "packagePlatform";
	public static final String PACKAGECHASSIS = "packageChassis";
	public static final String PRODUCTPROCESSPLATFORM = "productProcessPlatform";
	public static final String PACKAGEPROCESSPLATFORM = "packageProcessPlatform";
	public static final String PRODUCTEQUIPMENTPLATFORM = "productEquipmentPlatform";
	public static final String PACKAGEEQUIPMENTPLATFORM = "packageEquipmentPlatform";
	public static final String MULTIPLEOWNERSHIPACCESS = "multipleOwnershipAccess";
	public static final String PLATFORMCHASSIS = "platformChassis";
	public static final String PERSON = "Person";
	public static final String SECURITY_CONTEXT = "Security Context";

	static final String ATTRIBUTE_BUSINESSAREA = PropertyUtil.getSchemaProperty(null, "attribute_pgBusinessArea");
	static final String ATTRIBUTE_FRANCHISEPLATFORM = PropertyUtil.getSchemaProperty(null, "attribute_pgFranchisePlatform");
	static final String ATTRIBUTE_PRODUCTCATEGORYPLATFORM = PropertyUtil.getSchemaProperty(null, "attribute_pgProductCategoryPlatform");
	static final String ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM = PropertyUtil.getSchemaProperty(null, "attribute_pgProductTechnologyPlatform");
	static final String ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS = PropertyUtil.getSchemaProperty(null, "attribute_pgProductTechnologyChassis");
	static final String ATTRIBUTE_PRODUCTPROCESSPLATFORM = PropertyUtil.getSchemaProperty(null, "attribute_pgProductProcessPlatform");
	static final String ATTRIBUTE_PRODUCTEQUIPMENTPLATFORM = PropertyUtil.getSchemaProperty(null, "attribute_pgProductEquipmentPlatform");
	static final String ATTRIBUTE_PACKAGEPLATFORM = PropertyUtil.getSchemaProperty(null, "attribute_pgPackagePlatform");
	static final String ATTRIBUTE_PACKAGECHASSIS = PropertyUtil.getSchemaProperty(null, "attribute_pgPackageChassis");
	static final String ATTRIBUTE_PACKAGEPROCESSPLATFORM = PropertyUtil.getSchemaProperty(null, "attribute_pgPackageProcessPlatform");
	static final String ATTRIBUTE_MATERIALPLATFORM = PropertyUtil.getSchemaProperty(null, "attribute_pgMaterialPlatform");
	static final String ATTRIBUTE_TECHNICALBUILDINGBLOCKS = PropertyUtil.getSchemaProperty(null, "attribute_pgTechnicalBuildingBlocks");
	static final String ATTRIBUTE_PACKAGEEQUIPMENTPLATFORM = PropertyUtil.getSchemaProperty(null, "attribute_pgPackageEquipmentPlatform");
	static final String ATTRIBUTE_PGMANAGEMENTSAMPLES = PropertyUtil.getSchemaProperty(null, "attribute_pgManagementSamples");
	static final String ATTRIBUTE_PGPANELISTINCLUSIONCRITERIA = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistInclusionCriteria");
	static final String ATTRIBUTE_PGPANELISTEXCLUSIONCRITERIA = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistExclusionCriteria");
	static final String ATTRIBUTE_PGPANELISTEXCLUSIONDETAILS = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistExclusionDetails");
	static final String ATTRIBUTE_PGPANELISTINCLUSIONDETAILS = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistInclusionDetails");
	static final String ATTRIBUTE_PGPANELISTUNIQUECONSUMERPACKAGE = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistUniqueConsumerPackage");
	static final String ATTRIBUTE_PGPANELISTANCILLIARYSUPPORTINGITEMS = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistAncillarySupportingItems");
	static final String ATTRIBUTE_PGPANELISTSTABILITYDATAREQUIRED = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistStabilityDataRequired");
	static final String ATTRIBUTE_PGLOCATIONOFSTABILITY = PropertyUtil.getSchemaProperty(null, "attribute_pgLocationOfStabilityData");
	static final String ATTRIBUTE_PGPANELISTSIGNINFORMEDCONSENT = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistsignInformedConsent");
	static final String ATTRIBUTE_PGLOCATIONFORDISTRIBUTINGPRODUCTS = PropertyUtil.getSchemaProperty(null, "attribute_pgStydySites");
	static final String ATTRIBUTE_PGEXPECTEDPANELISTCOMPENSATION = PropertyUtil.getSchemaProperty(null, "attribute_pgExpectedPanelistCompensation");
	static final String ATTRIBUTE_PGSTUDYCDASIGNEDFORPANELIST = PropertyUtil.getSchemaProperty(null, "attribute_pgStudyCDASignedForPanelist");
	static final String ATTRIBUTE_PGDESCRIBEPANEISTINTERATION = PropertyUtil.getSchemaProperty(null, "attribute_pgDescribePanelistInteraction");
	static final String ATTRIBUTE_PGPANELISTINSTRUCTIONATTACHED = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistInstructionsAttached");
	static final String ATTRIBUTE_PGPANELISTFOCUSGROUPINTERVIEW = PropertyUtil.getSchemaProperty(null, "attribute_pgPanelistFocusGroupInterview");
	static final String ATTRIBUTE_PGGPSAPPROVALREQUIREDTORELEASESTUDY = PropertyUtil.getSchemaProperty(null, "attribute_pgGPSApprovalRequiredToReleaseStudy");
	static final String ATTRIBUTE_PGUSEPRODUCTBYCONTRACTMANUFORCOMPETITOR = PropertyUtil.getSchemaProperty(null, "attribute_pgUseProductByContractManufacturerOrCompetitor");
	static final String ATTRIBUTE_PGLEGACYRQID = PropertyUtil.getSchemaProperty(null, "attribute_pgLegacyRQID");
	static final String ATTRIBUTE_PGSINGLECONSUMERSTUDY = PropertyUtil.getSchemaProperty(null, "attribute_pgSingleConsumerStudy");
	static final String ATTRIBUTE_PGREQUESTEDEXPIRATIONDATE = PropertyUtil.getSchemaProperty(null, "attribute_pgRequestedExpirationDate");
	static final String ATTRIBUTE_PGDURATIONSTUDY = PropertyUtil.getSchemaProperty(null, "attribute_pgDurationStudy");
	static final String ATTRIBUTE_PGPRODUCTUSELOCATION = PropertyUtil.getSchemaProperty(null, "attribute_pgProductUseLocation");
	static final String ATTRIBUTE_PGSTORAGEUNPLACEDPRODUCT = PropertyUtil.getSchemaProperty(null, "attribute_pgStorageUnplacedProduct");
	static final String ATTRIBUTE_PGOTHERLOCATION = PropertyUtil.getSchemaProperty(null, "attribute_pgOtherLocation");
	static final String ATTRIBUTE_PGAGENCY = PropertyUtil.getSchemaProperty(null, "attribute_pgAgency");
	static final String ATTRIBUTE_PGPLACEMENTFIELDINGINSTRUCTIONS = PropertyUtil.getSchemaProperty(null, "attribute_pgPlacementFieldingInstructions");
	static final String ATTRIBUTE_PGESTIMATEDFIELDINGSCHEDULE = PropertyUtil.getSchemaProperty(null, "attribute_pgEstimatedFieldingSchedule");
	static final String ATTRIBUTE_PGREQUESTEDSITESCHEDULE = PropertyUtil.getSchemaProperty(null, "attribute_pgRequestedSiteSchedule");
	static final String SELECT_ATTRIBUTE_PGREQUESTEDSITESCHEDULE = "attribute["+ATTRIBUTE_PGREQUESTEDSITESCHEDULE+"]";
	static final String ATTRIBUTE_PGBUDGETAPPROVER = PropertyUtil.getSchemaProperty(null, "attribute_pgBudgetApprover");
	static final String SELECT_ATTRIBUTE_PGBUDGETAPPROVER = "attribute["+ATTRIBUTE_PGBUDGETAPPROVER+"]";
	static final String ATTRIBUTE_PGESTIMATEDCOMPLETIONDATEOFSTUDY = PropertyUtil.getSchemaProperty(null, "attribute_pgEstimatedCompletionDateOfStudy");
	static final String SELECT_ATTRIBUTE_PGESTIMATEDCOMPLETIONDATEOFSTUDY = "attribute["+ATTRIBUTE_PGESTIMATEDCOMPLETIONDATEOFSTUDY+"]";
	static final String ATTRIBUTE_PGCOSTOFPLACINGEXECUTION = PropertyUtil.getSchemaProperty(null, "attribute_pgCostOfPlacingExecution");
	static final String SELECT_ATTRIBUTE_PGCOSTOFPLACINGEXECUTION = "attribute["+ATTRIBUTE_PGCOSTOFPLACINGEXECUTION+"]";
	static final String ATTRIBUTE_PGCURRENCY = PropertyUtil.getSchemaProperty(null, "attribute_pgCurrency");
	static final String SELECT_ATTRIBUTE_PGCURRENCY = "attribute["+ATTRIBUTE_PGCURRENCY+"]";
	static final String ATTRIBUTE_PGPO = PropertyUtil.getSchemaProperty(null, "attribute_pgPO");
	static final String SELECT_ATTRIBUTE_PGPO = "attribute["+ATTRIBUTE_PGPO+"]";
	static final String ATTRIBUTE_PGBUDGETCCIO = PropertyUtil.getSchemaProperty(null, "attribute_pgBudgetCCIO");
	static final String SELECT_ATTRIBUTE_PGBUDGETCCIO = "attribute["+ATTRIBUTE_PGBUDGETCCIO+"]";
	static final String ATTRIBUTE_PGIPPROJECTSECURITY = PropertyUtil.getSchemaProperty(null, "attribute_pgIPProjectSecurity");
	static final String SELECT_ATTRIBUTE_PGIPPROJECTSECURITY = "attribute["+ATTRIBUTE_PGIPPROJECTSECURITY+"]";
	static final String ATTRIBUTE_PGGPSASSESSMENTCATEGORY = PropertyUtil.getSchemaProperty(null, "attribute_pgGPSAssessmentCategory");
	static final String SELECT_ATTRIBUTE_PGGPSASSESSMENTCATEGORY = "attribute["+ATTRIBUTE_PGGPSASSESSMENTCATEGORY+"]";
	static final String ATTRIBUTE_PGGPSSTATUS = PropertyUtil.getSchemaProperty(null, "attribute_pgGPSStatus");
	static final String SELECT_ATTRIBUTE_PGGPSSTATUS = "attribute["+ATTRIBUTE_PGGPSSTATUS+"]";
	static final String ATTRIBUTE_PGTASKNAME = PropertyUtil.getSchemaProperty(null, "attribute_pgOriginalTaskName");
	static final String ATTRIBUTE_PGADDRESSOTHERPGSITE = PropertyUtil.getSchemaProperty(null, "attribute_pgAddressOtherPGSite");
	static final String ATTRIBUTE_PGSTUDYPANELISTMATERIALS = PropertyUtil.getSchemaProperty(null, "attribute_pgStudyPanelistMaterials");
	static final String ATTRIBUTE_PGSTUDYPANELISTHOMEWORK = PropertyUtil.getSchemaProperty(null, "attribute_pgStudyPanelistsHomework");
	static final String ATTRIBUTE_PGSTUDYSUPERVISED = PropertyUtil.getSchemaProperty(null, "attribute_pgStudySupervised");
	static final String ATTRIBUTE_PGSTUDYPANELISTEMAILADDRESS = PropertyUtil.getSchemaProperty(null, "attribute_pgStudyPanelistEmailAddress");

	static final String SELECT_ATTRIBUTE_PGSTUDYPANELISTEMAILADDRESS = "attribute["+ATTRIBUTE_PGSTUDYPANELISTEMAILADDRESS+"]";
	static final String SELECT_ATTRIBUTE_PGSTUDYSUPERVISED = "attribute["+ATTRIBUTE_PGSTUDYSUPERVISED+"]";
	static final String SELECT_ATTRIBUTE_PGSTUDYPANELISTHOMEWORK = "attribute["+ATTRIBUTE_PGSTUDYPANELISTHOMEWORK+"]";
	static final String SELECT_ATTRIBUTE_PGSTUDYPANELISTMATERIALS = "attribute["+ATTRIBUTE_PGSTUDYPANELISTMATERIALS+"]";
	static final String SELECT_ATTRIBUTE_PGADDRESSOTHERPGSITE = "attribute["+ATTRIBUTE_PGADDRESSOTHERPGSITE+"]";
	static final String SELECT_ATTRIBUTE_PGTASKNAME = "attribute["+ATTRIBUTE_PGTASKNAME+"]";
	static final String SELECT_ATTRIBUTE_PGESTIMATEDFIELDINGSCHEDULE = "attribute["+ATTRIBUTE_PGESTIMATEDFIELDINGSCHEDULE+"]";
	static final String SELECT_ATTRIBUTE_PGPLACEMENTFIELDINGINSTRUCTIONS = "attribute["+ATTRIBUTE_PGPLACEMENTFIELDINGINSTRUCTIONS+"]";
	static final String SELECT_ATTRIBUTE_PGAGENCY = "attribute["+ATTRIBUTE_PGAGENCY+"]";
	static final String SELECT_ATTRIBUTE_PGOTHERLOCATION = "attribute["+ATTRIBUTE_PGOTHERLOCATION+"]";
	static final String SELECT_ATTRIBUTE_PGSTORAGEUNPLACEDPRODUCT = "attribute["+ATTRIBUTE_PGSTORAGEUNPLACEDPRODUCT+"]";
	static final String SELECT_ATTRIBUTE_PGPRODUCTUSELOCATION = "attribute["+ATTRIBUTE_PGPRODUCTUSELOCATION+"]";
	static final String SELECT_ATTRIBUTE_PGDURATIONSTUDY = "attribute["+ATTRIBUTE_PGDURATIONSTUDY+"]";
	static final String SELECT_ATTRIBUTE_PGREQUESTEDEXPIRATIONDATE = "attribute["+ATTRIBUTE_PGREQUESTEDEXPIRATIONDATE+"]";
	static final String SELECT_ATTRIBUTE_PGSINGLECONSUMERSTUDY = "attribute["+ATTRIBUTE_PGSINGLECONSUMERSTUDY+"]";
	static final String SELECT_ATTRIBUTE_PGLEGACYRQID = "attribute["+ATTRIBUTE_PGLEGACYRQID+"]";
	static final String SELECT_ATTRIBUTE_PGUSEPRODUCTBYCONTRACTMANUFORCOMPETITOR = "attribute["+ATTRIBUTE_PGUSEPRODUCTBYCONTRACTMANUFORCOMPETITOR+"]";
	static final String SELECT_ATTRIBUTE_PGGPSAPPROVALREQUIREDTORELEASESTUDY = "attribute["+ATTRIBUTE_PGGPSAPPROVALREQUIREDTORELEASESTUDY+"]";
	//<SPEC> 06/02/2021 Added by Govind for Defect #38890 start
	static final String ATTRIBUTE_PGIRMNRQID=PropertyUtil.getSchemaProperty(null, "attribute_pgIRMNRQID");
	static final String SELECT_ATTRIBUTE_PGGPSASSESSMENTTASKNRQID= "attribute["+ATTRIBUTE_PGIRMNRQID+"]";
	//<SPEC> 06/02/2021 Added by Govind for Defect #38890 end
	static final String SELECT_ATTRIBUTE_PGPANELISTFOCUSGROUPINTERVIEW = "attribute["+ATTRIBUTE_PGPANELISTFOCUSGROUPINTERVIEW+"]";
	static final String SELECT_ATTRIBUTE_PGPANELISTINSTRUCTIONATTACHED = "attribute["+ATTRIBUTE_PGPANELISTINSTRUCTIONATTACHED+"]";
	static final String SELECT_ATTRIBUTE_PGDESCRIBEPANEISTINTERATION = "attribute["+ATTRIBUTE_PGDESCRIBEPANEISTINTERATION+"]";
	static final String SELECT_ATTRIBUTE_PGSTUDYCDASIGNEDFORPANELIST = "attribute["+ATTRIBUTE_PGSTUDYCDASIGNEDFORPANELIST+"]";
	static final String SELECT_ATTRIBUTE_PGEXPECTEDPANELISTCOMPENSATION = "attribute["+ATTRIBUTE_PGEXPECTEDPANELISTCOMPENSATION+"]";
	static final String SELECT_ATTRIBUTE_PGPANELISTSIGNINFORMEDCONSENT = "attribute["+ATTRIBUTE_PGPANELISTSIGNINFORMEDCONSENT+"]";
	static final String SELECT_ATTRIBUTE_PGLOCATIONFORDISTRIBUTINGPRODUCTS = "attribute["+ATTRIBUTE_PGLOCATIONFORDISTRIBUTINGPRODUCTS+"]";
	static final String SELECT_ATTRIBUTE_PGLOCATIONOFSTABILITY = "attribute["+ATTRIBUTE_PGLOCATIONOFSTABILITY+"]";
	static final String SELECT_ATTRIBUTE_PGPANELISTSTABILITYDATAREQUIRED = "attribute["+ATTRIBUTE_PGPANELISTSTABILITYDATAREQUIRED+"]";
	static final String SELECT_ATTRIBUTE_PGPANELISTANCILLIARYSUPPORTINGITEMS = "attribute["+ATTRIBUTE_PGPANELISTANCILLIARYSUPPORTINGITEMS+"]";
	static final String SELECT_ATTRIBUTE_PGPANELISTUNIQUECONSUMERPACKAGE = "attribute["+ATTRIBUTE_PGPANELISTUNIQUECONSUMERPACKAGE+"]";

	static final String SELECT_ATTRIBUTE_PGPANELISTEXCLUSIONDETAILS = "attribute["+ATTRIBUTE_PGPANELISTEXCLUSIONDETAILS+"]";
	static final String SELECT_ATTRIBUTE_PGPANELISTINCLUSIONDETAILS = "attribute["+ATTRIBUTE_PGPANELISTINCLUSIONDETAILS+"]";
	static final String SELECT_ATTRIBUTE_PGPANELISTEXCLUSIONCRITERIA = "attribute["+ATTRIBUTE_PGPANELISTEXCLUSIONCRITERIA+"]";
	static final String SELECT_ATTRIBUTE_PGPANELISTINCLUSIONCRITERIA = "attribute["+ATTRIBUTE_PGPANELISTINCLUSIONCRITERIA+"]";
	static final String SELECT_ATTRIBUTE_PGMANAGEMENTSAMPLES = "attribute["+ATTRIBUTE_PGMANAGEMENTSAMPLES+"]";
	static final String SELECT_ATTRIBUTE_FRANCHISEPLATFORM = "attribute["+ATTRIBUTE_FRANCHISEPLATFORM+"]";
	static final String SELECT_ATTRIBUTE_PRODUCTCATEGORYPLATFORM = "attribute["+ATTRIBUTE_PRODUCTCATEGORYPLATFORM+"]";
	static final String SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM_IRMDOCS = "attribute["+ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM+"]";
	static final String SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS_IRMDOCS = "attribute["+ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS+"]";
	static final String SELECT_ATTRIBUTE_PRODUCTPROCESSPLATFORM = "attribute["+ATTRIBUTE_PRODUCTPROCESSPLATFORM+"]";
	static final String SELECT_ATTRIBUTE_PRODUCTEQUIPMENTPLATFORM = "attribute["+ATTRIBUTE_PRODUCTEQUIPMENTPLATFORM+"]";
	static final String SELECT_ATTRIBUTE_PACKAGEPLATFORM = "attribute["+ATTRIBUTE_PACKAGEPLATFORM+"]";
	static final String SELECT_ATTRIBUTE_PACKAGECHASSIS = "attribute["+ATTRIBUTE_PACKAGECHASSIS+"]";
	static final String SELECT_ATTRIBUTE_PACKAGEPROCESSPLATFORM = "attribute["+ATTRIBUTE_PACKAGEPROCESSPLATFORM+"]";
	static final String SELECT_ATTRIBUTE_MATERIALPLATFORM = "attribute["+ATTRIBUTE_MATERIALPLATFORM+"]";
	static final String SELECT_ATTRIBUTE_TECHNICALBUILDINGBLOCKS = "attribute["+ATTRIBUTE_TECHNICALBUILDINGBLOCKS+"]";
	static final String SELECT_ATTRIBUTE_PACKAGEEQUIPMENTPLATFORM = "attribute["+ATTRIBUTE_PACKAGEEQUIPMENTPLATFORM+"]";
	static final String SELECT_ATTRIBUTE_BUSINESSAREA = "attribute["+ATTRIBUTE_BUSINESSAREA+"]";
	static final String TYPE_PG_PLI_BUSINESSAREA=PropertyUtil.getSchemaProperty("type_pgPLIBusinessArea");
	static final String TYPE_PG_PLIPLATFORM = PropertyUtil.getSchemaProperty("type_pgPLIPlatform");
	static final String TYPE_PG_PLICHASSIS = PropertyUtil.getSchemaProperty("type_pgPLIChassis");
	static final String FRANCHISE_PLATFORM = "Franchise Platform";
	static final String PRODUCT_CATEGORY_PLATFORM = "Product Category Platform";
	static final String PRODUCT_FORM_PLATFORM = "Product Form Platform";
	static final String PRODUCT_TECHNOLOGY_PLATFORM = "Product Technology Platform";
	static final String PACKAGE_PLATFORM = "Package Platform";
	static final String MATERIAL_PLATFORM = "Material Platform";
	static final String TECHNICAL_BUILDING_BLOCKS = "Technical Building Blocks";
	static final String PRODUCT_PROCESS_PLATFORM = "Product Process Platform";
	static final String PRODUCT_TECHNOLOGY = "Product Technology Chassis";
	static final String PACKAGE_PROCESS_PLATFORM = "Package Process Platform";
	static final String PACKAGE = "Package Chassis";
	static final String PRODUCT_EQUIPMENT_PLATFORM = "Product Equipment Platform";
	static final String PACKAGE_EQUIPMENT_PLATFORM = "Package Equipment Platform";
	static final String TYPE_FRANCHISE_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPLIFranchisePlatform");
	static final String TYPE_PRODUCT_CATEGORY_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPLIProductCategoryPlatform");
	static final String TYPE_PRODUCT_TECHNOLOGY_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPLIProductTechnologyPlatform");
	static final String TYPE_PRODUCT_TECHNOLOGY_CHASSIS = 	PropertyUtil.getSchemaProperty(null, "type_pgPLIProductTechnologyChassis");
	static final String TYPE_PRODUCT_PROCESS_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPLIProductProcessPlatform");
	static final String TYPE_PRODUCT_EQUIPMENT_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPLIProductEquipmentPlatform");
	static final String TYPE_PACKAGE_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPLIPackagePlatform");
	static final String TYPE_PACKAGE_CHASSIS = PropertyUtil.getSchemaProperty(null, "type_pgPLIPackageChassis");
	static final String TYPE_PACKAGE_PROCESS_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPLIPackageProcessPlatform");
	static final String TYPE_MATERIAL_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPLIMaterialPlatform");
	static final String TYPE_TECHNICAL_BUILDING_BLOCKS = PropertyUtil.getSchemaProperty(null, "type_pgPLITechnicalBuildingBlocks");
	public static final String TYPE_PACKAGE_EQUIPMENT_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPLIPackageEquipmentPlatform");

	public static final String TYPE_PKGVALIDATION = PropertyUtil.getSchemaProperty(null, "type_pgPKGValidation");
	public static final String TYPE_PKGDEV_OTHER = PropertyUtil.getSchemaProperty(null, "type_pgPKGDevelopment");
	public static final String TYPE_PKGSTABILITY = PropertyUtil.getSchemaProperty(null, "type_pgPKGStability");
	public static final String TYPE_PKGCONSUMER_PROPOSITION = PropertyUtil.getSchemaProperty(null, "type_pgPKGConsumerProposition");
	public static final String TYPE_CORE_INNOVATION_RECORD = PropertyUtil.getSchemaProperty(null, "type_pgPKGProductReadiness");
	public static final String  TYPE_DI_PLATFORM = PropertyUtil.getSchemaProperty(null, "type_pgPKGDIPlatform");
	public static final String PG_BUSINESS_AREA= "pgBusinessArea";

	public static final String RELATIONSHIP_PGGPSASSESSMENTTASKINPUTS = PropertyUtil.getSchemaProperty("relationship_pgGPSAssessmentTaskInputs");
	public final static String TYPE_DOCUMENTS = PropertyUtil.getSchemaProperty("type_documents");
	public static final String OBJECTIVE	=	"objective";
	public static final String SUCCESSCRITERIA	=	"successCriteria";
	public static final String ACTIONTOBETAKEN	=	"actionToBeTaken";
	public static final String BACKGROUND	=	"background";
	public static final String STUDYTYPEFORMAT	=	"studyTypeFormat";
	public static final String STUDYTYPEFORMATIFSELECTED	=	"StudyTypeFormatIfSelected";
	public static final String TYPEOFRESEARCH	=	"typeOfResearch";
	public static final String CONFIDENCELEVELOFSIGNIFICANCETESTING	=	"confidenceLevelOfSignificanceTesting";
	public static final String TOTALNUMBEROFPANELISTS	=	"totalNumberOfPanelists";
	public static final String REVIEWPURCHASEINTENTQUESTIONS	=	"reviewPurchaseIntentquestions";
	public static final String ADDITIONALSERVICESNEEDED	=	"additionalServicesNeeded";
	public static final String HAVEYOUNOTIFIEDTHEPATENTOFFICE	=	"haveYouNotifiedThePatentOffice";
	public static final String STUDYCLASS	=	"studyClass";
	public static final String OVERALLREGULATORYCLASSIFICATION	=	"overallRegulatoryClassification";
	public static final String DATAUSE	=	"dataUse";
	public static final String CLINICALSTUDY	=	"clinicalStudy";
	public static final String PANELISTTYPE	=	"panelistType";
	public static final String GENDER	=	"gender";
	public static final String AGECONSTRAINTLOWERLIMIT	=	"ageConstraintLowerLimit";
	public static final String AGECONSTRAINTUPPERLIMIT	=	"ageConstraintUpperLimit";
	public static final String ISPANELISTEXCLUSIONCRITERIADEFINED	=	"isPanelistExclusionCriteriaDefined";
	public static final String PANELISTEXCLUSIONDETAILS	=	"panelistExclusionDetails";
	public static final String ETHNICITYRACE	=	"ethnicityRace";
	public static final String BALANCINGCRITERIA	=	"balancingCriteria";
	public static final String IFPRODUCTUSERAGERANGEISNOTPROVIDED	=	"ifProductUserAgeRangeIsNotProvided";
	public static final String ISPANELISTINCLUSIONCRITERIADEFINED	=	"isPanelistInclusionCriteriaDefined";
	public static final String USEDFORPGMANAGEMENTSAMPLES	=	"UsedForPgManagementSamples";
	public static final String WILLPRODUCTUSEDFORRDTEAMTEST	=	"willProductUsedForRdTeamTest";
	public static final String PANELISTINCLUSIONDETAILS	=	"panelistInclusionDetails";
	public static final String UNIQUECONSUMERPACKAGESHAPE	=	"uniqueConsumerPackageShape";
	public static final String ANCILLARYITEMSPROVIDEDTOPANELIST	=	"ancillaryItemsProvidedToPanelist";
	public static final String ISSTABILITYDATAREQUIRED	=	"isStabilityDataRequired";
	public static final String LOCATIONOFSTABILITYDATA	=	"locationOfStabilityData";
	public static final String PANELISTSIGNANINFORMEDCONSENT	=	"panelistSignAnInformedConsent";
	public static final String WILLPANELISTTOSIGNCDA	=	"willPanelistToSignCda";
	public static final String PRODUCTUNDERSUPERVISIONBYPG	=	"productUnderSupervisionByPg";
	public static final String PANELISTSREQUIREDTORETURNTESTPRODUCT	=	"panelistsRequiredToReturnTestProduct";
	public static final String EXPECTEDPANELISTCOMPENSATION	=	"expectedPanelistCompensation";
	public static final String REQUIREDPANELISTPERMISSIONTOSHAREPII	=	"requiredPanelistPermissionToSharePii";
	public static final String DESCRIBETHEPANELISTINTERACTION	=	"describeThePanelistInteraction";
	public static final String PANELISTSREQUIREDTOCOMPLETEPREWORK	=	"panelistsRequiredToCompletePrework";
	public static final String AREPANELISTINSTRUCTIONSATTACHED	=	"arePanelistInstructionsAttached";
	public static final String PANELISTQUESTIONNAIRE	=	"panelistQuestionnaire";
	public static final String PANELISTREQUIREDFORINDEPTH	=	"panelistRequiredForIndepth";
	public static final String ISGPSAPPROVALREQUIRED	=	"isGpsApprovalRequired";
	public static final String USEPRODUCTBYPGCONTRACTMANUFACTUREE	=	"UseProductByPgContractManufacturee";
	public static final String REQUESTFORASINGLECONSUMERSTUDY	=	"requestForASingleConsumerStudy";
	public static final String EXISTINGGPSASSESSMENTENTERTASK	=	"existingGpsAssessmentEnterTask";
	public static final String EXISTINGGPSASSESSMENTENTERLEGACY	=	"existingGpsAssessmentEnterLegacy";
	public static final String MARKETOFSTUDYPLACEMENT	=	"marketOfStudyPlacement";
	public static final String ESTIMATEDSTUDYSTARTDATE	=	"estimatedStudyStartDate";
	public static final String DURATIONOFSTUDY	=	"durationOfStudy";
	public static final String LOCATIONOFPRODUCTUSEBYPANELIST	=	"locationOfProductUseByPanelist";
	public static final String IFLOCATIONISOTHERENTERDETAILSHERE	=	"ifLocationIsOtherEnterDetailsHere";
	public static final String LOCATIONFORDISTRIBUTINGPRODUCTS	=	"locationForDistributingProducts";
	public static final String ADDRESSIFOTHERTHANPGSITE	=	"addressIfOtherThanPgSite";
	public static final String HOWWILLPRODUCTSARRIVE	=	"howWillProductsArrive";
	public static final String STORAGEOFUNPLACEDPRODUCT	=	"storageOfUnplacedProduct";
	public static final String UNPLACEDPRODUCTBEDISPOSED	=	"unplacedProductBeDisposed";
	public static final String RETURNADDRESS	=	"returnAddress";
	public static final String AGENCY	=	"agency";
	public static final String PLACEMENTFIELDINGINSTRUCTIONS	=	"placementFieldingInstructions";
	public static final String ESTIMATEDFIELDINGSCHEDULE	=	"estimatedFieldingSchedule";
	public static final String DATACOLLECTIONMETHODS	=	"dataCollectionMethods";
	public static final String DATAMERGENEEDED	=	"dataMergeNeeded";
	public static final String DATAOUTPUT	=	"dataOutput";
	public static final String REQUESTEDSITEBOOKINGFORINTERVIEWS 	=	"requestedSiteBookingForInterviews ";
	public static final String REQUESTEDSITESCHEDULEFORINTERVIEWS	=	"requestedSiteScheduleForInterviews";
	public static final String BUDGETAPPROVER	=	"budgetApprover";
	public static final String ESTIMATEDCOMPLETIONDATEOFSTUDY	=	"estimatedCompletionDateOfStudy";
	public static final String COSTOFPLACINGEXECUTION	=	"costOfPlacing&Execution";
	public static final String PO	=	"po";
	public static final String BUDGETCCORIO	=	"budgetCCorIO";
	public static final String CURRENCY	=	"Currency";
	public static final String IPSECURITYINFORMATION	=	"ipSecurityInformation";
	public static final String SECURITYCATEGORYCLASSIFICATION	=	"securityCategoryClassification";
	public static final String LIMITACCESSTONAMEDUSERS	=	"limitAccessToNamedUsers";
	public static final String PROJECTSECURITYCLASSIFICATION	=	"projectSecurityClassification";
	public static final String STATUS_IRM	=	"Status";
	public static final String TASKNAME_IRM	=	"taskName";
	public static final String NRQID	=	"nrqId";
	public static final String REQUESTEDEXPIRATIONDATEFORASSESSMENT	=	"requestedExpirationDateForAssessment";
	public static final String ATTRAGEANDCONDITIONCONTROL = "attrAgeAndConditionControl";
	public static final String ATTRSTUDYOBJECTIVESANDSUCCESSCRITERIA = "attrStudyObjectivesAndSuccessCriteria";
	public static final String ATTRSTUDYDESIGN = "attrStudyDesign";
	public static final String ATTRSTUDYCLASSIFICATION = "attrStudyClassification";
	public static final String ATTRPANELISTRECRUITINGCRITERIA = "attrPanelistRecruitingCriteria";
	public static final String ATTRSPECIALPRODUCTELEMENTS = "attrSpecialProductElements";
	public static final String ATTRPANELISTTASK = "attrPanelistTask";
	public static final String ATTRGPSASSESSMENTTYPE = "attrGpsAssessmentType";
	public static final String ATTRGPSASSESSMENT = "attrGpsAssessment";
	public static final String ATTRSTUDYLOCATIONDATES = "attrStudyLocationDates";
	public static final String ATTRAGENCYTASKS = "attrAgencyTasks";
	public static final String ATTRBUDGETOWNERAPPROVAL = "attrBudgetOwnerApproval";
	public static final String RELATIONSHIP_STUDYCLASS = PropertyUtil.getSchemaProperty("relationship_pgStudyProtocolToStudyClass");
	public static final String RELATIONSHIP_STUDYPROTOCOLTOGENDER = PropertyUtil.getSchemaProperty("relationship_pgStudyProtocolToGender");
	public static final String RELATIONSHIP_ETHNICITYTORACE = PropertyUtil.getSchemaProperty("relationship_pgStudyProtocolToRace");
	public static final String SELECT_RELATIONSHIP_STUDYCLASS_NAME = "from[" +RELATIONSHIP_STUDYCLASS + "].to.name";
	public static final String SELECT_RELATIONSHIP_STUDYPROTOCOLTOGENDER = "from[" +RELATIONSHIP_STUDYPROTOCOLTOGENDER + "].to.name";
	public static final String SELECT_RELATIONSHIP_ETHNICITYTORACE = "from[" +RELATIONSHIP_ETHNICITYTORACE + "].to.name";
	public static final String RELATIONSHIP_STUDYLOCATIONS = PropertyUtil.getSchemaProperty("relationship_pgStudyProtocolToStudyLocations");
	public static final String SELECT_RELATIONSHIP_STUDYLOCATIONS = "from[" +RELATIONSHIP_STUDYLOCATIONS + "].to.name";
	public static final String RELATIONSHIP_STUDYPROTOCOLTOREGULATORYCLASSIFICATION = PropertyUtil.getSchemaProperty("relationship_pgStudyProtocolToRegulatoryClassification");
	public static final String SELECT_RELATIONSHIP_STUDYPROTOCOLTOREGULATORYCLASSIFICATION = "from[" +RELATIONSHIP_STUDYPROTOCOLTOREGULATORYCLASSIFICATION + "].to.name";
	public static final String RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPE = PropertyUtil.getSchemaProperty("relationship_pgStudyProtocolToStudyType");
	public static final String SELECT_RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPE = "from[" +RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPE + "].to.name";

	// SPEC : Added for Defect #38134 -- Govind Start
	public static final String ATTRIBUTE_STUDYPROTOCOLTOSTUDYTYPE = PropertyUtil.getSchemaProperty("attribute_pgIRMStudyTypeFormat");
	public static final String SELECT_STUDYPROTOCOLTOSTUDYTYPE = "attribute[" + ATTRIBUTE_STUDYPROTOCOLTOSTUDYTYPE + "]";
	public static final String RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPTOPLIPANELISTSUP = PropertyUtil.getSchemaProperty("relationship_pgStudyProtocolToPLIPanelistSupervision");
	public static final String SELECT_RELATION_PGSTUDYSUPERVISED="from[" +RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPTOPLIPANELISTSUP + "].to.name";	
	static final String ATTRIBUTE_PGPANELISTQUESTIONAIRE = PropertyUtil.getSchemaProperty(null, "attribute_pgStudyPanelistQuestionaire");
	public static final String SELECT_PGPANELISTQUESTIONAIRE = "attribute[" + ATTRIBUTE_PGPANELISTQUESTIONAIRE + "]";	
	// SPEC : Added for Defect #38134 -- Govind End

	// SPEC: Added for 18x.5.2 DEV --Shashank -- END

	// SPEC: Added for 18x.5.2 DEV --Guna -- START
	public static final String REFERENCEDOCUMENT ="Reference Document";
	public static final String SELECTABLE_REFERENCEDOCUMENT ="relationship["+REFERENCEDOCUMENT+"].from[pgPKGValidationReport].attribute[Title]";
	public static final String VALIDATIONPROTOCOL = "validationProtocol";
	public static final String SELECTABLE_STABILITY_STUDYNUMBER ="to["+REFERENCEDOCUMENT+"].from[pgPKGStabilityProtocol].attribute[pgPKGStabilityStudyNumber]";
	public static final String SELECTABLE_ATTRIBUTE_TITLE ="to["+REFERENCEDOCUMENT+"].from[pgPKGStabilityProtocol].attribute[Title]";
	public static final String STABILITYPROTOCOL = "stabilityProtocol";
	public static final String STABILITYSTUDYNUMBER = "stabilityStudyNumber";
	public static final String PRODUCTSIZEUOM = "productSizeUOM";
	public static final String RELATIONSHIP_PRODUCTFORM = PropertyUtil.getSchemaProperty("relationship_pgProductForm");
	public static final String RELATIONSHIP_PRODUCTSIZEUOM = PropertyUtil.getSchemaProperty("relationship_pgProductSizeUoM");
	public static final String TYPE_PLIPRODUCTFORM = PropertyUtil.getSchemaProperty("type_pgPLIProductForm");
	public static final String TYPE_PLIPACKSIZEUNIT = PropertyUtil.getSchemaProperty("type_pgPLIPackSizeUnit");
	public static final String SELECT_POA_FILE_NAME = "from[" +REFERENCEDOCUMENT + "].to[pgPOADocument].format.file.name";
	public static final String SELECT_POA_FILE_PATH = "from[" +REFERENCEDOCUMENT + "].to[pgPOADocument].format.file.capturedfile";
	public static final String SELECT_ART_FILE_NAME = "from[" +REFERENCEDOCUMENT + "].to[pgIPMDocument].format.file.name";
	public static final String SELECT_ART_FILE_PATH = "from[" +REFERENCEDOCUMENT + "].to[pgIPMDocument].format.file.capturedfile";
	// SPEC: Added for 18x.5.2 DEV --Guna -- END

	// Release SR18x.5.2: Added for Defect 38075 by Amman ## -- START
	public static final String RELATIONSHIP_PGPKGDEVELOPMENTTOAREA = PropertyUtil.getSchemaProperty("relationship_pgPKGDevelopmentToArea");
	public static final String SELECT_ATTRIBUTE_PGPKGDEVELOPMENTTOAREA = "from[" + RELATIONSHIP_PGPKGDEVELOPMENTTOAREA + "].to."+SELECT_NAME;
	// Release SR18x.5.2: Added for Defect 38075 by Amman ## -- END

	// Release SR18x.5.2: Added for Defect 38203 by Amman ## -- START
	public static final String RELATIONSHIP_DATA_VAULT = PropertyUtil.getSchemaProperty("relationship_ProjectVaults");
	public static final String RELATIONSHIP_VAULTDOCUMENTREV2 = PropertyUtil.getSchemaProperty("relationship_VaultedDocumentsRev2");
	public static final String RELATIONSHIP_PGRITASKINPUTS = PropertyUtil.getSchemaProperty("relationship_pgRITaskInputs");
	public static final String TYPE_WORKSPACEVAULT = PropertyUtil.getSchemaProperty("type_ProjectVault");
	// Release SR18x.5.2: Added for Defect 38203 by Amman ## -- END
	//START:: gaikwad.tg :: Defect#38212
	public static final String SELECTABLE_REFERENCEDOCUMENTFORVPROTOCOL ="relationship["+REFERENCEDOCUMENT+"].from.attribute[Title]";
	//END:: gaikwad.tg :: Defect#38212
	// Guna Added for Defect 38711 18x.5.2 Release -- START
	static final String SELECT_ATTRIBUTE_IRMNRQID = "attribute[pgIRMNRQID]";
	// Guna Added for Defect 38711 18x.5.2 Release -- END

	// Aditya Added for Defect 38711 18x.5.2 Release 10/02/2021 -- START
	static final String SELECT_ATTRIBUTE_DOCEXPIRATIONDATE = "attribute[pgDocExpirationDate]";
	// Aditya Added for Defect 38711 18x.5.2 Release 10/02/2021-- END

	//SPEC: Release SR18x.5.2 - Added for Defect #39738 by Bala on Date Feb 15, 2021 -- START
	public static final String SELECT_ATTRIBUTE_STABILITY_STUDY_NUMBER = "attribute[pgPKGStabilityStudyNumber]";
	//SPEC: Release SR18x.5.2 - Added for Defect #39738 by Bala on Date Feb 15, 2021 -- end

	//SPEC: Release SR18x.5.2 - Added for Defect #39790 by Josephine  on Date Feb 16, 2021 -- START
	public static final String RELATIONSHIP_PGDOCUMENTTOSUBTYPE = PropertyUtil.getSchemaProperty("relationship_pgDocumentToSubType");
	public static final String REL_PGDOCUMENTTOSUBTYPE = "from[pgDocumentToSubType].to.name";
	//SPEC: Release SR18x.5.2 - Added for Defect #39790 by Josephine  on Date Feb 16, 2021 -- END

	//SPEC: 24/02/2021: Modified for 18x.6 DEV by Bala-- START
	public static final String TYPE_PGPLIBATTERYSIZE = PropertyUtil.getSchemaProperty("type_pgPLIBatterySize");
	public static final String TYPE_PGPLIYESNO = PropertyUtil.getSchemaProperty("type_pgPLIYesNo");
	public static final String BATTERYDETAILS="batteryDetails";		
	public static final String TYPE_PGPLIBATTERYCHEMISTRY = "pgPLIBatteryChemistry";
	public static final String RELATIONSHIP_PGPLRELATEDDATA = PropertyUtil.getSchemaProperty("relationship_pgPLRelatedData");
	public static final String SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIBATTERYCHEMISTRY = "from["+RELATIONSHIP_PGPLRELATEDDATA+"].to["+TYPE_PGPLIBATTERYCHEMISTRY+"].name";
	public static final String SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIBATTERYSIZE = "from["+RELATIONSHIP_PGPLRELATEDDATA+"].to["+TYPE_PGPLIBATTERYSIZE+"].name";
	public static final String SELECT_RELATIONSHIP_PGPLRELATEDDATA_TO_PGPLIYESNO = "from["+RELATIONSHIP_PGPLRELATEDDATA+"].to["+TYPE_PGPLIYESNO+"].name";
	//SPEC: 24/02/2021: Modified for 18x.6 DEV by Bala-- END


	//SPEC: <22.02.2021>: Sumit Added for Dev 18x.6   -- START
	public static final String RELATIONSHIP_COPYLISTCOUNTRY = PropertyUtil.getSchemaProperty("relationship_CopyListCountry");
	public static final String RELATIONSHIP_PFINGREDIENTSTATEMENT = PropertyUtil.getSchemaProperty("relationship_pgIngredientStatement");
	public static final String STR_RELATIONSHIP_COPYLISTCOUNTRY_NAME ="from["+RELATIONSHIP_COPYLISTCOUNTRY+"].to.name";
	public static final String INGREDIENTSTMTNAME ="ingredientStatementsname";
	public static final String INGREDIENTSTMT = "ingredientStatement";
	public static final String RELATIONSHIP_PGROLLEDUPBATTERY = PropertyUtil.getSchemaProperty("relationship_pgRolledUpBattery");
	public static final String ATTRIBUTE_PGDPPQTYPERCOP = PropertyUtil.getSchemaProperty("attribute_pgDPPQtyperCOP");
	public static final String SELECT_ATTRIBUTE_PGDPPQTYPERCOP = "attribute["+ATTRIBUTE_PGDPPQTYPERCOP+"]";
	public static final String ATTRIBUTE_PGAREBATTERIESINCLUDED = PropertyUtil.getSchemaProperty("attribute_pgAreBatteriesRequired");
	public static final String SELECT_ATTRIBUTE_PGAREBATTERIESINCLUDED = "attribute[" + ATTRIBUTE_PGAREBATTERIESINCLUDED + "]";
	public static final String ATTRIBUTE_PGAREBATTERIESBUILTIN = PropertyUtil.getSchemaProperty("attribute_pgAreBatteriesBuiltIn");
	public static final String SELECT_ATTRIBUTE_PGAREBATTERIESBUILTIN = "attribute[" + ATTRIBUTE_PGAREBATTERIESBUILTIN + "]";
	public static final String DPPQTYPERCOP = "dppQtyPerCOP";
	public static final String BATTERYROLLUP = "batteryRollupObjectData";
	public static final String BATTERYCALCOBJECTDATA = "batteryCalculationObjectData";
	public static final String AREBATTERIESINCLUDED = "arebatteriesincluded";
	public static final String AREBATTERIESBUILTIN = "arebatteriesbuiltin";	
	public static final String CUPARTWORK = "cupartwork";
	public static final String SMARTLABELROLLUPDATA = "smartLabelRollupData";
	public static final String COPLWD = "copLWD";
	public static final String CUPLWD = "cupLWD";
	public static final String IPLWD = "ipLWD";
	//SPEC: <22.02.2021>: Sumit Added for Dev 18x.6   -- END

	//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- START
	public static final String  COCA  = "coCa";
	public static final String RELATIONSHIP_MOSROLLEDUPREGISTRATION = PropertyUtil.getSchemaProperty("relationship_pgMOSRolledUpRegistration");
	public static final String TYPEPATTERN_PGMARKETREGISTRATION = "pgAssembledProductPart,pgDeviceProductPart,Formulation Part,pgConsumerUnitPart,pgFormulatedProduct";
	public static final String ATTRIBUTE_PGPACKSIZEUOM = PropertyUtil.getSchemaProperty("attribute_pgPackSizeUoM");
	public static final String SELECT_ATTRIBUTE_PGPACKSIZEUOM = "attribute[" + ATTRIBUTE_PGPACKSIZEUOM + "]"; 
	public static final String ATTRIBUTE_PGPACKSIZE = PropertyUtil.getSchemaProperty("attribute_pgPackSize");
	public static final String SELECT_ATTRIBUTE_PGPACKSIZE = "attribute[" + ATTRIBUTE_PGPACKSIZE + "]";
	public static final String ATTRIBUTE_PGBUSINESSCHANNEL = PropertyUtil.getSchemaProperty("attribute_pgBusinessChannel");
	public static final String SELECT_ATTRIBUTE_PGBUSINESSCHANNEL = "attribute[" + ATTRIBUTE_PGBUSINESSCHANNEL + "]";
	public static final String ATTRIBUTE_PGLEGALENTITY = PropertyUtil.getSchemaProperty("attribute_pgLegalEntity");
	public static final String SELECT_ATTRIBUTE_PGLEGALENTITY = "attribute[" + ATTRIBUTE_PGLEGALENTITY + "]";
	public static final String ATTRIBUTE_PGMARKETAPPROVERHOLER = PropertyUtil.getSchemaProperty("attribute_pgMarketApproverHolder");
	public static final String SELECT_ATTRIBUTE_PGMARKETAPPROVERHOLER = "attribute[" + ATTRIBUTE_PGMARKETAPPROVERHOLER + "]";
	public static final String COUNTRIESLIST = "CountriesList";
	public static final String PGPRODUCTPARTNAME = "productPartName";
	public static final String PGPRODUCTPARTREVISION = "productPartRevision";
	public static final String PGPRODUCTPARTTITLE = "productPartTitle";
	public static final String PRIMARYPART = "primaryPart";
	public static final String SUBSTITUTEPART = "substitutePart";
	public static final String ALTERNATE = "alternate";
	public static final String REGISTEREDCOUNTRY = "registeredCountry";
	public static final String MARKETAPPROVALHOLDER = "marketApprovalHolder";
	public static final String LEGALENTITY = "legalEntity";
	public static final String BUSINESSCHANNEL = "businessChannel";
	public static final String PACKSIZE = "packSize";
	public static final String PACKSIZEUOM = "packSizeUom";
	public static final String PRODUCTREGISTRATIONNUMBER = "productRegistrationNumber";
	public static final String REGISTRATIONSTATUS = "registrationStatus";
	public static final String REGISTRATIONEXPDATE = "registrationExpirationDate";
	public static final String PGREGISTEREDPRODUCTNAME = "registeredProductName";
	public static final String RESTRICTION = "restriction";
	public static final String GPSCOMMENTS = "gpsComments";
	public static final String PACKINGSITE = "packingSite";
	public static final String BULKMANUFACTURINGSITE = "bulkMakingManufacturingSite";
	public static final String REGISTRATIONDETAILS = "registrationDetails";
	//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- END

	public static final String GPSTYPE = "GPStype";
	public static final String GPSID = "GPSId";
	public static final String GPSNRQOID = "NRQID";
	public static final String GPSNRQTYPE = "NRQTYPE";
	public static final String STATE_COMPLETE = "Complete";
	public static final String STATE_CANCEL = "Cancel";
	public static final String STATE_CREATE = "Create";
	public static final String STATE_ASSIGN = "Assign";
	public static final String GPSALLOWED_TYPES = "pgConsumerUnitPart,pgCustomerUnitPart,Finished Product Part,pgInnerPackUnitPart,pgMasterConsumerUnitPart,pgMasterCustomerUnitPart,pgMasterInnerPackUnitPart,pgMasterPackagingAssemblyPart,pgMasterPackagingMaterialPart,Packaging Material Part,Packaging Assembly Part,Raw Material,pgTransportUnitPart,pgPromotionalItemPart,pgAncillaryPackagingMaterialPart,pgOnlinePrintingPart,pgFabricatedPart,pgMasterProductPart,pgAssembledProductPart,pgDeviceProductPart,pgAncillaryRawMaterialPart,pgMasterRawMaterialPart,Cosmetic Formulation,Formulation Part,pgIntermediateProductPart,pgCompetitiveProductPart,pgSoftwarePart,pgRawMaterial";
	public static final String CONST_PRODUCTCATEGORYPLATFORM = "Product Category Platform";

	//SPEC: <26.02.2021>: Guna Added for Dev 18x.6   -- START
	public static final String SMARTLABELNAME = "smartLabelName";
	public static final String PROPERTIES = "properties";
	public static final String SMARTLABELROW = "smartLabelRow";
	public static final String REL_PG_SMART_LABEL_ROW = PropertyUtil.getSchemaProperty("relationship_pgSmartLabelRow");
	public static final String TYPE_PG_SMART_LABEL_ROW = PropertyUtil.getSchemaProperty("type_pgSmartLabelRow");
	public static final String ATTRIBUTE_PGINGREDIENT = PropertyUtil.getSchemaProperty("attribute_pgIngredient");
	public static final String ATTRIBUTE_PGLAYER = PropertyUtil.getSchemaProperty("attribute_pgLayer");
	public static final String ATTRIBUTE_PGPURPOSE = PropertyUtil.getSchemaProperty("attribute_pgPurpose");
	public static final String ATTRIBUTE_CASNUMBER = PropertyUtil.getSchemaProperty("attribute_CASNumber");
	public static final String ATTRIBUTE_PGCHEMICALSOFCONCERN = PropertyUtil.getSchemaProperty("attribute_pgChemicalsOfConcern");

	public static final String SELECT_ATTRIBUTE_PGINGREDIENT = "attribute["+ATTRIBUTE_PGINGREDIENT+"]";
	public static final String SELECT_ATTRIBUTE_PGLAYER = "attribute["+ATTRIBUTE_PGLAYER+"]";
	public static final String SELECT_ATTRIBUTE_ATTRIBUTE_PGPURPOSE = "attribute["+ATTRIBUTE_PGPURPOSE+"]";
	public static final String SELECT_ATTRIBUTE_ATTRIBUTE_CASNUMBER = "attribute["+ATTRIBUTE_CASNUMBER+"]";
	public static final String SELECT_ATTRIBUTE_ATTRIBUTE_PGCHEMICALSOFCONCERN = "attribute["+ATTRIBUTE_PGCHEMICALSOFCONCERN+"]";
	public static final String GENERICTYPES ="FRAG Corporate transparency,FRAG NY+CA Cleaning Product Compliant,FRAG CA Cosmetic Compliant"; 
	//SPEC: <26.02.2021>: Guna Added for Dev 18x.6   -- END
	//SPEC: <01.03.2021>: Guna Added for Dev 18x.6   -- START
	public static final String INGREDIENT = "ingredient";
	public static final String CONSUMERFRIENDLYDESCRIPTION = "consumerFriendlyDescription";
	public static final String PURPOSE = "purpose";
	public static final String LAYER = "layer";
	public static final String MATERIALSINGREDIENT = "materialsIngredients";
	public static final String FUNCTIONPURPOSE = "functionPurpose";
	public static final String LISTOFCHEMICALS = "listOfChemicals";
	public static final String FRAGRANCEINGREDIENT = "fragranceIngredient";
	public static final String CACLEANING ="CA Cleaning Product Compliant";
	public static final String REL_SMARTLABELNAME ="to[pgSmartLabel|from.current == 'Release'].from.name";
	public static final String REL_SMARTLABELREVISION ="to[pgSmartLabel|from.current == 'Release'].from.revision";
	public static final String REL_SMARTLABELSTATE ="to[pgSmartLabel|from.current == 'Release'].from.current";
	public static final String REL_SMARTLABELID ="to[pgSmartLabel|from.current == 'Release'].from.id";
	//SPEC: <01.03.2021>: Guna Added for Dev 18x.6   -- END

	//SPEC: 03-01-2020: Added for 18x.6 DEV by Sanjeeva -- START
	public static final String ATTRIBUTE_POAIMPACTCONFIRMATION = PropertyUtil.getSchemaProperty("attribute_pgPOAImpactConfirmation");
	public static final String SELECT_ATTRIBUTE_POAIMPACTCONFIRMATION = "attribute[" + ATTRIBUTE_POAIMPACTCONFIRMATION + "]";
	//SPEC: 03-01-2020: Added for 18x.6 DEV by Sanjeeva -- START

	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 01 Mar 2021 -- START
	static final String TYPE_EXTERNAL_MATERIAL= PropertyUtil.getSchemaProperty("type_ExternalMaterial");
	public static final String ATTRIBUTE_PGILMARCHIVALSTATUS = PropertyUtil.getSchemaProperty("attribute_pgILMArchivalStatus");
	public static final String SELECT_ATTRIBUTE_PGILMARCHIVALSTATUS = "attribute[" + ATTRIBUTE_PGILMARCHIVALSTATUS + "]";
	public static final String SELECT_POLICYCLASSIFICATION = "policy.property[PolicyClassification].value";
	public static final String RELATIONSHIP_PGMATERIALTOPGPLIENVCLASS = PropertyUtil.getSchemaProperty("relationship_pgMaterialtopgPLIEnvironmentalClass");
	public static final String SELECTABLE_RELATIONSHIP_PGMATERIALTOPGPLIENVCLASS ="from["+RELATIONSHIP_PGMATERIALTOPGPLIENVCLASS+"].to.name";
	public static final String ATTRIBUTE_PG_POA_IMPACT_CONFIRMATION = PropertyUtil.getSchemaProperty("attribute_pgPOAImpactConfirmation");
	public static final String SELECTABLE_ATTRIBUTE_PG_POA_IMPACT_CONFIRMATION = "attribute[" + ATTRIBUTE_PG_POA_IMPACT_CONFIRMATION + "]";
	public static final String  POAIMPCONF  = "poaImpactConf";
	public static final String  ENVCLASS  = "envClass";
	public static final String RELATIONSHIP_MANUFACTURINGEQUIVALENT = PropertyUtil.getSchemaProperty("relationship_ManufacturerEquivalent");
	public static final String SELECT_MANUFACTURINGEQUIVALENT_FROM_TYPE = "to["+RELATIONSHIP_MANUFACTURINGEQUIVALENT+"].from.type";
	public static final String RELATIONSHIP_SUPPLIEREQUIVALENT = PropertyUtil.getSchemaProperty("relationship_SupplierEquivalent");
	public static final String SELECT_SUPPLIEREQUIVALENT_FROM_TYPE = "to["+RELATIONSHIP_SUPPLIEREQUIVALENT+"].from.type";
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 01 Mar 2021 -- END

	//SPEC: 03-03-2021: Added for 18x.6 DEV by Jwala -- START
	public static final String SELECT_SUBSTITUTE = "from[EBOM].frommid[EBOM Substitute]";
	public static final String SELECT_ALTERNATE = "from[Alternate]";
	public static final String SELECT_REGCOUNTRY = "from[pgProductCountryClearance].to.name";
	public static final String KEY_PRIMARY="Primary";
	public static final String KEY_SUBSTITUTE="Substitute";
	public static final String KEY_ALTERNATE="Alternate";
	public static final String KEY_EBOMCHILDREN="EBOMChildren";

	public static final String ATTRIBUTE_PGMOSROLLEDUPASSEMBLEDTYPE = PropertyUtil.getSchemaProperty("attribute_pgMOSRolledupAssembleType");
	public static final String SELECT_ATTRIBUTE_PGMOSROLLEDUPASSEMBLEDTYPE = "attribute[" + ATTRIBUTE_PGMOSROLLEDUPASSEMBLEDTYPE + "]";
	//SPEC: 03-03-2021: Added for 18x.6 DEV by Jwala -- END

	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 3, 2021 -- START
	public static final String BASECODETYPE = "baseCodeType";
	public static final String CHILDNAMETYPE = "childNameType";
	public static final String BASECODEID = "baseCodeID";
	public static final String CHILDNAMEID = "childNameID";
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 3, 2021 -- END
	//SPEC: 03/03/2021: Modified for 18x.6 DEV by Bala-- START
	public static final String ATTR_PG_ARTWORK_SECONDARY	 = PropertyUtil.getSchemaProperty("attribute_pgArtworkSecondary");
	public static final String SELECT_ATTR_PG_ARTWORK_SECONDARY = "attribute[" + ATTR_PG_ARTWORK_SECONDARY + "]";
	public static final String ARTWORKSECONDARY="artworkSecondary";
	//SPEC: 03/03/2021: Modified for 18x.6 DEV by Bala-- END	

	//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 02/03/2021 -- START
	public static final String PARTSASSOCIATION = "partsAssociation";
	public static final String ATTRIBUTE_PACKINGLEVEL = PropertyUtil.getSchemaProperty("attribute_pgAAA_PackagingLevel");
	public static final String SELECT_ATTRIBUTE_PACKINGLEVEL = "attribute[" + ATTRIBUTE_PACKINGLEVEL + "]";
	public static final String ATTRIBUTE_ARTWORKUSAGE = PropertyUtil.getSchemaProperty("attribute_ArtworkUsage");
	public static final String SELECT_ATTRIBUTE_ARTWORKUSAGE = "attribute[" + ATTRIBUTE_ARTWORKUSAGE + "]";
	public static final String ATTRIBUTE_ARTWORKBASIS = PropertyUtil.getSchemaProperty("attribute_ArtworkBasis");
	public static final String SELECT_ATTRIBUTE_ARTWORKBASIS = "attribute[" + ATTRIBUTE_ARTWORKBASIS + "]";
	public static final String ATTRIBUTE_FPCCODE = PropertyUtil.getSchemaProperty("attribute_pgAAA_FinishedProductCode");
	public static final String SELECT_ATTRIBUTE_FPCCODE = "attribute[" + ATTRIBUTE_FPCCODE + "]";
	public static final String ATTRIBUTE_OLDIPMS = PropertyUtil.getSchemaProperty("attribute_pgAAA_OldIPMS");
	public static final String SELECT_ATTRIBUTE_OLDIPMS = "attribute[" + ATTRIBUTE_OLDIPMS + "]";
	public static final String ATTRIBUTE_PRINTER = PropertyUtil.getSchemaProperty("attribute_pgAAA_Printer");
	public static final String SELECT_ATTRIBUTE_PRINTER = "attribute[" + ATTRIBUTE_PRINTER + "]";
	public static final String ATTRIBUTE_ADDDESCRIPTION = PropertyUtil.getSchemaProperty("attribute_pgAAA_AdditionalDescription");
	public static final String SELECT_ATTRIBUTE_ADDDESCRIPTION = "attribute[" + ATTRIBUTE_ADDDESCRIPTION + "]";
	public static final String REL_SUPPLIERPOA = PropertyUtil.getSchemaProperty("relationship_SupplierPOA");
	public static final String SELECT_REL_SUPPLIERPOANAME = "to[" + REL_SUPPLIERPOA + "].from.name";
	public static final String REL_PRINTINGPROCESS = PropertyUtil.getSchemaProperty("relationship_pgAAA_POATopgPLIPrintingProcess");
	public static final String SELECT_REL_PRINTINGPROCESS = "from[" + REL_PRINTINGPROCESS + "].to.name";
	public static final String REL_POALANGUAGES = PropertyUtil.getSchemaProperty("relationship_POALocalLanguage");
	public static final String SELECT_REL_POALANGUAGES = "from[" + REL_POALANGUAGES + "].to.name";
	public static final String ATTRIBUTE_CUSTOMIPMS = PropertyUtil.getSchemaProperty("attribute_pgAAA_CustomIPMS");
	public static final String SELECT_ATTRIBUTE_CUSTOMIPMS = "attribute[" + ATTRIBUTE_CUSTOMIPMS + "]";
	public static final String SUPPLIER = "supplier";
	public static final String ARTWORKUSAGE = "artworkUsage";
	public static final String ARTWORKBASIS = "artworkBasis";
	public static final String OLDIPMS = "oldipmspmpopp";
	public static final String PRINTER = "printer";
	public static final String SECONDARYPRINTER = "secondaryPrinter";
	public static final String FPCCODE = "finishProductCode";
	public static final String PACKINGMATERIALTYPE = "packagingMaterialType";
	public static final String CASECOUNT = "caseCount";
	public static final String CASETYPE = "caseType";
	public static final String PRINTINGPROCESS = "printingProcess";
	public static final String ADDDESCRIPTION = "additionalDescription";
	public static final String PACKINGLEVEL = "packagingLevel";
	public static final String COMMENTS = "comments";
	public static final String LANGUAGES = "languages";
	public static final String STR_CUSTOMSPEC = "No";
	public static final String TYPE_PGPACKINGMATERIAL = PropertyUtil.getSchemaProperty("type_pgPackingMaterial");

	public static final String ATTRIBUTE_ADDRESS = PropertyUtil.getSchemaProperty("attribute_Address");
	public static final String ATTRIBUTE_CITY = PropertyUtil.getSchemaProperty("attribute_City" );
	public static final String ATTRIBUTE_COUNTRY = PropertyUtil.getSchemaProperty("attribute_Country");
	public static final String SELECT_ATTRIBUTE_ADDRESS = "attribute["+ATTRIBUTE_ADDRESS+"]";
	public static final String SELECT_ATTRIBUTE_CITY = "attribute["+ATTRIBUTE_CITY+"]";
	public static final String SELECT_ATTRIBUTE_COUNTRY = "attribute["+ATTRIBUTE_COUNTRY+"]";
	public static final String STR_ATTR_PG_ARTWORK_SECONDARY = PropertyUtil.getSchemaProperty("attribute_pgArtworkSecondary");
	public static final String REL_CASETYPE = PropertyUtil.getSchemaProperty("relationship_pgAAA_POATopgPLICaseType");
	public static final String SELECT_REL_CASETYPE = "from[" + REL_CASETYPE + "].to.name";
	public static final String RELATIONSHIP_ARTWORK_TEMPLATE_TO_POA = PropertyUtil.getSchemaProperty("relationship_pgAAA_ArtworkTemplateToPOA");
	public static final String RELATIONSHIP_ACTIVE_VERSION = PropertyUtil.getSchemaProperty("relationship_ActiveVersion");
	//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 20/03/2021 -- START
	//public static final String TYPE_CIC = PropertyUtil.getSchemaProperty("type_CIC");
	public static final String TYPE_CIC = PropertyUtil.getSchemaProperty("type_pgAAA_CIC");
	//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 20/03/2021 -- END
	public static final String ARTWORK_FILE = PropertyUtil.getSchemaProperty("type_ArtworkFile");
	public static final String FILEVERSION = "version";
	public static final String SELECT_ACTIVEVERSION = "from[" + RELATIONSHIP_ACTIVE_VERSION + "].to.revision";
	public static final String ATTRIBUTE_CASECOUNT = PropertyUtil.getSchemaProperty("attribute_pgAAA_CaseCount");
	public static final String CASECOUNTKEY = "NA";
	public static final String FPPKEY  = "FPP-";
	//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 02/03/2021 -- END

	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- START
	public static final String INGREDIENTSTMTTYPE ="ingredientStatementsType";
	public static final String INGREDIENTSTMTID ="ingredientStatementsID";
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- END

	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- START
	public static final String COPGW = "copGW";
	public static final String CUPGW = "cupGW";
	public static final String IPGW = "ipGW";
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- END

	//SPEC: 05-03-2021: Added for 18x.6 DEV by Chandra -- START
	public static final String POLICY_ENGINEERING_CHANGE_STANDARD = PropertyUtil
			.getSchemaProperty("policy_EngineeringChangeStandard");

	public static final String RELATIONSHIP_DERIVED_ABSTRACT = PropertyUtil.getSchemaProperty("relationship_DERIVED_ABSTRACT");
	public static final String RELATIONSHIP_MAIN_DERIVED = PropertyUtil.getSchemaProperty("relationship_MainDerived");

	public static final String ACTIVECHANGEEXISTS = "activChangeExists";
	public static final String HIGHER_REV_EXISTS = "highRevExists";

	public static final String PRODUCT_BUILD_TYPE ="to[relationship_ProductBuild].businessobject.type";
	public static final String PRODUCT_BUILD_ID ="to[relationship_ProductBuild].businessobject.id";
	public static final String PRODUCT_BUILD_NAME ="to[relationship_ProductBuild].businessobject.name";

	public static final String PRODUCT_CONFIGURATION_TYPE ="to[relationship_ProductConfigurationBuild].from.type";
	public static final String PRODUCT_CONFIGURATION_ID ="to[relationship_ProductConfigurationBuild].from.id";
	public static final String PRODUCT_CONFIGURATION_NAME ="to[relationship_ProductConfigurationBuild].from.name";


	public static final String STR_PRODUCT_BUILD_TYPE ="prodBuildType";
	public static final String STR_PRODUCT_BUILD_ID ="prodBuildId";
	public static final String STR_PRODUCT_BUILD_NAME ="prodBuildName";

	public static final String STR_PRODUCT_CONFIGURATION_TYPE ="prodConfigType";
	public static final String STR_PRODUCT_CONFIGURATION_ID ="prodConfigId";
	public static final String STR_PRODUCT_CONFIGURATION_NAME ="prodConfigName";

	public static final String ATTRIBUTE_PGBUILDPATH =  PropertyUtil.getSchemaProperty("attribute_pgBuildPath");
	public static final String SELECT_ATTRIBUTE_PGBUILDPATH = "attribute[" + ATTRIBUTE_PGBUILDPATH + "]";

	public static final String RELATIONSHIP_ASSIGNEDPART = PropertyUtil.getSchemaProperty("relationship_AssignedPart");
	public static final String REL_ASSIGNED_PART_NAME = "from["+RELATIONSHIP_ASSIGNEDPART+"].to.name";
	public static final String REL_ASSIGNED_PART_ID = "from["+RELATIONSHIP_ASSIGNEDPART+"].to.id";
	public static final String REL_ASSIGNED_PART_TYPE = "from["+RELATIONSHIP_ASSIGNEDPART+"].to.type";
	public static final String REL_ASSIGNED_PART_REV = "from["+RELATIONSHIP_ASSIGNEDPART+"].to.revision";


	public static final String STR_ASSIGNED_PART_TYPE ="assignedPartType";
	public static final String STR_ASSIGNED_PART_ID ="assignedPartId";
	public static final String STR_ASSIGNED_PART_NAME ="assignedPartName";
	public static final String STR_ASSIGNED_PART_REV ="assignedPartRev";
	public static final String STR_DESIGN_RESPONSIBILITY ="designResponsibility";

	public static final String ATTRIBUTE_BUILD_UNIT_NUM =  PropertyUtil.getSchemaProperty("attribute_BuildUnitNumber");
	public static final String SELECT_ATTRIBUTE_BUILD_UNIT_NUM = "attribute[" + ATTRIBUTE_BUILD_UNIT_NUM + "]";
	public static final String BUILD_UNIT_NUM ="buildUnitNum";

	public static final String ATTRIBUTE_PLANNED_BUILD_DATE =  PropertyUtil.getSchemaProperty("attribute_PlannedBuildDate");
	public static final String SELECT_ATTRIBUTE_PLANNED_BUILD_DATE = "attribute[" + ATTRIBUTE_PLANNED_BUILD_DATE + "]";
	public static final String BUILD_PLANNED_DATE ="buildPlannedDate";

	public static final String ATTRIBUTE_SHORTH_HAND_NOTATION =  PropertyUtil.getSchemaProperty("attribute_Prefix");
	public static final String SELECT_ATTRIBUTE_SHORTH_HAND_NOTATION = "attribute[" + ATTRIBUTE_SHORTH_HAND_NOTATION + "]";
	public static final String BUILD_SHORTHAND_NOTATION ="shorthhandNotation";

	public static final String ATTRIBUTE_BUILD_SERIAL_NUM =  PropertyUtil.getSchemaProperty("attribute_BuildSerialNumber");
	public static final String SELECT_ATTRIBUTE_BUILD_SERIAL_NUM = "attribute[" + ATTRIBUTE_BUILD_SERIAL_NUM + "]";
	public static final String BUILD_SERIAL_NUM ="buildserialNum";

	public static final String ATTRIBUTE_DATE_SHIPPED =  PropertyUtil.getSchemaProperty("attribute_DateShipped");
	public static final String SELECT_ATTRIBUTE_DATE_SHIPPED = "attribute[" + ATTRIBUTE_DATE_SHIPPED + "]";
	public static final String BUILD_DATE_SHIPPED ="dateShipped";
	public static final String ATTRIBUTE_ACTUAL_BUILD_DATE =  PropertyUtil.getSchemaProperty("attribute_ActualBuildDate");
	public static final String SELECT_ATTRIBUTE_ACTUAL_BUILD_DATE = "attribute[" + ATTRIBUTE_ACTUAL_BUILD_DATE + "]";
	public static final String BUILD_ACTUAL_DATE ="buildActualDate";
	// SPEC Added on 05-April-2021 by Chandra for Defect 42125 --START
	/*	public static final String REL_CUSTOMER_TYPE = "to[relationship_CustomerUnit].from.type";
		public static final String REL_CUSTOMER_NAME = "to[relationship_CustomerUnit].from.name";
		public static final String REL_CUSTOMER_ID = "to[relationship_CustomerUnit].from.id";
	*/
	public static final String REL_CUSTOMER_TYPE = "to[Customer Unit].from.type";
	public static final String REL_CUSTOMER_NAME = "to[Customer Unit].from.name";
	public static final String REL_CUSTOMER_ID = "to[Customer Unit].from.id";
	// SPEC Added on 05-April-2021 by Chandra for Defect 42125 --END
	
	public static final String STR_CUSTOMER_TYPE ="customerType";
	public static final String STR_CUSTOMER_ID ="customerId";
	public static final String STR_CUSTOMER_NAME ="customerName";
	// SPEC Added on 05-April-2021 by Chandra for Defect 42126 --START
	//public static final String REL_MANUFACTURING_PLANT_NAME ="from[relationship_ManufacturingPlant].to.name";
	public static final String REL_MANUFACTURING_PLANT_NAME ="from[Manufacturing Plant].to.name";
	// SPEC Added on 05-April-2021 by Chandra for Defect 42126 --END
	
	public static final String STR_MANUF_PLANT_NAME ="plantName";
	public static final String CUSTOMERINFO = "customerInfo";
	public static final String PARTINFO = "partInfo";
	public static final String PRODUCTEFECTIVITY = "prodEffectiveInfo";
	public static final String GENINFO = "genrealInfo";
	public static final String CHANGEINFO = "changeInfo";

	//SPEC: 05-03-2021: Added for 18x.6 DEV by Chandra -- END
	//SPEC: 08/03/2021: Added for 18x.6 DEV by BALA -- START
	public static final String Stability_Document_AllowedParts = "pgAssembledProductPart,pgDeviceProductPart,Formulation Part";
	//SPEC: 08/03/2021: Added for 18x.6 DEV by BALA -- END

	//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- START
	public static final String STATEREVISION = "stateRevision";
	//SPEC: 03-08-2020: Added for 18x.6 DEV by Sanjeeva -- START

	//SPEC: Release SR18x.6.0 - Modified for ART-DSMPOA  by Dominic on Date 08/03/2021 -- START
	public static final String ART = "Art";
	public static final String ARTWORKLANGAUGE = "artworkLanguage";
	//SPEC: Release SR18x.6.0 - Modified for ART-DSMPOA  by Dominic on Date 08/03/2021 -- END

	//SPEC: 05-Mar-2020: Added for 18x.6 DEV by Ganesh -- START
	public static final String MATERIALCOMPANYNAME="materialCompanyName";
	public static final String MATERIALCOMPANYID="materialCompanyId";
	public static final String INTERNALMATERIALNUMBER="internalMaterialNumber";
	public static final String STANDARDMATERIALNUMBER="standardMaterialNumber";
	public static final String EXTERNALREVISIONDATE="externalRevisionDate";
	public static final String EXTERNALREVISIONLEVEL="externalRevisionLevel";
	public static final String ATTRIBUTE_EXTERNALREVISIONLEVEL = PropertyUtil.getSchemaProperty("attribute_ExternalRevisionLevel");
	public static final String ATTRIBUTE_EXTERNALREVISIONDATE = PropertyUtil.getSchemaProperty("attribute_ExternalRevisionDate");
	public static final String ATTRIBUTE_MATERIALNUMBER = PropertyUtil.getSchemaProperty("attribute_MaterialNumber");
	public static final String ATTRIBUTE_STANDARDMATERIALNUMBER = PropertyUtil.getSchemaProperty("attribute_StandardMaterialNumber");
	public static final String SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL= "attribute[" + ATTRIBUTE_EXTERNALREVISIONLEVEL + "]";
	public static final String SELECT_ATTRIBUTE_EXTERNALREVISIONDATE= "attribute[" + ATTRIBUTE_EXTERNALREVISIONDATE + "]";
	public static final String SELECT_ATTRIBUTE_MATERIALNUMBER= "attribute[" + ATTRIBUTE_MATERIALNUMBER + "]";
	public static final String SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER= "attribute[" + ATTRIBUTE_STANDARDMATERIALNUMBER + "]";
	public static final String RELATIONSHIP_PGMATERIALTOCOMPANY = PropertyUtil.getSchemaProperty("relationship_pgMaterialToCompany");
	public static final String REL_COMPANY_NAME = "from[pgMaterialToCompany].to.name";
	public static final String ATTRIBUTE_PGSHORTCODE = PropertyUtil.getSchemaProperty("attribute_pgShortCode");
	public static final String SELECT_ATTRIBUTE_PGSHORTCODE = "attribute[" + ATTRIBUTE_PGSHORTCODE + "]";
	public static final String REL_ATTRIBUTE_COMPANY_ID = "from[pgMaterialToCompany].to.attribute[pgShortCode].value";
	//SPEC: 05-Mar-2020: Added for 18x.6 DEV by Ganesh -- END
	//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- START
	//SPEC: <23.03.2021>: Guna Modified for Defect 41379 Dev 18x.6   -- START
	//SPEC: 21.10.2021: Jwala Modified for 43831 Defect  Dev 18x.6.0.2   -- START
	public static final String REFERENCE_DOCUMENT_TITLE= "relationship[Reference Document].to.attribute[Title]";
	//SPEC: 21.10.2021: Jwala Modified for 43831 Defect  Dev 18x.6.0.2   -- START
	//SPEC: <23.03.2021>: Guna Modified for Defect 41379 Dev 18x.6   -- END
	public static final String SUMMARIES= "summaries";
	public static final String REL_TECHNIQUE_USED= "from[pgStudyProtocolToConsumerTestTechnique].to.name"; 
	public static final String TECHNIQUEUSED ="techniqueUsed";
	public static final String TECHNIQUEOTHER ="techniqueOther";
	public static final String FEEDBACKTYPE ="feedbackType";
	public static final String OBJECTIVETYPE ="objectiveType";
	public static final String OBJECTIVETYPEOTHER ="objectiveTypeOthers";
	public static final String DESCRIPTIONMETHODOLOGY ="descriptionMethodology";
	public static final String PURCHASEINTENT ="purchaseIntent";
	public static final String TSCAINGREDIENTS ="tscaIngredient";
	public static final String PANELISTPURCHASEINTENT ="panelistPurchaseIntent";
	public static final String NATIVENUMBER ="nativeNumber";
	public static final String EXPERIENCEDNUMBER ="experiencedNumber";
	public static final String RECONTACTNUMBER ="recontactNumber";
	public static final String GRANTEDCONSENT ="grantedConsent";
	public static final String PANELISTTASKOTHER ="panelistTaskOther";
	public static final String STABILITYTESTING ="stabilityTesting";
	public static final String ATTRIBUTE_TECHNIQUEOTHER = PropertyUtil.getSchemaProperty("attribute_pgTechniqueOther");
	public static final String SELECT_ATTRIBUTE_TECHNIQUEOTHER= "attribute[" + ATTRIBUTE_TECHNIQUEOTHER + "]";
	public static final String ATTRIBUTE_DESCRIPTIONMETHODOLOGY = PropertyUtil.getSchemaProperty("attribute_pgDescriptionMethodology");
	public static final String SELECT_ATTRIBUTE_DESCRIPTIONMETHODOLOGY= "attribute[" + ATTRIBUTE_DESCRIPTIONMETHODOLOGY + "]";
	public static final String ATTRIBUTE_OBJECTIVETYPEOTHER = PropertyUtil.getSchemaProperty("attribute_pgObjectiveTypeOther");
	public static final String SELECT_ATTRIBUTE_OBJECTIVETYPEOTHER= "attribute[" + ATTRIBUTE_OBJECTIVETYPEOTHER + "]";
	public static final String ATTRIBUTE_PURCHASEINTENT = PropertyUtil.getSchemaProperty("attribute_pgStudyPanelistPurchaseIntent");
	public static final String SELECT_ATTRIBUTE_PURCHASEINTENT= "attribute[" + ATTRIBUTE_PURCHASEINTENT + "]";
	public static final String ATTRIBUTE_TSCAINGREDIENTS = PropertyUtil.getSchemaProperty("attribute_pgNonTSCAIngredients");
	public static final String SELECT_ATTRIBUTE_TSCAINGREDIENTS= "attribute[" + ATTRIBUTE_TSCAINGREDIENTS + "]";
	public static final String ATTRIBUTE_PANELISTPURCHASEINTENT = PropertyUtil.getSchemaProperty("attribute_pgPanelistPurchaseIntent");
	public static final String SELECT_ATTRIBUTE_PANELISTPURCHASEINTENT= "attribute[" + ATTRIBUTE_PANELISTPURCHASEINTENT + "]";
	public static final String REL_FEEDBACKTYPE= "from[pgStudyProtocolToConsumerTestFeedbackType].to.name";
	public static final String ATTRIBUTE_EXPERIENCEDNUMBER = PropertyUtil.getSchemaProperty("attribute_pgExperiencedNumber");
	public static final String SELECT_ATTRIBUTE_EXPERIENCEDNUMBER= "attribute[" + ATTRIBUTE_EXPERIENCEDNUMBER + "]";
	public static final String ATTRIBUTE_NATIVENUMBER = PropertyUtil.getSchemaProperty("attribute_pgNaiveNumber");
	public static final String SELECT_ATTRIBUTE_NATIVENUMBER= "attribute[" + ATTRIBUTE_NATIVENUMBER + "]";
	public static final String ATTRIBUTE_RECONTACTNUMBER = PropertyUtil.getSchemaProperty("attribute_pgRecontactNumber");
	public static final String SELECT_ATTRIBUTE_RECONTACTNUMBER= "attribute[" + ATTRIBUTE_RECONTACTNUMBER + "]";
	public static final String ATTRIBUTE_GRANTEDCONSENT = PropertyUtil.getSchemaProperty("attribute_pgGrantedConsent");
	public static final String SELECT_ATTRIBUTE_GRANTEDCONSENT= "attribute[" + ATTRIBUTE_GRANTEDCONSENT + "]";
	public static final String ATTRIBUTE_PANELISTTASKOTHER = PropertyUtil.getSchemaProperty("attribute_pgPanelistTaskOther");
	public static final String SELECT_ATTRIBUTE_PANELISTTASKOTHER= "attribute[" + ATTRIBUTE_PANELISTTASKOTHER + "]";
	public static final String ATTRIBUTE_STABILITYTESTING = PropertyUtil.getSchemaProperty("attribute_pgPanelistStabilityTesting");
	public static final String SELECT_ATTRIBUTE_STABILITYTESTING= "attribute[" + ATTRIBUTE_STABILITYTESTING + "]";
	public static final String RELATIONSHIP_PGREGIONMATERIALCERT = PropertyUtil.getSchemaProperty("relationship_pgPLIRegionCertified");
	public static final String RELATIONSHIP_PGAREAMATERIALCERT = PropertyUtil.getSchemaProperty("relationship_pgPLIAreaCertified");
	public static final String RELATIONSHIP_PGGROUPTOPMATERIALCERT = PropertyUtil.getSchemaProperty("relationship_pgPLIGroupCertified");
	public static final String SELECT_RELATIONSHIP_REGIONMATERIALCERT ="tomid["+RELATIONSHIP_PGREGIONMATERIALCERT+"].from.name";
	public static final String SELECT_RELATIONSHIP_AREAMATERIALCERT ="tomid["+RELATIONSHIP_PGAREAMATERIALCERT+"].from.name";
	public static final String SELECT_RELATIONSHIP_GROUPTOPMATERIALCERT ="tomid["+RELATIONSHIP_PGGROUPTOPMATERIALCERT+"].from.name";
	//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- END

	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- START
	public static final String ATTRIBUTE_AREBATTERIESINCLUDED = PropertyUtil.getSchemaProperty("attribute_pgAreBatteriesIncluded");
	public static final String SELECT_ATTRIBUTE_AREBATTERIESINCLUDED = "attribute[" + ATTRIBUTE_AREBATTERIESINCLUDED + "]";
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- END
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- START
	public static final String ATTRIBUTE_ORGANIZATION_TYPE = PropertyUtil.getSchemaProperty("attribute_OrganizationType");
	public static final String SELECT_ATTRIBUTE_ORGANIZATIONTYPE = "attribute[" + ATTRIBUTE_ORGANIZATION_TYPE + "]";
	public static final String  VENDORTYPE = "vendorType";
	public static final String  VENDOORZIPPOSTALCODE = "vendorZipPostalCode";
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- START
	//SPEC: Release SR18x.6.0 - Added for Defect 40907  by Dominic on Date 16/03/2021 -- START
	public static final String ATTRIBUTE_POACOMMENTS = PropertyUtil.getSchemaProperty("attribute_pgAAA_POA_Comments");
	public static final String SELECT_ATTRIBUTE_POACOMMENTST= "attribute[" + ATTRIBUTE_POACOMMENTS + "]";
	//SPEC: Release SR18x.6.0 - Added for Defect 40907  by Dominic on Date 16/03/2021 -- END

	//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 16, 2021 for Defect#40802 -- START
	public static final String ATTRIBUTE_PGREPLACEDPRODUCTNAME = PropertyUtil.getSchemaProperty("attribute_pgReplacedProductName");
	public static final String SELECT_ATTRIBUTE_PGREPLACEDPRODUCTNAME = "attribute[" + ATTRIBUTE_PGREPLACEDPRODUCTNAME + "]"; 
	//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 16, 2021 for Defect#40802 -- END

	//SPEC: Release SR18x.6.0 - Added by Jwala on Mar 16, 2021 -- START
	public static final String ELECTRONICDISTRIBUTION = "pgElectronicDistribution";
	public static final String OTHERDISTRIBUTIONLIST = "pgOtherDistributionList";
	//SPEC: Release SR18x.6.0 - Added by Jwala on Mar 16, 2021 -- END

	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 for Defect 40855 -- START
	public static final String STR_RELATIONSHIP_COPYLISTLOCALLANGUAGE_NAME = "from["+ConstantsUtil.RELATIONSHIP_COPYLISTLOCALLANGUAGE+"].to.name";
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 for Defect 40855 -- END

	//SPEC: Release SR18x.6.0 - Added for Registration Details  by Dominic on Date 17/03/2021 -- START
	public static final String OVERALLCLEARANCESTATUS = "overallClearanceStatus";
	public static final String GPSAPPROVALSTATUS = "gpsApprovalStatus";
	public static final String CLEARANCENUMBER = "clearanceNumber";
	//SPEC: Release SR18x.6.0 - Added for Registration Details  by Dominic on Date 17/03/2021 -- END

	public static final String STR_CONSTANT_TABLE = "table";
	public static final String STR_TABLE_PG_INGREDIENT_TABLE = "pgIngredientStatementTable";
	public static final String STR_TABLE_PG_MASTER_COPY_ELEMENT_TABLE = "pgMasterCopyElementTable";
	public static final String TYPE_MASTER_COPY_ELEMENT = PropertyUtil.getSchemaProperty("type_MasterCopyElement");
	public static final String TYPE_COPY_ELEMENT = PropertyUtil.getSchemaProperty("type_CopyElement");
	public static final String REL_COPY_LIST_ARTWORK_MASTER = PropertyUtil.getSchemaProperty("relationship_CopyListArtworkMaster");
	public static final String REL_ARTWORK_ASSEMLY = PropertyUtil.getSchemaProperty("relationship_ArtworkAssembly");
	public static final String REL_ARTWORK_ELEMENT_CONTENT = PropertyUtil.getSchemaProperty("relationship_ArtworkElementContent");
	public static final String ATTR_IS_BASE_COPY = PropertyUtil.getSchemaProperty("attribute_IsBaseCopy");
	public static final String ATTR_COPY_TEXT_LANGUAGE = PropertyUtil.getSchemaProperty("attribute_CopyTextLanguage");
	public static final String INIT_CAPS_YES = "Yes";
	public static final String CONSTANT_ENGLISH_US = "English_US";
	public static final String ATTR_PG_AICN = PropertyUtil.getSchemaProperty("attribute_pgAICN");
	public static final String SELECT_ATTR_PG_AICN= "attribute[" + ATTR_PG_AICN + "]";
	public static final String ATTR_PG_ADJ_TARGET = PropertyUtil.getSchemaProperty("attribute_pgAdjTarget");
	public static final String SELECT_ATTR_PG_ADJ_TARGET= "attribute[" + ATTR_PG_ADJ_TARGET + "]";
	public static final String ATTR_COMMON_NAME = PropertyUtil.getSchemaProperty("attribute_CommonName");
	public static final String SELECT_ATTR_COMMON_NAME= "attribute[" + ATTR_COMMON_NAME + "]";
	public static final String CONST_REL="relationship[";
	//SPEC: 02-26-2020: Added for 18x.6 DEV by Sanjeeva -- START

	public static final String CA = "ca";
	//SPEC: 02-26-2020: Added for 18x.6 DEV by Sanjeeva -- END
	//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- START
	public static final String SETPRODUCTNAME="setProductName";
	public static final String ATTRIBUTE_SETPRODUCTNAME = PropertyUtil.getSchemaProperty("attribute_pgSetProductName");
	public static final String SELECT_ATTRIBUTE_SETPRODUCTNAME= "attribute[" + ATTRIBUTE_SETPRODUCTNAME + "]";
	//SPEC: 03-2-2020: Added for 18x.6 DEV by Ganesh -- END

	//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- START
	public static final String REL_ROUTE_SEQUENCE="from[Object Route].to[Route].from[Route Node].attribute[Route Sequence].value";
	public static final String ROUTE_SEQUENCE="routeSequence";
	//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- END

	//SPEC: <19.03.2021>: Guna Added for Internal Defect 18x.6   -- START
	public static final String ATTRIBUTE_PGPANELISTRANGENOTPROVIDED = PropertyUtil.getSchemaProperty("attribute_pgPanelistRangeNotProvided");
	public static final String SELECT_ATTRIBUTE_PGPANELISTRANGENOTPROVIDED = "attribute[" + ATTRIBUTE_PGPANELISTRANGENOTPROVIDED + "]"; 
	public static final String SYMBOL_CAP = "^";
	//SPEC: <19.03.2021>: Guna Added for Internal Defect 18x.6   -- END

	public static final String CONST_RELATIONSHIPTYPE = "RelationshipType";
	public static final String CONST_REACHSTATUS = "ReachStatus";
	public static final String CONST_REACHREGNUM = "ReachRegistrationNumber";
	public static final String CONST_EP = "EP";
	public static final String CONST_MEP = "MEP";
	public static final String CONST_SEP = "SEP";
	public static final String CONST_MCP = "MCP";

	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 24 Feb 2021 -- START
	public static final String RELATIONSHIP_PGPLIREGION = PropertyUtil.getSchemaProperty("relationship_pgPLIRegionTopgPLIMaterialCertifications");
	public static final String RELATIONSHIP_PGPLIAREA = PropertyUtil.getSchemaProperty("relationship_pgPLIAreaTopgPLIMaterialCertifications");
	public static final String RELATIONSHIP_PGCPLIGROUP = PropertyUtil.getSchemaProperty("relationship_pgPLIGroupTopgPLIMaterialCertifications");
	public static final String AREAFORCERT = "area";
	public static final String GPTOMARKET = "gptomarket";
	public static final String CERTIFICATIONVALIDATION  = "certificationvalidation";
	public static final String RELTYPE  = "reltype";
	public static final String REGNO  = "regno";
	public static final String EXPDATE  = "expdate";
	public static final String CERTSTATE  = "maturitystate";
	public static final String CERTSTATUS = "certificationstatus";
	public static final String CERTF  = "certification";
	public static final String MARKET_APPROVAL_HOLDER  = "marketapprovalholder";
	public static final String LEGEL_ENTITY  = "legalentity";
	public static final String BUSINESS_CHANNEL  = "businesschannel";
	public static final String PACK_SIZE  = "packsize";
	public static final String PACK_SIZE_UOM  = "packsizeuom";

	public static final String RELATIONSHIP_SUBSTITUTE = PropertyUtil.getSchemaProperty("relationship_Substitute");
	public static final String CONSTANT_STRING_COMMA = ",";
	public static final String BLANK_SPACE = " ";
	public static final String CONST_REACH = "REACH";
	public static final String ATTRIBUTE_PGMARKETAPPROVALHOLDER = PropertyUtil.getSchemaProperty("attribute_pgMarketApproverHolder");
	public static final String ATTRIBUTE_PGLEGELENTITY = PropertyUtil.getSchemaProperty("attribute_pgLegalEntity");

	public static final String SELECT_ATTRIBUTE_PGMARKETAPPROVALHOLDER= "attribute[" + ATTRIBUTE_PGMARKETAPPROVALHOLDER + "]";
	public static final String SELECT_ATTRIBUTE_PGLEGELENTITY= "attribute[" + ATTRIBUTE_PGLEGELENTITY + "]";
	public static final String RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE = PropertyUtil.getSchemaProperty("relationship_pgProductCountryClearance");
	public static final String STR_COUNTRY_PGMARKETAPPROVALHOLDER = "from[" + RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE + "]."+SELECT_ATTRIBUTE_PGMARKETAPPROVALHOLDER;
	public static final String STR_COUNTRY_PGLEGELENTITY = "from[" + RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE + "]."+SELECT_ATTRIBUTE_PGLEGELENTITY;
	public static final String STR_COUNTRY_PGBUSINESSCHANNEL = "from[" + RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE + "]."+SELECT_ATTRIBUTE_PGBUSINESSCHANNEL;
	public static final String STR_COUNTRY_PGPACKSIZEUOM = "from[" + RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE + "]."+SELECT_ATTRIBUTE_PGPACKSIZEUOM;
	public static final String STR_COUNTRY_PGPACKSIZE = "from[" + RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE + "]."+SELECT_ATTRIBUTE_PGPACKSIZE;
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 24 Feb 2021 -- END

	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 20 Mar 2021 -- START
	public static final String FORMULANUMBERID = "formulaNumberId";
	public static final String FORMULANUMBERTYPE = "formulaNumberType";
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 20 Mar 2021 -- END

	//modified by Ganesh for defect 40911 <22/Mar/2021> ----->start
	public static final String REL_ROUTENODE_TO_NAME="from[Object Route].to[Route].from[Route Node].to.name";
	public static final String ROUTEAPPROVERS = "routeapprover";
	//modified by Ganesh for defect 40911 <22/Mar/2021> ----->end

	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 22, 2021 -- START
	public static final String CONNECTED_TYPE_TO_PQR = "from[Qualification].torel.type";
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 22, 2021 -- END

	//SPEC: <22.03.2021>: Guna Added for Defect 40839 Dev 18x.6   -- START
	public static final String ATTRIBUTE_PGSPSORIGINATION = PropertyUtil.getSchemaProperty("attribute_pgSPSOrigination");
	public static final String SELECT_ATTRIBUTE_PGSPSORIGINATION = "attribute[" + ATTRIBUTE_PGSPSORIGINATION + "]"; 
	//SPEC: <22.03.2021>: Guna Added for Defect 40839 Dev 18x.6   -- END
	//SPEC: <23.03.2021>: Guna Added for Defect 41412 Dev 18x.6   -- START
	public static final String REL_PENELISTTASK= "from[pgStudyProtocolToPanelistTask].to.name";
	//SPEC: <23.03.2021>: Guna Added for Defect 41412 Dev 18x.6   -- END
	//SPEC: <23.03.2021>: Guna Added for Defect 41414 Dev 18x.6   -- START
	public static final String ATTRIBUTE_PGSURPLUSDISPOSITION = PropertyUtil.getSchemaProperty("attribute_pgSurplusDisposition");
	public static final String SELECT_ATTRIBUTE_PGSURPLUSDISPOSITION = "attribute[" + ATTRIBUTE_PGSURPLUSDISPOSITION + "]"; 
	//SPEC: <23.03.2021>: Guna Added for Defect 41414 Dev 18x.6   -- END

	//SPEC: Release SR18x.6.0 - Defect#41377 Added  by gaikwad.tg on Date 23 Mar 2021 -- START
	public static final String RELATIONSHIP_QUALIFICATION = PropertyUtil.getSchemaProperty("relationship_Qualification");
	public static final String STR_SELECT_MANU_EQU_PARTS = "from["+RELATIONSHIP_QUALIFICATION+"].torel["+RELATIONSHIP_MANUFACTURINGEQUIVALENT+"].to.id";
	//SPEC: Release SR18x.6.0 - Added for Defect# 41946  by gaikwad.tg on Date 30 March 2021 -- START
	public static final String STR_SELECT_SUPP_EQU_PARTS = "from["+RELATIONSHIP_QUALIFICATION+"].torel["+RELATIONSHIP_SUPPLIEREQUIVALENT+"].to.id";
	//SPEC: Release SR18x.6.0 - Added for Defect# 41946  by gaikwad.tg on Date 30 March 2021 -- END
	//SPEC: Release SR18x.6.0 - Defect#41377 Added  by gaikwad.tg on Date 23 Mar 2021 -- START

	public static final String REL_ARTWORKASSEMBLY_ATTRIBUTE_ISBASECOPY="from[Artwork Assembly].to.attribute[Is Base Copy]";
	public static final String REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXTLANG="from[Artwork Assembly].to.attribute[Copy Text Language]";

	public static final String  TYPE_INNER_PACK = "Inner Pack";

	//SPEC: Added for Defect :41532   by Chandra -- START
	public static final String SOFTWARE_BUSINESS_AREA ="from[pgDocumentToBusinessArea].to[pgPLIBusinessArea].name";
	public static final String SOFTWARE_PRODUCT_CATEGORY ="from[pgDocumentToPlatform].to[pgPLIProductCategoryPlatform].name";
	//SPEC: Added for Defect :41532   by Chandra on 24-03-2021-- END
	//Modified by Ganesh for Defect 41521 & 41362 on Date <24/mar/2021>--->start
	public static final String ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC=PropertyUtil.getSchemaProperty("attribute_pgProductDoseperUseNumeric");
	public static final String SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC= "attribute[" + ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC + "]";
	//Modified by Ganesh for Defect 41521 & 41362 on Date <24/mar/2021>--->END

	public static final String PARENTPARTNAME = "parentpartname";
	public static final String CL_PARENTPART = "to[pgIngredientStatement].from.name";
	public static final String CL_PARENTPART_REVISION = "to[pgIngredientStatement].from.revision";
	
	

	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 25, 2021 for Defect 41567 -- START
	public static final String SELECT_MASTERPARTNAME_FP_HALB = "from["+ConstantsUtil.RELATIONSHIP_PGMASTER+"].to."+SELECT_NAME;
	public static final String SELECT_MASTERPARTTYPE_FP_HALB = "from["+ConstantsUtil.RELATIONSHIP_PGMASTER+"].to."+SELECT_TYPE;
	public static final String SELECT_MASTERPARTID_FP_HALB = "from["+ConstantsUtil.RELATIONSHIP_PGMASTER+"].to."+SELECT_ID;
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 25, 2021 for Defect 41567 -- END
	//SPEC: <25.03.2021>: Guna Added for Defect 40790 Dev 18x.6   -- START
	public static final String BASEUOMNOTSAME = "Not calculated because Base Unit of Measure is different between primary and alternate";
	public static final String PRIMARYWEIGHTZERO = "Gross-weight of primary part is 0";
	//SPEC: <25.03.2021>: Guna Added for Defect 40790 Dev 18x.6   -- END

	//SPEC: <25.03.2021>: Guna Added for internal Defect  Dev 18x.6   -- START
	public static final String ATTRIBUTE_PGPRODUCTSUSTAINCOMBUSTION = PropertyUtil.getSchemaProperty("attribute_pgProductSustainCombustion");
	public static final String SELECT_ATTRIBUTE_PGPRODUCTSUSTAINCOMBUSTION = "attribute[" + ATTRIBUTE_PGPRODUCTSUSTAINCOMBUSTION + "]"; 
	//SPEC: <25.03.2021>: Guna Added for internal Defect  Dev 18x.6   -- END

	//SPEC: Added for Defect #41616 by Jwala -- START
	public static final String ATTRIBUTE_PGTNUMBER=PropertyUtil.getSchemaProperty("attribute_pgTNumber");
	public static final String SELECT_ATTRIBUTE_PGTNUMBER = "attribute[" + ATTRIBUTE_PGTNUMBER + "]";
	//SPEC: Added for Defect #41616 by Jwala -- END
	//SPEC: <30.03.2021>: Guna Added for 41280 Defect  Dev 18x.6   -- START
	public static final String STR_SELECT_ENTERPRISE_PARTS_KEY = "from[Qualification|torel.from.latest =='True'].torel.id";
	//SPEC: <30.03.2021>: Guna Added for 41280 Defect  Dev 18x.6   -- END

	//SPEC: Release SR18x.6.0 Defect#41797- Added  by Madhana on Date 30 March 2021 -- START
	public static final String RELATIONSHIP_PGMEPTOPGPLIVENDORTYPEFORMEP = PropertyUtil.getSchemaProperty("relationship_pgMEPtopgPLIVendorTypeForMEP");	
	public static final String STR_RELATIONSHIP_PGMEPTOPGPLIVENDORTYPEFORMEP = "from["+RELATIONSHIP_PGMEPTOPGPLIVENDORTYPEFORMEP+"].to."+SELECT_NAME;
	//SPEC: Release SR18x.6.0 Defect#41797- Added  by Madhana on Date 30 March 2021 -- START
	public static final String FORMULATION_ID = "to[Formulation Propagate].from.id";
	//SPEC: Release SR18x.6. Modified by Dominic for Defect 42039 on Date 01/04/2021 --START
	public static final String RELATIONSHIP_PGAAA_PROJECTTOPOA = PropertyUtil.getSchemaProperty("relationship_pgAAA_ProjectToPOA");
	//SPEC: Release SR18x.6. Modified by Dominic for Defect 42039 on Date 01/04/2021 --END

	//public static final String E109 ="E109:You have searched a highly connected part and this part cannot be displayed.Please utilize 3DX Enovia to search this part until fixed in a future release.";
	//SPEC: <08.08.2022>: Satyam Modified for Defect 49774  -- START
	//SPEC: <17.08.2022>: Guna Modified for 49943 Defect   Dev 22x    -- START
	//Modified and added by Subhajit for Defect 50614
	public static final String E109 ="E109:This is a highly connected part. There could be other Enterprise Parts or Certifications connected. Please contact support.";
	//SPEC: <17.08.2022>: Guna Modified for 49943 Defect   Dev 22x    -- END
	//SPEC: <08.08.2022>: Satyam Modified for Defect 49774  -- END
	
	// SPEC Added on 07-April-2021 by Chandu for Defect 41763 -START
	public static final String RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME_ACTIVE = "to[Protected Item|from.current==Active].from[Security Control Class].name";
	 // SPEC Added on 07-April-2021 by Chandu for Defect 41763 -END
	
	//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
	public static final String ISFILEATTACHED = "isFileAttached";
	//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START

	//SPEC: Release SR18x.6.0 - Added by Amman on Apr 9, 2021 for Defect 42253 -- START
	public static final String STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE_FPP = "to["+ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODSDPP+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE;
	public static final String STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE_FPP = "to["+ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODSDPP+"].from."+SELECT_CURRENT;
	public static final String STR_RELATIONSHIP_PGDANGEROUSGOODS_NAME_FPP = "to["+ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODSDPP+"].from.name";
	public static final String STR_RELATIONSHIP_PGDANGEROUSGOODS_TYPE_FPP = "to["+ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODSDPP+"].from.type";
	public static final String STR_RELATIONSHIP_PGDANGEROUSGOODS_REVISION_FPP = "to["+ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODSDPP+"].from.revision";
	public static final String STR_RELATIONSHIP_PGDANGEROUSGOODS_ID_FPP = "to["+ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODSDPP+"].from.id";
	public static final String STR_RELATIONSHIP_PGDANGEROUSGOODS_TITLE_FPP = "to["+ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODSDPP+"].from."+SELECT_ATTRIBUTE_TITLE;
	//SPEC: Release SR18x.6.0 - Added by Amman on Apr 9, 2021 for Defect 42253 -- END
	//SPEC: <15.04.2021>: Guna Added for 42439 Defect  Dev 18x.6   -- START
	public static final String ATTRIBUTE_ACCESSTYPE=PropertyUtil.getSchemaProperty("attribute_AccessType");
	public static final String SELECT_ATTRIBUTE_ACCESSTYPE = "attribute[" + ATTRIBUTE_ACCESSTYPE + "]";
	public static final String INHERITED = "Inherited";
	//SPEC: <15.04.2021>: Guna Added for 42439 Defect  Dev 18x.6   -- END
	//SPEC: Release SR18x.6.0 - Added for Defect# 42611  by gaikwad.tg on Date 21 April 2021 -- START
	public static final String SMARTLABELTYPE	 = "smartLabelType";
	public static final String SMARTLABELID	 = "smartLabelID";
	//SPEC: Release SR18x.6.0 - Added for Defect# 42611  by gaikwad.tg on Date 21 April 2021 -- END
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 21 April 2021 -- START (FOr Internal Defect)
	public static final String SELECT_MANUFACTURINGEQUIVALENT_TO_TYPE = "from["+RELATIONSHIP_MANUFACTURINGEQUIVALENT+"].to.type";
	//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 21 April 2021 -- START (FOr Internal Defect)
	//SPEC: Release SR18x.6.0 - Added for Defect#42817 by gaikwad.tg on Date 28 April 2021 -- START
	public static final String ATTRIBUTE_PGSEQNO = PropertyUtil.getSchemaProperty("attribute_pgSequenceNumber");
	public static final String SELECT_ATTRIBUTE_PGSEQNO = "attribute[" + ATTRIBUTE_PGSEQNO + "]";
	//SPEC: Release SR18x.6.0 - Added for Defect#42817 by gaikwad.tg on Date 28 April 2021 -- END
	//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- START
	public static final String RELATIONSHIP_PGDOCUMENTTOBUSINESSAREA = PropertyUtil.getSchemaProperty("relationship_pgDocumentToBusinessArea");
	public static final String RELATIONSHIP_PGDOCUMENTTOPLATFORM = PropertyUtil.getSchemaProperty("relationship_pgDocumentToPlatform");
	public static final String  RELATIONSHIP_BUSINESS_AREANAME = "from["+RELATIONSHIP_PGDOCUMENTTOBUSINESSAREA+"].to.name";
	public static final String SELECT_ATTRIBUTE_PQRBANAME = "tomid["+RELATIONSHIP_QUALIFICATION+"].from."+RELATIONSHIP_BUSINESS_AREANAME;
	public static final String  RELATIONSHIP_PRODUCT_PLATFORM_AREANAME = "from["+RELATIONSHIP_PGDOCUMENTTOPLATFORM+"].to.name";
	public static final String SELECT_ATTRIBUTE_PQRPCPNAME = "tomid["+RELATIONSHIP_QUALIFICATION+"].from."+RELATIONSHIP_PRODUCT_PLATFORM_AREANAME;
	//SPEC: Release SR18x.6.0 - Added for Defect#35580 by gaikwad.tg on Date 29 April 2021 -- END
	
		//Added by Jwala for the defect 42876 -- START
	public static final String STR_AMAT ="AMAT";
	public static final String STR_APPROVAL_MATRIX ="Approval Matrix";
	
	public static final String STR_QAC = "QAC";
	public static final String STR_QUALITY_ACCEPTANCE_CRITERIA= "Quality Acceptance Criteria";
	
	public static final String STR_RMPI = "RMPI";
	public static final String STR_RAWMATERIAL_PLANT_INSTRUCTION = "Raw Material Plant Instruction";
	
	public static final String STR_CBA = "CBA";
	public static final String STR_CURRENT_BEST_APPROCH = "Current Best Approach";
	
	public static final String STR_GPMS = "GPMS";
	public static final String STR_GENERAL_PMS = "General Packaging Material Specification";
	
	public static final String STR_GPS = "GPS";
	public static final String STR_GENERAL_PACKING_STANDARD = "General Packing Standard";
	
	public static final String STR_IAS = "IAS";
	public static final String STR_INCOMMING_ACCEPT_SPEC = "Incoming Acceptance Specification";
	
	public static final String STR_MOC = "MOC";
	public static final String STR_MATERIAL_OF_CONSTRUCTION = "Material of Construction";
	
	
	// SPEC: Added for Security Update on 05/07/2021 by Jwala for the Defect #42969 -- START
	public static final String STR_PROJECT_SECURITY_FOP = "to[Formulation Propagate].from.to[Protected Item].from[Security Control Class]";
	// SPEC: Added for Security Update on 05/07/2021 by Jwala for the Defect #42969 -- END
	
	//Added by Jwala for the defect 42876 -- END
	//SPEC: <07.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
	public static final String STATE_REVIEW = "Review";
	//SPEC: <07.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END
	//SPEC: <20.05.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- START
	public static final String SELECTABLE_REFERENCEDOCUMENTVPROTOCOL ="relationship["+REFERENCEDOCUMENT+"||from.current !='Obsolete'].from.id";
	public static final String SELECTABLE_REFERENCEDOCUMENTVPROTOCOLTITLE ="relationship["+REFERENCEDOCUMENT+"||from.current !='Obsolete'].from.attribute[Title]";
	//SPEC: <05.10.2021>: Manikanta Modified for Defect# 43773  Dev 18x.6.0.2   -- START
	public static final String SELECTABLE_REFERENCEDOCUMENTVPROTOCOLID ="relationship["+REFERENCEDOCUMENT+"].to.id";
	//SPEC: <05.10.2021>: Manikanta Modified for Defect# 43773  Dev 18x.6.0.2   -- END
	//SPEC: <21.05.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- START
	public static final String SELECT_REL_SUBTYPE = "from[pgPDTemplatestopgPLIDocumentSubType].to.name";
	//SPEC: <21.05.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- END
	//SPEC: <08.06.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- START
	public static final String RELATIONSHIP_ACCESS_FROM_DISCONNECT_SECURITY = "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from["+ConstantsUtil.TYPE_SECURITYCONTROLCLASS+"].current.access[fromdisconnect]";
	//SPEC: <08.06.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- END
	
	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 11, 2021 for Defect #43500 -- START
	public static final String tMRMS ="pgMasterRawMaterial";
	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 11, 2021 for Defect #43500 -- END
	
	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 12, 2021 for Defect #43514 -- START
	public static final String SELECT_REF_DOC_TOCURRENT = "to["+ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT+"].from." +SELECT_CURRENT;
	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 12, 2021 for Defect #43514 -- END
	
	//SPEC: Release SR18x.6.0.1 - Added by Manikanta on June 17, 2021 for Defect #43415 -- START
	public static final String RELATIONSHIP_MANUFACTURING_RESPONSIBILITY = PropertyUtil.getSchemaProperty("relationship_ManufacturingResponsibility");
	//SPEC: Release SR18x.6.0.1 - Added by Manikanta on June 17, 2021 for Defect #43415 -- END
	
	public static final String ROLEINFO = "roleinfo";
	//SPEC: <24.06.2021>: Guna Added for 43831 Defect  Dev 18x.6.0.1   -- START
	//SPEC: 21.10.2021: Jwala Modified for 43831 Defect  Dev 18x.6.0.2   -- START
	public static final String SELECTABLE_REFERENCEDOCUMENTSTABILITYID ="relationship["+REFERENCEDOCUMENT+"].to.id";
	//SPEC: 21.10.2021: Jwala Modified for 43831  Defect  Dev 18x.6.0.2   -- END
	//SPEC: <24.06.2021>: Guna Added for 43831 Defect  Dev 18x.6.0.1   -- END
	
	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 25, 2021 for Defect #43822 -- START
	public static final String SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL = "attribute[" + ConstantsUtil.ATTRIBUTE_PGGROSSWEIGHTREAL + "]";
	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 25, 2021 for Defect #43822 -- END
	//SPEC: <13.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- STAR
	public static final String REFDESC = "RefDes";
	//SPEC: <13.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- END
	//SPEC: <10.28.2021>: Sanjeeva Added for 42821   -- START
		public static final String FORMULATION = "Formulation";
		public static final String COSMETICFORMULATION = "Cosmetic Formulation";
	//SPEC: <10.28.2021>: Sanjeeva Added for 42821   -- END
	//SPEC: 12.21.2021: Added for DSM Report & Dynamic Subscription  Dev 18x.6.0.3  -- START	
	public static final String TYPE_PGDSMREPORT = PropertyUtil.getSchemaProperty("type_pgDSMReport");	
	public static final String TYPE_PGDSMREPORTTEMPLATE = PropertyUtil.getSchemaProperty("type_pgDSMReportTemplate");
	public static final String ATTRIBUTE_PGDSMREPORTTYPE = PropertyUtil.getSchemaProperty("attribute_pgDSMReportType");
	public static final String SELECT_ATTRIBUTE_PGDSMREPORTTYPE = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMREPORTTYPE + "]";
	public static final String CONST_DATE = "date";
	public static final String DSMREPORT = "DSMReport";
	public static final String PARTS_AND_SPECIFICATION_REPORT = "Parts and Specification Report";
	public static final String PDFDOWNLOAD = "PDFDownload";
	public static final String PDF_DOWNLOAD = "PDF Download";
	public static final String MASSARTWORKDOWNLOAD = "MassArtworkDownload";
	public static final String MASS_ARTWORK_DOWNLOAD = "Mass Artwork Download";
	public static final String ATSREPORT = "ATSReport";
	public static final String ATS_REPORT = "ATS Report";
	public static final String REFERENCEDOCUMENTREPORT = "ReferenceDocumentReport";
	public static final String REFERENCE_DOCUMENT_REPORT = "Reference Document Report";
	//Added by Ketan for Req. no. 42801 -- START
	public static final String CHARACTERISTICMASTERREPORT = "CharacteristicMasterReport";
	public static final String CHARACTERISTIC_MASTER_REPORT = "Characteristic Master Report";
	public static final String CERTIFICATIONROLLUP = "CertificationRollUp";
	public static final String CERTIFICATION_ROLL_UP = "Certification Roll-Up";
	public static final String WHEREUSEDREPORT = "WhereUsedReport";
	public static final String WHERE_USED_REPORT = "Where Used Report";
	//Added by Ketan for Req. no. 42801 -- END
	//Added by Ketan for Req. no. 42791,42796 -- START
	public static final String INPUT_RELEASECMONLY = "AllLatestCMs";
	public static final String RELEASECMONLY = "releaseCMonly";
	public static final String INPUT_LATESTRELCM = "LatestCM";
	public static final String LATESTRELCM = "latestReleaseCMonly";
	public static final String SELBUSAREAS_PIPE = "SelectedBusinessAreas|";
	public static final String SELECTEDBUSAREAS = "selectedBusinessAreas";
	public static final String SELCERT_PIPE = "SelectedCertifications|";
	//Added by Ketan for Req. no. 42791,42796 -- END
	//Added by Ketan for Req. no. 47049 -- START
	public static final String INPUT_WHEREUSEDLATESTRELPART = "WhereUsedLatestReleasePartOnly";
	public static final String WHEREUSEDLATESTRELPART = "whereUsedlatestRelPartonly";
	public static final String INPUT_LEVELSELECTED = "LevelSelected";
	public static final String SELECTEDLEVEL = "pgDSMReportExpand";
	//Added by Ketan for Req. no. 47049 -- END
	public static final String STR_FILE_MODIFIED = "format.file.modified";
	public static final String STATE_ACTIVE = "Active";
	public static final String RELATIONSHIP_DYNAMIC_SUBSCRIPTION = PropertyUtil.getSchemaProperty("relationship_CPNDynamicSubscription");
	public static final String TYPE_USERSUBSCRIPTION = PropertyUtil.getSchemaProperty("type_CPNUserSubscription");	
	public static final String SUBSCRIPTIONRESULTS = "subscriptionResults";
	public static final String SUBSCRIPTIONDETAILS = "subscriptionDetails";
	public static final String SUBSCRIPTIONFIELDS = "subscriptionFields";
	public static final String FREQUENCY = "frequency";
	public static final String ORGANIZATION = "organization";	
	public static final String RDLAB = "r&d Lab";	
	public static final String RANGE_BOTH = "Both";
	public static final String STATE_BOTH = "Release,Obsolete";
	public static final String DYNLIST = "DynList";
	public static final String DYNDETAIL = "DynDetail";
	//Added by Ketan for Req. no. 42796,47051,42797,47058 -- START
	public static final String REGEX_EIGHTDOTTHREE = "\\d{8}\\.\\d{3}";
	public static final String REGEX_THREEDIGIT = "\\d{3}";
	public static final String S102 = "S102";
	public static final String S102_MSG = "All Parts have valid types";
	public static final String S103 = "S103";
	public static final String S103_MSG = "Your Report will be processed in the background and will complete shortly. Please refresh the screen after few minutes.";
	public static final String E113 = "E113";
	public static final String E113_MSG = "Please enter a valid part type. Assembled Product Part / Device Product Part / Formulation Part are the types allowed";
	public static final String E114 = "E114";
	public static final String E114_FORMAT_ERROR_MSG1 = "Please enter Part ";
	public static final String E114_FORMAT_ERROR_MSG2 = " in the mentioned (Name.Revision) format";
	public static final String E115 = "E115";
	public static final String E115_MSG = "Please enter Part Names to request a report";
	public static final String E116 = "E116";
	public static final String E116_MSG = "The Part(s) you entered are not valid for this report. Report will not be generated";
	public static final String E117 = "E117";
	public static final String E117_MSG = "Please enter Part Names OR upload an Input File to request a report";
	public static final String ALLOWEDTYPES_WHEREUSEDREPORT = "Finished Product Part,Formulation Part,Packaging Assembly Part,Packaging Material Part,pgAncillaryPackagingMaterialPart,pgAncillaryRawMaterialPart,pgAssembledProductPart,pgBaseFormula,pgConsumerUnitPart,pgCustomerUnitPart,pgDeviceProductPart,pgFabricatedPart,pgFinishedProduct,pgFormulatedProduct,pgInnerPackUnitPart,pgIntermediateProductPart,pgMasterConsumerUnitPart,pgMasterCustomerUnitPart,pgMasterFinishedProduct,pgMasterInnerPackUnitPart,pgMasterPackagingAssemblyPart,pgMasterPackagingMaterialPart,pgMasterPackingMaterial,pgMasterProductPart,pgMasterRawMaterial,pgMasterRawMaterialPart,pgOnlinePrintingPart,pgPackingMaterial,pgPackingSubassembly,pgPromotionalItemPart,pgRawMaterial,pgSoftwarePart,pgTransportUnitPart,Raw Material";
	//Added by Ketan for Req. no. 42796,47051,42797,47058 -- END
	//Added by Ketan for Req. no. 42791,42796 -- END
	public static final String COMMA_SPACE = ", ";
	public static final String MASTER_BUSAREA = "businessAreas";
	public static final String MASTER_BUSAREAS = "buisness_Area";
	public static final String CERT_BUSAREA = "certificationClaims";
	public static final String SELECTED_MASTER_BUSAREA = "buisness_Areas";
	public static final String SELECTED_CERT_BUSAREA = "CertificationClaims";
	public static final String TYPE_PGPLIBUSINESSAREA = PropertyUtil.getSchemaProperty("type_pgPLIBusinessArea");
	public static final String TYPE_PGPLIMATERIALCERTIFICATIONS = PropertyUtil.getSchemaProperty("type_pgPLIMaterialCertifications");
	//Added by Ketan for Req. no. 42791,42796 -- END
	public static final String TYPE_PGPLIORGANIZATIONCHANGEMANAGEMENT = PropertyUtil.getSchemaProperty("type_pgPLIOrganizationChangeManagement");
	public static final String TYPE_PGPLIRDLAB = PropertyUtil.getSchemaProperty("type_pgPLIRDLab");
	public static final String TYPE_PGPLILIFECYCLESTATUS = PropertyUtil.getSchemaProperty("type_pgPLILifeCycleStatus");
	public static final String ATTRIBUTE_PRODUCT_DATA_TYPE = PropertyUtil.getSchemaProperty("attribute_CPNProductDataType");
	public static final String SELECT_ATTRIBUTE_PRODUCT_DATA_TYPE = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PRODUCT_DATA_TYPE + "]";
	public static final String ATTRIBUTE_SUBSCRIPTION_FREQUENCY = PropertyUtil.getSchemaProperty("attribute_CPNSubscriptionFrequency");	
	public static final String SELECT_ATTRIBUTE_SUBSCRIPTION_FREQUENCY = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_SUBSCRIPTION_FREQUENCY + "]";
	public static final String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPOLICY = PropertyUtil.getSchemaProperty("attribute_pgDynamicSubscriptionPolicy");
	public static final String SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPOLICY = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPOLICY + "]";
	public static final String ATTRIBUTE_CPNSTATE = PropertyUtil.getSchemaProperty("attribute_CPNState");
	public static final String SELECT_ATTRIBUTE_CPNSTATE = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_CPNSTATE + "]";
	public static final String ATTRIBUTE_MANUFACTURING_LOCATION = PropertyUtil.getSchemaProperty("attribute_CPNManufacturingLocation");
	public static final String SELECT_ATTRIBUTE_MANUFACTURING_LOCATION = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_MANUFACTURING_LOCATION + "]";
	public static final String PLANT = "plant";	
	public static final String SYMBOL_LIKE = "~=";
	public static final String MQL_STMT = "temp query bus $1 $2 $3 vault 'eService Production' where $4 select $5 $6 $7 dump $8";
	public static final String MQL_STMT_CASE = "set system casesensitive $1";
	public static final String REPORTLIST = "reportList";
	public static final String TEMPLATELIST = "templateList";
	public static final String ATTRIBUTE_PGDSMREPORTREQUESTEDDATE = PropertyUtil.getSchemaProperty("attribute_pgDSMReportRequestedDate");
	public static final String SELECT_ATTRIBUTE_PGDSMREPORTREQUESTEDDATE = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMREPORTREQUESTEDDATE + "]";
	public static final String STR_FILE_PATH = "format.file.path";
	public static final String STR_FILE_FILEID = "format.file.fileid";
	public static final String FILEID = "fileid";
	public static final String REPORTDETAIL = "reportDetail";
	public static final String ATTRIBUTE_PGDSMREPORTCA = PropertyUtil.getSchemaProperty("attribute_pgDSMReportCA");
	public static final String SELECT_ATTRIBUTE_PGDSMREPORTCA = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMREPORTCA + "]";
	public static final String ATTRIBUTE_PGDSMREPORTGCAS = PropertyUtil.getSchemaProperty("attribute_pgDSMReportGCAS");
	public static final String SELECT_ATTRIBUTE_PGDSMREPORTGCAS = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMREPORTGCAS + "]";
	public static final String ATTRIBUTE_PGDSMCUSTOMNAME = PropertyUtil.getSchemaProperty("attribute_pgDSMCustomName");
	public static final String SELECT_ATTRIBUTE_PGDSMCUSTOMNAME = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMCUSTOMNAME + "]";
	public static final String ATTRIBUTE_PGDSMREPORTCTRLM = PropertyUtil.getSchemaProperty("attribute_pgDSMReportCTRLM");
	public static final String SELECT_ATTRIBUTE_PGDSMREPORTCTRLM = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMREPORTCTRLM + "]";
	public static final String ATTRIBUTE_PGDSMREPORTREALTIME = PropertyUtil.getSchemaProperty("attribute_pgDSMReportRealTime");
	public static final String SELECT_ATTRIBUTE_PGDSMREPORTREALTIME = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMREPORTREALTIME + "]";
	public static final String ATTRIBUTE_PGDSMREPORTREQUESTEDBY = PropertyUtil.getSchemaProperty("attribute_pgDSMReportRequestedBy");
	public static final String SELECT_ATTRIBUTE_PGDSMREPORTREQUESTEDBY = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMREPORTREQUESTEDBY + "]";
	public static final String DSM_REPORT = "DSM Report";
	public static final String CUSTOMNAME = "customName";
	public static final String PGDSMREPORTCTRLM = "pgDSMReportCTRLM";
	public static final String PGDSMREPORTREALTIME = "pgDSMReportRealTime";
	public static final String CONST_REPORTLIST = "ReportList";
	public static final String CONST_REPORTDETAIL = "ReportDetail";
	public static final String CONST_TEMPLATELIST = "TemplateList";
	public static final String CONST_TEMPLATEDETAIL = "TemplateDetail";
	public static final String ACCESSTOKEN = "access_token";
	public static final String USERNAME = "Username";
	//SPEC: 12.21.2021: Added for DSM Report & Dynamic Subscription  Dev 18x.6.0.3  -- END
	//SPEC: 12.30.2021: Added for Req- 41530,41531 Dev 18x.6.0.3  -- START
	public static final String TEMPLATEDETAIL = "templateDetail";
	public static final String RELATIONSHIP_PROPOSED_ACTIVITIES = PropertyUtil.getSchemaProperty("relationship_ProposedActivities");
	public static final String TYPE_PROPOSED_ACTIVITY = PropertyUtil.getSchemaProperty("type_ProposedActivity");
	public static final String DSMREPORTCONFIGURATION = "DSMReportConfiguration";
	public static final String RESPONSECODE = "responseCode";
	public static final String RESPONSEMESSAGE = "responseMessage";
	public static final String DAILYCOUNTER = "dailyCounter";
	public static final String E110 = "E110";
	public static final String E110_ERROR = "Part Number exceeds the max allowed limit";
	public static final String S101 = "S101";
	public static final String S101_SUCCESS = "Submit Successfully";
	public static final String E111 = "E111";
	//SPEC: <08.08.2022>: Satyam Modified for Defect 49774  -- START
	public static final String E111_ERROR = "You have exceeded the limit for the day and access to any additional Part/Specification is blocked! Please contact Support";
	//SPEC: <08.08.2022>: Satyam Modified for Defect 49774  -- END
	public static final String CAvalidation = "CAvalidation";
	public static final String REPORTNAME = "reportName";
	public static final String ARTWORKPDF = "artWorkChecked";
	public static final String FINALARTWORKPDF = "finalArtWorkChecked";
	public static final String EXPORTPOA = "exportPOAChecked";
	public static final String MAXCOUNTER = "maxCounter";
	public static final String PARTNAME = "partName";
	public static final String CHANGEACTION = "changeAction";
	public static final String ATTRIBUTE_PGDSMREPORTTEMPLATEVALUE = PropertyUtil.getSchemaProperty("attribute_pgDSMReportTemplateValue");
	public static final String SELECT_ATTRIBUTE_PGDSMREPORTTEMPLATEVALUE = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMREPORTTEMPLATEVALUE + "]";
	public static final String ATTRIBUTE_PGDSMREPORTCUSTOMNAME = PropertyUtil.getSchemaProperty("attribute_pgDSMReportCustomName");
	public static final String SELECT_ATTRIBUTE_PGDSMREPORTCUSTOMNAME = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDSMREPORTCUSTOMNAME + "]";
	public static final String E112 = "E112";
	public static final String E112_ERROR1 = "CA/Parts exceeds the ";
	public static final String E112_ERROR2 = " daily limit by ";
	public static final String E112_ERROR3 = " for download, please correct and resubmit";
	//SPEC: 12.30.2021: Added for Req- 41530,41531 Dev 18x.6.0.3  -- END
	//SPEC: <03.01.2022>: Guna Added for 45866 Defect 18x.6.0.3 Release -- START
	public static final String CONST_HALB = "HALB";
	//SPEC: <03.01.2022>: Guna Added for 45866 Defect 18x.6.0.3 Release -- END
	//SPEC: 01.05.2021: Added for Req- 41555 Dev 18x.6.0.3  -- START
	public static final String PDFVIEW = "pdfView";
	public static final String EXPANDPRODUCTBOM = "expandProductBom";
	public static final String INCLUDEPRODUCTBOM = "includeProductBom";
	public static final String INCLUDEPACKAGEBOM = "includePackageBom";
	public static final String LATESTRELEASE = "latestRelease";
	public static final String INCLUDEHYPERLINK = "includeHyperlink";
	//Added by Ketan for Req. no. 42788 -- START
	public static final String INPUT_INCLUDEMATCOMPFROMCOMPEQUV = "IncludeMatCompFromCompEquv";
	public static final String INCLUDEMATCOMPFROMCOMPEQUV = "pgDSMIncludeMaterialCompositionfromComponentEquivalents";
	//Added by Ketan for Req. no. 42788 -- END
	public static final String ALLTABS = "allTabs";
	public static final String ATTRIBUTES = "attributes";
	public static final String APPROVE = "approve";
	public static final String CONST_BATTERYROLLUP = "batteryRollUp";
	public static final String CHARACTERISTICSAPOLLO = "characteristicsApollo";
	public static final String CHEMPHYPROPERTIES = "pgDSMChemicalandPhysicaProperties";
	public static final String PGDESIGNPARAMETER = "pgDSMDesignParameter";
	public static final String DESIGNPARAMETER = "designParameter";
	public static final String EBOMWND = "ebomWnD";
	public static final String FOPFORMULAINGREDIENT = "fopFormulaIngredient";
	public static final String FOPVIEWSUBSTITUTES = "fopViewSubstitutes";
	public static final String GPSASSESMENTS = "gpsAssesments";
	public static final String MARKETCLEARANCE = "marketClearance";
	public static final String MARKETOFSALE = "marketOfSale";
	public static final String MATERIALSANDCOMPOSITION = "materialsAndComposition";
	public static final String MEPSEPCERTIFICATIONS = "mepSepCertifications";
	public static final String MEPSEPCOMPEQTS = "mepSepCompEqts";
	public static final String NOTES = "notes";
	public static final String PARTCERTIFICATIONS = "partCertifications";
	public static final String PARTCOMPONENTEQUIVALENTS = "partComponentEquivalents";
	public static final String PERFORMANCECHARACTERISTICS = "performanceCharacteristics";
	public static final String PRODUCINGFORMULA = "producingFormula";
	public static final String SAPBOMASFED = "sapBomAsFed";
	public static final String SPECSANDDOCS = "specsAndDocs";
	public static final String SUBSTANCESANDMATERIALS = "substancesAndMaterials";
	public static final String WEIGHTSANDDIMENSIONS = "weightsAndDimensions";
	public static final String LATESTVERSIONASINPUT = "LatestVersionAsInput";
	public static final String LATESTVERSIONASINPUTREFDOC = "LatestVersionAsInputRefDoc";
	public static final String HYPERLINKASINPUT = "HyperlinkAsInput";
	public static final String LIMIT_ERROR1 = "Please limit the number of parts to ";
	public static final String LIMIT_ERROR2 = " and resubmit the request";
	public static final String CONST_FINALARTWORKPDF = "FinalArtworkPDF";
	public static final String CONST_EXPORTPOA = "ExportPOA";
	public static final String CONST_PDFARTWORK = "PDFArtwork";
	public static final String LATESTRELESEINPUT = "latestReleaseInput";
	public static final String CONST_EXPANDPRODUCTBOM = "ExpandProductBOM";
	public static final String CONST_INCLUDEFOPCHILDTOBOM = "IncludeFOPChildToBOM";
	public static final String EXPANDPRODUCTCHILDBOM = "ExpandProductChildBOM";
	public static final String LATESTRELEASEPARTONLY = "LatestReleasePartOnly";
	public static final String PARTSPECTABS = "PartSpecTabs";
	public static final String CONST_ATTRIBUTES = "Attributes";
	public static final String CONST_APPROVE = "Approve";
	public static final String BATTERY_ROLL_UP = "Battery Roll-Up";
	public static final String BILL_OF_MATERIALS = "Bill of Materials";
	public static final String CHARACTERISTICS_APOLLO = "Characteristics - Apollo";
	public static final String CHEMICAL_AND_PHYSICAL_PROPERTIES = "Chemical and Physical Properties";
	public static final String DESIGN_PARAMETER = "Design Parameter";
	public static final String EBOM_W_AND_D = "EBOM W and D";
	public static final String FOP_FORMULA_INGREDIENT = "FOP-Formula Ingredient";
	public static final String VIEW_SUBSTITUTES = "View Substitutes";
	public static final String GPS_ASSESMENTS = "GPS Assesments";
	public static final String MARKET_CLEARANCE = "Market Clearance";
	public static final String MARKET_OF_SALE = "Market Of Sale";
	public static final String MATERIALS_AND_COMPOSITION = "Materials And Composition";
	public static final String MEP_SEP_CERTIFICATIONS = "MEP-SEP Certifications";
	public static final String MEP_SEP_COMPONENT_EQUIVALENTS = "MEP-SEP Component Equivalents";
	public static final String CONST_NOTES = "Notes";
	public static final String PART_CERTIFICATIONS = "Part Certifications";
	public static final String PART_COMPONENT_EQUIVALENTS = "Part Component Equivalents";
	public static final String PERFORMANCE_CHARACTERISTICS = "Performance Characteristics";
	public static final String CONST_PLANTS = "Plants";
	public static final String PRODUCING_FORMULA = "Producing Formula";
	public static final String SAP_BOM_AS_FED = "SAP BOM As Fed";
	public static final String SPECS_AND_DOCS = "Specs and Docs";
	public static final String SUBSTANCES_AND_MATERIALS = "Substances and Materials";
	public static final String WEIGHTS_AND_DIMENSIONS = "Weights and Dimensions";
	//Added by Ketan for Req. no. 42723 -- START
	public static final String CHARACTERISTICS_LPD = "Characteristics - LPD";
	public static final String DG_CLASS = "DG Classification";
	public static final String IP_EXPORT_CONTROL = "IP and Export Control";
	public static final String SUBS_PARTS_IN = "SubstitutePartsIn";
	public static final String CONST_SUSTAINABILITY = "Sustainibility";
	public static final String OUT_SUSTAINABILITY = "pgDSMSustainability";
	
	public static final String CHARACTERISTICSLPD = "pgDSMCharacteristicsLPD";
	public static final String DGCLASS = "pgDSMDGClassification";
	public static final String IPEXPORTCONTROL = "pgDSMIPandExportControl";
	public static final String SUBSPARTSIN = "pgDSMSubstitutePartsIn";
	public static final String SUSTAINABILTY = "pgDSMSustainability";
	//Added by Ketan for Req. no. 42723 -- END
	public static final String REQUESTEDBY = "requestedBy";
	public static final String LIMIT_CA_ERROR1 = "CA exceeds the ";
	public static final String LIMIT_CA_ERROR2 = " Part limit, Please correct and resubmit";//modified for in internal defect
	//SPEC: 01.05.2021: Added for Req- 41555 Dev 18x.6.0.3  -- END
	//SPEC: 01.24.2021: Added for Req- 41603 Dev 18x.6.0.3  -- START
	public static final String MANUFACTURING_STATUS = "PRODUCTION,PRODUCTION NEW,PRODUCTION TEMPORARY,PRODUCTION EXPERIMENTAL ORDER,PRODUCTION PHASE OUT,PRODUCTION BUSINESS CONTINUITY PLAN";//Modified by Ketan for Req. no. 41583 
	public static final String EXPERIMENTAL = "EXPERIMENTAL";
	public static final String IN_ASSESSMENT = "IN ASSESSMENT";
	public static final String PLANNING = "PLANNING";
	public static final String SINGLE_QUOTE = "'";
	public static final String TYPE_PGPLISUPPLIER = PropertyUtil.getSchemaProperty("type_pgPLISupplier");
	//SPEC: 01.24.2021: Added for Req- 41603 Dev 18x.6.0.3  -- END
	public static final String QUALIFICATION_PQR = "Qualification (PQR)";
	public static final String TESTMETHOD_CSS = "Test Method (CSS)";
	//SPEC: 03.07.2022: Added for Defect- 46877 Dev 18x.6.0.3  -- START
	public static final String PROMOTIONAL_ITEM_PART = "Promotional Item Part";
	public static final String SUPPLIER_INFORMATION_SHEET = "Supplier Information Sheet";
	//SPEC: 03.07.2022: Added for Defect- 46877 Dev 18x.6.0.3  -- END
	//SPEC: 03.08.2022: Added for Defect- 46882 Dev 18x.6.0.3  -- START
	public static final String CONTRACTPACKAGING = "contractpackaging";
	public static final String DEFAULT = "default";
	//SPEC: 03.08.2022: Added for Defect- 46882 Dev 18x.6.0.3  -- END
	//SPEC: <08.03.2022>: Guna Added for 46877 Defect  Dev 18x.6.0.3   -- START
	public static final String SYMBOL_MATCH = "~~";
	//SPEC: <08.03.2022>: Guna Added for 46877 Defect  Dev 18x.6.0.3   -- END
	
	//dsMapType Added by Jwala for the defect 46879 6.0.3 -- START
	//Added schema type name to share actual type name to UI
	public static final String SCHEMATYPE = "schematypename";
	//dsMapType Added by Jwala for the defect 46879 6.0.3 -- START
	//SPEC: Release 22x - added for JVM Crash Issue, by Guna -- START
	public static final String MQL_STMT1 = "temp query bus $1 $2 $3 select $4 $5 dump $6";
	//SPEC: Release 22x - added for JVM Crash Issue, by Guna -- END
	//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- START
	public static final String  TRANSPORTATIONTEMPCONTROL  = "transportationtempcontrol";
	public static final String ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL = PropertyUtil.getSchemaProperty("attribute_pgTransportationTempControl");
	public static final String SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL + "]";
	public static final String NOMINALBATTERYENERGY = "nominalbatteryenergy";
	public static final String LITHIUMBATTERYENERGYUOM = "lithiumbatteryenergyuom";
	//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- END
	//SPEC: 04/04/2022: Added by Manikanta for 18x.6.0.4 DEV -- START
	public static final String  CERTIFICATIONSOURCE  = "certificationsource";
	//SPEC: 04/04/2022: Added by Manikanta for 18x.6.0.4 DEV -- END
	//SPEC: <07.04.2022>: Guna Added for Req 35586 22x Release  -- START
	public static final String STATE_LOCKED = "Locked";
	//SPEC: <07.04.2022>: Guna Added for Req 35586 22x Release  -- END
	//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- START
	public static final String SELECT_CERTIFICATION_SOURCE ="frommid["+ ConstantsUtil.RELATIONSHIP_PGMEPSEPCERTIFICATION +"].torel["+ConstantsUtil.RELATIONSHIP_PG_PLI_MATERIAL_CERTIFICATIONS+"].from.name";
	//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- END
	//SPEC: 07.04.2022: Jwala Added for Req 34415 22x Release  -- START
	public static final String ATTRIBUTE_SMARTLABENREADY = PropertyUtil.getSchemaProperty("attribute_pgSmartLabelReady");
	public static final String SELECT_ATTRIBUTE_SMARTLABENREADY = "attribute[" + ATTRIBUTE_SMARTLABENREADY + "]";
	
	public static final String ATTRIBUTE_PGCLONETRANSFERRED = PropertyUtil.getSchemaProperty("attribute_pgCloneTransferred");
	public static final String SELECT_ATTRIBUTE_PGCLONETRANSFERRED = "attribute[" + ATTRIBUTE_PGCLONETRANSFERRED + "]";
	
	public static final String CLONETRANSFERRED = "cloneTransferred";
	public static final String SMARTLABELREADY = "smartLabelReady";
	public static final String DOESTHEFORMULACONTAINWATER = "doesTheFormulaContainWater"; 
	//SPEC: 07.04.2022: Jwala Added for Req 34415 22x Release  -- END
	//SPEC: 20-06-2022: Added by Satyam for Internal Defect -- START
	public static final String ATTRIBUTE_PGISTHELIQUIDANAQEOUSSOLUTION = PropertyUtil.getSchemaProperty("attribute_pgIsTheLiquidanAqeousSolution");
	public static final String SELECT_ATTRIBUTE_PGISTHELIQUIDANAQEOUSSOLUTION = "attribute[" + ATTRIBUTE_PGISTHELIQUIDANAQEOUSSOLUTION + "]";
	//SPEC: 20-06-2022: Added by Satyam for Internal Defect -- END
	//SPEC:20.04.2022: Sanjeeva added for Req 34415 22x Release -- START
	public static final String TRANSPORTTEMPCONTROL = "transportTempControl";
		//SPEC:20.04.2022: Sanjeeva added for Req 34415 22x Release -- END
	//CATIA APP
	
	public static final String ATTRIBUTE_LPDREGION = PropertyUtil.getSchemaProperty("attribute_pgLPDRegion");
	public static final String SELECT_ATTRIBUTE_LPDREGION = "attribute[" + ATTRIBUTE_LPDREGION + "]";
	
	public static final String ATTRIBUTE_LPDSUBREGION = PropertyUtil.getSchemaProperty("attribute_pgLPDSubRegion");
	public static final String SELECT_ATTRIBUTE_LPDSUBREGION = "attribute[" + ATTRIBUTE_LPDSUBREGION + "]";
	
	public static final String LPDREGION = "lpdregion";
	public static final String LPDSUBREGION = "lpdsubregion";
	public static final String PRODUCTDOSECOMMENT = "productDoseComment";
	public static final String CATIAAPP = "isCatiaAPP";
	
	public static final String RELATIONSHIP_AUTOCADIPCLASS = PropertyUtil.getSchemaProperty("relationship_pgArtiosCADToIPControlClass");
	//SPEC: 21/04/2022: Added by Manikanta for 22x DEV Req 41754-- START
	public static final String ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES = PropertyUtil.getSchemaProperty("attribute_pgPackageComponentOpticalProperties");
	public static final String SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES = "attribute[" + ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES + "]";
	public static final String ATTRIBUTE_PGMINERALOILSADDEDTOPRINTINGINKS = PropertyUtil.getSchemaProperty("attribute_pgMineralOilsAddedToPrintingInks");
	public static final String SELECT_ATTRIBUTE_PGMINERALOILSADDEDTOPRINTINGINKS = "attribute[" + ATTRIBUTE_PGMINERALOILSADDEDTOPRINTINGINKS + "]";
	public static final String ATTRIBUTE_PGPACKAGEDURABILITY = PropertyUtil.getSchemaProperty("attribute_pgPackageDurability");
	public static final String SELECT_ATTRIBUTE_PGPACKAGEDURABILITY = "attribute[" + ATTRIBUTE_PGPACKAGEDURABILITY + "]";
	public static final String ATTRIBUTE_PGPAPERWETSTRENGTH = PropertyUtil.getSchemaProperty("attribute_pgPaperWetStrength");
	public static final String SELECT_ATTRIBUTE_PGPAPERWETSTRENGTH = "attribute[" + ATTRIBUTE_PGPAPERWETSTRENGTH + "]";
	public static final String ATTRIBUTE_PGMATERIALTHICKNESS = PropertyUtil.getSchemaProperty("attribute_pgMaterialThickness");
	public static final String SELECT_ATTRIBUTE_PGMATERIALTHICKNESS = "attribute[" + ATTRIBUTE_PGMATERIALTHICKNESS + "]";
	public static final String ATTRIBUTE_PGMATERIALDENSITY = PropertyUtil.getSchemaProperty("attribute_pgMaterialDensity");
	public static final String SELECT_ATTRIBUTE_PGMATERIALDENSITY = "attribute[" + ATTRIBUTE_PGMATERIALDENSITY + "]";
	public static final String ATTRIBUTE_PGPAPERDISSOLVABILITY = PropertyUtil.getSchemaProperty("attribute_pgPaperDissolvability");
	public static final String SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY = "attribute[" + ATTRIBUTE_PGPAPERDISSOLVABILITY + "]";
	public static final String PGPACKAGECOMPOPTPROPERTIES = "packageCompOptProperties";
	public static final String PGMINERALOILADDEDTOPRINTINKS = "mineralOilAddedToPrintInks";
	public static final String PGPACKAGEDURABILITY = "packageDurability";
	public static final String PGPAPERWETSTRENGTH = "paperWetStrength";
	public static final String PGMATERIALTHICKNESS = "materialThickness";
	public static final String PGMATERIALDENSITY = "materialDensity";
	public static final String PGPAPERDISSOLVABILITY = "paperDissolvability";
	public static final String SUSTAINABILITY = "sustainability";
	//SPEC: 21/04/2022: Added by Manikanta for 22x DEV Req 41754-- END
	
	//SPEC: 29/04/2022: Added by Jwala for 22x DEV Req 34415-- START
	public static final String ATTRIBUTE_REASONFORMANUFACTURINGSTATUS = PropertyUtil.getSchemaProperty("attribute_pgReasonForChangeManfStatus");
	public static final String SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS = "attribute[" + ATTRIBUTE_REASONFORMANUFACTURINGSTATUS + "]";
	public static final String REASONFORMANUFACTURINGSTATUS = "reasonForChangeInManufacturingStatus";
	//SPEC: 29/04/2022: Added by Jwala for 22x DEV Req 34415-- END
	
	//SPEC: Updated the method by Sanjeeva for 18x.6.0.3 ELS Issue. Defects: 47517,47786 -- START
	public static final String ACTIVEVERSION = "Active Version";
	public static final String ATTRIBUTETITLE = "attribute[Title].value=='";
	public static final String STR_FORMAT_FILE_ = "format.file[";
	public static final String STR_CAPTURED_FILE_ = "].capturedfile";
	public static final String STR_STORE_ = "].store";
	//SPEC: Updated the method by Sanjeeva for 18x.6.0.3 ELS Issue. Defects: 47517,47786 -- END
	
	//Added by Jwala for Characteristic Master
	public static final String ATTRIBUTE_PGNSPCG = PropertyUtil.getSchemaProperty("attribute_pgNSPCG");
	public static final String SELECT_ATTRIBUTE_PGNSPCG = "attribute[" + ATTRIBUTE_PGNSPCG + "]";
	public static final String NSPCG = "nspcg";
	public static final String CHARACTERISTICINFORMATION = "CharacteristicInformation";
	public static final String ATTRIBUTE_CHARACTERISTICCATEGORY = PropertyUtil.getSchemaProperty("attribute_CharacteristicCategory");
	public static final String SELECT_ATTRIBUTE_CHARACTERISTICCATEGORY = "attribute[" + ATTRIBUTE_CHARACTERISTICCATEGORY + "]";
	public static final String ATTRIBUTE_PGCATEGORYSPECIFICS = PropertyUtil.getSchemaProperty("attribute_pgCategorySpecifics");
	public static final String SELECT_ATTRIBUTE_PGCATEGORYSPECIFICS = "attribute[" + ATTRIBUTE_PGCATEGORYSPECIFICS + "]";
	public static final String ATTRIBUTE_OVERWRITEALLOWEDONCHILD = PropertyUtil.getSchemaProperty("attribute_OverwriteAllowedOnChild");
	public static final String SELECT_ATTRIBUTE_OVERWRITEALLOWEDONCHILD = "attribute[" + ATTRIBUTE_OVERWRITEALLOWEDONCHILD + "]";
	public static final String ATTRIBUTE_OLMPARAMDISPLAYUNIT = PropertyUtil.getSchemaProperty("attribute_PlmParamDisplayUnit");
	public static final String SELECT_ATTRIBUTE_OLMPARAMDISPLAYUNIT = "attribute[" + ATTRIBUTE_OLMPARAMDISPLAYUNIT + "]";
	public static final String ATTRIBUTE_ISDESIGNDRIVEN = PropertyUtil.getSchemaProperty("attribute_pgIsDesignDriven");
	public static final String SELECT_ATTRIBUTE_ISDESIGNDRIVEN = "attribute[" + ATTRIBUTE_ISDESIGNDRIVEN + "]";
	public static final String ATTRIBUTE_APPLIESTOFINALPACKAGE = PropertyUtil.getSchemaProperty("attribute_AppliesToFinalPackage");
	public static final String SELECT_ATTRIBUTE_APPLIESTOFINALPACKAGE = "attribute[" + ATTRIBUTE_APPLIESTOFINALPACKAGE + "]";
	public static final String ATTRIBUTE_APPLIESTOINPROCESS = PropertyUtil.getSchemaProperty("attribute_AppliesToInProcess");
	public static final String SELECT_ATTRIBUTE_APPLIESTOINPROCESS = "attribute[" + ATTRIBUTE_APPLIESTOINPROCESS + "]";
	public static final String ATTRIBUTE_APPLIESTOBULK = PropertyUtil.getSchemaProperty("attribute_AppliesToBulk");
	public static final String SELECT_ATTRIBUTE_APPLIESTOBULK = "attribute[" + ATTRIBUTE_APPLIESTOBULK + "]";
	
	public static final String CATEGORYSPECIFICS = "CategorySpecifics";
	public static final String OVERWRITEALLOWEDONCHILD = "OverwriteAllowedonChild";
	public static final String CHARACTERISTICDESCRIPTION ="CharacteristicDescription";
	public static final String DIMENSION = "Dimension";
	public static final String VALUES = "Values";
	public static final String CHARNOTES= "characteristicNotes";
	public static final String ISDESIGNDRIVEN= "isDesignDriven";
	public static final String CRITICALFACTOR = "criticalityFactor";
	public static final String APPROCESS = "appliesToProcess";
	public static final String APBULK = "appliesToBulk";
	public static final String APFINALPKG = "appliesToFinalPackage";
	//Added by Jwala for Characteristic Master
	
	public static final String PDFCMVIEW = "CM";
	public static final String PDFSPVIEW = "SP";
	
	// Added by Pooja for the req 35902,41754,33476 -- START
	
	public static final String POAOVERRIDELEGALREWORKREQUIRED = "poaOverrideLegalReworkRequired";
	
	// Added by Pooja for the req 35902,41754,33476 -- END
	
	//SPEC: <17.05.2022>: Guna Added for Req 33205 22x Release  -- START
	public static final String TYPESLIST = "ANGLE,Boolean,Integer,LENGTH,MASS,Real,String,MASSFLOW,FORCE,FORCE_OVER_DISPLACEMENT,SPEED,TEMPRTRE,Ratio,TIME,AREA";
	public static final String PARAMETER_STRING ="Parameter";
	public static final String ATTRIBUTE_CHALOWERSPECIFICATIONLIMIT = PropertyUtil.getSchemaProperty("attribute_CharacteristicsLowerSpecificationLimit");
	public static final String SELECT_ATTRIBUTE_CHALOWERSPECIFICATIONLIMIT = "attribute[" + ATTRIBUTE_CHALOWERSPECIFICATIONLIMIT + "]";
	public static final String RELATIONSHIP_DERIVED_CHARACTERISTIC = PropertyUtil.getSchemaProperty("relationship_DerivedCharacteristic");
	public static final String SELECT_ATTRIBUTE_EVALUATED_CRITERIA = "attribute["+PropertyUtil.getSchemaProperty("attribute_EvaluatedCriteria")+"]";
	public static final String SELECT_CRITERIA=new StringBuilder("to[").append(RELATIONSHIP_DERIVED_CHARACTERISTIC).append("]").append(ConstantsUtil.SYMBL_DOT).append(SELECT_ATTRIBUTE_EVALUATED_CRITERIA).toString();
	public static final String  SELECT_LOGICAL_ID  = "logicalid";
	public static final String STR_CHAR_DIMENSION = "Dimension";
	public static final String SELECT_OBSCURE_UNIT_OF_MEASURE = "attribute["+PropertyUtil.getSchemaProperty("attribute_PlmParamDisplayUnit")+"]";
	public static final String SELECT_CHAR_MASTER =new StringBuilder("to[").append(RELATIONSHIP_DERIVED_CHARACTERISTIC).append("].from.id").toString();
	public static final String SELECT_CHAR_MASTER_PHYSICALID  =new StringBuilder("to[").append(RELATIONSHIP_DERIVED_CHARACTERISTIC).append("].from.physicalid").toString();
	public static final String ATTRIBUTE_OVERRIDEALLOWEDONCHILD = PropertyUtil.getSchemaProperty("attribute_OverwriteAllowedOnChild");
	public static final String SELECT_ATTRIBUTE_OVERRIDEALLOWEDONCHILD = "attribute["+ATTRIBUTE_OVERRIDEALLOWEDONCHILD+"]";
	public static final String ATTRIBUTE_MANDATORY_CHARACTERISTIC = PropertyUtil.getSchemaProperty("attribute_MandatoryCharacteristic");
	public static final String SELECT_ATTRIBUTE_MANDATORY_CHARACTERISTIC = "attribute["+ATTRIBUTE_MANDATORY_CHARACTERISTIC+"]";
	public static final String ATTRIBUTE_SEQUENCE_ORDER = PropertyUtil.getSchemaProperty("attribute_SequenceOrder");
	public static final String SELECT_ATTRIBUTE_SEQUENCE_ORDER = "attribute["+ATTRIBUTE_SEQUENCE_ORDER+"]";
	public static final String ATTRIBUTE_TREE_ORDER = PropertyUtil.getSchemaProperty("attribute_TreeOrder");
	public static final String SELECT_ATTRIBUTE_TREE_ORDER = "attribute["+ATTRIBUTE_TREE_ORDER+"]";
	public static final String ATTRIBUTE_CHARACTERISTIC_CATEGORY = PropertyUtil.getSchemaProperty("attribute_CharacteristicCategory");
	public static final String SELECT_ATTRIBUTE_CHARACTERISTIC_CATEGORY = "attribute["+ATTRIBUTE_CHARACTERISTIC_CATEGORY+"]";
	public static final String SELECT_ATTRIBUTE_CATEGORYSPECIFICS = "attribute["+PropertyUtil.getSchemaProperty(null,"attribute_pgCategorySpecifics")+"]";
	public static final String SELECT_ATTRIBUTE_PG_CHARACTERISTIC_CATEGORY = "attribute["+PropertyUtil.getSchemaProperty(null,"attribute_CharacteristicCategory")+"]";
	public static final String SELECT_ATTRIBUTE_DESIGNSPECIFICS = "attribute["+PropertyUtil.getSchemaProperty(null,"attribute_pgDesignSpecifics")+"]";
	public static final String SELECT_ATTRIBUTE_CHARNOTES = "attribute["+PropertyUtil.getSchemaProperty(null,"attribute_CharacteristicNotes")+"]";
	public static final String SELECT_CHAR_MASTER_TITLE=new StringBuilder("to[").append(RELATIONSHIP_DERIVED_CHARACTERISTIC).append("].from.attribute[Title]").toString();
	public static final String SELECT_CHAR_MASTER_TYPE=new StringBuilder("to[").append(RELATIONSHIP_DERIVED_CHARACTERISTIC).append("].from.type").toString();
	public static final String SELECT_CHAR_MASTER_CURRENT=new StringBuilder("to[").append(RELATIONSHIP_DERIVED_CHARACTERISTIC).append("].from.current").toString();
	public static final String SELECT_TM_NAME = new StringBuilder("from[").append(pgV3Constants.REL_CHARACTERISTICTESTMETHOD).append("].to.name").toString();
	public static final String SELECT_TM_ID = new StringBuilder("from[").append(pgV3Constants.REL_CHARACTERISTICTESTMETHOD).append("].to.id").toString();
	public static final String SELECT_TM_TYPE = new StringBuilder("from[").append(pgV3Constants.REL_CHARACTERISTICTESTMETHOD).append("].to.type").toString();
	public static final String SELECT_TMRD_ID = new StringBuilder("from[").append(ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT).append("].to.id").toString();
	public static final String SELECT_TMRD_NAME = new StringBuilder("from[").append(ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT).append("].to.name").toString();
	public static final String SELECT_TMRD_TYPE = new StringBuilder("from[").append(ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT).append("].to.type").toString();
	public static final String SELECT_CHAR_MASTER_NAME=new StringBuilder("to[").append(RELATIONSHIP_DERIVED_CHARACTERISTIC).append("].from.name").toString();
	public static final String SELECT_CHAR_MASTER_REVISION=new StringBuilder("to[").append(RELATIONSHIP_DERIVED_CHARACTERISTIC).append("].from.revision").toString();
	public static final String SELECT_CRITERIA_TITLE=new StringBuilder("to[").append(RELATIONSHIP_DERIVED_CHARACTERISTIC).append("]").append( pgV3Constants.SYMBOL_DOT).append(pgV3Constants.SELECT_ATTRIBUTE_TITLE).toString();
	public static final String SEQUENCEORDER = "sequenceOrder";
	public static final String DESIGNSPECIFICS ="designSpecifics";
	public static final String SUBGROUP="subGroup";
	public static final String CHARMASTERTITLE="charMasterTitle";
	public static final String CHARMASTERTYPE="charMasterType";
	public static final String CHARMASTERNAME="charMasterName";
	public static final String CHARMASTERREVISION="charMasterRevision";
	public static final String CHARMASTERID="charMasterId";
	public static final String CRITERIA="criteria";
	public static final String INTERFACE="interface";
	//SPEC: <17.05.2022>: Guna Added for Req 33205 22x Release  -- END
	//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- START
	public static final String SELECT_ATTRIBUTE_PGMOSPOAOVERRIDELRR = "attribute["+PropertyUtil.getSchemaProperty(null,"attribute_pgMOSPOAOverrideLRR")+"]";
	//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- END
	//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- START
	public static final String  HASATSBOM  = "hasAtsBom";
	public static final String GROSS_WEIGHTUOM = "grossWeightUOM";
	//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- END
		//SPEC: <01.06.2022>: Satyam Added for Req 42769, 34417  -- START
	public static final String PGISATSSPECIFICTOIMPACTEDPARTORSPECREV = "pgIsATSSpecificToImpactedPartOrSpecRev";
	public static final String ATTRIBUTE_PGISATSSPECIFICTOIMPACTEDPARTORSPECREV = PropertyUtil.getSchemaProperty(null,"attribute_pgIsATSSpecificToImpactedPartOrSpecRev");
	public static final String SELECT_ATTRIBUTE_PGISATSSPECIFICTOIMPACTEDPARTORSPECREV = "attribute["+ATTRIBUTE_PGISATSSPECIFICTOIMPACTEDPARTORSPECREV+"]";	
	//SPEC: <01.06.2022>: Satyam Added for Req 42769, 34417  -- END
	//SPEC: <07.06.2022>: Guna Added for Req 36041 and 41754 22x Release  -- START
	public static final String SELECT_ATTRIBUTE_GPSAPPROVEDBOUNDRY = "attribute["+PropertyUtil.getSchemaProperty(null,"attribute_pgStudyProtocolSupportedByGPSApprovedBoundry")+"]";
	public static final String SELECT_ATTRIBUTE_PGHASPARTICLESIZEDISTRIBUTIONFILE = "attribute["+PropertyUtil.getSchemaProperty(null,"attribute_pgHasParticleSizeDistributionfile")+"]";
	public static final String GPSAPPROVEDBOUNDARY ="gpsApprovedBoundary";
	public static final String HASPARTICLESIZEDISTRIBUTION ="hasParticleSizeDistribution";
	public static final String CONSUMERTESTLABEL ="consumerTestLabel";
	public static final String DPICFILE ="DPICFile";
	public static final String DEVICE="Device";
	public static final String RELATIONSHIP_ROLLED_UP_PACKAGING_MATERIAL_CERTIFICATIONS = PropertyUtil.getSchemaProperty(null,"relationship_pgRolledUpPLIPackagingCertifications");
	public static final String TYPE_PG_PLI_PACKAGING_MATERIAL_CERTIFICATION = PropertyUtil.getSchemaProperty(null,"type_pgPLIPackagingMaterialCertification");
	public static final String SELECT_ATTRIBUTE_ROLLUP_SOURCE_ID ="attribute["+PropertyUtil.getSchemaProperty(null,"attribute_pgRollupSourceID")+"]";
	public static final String SELECT_ATTRIBUTE_ROLLUP_SOURCE_IDENTIFIER ="attribute["+PropertyUtil.getSchemaProperty(null,"attribute_pgRollupSourceIdentifier")+"]";
	public static final String SELECT_ATTRIBUTE_ROLLUP_SOURCE_REL_TYPE ="attribute["+PropertyUtil.getSchemaProperty(null,"attribute_pgRollupSourceRelType")+"]";
	public static final String RELATIONSHIP_PGROLLEDUPCERTIFICATIONDOCUMENT = PropertyUtil.getSchemaProperty(null,"relationship_pgRolledUpCertificationDocument");
	public static final String SELECT_ROLLED_UP_CERTIFICATION_DOCUMENT_ID = "frommid["+RELATIONSHIP_PGROLLEDUPCERTIFICATIONDOCUMENT+"].to." + "id";
	public static final String CERTCOMMENTS="certificationComments";
	public static final String RELATIONSHIPTYPE="relationshipType";
	public static final String SOURCETYPE="sourceType";
	public static final String SOURCEID="sourceId";
	public static final String SUPPORTDOCSNAME="supportDocName";
	public static final String SUPPORTDOCSID="supportDocId";
	public static final String SUPPORTDOCSTYPE="supportDocType";
	public static final String PACKAGINGCERTIFICATIONS="packagingCertifications";
	//SPEC: <07.06.2022>: Guna Added for Req 36041 and 41754 22x Release  -- END
	//SPEC: <08.06.2022>: Guna Added for Req 36041 22x Release  -- START
	public static final String CONST_CONSUMERTESTLABEL="pgConsumerTestLabel";
	public static final String CONST_DPICFILE="pgDPICFileAttach";//SPEC: 26-08-2022: Pooja Modified for Defect 50359
	public static final String RELATIONSHIP_LATEST_VERSION = PropertyUtil.getSchemaProperty(null,"relationship_LatestVersion");
	//SPEC: <08.06.2022>: Guna Added for Req 36041 22x Release  -- END
	//SPEC: 22/05/2022: Added by Manikanta for 22x DEV Req 42404-- START
	public static final String PARAMETERSET = "ParameterSet";
	public static final String RMPNAME = "RMPName";
	public static final String GROUP = "Group";
	public static final String DESIGNPARAMETERVALUES = "designParameterValues";
	public static final String DESIGN_PARAMETER_VALUES = "Design Parameter Values";
	public static final String MATERIALFUNCTION = "MaterialFunction";
	public static final String UNIQUEKEY = "uniqueKey";
	public static final String CHG = "Chg";
	public static final String KEY_LAYER = "Layer";
	public static final String TYPE_VPMREFERENCE = PropertyUtil.getSchemaProperty("type_VPMReference");
	public static final String STR_AUTOMATION_DESIGN_PARAMETER_FILE_NAME = "Design_Parameters";
	public static final String CONSTANT_STRING_UNDERSCORE  = "_";
	public static final String STR_XMLFILE_EXTENSION = ".xml";
	public static final String FORMAT_NOT_RENDERABLE = "Not Renderable";
	public static final String STR_ROOT = "Root";
	public static final String CONSTANT_STRING_XMLPATH_SEPARATOR = "/";
	public static final String STR_PRODUCT_DEFINITION = "ProductDefinition";
	public static final String STR_VARIANTS = "Variants";
	public static final String STR_PERFORMANCE_CHAR = "PerformanceChar";
	public static final String STR_VARIANTS_PERFORMANCE_CHAR = "VariantsPerformanceChar";
	public static final String KEY_ISACTIVE = "IsActive";
	public static final String KEY_HIDDEN = "hidden";
	public static final String STR_SPACE_CHAR = "_SPACE_CHAR_";
	public static final String STR_TILDA_CHAR = "_TILDA_CHAR_";
	public static final String STR_RMP = "RMP";
	public static final String RANGE_VALUE_CHG_C = "C";	
	public static final String RANGE_VALUE_CHG_CPLUS = "C+";
	public static final String AZURE_FILE_DOWNLOAD_PATH = "/opt/matrix/EnoviaServices/EnoviaFiles";
	public static final String AZURE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=specdev2docstorage;AccountKey=Eb225im5YdaQKI7KnjCABc5HBVy1Xmmtha8DcC0GFbd8V+E7X1LKnLmK6Sa8+7ZsHS5+0jcVZwD49oVDr3KK9A==;EndpointSuffix=core.windows.net";
	public static final String AZURE_CONTAINER = "enovia-docs-container";
	public static final String STR_FILENAME = "fileName";
	//SPEC: 22/05/2022: Added by Manikanta for 22x DEV Req 42404-- END
	//SPEC: <09.06.2022>: Guna Added for Req 33476 and 41754 22x Release  -- START
	public static final String RELATIONSHIP_PG_PLI_PACKAGING_CERTIFICATIONS = PropertyUtil.getSchemaProperty("relationship_pgPLIPackagingCertifications");
	public static final String RELATIONSHIP_PG_CERTIFICATION_DOCUMENT = PropertyUtil.getSchemaProperty("relationship_pgCertificationDocument");
	public static final String STR_SEL_CERTIFICATION_DOC_NAME = "frommid[" + RELATIONSHIP_PG_CERTIFICATION_DOCUMENT + "].to." + "name";
	public static final String STR_SEL_CERTIFICATION_DOC_ID = "frommid[" + RELATIONSHIP_PG_CERTIFICATION_DOCUMENT + "].to." + "id";
	public static final String STR_SEL_CERTIFICATION_DOC_IS_LAST = "frommid[" + RELATIONSHIP_PG_CERTIFICATION_DOCUMENT + "].to." + "islast";
	//SPEC: Added for Req 42584 - Satyam -- START
	public static final String STR_SEL_CERTIFICATION_DOC_CURRENT = "frommid[" + RELATIONSHIP_PG_CERTIFICATION_DOCUMENT + "].to." + "current";
	public static final String STR_SEL_CERTIFICATION_DOC_TYPE = "frommid[" + RELATIONSHIP_PG_CERTIFICATION_DOCUMENT + "].to." + "type";
	//SPEC: Added for Req 42584 - Satyam -- END
	public static final String EQUIVALENT="Equivalent";
	//SPEC: <09.06.2022>: Guna Added for Req 33476 and 41754 22x Release  -- END
	
	//Added by Pooja for the req 35902,41754,33476 -- START	
	public static final String PGINTEGRATEDLIDGLASSBOTTLEONLY  = "IntegratedLidGlassBottleOnly";
	public static final String ATTRIBUTE_PGINTEGRATEDLIDGLASSBOTTLEONLY = PropertyUtil.getSchemaProperty("attribute_pgIntegratedLidGlassBottleOnly");
	public static final String SELECT_ATTRIBUTE_PGINTEGRATEDLIDGLASSBOTTLEONLY = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGINTEGRATEDLIDGLASSBOTTLEONLY + "]";
	public static final String PGDESIGNEDFORREUSE  = "DesignedforReUse";
	public static final String ATTRIBUTE_PGDESIGNEDFORREUSE = PropertyUtil.getSchemaProperty("attribute_pgDesignedforReUse");
	public static final String SELECT_ATTRIBUTE_PGDESIGNEDFORREUSE = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGDESIGNEDFORREUSE + "]";
	public static final String PGLABELREMOVABILITY  = "LabelRemovability";
	public static final String ATTRIBUTE_PGLABELREMOVABILITY = PropertyUtil.getSchemaProperty("attribute_pgLabelRemovability");
	public static final String SELECT_ATTRIBUTE_PGLABELREMOVABILITY = "attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGLABELREMOVABILITY + "]";
	public static final String SOURCE  = "source";
	public static final String PARTID = "PartID";
	public static final String PARTTYPE = "PartType";
	public static final String SUPPORTDOCS = "supportDocs";
	public static final String CERTIFICATENAME = "CertificateName";
	public static final String SELECT_CONNECTION_NAME = "name[connection]";
	public static final String POSITION = "Position";
	public static final String ISDISABLESELECTION = "IsDisableSelection";
	public static final String SELECT_CONNECTION_TYPE = "type[connection]";
	public static final String HASDOC = "hasDoc";
	public static final String DOCNAME = "DocName";
	//Added by Pooja for the req 35902,41754,33476 -- END
	public static final String ATTRIBUTE_CHAUPPERSPECIFICATIONLIMIT = PropertyUtil.getSchemaProperty("attribute_CharacteristicsUpperSpecificationLimit");
	public static final String SELECT_ATTRIBUTE_CHAUPPERSPECIFICATIONLIMIT = "attribute[" + ATTRIBUTE_CHAUPPERSPECIFICATIONLIMIT + "]";
	public static final String ATTRIBUTE_CHALOWERROUTINERELEASELIMIT = PropertyUtil.getSchemaProperty("attribute_CharacteristicsLowerRoutineReleaseLimit");
	public static final String SELECT_ATTRIBUTE_CHALOWERROUTINERELEASELIMIT = "attribute[" + ATTRIBUTE_CHALOWERROUTINERELEASELIMIT + "]";
	public static final String ATTRIBUTE_CHAUPPERROUTINERELEASELIMIT = PropertyUtil.getSchemaProperty("attribute_CharacteristicsUpperRoutineReleaseLimit");
	public static final String SELECT_ATTRIBUTE_CHAUPPERROUTINERELEASELIMIT = "attribute[" + ATTRIBUTE_CHAUPPERROUTINERELEASELIMIT + "]";
	public static final String CONST_REAL="Real";
	public static final String CONST_BOOLEAN ="Boolean";
	
	//Added by Sanjeeva for POA FPC/GTIN logic
	public static final String FPCNAME = "FPCName";
	public static final String FPCDESCR = "FPCDescr";
	public static final String FPCGTIN = "FPCGTIN";
	public static final String FPCPACKLEVEL = "FPCPackLevel";
	public static final String ATTRIBUTE_FPCDESCRIPTION = PropertyUtil.getSchemaProperty("attribute_pgAAA_FPCDescription");
	public static final String SELECT_ATTRIBUTE_FPCDESCRIPTION = "attribute[" + ATTRIBUTE_FPCDESCRIPTION + "]";
	public static final String ATTRIBUTE_PGGTIN = PropertyUtil.getSchemaProperty("attribute_pgAAA_GTIN");
	public static final String SELECT_ATTRIBUTE_PGGTIN = "attribute[" + ATTRIBUTE_PGGTIN + "]";
	public static final String ATTRIBUTE_PGDSOTYPE = PropertyUtil.getSchemaProperty("attribute_pgAAA_DSOType");
	public static final String SELECT_ATTRIBUTE_PGDSOTYPE = "attribute[" + ATTRIBUTE_PGDSOTYPE + "]";
	public static final String FPP_GTIN_IT = "FPP_GTIN_IT";
	public static final String FPP_GTIN_SW = "FPP_GTIN_SW";
	public static final String FPP_GTIN_CS = "FPP_GTIN_CS";
	public static final String FPP_GTIN_NGTIN = "FPP_GTIN_NGTIN";
	public static final String FPP_DESC = "FPP_DESC";
	public static final String DESCRIPTION = "Description";
	//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- START
	public static final String CHILDFPC = "Matnr";
	//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50223-- END
	public static final String BASEUNITOFMEASURE_NGTIN = "NGTIN";
	public static final String LANGUAGE = "Language";
	public static final String VAULT_ESERVICEADMINISTRATION = "eService Administration";
	public static final String CURRENT_RELEASE = "current==Release";
	public static final String CURRENT_RELEASE_OR_ACTIVE =  "(current == Release) || (current == Active)";
	//SPEC: 09-08-2022: Dominic Modified for Defect 49835 -- START
	public static final String ARTORPOA = "Art";
	//SPEC: 09-08-2022: Dominic Modified for Defect 49835 -- END
	public static final String FPP_CSSTYPE = "pgFinishedProduct";
	//SPEC: 20-06-2022: Pooja Added for Internal Defect -- START
	public static final String REL_PARTFAMILYREFERENCE = PropertyUtil.getSchemaProperty("relationship_PartFamilyReference");
	public static final String SELECT_REL_PARTFAMILYREFERENCE = "to[Classified Item].frommid[" + REL_PARTFAMILYREFERENCE + "].torel.to.id";
	//SPEC: 20-06-2022: Pooja Added for Internal Defect -- END
	
	//SPEC: <23.06.2022>: Guna Added for Req 42583 22x Release  -- START
	public static final String ATTR_PG_PACKAGING_MATERIAL_CERTIFICATIONS = PropertyUtil.getSchemaProperty("attribute_pgPackagingMaterialCertifications");
	public static final String SELECT_ATTR_PG_PACKAGING_MATERIAL_CERTIFICATIONS ="attribute[" + ATTR_PG_PACKAGING_MATERIAL_CERTIFICATIONS + "]";
	public static final String INTENDEDPACKAGINGMATERIALCERTIFICATION = "intendedPackagingMaterialCertification";
	//SPEC: <23.06.2022>: Guna Added for Req 42583 22x Release  -- END

	public static final String SOAPENVENVELOPE= "soapenv:Envelope";
	public static final String XMLNSSOAPENVKEY = "xmlns:soapenv";
	public static final String XMLNSSOAPENVVAL = "http://schemas.xmlsoap.org/soap/envelope/";
	public static final String XMLNSGPDBKEY = "xmlns:gpdb";
	public static final String XMLNSGPDBVAL = "http://pg.com/xi/mdm/gpdb";
	public static final String SOAPENVHEADER = "soapenv:Header";
	public static final String SOAPENVBODY = "soapenv:Body";
	public static final String GPDBSERVICE = "gpdb:GPDB_ProductGetDetails";
	public static final String GPDBPRODUCTMAT= "gpdb:ProductMatnr";
	public static final String INCLUDEDERIVEDATTRIBUTES = "includeDerivedAttributes";
	public static final String INCLUDELEADINGZEROS = "includeLeadingZeros";
	public static final String LETTERE = "E";
	public static final String AUTHORIZATION = "Authorization";
	public static final String BASIC = "Basic ";
	public static final String LETTERA = "A";
	public static final int ZERO = 0;
	public static final String DSM = "DSM";
	public static final String CSCOLON = "CS:";
	public static final String ITCOLON = "IT:";
	public static final String SWCOLON = "SW:";
	//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- START
	public static final String NGTINCOLON = "NGTIN:";
	//SPEC: 23-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50225-- END
	public static final String HYPHENS = "---";
	public static final String DELIMITER = "#~#";

	public static final String RENDITION = "Rendition";
	public static final String REFERENCEFILE = "Reference File";
	public static final String QUALEVOLUTIONCHARTFILE = "Quality Evolution Chart File";
	public static final String QECFILE = "QEC_File";
	public static final String DESIGN_FILE= "Design_File";
	public static final String DESIGNFILE = "Design File";
	public static final String LANG_RENDITION = "Language_Rendition";
	public static final String LANGRENDITION = "Language Rendition";
	public static final String STARTSWITHLR = "LR_*";
	public static final String SPACEPLANT = " Plant";
	public static final String CURRENTNOTOBSOLETE = "current!=Obsolete";
	public static final String CURRENTRELEASE = "current==Release || current==RELEASED";

	//SPEC: <01.07.2022>: Guna Added for Req 43515 22x Release  -- START
	public static final String TYPESELECTS = "Packaging Assembly Part,pgFabricatedPart,Packaging Material Part,pgInnerPackUnitPart,pgConsumerUnitPart,pgCustomerUnitPart,pgAncillaryPackagingMaterialPart";
	public static final String SELECT_EBOM ="from["+RELATIONSHIP_EBOM+"]";
	public static final String SELECT_EBOM_NAME ="from.name";
	//SPEC: <01.07.2022>: Guna Added for Req 43515 22x Release  -- END
	
	//SPEC: <06.07.2022>: Manikanta Modified for Req 41754 22x Release  -- START
	public static final String SELECT_EBOM_SUBSTITUTE_PGLIFECYCLE_STATUS  = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.").append(ConstantsUtil.SELECT_PGLIFECYCLE_STATUS).toString();
	public static final String SELECT_EBOM_SUBSTITUTE_MATERIALRESTRICTION  = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.").append(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION).toString();
	public static final String SELECT_EBOM_SUBSTITUTE_PGMATERIALRESTRICTIONCOMMENTS  = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.").append(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALRESTRICTIONCOMMENTS).toString();
	public static final String SELECT_EBOM_SUBSTITUTE_PGORIGINATINGSOURCE  = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.").append(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE).toString();
	public static final String FINISHED_PRODUCT  = "Finished Product";
	public static final String FWIP_FINISHED_WORK_IN_PROCESS = "FWIP-Finished Work in Process";
	public static final String PURCHASED_SUBASSEMBLY = "Purchased Subassembly";
	public static final String PURCHASED_PRODUCED_SUBASSEMBLY = "Purchased and/or Produced Subassembly";
	//SPEC: <06.07.2022>: Manikanta Modified for Req 41754 22x Release  -- END
	
	//SPEC: 11-07-2022: Satyam Added for Internal Defect -- START
	public static final String LAYERGROUP="layerGroup";
	public static final String ATTRIBUTE_LAYERGROUP = PropertyUtil.getSchemaProperty("attribute_pgLayerGroupName");
	public static final String SELECT_ATTRIBUTE_LAYERGROUP = "attribute["+ ATTRIBUTE_LAYERGROUP + "].value";
	//SPEC: 11-07-2022: Satyam Added for Internal Defect -- END
	
	public static final String ATTRIBUTE_CHARUPDATESTATUS = PropertyUtil.getSchemaProperty("attribute_pgLPDPerfCharacteristicsUpdateStatus");
	public static final String SELECT_ATTRIBUTE_CHARUPDATESTATUS = "attribute[" + ATTRIBUTE_CHARUPDATESTATUS + "]";
	public static final String ATTRIBUTE_LPDMODELUPDATESTATUS = PropertyUtil.getSchemaProperty("attribute_pgLPDModelUpdateStatus");
	public static final String SELECT_ATTRIBUTE_LPDMODELUPDATESTATUS = "attribute[" + ATTRIBUTE_LPDMODELUPDATESTATUS + "]";
	public static final String ATTRIBUTE_LPDREASONCHANGEGENERICMODEL = PropertyUtil.getSchemaProperty("attribute_pgLPDReasonForChangeGenericModel");
	public static final String SELECT_ATTRIBUTE_LPDREASONCHANGEGENERICMODEL = "attribute[" + ATTRIBUTE_LPDREASONCHANGEGENERICMODEL + "]";
	
	public static final String CHARUPDATESTATUS = "charactersticUpdateStatus";
	public static final String MODELUPDATESTATUS = "modelUpdateStatus";
	public static final String REASONFORCHANGEGENERICMODEL = "reasonForChangeInGenericModel";
	public static final String GENERIC = "Generic";
	
	public static final String SELECT_STACKPATTERNISPRESENT = "from[Extended Data].to[pgTransportUnitCharacteristic].to[Reference Document]";
	public static final String TYPE_PG_IRM_DOCUMENT = PropertyUtil.getSchemaProperty(null,"type_pgIRMDocument");
	public static final String BUSINESSTYPE="BusinessType";
	public static final String TYPELIST="slTypesList";
	public static final String POLICY_ECPART = PropertyUtil.getSchemaProperty("policy_ECPart");
	public static final String SLNO = "no";
	//SPEC: <14.07.2022>: Guna Added for Req 41754 22x Release  -- START
	public static final String RELATIONSHIP_CLASSIFIED_ITEM = PropertyUtil.getSchemaProperty("relationship_ClassifiedItem");
	//SPEC: <14.07.2022>: Guna Added for Req 41754 22x Release  -- END
	
	public static final String ATTRIBUTE_BUILDPATH = PropertyUtil.getSchemaProperty("attribute_pgBuildPath");
	public static final String SELECT_ATTRIBUTE_BUILDPATH= "attribute[" + ATTRIBUTE_BUILDPATH + "]";

	//SPEC: 16-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50049-- START
	public static final String ATTRIBUTE_PGMATERIALRESTRICTIONCOMMENT = PropertyUtil.getSchemaProperty("attribute_pgMaterialRestrictionComment");
	public static final String SELECT_ATTRIBUTE_PGMATERIALRESTRICTIONCOMMENT = "attribute[" + ATTRIBUTE_PGMATERIALRESTRICTIONCOMMENT + "]";
	//SPEC: 16-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50049-- END
	
	public static final String MASS = "Mass";
	public static final String DECIMAL_ZERO = "0.00";
	public static final String IRMSTORE = "IRMStore";
	//SPEC: <17.08.2022>: Guna Added for Defect 50094 22x Release  -- START
	public static final String SELECT_UNIT_OF_MEASURE = "attribute["+PropertyUtil.getSchemaProperty("attribute_ObscureUnitofMeasure")+"]";
	//SPEC: <17.08.2022>: Guna Added for Defect 50094 22x Release  -- END
	//SPEC: 24-08-2022: Pooja Modified for Defect 50276-- START
	public static final String SELECT_ACTUAL_RELEASE_DATE = "state[Release].actual";
	//SPEC: 24-08-2022: Pooja Modified for Defect 50276-- END
	//Added by Pooja for 22x Defect 50271 -- START
	public static final String TYPE_PPMSUBSTANCE = PropertyUtil.getSchemaProperty("type_pgPPMSubstance");
	//Added by Pooja for 22x Defect 50271 -- START
	//Added by Manikanta for 22x Defect 50325 -- START
		public final static String TYPE_DOCUMENT = PropertyUtil.getSchemaProperty("type_Document");
		//Added by Manikanta for 22x Defect 50325 -- END
		//SPEC: 26-08-2022: Pooja added for Defect 50362
		public static final String CONST_STUDYCLINIC="IsThisClinicalStudy";
		//SPEC: 26-08-2022: Pooja added for Defect 50362
		//Added by Pooja for 22x Defect 50271 -- START
		public static final String ATTRIBUTE_SUBSTANCENAME = PropertyUtil.getSchemaProperty("attribute_SubstanceName");
		public static final String SELECT_ATTRIBUTE_SUBSTANCENAME = "attribute[" + ATTRIBUTE_SUBSTANCENAME + "]";
		//Added by Pooja for 22x Defect 50271 -- END
		//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- START
		public static final String CONSTANT_THIRDLEVEL = "3";
		public static final String CONST_VALUE_ONE = "1";
		//SPEC: 02-09-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50459-- END
		//SPEC: 09-05-2022: Pooja added for Defect 50517 -- START
		public static final String  SELECT_FROM_POLICY  = "from.policy";
		//SPEC: 09-05-2022: Pooja added for Defect 50517 -- END
		public static final String PARENT_ID = "parentId";
		public static final String PARENT_NAME = "parentName";
		public static final String PARENT_REVISION = "parentRevision";
		public static final String PARENT_TYPE = "parentType";
		public static final String SELECT_EBOM_ID = "from.id";
		public static final String SELECT_EBOM_TYPE = "from.type";
		public static final String SELECT_EBOM_REV = "from.revision";
		//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- START
		public static final String ATTRIBUTE_PGWNDVALEXCP = PropertyUtil.getSchemaProperty("attribute_pgWnDValExcp");
		public static final String SELECT_ATTRIBUTE_PGWNDVALEXCP = "attribute[" + ATTRIBUTE_PGWNDVALEXCP + "]";
		public static final String ATTRIBUTE_PGWNDEXCPCMT = PropertyUtil.getSchemaProperty("attribute_pgWnDExcpCmt");
		public static final String SELECT_ATTRIBUTE_PGWNDEXCPCMT = "attribute[" + ATTRIBUTE_PGWNDEXCPCMT + "]";
		public static final String WDVALIDATIONEXCEPTION = "wdValidationException";
		public static final String WDVALIDATIONEXCEPTIONCOMMENT = "wdValidationExceptionComment";
		public static final String WDVALIDATIONEXCEPTIONSUPPORTDOC = "wdValidationExceptionSupportDoc";
		public static final String WDVALIDATIONEXCEPTIONSUPPORTDOCTYPE = "wdValidationExceptionSupportDocType";
		public static final String WDVALIDATIONEXCEPTIONSUPPORTDOCID = "wdValidationExceptionSupportDocId";
		public static final String RELATIONSHIP_PGWNDEXCPSUPPORTDOC = PropertyUtil.getSchemaProperty("relationship_pgWnDExcpSupportDoc");
		public static final String SELECT_PGWNDEXCPSUPPORTDOC = "from[" + RELATIONSHIP_PGWNDEXCPSUPPORTDOC + "].to." + "name";
		public static final String SELECT_PGWNDEXCPSUPPORTDOC_TYPE = "from[" + RELATIONSHIP_PGWNDEXCPSUPPORTDOC + "].to." + "type";
		public static final String SELECT_PGWNDEXCPSUPPORTDOC_ID = "from[" + RELATIONSHIP_PGWNDEXCPSUPPORTDOC + "].to." + "id";
		//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- END
				//Added by Subhajit , Req - 45670 - Start
		public static final String ALLOWED_MEP_NAME = "allowedMepName";
		public static final String ALLOWED_MEP_TITLE = "allowedMepTitle";
		public static final String ALLOWED_MEP_VENDOR = "allowedMepVendor";
		public static final String ALLOWED_MEP_ID = "allowedMepId";
		public static final String ALLOWED_MEP_TYPE = "allowedMepType";
		//Added by Subhajit , Req - 45670 - End
		public static final String MEP = "MEP";
		public static final String SEP = "SEP";
		//Added by Ketan for Req. no. 46464 - START
		public static final String ATTRIBUTE_RELATIONSHIPRESTRICTION = PropertyUtil.getSchemaProperty("attribute_pgMaterialRestriction");
		public static final String SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION = "attribute[" + ATTRIBUTE_RELATIONSHIPRESTRICTION + "]";
		public static final String ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS = PropertyUtil.getSchemaProperty("attribute_pgMaterialRestrictionComment");
		public static final String SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS = "attribute[" + ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS + "]";
		public static final String RELATIONSHIPRESTRICTION = "relationshipRestriction";
		public static final String RELATIONSHIPRESTRICTIONCOMMENTS = "relationshipRestrictionComment";
		public static final String SELECT_EBOM_SUBSTITUTE_RR  = "frommid[EBOM Substitute].to."+SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION;
		public static final String SELECT_EBOM_SUBSTITUTE_RRC  = "frommid[EBOM Substitute].to."+SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS;
		public static final String PGCONSUMERPACKFAMILY = "consumerPackFamily";
		public static final String PGCONSUMERPRIMARYPACKAGINGTYPE = "consumerPrimaryPackagingType";
		public static final String PGCONSUMERSECONDARYPACKAGINGTYPE = "consumerSecondaryPackagingType";
		public static final String ATTRIBUTE_PGCONSUMERPACKFAMILY = PropertyUtil.getSchemaProperty("attribute_pgConsumerPackFamily");
		public static final String SELECT_ATTRIBUTE_PGCONSUMERPACKFAMILY = "attribute[" + ATTRIBUTE_PGCONSUMERPACKFAMILY + "]";
		public static final String ATTRIBUTE_PGCONSUMERPRIMARYPACKAGINGTYPE = PropertyUtil.getSchemaProperty("attribute_pgConsumerPrimaryPackagingType");
		public static final String SELECT_ATTRIBUTE_PGCONSUMERPRIMARYPACKAGINGTYPE = "attribute[" + ATTRIBUTE_PGCONSUMERPRIMARYPACKAGINGTYPE + "]";
		public static final String ATTRIBUTE_PGCONSUMERSECONDARYPACKAGINGTYPE = PropertyUtil.getSchemaProperty("attribute_pgConsumerSecondaryPackagingType");
		public static final String SELECT_ATTRIBUTE_PGCONSUMERSECONDARYPACKAGINGTYPE = "attribute[" + ATTRIBUTE_PGCONSUMERSECONDARYPACKAGINGTYPE + "]";
		//Added by Ketan for Req. no. 46464 - END
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- START
		public static final String COMPONENTPACKFAMILY1 = "componentPackFamily1";
		public static final String COMPONENTPACKFAMILY2 = "componentPackFamily2";
		public static final String COMPONENTPACKFAMILY3 = "componentPackFamily3";
		public static final String AUTHORINGAPPLICATION = "authoringApplication";
		public static final String ATTRIBUTE_COMPONENTPACKFAMILY1 = PropertyUtil.getSchemaProperty("attribute_pgComponentPackFamilyLevel1");
		public static final String SELECT_ATTRIBUTE_COMPONENTPACKFAMILY1 = "attribute[" + ATTRIBUTE_COMPONENTPACKFAMILY1 + "]";
		public static final String ATTRIBUTE_COMPONENTPACKFAMILY2 = PropertyUtil.getSchemaProperty("attribute_pgComponentPackFamilyLevel2");
		public static final String SELECT_ATTRIBUTE_COMPONENTPACKFAMILY2 = "attribute[" + ATTRIBUTE_COMPONENTPACKFAMILY2 + "]";
		public static final String ATTRIBUTE_COMPONENTPACKFAMILY3 = PropertyUtil.getSchemaProperty("attribute_pgComponentPackFamilyLevel3");
		public static final String SELECT_ATTRIBUTE_COMPONENTPACKFAMILY3 = "attribute[" + ATTRIBUTE_COMPONENTPACKFAMILY3 + "]";
		public static final String ATTRIBUTE_AUTHORINGAPPLICATION = PropertyUtil.getSchemaProperty("attribute_pgAuthoringApplication");
		public static final String SELECT_ATTRIBUTE_AUTHORINGAPPLICATION = "attribute[" + ATTRIBUTE_AUTHORINGAPPLICATION + "]";
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- END
		//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- START
		public static final String REFERENCE = "reference";
		public static final String PREVIOUSID = "previous.id";
		public static final String PREVIOUSCURRENT = "previous.current";
		public static final String PREVIOUSTYPE = "previous.type";
		//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- END
		//Added by Subhajit for Defect 50614 - Start
		public static final String ERROR_CATEGORY = "errorcategory";
		public static final String CATEGORY_CERTIFICATION = "Certifications";
		public static final String CATEGORY_ENTERPRISEPART = "Enterprise Parts";
		//Added by Subhajit for Defect 50614 - End
		//SPEC: <04.10.2023>: Manikanta Added for 22x_DecCW -- START
		public static final String IMPACTEDPARTS = "impactedParts";
		public static final String REL_CLASSIFIED_ITEM = "Classified Item";
		public static final String IMPACTED_PART_TYPE = "pgSupplierInformationSheet,pgLaboratoryIndexSpecification,pgIllustration,pgLogisticSpec,pgVPDExternalTestMethod,pgMakingInstructions,pgProcessStandard,pgApprovedSupplierList,pgQualitySpecification,pgDSOAffectedFPPList,pgCommonPerformanceSpecification,pgRawMaterialPlantInstruction,pgConsumerDesignBasis,pgStackingPattern,Copy and Graphics Specification,Packing Process Specification,Pallet Information Specification,pgAuthorizedConfigurationStandard,pgPackingInstructions,pgStandardOperatingProcedure,Formula Technical Specification,Process Technical Specification,pgTestMethod,Test Method,Test Method Specification,POA,pgArtwork";
		public static final String WHERE_USED_MASTER_TYPE = "pgMasterPackagingMaterialPart,pgMasterPackingMaterial,pgMasterPackagingAssemblyPart,pgMasterRawMaterial,pgMasterRawMaterialPart,pgMasterProductPart";
		public static final String WHERE_USED_MASTER_PART_REL = "tomid[" + REL_PARTFAMILYREFERENCE + "].fromrel.to.id";
		public static final String WHERE_USED_TYPE = "pgAncillaryPackagingMaterialPart,Packaging Assembly Part,pgPackingSubassembly,Packaging Material Part,pgPackingMaterial,pgFabricatedPart,pgOnlinePrintingPart,pgPromotionalItemPart,pgAssembledProductPart,pgDeviceProductPart,Formulation Part,pgIntermediateProductPart,pgSoftwarePart,Raw Material Part,pgRawMaterial,Raw Material,pgAncillaryRawMaterialPart,pgFinishedProduct,Finished Product Part";
		//SPEC: <04.10.2023>: Manikanta Added for 22x_DecCW -- END
		//Added by Ketan for Req no. 1589,2180 -- START
		public static final String STRUCTURED_TYPE = "pgDeviceProductPart,pgIntermediateProductPart,pgFabricatedPart,pgAssembledProductPart,Formulation Part,Packaging Assembly Part,Packaging Material Part,Raw Material Part,pgRawMaterial,Raw Material,Finished Product Part,pgFinishedProduct,pgTransportUnitPart,pgCustomerUnitPart,pgInnerPackUnitPart,pgConsumerUnitPart";
		public static final String UNSTRUCTURED_TYPE = "pgIllustration,pgTestMethod,Test Method,Test Method Specification,pgStandardOperatingProcedure,pgQualitySpecification,pgAuthorizedConfigurationStandard,Formula Technical Specification,pgMakingInstructions,pgProcessStandard,pgPackingInstructions,pgLaboratoryIndexSpecification,pgRawMaterialPlantInstruction,pgStackingPattern";
		public static final String MASTER_TYPES = "pgMasterPackagingMaterialPart,pgMasterPackingMaterial,pgMasterPackagingAssemblyPart,pgMasterRawMaterial,pgMasterRawMaterialPart,pgMasterProductPart,pgMasterConsumerUnitPart,pgMasterCustomerUnitPart,pgMasterInnerPackUnitPart";
		public static final String TYPE_BACKEND = "backendType";
		
		public static final String RELATIONSHIP_ATS = PropertyUtil.getSchemaProperty("relationship_AuthorizedTemporarySpecification");
		public static final String SELECT_RELATIONSHIP_ATS_TO_TYPE ="from["+RELATIONSHIP_ATS+"].to.type";
		public static final String SELECT_RELATIONSHIP_ATS_TO_ID ="from["+RELATIONSHIP_ATS+"].to.id";
		public static final String SELECT_RELATIONSHIP_ATS_TO_NAME = "from["+RELATIONSHIP_ATS+"].to.name";
		public static final String SELECT_RELATIONSHIP_ATS_TO_REVISION = "from["+RELATIONSHIP_ATS+"].to.revision";
		public static final String SELECT_RELATIONSHIP_ATS_TO_TITLE = "from["+RELATIONSHIP_ATS+"].to."+ConstantsUtilIRM.SELECT_ATTRIBUTE_TITLE;
		//Added by Ketan for Req no. 1589,2180 -- END
		public static final String ATTRIBUTE_FIRST_NAME = PropertyUtil.getSchemaProperty("attribute_FirstName");
		public static final String SELECT_ATTRIBUTE_FIRST_NAME = "attribute[" + ATTRIBUTE_FIRST_NAME + "]";
		public static final String ATTRIBUTE_LAST_NAME = PropertyUtil.getSchemaProperty("attribute_LastName");
		public static final String SELECT_ATTRIBUTE_LAST_NAME = "attribute[" + ATTRIBUTE_LAST_NAME + "]";
		public static final String ATTRIBUTE_EMAIL_ADDRESS = PropertyUtil.getSchemaProperty("attribute_EmailAddress");
		public static final String SELECT_ATTRIBUTE_EMAIL_ADDRESS = "attribute[" + ATTRIBUTE_EMAIL_ADDRESS + "]";
		public static final String ATTRIBUTE_PGCONTACT_EMAIL = PropertyUtil.getSchemaProperty("attribute_pgContactEmail");
		public static final String SELECT_ATTRIBUTE_PGCONTACT_EMAIL = "attribute[" + ATTRIBUTE_PGCONTACT_EMAIL + "]";
		public static final String RELATIONSHIP_PGSIGNUPFORM = PropertyUtil.getSchemaProperty("relationship_pgSignupForm");
		public static final String TYPE_PGSIGNUPFORM = PropertyUtil.getSchemaProperty("type_pgSignupForm");
		
		public static final String STR_FIRSTNAME = "firstname";
		public static final String STR_LASTNAME = "lastname";
		public static final String STR_EMAILADDRESS = "emailaddress";
		public static final String STR_PGCONTACTEMAIL = "pgcontactemail";
		public static final String STR_USRINFORMATION = "UserInformation";
		public static final String DISPLAY_TYPE = "displayType";
		
		public static final String PGEMAIL= "@pg.com";
		public static final String ROLE_PGPGCONTACT = PropertyUtil.getSchemaProperty("role_pgIPMPGContact");
		
		public static final String CURRENT_DRAFT = "current == Draft";
		public static final String EXTENDED_DATA_SEL = "to[Extended Data].from.";
		public static final String WHERE_USED_FIRST_LVL_SPEC = "pgMakingInstructions,pgAuthorizedConfigurationStandard,Formula Technical Specification,pgProcessStandard,pgLaboratoryIndexSpecification,pgAuthorizedTemporarySpecification,pgStructuredATS,pgStandardOperatingProcedure";
		public static final String WHERE_USED_PERF_CHAR_SPEC = "pgIllustration,pgTestMethod,Test Method,Test Method Specification,pgStandardOperatingProcedure,pgQualitySpecification";
		public static final String E118 ="E118:This is a highly connected part. There could be other Enterprise Parts connected. Please contact support.";
		//Added by Manikanta for Req. no. 2334 - START
		public static final String SELECT_MANUFACTURINGRESPONSIBILITY_CITY = "to[" +ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY + "].from." +SELECT_ATTRIBUTE_CITY;
		public static final String SELECT_MANUFACTURINGRESPONSIBILITY_STATE = "to[" +ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY + "].from." +ConstantsUtil.SELECT_ATTRIBUTE_STATEREGION;
		public static final String SELECT_MANUFACTURINGRESPONSIBILITY_COUNTRY = "to[" +ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY + "].from." +SELECT_ATTRIBUTE_COUNTRY;
		public static final String SELECT_MANUFACTURINGRESPONSIBILITY_PGHOUSENUMBER = "to[" +ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY + "].from." +ConstantsUtil.SELECT_ATTRIBUTE_PGHOUSENUMBER;
		public static final String SELECT_MANUFACTURINGRESPONSIBILITY_ADDRESS = "to[" +ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY + "].from." +SELECT_ATTRIBUTE_ADDRESS;
		public static final String SELECT_SUPPLYRESPONSIBILITY_PGHOUSENUMBER = "to[" +ConstantsUtil.RELATIONSHIP_SUPPLYRESPONSIBILITY + "].from." +ConstantsUtil.SELECT_ATTRIBUTE_PGHOUSENUMBER;
		public static final String SELECT_SUPPLYRESPONSIBILITY_ADDRESS = "to[" +ConstantsUtil.RELATIONSHIP_SUPPLYRESPONSIBILITY + "].from." +SELECT_ATTRIBUTE_ADDRESS;
		public static final String SELECT_SUPPLYRESPONSIBILITY_POSTALCODE = "to[" + ConstantsUtil.RELATIONSHIP_SUPPLYRESPONSIBILITY + "].from."+ConstantsUtil.SELECT_ATTRIBUTE_POSTALCODE;
		//Added by Manikanta for Req. no. 2334 - END
		
		//Added by Ketan for Req. no. 5327 -- START
		public static final String NAME = "Name";
		public static final String REV = "Rev";
		public static final String TYPE = "Type";
		public static final String ID = "Id";
		public static final String SECTIONS = "sections";
		public static final String ISFILTERVIEW = "isFilterView";
		public static final String OBJECTTYPE = "objectType";
		public static final String ROLE = "role";
		public static final String DATA = "data";
		public static final String OBJECTID = "objectID";
		public static final String VIEW = "view";
		public static final String GENDOCVIEW = "gendocView";
		public static final String COM = "COM";
		public static final String APMP = "APMP";
		public static final String APP = "APP";
		public static final String ARMP = "ARMP";
		public static final String COP = "COP";
		public static final String CUP = "CUP";
		public static final String DPP = "DPP";
		public static final String FAB = "FAB";
		public static final String FOP = "FOP";
		public static final String FPP = "FPP";
		public static final String IP = "IP";
		public static final String IPP = "IPP";
		public static final String MCOP = "MCOP";
		public static final String MCP = "MCP";
		public static final String MCUP = "MCUP";
		public static final String MIP = "MIP";
		public static final String MPAP = "MPAP";
		public static final String MPMP = "MPMP";
		public static final String MPP = "MPP";
		public static final String MRMP = "MRMP";
		public static final String OPP = "OPP";
		public static final String PAP = "PAP";
		public static final String PIP = "PIP";
		public static final String PMP = "PMP";
		public static final String POA = "POA";
		public static final String PSUB = "PSUB";
		public static final String RMP = "RMP";
		public static final String SWP = "SWP";
		public static final String TUP = "TUP";
		public static final String ATTRIBUTEOBJECT = "attributeObject";
		public static final String WEIGHTCHARACTERSTICS = "weightCharacterstics";
		public static final String SUBSTANCEMATERIALS = "substanceMaterials";
		public static final String RELATEDSPECIFICATION = "relatedSpecification";
		public static final String MASTERSPECIFICATION = "masterSpecification";
		public static final String CONS_REFERENCEDOCUMENT = "referenceDocument";
		public static final String PQRVIEWMANUFACTURER = "pqrViewManufacturer";
		public static final String PQRSUPPLIERVIEW = "pqrSupplierView";
		public static final String IPCLASSES = "ipClasses";
		public static final String SECURITYCLASSES = "securityClasses";
		public static final String ORGANIZATIONOBJECT = "organizationObject";
		public static final String FILES = "files";
		public static final String GPSASSESSMENTS = "gpsAssessments";
		public static final String WEIGHTCHARACTERSTIC = "weightCharacterstic";
		public static final String GLOBALHARMONIZEDSTANDARD = "globalHarmonizedStandard";
		public static final String STORAGETRANSPORTATIONLABELINGASSESSMENTDATA = "storageTransportationLabelingAssessmentData";
		public static final String PRODUCTPARTSTABILITYDOCUMENT = "productPartStabilityDocument";
		public static final String MASTERPARTSTABILITYDOCUMENT = "masterPartStabilityDocument";
		public static final String PERFORMANCECHARCTERISTIC = "performanceCharcteristic";
		public static final String MATERIALSANDCOMPOSITIONS = "materialsAndCompositions";
		public static final String RELATEDATS = "relatedATS";
		public static final String MATERIALPRODUCED = "materialProduced";
		public static final String FILESECTION = "fileSection";
		public static final String CERTVALIDATION = "certificationValidation";
		public static final String MASTERATTRIBUTE = "masterAttribute";
		public static final String STABILITYRESULTS = "stabilityResults";
		public static final String WARHOUSECLASSIFICATION = "warHouseClassification";
		public static final String BATTERYCALCULATION = "batteryCalculation";
		public static final String SAPBOMFED = "sapBOMFed";
		public static final String CONS_CUPARTWORK = "cupArtwork";
		public static final String WEIGHTCHARACTERISTICS = "weightCharacteristics";
		public static final String SAPBOMFEDS = "sapBomFeds";
		public static final String MARKETOFSALES = "marketOfSales";
		public static final String BILLOFMATERIAL = "billOfMaterial";
		public static final String SUBSTITUTIONS = "substitutions";
		public static final String SUBSTITUTES = "subStitutes";
		public static final String BILLOFMATERIALS = "billofMaterials";
		public static final String REFERENCEDOCUMENTS = "referenceDocuments";
		public static final String CHARACTERISTICS = "characteristics";
		public static final String SECURITYCLASS = "securityClass";
		public static final String SECURITYCLAASES = "securityClaases";
		public static final String BOMMASTERCUSTOMERUNIT = "bomMasterCustomerUnit";
		public static final String BOMMASTERINNERPACK = "bomMasterInnerPack";
		public static final String BOMMASTERCONSUMERUNIT = "bomMasterConsumerUnit";
		public static final String ORGANIZATIONSDATA = "organizationsData";
		public static final String SUBATTRIBUTES = "subAttributes";
		public static final String RELATEDPARTS = "relatedParts";
		public static final String ATTRIBUTELIST = "attributeList";
		public static final String PARTASSOCIATION = "partAssociation";
		public static final String RELATEDACS = "relatedACS";
		public static final String RELATEDIAPS = "relatedIAPS";
		public static final String RELATEDSOFTWAREBUILDS = "relatedSoftwareBuilds";
		public static final String SPECIFICATION = "specification";
		public static final String ISATS = "isATS";
		public static final String HASATS = "hasATS";
		public static final String HALBPLANTS = "halbPlants";
		public static final String ROHPLANTS = "rohPlants";
		public static final String PACKAGINGCERTIFICATIONSMASTER = "packagingCertificationsMaster";
		public static final String STARTINGMATERIAL = "startingMaterial";
		public static final String LIFECYCLEAPPROVALPOWERVIEW = "lifeCycleApprovalPowerview";
		public static final String OWNERSHIP = "ownerShip";
		public static final String CONST_SECURITYCLASSES = "securityclasses";
		public static final String WEIGHTCHARATERISTIC = "weightCharateristic";
		public static final String MARKETSOFSALEOBJECT = "marketsOfSaleObject";
		public static final String BILLOFMATERIALSFINISHEDPRODUCTPART = "billOfMaterialsFinishedProductPart";
		public static final String SUBSTITUTESMASTERCONSUNIT = "substitutesMasterConsUnit";
		public static final String BOMINNERPACK = "bomInnerPack";
		public static final String SUBSTITUTESINNERPACK = "substitutesInnerPack";
		public static final String SUBSTITUTESCONSUMERUNIT = "substitutesConsumerUnit";
		public static final String WEIGHTCHARCTERISTIC = "weightCharcteristic";
		public static final String STABILITYRESULT = "stabilityResult";
		public static final String WEIGHTCHARCTERISTICS = "weightCharcteristics";
		public static final String TRANSPORTUNITHEAD = "transportUnitHead";
		//Added by Ketan for Req. no. 5327 -- END
		//Added by Ketan for Req. no. 6045 -- START
		public static final String EXTERNAL_MATERIAL = "External Material";
		public static final String IS_SUPPLIER = "isSupplierOrSP";
		//Added by Ketan for Req. no. 6045 -- END
		public static final String REL_MANUFACTURING_RESPONSIBILITY = "Manufacturing Responsibility"; //Added by Ketan for Defect no. 6630
		//Added by Ketan  for Req no. 6581 -- START
		public static final String USER_NAME = "userName";
		public static final String OBJECT_ID = "objectId";
		public static final String STR_ORIGEMAILADDRESS = "origemailaddress";
		//Added by Ketan for Req no. 6581 -- END
		//Added by Ajay for Reg. no. 8268 START
		public static final String VENDOR_NAME = "name";
		public static final String VENDORS = "vendors";
		public static final String INACTIVEVENDORS = "InactiveVendors";
		public static final String INACTIVE_PLANT_MESSAGE = "Below Vendors/Plants are Inactivated and removed from the Preferences list:";
		public static final String PLANT_NAME="Plant";
		//Added by Ajay for Reg. no. 8268 END
		//Added by Manikanta for Reg. no. 9601 START
		public static final String REL_EBOM_SUBSTITUTE_TYPE = "to[EBOM Substitute].fromrel.from.type";
		public static final String REL_EBOM_SUBSTITUTE_NAME = "to[EBOM Substitute].fromrel.from.name";
		public static final String REL_EBOM_SUBSTITUTE_REV = "to[EBOM Substitute].fromrel.from.revision";
		public static final String REL_EBOM_SUBSTITUTE_ID = "to[EBOM Substitute].fromrel.from.id";
		public static final String REL_EBOM_SUBSTITUTE_CURRENT = "to[EBOM Substitute].fromrel.from.current";
		public static final String REL_EBOM_SUBSTITUTE_TITLE = "to[EBOM Substitute].fromrel.from.attribute[Title]";
		public static final String REL_EBOM_SUBSTITUTE_SELECTS = "to[EBOM Substitute].fromrel.from.current to[EBOM Substitute].fromrel.from.type to[EBOM Substitute].fromrel.from.name to[EBOM Substitute].fromrel.from.revision to[EBOM Substitute].fromrel.from.id to[EBOM Substitute].fromrel.from.attribute[Title]";
		//Added by Manikanta for Reg. no. 9601 END
		//Added by Ajay for req 11877 START
		public static final String TUP_REVISION="tupRevision";
		//Added by Ajay for req 11877 END
		
		//SPEC: 07.11.2024: Jwala Added for Req 11640 Release  -- START
		public static final String MELTINGPOINTTARGET ="meltingpointtarget";
		public static final String MELTINGPOINTMIN ="meltingpointmin";
		public static final String MELTINGPOINTMAX ="meltingpointmax";
		public static final String AUTOIGNITIONTEMPTARGET ="autoignitiontemptarget";
		public static final String AUTOIGNITIONTEMPMIN ="autoignitiontempmin";
		public static final String AUTOIGNITIONTEMPMAX ="autoignitiontempmax";
		public static final String DUSTEXPLOSIVITY ="dustexplosivity";
		public static final String PGKST ="pgkst";
		public static final String PGPMAX ="pgpmax";
		public static final String PARTITIONCOEFFICIENT ="partitioncoefficient";
		public static final String WATERSOLUBILITY ="watersolubility";
		
		public static final String ATTRIBUTE_PGMELTINGPOINTTARGET = PropertyUtil.getSchemaProperty("attribute_pgMeltingPointTarget");
		public static final String SELECT_ATTRIBUTE_PGMELTINGPOINTTARGET = "attribute[" + ATTRIBUTE_PGMELTINGPOINTTARGET + "].inputvalue";
		public static final String ATTRIBUTE_PGMELTINGPOINTMIN = PropertyUtil.getSchemaProperty("attribute_pgMeltingPointMin");
		public static final String SELECT_AATTRIBUTE_PGMELTINGPOINTMIN = "attribute[" + ATTRIBUTE_PGMELTINGPOINTMIN + "].inputvalue";
		public static final String ATTRIBUTE_PGMELTINGPOINTMAX = PropertyUtil.getSchemaProperty("attribute_pgMeltingPointMax");
		public static final String SELECT_ATTRIBUTE_PGMELTINGPOINTMAX= "attribute[" + ATTRIBUTE_PGMELTINGPOINTMAX + "].inputvalue";
		public static final String ATTRIBUTE_AUTOIGNITIONTEMPTARGET = PropertyUtil.getSchemaProperty("attribute_pgAutoIgnitionTempTarget");
		public static final String SELECT_ATTRIBUTE_AUTOIGNITIONTEMPTARGET = "attribute[" + ATTRIBUTE_AUTOIGNITIONTEMPTARGET + "].inputvalue";
		public static final String ATTRIBUTE_AUTOIGNITIONTEMPMIN = PropertyUtil.getSchemaProperty("attribute_pgAutoIgnitionTempMin");
		public static final String SELECT_ATTRIBUTE_AUTOIGNITIONTEMPMIN = "attribute[" + ATTRIBUTE_AUTOIGNITIONTEMPMIN + "].inputvalue";
		public static final String ATTRIBUTE_AUTOIGNITIONTEMPMAX = PropertyUtil.getSchemaProperty("attribute_pgAutoIgnitionTempMax");
		public static final String SELECT_ATTRIBUTE_AUTOIGNITIONTEMPMAX = "attribute[" + ATTRIBUTE_AUTOIGNITIONTEMPMAX + "].inputvalue";
		public static final String ATTRIBUTE_DUSTEXPLOSIVITY = PropertyUtil.getSchemaProperty("attribute_pgDustExplosivity");
		public static final String SELECT_ATTRIBUTE_DUSTEXPLOSIVITY = "attribute[" + ATTRIBUTE_DUSTEXPLOSIVITY + "].inputvalue";
		public static final String ATTRIBUTE_PGKST = PropertyUtil.getSchemaProperty("attribute_pgKST");
		public static final String SELECT_ATTRIBUTE_PGKST = "attribute[" + ATTRIBUTE_PGKST + "].inputvalue";
		public static final String ATTRIBUTE_PGMAX = PropertyUtil.getSchemaProperty("attribute_pgPMax");
		public static final String SELECT_ATTRIBUTE_PGMAX = "attribute[" + ATTRIBUTE_PGMAX + "].inputvalue";
		public static final String ATTRIBUTE_PARTITIONCOEFFICIENT = PropertyUtil.getSchemaProperty("attribute_pgPartitionCoefficient");
		public static final String SELECT_ATTRIBUTE_PARTITIONCOEFFICIENT = "attribute[" + ATTRIBUTE_PARTITIONCOEFFICIENT + "].inputvalue";
		public static final String ATTRIBUTE_WATERSOLUBILITY = PropertyUtil.getSchemaProperty("attribute_pgWaterSolubility");
		public static final String SELECT_ATTRIBUTE_WATERSOLUBILITY = "attribute[" + ATTRIBUTE_WATERSOLUBILITY + "].inputvalue";
		//SPEC: 07.11.2024: Jwala Added for Req 11640 Release  -- END
		
		public static final String USERTYPE_SBM = "SBM";
		
		//Added By Jwala for the defect 14493 : START
		public static final String CPV_CONSOLIDATEDPACKAGING = "consolidatedpackaging";
		public static final String CON_DANGEROUSGOODSCLASSIFICATION = "DangerousGoodsClassification";
		public static final String DGCLASSIFICATION = "dgClassification";
		public static final String CON_GLOBALHARMONIZEDSTANDARD = "GlobalHarmonizedStandard";
		public static final String CON_STORAGETABLEFPP = "StorageTableFPP";
		public static final String STORAGETABLEFPP = "storageTransportationLabelingAssesmentData";
		public static final String CON_DSOSTABILITYRESULTS = "DSOStabilityResults";
		public static final String DSOSTABILITYRESULTS = "stabilityDocument";
		public static final String CON_BATTERYROLLUP = "BatteryRollUp";
		public static final String BATTERYROLUP = "batteryRollUp";
		public static final String CON_WHEREHOUSECLASSIFICATION = "DSOWarehouseClassification";
		public static final String WHEREHOUSECLASSIFICATION = "warehouseClassification";
		public static final String CON_INGREDIENTTRANSPARENCY = "DSOIngredientTransparency";
		public static final String INGREDIENTTRANSPARENCY = "ingredientTransparency";
		public static final String CON_DSOUFI = "DSOUFI";
		public static final String DSOUFI = "uniqueFormulaIdentifier";
		public static final String CON_DSONOTES = "DSONotes";
		public static final String DSONOTES= "notes";
		public static final String CON_FLATBOM = "FLATBOM";
		public static final String FLATBOM = "sAPBomAsFed";
		public static final String CON_DSONEWCOSTABLE = "DSONEWCOSTABLE";
		public static final String DSONEWCOSTABLE = "marketOfSale";
		public static final String CON_FPPBOM = "FPPBOM";
		public static final String FPPBOM = "billOfMaterialsIncludesSubstitutesAllCategories";
		public static final String CON_DSOPERFORMANCE = "DSOPerformance";
		public static final String DSOPERFORMANCE = "performanceCharacteristics";
		public static final String CON_FORMULATEDPRODUCTTABLE = "pgFormulatedProductTable";
		public static final String RELATEDSPECIFICATIONS = "relatedSpecifications";
		public static final String MASTERSPECIFICATIONS = "masterSpecifications";
		public static final String CON_DSOCERTIFICATIONS = "DSOCertifications";
		public static final String DSOCERTIFICATIONS = "certifications";
		public static final String CON_DSOWND = "DSOWnD";
		public static final String DSOWND = "weightsDimensionsIncludesTransportPackingUnit";
		public static final String CON_BASECODEDETAILS= "BaseCodeDetails";
		public static final String BASECODEDETAILS= "baseCodeSubstitute";
		public static final String CON_DSOISATS= "DSOIsATS";
		public static final String DSOISATS= "relatedATS";
		//Added By Jwala for the defect 14493 : END
		//Added By Ajay for the Req 14493 : START
		public static final String Master_PI_Gendoc= "MasterPIGendoc";
		//Added By Ajay for the Req 14493 : END
		
		//Added By Ajay for the Req 5489 : START
		public static final String Stability_Document= "Stability Document";
		public static final String MOS_Component_Details= "MOS Component Details";
		//Added By Ajay for the Req 5489 : END
		//Added By Ajay for the Req 17585 : START
		public static final String INCLUDEFILEINFO= "IncludeFileInfo";
		//Added By Ajay for the Req 17585 : END
		
		public static final String RELATIONSHIP_PGSTUDYPROTOCALTOCONSUMERTESTOBJECTIVE = PropertyUtil.getSchemaProperty("relationship_pgStudyProtocolToConsumerTestObjectiveType");
		public static final String REL_OBJECTIVETYPE= "from["+RELATIONSHIP_PGSTUDYPROTOCALTOCONSUMERTESTOBJECTIVE+"].to.name";
		
		//Added By Ajay for the Req 14570 : START
		public static final String ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYMAX = PropertyUtil.getSchemaProperty("attribute_pgRelativeDensitySpecificGravityMax");
		public static final String SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYTMAX = "attribute[" + ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYMAX + "]";
		public static final String ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYMIN = PropertyUtil.getSchemaProperty("attribute_pgRelativeDensitySpecificGravityMin");
		public static final String SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYTMIN = "attribute[" + ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITYMIN + "]";
		public static final String ATTRIBUTE_PGKINEMATICVISCOSITYMAX = PropertyUtil.getSchemaProperty("attribute_pgKinematicViscosityMax");
		public static final String SELECT_ATTRIBUTE_PGKINEMATICVISCOSITYMAX = "attribute[" + ATTRIBUTE_PGKINEMATICVISCOSITYMAX + "]";
		public static final String ATTRIBUTE_PGKINEMATICVISCOSITYMIN = PropertyUtil.getSchemaProperty("attribute_pgKinematicViscosityMin");
		public static final String SELECT_ATTRIBUTE_PGKINEMATICVISCOSITYMIN = "attribute[" + ATTRIBUTE_PGKINEMATICVISCOSITYMIN + "]";
		public static final String RELATIVEDENSITYMAX="relativedensitymax";
		public static final String RELATIVEDENSITYMIN="relativedensitymin";
		public static final String DYNAMICVISCOSITYMAX="dynamicViscositymax";
		public static final String DYNAMICVISCOSITYMIN="dynamicViscositymin";
		//Added By Ajay for the Req 14570 : END
		//Added By Ajay for the Defect 19156 : START
		public static final String ZERO_SIZE_C = "0 C";
		public static final String DOT_ZERO_C = ".0 C";
		public static final String SPACE_C = " cP";//Modified by Ajay for Defect. no. 133689
		public static final String USERNAMEREADONLY = "username";
		public static final String READONLYENVIRONMENT = "FF-RO";
		public static final String DOT_ZERO =".0";
		//Added By Ajay for the Defect 19156 : END
		//Added By Ajay for the Req 15195 : START
		public static final String ATTRIBUTE_PGTYPENUMBER = PropertyUtil.getSchemaProperty("attribute_pgTypeNumber");
		public static final String SELECT_ATTRIBUTE_PGTYPENUMBER = "attribute[" + ATTRIBUTE_PGTYPENUMBER + "]";
		public static final String TYPENUMBER="typeNumber";
		//Added By Ajay for the Req 15195 : END
		//Added By Ajay for the Defect 21654 : START
		public static final String ATTRIBUTE_PLIPRODUCTTECHNOLOGYCHASSIS = PropertyUtil.getSchemaProperty("attribute_pgProductTechnologyChassis");
		public static final String SELECT_ATTRIBUTE_PTC = "attribute[" + ATTRIBUTE_PLIPRODUCTTECHNOLOGYCHASSIS + "]";
		//Added By Ajay for the Defect 21654 : END
		//SPEC: Added by Ajay for Req. no. 21482 START
		public static final String RELEASEOBJECT="releaseObject";
		public static final String OBSOLETEOBJECT="obsoleteObject";
		public static final String COMPARE = "compare";
		//SPEC: Added by Ajay for Req. no. 21482 END
		//Added by Ajay for Req 21324 -- START
		public static final String DISTRIBUTIONS ="distributions";
		public static final String STR_FORMAT_FILE_PATH = "format.file.locationfile[pgCincinnatiStoreLoc]";
		public static final String ATTRIBUTE_NOTES = PropertyUtil.getSchemaProperty("attribute_Notes");
		public static final String SELECT_ATTRIBUTE_NOTES = "attribute[" + ATTRIBUTE_NOTES + "]";
		public static final String RELATIONSHIP_DISTRIBUTIONFILE= PropertyUtil.getSchemaProperty("relationship_DistributionFile");
		//Added by Ajay for Req 21324 -- END
		public static final String SUBTYPE_WITH_MCP ="with MCP";//SPEC: Modified by Ajay for Req. no. 30224
		//Modified by Ajay for Req no 36979 - START
		public static final String ATTRIBUTE_ANIMALDERIVED = PropertyUtil.getSchemaProperty("attribute_pgIsAnimalDerived");
		public static final String SELECT_ATTRIBUTE_ANIMALDERIVED = "attribute["+ ATTRIBUTE_ANIMALDERIVED + "]";
		//Modified by Ajay for Req no 36979 - END

		//SPEC: Added by Ajay for Req. no. 30355 - START
		public static final String ATTRIBUTE_FILECONTENTID = PropertyUtil.getSchemaProperty("attribute_pgFileContentID");
		public static final String SELECT_ATTRIBUTE_FILECONTENTID = "attribute[" + ATTRIBUTE_FILECONTENTID + "]";
		public static final String FILECONTENTID="fileContentId"; 
		//SPEC: Added by Ajay for Req. no. 30355 - END
		
		//SPEC: <21.02.2023>: Subhajit Added for Defect 51896 -- START
		public static final int FIRST_LVL = 1;
		public static final int SECOND_LVL = 2;
		public static final int THIRD_LVL = 3;
		//SPEC: <21.02.2023>: Subhajit Added for Defect 51896 -- END
		
		//SPEC: <21.02.2023>: Satyam Added for Defect 51895 -- START
		public static final String FIRST_LEVEL = "1";
		public static final String SECOND_LEVEL = "2";
		public static final String THIRD_LEVEL = "3";
		public static final String CONST_COMPLEX_CUP_STRCTURE ="ComplexCUPStructure";
		public static final String CONST_COMPLEX_IP_STRCTURE ="ComplexIPStructure";
		public static final String CONST_COP_QTY ="COPQty";
		public static final String CONST_OBJECTLIST ="objectList";
		//SPEC: <21.02.2023>: Satyam Added for Defect 51895 -- END
		
		
		//GPSAssessments Data
		//SPEC: Added for Dev 18x.6 Release by Jwala -- START
		public static final String GPSASSESSMENTREQCATEGORY="gpsAssessmentRequestCategory";
		public static final String TASKDECRIPTION="taskDescription";
		public static final String GPSSUMMARY= "gpsSummary";
		public static final String GPSASSTASKSTATE= "gpsAssessmentTaskState";
		public static final String BUSINESSAREAFROMPART= "businessAreaFromPart";
		public static final String PRODUCTCATEPLATFORMFRMPART= "productCategoryPlatformFromPart";
		public static final String GPSPRODUCTTYPE= "gpsProductType";
		public static final String GPSTASKNAME = "taskName";
		public static final String ATTRIBUTE_GPSSTATUS = PropertyUtil.getSchemaProperty("attribute_pgGPSStatus");
		public static final String SELECT_ATTRIBUTE_GPSSTATUS = "attribute[" + ATTRIBUTE_GPSSTATUS + "]";
		public static final String ATTRIBUTE_ORIGINALTASKNAME = PropertyUtil.getSchemaProperty("attribute_pgOriginalTaskName");
		public static final String SELECT_ATTRIBUTE_ORIGINALTASKNAME = "attribute[" + ATTRIBUTE_ORIGINALTASKNAME + "]";
		public static final String ATTRIBUTE_PGNRQID = PropertyUtil.getSchemaProperty("attribute_pgNRQID");
		public static final String SELECT_ATTRIBUTE_PGNRQID = "attribute[" + ATTRIBUTE_PGNRQID + "]";
		public static final String ATTRIBUTE_GPSASSESSMENTCATEGORY = PropertyUtil.getSchemaProperty("attribute_pgGPSAssessmentCategory");
		public static final String SELECT_ATTRIBUTE_GPSASSESSMENTCATEGORY = "attribute[" + ATTRIBUTE_GPSASSESSMENTCATEGORY + "]";
		public static final String REL_GPSASSESSMENTTASK_INPUTS= PropertyUtil.getSchemaProperty("relationship_pgGPSAssessmentTaskInputs");
		public static final String REL_GPSTOPRODUCTTYPE= PropertyUtil.getSchemaProperty("relationship_pgGPSToGPSProductType");

		public static final String INGREDIENTSTATEMENT = "ingredientstatement";
		public static final String NRQ = "NRQ#";
		public static final String GPSSOURCEINGREDIENTLIST="gpssourceingredientlist";
		public static final String GPSSOURCEINGREDIENTLISTSTATE = "gpssourceingredientstate";
		public static final String GPSSOURCEINGREDIENTLISTTYPE="gpssourceingredientlisttype";
		public static final String GPSSOURCEINGREDIENTLISTID="gpssourceingredientlistid";
		public static final String GPSINGREDIENTSTMTNAME= "gpsingredientstatementname";

		public static final String REL_INGREDIENTSTMT= PropertyUtil.getSchemaProperty("relationship_pgIngredientStatement");
		
		public static final String INGREDIENTSTMT_COPYLIST_COUNTRY ="from[Copy List Country].to.name";
		public static final String ATTRIBUTE_GPSASSESSMENTSTATEMENT = PropertyUtil.getSchemaProperty("attribute_pgGPSIngredientStatement");
		public static final String SELECT_ATTRIBUTE_GPSASSESSMENTSTATEMENT = "attribute[" + ATTRIBUTE_GPSASSESSMENTSTATEMENT + "]";

		public static final String INGREDIENTS ="ingredients";
		public static final String AICN ="aicn";
		public static final String ADJUSTEDTARGET="adjustedtarget";
		public static final String COMMONNAME="commonname";

		public static final String REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXT="from[Artwork Assembly].to.attribute[Copy Text]";
		public static final String REL_CLARTWORKMASTER_ATTRIBUTE_PGAICN="from[Artwork Assembly].to.to[Artwork Element Content].from.attribute[pgAICN].value";
		public static final String REL_CLARTWORKMASTER_ATTRIBUTE_PGADJTARGET="from[Artwork Assembly].to.to[Artwork Element Content].from.attribute[pgAdjTarget].value";
		public static final String REL_CLARTWORKMASTER_ATTRIBUTE_COMMONNAME="from[Artwork Assembly].to.to[Artwork Element Content].from.attribute[Common Name]";
		//SPEC: Added for Dev 18x.6 Release by Jwala -- END
		//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- START
		public static final String ISGENDOC = "isGendoc";
		//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- END
		//SPEC: Added by Ajay for Req. no. 36986 - START
		public static final String ATTRIBUTE_COMPONENT_LOCATION = PropertyUtil.getSchemaProperty("attribute_ComponentLocation]");
		public static final String SELECT_ATTRIBUTE_COMPONENT_LOCATION="attribute[" + ATTRIBUTE_COMPONENT_LOCATION  + "]";
		public static final String COMPONENTLOCATION="componentLocation";
		//SPEC: Added by Ajay for Req. no. 36986 - END
		//SPEC: Modified by Ajay for Req. no. 41685 - START
		public static final String PMP_COMPARE ="pmpComp";
		public static final String RMP_COMPARE ="rmpComp";
		public static final String E119 ="E119";
		public static final String ERROR_CSSPART ="Comparison not possible as previous revision is a non-DSM object";
		//SPEC: Modified by Ajay for Req. no. 41685 - END
		//SPEC: Added by Ajay for Req. no. 23961 START
		public static final String PAP_COMPARE ="papComp";
		//SPEC: Added by Ajay for Req. no. 23961 END
		public static final String MEP_OWNERSHIP ="from[Manufacturer Equivalent].to.ownership";
		public static final String SEP_OWNERSHIP ="from[Supplier Equivalent].to.ownership";
		//SPEC: Modified by Ajay for Req. no. 78405 START
		public static final String FPP_COMPARE ="fppComp";
		//SPEC: Modified by Ajay for Req. no. 78405 END
		//SPEC: Modified by Ajay for Req. no. 30189 START
		public static final String CTA = "CTA";
		public static final String EXTENDED_ATTRIBUTE = "extendedAttribute";
		//SPEC: Modified by Ajay for Req. no. 30189 END
		//SPEC: Added by Ajay for Req. no. 23960 - START
		public static final String FAB_COMPARE ="fabComp";
		//SPEC: Added by Ajay for Req. no. 23960 - END
		//SPEC: Modified by Subhajit for Req. no. 30189 - START
		public static final String PAGE ="emxFrameworkStringResource";
		public static final String EN ="en";
		public static final String PREFIX ="E-";
		public static final String SUFFIX =".1";
		public static final String TEMPLATE_PROPERTY_KEY = "emxFramework.Template.";
		public static final String ATTRIBUTE_PROPERTY_KEY = "emxFramework.Attribute.";
		public static final String RANGE_KEY = ".Range.";
		public static final String ATTRIBUTE = "attribute";
		public static final String MQL_SELECT_CONTENT = "content";
		public static final String EXTENSION_PROPERTIES = ".properties";
		//SPEC: Modified by Subhajit for Req. no. 30189 - END
		public static final String ATTRIBUTETYPE_TIMESTAMP = "timestamp";
		//Added by Ajay for Req. 78583 -- START
		public static final String CONST_EXTENDED_ATTRIBUTE = "Extended Attributes";
		public static final String STR_EXTENDED_ATTRIBUTE = "extendedAttributes";
		//Added by Ajay for Req. 78583 -- END
		public static final String SYMB_DOUBLE_EQUAL = "==";//SPEC: Added by Ajay for Defect No. 82686
		//SPEC: Added by Ajay for Req. no. 23970 START
		public static final String TCOMMONDOC = "commonDoc";
		public static final String TCOMMONDOC_COMP = "commonDocComp";
		public static final String TIRM = "pgPKGStudyProtocol";
		//SPEC: Added by Ajay for Req. no. 23970 END
		public static final String SAP_TIMEOUT = "SAP Timeout";
		public static final String GTITEM = "Item";
		//SPEC: Added by Ajay for Req. no. 89008 START
		public static final String ATTRIBUTE_ASSESSMENTBASIS = PropertyUtil.getSchemaProperty("attribute_pgAssessmentBasis]");
		public static final String SELECT_ATTRIBUTE_ASSESSMENTBASIS_LOCATION ="attribute[" + ATTRIBUTE_ASSESSMENTBASIS  + "]";
		public static final String STR_ASSESSMENTBASIS="assessmentBasis";
		public static final String ATTRIBUTE_ASSESSMENTLEVEL = PropertyUtil.getSchemaProperty("attribute_pgAssessmentLevel]");
		public static final String SELECT_ATTRIBUTE_ASSESSMENTLEVEL="attribute[" + ATTRIBUTE_ASSESSMENTLEVEL  + "]";
		public static final String STR_ATTRIBUTE_ASSESSMENTLEVEL="assessmentLevel";
		//SPEC: Added by Ajay for Req. no. 89008 END
		//SPEC: Added by Ajay for Req. no. 86912 START
		public static final String PGMARKET = "market";
		public static final String PGLPN = "localProductName";
		public static final String BACK_SLASH_PIPE = "\\|$";
		public static final String ISLATESTVERSION = "isLatestRevision";
		//SPEC: Added by Ajay for Req. no. 86912 END
		//Added by Ajay for Req No. 86913 -- START
		public static final String ATTRIBUTE_IRMMATERIALCERTIFICATION = PropertyUtil.getSchemaProperty("attribute_pgIRMMaterialCertification]");
		public static final String SELECT_ATTRIBUTE_IRMMATERIALCERTIFICATION = "attribute[" + ATTRIBUTE_IRMMATERIALCERTIFICATION  + "]";
		public static final String STR_MATERIALCERTIFICATION = "materialCertification";
		//Added by Ajay for Req No. 86913 -- END

		//Added by Ajay for Req No. 23964 -- START
		public static final String ARMP_COMPARE = "armpComp";
		public static final String TP_ARMP = "Ancillary Raw Material Part";
		//Added by Ajay for Req No. 23964 -- END
		//Added by Ajay for Req No. 23975 -- START
		public static final String PIP_COMPARE = "pipComp";
		//Added by Ajay for Req No. 23975 -- END
		//Added by Ajay for Req No. 23973 -- START
		public static final String APMP_COMPARE = "apmpComp";
		//Added by Ajay for Req No. 23973 -- END
		//Added by Ajay for Req No. 23973 -- START
		public static final String SWP_COMPARE = "swpComp";
		//Added by Ajay for Req No. 23973 -- END

		
		public static final String TYPE_PGLPNDATA=PropertyUtil.getSchemaProperty("type_pgLPNData");
		public static final String RELATIONSHIP_PGLPNDATA = PropertyUtil.getSchemaProperty("relationship_pgLPNData");
		
		public static final String ATTRIBUTE_PGLANGUAGE = PropertyUtil.getSchemaProperty("attribute_pgLanguage]");
		public static final String SELECT_ATTRIBUTE_PGLANGUAGE ="attribute[" + ATTRIBUTE_PGLANGUAGE  + "]";
		
		public static final String ATTRIBUTE_PGLPNDATA = PropertyUtil.getSchemaProperty("attribute_pgLPNData]");
		public static final String SELECT_ATTRIBUTE_PGLPNDATA ="attribute[" + ATTRIBUTE_PGLPNDATA  + "]";
		
		public static final String ATTRIBUTE_PGCOUNTRY = PropertyUtil.getSchemaProperty("attribute_pgCountry]");
		public static final String SELECT_ATTRIBUTE_PGCOUNTRY ="attribute[" + ATTRIBUTE_PGCOUNTRY  + "]";

		
		//Added by Ajay for Req No. 23966 -- START
		public static final String OPP_COMPARE = "oppComp";
		//Added by Ajay for Req No. 23966 -- END
		//Added by Ajay for Req. no. 96082 - START
		public static final String ATTRIBUTE_PGDERIVED = PropertyUtil.getSchemaProperty("attribute_pgDerived]");
		public static final String SELECT_ATTRIBUTE_PGDERIVED ="attribute[" + ATTRIBUTE_PGDERIVED  + "]";
		public static final String PG_DERIVED = "derived";
		//Added by Ajay for Req. no. 96082 - END
		
		//Added by Ajay for Req. no. 99576 - START
		public static final String ATTRIBUTE_PGCOMPENDIALREFERENCEPHARMACOPEIA = PropertyUtil.getSchemaProperty("attribute_pgCompendialReferencePharmacopeia]");
		public static final String SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEPHARMACOPEIA = "attribute[" + ATTRIBUTE_PGCOMPENDIALREFERENCEPHARMACOPEIA  + "]";
		public static final String PG_COMPENDIALREFERENCEPHARMACOPEIA = "compendialReferencePharmacopeia";
		
		public static final String ATTRIBUTE_PGQUALITYSTANDARDSMATERIALGRADE = PropertyUtil.getSchemaProperty("attribute_pgQualityStandardsMaterialGrade]");
		public static final String SELECT_ATTRIBUTE_PGQUALITYSTANDARDSMATERIALGRADE = "attribute[" + ATTRIBUTE_PGQUALITYSTANDARDSMATERIALGRADE  + "]";
		public static final String PG_QUALITYSTANDARDSMATERIALGRADE = "qualityStandardsMaterialGrade";
		
		public static final String ATTRIBUTE_PGCOMPENDIALREFERENCEFREETEXT = PropertyUtil.getSchemaProperty("attribute_pgCompendialReferenceFreeText]");
		public static final String SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEFREETEXT = "attribute[" + ATTRIBUTE_PGCOMPENDIALREFERENCEFREETEXT  + "]";
		public static final String PG_COMPENDIALREFERENCEFREETEXT = "compendialReferenceFreeText";
		
		public static final String ATTRIBUTE_PGQUALITYSTANDARDSFREETEXT = PropertyUtil.getSchemaProperty("attribute_pgQualityStandardsFreeText]");
		public static final String SELECT_ATTRIBUTE_PGQUALITYSTANDARDSFREETEXT = "attribute[" + ATTRIBUTE_PGQUALITYSTANDARDSFREETEXT  + "]";
		public static final String PG_QUALITYSTANDARDSFREETEXT = "QualityStandardsFreeText";
		
		public static final String OTHER = "Other";
		//Added by Ajay for Req. no. 99576 - END
		
		public static final String FILEERRORMESSAGE = "Waiting for file sync to complete from Enovia";
		public static final String MATERIAL_COMPOSITION_PART = "Material Composition Part";
		public static final String PG_MASTER_INNER_PACK = "Master Inner Pack";
		public static final String PG_PIECE_OF_ART = "Piece of Art";
		public static final String PG_PACKING_SUBASSEMBLY = "Packing Subassembly Part";
		public static final String PG_APMP = "Ancillary Packaging Material Part";
		public static final String PG_DPP = "Device Product Part";
		public static final String PG_FAB = "Fabricated Part";
		public static final String PG_IPP = "Intermediate Product Part";
		public static final String PG_MCOP = "Master Consumer Unit Part";
		public static final String PG_MPAP = "Master Packaging Assembly Part";
		public static final String PG_MRMP = "Master Raw Material Part";
		public static final String PG_OPP = "Online Printing Part";
		public static final String PG_SWP = "Software Part";
		public static final String PG_MPP = "Master Product Part";
		public static final String PG_MPMP = "Master Packaging Material Part";
		
		public static final String CALLEDFROM = "calledFrom";
		public static final String CURLYBRACES = "{}";
		public static final String PGPKGPRODUCTREADINESS = "pgPKGProductReadiness";
		public static final String CUP_COMPARE = "cupComp";
		public static final String COP_COMPARE = "copComp";
		public static final String STATE_PRILIMNARY = "Preliminary";
		public static final String PG_COP = "Consumer Unit Part";
		public static final String CURRENT_ST_PRELIMINARY = "current==Preliminary";
		public static final String PG_CUP = "Customer Unit Part";
		public static final String CURRENT_RELEASE_LAST = "current==Release && revision == last";
		
		public static final String tASL = "ASL";
		public static final String tBSF = "Base Formala";
		public static final String tMCUP = "Master Customer Unit Part";
		public static final String tSTD = "Study Protocol";
		public static final String tFC = "FC";
		public static final String tSIS = "SIS";
		
		public static final String INNOVATION_RECORD = "Innovation Record";
	    public static final String CONSUMER_RESEARCH = "Consumer Research";
	    public static final String STABILITY_REPORT = "Stability Report";
	    public static final String GENERAL_INNOVATION_RECORD = "General Innovation Record";
	    public static final String VALIDATION_PROTOCOL = "Validation Protocol";
	    public static final String CORE_INNOVATION_RECORD = "Core Innovation Record";
	    public static final String STABILITY_OUT_OF_SPEC_REPORT = "Stability Out of Spec Report";
	    public static final String VALIDATION_REPORT = "Validation Report";
	    public static final String STABILITY_OTHER = "Stability Other";
	    public static final String VALIDATION_OTHER = "Validation Other";
	    public static final String TRANSLATION_FILE = "Translation File";
	    public static final String STABILITY_PROTOCOL = "Stability Protocol";
	    public static final String TECHNICAL_RATIONALE = "Technical Rationale";
	    public static final String PACKAGING_MINIMIZATION_REPORT = "Packaging Minimization Report";
	    public static final String IRM = "IRM";
	    public static final String ASL = "Approved Supplier List";
	    public static final String BSF = "Base Formula";
	    public static final String FC = "Formula Card";
	    public static final String MPS = "Master Finished Product";
	    public static final String tPSUB = "Packing Subassembly Part";
	    public static final String SIS = "Supplier Information Sheet";
	    public static final String E120 ="E120";
	    public static final String ERROR_CSSTYPES ="The CSS objects do not  have the Premilinary data";
	    public static final String E121 ="E121";
	    public static final String ERROR_PART_REPORT ="You donot have access to view the page requested";
	    public static final String GENDOCHIDE ="gendochide";
	public static final String CURRENT_PRELIMINARY = "current==Preliminary";
		public static final String CURRENT_RELEASE_LASTID = "last[Release].id";
		public static final String CURRENT_RELEASE_LASTSTATE = "last[Release].current";


		//SPEC:04/20/2026 - Added for the req 125095 - START
		public static final String SHELFLIFEDAYS = "shelflifedays";
		public static final String ATTRIBUTE_PGSHELFLIFEDAYS = PropertyUtil.getSchemaProperty("attribute_pgShelfLifeDays");
		public static final String SELECT_ATTRIBUTE_PGSHELFLIFEDAYS = "attribute[" + ATTRIBUTE_PGSHELFLIFEDAYS + "]";
		//SPEC:04/20/2026 - Added for the req 125095 - START
		public static final String PRELIMINARY_CM ="preliminary CM";
	    public static final String PRELIMINARY_SP ="preliminary SP";
	    //Added for the req 127913 - START
	    public static final String ATTRIBUTE_PGDSGCASNAME = PropertyUtil.getSchemaProperty("attribute_pgDSGCASName");
		public static final String SELECT_ATTRIBUTE_PGDSGCASNAME = "attribute[" + ATTRIBUTE_PGDSGCASNAME + "]";
		public static final String STR_GCAS="gcas";
		public static final String ATTRIBUTE_PGDSIRMDOCOWNER = PropertyUtil.getSchemaProperty("attribute_pgDSIRMDocOwner");
		public static final String SELECT_ATTRIBUTE_PGDSIRMDOCOWNER = "attribute[" + ATTRIBUTE_PGDSIRMDOCOWNER + "]";
		public static final String STR_DSIRMDOCOWNER ="owner";
		//Added for the req 127913 - END
}

