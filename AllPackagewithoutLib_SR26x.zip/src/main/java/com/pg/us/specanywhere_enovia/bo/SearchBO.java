/**
 * Project 		: SpecsAnywhere
 * Program 		: SearchBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;

public class SearchBO {

	
		private String id;
		private String name;
		private String revision;
		private String type;
		private String description;
		private String maturityState;
		private String lastModification;
		private String creationDate;
		private String mappedType;
		
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getRevision() {
			return revision;
		}
		public void setRevision(String revision) {
			this.revision = revision;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getMaturityState() {
			return maturityState;
		}
		public void setMaturityState(String maturityState) {
			this.maturityState = maturityState;
		}
		public String getLastModification() {
			return lastModification;
		}
		public void setLastModification(String lastModification) {
			this.lastModification = lastModification;
		}
		public String getCreationDate() {
			return creationDate;
		}
		public void setCreationDate(String creationDate) {
			this.creationDate = creationDate;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		
		public String getMappedType() {
			return mappedType;
		}
		
		public String setMappedType(String mappedType) {
			mappedType = util.mapType(mappedType);
			return mappedType;
		}
		
		@Override
		public String toString() {
			return "SearchData [name=" + name + ", revision=" + revision + ", type=" + type + ", description=" + description
					+ ", maturityState=" + maturityState + ", lastModification=" + lastModification + ", creationDate="
					+ creationDate + "]";
		}
		
		
	}
