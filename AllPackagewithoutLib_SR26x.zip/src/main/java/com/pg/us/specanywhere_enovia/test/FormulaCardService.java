/*package com.pg.us.specanywhere_enovia.test;



	

	import java.io.IOException;
	import java.util.HashMap;
	import java.util.Map;

	import org.apache.commons.lang3.time.StopWatch;
	import org.apache.log4j.Logger;
	import org.springframework.core.env.Environment;

	import com.matrixone.apps.domain.DomainObject;
	import com.matrixone.apps.domain.util.MapList;
	import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
	import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
	import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
	import com.pg.us.specanywhere_enovia.bo.FormulaCardBO;
	import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
	import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
	import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
	import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
	import com.pg.us.specanywhere_enovia.security.SecurityService;
	import com.pg.us.specanywhere_enovia.service.EnoviaFormulaCardService;
	import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
	import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
	import com.pg.us.specanywhere_enovia.utility.EncryptCrypto;
	import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

	import matrix.db.Context;
	import matrix.db.JPO;
	import matrix.util.MatrixException;
	import matrix.util.StringList;

		public class FormulaCardService  {

		
		private static String USER;
		private static String PASS;
		private static String VAULT;
		private static String SECURITY;
		private static Logger LOGGER = Logger.getLogger(FormulaCardService.class);

		public static void main(String[] args) throws Exception
		{
			HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
			
			String objId ="20336.41905.32771.52568";
			StopWatch sp = new StopWatch();
			sp.start();
			try
			{
				
			    Context context = pool.checkOut();
			    
				BusObjectAttribUtil util = new BusObjectAttribUtil();
				StringValidatorUtil validator = new StringValidatorUtil();
				
				Map<String,String> mpHeaderResult = new HashMap<String,String>();
				Map<String,String> mpAttribResult = new HashMap<String,String>();
				Map<String,String> mpOrganization = new HashMap<String,String>();
				Map<String,String> mpHasATS = new HashMap<String,String>();
				Map<String,String> mpIsATS = new HashMap<String,String>();
				Map<String,String> mpTechnicalSupersedes = new HashMap<String,String>();
				Map<String,String> mpTechnicalSupersedesBy = new HashMap<String,String>();
				Map<String,String> mpMaterialProduced  = new HashMap<String,String>();
				Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
				Map<String,String> mpEBOMResult = new HashMap<String,String>();
				Map<String,String> mpSubstitute = new HashMap<String,String>();
				Map<String,String> mpPerformChar= new HashMap<String,String>();
				Map<String,String> mpSecurity = new HashMap<String,String>();
				Map<String,String> mpIPClass = new HashMap<String, String>();
				
				
				FormulaCardBO fcBO = new FormulaCardBO();
				StringList slContextSelects = fcBO.getFormulaCardSelects(context);
				DomainObject doFC=fcBO.getFormulaCardDO(context, objId);
				fcBO.addMultiList();
				StopWatch swAttributes = new StopWatch();
				swAttributes.start();
				Map resultMaps = doFC.getInfo(context, slContextSelects);
				swAttributes.stop();
				LOGGER.info("Formula Card GETINFO ELAPSED TIME : "+swAttributes.getTime());
				fcBO.removeMultiList();
				
				
				Map BusinessObjectRelSelectableMap = fcBO.getBOMSelects(context);
				StringList slEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.BUS_SELECTS);
				StringList slRelEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.REL_SELECTS);
				
				
				//Common usage Variables
				String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				
				
				*//**
				 *Attribute Section
				 *//*
				
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DOESTHEPRODUCTCONTAINBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STR_TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				
				mpAttribResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				
				mpAttribResult.put(ConstantsUtil.PGASLALLOCATION, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				
				
				String sClassifictaion = util.getClassification(resultMaps);
				mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));
				
				String sHasATS = "";
				String sIsATS = "";
				
				
				String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ATL_STATE));
				String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ATL_NAME));
				sHasATS =util.checkIsATSAttribute(sName,sCurrent);
				
				
				String sATSCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.REL_ATS_STATE));
				String sATSName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.REL_ATS_NAME));
				sIsATS =util.checkIsATSAttribute(sATSName,sATSCurrent);
				
				
				
				*//**
				 * Has ATS
				 *//*
				mpHasATS = util.checkHasATS(context,resultMaps);
				
				*//**
				 * Is ATS
				 *//*
				mpIsATS = util.checkIsATS(context,resultMaps);
				
				
				*//**
				 * Technical Supersedes 
				 *//*
				
				mpTechnicalSupersedes=util.getTechnicalSupersedes(context, resultMaps);
				

				*//**
				 * Technical SupersedesBy 
				 *//*
				
				mpTechnicalSupersedesBy=util.getTechnicalSupersedesBy(context, resultMaps);
				
				*//**
				 * Materials Produced By this Formulation
				 *//*
				
				//SPEC: Jwala Modified for Defect 43146 Release 18x.6.0.1 -- START
				//mpMaterialProduced=util.getMaterialsProceeded(context, resultMaps);
				mpMaterialProduced=util.getMaterialsProceeded(context, sContextObjectId);
				//SPEC: Jwala Modified for Defect 43146 Release 18x.6.0.1 -- END

				
				*//**
				 * LOAD ORGANIZATION DATA SECTION
				 * *//*
				StopWatch swOrganization = new StopWatch();
				swOrganization.start();
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = util.filterMapList(mpOrganization);
				swOrganization.stop();
				LOGGER.info("Formula Card Organization ELAPSED TIME : "+swOrganization.getTime());
				
				*//**
				 * 
				 * LOAD SAP BOM as FED SECTION
				 *
				 * *//*
				StopWatch swSapBomAsFed = new StopWatch();
				swSapBomAsFed.start();
				CalculateBOM clBom = new CalculateBOM();
	            mpSapBomAsFedcResult = clBom.getSapBOMasFed(context,sContextObjectId);
				
				
	            
				*//**
				 * LOAD Main BOM SECTION
				 * *//*
				StopWatch swBom = new StopWatch();
				swBom.start();
				MapList mlEBOMList = doFC.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
						ConstantsUtil.QUERY_WILDCARD, slEBOMSelects, slRelEBOMSelects, false, true, (short) 1,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
				
				
				 mpEBOMResult =fcBO.parseBOMMaplist(context,mlEBOMList);
				 mpSubstitute =fcBO.parseSubstituteMaplist(context,mlEBOMList);
				
				LOGGER.info("Formula card BOM  ELAPSED TIME : "+swBom.getTime());

				*//**
				 * LOAD PERFORMANCE CHAR SECTION
				 * *//*
				Map paramMap = new HashMap();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				PerformanceCharcteristics perform = new PerformanceCharcteristics();
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
					FinishedProductPartBO fppBO = new FinishedProductPartBO();
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					//mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
				swPerfChar.stop();
				LOGGER.info("Formula Card  PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
				
				
				
				
				 Map mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
				 
				 
				 	*//**
					 * LOAD REFERENCE DOCS SECTION
					 * *//*
					StopWatch swReference= new StopWatch();
					swReference.start();
					Map mapReferenceDocs =  fcBO.updateRefDocs(context, resultMaps);
					swReference.stop();
					LOGGER.info("Formula Card  Reference ELAPSED TIME : "+swReference.getTime());

				 
					*//**
					 * LOAD COUNTRY CLEARANCE SECTION
					 * *//*
					
					Map mapCountryClearanceResult = new HashMap();
					mapCountryClearanceResult.put(ConstantsUtil.COUNTRY_NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(  ConstantsUtil.STR_COUNTRY_NAME)))?(String)resultMaps.get(  ConstantsUtil.STR_COUNTRY_NAME) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_CT_NUM)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_CT_NUM) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.PSRAAPPROVALSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.MANU_SITE, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_MANU_SITE)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_MANU_SITE) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.PACK_SITE, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PACK_SITE)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PACK_SITE) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.CLEAR_COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.PLANT_REST, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PLANT_REST)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PLANT_REST) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_REG_DATE)))?validator.DateFormatter((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_REG_DATE)) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_REG_STATUS)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_REG_STATUS) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.COUNTRY_PROD_NUM, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PROD_REG_NUM)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PROD_REG_NUM) : ConstantsUtil.EMPTY_STRING);
					mapCountryClearanceResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS)))?(String)resultMaps.get( ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS) : ConstantsUtil.EMPTY_STRING);
					//mapCountryClearanceResult = util.filterMapList(mapCountryClearanceResult);
					
					Map mapOwnerShipResult =new HashMap();
					//Ownership
					StopWatch swOwnerShip = new StopWatch();
					swOwnerShip.start();
					mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.OWNINGSTANDARDOFFICE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.APPROVERS,"");//(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
					String sEDList =RawMaterialPartBO.getEDList(resultMaps);
					mapOwnerShipResult.put(ConstantsUtil.EDL, sEDList);
					mapOwnerShipResult.put(ConstantsUtil.ODL, util.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST) : ConstantsUtil.EMPTY_STRING));
					//mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
					swOwnerShip.stop();
					LOGGER.info("ASL  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());

					*//**
					 * LOAD HEADER SECTION
					 * *//*
					
					
					
					mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
					mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
					mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
					mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?util.mapType((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);		
					mpHeaderResult.put(ConstantsUtil.HASATS, sHasATS);
					mpHeaderResult.put(ConstantsUtil.HASATS, sIsATS);
					mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
					mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
					mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
					mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
					String sClassification = util.getClassification(resultMaps);
					mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
					
					
					*//**
					 * LOAD PLANTS SECTION
					 * *//*
					
					
					Map	mapPlantResult = util.updatePlantInfo(resultMaps);
					
					

					*//**
					 * LOAD SECURITY SECTION
					 * *//*
					StopWatch swSecurity = new StopWatch();
					CommonBusUtilBO bo = new CommonBusUtilBO();
					swSecurity.start();
					mpSecurity =bo.updateSecurity(context,resultMaps);
					swSecurity.stop();
					LOGGER.info("FPP  Security ELAPSED TIME : "+swSecurity.getTime());
					
					
					*//**
					 * IP Security Classes
					 *//*
					CommonBusUtilBO commonBo = new CommonBusUtilBO();
					StringList slIpSelects = new StringList();
					slIpSelects.add(ConstantsUtil.SELECT_NAME);
					slIpSelects.add(ConstantsUtil.SELECT_ID);
					slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
					slIpSelects.add(ConstantsUtil.SELECT_TYPE);
					slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
					mpIPClass =commonBo.getIpClass(context, doFC, slIpSelects);
					
				

				pool.checkIn(context);

				hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
				hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
				hmAttrib.put(ConstantsUtil.HASATS, mpHasATS);
				hmAttrib.put(ConstantsUtil.ISATS, mpIsATS);
				hmAttrib.put(ConstantsUtil.TECHSUPERSEDES, mpTechnicalSupersedes);
				hmAttrib.put(ConstantsUtil.TECHSUPERSEDESBY, mpTechnicalSupersedesBy);
				hmAttrib.put(ConstantsUtil.MATERIALS, mpMaterialProduced);
				hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
				hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
				hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC,mpPerformChar);
				hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
				hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
				hmAttrib.put(ConstantsUtil.COUNTRYCLEARENCE, mapCountryClearanceResult);
				hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
				hmAttrib.put(ConstantsUtil.PLANTS, mapPlantResult);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.IPSECURITY, mpIPClass);
				
				
				sp.stop();
				LOGGER.info("Formula Card Execution TIME::" + sp.getTime() +"  " + "Formula Card  OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));

			} catch (IOException e) {
				LOGGER.error("Unable to get Formula Card details "+e);
			} catch (MatrixException e) {
				LOGGER.error("Unable to get Formula Card details "+e);
			}
			LOGGER.info("Formula Card RESPONSE MESSAGE:: \n" + hmAttrib);
			
		}
				
	}

*/