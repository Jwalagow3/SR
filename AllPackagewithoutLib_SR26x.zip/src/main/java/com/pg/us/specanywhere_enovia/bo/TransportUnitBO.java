/**
 * Project 		: SpecsAnywhere
 * Program 		: TransportUnitBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class TransportUnitBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(TransportUnitBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	public TransportUnitBO() {
		// empty constructor
	}

	public TransportUnitBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getTupBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getTupBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getTupDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public DomainObject getTupDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getTUPSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getTUPSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getOrganizationSelectable(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getFileSelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	//SPEC: 11/24/2020: Added for Deefct 37543 -- Start
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	//SPEC: 11/24/2020: Added for Deefct 37543 -- END

	/**
	 * Method Name 			: getTupRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getTupRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}
	
	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}

	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		
		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
		//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - END
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- END
		return busSelect;
	}

	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		//Added by Ketan for Req. no. 46464 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC);
		//Added by Ketan for Req. no. 46464 -- END

		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
	
		//Added for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
		
		return relSelect;
	}
	
	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERHANGMAXLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERHANGMAXWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNDERHANGMAXLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PPGUNDERHANGMAXWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFECIENCY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAREAEFFECIENCY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSELOGISTICS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ID);

		busSelect.add(ConstantsUtil.STACK_PATTEREN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);


		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_STR_SEGMENT);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);

		busSelect.add(ConstantsUtil.OWNERSHIP);

		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_OVERHANGACTUALWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_OVERHANGACTUALLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_UNDERHANGACTUALWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_UNDERHANGACTUALLENGTH);
		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_CUBEEFFECIENCY);
		//<12.28.20202> Lingeswari added as reference to defect 37755 ---start
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		//<12.28.20202> Lingeswari added as reference to defect 37755 --end
		// Guna Added for Defect 39163  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASEPHASE);
		// Guna Added for Defect 39163  18x.5.2 Release -- END
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getOrganizationSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getOrganizationSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		return busSelect;
	}



	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context, MapList mapList) {
	
		StringValidatorUtil validator = new StringValidatorUtil();
		
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRD= new StringBuilder();
		StringBuilder sbEBOMOC= new StringBuilder();
		StringBuilder sbEBOMSubstute= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMId= new StringBuilder();
		
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		//SPEC: 10-29-2020 : added for Defect: 18X.5 ## -- END
		
		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlternate = new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDensityUOM = new StringBuilder();
		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
		//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - START
		StringBuilder sbGrossWeightReal = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder();
		//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - END
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			String sType =(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sId =(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String spgChg =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sFN =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				String sTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				sType = util.mapType(sType);
				String sRevision =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sReleaseDate =validator.DateFormatter((String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
				String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
				String sSubstitute=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
				sSubstitute =util.replaceSpecialSymbols(sSubstitute);
				String sQty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				String sBuom = validator.getStringEquivalentForStringList((String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
				String sComments=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				String sCurrent =(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sStage =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				String sRD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

				//StringValidatorUtil validator = new StringValidatorUtil();
				String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));

				sRD =util.replaceSpecialSymbols(sRD);
				sOC =util.replaceSpecialSymbols(sOC);

				
				//SPEC: 10-29-2020 : added for  18X.5 ## -- START
				String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
				//SPEC: 10-29-2020 : added for 18X.5 ## -- END
				
				
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
				//String sAlternate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
				//sAlternate = sAlternate.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
				strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strAltID = util.checkAlternateHasAccess(context,objectMap);	
				String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
				strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
				String sOSPD = validator.getStringEquivalentForStringList((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY));
				String sDensityUOM = validator.getStringEquivalentForStringList((String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM));
				//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - START
				String strGrossWeightReal = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
				String strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
				//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - END
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
				
				SecurityService sec = new SecurityService();
				String sUserlicense = sec.getUserLicense();

				boolean showData = false;

				if(util.isModificatinRequired())
				{
					//commented by Ganesh for security impl----->start
					/*String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);

					boolean bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);*/
					//commented by Ganesh for security impl----->end
					//modified by Ganesh for security impl----->start
					boolean bHasOwnership = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl----->end

					if(!bHasOwnership)
					{
						sTitle = ConstantsUtil.NO_ACCESS;
						spgChg = ConstantsUtil.NO_ACCESS;
						sFN    = ConstantsUtil.NO_ACCESS;
						sStage = ConstantsUtil.NO_ACCESS;
						sRevRelease = ConstantsUtil.NO_ACCESS;
						sSubstitute = ConstantsUtil.NO_ACCESS;
						sComments = ConstantsUtil.NO_ACCESS;
						sRD = ConstantsUtil.NO_ACCESS;
						sOC = ConstantsUtil.NO_ACCESS;
						sId = ConstantsUtil.NO_ACCESS;
						sQty = ConstantsUtil.NO_ACCESS;
						sBuom = ConstantsUtil.NO_ACCESS;
						sCurrent = ConstantsUtil.NO_ACCESS;
						
						//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
						sOSPD = ConstantsUtil.NO_ACCESS;
						sDensityUOM = ConstantsUtil.NO_ACCESS;
						
						// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
						//ssAlternate = ConstantsUtil.NO_ACCESS;
						// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
						//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
					}//commented by Ganesh for security impl------>start
				}else /*if(sec.isStaffAUGUser()) {

					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
					}
				}else {
					StringList slHIRTypes = new StringList();
					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

					if(slHIRTypes.contains(sType)) {
						showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
					}else {
						showData=true;
					}

				}*/
					//commented by Ganesh for security impl------>end
					//modified by Ganesh for security impl------>start
				{
					showData = util.checkHasAccess(context, null, sId);
				}
					//modified by Ganesh for security impl------>end

				if(!showData){
					sId = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
				}

				formatData(sbEBOMName,sName);
				formatData(sbEBOMId,sId);
				formatData(sbEBOMChg,spgChg);
				formatData(sbEBOMFN,sFN);
				formatData(sbEBOMTitle,sTitle);
				formatData(sbEBOMType,sType);
				formatData(sbEBOMRevRelDt,sRevRelease);
				formatData(sbEBOMSubstute,sSubstitute);
				formatData(sbEBOMQTY,sQty);
				formatData(sbEBOMBuom,sBuom);
				formatData(sbEBOMCommnts,sComments);
				formatData(sbEBOMState,sCurrent);
				formatData(sbEBOMStage,sStage);
				formatData(sbEBOMRD,sRD);
				formatData(sbEBOMOC,sOC);
				
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
				formatData(sbEBOMSubstitutePart, strSubPart);
				formatData(sbEBOMSubPartID, strSubPartId);
				formatData(sbEBOMSubPartType, strSubPartType);
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
				
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
				
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
				//formatData(sbEBOMAlternate, sAlternate);
				formatData(sbAltName,strAltName);
				formatData(sbAltID,strAltID);
				formatData(sbAltType,strAltType);
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
				formatData(sbEBOMOSPD, sOSPD);
				formatData(sbEBOMDensityUOM, sDensityUOM);
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
				//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - START
				formatData(sbGrossWeightReal, strGrossWeightReal);
				formatData(sbGrossWeightUOM, strGrossWeightUOM);
				//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - END
				
		}
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRD.toString());
		

		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		
		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlternate.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDensityUOM.toString());
		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
		//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - START
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
		//SPEC: Added for Internal Defect by Ketan on 06.20.2022 - END
		return mpEBOMResult;
	}

	
	/**
	 * Method Name 			: getSubstitute
	 * Method Description 	:
	 * @param mapList
	 * @return
	 */
	public Map<String, String> getSubstitute(MapList mapList) 
	{

		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentRev = new StringBuilder();
		StringBuilder sbEBOMParentTitle = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMRefDoc= new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMSubType= new StringBuilder();
		StringBuilder sbEBOMEffectDate= new StringBuilder();
		StringBuilder sbEBOMUntilDate= new StringBuilder();
		StringBuilder sbEBOMCobNum= new StringBuilder();
		StringBuilder sbEBOMChildRev= new StringBuilder();
		StringBuilder sbIntended= new StringBuilder();
		StringBuilder sbMF= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		try{
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				String sChildExists=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
				if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)){
					String sParentName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
					String sParentRev =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sParentTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sChildName =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
					String sChildId =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
					String sChildRev=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
					String sCombinationNum=(String)objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
					String sChildTitle =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
					String sChildType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
					sChildType = util.mapType(sChildType);
					String sSUBType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
					
					String sQTY =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
					String sBASEUOM =(String)objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
					String sEffectvityDate =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
					String sUntilDate=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
					String sRefDoc =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
					String sComments=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
					String sIntendedMarket =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
					String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
					String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
					sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);


					formatData(sbEBOMParentName,sParentName);
					formatData(sbEBOMParentRev,sParentRev);
					formatData(sbEBOMParentTitle,sParentTitle);
					formatData(sbEBOMName,sChildName);
					formatData(sbEBOMId,sChildId);
					formatData(sbEBOMChildRev,sChildRev);
					formatData(sbEBOMCobNum,sCombinationNum);
					formatData(sbEBOMTitle,sChildTitle);
					formatData(sbEBOMType,sChildType);
					formatData(sbEBOMSubType,sSUBType);
					formatData(sbEBOMQTY,sQTY);
					formatData(sbEBOMBuom,sBASEUOM);
					formatData(sbEBOMEffectDate,sEffectvityDate);
					formatData(sbEBOMUntilDate,sUntilDate);
					formatData(sbEBOMRefDoc,sRefDoc);
					formatData(sbEBOMCommnts,sComments);
					formatData(sbIntended,sIntendedMarket);
					formatData(sbMF,strMF);
					formatData(sbEBOMRDOC,sOC);

				}
			}
			mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
			mpEBOMResult.put(ConstantsUtil.INTENDEDFUNCTION, sbIntended.toString());
			mpEBOMResult.put(ConstantsUtil.OC, sbEBOMRDOC.toString());
			//return filterMapList(mpEBOMResult);

		}catch(Exception ex){
			LOGGER.error("Error from TransportUnitBO:  getSubstitute "+ex);
			return new HashMap();
		}
		return mpEBOMResult;
	}
	
	
	/**
	 * Method Name 			: formatData
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}


	/**
	 * Method Name 			: parseTUPMaplist
	 * Method Description 	:
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseTUPMaplist(MapList mapList) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator =  new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		StringBuilder sbEBOMSubstute= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMTupName= new StringBuilder();
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			String sType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));

			String sId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
			String sName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
			String sRevision =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
			String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
			String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			String spgChg =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
			String sFN =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER));
			String sTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

			String sTupName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.TUPNAME));
			sType = util.mapType(sType);
			String sSubstitute=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
			sSubstitute =util.replaceSpecialSymbols(sSubstitute);
			String sQty =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
			String sBuom =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
			String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
			String sCurrent =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
			String sStage =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
			String sRD =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR));
			String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));

			sRD =util.replaceSpecialSymbols(sRD);
			sOC =util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;

			formatData(sbEBOMName,sName);
			formatData(sbEBOMId,sId);
			formatData(sbEBOMChg,spgChg);
			formatData(sbEBOMFN,sFN);
			formatData(sbEBOMTitle,sTitle);
			formatData(sbEBOMType,sType);
			formatData(sbEBOMSubstute,sSubstitute);
			formatData(sbEBOMQTY,sQty);
			formatData(sbEBOMBuom,sBuom);
			formatData(sbEBOMCommnts,sComments);
			formatData(sbEBOMState,sCurrent);
			formatData(sbEBOMStage,sStage);
			formatData(sbEBOMRDOC,sRDOC);
			formatData(sbEBOMRevRelDt,sRevRelease);
			if(null!=sTupName && !sTupName.isEmpty()) {
				formatData(sbEBOMTupName,sTupName);
			}
		}
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		return mpEBOMResult;
	}
	
	//SPEC: Commented for 2018x.5 Dev - Jwala -- START
	//Related parts was removed from 18x.5 and there is no reference to this method. Hence commenting
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sType
	 * @param sID
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	/*public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sType, String sID, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		
		slBusSelects.add(ConstantsUtil.DERIVED_TO_NAME);
		slBusSelects.add(ConstantsUtil.DERIVED_TO_ID);
		slBusSelects.add(ConstantsUtil.DERIVED_TO_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.DERIVED_TO_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_TO_ORGNIZATION);
		slBusSelects.add(ConstantsUtil.DERIVED_TO_REVISION);
		slBusSelects.add(ConstantsUtil.DERIVED_TO_ORIGINATED);
		slBusSelects.add(ConstantsUtil.DERIVED_TO_OWNER);

		StringList slRelSelects = new StringList();

		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, getTo, getFrom, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();
			
			StringBuilder sbDerivedType = new StringBuilder();
			StringBuilder sbSourceType=new StringBuilder();
			
			StringBuilder sbDerivedId = new StringBuilder();
			StringBuilder sbSourceId=new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				StringValidatorUtil validator = new StringValidatorUtil();
				
				String sDerivedName	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sDerivedId	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sDerivedType	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
				String sDesc	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sCurrent	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String sOrganization	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG));
				String sOwner	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_OWNER));
				sCreatedDate	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ORIGINATED));
				sSourceRev	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));

				if (UIUtil.isNullOrEmpty(sOrganization)) {
					sOrganization=ConstantsUtil.EMPTY_STRING;
				}

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);

					util.formatData(sbDerivedType,sType);
					util.formatData(sbSourceType,sDerivedType);

					util.formatData(sbDerivedId,sID);
					util.formatData(sbSourceId,sDerivedId);

				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);

					util.formatData(sbDerivedType,sDerivedType);
					util.formatData(sbSourceType,sType);

					util.formatData(sbDerivedId,sDerivedId);
					util.formatData(sbSourceId,sID);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);

				String sDerivedToName	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_TO_NAME));
				String sDerivedToId	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_TO_ID));
				String sDerivedToType	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_TO_TYPE));
				String sToDesc	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_TO_DESCRIPTION));
				String sToCurrent	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_TO_CURRENT));
				String sToOrganization	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_TO_ORGNIZATION));
				String sToOwner	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_TO_OWNER));
				String sToCreatedDate	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_TO_ORIGINATED));
				String sToSourceRev	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.DERIVED_TO_REVISION));

				if (UIUtil.isNullOrEmpty(sOrganization)) {
					sOrganization=ConstantsUtil.EMPTY_STRING;
				}
				sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;

				if(getTo){
					String [] saDN = sDerivedToName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					for(String strDName:saDN){
						util.formatData(sbDerivedName,strDName);
						util.formatData(sbSourceName,sDerivedName);
						util.formatData(sbGenerationNum,sGenerationNum);
						util.formatData(sbOrganization,sOrganization);
					}

					util.formatData(sbDerivedType,sType);
					util.formatData(sbSourceType,sDerivedToType);

					util.formatData(sbDerivedId,sID);
					util.formatData(sbSourceId,sDerivedToId);

				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);

					util.formatData(sbDerivedType,sDerivedType);
					util.formatData(sbSourceType,sType);

					util.formatData(sbDerivedId,sDerivedId);
					util.formatData(sbSourceId,sID);
				}
				
				util.formatData(sbDesc,sToDesc);
				util.formatData(sbCurrent,sToCurrent);
				util.formatData(sbRevision,sToSourceRev);
				util.formatData(sbOwner,sToOwner);
				util.formatData(sbOriginated,sToCreatedDate);

			}
			
			mpDerived.put(ConstantsUtil.SOURCETYPE, sbSourceType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDTYPE, sbDerivedType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDID, sbDerivedId.toString());
			mpDerived.put(ConstantsUtil.SOURCEID, sbSourceId.toString());
			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : IRMSBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return mpDerived;
	}*/
	//SPEC: Commented for 2018x.5 Dev - Jwala -- END
	
	//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
	/**
     * Method Name 			: getIpClass
     * Method Description 	: Get IP Classification
     * @param context
     * @param doFormObj  - domain object of part
     * @param slIpSelects - Selectable
     */
    public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
    	MapList mlIPCLass;
		try {
			mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
					null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			Iterator itr = mlIPCLass.iterator();
			Map mpIpClass = new HashMap();
			StringBuilder sbIpName = new StringBuilder();
			StringBuilder sbHasClassAccess = new StringBuilder();
			StringBuilder sbIpType = new StringBuilder();
			StringBuilder sbIpDesc = new StringBuilder();
			StringBuilder sbIpState = new StringBuilder();
			StringBuilder sbIpLibrary = new StringBuilder();
			StringBuilder sbIpClassPath = new StringBuilder();
			
			while(itr.hasNext()) {
				mpIpClass = (Map)itr.next();
				String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
				sbIpName.append(sIpClassName);
				sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
				sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
				sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
				String strIpClass="";
				if(sIpClassName.contains(ConstantsUtil.HIR)) {
					strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
					sbIpLibrary.append(strIpClass);
				} else {
					strIpClass= ConstantsUtil.BUSINESS_USE;
					sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
				}
				if(!strIpClass.isEmpty()) {
					StringBuilder sbIpClassTemp = new StringBuilder();
					sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
					sbIpClassPath.append(sbIpClassTemp.toString());
				}
				
				//Compare user classification against IPName
				sbHasClassAccess.append("TRUE");
				
				if(itr.hasNext()) {
					sbIpName.append("|");
					sbIpType.append("|");
					sbIpDesc.append("|");
					sbIpState.append("|");
					sbIpLibrary.append("|");
					sbIpClassPath.append("|");
					sbHasClassAccess.append("|");
				}
			}
			mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
			mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
			mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
			mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
			//mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
			//mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
			mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
		} catch (FrameworkException e) {
			e.printStackTrace();
			LOGGER.error("Error from TransportUnitBO: getIpClass" + e);
		}
		return mpIpSecuritySetting;
    }
    
    
    /**
     * Method Name 			: parseSubstitute
     * Method Description 	: Fetching "Substitute" details
     * @param context
     * @param mapList
     * @return
     * @throws Exception 
     */
    public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
	{
    	StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
    	try {
			Iterator objectListItr = mapList.iterator();
			
			StringBuilder sbEBOMName = new StringBuilder();
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentRev = new StringBuilder();
			StringBuilder sbEBOMParentTitle = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			StringBuilder sbEBOMRefDoc= new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMCommnts = new StringBuilder();
			StringBuilder sbEBOMSubType= new StringBuilder();
			StringBuilder sbEBOMEffectDate= new StringBuilder();
			StringBuilder sbEBOMUntilDate= new StringBuilder();
			StringBuilder sbEBOMCobNum= new StringBuilder();
			StringBuilder sbEBOMChildRev= new StringBuilder();
			StringBuilder sbEBOMRevRelDt= new StringBuilder();
			StringBuilder sbEBOMSubFor= new StringBuilder();
			StringBuilder sbEBOMParentType = new StringBuilder();
			StringBuilder sbEBOMChg = new StringBuilder();
			StringBuilder sbEBOMSFSubType= new StringBuilder();
			
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				boolean showData = false;
				boolean bHasOwnership=false;
				
				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
				if(null!=objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
	
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
					//String
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
						String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
						
					
						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- STAT
						boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
						sReleaseDate =validator.DateFormatter(sReleaseDate);
						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- END
						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						
						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
						String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						//Added for Defect# 37591 -- START
						//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
						String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
						//Added for Defect# 37591 -- END
						String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
						String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
						String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
						String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
						String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
						sOC = util.replaceSpecialSymbols(sOC);
						String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
						
						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
						
						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- STAT
						if(!bChildHasAccess) {
							sChildId    = ConstantsUtil.NO_ACCESS;
							sChildTitle = ConstantsUtil.NO_ACCESS;
							sChildRev = ConstantsUtil.NO_ACCESS;
						}
						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- END
						
						if(util.isModificatinRequired())
						{
							//commented by Ganesh for security impl------->start
							/*SecurityService sec = new SecurityService();
							String sComp = sec.getUserCauthorities();
							StringList slUserOwnership=util.filterOwnerShip(sComp);
							
							String sFormulaPropagate = sParentID;
							if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
							}
							
							if(!sFormulaPropagate.isEmpty()) {
								bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
							}*/
							//commented by Ganesh for security impl------->end
							//modified by Ganesh for security impl------->start
							bHasOwnership = util.checkHasAccess(context, null, sParentID);
							//modified by Ganesh for security impl------->end
							
							if(!bHasOwnership)
							{
								//Commented Child parts for security in 1.0.1
								sParentType = ConstantsUtil.NO_ACCESS;
								sParentID = ConstantsUtil.NO_ACCESS;
								//sChildId    = ConstantsUtil.NO_ACCESS;
								sParentName = ConstantsUtil.NO_ACCESS;
								sParentRev = ConstantsUtil.NO_ACCESS;
								sParentTitle = ConstantsUtil.NO_ACCESS;
								sCombinationNum = ConstantsUtil.NO_ACCESS;
								//sChildTitle = ConstantsUtil.NO_ACCESS;
								sSUBType = ConstantsUtil.NO_ACCESS;
								sEffectvityDate = ConstantsUtil.NO_ACCESS;
								sRevRelease = ConstantsUtil.NO_ACCESS;
								sUntilDate = ConstantsUtil.NO_ACCESS;
								sRDOC = ConstantsUtil.NO_ACCESS;
								sQTY = ConstantsUtil.NO_ACCESS;
								sBASEUOM = ConstantsUtil.NO_ACCESS;
								//sChildRev = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								sSFSubType = ConstantsUtil.NO_ACCESS;
						    }//commented by Ganesh for security impl----->start
						}else /*if(sct.isStaffAUGUser()) {
							
							if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}
						}else {
							StringList slHIRTypes = new StringList();
							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
							slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
							
							if(slHIRTypes.contains(sParentType)) {
								if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
								}
							}else {
								showData=true;
							}
							
						}*///commented by Ganesh for security impl----->end
							//modified by Ganesh for security impl----->start
						{
							showData = util.checkHasAccess(context, null, sParentID);
						}
							//modified by Ganesh for security impl----->end
						
						if(!showData){
							//Commented Child parts for security in 1.0.1
							sParentID = ConstantsUtil.NO_ACCESS;
							//sChildId    = ConstantsUtil.NO_ACCESS;
							/*sParentType = ConstantsUtil.NO_ACCESS;
							sParentID = ConstantsUtil.NO_ACCESS;
							sChildId    = ConstantsUtil.NO_ACCESS;
							//sParentName = ConstantsUtil.NO_ACCESS;
							//sParentRev = ConstantsUtil.NO_ACCESS;
							sParentTitle = ConstantsUtil.NO_ACCESS;
							sCombinationNum = ConstantsUtil.NO_ACCESS;
							sChildTitle = ConstantsUtil.NO_ACCESS;
							sSUBType = ConstantsUtil.NO_ACCESS;
							sEffectvityDate = ConstantsUtil.NO_ACCESS;
							sRevRelease = ConstantsUtil.NO_ACCESS;
							sUntilDate = ConstantsUtil.NO_ACCESS;
							sRDOC = ConstantsUtil.NO_ACCESS;
							sComments = ConstantsUtil.NO_ACCESS;*/
						}
					
						sChildType = util.mapType(sChildType);
	
						formatData(sbEBOMName,sChildName);
						formatData(sbEBOMType,sChildType);
						formatData(sbEBOMQTY,sQTY);
						formatData(sbEBOMBuom,sBASEUOM);
						formatData(sbEBOMChildRev,sChildRev);
	
						formatData(sbEBOMParentType,sParentType);
						formatData(sbEBOMParentId,sParentID);
						formatData(sbEBOMId,sChildId);
						formatData(sbEBOMParentName,sParentName);
						formatData(sbEBOMParentRev,sParentRev);
						formatData(sbEBOMParentTitle,sParentTitle);
						formatData(sbEBOMCobNum,sCombinationNum);
						formatData(sbEBOMTitle,sChildTitle);
						formatData(sbEBOMSubType,sSUBType);
						formatData(sbEBOMRevRelDt,sRevRelease);
						formatData(sbEBOMEffectDate,sEffectvityDate);
						formatData(sbEBOMUntilDate,sUntilDate);
						formatData(sbEBOMRefDoc,sRDOC);
						formatData(sbEBOMCommnts,sComments);
						formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
						
						formatData(sbEBOMChg,sChg);
						formatData(sbEBOMSFSubType,sSFSubType);
					//}
					}
				}else {
					//StringList
					String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
					String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
					String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						for(int i =0; i<slChildId.size(); i++) {
							String sEachChildId = slChildId.getElement(i);
							//Commented for Child parts  security in 1.0.1--START
						/*	DomainObject doEachChild = new DomainObject(sEachChildId);
							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							StringList slSelect = new StringList();
							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							Map mpIpClass = doEachChild.getInfo(context, slSelect);
							StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							//String sIpClass = doEachChild.getInfo(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
							DomainConstants.MULTI_VALUE_LIST.remove("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");*/
							
							//Commented for  Child parts  security in 1.0.1--END
							
							StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
							String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
							
							boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
							
							if(util.isModificatinRequired())
							{
								//commented by Ganesh for security impl-------->start
								/*SecurityService sec = new SecurityService();
								String sComp = sec.getUserCauthorities();
								StringList slUserOwnership=util.filterOwnerShip(sComp);
								
								String sFormulaPropagate = sParentID;
								if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
								}
								
								if(!sFormulaPropagate.isEmpty()) {
									bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
								}
								*/
								//commented by Ganesh for security impl-------->end
								//modified by Ganesh for security impl-------->start
								bHasOwnership = util.checkHasAccess(context, null, sParentID);
								//modified by Ganesh for security impl-------->end
								if(bHasOwnership)
								{
									showData=true;
							    }
								//commented by Ganesh for security impl------>start
							}else/* if(sct.isStaffAUGUser()) {
								if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
								}
							}else {
								StringList slHIRTypes = new StringList();
								slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
								slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
								slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
								if(slHIRTypes.contains(slChildType.getElement(i))) {
									if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
										showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
									}else {
										showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
									}
								}else {
									showData=true;
								}
								
							}*/
								//commented by Ganesh for security impl------>end
								//modified by Ganesh for security impl------>start
							{
								showData = util.checkHasAccess(context, null, sParentID);
							}
							//modified by Ganesh for security impl------>end
							
							//Commented for Child parts  security in 1.0.1--START
							
							/*if(!showData) {
								sEachChildId=ConstantsUtil.NO_ACCESS;
							}*/
							
							
							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							//Modified for Defect# 37591 -- START
  							//StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
  							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  							//Modified for Defect# 37591 -- END
							
							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
							StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
							StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
							String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = slRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
							
							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
							StringList sSFSubType = (StringList) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							
							if(bChildHasAccess) {
								String sChildType = util.mapType(slChildType.get(i));
								formatData(sbEBOMName,slChildName.get(i));
								formatData(sbEBOMType,sChildType);
								formatData(sbEBOMChildRev,slChildRev.get(i));
								formatData(sbEBOMId,sEachChildId);
								formatData(sbEBOMTitle,slChildTitle.get(i));
							}
							else
							{
								
								formatData(sbEBOMName,slChildName.get(i));
								formatData(sbEBOMType,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMChildRev,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
							}
							
							if(showData) {
								//Commented for Child parts  security in 1.0.1
								//String sChildType = util.mapType(slChildType.get(i));
								//formatData(sbEBOMName,slChildName.get(i));
								//formatData(sbEBOMType,sChildType);
								formatData(sbEBOMQTY,slQTY.get(i));
								formatData(sbEBOMBuom,slBASEUOM.get(i));
								//formatData(sbEBOMChildRev,slChildRev.get(i));
								formatData(sbEBOMParentType,sParentType);
								formatData(sbEBOMParentId,sParentID);
								//formatData(sbEBOMId,sEachChildId);
								formatData(sbEBOMParentName,sParentName);
								formatData(sbEBOMParentRev,sParentRev);
								formatData(sbEBOMParentTitle,sParentTitle);
								formatData(sbEBOMCobNum,slCombinationNum.get(i));
								//formatData(sbEBOMTitle,slChildTitle.get(i));
								formatData(sbEBOMSubType,slSUBType.get(i));
								formatData(sbEBOMRevRelDt,sRevRelease);
								formatData(sbEBOMEffectDate,slEffectvityDate.get(i));
								formatData(sbEBOMUntilDate,slUntilDate.get(i));
								formatData(sbEBOMRefDoc,sRDOC);
								formatData(sbEBOMCommnts,slComments.get(i));
								formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								formatData(sbEBOMChg,sChg.get(i));
								formatData(sbEBOMSFSubType,sSFSubType.get(i));
							}else {
								//String sChildType = util.mapType(slChildType.get(i));
								//formatData(sbEBOMName,slChildName.get(i));
								//formatData(sbEBOMType,sChildType);
								formatData(sbEBOMQTY,slQTY.get(i));
								formatData(sbEBOMBuom,slBASEUOM.get(i));
								//formatData(sbEBOMChildRev,slChildRev.get(i));
								formatData(sbEBOMParentType,sParentType);
								formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMParentName,sParentName);
								formatData(sbEBOMParentRev,sParentRev);
								formatData(sbEBOMParentTitle,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMCobNum,ConstantsUtil.NO_ACCESS);
								//formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
								//Commented for Child parts  security in 1.0.1--END
								formatData(sbEBOMSubType,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMRevRelDt,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMEffectDate,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMUntilDate,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMRefDoc,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMCommnts,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMSFSubType,ConstantsUtil.NO_ACCESS);
							}
						}
					}
				}
				}

			}
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
    	}catch(Exception e) {
    		LOGGER.error("EXCEPTION IN TransportUnitBO : parseSubstitute: "+e);
    	}
		return util.filterMapList(mpEBOMResult);
	}
    
    
    /**
	 * Method Name 			: parseEBOMMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseEBOMMaplist(Context context, MapList mapList) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		
		
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);

		//SPEC: 10-23-2020 : added for Defect: 36641 ## -- START
		String sUserlicense = sec.getUserLicense();
		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		//SPEC: 10-23-2020 : added for Defect: 36641 ## -- END
		Iterator objectListItr = mapList.iterator();
		
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState = new StringBuilder();
		StringBuilder sbEBOMStage = new StringBuilder();
		StringBuilder sbEBOMRDOC = new StringBuilder();
		StringBuilder sbEBOMSubstute = new StringBuilder();
		StringBuilder sbEBOMRevRelDt = new StringBuilder();
		StringBuilder sbEBOMTupName = new StringBuilder();
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMAlternate = new StringBuilder();
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDensityUOM = new StringBuilder();
		
		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
			String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
			String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
			String sReleaseDate = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
			String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON + sReleaseDate;
			String spgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
			String sFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
			String sTupName = (String) objectMap.get(ConstantsUtil.TUPNAME);
			sType = util.mapType(sType);
			String sSubstitute = (String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
			sSubstitute = util.replaceSpecialSymbols(sSubstitute);
			String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			String sBuom = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
			String sComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
			sCurrent = util.mapType(sCurrent);
			String sStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
			sRD = util.replaceSpecialSymbols(sRD);
			String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
			sOC = util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
			String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));

			String sSubstitutePart = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			String sAlternate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
			sAlternate = sAlternate.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String sOSPD = validator.getStringEquivalentForStringList((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY));
			String sDensityUOM = validator.getStringEquivalentForStringList((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM));
			
			boolean bHasOwnership = false;
			if(util.isModificatinRequired())
			{
				//commented by Ganesh for security impl------>start
				//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
				/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) 
				{
					String sFormulaPropagate = util.getFormulaPropagate(context, sId);
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}
				}else {
					bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);
				}*/
				//commented by Ganesh for security impl------>start
				//modified by Ganesh for security impl------>start
				bHasOwnership = util.checkHasAccess(context, null, sId);
				//modified by Ganesh for security impl------>end
				if(!bHasOwnership)
				{
					sId = ConstantsUtil.NO_ACCESS;
					sRevision = ConstantsUtil.NO_ACCESS;
					sReleaseDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sTitle = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					sFN = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sQty = ConstantsUtil.NO_ACCESS;
					sBuom = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
					sCurrent = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					sSubstitutePart = ConstantsUtil.NO_ACCESS;
					sOSPD = ConstantsUtil.NO_ACCESS;
					sDensityUOM = ConstantsUtil.NO_ACCESS;
					sAlternate = ConstantsUtil.NO_ACCESS;
				}
		//SPEC: 10-23-2020 : Modified for Defect: 36641 ## -- START
		}else if(sec.isStaffAUGUser()) {
			boolean showData = true;
			//commented by Ganesh
			/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
				String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
			showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
			}else {
				showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
			}*///commented by Ganesh
			//modified by Ganesh for security impl------>start
			showData = util.checkHasAccess(context, null, sId);
			//modified by Ganesh for security impl------>end
			if(!showData){
				sId = ConstantsUtil.NO_ACCESS;
				spgChg = ConstantsUtil.NO_ACCESS;
			}
			
		//SPEC: 10-23-2020 : Modified for Defect: 36641 ## -- END
		} else if(!sec.isExternalUser())
		{

			boolean showData = true;
			//commented by Ganesh
			/*if(slHIRTypes.contains(sType) )
			{
					String sFormulaClassif =strClassFied;
					if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
					}
					if(null!=sUserlicense && null!=sFormulaClassif && !sUserlicense.contains(sFormulaClassif)) {
						showData=false;
					}
			}*///commented by Ganesh
			//modified by Ganesh for security impl----->start
			showData = util.checkHasAccess(context, null, sId);
			//modified by Ganesh for security impl----->end

				if(!showData){
					sId = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					/*Revision = ConstantsUtil.NO_ACCESS;
					sReleaseDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sTitle = ConstantsUtil.NO_ACCESS;
					sFN = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					//Req 33193 - 3 columns to be displayed for users with Business Use / Restricted access
					//sQty = ConstantsUtil.NO_ACCESS;
					//sBuom = ConstantsUtil.NO_ACCESS;
					//sCurrent = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;*/

				}
			}


			/*if (isModificatinRequired()) {

				boolean bHasOwnership = checkOwnerShip(context, slUserOwnership, sId);

				if (!bHasOwnership) {

					sId = ConstantsUtil.NO_ACCESS;
					sRevision = ConstantsUtil.NO_ACCESS;
					sReleaseDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sTitle = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					sFN = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sQty = ConstantsUtil.NO_ACCESS;
					sBuom = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
					sCurrent = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;

				}
			}*/

			formatData(sbEBOMName, sName);
			formatData(sbEBOMId, sId);
			formatData(sbEBOMChg, spgChg);
			formatData(sbEBOMFN, sFN);
			formatData(sbEBOMTitle, sTitle);
			formatData(sbEBOMType, sType);
			formatData(sbEBOMSubstute, sSubstitute);
			formatData(sbEBOMQTY, sQty);
			formatData(sbEBOMBuom, sBuom);
			formatData(sbEBOMCommnts, sComments);
			formatData(sbEBOMState, sCurrent);
			formatData(sbEBOMStage, sStage);
			formatData(sbEBOMRDOC, sRDOC);
			formatData(sbEBOMRevRelDt, sRevRelease);
			formatData(sbEBOMSubstitutePart, sSubstitutePart);
			formatData(sbEBOMAlternate, sAlternate);
			formatData(sbEBOMOSPD, sOSPD);
			formatData(sbEBOMDensityUOM, sDensityUOM);
			
			if (null != sTupName && !sTupName.isEmpty()) {
				formatData(sbEBOMTupName, sTupName);
			}

		}
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlternate.toString());
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDensityUOM.toString());
		if (null != sbEBOMTupName && sbEBOMTupName.length() > 0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		// return filterMapList(mpEBOMResult);

		return mpEBOMResult;
	}
	//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
	
	/**
	 * This method will verify the substitute Ownership.
	 * SPEC: 10/29/2020: Added for 18x.5 DEV -- START
	 * @param context
	 * @param objectMap
	 * @return
	 */
	
	public boolean checkSubstituteHasAccess(Context context, Map objectMap) {
	
		StringBuilder  sbReturnVal = new StringBuilder();
		boolean showData = false;
		try
		{
			StringValidatorUtil validator = new StringValidatorUtil();
			
			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership=util.filterOwnerShip(sComp);
			
		if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))
			{
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
				{
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
					String strSubPartId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
					
					DomainObject doEachChild = new DomainObject(strSubPartId);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					StringList slSelect = new StringList();
					slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					Map mpIpClass = doEachChild.getInfo(context, slSelect);
					//SPEC: <08-23-2021>: Sanjeeva Added/commented for Stress Testing Defect 44365  -- START
					doEachChild.close(context);
					//StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					//SPEC: <08-23-2021>: Sanjeeva Added/commented for Stress Testing Defect 44365  -- END
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					//commented by Ganesh for security impl------>start
					/*if(util.isModificatinRequired())
					{
						//For EBP User
						showData = util.checkOwnerShip(context, slUserOwnership, strSubPartId);
						
					}else if(sct.isStaffAUGUser())
					{
						//For Staff Aug USer check 
						if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							//Validation for Hir checks on Formulation
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else
						{
							//Validation for Hir checks for other than Formulation
							showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
						}
					}else 
					{
						//For Internal User check
						if(slHIRTypes.contains(strSubPartType)) 
						{
							//Validation for Hir checks on Formulation
							if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else 
							{
								//Validation for Hir checks for other than Formulation
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
						}else 
						{
							//If it is Non-Hir we can show without checks for internal user
							showData=true;
						}
					}*///commented by Ganesh for security impl------>end
					//modified by Ganesh for security impl------>start
					showData = util.checkHasAccess(context, null, strSubPartId);
//						//modified by Ganesh for security impl------>end
				}//close for string
				}else
			{	//If no Substitue found
				return showData;
			}
			
		}catch(Exception e){
			
			LOGGER.error("Error from TransportUnitBO :  checkSubstituteHasAccess" + e);
			return showData;
		}
		return showData;
	}
	
	//SPEC: <10.21.2020>: Added for #Defect 37543 -- START
	/**
	 * Method Name 			: addMultiSelects
	 * Method Description 	: 
	 */
	public StringList addMultiSelects() {
		StringList slMultiSelects = new StringList();
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.STRSEGMENT);
		
		return slMultiSelects;
	}
	/**
	 * Method Name 			: removeMultiSelects
	 * Method Description 	: For removing the multiselects from DomainCOnstants
	 */
	public void removeMultiSelects()
	{
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		// Guna Added for Defect 39163  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STRSEGMENT);
		// Guna Added for Defect 39163  18x.5.2 Release -- END
	}
	//SPEC: <10.21.2020>: Added for #Defect 37543 -- END

} 
