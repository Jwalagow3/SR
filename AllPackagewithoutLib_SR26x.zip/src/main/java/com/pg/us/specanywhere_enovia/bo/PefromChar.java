package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class PefromChar {

	
	public MapList getPerformanceChar(matrix.db.Context context, String[] args) throws Exception
	   {
		MapList objList = new MapList();
		try{
		   if (args.length == 0) {
			   throw new IllegalArgumentException();
		   }
		   String strCharInheritanceType = "";
		   String partType=null;
		   String strInheritanceType = "";
		   MapList parentPartFamilyMasterCharsLocal = new MapList();
		   MapList newMapList = new MapList();
		   StringList objectSelects = new StringList();
		   objectSelects.add(ConstantsUtil.SELECT_ID);
		   objectSelects.add(ConstantsUtil.SELECT_CURRENT);
		   objectSelects.add(ConstantsUtil.SELECT_NAME);
		   objectSelects.add(ConstantsUtil.SELECT_TYPE);
		   objectSelects.add(ConstantsUtil.SELECT_POLICY);
		   objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
		   objectSelects.add(ConstantsUtil.ATTR_REFERENCE_TYPE);

		   StringList relSelects = new StringList();
		   relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
		   relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
		   relSelects.add("attribute["+ConstantsUtil.ATTR_PG_INHERITANCE_TYPE + "]");
		   //Smart Scope Add Start
		   relSelects.add("attribute["+ ConstantsUtil.ATTRIBUTE_PG_INHERITED_FROM_PLATFORM + "]");
		   //Smart Scope Add End
		   //START :: gaikwad.tg
			relSelects.add("id[connection]");
			relSelects.add("from.name");
			relSelects.add("to.name");
			relSelects.add("relationship");
			String relPattern = ConstantsUtil.RELATIONSHIP_EXTENDEDDATA + "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE + "," + ConstantsUtil.RELATIONSHIP_SHAREDCHARACTERISTIC+ "," + "Extended Data";

			String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + "," + ConstantsUtil.TYPE__PERFORMANCE_CHAR;
			
			//END :: gaikwad.tg
		   HashMap paramMap = (HashMap) JPO.unpackArgs(args);

		  

		   String objectId = (String) paramMap.get("objectId");
		   String addNewRow = (String) paramMap.get("AddRow");
		   String strSwitchMode = (String) paramMap.get("SwitchMode");
		   
		   if(UIUtil.isNotNullAndNotEmpty(objectId)){
			   
			   DomainObject doObj = DomainObject.newInstance(context, objectId);

			   //START :: gaikwad.tg
			   boolean isShared = Boolean.valueOf(doObj.getInfo(context, "relationship[" + ConstantsUtil.RELATIONSHIP_SHARED_TABLE + "]")).booleanValue();
			   //END :: gaikwad.tg

			   String strSelectedTable = (String) paramMap.get(ConstantsUtil.SELECTEDTABLE);
			   strSelectedTable = strSelectedTable.substring(strSelectedTable
					   .lastIndexOf('~') + 1, strSelectedTable.length());
			   String strTypeSym = "type_pgPerformanceCharacteristic";//FrameworkProperties
			   String type = PropertyUtil.getSchemaProperty(context, strTypeSym);
			   boolean isContextPushed = false;
			   ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context,"person_UserAgent"),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);
			   isContextPushed = true;
			   StringList selStmt = new StringList();
			   selStmt.add(ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);
			   selStmt.add(ConstantsUtilIRM.SELECT_REL_PARTFAMILYREFERENCE);
			   selStmt.add(ConstantsUtil.SELECT_CURRENT);
			   //SPEC: 23-06-2022: Pooja Modified for Internal Defect -- START
			   Map partInfoMap = doObj.getInfo(context,selStmt);
			   
			   MapList conextObjectList = new MapList();
			   String strContextRefType =(String)partInfoMap.get(ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);
			 
			   String strConnectedRefId = ConstantsUtil.EMPTY_STRING;
			   if(partInfoMap.containsKey(ConstantsUtilIRM.SELECT_REL_PARTFAMILYREFERENCE)){
				   strConnectedRefId =(String)partInfoMap.get(ConstantsUtilIRM.SELECT_REL_PARTFAMILYREFERENCE);
			   }
			   //SPEC: 23-06-2022: Pooja Modified for Internal Defect -- END
			   final String derivedFilterSelection = (String) paramMap.get(ConstantsUtil.PGVPDPERMANCECHARFILTER);
			   String rangeAll = ConstantsUtil.ALL;
			   String rangeLocal = ConstantsUtil.STR_LOCAL;
			   String rangeReferenced = ConstantsUtil.STR_REFERENCED;

			   if("R".equals(strContextRefType) && UIUtil.isNotNullAndNotEmpty(strConnectedRefId))
			   {


				   /*String relPatrn = ConstantsUtil.RELATIONSHIP_CHARACTERISTIC+ "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE;
				 String typePatrn = ConstantsUtil.TYPE_SHARED_TABLE + ","+ type;
				 conextObjectList = doObj.getRelatedObjects(context, relPatrn, typePatrn,
						   objectSelects, relSelects, false, true, (short) 1, null,
						   null , 0);

					conextObjectList = doObj.getRelatedObjects(context, "Extended Data", "pgPerformanceCharacteristic,", objectSelects, relSelects,
							false, true, (short) 1, null, null, 0);*/

				   if (isShared) {
					   conextObjectList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
							   false, true, (short) 2, null, null, 0);
				   }
				   else {
					   conextObjectList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
							   false, true, (short) 1, null, null, 0);
				   }
				   //END :: gaikwad.tg

				   doObj.setId(strConnectedRefId);
			   }
			   String masterCurState = doObj.getInfo(context,ConstantsUtil.SELECT_CURRENT);

			   //String relPattern = null;


			   if("R".equals(strContextRefType) && UIUtil.isNotNullAndNotEmpty(strConnectedRefId) &&  !(ConstantsUtil.STATE_RELEASE.equals(masterCurState) || ConstantsUtil.STATE_COMPLETE.equals(masterCurState)) )
			   {
				   if(rangeReferenced.equalsIgnoreCase(derivedFilterSelection))
				   {
					   return new MapList(); 
				   }
				   else
				   {
					   return conextObjectList;
				   }
			   }


			   if (rangeAll.equalsIgnoreCase(derivedFilterSelection) || rangeLocal.equalsIgnoreCase(derivedFilterSelection))
			   {
				   //START :: gaikwad.tg
				   /*relPattern = ConstantsUtil.RELATIONSHIP_CHARACTERISTIC+ "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE;
			   String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + ","+ type;
			   String relWhere = null;

			   StringBuffer typeWhere = new StringBuffer();
			   typeWhere.append("type!=").append(ConstantsUtil.TYPE_PG_STABILITY_RESULTS);
			   objList = doObj.getRelatedObjects(context, relPattern, typePattern,
					   objectSelects, relSelects, false, true, (short) 1, typeWhere.toString(),
					   relWhere , 0);*/
				   if (isShared) {
					   objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
							   false, true, (short) 2, null, null, 0);
				   }
				   else {
					   objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
							   false, true, (short) 1, null, null, 0);
				   }
				   //END :: gaikwad.tg
				   String strCPGProductType = ConstantsUtil.TYPE_CPG_PRODUCT;
				   if(doObj.isKindOf(context, strCPGProductType) && rangeAll.equalsIgnoreCase(derivedFilterSelection))
				   {
					   if(isContextPushed){
						   ContextUtil.popContext(context);
						   isContextPushed = false;
					   }
					   HashMap hArgs = new HashMap();
					   hArgs.put("objectId",objectId);
					   String[] strArgs = JPO.packArgs(hArgs);	
					   MapList tmpList = new MapList();//JPO.invoke(context, "pgDSMConfigMgmtUtil", null,"getConfOptionsListForRootProduct", strArgs, MapList.class);

					   MapList finalList = getConsolidatedCharMapList(context, tmpList);

					   if(finalList!=null && !finalList.isEmpty())
						   objList.addAll(finalList);

					   if(!isContextPushed){
						   ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context,"person_UserAgent"),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);
						   isContextPushed = true;
					   }
				   }		   

				   MapList charObjList = new MapList();
				   Iterator objListItr = objList.iterator();
				   String strCharacteristicType = "";

				   while (objListItr.hasNext()) {
					   Map ObjMap = (Map) objListItr.next();
					   if(ObjMap != null && !ObjMap.isEmpty())
					   {
						   strCharacteristicType = (String) ObjMap.get(ConstantsUtil.SELECT_TYPE);
						   strCharInheritanceType = (String) ObjMap.get("attribute["+ConstantsUtil.ATTR_PG_INHERITANCE_TYPE + "]");
						   if(rangeLocal.equalsIgnoreCase(derivedFilterSelection) && ("M".equals(strContextRefType) || "U".equals(strContextRefType)) && strCharInheritanceType.equals(ConstantsUtil.STR_REFERENCED))
							   if(rangeLocal.equalsIgnoreCase(derivedFilterSelection) && UIUtil.isNotNullAndNotEmpty(strCharInheritanceType) && strCharInheritanceType.equals(ConstantsUtil.STR_REFERENCED))
							   {
								   charObjList.add(ObjMap); 
							   }
							   else if(rangeAll.equalsIgnoreCase(derivedFilterSelection) && ("R".equals(strContextRefType) && strCharInheritanceType.equals(ConstantsUtil.STR_LOCAL) && !(ConstantsUtil.STATE_RELEASE.equals(masterCurState) || ConstantsUtil.STATE_COMPLETE.equals(masterCurState))))
							   {
								   charObjList.add(ObjMap);            	   						   
							   }
					   }
				   }

				   if(!charObjList.isEmpty() && !("R".equals(strContextRefType) && UIUtil.isNullOrEmpty(strConnectedRefId)))
				   {
					   objList.removeAll(charObjList);
				   }
				   //SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43975 on Date 05/07/2021 --START
				   /*   Map mpTemp = new HashMap();
			   MapList mlTemp = new MapList();
			   for (int x = objList.size() - 1; x >= 0; x--) {
				   mpTemp = (Map) objList.get(x);
				   String strType = (String) mpTemp
				   .get(ConstantsUtil.SELECT_TYPE);
				   if (strType != null && strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) {
					   String strCharType = (String) mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
					   //START :: gaikwad.tg
					   if (strCharType != null && strCharType.equals(type)) {
						   objList.remove(x);
					   }
					   //END :: gaikwad.tg
				   }
			   }*/
				   //SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43975 on Date 05/07/2021 --END

				   objList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");
				   if(objList!=null && objList.size()>0){
					   objList = pgGetCharacteristicList(context,objList);
				   }


				   if (addNewRow != null && addNewRow.equals("true") && (strSwitchMode == null || "".equals(strSwitchMode))) {
					   HashMap m = new HashMap();
					   m.put(ConstantsUtil.SELECT_ID, "BLANK");
					   objList.add(m);
				   }

				   MapList mlTempList = new MapList();
				   for (int iSeq = 0; iSeq < objList.size(); iSeq++) {
					   Map mpTempList = (Map) objList.get(iSeq);
					   mpTempList.put("Sequence", Integer.toString(iSeq + 1));
					   mlTempList.add(mpTempList);
				   }
				   objList.clear();
				   objList.addAll(mlTempList);

			   }

			   String strReferenceType = (String)doObj.getInfo(context, "attribute[" + ConstantsUtil.ATTR_REFERENCE_TYPE + "]");
			   if (rangeAll.equalsIgnoreCase(derivedFilterSelection) || rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {

				   if(UIUtil.isNotNullAndNotEmpty(strReferenceType))
				   {
					   //START :: gaikwad.tg
					   /*relPattern = ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE;
				String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + "," + type;
						MapList charList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects,
								relSelects, false, true, (short) 1, null, null, 0);*/
					   MapList charList =  new MapList();
					   if (isShared) {
						   objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
								   false, true, (short) 2, null, null, 0);
					   }
					   else {
						   objList = doObj.getRelatedObjects(context, relPattern, typePattern, objectSelects, relSelects,
								   false, true, (short) 1, null, null, 0);
					   }
					   //END :: gaikwad.tg
					   Iterator charListItrtr = charList.iterator();
					   while (charListItrtr.hasNext()) {
						   Map charMap = (Map) charListItrtr.next();
						   if(charMap != null && !charMap.isEmpty())
						   {
							   String strType = (String) charMap.get(ConstantsUtil.SELECT_TYPE);
							   strCharInheritanceType = (String) charMap.get("attribute["+ConstantsUtil.ATTR_PG_INHERITANCE_TYPE + "]");
							   if(rangeAll.equalsIgnoreCase(derivedFilterSelection))
							   {
								   if (UIUtil.isNotNullAndNotEmpty(strType) && (strType.equals(ConstantsUtil.TYPE_SHARED_TABLE) || strType.equals(type))) 
								   {
									   String strCharType = (String) charMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
									   if (UIUtil.isNotNullAndNotEmpty(strCharType) && strCharType.equals(type) && (("M".equals(strContextRefType) || ("R".equals(strContextRefType) && (ConstantsUtil.STATE_RELEASE.equals(masterCurState) || ConstantsUtil.STATE_COMPLETE.equals(masterCurState)))))) 
									   {
										   objList.add(charMap);
									   }

								   }
							   }
							   else if(rangeReferenced.equalsIgnoreCase(derivedFilterSelection))
							   {
								   if (UIUtil.isNotNullAndNotEmpty(strType) && (strType.equals(ConstantsUtil.TYPE_SHARED_TABLE) || strType.equals(type))) 
								   {
									   String strCharType = (String) charMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
									   if ((UIUtil.isNotNullAndNotEmpty(strCharType) && strCharType.equals(type)) || "Referenced".equals(strCharInheritanceType) || ("R".equals(strContextRefType) && (ConstantsUtil.STATE_RELEASE.equals(masterCurState) || ConstantsUtil.STATE_COMPLETE.equals(masterCurState)) ))

									   {
										   objList.add(charMap);

									   }
								   } 
							   }
						   }
					   }
				   }
			   }
			   partType = doObj.getInfo(context, ConstantsUtil.SELECT_TYPE);
			   if (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(partType) && (rangeAll.equalsIgnoreCase(derivedFilterSelection) || rangeReferenced.equalsIgnoreCase(derivedFilterSelection) ))
			   {
				   objList=getEbomPartsCharacterstics(context,paramMap,doObj,objList,derivedFilterSelection);//Chandra
			   }

			   if("R".equals(strContextRefType) &&  conextObjectList != null && !conextObjectList.isEmpty() && !rangeReferenced.equalsIgnoreCase(derivedFilterSelection))
			   {
				   objList.addAll(conextObjectList);
			   }
			   if("R".equals(strContextRefType) && rangeLocal.equalsIgnoreCase(derivedFilterSelection) && strCharInheritanceType.equals(ConstantsUtil.STR_LOCAL))
			   {
				   return objList;
			   }
			   if("R".equals(strContextRefType) && rangeLocal.equalsIgnoreCase(derivedFilterSelection))
			   {
				   objList = conextObjectList;
			   }

			   StringList slConnectionIds = new StringList();
			   if(ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(partType) && (rangeAll.equalsIgnoreCase(derivedFilterSelection) || rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) ){

				   for (int i = 0; i < objList.size(); i++) {

					   Map mpTemp = (Map) objList.get(i);

					   String sRelId =(String) mpTemp.get(DomainRelationship.SELECT_ID);
					   if(UIUtil.isNotNullAndNotEmpty(sRelId))
						   slConnectionIds.add(sRelId);

				   }
				   String[] strArrIds = new String[slConnectionIds.size()];
				   strArrIds = slConnectionIds.toArray(strArrIds);
				   MapList mlConnectedObjTypes = DomainRelationship.getInfo(context, strArrIds, StringList.create(DomainConstants.SELECT_FROM_TYPE,DomainConstants.SELECT_RELATIONSHIP_ID));
				   Map mpObj = null;
				   String sObjConnectionId = ConstantsUtil.EMPTY_STRING;
				   Map mpConnectedObj = null;
				   String sConnectionId = ConstantsUtil.EMPTY_STRING;
				   String sConnectedObjType = ConstantsUtil.EMPTY_STRING;

				   MapList mlFPPObjList 	= new MapList();
				   MapList mlCUPObjList 	= new MapList();
				   MapList mlMCUPObjList 	= new MapList();
				   MapList mlIPObjList 		= new MapList();
				   MapList mlMIPObjList 	= new MapList();
				   MapList mlCOPObjList 	= new MapList();
				   MapList mlMCOPObjList 	= new MapList();

				   for(int x = 0; x < objList.size(); x++){
					   mpObj = (Map) objList.get(x);
					   sObjConnectionId = (String) mpObj.get(DomainRelationship.SELECT_ID);

					   for(int y = 0; y < mlConnectedObjTypes.size(); y++){
						   mpConnectedObj = (Map) mlConnectedObjTypes.get(y);
						   sConnectionId = (String) mpConnectedObj.get(DomainConstants.SELECT_RELATIONSHIP_ID);
						   if(sConnectionId.equals(sObjConnectionId)){
							   sConnectedObjType = (String) mpConnectedObj.get(DomainConstants.SELECT_FROM_TYPE);
						   }
					   }
					   mpObj.put("type",sConnectedObjType);

					   if(sConnectedObjType.equals(ConstantsUtil.TYPE_FINISHEDPRODUCTPART))
						   mlFPPObjList.add(mpObj);
					   else if(sConnectedObjType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART))
						   mlCUPObjList.add(mpObj);
					   else if(sConnectedObjType.equals(ConstantsUtil.TYPE_PGMASTERCUSTOMERUNITPART))
						   mlMCUPObjList.add(mpObj);
					   else if(sConnectedObjType.equals(ConstantsUtil.TYPE_PGINNERPACKUNITPART))
						   mlIPObjList.add(mpObj);
					   else if(sConnectedObjType.equals(ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART))
						   mlMIPObjList.add(mpObj);
					   else if(sConnectedObjType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART))
						   mlCOPObjList.add(mpObj);
					   else if(sConnectedObjType.equals(ConstantsUtil.TYPE_PGMASTERCONSUMERUNITPART))
						   mlMCOPObjList.add(mpObj);

				   }
				   mlFPPObjList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");
				   mlCUPObjList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");
				   mlMCUPObjList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");
				   mlIPObjList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");
				   mlMIPObjList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");
				   mlCOPObjList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");
				   mlMCOPObjList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");

				   MapList mlObjList = new MapList();
				   mlObjList.addAll(mlFPPObjList);
				   mlObjList.addAll(mlCUPObjList);
				   mlObjList.addAll(mlMCUPObjList);
				   mlObjList.addAll(mlIPObjList);
				   mlObjList.addAll(mlMIPObjList);
				   mlObjList.addAll(mlCOPObjList);
				   mlObjList.addAll(mlMCOPObjList);

				   MapList mlTempList = new MapList();
				   for (int iSeq = 0; iSeq < mlObjList.size(); iSeq++) {
					   Map mpTempList = (Map) mlObjList.get(iSeq);
					   mpTempList.put("Sequence", Integer.toString(iSeq + 1));
					   mlTempList.add(mpTempList);
				   }
				   objList.clear();
				   objList.addAll(mlTempList);
			   }
			   if(isContextPushed)
				   ContextUtil.popContext(context);
		   }
			}catch(Exception ex){
				ex.printStackTrace();
				throw ex;
			}
		   return objList;

	   }
	
	 
		public MapList getConsolidatedCharMapList(Context context, MapList optionMapList) throws Exception {
			StringList strConnectionIdList = new StringList();
			MapList mlRelInfoList = new MapList();
			MapList finalCharMapList = new MapList();
			StringList strUniqIdList = new StringList();
			String strObjId = null;
			StringList strObjIdList = null;
			StringList strObjTypeList = null;
			StringList strObjNameList = null;
			StringList strObjPolicyList = null;
			StringList strObjStateList= null;         
			StringList strRelIdList = null;
			StringList strRelAttrList = null;
			StringList strRelAttrInhTypeList = null;
			StringList strObjAttrTMLOGIC = null;
			StringList strObjAttrActionRequired = null;
			StringList strObjAttrRepType = null;
			StringList strObjAttrChar = null;
			StringList strObjAttrLowSpecLimit = null;
			StringList strObjAttrUpperSpecLimit = null;
			StringList strObjAttrLowRouteinLimit = null;
			StringList strObjAttrUpperRouteinLimit = null;
			StringList strObjAttrTarget = null;
			StringList strObjAttrLowerTarget = null;
			StringList strObjAttrUpperTarget = null;

			Map tempOptionMap = null;
			String strConnId = null;
			Map charInfoMap = null;
			Object charObjMap = null;
			Map tempCharMap = null;
			Map finalCharMap = null;

			try
			{	    	 
				if (optionMapList != null && !optionMapList.isEmpty()){
					for (Object optionMap : optionMapList){
						tempOptionMap = (Map) optionMap;
						strConnId = (String) tempOptionMap.get(DomainRelationship.SELECT_ID);
						strConnectionIdList.add(strConnId);
					}
				}

				String[] connectionOidsArray = new String[strConnectionIdList.size()];
				connectionOidsArray = (String[]) strConnectionIdList.toArray(connectionOidsArray);
				StringList slrelationshipSelects = new StringList(19);
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_ID);
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "]."+ConstantsUtil.SELECT_ID);
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].attribute[" +ConstantsUtil.ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE+"].value");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_CURRENT);
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_NAME);
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_TYPE);
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_POLICY);	         
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].attribute[" +ConstantsUtil.ATTR_PG_INHERITANCE_TYPE+"].value");

				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGTMLOGIC+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGACTIONREQUIRED+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGREPORTTYPE+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGCHARACTERISTIC+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERROUTINERELEASELIMIT+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGTARGET+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERTARGET+"]");
				slrelationshipSelects.addElement("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERTARGET+"]");

				mlRelInfoList = DomainRelationship.getInfo(context, connectionOidsArray, slrelationshipSelects);
				int iRelInfoListSize = mlRelInfoList.size();
				for (int i = 0; i < iRelInfoListSize; i++)
				{
					charInfoMap = (Map) mlRelInfoList.get(i);
					charObjMap = (Object) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.id");
					if (charObjMap != null)
					{
						if (charObjMap instanceof String)
						{
							tempCharMap = new HashMap();
							strObjId = ((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.id"));
							tempCharMap.put(ConstantsUtil.SELECT_ID,strObjId);
							tempCharMap.put(DomainConstants.SELECT_LEVEL,"1");
							tempCharMap.put(DomainRelationship.SELECT_ID,((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "]."+ConstantsUtil.SELECT_ID)));
							tempCharMap.put("attribute[" +ConstantsUtil.ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].attribute[" +ConstantsUtil.ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE+"].value")));
							tempCharMap.put(ConstantsUtil.SELECT_TYPE,((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_TYPE)));
							tempCharMap.put(ConstantsUtil.SELECT_NAME,((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_NAME)));
							tempCharMap.put(ConstantsUtil.SELECT_POLICY,((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_POLICY)));
							tempCharMap.put(ConstantsUtil.SELECT_CURRENT,((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_CURRENT)));
							tempCharMap.put("attribute[" +ConstantsUtil.ATTR_PG_INHERITANCE_TYPE+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].attribute[" +ConstantsUtil.ATTR_PG_INHERITANCE_TYPE+"].value")));

							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGTMLOGIC+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGTMLOGIC+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGACTIONREQUIRED+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGACTIONREQUIRED+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGREPORTTYPE+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGREPORTTYPE+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGCHARACTERISTIC+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGCHARACTERISTIC+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERROUTINERELEASELIMIT+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERROUTINERELEASELIMIT+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGTARGET+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGTARGET+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERTARGET+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERTARGET+"]")));
							tempCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERTARGET+"]",((String) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERTARGET+"]")));

							if(!strUniqIdList.contains(strObjId))
							{
								strUniqIdList.add(strObjId);
								finalCharMapList.add(tempCharMap);
							}
						}
						else
						{
							strObjIdList = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_ID);
							strObjTypeList = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_TYPE);
							strObjNameList = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_NAME);
							strObjPolicyList = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_POLICY);
							strObjStateList= (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to."+ConstantsUtil.SELECT_CURRENT);
							strRelIdList = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "]."+ConstantsUtil.SELECT_ID);
							strRelAttrList = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].attribute[" + ConstantsUtil.ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE+"].value");
							strRelAttrInhTypeList = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].attribute[" +ConstantsUtil.ATTR_PG_INHERITANCE_TYPE+"].value");
							strObjAttrTMLOGIC = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGTMLOGIC+"]");
							strObjAttrActionRequired = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGACTIONREQUIRED+"]");
							strObjAttrRepType = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGREPORTTYPE+"]");
							strObjAttrChar = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGCHARACTERISTIC+"]");
							strObjAttrLowSpecLimit = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT+"]");
							strObjAttrUpperSpecLimit = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT+"]");
							strObjAttrLowRouteinLimit = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT+"]");
							strObjAttrUpperRouteinLimit = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERROUTINERELEASELIMIT+"]");
							strObjAttrTarget = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGTARGET+"]");
							strObjAttrLowerTarget = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERTARGET+"]");
							strObjAttrUpperTarget = (StringList) charInfoMap.get("frommid[" + ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "].to.attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERTARGET+"]");

							int iObjIdIdListSize = strObjIdList.size();
							for (int num = 0; num <iObjIdIdListSize ; num++)
							{
								finalCharMap = new HashMap();
								strObjId = (String)strObjIdList.get(num);
								finalCharMap.put(ConstantsUtil.SELECT_ID, strObjId);
								finalCharMap.put(DomainConstants.SELECT_LEVEL,"1");
								finalCharMap.put(DomainRelationship.SELECT_ID, strRelIdList.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE+"]",strRelAttrList.get(num));

								finalCharMap.put(ConstantsUtil.SELECT_TYPE,strObjTypeList.get(num));
								finalCharMap.put(ConstantsUtil.SELECT_NAME,strObjNameList.get(num));
								finalCharMap.put(ConstantsUtil.SELECT_POLICY,strObjPolicyList.get(num));
								finalCharMap.put(ConstantsUtil.SELECT_CURRENT,strObjStateList.get(num));

								finalCharMap.put("attribute["+ConstantsUtil.ATTR_PG_INHERITANCE_TYPE+"]",strRelAttrInhTypeList.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGTMLOGIC+"]",strObjAttrTMLOGIC.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGACTIONREQUIRED+"]",strObjAttrActionRequired.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGREPORTTYPE+"]",strObjAttrRepType.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGCHARACTERISTIC+"]",strObjAttrChar.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT+"]",strObjAttrLowSpecLimit.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT+"]",strObjAttrUpperSpecLimit.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT+"]",strObjAttrLowRouteinLimit.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERROUTINERELEASELIMIT+"]",strObjAttrUpperRouteinLimit.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGTARGET+"]",strObjAttrTarget.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGLOWERTARGET+"]",strObjAttrLowerTarget.get(num));
								finalCharMap.put("attribute["+ConstantsUtil.ATTRIBUTE_PGUPPERTARGET+"]",strObjAttrUpperTarget.get(num));

								if(!strUniqIdList.contains(strObjId))
								{
									strUniqIdList.add(strObjId);
									finalCharMapList.add(finalCharMap);
								}
							}
						}
					}
				}
			} 
			catch (Exception exc)
			{
				exc.printStackTrace();
			}
			return finalCharMapList;
		}

		
		public MapList pgGetCharacteristicList(Context context, MapList inputList) throws Exception {

			Iterator objListItr = inputList.iterator();

			int nCount=0;

			MapList outputList=new MapList();

			while (objListItr.hasNext()) 
			{
				Map perMap = (Map) objListItr.next();
				nCount++;
				perMap.put("nCount", ""+nCount);

				outputList.add(perMap);
			}

			return outputList;

		}
		  private MapList getEbomPartsCharacterstics(Context context, Map paramMap,DomainObject finishedPartDO, MapList objList,String derivedFilterSelection ) throws Exception
	       {

	    	   MapList ebomCharList=new MapList();
	    	   MapList returnList=new MapList();
	    	   String [] newArguments=null;
	    	   StringList strlObjectSelectable = new StringList(3);
	    	   strlObjectSelectable.add(ConstantsUtil.SELECT_ID);
	    	   strlObjectSelectable.add(ConstantsUtil.SELECT_TYPE);
	    	   strlObjectSelectable.add(ConstantsUtil.SELECT_NAME);

	    	   StringList strlRelSelectable = new StringList(3);
	    	   strlRelSelectable.add(DomainRelationship.SELECT_FROM_TYPE);
	    	   strlRelSelectable.add(DomainRelationship.SELECT_TO_TYPE);
	    	   strlRelSelectable.add(DomainRelationship.SELECT_FROM_ID);

	    	   String ebomPartId = null;
	    	   String ebomPartName = null;
	    	   String strDerivedPath = null;
	    	   String relFromType = null;
	    	   String relToType = null;
	    	   String relFromId = null;
	    	   String relFromName = null;
	    	   String rangeAll=ConstantsUtil.ALL;;

	    	   if (objList != null && objList.size() > 0 && rangeAll.equalsIgnoreCase(derivedFilterSelection))
	    	   {
	    		   returnList.addAll(objList);
	    	   }

	    	   MapList conectedEBOMPartList = finishedPartDO.getRelatedObjects(context,
	    			   DomainObject.RELATIONSHIP_EBOM,
	    			   ConstantsUtil.TYPE_PGCUSTOMERUNITPART+ ","+ ConstantsUtil.TYPE_PGINNERPACKUNITPART+ ","+ ConstantsUtil.TYPE_PGCONSUMERUNITPART,
	    			   strlObjectSelectable,//Object Select
	    			   strlRelSelectable, //rel Select
	    			   false,//get To
	    			   true,//get From
	    			   (short)0,//recurse level
	    			   "",//where Clause
	    			   null,//relationshipWhere Clause
	    			   0);//return all

	    	   Iterator ebomItr=conectedEBOMPartList.iterator();
	    	   while(ebomItr.hasNext())
	    	   {
	    		   Map partMap=(Map)ebomItr.next();
	    		   ebomPartId=(String)partMap.get(ConstantsUtil.SELECT_ID);
	    		   ebomPartName=(String)partMap.get(ConstantsUtil.SELECT_NAME);
	    		   relFromType=(String)partMap.get(DomainRelationship.SELECT_FROM_TYPE);
	    		   relToType=(String)partMap.get(DomainRelationship.SELECT_TO_TYPE);
	    		   relFromId=(String)partMap.get(DomainRelationship.SELECT_FROM_ID);

	    		   if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equals(relFromType) && (ConstantsUtil.TYPE_PGCONSUMERUNITPART.equals(relToType) || ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(relToType)))
	    		   {
	    			   continue;
	    		   }
	    		   if(ConstantsUtil.TYPE_PGCUSTOMERUNITPART.equals(relFromType) && ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(relToType))
	    		   {
	                   returnList.clear();
	                   ebomPartId=relFromId;
	    			   if(UIUtil.isNotNullAndNotEmpty(ebomPartId))
	    			   {
	    				   ebomPartName=new DomainObject(ebomPartId).getInfo(context,ConstantsUtil.SELECT_NAME);
	                   }
	    		   }
	    		   String strMode = (String)paramMap.get("Mode");

	    		   paramMap.put(ConstantsUtil.STRING_OBJECTID,ebomPartId);
	    		   paramMap.put("pgVPDCPNCharacteristicDerivedFilter",rangeAll);
	    		   newArguments = JPO.packArgs(paramMap);
	    		   ebomCharList.addAll(getMicroChar(context,newArguments));

	    		   Iterator ebomCharListItr=ebomCharList.iterator();
	    		   while(ebomCharListItr.hasNext())
	    		   {
				   MapList tempMapList = new MapList();
	    		   StringList tempList = new StringList();
	    			   Map ebomCharListMap=(Map)ebomCharListItr.next();
	    			   strDerivedPath=(String)ebomCharListMap.get("derivedPath");
	    			   if(null==strDerivedPath)
	    			   {
	    				   if("PDF".equals(strMode)) {
	    					   ebomCharListMap.put("derivedPath", ebomPartName);
	    				   }
	    				   else {
	    					   ebomCharListMap.put("derivedPath", ""); 
	    				   }

	    				   ebomCharListMap.put("disableSelection", "true");
	    				   ebomCharListMap.put("RowEditable", "readonly");
	    				   ebomCharListMap.put("derivedCharacteristic", "true");
	    				   returnList.add(ebomCharListMap);
	    			   }
	    			   else
	    			   {
	    				   String strParse  = (String)ebomCharListMap.get("derivedPath");
	    				   String strObjectId = strParse.substring(strParse.lastIndexOf("objectId=") +9);
	    				   String sOid = strObjectId.substring(0, strObjectId.indexOf("'"));
	    					if(tempList.isEmpty())
	    					{
	    						tempList.addElement(sOid);
	    					}
	    					if(tempList.contains(sOid))
	    					{
	    						tempMapList.add(ebomCharListMap);
	    					}
	    						tempMapList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");
	    						for(int j=0;j<tempMapList.size();j++)
	    						{
	    							returnList.add((Map)tempMapList.get(j));
	    			   }
	    			   }

	    		   }
	    		   ebomCharList.clear();
	    		   if(relFromType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART) && relToType.equals(ConstantsUtil.TYPE_FINISHEDPRODUCTPART))
	    		   {
	    			   break;
	    		   }
	    	   }
	    	   return returnList;
	}

		  
		  public MapList getMicroChar(matrix.db.Context context, String[] args) throws Exception
	       {
	    	   if (args.length == 0) {
	    		   throw new IllegalArgumentException();
	    	   }

	    	   String partType=null;
	    	   MapList objList = new MapList();
	    	   MapList newMapList = new MapList();
	    	   StringList objectSelects = new StringList();
	    	   objectSelects.add(ConstantsUtil.SELECT_ID);
	    	   objectSelects.add(ConstantsUtil.SELECT_NAME);
	    	   objectSelects.add(ConstantsUtil.SELECT_TYPE);
	    	   objectSelects.add(ConstantsUtil.SELECT_POLICY);
	    	   objectSelects
	    	   .add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
	    	   objectSelects.add(ConstantsUtil.ATTR_REFERENCE_TYPE);

	    	   StringList relSelects = new StringList();
	    	   relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
	    	   relSelects
	    	   .add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
	    	   relSelects.add("attribute[" + ConstantsUtil.ATTR_PG_INHERITANCE_TYPE + "].value");

	    	   HashMap paramMap = (HashMap) JPO.unpackArgs(args);


	    	   String objectId = (String) paramMap.get("objectId");
	    	   String addNewRow = (String) paramMap.get("AddRow");
	    	   String strSwitchMode = (String) paramMap.get("SwitchMode");
	    	   DomainObject doObj = DomainObject.newInstance(context, objectId);

	    	   String strSelectedTable = (String) paramMap.get("selectedTable");
	    	   strSelectedTable = strSelectedTable.substring(strSelectedTable
	    			   .lastIndexOf('~') + 1, strSelectedTable.length());
	    	   String strTypeSym = "type_pgPerformanceCharacteristic";
		 
	    	   String type = PropertyUtil.getSchemaProperty(context, strTypeSym);

	    	   final String derivedFilterSelection = (String) paramMap.get(ConstantsUtil.PGVPDPERMANCECHARFILTER);
				String rangeAll = ConstantsUtil.ALL;
				String rangeLocal = ConstantsUtil.STR_LOCAL;
				String rangeReferenced = ConstantsUtil.STR_REFERENCED;
				
				
	    	   if (rangeAll.equalsIgnoreCase(derivedFilterSelection)|| rangeLocal.equalsIgnoreCase(derivedFilterSelection))
	    	   {
	    		   String relPattern =  ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE;
	    		   String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + ","
	    		   + type;
	    		   objList = doObj.getRelatedObjects(context, relPattern, typePattern,
	    				   objectSelects, relSelects, false, true, (short) 1, null,
	    				   null , 0);

	    		   Map mpTemp = new HashMap();
	    		   MapList mlTemp = new MapList();
	    		   for (int x = objList.size() - 1; x >= 0; x--) {
	    			   mpTemp = (Map) objList.get(x);
	    			   String strType = (String) mpTemp
	    			   .get(ConstantsUtil.SELECT_TYPE);
	    			   if (strType != null
	    					   && strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) {
	    				   String strCharType = (String) mpTemp
	    				   .get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);

	    				   if (strCharType != null && !strCharType.equals(type)) {
	    					   objList.remove(x);
	    				   }
	    			   }
	    		   }

	    		   objList
	    		   .sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");
	    		   if(objList!=null && objList.size()>0){
	    			   objList = pgGetCharacteristicList(context,objList);
	    		   }

	    		   if (addNewRow != null && addNewRow.equals("true")
	    				   && (strSwitchMode == null || "".equals(strSwitchMode))) {
	    			   HashMap m = new HashMap();
	    			   m.put(ConstantsUtil.SELECT_ID, "BLANK");
	    			   objList.add(m);
	    		   }

	    		   MapList mlTempList = new MapList();
	    		   for (int iSeq = 0; iSeq < objList.size(); iSeq++) {
	    			   Map mpTempList = (Map) objList.get(iSeq);
	    			   mpTempList.put("Sequence", Integer.toString(iSeq + 1));
	    			   mlTempList.add(mpTempList);
	    		   }
	    		   objList.clear();
	    		   objList.addAll(mlTempList);

	    	   }
	    	   String strReferenceType = (String)doObj.getInfo(context, "attribute[" + ConstantsUtil.ATTR_REFERENCE_TYPE + "]");
	    	   if (rangeAll.equalsIgnoreCase(derivedFilterSelection)
	    			   || rangeReferenced.equalsIgnoreCase(derivedFilterSelection)) {

	    		   if(UIUtil.isNotNullAndNotEmpty(strReferenceType) && "R".equalsIgnoreCase(strReferenceType))
	    		   {
	    			   MapList charList = getMasterCharacteristics(context, args);
	    		   
	    			   Iterator charListItrtr = charList.iterator();
	    			   while (charListItrtr.hasNext()) {
	    			   Map charMap = (Map) charListItrtr.next();
	    			   if(charMap != null && !charMap.isEmpty())
	    			   {
	    				   String strType = (String) charMap
	    				   .get(ConstantsUtil.SELECT_TYPE);
	    				   if (strType != null && strType.equals(type)) {
	    					   objList.add(charMap);
	    				   }

	    				   if (strType != null
	    						   && strType.equals(ConstantsUtil.TYPE_SHARED_TABLE)) {
	    					   String strCharType = (String) charMap
	    					   .get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);
	    					   if (strCharType != null && strCharType.equals(type)) {
	    						   objList.add(charMap);
	    					   }
	    				   }
	    			   }
	    		   }
	    		   }
	    	   }
	    	   partType = doObj.getInfo(context, ConstantsUtil.SELECT_TYPE);
	    	   if (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(partType) && (rangeAll.equalsIgnoreCase(derivedFilterSelection) || rangeReferenced.equalsIgnoreCase(derivedFilterSelection) ))
	    	   {
	    		   objList=getEbomPartsCharacterstics(context,paramMap,doObj,objList,derivedFilterSelection);
	    	   }

	    	   return objList;

	       }

		  public MapList getMasterCharacteristics(matrix.db.Context context, String[] args)
					throws Exception {
			  BusObjectAttribUtil UTILS = new BusObjectAttribUtil();
				if (args.length == 0) {
					throw new IllegalArgumentException();
				}
				
				MapList objList = new MapList();
				String objectId = UTILS.getParam(args, "objectId");
				String addNewRow = UTILS.getParam(args, "AddRow");
				String strSwitchMode = UTILS.getParam(args, "SwitchMode");
				String strSelectedTable = UTILS.getParam(args, "selectedTable");
				String strMode = UTILS.getParam(args, "Mode");
				strSelectedTable = strSelectedTable.substring(strSelectedTable
						.lastIndexOf('~') + 1, strSelectedTable.length());

				String strTypeSym = "type_pgPerformanceCharacteristic";//FrameworkProperties

				String type = PropertyUtil.getSchemaProperty(context, strTypeSym);
				if(UIUtil.isNotNullAndNotEmpty(objectId))
				{
					DomainObject doObj = DomainObject.newInstance(context, objectId);
					String masterPartIdSelect = UTILS.getMasterPartSelect(context, ConstantsUtil.SELECT_ID);
					String masterPartNameSelect = UTILS.getMasterPartSelect(context, ConstantsUtil.SELECT_NAME);
					String masterPartTypeSelect=UTILS.getMasterPartSelect(context, ConstantsUtil.SELECT_TYPE);
					String masterPartCurrentSelect=UTILS.getMasterPartSelect(context, ConstantsUtil.SELECT_CURRENT);
					StringList objSelects = UTILS.createSelects(ConstantsUtil.SELECT_ID,ConstantsUtil.SELECT_NAME,ConstantsUtil.SELECT_POLICY,"attribute["+ConstantsUtil.ATTRIBUTE_STAGE+"]",masterPartIdSelect, masterPartNameSelect,masterPartTypeSelect, masterPartCurrentSelect);
					String strRefPartStage = DomainConstants.EMPTY_STRING;
					Map objAndMasterMap = doObj.getInfo(context, objSelects);
					if(objAndMasterMap != null && !objAndMasterMap.isEmpty())
					{
						String masterPartId = (String)objAndMasterMap.get(masterPartIdSelect);				
						String strMasterPartType="";
						String strMasterPartPolicy  = (String)objAndMasterMap.get(ConstantsUtil.SELECT_POLICY);
						String strisFPP ="";
						if (UIUtil.isNotNullAndNotEmpty(masterPartId)){
							strMasterPartType = (String)objAndMasterMap.get(masterPartTypeSelect);
						} else {
							strMasterPartType = ConstantsUtil.TYPE_FINISHEDPRODUCTPART;
						}
						strRefPartStage = (String)objAndMasterMap.get("attribute["+ConstantsUtil.ATTRIBUTE_STAGE+"]");
						String strMasterCurrent = (String)objAndMasterMap.get(masterPartCurrentSelect);
						if(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strMasterCurrent)
								|| ConstantsUtil.STATE_COMPLETE.equalsIgnoreCase(strMasterCurrent))
						{
							if (UIUtil.isNotNullAndNotEmpty(masterPartId)) {
								 objList = getCharacteristicsList(context, masterPartId, type,
										addNewRow, strSwitchMode);
							}
							objAndMasterMap.put("Mode",strMode);
							objList = updatePathForImmediateMaster(context, objList, objAndMasterMap);
						}
					}
				}

				return objList;
			}
			
		  

			private MapList getCharacteristicsList(Context context, String objectId, String type,String addNewRow, String strSwitchMode) throws Exception {
				
				BusObjectAttribUtil UTILS = new BusObjectAttribUtil();
				String relPattern = ConstantsUtil.RELATIONSHIP_CHARACTERISTIC + "," + ConstantsUtil.RELATIONSHIP_SHARED_TABLE;
				MapList objList = new MapList();
				String typePattern = ConstantsUtil.TYPE_SHARED_TABLE + "," + type;
				StringList objectSelects = UTILS.createSelects(ConstantsUtil.SELECT_ID,ConstantsUtil.SELECT_NAME,ConstantsUtil.SELECT_TYPE,ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);

				StringList relSelects = UTILS.createSelects(ConstantsUtil.SELECT_RELATIONSHIP_ID, ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"attribute[" + ConstantsUtil.ATTR_PG_INHERITANCE_TYPE + "].value");
				DomainObject doMasterPart = DomainObject.newInstance(context,objectId);
				objList = doMasterPart.getRelatedObjects(context,
					relPattern,
					typePattern,
					objectSelects,
					relSelects,
					false,
					true,
					(short)1,
					null,
					null);

				Map mpTemp = new HashMap();
				MapList mlTemp = new MapList();
				for(int x=objList.size()-1 ; x >= 0 ; x--)
				{
					mpTemp = (Map)objList.get(x);
					String strType = (String) mpTemp.get(DomainConstants.SELECT_TYPE);

					if(strType != null && strType.equals(ConstantsUtil.TYPE_SHARED_TABLE))
					{
						String strCharType = (String) mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTTABLECHARACTERISTICTYPE);

						if(strCharType != null && !strCharType.equals(type))
						{
							objList.remove(x);
						}

					}
				}

				objList.sort(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE,"ascending", "integer");

				if (addNewRow != null && addNewRow.equals("true") && (strSwitchMode == null || "".equals(strSwitchMode)))
				{
					HashMap m = new HashMap();
					m.put(ConstantsUtil.SELECT_ID, "BLANK");
					objList.add(m);
				}

				MapList mlTempList = new MapList();
				for(int iSeq = 0 ; iSeq < objList.size() ; iSeq++)
				{
					Map mpTempList = (Map) objList.get(iSeq);
					mpTempList.put("Sequence",Integer.toString(iSeq+1));
					mlTempList.add(mpTempList);
				}
				objList.clear();
				objList.addAll(mlTempList);
				return objList;
			}

			private MapList updatePathForImmediateMaster(Context context, MapList characteristics, Map objAndMasterMap) {
				String path = "";
				try
				{
					String masterPartIdSelect = getMasterPartSelect(context, ConstantsUtil.SELECT_ID);
					String masterPartNameSelect = getMasterPartSelect(context, ConstantsUtil.SELECT_NAME);
					String strMode = (String)objAndMasterMap.get("Mode");

					String objLink = "";
					String masterLink = "";

					String partFamilyId = ConstantsUtil.EMPTY_STRING;
					String partFamilyName = ConstantsUtil.EMPTY_STRING;
					StringList slPartFamilyIdList = new StringList();
					
					if(UIUtil.isNotNullAndNotEmpty(strMode) && "PDF".equals(strMode))
					{
						objLink = (String)objAndMasterMap.get(ConstantsUtil.SELECT_NAME);
						String strMasterPFId = (String)objAndMasterMap.get(masterPartIdSelect);
						String strMasterPFName = (String)objAndMasterMap.get(masterPartNameSelect);
						if(UIUtil.isNotNullAndNotEmpty(strMasterPFId))
						{
							DomainObject doObj = DomainObject.newInstance(context, strMasterPFId);
							String classifiedItemRel = PropertyUtil.getSchemaProperty(context,"relationship_ClassifiedItem");
							slPartFamilyIdList = doObj.getInfoList(context,"to["+classifiedItemRel+"].from.id");
							slPartFamilyIdList = filterRestrictedControlClass(context, slPartFamilyIdList);
			    			if(slPartFamilyIdList != null && !slPartFamilyIdList.isEmpty()){
			    				for(Object objPFId : slPartFamilyIdList){
									partFamilyId = objPFId.toString();
									if(UIUtil.isNotNullAndNotEmpty(partFamilyId)){
										partFamilyName = (DomainObject.newInstance(context, partFamilyId)).getInfo(context, ConstantsUtil.SELECT_NAME);
							masterLink = strMasterPFName;
							String PFLink = partFamilyName;
							path = objLink + "->" + masterLink;
							if(UIUtil.isNotNullAndNotEmpty(partFamilyId))
							{
								path = PFLink + "->" + masterLink;
							}
							else
							{
								path = masterLink;
							}
									}
			    				}
			    			}
						}
					}
					else
					{
						objLink = "";
						String strMasterPFId = (String)objAndMasterMap.get(masterPartIdSelect);
						String strMasterPFName = (String)objAndMasterMap.get(masterPartNameSelect);
						if(UIUtil.isNotNullAndNotEmpty(strMasterPFId))
						{
							DomainObject doObj = DomainObject.newInstance(context, strMasterPFId);
							String classifiedItemRel = PropertyUtil.getSchemaProperty(context,"relationship_ClassifiedItem");
							slPartFamilyIdList = doObj.getInfoList(context,"to["+classifiedItemRel+"].from.id");
							slPartFamilyIdList = filterRestrictedControlClass(context, slPartFamilyIdList);
			    			if(slPartFamilyIdList != null && !slPartFamilyIdList.isEmpty()){
			    				for(Object objPFId : slPartFamilyIdList){
									partFamilyId = objPFId.toString();
									if(UIUtil.isNotNullAndNotEmpty(partFamilyId)){
										partFamilyName = (DomainObject.newInstance(context, partFamilyId)).getInfo(context, ConstantsUtil.SELECT_NAME);
							String PFLink ="";

							if(UIUtil.isNotNullAndNotEmpty(partFamilyId))
							{
								path = PFLink + "-->" + masterLink;
							}
							else
							{
								path = masterLink;
							}
									}
			    				}
			    			}
						}
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				return addPathToIndividualCharacteristics(characteristics, path);
			}
			

			private String getMasterPartSelect(Context context, String finalSelect) {
				String classifiedItemRel = PropertyUtil.getSchemaProperty(context,"relationship_ClassifiedItem");
				String partFamilyReferenceRel = PropertyUtil.getSchemaProperty(context,"relationship_PartFamilyReference");
				StringBuffer masterPartSelectBuf = new StringBuffer();
				masterPartSelectBuf.append("to[")
									.append(classifiedItemRel)
									.append("].frommid[")
									.append(partFamilyReferenceRel)
									.append("].torel.to.")
									.append(finalSelect);
				return masterPartSelectBuf.toString();
			}
			
			
			
			private MapList addPathToIndividualCharacteristics(MapList characteristics, String path) {
				return  characteristics ;
			}
			
			
			public StringList filterRestrictedControlClass(Context context, StringList slIdList)throws FrameworkException{
				StringList slFilteredIdList = new StringList();
				String strObjectType = ConstantsUtil.EMPTY_STRING;
				StringList slIPControlClassType = FrameworkUtil.split(ConstantsUtil.SECURITYCLASS_LIST, ",");
				StringList slSelectList = new StringList(ConstantsUtil.SELECT_TYPE);
				slSelectList.addElement(ConstantsUtil.SELECT_ID);
				Map mpObjectInfo = new HashMap();
				if(slIdList != null && !slIdList.isEmpty())
				{
					try {
						MapList mlObjectInfoList = DomainObject.getInfo(context, (String [])slIdList.toArray(new String[slIdList.size()]), slSelectList);
						if(mlObjectInfoList != null && !mlObjectInfoList.isEmpty())
						{
							for(Object objInfo : mlObjectInfoList)
							{
								mpObjectInfo = (Map)objInfo;
								strObjectType = mpObjectInfo.get(ConstantsUtil.SELECT_TYPE).toString();
								if(slIPControlClassType != null && !slIPControlClassType.isEmpty() && !slIPControlClassType.contains(FrameworkUtil.getAliasForAdmin(context, "type",strObjectType, false)))
								{
									slFilteredIdList.addElement(mpObjectInfo.get(ConstantsUtil.SELECT_ID).toString());
								}
							}
						}
					} catch (FrameworkException ex) {
						ex.printStackTrace();
						throw ex;
					}
				}
				return slFilteredIdList;
			}

			
			
			
			
			
			
			
			
			
			
			
}
