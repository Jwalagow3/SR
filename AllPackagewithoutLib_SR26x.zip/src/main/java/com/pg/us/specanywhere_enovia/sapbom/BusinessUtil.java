package com.pg.us.specanywhere_enovia.sapbom;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.matrixone.apps.domain.util.MapList;

import matrix.util.StringList;

public class BusinessUtil {

	
	public static StringList getIdList(MapList var0) {
		return toStringList(var0, "id");
	}

	public static StringList getRelIdList(MapList var0) {
		return toStringList(var0, "id[connection]");
	}

	public static StringList getObjectIdList(MapList var0) {
		return toStringList(var0, "objectId");
	}

	public static StringList toStringList(MapList var0, String var1) {
		StringList var2 = new StringList();
		Iterator var3 = var0.iterator();

		while (var3.hasNext()) {
			var2.add(getString((Map) var3.next(), var1));
		}

		return var2;
	}

	public static String getString(Map var0, String var1) {
		Object var2 = var0 != null ? var0.get(var1) : null;
		return var2 != null ? var2.toString().trim() : "";
	}

	public static boolean isNullOrEmpty(String var0) {
		return var0 == null || "".equals(var0.trim()) || "null".equalsIgnoreCase(var0.trim());
	}

	public static boolean isNullOrEmpty(String[] var0) {
		return var0 == null || var0.length == 0;
	}

	public static boolean isNotNullOrEmpty(String var0) {
		return !isNullOrEmpty(var0);
	}

	public static boolean isNullOrEmpty(List var0) {
		return var0 == null || var0.isEmpty();
	}

	public static boolean isNotNullOrEmpty(List var0) {
		return !isNullOrEmpty(var0);
	}

}
