package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaAPMPCompService {
	public HashMap<String, HashMap<String, Map<String, String>>> getAPMPCompdata(String objId, Environment env) throws Exception; 

}
