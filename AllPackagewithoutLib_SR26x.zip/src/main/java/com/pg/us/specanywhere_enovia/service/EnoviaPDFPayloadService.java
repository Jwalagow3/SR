package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;

import org.springframework.core.env.Environment;

public interface EnoviaPDFPayloadService {

	HashMap<String, Object> getPDFPayloaddata(Environment env, String sObjectName);

}
