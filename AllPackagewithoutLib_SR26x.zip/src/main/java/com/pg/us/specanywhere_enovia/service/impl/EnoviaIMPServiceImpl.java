/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaIMPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.PersonUtil;
import com.pg.us.specanywhere_enovia.bo.IMPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaIMPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaIMPServiceImpl implements EnoviaIMPService{

	private static Logger LOGGER = Logger.getLogger(EnoviaIMPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
	StringValidatorUtil validator = new StringValidatorUtil();

	@Override
	public HashMap<String, Map<String, String>> getIMPdata(String objId, Environment env)
			throws Exception 
	{

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("IMP SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());
		SecurityService sct = new SecurityService();
		//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
		String sUserType = sct.getUserType();
		BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
		if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
			sUserType = BObjutil.getUserView(context, objId);
		}

		IMPBO impbo = new IMPBO();
		try 
		{
			/**
			 * User Profile Section
			 * */
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpMaterialResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpHeaderResult = new HashMap<String,String>();

			BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = impbo.getIMPSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

			DomainObject dobIPM = new DomainObject(objId);
			StopWatch swInfo = new StopWatch();
			swInfo.start();
			Map resultMaps = dobIPM.getInfo(context, slContextSelects);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobIPM.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			swInfo.stop();
			LOGGER.info("IMP SERVICE GETINFO ELAPSED TIME : "+swInfo.getTime());

			/**
			 * BLOCK USER IF OBJECT IS NOT RELEASED
			 */
			if (sct.isExternalUser() || sct.isStaffAUGUser()) {
				String sState = (validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_CURRENT)))
						? (String) resultMaps.get(ConstantsUtil.SELECT_CURRENT)
								: ConstantsUtil.EMPTY_STRING;

				if ((!sState.equals(ConstantsUtil.RELEASE) && !sState.equals(ConstantsUtil.APPROVED)) && null != sState && !sState.isEmpty()) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(sState.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
			}

			//Header Content
			StopWatch sHeader = new StopWatch();
			sHeader.start();

			// Added by Jwala to send role info to Integration
			mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			// Added by Jwala to send role info to Integration


			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING));		
			mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			String sClassification = util.getClassification(resultMaps);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
			sHeader.stop();
			LOGGER.info("IMP Header ELAPSED TIME : "+sHeader.getTime());


			//Attribute Data
			mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));

			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.INTERNALMATERIAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR) : ConstantsUtil.EMPTY_STRING);
			String user = (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_OWNER)));
			String owner = PersonUtil.getFullName(context,user);
			mpAttribResult.put(ConstantsUtil.OWNER, owner);

			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.POLICY)))?(String)resultMaps.get(ConstantsUtil.POLICY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.VAULT)))?(String)resultMaps.get(ConstantsUtil.VAULT) : ConstantsUtil.EMPTY_STRING);

			String sClassFiedID=validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID) : ConstantsUtil.EMPTY_STRING;
			String sClassFiedName=validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME) : ConstantsUtil.EMPTY_STRING;
			String sMaterial = util.getMaterial(context,sClassFiedID,sClassFiedName);
			mpAttribResult.put(ConstantsUtil.MATERIALFAMILY,sMaterial); 
			String sClassifictaion = util.getClassification(resultMaps);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
			//SPEC: <13.10.2020>: Added for the Release 18x5 -- START--
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
			//SPEC: <13.10.2020>: Added for the Release 18x5 -- END

			mpAttribResult.put(ConstantsUtil.MANUFACTURER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GPSORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_MCPRF)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_MCPRF) : ConstantsUtil.EMPTY_STRING);

			/**
			 *  MATERIALS SECTION
			 * 
			 * */

			//SPEC: 05-11-2021: Added for 18x.6.0.1 DEV by Sanjeeva -- START
			if (!sUserType.equals(ConstantsUtil.PG_SP) && !sUserType.equals(ConstantsUtil.PG_CM)) 
			{
				//SPEC: 05-11-2021: Added for 18x.6.0.1 DEV by Sanjeeva -- END

				//Modified for Defect #37436 by Amman on 11/26/2020 -- START
				//mpMaterialResult = impbo.updateMaterials(context, dobIPM);
				mpMaterialResult = impbo.getMaterialComposition(context, resultMaps);
				//Modified for Defect #37436 by Amman on 11/26/2020 -- END

				mpMaterialResult = BbUtil.filterMapList(mpMaterialResult);

				//SPEC: 05-12-2021: Added in 18x.6.0.1 as per 18x.6.0 template  by Sanjeeva -- START
				mpMaterialResult.remove(ConstantsUtil.ID);
				//SPEC: 05-12-2021: Added in 18x.6.0.1 as per 18x.6.0 template  by Sanjeeva -- START

				//Added By Jwala for Defect 42077 -- START
				String strMaterial = validator.getStringEquivalentForStringList(mpMaterialResult.get(DomainConstants.SELECT_NAME));
				strMaterial = strMaterial.substring(0, strMaterial.length() -1);

				if(mpMaterialResult.size()!=1 && !(strMaterial.equalsIgnoreCase(mpHeaderResult.get(DomainConstants.SELECT_NAME)))) {
					hmAttrib.put(ConstantsUtil.MATERIALS, mpMaterialResult);
				}
				//Added By Jwala for Defect 42077 -- END
			}	

			//SPEC: 03-17-2020: Added for 18x.6 DEV by Sanjeeva -- START
			if (sUserType.equals(ConstantsUtil.PG_SP) || sUserType.equals(ConstantsUtil.PG_CM)) 
			{
				mpAttribResult.put(ConstantsUtilIRM.EXTERNALREVISIONLEVEL, ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtilIRM.EXTERNALREVISIONDATE,((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONDATE)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONDATE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtilIRM.INTERNALMATERIALNUMBER, ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALNUMBER)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALNUMBER) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtilIRM.STANDARDMATERIALNUMBER, ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER) : ConstantsUtil.EMPTY_STRING));
			}
			//SPEC: 03-17-2020: Added for 18x.6 DEV by Sanjeeva -- END

			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */
			StopWatch swReference= new StopWatch();
			swReference.start();
			MasterCOPBO mcop = new MasterCOPBO();
			mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);

			swReference.stop();
			LOGGER.info("IMP REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());

			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);

			pool.checkIn(context);
			sp.stop();
		}catch (Exception e) {
			LOGGER.error("Exception in IMP Service IMPL: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}

		//LOGGER.info("IPM SERVICE RESPONSE MESSAGE:: \n" + hmAttrib);
		context.close();
		return hmAttrib;


	}

}
