/**
 * Project 		: SpecsAnywhere
 * Program 		: MasterPackagingAssemblyPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;


import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;

import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;


import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;


public class MasterPackagingAssemblyPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(MasterPackagingAssemblyPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();

	public MasterPackagingAssemblyPartBO() {
		// empty constructor
	}

	public MasterPackagingAssemblyPartBO(String oid) {
		this.setObjectId(oid);
	}


	/**
	 * Method Name 			: getPAPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getPAPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getPAPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public DomainObject getPAPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getMPAPPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getMPAPPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getFileSelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}


	/**
	 * Method Name 			: getMPAPRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getMPAPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}


	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_CONNECTION_ID);
		busSelect.add(ConstantsUtil.SELECT_PARENT);
		busSelect.add(ConstantsUtil.SELECT_LEVEL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);

		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPOSTCOSUMERRECYCLEDCONTENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
		busSelect.add(ConstantsUtil.STR_IPCLASS);

		return busSelect;
	}


	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END

		return relSelect;
	}


	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);

		busSelect.add(ConstantsUtil.strSegment);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.STRPGPDTTOPGPLIREFUN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_TITLE);
		busSelect.add(ConstantsUtil.SELECT_STR_SEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONLENGTH);


		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROJECTINITIATIVEMILESTONE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		return busSelect;

	}

	/** 
	 * Method Name 			: formatData
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context,MapList mapList) 
	{
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMTupName= new StringBuilder();

		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDUOM = new StringBuilder();

		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		//SPEC: 10/12/2020: Added for 18x.5 DEV -- END

		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END

		SecurityService sct = new SecurityService();
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			String sId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ID)));
			String sName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_NAME)));
			String sRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_REVISION)));
			String sReleaseDate = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
			String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			String spgChg = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE)));
			String sFN = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER)));
			String sTitle = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
			String sType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_TYPE)));
			String sTupName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.TUPNAME)));

			String sQty = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY)));
			String sBuom = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)));
			String sComments = validator.getStringEquivalentForStringListWithSpecialChar((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)));
			String sCurrent = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_CURRENT)));
			String sStage = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)));
			String sRD = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR)));
			sRD = util.replaceSpecialSymbols(sRD);
			String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));

			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
			String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
			strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strAltID = util.checkAlternateHasAccess(context,objectMap);	
			String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
			strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			String strOSPD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
			String strDUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
			//SPEC: 10/12/2020: Added for 18x.5 DEV -- START
			
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
			String sParentId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID)));
			String sParentName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME)));
			String sParentRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV)));
			String sParentType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE)));
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END

			boolean showData = false;
			boolean bHasOwnership=false;
			boolean bHasOwnershipParent = false;
			boolean showDataParent = false;
			String sUserlicense = sct.getUserLicense();
			String sOC = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT)));
			sOC = util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;


			if(util.isModificatinRequired())
			{
				bHasOwnership = util.checkHasAccess(context, null, sId);

				if(!bHasOwnership)
				{
					spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;

				}
				bHasOwnershipParent=util.checkHasAccess(context, null, sParentId);
				if(!bHasOwnershipParent) {
					sParentId = ConstantsUtil.NO_ACCESS;
				}
			}
			else if(sct.isStaffAUGUser()) {
				showData = util.checkHasAccess(context, null, sId);
				showDataParent=util.checkHasAccess(context, null, sParentId);
				
			} else{
				showData = util.checkHasAccess(context, null, sId);
				showDataParent=util.checkHasAccess(context, null, sParentId);
			}
			//Added by Pooja for 22x Defect 50443
			
			if(!util.isModificatinRequired()) {
				if(!showData){
					spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
				}
				if(!showDataParent) {
					sParentId = ConstantsUtil.NO_ACCESS;
				}
			}
			sType = util.mapType(sType);
			sParentType = util.mapType(sParentType);
			//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 12, 2021 -- START
			sCurrent = util.mapType(sCurrent);
			//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 12, 2021 -- END
			// Security req -33193 HIR Components Attributes to Show
			formatData(sbEBOMType,sType);
			formatData(sbEBOMName,sName);
			formatData(sbEBOMQTY,sQty);
			formatData(sbEBOMBuom,sBuom);
			formatData(sbEBOMState,sCurrent);

			formatData(sbEBOMId,sId);
			formatData(sbEBOMChg,spgChg);
			formatData(sbEBOMFN,sFN);
			formatData(sbEBOMTitle,sTitle);

			formatData(sbEBOMCommnts,sComments);
			formatData(sbEBOMStage,sStage);
			formatData(sbEBOMRDOC,sRDOC);
			formatData(sbEBOMRevRelDt,sRevRelease);
			//SPEC: 10/12/2020: Added for 18x.5 DEV -- START

			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//formatData(sbEBOMAlt, strAlt);
			formatData(sbAltName,strAltName);
			formatData(sbAltID,strAltID);
			formatData(sbAltType,strAltType);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			formatData(sbEBOMOSPD, strOSPD);
			formatData(sbEBOMDUOM, strDUOM);
			//SPEC: 10/12/2020: Added for 18x.5 DEV -- END

			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
			util.formatData(sbEBOMSubstitutePart, strSubPart);
			util.formatData(sbEBOMSubPartID, strSubPartId);
			util.formatData(sbEBOMSubPartType, strSubPartType);
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
			
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
			formatData(sbEBOMParentId,sParentId);
			formatData(sbEBOMParentName,sParentName);
			formatData(sbEBOMParentRevision,sParentRevision);
			formatData(sbEBOMParentType,sParentType);
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END

			if(null!=sTupName && !sTupName.isEmpty()) {
				formatData(sbEBOMTupName,sTupName);
			}

		}
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());

		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlt.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());		
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDUOM.toString());	


		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END

		return mpEBOMResult;
	}

	public Map updatePartSpec(Context context, Map objectMap) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
					? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

			mpPartSpecs = getPartSpecifications(context, sType, sID);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : MasterPackagingAssemblyPartBO Method :updatePartSpec " + e);
			return new HashMap();

		}
		return util.filterMapList(mpPartSpecs);
	}


	public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();

		StringBuilder sbDescription = new StringBuilder();
		StringBuilder sbInHerType = new StringBuilder();
		boolean showData = false;

		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;

		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
			sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		}

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		//if (util.isModificatinRequired()) {
		//sWhere = "current==Release";

		StringBuilder sbwhere= new StringBuilder();
		sbwhere.append("(current == Release)");
		sbwhere.append("||");
		sbwhere.append("(current == RELEASED)");
		//}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();

		StringList slRelSelects = new StringList();
		slRelSelects.add(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
					slPartSpecSelects, slRelSelects, false, true, (short) 1, sbwhere.toString(), ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));

				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strDescription = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_DESCRIPTION));

				//SPEC: 10/30/2020: Added for Defect 36711  -- START
				if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)){
					strDescription = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYDESCRIPTION));
				}
				//SPEC: 10/30/2020: Added for Defect 36711  -- END

				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));

				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));

				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);

				String strInHerType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE));


				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}

				showData = util.checkHasAccess(context, sUserType, strId);
				if (showData) {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
					//Modified for Defect #36710 -- START
					sbDescription.append(strDescription).append(ConstantsUtil.SYMBL_PIPE);
					String strTitle = validator.getStringEquivalentForSubstituteString(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_VPMREFERENCE)){
						strTitle = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PLMENTITYVNAME));
					}
					//Modified for Defect #36710 -- END
					sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
					String strOrig = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
					sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
					//temporary fix to prevent users from downloading a Physical product(VPMReference)
					if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
						sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
					}else {
						sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
					}

					sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);

				} else {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

				}
				//Added by Ganesh Stop

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			//Modified for Defect #36710 -- START
			//mpFinalList.put(ConstantsUtil.DESCRIPTION, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			//Modified for Defect #36710 -- END
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());

			mpFinalList.put(ConstantsUtil.INHERITANCETYPE, sbInHerType.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Exception in MasterPackagingAssemblyPartBO getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}
	//SPEC: 10/12/2020: Added for 18x.5 DEV -- END

	/**
	 * Method Name 			: addMultiSelects
	 * Method Description 	: 
	 */
	public StringList addMultiSelects() {
		StringList slMultiSelects = new StringList();
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		
		return slMultiSelects;
		
	}
	/**
	 * Method Name 			: removeMultiSelects
	 * Method Description 	: For removing the multiselects from DomainCOnstants
	 */
	public void removeMultiSelects()
	{
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
	}


}
