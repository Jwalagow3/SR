package com.pg.us.specanywhere_enovia.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import com.microsoft.azure.storage.blob.CloudBlobContainer;

public class AzureService {
				
	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(AzureService.class);

	public void ResponseEntity (String file,String strUnhashedFileName,String container, String connectionString) {
		
		InputStream stream = null;
		Properties properties = new Properties();
		stream = AzureService.class.getClassLoader().getResourceAsStream("CATIAAPP.properties");
		try {
			properties.load(stream);
		} catch (IOException exp) {
			logger.error("Exception for properties file AzureService: ResponseEntity:" + exp);
		}
		String localfilestorage = properties.getProperty("AZURE_FILE_DOWNLOAD_PATH");
		logger.info("1. localfilestorage:"+localfilestorage);
		File file1 = new File(localfilestorage);
		if (!file1.isDirectory())
			file1.mkdirs();

		try {
			if (file == null) {
				throw new Exception("File Path not present");
			} else {
				logger.info("2. Before getFileDetails:..................strUnhashedFileName:"+strUnhashedFileName);
				String filestoBeDownloaded = getFileDetails(strUnhashedFileName, localfilestorage,file,container,connectionString);
				logger.info("3. After getFileDetails:..................filestoBeDownloaded:"+filestoBeDownloaded);
				HttpHeaders headers = new HttpHeaders();
				headers.setContentDisposition(
						ContentDisposition.parse("attachment; fileName=\"" + strUnhashedFileName + "" + "\""));
				InputStreamResource resource = null;
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(filestoBeDownloaded);
					resource = new InputStreamResource(fis);

				} catch (FileNotFoundException e) {
					e.getMessage();
				}
				//Subhajit Added for defect 45181 - Start
				if(fis!=null) {
					fis.close();
				}
				//Subhajit Added for defect 45181 - End
				List<String> str = new ArrayList<String>();
				str.add("fileName");
				headers.add(ConstantsUtilIRM.STR_FILENAME, strUnhashedFileName);
				headers.setAccessControlExposeHeaders(str);
				System.out.println(ResponseEntity.ok().headers(headers)
						.body(resource));
			}
		} catch (Exception exp) {
			logger.error("Exception in AzureService: ResponseEntity:" + exp);
		} finally {
			//Subhajit Added for defect 45181 - Start
			try {
				if(stream != null) {
					stream.close();	
				}
			} catch (IOException e) {
				logger.error("Exception in AzureService: ResponseEntity: IOException" + e);
			}
			//Subhajit Added for defect 45181 - End
		}
	}
	
public String getFileDetails(String file,String localfilestorage,String strFullHashedPath,String container,String connectionString) {
		ZipOutputStream zipStream = null;
		FileOutputStream fos=null;
		//String strHashedPath
		String 	path= localfilestorage+file+".zip";
		HashMap<String,String> fileMap= new HashMap<String,String>();
		
		if (file != null && file.length() > 1) {
			for (int i = 0; i < file.split("\\|").length; i++) {
				String fileName = file.split("\\|")[i];
				fileMap.put(fileName, strFullHashedPath);

			}
		}
		logger.info("getFileDetails.............fileMap:"+fileMap);
		
		if(fileMap!=null && fileMap.size()== 0)
		{
		     logger.info("No File Exists at path"+path);
		     path=null;
		     return null;
					
		}
		if(fileMap!=null && fileMap.size() ==1)
		{
			//path variable should have local path with actual file name, not hash name.
			
			path=localfilestorage+fileMap.keySet().stream().findFirst().orElse(null);
			logger.info("2.2. Before getFilesFromAzureStorage..................local path:"+path);
			//localfilestorage will have just local path. azurePath will have azure path as a return.
			String azurePath = getFilesFromAzureStorage(fileMap.get(fileMap.keySet().stream().findFirst().orElse(null)),localfilestorage,container,connectionString);
			logger.info("2.4. After getFilesFromAzureStorage..................azurePath:"+azurePath);
			if(azurePath==null) 
	        {
				path=null;
	        }
			try {
				logger.info("2.5. before makeFilesForAzure");
				fos = makeFilesForAzure(fileMap, path,azurePath,localfilestorage);
				logger.info("2.6. after makeFilesForAzure");
				if(fos==null)
				{
					logger.info("No File Exists at path"+path);
					path=null;
				}
			} catch (IOException e) {
				logger.error("Exception in AzureService: makeFilesForAzure method call:" + e);
			}
		}else
		{
			try {
				logger.info("2.7. before makeZipForFilesAzureDownload");
				zipStream = makeZipForFilesAzureDownload(fileMap,path,localfilestorage,container,connectionString);
				logger.info("2.7. after makeZipForFilesAzureDownload");
				if(zipStream==null)
				{
					logger.info("No File Exists for zipping in path"+path);
					path=null;
				}
						
			} catch (IOException e) {
				logger.error(e.toString());
			}
		}
		
		//Subhajit Added for defect 45181 - Start
		try {
			if(fos != null) {
				fos.close();
			}
		} catch (IOException e) {
			logger.error("Exception in AzureService: getFileDetails: IOException" + e);
		}
		
		try {
			if(zipStream != null) {
				zipStream.close();
			}
		} catch (IOException e) {
			logger.error("Exception in AzureService: getFileDetails: IOException" + e);
		}
		//Subhajit Added for defect 45181 - End
		
		return path;
	}
		
		public static FileOutputStream makeFilesForAzure(HashMap<String, String> fileMap, String path, String azurePath,
				String localstorage) throws IOException {
			if (path != null) {
				String filename = getFileName(azurePath);
				FileOutputStream fileOS = new FileOutputStream(path);
				try {

					for (Map.Entry<String, String> pair : fileMap.entrySet()) {
						File fileToZip = new File(localstorage + filename);

						logger.info("Zip file exisit"+fileToZip.exists());
						if (fileToZip.exists()) {
							try (FileInputStream inputStream = new FileInputStream(fileToZip)) {
								byte data[] = new byte[1024];
								int byteContent;
								while ((byteContent = inputStream.read(data, 0, 1024)) != -1) {
									fileOS.write(data, 0, byteContent);
								}

							} catch (IOException e) {
								logger.error("Error with makeFilesForAzure :FileInputStream"+e);
							}
						} else {
							return null;
						}
					}

				} catch (Exception e) {
					logger.error("Error with AzureService: makeFilesForAzure ::"+e);

				} finally {
					if(fileOS!=null)
					fileOS.close();
				}
				return fileOS;
			} else {
				return null;
			}
		}

public ZipOutputStream makeZipForFilesAzureDownload(Map<String, String> fileMap, String path,String localfilestorage,String container,String connectionString)throws IOException {
	FileOutputStream fos = new FileOutputStream(path);

	ZipOutputStream zipOut = new ZipOutputStream(fos);
	boolean ifAnyFileExists = false;
	try {

		for (Map.Entry<String, String> pair : fileMap.entrySet()) {
			String azurepath=getFilesFromAzureStorage(pair.getValue(),localfilestorage,container,connectionString);
			if(azurepath!=null) {
			String filename = getFileName(azurepath);
			File fileToZip = new File(localfilestorage + filename);
			if (fileToZip.exists()) {
				ifAnyFileExists = true;
				FileInputStream fis = new FileInputStream(fileToZip);
				try {
					ZipEntry zipEntry = new ZipEntry(pair.getKey());
					zipOut.putNextEntry(zipEntry);
					byte[] bytes = new byte[1024];
					int length;
					while ((length = fis.read(bytes)) >= 0) {
					zipOut.write(bytes, 0, length);
				}
				}catch(Exception ex){
					logger.error("FileInputStream error"+ex);
				} finally {
					fis.close();
				}
			}

		}
		}

	} catch (Exception e) {
		logger.error("Error with AzureService: makeZipForFilesAzureDownload ::"+e);

	} finally {
		if(zipOut!=null)
			zipOut.close();
			if(fos!=null)
			fos.close();
	}
	if (ifAnyFileExists)
		return zipOut;
	else
		return null;

}

private static String getFileName(String azurePath) {
	Path path = Paths.get(azurePath);
	if (path != null) {
		Path filePathName = path.getFileName();
		if (filePathName != null)
			return filePathName.toString();
	}
	return "";
}


	public  String	getFilesFromAzureStorage(String fileName,String localfilestorage,String container,String connectionString)
	{
		AzureStorageUtil azureStorageUtils= new AzureStorageUtil();
		
		CloudBlobContainer blobContainer = azureStorageUtils.getCloudBlobContainer(connectionString, container);
		String blobfiles=azureStorageUtils.downloadBlobFilesUsingCloudBlobClient(fileName, blobContainer,localfilestorage);
		
		
		if(blobfiles!=null)
			return fileName;
		else
			return blobfiles;
	}

}

