package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaListVendorService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaListVendorServiceImpl implements EnoviaListVendorService{
	
	private static Logger LOGGER = Logger.getLogger(EnoviaListVendorServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	
	
	@Override
	public HashMap<String, Map<String, String>> getVendorList(Environment env, Map<String, Object> vendorDetails) throws Exception
	{
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		List<Map<String, String>> vendorArray = (List<Map<String, String>>)vendorDetails.get(ConstantsUtilIRM.VENDORS);
		Context context = pool.checkOut();
		StopWatch sp = new StopWatch();
		sp.start();
		
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbstrVendorName	 =  new StringBuilder();
		StringBuilder sbVendorId =  new StringBuilder();
		StringBuilder sbInActiveVendors =  new StringBuilder();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		Map<String,String> mVendorList = new HashMap<String, String>();
		Boolean bInactiveCheck = false;
		
		StringList slVendorSelectables = new StringList();
		slVendorSelectables.add(DomainConstants.SELECT_NAME);
		slVendorSelectables.add(DomainConstants.SELECT_CURRENT);
		Map<?, ?> mpVendorInfo = new HashMap<>();
		String strVendorName = DomainConstants.EMPTY_STRING;
		String strCurrent = DomainConstants.EMPTY_STRING;
		StringList sLVendorName= new StringList();
		try {
			for(int i =0; i< vendorArray.size();i++){
			     Map<String, String>  vendorMap= vendorArray.get(i);
			     String vendorId = vendorMap.get(ConstantsUtilIRM.ID);
				 //Modified by Ajay for 22x.06 Defect-10120 - START
			     if(UIUtil.isNotNullAndNotEmpty(vendorId)) {
			    	 DomainObject dovendor = DomainObject.newInstance(context, vendorId);
				     mpVendorInfo=dovendor.getInfo(context, slVendorSelectables);
				     strVendorName= (String)mpVendorInfo.get(ConstantsUtilIRM.SELECT_NAME);
				     strCurrent= (String)mpVendorInfo.get(ConstantsUtilIRM.SELECT_CURRENT);
				     if(strVendorName.endsWith(ConstantsUtilIRM.PLANT_NAME)){
				    	 strVendorName=strVendorName.substring(0,strVendorName.length()-ConstantsUtilIRM.PLANT_NAME.length()-1); 
				     }
				     if(strCurrent.equals(ConstantsUtilIRM.STATE_ACTIVE) && !sLVendorName.contains(strVendorName)) {
				    	 util.formatData(sbVendorId, vendorId);
					     util.formatData(sbstrVendorName, strVendorName);
				     }
				     else if(!strCurrent.equals(ConstantsUtilIRM.STATE_ACTIVE) && !sLVendorName.contains(strVendorName)){
				    	 sbInActiveVendors.append(strVendorName);
				    	 sbInActiveVendors.append(ConstantsUtilIRM.COMMA_SPACE);
				    	 bInactiveCheck = true;
				     }
				     sLVendorName.add(strVendorName);
			     	}
			     
			     
				}
			
				if(UIUtil.isNotNullAndNotEmpty(sbVendorId.toString())) {
					mVendorList.put(ConstantsUtilIRM.ID, sbVendorId.toString());
					mVendorList.put(ConstantsUtilIRM.VENDOR_NAME, sbstrVendorName.toString());
					if(bInactiveCheck) {
						String sInActiveVendors=ConstantsUtilIRM.INACTIVE_PLANT_MESSAGE.concat(ConstantsUtil.EMPTY_SPACE).concat(sbInActiveVendors.toString());
						mVendorList.put(ConstantsUtilIRM.INACTIVEVENDORS,sInActiveVendors.substring(0,sInActiveVendors.length()-ConstantsUtilIRM.COMMA_SPACE.length()));
						
					}
					//Modified by Ajay for 22x.06 Defect-10120 - END
					
				}
				hmAttrib.put(ConstantsUtilIRM.VENDORS, mVendorList);
				
				pool.checkIn(context);
				sp.stop();
				LOGGER.info("VENDOR LIST MESSAGE ELAPSED TIME:: "+sp.getTime());
				LOGGER.info("VENDOR LIST RESPONSE MESSAGE:: \n" + hmAttrib);
			
		}catch (Exception e) {
			LOGGER.error("Exception in Vendor List Service IMPL: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		context.close();
		return hmAttrib;
	}
	

}
