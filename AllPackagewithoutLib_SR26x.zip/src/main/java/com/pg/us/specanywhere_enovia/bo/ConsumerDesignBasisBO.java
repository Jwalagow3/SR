/**
 * Project 		: SpecsAnywhere
 * Program 		: ConsumerDesignBasisBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.FileUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class ConsumerDesignBasisBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(ConsumerDesignBasisBO.class);
	
	public ConsumerDesignBasisBO() {
		// empty constructor
	}
	
	public ConsumerDesignBasisBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getCDBBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getCDBBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getCDBDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getCDBDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}
	
		
	/**
	 * Method Name 			: getConsumerDesignBasisSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getConsumerDesignBasisSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getPlantSelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID); 
		
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS); 
		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSECTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBSECTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGLOBALFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPH_BRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORMDETAIL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPHCATEGORY);
		
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNODEID);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.REFRECNE_DOCUMENT_TYPE);
		busSelect.add(ConstantsUtil.REFRECNE_DOCUMENT_NAME);
		busSelect.add(ConstantsUtil.STR_REFERENCE_DOC_REV);
		busSelect.add(ConstantsUtil.STR_REFERENCE_DOC_ID);
		
		return busSelect;
	}
	
	
	/**
	 * Method Name : getPlantSelects
	 * Method Description : Fetching "Plant" related information
	 * @param context
	 * @return
	 */
	public static StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		
		return busSelect;
	}
	/**
	 * Method Name : getRefDocs
	 * Method Description : Added for defect 36852
	 * @param context
	 * @return
	 */
	
	public Map getRefDocs(Context context, Map resultMaps) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();
		CommonDocBO commonDoc = new CommonDocBO();
		FileUtil fileUtil = new FileUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);

		boolean bHasOwnerShip = false;

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();

		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}
		String sObjectId = validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		Map<String, String> mpRefDoc = new HashMap();

		String objectWhere = "((name ~~RF_* || name ~~DF_* || name ~~QEC_* || name ~~LR_* || name ~~IMG_*) && (revision != Rendition))";

		if (util.isModificatinRequired()) {
			objectWhere = "((name ~~LR_*) && (revision != Rendition))";
		}

		try {
			DomainObject dobCdoc = new DomainObject(sObjectId);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1, objectWhere,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobCdoc.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if (util.isModificatinRequired()) {
				mlRelatedSpecs = util.filterPhase(mlRelatedSpecs);
			}
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbDispType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbDescription = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			StringBuilder sbGendocName = new StringBuilder();
			StringBuilder sbGendocPath = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
			// : 02-08-2021 -- START
			StringBuilder sbIsIRM = new StringBuilder();
			StringBuilder sbGendocFormat = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
			// : 02-08-2021 -- END
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sLangName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);

				String sName = (String) objectMap.get(ConstantsUtil.STR_FILE_NAME);
				String sCSSType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
				String Display_Type = "";

				String strClassFied = validator
						.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				StringList eachOwnership = validator
						.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				
				// SPEC: Added for 18x.5.2 DEV --Shashank -- START
				Map mpFiles = new HashMap();
				DomainObject doRefDoc = new DomainObject(sId);
				boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
				String sGendocName="";
				String sGendocPath="";
				// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments
				// On : 02-08-2021 -- START
				String sGendocPathFormat = "";
				// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments
				// On : 02-08-2021 -- END
				if(bisIRMDoc) {
					mpFiles=fileUtil.getGendocForIRM(context, doRefDoc);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
				}else {
					// SPEC: Modified for 18x.5.2 DEV -- Guna For ReferenceDocuments
					// On : 02-08-2021 -- START
					//mpFiles=fileUtil.getGendocForReferenceDocuments(context, doRefDoc);
					mpFiles = fileUtil.getFilesForIPM(context, doRefDoc);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					sGendocPathFormat = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
					// SPEC: Modified for 18x.5.2 DEV -- Guna For ReferenceDocuments
					// On : 02-08-2021 -- START
				}
				// SPEC: Added for 18x.5.2 DEV --Shashank -- END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doRefDoc.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- START
				if(bisIRMDoc){
					sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- END
				
				if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
					continue;
				}
				if (!sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR)) {
					String sLangBuffer = ConstantsUtil.EMPTY_STRING;
					if (sLangName.contains("LR_*"))
						sLangBuffer = sRev;
					else
						sLangBuffer = "";

					if ("Reference File".equalsIgnoreCase(sCSSType)  || "Reference_File".equalsIgnoreCase(sCSSType)) {

						Display_Type = "Reference File";

					} else if ("QEC_File".equalsIgnoreCase(sCSSType) ) {
						Display_Type = "Quality Evolution Chart File";

					} else if ("QEC File".equalsIgnoreCase(sCSSType) ) {
						Display_Type = "QEC File";

					}
					else if ("Design_File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Design File";

					} else if ("Language_Rendition".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Language Rendition";

					} else if ("Image File".equalsIgnoreCase(sCSSType)) {
						Display_Type = "Image File";
					}

					/*if (util.isModificatinRequired()) {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) {
							util.formatData(sbType, util.mapType(sType));
							util.formatData(sbDispType, Display_Type);
							util.formatData(sbName, sName);
							util.formatData(sbDescription, sDesc);
							util.formatData(sbCurrent, sCurrent);
							util.formatData(sbId, sId);
							util.formatData(sbRev, sRev);
							util.formatData(sbTitle, sTitle);
							util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
							util.formatData(sbLangBuffer, sLangBuffer);

						}
					} else {
						boolean showData = true;
						if (sIPClassfication.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED)) {
							SecurityService sct = new SecurityService();
							String sUserlicense = sct.getUserLicense();
							if (null != sUserlicense && null != strClassFied && !sUserlicense.contains(strClassFied)) {
								showData = false;
							}

							if (showData) 
							{
								util.formatData(sbType, util.mapType(sType));
								util.formatData(sbDispType, Display_Type);
								util.formatData(sbName, sName);
								util.formatData(sbDescription, sDesc);
								util.formatData(sbCurrent, sCurrent);
								util.formatData(sbId, sId);
								util.formatData(sbRev, sRev);
								util.formatData(sbTitle, sTitle);
								util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
								util.formatData(sbLangBuffer, sLangBuffer);
							}
						} else 
						{
							util.formatData(sbType, util.mapType(sType));
							util.formatData(sbDispType, Display_Type);
							util.formatData(sbName, sName);
							util.formatData(sbDescription, sDesc);
							util.formatData(sbCurrent, sCurrent);
							util.formatData(sbId, sId);
							util.formatData(sbRev, sRev);
							util.formatData(sbTitle, sTitle);
							util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
							util.formatData(sbLangBuffer, sLangBuffer);
						}
					}*/
					//Added by Ganesh Start
					//SPEC: <19.03.2021>: Guna Added for Req 38530 Dev 18x.6   -- START
					sType =Display_Type;
					//SPEC: <19.03.2021>: Guna Added for Req 38530 Dev 18x.6   -- END
					boolean showData = util.checkHasAccess(context, null, sId);
					if (showData) 
					{
						util.formatData(sbType, util.mapType(sType));
						util.formatData(sbDispType, Display_Type);
						util.formatData(sbName, sName);
						util.formatData(sbDescription, sDesc);
						util.formatData(sbCurrent, sCurrent);
						util.formatData(sbId, sId);
						util.formatData(sbRev, sRev);
						util.formatData(sbTitle, sTitle);
						util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbLangBuffer, sLangBuffer);
						util.formatData(sbGendocName, sGendocName);
						util.formatData(sbGendocPath, sGendocPath);
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, sGendocPathFormat);
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
					}
					//Added by Ganesh Stop
				}// close if condition for Perform Char
			}
			mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
			mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpRefDoc.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
			mpRefDoc.put(ConstantsUtil.DISPLAY_TYPE, sbDispType.toString());
			mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLangBuffer.toString());
			mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
			// : 02-08-2021 -- START
			mpRefDoc.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
			// : 02-08-2021 -- END
		} catch (Exception e) {

			LOGGER.error("Exception in Program : FormulaCardBO Method :updateRefDocs " + e);
			return new HashMap();
		}

		return mpRefDoc;
	}

	
	/**
	 * Method Name 			: updateRefDocs
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
	
	public Map<String, String> updateRefDocs(Map objectMap) {
		StringBuilder sLangBuffer = new StringBuilder();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpRefDoc = new HashMap();

		String sType    =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_TYPE));
		String sName    =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_NAME));
		String sId=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_ID));
		String sRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_REV));
		
		String[] saName = sName.split(ConstantsUtil.SYMBL_COMMA);
		String[] saRev= sRev.split(ConstantsUtil.SYMBL_COMMA);
		String[] saType = sType.split(ConstantsUtil.SYMBL_COMMA);
		
		StringList slTypes= util.MapsType(saType);
		sType=util.replaceSpecialSymbols(slTypes.toString());
		sName=util.replaceSpecialSymbols(sName);
		sType=util.replaceSpecialSymbols(sType);
		sId = util.replaceSpecialSymbols(sId);
		
		for(int i=0 ;i<saName.length;i++)
		{
			String	sTempName = saName[i];
			String	sTempRev = saRev[i];
			
			if(sTempName.contains(ConstantsUtil.STR_LR_MATCHCASE)){
				sLangBuffer.append(sTempRev).append(ConstantsUtil.SYMBL_PIPE);
			}else{
				sLangBuffer.append(ConstantsUtil.EMPTY_STRING).append(ConstantsUtil.SYMBL_PIPE);
			}
		}
		
		mpRefDoc.put(ConstantsUtil.ID, sId);
		mpRefDoc.put(ConstantsUtil.NAME, sName);
		mpRefDoc.put(ConstantsUtil.TYPE, sType);
		mpRefDoc.put(ConstantsUtil.LANGUAGE, sLangBuffer.toString());

		return mpRefDoc;
	}

	
	/**
	 * Method Name 			: updatePerformSpecs
	 * Method Description 	: 
	 * @param dobCDB
	 * @param context
	 * @return
	 */
	public Map<String, String> updatePerformSpecs(DomainObject dobCDB,Context context) {
		Map mpPerform = new HashMap();
		StringList busSelect = new StringList();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringBuilder sbChg = new StringBuilder();
		StringBuilder sbconNeed = new StringBuilder();
		StringBuilder sbChar = new StringBuilder();
		StringBuilder sbCS = new StringBuilder();
		StringBuilder sbDSImpct = new StringBuilder();
		StringBuilder sbLang = new StringBuilder();
		StringBuilder sbParamType = new StringBuilder();
		StringBuilder sbArea = new StringBuilder();
		StringBuilder sbComment = new StringBuilder();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERNEED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDESIGNIMPACT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERCOMMENTLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPARAMETERTYPE); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAREA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT); 
		try {
			MapList mlPerformChars = dobCDB.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EXTENDEDDATA,ConstantsUtil.TYPE_PGPRODUCTQUALITYCHARACTERISTIC+","+ConstantsUtil.TYPE_PGPRODUCTQUALITYCHARACTERISTIC+","+ConstantsUtil.TYPE_PGPACKAGEQUALITYCHARACTERISTIC, busSelect, null, false, true, (short) 0, null, null, 0);

			if(mlPerformChars.isEmpty()){
				return new HashMap();
			}
			Iterator objectListItr = mlPerformChars.iterator();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();

				String sChg =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sConNeed =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERNEED);
				String schar =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC);
				String sCS =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS);
				String sDSImpct =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDESIGNIMPACT);
				String sLang =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERCOMMENTLANGUAGE);
				String sParamType =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPARAMETERTYPE);
				String sPGArea=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAREA);
				String sComment=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

				util.formatData(sbChg,sChg);
				util.formatData(sbconNeed,sConNeed);
				util.formatData(sbChar,schar);
				util.formatData(sbCS,sCS);
				util.formatData(sbDSImpct,sDSImpct);
				util.formatData(sbLang,sLang);
				util.formatData(sbParamType,sParamType);
				util.formatData(sbArea,sPGArea);
				util.formatData(sbComment,sComment);

				mpPerform.put(ConstantsUtil.CHG, sbChg.toString());
				mpPerform.put(ConstantsUtil.CONNEED, sbconNeed.toString());
				mpPerform.put(ConstantsUtil.CHAR, sbChar.toString());
				mpPerform.put(ConstantsUtil.CS, sbCS.toString());
				mpPerform.put(ConstantsUtil.DSIMPACT, sbDSImpct.toString());
				mpPerform.put(ConstantsUtil.LANGUAGE, sbLang.toString());
				mpPerform.put(ConstantsUtil.PARAMTYPE, sbParamType.toString());
				mpPerform.put(ConstantsUtil.AREA, sbArea.toString());
				mpPerform.put(ConstantsUtil.COMMENTS, sbComment.toString());


			}

		} catch (FrameworkException e) {
			LOGGER.error("Unable to get the  updatePerformSpecs from ConsumerDesignBasisBO"+e);
			return new HashMap();
		}
		return mpPerform;

	}

	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	: 
	 */
	public void addMultiList(){
		
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REFRECNE_DOCUMENT_TYPE);
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REFRECNE_DOCUMENT_NAME);
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_REFERENCE_DOC_REV); 
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_REFERENCE_DOC_ID);
	}

	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	: 
	 */
	public  void removeMultiList(){
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REFRECNE_DOCUMENT_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REFRECNE_DOCUMENT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_REFERENCE_DOC_REV);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_REFERENCE_DOC_ID);

	}

}