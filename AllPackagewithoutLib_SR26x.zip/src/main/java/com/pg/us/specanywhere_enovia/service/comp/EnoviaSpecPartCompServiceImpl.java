package com.pg.us.specanywhere_enovia.service.comp;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaAPMPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaARMPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaCOPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaCUPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaCommonDocCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaCommonDocService;
import com.pg.us.specanywhere_enovia.service.EnoviaFABCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaOPPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaPackagingAssemblyPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSWPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaSpecPartCompService;
import com.pg.us.specanywhere_enovia.service.PromotionalItemPartCompService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaRMPServiceImpl;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaSpecPartCompServiceImpl implements EnoviaSpecPartCompService {
	
	private static Logger LOGGER = Logger.getLogger(EnoviaRMPServiceImpl.class);
	
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	
	@Autowired
	private EnoviaConnectionPool pool;
	
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private EnoviaPMPPartCompService pmp;
	
	@Autowired
	private EnoviaRMPPartCompService rmpcomp;
	
	@Autowired
	private EnoviaPackagingAssemblyPartCompService papcomp;
	@Autowired
	private EnoviaFABCompService fabcomp;
	
	@Autowired
	private EnoviaFPPCompService fppcomp;
	
	@Autowired
	private EnoviaCommonDocCompService commondoccmp;

	@Autowired
	private EnoviaARMPCompService armpcomp;
	
	@Autowired
	private PromotionalItemPartCompService pipcomp;
	
	@Autowired
	private EnoviaAPMPCompService apmpcomp;
	
	@Autowired
	private EnoviaSWPCompService swpcomp;
	
	@Autowired
	private EnoviaOPPCompService oppcomp;
	
	@Autowired
	private EnoviaCUPCompService cupcomp;
	
	@Autowired
	private EnoviaCOPCompService copcomp;
	
	@Override
	public HashMap<String, HashMap<String, Map>> getSpecPartCompData(String sObjectName,
			Environment env) {
		HashMap<String, HashMap<String, Map<String, String>>> hmMap = new HashMap<String, HashMap<String, Map<String, String>>>();
		HashMap<String, HashMap<String, Map>> hmAttrib = new HashMap<String,HashMap<String, Map>>();
		HashMap<String, Map> hmMapEmpty = new HashMap<String, Map> ();
		Map<String,String> mpMess = new HashMap<String,String>();
		
		StringValidatorUtil validator = new StringValidatorUtil();
		StopWatch sp = new StopWatch();
		sp.start();
		
		Context context = null;
		try {
			
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			swContext.stop();
			
			MapList mlObjectList = new MapList();
			StringList slObjectsSelect = new StringList();
			slObjectsSelect.add(DomainConstants.SELECT_ID);
			slObjectsSelect.add(ConstantsUtilIRM.CURRENT_RELEASE_LASTID);
			slObjectsSelect.add(ConstantsUtilIRM.CURRENT_RELEASE_LASTSTATE);
			slObjectsSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			mlObjectList = DomainObject.findObjects
					(context, //MatrixContext
							DomainConstants.QUERY_WILDCARD, //typePattern
							sObjectName, //namePattern
							DomainConstants.QUERY_WILDCARD, //revPattern
							DomainConstants.QUERY_WILDCARD, //ownerPattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
							ConstantsUtilIRM.CURRENT_RELEASE, //whereExpression modified for defect 130496
							false, //expandType
							slObjectsSelect); //objectSelects
			String sObjid = DomainConstants.EMPTY_STRING;
			String sType = DomainConstants.EMPTY_STRING;
			String sOrgSource = DomainConstants.EMPTY_STRING;
			String sPROrgSource = DomainConstants.EMPTY_STRING;
			String strlastObjid = DomainConstants.EMPTY_STRING;
			String strlastObjstate = DomainConstants.EMPTY_STRING;
			
			Iterator<MapList> objectListItr = mlObjectList.iterator(); 
			while(objectListItr.hasNext())
			{
				Map<String, String> mpObject = (Map<String, String>)objectListItr.next();
				strlastObjid = mpObject.get(ConstantsUtilIRM.CURRENT_RELEASE_LASTID);
				strlastObjstate = mpObject.get(ConstantsUtilIRM.CURRENT_RELEASE_LASTSTATE);
				sObjid = mpObject.get(ConstantsUtil.ID);
				sType = mpObject.get(ConstantsUtil.TYPE);
				sOrgSource = mpObject.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			}
			if(!strlastObjstate.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
				strlastObjid = sObjid;
			}
				
				
			if(UIUtil.isNotNullAndNotEmpty(strlastObjid)) {
				DomainObject doSpec = DomainObject.newInstance(context, strlastObjid);
				String sDocPreviousRevId  = doSpec.getPreviousRevision(context).getObjectId();
				if(UIUtil.isNotNullAndNotEmpty(sDocPreviousRevId)) {
					DomainObject doPrevSpec = DomainObject.newInstance(context, sDocPreviousRevId);
					sPROrgSource = doPrevSpec.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				}
			}
			if((sPROrgSource.equals(ConstantsUtil.DSO) && sOrgSource.equals(ConstantsUtil.DSO)) || sPROrgSource.equals(ConstantsUtil.EMPTY_STRING)) {
			if(sType.equals(ConstantsUtil.tRMP)) {
				hmMap=rmpcomp.getRMPPartCompData(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}
			if(sType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
				hmAttrib=pmp.getPMPPartCompData(strlastObjid, env);
				context.close();
				return hmAttrib;
		    }
			//SPEC: Added by Ajay for Req. no. 23961 START
			if(sType.equals(ConstantsUtil.tPAP)) {
				hmMap=papcomp.getPAPPartCompData(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}
			//SPEC: Added by Ajay for Req. no. 23961 END
			
			//SPEC: Added by Ajay for Req. no. 23960 START
			if(sType.equals(ConstantsUtil.TYPE_FABRICATEDPART)) {
				hmMap=fabcomp.getFABCompdata(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}
			//SPEC: Added by Ajay for Req. no. 23960 END
			
			//SPEC: Modified by Ajay for Req. no. 78405 START
			if(sType.equals(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
				hmMap=fppcomp.getFPPPartCompData(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}
			
			//SPEC: Modified by Ajay for Req. no. 78405 END
			//SPEC: Added by Ajay for Req. no. 23970 START
			if(sType.equals(ConstantsUtil.tQUAL) || sType.equals(ConstantsUtil.tATS) || sType.equals(ConstantsUtil.tILST) || sType.equals(ConstantsUtil.tMI) || sType.equals(ConstantsUtil.tPI) || sType.equals(ConstantsUtil.tRMPI) || sType.equals(ConstantsUtil.tSPS) || sType.equals(ConstantsUtil.tIAPS) || sType.equals(ConstantsUtil.tLIS) || sType.equals(ConstantsUtil.tACS) || sType.equals(ConstantsUtil.tPROS) || sType.equals(ConstantsUtil.tSOP) || sType.equals(ConstantsUtil.tTM) || sType.equals(ConstantsUtilIRM.TIRM) || sType.equals("pgPKGProductReadiness")) {
				hmMap=commondoccmp.getDocCompdata(strlastObjid, env, sType);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}

			//Added by Ajay for Req No. 23964 -- START
			if(sType.equals(ConstantsUtil.tARMP)) {
				hmMap=armpcomp.getARMPCompdata(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}
			//Added by Ajay for Req No. 23964 -- END
			if(sType.equals(ConstantsUtil.tPIP)) {
				hmMap=pipcomp.getPIPPartCompData(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}
			if(sType.equals(ConstantsUtil.tAPMP)) {
				hmMap=apmpcomp.getAPMPCompdata(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}
			//Added by Ajay for Req No. 23974 -- START
			if(sType.equals(ConstantsUtil.tSWP)) {
				hmMap=swpcomp.getSWPCompdata(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}
			//Added by Ajay for Req No. 23974 -- END
			//Added by Ajay for Req No. 23966 -- START
			if(sType.equals(ConstantsUtil.tOPP)) {
				hmMap=oppcomp.getOPPCompdata(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}//Added by Ajay for Req No. 23966 -- START
			if(sType.contentEquals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)) {
				hmMap=cupcomp.getCUPCompdata(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}//Added by Ajay for Req No. 23966 -- START
			if(sType.contentEquals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) {
				hmMap=copcomp.getCOPCompdata(strlastObjid, env);
				for (Map.Entry<String, HashMap<String, Map<String, String>>> outerEntry : hmMap.entrySet()) {
		            HashMap<String, Map> innerGenericMap = new HashMap<>();
		            for (Map.Entry<String, Map<String, String>> innerEntry : outerEntry.getValue().entrySet()) {
		                innerGenericMap.put(innerEntry.getKey(), innerEntry.getValue()); // No casting needed
		            }
		            hmAttrib.put(outerEntry.getKey(), innerGenericMap);
		        }
				context.close();
				return hmAttrib;
			}//Added by Ajay for Req No. 23966 -- START
			else {
				hmAttrib.put(ConstantsUtilIRM.RELEASEOBJECT, hmMapEmpty);
				hmAttrib.put(ConstantsUtilIRM.OBSOLETEOBJECT,hmMapEmpty);
				}
			}
			
			//SPEC: Added by Ajay for Req. no. 23961 END
			else {
				mpMess.put(ConstantsUtilIRM.RESPONSEMESSAGE, ConstantsUtilIRM.ERROR_CSSPART);
				hmMapEmpty.put(ConstantsUtilIRM.E119, mpMess);
				hmAttrib.put(ConstantsUtil.ERROR, hmMapEmpty);
			}
			
		}catch(Exception e) {
			LOGGER.error("Exception From RMP COMPARISION Service IMPL Class "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		return hmAttrib;
	}
	

}
