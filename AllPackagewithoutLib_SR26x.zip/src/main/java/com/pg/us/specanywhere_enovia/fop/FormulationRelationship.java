package com.pg.us.specanywhere_enovia.fop;

import com.matrixone.apps.domain.util.PropertyUtil;
import matrix.db.Context;
public enum FormulationRelationship {

		CHARACTERISTIC("relationship_Characteristic"), PARTSPECIFICATION("relationship_PartSpecification"), EBOM(
				"relationship_EBOM"), ORIGINATING_TEMPLATE("relationship_OriginatingTemplate"), SHARED_CHARACTERISTIC(
						"relationship_SharedCharacteristic"), SHARED_TABLE("relationship_SharedTable"), COMPONENT_MATERIAL(
								"relationship_ComponentMaterial"), COMPONENT_SUBSTANCE(
										"relationship_ComponentSubstance"), FORMULATION_PROCESS(
												"relationship_FormulationProcess"), PHASE_HEADER(
														"relationship_PhaseHeader"), PROCESS_STEP(
																"relationship_ProcessStep"), NOT_INCLUDED_PHASE(
																		"relationship_NotIncludedPhase"), FBOM(
																				"relationship_FBOM"), FBOM_SUBSTITUTE(
																						"relationship_FBOMSubstitute"), RELATIONSHIP_MANUFACTURER_EQUIVALENT(
																								"relationship_ManufacturerEquivalent"), RELATIONSHIP_MANUFACTURING_RESPONSIBILITY(
																										"relationship_ManufacturingResponsibility"), FORMULATION_PROPAGATE(
																												"relationship_FormulationPropagate"), FORMULATION_PROPAGATE_HISTORY(
																														"relationship_FormulationPropagateHistory"), PLANNED_FOR(
																																"relationship_PlannedFor"), PLANNED_FOR_HISTORY(
																																		"relationship_PlannedForHistory"), ASSOCIATED_PLANTS(
																																				"relationship_AssociatedPlants"), MANUFACTURING_RESPONSIBILITY(
																																						"relationship_ManufacturingResponsibility"), FORMULA_INGREDIENT(
																																								"relationship_FormulaIngredient"), FORMULA_INGREDIENT_HISTORY(
																																										"relationship_FormulaIngredientHistory"), OWNING_PRODUCTLINE(
																																												"relationship_OwningProductLine"), ADDITIONAL_BRAND(
																																														"relationship_AdditionalBrand"), DISTRIBUTION_LIST(
																																																"relationship_DistributionList"), LIST_MEMBER(
																																																		"relationship_ListMember"), MANUFACTURING_LOCATION(
																																																				"relationship_ManufacturingLocation"), FBOM_HISTORY(
																																																						"relationship_FBOMHistory"), FBOM_PENDING(
																																																								"relationship_FBOMPending"), DESIGN_RESPONSIBILITY(
																																																										"relationship_DesignResponsibility"), MANUFACTURER_EQUIVALENT(
																																																												"relationship_ManufacturerEquivalent"), ALTERNATE(
																																																														"relationship_Alternate"), TEMPLATE(
																																																																"relationship_Template"), PLANT_COST_OVERRIDE(
																																																																		"relationship_PlantCostOverride"), PLBOM(
																																																																				"relationship_PLBOM"), PLBOM_HISTORY(
																																																																						"relationship_PLBOMHistory"), PLBOM_PENDING(
																																																																								"relationship_PLBOMPending"), SECURE_COMPONENT_SUBSTANCE(
																																																																										"relationship_SecureComponentSubstance"), SECURE_COMPONENT_MATERIAL(
																																																																												"relationship_SecureComponentMaterial"), VIRTUAL_INTERMEDIATE_USAGE(
																																																																														"relationship_VirtualIntermediateUsage"), MATERIAL_FUNCTIONALITY(
																																																																																"relationship_MaterialFunctionality");

		private final String _name;

		private FormulationRelationship(String var3) {
			this._name = var3;
		}

		public String getRelationship(Context var1) {
			return PropertyUtil.getSchemaProperty(var1, this._name);
		}

		public String toString() {
			return this._name;
		}
	
}
