/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaIMPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import com.pg.us.specanywhere_enovia.bo.DSMReportBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaDSMReportValidationService;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import matrix.db.Context;

public class EnoviaDSMReportValidationServiceImpl implements EnoviaDSMReportValidationService{

	private static Logger dsmLOGGER = Logger.getLogger(EnoviaDSMReportValidationServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	StringValidatorUtil validator = new StringValidatorUtil();	

	@Override
	public HashMap<String, Map<String, String>> getDSMReportValidationData(Environment env, Map<String, Object> mCAValidationRequest)  {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<>();
		StopWatch sp = new StopWatch();
		sp.start();
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		dsmLOGGER.info("DSM REPORT Validation SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());
		
		DSMReportBO dsReportbo = new DSMReportBO();
		try 
		{
			// Added by Ketan for Req. no. 42796,47051,42797,47058 -- START
			// certificationRoll-Up
			if (mCAValidationRequest.get(ConstantsUtilIRM.REPORTNAME).equals(ConstantsUtilIRM.CERTIFICATION_ROLL_UP)) {
				Map<String, String> mCAValidationResponse = dsReportbo.getCAValidationResult(context, mCAValidationRequest);
				if (mCAValidationResponse.get(ConstantsUtilIRM.RESPONSECODE).equals(ConstantsUtilIRM.S101)) {
					Map<String, String> mPartNameValidationResponse = dsReportbo.getPartNameValidationResult(context, mCAValidationRequest);
					hmAttrib.put(ConstantsUtilIRM.CAvalidation, mPartNameValidationResponse);
				} else {
					hmAttrib.put(ConstantsUtilIRM.CAvalidation, mCAValidationResponse);
				}
			}

			// whereUsedReport
			if (mCAValidationRequest.get(ConstantsUtilIRM.REPORTNAME).equals(ConstantsUtilIRM.WHERE_USED_REPORT)) {
				Map<String, String> mCAValidationResponse = dsReportbo.getCAValidationResult(context, mCAValidationRequest);
				if (mCAValidationResponse.get(ConstantsUtilIRM.RESPONSECODE).equals(ConstantsUtilIRM.S101)) {
					Map<String, String> mPartTypeValidation = dsReportbo.getPartTypeValidationResult(context, mCAValidationRequest);
					hmAttrib.put(ConstantsUtilIRM.CAvalidation, mPartTypeValidation);
				} else {
					hmAttrib.put(ConstantsUtilIRM.CAvalidation, mCAValidationResponse);
				}
			}

			// Added by Ketan for Req. no. 42796,47051,42797,47058 -- END
			if(!mCAValidationRequest.get(ConstantsUtilIRM.REPORTNAME).equals(ConstantsUtilIRM.CERTIFICATION_ROLL_UP) && !mCAValidationRequest.get(ConstantsUtilIRM.REPORTNAME).equals(ConstantsUtilIRM.WHERE_USED_REPORT)) {
			Map<String, String> mCAValidationResponse = dsReportbo.getCAValidationResult(context, mCAValidationRequest);				
			hmAttrib.put(ConstantsUtilIRM.CAvalidation, mCAValidationResponse);
			}
			
		}catch (Exception e) {
			dsmLOGGER.error("Exception in DSM Report Validation Service IMPL: "+e);			
		}
		pool.checkIn(context);
		sp.stop();
		dsmLOGGER.info("DSM Report Validation SERVICE ELAPSED TIME : "+sp.getTime());
		dsmLOGGER.info("DSM Report Validation SERVICE MESSAGE:: \n" + hmAttrib);
		//SPEC: <25-07-2022>: Manikanta Added for Defect 45181  -- START
		context.close();
		//SPEC: <25-07-2022>: Manikanta Added for Defect 45181  -- END
		return hmAttrib;		
	}	
}
