/**
 * Project 		: SpecsAnywhere
 * Program 		: FinishedProductPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Vector;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.core.env.Environment;


import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.sapbom.pgV3Constants;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.EncryptCrypto;
import com.pg.us.specanywhere_enovia.utility.SAPBOMConstants;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class FinishedProductPartBO {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(FinishedProductPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	StringValidatorUtil validatorUtil=new StringValidatorUtil();
	public FinishedProductPartBO() {
		// empty constructor
	}

	
	/**
	 * Method Name 			: getFppBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getFppBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getFppDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getFppDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			if (doObj.exists(context))
				return doObj;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getFinishedProductPartSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getFinishedProductPartSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		busSelect.addAll(getStorageTrasportSelectable(context));
		busSelect.addAll(getPlantBusSelectable(context));
		busSelect.addAll(getWndBusSelectable(context));
		busSelect.addAll(getCosSelectable(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getStabilityResults(context));
		busSelect.addAll(getFileSelects(context));
		busSelect.addAll(getDangerousgoodsSpecSelects(context));
		busSelect.addAll(getGlobalHarmonizedStandard(context));
		busSelect.addAll(getMasterSpecs());
		busSelect.addAll(BusObjectAttribUtil.getPackingUnitSelectables(context));
		busSelect.addAll(BusObjectAttribUtil.getTUPCharSelectables(context));
		busSelect.addAll(getTransportCharSelectables());
		busSelect.addAll(getPackagingCharBusSelectables());
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	/**
	 * Method Name 			: getStabilityResults
	 * Method Description 	: Fetching "Stability" related data
	 * @param context
	 * @return
	 */
	public static StringList getStabilityResults(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_RELEASEDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getFppRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public  Map<String, StringList> getFppRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getCommonDataBusSelectable(context));
		busSelect.addAll(getTransportBusSelectables());
		busSelect.addAll(getStorageTrasportSelectable(context));
		relSelect.addAll(getTransportRelSelectables());
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);

		return mapSelecables;
	}
	/**
	 * Method Name 			: getStorageTrasportSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getStorageTrasportSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_PGINTERNUL_PRODUCT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		// SPEC: Guna Commented for Defect 38083  -- START
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		// SPEC: Guna Commented for Defect 38083  -- END
        busSelect.add(ConstantsUtil.RELATIONSHIP_WAREHOUSE_NAME);
        busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
        
        //SPEC: <10.19.2020>: Added for req 18x.5 ## -- START
        busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_UNIQUEFORMULAIDENTIFIER);
        //SPEC: <10.19.2020>: Added for req 18x.5 ## -- END
        
		return busSelect;
	}

	
	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);
		busSelect.add(DomainConstants.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.REL_AffectedItem_ATTRICHANGEAPPROVER);
		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSECURITYSTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_STATISTICALUNIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVE);
		// SPEC: Guna Commented for Defect 38083  -- START
		// Guna Modified for Defect 38721  18x.5.2 Release -- START
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		// Guna Modified for Defect 38721  18x.5.2 Release -- END
		// SPEC: Guna Commented for Defect 38083  -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		busSelect.add(DomainConstants.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);

		busSelect.add(ConstantsUtil.SELECT_REL_MATERIAL_CERTIFICATIONS_CERTIFICATIONCLAIM);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS);

		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.ATL_ORGNSOURCE);

		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		
		//SPEC: <10.19.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RETAILERPUBLICATIONREADY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		//SPEC: <10.19.2020>: Added for req 18x.5 ## -- END
		
		//SPEC: <11.07.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.PRIMARY_PACKAGING_TYPE);
		//SPEC: <11.07.2020>: Added for req 18x.5 ## -- END
		//SPEC: <02.24.2021>: Commented/Added for req 18x.6 ## -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGAREBATTERIESINCLUDED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAREBATTERIESREQUIRED);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGAREBATTERIESBUILTIN);
		//SPEC: <02.24.2021>: Commented/Added for req 18x.6 ## -- END
		
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_AREBATTERIESINCLUDED);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- END
		//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 16, 2021 for Defect#40802 -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGREPLACEDPRODUCTNAME);
		//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 16, 2021 for Defect#40802 -- END
		
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 25, 2021 for Defect 41567 -- START
		busSelect.add(ConstantsUtilIRM.SELECT_MASTERPARTNAME_FP_HALB);
		busSelect.add(ConstantsUtilIRM.SELECT_MASTERPARTTYPE_FP_HALB);
		busSelect.add(ConstantsUtilIRM.SELECT_MASTERPARTID_FP_HALB);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 25, 2021 for Defect 41567 -- END
		
		//SPEC: Release SR18x.6.0 - Added by Amman on Apr 7, 2021 for Defect 42199 , 42193 -- START
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_REL_OWNINGPRODUCTLINE);
		//SPEC: Release SR18x.6.0 - Added by Amman on Apr 7, 2021 for Defect 42199 , 42193 -- END
		//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL);
		//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- END
		//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- END
		//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDVALEXCP);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDEXCPCMT);
		busSelect.add(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC);
		busSelect.add(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC_TYPE);
		busSelect.add(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC_ID);
		//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- END
		//Added by Subhajit for Req 46464 - Start
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - End
		
		return busSelect;
	}

	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public  StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_CONNECTION_ID);
		busSelect.add(ConstantsUtil.SELECT_PARENT);
		busSelect.add(ConstantsUtil.SELECT_LEVEL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- END
		//SPEC: <01.07.2022>: Guna Added for Req 43515 22x Release  -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED);
		busSelect.add(ConstantsUtilIRM.SELECT_EBOM);
		//SPEC: <01.07.2022>: Guna Added for Req 43515 22x Release  -- END
		//Added by Subhajit for Req 46464 - Start
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - End
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}


	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public  StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCSSTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGQUANTITY); // Added for Defect #38628
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		//Added by Ketan for Req. no. 46464 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC);
		//Added by Ketan for Req. no. 46464 -- END
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
		

		//SPEC: <11.20.2020>: Chandra Added for Defect :37490 ## --START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
		//SPEC: <11.20.2020>: Chandra Added for Defect :37490 ## --END
		
		//Modified for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Modified for Defect# 37591 -- END
		
		
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --END
		
		// SPEC: Guna Added for Defect 38083  -- START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		// SPEC: Guna Added for Defect 38083  -- END
		//SPEC: Release SR18x.5.2 - Added for Defect# 38083  by Guna on Date 11/02/2021 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM);
		//SPEC: Release SR18x.5.2 - Added for Defect# 38083  by Guna on Date 11/02/2021 -- END
		relSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- END
		return relSelect;
	}
	
	
	/**
	 * Method Name 			: getDangerousgoodsSpecSelects
	 * Method Description 	: Fetching "Dangerous Goods" related information
	 * @param context
	 * @return
	 */
	public static StringList getDangerousgoodsSpecSelects(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2);
		
		return busSelect;
	}
	
	
	/** 
	 * Method Name 			: getGlobalHarmonizedStandard
	 * Method Description 	: Fetching "Global Harmonized Standard" related data
	 * @param context
	 * @return
	 */
	public static StringList getGlobalHarmonizedStandard(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_ID);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TYPE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getPlantBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getPlantBusSelectable(Context context) {
		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- START
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- END
		
		return busSelect;
	}

	
	/**
	 * Method Name 			: getPlantRelSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getPlantRelSelectable(Context context) {
		StringList relSelect = new StringList(2);
		relSelect.add(ConstantsUtil.ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
		relSelect.add(ConstantsUtil.ATTRIBUTE_PGISAUTHORIZEDTOUSE);
		return relSelect;
	}

	
	/**
	 * Method Name 			: getWndBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getWndBusSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM);

		return busSelect;
	}


	/**
	 * Method Name 			: getCosSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getCosSelectable(Context context) {

		StringList relSelect = new StringList(2);
		relSelect.add(ConstantsUtil.SELECT_COS_NAME);
		relSelect.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		return relSelect;
	}

	
	/**
	 * Method Name 			: getMasterSpecs
	 * Method Description 	: Fetching "Master Specifications" data
	 * @return
	 */
	public static StringList getMasterSpecs() {
		StringList busSelect = new StringList();

		busSelect.add(DomainConstants.SELECT_ID);
		busSelect.add(DomainConstants.SELECT_TYPE);
		busSelect.add(DomainConstants.SELECT_NAME);
		busSelect.add(ConstantsUtil.STR_MASTER_SPECS_ID);
		busSelect.add(ConstantsUtil.STR_MASTER_SPECS_TYPE);
		busSelect.add(ConstantsUtil.STR_MASTER_SPECS_NAME);
		busSelect.add(ConstantsUtil.STR_MASTER_SPECS_STATE);
		busSelect.add(ConstantsUtil.STR_MASTER_SPECS_ASSEMBLY);
		busSelect.add(ConstantsUtil.STR_MASTER_SPECS_TITLE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getMasterSpecs
	 * Method Description 	: Fetching "Master Specifications" data
	 * @param context
	 * @param doFPP
	 * @return
	 * @throws Exception
	 */
	public Map getMasterSpecs(Context context, DomainObject doFPP) throws Exception {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		Map<String, String> mpMasterSpecs = new HashMap<String, String>();
		
		StringBuilder sbtype = new StringBuilder();
		StringBuilder sbname = new StringBuilder();
		StringBuilder sbstate = new StringBuilder();
		StringBuilder sbSpecSubType = new StringBuilder();
		StringBuilder sbtitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		
		StringList slBusselects = new StringList(6);
		
		slBusselects.addElement(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_NAME);
		slBusselects.addElement(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_TYPE);
		slBusselects.addElement(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_ID);
		slBusselects.addElement(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_CURRENT);
		slBusselects.addElement(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_SUBTYPE);
		slBusselects.addElement(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_TITLE);
		
		MapList ebomPartList;
		try {
			ContextUtil.pushContext(context, PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING);

			Pattern sbTypePattern = new Pattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
			sbTypePattern.addPattern(ConstantsUtil.TYPE_PGINNERPACKUNITPART);
			sbTypePattern.addPattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
			sbTypePattern.addPattern(ConstantsUtil.TYPE_FINISHEDPRODUCTPART);
			
			ebomPartList = doFPP.getRelatedObjects(context, DomainObject.RELATIONSHIP_EBOM, sbTypePattern.getPattern(), // Type
					// Pattern
					slBusselects, // Object Select
					null, // rel Select
					false, // get To
					true, // get From
					(short) 0, // recurse level
					ConstantsUtil.EMPTY_STRING, // where Clause
					null, // relationshipWhere Clause
					(short) 0);
			
			Iterator objectListItr = ebomPartList.iterator();
			
			while(objectListItr.hasNext()){
				
			Map resultMaps = (Map) objectListItr.next();
			
			String strType	 =  util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_TYPE)));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_ID));
			String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_NAME));
			String strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_CURRENT));
			String SpecSubType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_SUBTYPE));
			String strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTSPECIFICATION_TO_TITLE));
			
			formatData(sbtype,strType);
			formatData(sbname,strName);
			formatData(sbstate,strState);
			formatData(sbSpecSubType,SpecSubType);
			formatData(sbId,strID);
			formatData(sbtitle,strTitle);
			
			}
			mpMasterSpecs.put(ConstantsUtil.ID, sbId.toString());
			mpMasterSpecs.put(ConstantsUtil.TYPE, sbtype.toString());
			mpMasterSpecs.put(ConstantsUtil.NAME, sbname.toString());
			mpMasterSpecs.put(ConstantsUtil.STATE, sbstate.toString());
			mpMasterSpecs.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
			mpMasterSpecs.put(ConstantsUtil.TITLE, sbtitle.toString());
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FinishedProductPartBO Method :getMasterSpecs " + e);
			return new HashMap();

		}
		return util.filterMapList(mpMasterSpecs);
	}

	
	/**
	 * Method Name 			: getMasterBusEbom
	 * Method Description 	:
	 * @return
	 */
	public StringList getMasterBusEbom() {
		StringList busSelect = new StringList();
		busSelect.add(DomainConstants.SELECT_ID);
		busSelect.add(DomainConstants.SELECT_TYPE);
		busSelect.add(DomainConstants.SELECT_NAME);
		busSelect.add(DomainConstants.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		busSelect.add(DomainConstants.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ID);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRISTAGE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_NAME);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRIBASEUOM);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_RELEASEDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRISUBSTITUTE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRIREFERENCEDESIGNATOR);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_PGOPTIONALCOMPONENT);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_PGCHANGE);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_ATTRIFN);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_QUANTITY);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_COMMENT);

		// Master Inner Pack selects
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_ID);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_NAME);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_PGCHANGE);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_FN);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_ATTRITITLE);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_TYPE);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_SUBSTITUTE);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_QUANTITY);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_BASEUOM);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_COMMENT);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_RELEASEDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_REVISION);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_CURRENT);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_STAGE);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_REFERENCEDESIGNATOR);
		busSelect.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_OPTIONALCOMPONENT);

		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
				
		return busSelect;

	}

	
	/**
	 * Method Name 			: getMasterRelEbom
	 * Method Description 	:
	 * @return
	 */
	public StringList getMasterRelEbom() {
		StringList strlRelSelectable = new StringList();
		strlRelSelectable.add(DomainRelationship.SELECT_FROM_TYPE);
		strlRelSelectable.add(DomainRelationship.SELECT_TO_TYPE);
		strlRelSelectable.add(DomainRelationship.SELECT_FROM_ID);
		strlRelSelectable.add(DomainObject.SELECT_RELATIONSHIP_ID);
		strlRelSelectable.add(DomainObject.SELECT_ATTRIBUTE_QUANTITY);

		return strlRelSelectable;
	}

	
	/**
	 * Method Name 			: updateMasterBom
	 * Method Description 	:
	 * @param ebomPgCustPartList
	 * @return
	 */
	public Map updateMasterBom(MapList ebomPgCustPartList) {

		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		Iterator objectListItr = ebomPgCustPartList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMRelease = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState = new StringBuilder();
		StringBuilder sbEBOMStage = new StringBuilder();
		StringBuilder sbEBOMRDOC = new StringBuilder();
		StringBuilder sbEBOMSubstute = new StringBuilder();
		String sSubstitute = DomainConstants.EMPTY_STRING;
		String sQty = DomainConstants.EMPTY_STRING;
		String sComments = DomainConstants.EMPTY_STRING;
		String sRD = DomainConstants.EMPTY_STRING;
		String sOC = DomainConstants.EMPTY_STRING;
		String sFN = DomainConstants.EMPTY_STRING;
		String spgChg = DomainConstants.EMPTY_STRING;
		String sRDOC = DomainConstants.EMPTY_STRING;
		StringList slOC = new StringList();
		StringList slRD = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();
		try {
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sParentType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				if (ConstantsUtil.TYPE_PG_MASTER_CUSTOMER_UNIT_PART.equals(sParentType)
						|| ConstantsUtil.TYPE_PG_CONSUMER_UNIT_PART.equals(sParentType)) {

					String sId = (validator
							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID)))
							? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID)
									: ConstantsUtil.EMPTY_STRING;
					String sName = (validator
							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME)))
									? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME)
									: ConstantsUtil.EMPTY_STRING;
					String sRevision = (validator
							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION)))
									? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION)
									: ConstantsUtil.EMPTY_STRING;
					String sReleaseDate = (validator
							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_RELEASEDATE)))
									? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_RELEASEDATE)
									: ConstantsUtil.EMPTY_STRING;
					String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON + sReleaseDate;
					String sTitle = (validator
							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE)))
									? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE)
									: ConstantsUtil.EMPTY_STRING;
					String sType = (validator
							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE)))
									? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_TYPE)
									: ConstantsUtil.EMPTY_STRING;
					sType = util.mapType(sType);

					boolean bSubCheck = objectMap.containsKey(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRISUBSTITUTE);
					if (bSubCheck) {
						sSubstitute = (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRISUBSTITUTE);
						sSubstitute = sSubstitute.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO)
								.replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
					}
					boolean bQty = objectMap.containsKey(ConstantsUtil.STR_CLASSI_EBOM_QUANTITY);
					if (bQty) {
						String clsName = (objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_QUANTITY)).getClass()
								.getSimpleName();

						if (clsName.equals(ConstantsUtil.STRINGLIST)) {
							StringList slQty = validator.isNotNullOrEmpty(
									(StringList) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_QUANTITY));
							sQty = validator.isNotNullOrEmpty(slQty.toString()) ? slQty.toString()
									: ConstantsUtil.EMPTY_STRING;
							sQty = sQty.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
						} else {
							sQty = (String) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_QUANTITY);
							util.formatData(sbEBOMQTY, sQty);
						}

					}
					boolean bCmnts = objectMap.containsKey(ConstantsUtil.STR_CLASSI_EBOM_COMMENT);
					if (bCmnts) {
						String clsName = (objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_COMMENT)).getClass()
								.getSimpleName();

						if (clsName.equals(ConstantsUtil.STRINGLIST)) {
							StringList slComments = validator.isNotNullOrEmpty(
									(StringList) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_COMMENT));
							sComments = validator.isNotNullOrEmpty(slComments.toString()) ? slComments.toString()
									: ConstantsUtil.EMPTY_STRING;
							sComments = sComments.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
						} else {
							sComments = (String) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_COMMENT);
							util.formatData(sbEBOMCommnts, sComments);
						}

					}
					boolean bStringCheck = false;
					boolean bRD = objectMap.containsKey(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRIREFERENCEDESIGNATOR);
					if (bRD) {
						String clsName = (objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRIREFERENCEDESIGNATOR))
								.getClass().getSimpleName();

						if (clsName.equals(ConstantsUtil.STRINGLIST)) {
							slRD = validator.isNotNullOrEmpty((StringList) objectMap
									.get(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRIREFERENCEDESIGNATOR));
							sRD = validator.isNotNullOrEmpty(slRD.toString()) ? slRD.toString()
									: ConstantsUtil.EMPTY_STRING;
							bStringCheck = true;
						} else {
							sRD = (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRIREFERENCEDESIGNATOR);
						}

					}

					boolean bOC = objectMap.containsKey(ConstantsUtil.STR_CLASSI_EBOM_PGOPTIONALCOMPONENT);
					if (bOC) {
						String clsName = (objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_PGOPTIONALCOMPONENT)).getClass()
								.getSimpleName();

						if (clsName.equals(ConstantsUtil.STRINGLIST)) {
							slOC = validator.isNotNullOrEmpty(
									(StringList) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_PGOPTIONALCOMPONENT));
							sOC = validator.isNotNullOrEmpty(slOC.toString()) ? slOC.toString()
									: ConstantsUtil.EMPTY_STRING;
							bStringCheck = true;
						} else {
							sOC = (String) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_PGOPTIONALCOMPONENT);
						}

					}

					if (bStringCheck) {
						StringList slMapType = new StringList();

						for (int i = 0; i < slRD.size(); i++) {
							String sTempRD = slRD.get(i);
							String sTempOC = slOC.get(i);
							slMapType.add(sTempRD + ConstantsUtil.SYMBL_COLON + sTempOC);
							sRDOC = slMapType.toString();
							sRDOC = sRDOC.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE)
									.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO)
									.replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
						}

					} else {
						sRDOC = (sRD + ConstantsUtil.SYMBL_COLON + sOC)
								.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO)
								.replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);

					}
					boolean bFN = objectMap.containsKey(ConstantsUtil.STR_CLASSI_EBOM_ATTRIFN);
					if (bFN) {
						String clsName = (objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_ATTRIFN)).getClass()
								.getSimpleName();

						if (clsName.equals(ConstantsUtil.STRINGLIST)) {
							StringList slFN = validator.isNotNullOrEmpty(
									(StringList) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_ATTRIFN));
							sFN = validator.isNotNullOrEmpty(slFN.toString()) ? slFN.toString()
									: ConstantsUtil.EMPTY_STRING;
							sFN = sFN.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
						} else {
							sFN = (String) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_ATTRIFN);
							util.formatData(sbEBOMFN, sFN);
						}

					}

					boolean bslpgChg = objectMap.containsKey(ConstantsUtil.STR_CLASSI_EBOM_PGCHANGE);
					if (bslpgChg) {
						String clsName = (objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_PGCHANGE)).getClass()
								.getSimpleName();

						if (clsName.equals(ConstantsUtil.STRINGLIST)) {
							StringList slpgChg = validator.isNotNullOrEmpty(
									(StringList) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_PGCHANGE));
							spgChg = validator.isNotNullOrEmpty(slpgChg.toString()) ? slpgChg.toString()
									: ConstantsUtil.EMPTY_STRING;
							spgChg = spgChg.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
									.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
						} else {
							spgChg = (String) objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_PGCHANGE);
							util.formatData(sbEBOMChg, spgChg);
						}

					}

					String sBuom = (validator
							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRIBASEUOM)))
									? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRIBASEUOM)
									: ConstantsUtil.EMPTY_STRING;

					String sCurrent = (validator
							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT)))
									? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_CURRENT)
									: ConstantsUtil.EMPTY_STRING;
					sCurrent = util.mapType(sCurrent);
					String sStage = (validator
							.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRISTAGE)))
									? (String) objectMap.get(ConstantsUtil.STR_CLASSI_REFERENCE_ATTRISTAGE)
									: ConstantsUtil.EMPTY_STRING;

					util.formatData(sbEBOMRDOC, sRDOC);
					util.formatData(sbEBOMId, sId);
					util.formatData(sbEBOMName, sName);
					util.formatData(sbEBOMRelease, sRevRelease);

					util.formatData(sbEBOMTitle, sTitle);
					util.formatData(sbEBOMType, sType);
					util.formatData(sbEBOMSubstute, sSubstitute);

					util.formatData(sbEBOMBuom, sBuom);
					util.formatData(sbEBOMStage, sStage);
					util.formatData(sbEBOMState, sCurrent);
				}

			}
			mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRelease.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
			mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
			mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());

		} catch (Exception e) {
			System.out.println("Error in Update Master EBOM from FinishedProductPartBO");
			return new HashMap();
		}
		return util.filterMapList(mpEBOMResult);
	}

	
	/**
	 * Method Name 			: addUnitSelects
	 * Method Description 	:
	 * @param masterBus
	 * @return
	 */
	public StringList addUnitSelects(StringList masterBus) {
		StringList busSelect = new StringList(40);
		busSelect.addAll(masterBus);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);

		return busSelect;
	}


	/**
	 * Method Name 			: parseUnitMaplist
	 * Method Description 	:
	 * @param ebomPgCustPartList
	 * @param mpPackingUnit
	 * @return
	 */
	public Map<String, String> parseUnitMaplist(MapList ebomPgCustPartList, Map mpPackingUnit) {
		StringBuilder sbPackingType = new StringBuilder();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		@SuppressWarnings("rawtypes")
		Iterator objectListItr = ebomPgCustPartList.iterator();
		while (objectListItr.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map objectMap = (Map) objectListItr.next();
			String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
			if (sType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) {
				sType = ConstantsUtil.TYPE_CONSUMER_UNIT;
			}
			if (sType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)) {
				sType = ConstantsUtil.TYPE_CUSTOMER_UNIT;
			}
			String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
			sName = sType + ConstantsUtil.SYMBL_OPNBRACE + sName + ConstantsUtil.SYMBL_CLSBRACE;
			util.formatData(sbPackingType, sName);

		}
		mpPackingUnit.replace(ConstantsUtil.PACKAGINGTYPE, sbPackingType.toString());

		return mpPackingUnit;
	}

	
	/**
	 * Method Name 			: getNumOfCUPPerTUP
	 * Method Description 	:
	 * @param resultMap
	 * @return
	 */
	public String getNumOfCUPPerTUP(Map resultMap) {
		StringValidatorUtil validator = new StringValidatorUtil();
		String sQty = DomainConstants.EMPTY_STRING;
		try {
			boolean sClass = resultMap.containsKey(ConstantsUtil.STR_PARTSPEC_QUANTITY);
			if (sClass) {
				String sClassName = (resultMap.get(ConstantsUtil.STR_PARTSPEC_QUANTITY)).getClass().getSimpleName();
				if (sClassName.equals(ConstantsUtil.STRINGLIST)) {
					StringList slQty = validator
							.isNotNullOrEmpty((StringList) resultMap.get(ConstantsUtil.STR_PARTSPEC_QUANTITY));
					StringList slType = validator
							.isNotNullOrEmpty((StringList) resultMap.get(ConstantsUtil.STR_EBOM_TYPE));
					for (int i = 0; i < slQty.size(); i++) {
						String stype = slType.get(i);
						String sTempQty = slQty.get(i);
						if (stype.equals(ConstantsUtil.TYPE_PGMASTERCUSTOMERUNITPART)) {
							sQty = sTempQty;
						}
					}
				} else {

					sQty = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.STR_PARTSPEC_QUANTITY))
							? (String) resultMap.get(ConstantsUtil.STR_PARTSPEC_QUANTITY) : ConstantsUtil.EMPTY_STRING;
							String sType = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.STR_EBOM_TYPE))
									? (String) resultMap.get(ConstantsUtil.STR_EBOM_TYPE) : ConstantsUtil.EMPTY_STRING;
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FinishedProductPartBO Method :getNumOfCUPPerTUP " + e);
			return DomainConstants.EMPTY_STRING;
		}
		return sQty;
	}

	
	/**
	 * Method Name 			: getTransportBusSelectables
	 * Method Description 	:
	 * @return
	 */
	public static StringList getTransportBusSelectables() {
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT);
		slBusSelects.add(ConstantsUtil.SELECT_STACKINGPATTERNGCASCODENAME);
		slBusSelects.add(ConstantsUtil.SELECT_STACKINGPATTERNGCASCODEID);
		slBusSelects.add(ConstantsUtil.SELECT_STACKINGPATTERNGCASCODETYPE);
		slBusSelects.add(ConstantsUtil.STR_PART_SPECSPS);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_CUBEEFFECIENCY);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT);
		slBusSelects.add(ConstantsUtil.STR_SELECT_CUP_QUANTITY);
		slBusSelects.add(ConstantsUtil.STR_SELECT_CUP_TYPE);

		return slBusSelects;

	}

	
	/**
	 * Method Name 			: getTransportCharSelectables
	 * Method Description 	:
	 * @return
	 */
	private static StringList getTransportCharSelectables() {
		StringList slBusSelects = new StringList();

		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		slBusSelects.add(ConstantsUtil.REL_EXTENDED_DATA_GTIN);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		// Jwala Added for Defect 39716  18x.5.2 Release -- START
		//slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE);
		// Jwala Added for Defect 39716  18x.5.2 Release -- END
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);
		slBusSelects.add(ConstantsUtil.SELECT_REF_DOC_TONAME);
		
		//SPEC: Release SR18x5.2- Added for Defect #40005 by Govind on Date 19/02/2021 start	
		slBusSelects.add(ConstantsUtilIRM.SELECT_STACKPATTERNISPRESENT);
		//SPEC: Release SR18x5.2- Added for Defect #40005 by Govind on Date 19/02/2021 end
		
		return slBusSelects;

	}

	
	/**
	 * Method Name 			: getPackagingCharBusSelectables
	 * Method Description 	:
	 * @return
	 */
	private static StringList getPackagingCharBusSelectables() {
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_ID);


		return slBusSelects;

	}

	
	/**
	 * Method Name 			: getTransportRelSelectables
	 * Method Description 	:
	 * @return
	 */
	private static StringList getTransportRelSelectables() {
		StringList slRelSelects = new StringList();
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLETREAL);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLETREAL);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);

		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY);

		return slRelSelects;
	}

	
	/**
	 * Method Name 			: parseTransMaplist
	 * Method Description 	:
	 * @param context 
	 * @param mapList
	 * @param sFPName 
	 * @param sFPType 
	 * @param sID 
	 * @param env 
	 * @return
	 */
	public Map<String, String> parseTransMaplist(Context context, MapList mapList, String sID, String sFPType, String sFPName, Map mpGTIN) throws Exception {
		Map<String, String> mpTransportUnit = new HashMap<String, String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbPalletType = new StringBuilder();
		StringBuilder sbOuterDimLength = new StringBuilder();
		StringBuilder sbTruckMaxHt = new StringBuilder();
		StringBuilder sbOuterDimWidth = new StringBuilder();
		StringBuilder sbOuterDimHeight = new StringBuilder();
		StringBuilder sbDimUOM = new StringBuilder();
		StringBuilder sbCUPLI = new StringBuilder();
		StringBuilder sbCUPTLI = new StringBuilder();
		StringBuilder sbWCMHT = new StringBuilder();
		StringBuilder sbCubeEff = new StringBuilder();
		StringBuilder sbTackPattern = new StringBuilder();
		StringBuilder sbNumOfCUPPerTUP = new StringBuilder();
		StringBuilder sbIsPrimary = new StringBuilder();
		StringBuilder sbGrossWithPallet = new StringBuilder();
		StringBuilder sbGrossWithOutPallet = new StringBuilder();
		StringBuilder sbGrossUOM = new StringBuilder();
		StringBuilder sbIncludedInBomAsFed = new StringBuilder();
		StringBuilder sbPalletMaxHt = new StringBuilder();
		StringBuilder sbTackPatternID = new StringBuilder();
		StringBuilder sbTackPatternType = new StringBuilder();

		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		boolean bHasOwnership = false;

		try {
			
			BusExtractUtil utill = new BusExtractUtil();
			String sGtinValue = utill.getGTINValue(context, mpGTIN,false,mapList);
			
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				
				
				String sPalletType = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE));
				String sOuterDimLength = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH));
				String sOuterDimWidth = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH));
				String sOuterDimHeight = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT));
				String sDimUOM = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM));
				
				
				String sCUPLI = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER));
				String sCUPTLI = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER));
				
				String sNumOfCUPPerTUP = ConstantsUtil.EMPTY_STRING;//getNumOfCUPPerTUP(objectMap);
				
				if(sCUPLI == null || "".equals(sCUPLI)){

					sCUPLI = "0";

				}
				if(sCUPTLI == null || "".equals(sCUPTLI)){

					sCUPTLI = "0";

				}
				
				long lCupPerTup = Long.parseLong(sCUPLI) * Long.parseLong(sCUPTLI);
				sNumOfCUPPerTUP = String.valueOf(lCupPerTup);
				
				String sWCMHT = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT));
				String sTruckMaxHt = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT));
				String sTackPattern = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_STACKINGPATTERNGCASCODENAME));
				String sTackPatternID = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_STACKINGPATTERNGCASCODEID));
				String sTackPatternType = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_STACKINGPATTERNGCASCODETYPE));
				
				String sCubeEff = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CUBEEFFECIENCY));
				String sPalletMaxHt = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT));
				String strIncludedInBomAsFed = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY));
				String sIsPrimary = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY));
				String sGrossWithPallet = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLETREAL));
				String sGrossWithOutPallet = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLETREAL));
				String sGrossUOM = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));

				//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 35738 on Date 21/05/2021 --START
				String strId = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.ID));
				//boolean showData=util.checkHasAccess(context, null, sTackPatternID);
				boolean showData=util.checkHasAccess(context, null, strId);
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 35738 on Date 21/05/2021 --END
				//SPEC: Release SR18x.6.0.1 - Commented by Amman on June 02, 2021 for Req #39652 -- START
				/*
				if (!showData && util.isModificatinRequired()) {
					continue;
				}
				*/
				//SPEC: Release SR18x.6.0.1 - Commented by Amman on June 02, 2021 for Req #39652 -- END
				//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
				
				//Modified by Manikanta for Defect 52961
				if(UIUtil.isNotNullAndNotEmpty(sTackPatternID))
				{
                    //Added by Ganesh 1.0.2 Release Start
					//bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sTackPatternID);
					bHasOwnership=util.checkHasAccess(context, null, sTackPatternID);
					//Added by Ganesh 1.0.2 Release End
					if(!bHasOwnership)
					{
						sTackPatternID =  (ConstantsUtil.EMPTY_STRING);
						sTackPatternType = (ConstantsUtil.NO_ACCESS);
					}
				}
				
				util.formatData(sbPalletType, sPalletType);
				util.formatData(sbOuterDimLength, sOuterDimLength);
				util.formatData(sbOuterDimWidth, sOuterDimWidth);
				util.formatData(sbOuterDimHeight, sOuterDimHeight);
				util.formatData(sbDimUOM, sDimUOM);
				util.formatData(sbCUPLI, sCUPLI);
				util.formatData(sbCUPTLI, sCUPTLI);
				util.formatData(sbWCMHT, sWCMHT);
				util.formatData(sbTruckMaxHt, sTruckMaxHt);
				util.formatData(sbTackPattern, sTackPattern);
				util.formatData(sbTackPatternID, sTackPatternID);
				util.formatData(sbTackPatternType, sTackPatternType);
				util.formatData(sbNumOfCUPPerTUP, sNumOfCUPPerTUP);
				util.formatData(sbCubeEff, sCubeEff);
				util.formatData(sbIsPrimary, sIsPrimary);
				util.formatData(sbGrossWithPallet, sGrossWithPallet);
				util.formatData(sbGrossWithOutPallet, sGrossWithOutPallet);
				util.formatData(sbGrossUOM, sGrossUOM);
				util.formatData(sbIncludedInBomAsFed, strIncludedInBomAsFed);
				util.formatData(sbPalletMaxHt, sPalletMaxHt);
			}

			mpTransportUnit.put(ConstantsUtil.PALLETTYPE, sbPalletType.toString());
			mpTransportUnit.put(ConstantsUtil.GTIN, sGtinValue);
			mpTransportUnit.put(ConstantsUtil.DEPTH, sbOuterDimLength.toString());
			mpTransportUnit.put(ConstantsUtil.WIDTH, sbOuterDimWidth.toString());
			mpTransportUnit.put(ConstantsUtil.HEIGHT, sbOuterDimHeight.toString());
			mpTransportUnit.put(ConstantsUtil.DIMENSIONUNITOFMEASURE, sbDimUOM.toString());
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHPALLET, sbGrossWithPallet.toString());
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHOUTPALLET, sbGrossWithOutPallet.toString());
			mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE1, sbGrossUOM.toString());
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERLAYER, sbCUPLI.toString());
			mpTransportUnit.put(ConstantsUtil.NUMBEROFLAYERSPERTRANSPORTUNIT, sbCUPTLI.toString());
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERTRANSPORTUNIT, sbNumOfCUPPerTUP.toString());
			mpTransportUnit.put(ConstantsUtil.WAREHOUSEPALLETSTACKHEIGHTMAXIMUM, sbPalletMaxHt.toString());
			mpTransportUnit.put(ConstantsUtil.WAREHOUSECASESTACKHEIGHTMAXIMUM, sbWCMHT.toString());
			mpTransportUnit.put(ConstantsUtil.TRUCKPALLETSTACKHEIGHTMAXIMUM, sbTruckMaxHt.toString());
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODE, sbTackPattern.toString());
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODEID, sbTackPatternID.toString());
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODETYPE, sbTackPatternType.toString());
			mpTransportUnit.put(ConstantsUtil.CUBEEFFICIENCY, sbCubeEff.toString());
			mpTransportUnit.put(ConstantsUtil.INCLUDEINSAPBOMFEED, sbIncludedInBomAsFed.toString());

		} catch (Exception e) {
			LOGGER.error("Error from FinishsedProductPartBO :  parseTransMaplist" + e);
			//return new HashMap();
			throw e;
		}

		return util.filterMapList(mpTransportUnit);
	}

	
	/**
	 * Method Name 			: updateMasterInnerPackBom
	 * Method Description 	:
	 * @param ebomPgCustPartList
	 * @return
	 */
	public Map<String, String> updateMasterInnerPackBom(MapList ebomPgCustPartList) {
		Map<String, String> mpMasterInnerBOM = new HashMap<String, String>();
		Iterator objectListItr = ebomPgCustPartList.iterator();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();

		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState = new StringBuilder();
		StringBuilder sbEBOMStage = new StringBuilder();
		StringBuilder sbEBOMRDOC = new StringBuilder();
		StringBuilder sbEBOMSubstute = new StringBuilder();
		StringBuilder sbEBOMRevRelDt = new StringBuilder();
		try {
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sPType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				if (ConstantsUtil.TYPE_PG_INNER_PACK_UNIT_PART.equals(sPType)) {

					String sId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_ID));
					String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_NAME));
					String sChange = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_PGCHANGE));
					String sFindNum = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_FN));
					String sTitle = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_ATTRITITLE));
					String sType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_TYPE));
					String sSubstitute = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_SUBSTITUTE));
					sSubstitute=sSubstitute.replace("TRUE", "Yes").replace("FALSE", "No");
					String sQty = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_QUANTITY));
					String sBUOM = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_BASEUOM));
					String sComments = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_COMMENT));
					String sCurrent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_CURRENT));
					sCurrent=util.mapType(sCurrent.trim());
					String sStage = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_STAGE));
					String sRD = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_RELEASEDATE));
					String sRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_REVISION));
					String sRefDes = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_REFERENCEDESIGNATOR));
					String sOptionalCommnt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_OPTIONALCOMPONENT));

					validator.formatRev(sRev.split(","), sRD.split(","), sbEBOMRevRelDt);
					validator.formatRev(sRefDes.split(","), sOptionalCommnt.split(","), sbEBOMRDOC);

					util.formatData(sbEBOMId, sId);
					util.formatData(sbEBOMName, sName);
					util.formatData(sbEBOMChg, sChange);
					util.formatData(sbEBOMFN, sFindNum);
					util.formatData(sbEBOMTitle, sTitle);
					util.formatData(sbEBOMType, sType);
					util.formatData(sbEBOMSubstute, sSubstitute);
					util.formatData(sbEBOMQTY, sQty);
					util.formatData(sbEBOMBuom, sBUOM);
					util.formatData(sbEBOMCommnts, sComments);
					util.formatData(sbEBOMState, sCurrent);
					util.formatData(sbEBOMStage, sStage);
				}
			}

			mpMasterInnerBOM.put(ConstantsUtil.ID, sbEBOMId.toString());
			mpMasterInnerBOM.put(ConstantsUtil.NAME, sbEBOMName.toString());
			mpMasterInnerBOM.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpMasterInnerBOM.put(ConstantsUtil.FN, sbEBOMFN.toString());
			mpMasterInnerBOM.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
			mpMasterInnerBOM.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpMasterInnerBOM.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
			mpMasterInnerBOM.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpMasterInnerBOM.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpMasterInnerBOM.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpMasterInnerBOM.put(ConstantsUtil.STATE, sbEBOMState.toString());
			mpMasterInnerBOM.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
			mpMasterInnerBOM.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
			mpMasterInnerBOM.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		} catch (Exception e) {
			LOGGER.error("Error from FinishsedProductPartBO :  updateMasterInnerPackBom" + e);
			return new HashMap();
		}
		return util.filterMapList(mpMasterInnerBOM);
	}


	/**
	 * Method Name 			: getAttributes
	 * Method Description 	:
	 * @param context
	 * @param mpsPerformChar
	 * @return
	 * @throws Exception
	 */
	public MapList getAttributes(Context context, MapList mpsPerformChar) throws Exception {
		MapList mlTempList = new MapList();
		StringValidatorUtil validator = new StringValidatorUtil();
		Iterator objectListItr = mpsPerformChar.iterator();

		try {
			//SPEC: <02.08.2022>: Guna Added for 48041 Defect   Dev 22x    -- START
			StringBuilder sbWhere =new StringBuilder();
			sbWhere.append(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE).append("==").append(ConstantsUtil.STR_LOCAL);
			StringList selectStmts = new StringList();
            selectStmts.add(DomainConstants.SELECT_NAME);
            selectStmts.add(DomainConstants.SELECT_REVISION);
            selectStmts.add(DomainConstants.SELECT_ID);
            selectStmts.add(ConstantsUtil.SELECT_ATTR_REFERENCE_TYPE);
            selectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
            StringList selectRelStmts = new StringList(1);
            selectRelStmts.add(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
          //SPEC: <02.08.2022>: Guna Added for 48041 Defect   Dev 22x    -- END
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sObjId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String relationship = (String) objectMap.get("relationship");
				String strSeq = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

				if (UIUtil.isNotNullAndNotEmpty(sObjId) && !ConstantsUtil.BLANK.equals(sObjId)) {
					DomainObject dob = new DomainObject(sObjId);
					StringList PerformTestMethodSelect =new StringList();
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_NAME);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_TONAME);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_TYPE);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_ID);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_TO_ID);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_IPCLASS);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_TO_IPCLASS);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);
					PerformTestMethodSelect.add(ConstantsUtil.STR_REF_DOC_FROMIPCLASS);
					PerformTestMethodSelect.add(ConstantsUtil.SELECT_REF_DOC_TO_CSS);
					PerformTestMethodSelect.add(ConstantsUtil.STR_REF_DOC_IPCLASS);
					Map<String, String> resultMap = dob.getInfo(context, util.getPerformCharSelects(),PerformTestMethodSelect);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39416  by gaikwad.tg on Date 17 Feb 2021 -- END
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_TO_CSS);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39416  by gaikwad.tg on Date 17 Feb 2021 -- END
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_TYPE);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_IPCLASS);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_ID);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_ATTRIBUTE_SHAREWITHSUPPLIERS);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_TONAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_TO_ID);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REF_DOC_TO_IPCLASS);
					
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_REF_DOC_FROMIPCLASS);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_REF_DOC_IPCLASS);
					//SPEC: <02.08.2022>: Guna Added for 48041 Defect   Dev 22x    -- START
					MapList connectedPartList = dob.getRelatedObjects(context, //context
							ConstantsUtil.RELATIONSHIP_EXTENDEDDATA, // relationshipPattern
							ConstantsUtil.SYMBL_ASTERISK,  // typePattern
							selectStmts, // objectSelects
							selectRelStmts, // relationshipSelects
							true, // getTo
							false, // getFrom
							(short)1, // recurseToLevel
							ConstantsUtil.EMPTY_STRING, // objectWhere
							sbWhere.toString(),// relationshipWhere 
							0); // limit 
					
					String sName =ConstantsUtil.EMPTY_STRING;
					String sRev =ConstantsUtil.EMPTY_STRING;
					String sId =ConstantsUtil.EMPTY_STRING;
					String sTitle =ConstantsUtil.EMPTY_STRING;
					String sType =ConstantsUtil.EMPTY_STRING;
 				    if(!connectedPartList.isEmpty()) {
						Iterator<Map> mapItr =connectedPartList.iterator();
						while (mapItr.hasNext()) {
      	                 Map  map = mapItr.next();
	                     sName =(String)map.get(DomainConstants.SELECT_NAME);
		                 sRev =(String)map.get(DomainConstants.SELECT_REVISION);
		                 sId =(String)map.get(DomainConstants.SELECT_ID);
		                 sType =(String)map.get(DomainConstants.SELECT_TYPE);
		                 sTitle =(String)map.get(DomainConstants.SELECT_ATTRIBUTE_TITLE);
						}
					}
					resultMap.put(ConstantsUtil.PERFORMCHAR_ID, sId);
					resultMap.put(ConstantsUtil.PERFORMCHAR_TYPE, sType);
					resultMap.put(ConstantsUtil.PERFORMCHAR_MPT_TITLE, sTitle);
					//SPEC: <02.08.2022>: Guna Added for 48041 Defect   Dev 22x    -- END
					
									String Path = sName + ConstantsUtil.EMPTY_SPACE + sRev;
									resultMap.put(ConstantsUtil.PATH, Path);
									resultMap.putAll(resultMap);
									resultMap.put("relationship", relationship);
									resultMap.put(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE, strSeq);
									mlTempList.add(resultMap);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					dob.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END				
				}
			}

		} catch (Exception e) {
			LOGGER.error("Error from FinishsedProductPartBO :  getAttributes" + e);
			return new MapList();
		}
		
		return mlTempList;
		
	}


	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList() {

		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE); 
		slMultiSelects.add(ConstantsUtil.SELECT_COS_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		slMultiSelects.add(ConstantsUtil.STR_EBOM_TYPE);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_NAME);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_PGCHANGE);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_FN);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_ATTRITITLE);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_TYPE);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_SUBSTITUTE);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_QUANTITY);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_BASEUOM);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_BASEUOM);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_RELEASEDATE);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_REVISION);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_CURRENT);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_STAGE);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_REFERENCEDESIGNATOR);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_OPTIONALCOMPONENT);
		slMultiSelects.add(ConstantsUtil.STR_CLASSI_EBOM_ID);

		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDED_DATA_GTIN);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);

		// Jwala Added for Defect 39716  18x.5.2 Release -- START
		//slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE);

		//SPEC: Release SR18x5.2- Added for Defect #40005 by Govind on Date 19/02/2021 start
		slMultiSelects.add(ConstantsUtilIRM.SELECT_STACKPATTERNISPRESENT);
		//SPEC: Release SR18x5.2- Added for Defect #40005 by Govind on Date 19/02/2021 end

		// Jwala Added for Defect 39716  18x.5.2 Release -- END

		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);


		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);
		slMultiSelects.add(ConstantsUtil.STR_IPCLASS);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_ID);

		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_WAREHOUSE_NAME);

		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID);

		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_ID);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TYPE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE);

		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2);

		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);


		//SPEC: <11.07.2020>: Added for req 18x.5 ## -- START
		slMultiSelects.add(ConstantsUtil.PRIMARY_PACKAGING_TYPE);
		//SPEC: <11.07.2020>: Added for req 18x.5 ## -- END

		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- START
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
		
		//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- START
		slMultiSelects.add(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC_TYPE);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC_ID);
		//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- END
		
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- START
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- END
	
		
		return slMultiSelects;
	}

	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	: Removing multi selects from
	 * 						 DomainConstants after getting the information
	 */
	public  void removeMultiList() {

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_PGCHANGE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_FN);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_ATTRITITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_SUBSTITUTE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_QUANTITY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_BASEUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_BASEUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_RELEASEDATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_STAGE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_REFERENCEDESIGNATOR);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_REFERENCE_OPTIONALCOMPONENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_CLASSI_EBOM_ID);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDED_DATA_GTIN);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		// Jwala Added for Defect 39716  18x.5.2 Release -- START
		//DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE);
		// Jwala Added for Defect 39716  18x.5.2 Release -- END
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);


		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_ID);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_WAREHOUSE_NAME);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);

		//SPEC: <11.07.2020>: Added for req 18x.5 ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.PRIMARY_PACKAGING_TYPE);
		//SPEC: <11.07.2020>: Added for req 18x.5 ## -- END

		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
	}

	
	/**
	 * Method Name 			: UpdateTransportChar
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map UpdateTransportChar(Context context , Map objectMap){
		
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String,String> mpTransportUnit = new HashMap<String,String>();
		try 
		{
			
			StringList slPalletType =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE));
			StringList slGtin=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDED_DATA_GTIN));
			StringList slOutDimDepth =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH));
			StringList slOutDimWidth =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH));
			StringList slOutDimHght=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT));
			StringList slOutDimUOM=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM));
			StringList slTUP_VOLUME=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME));
			StringList slITUP_UOM =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM));
			//SPEC: <11.20.2020>: Chandra Commented for Defect :37490 ## --START
			//StringList slGW_WITH_Pallet =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET));
			//StringList slGW_WITHout_Pallet =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET));
			//SPEC: <11.20.2020>: Chandra Commented for Defect :37490 ## --END
			StringList slGW_UOM =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM));
			StringList slCustomlayerperTup =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER));
			StringList sllayerperTup=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP));
			StringList slCUPPerTUp =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP));
			StringList slcubeEff =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF));
			StringList slPalletMXhgt =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT));
			StringList slCASMaxHGt =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT));
			StringList slTruckMXHGT =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT));
			
			//SPEC: Release SR18x.5.2: Jwala Added for Defect :39273 ## --START
			//StringList slStackPattern =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN));
			StringList slStackPattern =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME));
			//SPEC: Release SR18x.5.2: Jwala Added for Defect :39273 ## --END
			
			//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --START
			StringList slStackPatternId =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID));
			StringList slStackPatternType =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE));
			//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --END
			
			String sPalletType = validator.isNotNullOrEmpty(slPalletType.toString()) ? slPalletType.toString(): ConstantsUtil.EMPTY_STRING;
			String sGtin = validator.isNotNullOrEmpty(slGtin.toString()) ? slGtin.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimDepth = validator.isNotNullOrEmpty(slOutDimDepth.toString()) ? slOutDimDepth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimWidth = validator.isNotNullOrEmpty(slOutDimWidth.toString()) ? slOutDimWidth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimHght = validator.isNotNullOrEmpty(slOutDimHght.toString()) ? slOutDimHght.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimUOM = validator.isNotNullOrEmpty(slOutDimUOM.toString()) ? slOutDimUOM.toString(): ConstantsUtil.EMPTY_STRING;
			String sTUP_VOLUME = validator.isNotNullOrEmpty(slTUP_VOLUME.toString()) ? slTUP_VOLUME.toString(): ConstantsUtil.EMPTY_STRING; 
			String sITUP_UOM = validator.isNotNullOrEmpty(slITUP_UOM.toString()) ? slITUP_UOM.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: <11.20.2020>: Chandra Commented for Defect :37490 ## --START
			//String sGW_WITH_Pallet = validator.isNotNullOrEmpty(slGW_WITH_Pallet.toString()) ? slGW_WITH_Pallet.toString(): ConstantsUtil.EMPTY_STRING;
			//String sGW_WITHout_Pallet = validator.isNotNullOrEmpty(slGW_WITHout_Pallet.toString()) ? slGW_WITHout_Pallet.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: <11.20.2020>: Chandra Commented for Defect :37490 ## --END
			String sGW_UOM = validator.isNotNullOrEmpty(slGW_UOM.toString()) ? slGW_UOM.toString(): ConstantsUtil.EMPTY_STRING;
			String sCustomlayerperTup = validator.isNotNullOrEmpty(slCustomlayerperTup.toString()) ? slCustomlayerperTup.toString(): ConstantsUtil.EMPTY_STRING;
			String slayerperTup = validator.isNotNullOrEmpty(sllayerperTup.toString()) ? sllayerperTup.toString(): ConstantsUtil.EMPTY_STRING;
			String sCUPPerTUp = validator.isNotNullOrEmpty(slCUPPerTUp.toString()) ? slCUPPerTUp.toString(): ConstantsUtil.EMPTY_STRING;
			String scubeEff = validator.isNotNullOrEmpty(slcubeEff.toString()) ? slcubeEff.toString(): ConstantsUtil.EMPTY_STRING;
			String sPalletMXhgt = validator.isNotNullOrEmpty(slPalletMXhgt.toString()) ? slPalletMXhgt.toString(): ConstantsUtil.EMPTY_STRING;
			String sCASMaxHGt = validator.isNotNullOrEmpty(slCASMaxHGt.toString()) ? slCASMaxHGt.toString(): ConstantsUtil.EMPTY_STRING;
			String sTruckMXHGT = validator.isNotNullOrEmpty(slTruckMXHGT.toString()) ? slTruckMXHGT.toString(): ConstantsUtil.EMPTY_STRING;
			String sStackPattern  = validator.isNotNullOrEmpty(slStackPattern.toString()) ? slStackPattern.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --START
			String sStackPatternId  = validator.isNotNullOrEmpty(slStackPatternId.toString()) ? slStackPatternId.toString(): ConstantsUtil.EMPTY_STRING;
			String sStackPatternType  = validator.isNotNullOrEmpty(slStackPatternType.toString()) ? slStackPatternType.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --END
			
			//SPEC: Release SR18x5.2- Added for Defect #40005 by Govind on Date 19/02/2021 start
			StringList slStackPatternIsPresent = validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtilIRM.SELECT_STACKPATTERNISPRESENT)); 
			if(slStackPatternIsPresent!=null) {
				int j=0;
				sStackPatternId="";
				sStackPatternType="";
				sStackPattern="";
				for(int i=0;i<slStackPatternIsPresent.size();i++) {
					String strtemp=(String)slStackPatternIsPresent.get(i);
					if(strtemp.equalsIgnoreCase("True")){
						sStackPatternId+=(String)slStackPatternId.get(j)+ConstantsUtil.SYMBL_PIPE;
						sStackPatternType+=(String)slStackPatternType.get(j)+ConstantsUtil.SYMBL_PIPE;
						sStackPattern+=(String)slStackPattern.get(j)+ConstantsUtil.SYMBL_PIPE;
					} else {
						sStackPatternId+=ConstantsUtil.EMPTY_STRING + ConstantsUtil.SYMBL_PIPE;
						sStackPatternType+=ConstantsUtil.EMPTY_STRING + ConstantsUtil.SYMBL_PIPE;
						sStackPattern+=ConstantsUtil.EMPTY_STRING + ConstantsUtil.SYMBL_PIPE;
					}
				}
			}
			//SPEC: Release SR18x5.2- Added for Defect #40005 by Govind on Date 19/02/2021 end
			
			sPalletType = util.replaceSpecialSymbols(sPalletType);
			sGtin = util.replaceSpecialSymbols(sGtin);
			sOutDimDepth = util.replaceSpecialSymbols(sOutDimDepth);
			sOutDimWidth = util.replaceSpecialSymbols(sOutDimWidth);
			sOutDimHght = util.replaceSpecialSymbols(sOutDimHght);
			sOutDimUOM = util.replaceSpecialSymbols(sOutDimUOM);
			sTUP_VOLUME = util.replaceSpecialSymbols(sTUP_VOLUME);
			sITUP_UOM = util.replaceSpecialSymbols(sITUP_UOM);
			
			//SPEC: <11.20.2020>: Chandra Added for Defect :37490 ## --START
			
			
			String sGW_WITH_Pallet=getDataWithComma(objectMap, ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
			String sGW_WITHout_Pallet=getDataWithComma(objectMap, ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
			//SPEC: <11.20.2020>: Chandra Added for Defect :37490 ## --END
			
			sGW_UOM = util.replaceSpecialSymbols(sGW_UOM);
			sCustomlayerperTup = util.replaceSpecialSymbols(sCustomlayerperTup);
			slayerperTup = util.replaceSpecialSymbols(slayerperTup);
			sCUPPerTUp = util.replaceSpecialSymbols(sCUPPerTUp);
			scubeEff = util.replaceSpecialSymbols(scubeEff);
			sPalletMXhgt = util.replaceSpecialSymbols(sPalletMXhgt);
			sCASMaxHGt = util.replaceSpecialSymbols(sCASMaxHGt);
			sTruckMXHGT = util.replaceSpecialSymbols(sTruckMXHGT);
			sStackPattern = util.replaceSpecialSymbols(sStackPattern);
			//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --START
			sStackPatternId = util.replaceSpecialSymbols(sStackPatternId);
			sStackPatternType = util.replaceSpecialSymbols(sStackPatternType);
			//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --END

			mpTransportUnit.put(ConstantsUtil.PALLETTYPE,sPalletType);
			mpTransportUnit.put(ConstantsUtil.GTIN,sGtin);
			mpTransportUnit.put(ConstantsUtil.DEPTH,sOutDimDepth);
			mpTransportUnit.put(ConstantsUtil.WIDTH,sOutDimWidth);
			mpTransportUnit.put(ConstantsUtil.HEIGHT,sOutDimHght);
			mpTransportUnit.put(ConstantsUtil.TUPVOLUME,sTUP_VOLUME);
			mpTransportUnit.put(ConstantsUtil.TUPUOM,sITUP_UOM);
			mpTransportUnit.put(ConstantsUtil.DIMENSIONUNITOFMEASURE,sOutDimUOM);
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHPALLET,sGW_WITH_Pallet);
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHOUTPALLET,sGW_WITHout_Pallet);
			mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE1,sGW_UOM);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERLAYER,sCustomlayerperTup);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFLAYERSPERTRANSPORTUNIT,slayerperTup);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERTRANSPORTUNIT,sCUPPerTUp);
			mpTransportUnit.put(ConstantsUtil.WAREHOUSEPALLETSTACKHEIGHTMAXIMUM,sPalletMXhgt);
			mpTransportUnit.put(ConstantsUtil.WAREHOUSECASESTACKHEIGHTMAXIMUM,sCASMaxHGt);
			mpTransportUnit.put(ConstantsUtil.TRUCKPALLETSTACKHEIGHTMAXIMUM,sTruckMXHGT);
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODE,sStackPattern);
			mpTransportUnit.put(ConstantsUtil.CUBEEFFICIENCY,scubeEff);
			//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --START
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODEID,sStackPatternId);
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODETYPE,sStackPatternType);
			//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --END

		} catch (Exception e) {
			LOGGER.error("Exception in Program : FinishedProductPartBO Method :UpdateTransportChar "+e);
			return new HashMap();

		}
		return mpTransportUnit;
	}

	
	/**
	 * Method Name 			: UpdatePackagingChar
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map UpdatePackagingChar(Context context , Map objectMap){
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String,String> mpPackingUnit = new HashMap<String,String>();
		StringList slCop =  new StringList();
		StringList slCup =  new StringList();
		//SPEC: Release SR18x.5.2 - Added for Defect# 39185  by Jwala -- START
		StringBuilder sbCssType= new StringBuilder();
		//SPEC: Release SR18x.5.2 - Added for Defect# 39185  by Jwala -- END
		try 
		{
			StringList slId =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_ID));
			StringList slCssType =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE));
			StringList slOutDimUOM=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_UOM));
			StringList slGtin=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GTIN));
			StringList slOutDimDepth =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_DEPTH));
			StringList slOutDimWidth =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_WIDTH));
			StringList slOutDimHght=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT));
			StringList slDIM_UOM =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM));
			StringList slGrossWeight=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT));
			StringList slGW_UOM =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM));
			StringList slConsumerPerPackUnit =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT));
			StringList slNetweightProd=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION));
			StringList slNet_UOM =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM));
			StringList slcubeEff =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY));

			
			String sCssType = validator.isNotNullOrEmpty(slCssType.toString()) ? slCssType.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimUOM = validator.isNotNullOrEmpty(slOutDimUOM.toString()) ? slOutDimUOM.toString(): ConstantsUtil.EMPTY_STRING;
			String sGtin = validator.isNotNullOrEmpty(slGtin.toString()) ? slGtin.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimDepth = validator.isNotNullOrEmpty(slOutDimDepth.toString()) ? slOutDimDepth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimWidth = validator.isNotNullOrEmpty(slOutDimWidth.toString()) ? slOutDimWidth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimHght = validator.isNotNullOrEmpty(slOutDimHght.toString()) ? slOutDimHght.toString(): ConstantsUtil.EMPTY_STRING;
			String sGrossWeight = validator.isNotNullOrEmpty(slGrossWeight.toString()) ? slGrossWeight.toString(): ConstantsUtil.EMPTY_STRING;
			String sConsumerPerPackUnit = validator.isNotNullOrEmpty(slConsumerPerPackUnit.toString()) ? slConsumerPerPackUnit.toString(): ConstantsUtil.EMPTY_STRING;
			String sNetweightProd = validator.isNotNullOrEmpty(slNetweightProd.toString()) ? slNetweightProd.toString(): ConstantsUtil.EMPTY_STRING;
			String scubeEff = validator.isNotNullOrEmpty(slcubeEff.toString()) ? slcubeEff.toString(): ConstantsUtil.EMPTY_STRING;
			String sId = validator.isNotNullOrEmpty(slId.toString()) ? slId.toString(): ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.5.2 - Added for Defect# 39308  by Guna on Date 11/02/2021 -- START
			StringBuilder sDIM_UOM =new StringBuilder();
			StringBuilder sGW_UOM =new StringBuilder();
			StringBuilder sNetUOm =new StringBuilder();
			if(slDIM_UOM.size() !=0){
				for(int i=0;i<slDIM_UOM.size();i++){
				util.formatData(sDIM_UOM, (String)slDIM_UOM.get(i));
				util.formatData(sGW_UOM, (String)slGW_UOM.get(i));
				util.formatData(sNetUOm, (String)slNet_UOM.get(i));
				}
			}
			//SPEC: Release SR18x.5.2 - Added for Defect# 39308  by Guna on Date 11/02/2021 -- END
			
			//For some objects Data coming wrong from DB if in case of empty values. This is temporary till we find exact Data/issue
			//print bus 20336.41905.30016.25869 select from[Extended Data].to[pgPackingUnitCharacteristic].attribute[pgCSSType];
			//print bus 20336.41905.63874.35683 select from[Extended Data].to[pgPackingUnitCharacteristic].attribute[pgCSSType];
			if("[Inner_Pack, Customer_Unit, Consumer_Unit]".equalsIgnoreCase(sCssType)){
				sCssType = "Consumer_Unit| Inner_Pack| Customer_Unit";
			}
			
			sCssType = util.replaceSpecialSymbols(sCssType);
			//SPEC: Release SR18x.5.2 - Added for Defect# 39185  by Jwala -- START
			String[] aCssType = sCssType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			for (String strCssType : aCssType){
				sCssType = util.mapPackingUnitType(strCssType);	
				sbCssType.append(sCssType);
				sbCssType.append("|");
			}
			//SPEC: Release SR18x.5.2 - Added for Defect# 39185  by Jwala -- END
			sOutDimUOM = util.replaceSpecialSymbols(sOutDimUOM);
			sGtin = util.replaceSpecialSymbols(sGtin);
			sOutDimDepth = util.replaceSpecialSymbols(sOutDimDepth);
			sOutDimWidth = util.replaceSpecialSymbols(sOutDimWidth);
			sOutDimHght = util.replaceSpecialSymbols(sOutDimHght);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- START
			//sDIM_UOM = util.replaceSpecialSymbols(sDIM_UOM);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- END
			sGrossWeight = util.replaceSpecialSymbols(sGrossWeight);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- START
			//sGW_UOM = util.replaceSpecialSymbols(sGW_UOM);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- END
			sConsumerPerPackUnit = util.replaceSpecialSymbols(sConsumerPerPackUnit);
			sNetweightProd = util.replaceSpecialSymbols(sNetweightProd);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- START
			//sNetUOm = util.replaceSpecialSymbols(sNetUOm);
			//SPEC: Release SR18x.5.2 - Commented for Defect# 39308  by Guna on Date 11/02/2021 -- END
			scubeEff = util.replaceSpecialSymbols(scubeEff);
			sId = util.replaceSpecialSymbols(sId);
			
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39185  by Jwala -- START
			//mpPackingUnit.put(ConstantsUtil.PACKINGUNITTYPE, sCssType);
			mpPackingUnit.put(ConstantsUtil.PACKINGUNITTYPE, sbCssType.toString());
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39185  by Jwala -- END
			mpPackingUnit.put(ConstantsUtil.AUOM, sOutDimUOM);
			mpPackingUnit.put(ConstantsUtil.DEPTH, sOutDimDepth);
			mpPackingUnit.put(ConstantsUtil.WIDTH, sOutDimWidth);
			mpPackingUnit.put(ConstantsUtil.HEIGHT, sOutDimHght);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- START
			//mpPackingUnit.put(ConstantsUtil.DIMENSIONUNITOFMEASURE, sDIM_UOM);
			mpPackingUnit.put(ConstantsUtil.DIMENSIONUNITOFMEASURE, sDIM_UOM.toString());
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- END
			mpPackingUnit.put(ConstantsUtil.GROSSWEIGHT, sGrossWeight);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- START
			//mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE, sGW_UOM);
			mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE, sGW_UOM.toString());
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- END
			mpPackingUnit.put(ConstantsUtil.NUMBEROFCONSUMERUNITSPERUNIT, sConsumerPerPackUnit);
			mpPackingUnit.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCONSUMERUNIT, sNetweightProd);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- START
			//mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE1, sNetUOm);
			mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE1, sNetUOm.toString());
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39116  by Guna on Date 11/02/2021 -- END
			mpPackingUnit.put(ConstantsUtil.CUBEEFFICIENCY, scubeEff);
			mpPackingUnit.put(ConstantsUtil.GTIN,sGtin.toString());
			mpPackingUnit.put(ConstantsUtil.ID,sId.toString());
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39185  by Jwala -- START
			//mpPackingUnit.put(ConstantsUtil.TYPE, sCssType);
			mpPackingUnit.put(ConstantsUtil.TYPE, sbCssType.toString());
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39185  by Jwala -- END
			
			mpPackingUnit = util.verifyOwnership(context, mpPackingUnit);

		} catch (Exception e) {
			LOGGER.error("Exception in Program : FinishedProductPartBO Method :UpdatePackagingChar "+e);
			return new HashMap();
		}
		return mpPackingUnit;
	}

	
	/**
	 * Method Name 			: parseBOMMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseBOMMaplist(Context context,MapList mapList) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMREV = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMComment = new StringBuilder();
		StringBuilder sbEBOMState = new StringBuilder();
		StringBuilder sbEBOMStage = new StringBuilder();
		StringBuilder sbEBOMRDOC = new StringBuilder();
		StringBuilder sbEBOMRevRelDt = new StringBuilder();
		
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		
		//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlternate = new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDensityUOM = new StringBuilder();
		//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- END
		
		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			int iLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));
			if (iLevel == 1) {
			
				String sParentId =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID);
				String sParentName =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME);
				String sParentRevision =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV);
				String sParentType =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE);

				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sReleaseDate = validator.DateFormatter((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
				String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON+ sReleaseDate;
				String spgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				//String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sTitle = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				
				String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				
				//SPEC: <11.20.2020>: Chandra Added for Defect :37530 ## --START
				//SPEC: <11.20.2020>: Added for Defect :37589 ## --START
				String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				//String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
				//SPEC: <11.20.2020>: Chandra Added for Defect :37530 ## --START
				
				String sBuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				String sComments = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT))?(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT):ConstantsUtil.EMPTY_STRING;
				String sComment = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				sCurrent=util.mapType(sCurrent);
				String sStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				sRD =util.replaceSpecialSymbols(sRD);
				String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sOC = util.replaceSpecialSymbols(sOC);
				String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
				
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
				String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
				
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
				//String sAlternate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
				//sAlternate = sAlternate.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
				strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strAltID = util.checkAlternateHasAccess(context,objectMap);	
				String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
				strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);				
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
				String sOSPD = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY));
				String sDensityUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM));
				//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- END
				
				String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
				boolean bHasOwnership = false;
				SecurityService sct = new SecurityService();
				boolean showData = false;
				String sFormulaPropagate = sId;
				boolean bHasOwnershipParent = false;
				boolean showDataParent = false;
				
				if(util.isModificatinRequired())
				{
					String sUserType=sct.getUserType();
					bHasOwnership=util.checkHasAccess(context, sUserType, sId);
					if(!bHasOwnership)
					{
						sTitle = ConstantsUtil.NO_ACCESS;
						spgChg = ConstantsUtil.NO_ACCESS;
						sFN    = ConstantsUtil.NO_ACCESS;
						sComments = ConstantsUtil.NO_ACCESS;
						sComment = ConstantsUtil.NO_ACCESS;
						sStage = ConstantsUtil.NO_ACCESS;
						sRDOC = ConstantsUtil.NO_ACCESS;
						sId = ConstantsUtil.NO_ACCESS;
						sReleaseDate = ConstantsUtil.NO_ACCESS;
						sQty = ConstantsUtil.NO_ACCESS;
						sBuom = ConstantsUtil.NO_ACCESS;
						sCurrent = ConstantsUtil.NO_ACCESS;
						sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						
						//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- START
						sOSPD = ConstantsUtil.NO_ACCESS;
						sDensityUOM = ConstantsUtil.NO_ACCESS;						
						//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- END
					}
					bHasOwnershipParent=util.checkHasAccess(context, sUserType, sParentId);
					if(!bHasOwnershipParent) {
						sParentId = ConstantsUtil.NO_ACCESS;
					}
				}else if(sct.isStaffAUGUser()) {
                   //Added by Ganesh 1.0.2 Release Start
					String sUserType=sct.getUserType();
					showData=util.checkHasAccess(context, sUserType, sId);
					//Added by Ganesh 1.0.2 Release End
					showDataParent=util.checkHasAccess(context, sUserType, sParentId);
				}else {
					
					String sUserType=sct.getUserType();
                 showData=util.checkHasAccess(context, sUserType, sId);
                 showDataParent=util.checkHasAccess(context, sUserType, sParentId);
               //Added by Ganesh 1.0.2 Release Start
				}	
				if(!util.isModificatinRequired()) {
					if(!showData){
						spgChg = ConstantsUtil.NO_ACCESS;
						sId = ConstantsUtil.NO_ACCESS;
					}
					if(!showDataParent) {
						sParentId = ConstantsUtil.NO_ACCESS;
					}
				}
				
				sType = util.mapType(sType);
				sParentType = util.mapType(sParentType);

				//Security req -33193 HIR Components Attributes to Show
				formatData(sbEBOMType, sType);
				formatData(sbEBOMName, sName);
				formatData(sbEBOMREV, sRevision);
				formatData(sbEBOMQTY, sQty);
				formatData(sbEBOMBuom, sBuom);
				formatData(sbEBOMState, sCurrent);

				formatData(sbEBOMId, sId);
				formatData(sbEBOMChg, spgChg);
				formatData(sbEBOMFN, sFN);
				formatData(sbEBOMTitle, sTitle);
				formatData(sbEBOMCommnts, sComments);
				formatData(sbEBOMComment, sComment);
				formatData(sbEBOMStage, sStage);
				formatData(sbEBOMRDOC, sRDOC);
				formatData(sbEBOMRevRelDt, sRevRelease);
				
				formatData(sbEBOMParentId,sParentId);
				formatData(sbEBOMParentName,sParentName);
				formatData(sbEBOMParentRevision,sParentRevision);
				formatData(sbEBOMParentType,sParentType);
				
				//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- START
				
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
				//formatData(sbEBOMAlternate, sAlternate);
				formatData(sbAltName,strAltName);
				formatData(sbAltID,strAltID);
				formatData(sbAltType,strAltType);
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
				formatData(sbEBOMOSPD, sOSPD);
				formatData(sbEBOMDensityUOM, sDensityUOM);
				
				util.formatData(sbEBOMSubstitutePart, strSubPart);
				util.formatData(sbEBOMSubPartID, strSubPartId);
				util.formatData(sbEBOMSubPartType, strSubPartType);
				//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
			}
			mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.REVISION, sbEBOMREV.toString());
			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
			mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
			mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
			
			//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- START			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlternate.toString());
			mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
			mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
			mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
			mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDensityUOM.toString());
			
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
			
			//SPEC: <10.20.2020>: Modified for req 18x.5 ## -- END
			
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
		}
		return  util.filterMapList(mpEBOMResult);
	}
	
	//SPEC: <31.05.2022>: Guna Modified for Req 41754 22x Release  -- START
		/**
		 * Method Name 			: parseMaplist : Overloaded
		 * Method Description 	:
		 * @param context
		 * @param mapList
		 * @param boolean
		 * @return
		 */
		public Map<String, String> parseMaplist(Context context,MapList mapList,boolean bParent) 
		{
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Iterator objectListItr = mapList.iterator();
			SecurityService sec = new SecurityService();
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			StringBuilder sbEBOMParentRevision = new StringBuilder();
			StringBuilder sbEBOMParentType = new StringBuilder();
			mpEBOMResult = parseMaplist(context, mapList);
			if(bParent == true) {
				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String sParentId =(String)objectMap.get(ConstantsUtilIRM.PARENT_ID);
					String sParentName =(String)objectMap.get(ConstantsUtilIRM.PARENT_NAME);
					String sParentRevision =(String)objectMap.get(ConstantsUtilIRM.PARENT_REVISION);
					String sParentType =(String)objectMap.get(ConstantsUtilIRM.PARENT_TYPE);
					
					boolean bHasOwnershipParent = false;
					boolean showDataParent = false;
					
					if(util.isModificatinRequired()) {
						bHasOwnershipParent=util.checkHasAccess(context, null, sParentId);
						if(!bHasOwnershipParent) {
							sParentId = ConstantsUtil.NO_ACCESS;
						}
					}else if(sec.isStaffAUGUser()) {
						showDataParent=util.checkHasAccess(context, null, sParentId);
						
					} else{
						showDataParent=util.checkHasAccess(context, null, sParentId);
					}
					if(!util.isModificatinRequired()) {
						if(!showDataParent) {
							sParentId = ConstantsUtil.NO_ACCESS;
						}
					}
					sParentType = util.mapType(sParentType);
					
					formatData(sbEBOMParentId,sParentId);
					formatData(sbEBOMParentName,sParentName);
					formatData(sbEBOMParentRevision,sParentRevision);
					formatData(sbEBOMParentType,sParentType);
				}
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
			}
			return mpEBOMResult;
			
		}
	
	//SPEC: <31.05.2022>: Guna Modified for Req 41754 22x Release  -- START
	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context,MapList mapList) 
	{
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMTupName= new StringBuilder();
		//Added by Subhajit for Req 46464 - Start
		StringBuilder sbRelRestriction= new StringBuilder();
		StringBuilder sbRelRestrictionComment= new StringBuilder();
		//Added by Subhajit for Req 46464 - End
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlternate = new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDensityUOM = new StringBuilder();
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		StringBuilder sbGrossWeightReal = new StringBuilder(); //Modified by Ketan for req no. 41754 on 06.14.2022
		StringBuilder sbGrossWeightUOM = new StringBuilder();
		StringBuilder sbNSPCG = new StringBuilder();
		
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			String sId =(String)objectMap.get(ConstantsUtil.SELECT_ID);
			String sName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
			String sRevision =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
			//Added by Subhajit for Req 46464 - Start
			String sRelRestriction = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
			String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
			//Added by Subhajit for Req 46464 - End
			String sReleaseDate =validator.DateFormatter((String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
			String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			String spgChg =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
			String sFN =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			String sTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			String sType =(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
			String sTupName =(String)objectMap.get(ConstantsUtil.TUPNAME);
			String sSubstitute=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
			sSubstitute = util.replaceSpecialSymbols(sSubstitute);
			String sQty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			String sBuom =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
			String sComments=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			String sCurrent =(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
			sCurrent=util.mapType(sCurrent.trim());
			String sStage =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			String sRD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
			sRD = util.replaceSpecialSymbols(sRD);
			String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
			sOC = util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;

			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//String sAlternate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
			//sAlternate = sAlternate.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
			strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strAltID = util.checkAlternateHasAccess(context,objectMap);	
			String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
			strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			String sOSPD = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY));
			String sDensityUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM));
			
					
			String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			
			String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
			String strGrossWeightReal = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));//Modified by Ketan for req no. 41754 on 06.14.2022
			String strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));//Modified by Ketan for req no. 41754 on 06.14.2022
			String sNSPCG = (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
			boolean bHasOwnership = false;
			
			String sFormulaPropagate = sId;
			if(util.isModificatinRequired())
			{
				
				bHasOwnership=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End
				if(!bHasOwnership)
				{
						spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
					sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
				}
				
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			}else{
				boolean showData = true;
				
				//Added by Ganesh 1.0.2 Release Start
					showData=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End
					if(!showData){
						spgChg = ConstantsUtil.NO_ACCESS;
						sId = ConstantsUtil.NO_ACCESS;
						
					}
			}
			
			sType = util.mapType(sType);

			// Security req -33193 HIR Components Attributes to Show
			formatData(sbEBOMType,sType);
			formatData(sbEBOMName,sName);
			//Added by Subhajit for Req 46464 - Start
			formatData(sbRelRestriction,sRelRestriction);
			formatData(sbRelRestrictionComment,sRelRestrictionComment);
			//Added by Subhajit for Req 46464 - End
			formatData(sbEBOMQTY,sQty);
			formatData(sbEBOMBuom,sBuom);
			formatData(sbEBOMState,sCurrent);

			formatData(sbEBOMId,sId);
			formatData(sbEBOMChg,spgChg);
			formatData(sbEBOMFN,sFN);
			formatData(sbEBOMTitle,sTitle);
		//	formatData(sbEBOMSubstute,sSubstitute);
			formatData(sbEBOMCommnts,sComments);
			formatData(sbEBOMStage,sStage);
			formatData(sbEBOMRDOC,sRDOC);
			formatData(sbEBOMRevRelDt,sRevRelease);
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			
			formatData(sbEBOMSubstitutePart, strSubPart);
			formatData(sbEBOMSubPartID, strSubPartId);
			formatData(sbEBOMSubPartType, strSubPartType);
			
			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//formatData(sbEBOMAlternate, sAlternate);
			formatData(sbAltName,strAltName);
			formatData(sbAltID,strAltID);
			formatData(sbAltType,strAltType);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			
			formatData(sbEBOMOSPD, sOSPD);
			formatData(sbEBOMDensityUOM, sDensityUOM);
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			formatData(sbGrossWeightReal, strGrossWeightReal);//Modified by Ketan for req no. 41754 on 06.14.2022
			formatData(sbGrossWeightUOM, strGrossWeightUOM);//Modified by Ketan for req no. 41754 on 06.14.2022
			formatData(sbNSPCG, sNSPCG);
			if(null!=sTupName && !sTupName.isEmpty()) {
				formatData(sbEBOMTupName,sTupName);
			}

		}
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
	//	mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlternate.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDensityUOM.toString());
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		//Added by Subhajit for Req 46464 - Start
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
		//Added by Subhajit for Req 46464 - End
		if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());//Modified by Ketan for req no. 41754 on 06.14.2022
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());//Modified by Ketan for req no. 41754 on 06.14.2022
		mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbNSPCG.toString());
		return mpEBOMResult;
	}
	
	/**
	 * Method Name 			: parseBomCopMaplist  : Overloaded
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @param boolean
	 * @return
	 */
	
	public Map<String, String> parseBomCopMaplist(Context context,MapList mapList,boolean bParent)
    {
        Map<String,String> mpEBOMResult = new HashMap<String,String>();
        Iterator objectListItr = mapList.iterator();
        SecurityService sec = new SecurityService();
        StringBuilder sbEBOMParentName = new StringBuilder();
        StringBuilder sbEBOMParentId = new StringBuilder();
        StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
        mpEBOMResult = parseBomCopMaplist(context, mapList);
        if(bParent == true) {
            while(objectListItr.hasNext())
            {
                Map objectMap = (Map) objectListItr.next();
                String sParentId =(String)objectMap.get(ConstantsUtilIRM.PARENT_ID);
                String sParentName =(String)objectMap.get(ConstantsUtilIRM.PARENT_NAME);
                String sParentRevision =(String)objectMap.get(ConstantsUtilIRM.PARENT_REVISION);
				String sParentType =(String)objectMap.get(ConstantsUtilIRM.PARENT_TYPE);
                
				boolean bHasOwnershipParent = false;
				boolean showDataParent = false;
				
				if(util.isModificatinRequired()) {
					bHasOwnershipParent=util.checkHasAccess(context, null, sParentId);
					if(!bHasOwnershipParent) {
						sParentId = ConstantsUtil.NO_ACCESS;
					}
				}else if(sec.isStaffAUGUser()) {
					showDataParent=util.checkHasAccess(context, null, sParentId);
					
				} else{
					showDataParent=util.checkHasAccess(context, null, sParentId);
				}
				if(!util.isModificatinRequired()) {
					if(!showDataParent) {
						sParentId = ConstantsUtil.NO_ACCESS;
					}
				}
				sParentType = util.mapType(sParentType);
				
				formatData(sbEBOMParentId,sParentId);
                formatData(sbEBOMParentName,sParentName);
                formatData(sbEBOMParentRevision,sParentRevision);
                formatData(sbEBOMParentType,sParentType);
            }
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());

        }
        return mpEBOMResult;
        
    }
	
	
	/**
	 * Method Name 			: parseBomCopMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseBomCopMaplist(Context context,MapList mapList) {
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		StringBuilder sbEBOMSubstute= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMTupName= new StringBuilder();
		//Added by Subhajit for Req 46464 - Start
		StringBuilder sbRelRestriction = new StringBuilder();
		StringBuilder sbRelRestrictionComment = new StringBuilder();
		//Added by Subhajit for Req 46464 - End
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
						
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlternate = new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDensityUOM = new StringBuilder();
		String sUserlicense = sec.getUserLicense();
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		StringBuilder sbGrossWeight = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder();
		StringBuilder sbNSPCG = new StringBuilder();
		
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			String sId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
			String sName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
			String sRevision =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
			//Added by Subhajit for Req 46464 - Start
			String sRelRestriction = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
			String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
			//Added by Subhajit for Req 46464 - End
			String sReleaseDate =validator.getStringEquivalentForStringList((String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
			String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+validator.DateFormatter(sReleaseDate);
			String spgChg =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
			String sFN =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER));
			String sTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
			String sType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
			String sTupName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.TUPNAME));
			
			String sQty =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
			String sBuom =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
			
			//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- START
			//String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
			String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
			//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- END
			
			String sCurrent =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
			sCurrent=util.mapType(sCurrent);
			String sStage =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
			String sRD =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR));
			sRD = util.replaceSpecialSymbols(sRD);
			String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
			sOC = util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//String sAlternate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
			//sAlternate = sAlternate.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
			strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strAltID = util.checkAlternateHasAccess(context,objectMap);	
			String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
			strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			String sOSPD = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY));
			String sDensityUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM));
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			
			String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
			boolean showData = true;
			boolean bHasOwnership = false;
			String sFormulaPropagate = sId;
			String sGrossWeight= (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			String sGrossWeightUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			String sNSPCG = (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
			
						//SPEC: <06.18.2021>:Madhana/Ganesh Modified for 43728 defect  -- START											
			showData=util.checkHasAccess(context, null, sId);
			if(!showData){
				spgChg = ConstantsUtil.NO_ACCESS;
				sId = ConstantsUtil.NO_ACCESS;
			}
			//SPEC: <06.18.2021>:Madhana/Ganesh Modified for 43728 defect  -- END											
			
			
			sType = util.mapType(sType);
			// Security req -33193 HIR Components Attributes to Show
			formatData(sbEBOMType,sType);
			formatData(sbEBOMName,sName);
			formatData(sbEBOMQTY,sQty);
			formatData(sbEBOMBuom,sBuom);
			formatData(sbEBOMState,sCurrent);

			formatData(sbEBOMId,sId);
			formatData(sbEBOMChg,spgChg);
			formatData(sbEBOMFN,sFN);
			formatData(sbEBOMTitle,sTitle);
			formatData(sbEBOMCommnts,sComments);
			formatData(sbEBOMStage,sStage);
			formatData(sbEBOMRDOC,sRDOC);
			formatData(sbEBOMRevRelDt,sRevRelease);
			//Added by Subhajit for Req 46464 - Start
			formatData(sbRelRestriction, sRelRestriction);
			formatData(sbRelRestrictionComment, sRelRestrictionComment);
			//Added by Subhajit for Req 46464 - End
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//formatData(sbEBOMAlternate, sAlternate);
			formatData(sbAltName,strAltName);
			formatData(sbAltID,strAltID);
			formatData(sbAltType,strAltType);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			formatData(sbEBOMOSPD, sOSPD);
			formatData(sbEBOMDensityUOM, sDensityUOM);
			formatData(sbEBOMSubstitutePart, strSubPart);
			formatData(sbEBOMSubPartID, strSubPartId);
			formatData(sbEBOMSubPartType, strSubPartType);
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
			formatData(sbGrossWeight, sGrossWeight);
			formatData(sbGrossWeightUOM, sGrossWeightUOM);
			formatData(sbNSPCG, sNSPCG);
			if(null!=sTupName && !sTupName.isEmpty()) {
				formatData(sbEBOMTupName,sTupName);
			}


		}
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		//Added by Subhajit for Req 46464 - Start
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
		//Added by Subhajit for Req 46464 - End
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlternate.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDensityUOM.toString());
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		
		if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeight.toString());
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
		mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbNSPCG.toString());
		return util.filterMapList(mpEBOMResult);
	}
	//SPEC: <31.05.2022>: Guna Modified for Req 41754 22x Release  -- END
	
	
	/**
	 * Method Name 			: parseMaplistForTupSubstitute
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @param mpEBOMResult
	 * @return
	 * @throws Exception
	 */
	
	public Map<String, String> parseMaplistForTupSubstitute(Context context, MapList mapList, Map mpEBOMResult) throws Exception 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		
		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		
		StringBuilder sbSubPartType = new StringBuilder();
		StringBuilder sbSubPartName = new StringBuilder();
		StringBuilder sbSubPartRev = new StringBuilder();
		StringBuilder sbSubPartId = new StringBuilder();
		StringBuilder sbSubPartTitle = new StringBuilder();
		StringBuilder sbSubPartSpecSubType = new StringBuilder();	
		StringBuilder sbSubPartRevRelDt = new StringBuilder();
		StringBuilder sbSubPartValidStartDt = new StringBuilder();
		StringBuilder sbSubPartValidUntiltDt = new StringBuilder();
		StringBuilder sbSubPartBUOM = new StringBuilder();
		//Added by Subhajit for Req 46464 - Start
		StringBuilder sbRelRestriction = new StringBuilder();
		StringBuilder sbRelRestrictionComment = new StringBuilder();
		//Added by Subhajit for Req 46464 - End
		StringBuilder sbSubForType = new StringBuilder();
		StringBuilder sbSubstituteSCN = new StringBuilder();
		
		
		StringBuilder sbSubForName = new StringBuilder();
		StringBuilder sbSubForRev = new StringBuilder();
		StringBuilder sbSubForId = new StringBuilder();
		StringBuilder sbSubForTitle = new StringBuilder();
		StringBuilder sbSubForQty = new StringBuilder();
		
		StringBuilder sbSubForComments = new StringBuilder();
		StringBuilder sbSubForCurrent = new StringBuilder();
		StringBuilder sbSubForRDOC = new StringBuilder();
		
		StringBuilder sbSubPartChg = new StringBuilder();
		StringBuilder sbSubForSpecSubType= new StringBuilder();
		
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership = util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		
		
		try
		{
			for (int j = 0; j < mapList.size(); j++) 
			{
				MapList eachmapList = (MapList)mapList.get(j);
				Iterator objectListItr = eachmapList.iterator();
				while (objectListItr.hasNext()) 
				{
					Map objectMap = (Map) objectListItr.next();

					if (objectMap.containsKey(ConstantsUtil.SELECT_SUBSTITUTE))
					{
						String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
						String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
						String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
						String sReleaseDate = validator.DateFormatter((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
					
						
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
						String sTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
						
						String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
						//SPEC: <11.25.2020>:Guna Added for 37570 defect  -- START
						//String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
						//String sQty = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY ));
						StringList slsQty = util.getStringList(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY )));
						//Added by Subhajit for Req 46464 - Start
						StringList slRelRestriction = util.getStringList(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR )));
						StringList slRelRestrictionComment = util.getStringList(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC )));
						//String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
						//String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
						//Added by Subhajit for Req 46464 - End
						//String sComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
						
						//SPEC: <11.26.2020>:Modified for 37587 defect  -- START
						//String sComments = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						String sComments = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						//SPEC: <11.26.2020>:Modified for 37587 defect  -- END
						
						//SPEC: <11.25.2020>:Guna Added for 37570 defect  -- END
						String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
						sCurrent =  util.mapType(sCurrent.trim());
						StringList slOC = util.getStringList(validator.getStringEquivalentForStringList(objectMap.get("frommid[EBOM Substitute].attribute[pgOptionalComponent]")));
						StringList slRDOC = util.getStringList(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR)));
						
						
						String sSubPartChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						String sSubForSpecSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
						
						String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
						boolean bHasOwnership = false;
						boolean showData = true;
						boolean isExternal = util.isModificatinRequired(); 
						String sFormulaPropagate =sId;
						if (isExternal)
						{
							
							//modified by Ganesh for security impl---->start
							bHasOwnership  = util.checkHasAccess(context, null, sId);
							if(!bHasOwnership)
								{
								sId=ConstantsUtil.NO_ACCESS;
								sSubPartChg=ConstantsUtil.NO_ACCESS;
								}
							//modified by Ganesh for security impl---->end
							
						}
						//SPEC: 11/04/2020: Added for Non Employee Internal ## -- START
						else if(sec.isStaffAUGUser())
						{
							 showData = true;
							
							 //modified by Ganesh for security impl---->start
							 showData = util.checkHasAccess(context, null, sId);
							 //modified by Ganesh for security impl---->end
							
							if (!showData)
							{ 
								
								sId=ConstantsUtil.NO_ACCESS;
								sSubPartChg=ConstantsUtil.NO_ACCESS;
							}
						}else if (!isExternal) 
						{
							//modified by Ganesh for security impl---->start
							showData = util.checkHasAccess(context, null, sId);
							//modified by Ganesh for security impl---->end
							
							if (!showData)
							{ 
								sId=ConstantsUtil.NO_ACCESS;
								sSubPartChg=ConstantsUtil.NO_ACCESS;
							}
							
						}
						//SPEC: 11/04/2020: Added for Non Employee Internal ## -- END
						
						String sHasSubstitute = validator.getStringEquivalentForStringList((String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
						
						//Modified for Defect# 37591 -- START
						/*StringList slSubType = util. getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE)));*/
						StringList slSubType = util. getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE)));
						//Modified for Defect# 37591 -- END
						
						
						StringList slSubCSSType = util.getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCSSTYPE)));
						
						StringList slValidStartDate =  util.getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY)));
						StringList sltrValidUntilDt =  util.getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
						StringList slSubstituteName =  util.getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME)));
						StringList slSubstituteType =  util.getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)));
						StringList slSubstituteRev =  util.getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)));
						
						StringList slSubstituteTitle = new StringList();
						
					if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE)){
						
						String clClass = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE).getClass().getSimpleName();
						if (clClass.equals(ConstantsUtil.STRING)) {
							String sSubstituteTitle = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE))?(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE) : ConstantsUtil.EMPTY_STRING;
							slSubstituteTitle= util.getStringList(sSubstituteTitle);
							
						}else{
							
							slSubstituteTitle = validator.isNotNullOrEmpty((StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						}
						
					}
						
						StringList slSubstitutePart =  util.getStringList(validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID)));
						StringList slSubstituteReleaseDate =  util.getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE)));
						
						StringList slSubstituteSCN = util.getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER)));
						
						StringList slBuom =  util.getStringList(validator.getStringEquivalentForStringList(
								objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_BASEUNITOFMEASURE)));
						
						StringList slComments = new StringList();
						if(slSubstituteName.size()==1){
							 slComments =  util.getStringList(validator.getStringEquivalentForStringListWithComma(
									objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT)));
						}else{
							 slComments =  util.getStringList(validator.getStringEquivalentForStringList(
									objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT)));
						}
						//SPEC: <11.26.2020>: Added for Defect 37857 ## -- END
						
							for (int i = 0; i < slSubstituteName.size(); i++) 
							{
								if (UIUtil.isNotNullAndNotEmpty(sHasSubstitute)
										&& (sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)
												|| sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE))) 
								{
									String sSubstituteStartDate =  validator.DateFormatter(util.getValueFromStringList(slValidStartDate,i));
									//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
									//String sSubstituteUntilDate =  util.getValueFromStringList(sltrValidUntilDt,i);
									String sSubstituteUntilDate =  validator.DateFormatter(util.getValueFromStringList(sltrValidUntilDt,i));
									//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
									String sSubstituteName =  util.getValueFromStringList(slSubstituteName,i);
									String sSubstituteType =  util.getValueFromStringList(slSubstituteType,i);
									String sSubstituteRev =  util.getValueFromStringList(slSubstituteRev,i);
									String sSubstituteTitle =  util.getValueFromStringList(slSubstituteTitle,i);
									String sSubstitutePartId =  util.getValueFromStringList(slSubstitutePart,i);
									String sSubstituteRelDate =  validator.DateFormatter(util.getValueFromStringList(slSubstituteReleaseDate,i));
									String sSubstituteBUOM =  util.getValueFromStringList(slBuom,i);
									String sRevRelease = sSubstituteRelDate;
									String sSubstituteSCN = util.getValueFromStringList(slSubstituteSCN,i);
									String sSubstituteAssemblyType =  util.getValueFromStringList(slSubType,i);
									String strAttrPgCSSType = util.getValueFromStringList(slSubCSSType,i);
									String sQty = util.getValueFromStringList(slsQty, i);
									//Added by Ketan for Req. no. 46464 -- START
									String sRelRestriction = util.getValueFromStringList(slRelRestriction, i);
									String sRelRestrictionComment = util.getValueFromStringList(slRelRestrictionComment, i);
									//Added by Ketan for Req. no. 46464 -- START
									String sOC = util.getValueFromStringList(slOC, i);
									String sRD = util.getValueFromStringList(slRDOC, i);
									String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
									sSubstituteAssemblyType = util.getSpecificationSubtype(context, sSubstituteType, sSubstituteAssemblyType, strAttrPgCSSType);
									
									//SPEC: <11.26.2020>: Added for Defect 37857 ## -- START
									String sComment =  util.getValueFromStringList(slComments,i);
									//SPEC: <11.26.2020>: Added for Defect 37857 ## -- END
									
									DomainObject dobSubstitute = new DomainObject(sSubstitutePartId);
									//SPEC: <30.08.2021>: Guna Modified for 42792 Defect  Dev 18x.6.0.2   -- START
									//String sSubstituteIPClass = validator.getStringEquivalentForStringList(
											//objectMap.get(ConstantsUtil.STR_IPCLASS));
									StringList strList = new StringList(ConstantsUtil.STR_IPCLASS);
									DomainObject.MULTI_VALUE_LIST.add(ConstantsUtil.STR_IPCLASS);
									Map subMap =dobSubstitute.getInfo(context, strList);
									DomainObject.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
									String sSubstituteIPClass=	 validator.getStringEquivalentForStringList(subMap.get(ConstantsUtil.STR_IPCLASS));
									dobSubstitute.close(context);
									//SPEC: <30.08.2021>: Guna Modified for 42792 Defect  Dev 18x.6.0.2   -- END
									formatData(sbSubPartName, sSubstituteName);
									formatData(sbSubForType,  util.mapType(sType));
									formatData(sbSubForName, sName);
									//SPEC: <11.25.2020>:Guna Modified for 37570 defect  -- START
									formatData(sbSubPartRev, sRevision);
									formatData(sbSubForRev, sSubstituteRev);
									//SPEC: <11.25.2020>:Guna Modified for 37570 defect  -- END
									boolean bSubstuteHasAccess = false;
									
									//SPEC: 11/04/2020: Modified for Non Employee Internal ## -- START
									if (isExternal)
									{
										
										if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) 
										{
											//SPEC: <06.18.2021>:Madhana Modified for 43685 defect  -- START
											String sFormulaPropagateID = util.getFormulaPropagate(context, sSubstitutePartId);
											if(!sFormulaPropagate.isEmpty()) {
												bSubstuteHasAccess = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagateID);
											}

										}else {
											bSubstuteHasAccess = util.checkOwnerShip(context, slUserOwnership, sSubstitutePartId);
											//SPEC: <06.18.2021>:Madhana Modified for 43685 defect  -- END
										}
																			
										if (!bSubstuteHasAccess){ 
											//SPEC: <11.25.2020>:Guna Modified for 37570 defect  -- START
											//SPEC: <06.17.2021>:Madhana Modified for 43685 defect  -- START											
											formatData(sbSubPartType,  util.mapType(sSubstituteType));											
											sSubstitutePartId = ConstantsUtil.NO_ACCESS;
											sSubPartChg = ConstantsUtil.NO_ACCESS;
											//SPEC: <06.17.2021>:Madhana Modified for 43685 defect  -- END											
											formatData(sbSubPartId, sSubstitutePartId);
											formatData(sbSubPartTitle, sSubstituteTitle);
											formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
											formatData(sbSubPartRevRelDt, sRevRelease);
											formatData(sbSubPartValidStartDt, sSubstituteStartDate);
											formatData(sbSubPartValidUntiltDt, sSubstituteUntilDate);
											formatData(sbSubPartBUOM, sSubstituteBUOM);
											formatData(sbSubForComments, sComment);
											formatData(sbSubForCurrent, sCurrent);
											formatData(sbSubForRDOC, sRDOC);
											formatData(sbSubForId, sId);
											formatData(sbSubForTitle, sTitle);
											formatData(sbSubForQty, sQty);
											//Added by Subhajit for Req 46464 - Start
											util.formatData(sbRelRestriction, sRelRestriction);
											util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
											//Added by Subhajit for Req 46464 - End
											formatData(sbSubstituteSCN, sSubstituteSCN);
											formatData(sbSubPartChg, sSubPartChg);
											formatData(sbSubForSpecSubType, sSubForSpecSubType);
											//SPEC: <11.25.2020>:Guna Modified for 37570 defect  -- END
											//SPEC: <06.17.2021>:Madhana Modified for 43685 defect  -- START
											//SPEC: <08.09.2021>: Guna Added for 42792 Defect  Dev 18x.6.0.2   -- START
											formatData(sbSubPartType,  util.mapType(sSubstituteType));	
											//SPEC: <08.09.2021>: Guna Added for 42792 Defect  Dev 18x.6.0.2   -- END
											continue; 											
										}
											//continue;  
										//SPEC: <06.17.2021>:Madhana Modified for 43685 defect  -- END
									}else if(sec.isStaffAUGUser())
									{
										 bSubstuteHasAccess = false;
										//For Staff Aug USer check 
										if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) 
										{
											//Validation for Hir checks on Formulation
											//SPEC: <30.08.2021>: Guna Modified for 42792 Defect  Dev 18x.6.0.2   -- START
											String sFormulaClassif =util.getFormulaPropagateClassification(context, sSubstitutePartId);
											//SPEC: <30.08.2021>: Guna Modified for 42792 Defect  Dev 18x.6.0.2   -- END
											//SPEC: 10.11.2021: Jwala Modified for 42792 Defect 6.0.2   -- START
											//bSubstuteHasAccess=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
											bSubstuteHasAccess = util.checkHasAccess(context, null, sSubstitutePartId);
											//SPEC: 10.11.2021: Jwala Modified for 42792 Defect 6.0.2   -- END
										}else
										{
											//Validation for Hir checks for other than Formulation
											//SPEC: 10.11.2021: Jwala Modified for 42792 Defect 6.0.2   -- START
											//bSubstuteHasAccess=util.checkInternalUserAcess(sUserlicense,sSubstituteIPClass);
											bSubstuteHasAccess = util.checkHasAccess(context, null, sSubstitutePartId);
											//SPEC: 10.11.2021: Jwala Modified for 42792 Defect 6.0.2   -- END
										}
										
										if (!bSubstuteHasAccess) {
											//SPEC: <11.25.2020>:Guna Modified for 37570 defect  -- START
											//SPEC: <06.18.2021>:Madhana Modified for 43685 defect  -- START
											sSubstitutePartId = ConstantsUtil.NO_ACCESS;
											sSubPartChg = ConstantsUtil.NO_ACCESS;
											formatData(sbSubPartId, sSubstitutePartId);
											formatData(sbSubPartChg, sSubPartChg);
											//SPEC: <06.18.2021>:Madhana Modified for 43685 defect  -- END
											formatData(sbSubPartTitle, sSubstituteTitle);
											formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
											formatData(sbSubPartRevRelDt, sRevRelease);
											formatData(sbSubPartValidStartDt, sSubstituteStartDate);
											formatData(sbSubPartValidUntiltDt, sSubstituteUntilDate);
											formatData(sbSubPartBUOM, sSubstituteBUOM);
											formatData(sbSubForComments, sComment);
											formatData(sbSubForCurrent, sCurrent);
											formatData(sbSubForRDOC, sRDOC);
											formatData(sbSubForId, sId);
											formatData(sbSubForTitle, sTitle);
											formatData(sbSubForQty, sQty);
											//Added by Subhajit for Req 46464 - Start
											util.formatData(sbRelRestriction, sRelRestriction);
											util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
											//Added by Subhajit for Req 46464 - End
											formatData(sbSubstituteSCN, sSubstituteSCN);											
											formatData(sbSubForSpecSubType, sSubForSpecSubType);
											//SPEC: <11.25.2020>:Guna Modified for 37570 defect  -- END
											//SPEC: <08.09.2021>: Guna Added for 42792 Defect  Dev 18x.6.0.2   -- START
											formatData(sbSubPartType,  util.mapType(sSubstituteType));	
											//SPEC: <08.09.2021>: Guna Added for 42792 Defect  Dev 18x.6.0.2   -- END
										continue;
										}
									}							
									else if (!isExternal) 
									{
										if (slHIRTypes.contains(sSubstituteType)) 
										{
											String sSubFormulalassif = sSubstituteIPClass;
											if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
												sSubFormulalassif =  util.getFormulaPropagateClassification(context, sSubstitutePartId);
											}
											bSubstuteHasAccess=util.checkInternalUserAcess(sUserlicense,sSubFormulalassif);
											/*if (null != sUserlicense && null != sSubFormulalassif
													&& !sUserlicense.contains(sSubFormulalassif))*/
											if(!bSubstuteHasAccess)
											{
												//SPEC: <11.25.2020>:Guna Modified for 37570 defect  -- START
												//SPEC: <06.18.2021>:Madhana Modified for 43685 defect  -- START
												sSubstitutePartId = ConstantsUtil.NO_ACCESS;
												sSubPartChg = ConstantsUtil.NO_ACCESS;
												formatData(sbSubPartId, sSubstitutePartId);
												formatData(sbSubPartChg, sSubPartChg);
												//SPEC: <06.18.2021>:Madhana Modified for 43685 defect  -- END
												formatData(sbSubPartTitle, sSubstituteTitle);
												//Added by Subhajit for Req 46464 - Start
												util.formatData(sbRelRestriction, sRelRestriction);
												util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
												//Added by Subhajit for Req 46464 - End
												formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
												formatData(sbSubPartRevRelDt, sRevRelease);
												formatData(sbSubPartValidStartDt, sSubstituteStartDate);
												formatData(sbSubPartValidUntiltDt, sSubstituteUntilDate);
												formatData(sbSubPartBUOM, sSubstituteBUOM);
												formatData(sbSubForComments, sComment);
												formatData(sbSubForCurrent, sCurrent);
												formatData(sbSubForRDOC, sRDOC);
												formatData(sbSubForId, sId);
												formatData(sbSubForTitle, sTitle);
												formatData(sbSubForQty, sQty);
												formatData(sbSubstituteSCN, sSubstituteSCN);
												
												formatData(sbSubForSpecSubType, sSubForSpecSubType);
												//SPEC: <11.25.2020>:Guna Modified for 37570 defect  -- END
												continue;
											}
											//SPEC: 11/04/2020: Modified for Non Employee Internal ## -- END
										}
										
									}
									formatData(sbSubPartType,  util.mapType(sSubstituteType));
									formatData(sbSubPartId, sSubstitutePartId);
									formatData(sbSubPartTitle, sSubstituteTitle);
									formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
									formatData(sbSubPartRevRelDt, sRevRelease);
									formatData(sbSubstituteSCN, sSubstituteSCN);
									formatData(sbSubPartValidStartDt, sSubstituteStartDate);
									formatData(sbSubPartValidUntiltDt, sSubstituteUntilDate);
									formatData(sbSubPartBUOM, sSubstituteBUOM);
									formatData(sbSubForComments, sComment);
									formatData(sbSubForCurrent, sCurrent);
									formatData(sbSubForRDOC, sRDOC);
									formatData(sbSubForId, sId);
									formatData(sbSubForTitle, sTitle);
									formatData(sbSubForQty, sQty);
									//Added by Subhajit for Req 46464 - Start
									util.formatData(sbRelRestriction, sRelRestriction);
									util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
									//Added by Subhajit for Req 46464 - End
									formatData(sbSubPartChg, sSubPartChg);
									formatData(sbSubForSpecSubType, sSubForSpecSubType);
									}
							}

					} //For

				}//while

			}//Main For
				
				mpEBOMResult.put(ConstantsUtil.SF_ID, sbSubForId.toString());
				mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbSubForType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_REVISION, sbSubForRev.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubForName.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbSubForTitle.toString());
				//Added by Subhajit for Req 46464 - Start
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
				//Added by Subhajit for Req 46464 - End
				mpEBOMResult.put(ConstantsUtil.SCN, sbSubstituteSCN.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbSubForQty.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbSubPartBUOM.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbSubForComments.toString());
				mpEBOMResult.put(ConstantsUtil.STATE, sbSubForCurrent.toString());
				mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbSubForRDOC.toString());
				mpEBOMResult.put(ConstantsUtil.SST, sbSubPartSpecSubType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbSubPartId.toString());
				mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbSubPartType.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
				mpEBOMResult.put(ConstantsUtil.SF_REVISION, sbSubPartRev.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTEPARTS, sbSubPartName.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbSubPartRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.VALIDSTARTDATE, sbSubPartValidStartDt.toString());
				mpEBOMResult.put(ConstantsUtil.VALIDTILLDATE, sbSubPartValidUntiltDt.toString());
				mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbSubPartTitle.toString());
				
				mpEBOMResult.put(ConstantsUtil.CHG, sbSubPartChg.toString());
				mpEBOMResult.put(ConstantsUtil.SF_SST, sbSubForSpecSubType.toString());

			
		}catch(Exception e)
		{
			LOGGER.error("Unable to parseMaplistForTupSubstitute : Program FinishedProductPartBO "+e);
			return new HashMap();
		}
			return util.filterMapList(mpEBOMResult);
		
		}
		/**
	 * Method Name 			: formatData
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}

	//SPEC: <24.02.2023>: Satyam Added for Defect 51895 -- START
	public StringBuilder getNumberPerCustomerUnit(Context context, String[] args) throws Exception {
		StringBuilder sbNumberOfCopPerUnit = new StringBuilder();
		StringList slReturnVal = new StringList();

		try {
			Map<?, ?> programMap = (HashMap) JPO.unpackArgs(args);
			MapList mlObjectList = (MapList) programMap.get(ConstantsUtilIRM.CONST_OBJECTLIST);
			Iterator<?> objListItr = mlObjectList.iterator();
			Map<?, ?> mPartInfo = null;
			String strQuantity = "";
			while (objListItr.hasNext()) {
				mPartInfo = (Map) objListItr.next();
				strQuantity = (String) mPartInfo.get(ConstantsUtilIRM.CONST_COP_QTY);
				if (validatorUtil.isNotNullOrEmpty(strQuantity)) {
					slReturnVal.addElement(strQuantity);
				} else {
					slReturnVal.addElement("");
				}
			}
			for (int i = 0; i < slReturnVal.size(); i++) {
				formatData(sbNumberOfCopPerUnit, slReturnVal.get(i));
			}
		} catch (Exception e) {
			LOGGER.error(" Exception in program FPPBO : getNumberPerCustomerUnit");
		}
		
		return sbNumberOfCopPerUnit;

	}
	//SPEC: <24.02.2023>: Satyam Added for Defect 51895 -- END
	
	/**
	 * Method Name 			: getPackagingDimensions
	 * Method Description 	: For getting the Packing characteristics of FPP
	 * @param context
	 * @param mlObjectList
	 * @param mpPackingUnit
	 * @param env 
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getPackagingDimensions(Context context, MapList mlObjectList, Map<String, String> mpPackingUnit, String sId, String sFPType, String sFPName, Map mpGTIN) throws Exception {
		StringList slReturnVal = new StringList();
		StringBuilder sbDepth = new StringBuilder();
		StringBuilder sbWidth = new StringBuilder();
		StringBuilder sbHeight = new StringBuilder();
		StringBuilder sbDimUom= new StringBuilder();
		StringList strPGDUoM = new StringList();
		StringBuilder sbGrossWtUom = new StringBuilder();
		StringBuilder sbNetWt = new StringBuilder();
		StringBuilder sbAuom = new StringBuilder();
		StringBuilder sbGrossWtReal = new StringBuilder();
		StringBuilder sbPackingType = new StringBuilder();
		StringBuilder sbNetWetOfProdInCU = new StringBuilder();
		StringBuilder sbGtin = new StringBuilder();
		StringBuilder sbId = new StringBuilder();

		try
		{

			String  sAttrName = "";
			String  strReportFormat = "";
			String sDepthVal = "";
			String sWidthVal = "";
			String sHeightVal = "";
			String sDimUoMVal = "";
			String sConnectionId="";
			String sConn="";
			String strResult="";

			BusExtractUtil utill = new BusExtractUtil();
			String sGtinValue = utill.getGTINValue(context,mpGTIN, true,mlObjectList);
			
			//SPEC: <24.02.2023>: Satyam Added for Defect 51895 -- START
			Map hmArgMapParams = new HashMap();		
			hmArgMapParams.put(ConstantsUtilIRM.CONST_OBJECTLIST, mlObjectList); 
			String[] strObjectArr= JPO.packArgs(hmArgMapParams);
			StringBuilder sbNPC =  getNumberPerCustomerUnit(context,strObjectArr);
			//SPEC: <24.02.2023>: Satyam Added for Defect 51895 -- END
			
			Iterator objListItr = mlObjectList.iterator();
			while (objListItr.hasNext()) {

				Map perMap = (Map) objListItr.next();
				String sObjectId = (String)perMap.get(DomainConstants.SELECT_ID);
				String sType = (String)perMap.get(DomainConstants.SELECT_TYPE);

				String strGrossWth = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
				String strNetWetUoM = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
				
				//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 25, 2021 for Defect #43822 -- START
				//String strGrossWtReal = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
				String strGrossWtReal = (String)perMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
				//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 25, 2021 for Defect #43822 -- END
				
				String strNetWetOfProdInCU = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
				String sAUOM =  (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
				String sGtin =  (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);

				formatData(sbGtin,sGtin);
				formatData(sbId,sObjectId);
				formatData(sbGrossWtUom,strGrossWth);
				formatData(sbNetWt,strNetWetUoM);
				formatData(sbAuom,sAUOM);
				formatData(sbGrossWtReal,strGrossWtReal);
				formatData(sbNetWetOfProdInCU,strNetWetOfProdInCU);

				sType = util.mapType(sType);
				String sName =(String)perMap.get(ConstantsUtil.SELECT_NAME);
				sName = sType+ConstantsUtil.SYMBL_OPNBRACE+ sName +ConstantsUtil.SYMBL_CLSBRACE;
				formatData(sbPackingType,sName);

				if(sType != null && !"".equals(sType)){
					if(sObjectId != null && !"".equals(sObjectId))
					{
						sConn="";
						sDepthVal = "";
						sWidthVal = "";
						sHeightVal = "";

						String sMQLStmt = "print connection $1 select $2 dump $3;";
						DomainObject bomObject = DomainObject.newInstance(context,sObjectId);
						StringList sConnList = bomObject.getInfoList(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM+"].id");
						for(int i=0;i<sConnList.size();i++)

						{
							sConnectionId=(String)sConnList.get(i);
							String querycommand="print connection"+" "+"\"$1\""+" "+ "select $2 dump  $3";
							strResult=MqlUtil.mqlCommand(context,querycommand,sConnectionId,"frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"]","|").trim();

							if(strResult.equalsIgnoreCase("True"))
							{
								sConn=sConnectionId;
								break;
							}
							else
							{
								continue;
							}
						}

						String sSelectable1 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_LENGTH+"].value";
						String sSelectable2 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_WIDTH+"].value";
						String sSelectable3 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_OUTERDIMENSIONHEIGHT+"].value";
						String sSelectable4 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_DIMENSTION_UOM+"].value";

						String sSelectable5 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT+"].value";

						String tempVal = new String();						
						if(sConn != null && !"".equals(sConn))
						{

							sDepthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable1, "|");
							sWidthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable2, "|");
							sHeightVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable3, "|");
							sDimUoMVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable4, "|");
							if (sDepthVal == null || "".equals(sDepthVal)){

								sDepthVal = "0.0";

							}
							if (sWidthVal == null || "".equals(sWidthVal)){

								sWidthVal = "0.0";

							}
							if (sHeightVal == null || "".equals(sHeightVal)){

								sHeightVal = "0.0";

							}
							formatData(sbDepth,sDepthVal);
							formatData(sbWidth,sWidthVal);
							formatData(sbHeight,sHeightVal);
							formatData(sbDimUom,sDimUoMVal);

						} else 
						{
							sDepthVal = "0.0";
							sWidthVal = "0.0";
							sHeightVal = "0.0";
							sDimUoMVal = "";

							formatData(sbDepth,sDepthVal);
							formatData(sbWidth,sWidthVal);
							formatData(sbHeight,sHeightVal);
							formatData(sbDimUom,sDimUoMVal);
						}
					}
				}

			}
			mpPackingUnit.put(ConstantsUtil.ID, sbId.toString());
			mpPackingUnit.put(ConstantsUtil.TYPE, sbPackingType.toString());
			mpPackingUnit.put(ConstantsUtil.DEPTH, sbDepth.toString());
			mpPackingUnit.put(ConstantsUtil.WIDTH, sbWidth.toString());
			mpPackingUnit.put(ConstantsUtil.HEIGHT, sbHeight.toString());
			mpPackingUnit.put(ConstantsUtil.DIMENSIONUNITOFMEASURE, sbDimUom.toString());
			mpPackingUnit.put(ConstantsUtil.NUMBEROFCONSUMERUNITSPERUNIT, sbNPC.toString());
			mpPackingUnit.put(ConstantsUtil.PACKINGUNITTYPE, sbPackingType.toString());
			mpPackingUnit.put(ConstantsUtil.GROSSWEIGHT, sbGrossWtReal.toString());
			mpPackingUnit.put(ConstantsUtil.AUOM, sbAuom.toString());
			mpPackingUnit.put(ConstantsUtil.GTIN, sGtinValue);
			mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE, sbGrossWtUom.toString());
			mpPackingUnit.put(ConstantsUtil.UNITOFMEASURE1, sbNetWt.toString());
			mpPackingUnit.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCONSUMERUNIT, sbNetWetOfProdInCU.toString());
			mpPackingUnit = util.verifyOwnership(context, mpPackingUnit);
			
		} catch(Exception e){
			LOGGER.error(" Exception in program FPPBO : getPackagingDimensions");
		}
		
		return util.filterMapList(mpPackingUnit);

	}
	
	//SPEC: <24.02.2023>: Satyam Added for Defect 51895 -- START
	/**
	 * Method to add COPs present under IP 
	 * @param context
	 * @param strIPId	- IP Id
	 * @param iSeq	- Sequence number
	 * @param mIPInfo	- IP Part Info Map
	 * @param mFinalMaps	- FPP EBOM part info
	 * @param relSelects	- Rel selects
	 * @param busSelects	- Bus selects
	 * @return	- Return the last sequence
	 * @throws Exception
	 */
	private int addCOPsUnderIP(Context context, String strIPId, int iSeq, Map mIPInfo, MapList mFinalMaps, StringList relSelects, StringList busSelects) throws Exception{
		try {
			if(UIUtil.isNotNullAndNotEmpty(strIPId)) {      
				
				Map mCOPInfo = null;
				
				DomainObject domIP = DomainObject.newInstance(context, strIPId);
				MapList copsMl = domIP.getRelatedObjects(context,
										DomainConstants.RELATIONSHIP_EBOM,	//	Rel Type		
										ConstantsUtil.TYPE_PGCONSUMERUNITPART,//Type				
										busSelects,//Object Select				
										relSelects,//rel Select				
										false,//get To				
										true,//get From				
										(short)1,//recurse level				
										null,//where Clause				
										null,				
										0);
				Iterator itrCOPInfo = copsMl.iterator();
				Double dbQty = 0.0;
				while(itrCOPInfo.hasNext()) {
					mCOPInfo = (Map)itrCOPInfo.next();
					dbQty += Double.parseDouble((String)mCOPInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
					mCOPInfo.put(ConstantsUtil.STR_SEQUENCE, Integer.toString(iSeq++));
					mCOPInfo.put(DomainConstants.SELECT_LEVEL, ConstantsUtilIRM.THIRD_LEVEL);
					mFinalMaps.add(mCOPInfo);
				}
				mIPInfo.put(ConstantsUtilIRM.CONST_COP_QTY, dbQty.toString());
				
			}
		}catch(Exception ex) {
			LOGGER.error(" Exception in program FPPBO : addCOPsUnderIP");
		}
		return iSeq;
	}
	
	/**
	 * Method to update the COP quantity on IP and CUP level.
	 * @param mFinalList	- Final maplist
	 * @throws Exception
	 */
	private void processForNumberOfCOPsUnderCUP(MapList mFinalList) throws Exception{
		try {
			StringList strTypesList = validatorUtil.toStringList(mFinalList, DomainConstants.SELECT_TYPE);
			if(strTypesList.contains(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) {
				String strType = null;
				String strQty = null;
				Map mBOMInfo = null;
				double dbQty = 0.0;
				mFinalList.sort(ConstantsUtil.STR_SEQUENCE, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.INTEGER);
				Map mCUPInfo = (Map)mFinalList.get(0);
				Iterator itrBOMInfo = mFinalList.iterator();				
				if(strTypesList.contains(ConstantsUtil.TYPE_PGINNERPACKUNITPART)) {
					while(itrBOMInfo.hasNext()) {
						mBOMInfo = (Map)itrBOMInfo.next();
						strType = (String)mBOMInfo.get(DomainConstants.SELECT_TYPE);
						if(ConstantsUtil.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(strType)) {
							strQty = (String)mBOMInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
							dbQty += Double.parseDouble(strQty) * Double.parseDouble((String)mBOMInfo.get(ConstantsUtilIRM.CONST_COP_QTY)); 
						}						
					}
				} else {										
					while(itrBOMInfo.hasNext()) {
						mBOMInfo = (Map)itrBOMInfo.next();
						strType = (String)mBOMInfo.get(DomainConstants.SELECT_TYPE);
						if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strType)) {
							dbQty += Double.parseDouble((String)mBOMInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY)); 
						}
					}					
				}
				if(dbQty != 0.0) {
					mCUPInfo.put(ConstantsUtilIRM.CONST_COP_QTY, Double.toString(dbQty));
				}
			}
		}catch(Exception ex) {
			LOGGER.error(" Exception in program FPPBO : processForNumberOfCOPsUnderCUP");
		}
	}
	
	/**
	 * Method to check if the FPP structure is complex or not.
	 * @param context
	 * @param strFPPId FPP Object Id
	 * @return String null if its simple structure - ComplexCUPStructure for complex CUP structure - ComplexIPStructure for complex IP structure
	 * @throws Exception
	 */
	public String checkForComplexUnit(Context context, String strFPPId)throws Exception{
		
		String strIsComplexStructure = null;
		try {
			if(validatorUtil.isNotNullOrEmpty(strFPPId)) {				
			
				StringList busSelects = new StringList(1);
				busSelects.add(DomainConstants.SELECT_TYPE);
				
				String typePattern =  ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART+","+ConstantsUtil.TYPE_PGCONSUMERUNITPART;
				DomainObject domObject = DomainObject.newInstance(context, strFPPId);
	
				MapList objList = domObject.getRelatedObjects(context, 
																DomainConstants.RELATIONSHIP_EBOM, //rel pattern
																typePattern, //type pattern
																busSelects, //bus selects
																null, //rel selects
																false, //get from
																true, //get to
																(short) Integer.parseInt(ConstantsUtilIRM.THIRD_LEVEL),//level
																null, //bus where
																null, //rel where
																0);				
				Map<String, MapList> mLevelBasedPartInfo = new HashMap<>();
				MapList mLevelBasedInfoList = null;
				Iterator<?> itr = objList.iterator();
				Map<?,?> mPartInfo = null;
				String strLevel = null;
				StringList slLevelTypes = null;
				while(itr.hasNext()) {
					mPartInfo = (Map)itr.next();
					strLevel = (String)mPartInfo.get(DomainConstants.SELECT_LEVEL);
					if(mLevelBasedPartInfo.containsKey(strLevel)) {
						mLevelBasedInfoList = mLevelBasedPartInfo.get(strLevel);					
					} else {
						mLevelBasedInfoList = new MapList();
					}
					mLevelBasedInfoList.add(mPartInfo);
					mLevelBasedPartInfo.put(strLevel, mLevelBasedInfoList);
				}

				if(mLevelBasedPartInfo.containsKey(ConstantsUtilIRM.SECOND_LEVEL)) {
					mLevelBasedInfoList = mLevelBasedPartInfo.get(ConstantsUtilIRM.SECOND_LEVEL);
					slLevelTypes = validatorUtil.toStringList(mLevelBasedInfoList, DomainConstants.SELECT_TYPE);

					if(slLevelTypes.size() == 1) {
						if(slLevelTypes.contains(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)) {
							strIsComplexStructure = ConstantsUtilIRM.CONST_COMPLEX_CUP_STRCTURE;
						} else if(slLevelTypes.contains(ConstantsUtil.TYPE_PGINNERPACKUNITPART)) {							
							if(mLevelBasedPartInfo.containsKey(ConstantsUtilIRM.THIRD_LEVEL)) {
								mLevelBasedInfoList = mLevelBasedPartInfo.get(ConstantsUtilIRM.THIRD_LEVEL);
								slLevelTypes = validatorUtil.toStringList(mLevelBasedInfoList, DomainConstants.SELECT_TYPE);
								
								if(slLevelTypes.contains(ConstantsUtil.TYPE_PGINNERPACKUNITPART) || slLevelTypes.size() > 1) {
									strIsComplexStructure = ConstantsUtilIRM.CONST_COMPLEX_IP_STRCTURE;
								}
							} else {
								strIsComplexStructure = ConstantsUtilIRM.CONST_COMPLEX_IP_STRCTURE;
							}
						}
					} else if(slLevelTypes.size() > 1) {
						strIsComplexStructure = ConstantsUtilIRM.CONST_COMPLEX_CUP_STRCTURE;
					}
				}
			}
		}catch(Exception ex) {
			LOGGER.error(" Exception in program FPPBO : checkForComplexUnit");
		}
		return strIsComplexStructure;
	}
	//SPEC: <24.02.2023>: Satyam Added for Defect 51895 -- END
	
	/**
	 * Method Name 			: getPackingUnitWeightsAndDiamensionsData
	 * Method Description 	:
	 * @param context
	 * @param objectId
	 * @return
	 * @throws Exception
	 */
	public MapList getPackingUnitWeightsAndDiamensionsData(Context context, String objectId) throws Exception 

	{

		MapList tempList = new MapList();

		MapList objList = null;
		MapList finalBomList = new MapList();
		String sLevelPrev = "0";

		String sLevelNext = "0";
		
		try{

			StringList busSelects = new StringList();
			busSelects.add(ConstantsUtil.SELECT_NAME);
			busSelects.add(ConstantsUtil.SELECT_TYPE);
			busSelects.add(ConstantsUtil.SELECT_ID);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
			busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT);
			busSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN);
			//SPEC: Release SR18x.6.0.1 - Added by Amman on June 25, 2021 for Defect #43822 -- START
			busSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			//SPEC: Release SR18x.6.0.1 - Added by Amman on June 25, 2021 for Defect #43822 -- END
			
			StringList relSelects = new StringList();
			relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);
			busSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN);
			String typePattern =  ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART+","+ConstantsUtil.TYPE_PGCONSUMERUNITPART;
			String relPattern = DomainConstants.RELATIONSHIP_EBOM;

			DomainObject domObject = DomainObject.newInstance(context, objectId);

			objList = domObject.getRelatedObjects(
					context, 
					relPattern,
					typePattern, 
					busSelects, 
					relSelects, 
					false, 
					true, 
					(short) 3, //SPEC: <24.02.2023>: Satyam Modified for Defect 51895
					null, 
					null, 
					0);		

			String	strObjectType = null;

			String strLevel = null;

			String strCOPId = null;

			StringList listCOPLevel=new StringList();

			StringList listCOPDetails=new StringList();

			//Commented by Satyam for Defect 51895 -- START
			//StringList COPIgnoreList=new StringList();
			//Commented by Satyam for Defect 51895 -- END

			MapList listFinalCharacteristics = new MapList();
			
			//SPEC: <24.02.2023>: Satyam Added for Defect 51895 -- START
			if(!objList.isEmpty())
			{
				objList.sort(DomainConstants.SELECT_LEVEL, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.INTEGER);
				Iterator listCharacteristicsIterator = objList.iterator();
				String strIsComplexStructure = checkForComplexUnit(context, objectId);
				boolean isComplexStructure = false;
				Map listCharacteristicsMap = null;
				int iSeq = 0;
				
				String strIPId = null;
				while (listCharacteristicsIterator.hasNext())

				{
					listCharacteristicsMap = (Map) listCharacteristicsIterator.next();

					strLevel=(String)listCharacteristicsMap.get(DomainConstants.SELECT_LEVEL);
					strObjectType=(String)listCharacteristicsMap.get(DomainConstants.SELECT_TYPE);
					if(validatorUtil.isNotNullOrEmpty(strLevel) && validatorUtil.isNotNullOrEmpty(strObjectType)) {
						isComplexStructure = false;
						if(strLevel.equalsIgnoreCase(ConstantsUtilIRM.SECOND_LEVEL) && strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) {
							if(validatorUtil.isNotNullOrEmpty(strIsComplexStructure) && strIsComplexStructure.equals(ConstantsUtilIRM.CONST_COMPLEX_IP_STRCTURE)) {
								listCharacteristicsMap.put(ConstantsUtilIRM.CONST_COP_QTY, "");
								isComplexStructure = true;
							} else {						
								strCOPId=(String)listCharacteristicsMap.get(DomainConstants.SELECT_ID);					
								listCOPLevel.add(strLevel);
								listCOPDetails.add(strLevel+"-"+strCOPId);	
								listFinalCharacteristics.add(listCharacteristicsMap);
								listCharacteristicsMap.put(ConstantsUtil.STR_SEQUENCE, Integer.toString(iSeq++));
							}
						}  else if(strLevel.equalsIgnoreCase(ConstantsUtilIRM.SECOND_LEVEL) && strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGINNERPACKUNITPART)){
							listCharacteristicsMap.put(ConstantsUtil.STR_SEQUENCE, Integer.toString(iSeq++));
							listFinalCharacteristics.add(listCharacteristicsMap);
							if(validatorUtil.isNotNullOrEmpty(strIsComplexStructure) && strIsComplexStructure.equals(ConstantsUtilIRM.CONST_COMPLEX_IP_STRCTURE)) {
								listCharacteristicsMap.put(ConstantsUtilIRM.CONST_COP_QTY, "");
								isComplexStructure = true;
							} else {						
								strIPId = (String)listCharacteristicsMap.get(DomainConstants.SELECT_ID);
								iSeq = addCOPsUnderIP(context, strIPId, iSeq, listCharacteristicsMap, listFinalCharacteristics, relSelects, busSelects);
							}
						} else if(strLevel.equalsIgnoreCase(ConstantsUtilIRM.FIRST_LEVEL) && strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)) {
							listCharacteristicsMap.put(ConstantsUtil.STR_SEQUENCE, Integer.toString(iSeq++));
							listFinalCharacteristics.add(listCharacteristicsMap);
							if(validatorUtil.isNotNullOrEmpty(strIsComplexStructure) && strIsComplexStructure.equals(ConstantsUtilIRM.CONST_COMPLEX_CUP_STRCTURE)) {
								listCharacteristicsMap.put(ConstantsUtilIRM.CONST_COP_QTY, "");
								isComplexStructure = true;
							}
						}
						if(isComplexStructure) {
							break;
						}
					}
				}
			//SPEC: <24.02.2023>: Satyam Added for Defect 51895 -- END
				
			if(listFinalCharacteristics.size()>0)
			{
				processForNumberOfCOPsUnderCUP(listFinalCharacteristics); //SPEC: <24.02.2023>: Satyam Added for Defect 51895
				Iterator objItr=listFinalCharacteristics.iterator();

				while(objItr.hasNext())

				{

					Map objMap = (Map) objItr.next();

					Map objects = new HashMap();

					objects.put(DomainConstants.SELECT_NAME, (String)objMap.get(DomainConstants.SELECT_NAME));
					objects.put("relationship", (String)objMap.get("relationship"));
					objects.put("level", (String)objMap.get("level"));
					objects.put(DomainConstants.SELECT_ID, (String)objMap.get(DomainConstants.SELECT_ID));
					objects.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)objMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
					objects.put(DomainConstants.SELECT_TYPE, (String)objMap.get(DomainConstants.SELECT_TYPE));
					objects.put(ConstantsUtilIRM.CONST_COP_QTY, (String)objMap.get(ConstantsUtilIRM.CONST_COP_QTY)); //SPEC: <24.02.2023>: Satyam Added for Defect 51895
					
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM));
					
					//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 25, 2021 for Defect #43822 -- START
					//objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
					objects.put(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL, (String)objMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
					//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 25, 2021 for Defect #43822 -- END
					
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL));
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE));
					objects.put(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN, (String)objMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN));

					finalBomList.add(objects);

				}

			}
		
			}
		} catch (Exception e) {
			LOGGER.error(" Exception in program FPPBO : getPackingUnitWeightsAndDiamensionsData");
		}


		return finalBomList;


	}

	
	/**
	 * Method Name 			: getNumberPerCustomerUnit
	 * Method Description 	:
	 * @param context
	 * @param mlObjectList
	 * @return
	 * @throws Exception
	 */
	public StringBuilder getNumberPerCustomerUnit(Context context, MapList mlObjectList) throws Exception

	{

		String sReturn = "";
		StringBuilder sbNumberOfCopPerUnit = new StringBuilder();
		StringList slReturnVal = new StringList();
		String sObjectId = "";
		String strLevel ="";
		String strQuantity="";
		String strType="";
		String iPrevious="";
		Double dQuantity=0.0;

		boolean ipLevel2= false;

		boolean cupLevel1=false;

		try

		{

			mlObjectList.sort("level", "ascending", "integer");

			Iterator objListItr = mlObjectList.iterator();

			while (objListItr.hasNext())

			{

				Map perMap = (Map) objListItr.next();

				strType=(String)perMap.get(DomainConstants.SELECT_TYPE);

				sObjectId = (String)perMap.get(DomainConstants.SELECT_ID);

				strLevel=(String)perMap.get(ConstantsUtil.SELECT_LEVEL);

				strQuantity=(String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);

				DomainObject bomObject = DomainObject.newInstance(context,sObjectId);

				if(UIUtil.isNullOrEmpty(strType) || UIUtil.isNullOrEmpty(strLevel) || UIUtil.isNullOrEmpty(strQuantity) ||  mlObjectList.size()==1)

				{
					slReturnVal.addElement("");
				}

				else

				{

					if(strType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART) && "1".equals(strLevel))

					{
						cupLevel1=true;
					}

					else if(strType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) && "2".equals(strLevel) && cupLevel1)

					{
						slReturnVal.addElement(strQuantity);
						slReturnVal.addElement("");
						cupLevel1=false;

					}

					else if(strType.equals(ConstantsUtil.TYPE_PGINNERPACKUNITPART) && "2".equals(strLevel) && cupLevel1)

					{
						iPrevious=strQuantity;
						ipLevel2=true;
						slReturnVal.addElement("");
						slReturnVal.addElement("");

					}

					else if(strType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) && "3".equals(strLevel) && ipLevel2)

					{
						dQuantity=Double.parseDouble(iPrevious) * Double.parseDouble(strQuantity);
						slReturnVal.removeAllElements();
						slReturnVal.addElement(Double.toString(dQuantity));
						slReturnVal.addElement(strQuantity);
						slReturnVal.addElement("");

						ipLevel2=false;

					}

					else

					{
						slReturnVal.addElement("");
					}

				}

			}

			for (int i = 0; i < slReturnVal.size(); i++) {
				formatData(sbNumberOfCopPerUnit,slReturnVal.get(i));
			}



		} catch(Exception e){

			LOGGER.error(" Exception in program FPPBO : getNumberPerCustomerUnit");

		}

		return sbNumberOfCopPerUnit;

	}

	
	/**
	 * Method Name 			: getPhaseBOM
	 * Method Description 	:
	 * @param context
	 * @param mlEBOMList
	 * @return
	 */
	public Map getPhaseBOM(Context context, MapList mlEBOMList, Map mpSubstitute)
	{
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		Iterator objectListItr = mlEBOMList.iterator();	
		Map mapBomResult = new HashMap();
		Map mapFinalBomResult = new HashMap();
		CommonBusUtilBO commonBO = new CommonBusUtilBO();

		
		try {
		while (objectListItr.hasNext()) 
		{
			Map objectMap = (Map) objectListItr.next();
			String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
			String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
			
			if(!sType.equals("pgPhase")) {
				
				continue;
			}
			
			if(UIUtil.isNotNullAndNotEmpty(sId)) {
				
				DomainObject doFPP = new DomainObject(sId);
			MapList	mlPhaseEBOMList = doFPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
						ConstantsUtil.QUERY_WILDCARD, getBomBusSelect(context), getBomRelSelect(context), false, true, (short) 1,
						"type!=pgPhase", ConstantsUtil.EMPTY_STRING, 0);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doFPP.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				 mapBomResult =parsePGPhaseBOMMaplist(context,mlPhaseEBOMList,objectMap);
				//SPEC: <11.24.2020>: Modified for Defect :37556 by Madhana ## --START		
				 mpSubstitute =  commonBO.parseSubstitute(context,mlPhaseEBOMList);
				 mapFinalBomResult.put(ConstantsUtil.BILLOFMATERIALS,mapBomResult); 
				 mapFinalBomResult.put(ConstantsUtil.SUBSTITUTEPARTS,mpSubstitute);
			}
			
		}
		}catch(Exception e) {
			LOGGER.error("Exception in FinishedProductPartBO:  getPhaseBOM: "+e);
		}
		return mapFinalBomResult;
		//return util.filterMapList(mapFinalBomResult);
		//SPEC: <11.24.2020>: Modified for Defect :37556 by Madhana ## --END
	}
	
	
	/**
	 * Method Name 			: parsePGPhaseBOMMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @param mpPhase
	 * @return
	 */
	public Map<String, String> parsePGPhaseBOMMaplist(Context context,MapList mapList, Map mpPhase) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
		//Iterator objectListItr = mapList.iterator();
		CommonBusUtilBO commonBO = new CommonBusUtilBO();
		Map MPFinalEBOMSubStitute = new TreeMap();
		Map mpFinalEBOM = new TreeMap();
		Map mpFinalSubstitute = new TreeMap();
		//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
		int index=1;
		StringBuilder sbFEBOMParentName = new StringBuilder();
		StringBuilder sbFEBOMParentREV = new StringBuilder();
		StringBuilder sbFEBOMParentId = new StringBuilder();
		StringBuilder sbFEBOMParentType = new StringBuilder();
		//Added by Subhajit for Req 46464 - Start
		StringBuilder sbFRelRestriction = new StringBuilder();
		StringBuilder sbFRelRestrictionComment = new StringBuilder();
		//Added by Subhajit for Req 46464 - End
		StringBuilder sbFEBOMName = new StringBuilder();
		StringBuilder sbFEBOMREV = new StringBuilder();
		StringBuilder sbFEBOMId = new StringBuilder();
		StringBuilder sbFEBOMChg = new StringBuilder();
		StringBuilder sbFEBOMFN = new StringBuilder();
		StringBuilder sbFEBOMTitle = new StringBuilder();
		StringBuilder sbFEBOMType = new StringBuilder();
		StringBuilder sbFEBOMQTY = new StringBuilder();
		StringBuilder sbFEBOMBuom = new StringBuilder();
		StringBuilder sbFEBOMCommnts = new StringBuilder();
		StringBuilder sbFEBOMComment = new StringBuilder();
		StringBuilder sbFEBOMState = new StringBuilder();
		StringBuilder sbFEBOMStage = new StringBuilder();
		StringBuilder sbFEBOMRDOC = new StringBuilder();
		StringBuilder sbFEBOMSubstute = new StringBuilder();
		StringBuilder sbFEBOMRevRelDt = new StringBuilder();
		StringBuilder sbFOSPD= new StringBuilder();
		StringBuilder sbFDen= new StringBuilder();
		StringBuilder sbFAltName = new StringBuilder();
		StringBuilder sbFAltID = new StringBuilder();
		StringBuilder sbFAltType = new StringBuilder();
		StringBuilder sbFEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbFEBOMSubPartID = new StringBuilder();
		StringBuilder sbFEBOMSubPartType = new StringBuilder();
		
		StringBuilder sbGrossWeight = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder();
		StringBuilder sbNSPCG = new StringBuilder();
		MapList mlEBOMSubList = new MapList();
		//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
		try 
		{
			Map objectMap = null;
			Map<String, String> mpSubstituteResult = null;
			MapList mlPhaseEBOMList = null;
			int iParentLevel = 0;
			StringList slParentId = new StringList();
			String sParentId = ConstantsUtil.EMPTY_STRING;
			
			String sPParentName = (String)mpPhase.get(ConstantsUtil.SELECT_NAME);
			String sPParentId = (String)mpPhase.get(ConstantsUtil.SELECT_ID);
			String sPParentRev = (String)mpPhase.get(ConstantsUtil.SELECT_REVISION);
			String sPParentType = (String)mpPhase.get(ConstantsUtil.SELECT_TYPE);
			
			for(int i =0; i<mapList.size(); i++)
			{
				objectMap = (Map) mapList.get(i);
				iParentLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));
				
				mpSubstituteResult = new HashMap<String, String>();
				mpEBOMResult = new HashMap<String, String>();
				mlPhaseEBOMList = new MapList();
				sParentId = ConstantsUtil.EMPTY_STRING;
				//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS	
				
				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMREV = new StringBuilder();
				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMFN = new StringBuilder();
				StringBuilder sbEBOMTitle = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMQTY = new StringBuilder();
				StringBuilder sbEBOMBuom = new StringBuilder();
				StringBuilder sbEBOMCommnts = new StringBuilder();
				StringBuilder sbEBOMComment = new StringBuilder();
				StringBuilder sbEBOMState = new StringBuilder();
				StringBuilder sbEBOMStage = new StringBuilder();
				StringBuilder sbEBOMRDOC = new StringBuilder();
				StringBuilder sbEBOMSubstute = new StringBuilder();
				StringBuilder sbEBOMRevRelDt = new StringBuilder();
				StringBuilder sbOSPD= new StringBuilder();
				StringBuilder sbDen= new StringBuilder();
				StringBuilder sbAltName = new StringBuilder();
				StringBuilder sbAltID = new StringBuilder();
				StringBuilder sbAltType = new StringBuilder();
				StringBuilder sbEBOMSubstitutePart = new StringBuilder();
				StringBuilder sbEBOMSubPartID = new StringBuilder();
				StringBuilder sbEBOMSubPartType = new StringBuilder();
				
				StringBuilder sbEBOMGrossWeight = new StringBuilder();
				StringBuilder sbEBOMGrossWeightUOM = new StringBuilder();
				StringBuilder sbEBOMNSPCG = new StringBuilder();
				
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --START
				String sPId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sPName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sPRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sPReleaseDate = validator.DateFormatter(validator.getStringEquivalentForStringListWithComma((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
				String sPRevRelease = sPRevision + ConstantsUtil.SYMBL_COLON+ sPReleaseDate;
				String sPpgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sPFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				String sPTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43805 on Date 06/07/2021 --START
				//String sPType = util.mapType((String) objectMap.get(ConstantsUtil.SELECT_TYPE));
				String sPType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43805 on Date 06/07/2021 --END
				String sPSubstitute = (String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
				sPSubstitute =util.replaceSpecialSymbols(sPSubstitute);
				
				
				//SPEC: <11.20.2020>: Chandra Added for Defect :37530 ## --START
				//SPEC: <06.02.2021>: Govind Added for Defect :39082 ## --START
				
				String sPQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
				String sPQty1 = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				 if (UIUtil.isNullOrEmpty(sPQty))
		          {
				 	sPQty =sPQty1;
		          }
	             if (sPQty == null)
	             {
	            	 sPQty = "";
	             }
				//SPEC: <06.02.2021>: Govind Added for Defect :39082 ## --END
				//SPEC: <11.20.2020>: Chandra Added for Defect :37530 ## --START
	           //SPEC: <02.11.2021>: Added for Defect #39446 by Sumit  --START
		           //SPEC: <06.24.2021>: Madhana Added for Defect :43823 ## --START
	             if((sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE)) && ((iParentLevel == 1) || (iParentLevel == 2))){
	            	 sPQty = "";
	             }            	             
	             //SPEC: <06.24.2021>: Madhana Added for Defect :43823 ## --END
	           //SPEC: <02.11.2021>: Added for Defect #39446 by Sumit  --ENDS
				String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
				strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strAltID = util.checkAlternateHasAccess(context,objectMap);	
				String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
				strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strOSPD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
				String strDenUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);				
				String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
				// SPEC: Guna Modified for Defect 38083  -- START
				// SPEC Release SR18x.5.2: Amman Modified for Defect 38640  -- START
				//SPEC: <02.10.2021>: Modified for Defect #39277 by Sumit  --START
				String sPBuom = ConstantsUtil.EMPTY_STRING;
				if(validator.isNotNullOrEmpty((String)(mpPhase.get(ConstantsUtil.SELECT_TYPE))) && ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase((String)(mpPhase.get(ConstantsUtil.SELECT_TYPE))))
					sPBuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				else
					sPBuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				//SPEC: <02.10.2021>: Modified for Defect #39277 by Sumit  --ENDS
				// SPEC Release SR18x.5.2: Amman Modified for Defect 38640  -- END
				//String sPComments = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT))?(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT):ConstantsUtil.EMPTY_STRING;
				String sPComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				// SPEC: Guna Modified for Defect 38083  -- END
				String sPComment = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
				String sPCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				sPCurrent=util.mapType(sPCurrent);
				String sPStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				String sPRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				sPRD =util.replaceSpecialSymbols(sPRD);
				String sPOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sPOC = util.replaceSpecialSymbols(sPOC);
				String sPRDOC = sPRD + ConstantsUtil.SYMBL_COLON + sPOC;
				String strClassFiedParent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
				String sGrossWeight= (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
				String sGrossWeightUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
				String sNSPCG = (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
				//Added by Subhajit for Req 46464 - Start
				String sPRelRestriction = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
				String sPRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
				//Added by Subhajit for Req 46464 - End
				
				boolean bHasOwnership = false;
				
				String sFormulaPropagate = sPId;
				if(util.isModificatinRequired())
				{
		          
					//modified by Ganesh for security impl ---->start
					bHasOwnership = util.checkHasAccess(context, null, sPId);
					//modified by Ganesh for security impl ---->end
					if(!bHasOwnership)
					{
						
						sPpgChg = ConstantsUtil.NO_ACCESS;
						sPId = ConstantsUtil.NO_ACCESS;
						sPRevRelease = sPRevision+ConstantsUtil.SYMBL_COLON+sPReleaseDate;
		
					}
					boolean bHasOwnershipParent = false;
					bHasOwnershipParent = util.checkHasAccess(context, null, sPParentId);
					if(!bHasOwnershipParent)
					{
						sPParentId = ConstantsUtil.NO_ACCESS;
					}
					
					//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
				}else if(sec.isStaffAUGUser())
				{
					boolean showData = true;
					
					//modified by Ganesh for security impl---->start
					showData = util.checkHasAccess(context, null, sPId);
					//modified by Ganesh for security impl---->end
					if(!showData){
						//SPEC: <11.26.2020>: Guna Modified for Defect :37576 ## --START
						if(validator.isNotNullOrEmpty(sPpgChg) || !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE))
						sPpgChg = ConstantsUtil.NO_ACCESS;
						sPId = ConstantsUtil.NO_ACCESS;
						sPRevRelease = sPRevision+ConstantsUtil.SYMBL_COLON+sPReleaseDate;
						//SPEC: <11.26.2020>: Guna Modified for Defect :37576 ## --END
						
					}
					boolean showDataParent = true;
					showDataParent = util.checkHasAccess(context, null, sPParentId);
					if(!showDataParent){
						sPParentId = ConstantsUtil.NO_ACCESS;
					}
					//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
				}else{
					
					//Modified by Ganesh for security impl----start
					boolean showData = util.checkHasAccess(context, null, sPId);
					if(!showData){
						//SPEC: <11.26.2020>: Guna Modified for Defect :37576 ## --START
						if(validator.isNotNullOrEmpty(sPpgChg) || !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE))
						sPpgChg = ConstantsUtil.NO_ACCESS;
						
						sPId = ConstantsUtil.NO_ACCESS;
						sPRevRelease = sPRevision+ConstantsUtil.SYMBL_COLON+sPReleaseDate;
						//SPEC: <11.26.2020>: Guna Modified for Defect :37576 ## --END
					}
					boolean showDataParent = util.checkHasAccess(context, null, sPParentId);
					if(!showDataParent){
						sPParentId = ConstantsUtil.NO_ACCESS;
					}
					//Modified by Ganesh for security impl----end
				}//else 
				
				//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
				//SPEC: Release SR18x.5.2 - Added for Defect# 38083  by Guna on Date 11/02/2021 -- START
				objectMap.put(ConstantsUtil.CONTEXT_TYPE, (String)(mpPhase.get(ConstantsUtil.SELECT_TYPE)));
				//SPEC: Release SR18x.5.2 - Added for Defect# 38083  by Guna on Date 11/02/2021 -- END
				 mlPhaseEBOMList.add(objectMap);
				if(!sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1) {
					
					formatData(sbFEBOMParentName, sPParentName);
					formatData(sbFEBOMParentREV, sPParentRev);
					formatData(sbFEBOMParentId, sPParentId);
					formatData(sbFEBOMParentType, util.mapType(sPParentType));
					//Added by Subhajit for Req 46464 - Start
					formatData(sbFRelRestriction, sPRelRestriction);
					formatData(sbFRelRestrictionComment, sPRelRestrictionComment);
					//Added by Subhajit for Req 46464 - End
					//SPEC: Release SR18x.5.2: Added for Defect 38640 by Amman --START
					formatData(sbFEBOMType, util.mapType(sPType));
					//SPEC: Release SR18x.5.2: Added for Defect 38640 by Amman --END
					formatData(sbFEBOMName, sPName);
					formatData(sbFEBOMREV, sPRevision);
					formatData(sbFEBOMQTY, sPQty);
					formatData(sbFEBOMBuom, sPBuom);
					formatData(sbFEBOMState, sPCurrent);
			
					formatData(sbFEBOMId, sPId);
					formatData(sbFEBOMChg, sPpgChg);
					formatData(sbFEBOMFN, sPFN);
					formatData(sbFEBOMTitle, sPTitle);
					formatData(sbFEBOMSubstute, sPSubstitute);
					formatData(sbFEBOMCommnts, sPComments);
					formatData(sbFEBOMComment, sPComment);
					formatData(sbFEBOMStage, sPStage);
					formatData(sbFEBOMRDOC, sPRDOC);
					formatData(sbFEBOMRevRelDt, sPRevRelease);
					formatData(sbFOSPD,strOSPD);
					formatData(sbFDen,strDenUOM);
					formatData(sbFAltName,strAltName);
					formatData(sbFAltID,strAltID);
					formatData(sbFAltType,strAltType);
					formatData(sbFEBOMSubstitutePart, strSubPart);
					formatData(sbFEBOMSubPartID, strSubPartId);
					formatData(sbFEBOMSubPartType, strSubPartType);
					
					formatData(sbGrossWeight, sGrossWeight);
					formatData(sbGrossWeightUOM, sGrossWeightUOM);
					formatData(sbNSPCG, sNSPCG);
					if(!mlPhaseEBOMList.isEmpty()) {
						mlEBOMSubList.addAll(mlPhaseEBOMList);
					}
					
				} else {
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
				
					//SPEC: Release SR18x.5.2: Added for Defect 38640 by Amman --START
					formatData(sbEBOMType, util.mapType(sPType));
					//SPEC: Release SR18x.5.2: Added for Defect 38640 by Amman --START
					formatData(sbEBOMName, sPName);
					formatData(sbEBOMREV, sPRevision);
					formatData(sbEBOMQTY, sPQty);
					formatData(sbEBOMBuom, sPBuom);
					formatData(sbEBOMState, sPCurrent);
			
					formatData(sbEBOMId, sPId);
					formatData(sbEBOMChg, sPpgChg);
					formatData(sbEBOMFN, sPFN);
					formatData(sbEBOMTitle, sPTitle);
					formatData(sbEBOMSubstute, sPSubstitute);
					formatData(sbEBOMCommnts, sPComments);
					formatData(sbEBOMComment, sPComment);
					formatData(sbEBOMStage, sPStage);
					formatData(sbEBOMRDOC, sPRDOC);
					formatData(sbEBOMRevRelDt, sPRevRelease);
					formatData(sbOSPD,strOSPD);
					formatData(sbDen,strDenUOM);
					formatData(sbAltName,strAltName);
					formatData(sbAltID,strAltID);
					formatData(sbAltType,strAltType);
					formatData(sbEBOMSubstitutePart, strSubPart);
					formatData(sbEBOMSubPartID, strSubPartId);
					formatData(sbEBOMSubPartType, strSubPartType);
					
					formatData(sbEBOMGrossWeight, sGrossWeight);
					formatData(sbEBOMGrossWeightUOM, sGrossWeightUOM);
					formatData(sbEBOMNSPCG, sNSPCG);
				//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
				}
				//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
				
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --START
				//while (objectListItr.hasNext()) {
					//Map objectMap = (Map) objectListItr.next();
					//int iLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));
				int j = 0;
				int iNextLevel = 0;
				Map objectMaps =null;
				//SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --START
				//if(sPType.equals(ConstantsUtil.TYPE_PGPHASE) || iParentLevel == 1){
				 if(sPType.equals(ConstantsUtil.TYPE_PGPHASE)){
					 sParentId=sFormulaPropagate;
					 //SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --ENDS
					 
					 for(j =i+1; j<mapList.size(); j++)
					 {
						iNextLevel = 0;
						objectMaps = (Map) mapList.get(j);
						int iCurrLevel = Integer.parseInt((String) objectMaps.get(ConstantsUtil.SELECT_LEVEL));
						if(j < mapList.size()-1) {
							Map objectNxtMaps = (Map) mapList.get(j+1);
							iNextLevel = Integer.parseInt((String) objectNxtMaps.get(ConstantsUtil.SELECT_LEVEL));
						}
						
						if((iParentLevel+1 == iCurrLevel) && sPType.equals(ConstantsUtil.TYPE_PGPHASE)) {
							
							//SPEC: Release SR18x.5.2 - Added for Defect# 38083  by Guna on Date 11/02/2021 -- START
							objectMaps.put(ConstantsUtil.CONTEXT_TYPE, (String)(mpPhase.get(ConstantsUtil.SELECT_TYPE)));
							//SPEC: Release SR18x.5.2 - Added for Defect# 38083  by Guna on Date 11/02/2021 -- END
							mlPhaseEBOMList.add(objectMaps);
							//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
							String strClassFied = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.STR_IPCLASS));
							String sId = (String) objectMaps.get(ConstantsUtil.SELECT_ID);
							String sName = (String) objectMaps.get(ConstantsUtil.SELECT_NAME);
							String sRevision = (String) objectMaps.get(ConstantsUtil.SELECT_REVISION);
							String sReleaseDate = validator.DateFormatter(validator.getStringEquivalentForStringListWithComma((String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
							String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON+ sReleaseDate;
							String spgChg = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
							String sFN = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
							String sTitle = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							String sType = (String) objectMaps.get(ConstantsUtil.SELECT_TYPE);
							String sSubstitute = (String) objectMaps.get(ConstantsUtil.SELECT_SUBSTITUTE);
							sSubstitute =util.replaceSpecialSymbols(sSubstitute);
							//SPEC: <11.20.2020>: Chandra Added for Defect :37530 ## --START
							//String sQty = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
							String sQty = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
							//SPEC: <11.20.2020>: Chandra Added for Defect :37530 ## --START
							
							strAltName =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
							strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strAltID = util.checkAlternateHasAccess(context,objectMaps);	
							strAltType =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
							strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strOSPD =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
							strDenUOM =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);				
							strSubPart = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strSubPartId = util.checkSubstituteHasAccess(context,objectMaps);
							// SPEC: Guna Modified for Defect 38083  -- START
							// SPEC Release SR18x.5.2: Amman Modified for Defect 38640  -- START
							//SPEC: <02.10.2021>: Modified for Defect #39277 by Sumit  --START
							String sBuom = ConstantsUtil.EMPTY_STRING;
							if(validator.isNotNullOrEmpty((String)(mpPhase.get(ConstantsUtil.SELECT_TYPE))) && ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase((String)(mpPhase.get(ConstantsUtil.SELECT_TYPE))))
								sBuom = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
							else
								sBuom = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
							//SPEC: <02.10.2021>: Modified for Defect #39277 by Sumit  --ENDS
							// SPEC Release SR18x.5.2: Amman Modified for Defect 38640  -- START
							//String sComments = validator.isNotNullOrEmpty((String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT))?(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT):ConstantsUtil.EMPTY_STRING;
							String sComments = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
							// SPEC: Guna Modified for Defect 38083  -- END
							String sComment = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
							String sCurrent = (String) objectMaps.get(ConstantsUtil.SELECT_CURRENT);
							sCurrent=util.mapType(sCurrent);
							String sStage = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
							String sRD = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
							sRD =util.replaceSpecialSymbols(sRD);
							String sOC = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
							String sEBOMGrossWeight= (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
							String sEBOMGrossWeightUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
							String sEBOMNSPCG = (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
							
							if(util.isModificatinRequired())
							{
								
								//modified by Ganesh for security impl----start
								bHasOwnership = util.checkHasAccess(context, null, sId);
								//modified by Ganesh for security impl----end
								if(!bHasOwnership)
								{
									spgChg = ConstantsUtil.NO_ACCESS;
									sId = ConstantsUtil.NO_ACCESS;
									sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
									
								}
							}else{
			                     	//modified by Ganesh for security impl----->start
								boolean showData = util.checkHasAccess(context, null, sId);
								if(!showData)
								{
									spgChg = ConstantsUtil.NO_ACCESS;
									sId = ConstantsUtil.NO_ACCESS;
									sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
								}
								 //modified by Ganesh for security impl----->end
							}
							
							sType = util.mapType(sType);
			
							//Security req -33193 HIR Components Attributes to Show
							formatData(sbEBOMType, sType);
							formatData(sbEBOMName, sName);
							formatData(sbEBOMREV, sRevision);
							formatData(sbEBOMQTY, sQty);
							formatData(sbEBOMBuom, sBuom);
							formatData(sbEBOMState, sCurrent);
			
							formatData(sbEBOMId, sId);
							formatData(sbEBOMChg, spgChg);
							formatData(sbEBOMFN, sFN);
							formatData(sbEBOMTitle, sTitle);
							formatData(sbEBOMSubstute, sSubstitute);
							formatData(sbEBOMCommnts, sComments);
							formatData(sbEBOMComment, sComment);
							formatData(sbEBOMStage, sStage);
							formatData(sbEBOMRDOC, sRDOC);
							formatData(sbEBOMRevRelDt, sRevRelease);
							formatData(sbOSPD,strOSPD);
							formatData(sbDen,strDenUOM);
							formatData(sbAltName,strAltName);
							formatData(sbAltID,strAltID);
							formatData(sbAltType,strAltType);
							formatData(sbEBOMSubstitutePart, strSubPart);
							formatData(sbEBOMSubPartID, strSubPartId);
							formatData(sbEBOMSubPartType, strSubPartType);
							
							formatData(sbEBOMGrossWeight, sEBOMGrossWeight);
							formatData(sbEBOMGrossWeightUOM, sEBOMGrossWeightUOM);
							formatData(sbEBOMNSPCG, sEBOMNSPCG);
						}
						//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
						//SPEC: <01.21.2021>: Modified for Defect : 38181 by Sumit --START
						if(iParentLevel+1 > iNextLevel || iParentLevel == iCurrLevel) {
						//SPEC: <01.21.2021>: Added for Defect : 38181 by Sumit --ENDS	
							break;
						} 		
					}	
					
					mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
					mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
					mpEBOMResult.put(ConstantsUtil.REVISION, sbEBOMREV.toString());
					mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
					mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
					mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
					mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
					mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
					mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
					mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
					mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
					mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
					mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
					mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
					mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
					mpEBOMResult.put(ConstantsUtil.OSPD, sbOSPD.toString());
					mpEBOMResult.put(ConstantsUtil.DUOM, sbDen.toString());
					mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
					mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
					mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
					mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
					mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
					mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
					
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbEBOMGrossWeight.toString());
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbEBOMGrossWeightUOM.toString());
					mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbEBOMNSPCG.toString());
					//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
				 }
				//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --START
				 if(!mpEBOMResult.isEmpty() && validator.isNotNullOrEmpty(sParentId) && (!slParentId.contains(sParentId) || (slParentId.contains(sParentId) && !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1))) {
				//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --ENDS
					 slParentId.add(sParentId);
					mpFinalEBOM.put(String.valueOf(index), mpEBOMResult);
					//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --START
					if(!mlPhaseEBOMList.isEmpty()) {
						//mpFinalSubstitute.put(String.valueOf(index), mpSubstituteResult);
						mlEBOMSubList.addAll(mlPhaseEBOMList);
					}
					//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --ENDS
					index++;
				 }
			}
			
			//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
			mpEBOMResult = new HashMap();
			if(null != sbFEBOMId && sbFEBOMId.length()>0) {
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbFEBOMParentId.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbFEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbFEBOMParentREV.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbFEBOMParentType.toString());
				//Added by Subhajit for Req 46464 - Start
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbFRelRestriction.toString());
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbFRelRestrictionComment.toString());
				//Added by Subhajit for Req 46464 - End
				mpEBOMResult.put(ConstantsUtil.ID, sbFEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbFEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.REVISION, sbFEBOMREV.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbFEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.FN, sbFEBOMFN.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbFEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbFEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbFEBOMSubstute.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbFEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbFEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbFEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.STATE, sbFEBOMState.toString());
				mpEBOMResult.put(ConstantsUtil.PHASE, sbFEBOMStage.toString());
				mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbFEBOMRDOC.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbFEBOMRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.OSPD, sbFOSPD.toString());
				mpEBOMResult.put(ConstantsUtil.DUOM, sbFDen.toString());
				mpEBOMResult.put(ConstantsUtil.ALTNAME, sbFAltName.toString());
				mpEBOMResult.put(ConstantsUtil.ALTID, sbFAltID.toString());
				mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbFAltType.toString());
				mpEBOMResult.put(ConstantsUtil.SP, sbFEBOMSubstitutePart.toString());
				mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbFEBOMSubPartType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbFEBOMSubPartID.toString());
				
				mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeight.toString());
				mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
				mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbNSPCG.toString());
				if(!mpEBOMResult.isEmpty()) {
					mpFinalEBOM.put(String.valueOf(0), mpEBOMResult);
				}
			}
			
			mpSubstituteResult = commonBO.parseSubstitute(context,mlEBOMSubList);
			if(!mpSubstituteResult.isEmpty()) {
				HashMap mpSubstitute = new HashMap();
				mpSubstitute.put(String.valueOf(0), mpSubstituteResult);
				mpFinalSubstitute.put(String.valueOf(0), mpSubstitute);
			}
			
			//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
			
			MPFinalEBOMSubStitute.put(ConstantsUtil.BILLOFMATERIALS, mpFinalEBOM);
			MPFinalEBOMSubStitute.put(ConstantsUtil.SUBSTITUTEPARTS, mpFinalSubstitute);
			//MPFinalEBOMSubStitute.put(ConstantsUtil.HEADER, mpHeaderEBOMResult);

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in FPPBO:  parseMaplist: " + e);
		}
		return MPFinalEBOMSubStitute;
		
		//return  util.filterMapList(mpEBOMResult);
		//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS
	}
	
	
	//SPEC: <10.19.2020>: Added for req 18x.5 ## -- START
	/**
	 * Method Name 			: getDangerousProdcutValue
	 * Method Description 	: 
	 * @param context
	 * @param resultMaps
	 * @return
	 */

	public Map getDangerousProdcutValue(Context context,Map resultMaps)throws Exception
	{
		Map mpDangerousProdcut = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();	

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();

		String strRev = ConstantsUtil.EMPTY_STRING;
		String strName = ConstantsUtil.EMPTY_STRING;
		String strTitle = ConstantsUtil.EMPTY_STRING;
		String strId = ConstantsUtil.EMPTY_STRING;
		String strTyp = ConstantsUtil.EMPTY_STRING;
		String strState = ConstantsUtil.EMPTY_STRING;
		String strPhase = ConstantsUtil.EMPTY_STRING;

		StringBuilder sbDGD = new StringBuilder();
		StringBuilder sbUNN = new StringBuilder();
		StringBuilder sbPSN = new StringBuilder();
		StringBuilder sbHC = new StringBuilder();
		StringBuilder sbPgroup = new StringBuilder();
		StringBuilder sbShipqty = new StringBuilder();
		StringBuilder sbCON = new StringBuilder();
		StringBuilder sbOPR = new StringBuilder();
		StringBuilder sbUSPGreq = new StringBuilder();
		StringBuilder sbCust = new StringBuilder();
		StringBuilder sbGCUP = new StringBuilder();
		StringBuilder sbGCOP = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbTN1 = new StringBuilder();
		StringBuilder sbTN2 = new StringBuilder();

		StringList slProductSelects = new StringList();
		slProductSelects.add(ConstantsUtil.SELECT_NAME);
		slProductSelects.add(ConstantsUtil.SELECT_TYPE);
		slProductSelects.add(ConstantsUtil.SELECT_CURRENT);
		slProductSelects.add(ConstantsUtil.SELECT_REVISION);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

		//SPEC: 10/29/2020: Added for 18x.5 DEV -- START

		slProductSelects.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		String sComp = sct.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);


		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);


		//SPEC: 10/29/2020: Added for 18x.5 DEV -- END

		StringList slHCPGSelects = new StringList();
		slHCPGSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC);
		slHCPGSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP);


		String strIdsObjectId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID));

		StringList slsObjectId = FrameworkUtil.split(strIdsObjectId, ConstantsUtil.SYMBL_PIPE);
		try
		{
			for(String strID:slsObjectId){

				String sObjectId = strID.trim();

				if(UIUtil.isNotNullAndNotEmpty(sObjectId))
				{
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- START
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- END
					DomainObject doProductPart = new DomainObject(sObjectId);
					Map mpTemp = doProductPart.getInfo(context, slProductSelects);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doProductPart.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

					//SPEC: 10/29/2020: Added for 18x.5 DEV -- START
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- END
					strRev = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
					strName = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
					strTitle = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					strId = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ID));
					strTyp = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
					strState = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_CURRENT));
					strPhase = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

					//SPEC: 10/29/2020: Added for 18x.5 DEV -- START
					String	sIpClass = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));

					boolean bHasOwnership =false;
					boolean showData =true;

					if(util.isModificatinRequired())
					{
						//Added by Ganesh 1.0.2 Release Start
						//bHasOwnership = util.checkOwnerShip(context, slUserOwnership, strId);
						bHasOwnership=util.checkHasAccess(context, null, strId);
						//Added by Ganesh 1.0.2 Release End
						if(!bHasOwnership)
						{
							strId = ConstantsUtil.NO_ACCESS;
						}
					}else if(sct.isStaffAUGUser()) 
					{
						showData=util.checkHasAccess(context, null,strId);
					}else 
					{
						
						//Added by Ganesh 1.0.2 Release Start
						showData=util.checkHasAccess(context, null,strId);
						//Added by Ganesh 1.0.2 Release Start

					}

					if(!showData){
						strId = ConstantsUtil.NO_ACCESS;
					}

					//SPEC: 10/29/2020: Added for 18x.5 DEV -- END	

					formatData(sbName, strName);
					formatData(sbRev, strRev);
					formatData(sbTitle, strTitle);
					formatData(sbId, strId);
					formatData(sbType, strTyp);
					formatData(sbState, strState);
					formatData(sbPhase, strPhase);
				}
			}

			//SPEC: Release SR18x.5.2 - Added for Defect# 39371  by Jwala -- START
			String strContextId = (String)resultMaps.get(ConstantsUtil.SELECT_ID);

			DomainObject dobDG = new DomainObject(strContextId);

			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPMENTLIMITEDQUANTITY);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERWEIGHTVOLUME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXCONSUMERUNITSIZE);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERWEIGHTVOLUME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCUPLABELREQUIRED);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCOPLABELREQUIRED);
			slBusSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_HAZARDCLASS);
			slBusSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_PACKINGGGROPUP);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME1);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME2);

			MapList mlDGDList = dobDG.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODS,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, null, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobDG.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator objectListItr = mlDGDList.iterator();

			while(objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();

				String strDGD = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String strUNN = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER));
				String strPSN = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME));
				String strShipqty = validator.getStringEquivalentForString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPMENTLIMITEDQUANTITY));
				String strCON = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERWEIGHTVOLUME));
				
				//SPEC: Release SR18x.6.0 - Added by Amman on Apr 9, 2021 for Defect 42255 -- START
				//String strOPR = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS));
				String strOPR = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS));
				//SPEC: Release SR18x.6.0 - Added by Amman on Apr 9, 2021 for Defect 42255 -- END
				
				String strUSPGreq = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXCONSUMERUNITSIZE));
				String strCUST = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERWEIGHTVOLUME));
				
				//SPEC: Release SR18x.6.0 - Added by Amman on Apr 7, 2021 for Defect 42187 -- START
				//String strSDgcup = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCUPLABELREQUIRED));
				String strSDgcup = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCUPLABELREQUIRED));
				//String strSDgcop = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCOPLABELREQUIRED));
				String strSDgcop = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCOPLABELREQUIRED));
				//SPEC: Release SR18x.6.0 - Added by Amman on Apr 7, 2021 for Defect 42187 -- END
				
				String strHC  = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_HAZARDCLASS));
				
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- START
				//String strPGGroup = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_PACKINGGGROPUP));
				String strPGGroup = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_PACKINGGGROPUP));
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 14, 2021 -- END
				
				String strTN1 = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME1));
				String strTN2 = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME2));

				formatData(sbHC, strHC);
				formatData(sbPgroup, strPGGroup);
				formatData(sbDGD, strDGD);
				formatData(sbUNN, strUNN);
				formatData(sbPSN, strPSN);
				formatData(sbShipqty, strShipqty);
				formatData(sbCON, strCON);
				formatData(sbOPR, strOPR);
				formatData(sbUSPGreq, strUSPGreq);
				formatData(sbCust, strCUST);
				formatData(sbGCUP, strSDgcup);
				formatData(sbGCOP, strSDgcop);
				formatData(sbTN1, strTN1);
				formatData(sbTN2, strTN2);
			}
			
			
			mpDangerousProdcut.put(ConstantsUtil.PPN, sbName.toString());
			mpDangerousProdcut.put(ConstantsUtil.ID, sbId.toString());
			mpDangerousProdcut.put(ConstantsUtil.TYPE, sbType.toString());
			mpDangerousProdcut.put(ConstantsUtil.PPR,sbRev.toString());
			mpDangerousProdcut.put(ConstantsUtil.PPT,sbTitle.toString());
			mpDangerousProdcut.put(ConstantsUtil.DGD,sbDGD.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNN,sbUNN.toString());
			mpDangerousProdcut.put(ConstantsUtil.PSN,sbPSN.toString());
			mpDangerousProdcut.put(ConstantsUtil.HC,sbHC.toString());
			mpDangerousProdcut.put(ConstantsUtil.PGGROUP,sbPgroup.toString());
			mpDangerousProdcut.put(ConstantsUtil.SHIPPINGQTY,sbShipqty.toString());
			mpDangerousProdcut.put(ConstantsUtil.CON,sbCON.toString());
			mpDangerousProdcut.put(ConstantsUtil.OPR,sbOPR.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNSPECPACKGGREQUIRED,sbUSPGreq.toString());
			mpDangerousProdcut.put(ConstantsUtil.CUST,sbCust.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCUP,sbGCUP.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCOP,sbGCOP.toString());
			mpDangerousProdcut.put(ConstantsUtil.PHASE,sbPhase.toString());
			mpDangerousProdcut.put(ConstantsUtil.STATE,sbState.toString());
			mpDangerousProdcut.put(ConstantsUtil.TN1,sbTN1.toString());
			mpDangerousProdcut.put(ConstantsUtil.TN2,sbTN2.toString());

		}catch(Exception e){
			LOGGER.error("Error from FPPBO:  getDangerousProdcutValue"+e);
			return new HashMap();
		}
		return mpDangerousProdcut;
	}
	
	
	/**
	 * Method Name 			: getSapBOMasFed
	 * Method Description 	: It will return the connected SAP BOM
	 * @param context
	 * @param sID
	 * @return
	 */
	public Map getSapBOMasFed(Context context ,String sID){
		
		CalculateBOM clBom = new CalculateBOM();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		Map mapSapBomAsFedResult = new HashMap();
		
		SecurityService sct = new SecurityService();
		boolean isStaffAUg = sct.isStaffAUGUser();
		
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbSapType = new StringBuilder();
		StringBuilder sbSpecSubType = new StringBuilder();
		StringBuilder sbSpecGroup = new StringBuilder();
		StringBuilder sbBOMQTY = new StringBuilder();
		StringBuilder sbBuom = new StringBuilder();
		StringBuilder sbComnt = new StringBuilder();
		StringBuilder sbSAPDesc = new StringBuilder();
		StringBuilder sbAuthorized = new StringBuilder();
		StringBuilder sbAuthorizedToUse = new StringBuilder();
		StringBuilder sbAuthorizedToProduce = new StringBuilder();
		StringBuilder sbOC = new StringBuilder();
		
		StringBuilder sbTUType = new StringBuilder();
		StringBuilder sbTUName = new StringBuilder();
		StringBuilder sbTUId = new StringBuilder();
		
		
		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		
		try
		{
			ArrayList alSapBom = performDataReadFromEnovia(context,sID);
			MapList ml = getTableData(context,alSapBom);
			
			sbSpecSubType = clBom.getSpecificationSubtype(context ,ml);
			Iterator objectListItr = ml.iterator();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sId =(String)objectMap.get(ConstantsUtil.MAP_KEY_ID);
				String sName =(String)objectMap.get(ConstantsUtil.NAME);
				
				String sTitle =(String)objectMap.get(ConstantsUtil.DESCRIPTION);
				String sType =(String)objectMap.get(ConstantsUtil.TYPE);
				String sSapType =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPTYPE);
				String sSpecGroup =(String)objectMap.get(ConstantsUtil.MAP_KEY_SUBSTITUTE);
				String sQty =(String)objectMap.get(ConstantsUtil.MAP_KEY_BOMQTY);
				String sBuom =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPUOM);
				String strClassFied = (String)objectMap.get(ConstantsUtil.SECURITY);
				String strControlClass = (String)objectMap.get(ConstantsUtil.OBJECTSECURITYCLASS);
				String strComment = (String)objectMap.get(ConstantsUtil.ATTRIBUTE_COMMENT);
				String strSAPDesc = (String)objectMap.get(ConstantsUtil.SAPDESCRIPTION);
				
				
				
				
				String strOC = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.OC));
				 String strAuthorizedToProduce =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE));
				String strAuthorizedToUse = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE));
				String strAuthorized = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZED));
				
				strOC = strOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			
				String strTUType = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_TYPE);
				String strTUName = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_NAME);
				String strTUId = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_ID);
				
				
				boolean bHasOwnership = false;
				String sUserlicense = sct.getUserLicense();
				String sFormulaPropagate = sId;
				
				if(sType.equals(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT) || sType.equals(ConstantsUtil.TYPE_FORMULA_CARD))
				{
					sId =ConstantsUtil.NO_ACCESS;
					sTitle =ConstantsUtil.NO_ACCESS;
					
					strAuthorized=ConstantsUtil.NO_ACCESS;
					strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
					strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
					
					
			}
			else
			{
				if(util.isModificatinRequired())
				{
					
					//commented by Ganesh for security impl---->start
					bHasOwnership = util.checkHasAccess(context, null, sId);
					//commented by Ganesh for security impl---->end
					if(!bHasOwnership)
					{
						sTitle = ConstantsUtil.NO_ACCESS;
						sId =ConstantsUtil.NO_ACCESS;
						sTitle =ConstantsUtil.NO_ACCESS;
						sSapType =ConstantsUtil.NO_ACCESS;
						sSpecGroup =ConstantsUtil.NO_ACCESS;
						sQty =ConstantsUtil.NO_ACCESS;
						sBuom =ConstantsUtil.NO_ACCESS;
						strComment=ConstantsUtil.NO_ACCESS;
						strSAPDesc=ConstantsUtil.NO_ACCESS;
						strAuthorized=ConstantsUtil.NO_ACCESS;
						strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
						strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
						strOC=ConstantsUtil.NO_ACCESS;
					}
				}else
				{
					boolean showData = true;
					
					//commented by Ganesh for security impl---->start
					showData = util.checkHasAccess(context, null, sId);
					//commented by Ganesh for security impl---->end
					if(!showData)
					{
						sId =ConstantsUtil.NO_ACCESS;
						sTitle =ConstantsUtil.NO_ACCESS;
						if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
							strAuthorized=ConstantsUtil.NO_ACCESS;
						}else{
							strAuthorized=ConstantsUtil.EMPTY_STRING;
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
							strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
						}else{
							strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
							strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
						}else{
							strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
						}
						strTUId=ConstantsUtil.NO_ACCESS;
						
					}

				}
			}	
				util.formatData(sbId,sId);
				util.formatData(sbName,sName);
				util.formatData(sbTitle,sTitle);
				util.formatData(sbType,util.mapType(sType));
				util.formatData(sbSapType,sSapType);
				util.formatData(sbSpecGroup,sSpecGroup);
				util.formatData(sbBOMQTY,sQty);
				util.formatData(sbBuom,sBuom);
				util.formatData(sbComnt,strComment);
				util.formatData(sbSAPDesc,strSAPDesc);
				util.formatData(sbAuthorized,strAuthorized);
				util.formatData(sbAuthorizedToUse,strAuthorizedToUse);
				util.formatData(sbAuthorizedToProduce,strAuthorizedToProduce);
				util.formatData(sbOC,strOC);
				
				util.formatData(sbTUType,strTUType);
				util.formatData(sbTUName,strTUName);
				util.formatData(sbTUId,strTUId);
			}

			mapSapBomAsFedResult.put(ConstantsUtil.NAME, sbName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.ID, sbId.toString());
			//mapSapBomAsFedResult.put(ConstantsUtil.TITLE, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TYPE, sbType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPTYPE, sbSapType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONGROUP, sbSpecGroup.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BOMQUANTITY, sbBOMQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbBuom.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.COMMENTS, sbComnt.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPDESCRIPTION, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZED, sbAuthorized.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOUSE, sbAuthorizedToUse.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, sbAuthorizedToProduce.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.OC,sbOC.toString());
			
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_NAME,sbTUName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_TYPE,sbTUType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_ID,sbTUId.toString());

		}catch(Exception e){
			
		LOGGER.error("Exception in program FPPBO :getSapBOMasFed ");
			return new HashMap();
		}
		return mapSapBomAsFedResult;
	}
	
	
	/**
	 * Method Name 			: performDataReadFromEnovia
	 * Method Description 	: 
	 * @param context
	 * @param sPartObjectID
	 * @return
	 * @throws Exception
	 */
	public synchronized ArrayList performDataReadFromEnovia(Context context,String sPartObjectID) throws Exception {

		Map 	mapPartDetails				= new HashMap();

		ArrayList alPartRelatedObjects 		= new ArrayList();
		String strSpecSubType = DomainConstants.EMPTY_STRING;
		String strFormulationType = DomainConstants.EMPTY_STRING;

		StringValidatorUtil BusinessUtil= new StringValidatorUtil();
		CalculateBOM clBom = new CalculateBOM();
		
		try {

			if(BusinessUtil.isNotNullOrEmpty(sPartObjectID)){

				DomainObject doPart = DomainObject.newInstance(context,sPartObjectID);
				StringList slBusSelect = new StringList(12);
				slBusSelect.add(DomainConstants.SELECT_TYPE);
				slBusSelect.add(DomainConstants.SELECT_NAME);
				slBusSelect.add(DomainConstants.SELECT_ID);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slBusSelect.add(ConstantsUtil.STR_IPCLASS);
				
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slBusSelect.add("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
				slBusSelect.add("next.id");
				mapPartDetails = doPart.getInfo(context, slBusSelect);

				if(null != mapPartDetails && mapPartDetails.size()>0) {

					strSpecSubType = (String) mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					Object OFormulationType = (Object)mapPartDetails.get("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);

					StringList slFormulationType = new StringList();

					if (null != OFormulationType) {
						if (OFormulationType instanceof StringList) {
							slFormulationType = (StringList) OFormulationType;
						} else if (OFormulationType instanceof String) {
							slFormulationType.add(OFormulationType.toString());
						}
					}								
					if(clBom.doProdUsageCheckForeDelivery(context,mapPartDetails)) {

						String strPartType	=	(String)mapPartDetails.get(DomainConstants.SELECT_TYPE);

						if(BusinessUtil.isNotNullOrEmpty(strPartType)) {

							if(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equalsIgnoreCase(strPartType)) {

								alPartRelatedObjects = clBom.getPartObjectsFromEBOM(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_FORMULATIONPART.equalsIgnoreCase(strPartType) && !slFormulationType.isEmpty() && !slFormulationType.contains(ConstantsUtil.THIRD_PARTY_FORMULA) ) {
								alPartRelatedObjects = clBom.getObjectsForFOPFromFormulaIngredient(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(strPartType) || (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strPartType) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromIntermediateBOM(context,sPartObjectID);
							} else if(ConstantsUtil.TYPE_FABRICATEDPART.equalsIgnoreCase(strPartType) ||   ConstantsUtil.TYPE_INTERMEDIATEPRODUCTPART.equalsIgnoreCase(strPartType) || ((ConstantsUtil.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strPartType)) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromBOM(context,sPartObjectID);
							}
						}
					}
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return alPartRelatedObjects;
	}
	
	
	/**
	 * Method Name 			: getTableData
	 * Method Description 	: 
	 * @param context
	 * @param alPartObjectsWithGroupAndQty
	 * @return
	 * @throws Exception
	 */
	public MapList getTableData(Context context, ArrayList alPartObjectsWithGroupAndQty) throws Exception {
		MapList mpReturnList = new MapList();
		boolean isContextPushed = false;
		int OBJECT_ID = 27;
		int SUBSTITUTE_FLAG = 14;
		int QUANTITY = 10;
		int FC_MIN_QTY = 23;
		int FC_MAX_QTY = 25;
		int SORT_STRING = 13;
		int TUP_ID = 28;
		int OPT_COMPONENT = 29;
		
		//SPEC 11/05/2020 added for defect:37077 ##--START
		int INDEX_TPU_TYPE = 34;
		int INDEX_TPU_NAME = 35;
		//SPEC 11/05/2020 added for defect: 37077##--END
		try {
			StringList slPartSelect = new StringList(7);
			slPartSelect.addElement(DomainConstants.SELECT_NAME);
			slPartSelect.addElement(DomainConstants.SELECT_TYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slPartSelect.addElement(ConstantsUtil.STR_IPCLASS);
			slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			//slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
			
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_IPCLASS);
			ContextUtil.pushContext(context);
			isContextPushed = true;
			if(null != alPartObjectsWithGroupAndQty) 
			{
				int alsize=alPartObjectsWithGroupAndQty.size();
				StringValidatorUtil validator = new StringValidatorUtil();
				String strObjID = null;
				String strSubstitute=null;
				String strBOMQuantity = null;
				String strMin = null;
				String strMax = null;
				String strPosInd = null;
				String strObjectType = null;
				String strSAPUOM = null;
				String strSAPType = null;
				String strPGCSSType = null;
				String strTUPObjID = null;
				String strIPClass = null;
				String strOptComponent = null;
				//String strAuthorized = null;
				//String strAuthorizedToUse = null;
				//String strAuthorizedToProduce = null;
				String strTransportUnit = null;
				DomainObject domObject = null;
				Map mpPartObjectInfo = null;
				int COMMENT = 30;
				
				String strComment = DomainConstants.EMPTY_STRING; 
				String strName = DomainConstants.EMPTY_STRING; 
				String strDescription = DomainConstants.EMPTY_STRING; 
				
				String strTUPObjName = DomainConstants.EMPTY_STRING; 
				String strTUPObjType = DomainConstants.EMPTY_STRING;
				
				HashMap hmTemp = null;
				
				//SPEC 11/05/2020 added for defect: 37077##--START
				StringList slRelSelect = new StringList();
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
				//SPEC 11/05/2020 added for defect: 37077##--END
				
				CalculateBOM clBom = new CalculateBOM();
				for (int i=0; i<alsize; i++) {
					String [] satemp = (String[]) alPartObjectsWithGroupAndQty.get(i);
					strObjID = satemp[OBJECT_ID];
					strSubstitute= satemp[SUBSTITUTE_FLAG];
					strBOMQuantity = satemp[QUANTITY];
					strMin = satemp[FC_MIN_QTY];
					strMax = satemp[FC_MAX_QTY];
					strPosInd = satemp[SORT_STRING];
					//SPEC 11/05/2020 added for defect: 37077##--START
					strTUPObjID = validator.getStringEquivalentForStringList(satemp[TUP_ID]);
					strTUPObjName = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_NAME]);
					strTUPObjType = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_TYPE]);
					//SPEC 11/05/2020 added for defect: 37077##--END
					String sqty = satemp[ConstantsUtil.INDEX_TARGET] ;	
					strOptComponent = satemp[OPT_COMPONENT];
					domObject = DomainObject.newInstance(context,strObjID);
					mpPartObjectInfo = domObject.getInfo(context, slPartSelect);
					strObjectType = (String)mpPartObjectInfo.get(DomainConstants.SELECT_TYPE);
					strSAPUOM = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					strSAPType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
					strPGCSSType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
					strComment = satemp[COMMENT];
					strName = (String)mpPartObjectInfo.get(DomainConstants.SELECT_NAME);
					strDescription = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					//strAuthorized =  validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
					
					
					strIPClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.STR_IPCLASS));
					String strIPControlClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
					
					//SPEC 11/05/2020 added for defect: ##--START
					MapList mlParentPlantList = clBom.getConnectedPlantList(context, strObjID, slRelSelect, null);
				
					boolean bTUPAccess=false;
					if(UIUtil.isNotNullAndNotEmpty(strTUPObjID)){
					 bTUPAccess = clBom.checkHasAccess(context,strTUPObjID);
					}
					
					if(!bTUPAccess){
						strTUPObjID=ConstantsUtil.NO_ACCESS;
					}
					
					StringList	slAVPlantList = new StringList();
					StringList	slAUPlantList = new StringList();
					StringList	slAPPlantList = new StringList();
					if(mlParentPlantList!=null && mlParentPlantList.size()>0)
					{
						for(int ip=0;ip<mlParentPlantList.size();ip++)
						{
							Map mapSAPBOMComponent = (Map)mlParentPlantList.get(ip);
							String	sAVAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
							String	sAUAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
							String	sAPAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
							String	sSAPBOMComponentPlantName = (String)mapSAPBOMComponent.get(DomainObject.SELECT_NAME);
							
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAVAttributeValue) && strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAVPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAUAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAUPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAPAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAPPlantList.add(sSAPBOMComponentPlantName);
							}
						}
					}
					
					String	strAVPlantList = DomainConstants.EMPTY_STRING;
					String	strAUPlantList = DomainConstants.EMPTY_STRING;
					String	strAPPlantList = DomainConstants.EMPTY_STRING;
					
					if(slAVPlantList!= null && slAVPlantList.size()>0)
					{
						strAVPlantList = FrameworkUtil.join(slAVPlantList, "&&&");
					}

					if(slAUPlantList!= null && slAUPlantList.size()>0)
					{
						strAUPlantList = FrameworkUtil.join(slAUPlantList, "&&&");
					}
					
					if(slAPPlantList!= null && slAPPlantList.size()>0)
					{
						strAPPlantList = FrameworkUtil.join(slAPPlantList, "&&&");
					}
					
					//SPEC 11/05/2020 added for defect: ##--END
					
					
					hmTemp = new  HashMap();
					hmTemp.put("id",strObjID);  
					hmTemp.put("type",strObjectType);  
					hmTemp.put("substitute",strSubstitute);
					hmTemp.put("BOMQty",strBOMQuantity);
					hmTemp.put("Min",strMin);
					hmTemp.put("Max",strMax);
					hmTemp.put("PosInd",strPosInd);
					hmTemp.put("SAPUOM",strSAPUOM);
					hmTemp.put("SAPType",strSAPType);
					hmTemp.put("SSType",strPGCSSType);
					hmTemp.put("dispId", strObjID);
					
					hmTemp.put("OptComponent", strOptComponent);
					hmTemp.put(ConstantsUtil.ATTRIBUTE_COMMENT, strComment);
					hmTemp.put(DomainConstants.SELECT_NAME, strName);
					hmTemp.put(DomainConstants.SELECT_DESCRIPTION, strDescription);
					hmTemp.put(ConstantsUtil.SECURITY, strIPClass);
					hmTemp.put(ConstantsUtil.OBJECTSECURITYCLASS, strIPControlClass);
					
					hmTemp.put(ConstantsUtil.AUTHORIZED, strAVPlantList);
					hmTemp.put(ConstantsUtil.OC, strOptComponent);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOUSE, strAUPlantList);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, strAPPlantList);
					
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_TYPE, strTUPObjType);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_NAME, strTUPObjName);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_ID, strTUPObjID);
					
					
					mpReturnList.add(hmTemp);
				}
			}
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(isContextPushed) {
				ContextUtil.popContext(context);
				isContextPushed = false;
			}
		}
		return mpReturnList;
	}
	
	
	/**
     * Method Name 			: updatePartSpec
     * Method Description 	:
     * @param context
     * @param objectMap
     * @return
     */
    public Map updatePartSpec(Context context, Map objectMap) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

							mpPartSpecs = getPartSpecifications(context, sType, sID);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FPPBO Method :updatePartSpec " + e);
			return new HashMap();

		}
		return util.filterMapList(mpPartSpecs);
	}
    
    
    /**
     * Method Name 			: getPartSpecifications
     * Method Description 	:
     * @param context
     * @param sParentType
     * @param sObjectID
     * @return
     * @throws Exception
     */
    public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		boolean showData = false;
		
		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;
		
		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
			sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		}

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
					slPartSpecSelects, null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				

				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}

				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
				showData=util.checkHasAccess(context, sUserType, strId);
				if (showData) {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
					String strTitle = validator.getStringEquivalentForSubstituteString(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
					String strOrig = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
					sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
					//temporary fix to prevent users from downloading a Physical product(VPMReference)
					if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
						sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
					}else {
						
						sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
					}
				} else {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
				}
			}
			//}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
				mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
				mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			}

		} catch (FrameworkException e) {
			LOGGER.error("Exception in FPPBO getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
    }


    /**
     * 
     * @param context
     * @param mlMasterSpecs
     * @return
     * @throws Exception
	 */

	public Map getFPPMasterSpecifications(Context context, MapList mlMasterSpecs) throws Exception 
	{
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringBuilder sbMasterPartName = new StringBuilder();
		//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
		StringBuilder sbMasterPartType = new StringBuilder();		
		StringBuilder sbMasterPartId = new StringBuilder();
		//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END
		
		StringValidatorUtil validator = new StringValidatorUtil();

		try 
		{
			String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION;
			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			//String[] aCompany = sUserCompanies.split(",");
			String[] aCompany = new String[100];
			if (validator.isNotNullOrEmpty(sUserCompanies)) {
				aCompany = sUserCompanies.split(",");	
			}
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			StringBuilder sbCompany = new StringBuilder();
			StringList slCompanies = new StringList();

			boolean bHasOwnerShip = false;
			String sWhere = ConstantsUtil.EMPTY_STRING;
			String sUserType = util.getUserType();
			
			//SPEC: 10-23-2020 : Modified for Defect: 36677 ## -- START	
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			//SPEC: 10-23-2020 : Modified for Defect: 36677 ## -- END
			
			if (util.isModificatinRequired()) {
				
				//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 11, 2021 for Req #33248 -- START
				//sWhere = "current!=Obsolete";
				sWhere = "current==Release";
				//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 11, 2021 for Req #33248 -- END
			}
			if (aCompany.length > -1) {
				for (int k = 0; k < aCompany.length; k++) {
					if (null != aCompany[k]) {
						String Company = aCompany[k].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
						slCompanies.add(Company);
					}
				}
			}
			StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
			MapList mapList;
			//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
			String sChildId ="";
			//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END
			//SPEC: <08.04.2021>: Guna Added for 42226 Defect 18x.6   -- START
			StringList duplicateList =new StringList();
			//SPEC: <08.04.2021>: Guna Added for 42226 Defect 18x.6   -- END
			for (int j = 0; j < mlMasterSpecs.size(); j++) 
			{
				Map mpMasterEachObj = (Map) mlMasterSpecs.get(j);

				String strMasterId = validator.getStringEquivalentForStringList(mpMasterEachObj.get(ConstantsUtil.ID));
				
				//SPEC: 11-03-2020 : added for Defect: 37028 ## -- START
				if(mpMasterEachObj.containsKey(ConstantsUtil.RELATIONSHIP)){
					//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
					sChildId = validator.getStringEquivalentForStringList(mpMasterEachObj.get(ConstantsUtil.STR_DERIVED_PATH_ID));
				} else {
					sChildId=strMasterId;
				}
				//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END
				//SPEC: 11-03-2020 : added for Defect: 37028 ## -- END 
				String strMasterPartName  = validator.getStringEquivalentForStringList(mpMasterEachObj.get("strMasterName"));
				//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
				//String strMasterPartType  = validator.getStringEquivalentForStringList(mpMasterEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strMasterPartType  = validator.getStringEquivalentForStringList(mpMasterEachObj.get("strMasterType"));
				//DomainObject doAPP = new DomainObject(strMasterId);	
				
				//SPEC: <08.04.2021>: Guna Added for 42226 Defect 18x.6   -- START
				if(!duplicateList.contains(sChildId)){
					duplicateList.add(sChildId);
				//SPEC: <08.04.2021>: Guna Added for 42226 Defect 18x.6   -- END
				DomainObject doAPP = new DomainObject(sChildId);
				//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END						

				mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
						slPartSpecSelects, null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
						ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doAPP.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				for (int x = 0; x < mapList.size(); x++) 
				{
					Map mpEachObj = (Map) mapList.get(x);
					StringList eachOwnership = validator
							.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
					// Split this to get only the companies
					StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

					String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
					String strName = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_NAME));
					String strSharable = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
					String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
					String strClassFied = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
					String sIPClassfication = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
					String strSource = util.getSource(context, strId);
					String strSubType = util.UpdateSpecSubType(context, strId);
					
					
					boolean showData=util.checkHasAccess(context, sUserType, strId);
					
					//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- START
					if(util.isModificatinRequired()) {
						if(!showData) {
							continue;
						}
					}
					//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- END
					
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
						sbMasterPartType.append(strMasterPartType).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartId.append(sChildId).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
						sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END
					}
				}
				//SPEC: <08.04.2021>: Guna Added for 42226 Defect 18x.6   -- START
				}
				//SPEC: <08.04.2021>: Guna Added for 42226 Defect 18x.6   -- END
			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			mpFinalList.put(ConstantsUtil.MASTERPARTNAME, sbMasterPartName.toString());
			//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- START
			mpFinalList.put(ConstantsUtil.MASTERPARTTYPE, sbMasterPartType.toString());
			mpFinalList.put(ConstantsUtil.MASTERPARTID, sbMasterPartId.toString());
			//SPEC: 10-11-2020 : Modified for Defect: 37078 ## -- END			
			

		} catch (FrameworkException e) {
			LOGGER.error("Exception in FPPBO getFPPPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}
	
	
/**
     * Method Name 			: getIpClass
     * Method Description 	: Get IP Classification
     * @param context
     * @param doFormObj  - domain object of part
     * @param slIpSelects - Selectable
     */
    public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
    	MapList mlIPCLass;
		try {
			mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
					null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			Iterator itr = mlIPCLass.iterator();
			Map mpIpClass = new HashMap();
			StringBuilder sbIpName = new StringBuilder();
			StringBuilder sbHasClassAccess = new StringBuilder();
			StringBuilder sbIpType = new StringBuilder();
			StringBuilder sbIpDesc = new StringBuilder();
			StringBuilder sbIpState = new StringBuilder();
			StringBuilder sbIpLibrary = new StringBuilder();
			StringBuilder sbIpClassPath = new StringBuilder();
			
			while(itr.hasNext()) {
				mpIpClass = (Map)itr.next();
				String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
				sbIpName.append(sIpClassName);
				sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
				sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
				sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
				String strIpClass="";
				if(sIpClassName.contains(ConstantsUtil.HIR)) {
					strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
					sbIpLibrary.append(strIpClass);
				} else {
					strIpClass= ConstantsUtil.BUSINESS_USE;
					sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
				}
				if(!strIpClass.isEmpty()) {
					StringBuilder sbIpClassTemp = new StringBuilder();
					sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
					sbIpClassPath.append(sbIpClassTemp.toString());
				}
				
				//Compare user classification against IPName
				sbHasClassAccess.append("TRUE");
				
				if(itr.hasNext()) {
					sbIpName.append("|");
					sbIpType.append("|");
					sbIpDesc.append("|");
					sbIpState.append("|");
					sbIpLibrary.append("|");
					sbIpClassPath.append("|");
					sbHasClassAccess.append("|");
				}
			}
			mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
			mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
			mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
			mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());

		} catch (FrameworkException e) {
			e.printStackTrace();
			LOGGER.error("Error from FPPBO: getIpClass" + e);
		}
		return mpIpSecuritySetting;
    }
    
    
    /**
	 * Method Name 			: getStabilityDoc
	 * Method Description 	: Getting the Stability Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getStabilityDoc(Context context,Map resultMaps) 
	{
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
		
		//SPEC: Release SR18x.5.2 - Added for Defect# 39377  by Guna on Date 15/02/2021 -- START
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39377  by Guna on Date 15/02/2021 -- END
		
		StringList relSelects = new StringList();
		relSelects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		relSelects.addElement(ConstantsUtil.SELECT_RELATIONSHIP_ID);
		
		boolean bHasOwnerShip = false;
		//Added for Requirement #38397 by Manikanta -- START
		boolean bHasPartAccess = false;
		//Added for Requirement #38397 by Manikanta -- END
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		if (UIUtil.isNotNullAndNotEmpty(sUserCompanies))
		{
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END	
			String[] aCompany = sUserCompanies.split(",");
			StringBuilder sbCompany = new StringBuilder();
			
			if(aCompany.length>-1) {
				for(int i=0;i<aCompany.length;i++) {
					if(null!=aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					}
				}
			}
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		}
		//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		
		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			DomainObject doFOP = new DomainObject(sObjectId);
			MapList mlRefDocs = doFOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGROLLEDUPSTABILITYREPORT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, relSelects, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doFOP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			//Added for Requirement #38397 by Manikanta -- START
			bHasPartAccess = util.checkHasAccess(context, null, sObjectId);
			//Added for Requirement #38397 by Manikanta -- END
			String sUser = util.getUserType();
			
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			if (UIUtil.isNotNullAndNotEmpty(sUser))
			{
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				if(sUser.equals(ConstantsUtil.PG_CM))
				{
					if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
						return new HashMap();
					}
				}
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			}
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			
			
			Iterator objectListItr = mlRefDocs.iterator();
			//SPEC: Release SR18x.5.2 - Added for Defect# 39375  by Ganesh on Date 2/11/2021 -- START
			StringBuilder sbType=new StringBuilder();
			//SPEC: Release SR18x.5.2 - Added for Defect# 39375  by Ganesh on Date 2/11/2021 -- END
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbProductPartId = new StringBuilder();
			StringBuilder sbProductPartName = new StringBuilder();
			StringBuilder sbProductPartType = new StringBuilder();
			StringBuilder sbProductPartRevision = new StringBuilder();
			StringBuilder sbProductPartTitle =new StringBuilder();
			StringBuilder sbProductExpirationDataRequired=new StringBuilder();
			StringBuilder sbTotalShelfLifeDays=new StringBuilder();
			StringBuilder sbTemperatureGroup=new StringBuilder();
			StringBuilder sbHumidityGroup=new StringBuilder();
			StringBuilder sbTransportFreezeProtection = new StringBuilder();
			StringBuilder sbTransportHeatProtection = new StringBuilder();
			StringBuilder sbBoundaryConditions = new StringBuilder();
			StringBuilder sbStabilityDocument = new StringBuilder();
			
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				String sId    =  (String)objectMap.get(ConstantsUtil.SELECT_ID);
				
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	 =	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sProductPartName =ConstantsUtil.EMPTY_STRING;
				String sProductPartType =ConstantsUtil.EMPTY_STRING;
				String sProductPartRevision =ConstantsUtil.EMPTY_STRING;
				String sProductPartTitle =ConstantsUtil.EMPTY_STRING;
				String sProductPartId =ConstantsUtil.EMPTY_STRING;
				String sProductPartownership =ConstantsUtil.EMPTY_STRING;
				String sProductPartIpClass =ConstantsUtil.EMPTY_STRING;
				StringList eachOwnership = new StringList();
				String strProdPhysicalId = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
				if (UIUtil.isNotNullAndNotEmpty(strProdPhysicalId)) {
					DomainObject domProductPart = new DomainObject(strProdPhysicalId);
					sProductPartId = domProductPart.getInfo(context, ConstantsUtil.SELECT_ID);
					
					sProductPartName = domProductPart.getInfo(context, ConstantsUtil.SELECT_NAME);
					sProductPartType = domProductPart.getInfo(context, ConstantsUtil.SELECT_TYPE);
					sProductPartRevision = domProductPart.getInfo(context, ConstantsUtil.SELECT_REVISION);
					sProductPartTitle = domProductPart.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					sProductPartIpClass = domProductPart.getInfo(context, ConstantsUtil.STR_IPCLASS);
					sProductPartownership = domProductPart.getInfo(context, ConstantsUtil.OWNERSHIP);
					eachOwnership = validator.getStringListEquivalentForString(domProductPart.getInfo(context, ConstantsUtil.OWNERSHIP));
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					domProductPart.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					//SPEC: <07.04.2021>: Guna Added for 42192 Defect  Dev 18x.6   -- START
					bHasPartAccess = util.checkHasAccess(context, null, sProductPartId);
					if(!bHasPartAccess) {
						sProductPartId = ConstantsUtil.NO_ACCESS;
						//SPEC: Jwala Added for 42613 Defect  Dev 18x.6   -- START
						sProductPartTitle = ConstantsUtil.NO_ACCESS;
						//SPEC: Jwala Added for 42613 Defect  Dev 18x.6   -- END
					}
					//SPEC: <07.04.2021>: Guna Added for 42192 Defect  Dev 18x.6   -- END
					
					if (util.isModificatinRequired()) 
					{
						//Added by Ganesh 1.0.2 Release Start
						//bHasOwnerShip = util.checkOwnerShip(sbCompany,eachOwnership);
						bHasOwnerShip=util.checkHasAccess(context, null, sId);
						//Added by Ganesh 1.0.2 Release End
						//SPEC: Release SR18x.6.1 - Modified by Manikanta for Internal EBP Issue for Req# 38397 on 30/04/2021 -- START
						//if(sCurrent != ConstantsUtil.RELEASE) {
						if(!sCurrent.equals(ConstantsUtil.RELEASE)) {
							continue;
						}
						//SPEC: Release SR18x.6.1 - Modified by Manikanta for Internal EBP Issue for Req# 38397 on 30/04/2021 -- END
						if(bHasOwnerShip) {
							showData=true;
						}
						
					}else if(sct.isStaffAUGUser()) {
						
						//Added by Ganesh 1.0.2 Release Start
						showData=util.checkHasAccess(context, null, sId);
						//Added by Ganesh 1.0.2 Release End
						//Added by Jwala for the defect 49861 -- START
						if(!sCurrent.equals(ConstantsUtil.RELEASE)) {
							sId = ConstantsUtil.NO_ACCESS;
						}
						
					}else {
						
						//Added by Ganesh 1.0.2 Release Start
						showData=util.checkHasAccess(context, null, sId);
						//Added by Ganesh 1.0.2 Release End
						//Added by Jwala for the defect 49861 -- START
						if(!sCurrent.equals(ConstantsUtil.RELEASE)) {
							sId = ConstantsUtil.NO_ACCESS;
						}
					}
						
				}else {
					continue;
				}
				String sProductExpirationDataRequired	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE));
				String sTotalShelfLifeDays		=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE));
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39377  by Guna on Date 15/02/2021 -- START
				String sTemperatureGroup	=	validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP));
				String sHumidityGroup	=	validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP));
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39377  by Guna on Date 15/02/2021 -- END
				//<11.20.2020> Modified for #37435 SATRT	
				String sTransportFreezeProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
				String sTransportHeatProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
				//<11.20.2020> Modified for #37435 END		
				String sBoundaryConditions = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS));
				String sStabilityDocument = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				
								
				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}
				
				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					String sLangBuffer =ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;

				if(showData) 
				{   
					//SPEC: Release SR18x.5.2 - Added for Defect# 39375  by Ganesh on Date 2/11/2021 -- START
					util.formatData(sbType,sType);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39375  by Ganesh on Date 2/11/2021 -- END
					util.formatData(sbId,sId);
					util.formatData(sbProductPartId,sProductPartId);
					util.formatData(sbProductPartName,sProductPartName);
					util.formatData(sbProductPartType,util.mapType(sProductPartType));
					util.formatData(sbProductPartRevision,sProductPartRevision);
					util.formatData(sbProductPartTitle,sProductPartTitle);
					util.formatData(sbProductExpirationDataRequired,util.mapType(sProductExpirationDataRequired));
					util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
					util.formatData(sbTemperatureGroup,sTemperatureGroup);
					util.formatData(sbHumidityGroup,sHumidityGroup);
					util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
					util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
					util.formatData(sbBoundaryConditions,sBoundaryConditions);
					util.formatData(sbStabilityDocument,sStabilityDocument);

				}else
				{
					// Modified by Jwala for the defect 43812 -- START
					//If the user does not have access all values will show as "No Access" except IRM DOC
					//SPEC: Release SR18x.5.2 - Added for Defect# 39375  by Ganesh on Date 2/11/2021 -- START
					//util.formatData(sbType,util.mapType(sType));
					util.formatData(sbType,ConstantsUtil.NO_ACCESS);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39375  by Ganesh on Date 2/11/2021 -- END
					util.formatData(sbId,ConstantsUtil.NO_ACCESS);
					//SPEC: 10-20-2021:Modified by Jwala for the defect 42818 - START
					if(bHasPartAccess){
						util.formatData(sbProductPartId,sProductPartId);
						util.formatData(sbProductPartTitle,sProductPartTitle);
						util.formatData(sbProductPartName,sProductPartName);
						util.formatData(sbProductPartType,util.mapType(sProductPartType));
						util.formatData(sbProductPartRevision,sProductPartRevision);
					}else{
						util.formatData(sbProductPartId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbProductPartTitle,ConstantsUtil.NO_ACCESS);
						util.formatData(sbProductPartName,ConstantsUtil.NO_ACCESS);
						util.formatData(sbProductPartType,ConstantsUtil.NO_ACCESS);
						util.formatData(sbProductPartRevision,ConstantsUtil.NO_ACCESS);
					}
					//SPEC: 10-20-2021:Modified by Jwala for the defect 42818 - END

					//SPEC: 04-15-2020: Modified for 18x.6 Defect# 42460 by Sanjeeva -- START
					util.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
					//util.formatData(sbProductExpirationDataRequired,util.mapType(sProductExpirationDataRequired));
					util.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
					//util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
					util.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
					//util.formatData(sbTemperatureGroup,sTemperatureGroup);
					util.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
					//util.formatData(sbHumidityGroup,sHumidityGroup);
					util.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
					//util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
					util.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
					//util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
					util.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
					//util.formatData(sbBoundaryConditions,sBoundaryConditions);
					//util.formatData(sbStabilityDocument,ConstantsUtil.NO_ACCESS);
					util.formatData(sbStabilityDocument,sStabilityDocument);
					//SPEC: 04-15-2020: Modified for 18x.6 Defect# 42460 by Sanjeeva -- END

					// Modified by Jwala for the defect 43812 -- END
					//If the user does not have access all values will show as "No Access" except IRM DOC
				}
			  }
			}
			//SPEC: Release SR18x.5.2 - Added for Defect# 39375  by Ganesh on Date 2/11/2021 -- START
			mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
			//SPEC: Release SR18x.5.2 - Added for Defect# 39375  by Ganesh on Date 2/11/2021 -- END
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTID, sbProductPartId.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTNAME, sbProductPartName.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTTYPE, sbProductPartType.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTREVISION, sbProductPartRevision.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTPARTTITLE, sbProductPartTitle.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTEXPDATEREQ, sbProductExpirationDataRequired.toString());
			mpRefDoc.put(ConstantsUtil.TOTALSHELFLIFEDAYS, sbTotalShelfLifeDays.toString());
			mpRefDoc.put(ConstantsUtil.TEMPERATUREGROUP, sbTemperatureGroup.toString());
			mpRefDoc.put(ConstantsUtil.HUMIDITYGROUP, sbHumidityGroup.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, sbTransportFreezeProtection.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTHEATPROTECTION, sbTransportHeatProtection.toString());
			mpRefDoc.put(ConstantsUtil.BOUNDARYCONDITIONS, sbBoundaryConditions.toString());
			mpRefDoc.put(ConstantsUtil.STABILITYDOCUMENT, sbStabilityDocument.toString());

		}catch(Exception e){

			LOGGER.error("Exception in Program : FPPBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return util.filterMapList(mpRefDoc);
		//return mpRefDoc;
	}
	
	
	public Map getTupBom(Context context, MapList mapTupList, StringList slObjSelects, StringList slRelSelects, Map mpTUPSubstituteResult)
			throws Exception {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		//FinishedProductPartBO fppBO = new FinishedProductPartBO();
		MapList mlFinalConnectedEBOMParents = new MapList();
		MapList mlFinalConnectedEBOMParentsForSubstitues = new MapList();
		//BusObjectAttribUtil busutil = new BusObjectAttribUtil();
		StringList slObjSelectsTup= slObjSelects;
		StringList slRelObjSelectsTup= slRelSelects;
		slObjSelectsTup.addAll(addUnitSelects(getMasterBusEbom()));
		slRelObjSelectsTup.addAll(getMasterRelEbom());
		
		try {
			//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- START
			if(slRelObjSelectsTup.contains(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)) {
				slRelObjSelectsTup.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			}
			//SPEC: <31.05.2022>: Guna Added for Req 41754 22x Release  -- END
			String strTupName = ConstantsUtil.EMPTY_STRING;
			String strTupRev = ConstantsUtil.EMPTY_STRING;//Added by Ajay for req 11877 
			StringList slTupName = new StringList();
			StringList slTupId = new StringList();
			StringList slTupRev = new StringList();//Added by Aja for req 11877
			if (mapTupList != null && mapTupList.size() > 0) {
				for (int i = 0; i < mapTupList.size(); i++) {
					MapList mlConnectedEBOMParents = new MapList();
					Map mapObject = (Map) mapTupList.get(i);
					String sTupId = (String) mapObject.get(ConstantsUtil.SELECT_ID);
					strTupName = (String) mapObject.get(ConstantsUtil.SELECT_NAME);
					strTupRev = (String) mapObject.get(ConstantsUtil.SELECT_REVISION);//Added by Ajay for req 11877 
                     //Added by Ganesh 1.0.2 Release Start
					//boolean bHasOwnshp = util.checkOwnerShip(context, sTupId);
					boolean bHasOwnshp=util.checkHasAccess(context, null, sTupId);
                    //Added by Ganesh 1.0.2 Release End
					if (sTupId != null) {
						DomainObject domObject = DomainObject.newInstance(context, sTupId);
						mlConnectedEBOMParents = domObject.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
								ConstantsUtil.QUERY_WILDCARD, slObjSelectsTup, slRelObjSelectsTup, false, true, (short) 0, "", "",
								0);
						
						if (null != mlConnectedEBOMParents && mlConnectedEBOMParents.size() > 0) {
							//Modified by Ketan for Defect no. 52876 -- START (Sorted by Level)
							mlConnectedEBOMParents.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.ASCENDING,
									ConstantsUtil.INTEGER);
							mlConnectedEBOMParents.sort(ConstantsUtil.LEVEL, ConstantsUtil.ASCENDING,
									ConstantsUtil.INTEGER);
							//Modified by Ketan for Defect no. 52876 -- END
							
						}
					}

					if (!bHasOwnshp) {
						sTupId=ConstantsUtil.NO_ACCESS;
					}
					slTupName.add(strTupName);
					slTupId.add(sTupId);
					slTupRev.add(strTupRev);//Added by Ajay for req 11877 

					mlFinalConnectedEBOMParents.add(i, mlConnectedEBOMParents);
				}
				mlFinalConnectedEBOMParentsForSubstitues=mlFinalConnectedEBOMParents;
				mpEBOMResult = parseTUPMaplist(context,mlFinalConnectedEBOMParents,slTupName,slTupId,slTupRev);
				mpTUPSubstituteResult=parseMaplistForTupSubstitute(context, mlFinalConnectedEBOMParentsForSubstitues, mpTUPSubstituteResult);
			}

		}catch(Exception e) {
			LOGGER.info("Exception in getTupBom : Program FPPBO " + e);
			return new HashMap();
		}

		return mpEBOMResult;
	}
	
	//SPEC: <31.05.2022>: Guna Modified for Req 41754 22x Release  -- START
	public Map<String, String> parseTUPMaplist(Context context, MapList mapList, StringList slTupName, StringList slTupId ,StringList slTupRev) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership = util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		
		if(mapList.size()>0) {
			//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- START
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			StringBuilder sbEBOMParentRevision = new StringBuilder();
			StringBuilder sbEBOMParentType = new StringBuilder();
			//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- END
			//Added by Subhajit for Req 46464 - Start
			StringBuilder sbRelRestriction = new StringBuilder();
			StringBuilder sbRelRestrictionComment = new StringBuilder();
			//Added by Subhajit for Req 46464 - End
			StringBuilder sbEBOMName = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMChg = new StringBuilder();
			StringBuilder sbEBOMFN = new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMCommnts = new StringBuilder();
			StringBuilder sbEBOMState = new StringBuilder();
			StringBuilder sbEBOMStage = new StringBuilder();
			StringBuilder sbEBOMRDOC = new StringBuilder();
			StringBuilder sbEBOMSubstute = new StringBuilder();
			StringBuilder sbEBOMRevRelDt = new StringBuilder();
			StringBuilder sbTupName = new StringBuilder();
			StringBuilder sbTupId = new StringBuilder();
			StringBuilder sbTupType = new StringBuilder();
			StringBuilder sbTupRev = new StringBuilder();//Added by Ajay for req 11877 
			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//StringBuilder sbEBOMAlternate = new StringBuilder();
			StringBuilder sbAltName = new StringBuilder();
			StringBuilder sbAltID = new StringBuilder();
			StringBuilder sbAltType = new StringBuilder();
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			StringBuilder sbEBOMOSPD = new StringBuilder();
			StringBuilder sbEBOMDensityUOM = new StringBuilder();
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			StringBuilder sbEBOMSubstitutePart = new StringBuilder();
			StringBuilder sbEBOMSubPartID = new StringBuilder();
			StringBuilder sbEBOMSubPartType = new StringBuilder();
			
			StringBuilder sbGrossWeight = new StringBuilder();
			StringBuilder sbGrossWeightUOM = new StringBuilder();
			
			StringList slHIRTypes = new StringList();

			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			
			StringValidatorUtil validator = new StringValidatorUtil();
			for(int i =0;i<mapList.size();i++) {
				MapList mleach = (MapList) mapList.get(i);
				Iterator objectListItr = mleach.iterator();
				while (objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- START
					String sParentId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID)));
					String sParentName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME)));
					String sParentRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV)));
					String sParentType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE)));
					//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- END
					//Added by Subhajit for Req 46464 - Start
					String sRelRestriction = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
					String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
					//Added by Subhajit for Req 46464 - End
					String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sReleaseDate = validator.DateFormatter((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
					String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON + sReleaseDate;
					String spgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
					String sFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
					String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sTupName = "";
					sType = util.mapType(sType);
					
					
					String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					String sBuom = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					String sComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
					sCurrent = util.mapType(sCurrent);
					String sStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
					String sRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
					sRD = util.replaceSpecialSymbols(sRD);
					String sOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
					sOC = util.replaceSpecialSymbols(sOC);
					String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
					sbTupName.append(slTupName.get(i).toString()).append(ConstantsUtil.SYMBL_PIPE);
					sbTupId.append(slTupId.get(i).toString()).append(ConstantsUtil.SYMBL_PIPE);
					sbTupType.append(util.mapType(ConstantsUtil.TYPE_PGTRANSPORTUNITPART)).append(ConstantsUtil.SYMBL_PIPE);
					sbTupRev.append(slTupRev.get(i).toString()).append(ConstantsUtil.SYMBL_PIPE); //Added by Ajay for req 11877 
					
					
					//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
					String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
					strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
					strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
					//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
					
					String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
					strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					String strAltID = util.checkAlternateHasAccess(context,objectMap);	
					String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
					strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					String sOSPD = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY));
					String sDensityUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM));
					
					String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
					String sGrossWeight= (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
					String sGrossWeightUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
					boolean bHasOwnership = false;

					String sFormulaPropagate = sId;
					if(util.isModificatinRequired())
					{

												bHasOwnership = util.checkHasAccess(context, null, sId);
						if(!bHasOwnership)
						{
							sId = ConstantsUtil.NO_ACCESS;

						}
					}
					else{
						boolean showData = true;
						//Added by Ganesh Start
						showData = util.checkHasAccess(context, null, sId);
						//Added by Ganesh Stop
								
								if(!showData){
									sId = ConstantsUtil.NO_ACCESS;
									spgChg = ConstantsUtil.NO_ACCESS;
									
								}
					}
					
					//Added by Ketan for Internal Defect -- START
					boolean bHasOwnershipParent = false;
					boolean showDataParent = false;
					if(validator.isNotNullOrEmpty(sParentId)) {
						if(util.isModificatinRequired())
						{
							bHasOwnershipParent = util.checkHasAccess(context, null, sParentId);

							if(!bHasOwnershipParent)
							{
								sParentId = ConstantsUtil.NO_ACCESS;
							}
						}else if(sec.isStaffAUGUser())
						{
							showDataParent = util.checkHasAccess(context, null, sParentId);
						}else
						{	
							showDataParent = util.checkHasAccess(context, null, sParentId);
						}

						if(!util.isModificatinRequired()) {
							if(!showDataParent){
								sParentId = ConstantsUtil.NO_ACCESS;
							}
						}
						
					}
					//Added by Ketan for Internal Defect -- END

				    
					formatData(sbEBOMName, sName);
					formatData(sbEBOMId, sId);
					formatData(sbEBOMChg, spgChg);
					formatData(sbEBOMFN, sFN);
					formatData(sbEBOMTitle, sTitle);
					formatData(sbEBOMType, sType);
					formatData(sbEBOMQTY, sQty);
					formatData(sbEBOMBuom, sBuom);
					formatData(sbEBOMCommnts, sComments);
					formatData(sbEBOMState, sCurrent);
					formatData(sbEBOMStage, sStage);
					formatData(sbEBOMRDOC, sRDOC);
					formatData(sbEBOMRevRelDt, sRevRelease);
					/*if (null != sTupName && !sTupName.isEmpty()) {
						formatData(sbEBOMTupName, sTupName);
					}*/

					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
					util.formatData(sbEBOMSubstitutePart, strSubPart);
					util.formatData(sbEBOMSubPartID, strSubPartId);
					util.formatData(sbEBOMSubPartType, strSubPartType);
					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
					//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- START
					util.formatData(sbEBOMParentId,sParentId);
					util.formatData(sbEBOMParentName,sParentName);
					util.formatData(sbEBOMParentRevision,sParentRevision);
					util.formatData(sbEBOMParentType,sParentType);
					//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- END
					//Added by Subhajit for Req 46464 - Start
					util.formatData(sbRelRestriction, sRelRestriction);
					util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
					//Added by Subhajit for Req 46464 - End
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//formatData(sbEBOMAlternate, sAlternate);
					formatData(sbAltName,strAltName);
					formatData(sbAltID,strAltID);
					formatData(sbAltType,strAltType);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					formatData(sbEBOMOSPD, sOSPD);
					formatData(sbEBOMDensityUOM, sDensityUOM);
					
					formatData(sbGrossWeight, sGrossWeight);
					formatData(sbGrossWeightUOM, sGrossWeightUOM);
				}

			}
			mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
			mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
			mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbTupName.toString());
			mpEBOMResult.put(ConstantsUtil.TUPID, sbTupId.toString());
			mpEBOMResult.put(ConstantsUtil.TUPTYPE, sbTupType.toString());
			mpEBOMResult.put(ConstantsUtilIRM.TUP_REVISION, sbTupRev.toString());//Added by Ajay for req 11877 
			
			
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
			//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- START
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
			mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
			//SPEC: <24.11.2022>: Ketan Added for Req 45642 -- END
			//Added by Subhajit for Req 46464 - Start
			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
			//Added by Subhajit for Req 46464 - End
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlternate.toString());
			mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
			mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
			mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
			mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDensityUOM.toString());
			mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeight.toString());
			mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
		}
		// return filterMapList(mpEBOMResult);
		return mpEBOMResult;
	}
	//SPEC: <31.05.2022>: Guna Modified for Req 41754 22x Release  -- END

	/**
	 * SPEC: <11.18.2020>: Added for Defect:37341 
	 * @param context
	 * @param mlCertifications
	 * @return
	 */

	public Map<String, String> getCerifications(Context context, MapList mlCertifications) {
		Map<String, String> mpCert = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULA_CARD);
		slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
		
		StringList slObjectSelect = new StringList();
		slObjectSelect.addElement(ConstantsUtil.SELECT_NAME);
		slObjectSelect.addElement(ConstantsUtil.SELECT_TYPE);
		slObjectSelect.addElement(ConstantsUtil.SELECT_ID);
		slObjectSelect.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
		slObjectSelect.addElement(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME);
		
		//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- START
		slObjectSelect.addElement(ConstantsUtil.SELECT_CURRENT);
		//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- END
		
		try
		{
			SecurityService sec = new SecurityService();
			String sComp = sec.getUserCauthorities();
			StringList slUserOwnership = util.filterOwnerShip(sComp);
			String sUserlicense = sec.getUserLicense();
			String sUserProjectLicense = sec.getProjectLicenses();
			
			Iterator objectListItr = mlCertifications.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbMarket = new StringBuilder();
			StringBuilder sbClaim = new StringBuilder();
			//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
			StringBuilder sbRegion = new StringBuilder();
			StringBuilder sbArea = new StringBuilder();
			StringBuilder sbGroupTop = new StringBuilder();
			//SPEC: <02.24.2021>: Added for req 18x.6 ## -- END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				
				String sId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID));
				
				String sMarket =validator.getStringEquivalentForStringListWithComma(objectMap.get(SAPBOMConstants.RELATIONSHIP_COUNTRIES_CERTIFIED));
				sMarket=sMarket.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				
				String sClaim =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_NAME));
				sClaim=sClaim.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				
				String sName =ConstantsUtil.EMPTY_STRING;
				String sType =ConstantsUtil.EMPTY_STRING;
				String sObjId =ConstantsUtil.EMPTY_STRING;
				String strIPControlClass =ConstantsUtil.EMPTY_STRING;
				String strProjSecClass =ConstantsUtil.EMPTY_STRING;
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
				String strRegion =ConstantsUtil.EMPTY_STRING;
				String strArea =ConstantsUtil.EMPTY_STRING;
				String strGroup =ConstantsUtil.EMPTY_STRING;
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- END
				
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- START
				String sState =ConstantsUtil.EMPTY_STRING;
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- END
				
				if (UIUtil.isNotNullAndNotEmpty(sId)) 
				{
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME);
					DomainObject domProdId = new DomainObject(sId);
					Map mpTemp = domProdId.getInfo(context, slObjectSelect);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					domProdId.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					
					sName =validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
					sType =validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
					sObjId =validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ID));
				    strIPControlClass = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
				    strProjSecClass = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME));
				    //SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
				    strRegion =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_REGIONMATERIALCERT));
					strArea =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_AREAMATERIALCERT));
					strGroup =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_GROUPTOPMATERIALCERT));
					//SPEC: <02.24.2021>: Added for req 18x.6 ## -- END
					
					//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- START
					sState =validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_CURRENT));
					//SPEC: Release SR18x.6.0.1 - Added by Amman on May 11, 2021 for Req #33248 -- END
					
				    DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME);
				}
				boolean bShowDetails = false;
				boolean bProjectLicense=false;
				String sFormulaPropagate = sObjId;
				if(util.isModificatinRequired())
				{

						//Added by Ganesh 1.0.2 Release Start
					bShowDetails=util.checkHasAccess(context, null, sObjId);
					//Added by Ganesh 1.0.2 Release End
					
					//SPEC: Release SR18x.6.0.1 - Added by Amman on June 04, 2021 for Req #39652 -- START
					if(!bShowDetails) {
						continue;
					}
					if (!ConstantsUtil.RELEASED.equalsIgnoreCase(sState)
							&& !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))) {
						continue;
					}
					//SPEC: Release SR18x.6.0.1 - Added by Amman on June 04, 2021 for Req #39652 -- END
				}
				else if(sec.isStaffAUGUser()) 
				{
					//Added by Ganesh 1.0.2 Release Start
					bShowDetails=util.checkHasAccess(context, null, sObjId);
					//Added by Ganesh 1.0.2 Release End
					
					
				}
				else
				{
										//Added by Ganesh 1.0.2 Release Start
					bShowDetails=util.checkHasAccess(context, null, sObjId);
					//Added by Ganesh 1.0.2 Release End
				}

				if (!bShowDetails) {
					sObjId=ConstantsUtil.NO_ACCESS;
				}	
			
				formatData(sbName,sName);
				formatData(sbId,sObjId);
				formatData(sbType,sType);
				formatData(sbMarket,sMarket);
				formatData(sbClaim,sClaim);
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
				formatData(sbRegion, strRegion);
				formatData(sbArea, strArea);
				formatData(sbGroupTop, strGroup);
				//SPEC: <02.24.2021>: Added for req 18x.6 ## -- END
			}
			
			mpCert.put(ConstantsUtil.PRODUCTPARTNAME,sbName.toString());
			mpCert.put(ConstantsUtil.MARKETS,sbMarket.toString());
			mpCert.put(ConstantsUtil.CERTIFICATIONCLAIM,sbClaim.toString());
			mpCert.put(ConstantsUtil.PRODUCTPARTID, sbId.toString());
			mpCert.put(ConstantsUtil.PRODUCTPARTTYPE, sbType.toString());
			//SPEC: <02.24.2021>: Added for req 18x.6 ## -- START
			mpCert.put(ConstantsUtilIRM.REGION,sbRegion.toString());
			mpCert.put(ConstantsUtil.AREA,sbArea.toString());
			mpCert.put(ConstantsUtil.GROUPTOMARKET,sbGroupTop.toString());
			//SPEC: <02.24.2021>: Added for req 18x.6 ## -- ENDS
			
		} catch (Exception ex) {
			 LOGGER.error("Exception in program FPPBO :getCerifications ");
			return new HashMap();
		}
		return util.filterMapList(mpCert);
	}
	
	
	
	
	
	/** SPEC: <11.20.2020>: Chandra Added for Defect :37531
	 * AVoidng comma
	 * @param resultMaps
	 * @return
	 */
	
	
	public String getDataWithComma(Map resultMaps,String Key)
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbReturn = new StringBuilder();
		String sReturnValue =ConstantsUtil.EMPTY_STRING;
		try {
		if (resultMaps.containsKey((Key))) 
		{
			
			String sClass =resultMaps.get(Key).getClass().getSimpleName();
			
			if (sClass.equals(ConstantsUtil.STRING)) {
				 sReturnValue     =  validator.getStringEquivalentForStringListWithComma(resultMaps.get(Key));
				 formatData(sbReturn, sReturnValue);
			}else
			{
				StringList slSubstituteTitle = validator.isNotNullOrEmpty((StringList) resultMaps.get(Key));
				
				for (int i = 0; i < slSubstituteTitle.size(); i++) 
				{
					sReturnValue =slSubstituteTitle.get(i);
					sReturnValue.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					formatData(sbReturn, sReturnValue);
					
				}
			}
		}
		}catch(Exception e){
			
			LOGGER.error("Exception in Program : FPPBO Method :getTheValueWithComma signature of Map " + e);
			return "";
		}
		return sbReturn.toString();
	}
	
	
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 3, 2021 -- START
	/**
	 * Method Name 			: getBaseCodeDetails
	 * Method Description 	: For getting the Base Code Details of FPP
	 * @param context
	 * @param mlObjectList
	 * @param mpBaseCodeDetails
	 * @param env 
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getBaseCodeDetails(Context context, String sId) throws Exception {
		
		Map<String,String> mpBaseCodeDetails = new HashMap<String,String>();
		
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		StringBuilder sbBaseCodeName = new StringBuilder();
		StringBuilder sbBaseCodeType = new StringBuilder();
		StringBuilder sbBaseCodeId = new StringBuilder();
		StringBuilder sbBaseCodeState = new StringBuilder();
		
		StringBuilder sbBaseCodeIds = new StringBuilder();
		
		CommonBusUtilBO bo = new CommonBusUtilBO();
		
		try
		{
			DomainObject doFPP = new DomainObject(sId);
			
			//SPEC: Release SR18x.6.0 - Modifed by Amman on Mar 16, 2021 for Defect 40803/40805 -- START
			
			MapList mlEBOMList = doFPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
					ConstantsUtil.QUERY_WILDCARD, getBomBusSelect(context), getBomRelSelect(context), false, true, (short) 0,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
			//SPEC: Release SR18x.6.0 - Modifed by Amman on Mar 16, 2021 for Defect 40803/40805 -- END
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doFPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if(mlEBOMList.size()>0) {
				mlEBOMList.addSortKey(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.STRING);//Sorting necessary to populate Packaging Unit Table in order (CUP/COP)
				mlEBOMList.sort();
			}
			
			int i;
			Map<String, String> mp = null;
			for(i=0;i<mlEBOMList.size();i++) 
			{
				mp = (Map<String, String>) mlEBOMList.get(i);
				String sBaseCodeType = mp.get(ConstantsUtil.SELECT_TYPE).toString();

				if (ConstantsUtil.tFPP.contains(sBaseCodeType)) {
					String sBaseCodeId = (String) mp.get(ConstantsUtil.SELECT_ID);
					String sBaseCodeName = (String) mp.get(ConstantsUtil.SELECT_NAME);
					String sBaseCodeState = (String) mp.get(ConstantsUtil.SELECT_CURRENT);

					
					//SPEC: Release SR18x.6.0.1 - Added by Amman on June 23, 2021 for Defect 43811 -- START
					boolean duplicateBCD = sbBaseCodeId.toString().contains(sBaseCodeId);
					
					if(!duplicateBCD) {
					//SPEC: Release SR18x.6.0.1 - Added by Amman on June 23, 2021 for Defect 43811 -- END
					
					formatData(sbBaseCodeName, sBaseCodeName);
					formatData(sbBaseCodeType, sBaseCodeType);
					formatData(sbBaseCodeId, sBaseCodeId);
					formatData(sbBaseCodeState, sBaseCodeState);

					if (!ConstantsUtil.RELEASED.equalsIgnoreCase(sBaseCodeState)
							&& !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sBaseCodeState))) {
						sBaseCodeId = ConstantsUtil.NO_ACCESS;
					}
					if (!busUtil.checkHasAccess(context, null, sBaseCodeId)) {
						sBaseCodeId = ConstantsUtil.NO_ACCESS;
					}
					formatData(sbBaseCodeIds, sBaseCodeId);
					
					//SPEC: Release SR18x.6.0.1 - Added by Amman on June 23, 2021 for Defect 43811 -- START
					}
					//SPEC: Release SR18x.6.0.1 - Added by Amman on June 23, 2021 for Defect 43811 -- END
				 }
			 }
			
			mpBaseCodeDetails.put(ConstantsUtil.NAME, sbBaseCodeName.toString());
			mpBaseCodeDetails.put(ConstantsUtil.ID, sbBaseCodeId.toString());
			mpBaseCodeDetails.put(ConstantsUtil.TYPE, sbBaseCodeType.toString());
			mpBaseCodeDetails.put(ConstantsUtil.STATE, sbBaseCodeState.toString());
			
			mpBaseCodeDetails.put(ConstantsUtil.STRING_OBJECTID, sbBaseCodeIds.toString());
			
		} catch(Exception e){
			LOGGER.error(" Exception in program FPPBO : getBaseCodeDetails : "+e);
			return new HashMap();
		}
		return util.filterMapList(mpBaseCodeDetails);
	}
	
	
	/**
	 * Method Name 			: getSubstituteBaseCodeDetails
	 * Method Description 	: For getting the Substitute Base Code Details of FPP
	 * @param context
	 * @param mapList
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getSubstituteBaseCodeDetails(Context context,String sId, String sName, String sType, String sState) throws Exception 
  	{
      	StringValidatorUtil validator = new StringValidatorUtil();
      	CommonBusUtilBO commonBO = new CommonBusUtilBO();
      	
      	Map mpFinalSubStituteBaseCodeDetails = new TreeMap();
  		Map<String,String> mpCUPSubstituteBaseCodeDetails = new HashMap<String,String>();
  		Map<String,String> mpIPSubstituteBaseCodeDetails = new HashMap<String,String>();
  		Map<String,String> mpCOPSubstituteBaseCodeDetails = new HashMap<String,String>();
  		Map<String,String> mpCUPCOPSubstituteBaseCodeDetails = new HashMap<String,String>();
  		MapList mlFinalSubstitute = new MapList();
  		StringBuilder sbName = new StringBuilder();
  		StringBuilder sbChildName = new StringBuilder();
		StringList slObjID = new StringList();
		StringBuilder sbType = new StringBuilder();
  		StringBuilder sbChildType = new StringBuilder();
  		StringBuilder sbID = new StringBuilder();
  		StringBuilder sbChildID = new StringBuilder();
		
      	try 
      	{	
      		StringList eachBaseCodeID = util.getStringList(sId);
      		StringList eachBaseCodeName = util.getStringList(sName);
      		StringList eachBaseCodeType = util.getStringList(sType);
      		StringList eachBaseCodeState = util.getStringList(sState);
			
			for(int p=0;p<eachBaseCodeID.size();p++) 
			{
				sId=eachBaseCodeID.get(p);
				sName=eachBaseCodeName.get(p);
				sType=eachBaseCodeType.get(p);
				sState=eachBaseCodeState.get(p);
			
	      		DomainObject doFPP = new DomainObject(sId);
				
				MapList mlEBOMList = doFPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
						ConstantsUtil.QUERY_WILDCARD, getBomBusSelect(context), getBomRelSelect(context), false, true, (short) 1,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doFPP.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				mlEBOMList.addSortKey(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.STRING);//Sorting necessary to populate Packaging Unit Table in order (CUP/COP)
				mlEBOMList.sort();
				int i;
				Map<String, String> mp = null;
				for(i=0;i<mlEBOMList.size();i++) 
				{
					mp = (Map<String, String>) mlEBOMList.get(i);
					String type = mp.get(ConstantsUtil.SELECT_TYPE).toString();
					String strOid = mp.get(ConstantsUtil.SELECT_ID);
					
					//CUP-BOM
					if(type.equalsIgnoreCase(ConstantsUtil.TYPE_PGCUSTOMERUNITPART) && !slObjID.contains(strOid))
					{
						slObjID.add(strOid);
						String name = mp.get(ConstantsUtil.SELECT_NAME).toString();
						String Type = mp.get(ConstantsUtil.SELECT_TYPE).toString();
						String ID = mp.get(ConstantsUtil.SELECT_ID).toString();
						String STATE = mp.get(ConstantsUtil.SELECT_CURRENT).toString();
						
						if (!strOid.isEmpty()) 
						{
							//SPEC: Release SR18x.6.0 - Added  by Manikanta for defect 42164 on Date 12/04/2021 -- START
							Iterator objectListItrCUP = mlEBOMList.iterator();
							while (objectListItrCUP.hasNext()) 
							{
								Map objectMap = (Map) objectListItrCUP.next();
								String sChildCUPExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
								if (objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
									mlFinalSubstitute.add(objectMap);
									String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
									if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
					  				{
										util.formatData(sbName, sName);
										util.formatData(sbChildName, ConstantsUtil.EMPTY_STRING);
										util.formatData(sbType, sType);
										
										if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
											sId = ConstantsUtil.NO_ACCESS;
										}
										if (!util.checkHasAccess(context, null, sId)) {
											sId = ConstantsUtil.NO_ACCESS;
										}
										util.formatData(sbID, sId);
										
										util.formatData(sbChildType, ConstantsUtil.EMPTY_STRING);
										util.formatData(sbChildID, ConstantsUtil.EMPTY_STRING);
									}
								}
							}
							//SPEC: Release SR18x.6.0 - Added  by Manikanta for defect 42164 on Date 12/04/2021 -- END
							DomainObject doCup = new DomainObject(strOid);
							//StopWatch swCup = new StopWatch();
							//swCup.start();
							// Get FPP connected CUP Objects
							MapList mlCup = doCup.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, getBomBusSelect(context),
									getBomRelSelect(context), false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							doCup.close(context);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
							//swCup.stop();
							//LOGGER.info("FPP  CUP BOM ELAPSED TIME : "+swCup.getTime());
							if(mlCup.size()!=0)
							{
								mlCup.addSortKey(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.STRING);//Sorting necessary to populate Packaging Unit Table in order (CUP/COP)
								mlCup.sort();
								//mlFinalSubstitute.addAll(mlCup);
								Iterator objectListItr = mlCup.iterator();
								while (objectListItr.hasNext()) 
								{
									Map objectMap = (Map) objectListItr.next();
									String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
									if (objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
										mlFinalSubstitute.add(objectMap);
										String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
										if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
						  				{
											util.formatData(sbName, sName);
											util.formatData(sbChildName, name);
											util.formatData(sbType, sType);
											
											if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
												sId = ConstantsUtil.NO_ACCESS;
											}
											if (!util.checkHasAccess(context, null, sId)) {
												sId = ConstantsUtil.NO_ACCESS;
											}
											util.formatData(sbID, sId);
											
											util.formatData(sbChildType, Type);
											
											if(!ConstantsUtil.RELEASED.equalsIgnoreCase(STATE) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(STATE))){
												ID = ConstantsUtil.NO_ACCESS;
											}
											
											
											if (!util.checkHasAccess(context, null, ID)) {
												ID = ConstantsUtil.NO_ACCESS;
											}
											util.formatData(sbChildID, ID);
										}
										else 
										{
											if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						  						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						  						for(int m =0; m<slChildId.size(); m++) 
						  						{
						  							util.formatData(sbName, sName);
													util.formatData(sbChildName, name);
													util.formatData(sbType, sType);
													
													if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
														sId = ConstantsUtil.NO_ACCESS;
													}
													if (!util.checkHasAccess(context, null, sId)) {
														sId = ConstantsUtil.NO_ACCESS;
													}
													util.formatData(sbID, sId);
													
													util.formatData(sbChildType, Type);
													
													if(!ConstantsUtil.RELEASED.equalsIgnoreCase(STATE) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(STATE))){
														ID = ConstantsUtil.NO_ACCESS;
													}
													if (!util.checkHasAccess(context, null, ID)) {
														ID = ConstantsUtil.NO_ACCESS;
													}
													util.formatData(sbChildID, ID);
												}
											}
										}		
									}
									String sIpType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);

									//For getting the IP BOM and Substitute
									if (sIpType.equalsIgnoreCase(ConstantsUtil.TYPE_PGINNERPACKUNITPART)
											|| sIpType.equalsIgnoreCase(ConstantsUtil.INNERPACKUNITPAT)) 
									{
										String sIpId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
										String sIPname = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
										String sIPtype = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
										String sIPstate = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
										
										if (!sIpId.isEmpty()) {
											DomainObject doIp = new DomainObject(sIpId);
											//StopWatch swIp = new StopWatch();
											//swIp.start();
											MapList mlIp = doIp.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, getBomBusSelect(context),
													getBomRelSelect(context), false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
											//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
											doIp.close(context);
											//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
											//swIp.stop();
											//LOGGER.info("FPP  IPBOM ELAPSED TIME : "+swIp.getTime());
											
											if(mlIp.size()!=0){
												//Get IP BOM
												mlIp.addSortKey(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.STRING);//Sorting necessary to populate Packaging Unit Table in order (CUP/COP)
												mlIp.sort();
												//mlFinalSubstitute.addAll(mlIp);
												Iterator objectList = mlIp.iterator();
												while (objectList.hasNext()) 
												{
													Map objectMaps = (Map) objectList.next();
													sChildExists=validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.SELECT_SUBSTITUTE));
													if (objectMaps.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
														mlFinalSubstitute.add(objectMaps);
														String sClassName = objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
														if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
										  				{
															util.formatData(sbName, sName);
															util.formatData(sbChildName, sIPname);
															util.formatData(sbType, sType);
															
															if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
																sId = ConstantsUtil.NO_ACCESS;
															}
															if (!util.checkHasAccess(context, null, sId)) {
																sId = ConstantsUtil.NO_ACCESS;
															}
															util.formatData(sbID, sId);
															
															util.formatData(sbChildType, sIPtype);
															
															if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sIPstate) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sIPstate))){
																sIpId = ConstantsUtil.NO_ACCESS;
															}
															if (!util.checkHasAccess(context, null, sIpId)) {
																sIpId = ConstantsUtil.NO_ACCESS;
															}
															util.formatData(sbChildID, sIpId);
														}
														else 
														{
															if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
										  						StringList slChildId = (StringList)objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
										  						for(int m =0; m<slChildId.size(); m++) 
										  						{
										  							util.formatData(sbName, sName);
																	util.formatData(sbChildName, sIPname);
																	util.formatData(sbType, sType);
																	
																	if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
																		sId = ConstantsUtil.NO_ACCESS;
																	}
																	if (!util.checkHasAccess(context, null, sId)) {
																		sId = ConstantsUtil.NO_ACCESS;
																	}
																	util.formatData(sbID, sId);
																	
																	util.formatData(sbChildType, sIPtype);
																	
																	if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sIPstate) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sIPstate))){
																		sIpId = ConstantsUtil.NO_ACCESS;
																	}
																	if (!util.checkHasAccess(context, null, sIpId)) {
																		sIpId = ConstantsUtil.NO_ACCESS;
																	}
																	util.formatData(sbChildID, sIpId);
																}
															}
														}		
													}
												}
											}
											
											//COP under IP
											Iterator objectIpItr = mlIp.iterator();
											while (objectIpItr.hasNext()) {
												Map mpIpToCop = (Map) objectIpItr.next();
												String sCopType = (String) mpIpToCop.get(ConstantsUtil.SELECT_TYPE);
												if(sCopType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNITPART) || sCopType.equalsIgnoreCase(ConstantsUtil.TYPE_CUSTOMERUNITPART)) {
													String sCopId = (String) mpIpToCop.get(ConstantsUtil.SELECT_ID);
													if (!strOid.isEmpty()) {
														DomainObject doCop = new DomainObject(sCopId);
														String sCOPname = (String) mpIpToCop.get(ConstantsUtil.SELECT_NAME);
														String sCOPtype = (String) mpIpToCop.get(DomainConstants.SELECT_TYPE);
														String sCOPid = (String) mpIpToCop.get(DomainConstants.SELECT_ID);
														String sCOPstate = (String) mpIpToCop.get(ConstantsUtil.SELECT_CURRENT);
														
														//StopWatch swCOPBom = new StopWatch();
														//swCOPBom.start();
														MapList mlCop = doCop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, getBomBusSelect(context),
																getBomRelSelect(context), false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
														//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
														doCop.close(context);
														//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END													
														//swCOPBom.stop();
														//LOGGER.info("FPP GET COPBOM ELAPSED TIME : "+swCOPBom.getTime());
														
														if(mlCop.size()!=0){
															mlCop.addSortKey(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.STRING);//Sorting necessary to populate Packaging Unit Table in order (CUP/COP)
															mlCop.sort();
															//mlFinalSubstitute.addAll(mlCop);
															Iterator objectList = mlCop.iterator();
															while (objectList.hasNext()) 
															{
																Map objectMaps = (Map) objectList.next();
																sChildExists=validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.SELECT_SUBSTITUTE));
																if (objectMaps.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
																	mlFinalSubstitute.add(objectMaps);
																	String sClassName = objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
																	if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
													  				{
																		util.formatData(sbName, sName);
																		util.formatData(sbChildName, sCOPname);
																		util.formatData(sbType, sType);
																		
																		if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
																			sId = ConstantsUtil.NO_ACCESS;
																		}
																		if (!util.checkHasAccess(context, null, sId)) {
																			sId = ConstantsUtil.NO_ACCESS;
																		}
																		util.formatData(sbID, sId);
																		
																		util.formatData(sbChildType, sCOPtype);
																		
																		if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sCOPstate) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sCOPstate))){
																			sCOPid = ConstantsUtil.NO_ACCESS;
																		}
																		if (!util.checkHasAccess(context, null, sCOPid)) {
																			sCOPid = ConstantsUtil.NO_ACCESS;
																		}
																		util.formatData(sbChildID, sCOPid);
																	}
																	else 
																	{
																		if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
													  						StringList slChildId = (StringList)objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
													  						for(int m =0; m<slChildId.size(); m++) 
													  						{
													  							util.formatData(sbName, sName);
																				util.formatData(sbChildName, sCOPname);
																				util.formatData(sbType, sType);
																				
																				if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
																					sId = ConstantsUtil.NO_ACCESS;
																				}
																				if (!util.checkHasAccess(context, null, sId)) {
																					sId = ConstantsUtil.NO_ACCESS;
																				}
																				util.formatData(sbID, sId);
																				
																				util.formatData(sbChildType, sCOPtype);
																				
																				if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sCOPstate) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sCOPstate))){
																					sCOPid = ConstantsUtil.NO_ACCESS;
																				}
																				if (!util.checkHasAccess(context, null, sCOPid)) {
																					sCOPid = ConstantsUtil.NO_ACCESS;
																				}
																				util.formatData(sbChildID, sCOPid);
																			}
																		}
																	}		
																}
															}
														}
													}
												}
											}
										}
									} else if (sIpType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNITPART)
											|| sIpType.equalsIgnoreCase(ConstantsUtil.TYPE_CUSTOMERUNITPART)) {
		
										//COP Under Direct CUP
										Iterator objectIpItr = mlCup.iterator();
										while (objectIpItr.hasNext()) {
											Map mpIpToCop = (Map) objectIpItr.next();
											String sCopType = (String) mpIpToCop.get(ConstantsUtil.SELECT_TYPE);
											if(sCopType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNITPART) || sCopType.equalsIgnoreCase(ConstantsUtil.TYPE_CUSTOMERUNITPART)) {
												String sCopId = (String) mpIpToCop.get(ConstantsUtil.SELECT_ID);
												String sCopname = (String) mpIpToCop.get(ConstantsUtil.SELECT_NAME);
												String sCoptype = (String) mpIpToCop.get(ConstantsUtil.SELECT_TYPE);
												String sCopstate = (String) mpIpToCop.get(ConstantsUtil.SELECT_CURRENT);
												
												if (!strOid.isEmpty()) {
													DomainObject doCop = new DomainObject(sCopId);
													
													//StopWatch swCOPBom = new StopWatch();
													//swCOPBom.start();
													MapList mlCop = doCop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, getBomBusSelect(context),
															getBomRelSelect(context), false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
													//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
													doCop.close(context);
													//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END													
													//swCOPBom.stop();
													//LOGGER.info("FPP GET COPBOM ELAPSED TIME : "+swCOPBom.getTime());
													
													if(mlCop.size()!=0)
													{
														//Get COP Substitute
														mlCop.addSortKey(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.STRING);//Sorting necessary to populate Packaging Unit Table in order (CUP/COP)
														mlCop.sort();
														//mlFinalSubstitute.addAll(mlCop);
														Iterator objectList = mlCop.iterator();
														while (objectList.hasNext()) 
														{
															Map objectMaps = (Map) objectList.next();
															sChildExists=validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.SELECT_SUBSTITUTE));
															if (objectMaps.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
																mlFinalSubstitute.add(objectMaps);
																String sClassName = objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
																if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
												  				{
																	util.formatData(sbName, sName);
																	util.formatData(sbChildName, sCopname);
																	util.formatData(sbType, sType);
																	
																	if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
																		sId = ConstantsUtil.NO_ACCESS;
																	}
																	if (!util.checkHasAccess(context, null, sId)) {
																		sId = ConstantsUtil.NO_ACCESS;
																	}
																	util.formatData(sbID, sId);
																	util.formatData(sbChildType, sCoptype);
																	
																	if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sCopstate) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sCopstate))){
																		sCopId = ConstantsUtil.NO_ACCESS;
																	}
																	if (!util.checkHasAccess(context, null, sCopId)) {
																		sCopId = ConstantsUtil.NO_ACCESS;
																	}
																	util.formatData(sbChildID, sCopId);
																}
																else 
																{
																	if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
												  						StringList slChildId = (StringList)objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
												  						for(int m =0; m<slChildId.size(); m++) 
												  						{
												  							util.formatData(sbName, sName);
																			util.formatData(sbChildName, sCopname);
																			util.formatData(sbType, sType);
																			
																			if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
																				sId = ConstantsUtil.NO_ACCESS;
																			}
																			if (!util.checkHasAccess(context, null, sId)) {
																				sId = ConstantsUtil.NO_ACCESS;
																			}
																			util.formatData(sbID, sId);
																			
																			util.formatData(sbChildType, sCoptype);
																			
																			if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sCopstate) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sCopstate))){
																				sCopId = ConstantsUtil.NO_ACCESS;
																			}
																			if (!util.checkHasAccess(context, null, sCopId)) {
																				sCopId = ConstantsUtil.NO_ACCESS;
																			}
																			util.formatData(sbChildID, sCopId);
																		}
																	}
																}	
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			if(mlFinalSubstitute.size()>0) {
				mpFinalSubStituteBaseCodeDetails =  commonBO.parseSubstitute(context,mlFinalSubstitute);
				mpFinalSubStituteBaseCodeDetails.put(ConstantsUtil.BASECODE, sbName.toString());
				mpFinalSubStituteBaseCodeDetails.put(ConstantsUtil.CHILDNAME, sbChildName.toString());
				mpFinalSubStituteBaseCodeDetails.put(ConstantsUtilIRM.BASECODETYPE, sbType.toString());
				mpFinalSubStituteBaseCodeDetails.put(ConstantsUtilIRM.BASECODEID, sbID.toString());
				mpFinalSubStituteBaseCodeDetails.put(ConstantsUtilIRM.CHILDNAMETYPE, sbChildType.toString());
				mpFinalSubStituteBaseCodeDetails.put(ConstantsUtilIRM.CHILDNAMEID, sbChildID.toString());
			}
      	}catch(Exception e){
      		LOGGER.error("Exception in program FPPBO : getSubstituteBaseCodeDetails : "+e);
      		return new HashMap();
		}
      	return util.filterMapList(mpFinalSubStituteBaseCodeDetails);
  	}
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 3, 2021 -- END
	
	
	//SPEC: <02.24.2021>: Added for req 18x.6 by Sumit ## -- START
	/**
	 * Method Name : getSmartLabelRollUp Method Description : For getting the
	 * Smart Label
	 * 
	 * @param context
	 * @param DomainObject
	 * @return Map
	 * @throws Exception
	 */
	public Map getSmartLabelRollUp(Context context, DomainObject doFPP) {

		Map mpSmartLabel = new HashMap();
		try {

			StringBuilder sbPPartType = new StringBuilder();
			StringBuilder sbPPartID = new StringBuilder();
			StringBuilder sbPPartName = new StringBuilder();
			StringBuilder sbSmartLabel = new StringBuilder();
			StringBuilder sbSmartLabelType = new StringBuilder();
			StringBuilder sbSmartLabelID = new StringBuilder();
			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			StringValidatorUtil validator = new StringValidatorUtil();
			
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.SELECT_NAME);
			busSelect.add(ConstantsUtil.SELECT_ID);
			busSelect.add(ConstantsUtil.SELECT_TYPE);
			busSelect.add(ConstantsUtil.SELECT_CURRENT);

			StringList relSelect = new StringList();
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
			String strWhere ="current=="+ConstantsUtilIRM.STATE_COMPLETE;
			
			MapList mapList = doFPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGROLLEDUPSMARTLABEL,
					ConstantsUtil.TYPE_PGSMARTLABEL, busSelect, relSelect, false, true, (short) 1,
					strWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			Iterator objectListItr = mapList.iterator();
			DomainObject domProductPart = DomainObject.newInstance(context);
			while (objectListItr.hasNext()) {
				Map mpTemp = (Map) objectListItr.next();
				String sSmartLabel = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_NAME)));
				String sSmartLabelType = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_TYPE)));
				String sSmartLabelID = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_ID)));
				
				String sISPhysicalProduct = validator.getStringEquivalentForStringListWithComma(
						(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID)));

				if (UIUtil.isNotNullAndNotEmpty(sISPhysicalProduct)) {
					domProductPart.setId(sISPhysicalProduct);
					Map mProddata = domProductPart.getInfo(context, busSelect);
					String strProdPartType = validator
							.getStringEquivalentForStringList((String) mProddata.get(ConstantsUtil.SELECT_TYPE));
					String strProdPartName = validator
							.getStringEquivalentForStringList((String) mProddata.get(ConstantsUtil.SELECT_NAME));
					String strProdPartState = validator
							.getStringEquivalentForStringList((String) mProddata.get(ConstantsUtil.SELECT_CURRENT));
					String strProdPartID = validator
							.getStringEquivalentForStringList((String) mProddata.get(ConstantsUtil.SELECT_ID));

					
					if (!util.checkHasAccess(context, null, strProdPartID)) {
						strProdPartID = ConstantsUtil.NO_ACCESS;
					}
					
					if(!ConstantsUtil.RELEASED.equalsIgnoreCase(strProdPartState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strProdPartState))){
						strProdPartID = ConstantsUtil.NO_ACCESS;
					}
					busUtil.formatData(sbPPartID, strProdPartID);
					busUtil.formatData(sbPPartName, strProdPartName);
					busUtil.formatData(sbPPartType, strProdPartType);
					busUtil.formatData(sbSmartLabel, sSmartLabel);
					//SPEC: Release SR18x.6.0 - Added for Defect# 42611  by gaikwad.tg on Date 21 April 2021 -- START
					busUtil.formatData(sbSmartLabelType, sSmartLabelType);
					busUtil.formatData(sbSmartLabelID, sSmartLabelID);
					//SPEC: Release SR18x.6.0 - Added for Defect# 42611  by gaikwad.tg on Date 21 April 2021 -- END
				}
			}
			mpSmartLabel.put(ConstantsUtil.PRODUCTPARTNAME, sbPPartName.toString());
			mpSmartLabel.put(ConstantsUtil.ID, sbPPartID.toString());
			mpSmartLabel.put(ConstantsUtil.PRODUCTPARTTYPE, sbPPartType.toString());
			mpSmartLabel.put(ConstantsUtil.SMARTLABEL, sbSmartLabel.toString());
			mpSmartLabel.put(ConstantsUtilIRM.SMARTLABELTYPE, sbSmartLabelType.toString());
			mpSmartLabel.put(ConstantsUtilIRM.SMARTLABELID, sbSmartLabelID.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : FinishedProductPartBO Method :getSmartLabelRollUp " + e);
			return new HashMap();
		}
		return mpSmartLabel;
	}

	
	/**
	 * Method Name : getRelatedIngredient Method Description : For getting the
	 * Ingredient Statement
	 * 
	 * @param context
	 * @param DomainObject
	 * @return Map
	 * @throws Exception
	 */
	public Map getRelatedIngredient(Context context, DomainObject doFPP) {

		Map mpRelatedIS = new HashMap();
		try {

			StringBuilder sbPPartType = new StringBuilder();
			StringBuilder sbPPartID = new StringBuilder();
			StringBuilder sbPPartName = new StringBuilder();
			StringBuilder sbPPartRev = new StringBuilder();
			StringBuilder sbPPartTitle = new StringBuilder();
			StringBuilder sbISType = new StringBuilder();
			StringBuilder sbISName = new StringBuilder();
			StringBuilder sbISID = new StringBuilder();
			StringBuilder sbISMarket = new StringBuilder();
			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			StringValidatorUtil validator = new StringValidatorUtil();

			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.SELECT_NAME);
			busSelect.add(ConstantsUtil.SELECT_ID);
			busSelect.add(ConstantsUtil.SELECT_TYPE);
			busSelect.add(ConstantsUtil.SELECT_CURRENT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			busSelect.add(ConstantsUtilIRM.STR_RELATIONSHIP_COPYLISTCOUNTRY_NAME);
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 3, 2021 -- START
			busSelect.add(ConstantsUtil.SELECT_REVISION);
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 3, 2021 -- END
			
			StringList relSelect = new StringList();
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);

			MapList mapList = doFPP.getRelatedObjects(context, ConstantsUtilIRM.RELATIONSHIP_PFINGREDIENTSTATEMENT,
					ConstantsUtil.TYPE_COPYLIST, busSelect, relSelect, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			Iterator objectListItr = mapList.iterator();
			DomainObject domProductPart = DomainObject.newInstance(context);
			while (objectListItr.hasNext()) {
				Map mpTemp = (Map) objectListItr.next();
				String sISName = validator.getStringEquivalentForStringListWithComma((mpTemp.get(ConstantsUtil.SELECT_NAME)));
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- START
				String sISType = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_TYPE)));
				String sISID = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_ID)));
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- END
				
				//SPEC: Release SR18x.6.0 - Added by Jwala on Mar 4, 2021 -- START
				String strCLCurrent = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_CURRENT)));
				//SPEC: Release SR18x.6.0 - Added by Jwala on Mar 4, 2021 -- END
				
				String sISMarket = validator
						.getStringEquivalentForStringListWithComma((mpTemp.get(ConstantsUtilIRM.STR_RELATIONSHIP_COPYLISTCOUNTRY_NAME)));
				String sISPhysicalProduct = validator.getStringEquivalentForStringListWithComma(
						(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID)));

				if (UIUtil.isNotNullAndNotEmpty(sISPhysicalProduct)) {
					domProductPart.setId(sISPhysicalProduct);
					Map mProddata = domProductPart.getInfo(context, busSelect);
					String strProdPartType = validator
							.getStringEquivalentForStringList((String) mProddata.get(ConstantsUtil.SELECT_TYPE));
					String strProdPartName = validator
							.getStringEquivalentForStringList((String) mProddata.get(ConstantsUtil.SELECT_NAME));
					String strProdPartRev = validator
							.getStringEquivalentForStringList((String) mProddata.get(ConstantsUtil.SELECT_REVISION));
					String strProdPartState = validator
							.getStringEquivalentForStringList((String) mProddata.get(ConstantsUtil.SELECT_CURRENT));
					String strProdPartID = validator
							.getStringEquivalentForStringList((String) mProddata.get(ConstantsUtil.SELECT_ID));
					String strProdPartTitle = validator.getStringEquivalentForStringList(
							(String) mProddata.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

					if (!util.checkHasAccess(context, null, strProdPartID)) {
						strProdPartID = ConstantsUtil.NO_ACCESS;
						//SPEC: Release SR18x.6.0 - Added by Jwala for defect #41625 -- START
						strProdPartTitle = ConstantsUtil.NO_ACCESS;
						//SPEC: Release SR18x.6.0 - Added by Jwala for defect #41625 -- END
					}
					
					if(!ConstantsUtil.RELEASED.equalsIgnoreCase(strProdPartState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strProdPartState))){
						strProdPartID = ConstantsUtil.NO_ACCESS;
					}
					//SPEC: Release SR18x.6.0 - Added by Jwala for defect #41625 -- START
					if(!ConstantsUtil.RELEASED.equalsIgnoreCase(strCLCurrent) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strCLCurrent))){
						sISID = ConstantsUtil.NO_ACCESS;
					}
					//SPEC: Release SR18x.6.0 - Added by Jwala for defect #41625 -- END
					busUtil.formatData(sbPPartID, strProdPartID);
					busUtil.formatData(sbPPartName, strProdPartName);
					busUtil.formatData(sbPPartType, strProdPartType);
					busUtil.formatData(sbPPartRev, strProdPartRev);
					busUtil.formatData(sbPPartTitle, strProdPartTitle);
					busUtil.formatData(sbISName, sISName);
					busUtil.formatData(sbISMarket, sISMarket);
					
					//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- START
					busUtil.formatData(sbISType, sISType);
					busUtil.formatData(sbISID, sISID);
					//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- END
					
				}
			}
			mpRelatedIS.put(ConstantsUtil.PRODUCTPARTNAME, sbPPartName.toString());
			mpRelatedIS.put(ConstantsUtil.ID, sbPPartID.toString());
			mpRelatedIS.put(ConstantsUtil.PRODUCTPARTTYPE, sbPPartType.toString());
			mpRelatedIS.put(ConstantsUtil.PRODUCTPARTREVISION, sbPPartRev.toString());
			mpRelatedIS.put(ConstantsUtil.PRODUCTPARTTITLE, sbPPartTitle.toString());
			mpRelatedIS.put(ConstantsUtil.MARKETS, sbISMarket.toString());
			mpRelatedIS.put(ConstantsUtilIRM.INGREDIENTSTMTNAME, sbISName.toString());
			
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- START
			mpRelatedIS.put(ConstantsUtilIRM.INGREDIENTSTMTTYPE, sbISType.toString());
			mpRelatedIS.put(ConstantsUtilIRM.INGREDIENTSTMTID, sbISID.toString());
			//SPEC: Release SR18x.6.0 - Added by Amman on Mar 4, 2021 -- END
		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : FinishedProductPartBO Method :getRelatedIngredient " + e);
			return new HashMap();
		}
		return mpRelatedIS;
	}
	
	
	/**
	 * Method Name : getBatteryRollUp Method Description : For getting the Battery
	 * Details
	 * 
	 * @param context
	 * @param DomainObject
	 * @return Map
	 * @throws Exception
	 */
	public Map getBatteryRollUp(Context context, DomainObject doFPP) {
		Map mpBatteryRU = new HashMap();
		try {

			StringBuilder sbBatteryRUID = new StringBuilder();
			StringBuilder sbBatteryRUType = new StringBuilder();
			StringBuilder sbBatteryRUName = new StringBuilder();
			StringBuilder sbBatteryRURev = new StringBuilder();
			StringBuilder sbBatteryRUTitle = new StringBuilder();
			StringBuilder sbBatteryRUNW = new StringBuilder();
			StringBuilder sbBatteryRUGWUOM = new StringBuilder();
			StringBuilder sbBatteryRUPS = new StringBuilder();
			StringBuilder sbBatteryRUBT = new StringBuilder();
			StringBuilder sbBatteryRUBSID = new StringBuilder();
			StringBuilder sbBatteryRUNOBR = new StringBuilder();
			StringBuilder sbBatteryRUDPPQTY = new StringBuilder();
			StringBuilder sbBatteryRUBSOD = new StringBuilder();
			StringBuilder sbBatteryRUBCC = new StringBuilder();
			StringBuilder sbBatteryRUBUM = new StringBuilder();
			StringBuilder sbBatteryRUBS = new StringBuilder();
			StringBuilder sbBatteryRUNBV = new StringBuilder();
			StringBuilder sbBatteryRUBBVU = new StringBuilder();
			StringBuilder sbBatteryRUTC = new StringBuilder();
			StringBuilder sbBatteryRUTCU = new StringBuilder();
			StringBuilder sbBatteryRUNOC = new StringBuilder();
			StringBuilder sbBatteryRUGOLPC = new StringBuilder();
			StringBuilder sbBatteryRUGOLU = new StringBuilder();
			StringBuilder sbBatteryRUITBB = new StringBuilder();
			StringBuilder sbBatteryRULBE = new StringBuilder();
			//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- START
			StringBuilder sbBatteryNBW = new StringBuilder();
			StringBuilder sbBatteryLBEU = new StringBuilder();
			//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- END
			StringBuilder sbBatteryPTC = new StringBuilder();
			StringBuilder sbBatteryTypeNum = new StringBuilder();
			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			StringValidatorUtil validator = new StringValidatorUtil();
			
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.SELECT_TYPE);
			busSelect.add(ConstantsUtil.SELECT_NAME);
			busSelect.add(ConstantsUtil.SELECT_ID);
			busSelect.add(ConstantsUtil.SELECT_CURRENT);
			busSelect.add(ConstantsUtil.SELECT_REVISION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_NUMBEROFBATTERIESREQUIRED);
			//Added By Ajay for the Req 15195 : START
			//Added By Ajay for the Defect 21654 : START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PTC);
			//Added By Ajay for the Defect 21654 : END
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTYPENUMBER);
			//Added By Ajay for the Req 15195 : END
			
			StringList relSelect = new StringList();
			relSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDPPQTYPERCOP);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDOUTSIDEDEVICE);
			
			MapList mapList = doFPP.getRelatedObjects(context, ConstantsUtilIRM.RELATIONSHIP_PGROLLEDUPBATTERY,
					ConstantsUtil.TYPE_DEVICEPRODUCTPART+","+ConstantsUtil.TYPE_PGRAWMATERIAL+","+ConstantsUtil.TYPE_RAWMATERIALPART, busSelect, relSelect, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			Iterator objectListItr = mapList.iterator();
			DomainObject domProductPart = DomainObject.newInstance(context);
			while (objectListItr.hasNext()) {
				Map mpTemp = (Map) objectListItr.next();
				String sBatteryRUID = validator
						.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ID));
				String sBatteryRUType = validator
						.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
				String sBatteryRUName = validator
						.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
				String sBatteryRURev = validator
						.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
				String sState = validator
						.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_CURRENT));
				String sBatteryRUTitle = validator
						.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sBatteryRUNW = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT));
				String sBatteryRUGWUOM = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
				String sBatteryRUPS = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE));
				String sBatteryRUBT = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE));
				String sBatteryRUBSID = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE));
				String sBatteryRUNOBR = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_NUMBEROFBATTERIESREQUIRED));
				String sBatteryRUDPPQTY = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDPPQTYPERCOP));
				String sBatteryRUBSOD = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDOUTSIDEDEVICE));
				//Added By Ajay for the Req 15195 : START
				//Added By Ajay for the Defect 21654 : START
				String sBatteryPTC = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PTC)).replace(ConstantsUtil.SYMBL_PIPE,ConstantsUtil.SYMBL_COMMA);
				//Added By Ajay for the Defect 21654 : END
				String sBatteryTypeNum = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTYPENUMBER));
				//Added By Ajay for the Req 15195 : END
				if (ConstantsUtil.TYPE_PGRAWMATERIAL.equalsIgnoreCase(sBatteryRUType)
						|| ConstantsUtil.TYPE_RAWMATERIALPART.equalsIgnoreCase(sBatteryRUType)) {
					sBatteryRUPS = "Battery";
				}
				
				if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sState))){
					sBatteryRUID = ConstantsUtil.NO_ACCESS;
				}
				
				String sBatteryRUBCC = validator.getStringEquivalentForStringList(getBatteryTypeFields(context,
						sBatteryRUBT, "pgPLIBatteryChemistry", ConstantsUtil.EMPTY_STRING));
				String sBatteryRUBUM = validator.getStringEquivalentForStringList(getBatteryTypeFields(context,
						sBatteryRUBT, ConstantsUtil.EMPTY_STRING, "pgPLBatteryWeightUOM"));
				String sBatteryRUBS = validator.getStringEquivalentForStringList(
						getBatteryTypeFields(context, sBatteryRUBT, "pgPLIBatterySize", ConstantsUtil.EMPTY_STRING));
				String sBatteryRUNBV = validator.getStringEquivalentForStringList(
						getBatteryTypeFields(context, sBatteryRUBT, ConstantsUtil.EMPTY_STRING, "pgPLIBatteryVoltage"));
				String sBatteryRUBBVU = validator.getStringEquivalentForStringList(
						getBatteryTypeFields(context, sBatteryRUBT, ConstantsUtil.EMPTY_STRING, "pgPLBatteryVolUOM"));
				String sBatteryRUTC = validator.getStringEquivalentForStringList(getBatteryTypeFields(context,
						sBatteryRUBT, ConstantsUtil.EMPTY_STRING, "pgPLIBatteryCapacity"));
				String sBatteryRUTCU = validator.getStringEquivalentForStringList(
						getBatteryTypeFields(context, sBatteryRUBT, ConstantsUtil.EMPTY_STRING, "pgPLBatteryTCUOM"));
				String sBatteryRUNOC = validator.getStringEquivalentForStringList(
						getBatteryTypeFields(context, sBatteryRUBT, ConstantsUtil.EMPTY_STRING, "pgPLIBatteryCells"));
				String sBatteryRUGOLPC = validator.getStringEquivalentForStringList(
						getBatteryTypeFields(context, sBatteryRUBT, ConstantsUtil.EMPTY_STRING, "pgPLIBatteryLithum"));
				String sBatteryRUGOLU = validator.getStringEquivalentForStringList(getBatteryTypeFields(context,
						sBatteryRUBT, ConstantsUtil.EMPTY_STRING, "pgPLBatteryWeightLiUOM"));
				String sBatteryRUITBB = validator.getStringEquivalentForStringList(
						getBatteryTypeFields(context, sBatteryRUBT, "pgPLIYesNo", ConstantsUtil.EMPTY_STRING));
				String sBatteryRULBE = validator.getStringEquivalentForStringList(getBatteryTypeFields(context,
						sBatteryRUBT, ConstantsUtil.EMPTY_STRING, "pgPLIBatteryWhRating"));
				//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- START
				String sBatteryNBW = validator.getStringEquivalentForStringList(getBatteryTypeFields(context,
						sBatteryRUBT, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ATTRIBUTE_PGPLBATTERYWEIGHT));
				String sBatteryLBEU = validator.getStringEquivalentForStringList(getBatteryTypeFields(context,
						sBatteryRUBT, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ATTRIBUTE_PGPLBATTERYENRUOM));
				//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- END
				
				
				if (!busUtil.checkHasAccess(context, null, sBatteryRUID)) {
					sBatteryRUID = ConstantsUtil.NO_ACCESS;
					sBatteryRUTitle = ConstantsUtil.NO_ACCESS;
					
				}
				busUtil.formatData(sbBatteryRUID, sBatteryRUID);
				busUtil.formatData(sbBatteryRUType, sBatteryRUType);
				busUtil.formatData(sbBatteryRUName, sBatteryRUName);
				busUtil.formatData(sbBatteryRURev, sBatteryRURev);
				busUtil.formatData(sbBatteryRUTitle, sBatteryRUTitle);
				busUtil.formatData(sbBatteryRUNW, sBatteryRUNW);
				busUtil.formatData(sbBatteryRUGWUOM, sBatteryRUGWUOM);
				busUtil.formatData(sbBatteryRUPS, sBatteryRUPS);
				busUtil.formatData(sbBatteryRUBT, sBatteryRUBT);
				busUtil.formatData(sbBatteryRUBSID, sBatteryRUBSID);
				busUtil.formatData(sbBatteryRUNOBR, sBatteryRUNOBR);
				busUtil.formatData(sbBatteryRUDPPQTY, sBatteryRUDPPQTY);
				busUtil.formatData(sbBatteryRUBSOD, sBatteryRUBSOD);
				busUtil.formatData(sbBatteryRUBCC, sBatteryRUBCC);
				busUtil.formatData(sbBatteryRUBUM, sBatteryRUBUM);
				busUtil.formatData(sbBatteryRUBS, sBatteryRUBS);
				busUtil.formatData(sbBatteryRUNBV, sBatteryRUNBV);
				busUtil.formatData(sbBatteryRUBBVU, sBatteryRUBBVU);
				busUtil.formatData(sbBatteryRUTC, sBatteryRUTC);
				busUtil.formatData(sbBatteryRUTCU, sBatteryRUTCU);
				busUtil.formatData(sbBatteryRUNOC, sBatteryRUNOC);
				busUtil.formatData(sbBatteryRUGOLPC, sBatteryRUGOLPC);
				busUtil.formatData(sbBatteryRUGOLU, sBatteryRUGOLU);
				busUtil.formatData(sbBatteryRUITBB, sBatteryRUITBB);
				busUtil.formatData(sbBatteryRULBE, sBatteryRULBE);
				//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- START
				busUtil.formatData(sbBatteryNBW, sBatteryNBW);
				busUtil.formatData(sbBatteryLBEU, sBatteryLBEU);
				//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- END
				//Added By Ajay for the Req 15195 : START
				busUtil.formatData(sbBatteryPTC, sBatteryPTC);
				busUtil.formatData(sbBatteryTypeNum, sBatteryTypeNum);
				//Added By Ajay for the Req 15195 : END
			}
			mpBatteryRU.put(ConstantsUtil.ID, sbBatteryRUID.toString());
			mpBatteryRU.put(ConstantsUtil.TYPE, sbBatteryRUType.toString());
			mpBatteryRU.put(ConstantsUtil.NAME, sbBatteryRUName.toString());
			mpBatteryRU.put(ConstantsUtil.REVISION, sbBatteryRURev.toString());
			mpBatteryRU.put(ConstantsUtil.TITLE, sbBatteryRUTitle.toString());
			mpBatteryRU.put(ConstantsUtil.NETWEIGHT, sbBatteryRUNW.toString());
			mpBatteryRU.put(ConstantsUtil.NETWEIGHTUOM, sbBatteryRUGWUOM.toString());
			mpBatteryRU.put(ConstantsUtil.POWERSOURCE, sbBatteryRUPS.toString());
			mpBatteryRU.put(ConstantsUtil.BATTERYTYPE, sbBatteryRUBT.toString());
			mpBatteryRU.put(ConstantsUtil.NUMBEROFCELLSSHIPPEDINSIDEDEVICE, sbBatteryRUBSID.toString());
			mpBatteryRU.put(ConstantsUtil.NUMBEROFBATTRIESREQUIRED, sbBatteryRUNOBR.toString());
			mpBatteryRU.put(ConstantsUtilIRM.DPPQTYPERCOP, sbBatteryRUDPPQTY.toString());
			mpBatteryRU.put(ConstantsUtil.NUMBEROFCELLSSHIPPEDOUTSIDEDEVICE, sbBatteryRUBSOD.toString());
			mpBatteryRU.put(ConstantsUtil.BATTERYCHEMICALCOMPOSITION, sbBatteryRUBCC.toString());
			mpBatteryRU.put(ConstantsUtil.BATTERYWEIGHTUOM, sbBatteryRUBUM.toString());
			mpBatteryRU.put(ConstantsUtil.BATTERYSIZE, sbBatteryRUBS.toString());
			mpBatteryRU.put(ConstantsUtil.LITHUMBATTERYVOLTAGE, sbBatteryRUNBV.toString());
			mpBatteryRU.put(ConstantsUtil.LITHUMBATTERYENERGYUOM, sbBatteryRUBBVU.toString());
			mpBatteryRU.put(ConstantsUtil.TYPICALCAPACITY, sbBatteryRUTC.toString());
			mpBatteryRU.put(ConstantsUtil.TYPICALCAPACITYUOM, sbBatteryRUTCU.toString());
			mpBatteryRU.put(ConstantsUtil.NUMBEROFCELLS, sbBatteryRUNOC.toString());
			mpBatteryRU.put(ConstantsUtil.BATTERYLITHUM, sbBatteryRUGOLPC.toString());
			mpBatteryRU.put(ConstantsUtil.BATTERYLITHUMUOM, sbBatteryRUGOLU.toString());
			mpBatteryRU.put(ConstantsUtil.ISABUTTON, sbBatteryRUITBB.toString());
			mpBatteryRU.put(ConstantsUtil.LITHUMBATTERYENERGY, sbBatteryRULBE.toString());
			//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- START
			mpBatteryRU.put(ConstantsUtilIRM.NOMINALBATTERYENERGY, sbBatteryNBW.toString());
			mpBatteryRU.put(ConstantsUtilIRM.LITHIUMBATTERYENERGYUOM, sbBatteryLBEU.toString());
			//SPEC: <01.04.2022>: Guna Added for 22x Dev  -- END
			//Added By Ajay for the Req 15195 : START
			mpBatteryRU.put(ConstantsUtil.PRODUCTTECHNOLOGYCHASSIS, sbBatteryPTC.toString());
			mpBatteryRU.put(ConstantsUtilIRM.TYPENUMBER, sbBatteryTypeNum.toString());
			//Added By Ajay for the Req 15195 : END

		} catch (Exception e) {
			LOGGER.error("Exception in Program : FinishedProductPartBO Method :getBatteryRollUp " + e);
			return new HashMap();
		}
		return mpBatteryRU;
	}

	
	/**
	 * Method Name : getBatteryTypeFields Method Description : For getting the
	 * battery Details
	 * 
	 * @param context
	 * @param         BatteryType, PickListType, PickListAttribute
	 * @return String
	 * @throws Exception
	 */
	public String getBatteryTypeFields(Context context, String strIfYesselectbatterytype, String strpgPicklistTypeName,
			String strpgPicklistAttributeName) throws Exception

	{
		String strReturnValue = ConstantsUtil.EMPTY_STRING;
		try {
			if (UIUtil.isNotNullAndNotEmpty(strIfYesselectbatterytype)
					&& (UIUtil.isNotNullAndNotEmpty(strpgPicklistTypeName)
							|| UIUtil.isNotNullAndNotEmpty(strpgPicklistAttributeName))) {
				StringBuffer sbRelatedData = new StringBuffer();
				StringList objectSelects = new StringList();
				objectSelects.add(ConstantsUtil.SELECT_ID);
				if (UIUtil.isNotNullAndNotEmpty(strpgPicklistTypeName)) {
					sbRelatedData.append("from[").append(ConstantsUtilIRM.RELATIONSHIP_PGPLRELATEDDATA).append("].to[")
							.append(strpgPicklistTypeName).append("].name");
				} else {
					sbRelatedData.append("attribute[").append(strpgPicklistAttributeName).append("]");
				}
				objectSelects.add(sbRelatedData.toString());
				MapList mlPickListObjects = DomainObject.findObjects(context, //MatrixContext
						ConstantsUtil.TYPE_PGPLIBATTERYTYPE, //typePattern
						strIfYesselectbatterytype, //namePattern
						ConstantsUtil.SYMBL_DASH,  //revPattern
						DomainConstants.QUERY_WILDCARD, //ownerPattern
						context.getVault().getName(), //vaultPattern
						null, //whereExpression
						true,  //expandType
						objectSelects); //objectSelects
				if (mlPickListObjects != null && !mlPickListObjects.isEmpty()) {
					Map mapPickListObj = new HashMap();
					String strObjectId = ConstantsUtil.EMPTY_STRING;
					String strConnectedData = ConstantsUtil.EMPTY_STRING;
					for (int i = 0; i < mlPickListObjects.size(); i++) {
						mapPickListObj = (Map) mlPickListObjects.get(i);
						strObjectId = (String) mapPickListObj.get(ConstantsUtil.SELECT_ID);
						strConnectedData = (String) mapPickListObj.get(sbRelatedData.toString());
						if (UIUtil.isNotNullAndNotEmpty(strObjectId) && UIUtil.isNotNullAndNotEmpty(strConnectedData)) {
							if (strConnectedData.contains(ConstantsUtil.SYMBL_COMMA)) {

								strReturnValue = (String) FrameworkUtil
										.split(strConnectedData, ConstantsUtil.SYMBL_COMMA).get(0);

							} else {
								strReturnValue = strConnectedData;
							}
						}
					}
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in Program : FinishedProductPartBO Method :getBatteryTypeFields " + ex);
			return strReturnValue;
		}
		return strReturnValue;
	}
	
	
	/**
	 * This method returns the mapping for CUP Artwork table
	 * 
	 * @param context
	 * @param args    : domain object
	 * @return: Map
	 * @throws Exception
	 **/
	public Map getCUPArtworkObjects(Context context, DomainObject doFPP) throws Exception {

		MapList mlCUPObjects = new MapList();
		MapList mlSubInterChildData = new MapList();
		MapList mlConnectedInterChildData = new MapList();
		MapList mlArtObjects = new MapList();
		Map mArtObjects = new HashMap();
		MapList mlSubInterChildDataTemp = null;
		MapList mlSubPartArtObjects = null;
		MapList mlRelArtObjects = null;
		Map mChildData = null;
		Map tempMap = null;
		StringList slObjSel = new StringList(5);
		slObjSel.add(ConstantsUtil.SELECT_TYPE);
		slObjSel.add(ConstantsUtil.SELECT_NAME);
		slObjSel.add(ConstantsUtil.SELECT_REVISION);
		slObjSel.add(ConstantsUtil.SELECT_ID);
		slObjSel.add(ConstantsUtil.SELECT_CURRENT);
		slObjSel.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		String strSubIDSelectable = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE)
				.append("].to.id").toString();
		StringList slRelSelects = new StringList(2);
		slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
		slRelSelects.add(strSubIDSelectable);
		StringList slSubCUP = new StringList(1);
		StringList slSubPart = new StringList(1);
		String strCUPID = ConstantsUtil.EMPTY_STRING;
		String strInterID = ConstantsUtil.EMPTY_STRING;
		String strInterChildID = ConstantsUtil.EMPTY_STRING;
		String strSubPartID = ConstantsUtil.EMPTY_STRING;
		DomainObject dObjContext = null;
		DomainObject dObjCUP = null;
		DomainObject dObjInter = null;
		DomainObject dObjSubPart = null;
		DomainObject dObjInterChild = null;
		int iMlSize;
		int sizeOfSubInterm;
		int iMlChildDataSize;
		String strAllowedCUPChild = ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART+ConstantsUtil.SYMBL_COMMA+ConstantsUtil.TYPE_PGPACKINGMATERIAL+ConstantsUtil.SYMBL_COMMA+ConstantsUtil.TYPE_PGONLINEPRINTINGPART;
		String strObjectWhere = ConstantsUtil.SELECT_CURRENT + " == " + ConstantsUtil.STATE_PART_RELEASE;

		StringBuilder sbCUPArtType = new StringBuilder();
		StringBuilder sbCUPArtDisplayType = new StringBuilder();
		StringBuilder sbCUPArtName = new StringBuilder();
		StringBuilder sbCUPArtRev = new StringBuilder();
		StringBuilder sbCUPArtID = new StringBuilder();
		StringBuilder sbCUPArtTitle = new StringBuilder();
		StringBuilder sbCUPArtState = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbGenDocID = new StringBuilder();
		
		try {
			if (doFPP != null) {
				mlCUPObjects = doFPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, // relationshipPattern
						ConstantsUtil.TYPE_PGCUSTOMERUNITPART, // typePattern
						slObjSel, // objectSelects
						slRelSelects, // relationshipSelects
						false, // getTo
						true, // getFrom
						(short) 1, // recurseToLevel
						null, // objectWhere
						null, // relationshipWhere
						0);
			}
			// Get CUP Data
			if (null != mlCUPObjects) {
				iMlSize = mlCUPObjects.size();
				strCUPID = ConstantsUtil.EMPTY_STRING;
				mlConnectedInterChildData = new MapList();
				tempMap = null;
				dObjCUP = null;
				for (int i = 0; i < iMlSize; i++) {
					tempMap = (Map) mlCUPObjects.get(i);
					strCUPID = (String) (tempMap).get(ConstantsUtil.SELECT_ID);
					if (UIUtil.isNotNullAndNotEmpty(strCUPID)) {
						dObjCUP = DomainObject.newInstance(context, strCUPID);
						mlConnectedInterChildData = dObjCUP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, // rel
																														// pattern
								strAllowedCUPChild, // type pattern
								slObjSel, // object select
								slRelSelects, // rel select
								false, // to side
								true, // from side
								(short) 1, // recursion level
								null, // object where clause
								null, 0); // rel where clause
					}
					// Get the subsitutte data
					Object substituteInterId = (Object) (tempMap).get(strSubIDSelectable);
					slSubCUP = new StringList(1);
					if (null != substituteInterId) {
						if (substituteInterId instanceof StringList) {
							slSubCUP = (StringList) substituteInterId;
						} else {
							slSubCUP.add(substituteInterId.toString());
						}
					}
					// Get the Substitute data
					if (null != slSubCUP) {
						dObjInter = null;
						mlSubInterChildData = new MapList();
						strInterID = ConstantsUtil.EMPTY_STRING;
						mlSubInterChildDataTemp = null;
						sizeOfSubInterm = slSubCUP.size();
						for (int iSubInter = 0; iSubInter < sizeOfSubInterm; iSubInter++) {
							strInterID = (String) slSubCUP.get(iSubInter);
							if (UIUtil.isNotNullAndNotEmpty(strInterID)) {
								dObjInter = DomainObject.newInstance(context, strInterID);
								mlSubInterChildDataTemp = dObjInter.getRelatedObjects(context,
										ConstantsUtil.RELATIONSHIP_EBOM, // rel pattern
										strAllowedCUPChild, // type pattern
										slObjSel, // object select
										slRelSelects, // rel select
										false, // to side
										true, // from side
										(short) 1, // recursion level
										null, // object where clause
										null, 0);
								if (null != mlSubInterChildData)
									mlSubInterChildData.addAll(mlSubInterChildDataTemp);
							}
						}
					}
					// Merging CUP and CUP Subsitute Part Maplist
					if (null != mlConnectedInterChildData) {
						mlConnectedInterChildData.addAll(mlSubInterChildData);
					} else {
						mlConnectedInterChildData = mlSubInterChildData;
					}
					// Get the Artwork Data
					if (null != mlConnectedInterChildData) {
						iMlChildDataSize = mlConnectedInterChildData.size();
						strInterChildID = ConstantsUtil.EMPTY_STRING;
						mChildData = null;
						mlRelArtObjects = null;
						dObjInterChild = null;
						for (int k = 0; k < iMlChildDataSize; k++) {
							mChildData = (Map) mlConnectedInterChildData.get(k);
							strInterChildID = (String) mChildData.get(DomainConstants.SELECT_ID);
							if (UIUtil.isNotNullAndNotEmpty(strInterChildID)) {
								dObjInterChild = DomainObject.newInstance(context, strInterChildID);
								mlRelArtObjects = dObjInterChild.getRelatedObjects(context,
										DomainConstants.RELATIONSHIP_PART_SPECIFICATION, // rel pattern
										ConstantsUtil.TYPE_PGARTWORK + "," + ConstantsUtil.TYPE_POA, // type pattern
										slObjSel, // object select
										null, // rel select
										false, // to side
										true, // from side
										(short) 1, // recursion level
										strObjectWhere, // object where clause
										null, 0); // rel where clause
								if (null != mlArtObjects)
									mlArtObjects.addAll(mlRelArtObjects);
							}
							// Get Substitute Part Artwork
							Object substitutePartId = (Object) (mChildData).get(strSubIDSelectable);
							slSubPart = new StringList(1);
							if (null != substitutePartId) {
								if (substitutePartId instanceof StringList) {
									slSubPart = (StringList) substitutePartId;
								} else {
									slSubPart.add(substitutePartId.toString());
								}
								strSubPartID = ConstantsUtil.EMPTY_STRING;
								dObjSubPart = null;
								mlSubPartArtObjects = null;
								for (int iSub = 0; iSub < slSubPart.size(); iSub++) {
									strSubPartID = (String) slSubPart.get(iSub);
									if (UIUtil.isNotNullAndNotEmpty(strSubPartID)) {
										dObjSubPart = DomainObject.newInstance(context, strSubPartID);
										mlSubPartArtObjects = dObjSubPart.getRelatedObjects(context,
												ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION, // rel pattern
												ConstantsUtil.TYPE_PGARTWORK + "," + ConstantsUtil.TYPE_POA, // type
																												// pattern
												slObjSel, // object select
												null, // rel select
												false, // to side
												true, // from side
												(short) 1, // recursion level
												strObjectWhere, // object where clause
												null, 0); // rel where clause
										if (null != mlArtObjects)
											mlArtObjects.addAll(mlSubPartArtObjects);
									}
								}
							}

						}
					}
				}
			}
			if (null != mlArtObjects) {
				for (int k = 0; k < mlArtObjects.size(); k++) {
					mChildData = (Map) mlArtObjects.get(k);
					String sCUPArtType = validator.getStringEquivalentForStringList(mChildData.get(ConstantsUtil.SELECT_TYPE));
					String sCUPArtName = validator.getStringEquivalentForStringList(mChildData.get(ConstantsUtil.SELECT_NAME));
					String sCUPArtRev = validator.getStringEquivalentForStringList(mChildData.get(ConstantsUtil.SELECT_REVISION));
					String sCUPArtID = validator.getStringEquivalentForStringList(mChildData.get(ConstantsUtil.SELECT_ID));
					String sCUPArtTitle = validator.getStringEquivalentForStringList(mChildData.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String sCUPArtState = validator.getStringEquivalentForStringList(mChildData.get(ConstantsUtil.SELECT_CURRENT));
					String strGenDoc = validator.getStringEquivalentForStringList(mChildData.get(ConstantsUtil.SELECT_ID));
					
					if(!util.checkHasAccess(context, null, sCUPArtID)) {
						sCUPArtID = ConstantsUtil.NO_ACCESS;
					}
					
					if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sCUPArtState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sCUPArtState))){
						sCUPArtID = ConstantsUtil.NO_ACCESS;
					}
					util.formatData(sbCUPArtType, sCUPArtType);
					util.formatData(sbCUPArtDisplayType, util.mapType(sCUPArtType));
					util.formatData(sbCUPArtName, sCUPArtName);
					util.formatData(sbCUPArtRev, sCUPArtRev);
					util.formatData(sbCUPArtID, sCUPArtID);
					util.formatData(sbCUPArtTitle, sCUPArtTitle);
					util.formatData(sbCUPArtState, sCUPArtState);
					util.formatData(sbGenDocID, strGenDoc);
					
				}
			}
			mArtObjects.put(ConstantsUtil.TYPE, sbCUPArtType.toString());
			mArtObjects.put(ConstantsUtil.DISPLAY_TYPE, sbCUPArtDisplayType.toString());
			mArtObjects.put(ConstantsUtil.NAME, sbCUPArtName.toString());
			mArtObjects.put(ConstantsUtil.REVISION, sbCUPArtRev.toString());
			mArtObjects.put(ConstantsUtil.ID, sbCUPArtID.toString());
			mArtObjects.put(ConstantsUtil.TITLE, sbCUPArtTitle.toString());
			mArtObjects.put(ConstantsUtil.STATE, sbCUPArtState.toString());
			mArtObjects.put(ConstantsUtil.GENDOCVIEW, sbGenDocID.toString());
			
			
		} catch (Exception ex) {
			LOGGER.error("Exception in Program : FinishedProductPartBO Method :getCUPArtworkObjects " + ex);
		}
		return mArtObjects;
	}
	// SPEC: <02.24.2021>: Added for req 18x.6 by Sumit ## -- END
	
	
	/**
	 * Method Name 			: getBaseCodeDetailsUpdate
	 * Method Description 	: For getting the Base Code Details of FPP
	 * @param context
	 * @param mlObjectList
	 * @param mpBaseCodeDetails
	 * @param env 
	 * @return
	 * @throws Exception
	 */
	//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 23, 2021 for Defect#40803 -- START
	//public Map<String, String> getBaseCodeDetailsUpdate(Context context, MapList mlObjectList, Map mpGTIN) throws Exception {
	public Map<String, String> getBaseCodeDetailsUpdate(Context context, String baseCodeID, String baseCodeType, String baseCodeName, String strType, String baseCodeIDs, Environment env) throws Exception {
	//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 23, 2021 for Defect#40803 -- START
		Map<String,String> mpBaseCodeDetails = new HashMap<String,String>();
		
		StringList slReturnVal = new StringList();
		StringBuilder sbDepth = new StringBuilder();
		StringBuilder sbWidth = new StringBuilder();
		StringBuilder sbHeight = new StringBuilder();
		StringBuilder sbCOPDepth = new StringBuilder();
		StringBuilder sbCOPWidth = new StringBuilder();
		StringBuilder sbCOPHeight = new StringBuilder();
		StringBuilder sbCUPDepth = new StringBuilder();
		StringBuilder sbCUPWidth = new StringBuilder();
		StringBuilder sbCUPHeight = new StringBuilder();
		StringBuilder sbIPDepth = new StringBuilder();
		StringBuilder sbIPWidth = new StringBuilder();
		StringBuilder sbIPHeight = new StringBuilder();
		StringBuilder sbDimUom= new StringBuilder();
		StringList strPGDUoM = new StringList();
		StringBuilder sbGrossWtUom = new StringBuilder();
		StringBuilder sbNetWt = new StringBuilder();
		StringBuilder sbAuom = new StringBuilder();
		StringBuilder sbGrossWtReal = new StringBuilder();
		StringBuilder sbPackingType = new StringBuilder();
		StringBuilder sbNetWetOfProdInCU = new StringBuilder();
		StringBuilder sbGtin = new StringBuilder();
		StringBuilder sbCOPGTIN = new StringBuilder();
		StringBuilder sbCUPGTIN = new StringBuilder();
		StringBuilder sbIPGTIN = new StringBuilder();
		StringBuilder sbCOPGrossWeight = new StringBuilder();
		StringBuilder sbCUPGrossWeight = new StringBuilder();
		StringBuilder sbIPGrossWeight = new StringBuilder();
		StringBuilder sbCOPGrossWeightUOM = new StringBuilder();
		StringBuilder sbCUPGrossWeightUOM = new StringBuilder();
		StringBuilder sbIPGrossWeightUOM = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbBaseCodeName = new StringBuilder();
		StringBuilder sbBaseCodeType = new StringBuilder();
		StringBuilder sbBaseCodeId = new StringBuilder();
		StringBuilder sbCOPLWD = new StringBuilder();
		StringBuilder sbCUPLWD = new StringBuilder();
		StringBuilder sbIPLWD = new StringBuilder();
		StringBuilder sbCOPGW = new StringBuilder();
		StringBuilder sbCUPGW = new StringBuilder();
		StringBuilder sbIPGW = new StringBuilder();
		
		CommonBusUtilBO bo = new CommonBusUtilBO();
		
		try
		{
			String  sAttrName = "";
			String  strReportFormat = "";
			String sDepthVal = "";
			String sWidthVal = "";
			String sHeightVal = "";
			String sDimUoMVal = "";
			String sConnectionId="";
			String sConn="";
			String strResult="";

			BusExtractUtil busUtil = new BusExtractUtil();
			//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 23, 2021 for Defect#40803 -- START
			StringList eachBaseCodeID = util.getStringList(baseCodeID);
			StringList eachBaseCodeIDs = util.getStringList(baseCodeIDs);
			StringList eachBaseCodeType = util.getStringList(baseCodeType);
			StringList eachBaseCodeName = util.getStringList(baseCodeName);
			Map mpGTIN = null;
			
			for(int p=0;p<eachBaseCodeID.size();p++) {
				
				String objectId=eachBaseCodeID.get(p);
				String objectIds=eachBaseCodeIDs.get(p);
				String objectType=eachBaseCodeType.get(p);
				String objectName=eachBaseCodeName.get(p);
				mpGTIN = new HashMap();
				
				MapList mlObjectList = getPackingUnitWeightsAndDiamensionsData(context,objectId);
				if(!strType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT))
				{
					mpGTIN =  busUtil.getGTINFromSoapPO(context, objectId,objectType,objectName,env);
				}
				
				formatData(sbBaseCodeId,objectIds);
				formatData(sbBaseCodeType,objectType);
				formatData(sbBaseCodeName,objectName);
				//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 23, 2021 for Defect#40803 -- END
				
			String sGtinValue = busUtil.getGTINValue(context,mpGTIN,true,mlObjectList);
			StringList sGtinValues = util.getStringList(sGtinValue);
			
			StringBuilder sbNPC =  getNumberPerCustomerUnit(context,mlObjectList);
			
			Iterator objListItr = mlObjectList.iterator();
			while (objListItr.hasNext()) {

				Map perMap = (Map) objListItr.next();
				String sObjectId = (String)perMap.get(DomainConstants.SELECT_ID);
				String sType = (String)perMap.get(DomainConstants.SELECT_TYPE);

				String strGrossWth = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
				String strNetWetUoM = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
				String strGrossWtReal = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
				String strNetWetOfProdInCU = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
				String sAUOM =  (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
				String sGtin =  (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);

				if(ConstantsUtil.tCOP.contains(util.mapType(sType))) 
				{
					formatData(sbCOPGrossWeight,strGrossWtReal);
					formatData(sbCOPGrossWeightUOM,strGrossWth);
					formatData(sbCOPGW,strGrossWtReal+ConstantsUtilIRM.BLANK_SPACE+strGrossWth);
				}
				if(ConstantsUtil.tCUP.contains(util.mapType(sType))) 
				{
					try {
						formatData(sbCUPGTIN,sGtinValues.get(0));
					}catch(Exception e) {
						formatData(sbCUPGTIN,ConstantsUtil.EMPTY_STRING);
					}
					formatData(sbCUPGrossWeight,strGrossWtReal);
					formatData(sbCUPGrossWeightUOM,strGrossWth);
					formatData(sbCUPGW,strGrossWtReal+ConstantsUtilIRM.BLANK_SPACE+strGrossWth);
				}
				if(ConstantsUtil.tIP.contains(util.mapType(sType))) 
				{
					formatData(sbIPGrossWeight,strGrossWtReal);
					formatData(sbIPGrossWeightUOM,strGrossWth);
					formatData(sbIPGW,strGrossWtReal+ConstantsUtilIRM.BLANK_SPACE+strGrossWth);
				}
				
				if(sGtinValues.size()==2) {
					if(ConstantsUtil.tCOP.contains(util.mapType(sType))){
						try {
							formatData(sbCOPGTIN,sGtinValues.get(1));
						}catch(Exception e) {
							formatData(sbCOPGTIN,ConstantsUtil.EMPTY_STRING);
						}
					}
					if(ConstantsUtil.tIP.contains(util.mapType(sType))){
						try {
							formatData(sbIPGTIN,sGtinValues.get(1));
						}catch(Exception e) {
							formatData(sbIPGTIN,ConstantsUtil.EMPTY_STRING);
						}
					}
				}
				if(sGtinValues.size()==3) {
					if(ConstantsUtil.tCOP.contains(util.mapType(sType))){
						try {
							formatData(sbCOPGTIN,sGtinValues.get(2));
						}catch(Exception e) {
							formatData(sbCOPGTIN,ConstantsUtil.EMPTY_STRING);
						}
					}
					if(ConstantsUtil.tIP.contains(util.mapType(sType))){
						try {
							formatData(sbIPGTIN,sGtinValues.get(1));
						}catch(Exception e) {
							formatData(sbIPGTIN,ConstantsUtil.EMPTY_STRING);
						}
					}
				}
				
				formatData(sbId,sObjectId);
				formatData(sbNetWt,strNetWetUoM);
				formatData(sbAuom,sAUOM);
				formatData(sbNetWetOfProdInCU,strNetWetOfProdInCU);

				sType = util.mapType(sType);
				String sName =(String)perMap.get(ConstantsUtil.SELECT_NAME);
				sName = sType+ConstantsUtil.SYMBL_OPNBRACE+ sName +ConstantsUtil.SYMBL_CLSBRACE;
				formatData(sbPackingType,sName);

				if(sType != null && !"".equals(sType))
				{
					if(sObjectId != null && !"".equals(sObjectId))
					{
						sConn="";
						sDepthVal = "";
						sWidthVal = "";
						sHeightVal = "";

						String sMQLStmt = "print connection $1 select $2 dump $3;";
						DomainObject bomObject = DomainObject.newInstance(context,sObjectId);
						StringList sConnList = bomObject.getInfoList(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM+"].id");
						for(int i=0;i<sConnList.size();i++)
						{
							sConnectionId=(String)sConnList.get(i);
							String querycommand="print connection"+" "+"\"$1\""+" "+ "select $2 dump  $3";
							strResult=MqlUtil.mqlCommand(context,querycommand,sConnectionId,"frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"]","|").trim();

							if(strResult.equalsIgnoreCase("True"))
							{
								sConn=sConnectionId;
								break;
							}
							else
							{
								continue;
							}
						}

						String sSelectable1 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_LENGTH+"].value";
						String sSelectable2 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_WIDTH+"].value";
						String sSelectable3 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_OUTERDIMENSIONHEIGHT+"].value";
						String sSelectable4 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_DIMENSTION_UOM+"].value";
						String sSelectable5 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT+"].value";

						String tempVal = new String();	
						
						if(sConn != null && !"".equals(sConn))
						{
							sDepthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable1, "|");
							sWidthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable2, "|");
							sHeightVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable3, "|");
							sDimUoMVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable4, "|");
							if (sDepthVal == null || "".equals(sDepthVal))
							{
								sDepthVal = "0.0";
							}
							if (sWidthVal == null || "".equals(sWidthVal))
							{
								sWidthVal = "0.0";
							}
							if (sHeightVal == null || "".equals(sHeightVal))
							{
								sHeightVal = "0.0";
							}
							
							if(ConstantsUtil.tCOP.contains(sType)) 
							{
								formatData(sbCOPDepth,sDepthVal);
								formatData(sbCOPWidth,sWidthVal);
								formatData(sbCOPHeight,sHeightVal);
								formatData(sbDimUom,sDimUoMVal);
								formatData(sbCOPLWD,sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							else if(ConstantsUtil.tCUP.contains(sType)) 
							{
								formatData(sbCUPDepth,sDepthVal);
								formatData(sbCUPWidth,sWidthVal);
								formatData(sbCUPHeight,sHeightVal);
								formatData(sbDimUom,sDimUoMVal);
								formatData(sbCUPLWD,sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							else 
							{
								formatData(sbIPDepth,sDepthVal);
								formatData(sbIPWidth,sWidthVal);
								formatData(sbIPHeight,sHeightVal);
								formatData(sbDimUom,sDimUoMVal);
								formatData(sbIPLWD,sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
						} 
						else 
						{
							sDepthVal = "0.0";
							sWidthVal = "0.0";
							sHeightVal = "0.0";
							sDimUoMVal = "";

							if(ConstantsUtil.tCOP.contains(sType)) 
							{
								formatData(sbCOPDepth,sDepthVal);
								formatData(sbCOPWidth,sWidthVal);
								formatData(sbCOPHeight,sHeightVal);
								formatData(sbDimUom,sDimUoMVal);
								formatData(sbCOPLWD,sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							else if(ConstantsUtil.tCUP.contains(sType)) 
							{
								formatData(sbCUPDepth,sDepthVal);
								formatData(sbCUPWidth,sWidthVal);
								formatData(sbCUPHeight,sHeightVal);
								formatData(sbDimUom,sDimUoMVal);
								formatData(sbCUPLWD,sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							else 
							{
								formatData(sbIPDepth,sDepthVal);
								formatData(sbIPWidth,sWidthVal);
								formatData(sbIPHeight,sHeightVal);
								formatData(sbDimUom,sDimUoMVal);
								formatData(sbIPLWD,sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
						}
					}
				}
			}
		//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 23, 2021 for Defect#40803 -- START
		}
		//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 23, 2021 for Defect#40803 -- END
			mpBaseCodeDetails.put(ConstantsUtil.NAME, sbBaseCodeName.toString());
			mpBaseCodeDetails.put(ConstantsUtil.ID, sbBaseCodeId.toString());
			mpBaseCodeDetails.put(ConstantsUtil.TYPE, sbBaseCodeType.toString());
			mpBaseCodeDetails.put(ConstantsUtil.COPDEPTH, sbCOPDepth.toString());
			mpBaseCodeDetails.put(ConstantsUtil.COPWIDTH, sbCOPWidth.toString());
			mpBaseCodeDetails.put(ConstantsUtil.COPLENGTH, sbCOPHeight.toString());
			mpBaseCodeDetails.put(ConstantsUtil.CUPDEPTH, sbCUPDepth.toString());
			mpBaseCodeDetails.put(ConstantsUtil.CUPWIDTH, sbCUPWidth.toString());
			mpBaseCodeDetails.put(ConstantsUtil.CUPLENGTH, sbCUPHeight.toString());
			mpBaseCodeDetails.put(ConstantsUtil.IPDEPTH, sbIPDepth.toString());
			mpBaseCodeDetails.put(ConstantsUtil.IPWIDTH, sbIPWidth.toString());
			mpBaseCodeDetails.put(ConstantsUtil.IPLENGTH, sbIPHeight.toString());
			mpBaseCodeDetails.put(ConstantsUtil.CUPGROSSWEIGHT, sbCUPGrossWeight.toString());
			mpBaseCodeDetails.put(ConstantsUtil.COPGROSSWEIGHT, sbCOPGrossWeight.toString());
			mpBaseCodeDetails.put(ConstantsUtil.IPGROSSWEIGHT, sbIPGrossWeight.toString());
			mpBaseCodeDetails.put(ConstantsUtil.CUPGTIN, sbCUPGTIN.toString());
			mpBaseCodeDetails.put(ConstantsUtil.COPGTIN, sbCOPGTIN.toString());
			mpBaseCodeDetails.put(ConstantsUtil.IPGTIN, sbIPGTIN.toString());
			mpBaseCodeDetails.put(ConstantsUtil.CUPGROSSWEIGHTUOM, sbCUPGrossWeightUOM.toString());
			mpBaseCodeDetails.put(ConstantsUtil.COPGROSSWEIGHTUOM, sbCOPGrossWeightUOM.toString());
			mpBaseCodeDetails.put(ConstantsUtil.IPGROSSWEIGHTUOM, sbIPGrossWeightUOM.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.COPLWD, sbCOPLWD.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.CUPLWD, sbCUPLWD.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.IPLWD, sbIPLWD.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.COPGW, sbCOPGW.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.CUPGW, sbCUPGW.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.IPGW, sbIPGW.toString());
			
		} catch(Exception e){
			LOGGER.error(" Exception in program FPPBO : getBaseCodeDetailsUpdate : "+e);
			return new HashMap();
		}
		return util.filterMapList(mpBaseCodeDetails);
	}
	
	
	//SPEC: Release SR18x.6.0 - Added by Amman on Apr 9, 2021 for Defect 42253 -- START
	/**
	 * Method Name 			: getDangerousGoodsClassification
	 * Method Description 	: 
	 * @param context
	 * @param resultMaps
	 * @return
	 */

	public Map getDangerousGoodsClassification(Context context,Map resultMaps)throws Exception
	{
		Map mpDangerousProdcut = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();	

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();

		String strRev = ConstantsUtil.EMPTY_STRING;
		String strName = ConstantsUtil.EMPTY_STRING;
		String strTitle = ConstantsUtil.EMPTY_STRING;
		String strId = ConstantsUtil.EMPTY_STRING;
		String strTyp = ConstantsUtil.EMPTY_STRING;
		String strState = ConstantsUtil.EMPTY_STRING;
		String strPhase = ConstantsUtil.EMPTY_STRING;

		StringBuilder sbDGD = new StringBuilder();
		StringBuilder sbUNN = new StringBuilder();
		StringBuilder sbPSN = new StringBuilder();
		StringBuilder sbHC = new StringBuilder();
		StringBuilder sbPgroup = new StringBuilder();
		StringBuilder sbShipqty = new StringBuilder();
		StringBuilder sbCON = new StringBuilder();
		StringBuilder sbOPR = new StringBuilder();
		StringBuilder sbUSPGreq = new StringBuilder();
		StringBuilder sbCust = new StringBuilder();
		StringBuilder sbGCUP = new StringBuilder();
		StringBuilder sbGCOP = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbTN1 = new StringBuilder();
		StringBuilder sbTN2 = new StringBuilder();

		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		String sComp = sct.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);

		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		try
		{
			String strContextId = (String)resultMaps.get(ConstantsUtil.SELECT_ID);

			DomainObject dobDG = new DomainObject(strContextId);

			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPMENTLIMITEDQUANTITY);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERWEIGHTVOLUME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXCONSUMERUNITSIZE);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERWEIGHTVOLUME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCUPLABELREQUIRED);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCOPLABELREQUIRED);
			slBusSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_HAZARDCLASS);
			slBusSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_PACKINGGGROPUP);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME1);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME2);
			slBusSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_REVISION_FPP);
			slBusSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_NAME_FPP);
			slBusSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_TITLE_FPP);
			slBusSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_ID_FPP);
			slBusSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_TYPE_FPP);
			slBusSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE_FPP);
			slBusSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE_FPP);

			MapList mlDGDList = dobDG.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODS,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, null, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobDG.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator objectListItr = mlDGDList.iterator();

			while(objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				
				strRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_REVISION_FPP));
				strName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_NAME_FPP));
				strTitle = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_TITLE_FPP));
				strId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_ID_FPP));
				strTyp = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_TYPE_FPP));
				strState = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE_FPP));
				strPhase = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE_FPP));
				
				String strDGD = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String strUNN = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER));
				String strPSN = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME));
				String strShipqty = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPMENTLIMITEDQUANTITY));
				
				if(strShipqty.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
					strShipqty = ConstantsUtil.SYMBL_CAPTRUE;
				}
				else if(strShipqty.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
					strShipqty = ConstantsUtil.SYMBL_CAPFALSE;
				}
				
				String strCON = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERWEIGHTVOLUME));
				String strOPR = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS));
				String strUSPGreq = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXCONSUMERUNITSIZE));
				String strCUST = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERWEIGHTVOLUME));
				String strSDgcup = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCUPLABELREQUIRED));
				String strSDgcop = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCOPLABELREQUIRED));
				String strHC  = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_HAZARDCLASS));
				String strPGGroup = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_PACKINGGGROPUP));
				String strTN1 = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME1));
				String strTN2 = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME2));

				boolean bHasOwnership =false;
				boolean showData =true;

				if(util.isModificatinRequired())
				{
					bHasOwnership=util.checkHasAccess(context, null, strId);
					
					if(!bHasOwnership)
					{
						//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43248 -- START
						strId = ConstantsUtil.NO_ACCESS;
						//continue;
						strTitle = ConstantsUtil.NO_ACCESS;
						//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43248 -- END
					}
					
					//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43248 -- START
					if (!ConstantsUtil.RELEASED.equalsIgnoreCase(strState)
							&& !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strState))) {
						//continue;
						strId = ConstantsUtil.NO_ACCESS;
						strTitle = ConstantsUtil.NO_ACCESS;
					}
					//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 02, 2021 for Req #39652 / Defect 43248 -- END
					
				}else if(sct.isStaffAUGUser()) 
				{
					showData=util.checkHasAccess(context, null,strId);
				}else 
				{
					showData=util.checkHasAccess(context, null,strId);
				}

				if(!showData){
					strId = ConstantsUtil.NO_ACCESS;
					//Added by Jwala for the req 40516 for 2022x Release -- START
					strTitle = ConstantsUtil.NO_ACCESS;
					//Added by Jwala for the req 40516 for 2022x Release -- END
				}

				formatData(sbName, strName);
				formatData(sbRev, strRev);
				formatData(sbTitle, strTitle);
				formatData(sbId, strId);
				formatData(sbType, strTyp);
				formatData(sbState, strState);
				formatData(sbPhase, strPhase);
				
				formatData(sbHC, strHC);
				formatData(sbPgroup, strPGGroup);
				formatData(sbDGD, strDGD);
				formatData(sbUNN, strUNN);
				formatData(sbPSN, strPSN);
				formatData(sbShipqty, strShipqty);
				formatData(sbCON, strCON);
				formatData(sbOPR, strOPR);
				formatData(sbUSPGreq, strUSPGreq);
				formatData(sbCust, strCUST);
				formatData(sbGCUP, strSDgcup);
				formatData(sbGCOP, strSDgcop);
				formatData(sbTN1, strTN1);
				formatData(sbTN2, strTN2);
			}
			
			mpDangerousProdcut.put(ConstantsUtil.PPN, sbName.toString());
			mpDangerousProdcut.put(ConstantsUtil.ID, sbId.toString());
			mpDangerousProdcut.put(ConstantsUtil.TYPE, sbType.toString());
			mpDangerousProdcut.put(ConstantsUtil.PPR,sbRev.toString());
			mpDangerousProdcut.put(ConstantsUtil.PPT,sbTitle.toString());
			mpDangerousProdcut.put(ConstantsUtil.DGD,sbDGD.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNN,sbUNN.toString());
			mpDangerousProdcut.put(ConstantsUtil.PSN,sbPSN.toString());
			mpDangerousProdcut.put(ConstantsUtil.HC,sbHC.toString());
			mpDangerousProdcut.put(ConstantsUtil.PGGROUP,sbPgroup.toString());
			mpDangerousProdcut.put(ConstantsUtil.SHIPPINGQTY,sbShipqty.toString());
			mpDangerousProdcut.put(ConstantsUtil.CON,sbCON.toString());
			mpDangerousProdcut.put(ConstantsUtil.OPR,sbOPR.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNSPECPACKGGREQUIRED,sbUSPGreq.toString());
			mpDangerousProdcut.put(ConstantsUtil.CUST,sbCust.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCUP,sbGCUP.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCOP,sbGCOP.toString());
			mpDangerousProdcut.put(ConstantsUtil.PHASE,sbPhase.toString());
			mpDangerousProdcut.put(ConstantsUtil.STATE,sbState.toString());
			mpDangerousProdcut.put(ConstantsUtil.TN1,sbTN1.toString());
			mpDangerousProdcut.put(ConstantsUtil.TN2,sbTN2.toString());

		}catch(Exception e){
			LOGGER.error("Error from FPPBO:  getDangerousGoodsClassification"+e.getLocalizedMessage());
			throw e;
			//return new HashMap();
		}
		return mpDangerousProdcut;
	}
	//SPEC: Release SR18x.6.0 - Added by Amman on Apr 9, 2021 for Defect 42253 -- END
	
	
	//SPEC: Release SR18x.6.0 - Added by Amman on Apr 20, 2021 for Defect 42162 -- START
	/**
	 * Method Name : getBaseCodeDetails
	 * Method Description :
	 * @param context
	 * @param baseCodeID
	 * @param baseCodeType
	 * @param baseCodeName
	 * @param strType
	 * @param baseCodeIDs
	 * @param env
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getBaseCodeDetails(Context context, String baseCodeID, String baseCodeType, 
			String baseCodeName, String strType, String baseCodeIDs, Environment env) throws Exception 
	{
		Map<String,String> mpBaseCodeDetails = new HashMap<String,String>();
		
		StringBuilder sbBaseCodeName = new StringBuilder();
		StringBuilder sbBaseCodeType = new StringBuilder();
		StringBuilder sbBaseCodeId = new StringBuilder();
		
		StringBuilder sbCOPGTIN = new StringBuilder();
		StringBuilder sbCUPGTIN = new StringBuilder();
		StringBuilder sbIPGTIN = new StringBuilder();
		StringBuilder sbCOPLWD = new StringBuilder();
		StringBuilder sbCUPLWD = new StringBuilder();
		StringBuilder sbIPLWD = new StringBuilder();
		StringBuilder sbCOPGW = new StringBuilder();
		StringBuilder sbCUPGW = new StringBuilder();
		StringBuilder sbIPGW = new StringBuilder();
		
		StringBuilder sbFinalCOPGTIN = new StringBuilder();
		StringBuilder sbFinalCUPGTIN = new StringBuilder();
		StringBuilder sbFinalIPGTIN = new StringBuilder();
		StringBuilder sbFinalCOPGW = new StringBuilder();
		StringBuilder sbFinalCUPGW = new StringBuilder();
		StringBuilder sbFinalIPGW = new StringBuilder();
		StringBuilder sbFinalCOPLWD = new StringBuilder();
		StringBuilder sbFinalCUPLWD = new StringBuilder();
		StringBuilder sbFinalIPLWD = new StringBuilder();
		
		CommonBusUtilBO bo = new CommonBusUtilBO();
		
		try
		{
			StringList eachBaseCodeID = util.getStringList(baseCodeID);
			StringList eachBaseCodeIDs = util.getStringList(baseCodeIDs);
			StringList eachBaseCodeType = util.getStringList(baseCodeType);
			StringList eachBaseCodeName = util.getStringList(baseCodeName);
			
			Map mpGTIN = null;
			
			for(int p=0;p<eachBaseCodeID.size();p++) 
			{	
				String objectId=eachBaseCodeID.get(p);
				String objectIds=eachBaseCodeIDs.get(p);
				String objectType=eachBaseCodeType.get(p);
				String objectName=eachBaseCodeName.get(p);
				mpGTIN = new HashMap();
				MapList mlObjectList = getPackingUnitWeightsAndDiamensionsData(context,objectId);
				
			    String ss =	getBaseCodeTableWithData(context,mlObjectList,objectId,objectName,objectType,env,sbCUPGTIN,sbIPGTIN,sbCOPGTIN,sbCUPGW,sbIPGW,sbCOPGW,sbCUPLWD,sbIPLWD,sbCOPLWD);
				
				sbFinalCUPGTIN.append(sbCUPGTIN.toString()).append("|");
				sbFinalIPGTIN.append(sbIPGTIN.toString()).append("|");
				sbFinalCOPGTIN.append(sbCOPGTIN.toString()).append("|");
				
				sbCOPGTIN = new StringBuilder();
				sbCUPGTIN = new StringBuilder();
				sbIPGTIN = new StringBuilder();
				 
				sbFinalCUPGW.append(sbCUPGW.toString()).append("|");
				sbFinalIPGW.append(sbIPGW.toString()).append("|");
				sbFinalCOPGW.append(sbCOPGW.toString()).append("|");
				
				sbCUPGW = new StringBuilder();
				sbIPGW = new StringBuilder();
				sbCOPGW = new StringBuilder();
				
				sbFinalCUPLWD.append(sbCUPLWD.toString()).append("|");
				sbFinalIPLWD.append(sbIPLWD.toString()).append("|");
				sbFinalCOPLWD.append(sbCOPLWD.toString()).append("|");
				
				sbCUPLWD = new StringBuilder();
				sbIPLWD = new StringBuilder();
				sbCOPLWD = new StringBuilder();
				  
				formatData(sbBaseCodeId,objectIds);
				formatData(sbBaseCodeType,objectType);
				formatData(sbBaseCodeName,objectName);
			}
		
			mpBaseCodeDetails.put(ConstantsUtil.NAME, sbBaseCodeName.toString());
			mpBaseCodeDetails.put(ConstantsUtil.ID, sbBaseCodeId.toString());
			mpBaseCodeDetails.put(ConstantsUtil.TYPE, sbBaseCodeType.toString());
			
			mpBaseCodeDetails.put(ConstantsUtil.CUPGTIN, sbFinalCUPGTIN.toString());
			mpBaseCodeDetails.put(ConstantsUtil.COPGTIN, sbFinalCOPGTIN.toString());
			mpBaseCodeDetails.put(ConstantsUtil.IPGTIN, sbFinalIPGTIN.toString());
			
			mpBaseCodeDetails.put(ConstantsUtilIRM.COPLWD, sbFinalCOPLWD.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.CUPLWD, sbFinalCUPLWD.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.IPLWD, sbFinalIPLWD.toString());
			
			mpBaseCodeDetails.put(ConstantsUtilIRM.COPGW, sbFinalCOPGW.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.CUPGW, sbFinalCUPGW.toString());
			mpBaseCodeDetails.put(ConstantsUtilIRM.IPGW, sbFinalIPGW.toString());
			
		} catch(Exception e){
			LOGGER.error(" Exception in program FPPBO : getBaseCodeDetailsUpdate : "+e);
			return new HashMap();
		}
		return util.filterMapList(mpBaseCodeDetails);
	}
	
	
	/**
	 * Method Name : getBaseCodeGTIN
	 * Method Description : 
	 * @param context
	 * @param hmAUOM
	 * @param objectList
	 * @return
	 * @throws FrameworkException
	 */
	public MapList getBaseCodeGTIN(Context context, Map hmAUOM, MapList objectList) throws FrameworkException
	{
		StopWatch swGtinFinal = new StopWatch();
		swGtinFinal.start();
		
		Map  mpGTINValues = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		StringBuilder sbCUP = new StringBuilder();
		StringBuilder sbIP = new StringBuilder();
		StringBuilder sbCOP = new StringBuilder();
		String sGTINValue = new String();
		MapList mlGTIN = new MapList();
		try
		{
		Map mpTemp =(Map)hmAUOM.get("AlternativeUnitOfMeasure");
		if(objectList != null && !objectList.isEmpty())
		{
			for(int i = 0; i < objectList.size(); i ++)
			{
				Map mapIndividual = (Map) objectList.get(i);
				
				String	strObjId = (String) mapIndividual.get(DomainConstants.SELECT_ID);
				String	strObjType= (String) mapIndividual.get(DomainConstants.SELECT_TYPE);
				if(UIUtil.isNotNullAndNotEmpty(strObjId))
				{
					DomainObject domObject = DomainObject.newInstance(context, strObjId);
					String strObjAUOM = (String) domObject.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
						
					if(strObjAUOM.equals("ConsumerUnit")){
							strObjAUOM = "type_pgConsumerUnitPart";
						}else 	if(strObjAUOM.equals("InnerPack")){
							strObjAUOM = "type_pgInnerPackUnitPart";
						}else 	if(strObjAUOM.equals("CustomerUnit")){
							strObjAUOM = "type_pgCustomerUnitPart";
						}else if(strObjAUOM.equals("PalletType")){
							strObjAUOM = "type_pgTransportUnit";
						}else 	if(strObjAUOM.equals("Actual/Physical Case")){
							strObjAUOM = "CS";
						}else 	if(strObjAUOM.equals("Shrink Wrap")){
							strObjAUOM = "SW";
						}else 	if(strObjAUOM.equals("Bundle Pack")){
						strObjAUOM = "BP";
						}else	if(strObjAUOM.equals("IT")){
							strObjAUOM = "IT";
						}else 	if(strObjAUOM.equals("MP")){
							strObjAUOM = "MP";
						}else if(strObjAUOM.equals("SP")){
							strObjAUOM = "SP";
						}else 	if(strObjAUOM.equals("Item")){
							strObjAUOM = "IT";
						}else 	if(strObjAUOM.equals("SW")){
							strObjAUOM = "SW";
						}
						else{
							strObjAUOM = "";
						}
						
						if(mpTemp != null && !mpTemp.isEmpty() && UIUtil.isNotNullAndNotEmpty(strObjAUOM) && mpTemp.containsKey(strObjAUOM))
						{
							sGTINValue = (String)mpTemp.get(strObjAUOM);
						}
						else
						{
							sGTINValue =ConstantsUtil.EMPTY_STRING;
						}
						
						if (strObjType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)) {
							sbCUP.append(sGTINValue);
						}else if (strObjType.equals(ConstantsUtil.TYPE_PGINNERPACKUNITPART)) {
							sbIP.append(sGTINValue);
						}else if (strObjType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) {
							sbCOP.append(sGTINValue);
						}
						
						mapIndividual.put(ConstantsUtil.CUP, sbCUP.toString());
						mapIndividual.put(ConstantsUtil.IP, sbIP.toString());
						mapIndividual.put(ConstantsUtil.COP, sbCOP.toString());
						mlGTIN.add(mapIndividual);
						
						sbCUP = new StringBuilder();
						sbIP = new StringBuilder();
						sbCOP = new StringBuilder();	
				}
			}
		}
		swGtinFinal.stop();	
		
		//LOGGER.info("Total GTIN Taken  Time :"+swGtinFinal.getTime());
		return	mlGTIN;
		
		}catch(Exception e){
			LOGGER.error("Error in FPPBO  :unable to get  GTIN ");
			return new MapList();
		}
	}
	
	
	/**
	 * Method Name : getBaseCodeTableWithData
	 * Method Description :
	 * @param context
	 * @param mlBOM
	 * @param strBaseCodeId
	 * @param strBaseCodeName
	 * @param strBaseCodeType
	 * @param env
	 * @param sbCUPGTIN
	 * @param sbIPGTIN
	 * @param sbCOPGTIN
	 * @param sbCUPGW
	 * @param sbIPGW
	 * @param sbCOPGW
	 * @param sbCUPLWD
	 * @param sbIPLWD
	 * @param sbCOPLWD
	 * @return
	 */
	public String getBaseCodeTableWithData(Context context, MapList mlBOM, String strBaseCodeId, String strBaseCodeName,
			String strBaseCodeType,Environment env,StringBuilder sbCUPGTIN,StringBuilder sbIPGTIN,StringBuilder sbCOPGTIN,
			StringBuilder sbCUPGW,StringBuilder sbIPGW,StringBuilder sbCOPGW,StringBuilder sbCUPLWD,StringBuilder sbIPLWD,StringBuilder sbCOPLWD) 
	{
		
		StringBuilder baseCodeBuilder = new StringBuilder();
		BusExtractUtil busUtil = new BusExtractUtil();
		try {
			Map<String, String> mapObject = new HashMap<>();
			Map<String, String> mapObjectLWD = new HashMap<>();
			
			Map<String, String> mapWeightAttributeInfo = null;
			StringList slWeigth = new StringList(2);
			slWeigth.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			slWeigth.addElement(pgV3Constants.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			String strType= DomainConstants.EMPTY_STRING;
			String strId = DomainConstants.EMPTY_STRING;
			String strDepth = DomainConstants.EMPTY_STRING;
			String strWidth = DomainConstants.EMPTY_STRING;
			String strHeight= DomainConstants.EMPTY_STRING;
			String strGrossWgt = DomainConstants.EMPTY_STRING;
			String strGrossWth = DomainConstants.EMPTY_STRING;
			String strCUPGTIN = DomainConstants.EMPTY_STRING;
			String strIPGTIN = DomainConstants.EMPTY_STRING;
			String strCOPGTIN = DomainConstants.EMPTY_STRING;
			String strCUPLWD = DomainConstants.EMPTY_STRING;
			String strCOPLWD = DomainConstants.EMPTY_STRING;
			String strIPLWD = DomainConstants.EMPTY_STRING;
			String strLWD = DomainConstants.EMPTY_STRING;
			String strGrossWtAndUOM = DomainConstants.EMPTY_STRING;
			String strCUPGrossWtAndUOM = DomainConstants.EMPTY_STRING;
			String strCOPGrossWtAndUOM = DomainConstants.EMPTY_STRING;
			String strIPGrossWtAndUOM = DomainConstants.EMPTY_STRING;
			String pgCSSType =DomainConstants.EMPTY_STRING;
			String sGTIN = DomainConstants.EMPTY_STRING;

			
			if(pgV3Constants.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase(strBaseCodeType)) {
				StringList busSelect = new StringList(7);
				busSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
				busSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGGTIN);
				busSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGDEPTH);
				busSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGWIDTH);
				busSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGHEIGHT);
				busSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGGROSSWEIGHT);
				busSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);

				DomainObject domainObject = DomainObject.newInstance(context,strBaseCodeId);
				MapList mlRelatedObjects = domainObject.getRelatedObjects(context,
						pgV3Constants.RELATIONSHIP_CHARACTERISTIC,
						pgV3Constants.TYPE_PGPACKINGUNITCHARACTERISTIC,
						busSelect,
						null,
						false,
						true,
						(short) 1,
						null,
						null,
						0);
				for (Iterator iterator = mlRelatedObjects.iterator(); iterator.hasNext();)
				{
					mapObject = (Map) iterator.next();
					pgCSSType = (String) mapObject.get(pgV3Constants.SELECT_ATTRIBUTE_PGCSSTYPE);
					strHeight=validateString1(mapObject.get(pgV3Constants.SELECT_ATTRIBUTE_PGHEIGHT));
					strWidth=validateString1(mapObject.get(pgV3Constants.SELECT_ATTRIBUTE_PGWIDTH));
					strDepth=validateString1(mapObject.get(pgV3Constants.SELECT_ATTRIBUTE_PGDEPTH));
					strGrossWgt=validateString1(mapObject.get(pgV3Constants.SELECT_ATTRIBUTE_PGGROSSWEIGHT));
					strGrossWth=validateString1(mapObject.get(pgV3Constants.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
					strLWD=addSymbolStar(strHeight, strWidth, strDepth);
					strGrossWtAndUOM= validateString1(strGrossWgt)+pgV3Constants.SYMBOL_SPACE+validateString1(strGrossWth);
					sGTIN=validateString1(mapObject.get(pgV3Constants.SELECT_ATTRIBUTE_PGGTIN));

					if(pgCSSType.equalsIgnoreCase("Consumer_Unit")){
						strCOPGTIN=sGTIN;
						strCOPLWD=strLWD;
						strCOPGrossWtAndUOM= strGrossWtAndUOM;
						sbCOPGTIN.append(strCOPGTIN);
						sbCOPGW.append(strCOPGrossWtAndUOM);
						sbCOPLWD.append(strCOPLWD);
					}		
					if(pgCSSType.equalsIgnoreCase("Inner_Pack")){
						strIPGTIN=sGTIN;
						strIPLWD=strLWD;
						strIPGrossWtAndUOM= strGrossWtAndUOM;
						sbIPGTIN.append(strIPGTIN);
						sbIPGW.append(strIPGrossWtAndUOM);
						sbIPLWD.append(strIPLWD);
					}
					if(pgCSSType.equalsIgnoreCase("Customer_Unit")){
						strCUPGTIN=sGTIN;
						strCUPLWD=strLWD;
						strCUPGrossWtAndUOM= strGrossWtAndUOM;
						sbCUPGTIN.append(strCUPGTIN);
						sbCUPGW.append(strCUPGrossWtAndUOM);
						sbCUPLWD.append(strCUPLWD);
					}	
				}
			}else {
				int mlBOMsize= mlBOM.size();
				MapList commomML =  new MapList();
				Map argmapGTIN = new HashMap();
				String[] argsFPPGTIN = null;
				String[] argsFPPDM=null;
				StringList slDM = null;
				String strDM = DomainConstants.EMPTY_STRING;
				StringTokenizer stDM = null;
				List<String> vGTIN = new ArrayList();
				Map	mpGTIN =  busUtil.getGTINFromSoapPO(context, strBaseCodeId,strBaseCodeType,strBaseCodeName,env);
				
				MapList mpLWD = null;	
				mpLWD = getPackagingDimensionsforBCD(context, mlBOM);
				
				mlBOM = getBaseCodeGTIN(context,mpGTIN,mlBOM);
				
				//slDM = getPackagingDimensions(context,mlBOM);
				
				for (int j = 0;j< mlBOMsize; j++)
				{
					mapObject = (Map) mlBOM.get(j);
					strType = (String) mapObject.get(DomainConstants.SELECT_TYPE);
					strId = (String)mapObject.get(DomainConstants.SELECT_ID);
					
					String sCUPGTIN = (String)mapObject.get(ConstantsUtil.CUP);
					String sIPGTIN = (String)mapObject.get(ConstantsUtil.IP);
					String sCOPGTIN = (String)mapObject.get(ConstantsUtil.COP);
					
					mapObjectLWD = (Map) mpLWD.get(j);
					
					String sCUPLWD = (String)mapObjectLWD.get(ConstantsUtil.CUP);
					String sIPLWD = (String)mapObjectLWD.get(ConstantsUtil.IP);
					String sCOPLWD = (String)mapObjectLWD.get(ConstantsUtil.COP);
					
					mapWeightAttributeInfo = new HashMap<String , String>();
					DomainObject domainObj= DomainObject.newInstance(context,strId);
					mapWeightAttributeInfo = domainObj.getInfo(context, slWeigth);
					strGrossWgt = (String)mapWeightAttributeInfo.get(pgV3Constants.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
					strGrossWth = (String)mapWeightAttributeInfo.get(pgV3Constants.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
					//strLWD=addSymbolStar(strHeight, strWidth, strDepth);
					strGrossWtAndUOM= validateString1(strGrossWgt)+pgV3Constants.SYMBOL_SPACE+validateString1(strGrossWth);

					if(pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strType)){
						strCUPGTIN = sCUPGTIN;
						strCUPLWD=sCUPLWD;
						strCUPGrossWtAndUOM= strGrossWtAndUOM;
						sbCUPGTIN.append(strCUPGTIN);
						sbCUPGW.append(strCUPGrossWtAndUOM);
						sbCUPLWD.append(strCUPLWD);
					}
					if(pgV3Constants.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(strType)){
						strIPGTIN = sIPGTIN;
						strIPLWD=sIPLWD;
						strIPGrossWtAndUOM= strGrossWtAndUOM;
						sbIPGTIN.append(strIPGTIN);
						sbIPGW.append(strIPGrossWtAndUOM);
						sbIPLWD.append(strIPLWD);
					}
					if(pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strType)){
						strCOPGTIN = sCOPGTIN;
						strCOPLWD=sCOPLWD;
						strCOPGrossWtAndUOM= strGrossWtAndUOM;
						sbCOPGTIN.append(strCOPGTIN);
						sbCOPGW.append(strCOPGrossWtAndUOM);
						sbCOPLWD.append(strCOPLWD);
					}
				}
			}
			
		} catch (Exception e) {
			LOGGER.error("Error in FPPBO : getBaseCodeTableWithData : "+e);
			return ConstantsUtil.EMPTY_STRING;
		}
		return baseCodeBuilder.toString();
	}
	
	
	/**
	 * Check passed StringList object contains valid String
	 * @param obj
	 * @return
	 */
	public static String validateString1(Object obj)
	{
		String strReturn = DomainConstants.EMPTY_STRING;
		String strTestMethod = DomainConstants.EMPTY_STRING;
		
		if(null !=obj && !"null".equals(obj)) {
			if (obj instanceof String) {
				strReturn = (String) obj;
			}
			else if(obj instanceof StringList) {
				StringList listObject = (StringList) obj;
				if(listObject.size()==1){
					strReturn+=(String)listObject.get(0);
				} else{
					for (Iterator iterator2 = listObject.iterator(); iterator2.hasNext();){
						strTestMethod = (String) iterator2.next();
						strReturn+=" "+strTestMethod;
					}
				}
			}
		}
		return strReturn;
	}
	
	
	/**
	 * Helper method to Add STAR(*) between three values 
	 * @param String  -  height
	 * @param String  -  width
	 * @param String  -  depth
	 * @return String  - h*w*d
	 */
	public static String addSymbolStar(String height,String width, String depth) {
		if (UIUtil.isNotNullAndNotEmpty(height) && (UIUtil.isNotNullAndNotEmpty(width) || UIUtil.isNotNullAndNotEmpty(depth))) {
			height = height+pgV3Constants.SYMBOL_STAR;
		}else if(UIUtil.isNotNullAndNotEmpty(height)){
			height = height;
		}
		if(UIUtil.isNotNullAndNotEmpty(width) && UIUtil.isNotNullAndNotEmpty(depth)) {
			width = width+pgV3Constants.SYMBOL_STAR;
		}else if(UIUtil.isNotNullAndNotEmpty(width)){
			width = width;
		}
		return height+width+depth;
	}
	
	
	/**
	 * Method Name : getPackagingDimensions
	 * Method Description :
	 * @param context
	 * @param mlObjectList
	 * @return
	 * @throws Exception
	 */
	public StringList getPackagingDimensions(Context context,MapList mlObjectList) throws Exception 
	{
		StringList slReturnVal = new StringList();
		
		try{

			String sAttrName = PropertyUtil.getSchemaProperty(context,"");
			String sDepthVal = "";
			String strReportFormat ="CSV";
			String sWidthVal = "";
			String sHeightVal = "";
			String sDimUoMVal = "";
            String sConnectionId="";
            String sConn="";
            String strResult="";

			Iterator objListItr = mlObjectList.iterator();
			while (objListItr.hasNext()) 
			{
				Map perMap = (Map) objListItr.next();
				String sObjectId = (String)perMap.get(DomainConstants.SELECT_ID);
				String sType = (String)perMap.get(DomainConstants.SELECT_TYPE);
				if(sType != null && !"".equals(sType)){
                if(sObjectId != null && !"".equals(sObjectId))
                {
                    sConn="";
                    sDepthVal = "";
                    sWidthVal = "";
                    sHeightVal = "";

						String sMQLStmt = "print connection $1 select $2 dump $3;";
						DomainObject bomObject = DomainObject.newInstance(context,sObjectId);
                    StringList sConnList = bomObject.getInfoList(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM+"].id");
                    for(int i=0;i<sConnList.size();i++)
                    {
                        sConnectionId=(String)sConnList.get(i);

                        String querycommand="print connection"+" "+"\"$1\""+" "+ "select $2 dump  $3";

                        strResult=MqlUtil.mqlCommand(context,querycommand,sConnectionId,"frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"]","|").trim();

                        if(strResult.equalsIgnoreCase("True"))
                        {
                            sConn=sConnectionId;
                            break;
                        }
                        else
                        {
                            continue;
                        }

                    }
                    
					String sSelectable1 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_LENGTH+"].value";
					String sSelectable2 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_WIDTH+"].value";
					String sSelectable3 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_OUTERDIMENSIONHEIGHT+"].value";
					String sSelectable4 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_DIMENSTION_UOM+"].value";
					
					String tempVal = new String();		
					
                    if(sConn != null && !"".equals(sConn))
                    {
							sDepthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable1, "|");
							sWidthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable2, "|");
							sHeightVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable3, "|");
							if (sDepthVal == null || "".equals(sDepthVal)){
								sDepthVal = "0.0";
							}
							if (sWidthVal == null || "".equals(sWidthVal)){
								sWidthVal = "0.0";
							}

							if (sHeightVal == null || "".equals(sHeightVal)){
								sHeightVal = "0.0";
							}

							if(sAttrName != null && !"".equals(sAttrName) && sAttrName.equals(ConstantsUtil.ATTRIBUTE_PG_DIMENSTION_UOM)){
								sDimUoMVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable4, "|");
								tempVal = new String(sDimUoMVal);
							} else {
								if(( strReportFormat != null || strReportFormat != "") && ("CSV".equalsIgnoreCase(strReportFormat))){
									tempVal = new String(sDepthVal+"|"+sWidthVal+"|"+sHeightVal);
								}								
								else {
									tempVal = new String(sDepthVal+"|"+sWidthVal+"|"+sHeightVal);
								}
							}
						} else {
							sDepthVal = "0.0";
							sWidthVal = "0.0";
							sHeightVal = "0.0";
							sDimUoMVal = "";
							
							if(sAttrName != null && !"".equals(sAttrName) && sAttrName.equals(ConstantsUtil.ATTRIBUTE_PG_DIMENSTION_UOM)){
								tempVal = new String(sDimUoMVal);
							} else {
								if(( strReportFormat != null || strReportFormat != "") && ("CSV".equalsIgnoreCase(strReportFormat))){
									tempVal = new String(sDepthVal+"|"+sWidthVal+"|"+sHeightVal);
								}								
								else {
									tempVal = new String(sDepthVal+"|"+sWidthVal+"|"+sHeightVal);
								}	
							}
						}
						slReturnVal.addElement(tempVal);
					}
				} else {
					slReturnVal.addElement("");
				}
			}
		} catch(Exception e){
			LOGGER.error("Error in FPPBO :getPackagingDimensions : "+e);
			return new StringList();
		}
		return slReturnVal;
	}
	
	
	/**
	 * Method Name : getPackagingDimensionsforBCD
	 * Method Description : 
	 * @param context
	 * @param mlObjectList
	 * @return
	 * @throws Exception
	 */
	public MapList getPackagingDimensionsforBCD(Context context, MapList mlObjectList) throws Exception {
		
		StringBuilder sbCOPLWD = new StringBuilder();
		StringBuilder sbCUPLWD = new StringBuilder();
		StringBuilder sbIPLWD = new StringBuilder();
		
		MapList mlLWD = new MapList();
		
		Map<String, String> mpPackingUnit = new HashMap();

		try
		{

			String  sAttrName = "";
			String  strReportFormat = "";
			String sDepthVal = "";
			String sWidthVal = "";
			String sHeightVal = "";
			String sDimUoMVal = "";
			String sConnectionId="";
			String sConn="";
			String strResult="";

			BusExtractUtil utill = new BusExtractUtil();
			
			Iterator objListItr = mlObjectList.iterator();
			while (objListItr.hasNext()) {

				Map perMap = (Map) objListItr.next();
				String sObjectId = (String)perMap.get(DomainConstants.SELECT_ID);
				String sType = (String)perMap.get(DomainConstants.SELECT_TYPE);

				if(sType != null && !"".equals(sType))
				{
					if(sObjectId != null && !"".equals(sObjectId))
					{
						sConn="";
						sDepthVal = "";
						sWidthVal = "";
						sHeightVal = "";

						String sMQLStmt = "print connection $1 select $2 dump $3;";
						DomainObject bomObject = DomainObject.newInstance(context,sObjectId);
						StringList sConnList = bomObject.getInfoList(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM+"].id");
						for(int i=0;i<sConnList.size();i++)
						{
							sConnectionId=(String)sConnList.get(i);
							String querycommand="print connection"+" "+"\"$1\""+" "+ "select $2 dump  $3";
							strResult=MqlUtil.mqlCommand(context,querycommand,sConnectionId,"frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"]","|").trim();

							if(strResult.equalsIgnoreCase("True"))
							{
								sConn=sConnectionId;
								break;
							}
							else
							{
								continue;
							}
						}

						String sSelectable1 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_LENGTH+"].value";
						String sSelectable2 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTR_OUTER_DIMENSION_WIDTH+"].value";
						String sSelectable3 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_OUTERDIMENSIONHEIGHT+"].value";
						String sSelectable4 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.ATTRIBUTE_PG_DIMENSTION_UOM+"].value";
						String sSelectable5 = "frommid["+ConstantsUtil.REL_PARTFAMILYREFERENCE+"].torel.to.attribute["+ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT+"].value";

						String tempVal = new String();						
						if(sConn != null && !"".equals(sConn))
						{

							sDepthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable1, "|");
							sWidthVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable2, "|");
							sHeightVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable3, "|");
							sDimUoMVal  = MqlUtil.mqlCommand(context, sMQLStmt, sConn, sSelectable4, "|");
							
							if (sDepthVal == null || "".equals(sDepthVal)){

								sDepthVal = "0.0";

							}
							if (sWidthVal == null || "".equals(sWidthVal)){

								sWidthVal = "0.0";

							}
							if (sHeightVal == null || "".equals(sHeightVal)){

								sHeightVal = "0.0";

							}
							
							if (pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(sType)) {
								sbCUPLWD.append(sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							if (pgV3Constants.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(sType)) {
								sbIPLWD.append(sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							if (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(sType)) {
								sbCOPLWD.append(sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							
							mpPackingUnit.put(ConstantsUtil.CUP, sbCUPLWD.toString());
							mpPackingUnit.put(ConstantsUtil.IP, sbIPLWD.toString());
							mpPackingUnit.put(ConstantsUtil.COP, sbCOPLWD.toString());
							mlLWD.add(mpPackingUnit);

						} else 
						{
							sDepthVal = "0.0";
							sWidthVal = "0.0";
							sHeightVal = "0.0";
							sDimUoMVal = "";

							
							if (pgV3Constants.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(sType)) {
								sbCUPLWD.append(sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							if (pgV3Constants.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(sType)) {
								sbIPLWD.append(sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							if (pgV3Constants.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(sType)) {
								sbCOPLWD.append(sHeightVal+ConstantsUtil.SYMBL_ASTERISK+sWidthVal+ConstantsUtil.SYMBL_ASTERISK+sDepthVal);
							}
							
							mpPackingUnit.put(ConstantsUtil.CUP, sbCUPLWD.toString());
							mpPackingUnit.put(ConstantsUtil.IP, sbIPLWD.toString());
							mpPackingUnit.put(ConstantsUtil.COP, sbCOPLWD.toString());
							mlLWD.add(mpPackingUnit);
						}
					}
				}
			}
		} catch(Exception e){
			LOGGER.error("Error in FPPBO: getPackagingDimensionsforBCD : "+e);
			return new MapList();
		}
		
		return mlLWD;

	}
	//SPEC: Release SR18x.6.0 - Added by Amman on Apr 20, 2021 for Defect 42162 -- END
	
	
	//SPEC: Release SR18x.6.0.1 - Added by Amman on Apr 26, 2021 for Defect raised by Internal Testing Team -- START
	/**
	 * Method Name : getTopLevelObjectforFPP
	 * Method Description : used to get GCAS objects from first level of APP, DPP and FOP for in FPP
	 * @return String - Returns MapList for GCAS objects 
	 * @throws Exception
	 */	
	public MapList getTopLevelObjectforFPP(Context context, String sObjectId) throws Exception
	{   
		DomainObject doObj = null;
		Map mpIntermediate = null;
		MapList mlGCASObjects = new MapList();
		MapList mlTopLevelObjects = null;
		try
		{
			Pattern pIntermediateObjectType = new Pattern(pgV3Constants.TYPE_PGCONSUMERUNITPART);
			pIntermediateObjectType.addPattern(pgV3Constants.TYPE_PGCUSTOMERUNITPART);
			pIntermediateObjectType.addPattern(pgV3Constants.TYPE_PGINNERPACKUNITPART);
			Pattern pUFIObjectType = new Pattern(pgV3Constants.TYPE_ASSEMBLEDPRODUCTPART);
			pUFIObjectType.addPattern(pgV3Constants.TYPE_DEVICEPRODUCTPART);
			pUFIObjectType.addPattern(pgV3Constants.TYPE_FORMULATIONPART);
			if(UIUtil.isNotNullAndNotEmpty(sObjectId))
			{
				doObj = DomainObject.newInstance(context, sObjectId);
				StringList slObjSelect = new StringList(2);
				slObjSelect.add(pgV3Constants.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER);
				slObjSelect.add(DomainConstants.SELECT_ID);
				slObjSelect.add(DomainConstants.SELECT_NAME);
				//Gets all the IntermediateChildData list connected to the context part.
				MapList mlIntermediateChildData = doObj.getRelatedObjects(context,
						pgV3Constants.RELATIONSHIP_EBOM,       // rel pattern
						pIntermediateObjectType.getPattern(),  // type pattern
						slObjSelect,                          // object selects
						null,           					//  rel selects 
						false,                             // to side
						true,                              // from side
						(short)0,                          //  recursion level
						null,                       // object where clause
						null,0);       
				Iterator mlIterator = mlIntermediateChildData.iterator();

				while(mlIterator.hasNext())
				{
					mpIntermediate=(Map)mlIterator.next();
					String strIntermediateId = (String)mpIntermediate.get(DomainConstants.SELECT_ID);
					if(UIUtil.isNotNullAndNotEmpty(strIntermediateId)){						
						DomainObject doIntermediateObj = DomainObject.newInstance(context, strIntermediateId);
						// Gets all top level APP, DPP & FOP connected to FPP BOM
						mlTopLevelObjects = doIntermediateObj.getRelatedObjects(context,
								pgV3Constants.RELATIONSHIP_EBOM,   // rel pattern
								pUFIObjectType.getPattern(),       // type pattern
								slObjSelect,                       // object selects
								null,                              //  rel selects 
								false,                             // to side
								true,                              // from side
								(short)1,                          //  recursion level
								null,                       // object where clause
								null,0);   
						mlGCASObjects.addAll(mlTopLevelObjects);
					}
				}
			}	
		} catch(Exception ex) {
			LOGGER.error("Error in FPPBO: getTopLevelObjectforFPP : "+ex);
			return new MapList();
		}
		return mlGCASObjects;
	}	


	/**
	 * Method Name : getUniqueFormulaIdentifierforFPP
	 * Method Description : used to get UniqueFormulaIdentifier attribute values from first level of APP, DPP and FOP and gets the values displayed in FPP
	 * @return String - Returns multiple UFI values separated by comma
	 * @throws Exception
	 */
	public String getUniqueFormulaIdentifierforFPP(Context context, String sObjectId) throws Exception
	{ 
		String strUFIforChild = DomainConstants.EMPTY_STRING;
		String strUFIforFPP = DomainConstants.EMPTY_STRING;
		MapList mlGCASObjects = getTopLevelObjectforFPP(context, sObjectId);
		Map mpObjMap = null;
		try
		{
			if(!mlGCASObjects.isEmpty()){

				Iterator mlObjIterator = mlGCASObjects.iterator();

				while(mlObjIterator.hasNext())
				{
					mpObjMap=(Map)mlObjIterator.next();
					strUFIforChild = (String)mpObjMap.get(pgV3Constants.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER);

					if(UIUtil.isNullOrEmpty(strUFIforFPP))
					{
						strUFIforFPP += strUFIforChild; 

					}
					else
					{	
						strUFIforFPP += ", " + strUFIforChild; //Appends multiple values for FPP separated by comma.
					}
				}
			}
		} catch(Exception ex) {
			LOGGER.error("Error in FPPBO: getUniqueFormulaIdentifierforFPP : "+ex);
			return ConstantsUtil.EMPTY_STRING;
		}
		return strUFIforFPP;
	}
	//SPEC: Release SR18x.6.0.1 - Added by Amman on Apr 26, 2021 for Defect raised by Internal Testing Team -- END
	
	
	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 24, 2021 for Defect #43804 -- START
	/**
	 * Method Name : getTransportUnitDetails
	 * Method Description : to fetch the Transport Unit Details for External Users
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getTransportUnitDetails(Context context,Map resultMaps)
	{
		Map mpTransportUnit = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();	
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		StringBuilder sbPalletType = new StringBuilder();
		StringBuilder sbOutDimDepth = new StringBuilder();
		StringBuilder sbOutDimWidth = new StringBuilder();
		StringBuilder sbOutDimHght = new StringBuilder();
		StringBuilder sbOutDimUOM = new StringBuilder();
		StringBuilder sbTUP_VOLUME = new StringBuilder();
		StringBuilder sbITUP_UOM = new StringBuilder();
		StringBuilder sbGW_WITH_Pallet = new StringBuilder();
		StringBuilder sbGW_WITHout_Pallet = new StringBuilder();
		StringBuilder sbGW_UOM = new StringBuilder();
		StringBuilder sbCustomlayerperTup = new StringBuilder();
		StringBuilder sblayerperTup = new StringBuilder();
		StringBuilder sbCUPPerTUp = new StringBuilder();
		StringBuilder sbcubeEff = new StringBuilder();
		StringBuilder sbPalletMXhgt = new StringBuilder();
		StringBuilder sbCASMaxHGt = new StringBuilder();
		StringBuilder sbTruckMXHGT = new StringBuilder();
		StringBuilder sbStackPattern = new StringBuilder();
		StringBuilder sbStackPatternId = new StringBuilder();
		StringBuilder sbStackPatternType = new StringBuilder();
		StringBuilder sbGTIN = new StringBuilder();

		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		String sComp = sct.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);

		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		try
		{
			String strContextId = (String)resultMaps.get(ConstantsUtil.SELECT_ID);

			DomainObject doTU = new DomainObject(strContextId);

			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDEPTH);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWIDTH);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHEIGHT);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUNITOFMEASURE);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEUNITOFMEASURE);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLET);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLET);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CUSTOM_UNITS_PER_LAYER);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_LAYERS_PER_TUP);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CUP_PER_TUP);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFECIENCY);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PALLET_STACK_MAX_HEIGHT);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASE_STACK_MAX_HEIGHT);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TRUCK_STACK_MAX_HEIGHT);
			slBusSelects.add(ConstantsUtil.SELECT_REF_DOC_TONAME);
			slBusSelects.add(ConstantsUtil.SELECT_REF_DOC_TO_ID);
			slBusSelects.add(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
			slBusSelects.add(ConstantsUtilIRM.SELECT_REF_DOC_TOCURRENT);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN);
			
			MapList mlTUList = doTU.getRelatedObjects(context, "Extended Data",
					ConstantsUtil.TYPE_PGTRANSPORTUNITCHARACTERISTIC, slBusSelects, null, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doTU.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			mlTUList.sort(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
			
			Iterator objectListItr = mlTUList.iterator();

			while(objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				
				String strPalletType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE));
				String strOutDimDepth = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDEPTH));
				String strOutDimWidth = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWIDTH));
				String strOutDimHght = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEIGHT));
				String strOutDimUOM = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUNITOFMEASURE));
				String strTUP_VOLUME = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUME));
				String strITUP_UOM = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEUNITOFMEASURE));
				String strGW_WITH_Pallet = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLET));
				String strGW_WITHout_Pallet = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLET));
				String strGW_UOM = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
				String strCustomlayerperTup= validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CUSTOM_UNITS_PER_LAYER));
				String strlayerperTup = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LAYERS_PER_TUP));
				String strCUPPerTUp = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CUP_PER_TUP));
				String strcubeEff = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFECIENCY));
				String strPalletMXhgt = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PALLET_STACK_MAX_HEIGHT));
				String strCASMaxHGt = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASE_STACK_MAX_HEIGHT));
				String strTruckMXHGT = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TRUCK_STACK_MAX_HEIGHT));
				String strStackPattern = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME));
				String strStackPatternId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID));
				String strStackPatternType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE));
				String strStackPatternState = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtilIRM.SELECT_REF_DOC_TOCURRENT));
				String strGTIN = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGTIN));
				
				boolean bHasOwnership = false;
				boolean showData = false;

				if(util.isModificatinRequired()) {
					bHasOwnership=util.checkHasAccess(context, null, strStackPatternId);
					if(!bHasOwnership) {
						strStackPatternId = ConstantsUtil.NO_ACCESS;
					}
					if (!ConstantsUtil.RELEASED.equalsIgnoreCase(strStackPatternState)
							&& !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strStackPatternState))) {
						strStackPatternId = ConstantsUtil.NO_ACCESS;
					}
				}else if(sct.isStaffAUGUser()) {
					showData=util.checkHasAccess(context, null,strStackPatternId);
					if(!showData) {
						strStackPatternId = ConstantsUtil.NO_ACCESS;
					}
				}else {
					showData=util.checkHasAccess(context, null,strStackPatternId);
					if(!showData) {
						strStackPatternId = ConstantsUtil.NO_ACCESS;
					}
				}

				formatData(sbPalletType, strPalletType);
				formatData(sbOutDimDepth, strOutDimDepth);
				formatData(sbOutDimWidth, strOutDimWidth);
				formatData(sbOutDimHght, strOutDimHght);
				formatData(sbOutDimUOM, strOutDimUOM);
				formatData(sbTUP_VOLUME, strTUP_VOLUME);
				formatData(sbITUP_UOM, strITUP_UOM);
				formatData(sbGW_WITH_Pallet, strGW_WITH_Pallet);
				formatData(sbGW_WITHout_Pallet, strGW_WITHout_Pallet);
				formatData(sbGW_UOM, strGW_UOM);
				formatData(sbCustomlayerperTup, strCustomlayerperTup);
				formatData(sblayerperTup, strlayerperTup);
				formatData(sbCUPPerTUp, strCUPPerTUp);
				formatData(sbcubeEff, strcubeEff);
				formatData(sbPalletMXhgt, strPalletMXhgt);
				formatData(sbCASMaxHGt, strCASMaxHGt);
				formatData(sbTruckMXHGT, strTruckMXHGT);
				formatData(sbStackPattern, strStackPattern);
				formatData(sbStackPatternId, strStackPatternId);
				formatData(sbStackPatternType, strStackPatternType);
				formatData(sbGTIN, strGTIN);
			}
		
			mpTransportUnit.put(ConstantsUtil.PALLETTYPE,sbPalletType);
			mpTransportUnit.put(ConstantsUtil.GTIN,sbGTIN);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERLAYER,sbCustomlayerperTup);
			mpTransportUnit.put(ConstantsUtil.DEPTH,sbOutDimDepth);
			mpTransportUnit.put(ConstantsUtil.WIDTH,sbOutDimWidth);
			mpTransportUnit.put(ConstantsUtil.HEIGHT,sbOutDimHght);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFLAYERSPERTRANSPORTUNIT,sblayerperTup);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERTRANSPORTUNIT,sbCUPPerTUp);
			mpTransportUnit.put(ConstantsUtil.DIMENSIONUNITOFMEASURE, sbOutDimUOM);
			mpTransportUnit.put(ConstantsUtil.TUPUOM, sbITUP_UOM);
			mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE1, sbGW_UOM);
			mpTransportUnit.put(ConstantsUtil.TUPVOLUME,sbTUP_VOLUME);
			mpTransportUnit.put(ConstantsUtil.CUBEEFFICIENCY,sbcubeEff);
			mpTransportUnit.put(ConstantsUtil.WAREHOUSEPALLETSTACKHEIGHTMAXIMUM,sbPalletMXhgt);
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHPALLET,sbGW_WITH_Pallet);
			mpTransportUnit.put(ConstantsUtil.WAREHOUSECASESTACKHEIGHTMAXIMUM,sbCASMaxHGt);
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHOUTPALLET,sbGW_WITHout_Pallet);
			mpTransportUnit.put(ConstantsUtil.TRUCKPALLETSTACKHEIGHTMAXIMUM,sbTruckMXHGT);
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODE,sbStackPattern);
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODEID,sbStackPatternId);
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODETYPE,sbStackPatternType);
			
		}catch(Exception e){
			LOGGER.error("Error from FPPBO:  getTransportUnitDetails"+e);
			return new HashMap();
		}
		return mpTransportUnit;
	}
	//SPEC: Release SR18x.6.0.1 - Added by Amman on June 12, 2021 for Defect #43804 -- END

	//SPEC: <12.11.2021>: Guna Added for  Defect 45692 18x.6.0.2   -- START
	/**
	 * Method Name : getExcludedSharedTable
	 * Method Description : TO Exclude Shared table data
	 * @param context
	 * @param maplist
	 * @return
	 */
	public MapList getExcludedSharedTable(Context context, MapList mlPerformChar) {
		// TODO Auto-generated method stub
		 MapList outputList = new MapList();
		try {
		if(mlPerformChar.size() !=0){
		Iterator sharedmapItr = mlPerformChar.iterator();
		HashMap sharedmap = new HashMap();
		while(sharedmapItr.hasNext()){
			Map perMap = (Map) sharedmapItr.next();
			String mapType = (String)perMap.get(ConstantsUtil.SELECT_TYPE);
			String tableSeqNo = (String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
			String tabName = (String)perMap.get("name");
       if(UIUtil.isNotNullAndNotEmpty(mapType)){
			if(mapType.equals(ConstantsUtil.TYPE_SHARED_TABLE)){
				Vector charList = new Vector();
				charList.add(tableSeqNo);
				charList.add(perMap);
				sharedmap.put(tabName, charList);
			}
			}

		}
		
       StringList tabList  = new StringList();

		Set sharedTabNames  = new HashSet(); 

		sharedTabNames.addAll(sharedmap.keySet());

		Integer sortNo = 0;

		Iterator objListItr = mlPerformChar.iterator();

		while (objListItr.hasNext()) {

			Map perMap = (Map) objListItr.next();
			String seq = (String) perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);

			if(!"".equals(seq) && seq != null){
			sortNo = Integer.parseInt(seq) * 100;
			}
			perMap.put("sortNo", ""+sortNo);
			String relation = (String)perMap.get("relationship");
			if(UIUtil.isNotNullAndNotEmpty(relation)){
			if(relation.equals(ConstantsUtil.RELATIONSHIP_SHAREDCHARACTERISTIC)){
				String tableName = (String)perMap.get("from.name");

				Vector charList = (Vector)sharedmap.get(tableName);
				String tabSeqNo="0";

				if(charList!=null&&!charList.isEmpty()){

				tabSeqNo  = (String)charList.get(0);

				}

				if((sharedTabNames.contains(tableName))&&(null!=tabSeqNo)&&(!tabSeqNo.isEmpty())){

					sharedTabNames.remove(tableName);	
				}

				}
			if(!relation.equals("Shared Table")){
	               outputList.add(perMap);
				}
			}
		}
		//this code is to add empty shared tables which dont have any performance characteristics attached 
		for (Iterator emptySharedTableItr = sharedTabNames.iterator(); emptySharedTableItr.hasNext();) {

			String tableName = (String) emptySharedTableItr.next();
			Vector charList = (Vector)sharedmap.get(tableName);
			String tabSeqNo="0";

			if(charList!=null&&!charList.isEmpty()){

			tabSeqNo  = (String)charList.get(0);

			}

			Map perMap = (Map)charList.get(1);

			 outputList.add(perMap);

		}
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error from FPPBO:  getExcludedSharedTable"+e);
			// TODO: handle exception
		}
		return outputList;
	}
	//SPEC: <12.11.2021>: Guna Added for  Defect 45692 18x.6.0.2   -- END

	//SPEC: <02.05.2022>: Guna Added for Req 43515 22x Release  -- START
	/**
	 * Method Name : getATSFromBOM
	 * Method Description : TO get HAS Ats value
	 * @param context
	 * @param doFPP 
	 * @param maplist
	 * @return
	 */
	public String getATSFromBOM(Context context, DomainObject doFPP) {
		String hasATS =ConstantsUtil.EMPTY_STRING;          
		
		try {
			MapList mlBOMs = doFPP.getRelatedObjects(context, //MatrixContext
					ConstantsUtil.RELATIONSHIP_EBOM, //relationshipPattern
					ConstantsUtilIRM.TYPESELECTS, //typePattern
					getBomBusSelect(context), //objectSelects
					getBomRelSelect(context), //relationshipSelects
					false, //getTo
					true,  //getFrom
					(short)0, //recurseToLevel
					ConstantsUtil.EMPTY_STRING, //objectWhere 
					ConstantsUtil.EMPTY_STRING, //relationshipWhere
					0); //limit
			boolean isFab =false;
			String strFab =ConstantsUtil.EMPTY_STRING;
			String hasATSBom =ConstantsUtil.EMPTY_STRING;
			String hasATSAlt =ConstantsUtil.EMPTY_STRING;
			String hasATSSub =ConstantsUtil.EMPTY_STRING;
			String ebomType =ConstantsUtil.EMPTY_STRING;
			for(int i =0; i<mlBOMs.size(); i++)
			{
				Map objectMap  = (Map) mlBOMs.get(i);
				StringList pIdList = validatorUtil.getStringListEquivalentForString(objectMap.get(DomainConstants.SELECT_ID));
				StringList pTypeList = validatorUtil.getStringListEquivalentForString(objectMap.get(DomainConstants.SELECT_TYPE));
				StringList altIDList =validatorUtil.getStringListEquivalentForString(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID));
				StringList altType =validatorUtil.getStringListEquivalentForString(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
				StringList subList =validatorUtil.getStringListEquivalentForString(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
				StringList subType =validatorUtil.getStringListEquivalentForString(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				if(strFab.equals(validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME))) && isFab ) {
				 hasATSBom =checkHasATS(context,pIdList,pTypeList);
				 hasATSAlt =checkHasATSForAltSub(context,altIDList,altType);
				 hasATSSub =checkHasATSForAltSub(context,subList,subType);
				 ebomType =validatorUtil.getStringEquivalentForSubstituteString(pTypeList);
				if(ConstantsUtil.TYPE_FABRICATEDPART.equals(ebomType) && ConstantsUtil.SYMBL_CAPTRUE.equals(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED)) && !hasATSBom.equals(ConstantsUtil.SYMBL_YES) ) {
					isFab =true;
					strFab = validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.SELECT_NAME));
				}
				else if(ConstantsUtil.TYPE_FABRICATEDPART.equals(ebomType) && ConstantsUtil.SYMBL_CAPFALSE.equals(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED))) {
					isFab =false;
					strFab = validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.SELECT_NAME));
				}else {
					isFab =false;
					strFab = ConstantsUtil.EMPTY_STRING;
				}
				if(hasATSBom.equals(ConstantsUtil.SYMBL_YES) || hasATSAlt.equals(ConstantsUtil.SYMBL_YES) || hasATSSub.equals(ConstantsUtil.SYMBL_YES)) {
					hasATS =ConstantsUtil.SYMBL_YES;
					break;
				}
				}else if(!strFab.equals(validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME))) && !isFab) {
					hasATSBom =checkHasATS(context,pIdList,pTypeList);
					 hasATSAlt =checkHasATSForAltSub(context,altIDList,altType);
					 hasATSSub =checkHasATSForAltSub(context,subList,subType);
					 ebomType =validatorUtil.getStringEquivalentForSubstituteString(pTypeList);
						if(ConstantsUtil.TYPE_FABRICATEDPART.equals(ebomType) && ConstantsUtil.SYMBL_CAPTRUE.equals(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED)) && !hasATSBom.equals(ConstantsUtil.SYMBL_YES) ) {
							isFab =true;
							strFab = validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.SELECT_NAME));
						}else if(ConstantsUtil.TYPE_FABRICATEDPART.equals(ebomType) && ConstantsUtil.SYMBL_CAPFALSE.equals(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED)) ) {
							isFab =false;
							strFab = validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.SELECT_NAME));
						}
						else {
							strFab = ConstantsUtil.EMPTY_STRING;
						}
					 if(hasATSBom.equals(ConstantsUtil.SYMBL_YES) || hasATSAlt.equals(ConstantsUtil.SYMBL_YES) || hasATSSub.equals(ConstantsUtil.SYMBL_YES)) {
							hasATS =ConstantsUtil.SYMBL_YES;
							break;
						}
				}else if(strFab.equals(validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME))) && !isFab) {
					continue;
				}
				
			}
		} catch (Exception e) {
			LOGGER.error("Error from FPPBO:  getATSFromBOM"+e);
		}
		return hasATS;
	}

	/**
	 * Method Name : checkHasATS
	 * Method Description : TO Check HAS Ats value
	 * @param context
	 * @param altType 
	 * @param StringList
	 * @return
	 */
	public String checkHasATS(Context context, StringList pIdList, StringList altType) {
		String sHasATSAttrVal =ConstantsUtil.EMPTY_STRING;
		try {
			if(!pIdList.isEmpty())
			{
				StringList busSelect = new StringList();
				busSelect.add(DomainConstants.SELECT_NAME);
				busSelect.add(DomainConstants.SELECT_ID);
				busSelect.add(DomainConstants.SELECT_TYPE);
				busSelect.add(DomainConstants.SELECT_CURRENT);
				for(int t=0;t<pIdList.size();t++) {
				MapList atsMapList =getConnetedATS(context,pIdList.get(t),busSelect);	
				if(!atsMapList.isEmpty()) {
				Iterator itr = atsMapList.iterator();
				while (itr.hasNext()) {
					Map atsMap =(Map) itr.next();
					String strATSState = (String) atsMap.get(DomainConstants.SELECT_CURRENT);
					if (ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strATSState)) {
						sHasATSAttrVal = ConstantsUtil.SYMBL_YES; 
						break;
					} 
				}
				}
			}
			}
		} catch (Exception e) {
			LOGGER.error("Error from FPPBO:  checkHasATS"+e);
		}
		return sHasATSAttrVal;
	}
	/**
	 * Method Name : checkHasATS
	 * Method Description : To get connected ATS values
	 * @param context
	 * @param Sting StringList
	 * @return
	 */
	public MapList getConnetedATS(Context context, String objId, StringList busSelect) {
		MapList rtnList =new MapList();
		try {
			DomainObject doObj= DomainObject.newInstance(context, objId);
			rtnList = doObj.getRelatedObjects
			 			(context, //MatrixContex
			 			ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION, //relationshipPattern
			 			ConstantsUtil.SYMBL_ASTERISK, //typePattern
			 			busSelect, //objectSelects
					 	DomainConstants.EMPTY_STRINGLIST, //relationshipSelects
					 	true, //getTo
					 	false, //getFrom
					 	(short) 1, //recurseToLevel
					 	ConstantsUtil.EMPTY_STRING, //objectWhere
					 	ConstantsUtil.EMPTY_STRING, //relationshipWhere
					 	ConstantsUtil.ZERO_LEVEL); //limit
			 
		}
	 catch (Exception e) {
			LOGGER.error("Error from FPPBO:  getConnetedATS"+e);
		}
		
		return rtnList;
	}
	//SPEC: <02.05.2022>: Guna Added for Req 43515 22x Release  -- END

	//SPEC: <07.06.2022>: Guna Added for req 41754 22x Release  -- START
	/**
	 * Method Name : getPackagingCertData
	 * Method Description : To get the connected Packaging certifications
	 * @param context
	 * @param Sting String
	 * @return
	 */
	public Map<String, String> getPackagingCertData(Context context, String objId, String sName, String sType, String sUserType) {
		MapList objectList = new MapList();
		Map pkgCertMap =new HashMap<>();
	    try {
	    	StringBuilder sbName = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbRelType = new StringBuilder();
			StringBuilder sbCertSourceId = new StringBuilder();
			StringBuilder sbCertSourceType = new StringBuilder();
			StringBuilder sbCertSourceName = new StringBuilder();
			StringBuilder sbCertName = new StringBuilder();
			StringBuilder sbCertComments = new StringBuilder();
			StringBuilder sbExpDate = new StringBuilder();
			StringBuilder sbDocsName = new StringBuilder();
			StringBuilder sbDocsType = new StringBuilder();
			StringBuilder sbDocsId = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
	      Pattern relPattern = new Pattern(ConstantsUtilIRM.RELATIONSHIP_ROLLED_UP_PACKAGING_MATERIAL_CERTIFICATIONS);
	      Pattern typePattern = new Pattern(ConstantsUtilIRM.TYPE_PG_PLI_PACKAGING_MATERIAL_CERTIFICATION);
	      StringList busSelects = new StringList(4);
	      busSelects.add(DomainConstants.SELECT_ID);
	      busSelects.add(DomainConstants.SELECT_NAME);
	      busSelects.add(DomainConstants.SELECT_TYPE);
	      busSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
	      StringList relSelects = new StringList(10);
	      relSelects.add(ConstantsUtil.SELECT_CONNECTION_ID);
	      relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
	      relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
	      relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ROLLUP_SOURCE_ID);
	      relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ROLLUP_SOURCE_IDENTIFIER);
	      relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ROLLUP_SOURCE_REL_TYPE);
	      relSelects.add(ConstantsUtilIRM.SELECT_ROLLED_UP_CERTIFICATION_DOCUMENT_ID);
	      
	      DomainObject domainObject = DomainObject.newInstance(context, objId);
	      
	      objectList =   domainObject.getRelatedObjects
		    (context, //MatrixContex
		   relPattern.getPattern(), //relationshipPattern
		   typePattern.getPattern(), //typePattern
		   busSelects, //objectSelects
		   relSelects, //relationshipSelects
		 	false, //getTo
		 	true, //getFrom
		 	(short) 1, //recurseToLevel
		 	ConstantsUtil.EMPTY_STRING, //objectWhere
		 	ConstantsUtil.EMPTY_STRING, //relationshipWhere
		 	ConstantsUtil.ZERO_LEVEL); //limit
	      
	      if(!objectList.isEmpty()) {
	    	  for(int j=0;j<objectList.size();j++) {
	    		  Map mpCert =(Map) objectList.get(j);
	    		  Map mpSource =new HashMap();
	    		  Map mpCertDocs =new HashMap();
	    		  String sourceId =(String)mpCert.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ROLLUP_SOURCE_ID);
	    		  StringList docsList =validatorUtil.getStringListEquivalentForString(mpCert.get(ConstantsUtilIRM.SELECT_ROLLED_UP_CERTIFICATION_DOCUMENT_ID));
	    		  if (UIUtil.isNotNullAndNotEmpty(sourceId)) {
	    			  mpSource =getSourcePartInfo(context, sourceId);
	    		  }
	    		  if(!docsList.isEmpty()) {
	    			  mpCertDocs =getCertificationDocs(context, docsList);
	    		  }
	    		 
	    		  if(!mpSource.isEmpty()) {
	    			 String strCurrent =(String) mpSource.get(DomainConstants.SELECT_CURRENT);
	    			 String strCertId =(String) mpSource.get(DomainConstants.SELECT_ID);
	    			 boolean showData =util.checkHasAccess(context, sUserType, strCertId);
	    			//SPEC: <14.07.2022>: Modified Added for req 41754 22x Release  -- START
	    			 if((!strCurrent.equals(ConstantsUtil.STATE_RELEASE) && !strCurrent.equals(ConstantsUtil.RELEASED) && !strCurrent.equals(ConstantsUtil.APPROVED))) {
	    				 continue;
	    			 }
	    			 if(!showData) {
	    				 strCertId =ConstantsUtil.NO_ACCESS;
	    			 }
	    			//SPEC: <14.07.2022>: Guna Modified for req 41754 22x Release  -- END
	    			  util.formatData(sbCertSourceId, strCertId);
		    		  util.formatData(sbCertSourceType,  util.mapType((String) mpSource.get(DomainConstants.SELECT_TYPE)));
		    		  util.formatData(sbCertSourceName, (String) mpSource.get(DomainConstants.SELECT_NAME));
		    		  util.formatData(sbTitle, (String)mpSource.get(DomainConstants.SELECT_ATTRIBUTE_TITLE));
		    		  
	    		  }else {
	    			  util.formatData(sbCertSourceId, ConstantsUtil.EMPTY_STRING);
		    		  util.formatData(sbCertSourceType, ConstantsUtil.EMPTY_STRING);
		    		  util.formatData(sbCertSourceName, ConstantsUtil.EMPTY_STRING);
		    		  util.formatData(sbTitle, ConstantsUtil.EMPTY_STRING);
	    		  }
	    		  if(!mpCertDocs.isEmpty()) {
	    			  util.formatData(sbDocsId, (String) mpCertDocs.get(DomainConstants.SELECT_ID));
		    		  util.formatData(sbDocsName, (String) mpCertDocs.get(DomainConstants.SELECT_NAME));
		    		  util.formatData(sbDocsType, (String) mpCertDocs.get(DomainConstants.SELECT_TYPE));
	    		  }else {
	    			  util.formatData(sbDocsId, ConstantsUtil.EMPTY_STRING);
		    		  util.formatData(sbDocsName, ConstantsUtil.EMPTY_STRING);
		    		  util.formatData(sbDocsType, ConstantsUtil.EMPTY_STRING);
	    		  }
	    		  util.formatData(sbName, sName);
	    		  util.formatData(sbCertComments, ((String)mpCert.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)).trim());
	    		  util.formatData(sbExpDate, validatorUtil.DateFormatter((String)mpCert.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)));
	    		  util.formatData(sbRelType, (String)mpCert.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ROLLUP_SOURCE_REL_TYPE));
	    		  util.formatData(sbCertName, (String)mpCert.get(DomainConstants.SELECT_NAME));
	    		  util.formatData(sbType,  util.mapType(sType));
	    		  util.formatData(sbId, objId);
	    	  }
	    	  pkgCertMap.put(ConstantsUtilIRM.PARTNAME, sbName.toString());  
	    	  pkgCertMap.put(ConstantsUtil.TITLE, sbTitle.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.CERTIFICATENAME, sbCertName.toString());
	    	  pkgCertMap.put(ConstantsUtil.EXPIRATIONDATE, sbExpDate.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.CERTCOMMENTS, sbCertComments.toString());
	    	  pkgCertMap.put(ConstantsUtil.SOURCENAME, sbCertSourceName.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.SOURCEID, sbCertSourceId.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.SOURCETYPE, sbCertSourceType.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.SUPPORTDOCS, sbDocsName.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.SUPPORTDOCSID, sbDocsId.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.SUPPORTDOCSTYPE, sbDocsType.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.RELATIONSHIPTYPE, sbRelType.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.PARTTYPE, sbType.toString());
	    	  pkgCertMap.put(ConstantsUtilIRM.PARTID, sbId.toString());
	      }
	    }catch (Exception e) {
	    	LOGGER.error("Error from FPPBO:  getPackagingCertData"+e);
		}
		return pkgCertMap;
	}
	/**
	 * Method Name : getCertificationDocs
	 * Method Description : To get the connected Support Docs
	 * @param context
	 * @param StingList
	 * @return
	 */

	public Map getCertificationDocs(Context context, StringList docsList) {
		 Map mpCertDocs =new HashMap<>();
		try {
			StringList busSelects = new StringList(4);
		    busSelects.add(DomainConstants.SELECT_ID);
		    busSelects.add(DomainConstants.SELECT_NAME);
		    busSelects.add(DomainConstants.SELECT_TYPE);
		    busSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		    busSelects.add(DomainConstants.SELECT_CURRENT);
		      List<String> docNames = new ArrayList<>();
		      List<String> docObIDs = new ArrayList<>();
		      List<String> docTypes = new ArrayList<>();
		    MapList docsMpList =DomainObject.getInfo(context, docsList.<String>toArray(new String[docsList.size()]), busSelects);
		    for(int k=0;k<docsMpList.size();k++) {
		    	Map docsMap =(Map)docsMpList.get(k);
		    	String docId =(String)docsMap.get(DomainConstants.SELECT_ID);
		    	String docState =(String)docsMap.get(DomainConstants.SELECT_CURRENT);
		    	if(docState.equals(ConstantsUtil.STATE_RELEASE) || docState.equals(ConstantsUtil.RELEASED)) {
		    	 boolean hasAccess =util.checkHasAccess(context, null, docId);
		    	 if(!hasAccess) {
		    		 docId =ConstantsUtil.NO_ACCESS;
		    	 }
		    	    docNames.add((String)docsMap.get(DomainConstants.SELECT_NAME));
		            docObIDs.add(docId);
		            docTypes.add(util.mapType((String)docsMap.get(DomainConstants.SELECT_TYPE)));
		    	}
		    }
		    mpCertDocs.put(DomainConstants.SELECT_NAME, String.join(",", (Iterable)docNames));
		    mpCertDocs.put(DomainConstants.SELECT_ID, String.join(",", (Iterable)docObIDs));
	        mpCertDocs.put(DomainConstants.SELECT_TYPE, String.join(",", (Iterable)docTypes));
		    
		} catch (Exception e) {
			LOGGER.error("Error from FPPBO:  getCertificationDocs"+e);
		}
		return mpCertDocs;
	}

	/**
	 * Method Name : getSourcePartInfo
	 * Method Description : To get certification source
	 * @param context
	 * @param Sting
	 * @return
	 */
	private Map getSourcePartInfo(Context context, String sourceId) {
		 Map mpInfo =new HashMap<>();
		try {
			StringList busSelects = new StringList(4);
		    busSelects.add(DomainConstants.SELECT_ID);
		    busSelects.add(DomainConstants.SELECT_NAME);
		    busSelects.add(DomainConstants.SELECT_TYPE);
		    busSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		    busSelects.add(DomainConstants.SELECT_CURRENT);
		    DomainObject domSource =DomainObject.newInstance(context, sourceId);
		    mpInfo = domSource.getInfo(context, busSelects);
		} catch (Exception e) {
			LOGGER.error("Error from FPPBO:  getSourcePartInfo"+e);
		}
		return mpInfo;
	}
	//SPEC: <07.06.2022>: Guna Added for req 41754 22x Release  -- END
	/**
	 * Method Name : checkHasATSForAltSub
	 * Method Description : TO Check HAS Ats value
	 * @param context
	 * @param altType 
	 * @param StringList
	 * @return
	 */
	public String checkHasATSForAltSub(Context context, StringList pIdList, StringList altType) {
		String sHasATSAttrVal =ConstantsUtil.EMPTY_STRING;
		try {
			if(!pIdList.isEmpty())
			{
				StringList busSelect = new StringList();
				busSelect.add(DomainConstants.SELECT_NAME);
				busSelect.add(DomainConstants.SELECT_ID);
				busSelect.add(DomainConstants.SELECT_TYPE);
				busSelect.add(DomainConstants.SELECT_CURRENT);
				for(int t=0;t<pIdList.size();t++) {
				if(!ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equals(altType.get(t)) && !ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART.equals(altType.get(t)) && !ConstantsUtil.TYPE_DEVICEPRODUCTPART.equals(altType.get(t)) && !ConstantsUtil.TYPE_RAWMATERIALPART.equals(altType.get(t))) {	
				MapList atsMapList =getConnetedATS(context,pIdList.get(t),busSelect);	
				if(!atsMapList.isEmpty()) {
				Iterator itr = atsMapList.iterator();
				while (itr.hasNext()) {
					Map atsMap =(Map) itr.next();
					String strATSState = (String) atsMap.get(DomainConstants.SELECT_CURRENT);
					if (ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strATSState)) {
						sHasATSAttrVal = ConstantsUtil.SYMBL_YES; 
						break;
					} 
				}
				//SPEC: <09.08.2022>: Guna Added for 49840 Defect   Dev 22x    -- START
				if(sHasATSAttrVal.equals(ConstantsUtil.SYMBL_YES)) {
					break;
				}
				//SPEC: <09.08.2022>: Guna Added for 49840 Defect   Dev 22x    -- END
				}
				if(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART.equals(altType.get(t)) || ConstantsUtil.TYPE_FABRICATEDPART.equals(altType.get(t)) || ConstantsUtil.TYPE_PGCUSTOMERUNIT.equals(altType.get(t)) || ConstantsUtil.TYPE_PGCONSUMERUNIT.equals(altType.get(t))) {
					DomainObject domAltSub =DomainObject.newInstance(context, pIdList.get(t));
					//SPEC: <09.08.2022>: Guna Added for 49867 Defect   Dev 22x    -- START
					String sapBomAttr =ConstantsUtil.EMPTY_STRING;
				    sapBomAttr =getSAPBOMAttribute(context,domAltSub);
					if(ConstantsUtil.SYMBL_CAPTRUE.equals(sapBomAttr) && ConstantsUtil.TYPE_FABRICATEDPART.equals(altType.get(t))) {
					   sHasATSAttrVal =cheHasAtsForBom(context,domAltSub);
					}else if(!ConstantsUtil.TYPE_FABRICATEDPART.equals(altType.get(t))){
						 sHasATSAttrVal =cheHasAtsForBom(context,domAltSub);
					}
					//SPEC: <09.08.2022>: Guna Added for 49867 Defect   Dev 22x    -- END
					if(sHasATSAttrVal.equals(ConstantsUtil.SYMBL_YES)) {
						break;
					}
					
				}
			}
			}
			}
		} catch (Exception e) {
			LOGGER.error("Error from FPPBO:  checkHasATSForAltSub"+e);
		}
		return sHasATSAttrVal;
	}
	
	//SPEC: <09.08.2022>: Guna Added for 49867 Defect   Dev 22x    -- START
	private String getSAPBOMAttribute(Context context, DomainObject domAltSub) {
		try {
			return domAltSub.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED);
		} catch (FrameworkException e) {
			LOGGER.error("Error from FPPBO:  getSAPBOMAttribute"+e);
		}
		return ConstantsUtil.EMPTY_STRING;
	}
	//SPEC: <09.08.2022>: Guna Added for 49867 Defect   Dev 22x    -- END

	private String cheHasAtsForBom(Context context, DomainObject domAltSub) {
		String hasATSBom =ConstantsUtil.EMPTY_STRING;
		try {
			StringList busSelect = new StringList();
			busSelect.add(DomainConstants.SELECT_NAME);
			busSelect.add(DomainConstants.SELECT_TYPE);
			busSelect.add(DomainConstants.SELECT_ID);
			busSelect.add(DomainConstants.SELECT_REVISION);
			busSelect.add(DomainConstants.SELECT_CURRENT);
			
			MapList mlSubBOMs = domAltSub.getRelatedObjects(context, //MatrixContext
					ConstantsUtil.RELATIONSHIP_EBOM, //relationshipPattern
					ConstantsUtilIRM.TYPESELECTS, //typePattern
					busSelect, //objectSelects
					DomainConstants.EMPTY_STRINGLIST, //relationshipSelects
					false, //getTo
					true,  //getFrom
					(short)0, //recurseToLevel
					ConstantsUtil.EMPTY_STRING, //objectWhere 
					ConstantsUtil.EMPTY_STRING, //relationshipWhere
					0); //limit
			if(!mlSubBOMs.isEmpty()) {
			for(int i =0; i<mlSubBOMs.size(); i++)
			{
				Map objectMap  = (Map) mlSubBOMs.get(i);
				StringList pIdList = validatorUtil.getStringListEquivalentForString(objectMap.get(DomainConstants.SELECT_ID));
				StringList pTypeList = validatorUtil.getStringListEquivalentForString(objectMap.get(DomainConstants.SELECT_TYPE));
				 hasATSBom =checkHasATS(context,pIdList,pTypeList);
				 if(hasATSBom.equals(ConstantsUtil.SYMBL_YES)) {
						break;
					}
			}
			}
		}catch (Exception e) {
			LOGGER.error("Error from FPPBO:  cheHasAtsForBom"+e);
		}
		return hasATSBom;
	}

	//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- START
	public String checkSupportDocAccess(Context context, StringList supportDocIdtemp){
		StringList supportDocResult = new StringList();
		for(String s : supportDocIdtemp) {
			if(util.checkHasAccess(context, null, s)) {
				supportDocResult.add(s);
			}
			else {
				supportDocResult.add(ConstantsUtil.NO_ACCESS);
			}
		}
		
		return validatorUtil.getStringEquivalentForStringList(supportDocResult);
	}
	//SPEC: 16-12-2022: Added by Ketan for Requirement no. 45670 -- END
	
	
	//Added by Jwala for the requirement FPP Compare 78495 -- START
	
	/**
	 * Method Name 			: parsePGPhaseCompareBOM
	 * Method Description 	: Compare FPP Part
	 * @param context
	 * @param mapList  
	 * @param mpPhase
	 * @return
	 */
	public Map<String, String> parsePGPhaseCompareBOM(Context context,MapList mapList, Map mpPhase) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		StringValidatorUtil validator = new StringValidatorUtil();

		BusObjectAttribUtil util = new BusObjectAttribUtil();

		CommonBusUtilBO commonBO = new CommonBusUtilBO();
		Map MPFinalEBOMSubStitute = new TreeMap();
		Map mpFinalEBOM = new TreeMap();
		Map mpFinalSubstitute = new TreeMap();
		int index=1;
		StringBuilder sbFEBOMParentName = new StringBuilder();
		StringBuilder sbFEBOMParentREV = new StringBuilder();
		StringBuilder sbFEBOMParentId = new StringBuilder();
		StringBuilder sbFEBOMParentType = new StringBuilder();
		StringBuilder sbFRelRestriction = new StringBuilder();
		StringBuilder sbFRelRestrictionComment = new StringBuilder();
		StringBuilder sbFEBOMName = new StringBuilder();
		StringBuilder sbFEBOMREV = new StringBuilder();
		StringBuilder sbFEBOMId = new StringBuilder();
		StringBuilder sbFEBOMChg = new StringBuilder();
		StringBuilder sbFEBOMFN = new StringBuilder();
		StringBuilder sbFEBOMTitle = new StringBuilder();
		StringBuilder sbFEBOMType = new StringBuilder();
		StringBuilder sbFEBOMQTY = new StringBuilder();
		StringBuilder sbFEBOMBuom = new StringBuilder();
		StringBuilder sbFEBOMCommnts = new StringBuilder();
		StringBuilder sbFEBOMComment = new StringBuilder();
		StringBuilder sbFEBOMState = new StringBuilder();
		StringBuilder sbFEBOMStage = new StringBuilder();
		StringBuilder sbFEBOMRDOC = new StringBuilder();
		StringBuilder sbFEBOMSubstute = new StringBuilder();
		StringBuilder sbFEBOMRevRelDt = new StringBuilder();
		StringBuilder sbFOSPD= new StringBuilder();
		StringBuilder sbFDen= new StringBuilder();
		StringBuilder sbFAltName = new StringBuilder();
		StringBuilder sbFAltID = new StringBuilder();
		StringBuilder sbFAltType = new StringBuilder();
		StringBuilder sbFEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbFEBOMSubPartID = new StringBuilder();
		StringBuilder sbFEBOMSubPartType = new StringBuilder();

		StringBuilder sbGrossWeight = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder();
		StringBuilder sbNSPCG = new StringBuilder();
		MapList mlEBOMSubList = new MapList();
		try 
		{
			Map objectMap = null;
			Map<String, String> mpSubstituteResult = null;
			MapList mlPhaseEBOMList = null;
			int iParentLevel = 0;
			StringList slParentId = new StringList();
			String sParentId = ConstantsUtil.EMPTY_STRING;

			String sPParentName = (String)mpPhase.get(ConstantsUtil.SELECT_NAME);
			String sPParentId = (String)mpPhase.get(ConstantsUtil.SELECT_ID);
			String sPParentRev = (String)mpPhase.get(ConstantsUtil.SELECT_REVISION);
			String sPParentType = (String)mpPhase.get(ConstantsUtil.SELECT_TYPE);

			for(int i =0; i<mapList.size(); i++)
			{
				objectMap = (Map) mapList.get(i);
				iParentLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));

				mpSubstituteResult = new HashMap<String, String>();
				mpEBOMResult = new HashMap<String, String>();
				mlPhaseEBOMList = new MapList();
				sParentId = ConstantsUtil.EMPTY_STRING;

				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMREV = new StringBuilder();
				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMFN = new StringBuilder();
				StringBuilder sbEBOMTitle = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMQTY = new StringBuilder();
				StringBuilder sbEBOMBuom = new StringBuilder();
				StringBuilder sbEBOMCommnts = new StringBuilder();
				StringBuilder sbEBOMComment = new StringBuilder();
				StringBuilder sbEBOMState = new StringBuilder();
				StringBuilder sbEBOMStage = new StringBuilder();
				StringBuilder sbEBOMRDOC = new StringBuilder();
				StringBuilder sbEBOMSubstute = new StringBuilder();
				StringBuilder sbEBOMRevRelDt = new StringBuilder();
				StringBuilder sbOSPD= new StringBuilder();
				StringBuilder sbDen= new StringBuilder();
				StringBuilder sbAltName = new StringBuilder();
				StringBuilder sbAltID = new StringBuilder();
				StringBuilder sbAltType = new StringBuilder();
				StringBuilder sbEBOMSubstitutePart = new StringBuilder();
				StringBuilder sbEBOMSubPartID = new StringBuilder();
				StringBuilder sbEBOMSubPartType = new StringBuilder();

				StringBuilder sbEBOMGrossWeight = new StringBuilder();
				StringBuilder sbEBOMGrossWeightUOM = new StringBuilder();
				StringBuilder sbEBOMNSPCG = new StringBuilder();

				String sPId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sPName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sPRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sPReleaseDate = validator.DateFormatter(validator.getStringEquivalentForStringListWithComma((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
				String sPRevRelease = sPRevision + ConstantsUtil.SYMBL_COLON+ sPReleaseDate;
				String sPpgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sPFN = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				String sPTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sPType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sPSubstitute = (String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
				sPSubstitute =util.replaceSpecialSymbols(sPSubstitute);

				String sPQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
				String sPQty1 = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				if (UIUtil.isNullOrEmpty(sPQty))
				{
					sPQty =sPQty1;
				}
				if (sPQty == null)
				{
					sPQty = "";
				}
				if((sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE)) && ((iParentLevel == 1) || (iParentLevel == 2))){
					sPQty = "";
				}            	             
				String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
				strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strAltID = util.checkAlternateHasAccess(context,objectMap);	
				String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
				strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strOSPD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
				String strDenUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);				
				String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
				String sPBuom = ConstantsUtil.EMPTY_STRING;
				if(validator.isNotNullOrEmpty((String)(mpPhase.get(ConstantsUtil.SELECT_TYPE))) && ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase((String)(mpPhase.get(ConstantsUtil.SELECT_TYPE))))
					sPBuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				else
					sPBuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				String sPComments = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				String sPComment = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
				String sPCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				sPCurrent=util.mapType(sPCurrent);
				String sPStage = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				String sPRD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				sPRD =util.replaceSpecialSymbols(sPRD);
				String sPOC = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sPOC = util.replaceSpecialSymbols(sPOC);
				String sPRDOC = sPRD + ConstantsUtil.SYMBL_COLON + sPOC;
				String strClassFiedParent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sGrossWeight= (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
				String sGrossWeightUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
				String sNSPCG = (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
				String sPRelRestriction = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
				String sPRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;

				boolean bHasOwnership = false;

				String sFormulaPropagate = sPId;
				if(util.isModificatinRequired())
				{

					bHasOwnership = util.checkHasAccess(context, null, sPId);
					if(!bHasOwnership)
					{

						sPpgChg = ConstantsUtil.NO_ACCESS;
						sPId = ConstantsUtil.NO_ACCESS;
						sPRevRelease = sPRevision+ConstantsUtil.SYMBL_COLON+sPReleaseDate;

					}
					boolean bHasOwnershipParent = false;
					bHasOwnershipParent = util.checkHasAccess(context, null, sPParentId);
					if(!bHasOwnershipParent)
					{
						sPParentId = ConstantsUtil.NO_ACCESS;
					}

				}else if(sec.isStaffAUGUser())
				{
					boolean showData = true;

					showData = util.checkHasAccess(context, null, sPId);
					if(!showData){
						if(validator.isNotNullOrEmpty(sPpgChg) || !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE))
							sPpgChg = ConstantsUtil.NO_ACCESS;
						sPId = ConstantsUtil.NO_ACCESS;
						sPRevRelease = sPRevision+ConstantsUtil.SYMBL_COLON+sPReleaseDate;

					}
					boolean showDataParent = true;
					showDataParent = util.checkHasAccess(context, null, sPParentId);
					if(!showDataParent){
						sPParentId = ConstantsUtil.NO_ACCESS;
					}
				}else{

					boolean showData = util.checkHasAccess(context, null, sPId);
					if(!showData){
						if(validator.isNotNullOrEmpty(sPpgChg) || !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE))
							sPpgChg = ConstantsUtil.NO_ACCESS;

						sPId = ConstantsUtil.NO_ACCESS;
						sPRevRelease = sPRevision+ConstantsUtil.SYMBL_COLON+sPReleaseDate;
					}
					boolean showDataParent = util.checkHasAccess(context, null, sPParentId);
					if(!showDataParent){
						sPParentId = ConstantsUtil.NO_ACCESS;
					}
				}//else 

				objectMap.put(ConstantsUtil.CONTEXT_TYPE, (String)(mpPhase.get(ConstantsUtil.SELECT_TYPE)));
				mlPhaseEBOMList.add(objectMap);
				if(!sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1) {

					formatData(sbFEBOMParentName, sPParentName);
					formatData(sbFEBOMParentREV, sPParentRev);
					formatData(sbFEBOMParentId, sPParentId);
					formatData(sbFEBOMParentType, util.mapType(sPParentType));
					formatData(sbFRelRestriction, sPRelRestriction);
					formatData(sbFRelRestrictionComment, sPRelRestrictionComment);
					formatData(sbFEBOMType, util.mapType(sPType));
					formatData(sbFEBOMName, sPName);
					formatData(sbFEBOMREV, sPRevision);
					formatData(sbFEBOMQTY, sPQty);
					formatData(sbFEBOMBuom, sPBuom);
					formatData(sbFEBOMState, sPCurrent);
					formatData(sbFEBOMId, sPId);
					formatData(sbFEBOMChg, sPpgChg);
					formatData(sbFEBOMFN, sPFN);
					formatData(sbFEBOMTitle, sPTitle);
					formatData(sbFEBOMSubstute, sPSubstitute);
					formatData(sbFEBOMCommnts, sPComments);
					formatData(sbFEBOMComment, sPComment);
					formatData(sbFEBOMStage, sPStage);
					formatData(sbFEBOMRDOC, sPRDOC);
					formatData(sbFEBOMRevRelDt, sPRevRelease);
					formatData(sbFOSPD,strOSPD);
					formatData(sbFDen,strDenUOM);
					formatData(sbFAltName,strAltName);
					formatData(sbFAltID,strAltID);
					formatData(sbFAltType,strAltType);
					formatData(sbFEBOMSubstitutePart, strSubPart);
					formatData(sbFEBOMSubPartID, strSubPartId);
					formatData(sbFEBOMSubPartType, strSubPartType);
					formatData(sbGrossWeight, sGrossWeight);
					formatData(sbGrossWeightUOM, sGrossWeightUOM);
					formatData(sbNSPCG, sNSPCG);
					if(!mlPhaseEBOMList.isEmpty()) {
						mlEBOMSubList.addAll(mlPhaseEBOMList);
					}

				} else {
					formatData(sbEBOMType, util.mapType(sPType));
					formatData(sbEBOMName, sPName);
					formatData(sbEBOMREV, sPRevision);
					formatData(sbEBOMQTY, sPQty);
					formatData(sbEBOMBuom, sPBuom);
					formatData(sbEBOMState, sPCurrent);
					formatData(sbEBOMId, sPId);
					formatData(sbEBOMChg, sPpgChg);
					formatData(sbEBOMFN, sPFN);
					formatData(sbEBOMTitle, sPTitle);
					formatData(sbEBOMSubstute, sPSubstitute);
					formatData(sbEBOMCommnts, sPComments);
					formatData(sbEBOMComment, sPComment);
					formatData(sbEBOMStage, sPStage);
					formatData(sbEBOMRDOC, sPRDOC);
					formatData(sbEBOMRevRelDt, sPRevRelease);
					formatData(sbOSPD,strOSPD);
					formatData(sbDen,strDenUOM);
					formatData(sbAltName,strAltName);
					formatData(sbAltID,strAltID);
					formatData(sbAltType,strAltType);
					formatData(sbEBOMSubstitutePart, strSubPart);
					formatData(sbEBOMSubPartID, strSubPartId);
					formatData(sbEBOMSubPartType, strSubPartType);
					formatData(sbEBOMGrossWeight, sGrossWeight);
					formatData(sbEBOMGrossWeightUOM, sGrossWeightUOM);
					formatData(sbEBOMNSPCG, sNSPCG);
				}
				int j = 0;
				int iNextLevel = 0;
				Map objectMaps =null;
				if(sPType.equals(ConstantsUtil.TYPE_PGPHASE)){
					sParentId=sFormulaPropagate;
					for(j =i+1; j<mapList.size(); j++)
					{
						iNextLevel = 0;
						objectMaps = (Map) mapList.get(j);
						int iCurrLevel = Integer.parseInt((String) objectMaps.get(ConstantsUtil.SELECT_LEVEL));
						if(j < mapList.size()-1) {
							Map objectNxtMaps = (Map) mapList.get(j+1);
							iNextLevel = Integer.parseInt((String) objectNxtMaps.get(ConstantsUtil.SELECT_LEVEL));
						}

						if((iParentLevel+1 == iCurrLevel) && sPType.equals(ConstantsUtil.TYPE_PGPHASE)) {

							objectMaps.put(ConstantsUtil.CONTEXT_TYPE, (String)(mpPhase.get(ConstantsUtil.SELECT_TYPE)));
							mlPhaseEBOMList.add(objectMaps);
							String strClassFied = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.STR_IPCLASS));
							String sId = (String) objectMaps.get(ConstantsUtil.SELECT_ID);
							String sName = (String) objectMaps.get(ConstantsUtil.SELECT_NAME);
							String sRevision = (String) objectMaps.get(ConstantsUtil.SELECT_REVISION);
							String sReleaseDate = validator.DateFormatter(validator.getStringEquivalentForStringListWithComma((String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
							String sRevRelease = sRevision + ConstantsUtil.SYMBL_COLON+ sReleaseDate;
							String spgChg = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
							String sFN = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
							String sTitle = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							String sType = (String) objectMaps.get(ConstantsUtil.SELECT_TYPE);
							String sSubstitute = (String) objectMaps.get(ConstantsUtil.SELECT_SUBSTITUTE);
							sSubstitute =util.replaceSpecialSymbols(sSubstitute);
							String sQty = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
							strAltName =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
							strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strAltID = util.checkAlternateHasAccess(context,objectMaps);	
							strAltType =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
							strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strOSPD =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
							strDenUOM =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);				
							strSubPart = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strSubPartId = util.checkSubstituteHasAccess(context,objectMaps);
							String sBuom = ConstantsUtil.EMPTY_STRING;
							if(validator.isNotNullOrEmpty((String)(mpPhase.get(ConstantsUtil.SELECT_TYPE))) && ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase((String)(mpPhase.get(ConstantsUtil.SELECT_TYPE))))
								sBuom = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
							else
								sBuom = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
							String sComments = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
							String sComment = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
							String sCurrent = (String) objectMaps.get(ConstantsUtil.SELECT_CURRENT);
							sCurrent=util.mapType(sCurrent);
							String sStage = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
							String sRD = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
							sRD =util.replaceSpecialSymbols(sRD);
							String sOC = (String) objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = sRD + ConstantsUtil.SYMBL_COLON + sOC;
							String sEBOMGrossWeight= (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
							String sEBOMGrossWeightUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
							String sEBOMNSPCG = (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);

							if(util.isModificatinRequired())
							{

								bHasOwnership = util.checkHasAccess(context, null, sId);
								if(!bHasOwnership)
								{
									spgChg = ConstantsUtil.NO_ACCESS;
									sId = ConstantsUtil.NO_ACCESS;
									sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;

								}
							}else{
								boolean showData = util.checkHasAccess(context, null, sId);
								if(!showData)
								{
									spgChg = ConstantsUtil.NO_ACCESS;
									sId = ConstantsUtil.NO_ACCESS;
									sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
								}
							}

							sType = util.mapType(sType);

							formatData(sbEBOMType, sType);
							formatData(sbEBOMName, sName);
							formatData(sbEBOMREV, sRevision);
							formatData(sbEBOMQTY, sQty);
							formatData(sbEBOMBuom, sBuom);
							formatData(sbEBOMState, sCurrent);
							formatData(sbEBOMId, sId);
							formatData(sbEBOMChg, spgChg);
							formatData(sbEBOMFN, sFN);
							formatData(sbEBOMTitle, sTitle);
							formatData(sbEBOMSubstute, sSubstitute);
							formatData(sbEBOMCommnts, sComments);
							formatData(sbEBOMComment, sComment);
							formatData(sbEBOMStage, sStage);
							formatData(sbEBOMRDOC, sRDOC);
							formatData(sbEBOMRevRelDt, sRevRelease);
							formatData(sbOSPD,strOSPD);
							formatData(sbDen,strDenUOM);
							formatData(sbAltName,strAltName);
							formatData(sbAltID,strAltID);
							formatData(sbAltType,strAltType);
							formatData(sbEBOMSubstitutePart, strSubPart);
							formatData(sbEBOMSubPartID, strSubPartId);
							formatData(sbEBOMSubPartType, strSubPartType);
							formatData(sbEBOMGrossWeight, sEBOMGrossWeight);
							formatData(sbEBOMGrossWeightUOM, sEBOMGrossWeightUOM);
							formatData(sbEBOMNSPCG, sEBOMNSPCG);
						}
						if(iParentLevel+1 > iNextLevel || iParentLevel == iCurrLevel) {
							break;
						} 		
					}	

					mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
					mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
					mpEBOMResult.put(ConstantsUtil.REVISION, sbEBOMREV.toString());
					mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
					mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
					mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
					mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
					mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
					mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
					mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
					mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
					mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
					mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
					mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
					mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
					mpEBOMResult.put(ConstantsUtil.OSPD, sbOSPD.toString());
					mpEBOMResult.put(ConstantsUtil.DUOM, sbDen.toString());
					mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
					mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
					mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
					mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
					mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
					mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbEBOMGrossWeight.toString());
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbEBOMGrossWeightUOM.toString());
					mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbEBOMNSPCG.toString());
				}
				if(!mpEBOMResult.isEmpty() && validator.isNotNullOrEmpty(sParentId) && (!slParentId.contains(sParentId) || (slParentId.contains(sParentId) && !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1))) {
					slParentId.add(sParentId);
					mpFinalEBOM.put(String.valueOf(index), mpEBOMResult);
					if(!mlPhaseEBOMList.isEmpty()) {
						mlEBOMSubList.addAll(mlPhaseEBOMList);
					}
					index++;
				}
			}

			mpEBOMResult = new HashMap();
			if(null != sbFEBOMId && sbFEBOMId.length()>0) {
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbFEBOMParentId.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbFEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbFEBOMParentREV.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbFEBOMParentType.toString());
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbFRelRestriction.toString());
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbFRelRestrictionComment.toString());
				mpEBOMResult.put(ConstantsUtil.ID, sbFEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbFEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.REVISION, sbFEBOMREV.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbFEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.FN, sbFEBOMFN.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbFEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbFEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbFEBOMSubstute.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbFEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbFEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbFEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.STATE, sbFEBOMState.toString());
				mpEBOMResult.put(ConstantsUtil.PHASE, sbFEBOMStage.toString());
				mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbFEBOMRDOC.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbFEBOMRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.OSPD, sbFOSPD.toString());
				mpEBOMResult.put(ConstantsUtil.DUOM, sbFDen.toString());
				mpEBOMResult.put(ConstantsUtil.ALTNAME, sbFAltName.toString());
				mpEBOMResult.put(ConstantsUtil.ALTID, sbFAltID.toString());
				mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbFAltType.toString());
				mpEBOMResult.put(ConstantsUtil.SP, sbFEBOMSubstitutePart.toString());
				mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbFEBOMSubPartType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbFEBOMSubPartID.toString());
				mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeight.toString());
				mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
				mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbNSPCG.toString());

			}

			mpSubstituteResult = commonBO.parseSubstitute(context,mlEBOMSubList);
			MPFinalEBOMSubStitute.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
			MPFinalEBOMSubStitute.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstituteResult);

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in FPPBO:  FPPCompare: " + e);
		}
		return MPFinalEBOMSubStitute;

	}
	//Added by Jwala for the requirement FPP Compare 78495-- END
	
	//SPEC: Added by Jwala for Requirement #86912 ---  START
	
	public Map<String, String> getLocalProductName(Context context, String strObjectId) throws Exception {
		MapList mlLPList = new MapList();
		Map mpLocalProductName =new HashMap<>();
		StringValidatorUtil validator = new StringValidatorUtil();

		String sObjId = DomainConstants.EMPTY_STRING;
		String sLanguage = DomainConstants.EMPTY_STRING;
		String sLPNData = DomainConstants.EMPTY_STRING;
		String sCountry = DomainConstants.EMPTY_STRING;

		StringBuilder sbObjId = new StringBuilder();
		StringBuilder sbLanguage = new StringBuilder();
		StringBuilder sbLPNData = new StringBuilder();
		StringBuilder sbCountry = new StringBuilder();

		StringList slObjSel = new StringList(1);
		slObjSel.add(DomainConstants.SELECT_ID);
		slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLANGUAGE);
		slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLPNDATA);
		slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOUNTRY);

		StringList slLPRel = new StringList(3);

		try{
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				DomainObject domObj = DomainObject.newInstance(context, strObjectId);

				mlLPList = domObj.getRelatedObjects(context,
						ConstantsUtilIRM.TYPE_PGLPNDATA,
						ConstantsUtilIRM.RELATIONSHIP_PGLPNDATA,
						slObjSel, //objectSelects
						slLPRel, //relationshipSelects
						false, //getTo
						true, //getFrom
						(short)1, //recurseToLevel
						null, //objectWhere
						null, //relationshipWhere
						0);

				Iterator objectListItr = mlLPList.iterator();

				while(objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();

					sObjId = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.SELECT_ID));
					sLanguage = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLANGUAGE));
					sLPNData = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLPNDATA));
					sCountry = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOUNTRY));

					util.formatData(sbObjId, sObjId);
					util.formatData(sbLanguage, sLanguage);
					util.formatData(sbLPNData, sLPNData);
					util.formatData(sbCountry, sCountry);

				}
				mpLocalProductName.put(ConstantsUtilIRM.LANGUAGE,sbLanguage.toString());
				mpLocalProductName.put(ConstantsUtilIRM.PGMARKET,sbCountry.toString());
				mpLocalProductName.put(ConstantsUtilIRM.PGLPN,sbLPNData.toString());

			}
		}catch(Exception e){
			LOGGER.error("Error from FinishedProductPartBo :  getLocalProductName" + e);
			return new HashMap();
		}

		return mpLocalProductName;

	}
	
	//SPEC: Added by Jwala for Requirement #86912 ---  END
}