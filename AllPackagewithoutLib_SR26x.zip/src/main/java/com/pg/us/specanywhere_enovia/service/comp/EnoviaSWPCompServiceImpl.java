package com.pg.us.specanywhere_enovia.service.comp;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSWPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaSWPService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaRMPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaSWPServiceImpl;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;

public class EnoviaSWPCompServiceImpl implements EnoviaSWPCompService {
	private static Logger LOGGER = Logger.getLogger(EnoviaSWPServiceImpl.class);
	
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	
	@Autowired
	private EnoviaConnectionPool pool;
	
	
	@Autowired
	private HttpServletRequest request;
	@Autowired
	private EnoviaSWPService swp;
	@Override
	public HashMap<String, HashMap<String, Map<String, String>>> getSWPCompdata(String objId, Environment env) throws Exception {
		HashMap<String, HashMap<String, Map<String, String>>> hmAttrib = new HashMap<String,HashMap<String, Map<String, String>>>();
		HashMap<String, Map<String, String>> hmfinalrel = new HashMap<String, Map<String, String>>();
		HashMap<String, Map<String, String>> hmAttribObj = new HashMap<String, Map<String, String>>();
		StringValidatorUtil validator = new StringValidatorUtil();
		StopWatch sp = new StopWatch();
		sp.start();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		Context contextDq = pool.checkOut();
		swContext.stop();
		
		try {
			
			String sComp=ConstantsUtilIRM.SWP_COMPARE;
			if(UIUtil.isNotNullAndNotEmpty(objId)){
				hmfinalrel = swp.getSWPdata(objId,sComp, env);
				DomainObject doRMP = DomainObject.newInstance(context, objId);
				sComp=ConstantsUtilIRM.COMPARE;
				try {
					context.close();
				} catch(Exception e) {
					LOGGER.error("Exception From SWP COMPARISION Service IMPL Class "+e);
				}
				String sDocPreviousRevId  = doRMP.getPreviousRevision(contextDq).getObjectId();
				if(UIUtil.isNotNullAndNotEmpty(sDocPreviousRevId))
					hmAttribObj = swp.getSWPdata(sDocPreviousRevId, sComp,env);
			}
			hmAttrib.put(ConstantsUtilIRM.RELEASEOBJECT, hmfinalrel);
			hmAttrib.put(ConstantsUtilIRM.OBSOLETEOBJECT,hmAttribObj);
		}catch(Exception e) {
			LOGGER.error("Exception From SWP COMPARISION Service IMPL Class "+e);
		}
		contextDq.close();
		context.close();
		return hmAttrib;
	}

}
