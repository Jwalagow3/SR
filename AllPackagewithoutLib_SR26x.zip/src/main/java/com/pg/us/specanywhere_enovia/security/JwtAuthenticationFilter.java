package com.pg.us.specanywhere_enovia.security;

import java.io.IOException;
import java.util.Arrays;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.pg.us.specanywhere_enovia.payload.ApiResponse;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Autowired
	RestTemplate restTemplate;
	
	String accessTokenIDP=null;
	String authTokenPG=null;
	String strSBMUser=null;
	
	@Value("${ping.oauth.client_secret}")
	private String jwtSecret;
	
	@Value("${env.profile}")
   	private String envProfile;
	
	@Autowired
	private CustomUserDetailsService customUserDetailsService;

	private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

		
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		logger.info("In JwtAuthenticationFilter. doFilterInternal Method.Authorization in Request Header Received");
		if (request != null && request.getHeader("Authorization") != null) {
			logger.info("In JwtAuthenticationFilter. doFilterInternal Method. If Authorization is present in request Header.");
			try {       
				authTokenPG = request.getHeader("Authorization");

				authTokenPG = authTokenPG.substring(7, authTokenPG.length());
				accessTokenIDP = request.getHeader("access_token");

				StringValidatorUtil validator = new StringValidatorUtil();
				strSBMUser = validator.isNotNullOrEmpty(request.getHeader("user_type"))?request.getHeader("user_type") : ConstantsUtil.EMPTY_STRING;

				logger.info("Before validation: authTokenPG is Present");
				logger.info("Before validation: accessTokenIDP is Present");

				HttpHeaders headers = new HttpHeaders();
				headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
				boolean result = validateToken(authTokenPG, accessTokenIDP,strSBMUser);
				ApiResponse apiResponse = new ApiResponse();
				apiResponse.setMessage(authTokenPG);
				apiResponse.setSuccess(result);

				if (StringUtils.hasText(authTokenPG) && Boolean.TRUE.equals(result)) {

					String usernameClaimKey = ConstantsUtilIRM.READONLYENVIRONMENT.equalsIgnoreCase(envProfile)?ConstantsUtilIRM.USERNAMEREADONLY:ConstantsUtilIRM.USERNAME;
					DecodedJWT parsedTokenFromPNG=JwtParserUtils.parseJWTTokenPNG(accessTokenIDP);
					String name = parsedTokenFromPNG.getClaim(usernameClaimKey).asString();
					logger.info("After validation: Username*********>>"+name);

					customUserDetailsService.setResponse(apiResponse, authTokenPG);
					UserDetails userDetails = customUserDetailsService.loadUserByUsername(name);
					UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
							userDetails, null, userDetails.getAuthorities());

					authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

					SecurityContextHolder.getContext().setAuthentication(authentication);

					logger.info("Token Validated");

				}
			} catch (Exception ex) {
				logger.error("Could not set user authentication in security context", ex);
			}
		}
		filterChain.doFilter(request, response);
	}

	public boolean validateToken(String authTokenPG, String accessTokenIDP, String strSBMUser) {
		boolean isTokenValid = false;
		try {
			Jws<Claims> parsedToken=JwtParserUtils.parseJWTToken(jwtSecret, authTokenPG);
			DecodedJWT parsedTokenFromPNG=JwtParserUtils.parseJWTTokenPNG(accessTokenIDP);
		    String usernameClaimKey = ConstantsUtilIRM.READONLYENVIRONMENT.equalsIgnoreCase(envProfile)?ConstantsUtilIRM.USERNAMEREADONLY:ConstantsUtilIRM.USERNAME;
			if (ConstantsUtilIRM.USERTYPE_SBM.equalsIgnoreCase(strSBMUser)) {
				if (parsedTokenFromPNG.getClaim("preferred_username").asString().equalsIgnoreCase(parsedToken.getBody().getSubject())
						&& parsedToken.getBody().get("exp").toString()
						.equals(parsedTokenFromPNG.getClaim("exp").asLong().toString())) {

					isTokenValid = true;
					logger.info("Token Validated");
				}

			} else {
			if (parsedTokenFromPNG.getClaim(usernameClaimKey).asString().equalsIgnoreCase(parsedToken.getBody().getSubject())
						&& parsedToken.getBody().get("exp").toString()
						.equals(parsedTokenFromPNG.getClaim("exp").asLong().toString())) {

					isTokenValid = true;
				}
			}

		} catch (SignatureVerificationException | JWTDecodeException e) {
			logger.error("Invalid JWT signature");

		} catch (SignatureException ex) {
			logger.error("Invalid JWT signature");
		} catch (MalformedJwtException ex) {
			ex.printStackTrace();
			logger.error("Invalid JWT token");
		} catch (ExpiredJwtException ex) {
			ex.printStackTrace();
			logger.error("Expired JWT token");
		} catch (UnsupportedJwtException ex) {
			ex.fillInStackTrace();
			logger.error("Unsupported JWT token");
		} catch (IllegalArgumentException ex) {
			logger.error("JWT claims string is empty.");
		}
		return isTokenValid;

	}

	/*
	 * private String getJwtFromRequest(HttpServletRequest request) { String
	 * bearerToken = request.getHeader("Authorization"); if
	 * (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
	 * 
	 * return bearerToken.substring(7, bearerToken.length()); } return null; }
	 * 
	 * 
	 */
	
	
}
