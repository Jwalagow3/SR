package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaFABCompService {
	public HashMap<String, HashMap<String, Map<String, String>>> getFABCompdata(String objId, Environment env) throws Exception;
}
