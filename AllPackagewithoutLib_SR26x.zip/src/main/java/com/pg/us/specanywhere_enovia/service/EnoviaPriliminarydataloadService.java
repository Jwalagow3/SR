package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaPriliminarydataloadService {

	HashMap<String, Map<String, String>> getPriliminarydata(Environment env, String sObjectName);

}
