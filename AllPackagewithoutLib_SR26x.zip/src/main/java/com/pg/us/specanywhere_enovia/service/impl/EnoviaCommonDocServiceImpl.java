package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;

import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaCommonDocService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class EnoviaCommonDocServiceImpl implements EnoviaCommonDocService
{

	private static Logger LOGGER = Logger.getLogger(EnoviaCommonDocServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();

	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END

	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
	private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getDocdata(String objId, Environment env, String sType, String sComp)
			throws Exception 
	{

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("COMMON DOC SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());

		try 
		{
			/**
			 * User Profile Section
			 * */
			String sUserType = BbUtil.getUserType();
			
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START

			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			if (UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BbUtil.getUserView(context, objId);
				}
			}
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			BusObjectAttribUtil util = new BusObjectAttribUtil();

			if(UIUtil.isNullOrEmpty(sType)) {
				LOGGER.error("ERROR: INVALID TYPE FROM INTEGRATION SERVICE : "+sType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E102.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			boolean isExternal = false;
			boolean isInternal = true;

			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM) || sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP)){
				isExternal=true;
				isInternal=false;
			}

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;

			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);

			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				//CM and Supplier Both are same
				bSupplierView = true;
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				bSupplierView = true;
			} else {
				switch (sUserType) {
				case ConstantsUtil.PG:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PGSTAFF:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PG_CM:
					break;

				case ConstantsUtil.PG_SP:
					bSupplierView = true;
					break;
				}

			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			CommonDocBO commonDoc = new CommonDocBO();
			//DomainObject dobCdoc = new DomainObject(objId);
			DomainObject dobCdoc = DomainObject.newInstance(context, objId);
			String strCurrent = dobCdoc.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END

			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			//SPEC: Added by Ajay for Req. no. 23970 START
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && !sType.equalsIgnoreCase(ConstantsUtil.tPOA)  && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;

				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
				//SPEC: Added by Ajay for Defect. no. 93692 START
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC: Added by Ajay for Defect. no. 93692 END
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			//SPEC: Added by Ajay for Req. no. 23970 END

			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpPartSpecResult = new HashMap<String,String>();
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpOrganization = new HashMap<String, String>();
			Map<String,String> mpPlant = new HashMap<String, String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mpRelatedAts = new HashMap<String, String>();
			Map<String,String> mpRelatedParts = new HashMap<String, String>();
			Map<String,String> mpAcs = new HashMap<String, String>();
			Map<String,String> mpIaps = new HashMap<String, String>();
			Map<String,String> mpFiles = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String, String>();
			Map<String,String> mpMarketsApproved = new HashMap<String, String>();
			Map<String,String> mpMultipleOwnershipAccess = new HashMap<String, String>();
			Map<String,String> mpPlatformAndChassis = new HashMap<String, String>();
			//SUB SECTIONS FOR ATTRIBUTES FOR IRM DOCS
			Map<String,String> mpGpsAssessment = new HashMap<String, String>();
			Map<String,String> mpAgeAndConditionControl = new HashMap<String, String>();
			Map<String,String> mpStudyObjectivesAndSuccessCriteria = new HashMap<String, String>();
			Map<String,String> mpStudyDesign = new HashMap<String, String>();
			Map<String,String> mpStudyClassification = new HashMap<String, String>();
			Map<String,String> mpPanelistRecruitingCriteria = new HashMap<String, String>();
			Map<String,String> mpSpecialProductElements = new HashMap<String, String>();
			Map<String,String> mpPanelistTask = new HashMap<String, String>();
			Map<String,String> mpGpsAssessmentType = new HashMap<String, String>();
			Map<String,String> mpStudyLocationDates = new HashMap<String, String>();
			Map<String,String> mpAgencyTasks = new HashMap<String, String>();
			Map<String,String> mpBudgetOwnerApproval = new HashMap<String, String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			
			CommonDocBO cdoc = new CommonDocBO();
			Map<String, StringList> BusinessObjectSelectableMap = cdoc.getDefaultPartSelectables(context);

			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			//START :: gaikwad.tg :: Defect#38162
			slContextSelects.add(ConstantsUtil.ATTRIBUTE_PGORIGINATINGSOURCE);
			//END :: gaikwad.tg :: Defect#38162
			// SPEC: Added for 18x.5.2 DEV --Shashank -- START
			// Is this an IRM Doc
			String sSpec1srType = dobCdoc.getInfo(context, "type");
			String sSpecType = dobCdoc.getInfo(context, DomainConstants.SELECT_TYPE);

			boolean bisIRMDoc = commonDoc.isIRMDoc(sSpecType);
			if(bisIRMDoc) {
				slContextSelects.addAll(commonDoc.getIRMDocSelects(context,sSpecType));
			}
			// SPEC: Added for 18x.5.2 DEV --Shashank -- END
			//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- START
			StringList multiSel =new StringList();
			multiSel.add(ConstantsUtil.STR_FILE_CAPTURED);
			multiSel.add(ConstantsUtilIRM.REL_OBJECTIVETYPE);
			multiSel.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATACOLLECTIONMETHODS_NAME);
			multiSel.add(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTSTABILITYID);
			multiSel.add(ConstantsUtilIRM.REFERENCE_DOCUMENT_TITLE);
			multiSel.add(ConstantsUtil.ATL_STATE);
			//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- END
			//SPEC: <01.07.2022>: Satyam Added for Internal Defect  -- START
			multiSel.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
			multiSel.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
			multiSel.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
			multiSel.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
			multiSel.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
			//SPEC: <01.07.2022>: Satyam Added for Internal Defect  -- END
			//SPEC: Added by Ketan for Internal Defect - START
			multiSel.add(ConstantsUtil.SELECT_ACS_NAME);
			multiSel.add(ConstantsUtil.SELECT_ACS_REV);
			multiSel.add(ConstantsUtil.SELECT_ACS_STATE);
			multiSel.add(ConstantsUtil.SELECT_ACS_TYPE);
			multiSel.add(ConstantsUtil.SELECT_ACS_TITLE);
			multiSel.add(ConstantsUtil.SELECT_ACS_ID);
			multiSel.add(ConstantsUtil.SELECT_ACS_PHASE);
			multiSel.add(ConstantsUtil.strIntendedMarket);
			multiSel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGION);
			//SPEC: <23.08.2022>: Satyam Added for Defect 50234 -- START
			multiSel.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOPANELISTTYPE_NAME);
			//SPEC: <23.08.2022>: Satyam Added for Defect 50234 -- END
			multiSel.add(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTFORVPROTOCOL); // Added by Ketan for Defect no. 50279
			multiSel.add(ConstantsUtilIRM.REL_TECHNIQUE_USED);
			multiSel.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPE);
			multiSel.add(ConstantsUtil.strPGCountry);//SPEC: 23-08-2022: Pooja Modified for Internal Defect
			//SPEC: Added by Ketan for Internal Defect - END
			multiSel.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ETHNICITYTORACE);//SPEC: 26-08-2022: Pooja adeed for Defect 50363
			multiSel.add(ConstantsUtilIRM.SELECT_RELATION_PGSTUDYSUPERVISED);//SPEC: 26-08-2022: Pooja adeed for Defect 50364
			multiSel.add(ConstantsUtilIRM.REL_FEEDBACKTYPE);//SPEC: 26-08-2022: Pooja adeed for Defect 50361
			multiSel.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOASSEMBLYSTATE_NAME);//SPEC: 26-08-2022: Pooja adeed for Defect 50365
			multiSel.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATAMERGE_NAME);//SPEC: 26-08-2022: Pooja adeed for Defect 50367
			multiSel.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOATTACHMENTFORMAT_NAME);//SPEC: 26-08-2022: Pooja adeed for Defect 50367
			multiSel.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYLOCATIONS);//SPEC: 26-08-2022: Pooja adeed for Defect 50367
			//SPEC : Added by Ketan for Defect no. 49150 -- START
			multiSel.add(ConstantsUtilIRM.SELECT_PROJECTSPACE_PROJECTID);
			multiSel.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_PROJECTDOCUMENT_NAME);
			//Added By Ajay for the defect no. 77884 - START
			multiSel.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
			//Added By Ajay for the defect no. 77884 - END
			//SPEC : Added by Ketan for Defect no. 49150 -- END
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			StopWatch swInfo = new StopWatch();
			cdoc.addMultiList();
			swInfo.start();
			/*
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_SIZE);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_CAPTURED);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FORMAT_FILE);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.ATL_STATE);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOASSEMBLYSTATE_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATACOLLECTIONMETHODS_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATAMERGE_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOATTACHMENTFORMAT_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.
			 * SELECT_RELATIONSHIP_STUDYLOCATIONS);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.
			 * REFERENCE_DOCUMENT_TITLE);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.REL_TECHNIQUE_USED);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.REL_FEEDBACKTYPE);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.REL_OBJECTIVETYPE);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOPANELISTTYPE_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGION)
			 * ; DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.
			 * SELECTABLE_REFERENCEDOCUMENTFORVPROTOCOL);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.REL_PENELISTTASK);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.strPGCountry);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.strIntendedMarket);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.
			 * SELECTABLE_REFERENCEDOCUMENTVPROTOCOLID);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.
			 * SELECTABLE_REFERENCEDOCUMENTVPROTOCOLTITLE);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * RELATIONSHIP_CLASSFIED_ITEM_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.
			 * RELATIONSHIP_ACCESS_FROM_DISCONNECT_SECURITY);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * RELATIONSHIP_CLASSFIED_ITEM_STATE);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * RELATIONSHIP_CLASSFIED_ITEM_TYPE);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.
			 * RELATIONSHIP_CLASSFIED_ITEM_DESC);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.
			 * SELECTABLE_REFERENCEDOCUMENTSTABILITYID);
			 * DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.
			 * REFERENCE_DOCUMENT_TITLE);
			 */

			Map resultMaps = dobCdoc.getInfo(context, slContextSelects,multiSel);

			/*
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_STATE);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOASSEMBLYSTATE_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATACOLLECTIONMETHODS_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATAMERGE_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOATTACHMENTFORMAT_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.
			 * SELECT_RELATIONSHIP_STUDYLOCATIONS);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.
			 * REFERENCE_DOCUMENT_TITLE);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_TECHNIQUE_USED);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_FEEDBACKTYPE);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_OBJECTIVETYPE);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOPANELISTTYPE_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * SELECT_ATTRIBUTE_PGREGION);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.
			 * SELECTABLE_REFERENCEDOCUMENTFORVPROTOCOL);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_PENELISTTASK);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.strPGCountry);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.strIntendedMarket);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.
			 * SELECTABLE_REFERENCEDOCUMENTVPROTOCOLID);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.
			 * SELECTABLE_REFERENCEDOCUMENTVPROTOCOLTITLE);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * RELATIONSHIP_CLASSFIED_ITEM_NAME);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.
			 * RELATIONSHIP_ACCESS_FROM_DISCONNECT_SECURITY);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * RELATIONSHIP_CLASSFIED_ITEM_STATE);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * RELATIONSHIP_CLASSFIED_ITEM_TYPE);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.
			 * RELATIONSHIP_CLASSFIED_ITEM_DESC);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.
			 * SELECTABLE_REFERENCEDOCUMENTSTABILITYID);
			 * DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.
			 * REFERENCE_DOCUMENT_TITLE);
			 */
			swInfo.stop();
			cdoc.removeMultiList();
			LOGGER.info("COMMON DOC SERVICE GETINFO ELAPSED TIME : "+swInfo.getTime());

			String sObjectId =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sObjectType = (String)resultMaps.get(ConstantsUtil.SELECT_TYPE);
			String sSharable = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS) : ConstantsUtil.EMPTY_STRING;

			// SPEC: Added/Modified for 18x.5.2 DEV --Shashank -- START
			if(bisIRMDoc) {
				mpFiles=commonDoc.getIRMDocFiles(context, dobCdoc);
				mpHeaderContent.put(ConstantsUtilIRM.GENDOC, (String)mpFiles.get(ConstantsUtilIRM.GENDOC));
			}else {
				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
				//SPEC: 20-06-2022: Pooja Added for Internal Defect -- START
				String strFileSize = cdoc.updateFileSize(FileSize);
				//SPEC: 20-06-2022: Pooja Added for Internal Defect -- END
				StringTokenizer tokenizer = new StringTokenizer(FileFormats,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
				StringBuilder sbTokenIndex = new StringBuilder();

				if(tokenizer.countTokens()>1) {
					int count = tokenizer.countTokens();
					for(int i = 0; i<count;i++) {
						String sFormat = tokenizer.nextToken();
						if(sFormat.trim().equalsIgnoreCase("generic")){
							sbTokenIndex.append(i).append(ConstantsUtil.SYMBL_COMMA);
						}
					}

					StringBuilder sbFilename = validator.tokenizeFiles(FileName,sbTokenIndex);
					StringBuilder sbFileCapturedFie = validator.tokenizeFiles(FileCapturedFie,sbTokenIndex);
					StringBuilder sbFileFormats = validator.tokenizeFiles(FileFormats,sbTokenIndex);
					StringBuilder sbFileSize = validator.tokenizeFiles(strFileSize,sbTokenIndex);

					mpFiles.put(ConstantsUtil.FILESPATH, sbFileCapturedFie.toString());
					mpFiles.put(ConstantsUtil.FILESFORMAT, sbFileFormats.toString());
					mpFiles.put(ConstantsUtil.FILESNAMES, sbFilename.toString());
					mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());
				} else {
					mpFiles.put(ConstantsUtil.FILESPATH, FileCapturedFie.toString());
					mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats.toString());
					mpFiles.put(ConstantsUtil.FILESNAMES, FileName.toString());
					mpFiles.put(ConstantsUtil.FILESSIZES, FileSize.toString());
				}
			}
			/**
			 * SECURITY
			 * */
			StopWatch swSecurity = new StopWatch();
			swSecurity.start();
			mpSecurity =commonBo.updateSecurity(context, resultMaps);
			swSecurity.stop();
			LOGGER.info("COMMON DOC SERVICE Security ELAPSED TIME : "+swSecurity.getTime());

			/**
			 * Check SOP is a Universal Doc  
			 * */

			if(sType.equalsIgnoreCase("SOP") && (ConstantsUtil.TRUE.equalsIgnoreCase(sSharable)) && isExternal) 
			{
				StopWatch swReferences= new StopWatch();
				swReferences.start();
				String sView = BbUtil.updateReferences(context, sObjectId);
				LOGGER.info("COMMON DOC SERVICE SOP VIEW:"+sView +"User :"+sUserType);

				if(!sView.equals(sUserType) && !sView.equals("NO Connection Exists") && !sView.equals(ConstantsUtil.ALLOW_FOR_ALL))
				{
					LOGGER.error("ERROR: "+ConstantsUtil.E106);
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E106.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}

				swReferences.stop();
				LOGGER.info("COMMON DOC SERVICE REFERENCE ELAPSED TIME : "+swReferences.getTime());

			}else if(sType.equalsIgnoreCase("SOP") && (!ConstantsUtil.TRUE.equalsIgnoreCase(sSharable)) && isExternal) {

				LOGGER.error("ERROR: "+ConstantsUtil.E105 +ConstantsUtil.SYMBL_COLON+sType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E105.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			boolean bHIRComplaint = util.getHIRComplaintForSupplier(context,dobCdoc,resultMaps);

			if(!bHIRComplaint && sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP) && sType.equalsIgnoreCase("MI")){

				LOGGER.error("ERROR:"+ConstantsUtil.E104);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			boolean isAts=false;
			boolean isAcs=false;
			boolean isIaps=false;
			boolean isProc=false;
			boolean isMi=false;
			boolean isLis=false;
			boolean isTms=false;
			boolean isArt=false;
			boolean isSOP = false;
			boolean isPI = false;
			boolean isQual = false;
			boolean isRmpi = false;
			boolean isSPS = false;
			boolean isILST = false;


			if(ConstantsUtil.TYPE_PGAUTHORIZEDTEMPORARYSTANDARD.equalsIgnoreCase(sObjectType) || ConstantsUtil.TYPE_PGSTRUCTUREDAUTHORIZEDTEMPORARYSTANDARD.equalsIgnoreCase(sObjectType)) { //Modified by Ketan for Req. no. 47957
				isAts=true;
			}
			if(ConstantsUtil.TYPE_PGAUTHORIZEDCONFIGURATIONSTANDARD.equalsIgnoreCase(sObjectType)) {
				isAcs=true;
			}
			if(ConstantsUtil.TYPE_FORMULATECHNICALSPEC.equalsIgnoreCase(sObjectType)) {
				isIaps=true;
			}
			if(ConstantsUtil.TYPE_PGPROCESSSTANDARD.equalsIgnoreCase(sObjectType)) {
				isProc=true;
			}
			if(ConstantsUtil.TYPE_PGMAKINGINSTRUCTIONS.equalsIgnoreCase(sObjectType)) {
				isMi=true;
			}
			if(ConstantsUtil.TYPE_PGLABORATORYINDEXSPECIFICATION.equalsIgnoreCase(sObjectType)) {
				isLis=true;
			}
			if(ConstantsUtil.TYPE_TESTMETHOD.equalsIgnoreCase(sObjectType)) {
				isTms=true;
			}
			if(ConstantsUtil.TYPE_PGARTWORK.equalsIgnoreCase(sObjectType)) {
				isArt=true;
			}
			if(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE.equalsIgnoreCase(sObjectType)) {
				isSOP=true;
			}
			if(ConstantsUtil.TYPE_PGPACKINGINSTRUCTIONS.equalsIgnoreCase(sObjectType)) {
				isPI=true;
			}
			if(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION.equalsIgnoreCase(sObjectType)) {
				isQual=true;
			}
			if(ConstantsUtil.TYPE_RAW_MATERIAL_PLANT_INSTRUCTION.equalsIgnoreCase(sObjectType)) {
				isRmpi=true;
			}
			if(ConstantsUtil.TYPE_PGSTACKINGPATTERN.equalsIgnoreCase(sObjectType)) {
				isSPS=true;
			}
			if(ConstantsUtil.TYPE_PGILLUSTRATION.equalsIgnoreCase(sObjectType)) {
				isILST=true;
			}
			if(ConstantsUtil.TYPE_PGILLUSTRATION.equalsIgnoreCase(sObjectType)) {
				isILST=true;
			}
			/**
			 * LOAD HEADER CONTENT SECTION
			 * */
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			mpHeaderContent.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			if(!isArt){
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
			}
			mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.NOTAPPICABLE);//Modified by Ketan for Req no. 1137
			String sClassification1 = util.getClassification(resultMaps);
			mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, (sClassification1));
			/**
			 * LOAD RELATED ATS SECTION
			 * */
			StopWatch swAts = new StopWatch();
			swAts.start();
			String strAttrValue = (String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGORIGINATINGSOURCE);
			//String strObjSymbType = (String)resultMaps.get(ConstantsUtil.SELECT_TYPE);

			//String strAllStates=	validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ATL_STATE));
			//StringList slFromTypeState =FrameworkUtil.split(strAllStates, ",");

			//boolean isDSO = (("DSO".equalsIgnoreCase(strAttrValue))?true:false);

			//boolean isAPMP = dobCdoc.isKindOf(context, ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART);
			//boolean isTechSpec = dobCdoc.isKindOf(context, ConstantsUtil.TYPE_TECHNICALSPECIFICATION);

			String sHasATSAttrVal = util.checkHasATSForSIS (context, resultMaps);

			Map mphasATS=util.getRelatedAts(context, dobCdoc);

			mphasATS=util.filterMapList(mphasATS);
			mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
			swAts.stop();
			LOGGER.info("COMMON DOC SERVICE ATS ELAPSED TIME : "+swAts.getTime());

			if(sType.equalsIgnoreCase("SOP") || isTms) {
				mpAttribResult.put(ConstantsUtil.SHARABLEWITHEXTERNALBUSINESSPARTNERS, sSharable);
			}

			if(isTms) {

				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)));
				mpAttribResult.put(ConstantsUtil.SUBTYPE, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtilIRM.SELECT_REL_SUBTYPE)));
				mpAttribResult.put(ConstantsUtil.REPORTTONEAREST, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST)));
				mpAttribResult.put(ConstantsUtil.CHARACTERISTIC, validator.getStringEquivalentForSubstituteStringTitle(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC)));//SPEC: 12-08-2022: Pooja Modified  for Internal Defect
				mpAttribResult.put(ConstantsUtil.UNITOFMEASURE, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE)));
				mpAttribResult.put(ConstantsUtil.CHARACTERISTICSPECIFICS, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS)));
				//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- START
				mpAttribResult.put(ConstantsUtilIRM.AUTHORINGAPPLICATION, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTHORINGAPPLICATION)));
				//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- END
			}
			if(isAts) {
				//Related Parts
				mpRelatedParts=cdoc.getRelatedParts(context,resultMaps);

				//SPEC: <01.06.2022>: Satyam Added for Req 42769, 34417  -- START
				mpAttribResult.put(ConstantsUtilIRM.PGISATSSPECIFICTOIMPACTEDPARTORSPECREV, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISATSSPECIFICTOIMPACTEDPARTORSPECREV)));
				//SPEC: <01.06.2022>: Satyam Added for Req 42769, 34417  -- END
			}
			//SPEC: 20-06-2022: Satyam Added for Internal Defect -- START
			if((isRmpi || isPI || isSPS || isILST) && isInternal) {
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)));
			}
			//SPEC: 20-06-2022: Satyam Added for Internal Defect -- END
			if(bisIRMDoc) {
				boolean bisStudyProtocolDoc = commonDoc.isStudyProtocol(sSpecType);
				if(bisStudyProtocolDoc) {
					mpRelatedParts=cdoc.getLegDetails(context, objId);
				}else {
					mpRelatedParts=cdoc.getRelatedPartsforIrmDocs(context, resultMaps);
				}
				DeviceProductPartBO DPPBO = new DeviceProductPartBO();
				mpGpsAssessment = DPPBO.getGPSAssessments(context, sObjectId);
				mpGpsAssessment = util.filterMapList(mpGpsAssessment);
				mpMultipleOwnershipAccess = cdoc.getMultipleOwnershipAccess(context, sObjectId);
				mpPlatformAndChassis = cdoc.getPlatformChassis(context, sObjectId);
				if(!bisStudyProtocolDoc) {
					mpPlatformAndChassis.put(ConstantsUtil.AUTHORINGAPPLICATION, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION)));
				}
				mpPlatformAndChassis = util.filterMapList(mpPlatformAndChassis);
			}

			if ( isProc || isMi || isLis )
			{	
				mpMultipleOwnershipAccess = cdoc.getMultipleOwnershipAccess(context, sObjectId);
				hmAttrib.put(ConstantsUtil.RELATEDATS, mphasATS);

				if(isExternal) 
				{
					//hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.FILES)?hmAttrib.remove(ConstantsUtil.FILES) :ConstantsUtil.EMPTY_STRING);//Added by Ajay for Req No. 123134
					hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.PLANTS)?hmAttrib.remove(ConstantsUtil.PLANTS) :ConstantsUtil.EMPTY_STRING);
				}
			}
			//Related ATS
			if(!isAts) {

				StringBuilder sbPartType = new StringBuilder();
				StringBuilder sbPartID = new StringBuilder();
				StringBuilder sbPartName = new StringBuilder();
				StringBuilder sbPartState = new StringBuilder();
				StringBuilder sbPartTitle = new StringBuilder();
				StringBuilder sbPartPhase = new StringBuilder();

				StringList busSelect = new StringList();
				busSelect.add(ConstantsUtil.SELECT_NAME);
				busSelect.add(ConstantsUtil.SELECT_ID);
				busSelect.add(ConstantsUtil.SELECT_TYPE);
				busSelect.add(ConstantsUtil.SELECT_CURRENT);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				busSelect.add(ConstantsUtil.STR_IPCLASS);
				busSelect.add(ConstantsUtil.STR_IPCLASS_TYPE);

				//String strWhere = "current==Release";

				MapList mapList = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION, DomainConstants.QUERY_WILDCARD,
						busSelect, null, true, false, (short) 1, null, null,
						ConstantsUtil.ZERO_LEVEL);

				Iterator objectListItr = mapList.iterator();
				while(objectListItr.hasNext())
				{
					Map mpTemp = (Map) objectListItr.next();

					String sPartType = util.mapType(validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_TYPE))));
					String sPartID = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_ID)));
					String sPartName = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_NAME)));
					String sPartState = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_CURRENT)));
					String sPartTitle = validator.getStringEquivalentForSubstituteString((mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
					String sPartPhase = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)));
					String sPartClass = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.STR_IPCLASS)));
					//String sPartClassType = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.STR_IPCLASS_TYPE)));

					if (!sPartState.equals((ConstantsUtil.STATE_RELEASE).trim())) {
						continue;
					}
					
					boolean showData = util.checkHasAccess(context, sUserType, sPartID);

					if (!showData) {
						continue;
					}
					sPartType = util.replaceSpecialSymbols(sPartType);
					sPartID = util.replaceSpecialSymbols(sPartID);
					sPartName = util.replaceSpecialSymbols(sPartName);
					sPartState = util.replaceSpecialSymbols(sPartState);
					//sPartTitle = util.replaceSpecialSymbols(sPartTitle);
					sPartPhase = util.replaceSpecialSymbols(sPartPhase);
					sPartClass = util.replaceSpecialSymbols(sPartClass);

					util.formatData(sbPartType, sPartType);
					util.formatData(sbPartID, sPartID);
					util.formatData(sbPartName, sPartName);
					util.formatData(sbPartState, sPartState);
					util.formatData(sbPartTitle, sPartTitle);
					util.formatData(sbPartPhase, sPartPhase);

					mpRelatedAts.put(ConstantsUtil.NAME, sbPartName.toString());
					mpRelatedAts.put(ConstantsUtil.ID, sbPartID.toString());
					mpRelatedAts.put(ConstantsUtil.TYPE, sbPartType.toString());
					mpRelatedAts.put(ConstantsUtil.STATE, sbPartState.toString());
					mpRelatedAts.put(ConstantsUtil.TITLE, sbPartTitle.toString());
					mpRelatedAts.put(ConstantsUtil.PHASE, sbPartPhase.toString());

				}

				if (isExternal){
					mpRelatedAts = cdoc.validateRelatedATS(context,mpRelatedAts);
					mpRelatedAts = util.filterPhase(mpRelatedAts);
				}
				mpRelatedAts=util.filterMapList(mpRelatedAts);
				if(!mpRelatedAts.isEmpty()){
					mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
				}
				else{
					mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
				}
			}

			mpPlant.put(ConstantsUtil.PLANTS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_NAME)));
			//Req 35177 and 35170
			if(isAts || isProc || isMi || isLis || isSOP) {
				mpPlant.put(ConstantsUtil.AUTHORIZED, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW)));
			}
			else {
				mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOPRODUCE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE)));
			}
			//Organizations
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME))));
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME))));
			mpOrganization = BbUtil.filterMapList(mpOrganization);

			//ATTRIBUTE SECTION
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Common Attributes for all Specification Templates
			mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID))));
			String sSchemaSpecTypeName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
			String sDocType = util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE)));
			mpAttribResult.put(ConstantsUtil.TYPE, sDocType);

			String user = (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_OWNER)));
			String owner = PersonUtil.getFullName(context,user);
			mpAttribResult.put(ConstantsUtil.OWNER, owner);
			if(sObjectType.equalsIgnoreCase("pgStandardOperatingProcedure")) {
				mpAttribResult.put(ConstantsUtil.OWNER, user);
			}
			else if(sObjectType.equalsIgnoreCase("pgPackingInstructions")) {
				mpAttribResult.put(ConstantsUtil.OWNER, owner);
			}

			if(!bisIRMDoc) {
				mpAttribResult.put(ConstantsUtil.STATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT))));
			}
			mpAttribResult.put(ConstantsUtil.ORIGINATED, validator.DateFormatterParse((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))));
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);			
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))));
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, validator.DateFormatterParse((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_DOCEXPIRATIONDATE)))));
			if(isAcs || isIaps || isMi || isProc || isLis || isRmpi || isSPS || isTms || isILST || isQual || isSOP || isPI){
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			}
			//IRM DOC ATTRIBUTES
			if(bisIRMDoc) {
				mpAttribResult.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.POLICY, BbUtil.mapType((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_POLICY)))));
				mpAttribResult.put(ConstantsUtil.MODIFIEDDATE, validator.DateFormatter((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))));
				//SPEC: <29.08.2022>: Guna Modified for 50453 Defect   Dev 22x    -- START
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.getStringEquivalentForSubstituteStringTitle(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE))));
				//SPEC: <29.08.2022>: Guna Modified for 50453 Defect   Dev 22x    -- END
				if(isExternal)
				{
					mpAttribResult.put(ConstantsUtil.PROJECTID, ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.PROJECTNAME, ConstantsUtil.EMPTY_STRING);
				}
				else {
				mpAttribResult.put(ConstantsUtil.PROJECTID,  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtilIRM.SELECT_PROJECTSPACE_PROJECTID)));//SPEC: 23-08-2022: Pooja Modified for Internal Defect
				mpAttribResult.put(ConstantsUtilIRM.PROJECTNAME, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_PROJECTDOCUMENT_NAME)));//SPEC: 23-08-2022: Pooja Modified for Internal Defect
				}
				mpAttribResult.put(ConstantsUtilIRM.REGION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGION)));
				String strBusinessArea = ConstantsUtil.EMPTY_STRING;
				String strFinalBusinessArea = ConstantsUtil.EMPTY_STRING;
				StringList slBusinessArea  = new StringList();				
				slBusinessArea =  dobCdoc.getInfoList(context, ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSAREA);				
				for (int k = 0; k < slBusinessArea.size(); k++) {
					strBusinessArea = (String) slBusinessArea.get(k);
					strFinalBusinessArea += strBusinessArea;
					if (slBusinessArea.size()-1>k) {																
						strFinalBusinessArea += ConstantsUtil.SYMBL_PIPE;
					}
				}
				mpAttribResult.put(ConstantsUtil.BUSINESSAREA, strFinalBusinessArea);
				switch (sSchemaSpecTypeName) {
				case "pgPKGValidationProtocol":
					mpAttribResult.put(ConstantsUtilIRM.VALIDATIONSTEP,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSTEP)));
					mpAttribResult.put(ConstantsUtilIRM.VALIDATIONSYSTEM,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSYSTEM)));
					mpAttribResult.put(ConstantsUtilIRM.SITE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSITE)));
					mpAttribResult.put(ConstantsUtilIRM.INITIATIVE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGINITIATIVE)));

					break;
				case "pgValidationOther":
					mpAttribResult.put(ConstantsUtilIRM.VALIDATIONSTEP,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSTEP)));
					mpAttribResult.put(ConstantsUtilIRM.VALIDATIONSUBTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGVALIDATIONTYPE)));
					mpAttribResult.put(ConstantsUtilIRM.SITE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSITE)));
					mpAttribResult.put(ConstantsUtilIRM.VALIDATIONSYSTEM,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSYSTEM)));
					mpAttribResult.put(ConstantsUtilIRM.INITIATIVE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGINITIATIVE)));

					break;
				case "pgPKGValidationReport":
					mpAttribResult.put(ConstantsUtilIRM.VALIDATIONSTEP,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSTEP)));
					mpAttribResult.put(ConstantsUtilIRM.SITE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSITE)));
					mpAttribResult.put(ConstantsUtilIRM.VALIDATIONSYSTEM,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSYSTEM)));
					mpAttribResult.put(ConstantsUtilIRM.INITIATIVE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGINITIATIVE)));
					
					//Added by Ketan for Defect No. 51919 -- START
					//For fetching 'Validation Protocol' attribute
					MapList sValidationProtocolMapList = null;
					StringBuilder sValidationProtocol = new StringBuilder();
					StringList slObjectSelect 	= new StringList(1);
					slObjectSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String strProtocol = PropertyUtil.getSchemaProperty(context,"type_pgPKGValidationProtocol");
					sValidationProtocolMapList = 	dobCdoc.getRelatedObjects(context,
											ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT, 
											strProtocol, 
											slObjectSelect, 
											null, 
											true, 
											true, 
											(short)1, 
											null, 
											null,
											0);
					if(sValidationProtocolMapList != null && !sValidationProtocolMapList.isEmpty())
					{
						int sValidationProtocolMapListsize = sValidationProtocolMapList.size();
						for(int i=0; i < sValidationProtocolMapListsize; i++) {
							Map<String, String> sValidationProtocolMap = (Map)sValidationProtocolMapList.get(i);
							String sValidationProtocolTitle= sValidationProtocolMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							sValidationProtocol.append(sValidationProtocolTitle);
							sValidationProtocol.append(",");
					}
					}
					mpAttribResult.put(ConstantsUtilIRM.VALIDATIONPROTOCOL,sValidationProtocol.toString());
					//StringList vlProtocolId =validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTVPROTOCOLID));
					//StringList vlProtocolTitle =validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTFORVPROTOCOL));
					//String sValidationPrtcl =cdoc.getValidationProtocol(context,vlProtocolId,vlProtocolTitle);
					//mpAttribResult.put(ConstantsUtilIRM.VALIDATIONPROTOCOL,sValidationPrtcl);
					
					//Added by Ketan for Defect No. 51919 -- END
					
					break;
					
				case "pgPKGDevelopmentOther":
					mpAttribResult.put(ConstantsUtilIRM.GENERALINNOVATIONRECORDSUBTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGDEVELOPMENTTYPE)));
					mpAttribResult.put(ConstantsUtilIRM.DEVELOPMENTAREA,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGDEVELOPMENTTOAREA)));
					String sGeneralInnovationRecordSubtype = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGDEVELOPMENTTYPE)));
					//Added by Ajay for Req No. 86913 -- START
					if(sGeneralInnovationRecordSubtype.equalsIgnoreCase(ConstantsUtil.CERTIFICATION)){
						mpAttribResult.put(ConstantsUtilIRM.STR_MATERIALCERTIFICATION,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_IRMMATERIALCERTIFICATION)));
					}
					//Added by Ajay for Req No. 86913 -- END
					break;
				case "pgPKGProductReadiness":

					mpAttribResult.put(ConstantsUtilIRM.COREINNOVATIONRECORDSUBTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.REL_PGDOCUMENTTOSUBTYPE)));
					break;	
				case "pgPKGConsumerProposition":

					mpAttribResult.put(ConstantsUtilIRM.CONSUMERRESEARCHSUBTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.REL_PGDOCUMENTTOSUBTYPE)));
					mpAttribResult.put(ConstantsUtilIRM.CRPNUMBER,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCRPNUMBER)));
					mpAttribResult.put(ConstantsUtilIRM.GPSCLEARANCETRACKINGNUMBER,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGGPSCLEARANCE)));
					mpAttribResult.put(ConstantsUtilIRM.CONSUMERSTUDYLEG,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGCONSUMERSTUDYLEG)));
					break;
				case "pgPKGTechnicalR"
				+ "ationale":
			
				mpAttribResult.put(ConstantsUtilIRM.STUDYTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE)));
				String strStabilityStudyNumber =validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STABILITY_STUDY_NUMBER));

				mpAttribResult.put(ConstantsUtilIRM.STABILITYSTUDYNUMBER,strStabilityStudyNumber);

				mpAttribResult.put(ConstantsUtil.BOUNDARYCONDITIONS,validator.getStringEquivalentForSubstituteStringTitle(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS))); // Modified by Ketan for ALM Defect No. 50326

				mpAgeAndConditionControl.put(ConstantsUtilIRM.PRODUCTEXPIRATIONDATEREQUIRED,validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE)));
				mpAgeAndConditionControl.put(ConstantsUtil.TOTALSHELFLIFEDAYS,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE)));
				mpAgeAndConditionControl.put(ConstantsUtil.TEMPERATUREGROUP,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP)));
				mpAgeAndConditionControl.put(ConstantsUtil.HUMIDITYGROUP,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP)));
				mpAgeAndConditionControl.put(ConstantsUtilIRM.TEMPERATUREFREEZEPROTECTION,validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION)));
				mpAgeAndConditionControl.put(ConstantsUtilIRM.TEMPERATUREHEATPROTECTION,validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION)));

				String strStabilityTitle =validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECTABLE_ATTRIBUTE_TITLE));
				
				//Added by Ketan for Defect No. 51907 -- START
				//For fetching 'Stability Protocol' attribute
				
				/*String stabilityProtocol="";
				if(validator.isNotNullOrEmpty(strStabilityTitle) && validator.isNotNullOrEmpty(strStabilityStudyNumber)) {
					stabilityProtocol = strStabilityTitle +"["+strStabilityStudyNumber+"]";
				}
				mpAttribResult.put(ConstantsUtilIRM.STABILITYPROTOCOL,stabilityProtocol);*/
				
				MapList mlRelatedProtocolList = null;
				StringList slBusSelect = new StringList(2);
				slBusSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_STABILITY_STUDY_NUMBER);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String strStabilityStudyNumbr = ConstantsUtil.EMPTY_STRING;
				String stabilityProtocol = ConstantsUtil.EMPTY_STRING;
				String strdocTitle = ConstantsUtil.EMPTY_STRING;
				
				mlRelatedProtocolList = dobCdoc.getRelatedObjects(context,	//context
						ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,	// Relationship Pattern
						ConstantsUtil.TYPE_PGPKGSTABILITYPROTOCOL,	// Type pattern
						slBusSelect,	// bus selects
						null,			// rel selects
						true, 			// to
						false, 			//from
						(short)0,		//recursive
						null, 			// object where
						null,			// relationship where
						0);
				
				if(null != mlRelatedProtocolList && !mlRelatedProtocolList.isEmpty()) 
					{
						int mlRelatedProtocolListLength = mlRelatedProtocolList.size();
						for(int i=0; i < mlRelatedProtocolListLength; i++) {
							Map mlRelatedProtocol = (Map)mlRelatedProtocolList.get(0);
							strStabilityStudyNumbr = (String)mlRelatedProtocol.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STABILITY_STUDY_NUMBER);
							strdocTitle = (String)mlRelatedProtocol.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							stabilityProtocol = strdocTitle +"["+strStabilityStudyNumbr+"]";
							break;
						}
					}
				//Added by Ketan for Defect No. 51907 -- END
				mpAttribResult.put(ConstantsUtilIRM.STABILITYPROTOCOL,stabilityProtocol);
				
				break;
				case "pgStabilityOther":
					mpAttribResult.put(ConstantsUtilIRM.STUDYTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE)));
					mpAttribResult.put(ConstantsUtilIRM.STABILITYTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCSTABILITYTYPE)));
					break;
				case "pgPKGOutofSpec":
					mpAttribResult.put(ConstantsUtilIRM.STUDYTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE)));
					StringList vlStabilityId =validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTSTABILITYID));
					StringList vlStabilityTitle =validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtilIRM.REFERENCE_DOCUMENT_TITLE));
					String sSummaries =cdoc.getValidationProtocol(context,vlStabilityId,vlStabilityTitle);
					mpAttribResult.put(ConstantsUtilIRM.SUMMARIES, sSummaries);

					break;
				case "pgPKGStabilityProtocol":
					mpAttribResult.put(ConstantsUtilIRM.STUDYTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE)));
					mpAttribResult.put(ConstantsUtilIRM.STABILITYSTUDYNUMBER,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STABILITY_STUDY_NUMBER)));
					break;
				case "pgPKGTranslationFile":
					mpAttribResult.put(ConstantsUtil.LANGUAGE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE)));
					mpAttribResult.put(ConstantsUtilIRM.DEVELOPMENTAREA,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGDEVELOPMENTTOAREA)));
					break;
				case "pgPKGStabilityReport":
					mpAttribResult.put(ConstantsUtilIRM.STUDYTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE)));
					mpAttribResult.put(ConstantsUtil.BOUNDARYCONDITIONS,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS)));
					mpAttribResult.put(ConstantsUtilIRM.PRODUCTSIZE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTSIZE)));
					//AGE AND CONDITION CONTROL

					mpAgeAndConditionControl.put(ConstantsUtilIRM.PRODUCTEXPIRATIONDATEREQUIRED,validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE)));

					mpAgeAndConditionControl.put(ConstantsUtil.TOTALSHELFLIFEDAYS,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE)));
					mpAgeAndConditionControl.put(ConstantsUtil.TEMPERATUREGROUP,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP)));
					mpAgeAndConditionControl.put(ConstantsUtil.HUMIDITYGROUP,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP)));

					mpAgeAndConditionControl.put(ConstantsUtilIRM.TEMPERATUREFREEZEPROTECTION,validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION)));
					mpAgeAndConditionControl.put(ConstantsUtilIRM.TEMPERATUREHEATPROTECTION,validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION)));
					String stabilityStudyNumber =validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECTABLE_STABILITY_STUDYNUMBER));
					String stabilityTitle =validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECTABLE_ATTRIBUTE_TITLE));

					String strstabilityProtocol = ConstantsUtil.EMPTY_STRING;
					if(stabilityStudyNumber!=ConstantsUtil.EMPTY_STRING && stabilityTitle!=ConstantsUtil.EMPTY_STRING) {
						strstabilityProtocol = stabilityTitle +"["+stabilityStudyNumber+"]";
					}
					mpAttribResult.put(ConstantsUtilIRM.STABILITYPROTOCOL,strstabilityProtocol);

					mpAttribResult.put(ConstantsUtilIRM.STABILITYSTUDYNUMBER,stabilityStudyNumber);
					String strObjId =validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
					String strProductForm =cdoc.getProductFormSizeValue(context,strObjId,ConstantsUtilIRM.RELATIONSHIP_PRODUCTFORM,ConstantsUtilIRM.TYPE_PLIPRODUCTFORM);
					String strProductSize=cdoc.getProductFormSizeValue(context,strObjId,ConstantsUtilIRM.RELATIONSHIP_PRODUCTSIZEUOM,ConstantsUtilIRM.TYPE_PLIPACKSIZEUNIT);
					mpAttribResult.put(ConstantsUtil.PRODUCTFORM,strProductForm);
					mpAttribResult.put(ConstantsUtilIRM.PRODUCTSIZEUOM,strProductSize);
					break;
				//SPEC: Added by Ajay for Req. no. 89008 START
				case "pgPackagingMinimizationReport":
					mpAttribResult.put(ConstantsUtilIRM.STR_ASSESSMENTBASIS,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ASSESSMENTBASIS_LOCATION)));
					mpAttribResult.put(ConstantsUtilIRM.STR_ATTRIBUTE_ASSESSMENTLEVEL,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ASSESSMENTLEVEL)));
					break;
				//SPEC: Added by Ajay for Req. no. 89008 END
				case "pgPKGStudyProtocol":
					//STUDY OBJECTIVES AND SUCCESS CRITERIA
					mpStudyObjectivesAndSuccessCriteria.put(ConstantsUtilIRM.OBJECTIVE,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMPURPOSE)));
					mpStudyObjectivesAndSuccessCriteria.put(ConstantsUtilIRM.SUCCESSCRITERIA,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMSUCCESSCRITERIA)));
					mpStudyObjectivesAndSuccessCriteria.put(ConstantsUtilIRM.ACTIONTOBETAKEN,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMACTION)));
					mpStudyObjectivesAndSuccessCriteria.put(ConstantsUtilIRM.BACKGROUND,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMBACKGROUND)));
					//STUDY DESIGN

					mpStudyDesign.put(ConstantsUtilIRM.STUDYTYPEFORMAT,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPE)));
					mpStudyDesign.put(ConstantsUtilIRM.STUDYTYPEFORMATIFSELECTED,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_STUDYPROTOCOLTOSTUDYTYPE)));	

					mpStudyDesign.put(ConstantsUtilIRM.TYPEOFRESEARCH,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTYPEOFRESEARCH)));
					mpStudyDesign.put(ConstantsUtilIRM.CONFIDENCELEVELOFSIGNIFICANCETESTING,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMCONFIDENCELEVELSIGNIFICANCETESTING)));
					mpStudyDesign.put(ConstantsUtilIRM.TOTALNUMBEROFPANELISTS,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMTOTALNUMBEROFPANELISTS)));


					Pattern relPatternStudy = new Pattern(ConstantsUtil.RELATIONSHIP_PGSTUDYPROTOCOLTOADDITIONALSERVICES);
					StringList selectTypeStudy = new StringList(); 
					StringList selectRelStudy = new StringList(); 
					selectTypeStudy.add(ConstantsUtil.NAME);
					StringBuilder sbStudyAddService = new StringBuilder();

					MapList StudyAddServiceList = dobCdoc.getRelatedObjects(context,
							relPatternStudy.getPattern(),  //relationship pattern 
							DomainObject.QUERY_WILDCARD, // object pattern
							selectTypeStudy,                 // object selects
							selectRelStudy,              // relationship selects
							true,                        // to direction
							true,                       // from direction
							(short)1,                    // recursion level
							null,                        // object where clause
							null,
							0);
					Iterator objAddServiceItr = StudyAddServiceList.iterator();
					while(objAddServiceItr.hasNext()) 
					{
						Map objectMap = (Map) objAddServiceItr.next();
						util.formatData(sbStudyAddService, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.NAME)));
					}
					if(sbStudyAddService!=null && sbStudyAddService.length()>0) {
						String sStudyAddService = sbStudyAddService.toString().substring(0, sbStudyAddService.toString().length()-1);
						mpStudyDesign.put(ConstantsUtilIRM.ADDITIONALSERVICESNEEDED,sStudyAddService);
					}else {
						mpStudyDesign.put(ConstantsUtilIRM.ADDITIONALSERVICESNEEDED,sbStudyAddService.toString());
					}

					mpStudyDesign.put(ConstantsUtilIRM.REQUESTFORASINGLECONSUMERSTUDY,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSINGLECONSUMERSTUDY)));
					mpStudyDesign.put(ConstantsUtilIRM.REQUESTEDEXPIRATIONDATEFORASSESSMENT,validator.DateFormatterParse(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGREQUESTEDEXPIRATIONDATE))));
					mpStudyDesign.put(ConstantsUtilIRM.TECHNIQUEUSED,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.REL_TECHNIQUE_USED)));
					mpStudyDesign.put(ConstantsUtilIRM.TECHNIQUEOTHER,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_TECHNIQUEOTHER)));
					mpStudyDesign.put(ConstantsUtilIRM.FEEDBACKTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.REL_FEEDBACKTYPE)));
					mpStudyDesign.put(ConstantsUtilIRM.DESCRIPTIONMETHODOLOGY,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_DESCRIPTIONMETHODOLOGY)));
					mpStudyDesign.put(ConstantsUtilIRM.OBJECTIVETYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.REL_OBJECTIVETYPE)));
					mpStudyDesign.put(ConstantsUtilIRM.OBJECTIVETYPEOTHER,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_OBJECTIVETYPEOTHER)));
					//SPEC: <02.06.2022>: Guna Added for Req 36041 22x Release  -- START
					String isFileUploaded =validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGHASPARTICLESIZEDISTRIBUTIONFILE));
					mpStudyDesign.put(ConstantsUtilIRM.HASPARTICLESIZEDISTRIBUTION,isFileUploaded);
					//SPEC: <02.06.2022>: Guna Added for Req 36041 22x Release  -- END

					//STUDY CLASSIFICATION

					mpStudyClassification.put(ConstantsUtilIRM.STUDYCLASS,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYCLASS_NAME)));
					mpStudyClassification.put(ConstantsUtilIRM.DATAUSE,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMDATAUSE)));
					mpStudyClassification.put(ConstantsUtilIRM.OVERALLREGULATORYCLASSIFICATION,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOREGULATORYCLASSIFICATION)));
					//SPEC: 26-08-2022: Pooja added for Defect 50362
					MapList mlLatestVersion1 =cdoc.getLatestVersions(context,objId);
					String strStudyClinic =cdoc.getConsumerAndDPICFile(context,mlLatestVersion1,ConstantsUtilIRM.CONST_STUDYCLINIC);
					mpStudyClassification.put(ConstantsUtilIRM.CLINICALSTUDY,strStudyClinic);
					//SPEC: 26-08-2022: Pooja added for Defect 50362
					mpStudyClassification.put(ConstantsUtilIRM.HAVEYOUNOTIFIEDTHEPATENTOFFICE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNOTIFYPATENTOFFICE)));
					mpStudyClassification.put(ConstantsUtilIRM.PURCHASEINTENT, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PURCHASEINTENT)));
					StringList countryList =validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.strPGCountry));
					if(countryList.contains("UNITED STATES")){
						mpStudyClassification.put(ConstantsUtilIRM.TSCAINGREDIENTS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_TSCAINGREDIENTS)));
						mpStudyClassification.put(ConstantsUtilIRM.PANELISTPURCHASEINTENT, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PANELISTPURCHASEINTENT)));
					}

					//PANELIST RECRUITING CRITERIA
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.PANELISTTYPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOPANELISTTYPE_NAME)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.ISPANELISTEXCLUSIONCRITERIADEFINED,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTORACE_NAME)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.GENDER,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOGENDER)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.AGECONSTRAINTLOWERLIMIT,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERAGELIMIT)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.AGECONSTRAINTUPPERLIMIT,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERRAGELIMIT)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.ETHNICITYRACE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_ETHNICITYTORACE)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.BALANCINGCRITERIA,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBALANCINGCRITERIA)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.USEDFORPGMANAGEMENTSAMPLES,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMANAGEMENTSAMPLES)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.WILLPRODUCTUSEDFORRDTEAMTEST,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTUSEDFORRND)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.IFPRODUCTUSERAGERANGEISNOTPROVIDED,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTRANGENOTPROVIDED)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.ISPANELISTINCLUSIONCRITERIADEFINED,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTINCLUSIONCRITERIA)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.ISPANELISTEXCLUSIONCRITERIADEFINED,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTEXCLUSIONCRITERIA)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.NATIVENUMBER,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_NATIVENUMBER)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.EXPERIENCEDNUMBER,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXPERIENCEDNUMBER)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.RECONTACTNUMBER,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RECONTACTNUMBER)));
					mpPanelistRecruitingCriteria.put(ConstantsUtilIRM.GRANTEDCONSENT,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_GRANTEDCONSENT)));
					//SPECIAL PRODUCT ELEMENTS
					mpSpecialProductElements.put(ConstantsUtilIRM.UNIQUECONSUMERPACKAGESHAPE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTUNIQUECONSUMERPACKAGE)));
					mpSpecialProductElements.put(ConstantsUtilIRM.ANCILLARYITEMSPROVIDEDTOPANELIST,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTANCILLIARYSUPPORTINGITEMS)));
					mpSpecialProductElements.put(ConstantsUtilIRM.ISSTABILITYDATAREQUIRED,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTSTABILITYDATAREQUIRED)));
					mpSpecialProductElements.put(ConstantsUtilIRM.LOCATIONOFSTABILITYDATA,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLOCATIONOFSTABILITY)));
					mpSpecialProductElements.put(ConstantsUtilIRM.STABILITYTESTING,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STABILITYTESTING)));
					//SPEC: <08.06.2022>: Guna Modified for Req 36041 22x Release  -- START
					MapList mlLatestVersion =cdoc.getLatestVersions(context,objId);
					String strConsumerLabel =cdoc.getConsumerAndDPICFile(context,mlLatestVersion,ConstantsUtilIRM.CONST_CONSUMERTESTLABEL);
					String strDPICFile =cdoc.getConsumerAndDPICFile(context,mlLatestVersion,ConstantsUtilIRM.CONST_DPICFILE);
					mpSpecialProductElements.put(ConstantsUtilIRM.CONSUMERTESTLABEL,strConsumerLabel);
					mpSpecialProductElements.put(ConstantsUtilIRM.DPICFILE,strDPICFile);
					//SPEC: <08.06.2022>: Guna Modified for Req 36041 22x Release  -- END

					//PANELIST TASK
					mpPanelistTask.put(ConstantsUtilIRM.REQUIREDPANELISTPERMISSIONTOSHAREPII,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTUDYPANELISTEMAILADDRESS)));
					mpPanelistTask.put(ConstantsUtilIRM.PRODUCTUNDERSUPERVISIONBYPG,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_RELATION_PGSTUDYSUPERVISED)));
					mpPanelistTask.put(ConstantsUtilIRM.PANELISTSREQUIREDTOCOMPLETEPREWORK,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.REL_PENELISTTASK)));
					mpPanelistTask.put(ConstantsUtilIRM.PANELISTSREQUIREDTORETURNTESTPRODUCT,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTUDYPANELISTMATERIALS)));
					mpPanelistTask.put(ConstantsUtilIRM.PANELISTSIGNANINFORMEDCONSENT,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTSIGNINFORMEDCONSENT)));
					mpPanelistTask.put(ConstantsUtilIRM.EXPECTEDPANELISTCOMPENSATION,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGEXPECTEDPANELISTCOMPENSATION)));
					mpPanelistTask.put(ConstantsUtilIRM.WILLPANELISTTOSIGNCDA,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTUDYCDASIGNEDFORPANELIST)));
					mpPanelistTask.put(ConstantsUtilIRM.DESCRIBETHEPANELISTINTERACTION,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDESCRIBEPANEISTINTERATION)));

					mpPanelistTask.put(ConstantsUtilIRM.AREPANELISTINSTRUCTIONSATTACHED,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTINSTRUCTIONATTACHED)));
					mpPanelistTask.put(ConstantsUtilIRM.PANELISTREQUIREDFORINDEPTH,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTFOCUSGROUPINTERVIEW)));
					String sPanelInclusionCretira = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTINCLUSIONCRITERIA));
					if(validator.isNotNullOrEmpty(sPanelInclusionCretira)) {
						mpPanelistTask.put(ConstantsUtilIRM.ISPANELISTEXCLUSIONCRITERIADEFINED,ConstantsUtil.SYMBL_YES);
					}else {
						mpPanelistTask.put(ConstantsUtilIRM.ISPANELISTEXCLUSIONCRITERIADEFINED,"");
					}
					mpPanelistTask.put(ConstantsUtilIRM.PANELISTTASKOTHER,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PANELISTTASKOTHER)));

					//GPS ASSESSMENT TYPE
					mpGpsAssessmentType.put(ConstantsUtilIRM.ISGPSAPPROVALREQUIRED,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGPSAPPROVALREQUIREDTORELEASESTUDY)));
					mpGpsAssessmentType.put(ConstantsUtilIRM.EXISTINGGPSASSESSMENTENTERTASK,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_IRMNRQID)));
					mpGpsAssessmentType.put(ConstantsUtilIRM.USEPRODUCTBYPGCONTRACTMANUFACTUREE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGUSEPRODUCTBYCONTRACTMANUFORCOMPETITOR)));
					mpGpsAssessmentType.put(ConstantsUtilIRM.EXISTINGGPSASSESSMENTENTERLEGACY,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLEGACYRQID)));
					//SPEC: <02.06.2022>: Guna Added for Req 36041 22x Release  -- START
					mpGpsAssessmentType.put(ConstantsUtilIRM.GPSAPPROVEDBOUNDARY,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_GPSAPPROVEDBOUNDRY)));
					//SPEC: <02.06.2022>: Guna Added for Req 36041 22x Release  -- END

					mpStudyLocationDates.put(ConstantsUtilIRM.MARKETOFSTUDYPLACEMENT,validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.strPGCountry)));
					mpStudyLocationDates.put(ConstantsUtilIRM.ESTIMATEDSTUDYSTARTDATE,validator.DateFormatterParse(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTUDYLAUNCHDATE))));
					mpStudyLocationDates.put(ConstantsUtilIRM.ADDRESSIFOTHERTHANPGSITE,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGADDRESSOTHERPGSITE)));
					mpStudyLocationDates.put(ConstantsUtilIRM.DURATIONOFSTUDY,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDURATIONSTUDY)));


					mpStudyLocationDates.put(ConstantsUtilIRM.HOWWILLPRODUCTSARRIVE,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOASSEMBLYSTATE_NAME)));
					mpStudyLocationDates.put(ConstantsUtilIRM.LOCATIONOFPRODUCTUSEBYPANELIST,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTUSELOCATION)));
					mpStudyLocationDates.put(ConstantsUtilIRM.STORAGEOFUNPLACEDPRODUCT,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTORAGEUNPLACEDPRODUCT)));
					mpStudyLocationDates.put(ConstantsUtilIRM.IFLOCATIONISOTHERENTERDETAILSHERE,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGOTHERLOCATION)));
					mpStudyLocationDates.put(ConstantsUtilIRM.UNPLACEDPRODUCTBEDISPOSED,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSURPLUSDISPOSITION)));
					mpStudyLocationDates.put(ConstantsUtilIRM.RETURNADDRESS,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRETURNADDRESS)));
					mpStudyLocationDates.put(ConstantsUtilIRM.LOCATIONFORDISTRIBUTINGPRODUCTS,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLOCATIONFORDISTRIBUTINGPRODUCTS)));

					mpAgencyTasks.put(ConstantsUtilIRM.AGENCY,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGAGENCY)));
					mpAgencyTasks.put(ConstantsUtilIRM.PLACEMENTFIELDINGINSTRUCTIONS,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPLACEMENTFIELDINGINSTRUCTIONS)));
					mpAgencyTasks.put(ConstantsUtilIRM.ESTIMATEDFIELDINGSCHEDULE,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGESTIMATEDFIELDINGSCHEDULE)));
					mpAgencyTasks.put(ConstantsUtilIRM.DATACOLLECTIONMETHODS,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATACOLLECTIONMETHODS_NAME)));
					mpAgencyTasks.put(ConstantsUtilIRM.DATAMERGENEEDED,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATAMERGE_NAME)));
					mpAgencyTasks.put(ConstantsUtilIRM.DATAOUTPUT,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOATTACHMENTFORMAT_NAME)));
					mpAgencyTasks.put(ConstantsUtilIRM.REQUESTEDSITEBOOKINGFORINTERVIEWS,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYLOCATIONS)));
					mpAgencyTasks.put(ConstantsUtilIRM.REQUESTEDSITESCHEDULEFORINTERVIEWS,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGREQUESTEDSITESCHEDULE)));
					mpBudgetOwnerApproval.put(ConstantsUtilIRM.BUDGETAPPROVER,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBUDGETAPPROVER)));
					mpBudgetOwnerApproval.put(ConstantsUtilIRM.ESTIMATEDCOMPLETIONDATEOFSTUDY,validator.DateFormatterParse(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGESTIMATEDCOMPLETIONDATEOFSTUDY))));
					mpBudgetOwnerApproval.put(ConstantsUtilIRM.COSTOFPLACINGEXECUTION,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOSTOFPLACINGEXECUTION)));
					mpBudgetOwnerApproval.put(ConstantsUtilIRM.CURRENCY,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCURRENCY)));
					mpBudgetOwnerApproval.put(ConstantsUtilIRM.PO,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPO)));
					mpBudgetOwnerApproval.put(ConstantsUtilIRM.BUDGETCCORIO,validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBUDGETCCIO)));
					break;
				}
			}else {
				//All OTHER SPEC TYPE ATTRIBUTES
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR))));
				String strSegment =	validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT));
				if(isSPS || (isQual && UIUtil.isNotNullAndNotEmpty(strSegment)) || isILST || isPI){
					mpAttribResult.put(ConstantsUtil.SEGMENT, strSegment);
				}else{
					mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STRSEGMENT))));
				}
				mpAttribResult.put(ConstantsUtil.SAPTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))));
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE))));
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, validator.DateFormatterParse((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))));
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, validator.DateFormatterParse((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))));
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, validator.DateFormatterParse((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))));
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION))));
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT))));
				if(dobCdoc.isKindOf(context, ConstantsUtil.TYPE_TECHNICALSPECIFICATION))
				{
					mpAttribResult.put(ConstantsUtil.PHASE, ConstantsUtil.NOT_APPLICABLE);
				}else{
					mpAttribResult.put(ConstantsUtil.PHASE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE))));
				}
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, validator.DateFormatterParse((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))));

				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION))));

				String strPhase = (String)mpAttribResult.get(ConstantsUtil.PHASE);
				if(UIUtil.isNullOrEmpty(strPhase)){
					if (ConstantsUtil.FIRST_LEVEL_DOC_IAPS.equalsIgnoreCase(sDocType)
							|| ConstantsUtil.TYPE_RMPI.equalsIgnoreCase(sDocType)
							|| ConstantsUtil.FIRST_LEVEL_DOC_MI.equalsIgnoreCase(sDocType)
							|| ConstantsUtil.FIRST_LEVEL_DOC_LIS.equalsIgnoreCase(sDocType)
							|| ConstantsUtil.FIRST_LEVEL_DOC_ACS.equalsIgnoreCase(sDocType)
							|| ConstantsUtil.FIRST_LEVEL_DOC_PROS.equalsIgnoreCase(sDocType)
							|| ConstantsUtil.FIRST_LEVEL_DOC_ATSTANDARD.equalsIgnoreCase(sDocType)
							|| ConstantsUtil.FIRST_LEVEL_DOC_QUAL.equalsIgnoreCase(sDocType)
							|| ConstantsUtil.FIRST_LEVEL_DOC_SP.equalsIgnoreCase(sDocType)
							|| ConstantsUtil.FIRST_LEVEL_DOC_ILST.equalsIgnoreCase(sDocType)) {
						mpAttribResult.put(ConstantsUtil.PHASE, ConstantsUtil.NOT_APPLICABLE);
					}
				}
				String sClassifictaion = util.getClassification(resultMaps);
				if(!bSupplierView){
					mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
				}
			}
			if(bAllInfoView)
			{
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				Map mpLifeCycleApproval = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("COMMON DOC SERVICE GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				if(isSOP || isTms || isPI || isQual || isRmpi || isSPS || isLis || isAcs || isIaps || isILST || isProc || isMi)
				{
					mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);

				}
			}
			if(isQual) {
				String sOriginated =validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE));
				if(!sOriginated.equals(ConstantsUtil.DSO)){
					String strQualSpecSubType = cdoc.getQualitySpecificationSubType(context,sObjectId); 
					mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, strQualSpecSubType);
				}else{
					mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)));
				}
			}
			swAttributes.stop();
			LOGGER.info("COMMON DOC SERVICE GET ATTRIBUTE ELAPSED TIME : "+swAttributes.getTime());

			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */

			StopWatch swReferenceDoc= new StopWatch();
			swReferenceDoc.start();
			MasterCOPBO mcop = new MasterCOPBO();
			mapReferenceDocs = cdoc.updateRefDocs(context, resultMaps,bisIRMDoc);
			mapReferenceDocs=util.filterMapList(mapReferenceDocs);
			swReferenceDoc.stop();
			LOGGER.info("COMMON DOC SERVICE  REFERENCE DOCS ELAPSED TIME : "+swReferenceDoc.getTime());			
			StopWatch swSpecs = new StopWatch();
			swSpecs.start();	
			if (!isAts) {	
				mpPartSpecResult=cdoc.getPartSpecifications(context, sType, sObjectId,ldapuser,ldappwd);
			}else{

				mpPartSpecResult=cdoc.getPartSpecs(context,resultMaps, sType);
			}

			swSpecs.stop();
			LOGGER.info("COMMON DOC SERVICE GET RELATED SPECIFICATIONS ELAPSED TIME : "+swSpecs.getTime());


			//Related IAPS only for type ACS
			mpAcs = cdoc.getRelatedACS(context,dobCdoc );

			if(util.isModificatinRequired()){
				mpAcs =cdoc.removeNoAccessParts(context,mpAcs);
			}
			mpAcs=util.filterStateByRelease(mpAcs);

			if( sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP) &&  sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){

				mpAcs=util.filterPhase(mpAcs);
			}


			//SPEC: <13.10.2020>: Modified for the Release 18x5 -- START--
			//Related ACS only for type IAPS
			StringBuilder sbIapsName = new StringBuilder();
			StringBuilder sbIapsId = new StringBuilder();
			StringBuilder sbIapsType = new StringBuilder();
			StringBuilder sbIapsRev = new StringBuilder();
			StringBuilder sbIapsTitle = new StringBuilder();
			StringBuilder sbIapsPhase = new StringBuilder();
			StringBuilder sbIapsState = new StringBuilder();

			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.SELECT_NAME);
			busSelect.add(ConstantsUtil.SELECT_ID);
			busSelect.add(ConstantsUtil.SELECT_TYPE);
			busSelect.add(ConstantsUtil.SELECT_CURRENT);
			busSelect.add(ConstantsUtil.SELECT_REVISION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

			String strWhere = "current==Release";

			MapList mapList = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGAUTHORIZEDCONFIGURATIONSTANDARD, ConstantsUtil.SYMBL_ASTERISK,
					busSelect, null, true, false, (short) 1, strWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);

			Iterator objectListItr = mapList.iterator();
			while(objectListItr.hasNext())
			{
				Map mpTemp = (Map) objectListItr.next();
				String sName = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
				String sIapsType =  util.mapType(validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE)));
				String sRev =  validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
				String sState =  validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_CURRENT));
				String sTitle = validator.getStringEquivalentForSubstituteString(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sId =  validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ID));
				String sPhase = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

				//SPEC:  Commented for Defect 38380 on 01/29/2021 by Chandra -- START
				boolean showData = util.checkHasAccess(context, sUserType, sId);
				if(!showData && util.isModificatinRequired()){
					continue;
				}
				if (!showData) {
					sId=ConstantsUtil.NO_ACCESS;
					sState=ConstantsUtil.NO_ACCESS;
					sTitle=ConstantsUtil.NO_ACCESS;
				}

				util.formatData(sbIapsName, sName);
				util.formatData(sbIapsId, sId);
				util.formatData(sbIapsType, sIapsType);
				util.formatData(sbIapsRev, sRev);
				util.formatData(sbIapsState, sState);
				util.formatData(sbIapsTitle, sTitle);
				util.formatData(sbIapsPhase, sPhase);

			}

			mpIaps.put(ConstantsUtil.NAME, sbIapsName.toString().trim());
			mpIaps.put(ConstantsUtil.TYPE, sbIapsType.toString().trim());
			mpIaps.put(ConstantsUtil.REVISION, sbIapsRev.toString().trim());
			mpIaps.put(ConstantsUtil.STATE, sbIapsState.toString().trim());
			mpIaps.put(ConstantsUtil.TITLE, sbIapsTitle.toString().trim());
			mpIaps.put(ConstantsUtil.ID, sbIapsId.toString().trim());
			mpIaps.put(ConstantsUtil.PHASE, sbIapsPhase.toString().trim());
			String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			if( sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP) &&  sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				mpIaps=util.filterPhase(mpIaps);
			}

			if(isAcs || isIaps) {
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);

				mpAttribResult.put(ConstantsUtil.PROD_VARIANNT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT))));
				mpAttribResult.put(ConstantsUtil.TECHNOLOGY, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY))));
				mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, (validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.strIntendedMarket))));
				mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOUSE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE)));
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpMultipleOwnershipAccess = cdoc.getMultipleOwnershipAccess(context, objId);
			}
			if(isAts) {
				mpAttribResult.put(ConstantsUtil.IMPACTED_TYPE,util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_IMPACTEDTYPE))));
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			}
			//IP Class
			StringList slIpSelects = new StringList();
			slIpSelects.add(ConstantsUtil.SELECT_NAME);
			slIpSelects.add(ConstantsUtil.SELECT_ID);
			slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
			slIpSelects.add(ConstantsUtil.SELECT_TYPE);
			slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			if(!bisIRMDoc) {
				mpIPClass =commonBo.getIpClass(context, dobCdoc, slIpSelects);
			}else {
				mpIPClass =commonBo.getIpClass(context, dobCdoc, slIpSelects);
				mapReferenceDocs =cdoc.getReferenceDocsForIRM(context, resultMaps,bisIRMDoc);
			}
			if(isAts && isExternal) {
				//part
				hmAttrib.put(ConstantsUtil.RELATEDPARTS, mpRelatedParts);

				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
			} 
			else if(isAts && isInternal) {
				//part, plant, IPClass
				hmAttrib.put(ConstantsUtil.RELATEDPARTS, mpRelatedParts);
				hmAttrib.put(ConstantsUtil.PLANTS, mpPlant);
				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
			} 
			else if(!isAts) {
				if(isExternal) {
					//ats
					mpRelatedAts=util.filterMapList(mpRelatedAts);
					if(!mpRelatedAts.isEmpty()){
						mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
					}
					else{
						mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
					}
					hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);

					if(isAcs || isIaps){
						mpFiles.clear();
					}
					if(isAcs){
						hmAttrib.put(ConstantsUtil.RELIAPS, mpIaps);

					}
					if(isIaps){
						hmAttrib.put(ConstantsUtil.RELACS, mpAcs);
						hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
					}

				}else {
					if (sObjectType.equalsIgnoreCase("pgPackingInstructions")
							|| sObjectType.equalsIgnoreCase("pgStackingPattern")
							|| sObjectType.equalsIgnoreCase("pgIllustration")
							|| sObjectType.equalsIgnoreCase("pgQualitySpecification")
							|| sObjectType.equalsIgnoreCase("pgRawMaterialPlantInstruction")
							|| sObjectType.equalsIgnoreCase("pgStandardOperatingProcedure")
							|| sObjectType.equalsIgnoreCase("Test Method Specification")) {
						//ats, ipclasss
						mpRelatedAts=util.filterMapList(mpRelatedAts);
						if(!mpRelatedAts.isEmpty()){
							mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
						}
						else{
							mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
						}
						if(sObjectType.equalsIgnoreCase("pgRawMaterialPlantInstruction")) {
							mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
						}
						hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
						hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);
					} 
					else if(sObjectType.equalsIgnoreCase("pgMakingInstructions")
							|| sObjectType.equalsIgnoreCase("pgProcessStandard")
							|| sObjectType.equalsIgnoreCase("pgLaboratoryIndexSpecification")) {
						//Plant, ats, IPclass
						hmAttrib.put(ConstantsUtil.PLANTS, mpPlant);
						hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);
						mpIPClass.remove(ConstantsUtil.HASCLASSACCESS);
						if(isInternal) {
							hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
						}
					}
					else if(isAcs) {
						//plant, ats, IAPS, IPclass
						hmAttrib.put(ConstantsUtil.PLANTS, mpPlant);
						hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);
						hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
						hmAttrib.put(ConstantsUtil.RELIAPS, mpIaps);


					}
					else if(isIaps) {
						//plant, ats, ACS, IPclass
						hmAttrib.put(ConstantsUtil.PLANTS, mpPlant);
						hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);
						hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
						hmAttrib.put(ConstantsUtil.RELACS, mpAcs);
					}
				}

			}
			if(isArt) {
				mpAttribResult.put(ConstantsUtil.NEWIPMSPMPOPP, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ATTRIBUTE_IPMS))));
				mpAttribResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
			}
			if(isArt) {
				//MarketAproved
				mpMarketsApproved = cdoc.getMarketsApproved(context, resultMaps);
				hmAttrib.put(ConstantsUtil.MARKETSAPPROVED, mpMarketsApproved);
				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
			}
			// SPEC: Added for 18x.5.2 DEV --Shashank -- START
			if(bisIRMDoc) {
				hmAttrib.put(ConstantsUtil.RELATEDPARTS, mpRelatedParts);
				hmAttrib.put(ConstantsUtilIRM.PLATFORMCHASSIS, mpPlatformAndChassis);
				//SPEC: <09.03.2021>: Guna Modified for Dev 18x.6   -- START
				mpIPClass.remove(ConstantsUtil.CLASSIFICATIONPATH);
				//Added by Jwala for Internal Defect
				mpIPClass.remove(ConstantsUtil.LIBRARY);
				//Added by Jwala for Internal Defect
				//Commented by Jwala for Internal Defect
				//SPEC: <05.04.2022>: Guna Modified for Req 36041 22x Release  -- START
				mpIPClass.remove(ConstantsUtil.HASCLASSACCESS);
				mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				//Commented by Jwala for Internal Defect
				//SPEC: <05.04.2022>: Guna Modified for Req 36041 22x Release  -- END
				//SPEC: <05.04.2022>: Guna Modified for Req 38510 22x Release  -- START
				if(!isExternal) {
					hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
				}
				hmAttrib.put(ConstantsUtilIRM.ATTRAGEANDCONDITIONCONTROL, mpAgeAndConditionControl);
				hmAttrib.put(ConstantsUtilIRM.ATTRSTUDYOBJECTIVESANDSUCCESSCRITERIA, mpStudyObjectivesAndSuccessCriteria);
				hmAttrib.put(ConstantsUtilIRM.ATTRSTUDYDESIGN, mpStudyDesign);
				hmAttrib.put(ConstantsUtilIRM.ATTRSTUDYCLASSIFICATION, mpStudyClassification);
				hmAttrib.put(ConstantsUtilIRM.ATTRPANELISTRECRUITINGCRITERIA, mpPanelistRecruitingCriteria);
				hmAttrib.put(ConstantsUtilIRM.ATTRSPECIALPRODUCTELEMENTS, mpSpecialProductElements);
				hmAttrib.put(ConstantsUtilIRM.ATTRPANELISTTASK, mpPanelistTask);
				hmAttrib.put(ConstantsUtilIRM.ATTRGPSASSESSMENTTYPE, mpGpsAssessmentType);
				hmAttrib.put(ConstantsUtilIRM.ATTRSTUDYLOCATIONDATES, mpStudyLocationDates);
				hmAttrib.put(ConstantsUtilIRM.ATTRAGENCYTASKS, mpAgencyTasks);
				hmAttrib.put(ConstantsUtilIRM.ATTRBUDGETOWNERAPPROVAL, mpBudgetOwnerApproval);
				//SPEC: <15.03.2021>: Guna Modified for Dev 18x.6   -- START
				if(isInternal){
					//SPEC: <03.05.2021>: Guna Commented for Internal Defect Dev 18x.6.0.1   -- START
					//hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
					//SPEC: <03.05.2021>: Guna Commented for Internal Defect Dev 18x.6.0.1   -- END
					//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
					if (mpMultipleOwnershipAccess.containsKey(ConstantsUtilIRM.INHERITEDFROM)) {
						mpMultipleOwnershipAccess.remove(ConstantsUtilIRM.INHERITEDFROM);
					}	
					if (mpMultipleOwnershipAccess.containsKey(ConstantsUtilIRM.INHERITEDACCESS)) {
						mpMultipleOwnershipAccess.remove(ConstantsUtilIRM.INHERITEDACCESS);
					}
					//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
					hmAttrib.put(ConstantsUtilIRM.MULTIPLEOWNERSHIPACCESS, mpMultipleOwnershipAccess);
					hmAttrib.put(ConstantsUtilIRM.ATTRGPSASSESSMENT, mpGpsAssessment);
				}
				//SPEC: <15.03.2021>: Guna Modified for Dev 18x.6   -- END
				//SPEC: <03.05.2021>: Guna Added for Internal Defect Dev 18x.6.0.1   -- START
				//SPEC: <05.04.2022>: Guna Modified for Req 38510 22x Release  -- START
				if(!isExternal) {
					hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				}
				//SPEC: <05.04.2022>: Guna Modified for Req 38510 22x Release  -- END
				//SPEC: <03.05.2021>: Guna Added for Internal Defect Dev 18x.6.0.1   -- END
			}
			if(!bisIRMDoc) {

				hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
				//SPEC: <12.04.2022>: Guna Modified for Req 42769,34417 22x Release  -- START
				mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				if(isInternal) {
					hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
					hmAttrib.put(ConstantsUtil.ORGANIZATIONS, mpOrganization);
				}
			}
			//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
			if(!bSupplierView) {
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
			}
			//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
			dobCdoc.close(context);
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BbUtil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			//Mandatory outputs
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189

			if ((isProc || isMi || isLis) && isExternal)
			{
				hmAttrib.remove(ConstantsUtil.FILES);
			}
			if(isSOP){
				hmAttrib.put(ConstantsUtil.PLANTS, mpPlant);
				//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
				hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.RELATEDATS)?hmAttrib.remove(ConstantsUtil.RELATEDATS) :ConstantsUtil.EMPTY_STRING);
				//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
			}
			if(isAts && isExternal) {
				hmAttrib.remove(ConstantsUtil.FILES);

				//SPEC: 06-01-2022: Added for req #34417 by Satyam -- START
				hmAttrib.remove(ConstantsUtil.IPCLASSES);
				//SPEC: 06-01-2022: Added for req #34417 by Satyam -- END
			}
			if(isTms && isExternal) {

				hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.FILES)?hmAttrib.remove(ConstantsUtil.FILES) :ConstantsUtil.EMPTY_STRING);
			}

			if(isSOP && isExternal) {
				hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.PLANTS)?hmAttrib.remove(ConstantsUtil.PLANTS) :ConstantsUtil.EMPTY_STRING);
				//hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.FILES)?hmAttrib.remove(ConstantsUtil.FILES) :ConstantsUtil.EMPTY_STRING);//Added by Ketan for Defect No. 51907
			}
			if(isIaps && isExternal) {
				hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.ORGANIZATIONS)?hmAttrib.remove(ConstantsUtil.ORGANIZATIONS) :ConstantsUtil.EMPTY_STRING);
				hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.SECURITY)?hmAttrib.remove(ConstantsUtil.SECURITY) :ConstantsUtil.EMPTY_STRING);
				hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.IPCLASSES)?hmAttrib.remove(ConstantsUtil.IPCLASSES) :ConstantsUtil.EMPTY_STRING);
			}
			if(isExternal )
			{
				if(isRmpi || isSPS ||  isPI || isQual || isILST)
				{
					hmAttrib.remove(hmAttrib.containsKey(ConstantsUtil.FILES)?hmAttrib.remove(ConstantsUtil.FILES) :ConstantsUtil.EMPTY_STRING);
				}
			}
			if(isSPS){
				String spsOrigination =(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSPSORIGINATION);
				if(UIUtil.isNotNullAndNotEmpty(spsOrigination) && spsOrigination.equalsIgnoreCase("System Generated")){
					hmAttrib.remove(ConstantsUtil.REFERENCEDOCUMENTS);
				}
			}
			pool.checkIn(context);
			sp.stop();
			LOGGER.info("COMMON DOC SERVICE MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "COMMON DOC SERVICE OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		} catch (IOException e) {
			LOGGER.error("Unable to EnoviaCommonDocServiceImpl:getDocdata IOException"+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to EnoviaCommonDocServiceImpl:getDocdata MatrixException"+e);
		}
		//SPEC: Added by Ajay for Req. no. 23970 START
		if(sComp.equals(ConstantsUtilIRM.TCOMMONDOC)) {
			context.close();
		}//SPEC: Added by Ajay for Req. no. 23970 END
		context.close();
		return hmAttrib;
	}
}
