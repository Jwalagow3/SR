package com.pg.us.specanywhere_enovia.security;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;

import matrix.util.StringList;


@Service
public class SecurityService  {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public boolean isContractManufacturer()
	public synchronized boolean isContractManufacturer()
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
	{
		Collection<? extends GrantedAuthority> authorities = getAuthorities();
		HashMap<String, String> roleMap = (HashMap) getRoleAuthorities(authorities);

		if(roleMap.size()==1){
			//Jwala Modified for User change -- START
			roleMap.put(ConstantsUtil.SECURITYAUTHORITY, "sys_specreader");
			//Jwala Modified for User change -- END
		}
		if (isContractManufacturer(roleMap.get(ConstantsUtil.SECURITYAUTHORITY))) {
			log.info("User has Contract Manufacturer Role ");
			return true;
		}
		log.info("User does not have Contract Manufacturer Role");
		return false;

	}

	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public String getUserLicense()
	public synchronized String getUserLicense()
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
	{
		Collection<? extends GrantedAuthority> authorities = getAuthorities();
		HashMap<String, String> roleMap = (HashMap) getRoleAuthorities(authorities);
		boolean strTemp = roleMap!=null;
		//log.info("*********In security. getUserLicense method. Rolemap:"+roleMap);
		for (Entry<String, String> entry : roleMap.entrySet())
		{
			String key = entry.getKey();
			String value = entry.getValue();
			if(ConstantsUtil.LICENSEAUTHORITY.equalsIgnoreCase(key)) {
				//log.info("*********In security. getUserLicense method.key:"+key+"|value:"+value);
				return value;
			}
		}
		return "";
	}

	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public boolean isExternalUser()
	public synchronized boolean isExternalUser()
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
	{
		Collection<? extends GrantedAuthority> authorities = getAuthorities();
		HashMap<String, String> roleMap = (HashMap) getRoleAuthorities(authorities);
		for (Entry<String, String> entry : roleMap.entrySet())
		{
			String key = entry.getKey();
			String value = entry.getValue();
			if(ConstantsUtil.COMPANYAUTHORITY.equalsIgnoreCase(key)) {
				if(value.equalsIgnoreCase(ConstantsUtil.PG) || value.equalsIgnoreCase(ConstantsUtil.PGSTAFF)){
					return false;
				}
				break;
			}
		}
		return true;
	}

	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public String getUserType()
	public synchronized String getUserType()
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
	{	
		Collection<? extends GrantedAuthority> authorities = getAuthorities();
		HashMap<String, String> roleMap = (HashMap) getRoleAuthorities(authorities);
		//log.info("In Security service........0: roleMap:"+roleMap);
		for (Entry<String, String> entry : roleMap.entrySet())
		{
			//log.info("In Security service.....1");
			String key = entry.getKey();
			String value = entry.getValue();
			//log.info("In Security service.....1: key:"+key+": value:"+value);
			StringList slCompanyValues = new StringList();
			if(UIUtil.isNotNullAndNotEmpty(value) && key.equals(ConstantsUtil.COMPANYAUTHORITY))
			{
				slCompanyValues = getStringList(value);
				//log.info("In Security service.....2:slCompanyValues:"+slCompanyValues);
			}

			if(ConstantsUtil.COMPANYAUTHORITY.equalsIgnoreCase(key)) {

				if(slCompanyValues.contains(ConstantsUtil.PG)){
					//log.info("User has Internal PG Role");
					return ConstantsUtil.PG;
				} else if (slCompanyValues.contains(ConstantsUtil.PGSTAFF)){
					//log.info("User has Staff Aug Role");
					return ConstantsUtil.PGSTAFF;
				} else {
					if (isContractManufacturer(roleMap.get(ConstantsUtil.SECURITYAUTHORITY))) {
						//log.info("User has Contract Manufacturer Role ");
						return ConstantsUtil.PG_CM;
					}else if(isSupplierManufacturer(roleMap.get(ConstantsUtil.SECURITYAUTHORITY))){
						//log.info("User has Supplier Role ");
						return ConstantsUtil.PG_SP;
					} else{
						return null;
					}
				}
			}
		}
		return null;
	}
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public String getUserCauthorities(){
	public synchronized String getUserCauthorities(){
		//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
		Collection<? extends GrantedAuthority> authorities = getAuthorities();
		HashMap<String, String> roleMap = (HashMap) getRoleAuthorities(authorities);
		String strCauthorities = (String)roleMap.get(ConstantsUtil.COMPANYAUTHORITY);
		return strCauthorities;
	}
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public Collection<? extends GrantedAuthority> getAuthorities() {
	public synchronized Collection<? extends GrantedAuthority> getAuthorities() {
		//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
		//	log.info("*********In security. getAuthorities method.");
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Collection<? extends GrantedAuthority> authorities= auth.getAuthorities();
		//log.info("*********In security. getAuthorities method. Returning authorities:"+authorities);

		return authorities;
	}

	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public Map getRoleAuthorities(Collection<? extends GrantedAuthority> authorities) {
	public synchronized Map getRoleAuthorities(Collection<? extends GrantedAuthority> authorities) {
		//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END

		Map<String, String> roleMap = new HashMap<>();
		//log.info("*********In security. getRoleAuthorities method.");
		if (authorities != null) {
			//log.info("*********In security. getRoleAuthorities method. authorities not null.");
			//authorities.forEach(null);
			//authorities.parallelStream().forEach(k -> {
			authorities.forEach(k -> {
				roleMap.put(k.getAuthority().substring(0, ConstantsUtil.ROLELENGTH), k.getAuthority().substring(ConstantsUtil.ROLELENGTH + 1));
			});
		}
		//log.info("****************************************************************RoleMap:"+roleMap);
		return roleMap;
	}
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public boolean isContractManufacturer(String role) {
	public synchronized boolean isContractManufacturer(String role) {
		//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
		boolean flag = false;
		//Modified by Jwala for defect 44581 -- START
		//if (role.contains(ConstantsUtil.ROLE_CONTRACT_MANUFACTURER)) {
		if (role.contains(ConstantsUtil.ROLE_CONTRACT_MANUFACTURER_SR)) {
			flag = true;

		}
		return flag;
	}
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public boolean isSupplierManufacturer(String role) {
	public synchronized boolean isSupplierManufacturer(String role) {
		//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
		boolean flag = false;
		//Modified by Jwala for defect 44581 -- START
				//if (role.contains(ConstantsUtil.ROLE_CONTRACT_SUPPLIER)) {
				if (role.contains(ConstantsUtil.ROLE_CONTRACT_SUPPLIER_SR)) {
			flag = true;

		}
		return flag;
	}


	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public StringList getStringList(String cAuthorities)
	public synchronized StringList getStringList(String cAuthorities)
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
	{
		StringList slTemp = new StringList();
		StringList slCompanys = FrameworkUtil.split(cAuthorities.trim(), ConstantsUtil.SYMBL_COMMA);

		for (int i = 0; i < slCompanys.size(); ++i)
		{
			String strCompanyName = (String)slCompanys.get(i).trim();
			slTemp.add(strCompanyName);
		}
		return slTemp;

	}


	/**
	 * Check User is Staff Aug aren't?
	 * @return
	 */
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public boolean isStaffAUGUser()
	public synchronized boolean isStaffAUGUser()
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
	{
		Collection<? extends GrantedAuthority> authorities = getAuthorities();
		HashMap<String, String> roleMap = (HashMap) getRoleAuthorities(authorities);
		for (Entry<String, String> entry : roleMap.entrySet())
		{
			String key = entry.getKey();
			String value = entry.getValue();
			if(ConstantsUtil.COMPANYAUTHORITY.equalsIgnoreCase(key)) {
				if(value.equalsIgnoreCase(ConstantsUtil.PGSTAFF)){
					return true;
				}
				break;
			}
		}
		return false;

	}



	/**SPEC: <11.19.2020>: Chandra added for Defect :37446
	 * Return the Project security
	 * @return
	 */
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public String getProjectLicenses(){
	public synchronized String getProjectLicenses(){
		//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
		Collection<? extends GrantedAuthority> authorities = getAuthorities();
		HashMap<String, String> roleMap = (HashMap) getRoleAuthorities(authorities);
		String strProjectAuthorities = (String)roleMap.get(ConstantsUtil.PROGRAMBRIEFINGAUTHORITY);
		return strProjectAuthorities;
	}

	/**
	 * Check User is ComplainceEngineer aren't?
	 * SPEC: <01.22.2021>: Chandra added for Defect :38180
	 */
	//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
	//public  boolean isComplainceEngineer() {
	public synchronized boolean isComplainceEngineer() {
		//SPEC: <08-13-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
		Collection<? extends GrantedAuthority> authorities = getAuthorities();
		HashMap<String, String> roleMap = (HashMap) getRoleAuthorities(authorities);
		for (Entry<String, String> entry : roleMap.entrySet())
		{
			String key = entry.getKey();
			String value = entry.getValue();
			if(ConstantsUtil.COMPANYAUTHORITY.equalsIgnoreCase(key)) {
				if(value.equalsIgnoreCase(ConstantsUtil.ROLE_COMPLIANCE_ENGINEER)){
					return true;
				}
				break;
			}
		}
		return false;



	}



}
