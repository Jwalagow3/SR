package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.pg.us.specanywhere_enovia.bo.IngredientStatementBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class INGSTMTService {

	private static Logger LOGGER = Logger.getLogger(INGSTMTService.class);

	public static void main(String[] args) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		String objId = "20336.41905.11788.9415";

		StopWatch sppool = new StopWatch();
		sppool.start();

		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
		Context context = pool.checkOut();

		sppool.stop();
		LOGGER.info("INGSTMT sppool ELAPSED TIME : "+sppool.getTime());


		Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();

		IngredientStatementBO INGBO = new IngredientStatementBO();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		Map<String, StringList> BusinessObjectSelectableMap = INGBO.getIngredientStatementSelectables(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

		StringValidatorUtil validator = new StringValidatorUtil();

		DomainObject doINGSTMT =  INGBO.getIngredientStatementDO(context, objId);

		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doINGSTMT.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("doINGSTMT GETINFO ELAPSED TIME : "+swAttributes.getTime());

		/**
		 * LOAD HEADER CONTENT SECTION
		 * */
		mpHeaderContent.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
		
		/**
		 * LOAD ATTRIBUTE CONTENT SECTION
		 * */
		mpAttribResult.put(ConstantsUtilIRM.INGREDIENTS, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXT)));
		mpAttribResult.put(ConstantsUtilIRM.AICN, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_PGAICN)));
		mpAttribResult.put(ConstantsUtilIRM.ADJUSTEDTARGET, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_PGADJTARGET)));
		mpAttribResult.put(ConstantsUtilIRM.COMMONNAME, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtilIRM.REL_CLARTWORKMASTER_ATTRIBUTE_COMMONNAME)));
		

		pool.checkIn(context);
		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);

		sp.stop();
		LOGGER.info("INGSTMT Execution TIME::" + sp.getTime() +"  " + "INGSTMT OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));

		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End

	}

}
