/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaOPPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.OnlinePrintingPartBO;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaOPPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaOPPServiceImpl  implements EnoviaOPPService{

	private static Logger LOGGER = Logger.getLogger(EnoviaOPPServiceImpl.class);
	
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
	
	@Override
	public HashMap<String, Map<String, String>> getOPPdata(String objId, String sComp, Environment env) throws Exception {

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		try 
		{
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- START
			/*StopWatch swContext = new StopWatch();
			swContext.start();
			Context context = pool.checkOut();
			swContext.stop();*/
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- END
			LOGGER.info("OPP CONTEXT ELAPSED TIME : "+swContext.getTime());

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
				
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			OnlinePrintingPartBO OPPBO =new OnlinePrintingPartBO();
			DomainObject doOPP =  OPPBO.getOPPDO(context, objId);
			String strCurrent = doOPP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && sComp!=ConstantsUtilIRM.STATE_PRILIMNARY)
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpPerformChar = new HashMap<String,String>();
			Map<String,String> mpMaterialResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String, String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mpMEPResult = new HashMap<String,String>();
			Map<String,String> mpSEPResult = new HashMap<String,String>();
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			Map<String,String> mpSustainability = new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();

			BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = OPPBO.getOnlinePrintingPartSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 12 Feb 2021 -- START
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slContextSelects.add(ConstantsUtil.ATL_STATE);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 12 Feb 2021 -- END

			if (null == doOPP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doOPP.getInfo(context, slContextSelects);
			Map resultMaps = doOPP.getInfo(context, slContextSelects,OPPBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("OPP GETINFO ELAPSED TIME : "+swAttributes.getTime());
			
			
			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sClassifictaion = util.getClassification(resultMaps);
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			

			if(bAllInfoView || bSupplierView || bManufacturerView) {

				//Header Content
				mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		

				String strHasATS = util.checkHasATSForSIS (context, resultMaps);
				mpHeaderResult.put(ConstantsUtil.HASATS, strHasATS);				
				
				mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				
				if(!bManufacturerView && !bSupplierView){
					mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				}
				
				mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				String sClassification = util.getClassification(resultMaps);
				mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))));
				
				//Basic  Data
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));			
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
					}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
				
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PARTCOLOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRINTINGPROCESS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRPRINTINGPROSS)))?(String)resultMaps.get(ConstantsUtil.STRPRINTINGPROSS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DECORATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);

				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.HASART, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART)))?validator.replaceSpecialSymbols((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.HASMUTIPLEGTIN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASMULTIPLEGTINS)))?validator.replaceSpecialSymbols((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASMULTIPLEGTINS)) : ConstantsUtil.EMPTY_STRING);				
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				
				//Sustainability
				mpSustainability.put(ConstantsUtilIRM.PGMINERALOILADDEDTOPRINTINKS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMINERALOILSADDEDTOPRINTINGINKS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMINERALOILSADDEDTOPRINTINGINKS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <10.03.2023>: Manikanta Added for Req 46464 -- START
				if(!bSupplierView){
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: <10.03.2023>: Manikanta Added for Req 46464 -- END
				if(bSupplierView || bManufacturerView)
				{
					mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);				
					mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
					mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));
					mpAttribResult.put(ConstantsUtil.POAIMPACTCONFIRMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_POAIMPACTCONFIRMATION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_POAIMPACTCONFIRMATION) : ConstantsUtil.EMPTY_STRING);
					//Security
					CommonBusUtilBO commonBo = new CommonBusUtilBO();
					mpSecurity =commonBo.updateSecurity(context,resultMaps);
					StringList slIpSelects = new StringList();
					slIpSelects.add(ConstantsUtil.SELECT_NAME);
					slIpSelects.add(ConstantsUtil.SELECT_ID);
					slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
					slIpSelects.add(ConstantsUtil.SELECT_TYPE);
					slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
					slIpSelects.add(ConstantsUtil.HASCLASSACCESS);
					CommonBusUtilBO commonBO = new CommonBusUtilBO();
					mpIpSecuritySetting =commonBO.getIpClass(context, doOPP, slIpSelects);
				
					mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
				

					mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					mpOrganization = util.filterMapList(mpOrganization);
					
					mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
				
				}
				
				/**
				 * LOAD PERFORMANCE CHAR SECTION
				 * */
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				Map<String, String> paramMap = new HashMap<String, String>();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);
				
				FinishedProductPartBO fppBO = new FinishedProductPartBO();
				PefromChar perform = new PefromChar();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
				mpPerformChar = util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
				swPerfChar.stop();
				LOGGER.info("OPP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
				
				if (bSupplierView) {
					mpPerformChar.remove(ConstantsUtil.PLANTTESTING);
					mpPerformChar.remove(ConstantsUtil.RT);
				}

				/**
				 * SUBSTANCES & MATERIALS SECTION
				 * */
				PackagingMaterialPartBO PMPBO =new PackagingMaterialPartBO();
				mpMaterialResult = PMPBO.getSubstances(context,resultMaps);
				if(bSupplierView || bManufacturerView) {
					mpMaterialResult=util.filterPhase(mpMaterialResult);
					mpMaterialResult=util.filterMapList(mpMaterialResult);
					
				}

				/**
				 * LOAD MASTER ATTRIBUTE DATA SECTION
				 * */
				
				//RelatedSpec
				StopWatch swRelatedSpec = new StopWatch();
				swRelatedSpec.start();
				mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
				swRelatedSpec.stop();
				LOGGER.info("OPP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());
				
				
				//Reference Docs
				StopWatch swReference= new StopWatch();
				swReference.start();
				MasterCOPBO mcop = new MasterCOPBO();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
				swReference.stop();
				LOGGER.info("OPP  Reference ELAPSED TIME : "+swReference.getTime());


			}

			if(bAllInfoView) {

				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
				mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);

				//LifeCycle
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("OPP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.POAIMPACTCONFIRMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_POAIMPACTCONFIRMATION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_POAIMPACTCONFIRMATION) : ConstantsUtil.EMPTY_STRING);
				
				//Organization Data
				StopWatch swOrganization = new StopWatch();
				swOrganization.start();
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = util.filterMapList(mpOrganization);
				swOrganization.stop();
				LOGGER.info("OPP Organization ELAPSED TIME : "+swOrganization.getTime());

				
				//Plant Data
				StopWatch swPlant = new StopWatch();
				swPlant.start();
				FabricatedPartBO fab = new FabricatedPartBO();
				mpPlantResult.put(ConstantsUtil.PLANTS, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_NAME))));
				mpPlantResult.put(ConstantsUtil.PLANTSAUTHORIZEDTOVIEW, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW))));
				swPlant.stop();
				LOGGER.info("OPP Plant ELAPSED TIME : "+swPlant.getTime());

				//Ownership
				StopWatch swOwnerShip = new StopWatch();
				swOwnerShip.start();
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
				swOwnerShip.stop();
				LOGGER.info("OPP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());

				//Security
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO commonBo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =commonBo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				LOGGER.info("OPP  Security ELAPSED TIME : "+swSecurity.getTime());


				/**
				 * MASTER SPECIFICATION
				 * */
				StopWatch swmpMasterSpecs = new StopWatch();
				swmpMasterSpecs.start();
				mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
				swmpMasterSpecs.stop();
				LOGGER.info("OPP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());

				/**
				 * LOAD IP CLASSES SECTION
				 */
				//SPEC: 10/12/2020:: Added for req 18x.5 ## -- START
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				slIpSelects.add(ConstantsUtil.HASCLASSACCESS);
				CommonBusUtilBO commonBO = new CommonBusUtilBO();
				mpIpSecuritySetting =commonBO.getIpClass(context, doOPP, slIpSelects);
				//SPEC: 10/12/2020:: Added for req 18x.5 ## -- END
				
				
				/**
				 * FILES SECTION
				 */
				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
				CommonDocBO cdoc = new CommonDocBO();
				String strFileSize = cdoc.updateFileSize(FileSize);
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);
			}
				
				if(bSupplierView || bManufacturerView || bAllInfoView ) {
					/**
					 * This Method is for getting the MEPS
					 * @param context
					 * @param Relationship
					 * @param objectMap
					 * @param bMEP
					 * @return
					 * @throws Exception
					 */

					mpMEPResult = util.getPQREquivalents(context, resultMaps, true, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT,sUserType);
					
					// Added by Jwala for Req/Defect 35581 43951 -- START
					if(bManufacturerView || bSupplierView){
						mpMEPResult.remove(ConstantsUtil.PQRBA);
						mpMEPResult.remove(ConstantsUtil.PQRPCP);
						//Modified by Jwala for 22x Development Req 42996 -- START
						if(bSupplierView){
							mpMEPResult.remove(ConstantsUtil.PQRPLANTS);
						}
						//Modified by Jwala for 22x Development Req 42996 -- END
					}
					// Added by Jwala for Req/Defect 35581 43951 -- END
					//SPEC: 23-12-2022: Satyam added for Req 34055 -- START
					if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
						mpMEPResult = new HashMap<String,String>();
	                }
					//SPEC: 23-12-2022: Satyam added for Req 34055 -- END
					
					/**
					 * This Method is for getting the SEPS 
					 * @param context
					 * @param Relationship
					 * @param objectMap
					 * @param bSEP
					 * @return
					 * @throws Exception
					 */
					
					mpSEPResult = util.getPQREquivalents(context, resultMaps, false, ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT,sUserType);
					
					// Added by Jwala for Req/Defect 35581 43951 -- START
					if(bManufacturerView || bSupplierView){
						mpSEPResult.remove(ConstantsUtil.PQRBA);
						mpSEPResult.remove(ConstantsUtil.PQRPCP);
						//Modified by Jwala for 22x Development Req 42996 -- START
						if(bSupplierView){
							mpSEPResult.remove(ConstantsUtil.PQRPLANTS);
						}
						//Modified by Jwala for 22x Development Req 42996 -- END
					}
					// Added by Jwala for Req/Defect 35581 43951 -- END
					//SPEC: 23-12-2022: Satyam added for Req 34055 -- START
					if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
						mpSEPResult = new HashMap<String,String>();
	                }
					//SPEC: 23-12-2022: Satyam added for Req 34055 -- END
				}	
				
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END	

			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			hmAttrib.put(ConstantsUtil.MATERIALS, mpMaterialResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
			hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult);
			hmAttrib.put(ConstantsUtilIRM.SUSTAINABILITY, mpSustainability);
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			if(!bSupplierView && !bManufacturerView){    // Modified by Ketan for Internal Defect
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
			}
			
			pool.checkIn(context);
			sp.stop();

			LOGGER.info("OPP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "OPP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			//LOGGER.info("OPP Data : "+hmAttrib);
					
		} catch (IOException e) {
			LOGGER.error(" Unable to get getOPPdata IOException "+e);
		} catch (MatrixException e) {
			LOGGER.error(" Unable to get getOPPdata MatrixException "+e);
		}
		if(sComp.equals(ConstantsUtilIRM.OPP)) {
			context.close();
		}
		context.close();
		return hmAttrib;
	}
}