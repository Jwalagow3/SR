/**
 * Project 		: SpecReader
 * Program 		: EnoviaINGSTMTServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: Added by Jwala for Dev SR2018x.6 
 */
package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.pg.us.specanywhere_enovia.bo.IngredientStatementBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaINGSTMTService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaINGSTMTServiceImpl implements EnoviaINGSTMTService{

/*	private static String USER;
	private static String PASS;
	private static String VAULT;*/
	private static Logger LOGGER = Logger.getLogger(EnoviaINGSTMTServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	@Override
	public HashMap<String, Map<String, String>> getINGSTMTdata(String objId, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("INGSTMT CONTEXT ELAPSED TIME : "+swContext.getTime());
		try 
		{
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
		
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;

			switch (sUserType) {
			case ConstantsUtil.PG:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PGSTAFF:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PG_CM:
				bManufacturerView = true;
				break;

			case ConstantsUtil.PG_SP:
				bSupplierView = true;
				break;
			}
			
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			
			StringBuilder sbCopyText = new StringBuilder();
			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();

			IngredientStatementBO INGBO = new IngredientStatementBO();
			BusObjectAttribUtil util = new BusObjectAttribUtil();

			Map<String, StringList> BusinessObjectSelectableMap = INGBO.getIngredientStatementSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

			StringValidatorUtil validator = new StringValidatorUtil();

			DomainObject doINGSTMT =  INGBO.getIngredientStatementDO(context, objId);

			if (null == doINGSTMT) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doINGSTMT.getInfo(context, slContextSelects);
			Map resultMaps = doINGSTMT.getInfo(context, slContextSelects,INGBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("INGSTMT GETINFO ELAPSED TIME : "+swAttributes.getTime());

			/**
			 * BLOCK USER IF OBJECT IS NOT RELEASED
			 */
			if (sct.isExternalUser() || sct.isStaffAUGUser()) {
				String strState = (validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_CURRENT)))
						? (String) resultMaps.get(ConstantsUtil.SELECT_CURRENT)
								: ConstantsUtil.EMPTY_STRING;

						if (!strState.equals(ConstantsUtil.RELEASE) && null != strState && !strState.isEmpty()) {
							HashMap<String, String> errorMap = new HashMap<String, String>();
							//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
							String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
							if(strState.equals(ConstantsUtil.STATE_OBSOLETE)) {
								sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
							}
							//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
							errorMap.put(sError[0], sError[1]);
							hmAttrib.put(ConstantsUtil.ERROR, errorMap);
							LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
							//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
							context.close();
							//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
							return hmAttrib;
						}
			}
			
			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			/**
			 * LOAD HEADER CONTENT SECTION
			 * */

			// Added by Jwala to send role info to Integration
			mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			// Added by Jwala to send role info to Integration

			mpHeaderContent.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.CL_PARENTPART_REVISION)))?(String)resultMaps.get(ConstantsUtilIRM.CL_PARENTPART_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtilIRM.PARENTPARTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.CL_PARENTPART)))?(String)resultMaps.get(ConstantsUtilIRM.CL_PARENTPART) : ConstantsUtil.EMPTY_STRING);

			/**
			 * LOAD ATTRIBUTE CONTENT SECTION
			 * */
			//SPEC: Added for Defect 40643 & 41015 -- START	
			
			//SPEC: Modified  for Defect 41015 -- START	
			/*StringBuilder sbpgACIN = new StringBuilder();
			StringBuilder sbAdjTarget = new StringBuilder();
			StringBuilder sbCOmmonName = new StringBuilder();
			
			String strCopyTxt = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXT));
			String strIsBasCopy = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_ISBASECOPY));
			String strCpyTxtLang = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXTLANG));

			String strpgACIN = validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.REL_CLARTWORKMASTER_ATTRIBUTE_PGAICN));
			String strAdjTarget = validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.REL_CLARTWORKMASTER_ATTRIBUTE_PGADJTARGET));
			String strCOmmonName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.REL_CLARTWORKMASTER_ATTRIBUTE_COMMONNAME));
			
			StringList slCopyTxt =FrameworkUtil.split(strCopyTxt, "|");
			StringList slIsBasCopy =FrameworkUtil.split(strIsBasCopy, "|");
			StringList slCopyTxtLang =FrameworkUtil.split(strCpyTxtLang, "|");
			StringList slpgACIN =FrameworkUtil.split(strpgACIN, "|");
			StringList slAdjTarget =FrameworkUtil.split(strAdjTarget, "|");
			StringList slCOmmonName =FrameworkUtil.split(strCOmmonName, "|");
			
			//90006241 and 81690505(FPP)
			//slCopyTxt = util.removeDuplicateSlType(slCopyTxt);
			//slCOmmonName = util.removeDuplicateSlType(slCOmmonName);
			
			for (int index = 0; index < slCopyTxt.size(); index++) 
			{
				String stCopy = (String)slCopyTxt.get(index);

				String stPGACN = (String)slpgACIN.get(index);
				String stAdjTar = (String)slAdjTarget.get(index);
				String stCommonName = (String)slCOmmonName.get(index);

				if (stCopy != null && stCopy.trim().length() > 0 && stAdjTar != null && stAdjTar.trim().length() > 0 && stCommonName != null && stCommonName.trim().length() > 0) 
				{
					if (index != -1 && slIsBasCopy != null && slIsBasCopy.size() >= index)
						stIsBase = (String)slIsBasCopy.get(index).trim();
					if (index != -1 && slCopyTxtLang != null && slCopyTxtLang.size() >= index)
						stLang = (String)slCopyTxtLang.get(index).trim();

					if (UIUtil.isNotNullAndNotEmpty(stIsBase) && UIUtil.isNotNullAndNotEmpty(stLang) && stIsBase.equalsIgnoreCase("Yes") && stLang.equalsIgnoreCase("English_US")){
						busUtil.formatData(sbCopyText, stCopy);
						busUtil.formatData(sbpgACIN, stPGACN);
						busUtil.formatData(sbAdjTarget, stAdjTar);
						busUtil.formatData(sbCOmmonName, stCommonName);
					}
					else if("English_GL".equalsIgnoreCase(stLang)){  // Added for Defect #41015 & #41014
						busUtil.formatData(sbCopyText, stCopy);
						busUtil.formatData(sbpgACIN, stPGACN);
						busUtil.formatData(sbAdjTarget, stAdjTar);
						busUtil.formatData(sbCOmmonName, stCommonName);
					}
				} 
			}
				
			mpAttribResult.put(ConstantsUtil.INGREDIENTS, sbCopyText.toString().trim());
			mpAttribResult.put(ConstantsUtil.AICN, sbpgACIN.toString().trim());
			mpAttribResult.put(ConstantsUtil.ADJUSTEDTARGET, sbAdjTarget.toString().trim());
			mpAttribResult.put(ConstantsUtil.COMMONNAME, sbCOmmonName.toString().trim());*/
			
			mpAttribResult = INGBO.getCopyListAndMasterCopyElement(context,sContextObjectId);
			//SPEC: Modified  for Defect 41015 -- START	
			//mpAttribResult.put(ConstantsUtil.INGREDIENTS, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.REL_ARTWORKASSEMBLY_ATTRIBUTE_COPYTEXT)));
			//SPEC: Added for Defect 40643 & 41015 -- START	
			//SPEC: Commented  for Defect 41015 -- START	
			//mpAttribResult.put(ConstantsUtil.AICN, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.REL_CLARTWORKMASTER_ATTRIBUTE_PGAICN)));
			//mpAttribResult.put(ConstantsUtil.ADJUSTEDTARGET, validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.REL_CLARTWORKMASTER_ATTRIBUTE_PGADJTARGET)));
			//mpAttribResult.put(ConstantsUtil.COMMONNAME, validator.getEquivalentString(resultMaps.get(ConstantsUtil.REL_CLARTWORKMASTER_ATTRIBUTE_COMMONNAME)));
			//SPEC: Commented  for Defect 41015 -- END	
			
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);

			pool.checkIn(context);
			sp.stop();
			LOGGER.info("INGSTMT MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "INGSTMT OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			
		} catch (IOException e) {
			LOGGER.error("Exception in getINGSTMTdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		} catch (MatrixException e) {
			LOGGER.error("Exception in getINGSTMTdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		//LOGGER.info("Ingredient Statement RESPONSE MESSAGE:: \n" + hmAttrib);
		context.close();
		return hmAttrib;
	}
}
