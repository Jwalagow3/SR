/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaMEPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.ManufacturingEquivalentPartBO;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.SupplierEquivalentPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaMEPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaMEPServiceImpl  implements EnoviaMEPService{

	private static Logger LOGGER = Logger.getLogger(EnoviaMEPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
	
	@Override
	public HashMap<String, Map<String, String>> getMEPdata(String objId, String sComp, Environment env) throws Exception {

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		Context context = null;
		try 
		{
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			swContext.stop();
			LOGGER.info("MEP CONTEXT ELAPSED TIME : "+swContext.getTime());
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
				
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
				
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			ManufacturingEquivalentPartBO MEP = new ManufacturingEquivalentPartBO();
			SupplierEquivalentPartBO SEP = new SupplierEquivalentPartBO();//Added by Ketan for Defect no. 54123
			DomainObject doMEP = MEP.getMepDO(context,objId);
			String strCurrent = doMEP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType) &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY)
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			//SPEC: Release SR18x.6.0 - Added for 33481 by gaikwad.tg on Date 20 March 2021 -- START
			if(bManufacturerView)
			bSupplierView = true;
			//SPEC: Release SR18x.6.0 - Added for 33481 by gaikwad.tg on Date 20 March 2021 -- END
			
			
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			if (null == doMEP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			Map BusinessObjectSelectableMap = MEP.getManufacturingEquivalentPartSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = MEP.getMepRelatedObjsSelectableMap(context);
			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);

			boolean showMaterialAndComp = false;
			boolean showSubstanceAndMaterial = false;
			DeviceProductPartBO DPPBO = new DeviceProductPartBO();
			
			MEP.addMultiSelects();
			StopWatch swInfo = new StopWatch();
			swInfo.start();
			//START :: gaikwad.tg :: Defect#38264
			slSelects.add(ConstantsUtil.CERTIFICATION_NAME);
			slSelects.add(ConstantsUtilIRM.STR_RELATIONSHIP_PGMEPTOPGPLIVENDORTYPEFORMEP);

			//Map resultMaps = doMEP.getInfo(context, slSelects);
			Map resultMaps = doMEP.getInfo(context, slSelects,MEP.addMultiSelects());

			String strMaterialCertification=	validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.CERTIFICATION_NAME));
			strMaterialCertification = strMaterialCertification.replace("|", ",");
			swInfo.stop();
			LOGGER.info("MEP GET INFO ELAPSED TIME : "+swInfo.getTime());
			MEP.removeMultiselects();

			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpReachResult = new HashMap<String,String>();
			Map<String,String> mpMaterialComposition = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpEnterpriseParts = new HashMap<String,String>();
			Map<String,String> mpEquivalentSep = new HashMap<String,String>();
			Map<String,String> mpCertification = new HashMap<String,String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
			Map<String,String> mpMaterialResult = new HashMap<String,String>();
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- END
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			//SPEC: <10.19.2020>: Added for the Defect ## -- START
			
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			
			Map<String,String> mpStability = new HashMap<String,String>();
			RawMaterialPartBO RawBO = new RawMaterialPartBO();
		
			boolean isExternal=util.isModificatinRequired();
			Map<String,String> mpPackCert = new HashMap<>();
			
			//Header Content
			StopWatch sHeader = new StopWatch();
			sHeader.start();
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			mpHeaderResult.put(ConstantsUtil.NAME, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			//Added by Pooja for 22x Defect 50391 -- START
			String sHasATSAttrVal = util.checkHasATSForSIS(context,resultMaps);
			mpHeaderResult.put(ConstantsUtil.HASATS, sHasATSAttrVal);
			//Added by Pooja for 22x Defect 50391 -- START
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);

			
			
			if(!bManufacturerView && !bSupplierView){
				mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
			}
			
			mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			String sClassification = util.getClassification(resultMaps);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
			
			sHeader.stop();
			LOGGER.info("MEP HEADER ELAPSED TIME : "+sHeader.getTime());

			String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;
			
			StopWatch swAttrib = new StopWatch();
			swAttrib.start();
			
			if(bAllInfoView || bSupplierView || bManufacturerView) {
				mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);

				//SPEC: <10.19.2020>: Added for the Defect ## -- START
				
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				//Commented by Ketan for Req. no. 47200
				//mpAttribResult.put(ConstantsUtil.MATERIALRESTRICTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION))));
				//mpAttribResult.put(ConstantsUtil.MATERIALRESTRICTIONCOMMENTS, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS))));
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <18.04.2022>: Guna Added for Req 41754 22x Release  -- START
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <18.04.2022>: Guna Added for Req 41754 22x Release  -- END

				mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);

				//Vendor
				//Modified by jwala for the ADO defect #7839 -- START 
				MapList mlObjList = commonBo.getVendorInfo(context, doMEP,ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY);
				//Modified by jwala for the ADO defect #7839 -- END
				Iterator objectListItr = mlObjList.iterator();
				while (objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					
					String Symbol="~";
					String Vendor = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATION_NAME));
					String VendorID =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATIONID));
					String Vendor_id =Vendor+Symbol+VendorID;
					Vendor=Vendor_id.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
					mpAttribResult.put(ConstantsUtil.VENDOR, Vendor_id);
					
					//mpAttribResult.put(ConstantsUtil.VENDOR, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATION_NAME)));
					mpAttribResult.put(ConstantsUtil.VENDORID, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATIONID)));
					//SPEC: Release SR18x.6.0 - Modified for Defect 41905  by Manikanta on Date 29/03/2021 -- START
					mpAttribResult.put(ConstantsUtil.VENDOR_STREET_ADDRESS, validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ADDRESS)));
					//SPEC: Release SR18x.6.0 - Modified for Defect 41905  by Manikanta on Date 29/03/2021 -- END
					mpAttribResult.put(ConstantsUtil.VENDOR_STREET_ADDRESS_NUMBER, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHOUSENUMBER)));
					mpAttribResult.put(ConstantsUtil.VENDOR_CITY, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CITY)));
					mpAttribResult.put(ConstantsUtil.VENDOR_STATE, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATEREGION)));
					mpAttribResult.put(ConstantsUtil.VENDOR_MARKET, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COUNTRY)));
					
					//SPEC: <10.19.2020>: Added for the Defect ## -- Start
					String VendorZIPperPostalcode = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_POSTALCODE));
					VendorZIPperPostalcode=VendorZIPperPostalcode.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
					mpAttribResult.put(ConstantsUtilIRM.VENDOORZIPPOSTALCODE, VendorZIPperPostalcode);
					//SPEC: <10.19.2020>: Added for the Defect ## -- END
					
					break;
				}
             	mpAttribResult.put(ConstantsUtilIRM.VENDORTYPE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.STR_RELATIONSHIP_PGMEPTOPGPLIVENDORTYPEFORMEP)));
			

					StopWatch swReference= new StopWatch();
					swReference.start();
					StringList slRefDocSelects = MEP.getRefDocBusSelect(context);
					//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 18 March 2021 -- START
					 String strTypePattern = DomainConstants.EMPTY_STRING;
					 String strDocumentPolicy = doMEP.getInfo(context, "policy");
					 String strpgPKGSignatureReferenceDoc = PropertyUtil.getSchemaProperty(context, "policy_pgPKGSignatureReferenceDoc");
					 if(strpgPKGSignatureReferenceDoc.equals(strDocumentPolicy))
						 strTypePattern = ConstantsUtil.SYMBL_ASTERISK;
					 else
						 strTypePattern = PropertyUtil.getSchemaProperty(context, "type_DOCUMENTS");
					 String strWhere = ConstantsUtil.EMPTY_STRING;
					 if(bSupplierView)
						 strWhere = "current==Release";
					MapList mlRefDocs = doMEP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
							strTypePattern, slRefDocSelects, new StringList(), false, true, (short) 1,
							strWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
					Iterator objectRefDocListItr = mlRefDocs.iterator();
					
					if(mlRefDocs.size()>0) {
						mapReferenceDocs =	util.parseRefDoclist(context, mlRefDocs);
					}
					swReference.stop();
					LOGGER.info("MEP  Reference ELAPSED TIME : "+swReference.getTime());

			}
			//Added by Ketan for Req. no. 47200 -- START
			String strType = (String) resultMaps.get(ConstantsUtil.SELECT_TYPE);
			if(!bSupplierView) {
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION))));
				mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS))));
				
			}
			//Added by Ketan for Req. no. 47200 -- END
			
			//Added by Ajay for Req. no. 96082 - START
			if(strType.equals(ConstantsUtil.tRMP)) {
				mpAttribResult.put(ConstantsUtilIRM.PG_DERIVED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDERIVED))));
			}
			//Added by Ajay for Req. no. 96082 - END
			boolean isRM = false;
			if(bAllInfoView || bSupplierView || bManufacturerView) {
			
			//Added by Ajay for Req. no. 99576 - START
				if(strType.equals(ConstantsUtil.tRMP)) {
					String sCompendialReferencePharmacopeia = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEPHARMACOPEIA));
					String sQualityStandardsMaterialGrade = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSMATERIALGRADE));
					mpAttribResult.put(ConstantsUtilIRM.PG_COMPENDIALREFERENCEPHARMACOPEIA, sCompendialReferencePharmacopeia);
					mpAttribResult.put(ConstantsUtilIRM.PG_QUALITYSTANDARDSMATERIALGRADE, sQualityStandardsMaterialGrade);
					if(sCompendialReferencePharmacopeia.contains(ConstantsUtilIRM.OTHER)) {
						mpAttribResult.put(ConstantsUtilIRM.PG_COMPENDIALREFERENCEFREETEXT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOMPENDIALREFERENCEFREETEXT))));
					}
					if(sQualityStandardsMaterialGrade.contains(ConstantsUtilIRM.OTHER)) {
						mpAttribResult.put(ConstantsUtilIRM.PG_QUALITYSTANDARDSFREETEXT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGQUALITYSTANDARDSFREETEXT))));
					}
				}//Added by Ajay for Req. no. 99576 - END
			/**
			 * Material Composition SECTION
			 */
				
				//Condition To check for access to Material & Composition category
			
				
				String strAttrIntMatFor = (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
				String strArchstatus = (String) resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGILMARCHIVALSTATUS);
				String strPolClass = (String) resultMaps.get(ConstantsUtilIRM.SELECT_POLICYCLASSIFICATION);
				String strpolicy = (String) resultMaps.get(ConstantsUtil.SELECT_POLICY);
				String sContextObjectId = (String) resultMaps.get(ConstantsUtil.SELECT_ID);
				String sFromTYpeSuppEq = (String) resultMaps.get(ConstantsUtilIRM.SELECT_MANUFACTURINGEQUIVALENT_FROM_TYPE);
				if(UIUtil.isNullOrEmpty(sFromTYpeSuppEq)) {
					sFromTYpeSuppEq = strType;
				}
				String strSpecSubType =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING;
				//SPEC: Modified by Ajay for Defect no. 55816 START
				if((UIUtil.isNotNullAndNotEmpty(sFromTYpeSuppEq) && util.getTypeIncludeForMatAndComp().contains(sFromTYpeSuppEq)) && (sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) && (!strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.SUBTYPE_WITH_MCP) || !strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.DEVICE)))  && strArchstatus.equalsIgnoreCase(ConstantsUtil.FALSE)) {
				//SPEC: Modified by Ajay for Defect no. 55816 START
				showMaterialAndComp = true;
				}
				if((((strPolClass.equalsIgnoreCase("Equivalent") || strPolClass.equalsIgnoreCase("Production") || strPolClass.equalsIgnoreCase("Development")) && (UIUtil.isNotNullAndNotEmpty(sFromTYpeSuppEq) && util.getTypeIncludeForSubAndMat().contains(sFromTYpeSuppEq))) || ((sFromTYpeSuppEq.equalsIgnoreCase(ConstantsUtil.TYPE_PGPROMOTIONALITEMPART) || sFromTYpeSuppEq.equalsIgnoreCase(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART)) && strpolicy.equalsIgnoreCase(ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT))) && !strpolicy.equalsIgnoreCase(ConstantsUtil.POLICY_SUPPLIEREQUIVALENT) && strArchstatus.equalsIgnoreCase("FALSE"))
				{
				showSubstanceAndMaterial = true;
				}
				//SPEC: Modified by Ajay for Req. no. 30224 START
				if((sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) && (strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.SUBTYPE_WITH_MCP) || strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.DEVICE))) ||  sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_DEVICEPRODUCTPART)) {
					showSubstanceAndMaterial = true;
				//SPEC: 30-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50470-- START
				//SPEC: Modified by Ajay for Req. no. 30224 END
				}else if((sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART) || sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_INTERMEDIATEPRODUCTPART) || ((sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_PGRAWMATERIAL)) && (!strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.SUBTYPE_WITH_MCP) && !strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.DEVICE))))) {
				//SPEC: 30-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50470-- END
					showMaterialAndComp = true;
				}
			//Modified by Ketan for Defect no. 2332	
			isRM = (sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_PGRAWMATERIAL));	
			//Added by Ketan for Req. no. 6045 -- START
			boolean bSupplierOrSP = false;
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
				bSupplierOrSP = true;
			}
			resultMaps.put(ConstantsUtilIRM.IS_SUPPLIER, bSupplierOrSP);
			//Added by Ketan for Req. no. 6045 -- END
			if(showMaterialAndComp)
			{
				if(!isRM) {
				StopWatch swSubts = new StopWatch();
				swSubts.start();
				mpMaterialComposition = RawBO.getMaterialCompositionAndSubstance(context, resultMaps);
				mpMaterialComposition = util.verifyOwnership(context,mpMaterialComposition);
				if(bSupplierView || bManufacturerView) 
				{
					mpMaterialComposition=util.filterPhase(mpMaterialComposition);
					mpMaterialComposition = util.filterMapList(mpMaterialComposition);
				}
				swSubts.stop();
				LOGGER.info("MEP GET SUBSTANCE ELAPSED TIME : "+swSubts.getTime());
				}
				else if(isRM) { //Modified by Ketan for Req. no. 6045
					StopWatch swSubts = new StopWatch();
					swSubts.start();
					mpMaterialComposition = RawBO.getMaterialCompositionAndSubstance(context, resultMaps);
					mpMaterialComposition = util.verifyOwnership(context,mpMaterialComposition);
					if(bSupplierView || bManufacturerView) 
					{
						mpMaterialComposition=util.filterPhase(mpMaterialComposition);
						mpMaterialComposition = util.filterMapList(mpMaterialComposition);
					}
					swSubts.stop();
					LOGGER.info("MEP GET SUBSTANCE ELAPSED TIME : "+swSubts.getTime());
					
				}
			}
			if(showSubstanceAndMaterial)
			{
				StopWatch swMSubts = new StopWatch();
				swMSubts.start();
				PackagingMaterialPartBO pmpBO = new PackagingMaterialPartBO();
				mpMaterialResult=pmpBO.getSubstances(context,resultMaps);
				if(bSupplierView || bManufacturerView) 
				{
					mpMaterialResult=util.filterPhase(mpMaterialResult);
					mpMaterialResult=util.filterMapList(mpMaterialResult);
				}
				//SPEC: Modified by Ajay for Req. no. 30224 START
				//SPEC: <21.04.2022>: Guna Added for Req 41754 22x Release  -- START
				if(sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_DEVICEPRODUCTPART) || (sFromTYpeSuppEq.equals(ConstantsUtil.TYPE_RAWMATERIALPART) && (strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.SUBTYPE_WITH_MCP) || strSpecSubType.equalsIgnoreCase(ConstantsUtilIRM.DEVICE)))) { //Modified by Ketan for Defect no. 51812
					mpMaterialResult.remove(ConstantsUtil.TRADE_NAME);
					mpMaterialResult.remove(ConstantsUtil.LAYER_DESC);
				}
				//SPEC: <21.04.2022>: Guna Added for Req 41754 22x Release  -- END
				//SPEC: Modified by Ajay for Req. no. 30224 END
				swMSubts.stop();
				LOGGER.info("MEP GET SUBSTANCE&MATERIAL ELAPSED TIME : "+swMSubts.getTime());
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 18 March 2021 -- START
			if(!bSupplierView)
			{
				/**
				 * LOAD GPSASSESSMENTS SECTION
				 * */
				StopWatch swgps= new StopWatch();
				swgps.start();
				mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
				mpGPSAssessments = util.filterMapList(mpGPSAssessments);
				swgps.stop();
				LOGGER.info("MEP  GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
				//SPEC: Release SR18x.6.0 - MODIFIED  by gaikwad.tg on Date 02 Mar 2021 -- END
				//SPEC: Modified related to Defect#37311 1.0.2 Release - Amman -- END
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 18 March 2021 -- END
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 18 March 2021 -- START
			if(bAllInfoView || bSupplierView) {
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 18 March 2021 -- END
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MATERIALCERTIFICATIONS, (validator.isNotNullOrEmpty(strMaterialCertification))? strMaterialCertification : ConstantsUtil.EMPTY_STRING);
				
				//Lifecycle
				String sPhysicalId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID));
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("MEP  LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 18 March 2021 -- START
				if(!bSupplierView)
				{
					mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
					String sClassifictaion = util.getClassification(resultMaps);
					mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
					mpAttribResult.put(ConstantsUtil.RESTRICTED, "");
					String strTempPKGMatType = validator.getEquivalentStringFromMapValue(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOPACKMATERIALTYPE));
					mpAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, UIUtil.isNotNullAndNotEmpty(strTempPKGMatType)? strTempPKGMatType : DomainConstants.EMPTY_STRING);
					//SPEC: Release SR18x.6.0 - Added for Defect#  by gaikwad.tg on Date 30 March 2021 -- END
					mpAttribResult.put(ConstantsUtil.TRADENAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET)))?(String)resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET) : ConstantsUtil.EMPTY_STRING);
					
					//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
					String strCOCAName = (String) mpLifeCycleApproval.get(ConstantsUtil.CO);
					String strEnvClass = (String) resultMaps.get(ConstantsUtilIRM.SELECTABLE_RELATIONSHIP_PGMATERIALTOPGPLIENVCLASS);
					String strPOAImpactConf = (String) resultMaps.get(ConstantsUtilIRM.SELECTABLE_ATTRIBUTE_PG_POA_IMPACT_CONFIRMATION);
					mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty(strCOCAName))?strCOCAName : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtil.LEGACY_ENV_CLASS, (validator.isNotNullOrEmpty(strEnvClass))?strEnvClass : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.POAIMPCONF, (validator.isNotNullOrEmpty(strPOAImpactConf))?strPOAImpactConf : ConstantsUtil.EMPTY_STRING);
					//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- END

					swAttrib.stop();
					LOGGER.info("MEP GET Attribute ELAPSED TIME : "+swAttrib.getTime());
		
					//Ownership
					StopWatch swOwnerShip = new StopWatch();
					swOwnerShip.start();
					mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)));
					mapOwnerShipResult.put(ConstantsUtil.SEGMENT, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.strSegment)));
					mapOwnerShipResult.put(ConstantsUtil.APPROVERS,validator.getStringEquivalentForStringList(mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)));
					mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, validator.DateFormatter(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MODIFIED))));
					mapOwnerShipResult.put(ConstantsUtil.APPROVERS,validator.getStringEquivalentForStringList(mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)));
					mapOwnerShipResult.put(ConstantsUtil.COOWNERS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)));
					mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
					swOwnerShip.stop();
					LOGGER.info("MEP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());
					
					/**
					 * FILES SECTION
					 */
					
					String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
					String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
					String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
					StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
					//SPEC: 30-06-2022: Pooja Added for Internal Defect -- START
					CommonDocBO cdoc = new CommonDocBO();
					String strFileSize = cdoc.updateFileSize(FileSize);
					//SPEC: 30-06-2022: Pooja Added for Internal Defect -- END
					mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
					mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
					mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
					mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);
					//SPEC: Modified related to Defect#37745 1.0.2 Release - Amman -- END
					
					//SPEC: <10.19.2020>: Added for req 18x.5 ## -- END
				}
				//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 18 March 2021 -- END
				
				//Organization Data
				StopWatch swOrganization = new StopWatch();
				swOrganization.start();
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)));
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)));
				swOrganization.stop();
				LOGGER.info("MEP Organization ELAPSED TIME : "+swOrganization.getTime());
	
				
				//Reach
				mpReachResult.put(ConstantsUtil.STATUS, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS)));
				mpReachResult.put(ConstantsUtil.REGISTRATIONNUMBER, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER)));
				//SPEC: Release SR18x.6.0 - #Defect42052,41952 Added  by gaikwad.tg on Date 06 April 2021 -- START
				mpReachResult = util.filterMapList(mpReachResult);
				//SPEC: Release SR18x.6.0 - #Defect42052,41952 Added  by gaikwad.tg on Date 06 April 2021 -- END
				
				/**
				 * LOAD IP CLASSES SECTION
				 */
				//SPEC: <10.19.2020>: Added for req 18x.5 ## -- START
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIpSecuritySetting =MEP.getIpClass(context, doMEP, slIpSelects);
				//SPEC: <10.19.2020>: Added for req 18x.5 ## -- END
				//SPEC: <18.04.2022>: Guna Added for Req 41754 22x Release  -- START
				if (mpIpSecuritySetting.containsKey(ConstantsUtil.HASCLASSACCESS)) {
					mpIpSecuritySetting.remove(ConstantsUtil.HASCLASSACCESS);
				}
				//SPEC: <18.04.2022>: Guna Added for Req 41754 22x Release  -- END
				
				//RelatedSpec
				StopWatch swRelatedSpec = new StopWatch();
				swRelatedSpec.start();
				mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
				swRelatedSpec.stop();
				LOGGER.info("MEP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());
	
	
				//Security
				StopWatch swSecurity = new StopWatch();
				swSecurity.start();
				mpSecurity =commonBo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				//SPEC: <18.04.2022>: Guna Added for Req 41754 22x Release  -- START
				if (mpSecurity.containsKey(ConstantsUtil.HASCLASSACCESS)) {
					mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				}
				//SPEC: <18.04.2022>: Guna Added for Req 41754 22x Release  -- END
				LOGGER.info("MEP  Security ELAPSED TIME : "+swSecurity.getTime());
				
				
				// Enterprise Parts
				StopWatch swEnterprise = new StopWatch();
				swEnterprise.start();
				
				StringList busSelect = new StringList();
				 
				busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
				busSelect.add(ConstantsUtil.SELECT_NAME);
				busSelect.add(ConstantsUtil.SELECT_REVISION);
				busSelect.add(ConstantsUtil.SELECT_TYPE);
				busSelect.add(ConstantsUtil.SELECT_CURRENT);
				busSelect.add(ConstantsUtil.SELECT_POLICY);
				busSelect.add(ConstantsUtil.SELECT_ID);
				
				busSelect.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
				
				busSelect.add(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME);
				
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- Start
				StringList slRelSelects = new StringList();
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRID);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PQRTYPE);
				StringBuilder sbSupId = new StringBuilder();
				StringBuilder sbName = new StringBuilder();
				StringBuilder sbRev = new StringBuilder();
				StringBuilder sbType = new StringBuilder();
				StringBuilder sbDesc = new StringBuilder();
				StringBuilder sbState = new StringBuilder();
				StringBuilder sbSupName = new StringBuilder();
				StringBuilder sbSupRev = new StringBuilder();
				StringBuilder sbSupType = new StringBuilder();
				StringBuilder sbSupDesc = new StringBuilder();
				StringBuilder sbSupState = new StringBuilder();
				
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
				StringBuilder sbId = new StringBuilder();
				StringBuilder sbPQRName = new StringBuilder();
				StringBuilder sbPQRRevision = new StringBuilder();
				StringBuilder sbSupplier =new StringBuilder();
				StringBuilder sbPQRType = new StringBuilder();
				StringBuilder sbPQRState = new StringBuilder();
				StringBuilder sbPQRId = new StringBuilder();
				//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
				
				//SPEC: <07.04.2022>: Guna Modified for Req 35586 22x Release  -- START  
				//SPEC: <07.04.2022>: Guna Modified for Req 35586 22x Release  -- END
				//SPEC: <08.04.2022>: Guna Modified for Req 42491 22x Release  -- START 
				StringBuilder sbWhere =new StringBuilder();
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM) || sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP)) {
					sbWhere.append(DomainConstants.SELECT_CURRENT).append(" ==").append(ConstantsUtil.STATE_RELEASE).append(" && ");
					sbWhere.append(DomainConstants.SELECT_CURRENT).append(" !=").append(ConstantsUtilIRM.STATE_LOCKED);
				}else {
					sbWhere.append(DomainConstants.SELECT_CURRENT).append(" !==").append(ConstantsUtil.STATE_OBSOLETE).append(" && ");
					sbWhere.append(DomainConstants.SELECT_CURRENT).append(" !=").append(ConstantsUtilIRM.STATE_LOCKED);
				}
				//SPEC: <08.04.2022>: Guna Modified for Req 42491 22x Release  -- END
				MapList mlEnterpriseParts = doMEP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT,
						ConstantsUtil.SYMBL_ASTERISK, busSelect, slRelSelects, true, false, (short) 1,
						sbWhere.toString(), ConstantsUtil.EMPTY_STRING, 500);
				//SPEC: Release SR18x.6.0 - Defect#InternalDefect Added  by gaikwad.tg on Date 05 May 2021 -- END :: Added
				//SPEC: Release SR18x.5.2: Modified for Defect 37248 by Amman ## -- END
				 int size=mlEnterpriseParts.size();
				  if (size==500) {
					  String[] sError = ConstantsUtilIRM.E109.split(ConstantsUtil.SYMBL_COLON);
					  mpHeaderResult.put(ConstantsUtil.ERROR, sError[1].toString());
				}
				//SPEC: <02.09.2022>: Guna Modified for 49943 Defect   Dev 22x    -- END		
				//SPEC: Release SR18x.5.2: Modified for Defect 37248 by Amman ## -- START
				mlEnterpriseParts.sort(DomainConstants.SELECT_NAME, "ascending", "String");
				//SPEC: Release SR18x.5.2: Modified for Defect 37248 by Amman ## -- END
				
				Iterator entPartsListItr = mlEnterpriseParts.iterator();
				while (entPartsListItr.hasNext()) {
					Map objectMap = (Map) entPartsListItr.next();
					String sPolicy = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_POLICY));
					if(sPolicy.equalsIgnoreCase("Supplier Equivalent")) {
						String supDesc = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
						String supCurrent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
						String supSuplier = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SUPPLIER_NAME));
						
						
						String supId = validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));

						if (!supCurrent.equalsIgnoreCase("Release")
								&& !supCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED)) {

							supId = ConstantsUtil.NO_ACCESS;
						}
						boolean showData = util.checkHasAccess(context, sUserType, validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID)));
						if (!showData) {
							supId = ConstantsUtil.NO_ACCESS;
							supCurrent = ConstantsUtil.NO_ACCESS;
							supSuplier = ConstantsUtil.NO_ACCESS;
							supDesc = ConstantsUtil.NO_ACCESS;
						}
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 06 May 2021 -- START
						if(isExternal && supId.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
						continue;
						
						formatData(sbSupName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
						formatData(sbSupRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
						//SPEC: 09-08-2022: Pooja Added for Internal Defect -- START
						formatData(sbSupType, util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
						formatData(sbSupDesc, supDesc);
						//SPEC: 09-08-2022: Pooja Added for Internal Defect -- END
						formatData(sbSupId, supId);
						formatData(sbDesc, supDesc);
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 06 May 2021 -- END
						formatData(sbSupState, supCurrent);
						formatData(sbSupplier, supSuplier);
						// modified by Ganesh for defect 39122 ---->end
					}else {
						
						//SPEC: Release 18x.5.2: Modified for Defect 37248 by Amman ## -- START
						if(objId.equalsIgnoreCase((String)objectMap.get(ConstantsUtil.SELECT_ID))) {
							continue;
						}
						//SPEC: Release 18x.5.2: Modified for Defect 37248 by Amman ## -- END
						//SPEC: Release SR18x.6.0 - Added for Defect# 41902 by gaikwad.tg on Date 30 March 2021 -- START
						boolean isShowParent = true;
						String supTempId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String supTempCurrent = util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
						String supTempDesc = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
						
						boolean showData = util.checkHasAccess(context, sUserType, validator
								.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID)));
						if (!showData) {
							supTempId = ConstantsUtil.NO_ACCESS;
							supTempCurrent = ConstantsUtil.NO_ACCESS;
							supTempDesc = ConstantsUtil.NO_ACCESS;
							isShowParent = false;
						}
						else
						{
							if(!(supTempCurrent.equals(ConstantsUtil.RELEASE)|| supTempCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED)))
								supTempId = ConstantsUtil.NO_ACCESS;
						}
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 06 May 2021 -- START
						if(isExternal && supTempId.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
						continue;
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 06 May 2021 -- END
						
						
						//SPEC: Release SR18x.6.0 - Added for internal bug by gaikwad.tg on Date 08 April 2021 -- START
						if(!isShowParent)
						{
							formatData(sbPQRId,ConstantsUtil.NO_ACCESS);
							formatData(sbPQRType,ConstantsUtil.NO_ACCESS);
							formatData(sbPQRName,ConstantsUtil.NO_ACCESS);
							formatData(sbPQRRevision,ConstantsUtil.NO_ACCESS);
							formatData(sbPQRState,ConstantsUtil.NO_ACCESS); 
						}
						else
						{
							//SPEC: Release SR18x.6.0 - Added for internal bug by gaikwad.tg on Date 08 April 2021 -- END
							String strPQRIdClassType = validator.getClassType(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
						  
						  if(strPQRIdClassType.equalsIgnoreCase(ConstantsUtil.STRING)||strPQRIdClassType.equalsIgnoreCase(ConstantsUtil.EMPTY_STRING)) 
						  {
							  if(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE)).equalsIgnoreCase(ConstantsUtil.STATE_FROZEN)) {
								  continue;
							  }
							 //SPEC: Release SR18x.6.0 - Added for Defect# 41902 by gaikwad.tg on Date 30 March 2021 -- START
							  String sTempPQRID = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
							  String sTempPQRType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRTYPE));
							  String sTempPQRName = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME));
							  String sTempPQRRev = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION));
							  String sTempPQRState = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE));
							  sTempPQRState=sTempPQRState.replace(ConstantsUtil.RELEASED,ConstantsUtil.APPROVED);
							  if(supTempId.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
								  sTempPQRID = ConstantsUtil.NO_ACCESS;
							  
							  if(sTempPQRState.equalsIgnoreCase(ConstantsUtil.RELEASED)||sTempPQRState.equalsIgnoreCase(ConstantsUtil.APPROVED)||sTempPQRState.equalsIgnoreCase(ConstantsUtil.QUALIFICATION_STATE_QUALIFIED)) {
								  formatData(sbPQRId,isShowParent ? sTempPQRID : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRType,isShowParent ? sTempPQRType : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRName,isShowParent ? sTempPQRName : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRRevision,isShowParent ? sTempPQRRev : ConstantsUtil.NO_ACCESS);
								  formatData(sbPQRState,isShowParent ? sTempPQRState : ConstantsUtil.NO_ACCESS); 
							  }
							  else {
							
									  formatData(sbPQRId,ConstantsUtil.NO_ACCESS);
									  formatData(sbPQRType,isShowParent ? sTempPQRType : ConstantsUtil.NO_ACCESS);
									  formatData(sbPQRName,isShowParent ? sTempPQRName : ConstantsUtil.NO_ACCESS);
									  formatData(sbPQRRevision,isShowParent ? sTempPQRRev : ConstantsUtil.NO_ACCESS);
									  formatData(sbPQRState,isShowParent ? sTempPQRState : ConstantsUtil.NO_ACCESS); 
									//}
							//SPEC: Release SR18x.6.0 - Added for Defect# 41902 by gaikwad.tg on Date 30 March 2021 -- END
							  }
						  }
						  
						  else
						  {
							  String strPQRId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRID));
							  String strPQRType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRTYPE));
							  String strPQRName = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRNAME));
							  String strPQRRev = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRREVISION));
							  String strPQRState = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRSTATE)).replace(ConstantsUtil.RELEASED, ConstantsUtil.APPROVED);
							  
							  String[] slPQRId = strPQRId.split(ConstantsUtil.SYMBL_COMMA);
							  String[] slPQRType = strPQRType.split(ConstantsUtil.SYMBL_COMMA);
							  String[] slPQRName = strPQRName.split(ConstantsUtil.SYMBL_COMMA);
							  String[] slPQRRev = strPQRRev.split(ConstantsUtil.SYMBL_COMMA);
							  String[] slPQRState = strPQRState.split(ConstantsUtil.SYMBL_COMMA);
							  
							  StringList sPQRId = new StringList();
							  StringList sPQRType = new StringList();
							  StringList sPQRName = new StringList();
							  StringList sPQRRev = new StringList();
							  StringList sPQRState = new StringList();
							  
							  for(int i=0;i<slPQRId.length;i++) {
								  if(i!=0) {
									  slPQRId[i] = slPQRId[i].substring(1);
									  slPQRType[i] = slPQRType[i].substring(1);
									  slPQRName[i] = slPQRName[i].substring(1);
									  slPQRRev[i] = slPQRRev[i].substring(1);
									  slPQRState[i] = slPQRState[i].substring(1);
								  }
							
								  if(slPQRState[i].equalsIgnoreCase(ConstantsUtil.STATE_FROZEN)) {
									  continue;
								  }
								  //SPEC: Release SR18x.6.0 - Added for Defect# 41902 by gaikwad.tg on Date 30 March 2021 -- START
								  slPQRState[i].replace(ConstantsUtil.RELEASED, ConstantsUtil.APPROVED);
								  
								  if(supTempId.equalsIgnoreCase(ConstantsUtil.NO_ACCESS))
									slPQRId[i] = ConstantsUtil.NO_ACCESS;
								  
								  if(slPQRState[i].equalsIgnoreCase(ConstantsUtil.RELEASED) || slPQRState[i].equalsIgnoreCase(ConstantsUtil.APPROVED) || slPQRState[i].equalsIgnoreCase(ConstantsUtil.QUALIFICATION_STATE_QUALIFIED)) {
									  
									  sPQRId.add(isShowParent ? slPQRId[i] : ConstantsUtil.NO_ACCESS);
									  sPQRType.add(isShowParent ? slPQRType[i] : ConstantsUtil.NO_ACCESS);
									  sPQRName.add(isShowParent ? slPQRName[i] : ConstantsUtil.NO_ACCESS);
									  sPQRRev.add(isShowParent ? slPQRRev[i] : ConstantsUtil.NO_ACCESS);
									  sPQRState.add(isShowParent ? slPQRState[i] : ConstantsUtil.NO_ACCESS);
								  }
								  else {
										  sPQRId.add(ConstantsUtil.NO_ACCESS);
										  sPQRType.add(isShowParent ? slPQRType[i] : ConstantsUtil.NO_ACCESS);
										  sPQRName.add(isShowParent ? slPQRName[i] : ConstantsUtil.NO_ACCESS);
										  sPQRRev.add(isShowParent ? slPQRRev[i] : ConstantsUtil.NO_ACCESS);
										  sPQRState.add(isShowParent ? slPQRState[i] : ConstantsUtil.NO_ACCESS);
										//}
								  //SPEC: Release SR18x.6.0 - Added for Defect# 41902 by gaikwad.tg on Date 30 March 2021 -- END
								  }
							  }
							//SPEC: Release SR18x.6.0.1 - Added for Defect# 43157  by gaikwad.tg on Date 26 May 2021 -- START
							  if(slPQRId.length>0 && sPQRId.isEmpty() )
							  {
								sPQRId.add(DomainConstants.EMPTY_STRING);
								sPQRType.add(DomainConstants.EMPTY_STRING);
								sPQRName.add(DomainConstants.EMPTY_STRING);
								sPQRRev.add(DomainConstants.EMPTY_STRING);
								sPQRState.add(DomainConstants.EMPTY_STRING); 
							  }
							  //SPEC: Release SR18x.6.0.1 - Added for Defect# 43157  by gaikwad.tg on Date 26 May 2021 -- END
							  formatData(sbPQRId,sPQRId.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
							  formatData(sbPQRType,sPQRType.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
							  formatData(sbPQRName,sPQRName.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
							  formatData(sbPQRRevision,sPQRRev.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
							  formatData(sbPQRState,sPQRState.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
										.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING));
						  }
						  //SPEC: Release SR18x.5.2: Modified for Defect 38345 by Amman ## -- END
						//SPEC: Release SR18x.6.0 - Added for internal bug by gaikwad.tg on Date 08 April 2021 -- START
					}
						formatData(sbName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
						formatData(sbRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
						formatData(sbType, util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
						formatData(sbDesc, supTempDesc);
						formatData(sbState, supTempCurrent);
						formatData(sbId,supTempId);
					}
				}
				/**
				 * This Method is for getting the MEPS
				 * @param context
				 * @param Relationship
				 * @param objectMap
				 * @param bMEP
				 * @return
				 * @throws Exception
				 */
				
				
				/**
				 * This Method is for getting the SEPS 
				 * @param context
				 * @param Relationship
				 * @param objectMap
				 * @param bSEP
				 * @return
				 * @throws Exception
				 */
				

				mpEnterpriseParts.put(ConstantsUtil.NAME, sbName.toString());
				mpEnterpriseParts.put(ConstantsUtil.REVISION, sbRev.toString());
				mpEnterpriseParts.put(ConstantsUtil.TYPE, sbType.toString());
				mpEnterpriseParts.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
				mpEnterpriseParts.put(ConstantsUtil.STATE, sbState.toString());
				
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- START
				mpEnterpriseParts.put(ConstantsUtil.ID, sbId.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRNAME, sbPQRName.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRSTATE, sbPQRState.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRREVISION, sbPQRRevision.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRID, sbPQRId.toString());
				mpEnterpriseParts.put(ConstantsUtil.PQRTYPE, sbPQRType.toString());
				//SPEC: <10.21.2020>: Added for req 18x.5 ## -- END
				
				swEnterprise.stop();
				LOGGER.info("MEP ENTERPRISE ELAPSED TIME : "+swEnterprise.getTime());
				
				//Equivalent SEP
				//modified by Ganesh for defect 39122 ----> start
				mpEquivalentSep.put(ConstantsUtil.ID, sbSupId.toString());
				//modified by Ganesh for defect 39122 ----> end
				mpEquivalentSep.put(ConstantsUtil.NAME, sbSupName.toString());
				mpEquivalentSep.put(ConstantsUtil.REVISION, sbSupRev.toString());
				mpEquivalentSep.put(ConstantsUtil.TYPE, sbSupType.toString());
				mpEquivalentSep.put(ConstantsUtil.DESCRIPTION, sbSupDesc.toString());
				mpEquivalentSep.put(ConstantsUtil.STATE, sbSupState.toString());
				mpEquivalentSep.put(ConstantsUtil.SUPPLIER, sbSupplier.toString());
				
				//Certification
				// Guna Added for Defect 37250  18x.5.2 Release -- START
				// Added by Jwala for the req 4945 - START
				if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					StopWatch swCert = new StopWatch();
					swCert.start();
					//MapList mlCertifications = commonBo.getCertifications(context, objId);
					MapList mlCertifications = SEP.getCertifications(context, objId, mpHeaderResult);
					StringBuilder sbCertName = new StringBuilder();
					StringBuilder sbCertRev = new StringBuilder();
					StringBuilder sbCertType = new StringBuilder();
					StringBuilder sbCertDesc = new StringBuilder();
					StringBuilder sbCertState = new StringBuilder();
					StringBuilder sbCertifications = new StringBuilder();
					StringBuilder sbStatus = new StringBuilder();
					StringBuilder sbCExpirationDate = new StringBuilder();
					StringBuilder sbCertId = new StringBuilder();
					//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- START
					StringBuilder sbCertSource = new StringBuilder();
					//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- END
					boolean showData = true;
					String strObjectID = DomainConstants.EMPTY_STRING;
					mlCertifications.sort(DomainConstants.SELECT_NAME, "ascending", "String");

					Iterator itrCerts = mlCertifications.iterator();
					while (itrCerts.hasNext()) {
						Map objectMap = (Map) itrCerts.next();
						String strCertification  =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_VALUE));
						StringTokenizer tokenize = new StringTokenizer(strCertification,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						String strStatus =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_STATUS));
						String strExpireDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_EXPIRATION_DATE));
						//SPEC: Release SR18x.6.0 - Added for Defect# 41799 by gaikwad.tg on Date 01 April 2021 -- START
						String strID = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						StringTokenizer objIDTokenize = new StringTokenizer(strID,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						//SPEC: Release SR18x.6.0 - Added for Defect# 41799 by gaikwad.tg on Date 01 April 2021 -- END
						StringTokenizer statusTokenize = new StringTokenizer(strStatus,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						StringTokenizer expireDateTokenize = new StringTokenizer(strExpireDate,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- START
						String strCertificationSource  =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_CERTIFICATION_SOURCE));
						StringTokenizer sourceTokenize = new StringTokenizer(strCertificationSource,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- END
						while(tokenize.hasMoreTokens())
						{
							//SPEC: Added for Defect 41799 by Jwala ## -- START
							strID  = (String)validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
							String strName= (String)validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
							String strCertRev = (String)validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
							String strCertType = (String)util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE)));
							String strCertDesc = (String)validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
							String strCertState = (String)validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
							String strCert  = tokenize.nextToken().toString().trim();
							//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- START
							String strCertSource =ConstantsUtil.EMPTY_STRING;
							if(sourceTokenize.hasMoreTokens()) {
								strCertSource =sourceTokenize.nextToken().toString().trim();
							}
							//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- END
							showData = util.checkHasAccess(context, sUserType, strID);

							if (!strCertState.equals(ConstantsUtil.RELEASE) &&  !strCertState.equals(ConstantsUtil.RELEASED)) {
								if(isExternal)
									continue;
								strID = ConstantsUtil.NO_ACCESS;
							}
							//SPEC: Release SR18x.6.0 - Added for ExternalDefect# by gaikwad.tg on Date 29 April 2021 -- START
							if(strCertState.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && strCertType.equalsIgnoreCase(ConstantsUtil.TYPE_RAWMATERIALPART))
								strCertState = ConstantsUtil.RELEASED;
							//SPEC: Release SR18x.6.0 - Added for ExternalDefect# by gaikwad.tg on Date 29 April 2021 -- END
							if(!showData){
								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 06 May 2021 -- START
								if(isExternal)
									continue;
								//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 06 May 2021 -- END
								formatData(sbCertName,strName);
								formatData(sbCertRev,strCertRev);
								formatData(sbCertType,strCertType);
								formatData(sbCertifications, strCert);
								formatData(sbCertDesc,ConstantsUtil.NO_ACCESS);
								formatData(sbCertState,ConstantsUtil.NO_ACCESS);
								formatData(sbCertId,ConstantsUtil.NO_ACCESS);
								//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- START
								formatData(sbCertSource,strCertSource);
								//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- END
							}else{
								formatData(sbCertName,strName);
								formatData(sbCertRev,strCertRev);
								formatData(sbCertType,strCertType);
								formatData(sbCertDesc,strCertDesc);
								formatData(sbCertState,strCertState);
								formatData(sbCertId,strID);
								formatData(sbCertifications, strCert);
								//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- START
								formatData(sbCertSource,strCertSource);
								//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- END
							}


							if(statusTokenize.hasMoreTokens() && expireDateTokenize.hasMoreTokens()){
								//SPEC: Modified for Defect 41799 by Jwala ## -- START
								if(showData){
									formatData(sbStatus,statusTokenize.nextToken().toString().trim());
									//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- START
									formatData(sbCExpirationDate,validator.DateFormatter(expireDateTokenize.nextToken().toString().trim()));
									//SPEC: Release SR18x.5.2 - Added for Defect 37250 by Amman ## -- END
								}else{
									formatData(sbStatus,ConstantsUtil.NO_ACCESS);
									formatData(sbCExpirationDate,validator.DateFormatter(expireDateTokenize.nextToken().toString().trim()));
								}
								//SPEC: Modified for Defect 41799 by Jwala ## -- END
							}else{
								// strStatus Added by Jwala insted of EMPTY_String for the defect - 50587
								formatData(sbStatus,strStatus);
								formatData(sbCExpirationDate,ConstantsUtil.EMPTY_STRING);
							}
						}
					}

					mpCertification.put(ConstantsUtil.NAME, sbCertName.toString());	
					mpCertification.put(ConstantsUtil.REVISION, sbCertRev.toString());
					mpCertification.put(ConstantsUtil.TYPE, sbCertType.toString());
					mpCertification.put(ConstantsUtil.DESCRIPTION, sbCertDesc.toString());
					mpCertification.put(ConstantsUtil.STATE, sbCertState.toString());
					mpCertification.put(ConstantsUtil.ID, sbCertId.toString());
					mpCertification.put(ConstantsUtil.CERTIFICATION, sbCertifications.toString());
					mpCertification.put(ConstantsUtil.STATUS, sbStatus.toString());
					mpCertification.put(ConstantsUtil.EXPIRATIONDATE, sbCExpirationDate.toString());
					//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- START
					mpCertification.put(ConstantsUtilIRM.CERTIFICATIONSOURCE, sbCertSource.toString());
					//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- END
					swCert.stop();
					LOGGER.info("MEP CERTIFICATION ELAPSED TIME : "+swCert.getTime());
				}
				// Added by Jwala for the req 4945 - END
				// Guna Added for Defect 37250  18x.5.2 Release -- END
				//SPEC: <09.06.2022>: Guna Added for Req 33476 and 41754 22x Release  -- START
				/**
				 * LOAD PACKAGING CERTIFICATIONS
				 * */
				String strCtxType = (String) resultMaps.get(DomainConstants.SELECT_TYPE);
				if(strCtxType.equals(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART) || strCtxType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
					StopWatch swPkgCert = new StopWatch();
					swPkgCert.start();
					String strName =(String)resultMaps.get(DomainConstants.SELECT_NAME);
					String strPolicy =(String)resultMaps.get(DomainConstants.SELECT_POLICY);
					if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
						MapList mpPackagingCert =MEP.getPackagingCertificationsList(context,objId,strName,strCtxType,strPolicy);
						mpPackCert =MEP.getCertificationDetails(context,mpPackagingCert,(String)resultMaps.get(DomainConstants.SELECT_NAME),doMEP,strCtxType);
					}
					 swPkgCert.stop();
					LOGGER.info("MEP PACKAGING CERTIFICATIONS ELAPSED TIME : "+swPkgCert.getTime());
				}
				//SPEC: <09.06.2022>: Guna Added for Req 33476 and 41754 22x Release  -- END
			}
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		
			hmAttrib.put(ConstantsUtil.REACH, mpReachResult);
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- START
			//Modified by Ketan for Req 2332 -- START
			if(showMaterialAndComp) {
				if(!isRM) {
					hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialComposition);
				}
				else if(isRM && !bSupplierView) {
					hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialComposition);
				}
				//Added by Ketan for Req. no. 6045 -- START
				else if(isRM && bSupplierView) {
					String stType = validator.isNotNullOrEmpty((String)mpMaterialComposition.get(ConstantsUtil.TYPE))?(String)mpMaterialComposition.get(ConstantsUtil.TYPE) : ConstantsUtil.EMPTY_STRING;
					if(stType.contains(ConstantsUtilIRM.EXTERNAL_MATERIAL)) {
						hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialComposition);
					}
				}
				//Added by Ketan for Req. no. 6045 -- END
			}
			//Modified by Ketan for Req 2332 -- END
			if(showSubstanceAndMaterial)
			hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpMaterialResult);
			hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 02 Mar 2021 -- END
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- START
			//SPEC: <07.09.2021>: Bala Modified for 41875 Defect  Dev 18x.6.0.2   -- START
			if (bAllInfoView) {
				hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			}
			//SPEC: <07.09.2021>: Bala Modified for 41875 Defect  Dev 18x.6.0.2   -- END
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 15 March 2021 -- END
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.ENTERPRISEPARTS, mpEnterpriseParts);
			hmAttrib.put(ConstantsUtil.EQUIVALENTSEP, mpEquivalentSep);
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				hmAttrib.put(ConstantsUtil.CERTIFICATION, mpCertification);
			}
			// Added by Jwala for the req 4945 - END
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
			
			//SPEC: <10.19.2020>: Added for req 18x.5 ## -- START
			
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			//SPEC: <10.19.2020>: Added for req 18x.5 ## -- END
			//SPEC: <18.04.2022>: Guna Modified for Req 33476 22x Release  -- START
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: <18.04.2022>: Guna Modified for Req 33476 22x Release  -- END
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				hmAttrib.put(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS, mpPackCert);
			}
			pool.checkIn(context);
			sp.stop();
			LOGGER.info("MEP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "MEP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));

		} catch (IOException e) {
			LOGGER.error("Exception in getMEPdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		} catch (MatrixException e) {
			LOGGER.error("Exception in getMEPdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		//LOGGER.info("MEP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		context.close();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmAttrib;
	}
	
	public static void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
}
