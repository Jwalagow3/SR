package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UITableCustom;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MRMPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class MRMPService {

	private static Logger LOGGER = Logger.getLogger(MRMPService.class);

	public static void main(String[] args) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();
		//String objId = "20336.41905.32768.33740";
		//String objId = "20336.41905.32768.33730";//
		//String objId = "20336.41905.45835.24537";
		String objId = "20336.41905.38752.3462";
		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
	    Context context = pool.checkOut();

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);

		
		Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
		Map<String,String> mpDerivedToResult = new HashMap<String,String>();
		Map<String,String> mpSecurity = new HashMap<String,String>();
		Map<String,String> mapPartSpecification = new HashMap<String,String>();
		Map<String,String> mpPerformChar= new HashMap<String,String>();
		Map<String, String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mpNotes = new HashMap<String,String>();

		MRMPBO mrmpBO = new MRMPBO();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, StringList> BusinessObjectSelectableMap = mrmpBO.getMRMPPartSelectables(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringValidatorUtil validator = new StringValidatorUtil();
		DomainObject doMRMP =  mrmpBO.getMRMPDO(context, objId);
		mrmpBO.addMultiList();
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doMRMP.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("MRMP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		mrmpBO.removeMultiList();
		
		StopWatch swHistory = new StopWatch();
		swHistory.start();
		StringList slHistoryInfo = doMRMP.getHistory(context);
		String lastUpdatedUser = util.getLastUpdateUser(slHistoryInfo);
		swHistory.stop();
		LOGGER.info("MRMP swHistory ELAPSED TIME : "+swHistory.getTime());

		//Attribute Data
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(lastUpdatedUser)))?(String)resultMaps.get(lastUpdatedUser) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_TEMPLATE)))?(String)resultMaps.get(ConstantsUtil.STR_TEMPLATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		
		//Organization Data
		StopWatch swOrganization = new StopWatch();
		swOrganization.start();
		mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization = util.filterMapList(mpOrganization);
		swOrganization.stop();
		LOGGER.info("MRMP Organization ELAPSED TIME : "+swOrganization.getTime());
	
		//Notes 
		StopWatch swNotes = new StopWatch();
		swNotes.start();
		MasterCOPBO mcop = new MasterCOPBO();
		mpNotes=mcop.updateNotes(context,resultMaps);
		swNotes.stop();
		LOGGER.info("MRMP Notes ELAPSED TIME : "+swNotes.getTime());
	
		//Performance Car
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(ConstantsUtil.OBJECT_ID, objId);
		paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
		paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
		paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

		PerformanceCharcteristics perform = new PerformanceCharcteristics();
		StopWatch swPerfChar = new StopWatch();
		swPerfChar.start();
		MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
		if(!mlPerformChar.isEmpty())
		{
			FinishedProductPartBO fppBO = new FinishedProductPartBO();
			MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
			//mpPerformChar =  util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
		}
		swPerfChar.stop();
		LOGGER.info("MRMP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

		
		//Reference Docs
		StopWatch swReference= new StopWatch();
		swReference.start();
		mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
		swReference.stop();
		LOGGER.info("MRMP  Reference ELAPSED TIME : "+swReference.getTime());
		
		
		//Derived Data
		StopWatch swDerived = new StopWatch();
		swDerived.start();
		String sName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
		String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
		String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING;
		mpDerivedFromResult = mrmpBO.updateDerivedDataInfo(context,sName, sRev, sCreatedDate, doMRMP,true,false);
		mpDerivedToResult = mrmpBO.updateDerivedDataInfo(context,sName, sRev, sCreatedDate, doMRMP,false,true);
		swDerived.stop();
		LOGGER.info("MRMP  Derived ELAPSED TIME : "+swDerived.getTime());

		
		//LifeCycle
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={objId,sPhysicalId};
		StopWatch swLifecycle = new StopWatch();
		swLifecycle.start();
		mpLifeCycleApproval = util.getCOName(context, changeargs);
		swLifecycle.stop();
		LOGGER.info("MRMP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
		mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);


		//Ownership
		StopWatch swOwnerShip = new StopWatch();
		swOwnerShip.start();
		mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		String sCoOwner = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS) : ConstantsUtil.EMPTY_STRING;
		String sCoOwnerActual = "";
		mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty(sCoOwnerActual))?(sCoOwnerActual) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?(lastUpdatedUser) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
		swOwnerShip.stop();
		LOGGER.info("MRMP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());

		//Security
		StopWatch swSecurity = new StopWatch();
		swSecurity.start();
		CommonBusUtilBO cbs = new CommonBusUtilBO();
		mpSecurity =cbs.updateSecurity(context,resultMaps);
		swSecurity.stop();
		LOGGER.info("MRMP  Security ELAPSED TIME : "+swSecurity.getTime());


		//HeaderContent
		mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);

		
		//Part Spec Data
		mapPartSpecification = util.updatePartSpec(context, resultMaps);
		

		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO, mpDerivedToResult);
		hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mapPartSpecification);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
		
		System.out.println("RESULT :: \n"+mapPartSpecification);
		
		ContextUtil.popContext(context);
		pool.checkIn(context);
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
		sp.stop();
		LOGGER.info("MRMP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "MRMP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		
	}
	
	
	
}
