/**
 * Project 		: SpecsAnywhere
 * Program 		: MPPBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class MPPBO extends BusinessObject{
	
	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(MPPBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	
	public MPPBO() {
		// empty constructor
	}

	public MPPBO(String oid) {
		this.setObjectId(oid);
	}

	/**
	 * Method Name 			: getMPPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getMPPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getMPPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getMPPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getMPPPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getMPPPartSelectables(Context context) {
		StringList busSelect = new StringList(150);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getFileSelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
		
		
	}
	
	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT);
		busSelect.add(ConstantsUtil.ATTRIBUTE_PGPRODUCTFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.STR_TEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.ATL_STATE);
		
		busSelect.add(ConstantsUtil.SELECT_REL_DERIVIED_ID);
		busSelect.add(ConstantsUtil.SELECT_REL_DERIVED_NAME);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		return busSelect;
		
	}
	
	
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();


		try {

			
			MapList mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , null, getTo, getFrom, (short)0,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			if(mlDerivedList.isEmpty()){
				return new HashMap();
			}
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				StringValidatorUtil validator = new StringValidatorUtil();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				sCurrent=util.mapType(sCurrent);
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);
				String sCreatedDate=(String)objectMap.get(ConstantsUtil.SELECT_ORIGINATED);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
				util.formatData(sbDerivedName,sSourceName);
				util.formatData(sbSourceName,sDerivedName);
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());
				
		} catch (Exception e) {
			LOGGER.error("Error from MPPBO: updateDerivedDataInfo"+e);
			return new HashMap();
		}
		return util.filterMapList(mpDerived);
	}
	
	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related details
	 * @param context
	 * @return
	 */
	private StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getRefDocSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getRefDocSelects(Context context)
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_REFERENCE_DOC_DESC);
		busSelect.add(ConstantsUtil.STR_REFERENCE_DOC_ID);
		busSelect.add(ConstantsUtil.STR_REFERENCE_DOC_TITLLE);
		busSelect.add(ConstantsUtil.STR_REFERENCE_DOC_TYPE);
		busSelect.add(ConstantsUtil.STR_REFERENCE_DOC_NAME);
		busSelect.add(ConstantsUtil.STR_REFERENCE_DOC_REV); 
		busSelect.add(ConstantsUtil.STR_REFERENCE_DOC_STATE);

		
	
	return busSelect;
	}
	
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList(){
		 
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.OWNERSHIP);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		
		return slMultiSelects;
	}
	
	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	:
	 */
	public void removeMultiList(){
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.OWNERSHIP);
		 
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--END

	}

	
	/**
	 * Method Name 			: updateRefDocs
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> updateRefDocs(Context context,Map objectMap) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpRefDoc = new HashMap();
		StringBuilder sLangBuffer = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		try 
		{
			
			String sType = validator
					.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_TYPE));

			if (sType.isEmpty()) {
				return new HashMap();
			}
			String[] slType = sType.split(",");
			
		String sName    =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_NAME));
		String sId=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_ID));
		String sCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_STATE));
		String sRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_REV));
		String sDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_DESC));
		String sTitle=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_REFERENCE_DOC_TITLLE));
		String[] slId = sId.split(ConstantsUtil.SYMBL_COMMA);

		for(int i=0 ;i<slType.length;i++)
		{
			String	sTempType = slType[i];
			String	sTempsId = slId[i];
			if((!sTempType.equals(ConstantsUtil.TYPE_PKDIPLATFORM)))
			{
				sLangBuffer.append(new DomainObject(sTempsId).getAttributeValue(context,ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE)).append(ConstantsUtil.SYMBL_PIPE);
			} else {
				sLangBuffer.append(new DomainObject(sTempsId).getAttributeValue(context,ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE)).append(ConstantsUtil.SYMBL_PIPE);
			}
			sbSource.append(ConstantsUtil.SOURCE_DIRECT).append(ConstantsUtil.SYMBL_PIPE);
		}

			StringList slTypes= util.MapsType(slType);
			sType=util.replaceSpecialSymbols(slTypes.toString());
			mpRefDoc.put(ConstantsUtil.NAME, sName);
			mpRefDoc.put(ConstantsUtil.TITLE, sTitle);
			mpRefDoc.put(ConstantsUtil.SOURCE,sbSource.toString());
			mpRefDoc.put(ConstantsUtil.TYPE,sType);
			mpRefDoc.put(ConstantsUtil.STATE, sCurrent);
			mpRefDoc.put(ConstantsUtil.DESCRIPTION, sDesc);
			mpRefDoc.put(ConstantsUtil.ID, sId);
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sLangBuffer.toString());
			mpRefDoc.put(ConstantsUtil.REVISION, sRev);

		} catch (Exception e) {
			LOGGER.error("Exception in Program : MPPBO Method :updateRefDocs "+e);
			return new HashMap();
		}

		return mpRefDoc;
	}

	
	/**
	 * Method Name 			: getMPPRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getMPPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;
		
	}
	
	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.STR_IPCLASS);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
	
		// Added for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		// Added for Defect# 37591 -- END
		
		
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --END
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
		

		return relSelect;
	}
	
	
	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context,MapList mapList) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		 StringBuilder sbEBOMChg = new StringBuilder();
		 StringBuilder sbEBOMFN = new StringBuilder();
		 StringBuilder sbEBOMTitle = new StringBuilder();
		 StringBuilder sbEBOMType = new StringBuilder();
		 StringBuilder sbEBOMQTY = new StringBuilder();
		 StringBuilder sbEBOMBuom = new StringBuilder();
		 StringBuilder sbEBOMCommnts = new StringBuilder();
		 StringBuilder sbEBOMState= new StringBuilder();
		 StringBuilder sbEBOMStage= new StringBuilder();
		 StringBuilder sbEBOMRD= new StringBuilder();
		 StringBuilder sbEBOMOC= new StringBuilder();
		 StringBuilder sbEBOMSubstute= new StringBuilder();
		 
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlter= new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		 StringBuilder sbEBOMRevRelDt= new StringBuilder();
		 StringBuilder sbEBOMId= new StringBuilder();
	 	 StringBuilder sbMinqty= new StringBuilder();
		 StringBuilder sbMaxqty= new StringBuilder();
		 StringBuilder sbMF= new StringBuilder();
		 StringBuilder sbOSPD= new StringBuilder();
		 StringBuilder sbDen= new StringBuilder();
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		 try {
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			 while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String sType =(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
					String sId =(String)objectMap.get(ConstantsUtil.SELECT_ID);
					String spgChg =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
					String sFN =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
					String sTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					sType = util.mapType(sType);
					String sRevision =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sSubstitute=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
					sSubstitute =util.replaceSpecialSymbols(sSubstitute);
					
					
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//String sAlterNate=(String)objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
					//sAlterNate =util.replaceSpecialSymbols(sAlterNate);
					StringValidatorUtil validator = new StringValidatorUtil();
					String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
					strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					String strAltID = util.checkAlternateHasAccess(context,objectMap);	
					String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
					strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					
	
					String sMin=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
					String sMax=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
					String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
					
					
					
					String strOSPD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
					String strDenUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
					
					String sQty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					String sBuom =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					String sComments=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					String sCurrent =(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
					sCurrent = util.mapType(sCurrent);
					String sStage =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
					String sRD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
					String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
					
					sRD =util.replaceSpecialSymbols(sRD);
					sOC =util.replaceSpecialSymbols(sOC);
					//StringValidatorUtil validator = new StringValidatorUtil();
					String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
					
					SecurityService sec = new SecurityService();
					String sUserlicense = sec.getUserLicense();
					
					boolean bHasOwnership = false;
					boolean showData = false;
					if(util.isModificatinRequired())
					{   
						//commented by Ganesh for security impl------>start
						/*String sComp = sec.getUserCauthorities();
						StringList slUserOwnership=util.filterOwnerShip(sComp);
	
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);*/
						//commented by Ganesh for security impl------>end
						//modified by Ganesh for security impl------>start
						bHasOwnership = util.checkHasAccess(context, null, sId);
						//modified by Ganesh for security impl------>end
					
						if(!bHasOwnership)
						{
							sId = ConstantsUtil.NO_ACCESS;
							spgChg = ConstantsUtil.NO_ACCESS;
							sFN    = ConstantsUtil.NO_ACCESS;
							sTitle = ConstantsUtil.NO_ACCESS;
							sSubstitute = ConstantsUtil.NO_ACCESS;
							
							// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
							//sAlterNate = ConstantsUtil.NO_ACCESS;
							// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
							sMin = ConstantsUtil.NO_ACCESS;
							sMax = ConstantsUtil.NO_ACCESS;
							sBuom = ConstantsUtil.NO_ACCESS;
							sCurrent = ConstantsUtil.NO_ACCESS;
							strMF = ConstantsUtil.NO_ACCESS;
							sComments = ConstantsUtil.NO_ACCESS;
							sStage = ConstantsUtil.NO_ACCESS;
							sRD = ConstantsUtil.NO_ACCESS;
							sOC = ConstantsUtil.NO_ACCESS;
							strOSPD = ConstantsUtil.NO_ACCESS;
							strDenUOM = ConstantsUtil.NO_ACCESS;
							
					    }
					}else //commented by Ganesh for security impl------>start
						/*if(sec.isStaffAUGUser()) {
						
						if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else {
							showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
						}
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
						
						if(slHIRTypes.contains(sType)) {
							showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
						}else {
							showData=true;
						}
						
					}*/
						//commented by Ganesh for security impl------>end
						//modified by Ganesh for security impl------>start
					{
						showData = util.checkHasAccess(context, null, sId);
					}
						//modified by Ganesh for security impl------>end
					
					if(!showData){
						sId = ConstantsUtil.NO_ACCESS;
						spgChg = ConstantsUtil.NO_ACCESS;
					}
				
					sType = util.mapType(sType);
							
					util.formatData(sbEBOMName,sName);
					util.formatData(sbEBOMRevRelDt,sRevision);
					util.formatData(sbEBOMType,sType);
					
					util.formatData(sbEBOMId,sId);
					util.formatData(sbEBOMChg,spgChg);
					util.formatData(sbEBOMFN,sFN);
					util.formatData(sbEBOMTitle,sTitle);
					util.formatData(sbEBOMSubstute,sSubstitute);
					
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//util.formatData(sbEBOMAlter,sAlterNate);
					util.formatData(sbAltName,strAltName);
					util.formatData(sbAltID,strAltID);
					util.formatData(sbAltType,strAltType);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					util.formatData(sbMinqty,sMin);
					util.formatData(sbMaxqty,sMax);
					util.formatData(sbEBOMQTY,sQty);
					util.formatData(sbEBOMBuom,sBuom);
					util.formatData(sbEBOMState,sCurrent);
					util.formatData(sbMF,strMF);
					util.formatData(sbEBOMCommnts,sComments);
					util.formatData(sbEBOMStage,sStage);
					util.formatData(sbEBOMRD,sRD);
					util.formatData(sbEBOMOC,sOC);
					util.formatData(sbOSPD,strOSPD);
					util.formatData(sbDen,strDenUOM);
					
				}
			 mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
			 mpEBOMResult.put(ConstantsUtil.REVISION, sbEBOMRevRelDt.toString());
			 mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
			 mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			 mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
			 mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
			 mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			 mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
			 
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//mpEBOMResult.put(ConstantsUtil.ALTERNATES, sbEBOMAlter.toString());
			mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
			mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
			mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			
	//		 mpEBOMResult.put(ConstantsUtil.MIN, sbMinqty.toString());
	//		 mpEBOMResult.put(ConstantsUtil.MAX, sbMaxqty.toString());
	//		 mpEBOMResult.put(ConstantsUtil.MATERIALFUNCTION, sbMF.toString());
			 
			 mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			 mpEBOMResult.put(ConstantsUtil.UNITOFMEASURE, sbEBOMBuom.toString());
			 mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			 mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
			 mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
			 mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRD.toString());
			 mpEBOMResult.put(ConstantsUtil.OSPD, sbOSPD.toString());
			 mpEBOMResult.put(ConstantsUtil.DUOM, sbDen.toString());
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		 }catch(Exception e){

				LOGGER.error("Error from MPPBO:  parseMaplist"+e);
				return new HashMap();
		}
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
		 
		return mpEBOMResult;
	}
	
	/**
	 * Method Name 			: parseMaplistBOM
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplistBOM(Context context,MapList mapList) 
	{
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMTupName= new StringBuilder();
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlternate = new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDensityUOM = new StringBuilder();
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		StringBuilder sbGrossWeightReal = new StringBuilder(); //Modified by Ketan for req no. 41754 on 06.14.2022
		StringBuilder sbGrossWeightUOM = new StringBuilder();
		StringBuilder sbNSPCG = new StringBuilder();
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- START
		StringBuilder sbRR = new StringBuilder();
		StringBuilder sbRRC = new StringBuilder();
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- END
		
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			String sId =(String)objectMap.get(ConstantsUtil.SELECT_ID);
			String sName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
			String sRevision =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
			String sReleaseDate =validator.DateFormatter((String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
			String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			String spgChg =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
			String sFN =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			String sTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			String sType =(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
			String sTupName =(String)objectMap.get(ConstantsUtil.TUPNAME);
			String sSubstitute=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
			sSubstitute = util.replaceSpecialSymbols(sSubstitute);
			String sQty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			String sBuom =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
			String sComments=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			String sCurrent =(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
			sCurrent=util.mapType(sCurrent.trim());
			String sStage =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			String sRD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
			sRD = util.replaceSpecialSymbols(sRD);
			String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
			sOC = util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;

			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//String sAlternate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
			//sAlternate = sAlternate.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
			strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strAltID = util.checkAlternateHasAccess(context,objectMap);	
			String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
			strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			String sOSPD = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY));
			String sDensityUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM));
			
					
			String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
			String sParentId =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID);
			String sParentName =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME);
			String sParentRevision =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV);
			String sParentType =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE);
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
			//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- START
			String sRR = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
			String sRRC = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
			//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- END
			String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
			String strGrossWeightReal = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));//Modified by Ketan for req no. 41754 on 06.14.2022
			String strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));//Modified by Ketan for req no. 41754 on 06.14.2022
			String sNSPCG = (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
			boolean bHasOwnership = false;
			boolean bHasOwnershipParent = false;
			boolean showDataParent = false;
			
			String sFormulaPropagate = sId;
			if(util.isModificatinRequired())
			{
				
				bHasOwnership=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End
				if(!bHasOwnership)
				{
						spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
					sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
				}
				bHasOwnershipParent=util.checkHasAccess(context, null, sParentId);
				if(!bHasOwnershipParent) {
					sParentId = ConstantsUtil.NO_ACCESS;
				}
				
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			}else{
				boolean showData = true;
				
				//Added by Ganesh 1.0.2 Release Start
					showData=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End
					if(!showData){
						spgChg = ConstantsUtil.NO_ACCESS;
						sId = ConstantsUtil.NO_ACCESS;
						
					}
				showDataParent=util.checkHasAccess(context, null, sParentId);
				if(!showDataParent) {
					sParentId = ConstantsUtil.NO_ACCESS;
				}
			}			
			sType = util.mapType(sType);
			//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- START
			if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGTRANSPORTUNITPART)) {
				util.formatData(sbRR,sRR);
				util.formatData(sbRRC,sRRC);
			}
			//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- END
			sParentType = util.mapType(sParentType);

			// Security req -33193 HIR Components Attributes to Show
			util.formatData(sbEBOMType,sType);
			util.formatData(sbEBOMName,sName);
			util.formatData(sbEBOMQTY,sQty);
			util.formatData(sbEBOMBuom,sBuom);
			util.formatData(sbEBOMState,sCurrent);

			util.formatData(sbEBOMId,sId);
			util.formatData(sbEBOMChg,spgChg);
			util.formatData(sbEBOMFN,sFN);
			util.formatData(sbEBOMTitle,sTitle);
		//	util.formatData(sbEBOMSubstute,sSubstitute);
			util.formatData(sbEBOMCommnts,sComments);
			util.formatData(sbEBOMStage,sStage);
			util.formatData(sbEBOMRDOC,sRDOC);
			util.formatData(sbEBOMRevRelDt,sRevRelease);
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			
			util.formatData(sbEBOMSubstitutePart, strSubPart);
			util.formatData(sbEBOMSubPartID, strSubPartId);
			util.formatData(sbEBOMSubPartType, strSubPartType);
			
			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//formatData(sbEBOMAlternate, sAlternate);
			util.formatData(sbAltName,strAltName);
			util.formatData(sbAltID,strAltID);
			util.formatData(sbAltType,strAltType);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
			util.formatData(sbEBOMParentId,sParentId);
			util.formatData(sbEBOMParentName,sParentName);
			util.formatData(sbEBOMParentRevision,sParentRevision);
			util.formatData(sbEBOMParentType,sParentType);
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END			
			util.formatData(sbEBOMOSPD, sOSPD);
			util.formatData(sbEBOMDensityUOM, sDensityUOM);
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			util.formatData(sbGrossWeightReal, strGrossWeightReal);//Modified by Ketan for req no. 41754 on 06.14.2022
			util.formatData(sbGrossWeightUOM, strGrossWeightUOM);//Modified by Ketan for req no. 41754 on 06.14.2022
			util.formatData(sbNSPCG, sNSPCG);
			if(null!=sTupName && !sTupName.isEmpty()) {
				util.formatData(sbEBOMTupName,sTupName);
			}

		}
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
	//	mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlternate.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDensityUOM.toString());
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- START
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRR.toString());
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRRC.toString());
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- END
		if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());//Modified by Ketan for req no. 41754 on 06.14.2022
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());//Modified by Ketan for req no. 41754 on 06.14.2022
		mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbNSPCG.toString());
		return mpEBOMResult;
	}
	
	
	/**
	 * Method Name 			: getSubstitute
	 * Method Description 	:
	 * @param mapList
	 * @return
	 */
	public Map<String, String> getSubstitute(MapList mapList) 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Iterator objectListItr = mapList.iterator();
			StringBuilder sbEBOMName = new StringBuilder();
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentRev = new StringBuilder();
			StringBuilder sbEBOMParentTitle = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMRefDoc= new StringBuilder();
			StringBuilder sbEBOMFN = new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMCommnts = new StringBuilder();
			StringBuilder sbEBOMSubType= new StringBuilder();
			StringBuilder sbEBOMEffectDate= new StringBuilder();
			StringBuilder sbEBOMUntilDate= new StringBuilder();
			StringBuilder sbEBOMCobNum= new StringBuilder();
			StringBuilder sbEBOMChildRev= new StringBuilder();
			StringBuilder sbIntended= new StringBuilder();
			StringBuilder sbMF= new StringBuilder();
			StringBuilder sbEBOMRDOC= new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
			try {
			//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String sChildExists=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)){
					String sParentName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
					String sParentRev =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sParentTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sChildName =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
					String sChildRev=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
					String sCombinationNum=(String)objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
					String sChildTitle =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
					String sChildType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
					sChildType = util.mapType(sChildType);
					//Added for Defect# 37591 -- START
					//String sSUBType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
					String sSUBType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
					//Added for Defect# 37591 -- END
					String sQTY =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
					String sBASEUOM =(String)objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
					String sEffectvityDate =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
					String sUntilDate=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
					String sRefDoc =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
					String sComments=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
					String sIntendedMarket =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
					String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
					String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
					sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
					
					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
	
	
	
					util.formatData(sbEBOMParentId,sParentID);
					util.formatData(sbEBOMId,sChildId);
					
					util.formatData(sbEBOMParentName,sParentName);
					util.formatData(sbEBOMParentRev,sParentRev);
					util.formatData(sbEBOMParentTitle,sParentTitle);
					util.formatData(sbEBOMName,sChildName);
					util.formatData(sbEBOMId,sChildId);
					util.formatData(sbEBOMChildRev,sChildRev);
					util.formatData(sbEBOMCobNum,sCombinationNum);
					util.formatData(sbEBOMTitle,sChildTitle);
					util.formatData(sbEBOMType,sChildType);
					util.formatData(sbEBOMSubType,sSUBType);
					util.formatData(sbEBOMQTY,sQTY);
					util.formatData(sbEBOMBuom,sBASEUOM);
					util.formatData(sbEBOMEffectDate,sEffectvityDate);
					util.formatData(sbEBOMUntilDate,sUntilDate);
					util.formatData(sbEBOMRefDoc,sRefDoc);
					util.formatData(sbEBOMCommnts,sComments);
					util.formatData(sbIntended,sIntendedMarket);
					util.formatData(sbMF,strMF);
					util.formatData(sbEBOMRDOC,sOC);
	
					}
				}
				mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
				mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
				mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
				mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
				mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
				mpEBOMResult.put(ConstantsUtil.INTENDEDFUNCTION, sbIntended.toString());
				mpEBOMResult.put(ConstantsUtil.OC, sbEBOMRDOC.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
			//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
			}catch(Exception e){

				LOGGER.error("Error from MPPBO:  getSubstitute"+e);
				return new HashMap();
			}
			//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			return mpEBOMResult;

	}

	
	/**
	 * Method Name 			: getDerivedFromParts
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param strDerivedFromSourceObjId
	 * @return
	 * @throws FrameworkException
	 */
	  public static Map getDerivedFromParts(Context context, String sSourceName, String strDerivedFromSourceObjId) throws FrameworkException

      {

      	MapList DerivedFrompartList = new MapList();
      	Map mpDerived = new HashMap();
      	
      	BusObjectAttribUtil util  = new BusObjectAttribUtil();
      	
      	StringBuilder sbDerivedName = new StringBuilder();
		StringBuilder sbSourceName=new StringBuilder();
		StringBuilder sbDesc=new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbOrganization=new StringBuilder();
		StringBuilder sbRevision=new StringBuilder();
		StringBuilder sbOwner=new StringBuilder();
		StringBuilder sbOriginated=new StringBuilder();
		StringBuilder sbGenerationNum =new StringBuilder();
		
		
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();

		
      	try
      	{
      		if(UIUtil.isNotNullAndNotEmpty(strDerivedFromSourceObjId)){

      			DomainObject doDerivedFromSourceObj =DomainObject.newInstance(context, strDerivedFromSourceObjId);
      			DerivedFrompartList = (MapList)doDerivedFromSourceObj.getRelatedObjects(context,         //Context
      					ConstantsUtil.RELATIONSHIP_DERIVED,        //Relationship Pattern
      					ConstantsUtil.TYPE_PART,                     //Type Pattern
      					slBusSelects,                 //Object Selects
      					null,                    //Relationship Selects
      					false,                        //get TO
      					true,                       //get From
      					(short)1,                    //Recurrence Level
      					"",                          //Object Where
      					""                           //RelationShip Where
      					);
      			
      			
      			
      			Iterator objectListItr = DerivedFrompartList.iterator();
      			while(objectListItr.hasNext())
    			{
    				Map objectMap = (Map) objectListItr.next();
    				StringValidatorUtil validator = new StringValidatorUtil();
    				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
    				String sDerivedRev=(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
    				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
    				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
    				sCurrent=util.mapType(sCurrent);
    				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
    				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);
    				String sCreatedDate=(String)objectMap.get(ConstantsUtil.SELECT_ORIGINATED);

    				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
    				
    				util.formatData(sbDerivedName,sDerivedName);
    				util.formatData(sbSourceName,sSourceName);
    				util.formatData(sbDesc,sDesc);
    				util.formatData(sbCurrent,sCurrent);
    				util.formatData(sbOrganization,sOrganization);
    				util.formatData(sbRevision,sDerivedRev);
    				util.formatData(sbOwner,sOwner);
    				util.formatData(sbOriginated,sCreatedDate);
    				util.formatData(sbGenerationNum,sGenerationNum);

    			}

    			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
    			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
    			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
    			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
    			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
    			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
    			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
    			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
    			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());
    		  }
      		
      	}catch(Exception exp)
      	{
      		throw new FrameworkException(exp.toString());
      	}

    	return mpDerived ;
      }
	  
	  public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
			HashMap mpFinalList = new HashMap();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbRevision = new StringBuilder();
			StringBuilder sbState = new StringBuilder();
			StringBuilder sbSubType = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbPhase = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			StringBuilder sbOrig = new StringBuilder();
			StringBuilder sbOwnership = new StringBuilder();
			StringValidatorUtil validator = new StringValidatorUtil();
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			
			StringBuilder sbDescription = new StringBuilder();
			StringBuilder sbInHerType = new StringBuilder();
			boolean showData = false;
			
			String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;
			
			if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
				sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
						+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
			}

			SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			String[] aCompany = sUserCompanies.split(",");
			StringBuilder sbCompany = new StringBuilder();
			StringList slCompanies = new StringList();

			boolean bHasOwnerShip = false;
			String sWhere = ConstantsUtil.EMPTY_STRING;
			String sUserType = util.getUserType();
			if (util.isModificatinRequired()) {
				sWhere = "current!=Obsolete";
			}
			if (aCompany.length > -1) {
				for (int i = 0; i < aCompany.length; i++) {
					if (null != aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
						slCompanies.add(Company);
					}
				}
			}
			StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
			
			StringList slRelSelects = new StringList();
			slRelSelects.add(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE);
			MapList mapList;
			try {
				DomainObject doAPP = new DomainObject(sObjectID);

				mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
						slPartSpecSelects, slRelSelects, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
						ConstantsUtil.ZERO_LEVEL);
				//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
				doAPP.close(context);
				//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
				for (int j = 0; j < mapList.size(); j++) {
					Map mpEachObj = (Map) mapList.get(j);
					StringList eachOwnership = validator
							.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
					// Split this to get only the companies
					StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

					String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
					
					String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
					String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
					String strSharable = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
					String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
					
					String strClassFied = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
					String strAutocadClassFied = validator
							.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
					
					String sIPClassfication = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
					String strSource = util.getSource(context, strId);
					String strSubType = util.UpdateSpecSubType(context, strId);
					
					String strInHerType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_ATTR_PG_INHERITANCE_TYPE));
					
					//commented by Ganesh start
					/*if (util.isModificatinRequired()) {
						if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {

							bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
							if (bHasOwnerShip) 
							{
								if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									
									
								} else {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
									
									sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
								}

							}else{
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							}

						} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
								|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
							bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
							if (bHasOwnerShip) 
							{
								if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {
									String sView = util.updateReferences(context, strId);
									LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

									if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
											&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
										sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
										sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
										sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
										sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
										sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
										sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
										sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
										sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
										sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
										sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									} else {

										sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
										sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
										sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
										String strState = validator
												.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
										sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
										sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
										String strTitle = validator.getStringEquivalentForSubstituteString(
												mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
										sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
										sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
										sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
										String strOrig = validator.getStringEquivalentForStringList(
												mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
										sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

										
										sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
									}
								}
							}else
							{
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							}
						} else {
							bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
							if (bHasOwnerShip) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteString(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

								sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
								
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							}
						}

					} else {
						if(sct.isStaffAUGUser()) {
							
							if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else if("ArtiosCAD Component".equalsIgnoreCase(strType)){
								showData=util.checkInternalUserAcess(sUserlicense,strAutocadClassFied);
							}else{
								showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
							}
						}else {
							StringList slHIRTypes = new StringList();
							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
							slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
							
							if(slHIRTypes.contains(strType)) {
								showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
							}else {
								showData=true;
							}
							
						}
						if (showData) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							//temporary fix to prevent users from downloading a Physical product(VPMReference)
							if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
								sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
							}else {
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							}
							
							sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
							
						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

						}

						
					}commented by Ganesh stop*/
					
					//Added by Ganesh start
					
					//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
String strId_Result = strId;
if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
strId_Result=ConstantsUtil.NO_ACCESS;
}

//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
					showData = util.checkHasAccess(context, sUserType, strId);
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						//temporary fix to prevent users from downloading a Physical product(VPMReference)
						if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
							sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
						}else {
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
/*String strState = validator
.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
						}
						
						sbInHerType.append(strInHerType).append(ConstantsUtil.SYMBL_PIPE);
						
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbInHerType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					}
					//Added by Ganesh stop

				}
				mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
				mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
				mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
				mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
				mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
				mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
				mpFinalList.put(ConstantsUtil.DESCRIPTION, sbTitle.toString());
				mpFinalList.put(ConstantsUtil.ID, sbId.toString());
				if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
					mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
					mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
				}
				mpFinalList.put(ConstantsUtil.INHERITANCETYPE, sbInHerType.toString());

			} catch (FrameworkException e) {
				LOGGER.error("Exception in MPPBO getPartSpecifications: " + e);
				return new HashMap();
			}
			return mpFinalList;
		}
	  
	  public Map updatePartSpec(Context context, Map objectMap) {
			StringValidatorUtil validator = new StringValidatorUtil();
			Map<String, String> mpPartSpecs = new HashMap<String, String>();
			try {

				String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
						? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
						String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
								? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

								mpPartSpecs = getPartSpecifications(context, sType, sID);
			} catch (Exception e) {
				LOGGER.error("Exception in Program : MPPBO Method :updatePartSpec " + e);
				return new HashMap();

			}
			return util.filterMapList(mpPartSpecs);
		}
	  
	//SPEC: <10.20.2020>: Added for req 18x.5 ## -- Start
		 public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
		    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
		    	MapList mlIPCLass;
				try {
					mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
							null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
							ConstantsUtil.ZERO_LEVEL);
					Iterator itr = mlIPCLass.iterator();
					Map mpIpClass = new HashMap();
					StringBuilder sbIpName = new StringBuilder();
					StringBuilder sbIpType = new StringBuilder();
					StringBuilder sbIpDesc = new StringBuilder();
					StringBuilder sbIpState = new StringBuilder();
					
					while(itr.hasNext()) {
						mpIpClass = (Map)itr.next();
						String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
						sbIpName.append(sIpClassName);
						sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
						sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
						sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
						
						if(itr.hasNext()) {
							sbIpName.append("|");
							sbIpType.append("|");
							sbIpDesc.append("|");
							sbIpState.append("|");
							
						}
					}
					mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
					mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
					mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
					mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
					
				} catch (FrameworkException e) {
					e.printStackTrace();
					LOGGER.error("Error from MPPBO: getIpClass" + e);
				}
				return mpIpSecuritySetting;
		    }
		 
		 public Map getProductPartStabilityDoc(Context context,Map resultMaps) 
			{
				StringList busSelect = new StringList();
				StringValidatorUtil validator = new StringValidatorUtil();

				busSelect.add(ConstantsUtil.SELECT_ID);
				busSelect.add(ConstantsUtil.SELECT_NAME);
				busSelect.add(ConstantsUtil.SELECT_REVISION);
				busSelect.add(ConstantsUtil.SELECT_TYPE);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				busSelect.add(ConstantsUtil.SELECT_CURRENT);
				busSelect.add(ConstantsUtil.STR_IPCLASS);
				
				busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
				busSelect.add(ConstantsUtil.SELECT_MASTERPARTREVISION);
				busSelect.add(ConstantsUtil.SELECT_MASTERPARTTITLE);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
				busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
				
				boolean bHasOwnerShip = false;
				
				SecurityService ss = new SecurityService();
				String sUserCompanies = ss.getUserCauthorities();
				String[] aCompany = sUserCompanies.split(",");
				StringBuilder sbCompany = new StringBuilder();
				
				if(aCompany.length>-1) {
					for(int i=0;i<aCompany.length;i++) {
						if(null!=aCompany[i]) {
							String Company = aCompany[i].toString();
							sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
						}
					}
				}

				String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

				
				Map<String, String> mpRefDoc = new HashMap();
				try
				{
					//SPEC: Release SR18x.6.0 - Modified for Defect# 42036 by Manikanta on Date 7/4/2021 -- START
					DomainObject doFOP = new DomainObject(sObjectId);
					MapList mlRefDocs = doFOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
							ConstantsUtil.TYPE_PGPKGSTABILITYREPORT.concat(",").concat(ConstantsUtil.TYPE_PGTECHNICALRATIONAL), busSelect, new StringList(), false, true, (short) 1,
							ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
					//SPEC: Release SR18x.6.0 - Modified for Defect# 42036 by Manikanta on Date 7/4/2021 -- END
					//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
					doFOP.close(context);
					//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
					String sUser = util.getUserType();
				
					if(sUser.equals(ConstantsUtil.PG_CM))
					{
						if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
							return new HashMap();
						}
					}
					
					if(util.isModificatinRequired()) 
					{
						mlRefDocs=util.filterPhase(mlRefDocs);
					}
					Iterator objectListItr = mlRefDocs.iterator();
					StringBuilder sbId = new StringBuilder();
					StringBuilder sbMasterProductPartName = new StringBuilder();
					StringBuilder sbMasterProductPartRevision = new StringBuilder();
					StringBuilder sbMasterProductPartTitle =new StringBuilder();
					StringBuilder sbProductExpirationDataRequired=new StringBuilder();
					StringBuilder sbTotalShelfLifeDays=new StringBuilder();
					StringBuilder sbTemperatureGroup=new StringBuilder();
					StringBuilder sbHumidityGroup=new StringBuilder();
					StringBuilder sbTransportFreezeProtection = new StringBuilder();
					StringBuilder sbTransportHeatProtection = new StringBuilder();
					StringBuilder sbBoundaryConditions = new StringBuilder();
					StringBuilder sbStabilityDocument = new StringBuilder();
					// Guna Added for Defect 38534  18x.5.2 Release -- START
					StringBuilder sbStabilityDocumentType = new StringBuilder();
					// Guna Added for Defect 38534  18x.5.2 Release -- END
					while(objectListItr.hasNext()) 
					{
						Map objectMap = (Map) objectListItr.next();
						String sId    =  (String)objectMap.get(ConstantsUtil.SELECT_ID);
						String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
						String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
						String sPLangBuffer	 =	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
						String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
						String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
						
						String sMasterProductPartName    =  validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_MASTERPARTNAME))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
						String sMasterProductPartRevision    =   validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_MASTERPARTREVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
						String sMasterProductPartTitle		=	validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_MASTERPARTTITLE))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTITLE) : ConstantsUtil.EMPTY_STRING;
						String sProductExpirationDataRequired	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
						String sTotalShelfLifeDays		=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
						String sTemperatureGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
						String sHumidityGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
						String sTransportFreezeProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
						String sTransportHeatProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
						String sBoundaryConditions = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
						String sStabilityDocument = (String)objectMap.get(ConstantsUtil.SELECT_NAME);
						
						StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
						StringList slEachOwnership = util.filterOwnerShip(eachOwnership);
						
						SecurityService sct = new SecurityService();
						String sUserlicense = sct.getUserLicense();
						boolean showData = false;
						
						if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
							continue;
						}
						
						if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
						{
							String sLangBuffer =ConstantsUtil.EMPTY_STRING;
							if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
								sLangBuffer=sPGLangBuffer;
							else 
								sLangBuffer=sPLangBuffer;

						if (util.isModificatinRequired()) 
						{
							//bHasOwnerShip = util.checkOwnerShip(sbCompany,slEachOwnership);
							//Added by Ganesh start
							bHasOwnerShip = util.checkHasAccess(context, null, sId);
							//Added by Ganesh stop
							//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
							//if(sCurrent!=ConstantsUtil.RELEASE) {
								if(!sCurrent.equals(ConstantsUtil.RELEASE) && !sCurrent.equals(ConstantsUtil.RELEASED)) {
								bHasOwnerShip=false;
							}
							if(bHasOwnerShip) 
							{
								/*util.formatData(sbId,sId);
								util.formatData(sbMasterProductPartName,sMasterProductPartName);
								util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
								util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
								util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
								util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
								util.formatData(sbTemperatureGroup,sTemperatureGroup);
								util.formatData(sbHumidityGroup,sHumidityGroup);
								util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
								util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
								util.formatData(sbBoundaryConditions,sBoundaryConditions);
								util.formatData(sbStabilityDocument,sStabilityDocument);
								// Guna Added for Defect 38534  18x.5.2 Release -- START
								util.formatData(sbStabilityDocumentType,sType);*/
								// Guna Added for Defect 38534  18x.5.2 Release -- END
								showData =true;
							}else{
								continue;
							}
							//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
						}else if(sct.isStaffAUGUser()) {
							/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
							}*/
							//Added by Ganesh start
							showData = util.checkHasAccess(context, null, sId);
							//Added by Ganesh stop
							if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
								showData=false;
							}
						}else {
							/*StringList slHIRTypes = new StringList();
							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
							slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

							if(slHIRTypes.contains(sType)) {
								showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
							}else {
								showData=true;
							}*/
							//Added by Ganesh start
							showData = util.checkHasAccess(context, null, sId);
							//Added by Ganesh stop
						}
						//SPEC: Release SR18x.6.0 - Commented for Defect# 42036  by Manikanta on Date 7/4/2021 -- START
						//if(sType.equalsIgnoreCase("DI Platform")) {
						//SPEC: Release SR18x.6.0 - Commented for Defect# 42036  by Manikanta on Date 7/4/2021 -- END
							if(showData) 
							{
								util.formatData(sbId,sId);
								util.formatData(sbMasterProductPartName,sMasterProductPartName);
								util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
								util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
								util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
								util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
								util.formatData(sbTemperatureGroup,sTemperatureGroup);
								util.formatData(sbHumidityGroup,sHumidityGroup);
								util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
								util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
								util.formatData(sbBoundaryConditions,sBoundaryConditions);
								util.formatData(sbStabilityDocument,sStabilityDocument);
								// Guna Added for Defect 38534  18x.5.2 Release -- START
								util.formatData(sbStabilityDocumentType,sType);
								// Guna Added for Defect 38534  18x.5.2 Release -- END
							}else
							{
								util.formatData(sbId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
								util.formatData(sbMasterProductPartName,sMasterProductPartName);
								util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
								//SPEC: 16/04/2021: Modified for 18x.6 Defect #41022 & Req #38398 by Bala-- START
								//util.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
								util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
								//util.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
								util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
								//util.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
								util.formatData(sbTemperatureGroup,sTemperatureGroup);
								//util.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
								util.formatData(sbHumidityGroup,sHumidityGroup);
								//util.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
								util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
								//util.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
								util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
								//util.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
								util.formatData(sbBoundaryConditions,sBoundaryConditions);
								//util.formatData(sbStabilityDocument,ConstantsUtil.NO_ACCESS);
								util.formatData(sbStabilityDocument,sStabilityDocument);
								//SPEC: 16/04/2021: Modified for 18x.6 Defect #41022 & Req #38398 by Bala-- END
								// Guna Added for Defect 38534  18x.5.2 Release -- START
								util.formatData(sbStabilityDocumentType,sType);
								// Guna Added for Defect 38534  18x.5.2 Release -- END
							}
							//SPEC: Release SR18x.6.0 - Commented for Defect# 42036  by Manikanta on Date 7/4/2021 -- START
						  //}
							//SPEC: Release SR18x.6.0 - Commented for Defect# 42036  by Manikanta on Date 7/4/2021 -- END
					   }
					}
					mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
					//mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTNAME, sbMasterProductPartName.toString());
					//mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTREV, sbMasterProductPartRevision.toString());
					//mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTTITLE, sbMasterProductPartTitle.toString());
					mpRefDoc.put(ConstantsUtil.PRODUCTEXPDATEREQ, sbProductExpirationDataRequired.toString());
					mpRefDoc.put(ConstantsUtil.TOTALSHELFLIFEDAYS, sbTotalShelfLifeDays.toString());
					mpRefDoc.put(ConstantsUtil.TEMPERATUREGROUP, sbTemperatureGroup.toString());
					mpRefDoc.put(ConstantsUtil.HUMIDITYGROUP, sbHumidityGroup.toString());
					mpRefDoc.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, sbTransportFreezeProtection.toString());
					mpRefDoc.put(ConstantsUtil.TRANSPORTHEATPROTECTION, sbTransportHeatProtection.toString());
					mpRefDoc.put(ConstantsUtil.BOUNDARYCONDITIONS, sbBoundaryConditions.toString());
					mpRefDoc.put(ConstantsUtil.STABILITYDOCUMENT, sbStabilityDocument.toString());
					// Guna Added for Defect 38534  18x.5.2 Release -- START
					mpRefDoc.put(ConstantsUtil.TYPE, sbStabilityDocumentType.toString());
					// Guna Added for Defect 38534  18x.5.2 Release -- END
				}catch(Exception e){

					LOGGER.error("Exception in Program : MPPBO Method :updateRefDocs "+e);
					return new HashMap();
				}
				return util.filterMapList(mpRefDoc);
				//return mpRefDoc;
			}
		 
		 
		 /**
			 * getFiles Selectables
			 * @param context
			 * @return StringList
			 */
			public static StringList getFileSelects(Context context) {
				
				StringList busSelect = new StringList();
				busSelect.add(ConstantsUtil.STR_FILE_NAME);
				busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
				busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
				busSelect.add(ConstantsUtil.STR_FILE_SIZE);
				return busSelect;

			}
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		 
		
}
