package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaCommonDocService {
	
	public HashMap<String, Map<String, String>> getDocdata(String objId, Environment env,String sType, String sComp) throws Exception;
}
