/**
 * Project 		: SpecsAnywhere
 * Program 		: PackagingAssemblyPart
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class PackagingAssemblyPart extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(PackagingAssemblyPart.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	public PackagingAssemblyPart() {
		// empty constructor
	}

	public PackagingAssemblyPart(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getPAPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getPAPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getPAPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public DomainObject getPAPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getPAPPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getPAPPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getCosSelectable(context));
		busSelect.addAll(getWeightCharSelectables(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getFileSelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	/**
	 * Method Name 			: getWeightCharSelectables
	 * Method Description 	: Fetching "Weight Characteristics" data
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYPRODUCTWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTORUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getPAPRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getPAPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}

	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		//Added by Pooja for the req 35902,41754,33476 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		//Added by Pooja for the req 35902,41754,33476 -- END
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//SPEC: 11/22/2020: Added for Defect : 37487 -- START
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		//SPEC: 11/22/2020: Added for Defect : 37487 -- END
		
		//SPEC: 11/30/2020: Added for Defect 37596 by Amman -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		//SPEC: 11/30/2020: Added for Defect 37596 by Amman -- END
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
		return busSelect;
	}

	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		//Added by Ketan for Req. no. 46464 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC);
		//Added by Ketan for Req. no. 46464 -- END
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
		
		//Added for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
		//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 26, 2021 for Defect# 41510 & 41597-- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGQUANTITY);
		//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 26, 2021 for Defect# 41510 & 41597-- END
		//Added by Pooja for the req 35902,41754,33476 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
		//Added by Pooja for the req 35902,41754,33476 -- START
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
		
		return relSelect;
	}

	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.LEGACYENVCLASSNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.STRPGPDTTOPGPLIREFUN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);

		busSelect.add(ConstantsUtil.STR_SELECT_PARTSPECIFICATION_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PARTSPECIFICATION_TYPE);
		busSelect.add(ConstantsUtil.STR_SELECT_PARTSPECIFICATION_TITLE);
		busSelect.add(ConstantsUtil.SELECT_STR_SEGMENT);
		
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMATERIALLEGACYENVCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);

		//SPEC: 10/16/2020: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
	    busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		//SPEC: 10/16/2020: Added for req 18x.5 ## -- END
	    //SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
		return busSelect;

	}

	
	/**
	 * Method Name 			: getCosSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getCosSelectable(Context context) {

		StringList relSelect = new StringList(2);
		relSelect.add(ConstantsUtil.SELECT_COS_NAME);
		relSelect.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		return relSelect;
	}

	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching "Plant" information
	 * @param context
	 * @return
	 */
	public static StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED);		
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		return busSelect;
	}


	/**
	 * Method Name 			: getMasterAttributeData
	 * Method Description 	:
	 * @param context
	 * @param sMasterID
	 * @return
	 * @throws Exception
	 */
	public Map getMasterAttributeData(Context context, String sMasterID) throws Exception {

		Map mpAttribResult = new HashMap();
		StringList busSelect = new StringList();	
		DomainObject doRMP =  getPAPDO(context, sMasterID);
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		Map resultMaps = doRMP.getInfo(context,busSelect);
		StringValidatorUtil validator = new StringValidatorUtil();
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={sMasterID,sPhysicalId};
		Map  mpLifeCycle = util.getCOName(context, changeargs);
		mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycle.get(ConstantsUtil.CO)))?(String)mpLifeCycle.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.EMPTY_STRING)))?(String)resultMaps.get(ConstantsUtil.EMPTY_STRING) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		
		//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
		String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String strBrand = util.getBrandInformationValue(context,sID);
		if(strBrand.isEmpty()) {
			strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
		}
		mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
		
		mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_VAULT)))?(String)resultMaps.get(ConstantsUtil.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ALTERNATIVEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		String sClassifictaion = util.getClassification(resultMaps);
		mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
		mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTER_DIM_LENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTER_DIM_WIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTER_DIM_HEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PROPERSHIPPINGNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.HAZARDCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKINGGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ISBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.ISBATTERYCONTAINS, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DIMENSIONUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.INNERWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.INNERLENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.INNERHEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);

		return mpAttribResult;
	}

	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList(){
		StringList slMultiSelects = new StringList();
		slMultiSelects.add(ConstantsUtil.SELECT_COS_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);

		return slMultiSelects;
	}
	
	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	:
	 */
	public  void removeMultiList(){
	
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END
	}
	
	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: updateRefDocs
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map updateRefDocs(Context context,Map resultMaps) 
	{
		StringValidatorUtil validator = new StringValidatorUtil();

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		boolean bHasOwnerShip = false;
		
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		
		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

		
		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			DomainObject dobCdoc = new DomainObject(sObjectId);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobCdoc.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			String sUser = util.getUserType();
		
			if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}
			
			if(util.isModificatinRequired()) 
			{
				mlRelatedSpecs=util.filterPhase(mlRelatedSpecs);
			}
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType=new StringBuilder();
			StringBuilder sbRev=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbDescription=new StringBuilder();
			StringBuilder sbTitle=new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sName    =   (String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sId		=	(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sDesc	=	(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sTitle	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String strClassFied = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				
				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}
				
				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					String sLangBuffer =ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;

				if (util.isModificatinRequired()) 
				{
					//modified by Ganesh for security impl-------->start
					//bHasOwnerShip = util.checkOwnerShip(sbCompany,slEachOwnership);
					bHasOwnerShip = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl-------->end
					if(sCurrent!=ConstantsUtil.RELEASE) {
						bHasOwnerShip=false;
					}
					if(bHasOwnerShip) 
					{
						util.formatData(sbType,util.mapType(sType));
						util.formatData(sbName,sName);
						util.formatData(sbDescription,sDesc);
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbId,sId);
						util.formatData(sbRev,sRev);
						util.formatData(sbTitle,sTitle);
						util.formatData(sbSource,ConstantsUtil.EMPTY_STRING);
						util.formatData(sbLangBuffer,sLangBuffer);

					}
				}else if(sct.isStaffAUGUser()) {
					//commented by Ganesh for security impl-----start
					/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}*/
					//commented by Ganesh for security impl-----end
					//modified by Ganesh for security impl-----start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl-----end
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
						showData=false;
					}
				}else {
					//commented by Ganesh for security impl----->start
					/*StringList slHIRTypes = new StringList();
					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
					slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);

					if(slHIRTypes.contains(sType)) {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}else {
						showData=true;
					}*/
					//commented by Ganesh for security impl----->end
					//modified by Ganesh for security impl----->start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl----->end
				}	

				if(showData) 
				{
					util.formatData(sbType,util.mapType(sType));
					util.formatData(sbName,sName);
					util.formatData(sbDescription,sDesc);
					util.formatData(sbCurrent,sCurrent);
					//util.formatData(sbId,sId);
					util.formatData(sbRev,sRev);
					util.formatData(sbTitle,sTitle);
					//util.formatData(sbSource,ConstantsUtil.EMPTY_STRING);
					util.formatData(sbSource,ConstantsUtil.SOURCE_DIRECT);
					util.formatData(sbLangBuffer,sLangBuffer);
					util.formatData(sbId,sId);
				}
				}else
				{
					util.formatData(sbType,util.mapType(sType));
					util.formatData(sbName,sName);
					util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
					util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
					util.formatData(sbId,ConstantsUtil.NO_ACCESS);
					util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
					util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
					util.formatData(sbSource,ConstantsUtil.NO_ACCESS);
					util.formatData(sbLangBuffer,ConstantsUtil.NO_ACCESS);
				}
				
			}

			mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
			mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpRefDoc.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
			mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLangBuffer.toString());
			mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());

		}catch(Exception e){

			LOGGER.error("Exception in Program : PackagingAssemblyPart Method :updateRefDocs "+e);
			return new HashMap();
		}
		return util.filterMapList(mpRefDoc);
		//return mpRefDoc;
	}

	
	/**
     * Method Name 			: parseSubstitute
     * Method Description 	: Fetching "Substitute" details
     * @param context
     * @param mapList
     * @return
     * @throws Exception 
     */
    public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
	{
    	StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
    	try {
			Iterator objectListItr = mapList.iterator();
			
			StringBuilder sbEBOMName = new StringBuilder();
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentRev = new StringBuilder();
			StringBuilder sbEBOMParentTitle = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			StringBuilder sbEBOMRefDoc= new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMCommnts = new StringBuilder();
			StringBuilder sbEBOMSubType= new StringBuilder();
			StringBuilder sbEBOMEffectDate= new StringBuilder();
			StringBuilder sbEBOMUntilDate= new StringBuilder();
			StringBuilder sbEBOMCobNum= new StringBuilder();
			StringBuilder sbEBOMChildRev= new StringBuilder();
			StringBuilder sbEBOMRevRelDt= new StringBuilder();
			StringBuilder sbEBOMSubFor= new StringBuilder();
			StringBuilder sbEBOMParentType = new StringBuilder();
			StringBuilder sbEBOMChg = new StringBuilder();
			StringBuilder sbEBOMSFSubType= new StringBuilder();
			
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				boolean showData = false;
				boolean bHasOwnership=false;
				
				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
				if(null!=objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
	
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
					//String
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
						String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						
						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
						String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						//Added for Defect# 37591 -- START
						//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
						String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
						//Added for Defect# 37591 -- END
						
						String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
						String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
						String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
						String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
						String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
						sOC = util.replaceSpecialSymbols(sOC);
						String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
						
						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
						
						if(util.isModificatinRequired())
						{
							//commented by Ganesh for security impl--------start
							/*SecurityService sec = new SecurityService();
							String sComp = sec.getUserCauthorities();
							StringList slUserOwnership=util.filterOwnerShip(sComp);
	
							bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sChildId);*/
							//commented by Ganesh for security impl--------end
							//modified by Ganesh for security impl--------start
							bHasOwnership = util.checkHasAccess(context, null, sChildId);
							//modified by Ganesh for security impl--------end
						
							if(!bHasOwnership)
							{
								sParentType = ConstantsUtil.NO_ACCESS;
								sParentID = ConstantsUtil.NO_ACCESS;
								sChildId    = ConstantsUtil.NO_ACCESS;
								sParentName = ConstantsUtil.NO_ACCESS;
								sParentRev = ConstantsUtil.NO_ACCESS;
								sParentTitle = ConstantsUtil.NO_ACCESS;
								sCombinationNum = ConstantsUtil.NO_ACCESS;
								sChildTitle = ConstantsUtil.NO_ACCESS;
								sSUBType = ConstantsUtil.NO_ACCESS;
								sEffectvityDate = ConstantsUtil.NO_ACCESS;
								sRevRelease = ConstantsUtil.NO_ACCESS;
								sUntilDate = ConstantsUtil.NO_ACCESS;
								sRDOC = ConstantsUtil.NO_ACCESS;
								sQTY = ConstantsUtil.NO_ACCESS;
								sBASEUOM = ConstantsUtil.NO_ACCESS;
								sChildRev = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								sSFSubType = ConstantsUtil.NO_ACCESS;
						    }//commented by Ganesh for security impl----->start
						}else /*if(sct.isStaffAUGUser()) {
							
							if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sChildId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}
						}else {
							StringList slHIRTypes = new StringList();
							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
							slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
							
							if(slHIRTypes.contains(sChildType)) {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}else {
								showData=true;
							}
							
						}*///commented by Ganesh for security impl----->end
							//modified by Ganesh for security impl----->start
						{
							showData=util.checkHasAccess(context, null, sChildId);	
						}
						//modified by Ganesh for security impl----->end
						
						if(!showData){
							sParentID = ConstantsUtil.NO_ACCESS;
							sChildId    = ConstantsUtil.NO_ACCESS;
							/*sParentType = ConstantsUtil.NO_ACCESS;
							sParentID = ConstantsUtil.NO_ACCESS;
							sChildId    = ConstantsUtil.NO_ACCESS;
							//sParentName = ConstantsUtil.NO_ACCESS;
							//sParentRev = ConstantsUtil.NO_ACCESS;
							sParentTitle = ConstantsUtil.NO_ACCESS;
							sCombinationNum = ConstantsUtil.NO_ACCESS;
							sChildTitle = ConstantsUtil.NO_ACCESS;
							sSUBType = ConstantsUtil.NO_ACCESS;
							sEffectvityDate = ConstantsUtil.NO_ACCESS;
							sRevRelease = ConstantsUtil.NO_ACCESS;
							sUntilDate = ConstantsUtil.NO_ACCESS;
							sRDOC = ConstantsUtil.NO_ACCESS;
							sComments = ConstantsUtil.NO_ACCESS;*/
						}
					
						sChildType = util.mapType(sChildType);
	
						util.formatData(sbEBOMName,sChildName);
						util.formatData(sbEBOMType,sChildType);
						util.formatData(sbEBOMQTY,sQTY);
						util.formatData(sbEBOMBuom,sBASEUOM);
						util.formatData(sbEBOMChildRev,sChildRev);
	
						util.formatData(sbEBOMParentType,sParentType);
						util.formatData(sbEBOMParentId,sParentID);
						util.formatData(sbEBOMId,sChildId);
						util.formatData(sbEBOMParentName,sParentName);
						util.formatData(sbEBOMParentRev,sParentRev);
						util.formatData(sbEBOMParentTitle,sParentTitle);
						util.formatData(sbEBOMCobNum,sCombinationNum);
						util.formatData(sbEBOMTitle,sChildTitle);
						util.formatData(sbEBOMSubType,sSUBType);
						util.formatData(sbEBOMRevRelDt,sRevRelease);
						util.formatData(sbEBOMEffectDate,sEffectvityDate);
						util.formatData(sbEBOMUntilDate,sUntilDate);
						util.formatData(sbEBOMRefDoc,sRDOC);
						util.formatData(sbEBOMCommnts,sComments);
						util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
						
						util.formatData(sbEBOMChg,sChg);
						util.formatData(sbEBOMSFSubType,sSFSubType);
					//}
					}
				}else {
					//StringList
					String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
					String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
					String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
					
					
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						for(int i =0; i<slChildId.size(); i++) {
							String sEachChildId = slChildId.getElement(i);
							DomainObject doEachChild = new DomainObject(sEachChildId);
							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							StringList slSelect = new StringList();
							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							Map mpIpClass = doEachChild.getInfo(context, slSelect);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							doEachChild.close(context);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
							StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							String sType = (String) mpIpClass.get("type");
							String sId = (String) mpIpClass.get("id");
							if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
								sIpClass=new StringList();
								sIpClass.add(sFormulaClassif);
							}
							//String sIpClass = doEachChild.getInfo(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
							DomainConstants.MULTI_VALUE_LIST.remove("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
							StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
							if(util.isModificatinRequired())
							{
								//commented by Ganesh for security impl------>start
								/*SecurityService sec = new SecurityService();
								String sComp = sec.getUserCauthorities();
								StringList slUserOwnership=util.filterOwnerShip(sComp);
	
								bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sEachChildId);*/
								//commented by Ganesh for security impl------>end
								//modified by Ganesh for security impl------>start
								bHasOwnership = util.checkHasAccess(context, null, sEachChildId);
								//modified by Ganesh for security impl------>end
								if(bHasOwnership)
								{
									showData=true;
							    }//commented by ganesh for security impl--->start
							}else /*if(sct.isStaffAUGUser()) {
								if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sEachChildId);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
								}
							}else {
								StringList slHIRTypes = new StringList();
								slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
								slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
								slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
								slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
								if(slHIRTypes.contains(slChildType.getElement(i))) {
									String sIpClassif =  validator.replaceSpecialSymbols(sIpClass.toString());
									showData=util.checkInternalUserAcess(sUserlicense,sIpClassif);
								}else {
									showData=true;
								}
							}*///commented by ganesh for security impl--->end
								//modified by ganesh for security impl--->start
							{
								showData = util.checkHasAccess(context, null, sEachChildId);
							}
								//modified by ganesh for security impl--->end
							
							if(!showData) {
								sEachChildId=ConstantsUtil.NO_ACCESS;
							}
							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							//Modified for Defect# 37591 -- START
  							//StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
  							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  							//Modified for Defect# 37591 -- END
							
							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
							StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
							StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
							String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = slRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
							
							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
							
							if(showData) {
								String sChildType = util.mapType(slChildType.get(i));
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMQTY,slQTY.get(i));
								util.formatData(sbEBOMBuom,slBASEUOM.get(i));
								util.formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMParentType,sParentType);
								util.formatData(sbEBOMParentId,sParentID);
								util.formatData(sbEBOMId,sEachChildId);
								util.formatData(sbEBOMParentName,sParentName);
								util.formatData(sbEBOMParentRev,sParentRev);
								util.formatData(sbEBOMParentTitle,sParentTitle);
								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
								util.formatData(sbEBOMTitle,slChildTitle.get(i));
								util.formatData(sbEBOMSubType,slSUBType.get(i));
								util.formatData(sbEBOMRevRelDt,sRevRelease);
								util.formatData(sbEBOMEffectDate,slEffectvityDate.get(i));
								util.formatData(sbEBOMUntilDate,slUntilDate.get(i));
								util.formatData(sbEBOMRefDoc,sRDOC);
								util.formatData(sbEBOMCommnts,slComments.get(i));
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								util.formatData(sbEBOMChg,sChg.get(i));
								util.formatData(sbEBOMSFSubType,sSFSubType);
							}else {
								String sChildType = util.mapType(slChildType.get(i));
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMQTY,slQTY.get(i));
								util.formatData(sbEBOMBuom,slBASEUOM.get(i));
								util.formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMParentType,sParentType);
								util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMParentName,sParentName);
								util.formatData(sbEBOMParentRev,sParentRev);
								util.formatData(sbEBOMParentTitle,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMCobNum,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMSubType,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMRevRelDt,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMEffectDate,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMUntilDate,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMRefDoc,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMCommnts,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMSFSubType,ConstantsUtil.NO_ACCESS);
							}
						}
					}
				}
				}

			}
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
    	}catch(Exception e) {
    		LOGGER.error("EXCEPTION IN PackagingAssemblyPart : parseSubstitute: "+e);
    	}
		return util.filterMapList(mpEBOMResult);
	}
    
    
    /**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	
	
	/**Added for 18x.5 DEV 
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context,MapList mapList) 
	{
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMTupName= new StringBuilder();
		//Added by Pooja for the req 35902,41754,33476 -- START
		StringBuilder sbGrossWeightReal = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder ();
		StringBuilder sbEBOMpgNSPCG= new StringBuilder();
		//Added by Pooja for the req 35902,41754,33476 -- end
		//SPEC: 10/12/2020: Added for 18x.5 DEV -- START
		StringBuilder sbEBOMSubPart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		//SPEC: 10/12/2020: Added for 18x.5 DEV -- END
		
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlt = new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDUOM = new StringBuilder();
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
		StringBuilder sbRR = new StringBuilder();
		StringBuilder sbRRC = new StringBuilder();
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
		
		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);

		SecurityService sct = new SecurityService();
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			String sId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ID)));
			String sName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_NAME)));
			String sRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_REVISION)));
			
			//SPEC: 11/30/2020: Modified for Defect 37596 by Amman -- START
			String sReleaseDate = validator.DateFormatter(validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE))));
			//SPEC: 11/30/2020: Modified for Defect 37596 by Amman -- END
			
			String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			String spgChg = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE)));
			String sFN = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER)));
			//Added by Pooja for the req 35902,41754,33476 -- START
			String spgNSPCG = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG)));
			String strGrossWeightReal = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
			String strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
			//Added by Pooja for the req 35902,41754,33476 -- END
			String sTitle = validator.getStringEquivalentForStringListWithComma((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
			String sType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_TYPE)));
			String sTupName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.TUPNAME)));
			String sQty = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY)));
			String sBuom = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)));
			
			//SPEC: 11/21/2020: Modified for Defect 37487 by Amman -- START
			//String sComments = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)));
			String sComments = validator.getStringEquivalentForStringListWithComma((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)));
			//SPEC: 11/21/2020: Modified for Defect 37487 by Amman -- END
			
			String sCurrent = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_CURRENT)));
			String sStage = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)));
			String sRD = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR)));
			sRD = util.replaceSpecialSymbols(sRD);
			String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
			
			//SPEC: 10/12/2020: Added for 18x.5 DEV -- START
			String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
			//SPEC: 10/12/2020: Added for 18x.5 DEV -- END
			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//String strAlt =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
			//strAlt = strAlt.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
			strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strAltID = util.checkAlternateHasAccess(context,objectMap);	
			String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
			strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		     
			String strOSPD = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY));
			
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
			String sParentId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID)));
			String sParentName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME)));
			String sParentRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV)));
			String sParentType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE)));
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
			//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
			String sRR = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
			String sRRC = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
			//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
			// SPEC: <06.06.2022>: Pooja Modified for 22x release - START
			if(strOSPD.equalsIgnoreCase(ConstantsUtil.GEN_NUM_ZERO)) 
			{
				strOSPD = ConstantsUtil.ZERO_SIZE;
			}
			// SPEC: <06.06.2022>: Pooja Modified for 22x release - END
			String strDUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM));
			LOGGER.info("object map "+ objectMap);
			boolean showData = false;
			boolean bHasOwnership=false;
			boolean showDataParent = false;
			boolean bHasOwnershipParent=false;
			String sUserlicense = sct.getUserLicense();
			String sOC = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT)));
			sOC = util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
			if(util.isModificatinRequired())
			{
				/*SecurityService sec = new SecurityService();
				String sComp = sec.getUserCauthorities();
				StringList slUserOwnership=util.filterOwnerShip(sComp);

				//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
				if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")) {
					String sFormulaPropagate = util.getFormulaPropagate(context, sId);
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}

				}else {
					bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);
					if(bHasOwnership)
						showData=true;
				}*/
				//Added by Ganesh start
				bHasOwnership = util.checkHasAccess(context, null, sId);
				//Added by Ganesh stop

				if(!bHasOwnership)
				{
					//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- START
					//sTitle = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					/*sFN    = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sReleaseDate = ConstantsUtil.NO_ACCESS;*/
					sId = ConstantsUtil.NO_ACCESS;
					sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//strAlt = ConstantsUtil.NO_ACCESS;
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					/*strOSPD = ConstantsUtil.NO_ACCESS;
					strDUOM = ConstantsUtil.NO_ACCESS;*/
					//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- END
				}
				bHasOwnershipParent=util.checkHasAccess(context, null, sParentId);
				if(!bHasOwnershipParent) {
					sParentId = ConstantsUtil.NO_ACCESS;
				}
			
			}/*else if(sct.isStaffAUGUser()) {

				if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
					String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
					showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
				}else {
					showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
				}
			} else{
				if(slHIRTypes.contains(sType)) 
				{
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
					}
				}else {
					showData=true;
				}
			}*/
			//Added by Ganesh Start
			//Modified by Jwala for the Internal Defect -- START
			else {
				showData = util.checkHasAccess(context, null, sId);
				//}
				//Added by Ganesh stop

				if(!showData){
					spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
				} 
				
				showDataParent=util.checkHasAccess(context, null, sParentId);
				if(!showDataParent) {
					sParentId = ConstantsUtil.NO_ACCESS;
				}
			}
			//Modified by Jwala for the Internal Defect -- END
			
			sType = util.mapType(sType);
			sCurrent = util.mapType(sCurrent);
			sParentType = util.mapType(sParentType);
			
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- START
			sCurrent = util.getTypeToBeDisplayedAsReleaseNotReleased(sType, sCurrent);
			//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- END

			formatData(sbEBOMType,sType);
			formatData(sbEBOMName,sName);
			formatData(sbEBOMQTY,sQty);
			formatData(sbEBOMBuom,sBuom);
			formatData(sbEBOMState,sCurrent);
			formatData(sbEBOMId,sId);
			formatData(sbEBOMChg,spgChg);
			formatData(sbEBOMFN,sFN);
			formatData(sbEBOMTitle,sTitle);
			formatData(sbEBOMCommnts,sComments);
			formatData(sbEBOMStage,sStage);
			formatData(sbEBOMRDOC,sRDOC);
			formatData(sbEBOMRevRelDt,sRevRelease);
			//SPEC: 10/12/2020: Added for 18x.5 DEV -- START
		    formatData(sbEBOMSubPart, strSubPart);
			
			formatData(sbEBOMSubPartID, strSubPartId);
			formatData(sbEBOMSubPartType, strSubPartType);
			//SPEC: 10/12/2020: Added for 18x.5 DEV -- END
			//Added by Pooja for the req 35902,41754,33476 -- START
			formatData(sbEBOMpgNSPCG,spgNSPCG);
			formatData(sbGrossWeightReal, strGrossWeightReal);
			formatData(sbGrossWeightUOM, strGrossWeightUOM);
			//Added by Pooja for the req 35902,41754,33476 -- end
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//formatData(sbEBOMAlt, strAlt);
			formatData(sbAltName,strAltName);
			formatData(sbAltID,strAltID);
			formatData(sbAltType,strAltType);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			formatData(sbEBOMOSPD, strOSPD);
			formatData(sbEBOMDUOM, strDUOM);
			
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
			formatData(sbEBOMParentId,sParentId);
			formatData(sbEBOMParentName,sParentName);
			formatData(sbEBOMParentRevision,sParentRevision);
			formatData(sbEBOMParentType,sParentType);
			//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END
			//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
			formatData(sbRR,sRR);
			formatData(sbRRC,sRRC);
			//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
			
			if(null!=sTupName && !sTupName.isEmpty()) {
				formatData(sbEBOMTupName,sTupName);
			}

		}
		
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		//SPEC: 10/12/2020: Added for 18x.5 DEV -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubPart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		//SPEC: 10/12/2020: Added for 18x.5 DEV -- END
		//Added by Pooja for the req 35902,41754,33476 -- START
	    mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbEBOMpgNSPCG.toString());
	    mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
		//Added by Pooja for the req 35902,41754,33476 -- END
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlt.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDUOM.toString());
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRR.toString());
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRRC.toString());
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
		
		if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		return mpEBOMResult;
	}
	
	
	
	/**
	 * As part of 18.5 development this method has modifications.
	 * Instead of changing the common method this has been brought from commonbusBO.
	 * Added for Defect 36617
	 * @param context
	 * @param mapList
	 * @return
	 */
 public Map<String, String> getSubstitute(Context context,MapList mapList) 
	{

		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();
		
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentRev = new StringBuilder();
		StringBuilder sbEBOMParentTitle = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMRefDoc= new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMSubType= new StringBuilder();
		StringBuilder sbEBOMEffectDate= new StringBuilder();
		StringBuilder sbEBOMUntilDate= new StringBuilder();
		StringBuilder sbEBOMCobNum= new StringBuilder();
		StringBuilder sbEBOMChildRev= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMSubFor= new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		
		//SPEC: 11/06/2020: Added for defect 37234 -- START
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMSFSubType= new StringBuilder();
		//SPEC: 11/06/2020: Added for defect 37234 -- END
		
		SecurityService sct = new SecurityService();
		
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();

			String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
			if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
				
				String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				StringTokenizer token = new StringTokenizer(sChildName,ConstantsUtil.SYMBL_PIPE);
				/*while(token.hasMoreTokens()) {
				sChildName=token.nextToken().toString().trim();*/
				String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				sParentType=util.MapsType(sParentType);
				String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
				String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
				String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
				
				//SPEC: 11/06/2020: Added for defect 37234 -- START
				String sParentSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
				String sChildCHG =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
				//SPEC: 11/06/2020: Added for defect 37234 -- END
				
				String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
				String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
				String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
				String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				sChildType=util.MapsType(sChildType);
				//Modified for Defect# 37591 -- START
				//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
				String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
				//Modified for Defect# 37591 -- END
				String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
				String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
				String sEffectvityDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY)));
				String sUntilDate=validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
				String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
				String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
				String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sOC = util.replaceSpecialSymbols(sOC);
				//String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
				String sRDOC = sRefDoc;
				String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
				boolean showData = false;
				boolean bHasOwnership=false;
				String sUserlicense = sct.getUserLicense();
				
				boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
				
				if(util.isModificatinRequired())
				{
					//commented by Ganesh for security impl----->start
					/*SecurityService sec = new SecurityService();
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);
					String sFormulaPropagate = sParentID;
					if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
					}
					
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}*/
					//commented by Ganesh for security impl----->end
					//commented by Ganesh for security impl----->start
					bHasOwnership  = util.checkHasAccess(context, null, sParentID);
					//commented by Ganesh for security impl----->end
					if(!bHasOwnership)
					{
						sParentType = ConstantsUtil.NO_ACCESS;
						sParentID = ConstantsUtil.NO_ACCESS;
						sParentName = ConstantsUtil.NO_ACCESS;
						sParentRev = ConstantsUtil.NO_ACCESS;
						sParentTitle = ConstantsUtil.NO_ACCESS;
						sCombinationNum = ConstantsUtil.NO_ACCESS;
						sSUBType = ConstantsUtil.NO_ACCESS;
						sEffectvityDate = ConstantsUtil.NO_ACCESS;
						sRevRelease = ConstantsUtil.NO_ACCESS;
						sUntilDate = ConstantsUtil.NO_ACCESS;
						sRDOC = ConstantsUtil.NO_ACCESS;
						sQTY = ConstantsUtil.NO_ACCESS;
						sBASEUOM = ConstantsUtil.NO_ACCESS;
						//SPEC: 11/06/2020: Added for defect 37234 -- START
						sParentSubType = ConstantsUtil.NO_ACCESS;
						//SPEC: 11/06/2020: Added for defect 37234 -- END
				    }//commented by Ganesh for security ----->start
				}else /*if(sct.isStaffAUGUser()) {
					
					if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
					}
				}else {
					StringList slHIRTypes = new StringList();
					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
					slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
					
					if(slHIRTypes.contains(sParentType)) {
						if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else {
							showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
						}
					}else {
						showData=true;
					}
					
				}*///commented by Ganesh for security ----->end
					//modified by Ganesh for security ----->start
				{
					showData = util.checkHasAccess(context, null, sParentID);
				}
					//modified by Ganesh for security ----->end
			
				if(!showData){
					sParentType = ConstantsUtil.NO_ACCESS;
					sParentID = ConstantsUtil.NO_ACCESS;
					sParentName = ConstantsUtil.NO_ACCESS;
					sParentRev = ConstantsUtil.NO_ACCESS;
					sParentTitle = ConstantsUtil.NO_ACCESS;
					sCombinationNum = ConstantsUtil.NO_ACCESS;
					sSUBType = ConstantsUtil.NO_ACCESS;
					sEffectvityDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sUntilDate = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
					//SPEC: 11/06/2020: Added for defect 37234 -- START
					sParentSubType = ConstantsUtil.NO_ACCESS;
					//SPEC: 11/06/2020: Added for defect 37234 -- END
				}
				//Child Ownership access logic	
				String sChildIpClass =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_IPCLASS));
				if(util.isModificatinRequired())
				{
					//commented by Ganesh for security impl------->start
					/*SecurityService sec = new SecurityService();
					
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);
					String sFormulaPropagate = sParentID;
					if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sChildId);
					}
					
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}*/
					//commented by Ganesh for security impl------->end
					//commented by Ganesh for security impl------->start
					bHasOwnership = util.checkHasAccess(context, null, sParentID);
					//commented by Ganesh for security impl------->end

					
				
					if(!bHasOwnership)
					{
						sChildId    = ConstantsUtil.NO_ACCESS;
						sChildTitle = ConstantsUtil.NO_ACCESS;
						sChildRev = ConstantsUtil.NO_ACCESS;
				    }//commented by Ganesh for security impl---->start
				}else /*if(sct.isStaffAUGUser()) {
					
					if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sChildId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
					}
				}else {
					StringList slHIRTypes = new StringList();
					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
					slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
					
					if(slHIRTypes.contains(sParentType)) {
						if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							String sFormulaClassif = util.getFormulaPropagateClassification(context, sChildId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else {
							showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
						}
					}else {
						showData=true;
					}
					
				}*///commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl---->start
				{
					showData = util.checkHasAccess(context, null, sParentID);
				}
					//modified by Ganesh for security impl---->end
				
				if(!showData){
					sChildId    = ConstantsUtil.NO_ACCESS;
					sChildTitle = ConstantsUtil.NO_ACCESS;
					sChildRev = ConstantsUtil.NO_ACCESS;
				}
				
				
				sChildType = util.mapType(sChildType);
				formatData(sbEBOMName,sChildName);
				formatData(sbEBOMType,sChildType);
				formatData(sbEBOMQTY,sQTY);
				formatData(sbEBOMBuom,sBASEUOM);
				formatData(sbEBOMChildRev,sChildRev);

				formatData(sbEBOMParentType,sParentType);
				formatData(sbEBOMParentId,sParentID);
				formatData(sbEBOMId,sChildId);
				formatData(sbEBOMParentName,sParentName);
				formatData(sbEBOMParentRev,sParentRev);
				formatData(sbEBOMParentTitle,sParentTitle);
				formatData(sbEBOMCobNum,sCombinationNum);
				formatData(sbEBOMTitle,sChildTitle);
				formatData(sbEBOMSubType,sSUBType);
				formatData(sbEBOMRevRelDt,sRevRelease);
				formatData(sbEBOMEffectDate,sEffectvityDate);
				formatData(sbEBOMUntilDate,sUntilDate);
				formatData(sbEBOMRefDoc,sRDOC);
				formatData(sbEBOMCommnts,sComments);
				formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
				
				//SPEC: 11/06/2020: Added for defect 37234 -- START
				formatData(sbEBOMChg,sChildCHG);
				formatData(sbEBOMSFSubType,sParentSubType);
				//SPEC: 11/06/2020: Added for defect 37234 -- END
			}
		}
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
		mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
		mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
		//mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
		mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
		mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
		
		//SPEC: 11/06/2020: Added for defect 37234 -- START
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
		//SPEC: 11/06/2020: Added for defect 37234 -- END

		return util.filterMapList(mpEBOMResult);
	}
    
	/**
	 * Formatting the data
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	
	public boolean checkSubstituteHasAccess(Context context, Map objectMap) {
		
		StringBuilder  sbReturnVal = new StringBuilder();
		boolean showData = false;
		try
		{
			StringValidatorUtil validator = new StringValidatorUtil();
			
			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
			slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership=util.filterOwnerShip(sComp);
			
			if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))
			{
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
				{
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
					String strSubPartId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
					
					DomainObject doEachChild = new DomainObject(strSubPartId);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					StringList slSelect = new StringList();
					slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					Map mpIpClass = doEachChild.getInfo(context, slSelect);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doEachChild.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					//commented by Ganesh for security impl------>start
					/*if(util.isModificatinRequired())
					{
						//For EBP User
						showData = util.checkOwnerShip(context, slUserOwnership, strSubPartId);
						
					}else if(sct.isStaffAUGUser())
					{
						//For Staff Aug USer check 
						if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							//Validation for Hir checks on Formulation
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else
						{
							//Validation for Hir checks for other than Formulation
							showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
						}
					}else 
					{
						//For Internal User check
						if(slHIRTypes.contains(strSubPartType)) 
						{
							//Validation for Hir checks on Formulation
							if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else 
							{
								//Validation for Hir checks for other than Formulation
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
						}else 
						{
							//If it is Non-Hir we can show without checks for internal user
							showData=true;
						}
					}*///commented by Ganesh for security impl------>end
					//modified by Ganesh for security impl------>start
					showData = util.checkHasAccess(context, null, strSubPartId);
					//modified by Ganesh for security impl------>end
					
//						
				}//close for string
				}else
			{	//If no Substitue found
				return showData;
			}
			
		}catch(Exception e){
			
			LOGGER.error("Error from PackagingAssemblyPart :  checkSubstituteHasAccess" + e);
			return showData;
		}
		return showData;
	}
	
	
	//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  	public Map<String, String> parseBOMSubstitute(Context context,MapList mapList) throws Exception 
  	{
  		CommonBusUtilBO commonBO = new CommonBusUtilBO();
      	StringValidatorUtil validator = new StringValidatorUtil();
  		Map<String,String> mpEBOMResult = new HashMap<String,String>();
      	try {
  			Iterator objectListItr = mapList.iterator();
  			StringBuilder sbEBOMName = new StringBuilder();
  			StringBuilder sbEBOMParentName = new StringBuilder();
  			StringBuilder sbEBOMParentRev = new StringBuilder();
  			StringBuilder sbEBOMParentTitle = new StringBuilder();
  			StringBuilder sbEBOMId = new StringBuilder();
  			StringBuilder sbEBOMParentId = new StringBuilder();
  			StringBuilder sbEBOMRefDoc= new StringBuilder();
  			StringBuilder sbEBOMTitle = new StringBuilder();
  			StringBuilder sbEBOMType = new StringBuilder();
  			StringBuilder sbEBOMQTY = new StringBuilder();
  			StringBuilder sbEBOMBuom = new StringBuilder();
  			StringBuilder sbEBOMCommnts = new StringBuilder();
  			StringBuilder sbEBOMSubType= new StringBuilder();
  			StringBuilder sbEBOMEffectDate= new StringBuilder();
  			StringBuilder sbEBOMUntilDate= new StringBuilder();
  			StringBuilder sbEBOMCobNum= new StringBuilder();
  			StringBuilder sbEBOMChildRev= new StringBuilder();
  			StringBuilder sbEBOMRevRelDt= new StringBuilder();
  			StringBuilder sbEBOMSubFor= new StringBuilder();
  			StringBuilder sbEBOMParentType = new StringBuilder();
  			StringBuilder sbEBOMChg = new StringBuilder();
  			StringBuilder sbEBOMSFSubType= new StringBuilder();
  			
  			
  			SecurityService sct = new SecurityService();
  			String sUserlicense = sct.getUserLicense();
  			while(objectListItr.hasNext())
  			{
  				Map objectMap = (Map) objectListItr.next();
  				boolean showData = false;
  				boolean bHasOwnership=false;
  	
  				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
  				if (!objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
  					continue;
  				}
					
				
  				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
  				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
  				{
  					//String
  					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
  						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
  						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
  						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
  						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
  						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
  						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
  						String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
  						String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE));
  						
  						//Modified for Defect #37282 -- START
  						//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
  						boolean bChildHasAccess = commonBO.checkSubstituteHasAccess(context,objectMap,null,null);
  						//Modified for Defect #37282 -- END
  						
  						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- START
  						sReleaseDate =validator.DateFormatter(sReleaseDate);
  						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- END
  						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
  						
  						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
  						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
  						String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  						String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
  						
						//Modified for Defect# 37591 -- START
						String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
						//Modified for Defect# 37591 -- END
  						String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  						String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
  						String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  						String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
  						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  						
  						//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- START
  						//String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  						String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  						//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- END
  						
	  					//SPEC: 11/09/2020: Modified for Defect : 37019 -- START
	  						String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT));
	  						/*String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
	  						sOC = util.replaceSpecialSymbols(sOC);*/
	  					//SPEC: 11/09/2020: Modified for Defect : 37019 -- END
  						
  						String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
  						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
  						
  						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
  						String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
  						
  						if(!bChildHasAccess) {
  							sChildId    = ConstantsUtil.NO_ACCESS;
  							sChildTitle = ConstantsUtil.NO_ACCESS;
  							//sChildRev = ConstantsUtil.NO_ACCESS;
  						}
  						
  						if(util.isModificatinRequired())
  						{
  							//commented by Ganesh for security impl------>start
  							/*SecurityService sec = new SecurityService();
  							String sComp = sec.getUserCauthorities();
  							StringList slUserOwnership=util.filterOwnerShip(sComp);
  							
  							String sFormulaPropagate = sParentID;
  							if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  								sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
  							}
  							
  							if(!sFormulaPropagate.isEmpty()) {
  								bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
  							}*/
  						//commented by Ganesh for security impl------>end
  						//modified by Ganesh for security impl------>start
  							bHasOwnership = util.checkHasAccess(context, null, sParentID);
  						//modified by Ganesh for security impl------>end
  							if(!bHasOwnership)
  							{
  								sParentType = ConstantsUtil.NO_ACCESS;
  								sParentID = ConstantsUtil.NO_ACCESS;
  								//sChildId    = ConstantsUtil.NO_ACCESS;
  								sParentName = ConstantsUtil.NO_ACCESS;
  								sParentRev = ConstantsUtil.NO_ACCESS;
  								sParentTitle = ConstantsUtil.NO_ACCESS;
  								sCombinationNum = ConstantsUtil.NO_ACCESS;
  								//sChildTitle = ConstantsUtil.NO_ACCESS;
  								sSUBType = ConstantsUtil.NO_ACCESS;
  								sEffectvityDate = ConstantsUtil.NO_ACCESS;
  								sRevRelease = ConstantsUtil.NO_ACCESS;
  								sUntilDate = ConstantsUtil.NO_ACCESS;
  								sRDOC = ConstantsUtil.NO_ACCESS;
  								sQTY = ConstantsUtil.NO_ACCESS;
  								sBASEUOM = ConstantsUtil.NO_ACCESS;
  								//sChildRev = ConstantsUtil.NO_ACCESS;
  								sChg = ConstantsUtil.NO_ACCESS;
  								sSFSubType = ConstantsUtil.NO_ACCESS;
  								
  						    }//commented by Ganesh for security impl------>start
  						}else /*if(sct.isStaffAUGUser()) {
  							
  							if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  								String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
  								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
  							}else {
  								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
  							}
  						}else {
  							StringList slHIRTypes = new StringList();
  							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
  							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
  							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
  							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
  							slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
  							slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
  							
  							if(slHIRTypes.contains(sParentType)) {
  								if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
  									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
  								}else {
  									showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
  								}
  							}else {
  								showData=true;
  							}
  						}*///commented by Ganesh for security impl------>start
  						//modified by Ganesh for security impl------>start
  						{
  							showData = util.checkHasAccess(context, null, sParentID);
  						}//modified by Ganesh for security impl------>end
  						
  						if(!showData){
  							sParentID = ConstantsUtil.NO_ACCESS;
  							//sParentTitle = ConstantsUtil.NO_ACCESS;
  							sBASEUOM = ConstantsUtil.NO_ACCESS;
  							
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
  							//sChildId    = ConstantsUtil.NO_ACCESS;
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
  							
  							/*sParentType = ConstantsUtil.NO_ACCESS;
  							sParentID = ConstantsUtil.NO_ACCESS;
  							sChildId    = ConstantsUtil.NO_ACCESS;
  							//sParentName = ConstantsUtil.NO_ACCESS;
  							//sParentRev = ConstantsUtil.NO_ACCESS;
  							sParentTitle = ConstantsUtil.NO_ACCESS;
  							sCombinationNum = ConstantsUtil.NO_ACCESS;
  							sChildTitle = ConstantsUtil.NO_ACCESS;
  							sSUBType = ConstantsUtil.NO_ACCESS;
  							sEffectvityDate = ConstantsUtil.NO_ACCESS;
  							sRevRelease = ConstantsUtil.NO_ACCESS;
  							sUntilDate = ConstantsUtil.NO_ACCESS;
  							sRDOC = ConstantsUtil.NO_ACCESS;
  							sComments = ConstantsUtil.NO_ACCESS;*/
  						}
  					
  						sChildType = util.mapType(sChildType.trim());
  						sParentType = util.mapType(sParentType.trim());
  	
  						util.formatData(sbEBOMName,sChildName);
  						util.formatData(sbEBOMType,sChildType);
  						util.formatData(sbEBOMQTY,sQTY);
  						util.formatData(sbEBOMBuom,sBASEUOM);
  						util.formatData(sbEBOMChildRev,sChildRev);
  						
  						util.formatData(sbEBOMParentType,sParentType);
  						util.formatData(sbEBOMParentId,sParentID);
  						util.formatData(sbEBOMId,sChildId);
  						util.formatData(sbEBOMParentName,sParentName);
  						util.formatData(sbEBOMParentRev,sParentRev);
  						util.formatData(sbEBOMParentTitle,sParentTitle);
  						util.formatData(sbEBOMCobNum,sCombinationNum);
  						util.formatData(sbEBOMTitle,sChildTitle);
  						util.formatData(sbEBOMSubType,sSUBType);
  						util.formatData(sbEBOMRevRelDt,sRevRelease);
  						util.formatData(sbEBOMEffectDate,validator.DateFormatter(sEffectvityDate));
  						util.formatData(sbEBOMUntilDate,validator.DateFormatter(sUntilDate));
  						util.formatData(sbEBOMRefDoc,sRDOC);
  						util.formatData(sbEBOMCommnts,sComments);
  						util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  						
  						//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  						util.formatData(sbEBOMChg,sChg);
  						util.formatData(sbEBOMSFSubType,sSFSubType);
  						//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
  					//}
  					}
  				}else {
  					//StringList
  					String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
  					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
  					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
  					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
  					String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
  					
  					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
  						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
  						for(int i =0; i<slChildId.size(); i++) {
  							String sEachChildId = slChildId.getElement(i);
  							
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
//  							DomainObject doEachChild = new DomainObject(sEachChildId);
//  							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//  							StringList slSelect = new StringList();
//  							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//  							Map mpIpClass = doEachChild.getInfo(context, slSelect);
//  							StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//  							StringsIpClass = doEachChild.getInfo(contexts"to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
//  							DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
  							
  							StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
  							String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
  							
  							//Added for Defect #37282 -- START
  							String strEachChildType = slChildType.getElement(i);
  							//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
  							boolean bChildHasAccess = commonBO.checkSubstituteHasAccess(context,objectMap,strEachChildType,sEachChildId);
  							//Added for Defect #37282 -- START

  							if(util.isModificatinRequired())
  							{
  								//commented by Ganesh for security impl------->start
  								/*SecurityService sec = new SecurityService();
  								String sComp = sec.getUserCauthorities();
  								StringList slUserOwnership=util.filterOwnerShip(sComp);
  								
  								String sFormulaPropagate = sParentID;
  								if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  									sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
  								}
  								
  								if(!sFormulaPropagate.isEmpty()) {
  									bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
  								}*/
  							//commented by Ganesh for security impl------->end
  							//modified by Ganesh for security impl------->start
  								bHasOwnership = util.checkHasAccess(context, null, sParentID);
  							//modified by Ganesh for security impl------->start
  								
  								if(bHasOwnership)
  								{
  									showData=true;
  							    }//commented by Ganesh for security impl---->start
  							}else /*if(sct.isStaffAUGUser()) {
  								//Modified for Defect #37269 -- START
  								//if(slChildType.get(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  								if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  								//Modified for Defect #37269 -- END
  									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
  									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
  								}else {
  									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
  								}
  							}else {
  								StringList slHIRTypes = new StringList();
  								slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
  								slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
  								slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
  								slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
  								slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
  								slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
  								
  							//Modified for Defect #37269 -- START
  								//if(slHIRTypes.contains(slChildType.getElement(i))) {
  									//if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
  								if(slHIRTypes.contains(sParentType)) {
  									if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {		
  							//Modified for Defect #37269 -- START
  										String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
  										showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
  									}else {
  										showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
  									}
  								}else {
  									showData=true;
  								}
  							}*///commented by Ganesh for security impl---->end
  							//modified by Ganesh for security impl---->start
  							{
  								showData = util.checkHasAccess(context, null, sParentID);
  							}//modified by Ganesh for security impl---->end
  							
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
  							/*if(!showData) {
  								sEachChildId=ConstantsUtil.NO_ACCESS;
  							}*/
  							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
  							
  							
  							StringList slReleaseDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE));
  							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
  							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
  							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
  							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  							//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
  							//Modified for Defect# 37591 -- START
  							//StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
  							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  							//Modified for Defect# 37591 -- END
  							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  							StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
  							StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
  							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  							
  							//SPEC: 11/09/2020: Modified for Defect : 37019 -- START
  							//String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  							StringList slOCs =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT));
  							StringList slRefDoc =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  							//SPEC: 11/09/2020: Modified for Defect : 37019 -- END
  							/*String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
  							sOC = util.replaceSpecialSymbols(sOC);*/
  							
  							String sRDOC = slRefDoc.get(i)+ConstantsUtil.SYMBL_COLON+slOCs.get(i);
  							
  							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
  							//SPEC: 11/07/2020: Modified for Defect : 37019 -- START
  							String sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
  							//SPEC: 11/07/2020: Modified for Defect : 37019-- END
  							
  							String sReleaseDate =validator.DateFormatter(slReleaseDate.get(i));
  		  					String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
  		  					
  							//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  							if(bChildHasAccess) {
  								String sChildType = util.mapType(slChildType.get(i));
  								util.formatData(sbEBOMName,slChildName.get(i));
  								util.formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMId,sEachChildId);
  								util.formatData(sbEBOMTitle,slChildTitle.get(i));
  								util.formatData(sbEBOMBuom,slBASEUOM.get(i));
  							}
  							else
  							{
  								String sChildType = util.mapType(slChildType.get(i));
  								util.formatData(sbEBOMName,slChildName.get(i));
  								util.formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMBuom,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
  								//util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
  							}
  							
  							//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
  							
  							if(showData) {
  								//String sChildType = util.mapType(slChildType.get(i));
  								//formatData(sbEBOMName,slChildName.get(i));
  								//formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMQTY,slQTY.get(i));
  								//util.formatData(sbEBOMBuom,slBASEUOM.get(i));
  								//formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMParentType,util.mapType(sParentType));
  								util.formatData(sbEBOMParentId,sParentID);
  								//formatData(sbEBOMId,sEachChildId);
  								util.formatData(sbEBOMParentName,sParentName);
  								util.formatData(sbEBOMParentRev,sParentRev);
  								util.formatData(sbEBOMParentTitle,sParentTitle);
  								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
  								//formatData(sbEBOMTitle,slChildTitle.get(i));
  							
  								//SPEC: 11/30/2020: Added for Defect 37596 by Amman -- START
  								if(slSUBType!=null) {
  									util.formatData(sbEBOMSubType,slSUBType.get(i));
  								}else {
  									util.formatData(sbEBOMSubType,ConstantsUtil.EMPTY_STRING);
  								}
  								//SPEC: 11/30/2020: Added for Defect 37596 by Amman -- END
  								
  								util.formatData(sbEBOMRevRelDt,sRevRelease);
  								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
  								util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
  								util.formatData(sbEBOMRefDoc,sRDOC);
  								util.formatData(sbEBOMCommnts,slComments.get(i));
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								util.formatData(sbEBOMChg,sChg.get(i));
  							//SPEC: 11/07/2020: Modified for Defect : 37019 -- START
  								util.formatData(sbEBOMSFSubType,sSFSubType);
  							//SPEC: 11/07/2020: Modified for Defect : 37019 -- END
  								
  							}else {
  								//String sChildType = util.mapType(slChildType.get(i));
  								//formatData(sbEBOMName,slChildName.get(i));
  								//formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMQTY,slQTY.get(i));
  								//util.formatData(sbEBOMBuom,ConstantsUtil.NO_ACCESS);
  								//formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMParentType,util.mapType(sParentType));
  								util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
  								//util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMParentName,sParentName);
  								util.formatData(sbEBOMParentRev,sParentRev);
  								util.formatData(sbEBOMParentTitle,sParentTitle);
  								//util.formatData(sbEBOMCobNum,ConstantsUtil.NO_ACCESS);
  								//formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
  								//util.formatData(sbEBOMSubType,ConstantsUtil.NO_ACCESS);
  								//util.formatData(sbEBOMRevRelDt,ConstantsUtil.NO_ACCESS);
  								/*util.formatData(sbEBOMEffectDate,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMUntilDate,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMRefDoc,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMCommnts,ConstantsUtil.NO_ACCESS);*/
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								/*util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMSFSubType,ConstantsUtil.NO_ACCESS);*/
  								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
  								
  								//SPEC: 11/30/2020: Added for Defect 37596 by Amman -- START
  								if(slSUBType!=null) {
  									util.formatData(sbEBOMSubType,slSUBType.get(i));
  								}else {
  									util.formatData(sbEBOMSubType,ConstantsUtil.EMPTY_STRING);
  								}
  								//SPEC: 11/30/2020: Added for Defect 37596 by Amman -- END
  								
  								util.formatData(sbEBOMRevRelDt,sRevRelease);
  								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
  								util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
  								util.formatData(sbEBOMRefDoc,sRDOC);
  								util.formatData(sbEBOMCommnts,slComments.get(i));
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								util.formatData(sbEBOMChg,sChg.get(i));
  								util.formatData(sbEBOMSFSubType,sSFSubType);
  								
  							}
  						}
  					}
  				}

  			}
  			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
  			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
  			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
  			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
  			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
  			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
  			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
  			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
  			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
  			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
  			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
  			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
  			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
  			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
  			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
  			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
  			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
  			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
  			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
  			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
  			
      	}catch(Exception e) {
      		
      		e.printStackTrace();
      		LOGGER.error("EXCEPTION IN PackagingAssemblyPart : parseSubstitute: "+e);
      	}
  		return util.filterMapList(mpEBOMResult);
  	
  	}
}
