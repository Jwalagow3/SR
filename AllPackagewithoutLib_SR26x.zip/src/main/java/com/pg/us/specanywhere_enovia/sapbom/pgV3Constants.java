package com.pg.us.specanywhere_enovia.sapbom;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.PropertyUtil;

public interface pgV3Constants extends DomainConstants {
	String TYPE_PART = PropertyUtil.getSchemaProperty("type_Part");
	String TYPE_PGPRODUCT = PropertyUtil.getSchemaProperty("type_pgProduct");
	String TYPE_PGMATERIAL = PropertyUtil.getSchemaProperty("type_pgMaterial");
	String TYPE_PGRAWMATERIAL = PropertyUtil.getSchemaProperty("type_pgRawMaterial");
	String TYPE_PGPACKINGMATERIAL = PropertyUtil.getSchemaProperty("type_pgPackingMaterial");
	String TYPE_PGFINISHEDPRODUCT = PropertyUtil.getSchemaProperty("type_pgFinishedProduct");
	String TYPE_PGFORMULATEDPRODUCT = PropertyUtil.getSchemaProperty("type_pgFormulatedProduct");
	String TYPE_PGPHASE = PropertyUtil.getSchemaProperty("type_pgPhase");
	String TYPE_TECHNICALSPECIFICATION = PropertyUtil.getSchemaProperty("type_TechnicalSpecification");
	String TYPE_PGBASEFORMULA = PropertyUtil.getSchemaProperty("type_pgBaseFormula");
	String TYPE_PGNONGCASPART = PropertyUtil.getSchemaProperty("type_pgNonGCASPart");
	String TYPE_PGMASTERRAWMATERIAL = PropertyUtil.getSchemaProperty("type_pgMasterRawMaterial");
	String TYPE_PGMASTERFINISHEDPRODUCT = PropertyUtil.getSchemaProperty("type_pgMasterFinishedProduct");
	String TYPE_PGMASTERPACKINGMATERIAL = PropertyUtil.getSchemaProperty("type_pgMasterPackingMaterial");
	String TYPE_CHARACTERISTIC = PropertyUtil.getSchemaProperty("type_Characteristic");
	String TYPE_PGARTWORK = PropertyUtil.getSchemaProperty("type_pgArtwork");
	String TYPE_LOCATION = PropertyUtil.getSchemaProperty("type_Location");
	String TYPE_ORGANIZATION = PropertyUtil.getSchemaProperty("type_Organization");
	String TYPE_PGTESTMETHOD = PropertyUtil.getSchemaProperty("type_pgTestMethod");
	String TYPE_SHAREDTABLE = PropertyUtil.getSchemaProperty("type_SharedTable");
	String TYPE_PGSTACKINGPATTERN = PropertyUtil.getSchemaProperty("type_pgStackingPattern");
	String TYPE_PGAPPROVEDSUPPLIERLIST = PropertyUtil.getSchemaProperty("type_pgApprovedSupplierList");
	String TYPE_PGMAKINGINSTRUCTIONS = PropertyUtil.getSchemaProperty("type_pgMakingInstructions");
	String TYPE_PGQUALITYSPECIFICATION = PropertyUtil.getSchemaProperty("type_pgQualitySpecification");
	String TYPE_PGSUPPLIERINFORMATIONSHEET = PropertyUtil.getSchemaProperty("type_pgSupplierInformationSheet");
	String TYPE_PGPROCESSSTANDARD = PropertyUtil.getSchemaProperty("type_pgProcessStandard");
	String TYPE_PGILLUSTRATION = PropertyUtil.getSchemaProperty("type_pgIllustration");
	String TYPE_PGSTANDARDOPERATINGPROCEDURE = PropertyUtil.getSchemaProperty("type_pgStandardOperatingProcedure");
	String TYPE_PGPACKINGINSTRUCTIONS = PropertyUtil.getSchemaProperty("type_pgPackingInstructions");
	String TYPE_PGEBPSUMMARY = PropertyUtil.getSchemaProperty("type_pgIPMEBPSummary");
	String TYPE_PGSUPPLIER = PropertyUtil.getSchemaProperty("type_pgSupplier");
	String TYPE_PLANT = PropertyUtil.getSchemaProperty("type_Plant");
	String TYPE_PGIPMPGCONTACT = PropertyUtil.getSchemaProperty("type_pgIPMPGContact");
	String TYPE_PERSON = PropertyUtil.getSchemaProperty("type_Person");
	String TYPE_PGAUTOCOATEMPLATE = PropertyUtil.getSchemaProperty("type_pgIPMAutoCOATemplate");
	String TYPE_PGPERFORMANCECHARACTERISTIC = PropertyUtil.getSchemaProperty("type_pgPerformanceCharacteristic");
	String TYPE_PGCONFIGURATIONADMIN = PropertyUtil.getSchemaProperty("type_pgConfigurationAdmin");
	String TYPE_PGMANUFACTURERMATERIAL = PropertyUtil.getSchemaProperty("type_pgManufacturerMaterial");
	String TYPE_PGIPMUNIVERSALDOCUMENT = PropertyUtil.getSchemaProperty("type_pgIPMUniversalDocument");
	String TYPE_PRODUCTDATA = PropertyUtil.getSchemaProperty("type_ProductData");
	String TYPE_PGSECURITYGROUP = PropertyUtil.getSchemaProperty("type_pgSecurityGroup");
	String TYPE_REGION = PropertyUtil.getSchemaProperty("type_Region");
	String TYPE_PGPLICSSREGION = PropertyUtil.getSchemaProperty("type_pgPLICSSRegion");
	String TYPE_PGBRAND = PropertyUtil.getSchemaProperty("type_pgBrand");
	String TYPE_BUSINESSUNIT = PropertyUtil.getSchemaProperty("type_BusinessUnit");
	String TYPE_PGAREA = PropertyUtil.getSchemaProperty("type_pgArea");
	String TYPE_PGPLISECTOR = PropertyUtil.getSchemaProperty("type_pgPLISector");
	String TYPE_PGPLISUBSECTOR = PropertyUtil.getSchemaProperty("type_pgPLISubSector");
	String TYPE_FINISHEDPRODUCTPART = PropertyUtil.getSchemaProperty("type_FinishedProductPart");
	String TYPE_PGCONSUMERUNITPART = PropertyUtil.getSchemaProperty("type_pgConsumerUnitPart");
	String TYPE_PGCUSTOMERUNITPART = PropertyUtil.getSchemaProperty("type_pgCustomerUnitPart");
	String TYPE_PGINNERPACKUNITPART = PropertyUtil.getSchemaProperty("type_pgInnerPackUnitPart");
	String TYPE_PGTRANSPORTUNITPART = PropertyUtil.getSchemaProperty("type_pgTransportUnitPart");
	String TYPE_PGMASTERCONSUMERUNITPART = PropertyUtil.getSchemaProperty("type_pgMasterConsumerUnitPart");
	String TYPE_PGMASTERCUSTOMERUNITPART = PropertyUtil.getSchemaProperty("type_pgMasterCustomerUnitPart");
	String TYPE_PGMASTERINNERPACKUNITPART = PropertyUtil.getSchemaProperty("type_pgMasterInnerPackUnitPart");
	String TYPE_PGANCILLARYPACKAGINGMATERIALPART = PropertyUtil
			.getSchemaProperty("type_pgAncillaryPackagingMaterialPart");
	String TYPE_PGPROMOTIONALITEMPART = PropertyUtil.getSchemaProperty("type_pgPromotionalItemPart");
	String TYPE_FORMULATIONPART = PropertyUtil.getSchemaProperty("type_FormulationPart");
	String TYPE_PACKAGINGMATERIALPART = PropertyUtil.getSchemaProperty("type_PackagingMaterialPart");
	String TYPE_RAWMATERIALPART = PropertyUtil.getSchemaProperty("type_RawMaterial");
	String TYPE_PGMASTERPACKAGINGMATERIALPART = PropertyUtil.getSchemaProperty("type_pgMasterPackagingMaterialPart");
	String TYPE_PACKAGINGASSEMBLYPART = PropertyUtil.getSchemaProperty("type_PackagingAssemblyPart");
	String TYPE_PGMASTERPACKAGINGASSEMBLYPART = PropertyUtil.getSchemaProperty("type_pgMasterPackagingAssemblyPart");
	String TYPE_PGAUTHORIZEDTEMPORARYSTANDARD = PropertyUtil
			.getSchemaProperty("type_pgAuthorizedTemporarySpecification");
	String TYPE_PGPPMCONSTITUENT = PropertyUtil.getSchemaProperty("type_pgPPMConstituent");
	String TYPE_PGIPMDOCUMENT = PropertyUtil.getSchemaProperty("type_pgIPMDocument");
	String TYPE_PARTFAMILY = PropertyUtil.getSchemaProperty("type_PartFamily");
	String TYPE_PGONLINEPRINTINGPART = PropertyUtil.getSchemaProperty("type_pgOnlinePrintingPart");
	String TYPE_PGPLICSSCOUNTRY = PropertyUtil.getSchemaProperty("type_pgPLICSSCountry");
	String TYPE_PGPLICHARACTERISTIC = PropertyUtil.getSchemaProperty("type_pgPLICharacteristic");
	String TYPE_PGPLICHARACTERISTICSPECIFICS = PropertyUtil.getSchemaProperty("type_pgPLICharacteristicSpecifics");
	String TYPE_PGPLICHANGE = PropertyUtil.getSchemaProperty("type_pgPLIChange");
	String TYPE_PGMAKINGPERFORMANCECHARACTERISTIC = PropertyUtil
			.getSchemaProperty("type_pgMakingPerformanceCharacteristic");
	String TYPE_PGRECEIVINGPERFORMANCECHARACTERISTIC = PropertyUtil
			.getSchemaProperty("type_pgReceivingPerformanceCharacteristic");
	String TYPE_TESTMETHOD = PropertyUtil.getSchemaProperty("type_TestMethodSpecification");
	String POLICY_PGIPMDOCUMENT = PropertyUtil.getSchemaProperty("policy_pgIPMDocument");
	String ATTRIBUTE_TITLE = PropertyUtil.getSchemaProperty("attribute_Title");
	String ATTRIBUTE_PGPALLETTYPE = PropertyUtil.getSchemaProperty("attribute_pgPalletType");
	String ATTRIBUTE_PGFINISHEDPRODUCTCODE = PropertyUtil.getSchemaProperty("attribute_pgFinishedProductCode");
	String ATTRIBUTE_PGSAPTYPE = PropertyUtil.getSchemaProperty("attribute_pgSAPType");
	String ATTRIBUTE_COMMENT = PropertyUtil.getSchemaProperty("attribute_Comment");
	String ATTRIBUTE_PGLOCALDESCRIPTION = PropertyUtil.getSchemaProperty("attribute_pgLocalDescription");
	String ATTRIBUTE_PGOTHERNAMES = PropertyUtil.getSchemaProperty("attribute_pgOtherNames");
	String ATTRIBUTE_PGARTWORKREQUIRED = PropertyUtil.getSchemaProperty("attribute_pgArtworkRequired");
	String ATTRIBUTE_PGBASEUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_pgBaseUnitOfMeasure");
	String ATTRIBUTE_PGBOMBASEQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgBOMBaseQuantity");
	String ATTRIBUTE_REASONFORCHANGE = PropertyUtil.getSchemaProperty("attribute_ReasonforChange");
	String ATTRIBUTE_FINDNUMBER = PropertyUtil.getSchemaProperty("attribute_FindNumber");
	String ATTRIBUTE_PGMATERIALGROUP = PropertyUtil.getSchemaProperty("attribute_pgMaterialGroup");
	String ATTRIBUTE_PGPACKAGINGMATERIALTYPE = PropertyUtil.getSchemaProperty("attribute_pgPackagingMaterialType");
	String ATTRIBUTE_PGMATERIALTYPE = PropertyUtil.getSchemaProperty("attribute_pgMaterialType");
	String ATTRIBUTE_PGMINQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgMinQuantity");
	String ATTRIBUTE_PGMAXQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgMaxQuantity");
	String ATTRIBUTE_PGPOSITIONINDICATOR = PropertyUtil.getSchemaProperty("attribute_pgPositionIndicator");
	String ATTRIBUTE_PGVALIDUNTILDATE = PropertyUtil.getSchemaProperty("attribute_pgValidUntilDate");
	String ATTRIBUTE_PGISAUTHORIZEDTOUSE = PropertyUtil.getSchemaProperty("attribute_pgIsAuthorizedtoUse");
	String ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE = PropertyUtil.getSchemaProperty("attribute_pgIsAuthorizedtoProduce");
	String ATTRIBUTE_PGISACTIVATED = PropertyUtil.getSchemaProperty("attribute_pgIsActivated");
	String ATTRIBUTE_PGQUANTITYUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_pgQuantityUnitOfMeasure");
	String ATTRIBUTE_QUANTITY = PropertyUtil.getSchemaProperty("attribute_Quantity");
	String ATTRIBUTE_PGQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgQuantity");
	String ATTRIBUTE_ENDEFFECTIVITYDATE = PropertyUtil.getSchemaProperty("attribute_EndEffectivityDate");
	String ATTRIBUTE_PGINCLUDEINCOSANALYSIS = PropertyUtil.getSchemaProperty("attribute_pgIncludeInCOSAnalysis");
	String ATTRIBUTE_PGSUBSTITUTECOMBINATIONNUMBER = PropertyUtil
			.getSchemaProperty("attribute_pgSubstituteCombinationNumber");
	String ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE = PropertyUtil
			.getSchemaProperty("attribute_SharedTableCharacteristicSequence");
	String ATTRIBUTE_PGENTRYBASEQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgEntryBaseQuantity");
	String ATTRIBUTE_PGUNIVERSALDOCUMENTRECIPIENTGROUP = PropertyUtil
			.getSchemaProperty("attribute_pgIPMUniversalDocumentRecipientGroup");
	String ATTRIBUTE_PGMODIFIEDHISTORY = PropertyUtil.getSchemaProperty("attribute_pgIPMModifiedHistory");
	String ATTRIBUTE_PGLOGINTIME = PropertyUtil.getSchemaProperty("attribute_pgIPMLoginTime");
	String ATTRIBUTE_PGLOGINCOUNT = PropertyUtil.getSchemaProperty("attribute_pgIPMLoginCount");
	String ATTRIBUTE_PGEBPSUMMARYPENDING = PropertyUtil.getSchemaProperty("attribute_pgIPMEBPSummaryPending");
	String ATTRIBUTE_PGEBPSUMMARYDOWNLOADED = PropertyUtil.getSchemaProperty("attribute_pgIPMEBPSummaryDownloaded");
	String ATTRIBUTE_PGEBPSUMMARYACCEPTED = PropertyUtil.getSchemaProperty("attribute_pgIPMEBPSummaryAccept");
	String ATTRIBUTE_PGEBPSUMMARYREJECTED = PropertyUtil.getSchemaProperty("attribute_pgIPMEBPSummaryReject");
	String ATTRIBUTE_PGCHARACTERISTIC = PropertyUtil.getSchemaProperty("attribute_pgCharacteristic");
	String ATTRIBUTE_PGRELEASECRITERIA = PropertyUtil.getSchemaProperty("attribute_pgReleaseCriteria");
	String ATTRIBUTE_PGREPORTTYPE = PropertyUtil.getSchemaProperty("attribute_pgReportType");
	String ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT = PropertyUtil.getSchemaProperty("attribute_pgLowerSpecificationLimit");
	String ATTRIBUTE_PGLOWERTARGET = PropertyUtil.getSchemaProperty("attribute_pgLowerTarget");
	String ATTRIBUTE_PGTARGET = PropertyUtil.getSchemaProperty("attribute_pgTarget");
	String ATTRIBUTE_PGUPPERTARGET = PropertyUtil.getSchemaProperty("attribute_pgUpperTarget");
	String ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT = PropertyUtil.getSchemaProperty("attribute_pgUpperSpecificationLimit");
	String ATTRIBUTE_PGUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_pgUnitOfMeasure");
	String ATTRIBUTE_PGREPORTTONEAREST = PropertyUtil.getSchemaProperty("attribute_pgReportToNearest");
	String ATTRIBUTE_PGMETHODORIGIN = PropertyUtil.getSchemaProperty("attribute_pgMethodOrigin");
	String ATTRIBUTE_PGMETHODNUMBER = PropertyUtil.getSchemaProperty("attribute_pgMethodNumber");
	String ATTRIBUTE_PGMETHODSPECIFICS = PropertyUtil.getSchemaProperty("attribute_pgMethodSpecifics");
	String ATTRIBUTE_PGSAMPLING = PropertyUtil.getSchemaProperty("attribute_pgSampling");
	String ATTRIBUTE_PGSUBGROUP = PropertyUtil.getSchemaProperty("attribute_pgSubGroup");
	String ATTRIBUTE_PGACTIONREQUIRED = PropertyUtil.getSchemaProperty("attribute_pgActionRequired");
	String ATTRIBUTE_PGCRITICALITYFACTOR = PropertyUtil.getSchemaProperty("attribute_pgCriticalityFactor");
	String ATTRIBUTE_PGBASIS = PropertyUtil.getSchemaProperty("attribute_pgBasis");
	String ATTRIBUTE_PGTESTGROUP = PropertyUtil.getSchemaProperty("attribute_pgTestGroup");
	String ATTRIBUTE_PGAPPLICATION = PropertyUtil.getSchemaProperty("attribute_pgApplication");
	String ATTRIBUTE_PGIPMBRANDBOOKLEVEL = PropertyUtil.getSchemaProperty("attribute_pgIPMBrandBookLevel");
	String ATTRIBUTE_PGIPMSITEORVENDORNUMBER = PropertyUtil.getSchemaProperty("attribute_pgIPMSiteorVendorNumber");
	String ATTRIBUTE_PGCSSTYPE = PropertyUtil.getSchemaProperty("attribute_pgCSSType");
	String ATTRIBUTE_PGASSEMBLYTYPE = PropertyUtil.getSchemaProperty("attribute_pgAssemblyType");
	String ATTRIBUTE_ADDRESS = PropertyUtil.getSchemaProperty("attribute_Address");
	String ATTRIBUTE_PGSHAREWITHSUPPLIERS = PropertyUtil.getSchemaProperty("attribute_pgShareWithSuppliers");
	String ATTRIBUTE_PGIPMCMSHARINGHIERARCHY = PropertyUtil.getSchemaProperty("attribute_pgIPMCMSharingHierarchy");
	String ATTRIBUTE_PGIPMSUPPLIERSHARINGHIERARCHY = PropertyUtil
			.getSchemaProperty("attribute_pgIPMSupplierSharingHierarchy");
	String ATTRIBUTE_PGHOUSENUMBER = PropertyUtil.getSchemaProperty("attribute_pgHouseNumber");
	String ATTRIBUTE_PGCLAIMEDBY = PropertyUtil.getSchemaProperty("attribute_pgClaimedBy");
	String ATTRIBUTE_PGUSERNAME = PropertyUtil.getSchemaProperty("attribute_pgUserName");
	String ATTRIBUTE_PGTMLOGIC = PropertyUtil.getSchemaProperty("attribute_pgTMLogic");
	String ATTRIBUTE_PGIPMEBPRESET = PropertyUtil.getSchemaProperty("attribute_pgIPMReset");
	String ATTRIBUTE_PGISTEMPLATE = PropertyUtil.getSchemaProperty("attribute_pgIsTemplate");
	String ATTRIBUTE_PGPLSITEOWNERSHIP = PropertyUtil.getSchemaProperty("attribute_pgPLSiteOwnership");
	String ATTRIBUTE_PGIPMREASONFORCHANGE_DS = PropertyUtil
			.getSchemaProperty("attribute_pgIPMReasonForChangeDynamicSubscription");
	String ATTRIBUTE_PGCALCQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgCalcQuantity");
	String ATTRIBUTE_ISFCEXIST = PropertyUtil.getSchemaProperty("attribute_pgIsFCExist");
	String ATTRIBUTE_ISARTEXIST = PropertyUtil.getSchemaProperty("attribute_pgIsArtExist");
	String ATTRIBUTE_PGORIGINATINGSOURCE = PropertyUtil.getSchemaProperty("attribute_pgOriginatingSource");
	String ATTRIBUTE_REFERENCETYPE = PropertyUtil.getSchemaProperty("attribute_ReferenceType");
	String ATTRIBUTE_REFERENCEDESIGNATOR = PropertyUtil.getSchemaProperty("attribute_ReferenceDesignator");
	String ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT = PropertyUtil
			.getSchemaProperty("attribute_pgLowerRoutineReleaseLimit");
	String ATTRIBUTE_PGUPPERROUTINERELEASELIMIT = PropertyUtil
			.getSchemaProperty("attribute_pgUpperRoutineReleaseLimit");
	String ATTRIBUTE_PGROUTINERELEASECRITERIA = PropertyUtil.getSchemaProperty("attribute_pgRoutineReleaseCriteria");
	String ATTRIBUTE_PGDIMENSIONUOM = PropertyUtil.getSchemaProperty("attribute_pgDimensionUoM");
	String ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE = PropertyUtil
			.getSchemaProperty("attribute_pgPreviousRevisionObsoleteDate");
	String ATTRIBUTE_PGCSU = PropertyUtil.getSchemaProperty("attribute_PGC_SU");
	String ATTRIBUTE_STAGE = PropertyUtil.getSchemaProperty("attribute_Stage");
	String ATTRIBUTE_PGARCHIVEDATE = PropertyUtil.getSchemaProperty("attribute_pgArchiveDate");
	String ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONRETRYCOUNT = PropertyUtil
			.getSchemaProperty("attribute_pgIPMDynamicSubscriptionCronRetryCount");
	String ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONFAILURENOTIFYL3SUPPORTMAILIDS = PropertyUtil
			.getSchemaProperty("attribute_pgIPMDynamicSubscriptionCronFailureNotifyL3SupportMailIds");
	String ATTRIBUTE_STATUS = PropertyUtil.getSchemaProperty("attribute_Status");
	String ATTRIBUTE_PGPREFERREDMATERIAL = PropertyUtil.getSchemaProperty("attribute_pgPreferredMaterial");
	String ATTRIBUTE_PGDECORATIONDETAILS = PropertyUtil.getSchemaProperty("attribute_pgDecorationDetails");
	String ATTRIBUTE_PGPACKAGINGSIZE = PropertyUtil.getSchemaProperty("attribute_pgPackagingSize");
	String ATTRIBUTE_PGPACKAGINGUNIT = PropertyUtil.getSchemaProperty("attribute_pgPackagingUnit");
	String ATTRIBUTE_PGPARTCOLOR = PropertyUtil.getSchemaProperty("attribute_pgPartColor");
	String ATTRIBUTE_PGMARKETINGSIZEREAL = PropertyUtil.getSchemaProperty("attribute_pgMarketingSizeReal");
	String ATTRIBUTE_PGWHSELOGISTICS = PropertyUtil.getSchemaProperty("attribute_pgWhseLogistics");
	String ATTRIBUTE_PGAREAEFFECIENCY = PropertyUtil.getSchemaProperty("attribute_pgAreaEffeciency");
	String ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER = PropertyUtil
			.getSchemaProperty("attribute_pgLayersPerTransportUnitInteger");
	String ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER = PropertyUtil
			.getSchemaProperty("attribute_pgCustomerUnitsPerLayerInteger");
	String ATTRIBUTE_PGCRUSHINDEX = PropertyUtil.getSchemaProperty("attribute_pgCrushIndex");
	String ATTRIBUTE_PGCUBEEFFECIENCY = PropertyUtil.getSchemaProperty("attribute_pgCubeEffeciency");
	String ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT = PropertyUtil
			.getSchemaProperty("attribute_pgTruckPalletStackMaxHeight");
	String ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT = PropertyUtil
			.getSchemaProperty("attribute_pgWhsePalletStackMaxHeight");
	String ATTRIBUTE_PGUNDERHANGMAXLENGTH = PropertyUtil.getSchemaProperty("attribute_pgUnderhangMaxLength");
	String ATTRIBUTE_PGUNDERHANGMAXWIDTH = PropertyUtil.getSchemaProperty("attribute_pgUnderhangMaxWidth");
	String ATTRIBUTE_PGOVERHANGMAXLENGTH = PropertyUtil.getSchemaProperty("attribute_pgOverhangMaxLength");
	String ATTRIBUTE_PGOVERHANGMAXWIDTH = PropertyUtil.getSchemaProperty("attribute_pgOverhangMaxWidth");
	String ATTRIBUTE_PGVOLUMEREAL = PropertyUtil.getSchemaProperty("attribute_pgVolumeReal");
	String ATTRIBUTE_PGOUTERDIMENSIONWIDTH = PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionWidth");
	String ATTRIBUTE_PGOUTERDIMENSIONLENGTH = PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionLength");
	String ATTRIBUTE_PGOUTERDIMENSIONHEIGHT = PropertyUtil.getSchemaProperty("attribute_pgOuterDimensionHeight");
	String ATTRIBUTE_PGALTERNATEUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_pgAlternateUnitOfMeasure");
	String ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL = PropertyUtil
			.getSchemaProperty("attribute_pgNetWeightOfProductInConsumerUnitReal");
	String ATTRIBUTE_PGGROSSWEIGHTREAL = PropertyUtil.getSchemaProperty("attribute_pgGrossWeightReal");
	String ATTRIBUTE_PGWHSECASEMAXHEIGHT = PropertyUtil.getSchemaProperty("attribute_pgWhseCaseMaxHeight");
	String ATTRIBUTE_PGFAILEDREASON = PropertyUtil.getSchemaProperty("attribute_pgFailedReason");
	String ATTRIBUTE_PGPDFREACHSTATEMENT = PropertyUtil.getSchemaProperty("attribute_pgPDFReachStatement");
	String ATTRIBUTE_PGERRORCLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pgErrorClassification");
	String ATTRIBUTE_PGGTIN = PropertyUtil.getSchemaProperty("attribute_pgGTIN");
	String ATTRIBUTE_PGNUMBEROFCONSUMERUNITSINCUSTOMERUNIT = PropertyUtil
			.getSchemaProperty("attribute_pgNumberOfConsumerUnitsInCustomerUnit");
	String ATTRIBUTE_PGVOLUMEUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_pgVolumeUnitOfMeasure");
	String ATTRIBUTE_PGGROSSWEIGHTWITHPALLETREAL = PropertyUtil
			.getSchemaProperty("attribute_pgGrossWeightWithPalletReal");
	String ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLETREAL = PropertyUtil
			.getSchemaProperty("attribute_pgGrossWeightWithoutPalletReal");
	String ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE = PropertyUtil
			.getSchemaProperty("attribute_pgGrossWeightUnitOfMeasure");
	String ATTRIBUTE_PGLIFECYCLESTATUS = PropertyUtil.getSchemaProperty("attribute_pgLifeCycleStatus");
	String ATTRIBUTE_PGINNERDIMENSIONWIDTH = PropertyUtil.getSchemaProperty("attribute_pgInnerDimensionWidth");
	String ATTRIBUTE_PGINNERDIMENSIONLENGTH = PropertyUtil.getSchemaProperty("attribute_pgInnerDimensionLength");
	String ATTRIBUTE_PGINNERDIMENSIONHEIGHT = PropertyUtil.getSchemaProperty("attribute_pgInnerDimensionHeight");
	String ATTRIBUTE_MARKETINGNAME = PropertyUtil.getSchemaProperty("attribute_MarketingName");
	String ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT = PropertyUtil
			.getSchemaProperty("attribute_pgPostConsumerRecycledContent");
	String ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT = PropertyUtil
			.getSchemaProperty("attribute_pgMinimumPercentWeightbyWeight");
	String ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT = PropertyUtil
			.getSchemaProperty("attribute_pgMaximumPercentWeightbyWeight");
	String ATTRIBUTE_PGMATERIALLAYER = PropertyUtil.getSchemaProperty("attribute_pgMaterialLayer");
	String ATTRIBUTE_CASNUMBER = PropertyUtil.getSchemaProperty("attribute_CASNumber");
	String ATTRIBUTE_ECNUMBER = PropertyUtil.getSchemaProperty("attribute_ECNumber");
	String ATTRIBUTE_REACHREGISTRATIONSTATUS = PropertyUtil.getSchemaProperty("attribute_ReachStatus");
	String ATTRIBUTE_REACHPREREGISTRATIONSTATUS = PropertyUtil
			.getSchemaProperty("attribute_REACHPreRegistrationStatus");
	String ATTRIBUTE_PGMATERIALLEGACYENVCLASS = PropertyUtil.getSchemaProperty("attribute_pgMaterialLegacyEnvClass");
	String ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM = PropertyUtil
			.getSchemaProperty("attribute_pgNetWeightOfProductInConsumerUnitUoM");
	String ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE = PropertyUtil.getSchemaProperty("attribute_pgPackagingComponentType");
	String ATTRIBUTE_PGPLANTTESTING = PropertyUtil.getSchemaProperty("attribute_pgPlantTesting");
	String ATTRIBUTE_PGRETESTINGUOM = PropertyUtil.getSchemaProperty("attribute_pgRetestingUOM");
	String ATTRIBUTE_PGSUBCLASS = PropertyUtil.getSchemaProperty("attribute_pgSubClass");
	String ATTRIBUTE_PGLANGUAGE = PropertyUtil.getSchemaProperty("attribute_pgLanguage");
	String ATTRIBUTE_PGEPADEXEMAILADDRESS = PropertyUtil.getSchemaProperty("attribute_pgEPADExContactEmailAddress");
	String ATTRIBUTE_PGEPADEXINTESDEDIPMSGCAS = PropertyUtil.getSchemaProperty("attribute_pgEPADExIntendedIPMSGCAS");
	String ATTRIBUTE_PGEPADEXPOANUMBER = PropertyUtil.getSchemaProperty("attribute_pgEPADExPOANumber");
	String ATTRIBUTE_PGEPADEXPROJECTNAME = PropertyUtil.getSchemaProperty("attribute_pgEPADExProjectName");
	String ATTRIBUTE_PGEPADEXPROJECTNUMBER = PropertyUtil.getSchemaProperty("attribute_pgEPADExProjectNumber");
	String ATTRIBUTE_PGEPADEXRELEASEDATE = PropertyUtil.getSchemaProperty("attribute_pgEPADExReleaseDate");
	String ATTRIBUTE_PGEPADEXSIGNATUREDATE = PropertyUtil.getSchemaProperty("attribute_pgEPADExSignatureDates");
	String ATTRIBUTE_PGEPADEXSIGNATURENAME = PropertyUtil.getSchemaProperty("attribute_pgEPADExSignatureNames");
	String ATTRIBUTE_PGGBU = PropertyUtil.getSchemaProperty("attribute_pgGBU");
	String ATTRIBUTE_PGARTWORKLANGUAGE = PropertyUtil.getSchemaProperty("attribute_pgArtworkLanguage");
	String ATTRIBUTE_PGCATEGORY = PropertyUtil.getSchemaProperty("attribute_pgCategory");
	String ATTRIBUTE_PGPRIMARYAFFECTEDCATEGORY = PropertyUtil.getSchemaProperty("attribute_pgPrimaryAffectedCategory");
	String ATTRIBUTE_PGSHORTCODE = PropertyUtil.getSchemaProperty("attribute_pgShortCode");
	String ATTRIBUTE_PGPLANTTESTINGRETESTING = PropertyUtil.getSchemaProperty("attribute_pgPlantTestingRetesting");
	String ATTRIBUTE_WEIGHT = PropertyUtil.getSchemaProperty("attribute_Weight");
	String ATTRIBUTE_PGWEIGHTUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_pgWeightUnitOfMeasure");
	String ATTRIBUTE_PGCHARACTERISTICSPECIFICS = PropertyUtil.getSchemaProperty("attribute_pgCharacteristicSpecifics");
	String ATTRIBUTE_PGERRORDATE = PropertyUtil.getSchemaProperty("attribute_pgErrorDate");
	String ATTRIBUTE_PGPACKAGINGSIZEUOM = PropertyUtil.getSchemaProperty("attribute_pgPackagingSizeUOM");
	String ATTRIBUTE_PGCLASS = PropertyUtil.getSchemaProperty("attribute_pgClass");
	String ATTRIBUTE_PGCSS_MANUFACTURER = PropertyUtil.getSchemaProperty("attribute_pgCSSManufacturer");
	String ATTRIBUTE_CPNEVENTFORDAILYSUBSCRIPTION = PropertyUtil
			.getSchemaProperty("attribute_CPNEventForDailySubscription");
	String SELECT_ATTRIBUTE_CPNEVENTFORDAILYSUBSCRIPTION = "attribute[" + ATTRIBUTE_CPNEVENTFORDAILYSUBSCRIPTION + "]";
	String ATTRIBUTE_PGISAUTHORIZEDTOVIEW = PropertyUtil.getSchemaProperty("attribute_pgIsAuthorizedtoView");
	String ATTRIBUTE_PGFIRSTLEVELIPMTYPESFORCM = PropertyUtil.getSchemaProperty("attribute_pgFirstLevelIPMTypesForCM");
	String ATTRIBUTE_PGFIRSTLEVELDSMTYPESFORCM = PropertyUtil.getSchemaProperty("attribute_pgFirstLevelDSMTypesForCM");
	String ATTRIBUTE_PGFIRSTLEVELIPMTYPESFORCS = PropertyUtil.getSchemaProperty("attribute_pgFirstLevelIPMTypesForCS");
	String ATTRIBUTE_PGFIRSTLEVELDSMTYPESFORCS = PropertyUtil.getSchemaProperty("attribute_pgFirstLevelDSMTypesForCS");
	String ATTRIBUTE_PGSECONDLEVELTYPES = PropertyUtil.getSchemaProperty("attribute_pgSecondLevelTypes");
	String ATTRIBUTE_PGSEQUENCE = PropertyUtil.getSchemaProperty("attribute_pgSequence");
	String SELECT_ATTRIBUTE_PGFIRSTLEVELIPMTYPESFORCM = "attribute[" + ATTRIBUTE_PGFIRSTLEVELIPMTYPESFORCM + "]";
	String SELECT_ATTRIBUTE_PGFIRSTLEVELDSMTYPESFORCM = "attribute[" + ATTRIBUTE_PGFIRSTLEVELDSMTYPESFORCM + "]";
	String SELECT_ATTRIBUTE_PGFIRSTLEVELIPMTYPESFORCS = "attribute[" + ATTRIBUTE_PGFIRSTLEVELIPMTYPESFORCS + "]";
	String SELECT_ATTRIBUTE_PGFIRSTLEVELDSMTYPESFORCS = "attribute[" + ATTRIBUTE_PGFIRSTLEVELDSMTYPESFORCS + "]";
	String SELECT_ATTRIBUTE_PGSECONDLEVELTYPES = "attribute[" + ATTRIBUTE_PGSECONDLEVELTYPES + "]";
	String SELECT_ATTRIBUTE_PGSEQUENCE = "attribute[" + ATTRIBUTE_PGSEQUENCE + "]";
	String SELECT_ATTRIBUTE_TITLE = "attribute[" + ATTRIBUTE_TITLE + "]";
	String SELECT_ATTRIBUTE_PGPALLETTYPE = "attribute[" + ATTRIBUTE_PGPALLETTYPE + "]";
	String SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE = "attribute[" + ATTRIBUTE_PGFINISHEDPRODUCTCODE + "]";
	String SELECT_ATTRIBUTE_PGSAPTYPE = "attribute[" + ATTRIBUTE_PGSAPTYPE + "]";
	String SELECT_ATTRIBUTE_COMMENT = "attribute[" + ATTRIBUTE_COMMENT + "]";
	String SELECT_ATTRIBUTE_PGLOCALDESCRIPTION = "attribute[" + ATTRIBUTE_PGLOCALDESCRIPTION + "]";
	String SELECT_ATTRIBUTE_PGOTHERNAMES = "attribute[" + ATTRIBUTE_PGOTHERNAMES + "]";
	String SELECT_ATTRIBUTE_PGARTWORKREQUIRED = "attribute[" + ATTRIBUTE_PGARTWORKREQUIRED + "]";
	String SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGBASEUNITOFMEASURE + "]";
	String SELECT_ATTRIBUTE_PGBOMBASEQUANTITY = "attribute[" + ATTRIBUTE_PGBOMBASEQUANTITY + "]";
	String SELECT_ATTRIBUTE_REASONFORCHANGE = "attribute[" + ATTRIBUTE_REASONFORCHANGE + "]";
	String SELECT_ATTRIBUTE_FINDNUMBER = "attribute[" + ATTRIBUTE_FINDNUMBER + "]";
	String SELECT_ATTRIBUTE_PGMATERIALGROUP = "attribute[" + ATTRIBUTE_PGMATERIALGROUP + "]";
	String SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE = "attribute[" + ATTRIBUTE_PGPACKAGINGMATERIALTYPE + "]";
	String SELECT_ATTRIBUTE_PGMATERIALTYPE = "attribute[" + ATTRIBUTE_PGMATERIALTYPE + "]";
	String SELECT_ATTRIBUTE_PGMINQUANTITY = "attribute[" + ATTRIBUTE_PGMINQUANTITY + "]";
	String SELECT_ATTRIBUTE_PGMAXQUANTITY = "attribute[" + ATTRIBUTE_PGMAXQUANTITY + "]";
	String SELECT_ATTRIBUTE_PGPOSITIONINDICATOR = "attribute[" + ATTRIBUTE_PGPOSITIONINDICATOR + "]";
	String SELECT_ATTRIBUTE_PGVALIDUNTILDATE = "attribute[" + ATTRIBUTE_PGVALIDUNTILDATE + "]";
	String SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE = "attribute[" + ATTRIBUTE_PGISAUTHORIZEDTOUSE + "]";
	String SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE = "attribute[" + ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE + "]";
	String SELECT_ATTRIBUTE_PGISACTIVATED = "attribute[" + ATTRIBUTE_PGISACTIVATED + "]";
	String SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGQUANTITYUNITOFMEASURE + "]";
	String SELECT_ATTRIBUTE_QUANTITY = "attribute[" + ATTRIBUTE_QUANTITY + "]";
	String SELECT_ATTRIBUTE_PGQUANTITY = "attribute[" + ATTRIBUTE_PGQUANTITY + "]";
	String SELECT_ATTRIBUTE_ENDEFFECTIVITYDATE = "attribute[" + ATTRIBUTE_ENDEFFECTIVITYDATE + "]";
	String SELECT_ATTRIBUTE_PGINCLUDEINCOSANALYSIS = "attribute[" + ATTRIBUTE_PGINCLUDEINCOSANALYSIS + "]";
	String SELECT_ATTRIBUTE_PGSUBSTITUTECOMBINATIONNUMBER = "attribute[" + ATTRIBUTE_PGSUBSTITUTECOMBINATIONNUMBER
			+ "]";
	String SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE = "attribute["
			+ ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE + "]";
	String SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY = "attribute[" + ATTRIBUTE_PGENTRYBASEQUANTITY + "]";
	String SELECT_ATTRIBUTE_PGUNIVERSALDOCUMENTRECIPIENTGROUP = "attribute["
			+ ATTRIBUTE_PGUNIVERSALDOCUMENTRECIPIENTGROUP + "]";
	String SELECT_ATTRIBUTE_PGMODIFIEDHISTORY = "attribute[" + ATTRIBUTE_PGMODIFIEDHISTORY + "]";
	String SELECT_ATTRIBUTE_PGLOGINTIME = "attribute[" + ATTRIBUTE_PGLOGINTIME + "]";
	String SELECT_ATTRIBUTE_PGLOGINCOUNT = "attribute[" + ATTRIBUTE_PGLOGINCOUNT + "]";
	String SELECT_ATTRIBUTE_PGEBPSUMMARYPENDING = "attribute[" + ATTRIBUTE_PGEBPSUMMARYPENDING + "]";
	String SELECT_ATTRIBUTE_PGEBPSUMMARYDOWNLOADED = "attribute[" + ATTRIBUTE_PGEBPSUMMARYDOWNLOADED + "]";
	String SELECT_ATTRIBUTE_PGEBPSUMMARYACCEPTED = "attribute[" + ATTRIBUTE_PGEBPSUMMARYACCEPTED + "]";
	String SELECT_ATTRIBUTE_PGEBPSUMMARYREJECTED = "attribute[" + ATTRIBUTE_PGEBPSUMMARYREJECTED + "]";
	String SELECT_ATTRIBUTE_PGCHARACTERISTIC = "attribute[" + ATTRIBUTE_PGCHARACTERISTIC + "]";
	String SELECT_ATTRIBUTE_PGRELEASECRITERIA = "attribute[" + ATTRIBUTE_PGRELEASECRITERIA + "]";
	String SELECT_ATTRIBUTE_PGREPORTTYPE = "attribute[" + ATTRIBUTE_PGREPORTTYPE + "]";
	String SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT = "attribute[" + ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT + "]";
	String SELECT_ATTRIBUTE_PGLOWERTARGET = "attribute[" + ATTRIBUTE_PGLOWERTARGET + "]";
	String SELECT_ATTRIBUTE_PGTARGET = "attribute[" + ATTRIBUTE_PGTARGET + "]";
	String SELECT_ATTRIBUTE_PGUPPERTARGET = "attribute[" + ATTRIBUTE_PGUPPERTARGET + "]";
	String SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT = "attribute[" + ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT + "]";
	String SELECT_ATTRIBUTE_PGUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGUNITOFMEASURE + "]";
	String SELECT_ATTRIBUTE_PGREPORTTONEAREST = "attribute[" + ATTRIBUTE_PGREPORTTONEAREST + "]";
	String SELECT_ATTRIBUTE_PGMETHODORIGIN = "attribute[" + ATTRIBUTE_PGMETHODORIGIN + "]";
	String SELECT_ATTRIBUTE_PGMETHODNUMBER = "attribute[" + ATTRIBUTE_PGMETHODNUMBER + "]";
	String SELECT_ATTRIBUTE_PGMETHODSPECIFICS = "attribute[" + ATTRIBUTE_PGMETHODSPECIFICS + "]";
	String SELECT_ATTRIBUTE_PGSAMPLING = "attribute[" + ATTRIBUTE_PGSAMPLING + "]";
	String SELECT_ATTRIBUTE_PGSUBGROUP = "attribute[" + ATTRIBUTE_PGSUBGROUP + "]";
	String SELECT_ATTRIBUTE_PGACTIONREQUIRED = "attribute[" + ATTRIBUTE_PGACTIONREQUIRED + "]";
	String SELECT_ATTRIBUTE_PGCRITICALITYFACTOR = "attribute[" + ATTRIBUTE_PGCRITICALITYFACTOR + "]";
	String SELECT_ATTRIBUTE_PGBASIS = "attribute[" + ATTRIBUTE_PGBASIS + "]";
	String SELECT_ATTRIBUTE_PGTESTGROUP = "attribute[" + ATTRIBUTE_PGTESTGROUP + "]";
	String SELECT_ATTRIBUTE_PGAPPLICATION = "attribute[" + ATTRIBUTE_PGAPPLICATION + "]";
	String SELECT_ATTRIBUTE_PGIPMBRANDBOOKLEVEL = "attribute[" + ATTRIBUTE_PGIPMBRANDBOOKLEVEL + "]";
	String SELECT_ATTRIBUTE_PGIPMSITEORVENDORNUMBER = "attribute[" + ATTRIBUTE_PGIPMSITEORVENDORNUMBER + "]";
	String SELECT_ATTRIBUTE_PGCSSTYPE = "attribute[" + ATTRIBUTE_PGCSSTYPE + "]";
	String SELECT_ATTRIBUTE_PGASSEMBLYTYPE = "attribute[" + ATTRIBUTE_PGASSEMBLYTYPE + "]";
	String SELECT_ATTRIBUTE_ADDRESS = "attribute[" + ATTRIBUTE_ADDRESS + "]";
	String SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS = "attribute[" + ATTRIBUTE_PGSHAREWITHSUPPLIERS + "]";
	String SELECT_ATTRIBUTE_PGIPMCMSHARINGHIERARCHY = "attribute[" + ATTRIBUTE_PGIPMCMSHARINGHIERARCHY + "]";
	String SELECT_ATTRIBUTE_PGIPMSUPPLIERSHARINGHIERARCHY = "attribute[" + ATTRIBUTE_PGIPMSUPPLIERSHARINGHIERARCHY
			+ "]";
	String SELECT_ATTRIBUTE_PGHOUSENUMBER = "attribute[" + ATTRIBUTE_PGHOUSENUMBER + "]";
	String SELECT_ATTRIBUTE_PGCLAIMEDBY = "attribute[" + ATTRIBUTE_PGCLAIMEDBY + "]";
	String SELECT_ATTRIBUTE_PGUSERNAME = "attribute[" + ATTRIBUTE_PGUSERNAME + "]";
	String SELECT_ATTRIBUTE_PGTMLOGIC = "attribute[" + ATTRIBUTE_PGTMLOGIC + "]";
	String SELECT_ATTRIBUTE_PGISTEMPLATE = "attribute[" + ATTRIBUTE_PGISTEMPLATE + "]";
	String SELECT_ATTRIBUTE_PGPLSITEOWNERSHIP = "attribute[" + ATTRIBUTE_PGPLSITEOWNERSHIP + "]";
	String SELECT_ATTRIBUTE_PGIPMREASONFORCHANGE_DS = "attribute[" + ATTRIBUTE_PGIPMREASONFORCHANGE_DS + "]";
	String SELECT_ATTRIBUTE_PGCALCQUANTITY = "attribute[" + ATTRIBUTE_PGCALCQUANTITY + "]";
	String SELECT_ATTRIBUTE_ISFCEXIST = "attribute[" + ATTRIBUTE_ISFCEXIST + "]";
	String SELECT_ATTRIBUTE_ISARTEXIST = "attribute[" + ATTRIBUTE_ISARTEXIST + "]";
	String SELECT_ATTRIBUTE_PGORIGINATINGSOURCE = "attribute[" + ATTRIBUTE_PGORIGINATINGSOURCE + "]";
	String SELECT_ATTRIBUTE_REFERENCEDESIGNATOR = "attribute[" + ATTRIBUTE_REFERENCEDESIGNATOR + "]";
	String SELECT_ATTRIBUTE_STAGE = "attribute[" + ATTRIBUTE_STAGE + "]";
	String SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT = "attribute[" + ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT + "]";
	String SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT = "attribute[" + ATTRIBUTE_PGUPPERROUTINERELEASELIMIT + "]";
	String SELECT_ATTRIBUTE_PGROUTINERELEASECRITERIA = "attribute[" + ATTRIBUTE_PGROUTINERELEASECRITERIA + "]";
	String SELECT_ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONRETRYCOUNT = "attribute["
			+ ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONRETRYCOUNT + "]";
	String SELECT_ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONFAILURENOTIFYL3SUPPORTMAILIDS = "attribute["
			+ ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONFAILURENOTIFYL3SUPPORTMAILIDS + "]";
	String SELECT_ATTRIBUTE_REFERENCETYPE = "attribute[" + ATTRIBUTE_REFERENCETYPE + "]";
	String SELECT_ATTRIBUTE_PGDIMENSIONUOM = "attribute[" + ATTRIBUTE_PGDIMENSIONUOM + "]";
	String SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE = "attribute[" + ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE
			+ "]";
	String SELECT_ATTRIBUTE_PGCSU = "attribute[" + ATTRIBUTE_PGCSU + "]";
	String SELECT_ATTRIBUTE_PGARCHIVEDATE = "attribute[" + ATTRIBUTE_PGARCHIVEDATE + "]";
	String SELECT_ATTRIBUTE_STATUS = "attribute[" + ATTRIBUTE_STATUS + "]";
	String SELECT_ATTRIBUTE_PGDECORATIONDETAILS = "attribute[" + ATTRIBUTE_PGDECORATIONDETAILS + "]";
	String SELECT_ATTRIBUTE_PGPACKAGINGSIZE = "attribute[" + ATTRIBUTE_PGPACKAGINGSIZE + "]";
	String SELECT_ATTRIBUTE_PGPACKAGINGUNIT = "attribute[" + ATTRIBUTE_PGPACKAGINGUNIT + "]";
	String SELECT_ATTRIBUTE_PGPARTCOLOR = "attribute[" + ATTRIBUTE_PGPARTCOLOR + "]";
	String SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL = "attribute[" + ATTRIBUTE_PGMARKETINGSIZEREAL + "]";
	String SELECT_ATTRIBUTE_PGWHSELOGISTICS = "attribute[" + ATTRIBUTE_PGWHSELOGISTICS + "]";
	String SELECT_ATTRIBUTE_PGAREAEFFECIENCY = "attribute[" + ATTRIBUTE_PGAREAEFFECIENCY + "]";
	String SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER = "attribute[" + ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER
			+ "]";
	String SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER = "attribute[" + ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER
			+ "]";
	String SELECT_ATTRIBUTE_PGCRUSHINDEX = "attribute[" + ATTRIBUTE_PGCRUSHINDEX + "]";
	String SELECT_ATTRIBUTE_PGCUBEEFFECIENCY = "attribute[" + ATTRIBUTE_PGCUBEEFFECIENCY + "]";
	String SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT = "attribute[" + ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT + "]";
	String SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT = "attribute[" + ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT + "]";
	String SELECT_ATTRIBUTE_PGUNDERHANGMAXLENGTH = "attribute[" + ATTRIBUTE_PGUNDERHANGMAXLENGTH + "]";
	String SELECT_ATTRIBUTE_PPGUNDERHANGMAXWIDTH = "attribute[" + ATTRIBUTE_PGUNDERHANGMAXWIDTH + "]";
	String SELECT_ATTRIBUTE_PGOVERHANGMAXLENGTH = "attribute[" + ATTRIBUTE_PGOVERHANGMAXLENGTH + "]";
	String SELECT_ATTRIBUTE_PGOVERHANGMAXWIDTH = "attribute[" + ATTRIBUTE_PGOVERHANGMAXWIDTH + "]";
	String SELECT_ATTRIBUTE_PGVOLUMEREAL = "attribute[" + ATTRIBUTE_PGVOLUMEREAL + "]";
	String SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH = "attribute[" + ATTRIBUTE_PGOUTERDIMENSIONWIDTH + "]";
	String SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH = "attribute[" + ATTRIBUTE_PGOUTERDIMENSIONLENGTH + "]";
	String SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT = "attribute[" + ATTRIBUTE_PGOUTERDIMENSIONHEIGHT + "]";
	String SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGALTERNATEUNITOFMEASURE + "]";
	String SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL = "attribute["
			+ ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL + "]";
	String SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT = "attribute[" + ATTRIBUTE_PGWHSECASEMAXHEIGHT + "]";
	String SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL = "attribute[" + ATTRIBUTE_PGGROSSWEIGHTREAL + "]";
	String SELECT_ATTRIBUTE_PGFAILEDREASON = "attribute[" + ATTRIBUTE_PGFAILEDREASON + "]";
	String SELECT_ATTRIBUTE_PGPDFREACHSTATEMENT = "attribute[" + ATTRIBUTE_PGPDFREACHSTATEMENT + "]";
	String SELECT_ATTRIBUTE_PGERRORCLASSIFICATION = "attribute[" + ATTRIBUTE_PGERRORCLASSIFICATION + "]";
	String SELECT_ATTRIBUTE_PGGTIN = "attribute[" + ATTRIBUTE_PGGTIN + "]";
	String SELECT_ATTRIBUTE_PGNUMBEROFCONSUMERUNITSINCUSTOMERUNIT = "attribute["
			+ ATTRIBUTE_PGNUMBEROFCONSUMERUNITSINCUSTOMERUNIT + "]";
	String SELECT_ATTRIBUTE_PGVOLUMEUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGVOLUMEUNITOFMEASURE + "]";
	String SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLETREAL = "attribute[" + ATTRIBUTE_PGGROSSWEIGHTWITHPALLETREAL + "]";
	String SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLETREAL = "attribute[" + ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLETREAL
			+ "]";
	String SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE + "]";
	String SELECT_ATTRIBUTE_PGLIFECYCLESTATUS = "attribute[" + ATTRIBUTE_PGLIFECYCLESTATUS + "]";
	String SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH = "attribute[" + ATTRIBUTE_PGINNERDIMENSIONWIDTH + "]";
	String SELECT_ATTRIBUTE_PGINNERDIMENSIONLENGTH = "attribute[" + ATTRIBUTE_PGINNERDIMENSIONLENGTH + "]";
	String SELECT_ATTRIBUTE_PGINNERDIMENSIONHEIGHT = "attribute[" + ATTRIBUTE_PGINNERDIMENSIONHEIGHT + "]";
	String SELECT_ATTRIBUTE_MARKETINGNAME = "attribute[" + ATTRIBUTE_MARKETINGNAME + "]";
	String SELECT_ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT = "attribute[" + ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT
			+ "]";
	String SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT = "attribute[" + ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT
			+ "]";
	String SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT = "attribute[" + ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT
			+ "]";
	String SELECT_ATTRIBUTE_PGMATERIALLAYER = "attribute[" + ATTRIBUTE_PGMATERIALLAYER + "]";
	String SELECT_ATTRIBUTE_CASNUMBER = "attribute[" + ATTRIBUTE_CASNUMBER + "]";
	String SELECT_ATTRIBUTE_ECNUMBER = "attribute[" + ATTRIBUTE_ECNUMBER + "]";
	String SELECT_ATTRIBUTE_REACHREGISTRATIONSTATUS = "attribute[" + ATTRIBUTE_REACHREGISTRATIONSTATUS + "]";
	String SELECT_ATTRIBUTE_REACHPREREGISTRATIONSTATUS = "attribute[" + ATTRIBUTE_REACHPREREGISTRATIONSTATUS + "]";
	String SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS = "attribute[" + ATTRIBUTE_PGMATERIALLEGACYENVCLASS + "]";
	String SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM = "attribute["
			+ ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM + "]";
	String SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE = "attribute[" + ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE + "]";
	String SELECT_ATTRIBUTE_PGPLANTTESTING = "attribute[" + ATTRIBUTE_PGPLANTTESTING + "]";
	String SELECT_ATTRIBUTE_PGRETESTINGUOM = "attribute[" + ATTRIBUTE_PGRETESTINGUOM + "]";
	String SELECT_ATTRIBUTE_PGSUBCLASS = "attribute[" + ATTRIBUTE_PGSUBCLASS + "]";
	String SELECT_ATTRIBUTE_PGLANGUAGE = "attribute[" + ATTRIBUTE_PGLANGUAGE + "]";
	String SELECT_ATTRIBUTE_PGEPADEXEMAILADDRESS = "attribute[" + ATTRIBUTE_PGEPADEXEMAILADDRESS + "]";
	String SELECT_ATTRIBUTE_PGEPADEXINTESDEDIPMSGCAS = "attribute[" + ATTRIBUTE_PGEPADEXINTESDEDIPMSGCAS + "]";
	String SELECT_ATTRIBUTE_PGEPADEXPOANUMBER = "attribute[" + ATTRIBUTE_PGEPADEXPOANUMBER + "]";
	String SELECT_ATTRIBUTE_PGEPADEXPROJECTNAME = "attribute[" + ATTRIBUTE_PGEPADEXPROJECTNAME + "]";
	String SELECT_ATTRIBUTE_GEPADEXPROJECTNUMBER = "attribute[" + ATTRIBUTE_PGEPADEXPROJECTNUMBER + "]";
	String SELECT_ATTRIBUTE_PGEPADEXRELEASEDATE = "attribute[" + ATTRIBUTE_PGEPADEXRELEASEDATE + "]";
	String SELECT_ATTRIBUTE_PGEPADEXSIGNATUREDATE = "attribute[" + ATTRIBUTE_PGEPADEXSIGNATUREDATE + "]";
	String SELECT_ATTRIBUTE_PGEPADEXSIGNATURENAME = "attribute[" + ATTRIBUTE_PGEPADEXSIGNATURENAME + "]";
	String SELECT_ATTRIBUTE_PGGBU = "attribute[" + ATTRIBUTE_PGGBU + "]";
	String SELECT_ATTRIBUTE_PGARTWORKLANGUAGE = "attribute[" + ATTRIBUTE_PGARTWORKLANGUAGE + "]";
	String SELECT_ATTRIBUTE_PGCATEGORY = "attribute[" + ATTRIBUTE_PGCATEGORY + "]";
	String SELECT_ATTRIBUTE_PGPRIMARYAFFECTEDCATEGORY = "attribute[" + ATTRIBUTE_PGPRIMARYAFFECTEDCATEGORY + "]";
	String SELECT_ATTRIBUTE_PGSHORTCODE = "attribute[" + ATTRIBUTE_PGSHORTCODE + "]";
	String SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING = "attribute[" + ATTRIBUTE_PGPLANTTESTINGRETESTING + "]";
	String SELECT_ATTRIBUTE_WEIGHT = "attribute[" + ATTRIBUTE_WEIGHT + "]";
	String SELECT_ATTRIBUTE_PGWEIGHTUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGWEIGHTUNITOFMEASURE + "]";
	String SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS = "attribute[" + ATTRIBUTE_PGCHARACTERISTICSPECIFICS + "]";
	String SELECT_ATTRIBUTE_PGERRORDATE = "attribute[" + ATTRIBUTE_PGERRORDATE + "]";
	String SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM = "attribute[" + ATTRIBUTE_PGPACKAGINGSIZEUOM + "]";
	String SELECT_ATTRIBUTE_PGCLASS = "attribute[" + ATTRIBUTE_PGCLASS + "]";
	String SELECT_ATTRIBUTE_PGCSS_MANUFACTURER = "attribute[" + ATTRIBUTE_PGCSS_MANUFACTURER + "]";
	String SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW = "attribute[" + ATTRIBUTE_PGISAUTHORIZEDTOVIEW + "]";
	String VAULT_ESERVICEPRODUCTION = PropertyUtil.getSchemaProperty("vault_eServiceProduction");
	String POLICY_IPMPART = PropertyUtil.getSchemaProperty("policy_IPMPart");
	String RELATIONSHIP_PGMATERIALTOPGPLIENVIRONMENTALCLASS = PropertyUtil
			.getSchemaProperty("relationship_pgMaterialtopgPLIEnvironmentalClass");
	String RELATIONSHIP_MANUFACTURINGRESPONSIBILITY = PropertyUtil
			.getSchemaProperty("relationship_ManufacturingResponsibility");
	String RELATIONSHIP_PGMASTER = PropertyUtil.getSchemaProperty("relationship_pgMaster");
	String RELATIONSHIP_PGAPPROVEDSUPPLIERLIST = PropertyUtil.getSchemaProperty("relationship_pgApprovedSupplierList");
	String RELATIONSHIP_PGDEFINESMATERIAL = PropertyUtil.getSchemaProperty("relationship_pgDefinesMaterial");
	String RELATIONSHIP_PGAPPROVEDSUPPLIERLISTROW = PropertyUtil
			.getSchemaProperty("relationship_pgApprovedSupplierListRow");
	String RELATIONSHIP_CHARACTERISTIC = PropertyUtil.getSchemaProperty("relationship_Characteristic");
	String RELATIONSHIP_REFERENCEDOCUMENT = PropertyUtil.getSchemaProperty("relationship_ReferenceDocument");
	String RELATIONSHIP_SHAREDTABLE = PropertyUtil.getSchemaProperty("relationship_SharedTable");
	String RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION = PropertyUtil
			.getSchemaProperty("relationship_AuthorizedTemporarySpecification");
	String RELATIONSHIP_PGPLANTORSUPPLIERTOSUMMARY = PropertyUtil
			.getSchemaProperty("relationship_pgIPMPlantOrSupplierToSummary");
	String RELATIONSHIP_PGSUMMARYTOPRODUCTDATA = PropertyUtil
			.getSchemaProperty("relationship_pgIPMSummaryToProductData");
	String RELATIONSHIP_PGUNIVERSALDOCUMENTTOSTANDARD = PropertyUtil
			.getSchemaProperty("relationship_pgIPMUniversalDocumentToStandard");
	String RELATIONSHIP_PGSECURITYMEMBER = PropertyUtil.getSchemaProperty("relationship_pgSecurityMember");
	String RELATIONSHIP_EBOMSUBSTITUTE = PropertyUtil.getSchemaProperty("relationship_EBOMSubstitute");
	String RELATIONSHIP_SHAREDCHARACTERISTIC = PropertyUtil.getSchemaProperty("relationship_SharedCharacteristic");
	String RELATIONSHIP_SUPPLYRESPONSIBILITY = PropertyUtil.getSchemaProperty("relationship_SupplyResponsibility");
	String RELATIONSHIP_PGIPMPGCONTACT = PropertyUtil.getSchemaProperty("relationship_pgIPMPGContact");
	String RELATIONSHIP_PROPERTIESTESTINGREQUIREMENTS = PropertyUtil
			.getSchemaProperty("relationship_PropertiesTestingRequirements");
	String RELATIONSHIP_PGSUPERSEDES = PropertyUtil.getSchemaProperty("relationship_pgSupersedes");
	String RELATIONSHIP_PGSECURITYASSETTOSECURITYGROUP = PropertyUtil
			.getSchemaProperty("relationship_pgSecurityAssetToSecurityGroup");
	String RELATIONSHIP_PGCSSORGANIZATION = PropertyUtil.getSchemaProperty("relationship_pgCSSOrganization");
	String RELATIONSHIP_PG_PLI_MATERIAL_CERTIFICATIONS = PropertyUtil
			.getSchemaProperty("relationship_pgPLIMaterialCertifications");
	String RELATIONSHIP_PGBUREGIONTOPLMREGION = PropertyUtil.getSchemaProperty("relationship_pgBURegiontoPLMRegion");
	String RELATIONSHIP_PGBUTOPLMCATEGORY = PropertyUtil.getSchemaProperty("relationship_pgBUToPLMCategory");
	String RELATIONSHIP_PGBUREGIONTOPLMAREA = PropertyUtil.getSchemaProperty("relationship_pgBURegiontoPLMArea");
	String RELATIONSHIP_PGPLMCATEGORYTOPLMSECTOR = PropertyUtil
			.getSchemaProperty("relationship_pgPLMCategorytoPLMSector");
	String RELATIONSHIP_PGPLMCATEGORYTOPLMSUBSECTOR = PropertyUtil
			.getSchemaProperty("relationship_pgPLMCategorytoPLMSubSector");
	String RELATIONSHIP_PGBRANDTOPLMCATEGORY = PropertyUtil.getSchemaProperty("relationship_pgBrandtoPLMCategory");
	String RELATIONSHIP_PGBRANDTOPGPLICSSBRAND = PropertyUtil.getSchemaProperty("relationship_pgBrandtopgPLICSSBrand");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIASSEMBLYTYPE = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIAssemblyType");
	String RELATIONSHIP_SUBCLASS = PropertyUtil.getSchemaProperty("relationship_Subclass");
	String RELATIONSHIP_PGPCHARSTOPGPLIRETESTINGUOM = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLIRetestingUOM");
	String RELATIONSHIP_PGPCHARSTOPGPLIPLANTTESTING = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLIPlantTesting");
	String RELATIONSHIP_PGPCHARSTOPGPLIMETHODORIGIN = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLIMethodOrigin");
	String RELATIONSHIP_PGPCHARSTOPGPLIREPORTTYPE = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLIReportType");
	String RELATIONSHIP_PGPCHARSTOPGPLICHANGE = PropertyUtil.getSchemaProperty("relationship_pgPCharstopgPLIChange");
	String RELATIONSHIP_PGPCHARSTOPGPLICHARACTERISTIC = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLICharacteristic");
	String RELATIONSHIP_PGPCHARSTOPGPLICHARACTERISTICSPECIFICS = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLICharacteristicSpecifics");
	String RELATIONSHIP_PGPCHARSTOPGPLIUNITOFMEASUREMASTERLIST = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLIUnitofMeasureMasterList");
	String RELATIONSHIP_PGPCHARSTOPGPLIACTIONREQUIRED = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLIActionRequired");
	String RELATIONSHIP_PGPCHARSTOPGPLICRITICALITYFACTOR = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLICriticalityFactor");
	String RELATIONSHIP_PGPCHARSTOPGPLITESTGROUP = PropertyUtil
			.getSchemaProperty("relationship_pgPCharstopgPLITestGroup");
	String RELATIONSHIP_DERIVED = PropertyUtil.getSchemaProperty("relationship_Derived");
	String RELATIONSHIP_DESIGNRESPONSIBILITY = PropertyUtil.getSchemaProperty("relationship_DesignResponsibility");
	String RELATIONSHIP_PARTFAMILYREFERENCE = PropertyUtil.getSchemaProperty("relationship_PartFamilyReference");
	String RELATIONSHIP_CLASSIFIEDITEM = PropertyUtil.getSchemaProperty("relationship_ClassifiedItem");
	String RELATIONSHIP_PGPDTEMPLATESTONETWEIGHTOFPRODUCTINCONSUMERUNITUOM = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestoNetWeightOfProductInConsumerUnitUoM");
	String RELATIONSHIP_PARTSPECIFICATION = PropertyUtil.getSchemaProperty("relationship_PartSpecification");
	String RELATIONSHIP_PGPDTEMPLSTESTOPGPLILIFECYCLESTATUS = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLILifeCycleStatus");
	String RELATIONSHIP_PGPDTEMPLATESTOPGBRAND = PropertyUtil.getSchemaProperty("relationship_pgPDTemplatestopgBrand");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIBUOM = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIBUOM");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLUNITSIZE = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIUnitSize");
	String RELATIONSHIP_ORIGINATINGTEMPLATE = PropertyUtil.getSchemaProperty("relationship_OriginatingTemplate");
	String RELATIONSHIP_AFFECTEDITEM = PropertyUtil.getSchemaProperty("relationship_AffectedItem");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIPRODUCTFORM = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIProductForm");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLICLASS = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIClass");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLISUBCLASS = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLISubClass");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIREPORTEDFUNCTION = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIReportedFunction");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIMATERIALTYPE = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIMaterialType");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLICOMPONENTTYPE = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIComponentType");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIPACKAGINGTECHNOLOGY = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIPackagingTechnology");
	String RELATIONSHIP_PGPDTEMPLATESTOGROSSWEIGHTUNITOFMEASURE = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestoGrossWeightUnitOfMeasure");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIBATTERYTYPE = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIBatteryType");
	String RELATIONSHIP_PGPDTEMPLATESTOPGMATERIALGROUP = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgMaterialGroup");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIBOMBASEQUANTITY = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIBOMBaseQuantity");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLICUSTOMIZATIONTYPE = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLICustomizationType");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIWAREHOUSINGCLASSIFICATION = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIWarehousingClassification");
	String RELATIONSHIP_COOWNED = PropertyUtil.getSchemaProperty("relationship_CoOwned");
	String RELATIONSHIP_REGIONOWNS = PropertyUtil.getSchemaProperty("relationship_RegionOwns");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLILANGUAGE = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLILanguage");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIPALLETTYPE = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIPalletType");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIUNITOFMEASUREVOLUMEAREA = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIUnitofMeasureVolumeArea");
	String RELATIONSHIP_PGTRANSPORTUNIT = PropertyUtil.getSchemaProperty("relationship_pgTransportUnit");
	String RELATIONSHIP_PGREGIONSHARED = PropertyUtil.getSchemaProperty("relationship_pgRegionShared");
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLIPRINTINGPROCESS = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLIPrintingProcess");
	String RELATIONSHIP_PGMATERIALTOCOMPANY = PropertyUtil.getSchemaProperty("relationship_pgMaterialToCompany");
	String RELATIONSHIP_PGEXTERNALBUSINESSPARTNERS = PropertyUtil
			.getSchemaProperty("relationship_pgExternalBusinessPartners");
	String ROLE_PGCONTRACTSUPPLIER = PropertyUtil.getSchemaProperty("role_pgIPMContractSupplier");
	String ROLE_PGCONTRACTPACKER = PropertyUtil.getSchemaProperty("role_pgIPMContractPacker");
	String ROLE_PGCONTRACTMANUFACTURER = PropertyUtil.getSchemaProperty("role_pgIPMContractManufacturer");
	String ROLE_PGPGCONTACT = PropertyUtil.getSchemaProperty("role_pgIPMPGContact");
	String ROLE_PGCURRENTUSERREGISTRAR = PropertyUtil.getSchemaProperty("role_pgCurrentUserRegistrar");
	String PERSON_USER_AGENT = PropertyUtil.getSchemaProperty("person_UserAgent");
	String EBP_USER_TABLE = "pgIPMPNGEBPUserTableForm";
	String TYPE_PGTRANSPORTUNITCHARACTERISTIC = PropertyUtil.getSchemaProperty("type_pgTransportUnitCharacteristic");
	String ATTRIBUTE_PGLEGACYFPC = PropertyUtil.getSchemaProperty("attribute_pgLegacyFPC");
	String ATTRIBUTE_PGRESTRICTREVISE = PropertyUtil.getSchemaProperty("attribute_pgRestrictRevise");
	String ATTRIBUTE_PGLEGACYGCAS = PropertyUtil.getSchemaProperty("attribute_pgLegacyGCAS");
	String ATTRIBUTE_PGFIRSTLEVELOBJECT = PropertyUtil.getSchemaProperty("attribute_pgFirstLevelObject");
	String SELECT_ATTRIBUTE_PGLEGACYFPC = "attribute[" + ATTRIBUTE_PGLEGACYFPC + "]";
	String SELECT_ATTRIBUTE_PGRESTRICTREVISE = "attribute[" + ATTRIBUTE_PGRESTRICTREVISE + "]";
	String SELECT_ATTRIBUTE_PGLEGACYGCAS = "attribute[" + ATTRIBUTE_PGLEGACYGCAS + "]";
	String SELECT_ATTRIBUTE_PGFIRSTLEVELOBJECT = "attribute[" + ATTRIBUTE_PGFIRSTLEVELOBJECT + "]";
	String RELATIONSHIP_EBOMHISTORY = PropertyUtil.getSchemaProperty("relationship_EBOMHistory");
	String RELATIONSHIP_PGEBOMSUBSTITUTEHISTORY = PropertyUtil
			.getSchemaProperty("relationship_pgEBOMSubstituteHistory");
	String XMLFILE = "xmlfile";
	String XMLSTRING = "xmlstring";
	String PSRA_APPROVAL_STATUS_NOT_APPROVED = "Not Approved";
	String PSRA_APPROVAL_STATUS_APPROVED = "Approved";
	String PSRA_APPROVAL_STATUS_REG_REQUIRED = "Registration Required";
	String REG_STATUS_IN_PROGRESS = "In Progress";
	String REG_STATUS_SUBMITTED_FOR_REG = "Submitted for Registration";
	String CLEARANCE_STATUS_CLEARED = "Cleared";
	String CLEARANCE_STATUS_CLEARED_WITH_RESTRICTIONS = "Cleared with Plant Restriction";
	String CLEARANCE_STATUS_NOT_CLEARED = "Not Cleared";
	String COUNTRY_CLEARANCE_NULL = "";
	String ATTRIBUTE_PGCTNUMBER = PropertyUtil.getSchemaProperty("attribute_pgCTNumber");
	String SELECT_ATTRIBUTE_PGCTNUMBER = "attribute[" + ATTRIBUTE_PGCTNUMBER + "]";
	String ATTRIBUTE_PGCLEARANCECOMMENT = PropertyUtil.getSchemaProperty("attribute_pgClearanceComment");
	String SELECT_ATTRIBUTE_PGCLEARANCECOMMENT = "attribute[" + ATTRIBUTE_PGCLEARANCECOMMENT + "]";
	String ATTRIBUTE_PGPLANTRESTRICTION = PropertyUtil.getSchemaProperty("attribute_pgPlantRestriction");
	String SELECT_ATTRIBUTE_PGPLANTRESTRICTION = "attribute[" + ATTRIBUTE_PGPLANTRESTRICTION + "]";
	String ATTRIBUTE_PGMODIFIEDDATE = PropertyUtil.getSchemaProperty("attribute_pgModifiedDate");
	String SELECT_ATTRIBUTE_PGMODIFIEDDATE = "attribute[" + ATTRIBUTE_PGMODIFIEDDATE + "]";
	String ATTRIBUTE_PGCREATEDDATE = PropertyUtil.getSchemaProperty("attribute_pgCreatedDate");
	String SELECT_ATTRIBUTE_PGCREATEDDATE = "attribute[" + ATTRIBUTE_PGCREATEDDATE + "]";
	String ATTRIBUTE_PGMODIFIEDBY = PropertyUtil.getSchemaProperty("attribute_pgModifiedBy");
	String SELECT_ATTRIBUTE_PGMODIFIEDBY = "attribute[" + ATTRIBUTE_PGMODIFIEDBY + "]";
	String ATTRIBUTE_PGOVERALLCLEARANCESTATUS = PropertyUtil.getSchemaProperty("attribute_pgOverallClearanceStatus");
	String SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS = "attribute[" + ATTRIBUTE_PGOVERALLCLEARANCESTATUS + "]";
	String ATTRIBUTE_PGREGISTRATIONSTATUS = PropertyUtil.getSchemaProperty("attribute_pgRegistrationStatus");
	String SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS = "attribute[" + ATTRIBUTE_PGREGISTRATIONSTATUS + "]";
	String ATTRIBUTE_PGREGISTRATIONENDDATE = PropertyUtil.getSchemaProperty("attribute_pgRegistrationEndDate");
	String SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE = "attribute[" + ATTRIBUTE_PGREGISTRATIONENDDATE + "]";
	String ATTRIBUTE_PGPSRAAPPROVALSTATUS = PropertyUtil.getSchemaProperty("attribute_pgPSRAApprovalStatus");
	String SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS = "attribute[" + ATTRIBUTE_PGPSRAAPPROVALSTATUS + "]";
	String RELATIONSHIP_PGFORMULATEDPRODUCTCOUNTRYCLEARANCE = PropertyUtil
			.getSchemaProperty("relationship_pgFormulatedProductCountryClearance");
	String RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE = PropertyUtil
			.getSchemaProperty("relationship_pgProductCountryClearance");
	String RELATIONSHIP_PGAAA_POATOCOUNTRY = PropertyUtil.getSchemaProperty("relationship_pgAAA_POAToCountry");
	String RELATIONSHIP_PGCOUNTRYOFSALEHISTORY = PropertyUtil.getSchemaProperty("relationship_pgCountryOfSaleHistory");
	String RELATIONSHIP_PGCOUNTRYOFSALE = PropertyUtil.getSchemaProperty("relationship_pgCountryOfSale");
	String TYPE_POA = PropertyUtil.getSchemaProperty("type_POA");
	String TYPE_COUNTRY = PropertyUtil.getSchemaProperty("type_Country");
	String TYPE_PGCOSHISTORY = PropertyUtil.getSchemaProperty("type_pgCOSHistory");
	String TYPE_PGPACKINGSUBASSEMBLY = PropertyUtil.getSchemaProperty("type_pgPackingSubassembly");
	String TYPE_PGASSEMBLEDPRODUCT = PropertyUtil.getSchemaProperty("type_pgAssembledProduct");
	String TYPE_PGAPPLIANCEPRODUCT = PropertyUtil.getSchemaProperty("type_pgApplianceProduct");
	String TYPE_CADDRAWING = PropertyUtil.getSchemaProperty("type_CADDrawing");
	String TYPE_CADMODEL = PropertyUtil.getSchemaProperty("type_CADModel");
	String POLICY_PGCOSHISTORY = PropertyUtil.getSchemaProperty("policy_pgCOSHistory");
	String COUNTRY_APPROVED_RESPONSE_GCAS_ERROR = "Error: Not an Artwork!";
	String COUNTRY_APPROVED_RESPONSE_COUNTRY_ERROR = "Error: Some Countries not available!";
	String COUNTRY_APPROVED_RESPONSE_SUCCESS = "Added Approved Countries.";
	String ATTRIBUTE_PGCHANGEDETAIL = PropertyUtil.getSchemaProperty("attribute_pgChangeDetail");
	String ATTRIBUTE_PGCOUNTRYNAME = PropertyUtil.getSchemaProperty("attribute_pgCountryName");
	String ATTRIBUTE_PGCOSRESTRICTION = PropertyUtil.getSchemaProperty("attribute_pgCOSRestriction");
	String ATTRIBUTE_PGSUBTYPE = PropertyUtil.getSchemaProperty("attribute_pgSubType");
	String ATTRIBUTE_PRODUCTDATA_FORMNAME = PropertyUtil.getSchemaProperty("attribute_ProductDataViewFormName");
	String ATTRIBUTE_PGCOSRUNDATE = PropertyUtil.getSchemaProperty("attribute_pgCOSRunDate");
	String ATTRIBUTE_PGCOSRUNHISTORY = PropertyUtil.getSchemaProperty("attribute_pgCOSRunHistory");
	String ATTRIBUTE_PGCOSCALCULATE = PropertyUtil.getSchemaProperty("attribute_pgCOSCalculate");
	String ATTRIBUTE_PGCOSCALCULATE_TRUE = "True";
	String ATTRIBUTE_PGCOSCALCULATE_FALSE = "False";
	String SELECT_LAST_LAST = "last.last";
	String SELECT_LAST_CURRENT = "last.current";
	String ATTRIBUTE_PGEPADEXSIGNATURENAMES = PropertyUtil.getSchemaProperty("attribute_pgEPADExSignatureNames");
	String ATTRIBUTE_PGEPADEXSIGNATUREDATES = PropertyUtil.getSchemaProperty("attribute_pgEPADExSignatureDates");
	String ATTRIBUTE_PGLASTUPDATEUSER = PropertyUtil.getSchemaProperty("attribute_pgLastUpdateUser");
	String TYPE_PGPACKINGUNITCHARACTERISTIC = PropertyUtil.getSchemaProperty("type_pgPackingUnitCharacteristic");
	String SELECT_LAST_ID = "last.id";
	String ATTRIBUTE_PGBATTERYTYPE = PropertyUtil.getSchemaProperty("attribute_pgBatteryType");
	String ATTRIBUTE_PGBRANDINFORMATION = PropertyUtil.getSchemaProperty("attribute_pgBrandInformation");
	String ATTRIBUTE_PGISBATTERY = PropertyUtil.getSchemaProperty("attribute_pgIsBattery");
	String ATTRIBUTE_PGPRODUCTEXTRAVARIANT = PropertyUtil.getSchemaProperty("attribute_pgProductExtraVariant");
	String ATTRIBUTE_PGCONTAINSBATTERY = PropertyUtil.getSchemaProperty("attribute_pgContainsBattery");
	String ATTRIBUTE_PGCUSTOMIZATIONTYPE = PropertyUtil.getSchemaProperty("attribute_pgCustomizationType");
	String ATTRIBUTE_PGLABELINGINFORMATION = PropertyUtil.getSchemaProperty("attribute_pgLabelingInformation");
	String ATTRIBUTE_PGMARKETINGSIZE = PropertyUtil.getSchemaProperty("attribute_pgMarketingSize");
	String ATTRIBUTE_PGPACKAGINGTECHNOLOGY = PropertyUtil.getSchemaProperty("attribute_pgPackagingTechnology");
	String ATTRIBUTE_PGPRODUCTFORM = PropertyUtil.getSchemaProperty("attribute_pgProductForm");
	String ATTRIBUTE_PGSHIPPINGINSTRUCTIONS = PropertyUtil.getSchemaProperty("attribute_pgShippingInstructions");
	String ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS = PropertyUtil.getSchemaProperty("attribute_pgStorageHumidityLimits");
	String ATTRIBUTE_PGSTORAGEINFORMATION = PropertyUtil.getSchemaProperty("attribute_pgStorageInformation");
	String ATTRIBUTE_PGSTORAGETEMPERATURELIMITS = PropertyUtil
			.getSchemaProperty("attribute_pgStorageTemperatureLimits");
	String ATTRIBUTE_PGWAREHOUSECLASIFICATION = PropertyUtil.getSchemaProperty("attribute_pgWarehousingClassification");
	String ATTRIBUTE_PGWDSTATIUS = PropertyUtil.getSchemaProperty("attribute_pgWDStatius");
	String SELECT_ATTRIBUTE_PGWDSTATIUS = "attribute[" + ATTRIBUTE_PGWDSTATIUS + "]";
	String ATTRIBUTE_RENDERLANGUAGE = PropertyUtil.getSchemaProperty("attribute_RenderLanguage");
	String ATTRIBUTE_PGBRAND = PropertyUtil.getSchemaProperty("attribute_pgBrand");
	String ATTRIBUTE_PGSUBBRAND = PropertyUtil.getSchemaProperty("attribute_pgSubBrand");
	String ATTRIBUTE_PGGLOBALFORM = PropertyUtil.getSchemaProperty("attribute_pgGlobalForm");
	String ATTRIBUTE_PGPHCATEGORY = PropertyUtil.getSchemaProperty("attribute_pgPHCategory");
	String ATTRIBUTE_PGUNITOFMEASURESYSTEM = PropertyUtil.getSchemaProperty("attribute_pgUnitOfMeasureSystem");
	String SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM = "attribute[" + ATTRIBUTE_PGUNITOFMEASURESYSTEM + "]";
	String ATTRIBUTE_PGASLALLOCATION = PropertyUtil.getSchemaProperty("attribute_pgASLAllocation");
	String ATTRIBUTE_SECURITYCLASIFICATION = PropertyUtil.getSchemaProperty("attribute_SecurityClassification");
	String ATTRIBUTE_PGQUANTITYOFPRODUCTIS = PropertyUtil.getSchemaProperty("attribute_pgQuantityForProductIs");
	String ATTRIBUTE_PGPRODUCTFORMDETAIL = PropertyUtil.getSchemaProperty("attribute_pgProductFormDetail");
	String SELECT_ATTRIBUTE_PGBRANDINFORMATION = "attribute[" + ATTRIBUTE_PGBRANDINFORMATION + "]";
	String ATTRIBUTE_PGCONFIGCOMMON_COSISACTIVE = PropertyUtil.getSchemaProperty("attribute_pgConfigCommonCOSIsActive");
	String ATTRIBUTE_PGCONFIGCOMMON_COSRETRYCOUNT = PropertyUtil
			.getSchemaProperty("attribute_pgConfigCommonCOSRetryCount");
	String ATTRIBUTE_PGCONFIGCOMMON_COSADMINMAILID = PropertyUtil
			.getSchemaProperty("attribute_pgConfigCommonCOSAdminMailId");
	String ATTRIBUTE_PGCONFIGCOMMON_ATTR = PropertyUtil.getSchemaProperty("attribute_pgConfigCommonAttr");
	String ATTRIBUTE_PGCOSWIP = PropertyUtil.getSchemaProperty("attribute_pgCOSWIP");
	String SELECT_ATTRIBUTE_PGCONFIGCOMMON_COSISACTIVE = "attribute[" + ATTRIBUTE_PGCONFIGCOMMON_COSISACTIVE + "]";
	String SELECT_ATTRIBUTE_PGCONFIGCOMMON_COSRETRYCOUNT = "attribute[" + ATTRIBUTE_PGCONFIGCOMMON_COSRETRYCOUNT + "]";
	String SELECT_ATTRIBUTE_PGCONFIGCOMMON_COSADMINMAILID = "attribute[" + ATTRIBUTE_PGCONFIGCOMMON_COSADMINMAILID
			+ "]";
	String SELECT_ATTRIBUTE_PGCONFIGCOMMON_ATTR = "attribute[" + ATTRIBUTE_PGCONFIGCOMMON_ATTR + "]";
	String SELECT_ATTRIBUTE_PGCOSWIP = "attribute[" + ATTRIBUTE_PGCOSWIP + "]";
	String ATTRIBUTE_PGINCLUDEINCOS = PropertyUtil.getSchemaProperty("attribute_pgIncludeInCOS");
	String SELECT_ATTRIBUTE_PGINCLUDEINCOS = "attribute[" + ATTRIBUTE_PGINCLUDEINCOS + "]";
	String ATTRIBUTE_PGMATERIALFUNCTION = PropertyUtil.getSchemaProperty("attribute_pgMaterialFunction");
	String SELECT_ATTRIBUTE_PGMATERIALFUNCTION = "attribute[" + ATTRIBUTE_PGMATERIALFUNCTION + "]";
	String ATTRIBUTE_PGCHANGE = PropertyUtil.getSchemaProperty("attribute_pgChange");
	String SELECT_ATTRIBUTE_PGCHANGE = "attribute[" + ATTRIBUTE_PGCHANGE + "]";
	String ATTRIBUTE_PGPCLTRACKINGCODE = PropertyUtil.getSchemaProperty("attribute_pgPCLTrackingCode");
	String SELECT_ATTRIBUTE_PGPCLTRACKINGCODE = "attribute[" + ATTRIBUTE_PGPCLTRACKINGCODE + "]";
	String ATTRIBUTE_PGPCLDESCRIPTION = PropertyUtil.getSchemaProperty("attribute_pgPCLDescription");
	String SELECT_ATTRIBUTE_PGPCLDESCRIPTION = "attribute[" + ATTRIBUTE_PGPCLDESCRIPTION + "]";
	String ATTRIBUTE_PGPCLQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgPCLQuantity");
	String SELECT_ATTRIBUTE_PGPCLQUANTITY = "attribute[" + ATTRIBUTE_PGPCLQUANTITY + "]";
	String ATTRIBUTE_PGPCLUOM = PropertyUtil.getSchemaProperty("attribute_pgPCLUOM");
	String SELECT_ATTRIBUTE_PGPCLUOM = "attribute[" + ATTRIBUTE_PGPCLUOM + "]";
	String RELATIONSHIP_PGPRODUCTCOMPOSITION = PropertyUtil.getSchemaProperty("relationship_pgProductComposition");
	String ATTRIBUTE_PGDSALLOWEDTYPESFORCM = PropertyUtil.getSchemaProperty("attribute_pgDSAllowedTypesForCM");
	String SELECT_ATTRIBUTE_PGDSALLOWEDTYPESFORCM = "attribute[" + ATTRIBUTE_PGDSALLOWEDTYPESFORCM + "]";
	String ATTRIBUTE_PGDSALLOWEDTYPESFORSUPPLIER = PropertyUtil
			.getSchemaProperty("attribute_pgDSAllowedTypesForSupplier");
	String SELECT_ATTRIBUTE_PGDSALLOWEDTYPESFORSUPPLIER = "attribute[" + ATTRIBUTE_PGDSALLOWEDTYPESFORSUPPLIER + "]";
	String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONREGION = PropertyUtil
			.getSchemaProperty("attribute_pgDynamicSubscriptionRegion");
	String SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONREGION = "attribute[" + ATTRIBUTE_PGDYNAMICSUBSCRIPTIONREGION + "]";
	String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONSEGMENT = PropertyUtil
			.getSchemaProperty("attribute_pgDynamicSubscriptionSegment");
	String SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONSEGMENT = "attribute[" + ATTRIBUTE_PGDYNAMICSUBSCRIPTIONSEGMENT + "]";
	String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONMATERIALGROUP = PropertyUtil
			.getSchemaProperty("attribute_pgDynamicSubscriptionMaterialGroup");
	String SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONMATERIALGROUP = "attribute["
			+ ATTRIBUTE_PGDYNAMICSUBSCRIPTIONMATERIALGROUP + "]";
	String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONBRAND = PropertyUtil
			.getSchemaProperty("attribute_pgDynamicSubscriptionBrand");
	String SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONBRAND = "attribute[" + ATTRIBUTE_PGDYNAMICSUBSCRIPTIONBRAND + "]";
	String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONCATEGORY = PropertyUtil
			.getSchemaProperty("attribute_pgDynamicSubscriptionCategory");
	String SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONCATEGORY = "attribute[" + ATTRIBUTE_PGDYNAMICSUBSCRIPTIONCATEGORY
			+ "]";
	String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONLIFECYCLE = PropertyUtil
			.getSchemaProperty("attribute_pgDynamicSubscriptionLifecycle");
	String SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONLIFECYCLE = "attribute[" + ATTRIBUTE_PGDYNAMICSUBSCRIPTIONLIFECYCLE
			+ "]";
	String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPLANT = PropertyUtil
			.getSchemaProperty("attribute_pgDynamicSubscriptionPlant");
	String SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPLANT = "attribute[" + ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPLANT + "]";
	String ATTRIBUTE_PGFTPROOTFOLDERPATHGENDOC = PropertyUtil.getSchemaProperty("attribute_pgFTPRootFolderPathGenDoc");
	String ATTRIBUTE_PGDTDFILEGENDOC = PropertyUtil.getSchemaProperty("attribute_pgDTDFileGenDoc");
	String ATTRIBUTE_PGFTPINPUTFOLDERPATHGENDOC = PropertyUtil
			.getSchemaProperty("attribute_pgFTPInputFolderPathGenDoc");
	String ATTRIBUTE_PGFTPOUTPUTFOLDERPATHGENDOC = PropertyUtil
			.getSchemaProperty("attribute_pgFTPOutputFolderPathGenDoc");
	String ATTRIBUTE_PGRENDERPDFGENDOC = PropertyUtil.getSchemaProperty("attribute_pgRenderPDFGenDoc");
	String ATTRIBUTE_PGPORTGENDOC = PropertyUtil.getSchemaProperty("attribute_pgPortGenDoc");
	String ATTRIBUTE_PGPROTOCOLGENDOC = PropertyUtil.getSchemaProperty("attribute_pgProtocolGenDoc");
	String ATTRIBUTE_PGHOSTNAMEGENDOC = PropertyUtil.getSchemaProperty("attribute_pgHostNameGenDoc");
	String ATTRIBUTE_PGADLIBUSERNAMEGENDOC = PropertyUtil.getSchemaProperty("attribute_pgAdlibUserNameGenDoc");
	String ATTRIBUTE_PGADLIBPASSWORDGENDOC = PropertyUtil.getSchemaProperty("attribute_pgAdlibPasswordGenDoc");
	String TYPE_FABRICATEDPART = PropertyUtil.getSchemaProperty("type_pgFabricatedPart");
	String TYPE_SUPPLIEREQUIVALENTPART = PropertyUtil.getSchemaProperty("type_SupplierEquivalentPart");
	String TYPE_PRODUCTDATAPART = PropertyUtil.getSchemaProperty("type_ProductDataPart");
	String TYPE_PGPKGTRANSLATIONFILE = PropertyUtil.getSchemaProperty("type_pgPKGTranslationFile");
	String TYPE_MATERIAL = PropertyUtil.getSchemaProperty("type_Material");
	String TYPE_PGPLIORGANIZATION = PropertyUtil.getSchemaProperty("type_pgPLIOrganization");
	String TYPE_PGPLIORGANIZATIONCHANGEMANAGEMENT = PropertyUtil
			.getSchemaProperty("type_pgPLIOrganizationChangeManagement");
	String TYPE_COMPANY = PropertyUtil.getSchemaProperty("type_Company");
	String POLICY_MANUFACTUREREQUIVALENT = PropertyUtil.getSchemaProperty("policy_ManufacturerEquivalent");
	String POLICY_SUPPLIEREQUIVALENT = PropertyUtil.getSchemaProperty("policy_SupplierEquivalent");
	String RELATIONSHIP_MANUFACTUREREQUIVALENT = PropertyUtil.getSchemaProperty("relationship_ManufacturerEquivalent");
	String RELATIONSHIP_SUPPLIEREQUIVALENT = PropertyUtil.getSchemaProperty("relationship_SupplierEquivalent");
	String RELATIONSHIP_MEMBER = PropertyUtil.getSchemaProperty("relationship_Member");
	String RELATIONSHIP_MANUFACTURINGLOCATION = PropertyUtil.getSchemaProperty("relationship_ManufacturingLocation");
	String RELATIONSHIP_COMPONENTMATERIAL = PropertyUtil.getSchemaProperty("relationship_ComponentMaterial");
	String RELATIONSHIP_PGPRIMARYORGANIZATION = PropertyUtil.getSchemaProperty("relationship_pgPrimaryOrganization");
	String RELATIONSHIP_PGSECONDARYORGANIZATION = PropertyUtil
			.getSchemaProperty("relationship_pgSecondaryOrganization");
	String ROLE_ARTWORK_PROJECT_MANAGER = PropertyUtil.getSchemaProperty("role_ArtworkProjectManager");
	String ROLE_IPMWAREHOUSEREADER = PropertyUtil.getSchemaProperty("role_pgIPMWarehouseReader");
	String ATTRIBUTE_PGEXTEVENTFORDAILYSUBSCRIPTION = PropertyUtil
			.getSchemaProperty("attribute_pgExternalEventForDailySubscription");
	String SELECT_ATTRIBUTE_PGEXTEVENTFORDAILYSUBSCRIPTION = "attribute[" + ATTRIBUTE_PGEXTEVENTFORDAILYSUBSCRIPTION
			+ "]";
	String ATTRIBUTE_PGCONFIGCOMMON_STATUS = PropertyUtil.getSchemaProperty("attribute_pgIPMEBPCronStatus");
	String SELECT_ATTRIBUTE_PGCONFIGCOMMON_STATUS = "attribute[" + ATTRIBUTE_PGCONFIGCOMMON_STATUS + "]";
	String ATTRIBUTE_PGCONFIGCOMMON_TIMESTAMP = PropertyUtil.getSchemaProperty("attribute_pgIPMEBPCronTimeStamp");
	String SELECT_ATTRIBUTE_PGCONFIGCOMMON_TIMESTAMP = "attribute[" + ATTRIBUTE_PGCONFIGCOMMON_TIMESTAMP + "]";
	String ATTRIBUTE_PGIPMCONNECTION_SUMMARY = PropertyUtil.getSchemaProperty("attribute_pgIPMConnectionSummary");
	String SELECT_ATTRIBUTE_PGIPMCONNECTION_SUMMARY = "attribute[" + ATTRIBUTE_PGIPMCONNECTION_SUMMARY + "]";
	String ATTRIBUTE_DAILY_MANUFACTURER_PACKER_EVENT = PropertyUtil
			.getSchemaProperty("attribute_DailyManufacturerPackerEvent");
	String SELECT_ATTRIBUTE_DAILY_MANUFACTURER_PACKER_EVENT = "attribute[" + ATTRIBUTE_DAILY_MANUFACTURER_PACKER_EVENT
			+ "]";
	String ATTRIBUTE_NEXT_MANUFACTURER_PACKER_EVENT = PropertyUtil
			.getSchemaProperty("attribute_NextManufacturerPackerEvent");
	String SELECT_ATTRIBUTE_NEXT_MANUFACTURER_PACKER_EVENT = "attribute[" + ATTRIBUTE_NEXT_MANUFACTURER_PACKER_EVENT
			+ "]";
	String ATTRIBUTE_DAILY_SUPPLIER_EVENT = PropertyUtil
			.getSchemaProperty("attribute_pgExternalEventForDailySubscription");
	String SELECT_ATTRIBUTE_DAILY_SUPPLIER_EVENT = "attribute[" + ATTRIBUTE_DAILY_SUPPLIER_EVENT + "]";
	String ATTRIBUTE_NEXT_SUPPLIER_EVENT = PropertyUtil.getSchemaProperty("attribute_NextSupplierEvent");
	String SELECT_ATTRIBUTE_NEXT_SUPPLIER_EVENT = "attribute[" + ATTRIBUTE_NEXT_SUPPLIER_EVENT + "]";
	String ATTRIBUTE_MANUFACTURER_PACKER_JOB_SUBSCRIPTION_STATUS = PropertyUtil
			.getSchemaProperty("attribute_ManufacturerPackerJobSubscriptionStatus");
	String SELECT_ATTRIBUTE_MANUFACTURER_PACKER_JOB_SUBSCRIPTION_STATUS = "attribute["
			+ ATTRIBUTE_MANUFACTURER_PACKER_JOB_SUBSCRIPTION_STATUS + "]";
	String ATTRIBUTE_SUPPLIER_JOB_SUBSCRIPTION_STATUS = PropertyUtil
			.getSchemaProperty("attribute_SupplierJobSubscriptionStatus");
	String SELECT_ATTRIBUTE_SUPPLIER_JOB_SUBSCRIPTION_STATUS = "attribute[" + ATTRIBUTE_SUPPLIER_JOB_SUBSCRIPTION_STATUS
			+ "]";
	String ATTRIBUTE_MANUFACTURER_PACKER_CRONJOBRUNNINGSTATUS = PropertyUtil
			.getSchemaProperty("attribute_ManufacturerPackerCronJobExecutionSubscriptionStatus");
	String SELECT_ATTRIBUTE_MANUFACTURER_PACKER_CRONJOBRUNNINGSTATUS = "attribute["
			+ ATTRIBUTE_MANUFACTURER_PACKER_CRONJOBRUNNINGSTATUS + "]";
	String ATTRIBUTE_SUPPLIERCRONJOBRUNNINGSTATUS = PropertyUtil
			.getSchemaProperty("attribute_SupplierCronJobExecutionSubscriptionStatus");
	String SELECT_ATTRIBUTE_SUPPLIERCRONJOBRUNNINGSTATUS = "attribute[" + ATTRIBUTE_SUPPLIERCRONJOBRUNNINGSTATUS + "]";
	String ATTRIBUTE_PGEBPSUMMARY_HISTORY = PropertyUtil.getSchemaProperty("attribute_pgIPMEBPSummaryHistory");
	String SELECT_ATTRIBUTE_PGEBPSUMMARY_HISTORY = "attribute[" + ATTRIBUTE_PGEBPSUMMARY_HISTORY + "]";
	String ATTRIBUTE_MANUFACTURER_PACKER_LATESTSUBSCRIPTIONGENERATEDDATE = PropertyUtil
			.getSchemaProperty("attribute_ManufacturerPackerLatestSubscriptionGeneratedDate");
	String SELECT_ATTRIBUTE_MANUFACTURER_PACKER_LATESTSUBSCRIPTIONGENERATEDDATE = "attribute["
			+ ATTRIBUTE_MANUFACTURER_PACKER_LATESTSUBSCRIPTIONGENERATEDDATE + "]";
	String ATTRIBUTE_SUPPLIERLATESTSUBSCRIPTIONGENERATEDDATE = PropertyUtil
			.getSchemaProperty("attribute_SupplierLatestSubscriptionGeneratedDate");
	String SELECT_ATTRIBUTE_SUPPLIERLATESTSUBSCRIPTIONGENERATEDDATE = "attribute["
			+ ATTRIBUTE_SUPPLIERLATESTSUBSCRIPTIONGENERATEDDATE + "]";
	String ATTRIBUTE_MANUFACTURER_PACKER_LATESTWEEKLYSUBSCRIPTIONDATE = PropertyUtil
			.getSchemaProperty("attribute_ManufacturerPackerLatestWeeklySubscriptionDate");
	String SELECT_ATTRIBUTE_MANUFACTURER_PACKER_LATESTWEEKLYSUBSCRIPTIONDATE = "attribute["
			+ ATTRIBUTE_MANUFACTURER_PACKER_LATESTWEEKLYSUBSCRIPTIONDATE + "]";
	String ATTRIBUTE_PGEVENTFORDAILYSUBSCRIPTION_HISTORY = PropertyUtil
			.getSchemaProperty("attribute_pgEventForDailySubscriptionHistory");
	String SELECT_ATTRIBUTE_PGEVENTFORDAILYSUBSCRIPTION_HISTORY = "attribute["
			+ ATTRIBUTE_PGEVENTFORDAILYSUBSCRIPTION_HISTORY + "]";
	String ATTRIBUTE_EXPIRATION_DATE = PropertyUtil.getSchemaProperty("attribute_ExpirationDate");
	String SELECT_ATTRIBUTE_EXPIRATION_DATE = "attribute[" + ATTRIBUTE_EXPIRATION_DATE + "]";
	String ATTRIBUTE_REASON_FOR_CHANGE = PropertyUtil.getSchemaProperty("attribute_ReasonforChange");
	String SELECT_ATTRIBUTE_REASON_FOR_CHANGE = "attribute[" + ATTRIBUTE_REASON_FOR_CHANGE + "]";
	String ATTRIBUTE_CPNPRODUCTDATATYPE = PropertyUtil.getSchemaProperty("attribute_CPNProductDataType");
	String SELECT_ATTRIBUTE_CPNPRODUCTDATATYPE = "attribute[" + ATTRIBUTE_CPNPRODUCTDATATYPE + "]";
	String ATTRIBUTE_RELEASE_DATE = PropertyUtil.getSchemaProperty("attribute_ReleaseDate");
	String SELECT_ATTRIBUTE_RELEASE_DATE = "attribute[" + ATTRIBUTE_RELEASE_DATE + "]";
	String ATTRIBUTE_PGCOSFLAGDATE = PropertyUtil.getSchemaProperty("attribute_pgCOSFlagDate");
	String SELECT_ATTRIBUTE_PGCOSFLAGDATE = "attribute[" + ATTRIBUTE_PGCOSFLAGDATE + "]";
	String ATTRIBUTE_PGDSALLOWEDTYPESFORCMSUPPLIER = PropertyUtil
			.getSchemaProperty("attribute_pgDSAllowedTypesForCMAndSupplier");
	String SELECT_ATTRIBUTE_PGDSALLOWEDTYPESFORCMSUPPLIER = "attribute[" + ATTRIBUTE_PGDSALLOWEDTYPESFORCMSUPPLIER
			+ "]";
	String ATTRIBUTE_PGDSALLOWEDWDATTRIBUTE = PropertyUtil.getSchemaProperty("attribute_pgDSAllowedWDAttribute");
	String SELECT_ATTRIBUTE_PGDSALLOWEDWDATTRIBUTE = "attribute[" + ATTRIBUTE_PGDSALLOWEDWDATTRIBUTE + "]";
	String ATTRIBUTE_PGIPMCONNECTION_SUMMARY_MARK_OBSOLETE = PropertyUtil
			.getSchemaProperty("attribute_pgIPMConnectionSummaryMarkObsolete");
	String SELECT_ATTRIBUTE_PGIPMCONNECTION_SUMMARY_MARK_OBSOLETE = "attribute["
			+ ATTRIBUTE_PGIPMCONNECTION_SUMMARY_MARK_OBSOLETE + "]";
	String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONEXPIRATIONDATE = PropertyUtil
			.getSchemaProperty("attribute_pgDynamicSubscriptionExpirationDate");
	String SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONEXPIRATIONDATE = "attribute["
			+ ATTRIBUTE_PGDYNAMICSUBSCRIPTIONEXPIRATIONDATE + "]";
	String ATTRIBUTE_PGIPMCONNECTIONSUMMARY_MARK_PLANT = PropertyUtil
			.getSchemaProperty("attribute_pgIPMConnectionSummaryMarkPlant");
	String ATTRIBUTE_PGIPMCONNECTIONSUMMARY_PLANT = PropertyUtil
			.getSchemaProperty("attribute_pgIPMConnectionSummaryPlant");
	String ATTRIBUTE_PGIPMCONNECTIONSUMMARY_SUPPLIER = PropertyUtil
			.getSchemaProperty("attribute_pgIPMConnectionSummarySupplier");
	String ATTRIBUTE_PGIPMCONNECTIONSUMMARY_MARK_SUPPLIER = PropertyUtil
			.getSchemaProperty("attribute_pgIPMConnectionSummaryMarkSupplier");
	String ATTRIBUTE_PGIPMCONNECTIONSUMMARY_MARK = PropertyUtil
			.getSchemaProperty("attribute_pgIPMConnectionSummaryMark");
	String SELECT_ATTRIBUTE_PGIPMCONNECTIONSUMMARY_MARK_PLANT = "attribute["
			+ ATTRIBUTE_PGIPMCONNECTIONSUMMARY_MARK_PLANT + "]";
	String SELECT_ATTRIBUTE_PGIPMCONNECTIONSUMMARY_PLANT = "attribute[" + ATTRIBUTE_PGIPMCONNECTIONSUMMARY_PLANT + "]";
	String SELECT_ATTRIBUTE_PGIPMCONNECTIONSUMMARY_SUPPLIER = "attribute[" + ATTRIBUTE_PGIPMCONNECTIONSUMMARY_SUPPLIER
			+ "]";
	String SELECT_ATTRIBUTE_PGIPMCONNECTIONSUMMARY_MARK_SUPPLIER = "attribute["
			+ ATTRIBUTE_PGIPMCONNECTIONSUMMARY_MARK_SUPPLIER + "]";
	String SELECT_ATTRIBUTE_PGIPMCONNECTIONSUMMARY_MARK = "attribute[" + ATTRIBUTE_PGIPMCONNECTIONSUMMARY_MARK + "]";
	String ATTRIBUTE_PGMANUFACTURERVENDORNUMBER = PropertyUtil
			.getSchemaProperty("attribute_pgManufacturerVendorNumber");
	String SELECT_ATTRIBUTE_PGMANUFACTURERVENDORNUMBER = "attribute[" + ATTRIBUTE_PGMANUFACTURERVENDORNUMBER + "]";
	String ATTRIBUTE_ADDRESS1 = PropertyUtil.getSchemaProperty("attribute_Address1");
	String SELECT_ATTRIBUTE_ADDRESS1 = "attribute[" + ATTRIBUTE_ADDRESS1 + "]";
	String ATTRIBUTE_ADDRESS2 = PropertyUtil.getSchemaProperty("attribute_Address2");
	String SELECT_ATTRIBUTE_ADDRESS2 = "attribute[" + ATTRIBUTE_ADDRESS2 + "]";
	String ATTRIBUTE_ISRESTRICTED = PropertyUtil.getSchemaProperty("attribute_IsRestricted");
	String SELECT_ATTRIBUTE_ISRESTRICTED = "attribute[" + ATTRIBUTE_ISRESTRICTED + "]";
	String ATTRIBUTE_PGIPCLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pgIPClassification");
	String SELECT_ATTRIBUTE_PGIPCLASSIFICATION = "attribute[" + ATTRIBUTE_PGIPCLASSIFICATION + "]";
	String ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONRETRYCOUNTMANUFACTURER = PropertyUtil
			.getSchemaProperty("attribute_pgIPMDynamicSubscriptionCronRetryCountManufacturer");
	String SELECT_ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONRETRYCOUNTMANUFACTURER = "attribute["
			+ ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONRETRYCOUNTMANUFACTURER + "]";
	String ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONRETRYCOUNTSUPPLIER = PropertyUtil
			.getSchemaProperty("attribute_pgIPMDynamicSubscriptionCronRetryCountSupplier");
	String SELECT_ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONRETRYCOUNTSUPPLIER = "attribute["
			+ ATTRIBUTE_PGIPMDYNAMICSUBSCRIPTIONCRONRETRYCOUNTSUPPLIER + "]";
	String ATTRIBUTE_COMMENTS = PropertyUtil.getSchemaProperty("attribute_Comments");
	String SELECT_ATTRIBUTE_COMMENTS = "attribute[" + ATTRIBUTE_COMMENTS + "]";
	String ATTRIBUTE_ISSUEDDATE = PropertyUtil.getSchemaProperty("attribute_IssuedDate");
	String SELECT_ATTRIBUTE_ISSUEDDATE = "attribute[" + ATTRIBUTE_ISSUEDDATE + "]";
	String ATTRIBUTE_PGTYPEMAPPING = PropertyUtil.getSchemaProperty("attribute_pgTypeMapping");
	String SELECT_ATTRIBUTE_PGTYPEMAPPING = "attribute[" + ATTRIBUTE_PGTYPEMAPPING + "]";
	String ATTRIBUTE_CPNMANUFACTURERADDEDFORDAILYSUBSCRIPTION = PropertyUtil
			.getSchemaProperty("attribute_CPNManufacturerAddedForDailySubscription");
	String SELECT_ATTRIBUTE_CPNMANUFACTURERADDEDFORDAILYSUBSCRIPTION = "attribute["
			+ ATTRIBUTE_CPNMANUFACTURERADDEDFORDAILYSUBSCRIPTION + "]";
	String FIRST_LEVEL_FOR_PLANT = "pgAncillaryPackagingMaterialPart,pgAuthorizedTemporarySpecification,pgConsumerUnitPart,pgFabricatedPart,pgCustomerUnitPart,pgFormulatedProduct,pgFinishedProduct,Finished Product Part,pgInnerPackUnitPart,pgPackingMaterial,pgRawMaterial,pgMakingInstructions,Packaging Assembly Part,pgPromotionalItemPart,Packaging Material Part,pgPackingSubassembly,pgStandardOperatingProcedure,pgOnlinePrintingPart";
	String FIRST_LEVEL_FOR_SUPPLIER = "pgAncillaryPackagingMaterialPart,pgAuthorizedTemporarySpecification,pgFabricatedPart,pgPackingMaterial,pgRawMaterial,pgOnlinePrintingPart,Packaging Assembly Part,pgPromotionalItemPart,Packaging Material Part,pgPackingSubassembly,pgSupplierInformationSheet,pgStandardOperatingProcedure";
	String TABLE_PGIPMEBPUSERNOTIFICATIONTABLE = "pgIPMEBPUserNotificationTable";
	String TABLE_CPNIPMUSERNOTIFICATIONTABLE = "CPNIPMUserNotificationTable";
	String SEP_MEP_ALLOWEDTYPES = "Packaging Material Part,Packaging Assembly Part,pgFabricatedPart,pgOnlinePrintingPart,pgAncillaryPackagingMaterialPart,pgPromotionalItemPart,Raw Material,pgAncillaryRawMaterialPart,pgRawMaterial,pgSoftwarePart,pgAssembledProductPart,pgDeviceProductPart,pgIntermediateProductPart";
	String USER_MATERIAL_SUBJECT = "User Material Status by Company";
	String ATTRIBUTE_EFFECTIVITYDATE = PropertyUtil.getSchemaProperty("attribute_EffectivityDate");
	String SELECT_ATTRIBUTE_EFFECTIVITYDATE = "attribute[" + ATTRIBUTE_EFFECTIVITYDATE + "]";
	String USER_MATERIAL_STATUS = "UserMaterialStatus";
	String ROW_INFO = "RowInfo";
	String USER_MATERIAL_XML = "pgIPMUserMaterialStatusReportbyCompany.xml";
	String USER_MATERIAL_XSL = "pgIPMUserMaterialStatusReportbyCompany.xsl";
	String USER_MATERIAL_CSV = "pgIPMUserMaterialStatusReportbyCompany.csv";
	String GLOBAL_SUB_NAME = "Global Subscription Object";
	String PGV3CONFIGURATIONMAPPING = "pgV3ConfigurationMapping";
	String PGTYPEMAPPING = "pgTypeMapping";
	String CSS_SOURCE = "CSS";
	String INTERNAL = "Internal";
	String MANUFACTURER = "Manufacturer";
	String SUPPLIER = "Supplier";
	String SYMBOL_HYPHEN = "-";
	String USERMATERIALSTATUSCOMPANY = "pgIPMUserMaterialStatusReportbyCompany";
	String STATE_OBSOLETE = "Obsolete";
	String DEFAULT_ACCESS = "read,show,checkout";
	String COMPANY_EXTERNALSUPPLIER = "pgIPMExternalSuppliers";
	String COMPANY_EXTERNALMANUFACTURER = "pgIPMExternalManufacturers";
	String STATE_RELEASE = "Release";
	String STATE_PENDING = "Pending";
	String ATTRIBUTE_PGCLASSIFICATION = PropertyUtil.getSchemaProperty("attribute_pgSecurityClassification");
	String SELECT_ATTRIBUTE_PGCLASSIFICATION = "attribute[" + ATTRIBUTE_PGCLASSIFICATION + "]";
	String RELATIONSHIP_PGPDTEMPLATESTOPGPLISEGMENT = PropertyUtil
			.getSchemaProperty("relationship_pgPDTemplatestopgPLISegment");
	String TYPE_EXPORTCONTROLCLASS = PropertyUtil.getSchemaProperty("type_ExportControlClass");
	String TYPE_SECURITYCONTROLCLASS = PropertyUtil.getSchemaProperty("type_SecurityControlClass");
	String TYPE_IPCONTROLCLASS = PropertyUtil.getSchemaProperty("type_IPControlClass");
	String RELATIONSHIP_CHANGEAFFECTEDITEM = PropertyUtil.getSchemaProperty("relationship_ChangeAffectedItem");
	String RELATIONSHIP_IMPLEMENTEDITEM = PropertyUtil.getSchemaProperty("relationship_ImplementedItem");
	String TYPE_CHANGE = PropertyUtil.getSchemaProperty("type_Change");
	String REMOVEACCESS = "RemoveAccess";
	String ADDACCESS = "AddAccess";
	String CONTROLADDED = "ControlAdded";
	String CONTROLREMOVED = "ControlRemoved";
	String INTERNAL_EMP_COMPANY = "PG";
	String INTERNAL_NONEMP_COMPANY = "PG Staff Augmentation";
	String PROJECT = "Internal_PG";
	String ORGANIZATION = "PG";
	String TYPE_PGPKG_REPREF = PropertyUtil.getSchemaProperty("type_pgPKG_RepRef");
	String TYPE_PGPKG_REF = PropertyUtil.getSchemaProperty("type_pgPKG_Ref");
	String TYPE_ARTIOSCADCOMPONENT = PropertyUtil.getSchemaProperty("type_ArtiosCADComponent");
	String RELATIONSHIP_PGINHERITEDCADSPECIFICATION = PropertyUtil
			.getSchemaProperty("relationship_pgInheritedCADSpecification");
	String POLICY_VPLM_SMB_PG = PropertyUtil.getSchemaProperty("policy_VPLM_SMB_PG ");
	String POLICY_PGARTIOSCADCOMPONENT = PropertyUtil.getSchemaProperty("policy_pgArtiosCADComponent");
	String TYPE_PGPLISEGMENT = PropertyUtil.getSchemaProperty("type_pgPLISegment");
	String RELATIONSHIP_CHANGEACTION = PropertyUtil.getSchemaProperty("relationship_ChangeAction");
	String TYPE_CHANGEORDER = PropertyUtil.getSchemaProperty("type_ChangeOrder");
	String ATTRIBUTE_PGPLANTTESTINGTEXT = PropertyUtil.getSchemaProperty("attribute_pgPlantTestingText");
	String ATTRIBUTE_PGSEGMENT = PropertyUtil.getSchemaProperty("attribute_pgSegment");
	String ATTRIBUTE_ISPROCESSGENDOC = PropertyUtil.getSchemaProperty("attribute_isProcessGenDoc");
	String SELECT_ATTRIBUTE_ISPROCESSGENDOC = "attribute[" + ATTRIBUTE_ISPROCESSGENDOC + "]";
	String TYPE_CHANGEACTION = PropertyUtil.getSchemaProperty("type_ChangeAction");
	String STATE_PRELIMINARY = "Preliminary";
	String STATE_INWORK = "In Work";
	String ATTRIBUTE_RESETTOPENDING = PropertyUtil.getSchemaProperty("attribute_isResetToPending");
	String ATTRIBUTE_EMAILENABLED = PropertyUtil.getSchemaProperty("attribute_iseMailEnabled");
	String SELECT_ATTRIBUTE_RESETTOPENDING = "attribute[" + ATTRIBUTE_RESETTOPENDING + "]";
	String SELECT_ATTRIBUTE_EMAILENABLED = "attribute[" + ATTRIBUTE_EMAILENABLED + "]";
	String DSM_ORIGIN = "DSO";
	String ATTRIBUTE_ORGANIZATIONID = PropertyUtil.getSchemaProperty("attribute_OrganizationID");
	String SELECT_ATTRIBUTE_ORGANIZATIONID = "attribute[" + ATTRIBUTE_ORGANIZATIONID + "]";
	String DUMP_CHARACTER = "|";
	String CRON_JOB_STATUS_RUNNING = "Running";
	String CRON_JOB_STATUS_NOTSTARTED = "Not Started";
	String GLOBAL_CONFIG = "Global Subscription Configuration";
	String POLICY_EXPERIMENTALPRODUCTDATA = PropertyUtil.getSchemaProperty("policy_ExperimentalProductData");
	String RELATIONSHIP_PGAUTHORIZEDCONFIGURATIONSTANDARD = PropertyUtil
			.getSchemaProperty("relationship_pgAuthorizedConfigurationStandard");
	String TYPE_ASSEMBLEDPRODUCTPART = PropertyUtil.getSchemaProperty("type_pgAssembledProductPart");
	String TYPE_DEVICEPRODUCTPART = PropertyUtil.getSchemaProperty("type_pgDeviceProductPart");
	String TYPE_AUTHORIZEDCONFIGSTAND = PropertyUtil.getSchemaProperty("type_pgAuthorizedConfigurationStandard");
	String ATTRIBUTE_PGREVISETOTYPE = PropertyUtil.getSchemaProperty("attribute_pgRevisedToType");
	String SELECT_ATTRIBUTE_PGREVISETOTYPE = "attribute[" + ATTRIBUTE_PGREVISETOTYPE + "]";
	String TYPE_FORMULATIONPROCESS = PropertyUtil.getSchemaProperty("type_FormulationProcess");
	String TYPE_FORMULATIONPHASE = PropertyUtil.getSchemaProperty("type_FormulationPhase");
	String POLICY_PRODFORMULATIONPROCESS = PropertyUtil.getSchemaProperty("policy_ProductionFormulationProcess");
	String POLICY_PRODFORMULATIONPHASE = PropertyUtil.getSchemaProperty("policy_FormulationPhase");
	String RELATIONSHIP_PLANNEDFOR = PropertyUtil.getSchemaProperty("relationship_PlannedFor");
	String RELATIONSHIP_PLBOM = PropertyUtil.getSchemaProperty("relationship_FBOM");
	String TYPE_MASTERRAWMATERIALPART = PropertyUtil.getSchemaProperty("type_pgMasterRawMaterialPart");
	String TYPE_FORMULATECHNICALSPEC = PropertyUtil.getSchemaProperty("type_FormulaTechnicalSpecification");
	String TYPE_MASTERPRODUCTPART = PropertyUtil.getSchemaProperty("type_pgMasterProductPart");
	String TYPE_ANCILLARYRAWMATERIALPART = PropertyUtil.getSchemaProperty("type_pgAncillaryRawMaterialPart");
	String RELATIONSHIP_PLBOMSUBSTITUTE = PropertyUtil.getSchemaProperty("relationship_FBOMSubstitute");
	String ATTRIBUTE_PGTECHNOLOGY = PropertyUtil.getSchemaProperty("attribute_pgTechnology");
	String SELECT_ATTRIBUTE_PGTECHNOLOGY = "attribute[" + ATTRIBUTE_PGTECHNOLOGY + "]";
	String ATTRIBUTE_PGSHIPPINGHAZARDCLASSIFICATION = PropertyUtil
			.getSchemaProperty("attribute_pgShippingHazardClassification");
	String SELECT_ATTRIBUTE_PGSHIPPINGHAZARDCLASSIFICATION = "attribute[" + ATTRIBUTE_PGSHIPPINGHAZARDCLASSIFICATION
			+ "]";
	String ATTRIBUTE_PGINTENDEDMARKETS = PropertyUtil.getSchemaProperty("attribute_pgIntendedMarkets");
	String SELECT_ATTRIBUTE_PGINTENDEDMARKETS = "attribute[" + ATTRIBUTE_PGINTENDEDMARKETS + "]";
	String TYPE_COSMETICFORMULATION = PropertyUtil.getSchemaProperty("type_CosmeticFormulation");
	String POLICY_PRODFORMULATION = PropertyUtil.getSchemaProperty("policy_ProductionFormulation");
	String RELATIONSHIP_FORMULATIONPROPAGATE = PropertyUtil.getSchemaProperty("relationship_FormulationPropagate");
	String RELATIONSHIP_FORMULATIONPROCESS = PropertyUtil.getSchemaProperty("relationship_FormulationProcess");
	String REL_SENIOR_TECH_ASSIGNEE = PropertyUtil.getSchemaProperty("relationship_SeniorTechnicalAssignee");
	String ATTRIBUTE_PGSERVERHOST = PropertyUtil.getSchemaProperty("attribute_pgServerHost");
	String ATTRIBUTE_PGJMSUSERNAME = PropertyUtil.getSchemaProperty("attribute_pgJMSUserName");
	String ATTRIBUTE_PGPASSWORD = PropertyUtil.getSchemaProperty("attribute_pgPassword");
	String ATTRIBUTE_PGCONFIGCOMMONATTR = PropertyUtil.getSchemaProperty("attribute_pgConfigCommonAttr");
	String NO_ACCESS = "No Access";
	String ATTRIBUTE_PGFORMULATIONPROCESSNUMBER = PropertyUtil
			.getSchemaProperty("attribute_pgFormulationProcessNumber");
	String RELATIONSHIP_COUNTRY = PropertyUtil.getSchemaProperty("relationship_Country");
	String RELATIONSHIP_ASSOCIATED_PLANTS = PropertyUtil.getSchemaProperty("relationship_AssociatedPlants");
	String TYPE_NUMERIC_CHARACTERISTIC = PropertyUtil.getSchemaProperty("type_NumericCharacteristic");
	String TYPE_FREETEXT_CHARACTERISTIC = PropertyUtil.getSchemaProperty("type_FreeTextCharacteristic");
	String POLICY_CHARACTERISTIC = PropertyUtil.getSchemaProperty("policy_Characteristic");
	String RELATIONSHIP_POACOUNTRY = PropertyUtil.getSchemaProperty("relationship_POACountry");
	String TYPE_PGIPMSOREPORTTEMPLATE = PropertyUtil.getSchemaProperty("type_pgIPMSOReportTemplate");
	String ERROR_MSG_BLANK_ID = "Error - Object ID is Blank OR Null";
	String ERROR_MSG_GROUPING = "Error - Grouping or Quantity Issue";
	String ERROR_MSG_SAP_CONF = "Error - SAP Configuration object is not set properly";
	String ERROR_MSG_EXCEPTION = "Caught Exception in JPO pgEDeliverBOMToSap.doBOMeDelivery(): ";
	String ERROR_MSG_ARGUMENT = "Error - Method doBOMeDelivery gets called with wrong Parameters";
	String DUMMY_PLANT_VALUE_3151 = "3151";
	String CONFIG_OBJECT_PGSENDPLANTSSAPCONFIG = "pgSendPlantsSapConfig";
	String SUBASSEMBLY_TYPE_PURCHASED = "Purchased Subassembly";
	String PGASSEMBLY_TYPE_FWIP = "FWIP-Finished Work in Process";
	String RANGE_ATTRIBUTE_STATUS_PLANNING = "PLANNING";
	String RANGE_ATTRIBUTE_PGBOMBASEQUANTITY_EXPERIMENTAL = "EXPERIMENTAL";
	String TYPE_PGSAPDESIGNATEDSITES = PropertyUtil.getSchemaProperty("type_pgSAPDesignatedSites");
	String CONFIG_OBJECT_DESIGNATEDSITESOBJ = "DesignatedSitesObj";
	String ATTRIBUTE_PGSAPDESIGNATEDSITESLIST = PropertyUtil.getSchemaProperty("attribute_pgSAPDesignatedSitesList");
	String SYMBOL_PIPE = "|";
	String SYMBOL_STAR = "*";
	String SYMBOL_TILDA = "~";
	String ATTRIBUTE_CURRENT_INACTIVE = "Inactive";
	String TYPE_MASTER = "Master";
	String RANGE_ATTRIBUTE_SAPTYPE_DOC = "doc";
	String ATTRIBUTE_ENGINUITYAUTHORED = PropertyUtil.getSchemaProperty("attribute_EnginuityAuthored");
	String SELECT_ATTRIBUTE_ENGINUITYAUTHORED = "attribute[" + ATTRIBUTE_ENGINUITYAUTHORED + "]";
	String RELATIONSHIP_PGSYNCVIRTUALINTERMEDIATE = PropertyUtil
			.getSchemaProperty("relationship_pgSyncVirtualIntermediate");
	String RESHIPPER_ASS_TYPE_VAL = "Reshipper";
	String SELECT_ATTRIBUTE_PGSERVERHOST = "attribute[" + ATTRIBUTE_PGSERVERHOST + "]";
	String SELECT_ATTRIBUTE_PGJMSUSERNAME = "attribute[" + ATTRIBUTE_PGJMSUSERNAME + "]";
	String SELECT_ATTRIBUTE_PGPASSWORD = "attribute[" + ATTRIBUTE_PGPASSWORD + "]";
	String SELECT_ATTRIBUTE_PGCONFIGCOMMONATTR = "attribute[" + ATTRIBUTE_PGCONFIGCOMMONATTR + "]";
	String SELECT_ATTRIBUTE_PGSAPDESIGNATEDSITESLIST = "attribute[" + ATTRIBUTE_PGSAPDESIGNATEDSITESLIST + "]";
	String ATTRIBUTE_PGMINCALCQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgMinCalcQuantity");
	String ATTRIBUTE_PGMIXCALCQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgMaxCalcQuantity");
	String SELECT_ATTRIBUTE_PGMINCALCQUANTITY = "attribute[" + ATTRIBUTE_PGMINCALCQUANTITY + "]";
	String SELECT_ATTRIBUTE_PGMIXCALCQUANTITY = "attribute[" + ATTRIBUTE_PGMIXCALCQUANTITY + "]";
	String ATTRIBUTE_PGDEPTH = PropertyUtil.getSchemaProperty("attribute_pgDepth");
	String SELECT_ATTRIBUTE_PGDEPTH = "attribute[" + ATTRIBUTE_PGDEPTH + "]";
	String ATTRIBUTE_PGWIDTH = PropertyUtil.getSchemaProperty("attribute_pgWidth");
	String SELECT_ATTRIBUTE_PGWIDTH = "attribute[" + ATTRIBUTE_PGWIDTH + "]";
	String ATTRIBUTE_PGHEIGHT = PropertyUtil.getSchemaProperty("attribute_pgHeight");
	String SELECT_ATTRIBUTE_PGHEIGHT = "attribute[" + ATTRIBUTE_PGHEIGHT + "]";
	String ATTRIBUTE_PGDIMENSIONUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_pgDimensionUnitOfMeasure");
	String SELECT_ATTRIBUTE_PGDIMENSIONUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGDIMENSIONUNITOFMEASURE + "]";
	String ATTRIBUTE_PGGROSSWEIGHT = PropertyUtil.getSchemaProperty("attribute_pgGrossWeight");
	String SELECT_ATTRIBUTE_PGGROSSWEIGHT = "attribute[" + ATTRIBUTE_PGGROSSWEIGHT + "]";
	String ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT = PropertyUtil
			.getSchemaProperty("attribute_pgConsumerUnitsPerPackingUnit");
	String SELECT_ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT = "attribute[" + ATTRIBUTE_PGCONSUMERUNITSPERPACKINGUNIT
			+ "]";
	String ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNIT = PropertyUtil
			.getSchemaProperty("attribute_pgNetWeightOfProductInConsumerUnit");
	String SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNIT = "attribute["
			+ ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNIT + "]";
	String ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_pgNetWeightUnitOfMeasure");
	String SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE + "]";
	String ATTRIBUTE_PGCUBEEFFICIENCY = PropertyUtil.getSchemaProperty("attribute_pgCubeEfficiency");
	String SELECT_ATTRIBUTE_PGCUBEEFFICIENCY = "attribute[" + ATTRIBUTE_PGCUBEEFFICIENCY + "]";
	String RELATIONSHIP_EBOM = PropertyUtil.getSchemaProperty("relationship_EBOM");
	String ATTRIBUTE_PGUNARCHIVEDATE = PropertyUtil.getSchemaProperty("attribute_pgUnarchiveDate");
	String SELECT_ATTRIBUTE_PGUNARCHIVEDATE = "attribute[" + ATTRIBUTE_PGUNARCHIVEDATE + "]";
	String ATTRIBUTE_PGSUPERSEDESONDATE = PropertyUtil.getSchemaProperty("attribute_pgSupersedesOnDate");
	String SELECT_ATTRIBUTE_PGSUPERSEDESONDATE = "attribute[" + ATTRIBUTE_PGSUPERSEDESONDATE + "]";
	String ATTRIBUTE_PGELECTRONICDISTRIBUTION = PropertyUtil.getSchemaProperty("attribute_pgElectronicDistribution");
	String SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION = "attribute[" + ATTRIBUTE_PGELECTRONICDISTRIBUTION + "]";
	String ATTRIBUTE_PGCOCREATORS = PropertyUtil.getSchemaProperty("attribute_pgCoCreators");
	String SELECT_ATTRIBUTE_PGCOCREATORS = "attribute[" + ATTRIBUTE_PGCOCREATORS + "]";
	String SELECT_ATTRIBUTE_PGBRAND = "attribute[" + ATTRIBUTE_PGBRAND + "]";
	String ATTRIBUTE_APPROVED_DATE = PropertyUtil.getSchemaProperty("attribute_ApprovedDate");
	String SELECT_ATTRIBUTE_APPROVED_DATE = "attribute[" + ATTRIBUTE_APPROVED_DATE + "]";
	String STATE_RELEASED = "Released";
	String TYPE_PGCONSUMERDESIGNBASIS = PropertyUtil.getSchemaProperty("type_pgConsumerDesignBasis");
	String TYPE_PGFORMULATEDMATERIAL = PropertyUtil.getSchemaProperty("type_pgFormulatedMaterial");
	String ATTRIBUTE_PGPACKINGLEVEL = PropertyUtil.getSchemaProperty("attribute_pgPackingLevel");
	String SELECT_ATTRIBUTE_PGPACKINGLEVEL = "attribute[" + ATTRIBUTE_PGPACKINGLEVEL + "]";
	String TYPE_PGENVIRONMENTALCHARACTERISTIC = PropertyUtil.getSchemaProperty("type_pgEnvironmentalCharacteristic");
	String RANGE_ATTRIBUTE_STATUS_UNKNOWN = "Unknown";
	String ATTRIBUTE_PGFAILEDREASON_ERRORMESSAGE = "Error message received on exception";
	String ATTRIBUTE_PGFAILED_CLASSIFICATION_BOMDELIVERY = "BOMDelivery";
	String RELATIONSHIP_MIGRATE_POAToCOUNTRY = PropertyUtil.getSchemaProperty("relationship_pgAAA_POAToCountry");
	String OBJECT_ID = "objectId";
	String PARENT_ID = "parentId";
	String SELECTED_RELS = "selectedRels";
	String MESSAGE_TYPE = "MESSAGE_TYPE";
	String ACTUAL_ERROR = "ACTUAL_ERROR";
	String SELECTION_TYPE = "SELECTION_TYPE";
	String FROM_TYPE = "FROM_TYPE";
	String FROM_NAME = "FROM_NAME";
	String FROM_REVISION = "FROM_REVISION";
	String TO_FORMULATION_PART_REVISION = "TO_FORMULATION_PART_REVISION";
	String TO_FORMULATION_PROCESS_NAME = "TO_FORMULATION_PROCESS_NAME";
	String TO_FORMULATION_PROCESS_TYPE = "TO_FORMULATION_PROCESS_TYPE";
	String COPY_ENGINUITY_STATUS_INFO = "COPY_ENGUNUITY_STATUS_INFO";
	String FROM_FORMULATION_PROCESS_REVISION = "FROM_FORMULATION_PROCESS_REVISION";
	String FROM_FORMULATION_PROCESS_NAME = "FROM_FORMULATION_PROCESS_NAME";
	String FROM_FORMULATION_PROCESS_TYPE = "FROM_FORMULATION_PROCESS_TYPE";
	String TO_OBJECT = "ToObject";
	String ATTRIBUTE_DETAILS = "AttributeDetails";
	String REL_ID = "RelId";
	String OBJ_TYPE = "ObjType";
	String ATTR_VALUE = "AttrValue";
	String REL_NAME = "RelName";
	String LIST_FOR_CONNECTION = "ListForConnection";
	String ENGINUITY_OBJ_TYPE = "EnginuityObjType";
	String ENGINUITY_OBJ_NAME = "EnginuityObjName";
	String ENGINUITY_OBJ_REVISION = "EnginuityObjRevision";
	String CHAR_ENGINUITY_REVISION = "CharEnginuityRevision";
	String CHAR_ENGINUITY_NAME = "CharEnginuityName";
	String CHAR_ENGINUITY_TYPE = "CharEnginuityType";
	String CHAR_ATTRIBUTES = "CharAttributes";
	String CHAR_DSO_OBJ = "CharDSOObj";
	String PLANT_ENGINUITY_REVISION = "PlantEnginuityRevision";
	String PLANT_ENGINUITY_NAME = "PlantEnginuityName";
	String PLANT_ENGINUITY_TYPE = "PlantEnginuityType";
	String PHASE_ENGINUITY_TYPE = "PhaseEnginuityType";
	String PHASE_ENGINUITY_NAME = "PhaseEnginuityName";
	String PHASE_ENGINUITY_REVISION = "PhaseEnginuityRevision";
	String PARENT_OID = "PARENT_OID";
	String FROM_OBJECT = "FromObject";
	String PARENT_TYPE = "PARENT_TYPE";
	String FROM_COSMETIC_FORMULATION_TYPE = "FROM_COSMETIC_FORMULATION_TYPE";
	String FROM_COSMETIC_FORMULATION_NAME = "FROM_COSMETIC_FORMULATION_NAME";
	String FROM_COSMETIC_FORMULATION_REVISION = "FROM_COSMETIC_FORMULATION_REVISION";
	String FROM_FORMULATION_PART_TYPE = "FROM_FORMULATION_PART_TYPE";
	String FROM_FORMULATION_PART_NAME = "FROM_FORMULATION_PART_NAME";
	String FROM_FORMULATION_PART_REVISION = "FROM_FORMULATION_PART_REVISION";
	String TO_COSMETIC_FORMULATION_TYPE = "TO_COSMETIC_FORMULATION_TYPE";
	String TO_COSMETIC_FORMULATION_NAME = "TO_COSMETIC_FORMULATION_NAME";
	String TO_COSMETIC_FORMULATION_REVISION = "TO_COSMETIC_FORMULATION_REVISION";
	String TO_FORMULATION_PART_TYPE = "TO_FORMULATION_PART_TYPE";
	String TO_FORMULATION_PART_NAME = "TO_FORMULATION_PART_NAME";
	String META_DATA = "Meta Data";
	String OBJECTS_TAG = "Objects";
	String OBJECT_TAG = "Object";
	String ATTRIBUTE_TAG = "Attribute";
	String ATTRIBUTES_TAG = "Attributes";
	String FROM_OBJECT_TYPE_ATTRIBUTE_TAG = "FromObjectTypeAttributes";
	String RELATIONSHIPS_TAG = "Relationships";
	String RELATIONSHIP_TAG = "Relationship";
	String REL_ATTRIBUTE_TAG = "RelAttributes";
	String FROM_RELATIONSHIP_NAME_TAG = "FromRelationShipName";
	String TO_RELATIONSHIP_NAME_TAG = "ToRelationShipName";
	String FROM_OBJECT_TYPE_TAG = "FromObjectType";
	String TO_OBJECT_TYPE_TAG = "ToObjectType";
	String FROM_TYPE_TAG = "FromType";
	String TO_TYPE_TAG = "ToType";
	String ACTION_TAG = "Action";
	String FROM_ATTRIBUTE_FIELD_TAG = "FromAttributeField";
	String TO_ATTRIBUTE_FIELD_TAG = "ToAttributeField";
	String ATTRIBUTES_EXCLUDED_TAG_VALUE = "AttributesExcluded";
	String ATTRIBUTES_MAPPING_TAG_VALUE = "AttributesMapping";
	String ATTRIBUTES_INCLUDED_TAG_VALUE = "AttributesIncluded";
	String PPM_PGORIGINATINGSOURCE_VALUE = "PPM";
	String ENGINUITY_AUTHORED_PGORIGINATINGSOURCE_VALUE = "Enginuity";
	String TYPE_PGMATERIALCONSTRUCTIONCHARACTERISTIC = PropertyUtil
			.getSchemaProperty("type_pgMaterialConstructionCharacteristic");
	String TYPE_PGPACKAGEQUALITYCHARACTERISTIC = PropertyUtil.getSchemaProperty("type_pgPackageQualityCharacteristic");
	String TYPE_PGPRODUCTQUALITYCHARACTERISTIC = PropertyUtil.getSchemaProperty("type_pgProductQualityCharacteristic");
	String ATTRIBUTE_PGSECURITYSTATUS = PropertyUtil.getSchemaProperty("attribute_pgSecurityStatus");
	String SELECT_ATTRIBUTE_PGSECURITYSTATUS = "attribute[" + ATTRIBUTE_PGSECURITYSTATUS + "]";
	String GBU_BABYCARE = "BABY CARE";
	String GBU_FEMCARE = "FEMININE CARE";
	String PGMASTER = "pgMaster";
	String ATTRIBUTE_PGISPRIMARY = PropertyUtil.getSchemaProperty("attribute_pgIsPrimary");
	String SELECT_ATTRIBUTE_PGISPRIMARY = "attribute[" + ATTRIBUTE_PGISPRIMARY + "]";
	String SAP_LANGUAGE = "E";
	//String ENCRYPT_ALG = "DESede";
	int INDEX_MATERIAL_NUMBER = 0;
	int INDEX_BOM_USAGE = 1;
	int INDEX_ALT_BOM = 2;
	int INDEX_VALID_FROM_DATE_PARENT = 3;
	int INDEX_BOM_TEXT = 4;
	int INDEX_ALT_BOM_TEXT = 5;
	int INDEX_CONFIRMED_QUANTITY = 6;
	int INDEX_BOM_STATUS = 7;
	int INDEX_BOM_ITEM_NUMBER = 8;
	int INDEX_COMPONENT_NAME = 9;
	int INDEX_QUANTITY = 10;
	int INDEX_ITEM_CATEGORY = 11;
	int INDEX_VALID_FROM_DATE_CHILD = 12;
	int INDEX_SORT_STRING = 13;
	int INDEX_SUBSTITUTE_FLAG = 14;
	int INDEX_USAGE_PROBABILITY = 15;
	int INDEX_RANGE_FLAG = 16;
	int INDEX_UPPER_LIMIT = 17;
	int INDEX_TARGET = 18;
	int INDEX_LOWER_LIMIT = 19;
	int INDEX_FIND_NUMBER = 20;
	int INDEX_PHASE_NAME = 21;
	int INDEX_BOM_ARRAY_SIZE = 35;
	int INDEX_FC_MIN_QTY = 23;
	int INDEX_FORMULA_CARD = 24;
	int INDEX_FC_MAX_QTY = 25;
	int INDEX_IPS_QTY = 26;
	int INDEX_OBJECT_ID = 27;
	int INDEX_TPU_ID = 28;
	int INDEX_OPT_COMPONENT = 29;
	int INDEX_COMMENT = 30;
	int INDEX_TARGETWETWEIGHT = 31;
	int INDEX_TARGETDRYWEIGHT = 32;
	int INDEX_ISPRIMARYCOMPONENT = 33;
	String VALUE_ALT_BOM = "ZZ";
	String VALUE_ALT_BOM_TEXT = "";
	String VALUE_BOM_TEXT = "";
	String VALUE_BOM_STATUS = "1";
	String VALUE_ITEM_CATEGORY = "L";
	String VALUE_USAGE_PROBABILITY = "100";
	String VALUE_SUBSTITUTE_FLAG = "X";
	String VALUE_RANGE_FLAG = "X";
	String PLANNING_CODE = "2";
	String EXPERIMENTAL_CODE = "0";
	String VALID_CODE = "3";
	String MAP_KEY_ID = "id";
	String MAP_KEY_SUBSTITUTE = "substitute";
	String MAP_KEY_EFFECTIVITYDATE = "effectivityDate";
	String MAP_KEY_BOMQTY = "BOMQty";
	String MAP_KEY_MIN = "Min";
	String MAP_KEY_MAX = "Max";
	String MAP_KEY_POSINDEX = "PosInd";
	String MAP_KEY_OPTCOMPONENT = "OptComponent";
	String MAP_KEY_SAPNAME = "SAPName";
	String MAP_KEY_CHILD = "Child";
	String MAP_KEY_SAPUOM = "SAPUOM";
	String MAP_KEY_SAPTYPE = "SAPType";
	String MAP_KEY_SSTYPE = "SSType";
	String MAP_KEY_SAPDESC = "SAPDescription";
	String MAP_KEY_dISPLAYID = "dispId";
	String MAP_KEY_CHILD_ID = "ChildID";
	String MAP_KEY_REL_ID = "RELID";
	String RELATIONSHIP_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_Template");
	String CHARACTERISTICSOBJ = "CharacteristicsObj";
	String TMTOCONNECT = "TMToConnect";
	String PHASEDSOOBJ = "PhaseDSOObj";
	String PHASEATTRIBUTES = "PhaseAttributes";
	String RELATIONSHIP_VIRTUALINTERMEDIATEUSAGE = PropertyUtil
			.getSchemaProperty("relationship_VirtualIntermediateUsage");
	String TYPE_SUBSTANCE = PropertyUtil.getSchemaProperty("type_Substance");
	String CONFIG_OBJECT_NAME_PG_SMART_COUNTRY_ADMIN = "pgSMARTCountryAdmin";
	String TYPE_VIRTUALINTERMEDIATE = PropertyUtil.getSchemaProperty("type_VirtualIntermediate");
	String RELATIONSHIP_FORMULA_INGREDIENT = PropertyUtil.getSchemaProperty("relationship_FormulaIngredient");
	String ATTRIBUTE_LOSS = PropertyUtil.getSchemaProperty("attribute_Loss");
	String SELECT_ATTRIBUTE_LOSS = "attribute[" + ATTRIBUTE_LOSS + "].inputvalue";
	String ATTRIBUTE_ACTUAL_WEIGHT_DRY = PropertyUtil.getSchemaProperty("attribute_ActualWeightDry");
	String SELECT_ATTRIBUTE_ACTUAL_WEIGHT_DRY = "attribute[" + ATTRIBUTE_ACTUAL_WEIGHT_DRY + "].inputvalue";
	String ATTRIBUTE_ACTUAL_WEIGHT_WET = PropertyUtil.getSchemaProperty("attribute_ActualWeightWet");
	String SELECT_ATTRIBUTE_ACTUAL_WEIGHT_WET = "attribute[" + ATTRIBUTE_ACTUAL_WEIGHT_WET + "].inputvalue";
	String ATTRIBUTE_ACTUAL_PERCENT_DRY = PropertyUtil.getSchemaProperty("attribute_ActualPercentDry");
	String SELECT_ATTRIBUTE_ACTUAL_PERCENT_DRY = "attribute[" + ATTRIBUTE_ACTUAL_WEIGHT_DRY + "].inputvalue";
	String ATTRIBUTE_ACTUAL_PERCENT_WET = PropertyUtil.getSchemaProperty("attribute_ActualPercentWet");
	String SELECT_ATTRIBUTE_ACTUAL_PERCENT_WET = "attribute[" + ATTRIBUTE_ACTUAL_WEIGHT_WET + "].inputvalue";
	char ALT_ITEM_NINE = '9';
	char ALT_ITEM_A = 'A';
	String STR_DEFAULT_QTY_IF_FAILED = "-9.99";
	String POLICY_VIRTUALINTERMEDIATE = PropertyUtil.getSchemaProperty("policy_VirtualIntermediate");
	String ATTRIBUTE_STAGE_PRODUCTION_VALUE = "Production";
	String VIRTUAL_INTERMEDIATE = "VirtualIntermediate";
	String ENGINUITY_OBJECTID = "EnginuityObjectId";
	String DSM_OBJECTID = "DSMObjectId";
	String ATTRIBUTE_PGSHELFLIFE = PropertyUtil.getSchemaProperty("attribute_pgShelfLife");
	String SELECT_ATTRIBUTE_PGSHELFLIFE = "attribute[" + ATTRIBUTE_PGSHELFLIFE + "]";
	String ATTRIBUTE_MIN = PropertyUtil.getSchemaProperty("attribute_Min");
	String ATTRIBUTE_MAX = PropertyUtil.getSchemaProperty("attribute_Max");
	String ATTRIBUTE_PGDENSITYUOM = PropertyUtil.getSchemaProperty("attribute_pgDensityUOM");
	String ATTRIBUTE_PGONSHELFPRODUCTDENSITY = PropertyUtil.getSchemaProperty("attribute_pgOnshelfProductDensity");
	String RELATIONSHIP_PROCESSSTEP = PropertyUtil.getSchemaProperty("relationship_ProcessStep");
	String TYPE_REACTION_DEFINITION = PropertyUtil.getSchemaProperty("type_ReactionDefinition");
	String RELATIONSHIP_REACTION_PRODUCT = PropertyUtil.getSchemaProperty("relationship_ReactionProduct");
	String PGENGINUITYREACTIONDEFCONFIG = "pgEnginuityReactionDefConfig";
	String POLICY_PRODPRODUCTDATA = PropertyUtil.getSchemaProperty("policy_ProductionProductData");
	String POLICY_INTERNALMATERIAL = PropertyUtil.getSchemaProperty("policy_InternalMaterial");
	String USER_CORPORATE = "Corporate";
	String RELATIONSHIP_ALIAS = PropertyUtil.getSchemaProperty("relationship_Alias");
	String RELATIONSHIP_ALLOCATIONRESPONSIBILITY = PropertyUtil
			.getSchemaProperty("relationship_AllocationResponsibility");
	String TYPE_INTERNALMATERIAL = PropertyUtil.getSchemaProperty("type_InternalMaterial");
	String PGORIGINATINGSOURCE_VALUE_CSS_INTEGRATION = "CSS INTEGRATION -";
	String PROJECT_INTERNAL_PG = "Internal_PG";
	String ATTRIBUTE_PGRMGCASCODE = PropertyUtil.getSchemaProperty("attribute_pgRMGCASCode");
	String ATTRIBUTE_PGRMCISPRONUMBER = PropertyUtil.getSchemaProperty("attribute_pgRMCISProNumber");
	String ATTRIBUTE_MINIMUMWEIGHT = PropertyUtil.getSchemaProperty("attribute_MinimumWeight");
	String SELECT_ATTRIBUTE_MINIMUMWEIGHT = "attribute[" + ATTRIBUTE_MINIMUMWEIGHT + "]";
	String ATTRIBUTE_MAXIMUMWEIGHT = PropertyUtil.getSchemaProperty("attribute_MaximumWeight");
	String SELECT_ATTRIBUTE_MAXIMUMWEIGHT = "attribute[" + ATTRIBUTE_MAXIMUMWEIGHT + "]";
	String ATTRIBUTE_QUANTITYUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_QuantityUnitOfMeasure");
	String SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE = "attribute[" + ATTRIBUTE_QUANTITYUNITOFMEASURE + "]";
	String ATTRIBUTE_QSTOCOMPOSITE = PropertyUtil.getSchemaProperty("attribute_QsToComposite");
	String SELECT_ATTRIBUTE_QSTOCOMPOSITE = "attribute[" + ATTRIBUTE_QSTOCOMPOSITE + "]";
	String ATTRIBUTE_ISCONTAMINANT = PropertyUtil.getSchemaProperty("attribute_IsContaminant");
	String SELECT_ATTRIBUTE_ISCONTAMINANT = "attribute[" + ATTRIBUTE_ISCONTAMINANT + "]";
	String ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT = PropertyUtil.getSchemaProperty("attribute_MaximumActualPercentWet");
	String ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT = PropertyUtil.getSchemaProperty("attribute_MinimumActualPercentWet");
	String SELECT_ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT = "attribute[" + ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT + "]";
	String SELECT_ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT = "attribute[" + ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT + "]";
	String ATTRIBUTE_PGCHARACTERISTICNAME = PropertyUtil.getSchemaProperty("attribute_pgCharacteristicName");
	String SELECT_ATTRIBUTE_PGCHARACTERISTICNAME = "attribute[" + ATTRIBUTE_PGCHARACTERISTICNAME + "]";
	String CHAR_NAME = "CharName";
	String POLICY_PARENTSUB = PropertyUtil.getSchemaProperty("policy_ParentSub");
	String ATTRIBUTE_QUANTITY_ADJUSTMENT = PropertyUtil.getSchemaProperty("attribute_QuantityAdjustment");
	String SELECT_ATTRIBUTE_QUANTITY_ADJUSTMENT = "attribute[" + ATTRIBUTE_QUANTITY_ADJUSTMENT + "]";
	String ATTRIBUTE_PRIMARY_REPLACE_ING = PropertyUtil.getSchemaProperty("attribute_PrimaryReplacementIngredient");
	String SELECT_ATTRIBUTE_PRIMARY_REPLACE_ING = "attribute[" + ATTRIBUTE_PRIMARY_REPLACE_ING + "]";
	String ATTRIBUTE_INGREDIENT_LOSS = PropertyUtil.getSchemaProperty("attribute_pgIngredientLoss");
	String SELECT_ATTRIBUTE_INGREDIENT_LOSS = "attribute[" + ATTRIBUTE_INGREDIENT_LOSS + "]";
	String ATTRIBUTE_ACTUALWETWEIGHT = PropertyUtil.getSchemaProperty("attribute_ActualWeightWet");
	String SELECT_ATTRIBUTE_ACTUALWETWEIGHT = "attribute[" + ATTRIBUTE_ACTUALWETWEIGHT + "].inputvalue";
	String ATTRIBUTE_ACTUALDRYWEIGHT = PropertyUtil.getSchemaProperty("attribute_ActualWeightDry");
	String SELECT_ATTRIBUTE_ACTUALDRYWEIGHT = "attribute[" + ATTRIBUTE_ACTUALDRYWEIGHT + "].inputvalue";
	String ATTRIBUTE_TOTAL = PropertyUtil.getSchemaProperty("attribute_Total");
	String SELECT_ATTRIBUTE_TOTAL = "attribute[" + ATTRIBUTE_TOTAL + "].inputvalue";
	String TYPE_PARENTSUB = PropertyUtil.getSchemaProperty("type_ParentSub");
	String ATTRIBUTE_MIN_ACTUALWEIGHTWET = PropertyUtil.getSchemaProperty("attribute_MinimumActualWeightWet");
	String SELECT_ATTRIBUTE_MIN_ACTUALWEIGHTWET = "attribute[" + ATTRIBUTE_MIN_ACTUALWEIGHTWET + "]";
	String ATTRIBUTE_MAX_ACTUALWEIGHTWET = PropertyUtil.getSchemaProperty("attribute_MaximumActualWeightWet");
	String SELECT_ATTRIBUTE_MAX_ACTUALWEIGHTWET = "attribute[" + ATTRIBUTE_MAX_ACTUALWEIGHTWET + "]";
	String ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET = PropertyUtil.getSchemaProperty("attribute_Min");
	String SELECT_ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET = "attribute[" + ATTRIBUTE_MIN_PERCENT_ACTUALWEIGHTWET + "]";
	String ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET = PropertyUtil.getSchemaProperty("attribute_Max");
	String SELECT_ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET = "attribute[" + ATTRIBUTE_MAX_PERCENT_ACTUALWEIGHTWET + "]";
	String ATTRIBUTE_TARGETWETWEIGHT = PropertyUtil.getSchemaProperty("attribute_TargetWeightWet");
	String SELECT_ATTRIBUTE_TARGETWETWEIGHT = "attribute[" + ATTRIBUTE_TARGETWETWEIGHT + "].inputvalue";
	String ATTRIBUTE_FORMULATIONTYPE = PropertyUtil.getSchemaProperty("attribute_FormulationType");
	String SELECT_ATTRIBUTE_FORMULATIONTYPE = "attribute[" + ATTRIBUTE_FORMULATIONTYPE + "]";
	String FORMULATIONTYPE_INTERMEDIATEFORMULA_VALUE = "Intermediate Formula";
	String KEY_INTERMEDIATE_NAME = "IntermediateName";
	String KEY_INTERMEDIATE_ID = "IntermediateID";
	String TYPE_PGPOADOCUMENT = PropertyUtil.getSchemaProperty("type_pgPOADocument");
	String TYPE_QUALIFICATION = PropertyUtil.getSchemaProperty("type_Qualification");
	String RELATIONSHIP_QUALIFICATION = PropertyUtil.getSchemaProperty("relationship_Qualification");
	String TYPE_CONFIGURATION_FEATURE = PropertyUtil.getSchemaProperty("type_ConfigurationFeature");
	String TYPE_CONFIGURATION_OPTION = PropertyUtil.getSchemaProperty("type_ConfigurationOption");
	String TYPE_INTERMEDIATE_PRODUCT_PART = PropertyUtil.getSchemaProperty("type_pgIntermediateProductPart");
	String TYPE_RAW_MATERIAL_PLANT_INSTRUCTION = PropertyUtil.getSchemaProperty("type_pgRawMaterialPlantInstruction");
	String TYPE_RDLAB = PropertyUtil.getSchemaProperty("type_RDLab");
	String CSSTYPE_VALUE_TRANSLATION_FILE = "Translation File";
	String CSSTYPE_VALUE_DESIGN_FILE = "Design File";
	String CSSTYPE_VALUE_IMAGE_FILE = "Image File";
	String CSSTYPE_VALUE_QEC_FILE = "QEC File";
	String CSSTYPE_VALUE_REFERENCE_FILE = "Reference File";
	String CSSTYPE_VALUE_NATIVE_FILE = "Native File";
	String CSSTYPE_VALUE_RENDITION_FILE = "Rendition File";
	String ELEMENT_TECHNICAL_STANDARD = "TechnicalStandard";
	String ELEMENT_TYPE = "Type";
	String ELEMENT_IDENTIFIER = "Identifier";
	String ELEMENT_REVISION = "Revision";
	String ELEMENT_FILES = "Files";
	String ELEMENT_FILE = "File";
	String ELEMENT_FILE_TYPE = "FileType";
	String ELEMENT_FILE_NAME = "FileName";
	String ELEMENT_ORIGINAl_FILE_NAME = "OriginalFileName";
	String ELEMENT_DESIGNFILE = "DesignFile";
	String ELEMENT_REFERENCEFILE = "ReferenceFile";
	String ELEMENT_TRANSLATION = "Translation";
	String ELEMENT_QECFILE = "QECFile";
	String ELEMENT_NATIVE = "Native";
	String ELEMENT_IMAGE = "Image";
	String ENCODING_CHAR = "UTF-8";
	String ERROR_INVALID_INPUT = "Invalid Input \n\n";
	String ERROR_NO_PACKET_FOUND = "No Packet Found for the Input Type \n\n";
	String ERROR_INPUT_FILE_NOT_FOUND = "Input File not found. Hence Exiting.";
	String ERROR_ERROR_FILE_NOT_FOUND = "Error/Output File not found. Hence Exiting.";
	String ERROR_OUTPUT_DIRECTORY_NOT_FOUND = "Output Directory not found. Hence Exiting.";
	String EXCEPTION_IN_METADATA_EXTRACTION = "Exception in Extracting Metadata";
	String EXCEPTION_IN_EXTRACTION = "Exception in Extracting";
	String EXCEPTION_IN_WRITING_INTO_NEWFILE = "Exception in Writing Remaining Entry of Input File into New Input File- ";
	String FILE_FORMAT_GENERIC = "generic";
	String FILE_TYPE_REFERENCEDOCUMENT = "ReferenceDocument";
	String FILE_DOT_PDF = ".pdf";
	String FILE_COMPLETE_DOT_ZIP = ".complete.zip";
	String FILE_METADATA_DOT_XML = ".metadata.xml";
	String FILE_FILEDETAILS_DOT_XML = ".FileDetails.xml";
	String KEY_STATUS = "Status";
	String KEY_TARGET = "enovia";
	String KEY_MESSAGE = "Message";
	String KEY_YES = "yes";
	String MSG_OUTPUT_SUBDIRECTORIES_TO_BE_USED = "Output Subdirectories are being used.";
	String MSG_OUTPUT_SUBDIRECTORIES_TO_BE_ZIPPED = "Output Subdirectories will be zipped.";
	String MSG_OUTPUT_SUBDIRECTORIES_NOT_ZIPPED = "Output Subdirectories will not be zipped. \n Unless the zipOutputSubDirectories flag is also set to true there is a potential to exhaust the number of allowed directories.";
	String MSG_ZIP_OUTPUT_DIRECTORIES_NOT_FOUND = "zipOutputSubDirectories not found. Hence Output Subdirectories will not be zipped. \n Unless the zipOutputSubDirectories flag is also set to true there is a potential to exhaust the number of allowed directories.";
	String MSG_USE_OUTPUT_SUBDIRECTORIES_NOT_FOUND = "useOutputSubDirectories not found. Setting useOutputSubDirectories to False.";
	String MSG_INCLUDE_REFERENCE_DOCUMENTS_NOT_FOUND = "includeReferenceDocuments not found. Setting includeReferenceDocuments set to False.";
	String MSG_INCLUDE_NATIVE_DOCUMENTS_NOT_FOUND = "includeNativeDocuments not found. Setting includeNativeDocuments set to False.";
	String MSG_INCLUDE_TRANSLATIONS_NOT_FOUND = "includeTranslations not found. Setting includeTranslations set to False.";
	String MSG_INCLUDE_DESIGN_NOT_FOUND = "includeDesign not found. Setting includeDesign set to False.";
	String MSG_INCLUDE_IMAGES_NOT_FOUND = "includeImages not found. Setting includeImages set to False.";
	String MSG_INCLUDE_QEC_NOT_FOUND = "includeQEC not found. Setting includeQEC set to False.";
	String MSG_INCLUDE_PDF_DOCUMENTS_NOT_FOUND = "includePDFDocuments not found. Setting includePDFDocuments set to False.";
	String MSG_INCLUDE_PDF_PQR_NOT_FOUND = "includePQRView not found. Setting includePQRView set to False.";
	String MSG_INCLUDE_PDF_ALLINFO_NOT_FOUND = "includeAllInfo not found. Setting includeAllInfo set to False.";
	String MSG_INCLUDE_PDF_SUPPLIERVIEW_NOT_FOUND = "includeSupplierView not found. Setting includeSupplierView set to False.";
	String MSG_INCLUDE_PDF_CONSOLIDATEDPACKAGINGVIEW_NOT_FOUND = "includeConsolidatedPackagingView not found. Setting includeConsolidatedPackagingView set to False.";
	String MSG_INCLUDE_PDF_COMBINEDWITHMASTERVIEW_NOT_FOUND = "includeCombinedWithMasterView not found. Setting includeCombinedWithMasterView set to False.";
	String MSG_INCLUDE_PDF_WAREHOUSEVIEW_NOT_FOUND = "includeWarehouseView not found. Setting includeWarehouseView set to False.";
	String MSG_INCLUDE_PDF_CONTRACTMANUFACTURINGVIEW_NOT_FOUND = "includeContractManufacturingView not found. Setting includeContractmanufacturing set to False.";
	String MSG_INCLUDE_PDF_CONTRACTPACKAGINGVIEW_NOT_FOUND = "includeContractPackagingView not found. Setting includeContractPackagingView set to False.";
	String MSG_RUNTIME_NOT_FOUND = "runTime not found, or not a number. Setting runTime to 0 (no limit)";
	String MSG_TYPEPOSITION_NOT_FOUND = "TypePositionInLoadFile not found. Setting Type column to 0";
	String MSG_NAMEPOSITION_NOT_FOUND = "NamePositionInLoadFile not found. Setting Name column to 1";
	String MSG_REVPOSITION_NOT_FOUND = "RevPositionInLoadFile not found. Setting revision column to 2";
	String MSG_RUNTIME_FOUND = "RunTime(In Millies) set to ";
	String MSG_TYPEPOSITION_FOUND = "Type Column Position set to ";
	String MSG_NAMEPOSITION_FOUND = "Name Column Position set to ";
	String MSG_REVPOSITION_FOUND = "Revision Column Position set to ";
	String MSG_SUCCESSFULL_EXTRACTION_METADATA = "Successfully Extracted Metadata \n";
	String MSG_SUCCESSFULL_EXTRACTION = "Successfully Extracted";
	String MSG_RUNTIME_EXCEEDED = "RunTime Exceeded!";
	String MSG_SUCCESSFULLY_WRITTEN_INTO_NEWFILE = "Successfully Written Remaining Entry of Input File into New Input File- ";
	String MSG_NO_CONNECTION_FOUND = "No Connection found for";
	String MSG_FILE_NOT_DELETED = "File Not deleted";
	String PDFVIEW_RENDITION = "Rendition";
	String PDFVIEW_ALLINFO = "AllInfo";
	String PDFVIEW_SUPPLIER = "Supplier";
	String PDFVIEW_CONTRACTPACKAGING = "ContractPackaging";
	String PDFVIEW_CONSOLIDATEDPACKAGING = "ConsolidatedPackaging";
	String PDFVIEW_COMBINEDWITHMASTER = "CombinedWithMaster";
	String PDFVIEW_WAREHOUSE = "Warehouse";
	String PDFVIEW_GENDOC = "GenDoc";
	String RUNTIME_IN_MILES = "\n runTimeInMillies :: ";
	String SYMBOL_NEXT_LINE = "\n";
	String SYMBOL_SPACE = " ";
	String SYMBOL_FORWARD_SLASH = "/";
	String SYMBOL_EQUALS = " == ";
	String SYMBOL_OR = "||";
	String SYMBOL_AND = "&&";
	String SYMBOL_COLON = ": ";
	String SYMBOL_DOT = ".";
	String SYMBOL_COMMA = ",";
	String SYMBOL_UNDERSCORE = "_";
	String ATTRIBUTE_OPTIONAL_COMPONENT = PropertyUtil.getSchemaProperty("attribute_pgOptionalComponent");
	String SELECT_ATTRIBUTE_OPTIONAL_COMPONENT = "attribute[" + ATTRIBUTE_OPTIONAL_COMPONENT + "]";
	String ATTRIBUTE_PGOPTIONALCOMPONENT = PropertyUtil.getSchemaProperty("attribute_pgOptionalComponent");
	String SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT = "attribute[" + ATTRIBUTE_PGOPTIONALCOMPONENT + "]";
	String ATTRIBUTE_PGNETWEIGHT = PropertyUtil.getSchemaProperty("attribute_pgNetWeight");
	String SELECT_ATTRIBUTE_PGNETWEIGHT = "attribute[" + ATTRIBUTE_PGNETWEIGHT + "]";
	String ATTRIBUTE_PGNETWEIGHTUOM = PropertyUtil.getSchemaProperty("attribute_pgNetWeightUnitOfMeasure");
	String SELECT_ATTRIBUTE_PGNETWEIGHTUOM = "attribute[" + ATTRIBUTE_PGNETWEIGHTUOM + "]";
	String ATTRIBUTE_MASTERTITLE = PropertyUtil.getSchemaProperty("attribute_Title");
	String ATTRIBUTE_PGAREA = PropertyUtil.getSchemaProperty("attribute_pgArea");
	String SELECT_ATTRIBUTE_PGAREA = "attribute[" + ATTRIBUTE_PGAREA + "]";
	String ATTRIBUTE_PGCONSUMERCOMMENTLANGUAGE = PropertyUtil.getSchemaProperty("attribute_pgConsumerCommentLanguage");
	String SELECT_ATTRIBUTE_PGCONSUMERCOMMENTLANGUAGE = "attribute[" + ATTRIBUTE_PGCONSUMERCOMMENTLANGUAGE + "]";
	String ATTRIBUTE_PGCONSUMERNEED = PropertyUtil.getSchemaProperty("attribute_pgConsumerNeed");
	String SELECT_ATTRIBUTE_PGCONSUMERNEED = "attribute[" + ATTRIBUTE_PGCONSUMERNEED + "]";
	String ATTRIBUTE_PGDESIGNIMPACT = PropertyUtil.getSchemaProperty("attribute_pgDesignImpact");
	String SELECT_ATTRIBUTE_PGDESIGNIMPACT = "attribute[" + ATTRIBUTE_PGDESIGNIMPACT + "]";
	String ATTRIBUTE_PGPARAMETERTYPE = PropertyUtil.getSchemaProperty("attribute_pgParameterType");
	String SELECT_ATTRIBUTE_PGPARAMETERTYPE = "attribute[" + ATTRIBUTE_PGPARAMETERTYPE + "]";
	String ATTRIBUTE_PGVOLUME = PropertyUtil.getSchemaProperty("attribute_pgVolume");
	String SELECT_ATTRIBUTE_PGVOLUME = "attribute[" + ATTRIBUTE_PGVOLUME + "]";
	String ATTRIBUTE_PGGROSSWEIGHTWITHPALLET = PropertyUtil.getSchemaProperty("attribute_pgGrossWeightWithPallet");
	String SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLET = "attribute[" + ATTRIBUTE_PGGROSSWEIGHTWITHPALLET + "]";
	String ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLET = PropertyUtil
			.getSchemaProperty("attribute_pgGrossWeightWithoutPallet");
	String SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLET = "attribute[" + ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLET + "]";
	String ATTRIBUTE_INCINAME = PropertyUtil.getSchemaProperty("attribute_INCIName");
	String ATTRIBUTE_CITY = PropertyUtil.getSchemaProperty("attribute_City");
	String ATTRIBUTE_COUNTRY = PropertyUtil.getSchemaProperty("attribute_Country");
	String ATTRIBUTE_CHEMICALNAME = PropertyUtil.getSchemaProperty("attribute_ChemicalName");
	String SELECT_ATTRIBUTE_INCINAME = "attribute[" + ATTRIBUTE_INCINAME + "]";
	String SELECT_ATTRIBUTE_CHEMICALNAME = "attribute[" + ATTRIBUTE_CHEMICALNAME + "]";
	String ATTRIBUTE_PGARCHIVECOMMENT = PropertyUtil.getSchemaProperty("attribute_pgArchiveComment");
	String SELECT_ATTRIBUTE_PGARCHIVECOMMENT = "attribute[" + ATTRIBUTE_PGARCHIVECOMMENT + "]";
	String SELECT_ATTRIBUTE_PGISBATTERY = "attribute[" + ATTRIBUTE_PGISBATTERY + "]";
	String SELECT_ATTRIBUTE_PGCONTAINSBATTERY = "attribute[" + ATTRIBUTE_PGCONTAINSBATTERY + "]";
	String SELECT_ATTRIBUTE_PGBATTERYTYPE = "attribute[" + ATTRIBUTE_PGBATTERYTYPE + "]";
	String SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS = "attribute[" + ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS + "]";
	String SELECT_ATTRIBUTE_PGSTORAGEINFORMATION = "attribute[" + ATTRIBUTE_PGSTORAGEINFORMATION + "]";
	String SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS = "attribute[" + ATTRIBUTE_PGSTORAGETEMPERATURELIMITS + "]";
	String SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS = "attribute[" + ATTRIBUTE_PGSHIPPINGINSTRUCTIONS + "]";
	String SELECT_ATTRIBUTE_PGDENSITYUOM = "attribute[" + ATTRIBUTE_PGDENSITYUOM + "]";
	String SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY = "attribute[" + ATTRIBUTE_PGONSHELFPRODUCTDENSITY + "]";
	String SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT = "attribute[" + ATTRIBUTE_PGPRODUCTEXTRAVARIANT + "]";
	String SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY = "attribute[" + ATTRIBUTE_PGPACKAGINGTECHNOLOGY + "]";
	String SELECT_ATTRIBUTE_PGLABELINGINFORMATION = "attribute[" + ATTRIBUTE_PGLABELINGINFORMATION + "]";
	String ATTRIBUTE_MINACTUAL_PERCENTWET = PropertyUtil.getSchemaProperty("attribute_pgMinActualPercenWet");
	String SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET = "attribute[" + ATTRIBUTE_MINACTUAL_PERCENTWET + "]";
	String ATTRIBUTE_MAXACTUALPERCENTWET = PropertyUtil.getSchemaProperty("attribute_pgMaxActualPercenWet");
	String SELECT_ATTRIBUTE_MAXACTUALPERCENTWET = "attribute[" + ATTRIBUTE_MAXACTUALPERCENTWET + "]";
	String ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID = PropertyUtil
			.getSchemaProperty("attribute_VirtualIntermediatePhysicalId");
	String SELECT_ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID = "attribute[" + ATTRIBUTE_VIRTUALINTERMEDIATEPHYSICALID
			+ "]";
	String ATTRIBUTE_PREFERREDNAME = PropertyUtil.getSchemaProperty("attribute_PreferredName");
	String SELECT_ATTRIBUTE_PREFERREDNAME = "attribute[" + ATTRIBUTE_PREFERREDNAME + "]";
	String ATTRIBUTE_TARGETWEIGHTDRY = PropertyUtil.getSchemaProperty("attribute_TargetWeightDry");
	String SELECT_ATTRIBUTE_TARGETWEIGHTDRY = "attribute[" + ATTRIBUTE_TARGETWEIGHTDRY + "].inputvalue";
	String ATTRIBUTE_PROCESSINGNOTE = PropertyUtil.getSchemaProperty("attribute_ProcessingNote");
	String SELECT_ATTRIBUTE_PROCESSINGNOTE = "attribute[" + ATTRIBUTE_PROCESSINGNOTE + "]";
	String ATTRIBUTE_ORIGINATOR = PropertyUtil.getSchemaProperty("attribute_Originator");
	String SELECT_ATTRIBUTE_ORIGINATOR = "attribute[" + ATTRIBUTE_ORIGINATOR + "]";
	String KEY_NO = "No";
	String RELATIONSHIP_PGMEPTOPGPLANT = PropertyUtil.getSchemaProperty("relationship_pgMEPtopgPlant");
	String ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE = PropertyUtil
			.getSchemaProperty("attribute_pgBatchUnitSizeUnitOfMeasure");
	String SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE + "]";
	String ATTRIBUTE_PGQUANTITYFORPRODUCTIS = PropertyUtil.getSchemaProperty("attribute_pgQuantityForProductIs");
	String SELECT_ATTRIBUTE_PGQUANTITYFORPRODUCTIS = "attribute[" + ATTRIBUTE_PGQUANTITYFORPRODUCTIS + "]";
	String ATTRIBUTE_MANUFACTURER = PropertyUtil.getSchemaProperty("attribute_Manufacturer");
	String SELECT_ATTRIBUTE_MANUFACTURER = "attribute[" + ATTRIBUTE_MANUFACTURER + "]";
	String TYPE_PGPLIMATERIALFUNCTIONGLOBAL = PropertyUtil.getSchemaProperty("type_pgPLIMaterialFunctionGlobal");
	String RELATIONSHIP_MATERIALFUNCTIONALITY = PropertyUtil.getSchemaProperty("relationship_MaterialFunctionality");
	String ATTRIBUTE_PGINGREDIENTLOSS = PropertyUtil.getSchemaProperty("attribute_pgIngredientLoss");
	String SELECT_ATTRIBUTE_PGINGREDIENTLOSS = "attribute[" + ATTRIBUTE_PGINGREDIENTLOSS + "]";
	String ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE = PropertyUtil
			.getSchemaProperty("attribute_pgIngredientLossUnitOfMeasure");
	String SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE
			+ "]";
	String ATTRIBUTE_PGSUBTOTAL = PropertyUtil.getSchemaProperty("attribute_pgSubTotal");
	String ATTRIBUTE_PGSUBTOTALUNITOFMEASURE = PropertyUtil.getSchemaProperty("attribute_pgSubTotalUnitOfMeasure");
	String SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE = "attribute[" + ATTRIBUTE_PGSUBTOTALUNITOFMEASURE + "]";
	String ATTRIBUTE_PGINGREDIENTLOSSCOMMENT = PropertyUtil.getSchemaProperty("attribute_pgIngredientLossComment");
	String SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT = "attribute[" + ATTRIBUTE_PGINGREDIENTLOSSCOMMENT + "]";
	String ATTRIBUTE_PGBATCHUNITSIZE = PropertyUtil.getSchemaProperty("attribute_pgBatchUnitSize");
	String SELECT_ATTRIBUTE_PGBATCHUNITSIZE = "attribute[" + ATTRIBUTE_PGBATCHUNITSIZE + "]";
	String ATTRIBUTE_PGARCHIVEREASON = PropertyUtil.getSchemaProperty("attribute_pgArchiveReason");
	String SELECT_ATTRIBUTE_PGARCHIVEREASON = "attribute[" + ATTRIBUTE_PGARCHIVEREASON + "]";
	String SELECT_ATTRIBUTE_PGLASTUPDATEUSER = "attribute[" + ATTRIBUTE_PGLASTUPDATEUSER + "]";
	String ATTRIBUTE_PGOTHERDISTRIBUTIONLIST = PropertyUtil.getSchemaProperty("attribute_pgOtherDistributionList");
	String ATTRIBUTE_PGUNARCHIVEREASON = PropertyUtil.getSchemaProperty("attribute_pgUnarchiveReason");
	String SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST = "attribute[" + ATTRIBUTE_PGOTHERDISTRIBUTIONLIST + "]";
	String SELECT_ATTRIBUTE_PGUNARCHIVEREASON = "attribute[" + ATTRIBUTE_PGUNARCHIVEREASON + "]";
	String SELECT_ATTRIBUTE_PGSEGMENT = "attribute[" + ATTRIBUTE_PGSEGMENT + "]";
	String SELECT_ATTRIBUTE_PGGLOBALFORM = "attribute[" + ATTRIBUTE_PGGLOBALFORM + "]";
	String ATTRIBUTE_PGREGION = PropertyUtil.getSchemaProperty("attribute_pgRegion");
	String SELECT_ATTRIBUTE_PGREGION = "attribute[" + ATTRIBUTE_PGREGION + "]";
	String ATTRIBUTE_PGSECTOR = PropertyUtil.getSchemaProperty("attribute_pgSector");
	String SELECT_ATTRIBUTE_PGSECTOR = "attribute[" + ATTRIBUTE_PGSECTOR + "]";
	String ATTRIBUTE_PGSUBSECTOR = PropertyUtil.getSchemaProperty("attribute_pgSubSector");
	String SELECT_ATTRIBUTE_PGSUBSECTOR = "attribute[" + ATTRIBUTE_PGSUBSECTOR + "]";
	String ATTRIBUTE_PGCHANGEAPPROVER = PropertyUtil.getSchemaProperty("attribute_pgChangeApprover");
	String SELECT_ATTRIBUTE_PGCHANGEAPPROVER = "attribute[" + ATTRIBUTE_PGCHANGEAPPROVER + "]";
	String RELATIONSHIP_PGTOSHIPPINGHAZARDCLASSSIFICATION = PropertyUtil
			.getSchemaProperty("relationship_pgToShippingHazardClasssification");
	String ATTRIBUTE_STATEREGION = PropertyUtil.getSchemaProperty("attribute_StateRegion");
	String SELECT_ATTRIBUTE_STATEREGION = "attribute[" + ATTRIBUTE_STATEREGION + "]";
	String SELECT_ATTRIBUTE_PGSUBTOTAL = "attribute[" + ATTRIBUTE_PGSUBTOTAL + "]";
	String ATTRIBUTE_SUBSTANCENAME = PropertyUtil.getSchemaProperty("attribute_SubstanceName");
	String SELECT_ATTRIBUTE_SUBSTANCENAME = "attribute[" + ATTRIBUTE_SUBSTANCENAME + "]";
	String ATTRIBUTE_ISTARGETMATERIAL = PropertyUtil.getSchemaProperty("attribute_IsTargetMaterial");
	String SELECT_ATTRIBUTE_ISTARGETMATERIAL = "attribute[" + ATTRIBUTE_ISTARGETMATERIAL + "]";
	String ERROR_GCAS_NOT_FOUND = "Error :  GCAS not found ";
	String ERROR_COUNTRY_NOT_FOUND = "Error : Country not found ";
	String ERROR = "ERROR: ";
	String SUCCESS = "success";
	String CONFIG_OBJECT_NOT_FOUND = "configObjectName not found. Hence Exiting.";
	String CONFIG_OBJECT_NOT_EXISTS = "Config Object does not exist. Hence Exiting.";
	String RUNNING_ENV_NOT_FOUND = "runningEnv not found. Hence Exiting.";
	String CONFIGOBJECT_ACTIVE = "Config Object is Active. Hence Divestiture Data Extraction cannot be executed.";
	String CONFIGOBJECT_RETRYATTEMPT_EXCEEDED = "Config Object Retry Attempt exceeded. Hence sending an email.";
	String MAIL_SUCCESSFULLY_SENT = "Mail Sent Successfully.";
	String SENDING_MAIL_FAILED = "Exception in Sending Mail : ";
	String MAIL_SUBJECT = "Status of Divestiture Mass Data Extraction scheduled job in ";
	String MAIL_START = "Hi,";
	String MAIL_MESSAGE = "Divestiture Mass Data Extraction is stuck and not executed properly for last 2 scheduled runs. Please look into the issue.";
	String MAIL_END = "Thanks.";
	String ATTRIBUTE_PGCONFIGISACTIVE = PropertyUtil.getSchemaProperty("attribute_pgConfigCommonIsActive");
	String SELECT_ATTRIBUTE_PGCONFIGISACTIVE = "attribute[" + ATTRIBUTE_PGCONFIGISACTIVE + "]";
	String ATTRIBUTE_PGCONFIGCOMMONRETRYCOUNT = PropertyUtil.getSchemaProperty("attribute_pgConfigCommonRetryCount");
	String SELECT_ATTRIBUTE_PGCONFIGCOMMONRETRYCOUNT = "attribute[" + ATTRIBUTE_PGCONFIGCOMMONRETRYCOUNT + "]";
	String ATTRIBUTE_PGCONFIGCOMMONADMINMAILID = PropertyUtil.getSchemaProperty("attribute_pgConfigCommonAdminMailId");
	String SELECT_ATTRIBUTE_PGCONFIGCOMMONADMINMAILID = "attribute[" + ATTRIBUTE_PGCONFIGCOMMONADMINMAILID + "]";
	String ATTRIBUTE_PGCONFIGCOMMONDSTARTEDDATE = PropertyUtil.getSchemaProperty("attribute_pgConfigCommonStartedDate");
	String SELECT_ATTRIBUTE_PGCONFIGCOMMONDSTARTEDDATE = "attribute[" + ATTRIBUTE_PGCONFIGCOMMONDSTARTEDDATE + "]";
	String ATTRIBUTE_REQUESTEDCHANGE = PropertyUtil.getSchemaProperty("attribute_RequestedChange");
	String SELECT_ATTRIBUTE_REQUESTEDCHANGE = "attribute[" + ATTRIBUTE_REQUESTEDCHANGE + "]";
	String For_Release = "For Release";
	String ATTRIBUTE_QUALIFICATIONDESCRIPTION = PropertyUtil.getSchemaProperty("attribute_QualificationDescription");
	String SELECT_ATTRIBUTE_QUALIFICATIONDESCRIPTION = "attribute[" + ATTRIBUTE_QUALIFICATIONDESCRIPTION + "]";
	String ATTRIBUTE_PGLOCATIONSTATUS = PropertyUtil.getSchemaProperty("attribute_pgLocationStatus");
	String SELECT_ATTRIBUTE_PGLOCATIONSTATUS = "attribute[" + ATTRIBUTE_PGLOCATIONSTATUS + "]";
	String ATTRIBUTE_APPLICATION = PropertyUtil.getSchemaProperty("attribute_Application");
	String SELECT_ATTRIBUTE_APPLICATION = "attribute[" + ATTRIBUTE_APPLICATION + "]";
	String SAP_DATE_FORMAT = "yyyyMMdd";
	String STATE_IN_APPROVAL = "In Approval";
	String SIGNATURE_SOAPPROVAL = "SOApproval";
	String PLANT = "Plant";
	String VENDOR = "Vendor";
	String DELETED = "Deleted";
	String ADDED = "Added";
	String CONSTANT_EXPIRATION_DATE_CRITERIA = "Expiration Date Criteria";
	String STATE_COMPLETE = "Complete";
	String EVENT_MODIFY_WD = "modifyWD";
	String EVENT_MODIFY_WD_TU = "modifyWDTU";
	String EVENT_EFFECTIVITY_DATE = "Effectivity Date";
	String EVENT_CONNECTRD = "connectRD";
	String EVENT_DISCONNECTRD = "disconnectRD";
	String EVENT_CONNECTCOS = "connectCOS";
	String EVENT_DISCONNECTCOS = "disconnectCOS";
	String EVENT_OVERALLCLEARANCESTATUS = "OverallClearanceStatus";
	String EVENT_COSRESTRICTION = "COSRestriction";
	String EVENT_CONNECTCOSCLEARANCE = "connectCOSClearance";
	String EVENT_DISCONNECTCOSCLEARANCE = "disconnectCOSClearance";
	String EVENT_CONNECTPLANT = "connectPlant";
	String EVENT_DISCONNECTPLANT = "disconnectPlant";
	String EVENT_DEMOTE = "Demote";
	String EVENT_CONNECTEBOM = "connectEBOM";
	String ATTRIBUTE_PGDSEXPIRATIONEVENT = PropertyUtil.getSchemaProperty("attribute_pgDSExpirationEvent");
	String ATTRIBUTE_PGDSNONEXPIRATIONEVENT = PropertyUtil.getSchemaProperty("attribute_pgDSNonExpirationEvent");
	String ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPOLICY = PropertyUtil
			.getSchemaProperty("attribute_pgDynamicSubscriptionPolicy");
	String RELATIONSHIP_PGDOCUMENTTOPLATFORM = PropertyUtil.getSchemaProperty("relationship_pgDocumentToPlatform");
	String RELATIONSHIP_PGDOCUMENTTOBUSINESSAREA = PropertyUtil
			.getSchemaProperty("relationship_pgDocumentToBusinessArea");
	String PQR_VIEW = "PQR";
	String STRING_MANUFACTUREREQUIVALENTPART = "Manufacturer Equivalent Part";
	String STRING_SUPPLIEREQUIVALENTPART = "Supplier Equivalent Part";
	String ERROR_NEW_INPUT_FILENAME_NOT_FOUND = "newInputFilename not found. Hence setting runTime to 0 (no limit)";
	String ERROR_PDFUSER_NOT_FOUND = "pdfUser not found. Hence Exiting.";
	String MAP_KEY_BOM_TARGET = "BOMTarget";
	String POLICY_CPNGLOBALSUBSCRIPTIONCONFIGURATION = PropertyUtil
			.getSchemaProperty("policy_CPNGlobalSubscriptionConfiguration");
	String PGDYNAMICSUBSCRIPTIONJOB = "pgDynamicSubscriptionJob";
	String NUMBEROFJOBS = "Number of Jobs";
	String ATTRIBUTE_PGENABLECABATCHPROCESS = PropertyUtil.getSchemaProperty("attribute_pgEnableCABatchProcess");
	String SELECT_ATTRIBUTE_PGENABLECABATCHPROCESS = "attribute[" + ATTRIBUTE_PGENABLECABATCHPROCESS + "]";
	String GLOBALSUBSCRIPTIONOBJECT = "Global Subscription Object";
	String GLOBALSUBSCRIPTIONOBJECTTHREAD = "Global Subscription Object Thread";
	String ATTRIBUTE_PGEINECSELINCSNUMBER = PropertyUtil.getSchemaProperty("attribute_pgEinecsElincsNumber");
	String SELECT_ATTRIBUTE_PGEINECSELINCSNUMBER = "attribute[" + ATTRIBUTE_PGEINECSELINCSNUMBER + "]";
	String QUALIFICATION_STATE_INPROCESS = "In Process";
	String QUALIFICATION_STATE_QUALIFIED = "Qualified";
	String ATTRIBUTE_SUBSTITUTEINSTRUCTIONS = PropertyUtil.getSchemaProperty("attribute_SubstituteInstructions");
	String SELECT_ATTRIBUTE_SUBSTITUTEINSTRUCTIONS = "attribute[" + ATTRIBUTE_SUBSTITUTEINSTRUCTIONS + "]";
	String RELATIONSHIP_PGPLSUBLISTITEM = PropertyUtil.getSchemaProperty("relationship_pgPLSubsetItem");
	String TYPE_PGPLSUBSETLIST = PropertyUtil.getSchemaProperty("type_pgPLSubsetList");
	String ATTRIBUTE_PGCSSSUBTYPE = PropertyUtil.getSchemaProperty("attribute_pgCSSSubType");
	String PDF_VIEW = "View";
	String THIRD_PARTY = "Third Party";
	String THIRD_PARTY_FORMULA = "Third Party Formula";
	String TYPE_PGLABORATORYINDEXSPECIFICATION = PropertyUtil.getSchemaProperty("type_pgLaboratoryIndexSpecification");
	String ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED = PropertyUtil
			.getSchemaProperty("attribute_pgIsProductCertificationorLocalStandardsComplianceStatementRequired");
	String SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED = "attribute["
			+ ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED + "]";
	String ATTRIBUTE_PGPRODUCTDOSEPERUSE = PropertyUtil.getSchemaProperty("attribute_pgProductDoseperUse");
	String SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE = "attribute[" + ATTRIBUTE_PGPRODUCTDOSEPERUSE + "]";
	String ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM = PropertyUtil.getSchemaProperty("attribute_pgProductDoseperUseUoM");
	String SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM = "attribute[" + ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM + "]";
	String ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE = PropertyUtil.getSchemaProperty("attribute_pgExpectedFrequencyofUse");
	String SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE = "attribute[" + ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE + "]";
	String ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM = PropertyUtil
			.getSchemaProperty("attribute_pgExpectedFrequencyofUseUoM");
	String SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM = "attribute[" + ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM + "]";
	String ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL = PropertyUtil.getSchemaProperty("attribute_pgModeofProductDisposal");
	String SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL = "attribute[" + ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL + "]";
	String ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN = PropertyUtil
			.getSchemaProperty("attribute_pgProductExposedToChildren");
	String SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN = "attribute[" + ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN + "]";
	String ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT = PropertyUtil
			.getSchemaProperty("attribute_pgProductMarketedAsChildrenProduct");
	String SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT = "attribute["
			+ ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT + "]";
	String ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN = PropertyUtil
			.getSchemaProperty("attribute_pgDoestheProductRequireChildSafeDesign");
	String SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN = "attribute["
			+ ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN + "]";
	String ATTRIBUTE_PGMATERIALCERTIFICATIONS = PropertyUtil.getSchemaProperty("attribute_pgMaterialCertifications");
	String SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS = "attribute[" + ATTRIBUTE_PGMATERIALCERTIFICATIONS + "]";
	String ATTRIBUTE_PGISTHEDESIGNCHILDSAFE = PropertyUtil.getSchemaProperty("attribute_pgIstheDesignChildSafe");
	String SELECT_ATTRIBUTE_PGISTHEDESIGNCHILDSAFE = "attribute[" + ATTRIBUTE_PGISTHEDESIGNCHILDSAFE + "]";
	String TYPE_PGCOMPETITIVEPRODUCTPART = PropertyUtil.getSchemaProperty("type_pgCompetitiveProductPart");
	String ATTRIBUTE_PGEXPECTEDREGULATORYPRODUCTCLASSIFICATION = PropertyUtil
			.getSchemaProperty("attribute_pgExpectedRegulatoryProductClassification");
	String SELECT_ATTRIBUTE_PGEXPECTEDREGULATORYPRODUCTCLASSIFICATION = "attribute["
			+ ATTRIBUTE_PGEXPECTEDREGULATORYPRODUCTCLASSIFICATION + "]";
	String ATTRIBUTE_PGPOWERSOURCE = PropertyUtil.getSchemaProperty("attribute_pgPowerSource");
	String SELECT_ATTRIBUTE_PGPOWERSOURCE = "attribute[" + ATTRIBUTE_PGPOWERSOURCE + "]";
	String RESTRICTED = "Restricted";
	String INTERNAL_USE = "Internal Use";
	String BUSINESS_USE = "Business Use";
	String BUSINESS_USE_HYPHEN = "Business Use -";
	String ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION = PropertyUtil
			.getSchemaProperty("attribute_pgProductRegulatoryClassification");
	String SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION = "attribute["
			+ ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION + "]";
	String ATTRIBUTE_PGSTUDYLAUNCHDATE = PropertyUtil.getSchemaProperty("attribute_pgStudyLaunchDate");
	String SELECT_ATTRIBUTE_PGSTUDYLAUNCHDATE = "attribute[" + ATTRIBUTE_PGSTUDYLAUNCHDATE + "]";
	String ATTRIBUTE_PGSTUDYIMPLEMENTSSUPPLIED = PropertyUtil.getSchemaProperty("attribute_pgStudyImplementsSupplied");
	String SELECT_ATTRIBUTE_PGSTUDYIMPLEMENTSSUPPLIED = "attribute[" + ATTRIBUTE_PGSTUDYIMPLEMENTSSUPPLIED + "]";
	String ATTRIBUTE_PGSTUDYSUPERVISED = PropertyUtil.getSchemaProperty("attribute_pgStudySupervised");
	String SELECT_ATTRIBUTE_PGSTUDYSUPERVISED = "attribute[" + ATTRIBUTE_PGSTUDYSUPERVISED + "]";
	String ATTRIBUTE_PGSTUDYBLANKETREQUEST = PropertyUtil.getSchemaProperty("attribute_pgStudyBlanketRequest");
	String SELECT_ATTRIBUTE_PGSTUDYBLANKETREQUEST = "attribute[" + ATTRIBUTE_PGSTUDYBLANKETREQUEST + "]";
	String ATTRIBUTE_PGSTUDYCOMPETITIVEPRODUCTPART = PropertyUtil
			.getSchemaProperty("attribute_pgStudyCompetitiveProductPart");
	String SELECT_ATTRIBUTE_PGSTUDYCOMPETITIVEPRODUCTPART = "attribute[" + ATTRIBUTE_PGSTUDYCOMPETITIVEPRODUCTPART
			+ "]";
	String ATTRIBUTE_PGSTUDYSKINLAB = PropertyUtil.getSchemaProperty("attribute_pgStudySkinLab");
	String SELECT_ATTRIBUTE_PGSTUDYSKINLAB = "attribute[" + ATTRIBUTE_PGSTUDYSKINLAB + "]";
	String TYPE_PGPKGSTUDYPROTOCOL = PropertyUtil.getSchemaProperty("type_pgPKGStudyProtocol");
	String ATTRIBUTE_NOOFSTUDYPANELISTS = PropertyUtil.getSchemaProperty("attribute_pgNumberofStudyPanelists");
	String SELECT_ATTRIBUTE_NOOFSTUDYPANELISTS = "attribute[" + ATTRIBUTE_NOOFSTUDYPANELISTS + "]";
	String ATTRIBUTE_PGLOWERAGELIMIT = PropertyUtil.getSchemaProperty("attribute_pgLowerAgeLimit");
	String SELECT_ATTRIBUTE_PGLOWERAGELIMIT = "attribute[" + ATTRIBUTE_PGLOWERAGELIMIT + "]";
	String ATTRIBUTE_PGUPPERRAGELIMIT = PropertyUtil.getSchemaProperty("attribute_pgUpperAgeLimit");
	String SELECT_ATTRIBUTE_PGUPPERRAGELIMIT = "attribute[" + ATTRIBUTE_PGUPPERRAGELIMIT + "]";
	String ATTRIBUTE_PGSTUDYNOOFPRODUCTSORVERSION = PropertyUtil
			.getSchemaProperty("attribute_pgStudyNumberOfProductsOrVersions");
	String SELECT_ATTRIBUTE_PGSTUDYNOOFPRODUCTSORVERSION = "attribute[" + ATTRIBUTE_PGSTUDYNOOFPRODUCTSORVERSION + "]";
	String ATTRIBUTE_PGSTUDYNOOFPRODUCTSORVERSIONEXP = PropertyUtil
			.getSchemaProperty("attribute_pgNumberOfProductsOrVersionsPersonExperience");
	String ATTRIBUTE_PGRETURNADDRESS = PropertyUtil.getSchemaProperty("attribute_pgReturnAddress");
	String SELECT_ATTRIBUTE_PGRETURNADDRESS = "attribute[" + ATTRIBUTE_PGRETURNADDRESS + "]";
	String ATTRIBUTE_PGSTUDYSPECIFYNOOFVISITS = PropertyUtil
			.getSchemaProperty("attribute_pgStudySpecifyNumberOfVisits");
	String SELECT_ATTRIBUTE_PGSTUDYSPECIFYNOOFVISITS = "attribute[" + ATTRIBUTE_PGSTUDYSPECIFYNOOFVISITS + "]";
	String ATTRIBUTE_PGSTUDYPANELISTSHOMEWORK = PropertyUtil.getSchemaProperty("attribute_pgStudyPanelistsHomework");
	String SELECT_ATTRIBUTE_PGSTUDYPANELISTSHOMEWORK = "attribute[" + ATTRIBUTE_PGSTUDYPANELISTSHOMEWORK + "]";
	String ATTRIBUTE_PGSTUDYPANELISTEMAIL = PropertyUtil.getSchemaProperty("attribute_pgStudyPanelistEmailAddress");
	String SELECT_ATTRIBUTE_PGSTUDYPANELISTEMAIL = "attribute[" + ATTRIBUTE_PGSTUDYPANELISTEMAIL + "]";
	String ATTRIBUTE_PGSTUDYPANELISTMATERIALS = PropertyUtil.getSchemaProperty("attribute_pgStudyPanelistMaterials");
	String SELECT_ATTRIBUTE_PGSTUDYPANELISTMATERIALS = "attribute[" + ATTRIBUTE_PGSTUDYPANELISTMATERIALS + "]";
	String ATTRIBUTE_PGSTUDYADDRESS = PropertyUtil.getSchemaProperty("attribute_pgStudyAddress");
	String SELECT_ATTRIBUTE_PGSTUDYADDRESS = "attribute[" + ATTRIBUTE_PGSTUDYADDRESS + "]";
	String ATTRIBUTE_PGSTUDYAGREEMENT = PropertyUtil.getSchemaProperty("attribute_pgStudyAgreement");
	String SELECT_ATTRIBUTE_PGSTUDYAGREEMENT = "attribute[" + ATTRIBUTE_PGSTUDYAGREEMENT + "]";
	String ATTRIBUTE_PGSTUDYCDASIGNED = PropertyUtil.getSchemaProperty("attribute_pgStudyCDASignedForPanelist");
	String SELECT_ATTRIBUTE_PGSTUDYCDASIGNED = "attribute[" + ATTRIBUTE_PGSTUDYCDASIGNED + "]";
	String ATTRIBUTE_PGSTUDYPANELISTPURCHASEINTENT = PropertyUtil
			.getSchemaProperty("attribute_pgStudyPanelistPurchaseIntent");
	String SELECT_ATTRIBUTE_PGSTUDYPANELISTPURCHASEINTENT = "attribute[" + ATTRIBUTE_PGSTUDYPANELISTPURCHASEINTENT
			+ "]";
	String ATTRIBUTE_PGNOOFPRODUCTSVERSIONSPERSONEXP = PropertyUtil
			.getSchemaProperty("attribute_pgNumberOfProductsOrVersionsPersonExperience");
	String SELECT_ATTRIBUTE_PGNOOFPRODUCTSVERSIONSPERSONEXP = "attribute[" + ATTRIBUTE_PGNOOFPRODUCTSVERSIONSPERSONEXP
			+ "]";
	String ATTRIBUTE_PGPANELISTPARTICIPATION = PropertyUtil.getSchemaProperty("attribute_pgPanelistParticipation");
	String SELECT_ATTRIBUTE_PGPANELISTPARTICIPATION = "attribute[" + ATTRIBUTE_PGPANELISTPARTICIPATION + "]";
	String RELATIONSHIP_PGDOCTOBUSINESSAREA = PropertyUtil.getSchemaProperty("relationship_pgDocumentToBusinessArea");
	String RELATIONSHIP_PGSTUDYPROTOCOLTORESEARCHTYOE = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToResearchType");
	String RELATIONSHIP_PGSTUDYPROTOCOLTOGENDER = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToGender");
	String RELATIONSHIP_PGSTUDYPROTOCOLTOPANELISTTYPE = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToPanelistType");
	String RELATIONSHIP_PGSTUDYPROTOCOLTORACE = PropertyUtil.getSchemaProperty("relationship_pgStudyProtocolToRace");
	String RELATIONSHIP_PGSTUDYPROTOCOLTODATACOLLECTIONMETHODS = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToDataCollectionMethods");
	String RELATIONSHIP_PGSTUDYPROTOCOLTOSTUDYLOCATIONS = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToStudyLocations");
	String RELATIONSHIP_PGSTUDYPROTOCOLTOSTUDYTYPE = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToStudyType");
	String RELATIONSHIP_PGSTUDYPROTOCOLTOADDITIONALSERVICES = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToAdditionalServices");
	String RELATIONSHIP_PGSTUDYPROTOCOLTODATAMERGE = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToDataMerge");
	String RELATIONSHIP_PGSTUDYPROTOCOLTOCONFIDENCELEVEL = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToConfidenceLevel");
	String RELATIONSHIP_PGSTUDYPROTOCOLTOASSESSMENTREQUIRED = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToAssessmentRequired");
	String RELATIONSHIP_PGDOCUMENTTOCHASSIS = PropertyUtil.getSchemaProperty("relationship_pgDocumentToChassis");
	String RELATIONSHIP_OBJECTROUTE = PropertyUtil.getSchemaProperty("relationship_ObjectRoute");
	String ATTRIBUTE_ROUTEBASESTATE = PropertyUtil.getSchemaProperty("attribute_RouteBaseState");
	String SELECT_ATTRIBUTE_ROUTEBASESTATE = "attribute[" + ATTRIBUTE_ROUTEBASESTATE + "]";
	String RELATIONSHIP_ROUTETASK = PropertyUtil.getSchemaProperty("relationship_RouteTask");
	String ATTRIBUTE_APPROVALSTATUS = PropertyUtil.getSchemaProperty("attribute_ApprovalStatus");
	String SELECT_ATTRIBUTE_APPROVALSTATUS = "attribute[" + ATTRIBUTE_APPROVALSTATUS + "]";
	String POLICY_PGPARALLELCLONEPRODUCTDATAPART = PropertyUtil
			.getSchemaProperty("policy_pgParallelCloneProductDataPart");
	String TYPE_PGSTUDYLEG = PropertyUtil.getSchemaProperty("type_pgStudyLeg");
	String RELATIONSHIP_PGLEGPROCESS = PropertyUtil.getSchemaProperty("relationship_pgLegProcess");
	String RELATIONSHIP_PGLEGINPUT = PropertyUtil.getSchemaProperty("relationship_pgLegInput");
	String ATTRIBUTE_PGNUMBEROFPANELISTS = PropertyUtil.getSchemaProperty("attribute_pgNumberOfPanelists");
	String SELECT_ATTRIBUTE_PGNUMBEROFPANELISTS = "attribute[" + ATTRIBUTE_PGNUMBEROFPANELISTS + "]";
	String ATTRIBUTE_PGPLACEMENTS = PropertyUtil.getSchemaProperty("attribute_pgPlacements");
	String SELECT_ATTRIBUTE_PGPLACEMENTS = "attribute[" + ATTRIBUTE_PGPLACEMENTS + "]";
	String ATTRIBUTE_PGMINIMUMTARGETLEVEL = PropertyUtil.getSchemaProperty("attribute_pgMinimumTargetLevel");
	String SELECT_ATTRIBUTE_PGMINIMUMTARGETLEVEL = "attribute[" + ATTRIBUTE_PGMINIMUMTARGETLEVEL + "]";
	String ATTRIBUTE_PGMAXIUMTARGETLEVEL = PropertyUtil.getSchemaProperty("attribute_pgMaxiumTargetLevel");
	String SELECT_ATTRIBUTE_PGMAXIUMTARGETLEVEL = "attribute[" + ATTRIBUTE_PGMAXIUMTARGETLEVEL + "]";
	String ATTRIBUTE_PGWASHOUTTIMEBETWEENPRODUCTS = PropertyUtil
			.getSchemaProperty("attribute_pgWashoutTimeBetweenProducts");
	String SELECT_ATTRIBUTE_PGWASHOUTTIMEBETWEENPRODUCTS = "attribute[" + ATTRIBUTE_PGWASHOUTTIMEBETWEENPRODUCTS + "]";
	String ATTRIBUTE_PGSTABILITYSAMPLECOUNT = PropertyUtil.getSchemaProperty("attribute_pgStabilitySampleCount");
	String SELECT_ATTRIBUTE_PGSTABILITYSAMPLECOUNT = "attribute[" + ATTRIBUTE_PGSTABILITYSAMPLECOUNT + "]";
	String ATTRIBUTE_PGANALYTICALSAMPLECOUNT = PropertyUtil.getSchemaProperty("attribute_pgAnalyticalSampleCount");
	String SELECT_ATTRIBUTE_PGANALYTICALSAMPLECOUNT = "attribute[" + ATTRIBUTE_PGANALYTICALSAMPLECOUNT + "]";
	String ATTRIBUTE_PGRNDTEAMSAMPLECOUNT = PropertyUtil.getSchemaProperty("attribute_pgRnDTeamSampleCount");
	String SELECT_ATTRIBUTE_PGRNDTEAMSAMPLECOUNT = "attribute[" + ATTRIBUTE_PGRNDTEAMSAMPLECOUNT + "]";
	String ATTRIBUTE_PGINVENTORYSAMPLECOUNT = PropertyUtil.getSchemaProperty("attribute_pgInventorySampleCount");
	String SELECT_ATTRIBUTE_PGINVENTORYSAMPLECOUNT = "attribute[" + ATTRIBUTE_PGINVENTORYSAMPLECOUNT + "]";
	String ATTRIBUTE_PGNUMBEROFUNITSTOSHIP = PropertyUtil.getSchemaProperty("attribute_pgNumberOfUnitsToShip");
	String SELECT_ATTRIBUTE_PGNUMBEROFUNITSTOSHIP = "attribute[" + ATTRIBUTE_PGNUMBEROFUNITSTOSHIP + "]";
	String ATTRIBUTE_PGNETSAMPLECOUNT = PropertyUtil.getSchemaProperty("attribute_pgNetSampleCount");
	String SELECT_ATTRIBUTE_PGNETSAMPLECOUNT = "attribute[" + ATTRIBUTE_PGNETSAMPLECOUNT + "]";
	String ATTRIBUTE_PGISPRODUCTANAERSOLSPRAY = PropertyUtil.getSchemaProperty("attribute_pgIsProductanAersolSpray");
	String SELECT_ATTRIBUTE_PGISPRODUCTANAERSOLSPRAY = "attribute[" + ATTRIBUTE_PGISPRODUCTANAERSOLSPRAY + "]";
	String ATTRIBUTE_PGISITPOWEREDDEVICE = PropertyUtil.getSchemaProperty("attribute_pgIsItPoweredDevice");
	String SELECT_ATTRIBUTE_PGISITPOWEREDDEVICE = "attribute[" + ATTRIBUTE_PGISITPOWEREDDEVICE + "]";
	String ATTRIBUTE_PGFINALUNITDESCIRPTION = PropertyUtil.getSchemaProperty("attribute_pgFinalUnitDescirption");
	String SELECT_ATTRIBUTE_PGFINALUNITDESCIRPTION = "attribute[" + ATTRIBUTE_PGFINALUNITDESCIRPTION + "]";
	String ATTRIBUTE_PGPRODUCTCODE = PropertyUtil.getSchemaProperty("attribute_pgProductCode");
	String SELECT_ATTRIBUTE_PGPRODUCTCODE = "attribute[" + ATTRIBUTE_PGPRODUCTCODE + "]";
	String ATTRIBUTE_PGNETCONTENTOFPRODUCTINPACKAGE = PropertyUtil
			.getSchemaProperty("attribute_pgNetContentOfProductInPackage");
	String SELECT_ATTRIBUTE_PGNETCONTENTOFPRODUCTINPACKAGE = "attribute[" + ATTRIBUTE_PGNETCONTENTOFPRODUCTINPACKAGE
			+ "]";
	String ATTRIBUTE_PGLOTNUMBER = PropertyUtil.getSchemaProperty("attribute_pgLotNumber");
	String SELECT_ATTRIBUTE_PGLOTNUMBER = "attribute[" + ATTRIBUTE_PGLOTNUMBER + "]";
	String ATTRIBUTE_PGBLINDCODE = PropertyUtil.getSchemaProperty("attribute_pgBlindCode");
	String SELECT_ATTRIBUTE_PGBLINDCODE = "attribute[" + ATTRIBUTE_PGBLINDCODE + "]";
	String ATTRIBUTE_PGBATCH = PropertyUtil.getSchemaProperty("attribute_pgBatch");
	String SELECT_ATTRIBUTE_PGBATCH = "attribute[" + ATTRIBUTE_PGBATCH + "]";
	String ATTRIBUTE_PGDOSAGE = PropertyUtil.getSchemaProperty("attribute_pgDosage");
	String SELECT_ATTRIBUTE_PGDOSAGE = "attribute[" + ATTRIBUTE_PGDOSAGE + "]";
	String ATTRIBUTE_PGFREQUENCY = PropertyUtil.getSchemaProperty("attribute_pgFrequency");
	String SELECT_ATTRIBUTE_PGFREQUENCY = "attribute[" + ATTRIBUTE_PGFREQUENCY + "]";
	String ATTRIBUTE_PGUSAGEPERIOD = PropertyUtil.getSchemaProperty("attribute_pgUsagePeriod");
	String SELECT_ATTRIBUTE_PGUSAGEPERIOD = "attribute[" + ATTRIBUTE_PGUSAGEPERIOD + "]";
	String ATTRIBUTE_PGFILLAMOUNT = PropertyUtil.getSchemaProperty("attribute_pgFillAmount");
	String SELECT_ATTRIBUTE_PGFILLAMOUNT = "attribute[" + ATTRIBUTE_PGFILLAMOUNT + "]";
	String RELATIONSHIP_PGINTENDEDMARKETS = PropertyUtil.getSchemaProperty("relationship_pgIntendedMarkets");
	String ATTRIBUTE_PGINGREDIENTLOSSCOMMENTS = PropertyUtil.getSchemaProperty("attribute_pgIngredientLossComments");
	String SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENTS = "attribute[" + ATTRIBUTE_PGINGREDIENTLOSSCOMMENTS + "]";
	String ATTRIBUTE_PGTOTAL = PropertyUtil.getSchemaProperty("attribute_pgTotal");
	String SELECT_ATTRIBUTE_PGTOTAL = "attribute[" + ATTRIBUTE_PGTOTAL + "]";
	String ATTRIBUTE_PGSAMEASISSUEDATE = PropertyUtil.getSchemaProperty("attribute_pgSameAsIssueDate");
	String SELECT_ATTRIBUTE_PGSAMEASISSUEDATE = "attribute[" + ATTRIBUTE_PGSAMEASISSUEDATE + "]";
	String ATTRIBUTE_PGPARALLELCLONEPHYSICALID = PropertyUtil.getSchemaProperty("attribute_pgParallelClonePhysicalId");
	String SELECT_ATTRIBUTE_PGPARALLELCLONEPHYSICALID = "attribute[" + ATTRIBUTE_PGPARALLELCLONEPHYSICALID + "]";
	String ATTRIBUTE_PGDANGERCATEGORY = PropertyUtil.getSchemaProperty("attribute_pgDangerCategory");
	String SELECT_ATTRIBUTE_PGDANGERCATEGORY = "attribute[" + ATTRIBUTE_PGDANGERCATEGORY + "]";
	String ATTRIBUTE_PGSAFETYSYMBOL = PropertyUtil.getSchemaProperty("attribute_pgSafetySymbol");
	String SELECT_ATTRIBUTE_PGSAFETYSYMBOL = "attribute[" + ATTRIBUTE_PGSAFETYSYMBOL + "]";
	String TYPE_SOFTWAREBUILD = PropertyUtil.getSchemaProperty("type_SoftwareBuild");
	String TYPE_SOFTWAREPART = PropertyUtil.getSchemaProperty("type_pgSoftwarePart");
	String RELATIONSHIP_ASSIGNEDPART = PropertyUtil.getSchemaProperty("relationship_AssignedPart");
	String EVENT_CONNECTEDSOFTWAREBUILDRELEASED = "connectedSoftwareBuildReleased";
	String EVENT_CONNECTEDSOFTWAREBUILDOBSOLETED = "connectedSoftwareBuildObsoleted";
	String ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER = PropertyUtil
			.getSchemaProperty("attribute_pgCountryProductRegistrationNumber");
	String SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER = "attribute["
			+ ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER + "]";
	String ATTRIBUTE_PGTEMPERATUREGROUP = PropertyUtil.getSchemaProperty("attribute_pgTemparatureGroup");
	String SELECT_ATTRIBUTE_PGTEMPERATUREGROUP = "attribute[" + ATTRIBUTE_PGTEMPERATUREGROUP + "]";
	String ATTRIBUTE_PGHUMIDITYGROUP = PropertyUtil.getSchemaProperty("attribute_pgHumidityGroup");
	String SELECT_ATTRIBUTE_PGHUMIDITYGROUP = "attribute[" + ATTRIBUTE_PGHUMIDITYGROUP + "]";
	String ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION = PropertyUtil
			.getSchemaProperty("attribute_pgTransportFreezeProtection");
	String SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION = "attribute[" + ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION + "]";
	String ATTRIBUTE_PGTRANSPORTHEATPROTECTION = PropertyUtil.getSchemaProperty("attribute_pgTransportHeatProtection");
	String SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION = "attribute[" + ATTRIBUTE_PGTRANSPORTHEATPROTECTION + "]";
	String ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION = PropertyUtil
			.getSchemaProperty("attribute_pgDangerousGoodsClassification");
	String SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION = "attribute[" + ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION
			+ "]";
	String ATTRIBUTE_PGMAXCONSUMERUNITSIZE = PropertyUtil.getSchemaProperty("attribute_pgMaxConsumerUnitSize");
	String SELECT_ATTRIBUTE_PGMAXCONSUMERUNITSIZE = "attribute[" + ATTRIBUTE_PGMAXCONSUMERUNITSIZE + "]";
	String ATTRIBUTE_PGCUSTOMERUNITLABELING = PropertyUtil.getSchemaProperty("attribute_pgCustomerUnitLabeling");
	String SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING = "attribute[" + ATTRIBUTE_PGCUSTOMERUNITLABELING + "]";
	String ATTRIBUTE_PGEVAPORATIONRATE = PropertyUtil.getSchemaProperty("attribute_pgEvaporationRate");
	String SELECT_ATTRIBUTE_PGEVAPORATIONRATE = "attribute[" + ATTRIBUTE_PGEVAPORATIONRATE + "]";
	String ATTRIBUTE_PGCONSUMERUNITLABELING = PropertyUtil.getSchemaProperty("attribute_pgConsumerUnitLabeling");
	String SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING = "attribute[" + ATTRIBUTE_PGCONSUMERUNITLABELING + "]";
	String ATTRIBUTE_PGRESERVEACIDITY = PropertyUtil.getSchemaProperty("attribute_pgReserveAcidity");
	String SELECT_ATTRIBUTE_PGRESERVEACIDITY = "attribute[" + ATTRIBUTE_PGRESERVEACIDITY + "]";
	String ATTRIBUTE_PGRESERVERALKALINITY = PropertyUtil.getSchemaProperty("attribute_pgReserveAlkalinity");
	String SELECT_ATTRIBUTE_PGRESERVERALKALINITY = "attribute[" + ATTRIBUTE_PGRESERVERALKALINITY + "]";
	String ATTRIBUTE_PGTOTALSHELFLIFE = PropertyUtil.getSchemaProperty("attribute_pgTotalShelfLife");
	String SELECT_ATTRIBUTE_PGTOTALSHELFLIFE = "attribute[" + ATTRIBUTE_PGTOTALSHELFLIFE + "]";
	String ATTRIBUTE_PGPRODUCTEXPIRATIONDATE = PropertyUtil
			.getSchemaProperty("attribute_pgExpirationDateForStabilityResults");
	String SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE = "attribute[" + ATTRIBUTE_PGPRODUCTEXPIRATIONDATE + "]";
	String RELATIONSHIP_OWNINGPRODUCTLINE = PropertyUtil.getSchemaProperty("relationship_OwningProductLine");
	String TYPE_PG_GLOBALFORM = PropertyUtil.getSchemaProperty("type_pgGlobalForm");
	String ATTRIBUTE_MARKETING_NAME = PropertyUtil.getSchemaProperty("attribute_MarketingName");
	String ATTRIBUTE_PGPUNNUMBER = PropertyUtil.getSchemaProperty("attribute_pgUNNumber");
	String SELECT_ATTRIBUTE_PGPUNNUMBER = "attribute[" + ATTRIBUTE_PGPUNNUMBER + "]";
	String ATTRIBUTE_PGPROPERSHIPPINGNAME = PropertyUtil.getSchemaProperty("attribute_pgProperShippingName");
	String SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME = "attribute[" + ATTRIBUTE_PGPROPERSHIPPINGNAME + "]";
	String SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION = "attribute[" + ATTRIBUTE_PGWAREHOUSECLASIFICATION + "]";
	String ATTRIBUTE_PGPAKAGINGTYPE = PropertyUtil.getSchemaProperty("attribute_pgPackagingType");
	String SELECT_ATTRIBUTE_PGPAKAGINGTYPE = "attribute[" + ATTRIBUTE_PGPAKAGINGTYPE + "]";
	String ATTRIBUTE_PGHAZARDCLASS = PropertyUtil.getSchemaProperty("attribute_pgHazardClass");
	String SELECT_ATTRIBUTE_PGHAZARDCLASS = "attribute[" + ATTRIBUTE_PGHAZARDCLASS + "]";
	String ATTRIBUTE_PGPACKINGGROUP = PropertyUtil.getSchemaProperty("attribute_pgPackingGroup");
	String SELECT_ATTRIBUTE_PGPACKINGGROUP = "attribute[" + ATTRIBUTE_PGPACKINGGROUP + "]";
	String ATTRIBUTE_PGGAUGEPRESSURE = PropertyUtil.getSchemaProperty("attribute_pgGaugePressure");
	String SELECT_ATTRIBUTE_PGGAUGEPRESSURE = "attribute[" + ATTRIBUTE_PGGAUGEPRESSURE + "]";
	String ATTRIBUTE_PGIGNITIONDISTANCE = PropertyUtil.getSchemaProperty("attribute_pgIgnitionDistance");
	String SELECT_ATTRIBUTE_PGIGNITIONDISTANCE = "attribute[" + ATTRIBUTE_PGIGNITIONDISTANCE + "]";
	String ATTRIBUTE_PGENCLOSEDSPACEIGNITION = PropertyUtil.getSchemaProperty("attribute_pgEnclosedSpaceIgnition");
	String SELECT_ATTRIBUTE_PGENCLOSEDSPACEIGNITION = "attribute[" + ATTRIBUTE_PGENCLOSEDSPACEIGNITION + "]";
	String ATTRIBUTE_PGFOAMFLAMMABILITY = PropertyUtil.getSchemaProperty("attribute_pgFoamflammability");
	String SELECT_ATTRIBUTE_PGFOAMFLAMMABILITY = "attribute[" + ATTRIBUTE_PGFOAMFLAMMABILITY + "]";
	String ATTRIBUTE_PGCONTENTCONDUCTIVITY = PropertyUtil.getSchemaProperty("attribute_pgContentConductivity");
	String SELECT_ATTRIBUTE_PGCONTENTCONDUCTIVITY = "attribute[" + ATTRIBUTE_PGCONTENTCONDUCTIVITY + "]";
	String ATTRIBUTE_PGCORROSIVETOMETALS = PropertyUtil.getSchemaProperty("attribute_pgCorrosivetoMetals");
	String SELECT_ATTRIBUTE_PGCORROSIVETOMETALS = "attribute[" + ATTRIBUTE_PGCORROSIVETOMETALS + "]";
	String ATTRIBUTE_PGCLOSEDCUPFLASHPOINT = PropertyUtil.getSchemaProperty("attribute_pgClosedCupFlashpoint");
	String SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT = "attribute[" + ATTRIBUTE_PGCLOSEDCUPFLASHPOINT + "]";
	String ATTRIBUTE_PGBOILINGPOINT = PropertyUtil.getSchemaProperty("attribute_pgBoilingPoint");
	String SELECT_ATTRIBUTE_PGBOILINGPOINT = "attribute[" + ATTRIBUTE_PGBOILINGPOINT + "]";
	String ATTRIBUTE_PGSUSTAINCOMBUSTION = PropertyUtil.getSchemaProperty("attribute_pgSustainCombustion");
	String SELECT_ATTRIBUTE_PGSUSTAINCOMBUSTION = "attribute[" + ATTRIBUTE_PGSUSTAINCOMBUSTION + "]";
	String ATTRIBUTE_PGOXIDIZER = PropertyUtil.getSchemaProperty("attribute_pgOxidizer");
	String SELECT_ATTRIBUTE_PGOXIDIZER = "attribute[" + ATTRIBUTE_PGOXIDIZER + "]";
	String ATTRIBUTE_PGAVAILABLEOXYGEN = PropertyUtil.getSchemaProperty("attribute_pgAvailableOxygen");
	String SELECT_ATTRIBUTE_PGAVAILABLEOXYGEN = "attribute[" + ATTRIBUTE_PGAVAILABLEOXYGEN + "]";
	String ATTRIBUTE_PGBYVOLUME = PropertyUtil.getSchemaProperty("attribute_pgbyVolume");
	String SELECT_ATTRIBUTE_PGBYVOLUME = "attribute[" + ATTRIBUTE_PGBYVOLUME + "]";
	String ATTRIBUTE_PGBYWEIGHT = PropertyUtil.getSchemaProperty("attribute_pgbyWeight");
	String SELECT_ATTRIBUTE_PGBYWEIGHT = "attribute[" + ATTRIBUTE_PGBYWEIGHT + "]";
	String ATTRIBUTE_PGPROPELLANTEMULSIFIEDPRODUCT = PropertyUtil
			.getSchemaProperty("attribute_pgPropellantemulsifiedforlifeofproduct");
	String SELECT_ATTRIBUTE_PGPROPELLANTEMULSIFIEDPRODUCT = "attribute[" + ATTRIBUTE_PGPROPELLANTEMULSIFIEDPRODUCT
			+ "]";
	String ATTRIBUTE_PGPROPELLANTNONFLAMMABLE = PropertyUtil.getSchemaProperty("attribute_pgPropellantisnonflammable");
	String SELECT_ATTRIBUTE_PGPROPELLANTNONFLAMMABLE = "attribute[" + ATTRIBUTE_PGPROPELLANTNONFLAMMABLE + "]";
	String ATTRIBUTE_PGKINEMATICVISCOSITY = PropertyUtil.getSchemaProperty("attribute_pgKinematicViscosity");
	String SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY = "attribute[" + ATTRIBUTE_PGKINEMATICVISCOSITY + "]";
	String ATTRIBUTE_PGVAPORPRESSURE = PropertyUtil.getSchemaProperty("attribute_pgVaporPressure");
	String SELECT_ATTRIBUTE_PGVAPORPRESSURE = "attribute[" + ATTRIBUTE_PGVAPORPRESSURE + "]";
	String ATTRIBUTE_PGWTPARAMETERIZED = PropertyUtil.getSchemaProperty("attribute_pgWTParameterized");
	String SELECT_ATTRIBUTE_PGWTPARAMETERIZED = "attribute[" + ATTRIBUTE_PGWTPARAMETERIZED + "]";
	String ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY = PropertyUtil
			.getSchemaProperty("attribute_pgRelativeDensity/SpecificGravity");
	String SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY = "attribute["
			+ ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY + "]";
	String ATTRIBUTE_PGBURNRATE = PropertyUtil.getSchemaProperty("attribute_pgBurnRate");
	String SELECT_ATTRIBUTE_PGBURNRATE = "attribute[" + ATTRIBUTE_PGBURNRATE + "]";
	String ATTRIBUTE_PGHEATOFDECOMPOSITION = PropertyUtil.getSchemaProperty("attribute_pgHeatofDecomposition");
	String SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION = "attribute[" + ATTRIBUTE_PGHEATOFDECOMPOSITION + "]";
	String ATTRIBUTE_PGSELFACCELDECOMTEMP = PropertyUtil
			.getSchemaProperty("attribute_pgSelfAcceleratingDecompositionTemperature");
	String SELECT_ATTRIBUTE_PGSELFACCELDECOMTEMP = "attribute[" + ATTRIBUTE_PGSELFACCELDECOMTEMP + "]";
	String ATTRIBUTE_PGKSTDUSTDEFLAGRATIONINDEX = PropertyUtil
			.getSchemaProperty("attribute_pgKstDustDeflagrationIndex");
	String SELECT_ATTRIBUTE_PGKSTDUSTDEFLAGRATIONINDEX = "attribute[" + ATTRIBUTE_PGKSTDUSTDEFLAGRATIONINDEX + "]";
	String ATTRIBUTE_PGPMAXEXPLOSIONPRESSURE = PropertyUtil.getSchemaProperty("attribute_pgpmaxmaxexplosionpressure");
	String SELECT_ATTRIBUTE_PGPMAXEXPLOSIONPRESSURE = "attribute[" + ATTRIBUTE_PGPMAXEXPLOSIONPRESSURE + "]";
	String ATTRIBUTE_SO3CONTRIBUTOR = PropertyUtil.getSchemaProperty("attribute_SO3Contributor");
	String SELECT_ATTRIBUTE_SO3CONTRIBUTOR = "attribute[" + ATTRIBUTE_SO3CONTRIBUTOR + "]";
	String ATTRIBUTE_REACHREGISTRATIONNUMBER = PropertyUtil.getSchemaProperty("attribute_REACHRegistrationNumber");
	String SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER = "attribute[" + ATTRIBUTE_REACHREGISTRATIONNUMBER + "]";
	String ATTRIBUTE_PGHLBVALUE = PropertyUtil.getSchemaProperty("attribute_pgHLBValue");
	String SELECT_ATTRIBUTE_PGHLBVALUE = "attribute[" + ATTRIBUTE_PGHLBVALUE + "]";
	String ATTRIBUTE_SAPONIFICATIONVALUE = PropertyUtil.getSchemaProperty("attribute_SaponificationValue");
	String SELECT_ATTRIBUTE_SAPONIFICATIONVALUE = "attribute[" + ATTRIBUTE_SAPONIFICATIONVALUE + "].value";
	String ATTRIBUTE_PGHYDROPHILICINDEX = PropertyUtil.getSchemaProperty("attribute_pgHydrophilicIndex");
	String SELECT_ATTRIBUTE_PGHYDROPHILICINDEX = "attribute[" + ATTRIBUTE_PGHYDROPHILICINDEX + "]";
	String ATTRIBUTE_HYDROXYLVALUE = PropertyUtil.getSchemaProperty("attribute_HydroxylValue");
	String SELECT_ATTRIBUTE_HYDROXYLVALUE = "attribute[" + ATTRIBUTE_HYDROXYLVALUE + "]";
	String ATTRIBUTE_PH = PropertyUtil.getSchemaProperty("attribute_pH");
	String SELECT_ATTRIBUTE_PH = "attribute[" + ATTRIBUTE_PH + "]";
	String ATTRIBUTE_REACTIVITY = PropertyUtil.getSchemaProperty("attribute_Reactivity");
	String SELECT_ATTRIBUTE_REACTIVITY = "attribute[" + ATTRIBUTE_REACTIVITY + "]";
	String ATTRIBUTE_PGIUSPERGRAM = PropertyUtil.getSchemaProperty("attribute_pgIUsPerGram");
	String SELECT_ATTRIBUTE_PGIUSPERGRAM = "attribute[" + ATTRIBUTE_PGIUSPERGRAM + "]";
	String ATTRIBUTE_ALKALINITY = PropertyUtil.getSchemaProperty("attribute_Alkalinity");
	String SELECT_ATTRIBUTE_ALKALINITY = "attribute[" + ATTRIBUTE_ALKALINITY + "]";
	String ATTRIBUTE_ISANIMALDERIVED = PropertyUtil.getSchemaProperty("attribute_IsAnimalDerived");
	String SELECT_ATTRIBUTE_ISANIMALDERIVED = "attribute[" + ATTRIBUTE_ISANIMALDERIVED + "]";
	String ATTRIBUTE_PGODORFAMILY = PropertyUtil.getSchemaProperty("attribute_TopNote");
	String SELECT_ATTRIBUTE_PGODORFAMILY = "attribute[" + ATTRIBUTE_PGODORFAMILY + "]";
	String ATTRIBUTE_PGPRIMARYODORDESCRIPTOR = PropertyUtil.getSchemaProperty("attribute_MiddleNote");
	String SELECT_ATTRIBUTE_PGPRIMARYODORDESCRIPTOR = "attribute[" + ATTRIBUTE_PGPRIMARYODORDESCRIPTOR + "].value";
	String ATTRIBUTE_PGSECONDARYODORDESCRIPTOR = PropertyUtil.getSchemaProperty("attribute_BottomNote");
	String SELECT_ATTRIBUTE_PGSECONDARYODORDESCRIPTOR = "attribute[" + ATTRIBUTE_PGSECONDARYODORDESCRIPTOR + "]";
	String ATTRIBUTE_PGODORDESCRIPTION = PropertyUtil.getSchemaProperty("attribute_FragranceDescription");
	String SELECT_ATTRIBUTE_PGODORDESCRIPTION = "attribute[" + ATTRIBUTE_PGODORDESCRIPTION + "]";
	String ATTRIBUTE_APPEARANCE = PropertyUtil.getSchemaProperty("attribute_Appearance");
	String ATTRIBUTE_COLOR = PropertyUtil.getSchemaProperty("attribute_Color");
	String SELECT_ATTRIBUTE_COLOR = "attribute[" + ATTRIBUTE_COLOR + "].value";
	String ATTRIBUTE_SPECIFICGRAVITY = PropertyUtil.getSchemaProperty("attribute_SpecificGravity");
	String SELECT_ATTRIBUTE_APPEARANCE = "attribute[" + ATTRIBUTE_APPEARANCE + "]";
	String SELECT_ATTRIBUTE_SPECIFICGRAVITY = "attribute[" + ATTRIBUTE_SPECIFICGRAVITY + "]";
	String ATTRIBUTE_MELTINGPOINT = PropertyUtil.getSchemaProperty("attribute_MeltingPoint");
	String SELECT_ATTRIBUTE_MELTINGPOINT = "attribute[" + ATTRIBUTE_MELTINGPOINT + "]";
	String ATTRIBUTE_BOILINGPOINT = PropertyUtil.getSchemaProperty("attribute_BoilingPoint");
	String SELECT_ATTRIBUTE_BOILINGPOINT = "attribute[" + ATTRIBUTE_BOILINGPOINT + "]";
	String ATTRIBUTE_VISCOSITY = PropertyUtil.getSchemaProperty("attribute_Viscosity");
	String SELECT_ATTRIBUTE_VISCOSITY = "attribute[" + ATTRIBUTE_VISCOSITY + "]";
	String ATTRIBUTE_PHYSICALFORM = PropertyUtil.getSchemaProperty("attribute_PhysicalForm");
	String SELECT_ATTRIBUTE_PHYSICALFORM = "attribute[" + ATTRIBUTE_PHYSICALFORM + "]";
	String ATTRIBUTE_VAPORPRESSURE = PropertyUtil.getSchemaProperty("attribute_VaporPressure");
	String SELECT_ATTRIBUTE_VAPORPRESSURE = "attribute[" + ATTRIBUTE_VAPORPRESSURE + "]";
	String ATTRIBUTE_GRADE = PropertyUtil.getSchemaProperty("attribute_Grade");
	String SELECT_ATTRIBUTE_GRADE = "attribute[" + ATTRIBUTE_GRADE + "]";
	String ATTRIBUTE_PGRMAQUEOUSSOLUBILITY = PropertyUtil.getSchemaProperty("attribute_pgRMAqueousSolubility");
	String SELECT_ATTRIBUTE_PGRMAQUEOUSSOLUBILITY = "attribute[" + ATTRIBUTE_PGRMAQUEOUSSOLUBILITY + "]";
	String ATTRIBUTE_AUTOIGNITIONTEMPERATURE = PropertyUtil.getSchemaProperty("attribute_AutoignitionTemperature");
	String SELECT_ATTRIBUTE_AUTOIGNITIONTEMPERATURE = "attribute[" + ATTRIBUTE_AUTOIGNITIONTEMPERATURE + "]";
	String ATTRIBUTE_FLASHPOINT = PropertyUtil.getSchemaProperty("attribute_FlashPoint");
	String SELECT_ATTRIBUTE_FLASHPOINT = "attribute[" + ATTRIBUTE_FLASHPOINT + "]";
	String ATTRIBUTE_PGCASNUMBER = PropertyUtil.getSchemaProperty("attribute_pgCASNumber");
	String SELECT_ATTRIBUTE_PGCASNUMBER = "attribute[" + ATTRIBUTE_PGCASNUMBER + "]";
	String ATTRIBUTE_EINECSNUMBER = PropertyUtil.getSchemaProperty("attribute_EINECSNumber");
	String SELECT_ATTRIBUTE_EINECSNUMBER = "attribute[" + ATTRIBUTE_EINECSNUMBER + "].value";
	String REL_MATERIAL_FUNCTIONALITY = PropertyUtil.getSchemaProperty("relationship_MaterialFunctionality");
	String ATTRIBUTE_PGCHEMICALGROUP = PropertyUtil.getSchemaProperty("attribute_pgChemicalGroup");
	String SELECT_ATTRIBUTE_PGCHEMICALGROUP = "attribute[" + ATTRIBUTE_PGCHEMICALGROUP + "]";
	String ATTRIBUTE_PGINGREDIENTCLASS = PropertyUtil.getSchemaProperty("attribute_pgIngredientClass");
	String SELECT_ATTRIBUTE_PGINGREDIENTCLASS = "attribute[" + ATTRIBUTE_PGINGREDIENTCLASS + "]";
	String ATTRIBUTE_EMPIRICALFORMULA = PropertyUtil.getSchemaProperty("attribute_EmpiricalFormula");
	String SELECT_ATTRIBUTE_EMPIRICALFORMULA = "attribute[" + ATTRIBUTE_EMPIRICALFORMULA + "].value";
	String ATTRIBUTE_STANDARDCOSTPERKG = PropertyUtil.getSchemaProperty("attribute_StandardCostPerKg");
	String SELECT_ATTRIBUTE_STANDARDCOSTPERKG = "attribute[" + ATTRIBUTE_STANDARDCOSTPERKG + "].value";
	String ATTRIBUTE_COLORINDEX = PropertyUtil.getSchemaProperty("attribute_ColorIndex");
	String SELECT_ATTRIBUTE_COLORINDEX = "attribute[" + ATTRIBUTE_COLORINDEX + "].value";
	String ATTRIBUTE_PGCISPRO = PropertyUtil.getSchemaProperty("attribute_pgCISPro");
	String SELECT_ATTRIBUTE_PGCISPRO = "attribute[" + ATTRIBUTE_PGCISPRO + "].value";
	String SELECT_ATTRIBUTE_PGRMCISPRONUMBER = "attribute[" + ATTRIBUTE_PGRMCISPRONUMBER + "].value";
	String ATTRIBUTE_PGEXPERIMENTALNUMBER = PropertyUtil.getSchemaProperty("attribute_pgExperimentalNumber");
	String SELECT_ATTRIBUTE_PGEXPERIMENTALNUMBER = "attribute[" + ATTRIBUTE_PGEXPERIMENTALNUMBER + "].value";
	String SELECT_ATTRIBUTE_PGPREFERREDMATERIAL = "attribute[" + ATTRIBUTE_PGPREFERREDMATERIAL + "].value";
	String ATTRIBUTE_PGMATERIALUSAGEGUIDANCE = PropertyUtil.getSchemaProperty("attribute_pgMaterialUsageGuidance");
	String SELECT_ATTRIBUTE_PGMATERIALUSAGEGUIDANCE = "attribute[" + ATTRIBUTE_PGMATERIALUSAGEGUIDANCE + "].value";
	String ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE = PropertyUtil
			.getSchemaProperty("attribute_HydrophilicLipophilicBalance");
	String SELECT_ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE = "attribute[" + ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE
			+ "].value";
	String ATTRIBUTE_PHVALUE = PropertyUtil.getSchemaProperty("attribute_PHValue");
	String SELECT_ATTRIBUTE_PHVALUE = "attribute[" + ATTRIBUTE_PHVALUE + "].value";
	String ATTRIBUTE_IUSPERGRAM = PropertyUtil.getSchemaProperty("attribute_IUsPerGram");
	String SELECT_ATTRIBUTE_IUSPERGRAM = "attribute[" + ATTRIBUTE_IUSPERGRAM + "].value";
	String ATTRIBUTE_PGRMEXPERIMENTNUMBER = PropertyUtil.getSchemaProperty("attribute_pgRMExperimentNumber");
	String SELECT_ATTRIBUTE_PGRMEXPERIMENTNUMBER = "attribute[" + ATTRIBUTE_PGRMEXPERIMENTNUMBER + "].value";
	String ATTRIBUTE_PGPRIMARYPACKAGINGTYPE = PropertyUtil.getSchemaProperty("attribute_pgPrimaryPackagingType");
	String ATTRIBUTE_PGSECONDARYPACKAGINGTYPE = PropertyUtil.getSchemaProperty("attribute_pgSecondaryPackagingType");
	String SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE = "attribute[" + ATTRIBUTE_PGPRIMARYPACKAGINGTYPE + "]";
	String SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE = "attribute[" + ATTRIBUTE_PGSECONDARYPACKAGINGTYPE + "]";
	String ATTRIBUTE_PGISTHEPRODUCTABATTERY = PropertyUtil.getSchemaProperty("attribute_pgIsTheProductABattery");
	String SELECT_ATTRIBUTE_PGISTHEPRODUCTABATTERY = "attribute[" + ATTRIBUTE_PGISTHEPRODUCTABATTERY + "]";
	String ATTRIBUTE_PGDOESTHEPRODUCTCONTAINABATTERY = PropertyUtil
			.getSchemaProperty("attribute_pgDoesTheProductContainABattery");
	String SELECT_ATTRIBUTE_PGDOESTHEPRODUCTCONTAINABATTERY = "attribute[" + ATTRIBUTE_PGDOESTHEPRODUCTCONTAINABATTERY
			+ "]";
	String ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE = PropertyUtil
			.getSchemaProperty("attribute_pgBatteriesShippedInsideDevice");
	String SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE = "attribute[" + ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE
			+ "]";
	String ATTRIBUTE_PGBATTERIESSHIPPEDOUTSIDEDEVICE = PropertyUtil
			.getSchemaProperty("attribute_pgBatteriesShippedOutsideDevice");
	String SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDOUTSIDEDEVICE = "attribute[" + ATTRIBUTE_PGBATTERIESSHIPPEDOUTSIDEDEVICE
			+ "]";
	String ATTRIBUTE_PGAREBATTERIESREQUIRED = PropertyUtil.getSchemaProperty("attribute_pgAreBatteriesRequired");
	String SELECT_ATTRIBUTE_PGAREBATTERIESREQUIRED = "attribute[" + ATTRIBUTE_PGAREBATTERIESREQUIRED + "]";
	String ATTRIBUTE_PGPLIBATTERYLITHUM = PropertyUtil.getSchemaProperty("attribute_pgPLIBatteryLithum");
	String SELECT_ATTRIBUTE_PGPLIBATTERYLITHUM = "attribute[" + ATTRIBUTE_PGPLIBATTERYLITHUM + "]";
	String ATTRIBUTE_PGPLIBATTERYWHRATING = PropertyUtil.getSchemaProperty("attribute_pgPLIBatteryWhRating");
	String SELECT_ATTRIBUTE_PGPLIBATTERYWHRATING = "attribute[" + ATTRIBUTE_PGPLIBATTERYWHRATING + "]";
	String ATTRIBUTE_PGPLIBATTERYVOLTAGE = PropertyUtil.getSchemaProperty("attribute_pgPLIBatteryVoltage");
	String SELECT_ATTRIBUTE_PGPLIBATTERYVOLTAGE = "attribute[" + ATTRIBUTE_PGPLIBATTERYVOLTAGE + "]";
	String ATTRIBUTE_PGPLBATTERYWEIGHT = PropertyUtil.getSchemaProperty("attribute_pgPLBatteryWeight");
	String SELECT_ATTRIBUTE_PGPLBATTERYWEIGHT = "attribute[" + ATTRIBUTE_PGPLBATTERYWEIGHT + "]";
	String ATTRIBUTE_PGPLBATTERYWEIGHTUOM = PropertyUtil.getSchemaProperty("attribute_pgPLBatteryWeightUOM");
	String SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTUOM = "attribute[" + ATTRIBUTE_PGPLBATTERYWEIGHTUOM + "]";
	String ATTRIBUTE_PGPLIBATTERYCAPACITY = PropertyUtil.getSchemaProperty("attribute_pgPLIBatteryCapacity");
	String SELECT_ATTRIBUTE_PGPLIBATTERYCAPACITY = "attribute[" + ATTRIBUTE_PGPLIBATTERYCAPACITY + "]";
	String ATTRIBUTE_PGPLIBATTERYCELLS = PropertyUtil.getSchemaProperty("attribute_pgPLIBatteryCells");
	String SELECT_ATTRIBUTE_PGPLIBATTERYCELLS = "attribute[" + ATTRIBUTE_PGPLIBATTERYCELLS + "]";
	String TYPE_PGPLIBATTERYTYPE = PropertyUtil.getSchemaProperty("type_pgPLIBatteryType");
	String TYPE_PGPLICHEMISTRY = PropertyUtil.getSchemaProperty("type_pgPLIChemistry");
	String TYPE_PGPLIBATTERYSIZE = PropertyUtil.getSchemaProperty("type_pgPLIBatterySize");
	String TYPE_PGPLIYESNO = PropertyUtil.getSchemaProperty("type_pgPLIYesNo");
	String ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET = PropertyUtil.getSchemaProperty("attribute_pgMinimumActualWeightWet");
	String SELECT_ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET = "attribute[" + ATTRIBUTE_PGMINIMUMACTUALWEIGHTWET + "]";
	String ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET = PropertyUtil.getSchemaProperty("attribute_pgMaximumActualWeightWet");
	String SELECT_ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET = "attribute[" + ATTRIBUTE_PGMAXIMUMACTUALWEIGHTWET + "]";
	String ATTRIBUTE_UNITSVALUE = PropertyUtil.getSchemaProperty("attribute_UnitsValue");
	String SELECT_ATTRIBUTE_UNITSVALUE = "attribute[" + ATTRIBUTE_UNITSVALUE + "]";
	String ATTRIBUTE_PGHIRCOMPLAINT = PropertyUtil.getSchemaProperty("attribute_pgHiRCompliant");
	String SELECT_ATTRIBUTE_PGHIRCOMPLAINT = "attribute[" + ATTRIBUTE_PGHIRCOMPLAINT + "]";
	String BASEUNITOFMEASURE_IT = "IT";
	String BASEUNITOFMEASURE_CS = "CS";
	String BASEUNITOFMEASURE_SW = "SW";
	String BASEUNITOFMEASURE_SP = "SP";
	String BASEUNITOFMEASURE_MP = "MP";
	String BASEUNITOFMEASURE_BP = "BP";
	String REL_CHANGE_REVIEWER = PropertyUtil.getSchemaProperty("relationship_ChangeReviewer");
	int INDEX_VALID_UNTIL_DATE = 34;
	String TYPE_PLMPARAMETER = PropertyUtil.getSchemaProperty("type_PlmParameter");
	String REL_PARAMETERAGGREGATION = PropertyUtil.getSchemaProperty("relationship_ParameterAggregation");
	String REL_PARAMETERUSAGE = PropertyUtil.getSchemaProperty("relationship_ParameterUsage");
	String REL_CHARACTERISTICTESTMETHOD = PropertyUtil.getSchemaProperty("relationship_CharacteristicTestMethod");
	String ATTRIBUTE_PGSTRINGPARAMETERVALUE = PropertyUtil.getSchemaProperty("attribute_StringParameterValue");
	String SELECT_ATTRIBUTE_PGSTRINGPARAMETERVALUE = "attribute[" + ATTRIBUTE_PGSTRINGPARAMETERVALUE + "]";
	String ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER = PropertyUtil.getSchemaProperty("attribute_pgUniqueFormulaIdentifier");
	String SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER = "attribute[" + ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER + "]";
	String ATTRIBUTE_PGSTANDARDCOST = PropertyUtil.getSchemaProperty("attribute_pgStandardCost");
	String SELECT_ATTRIBUTE_PGSTANDARDCOST = "attribute[" + ATTRIBUTE_PGSTANDARDCOST + "]";
	String ATTRIBUTE_PGREPLACEDBYPRODUCTID = PropertyUtil.getSchemaProperty("attribute_pgReplacedByProductID");
	String SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID = "attribute[" + ATTRIBUTE_PGREPLACEDBYPRODUCTID + "]";
	String PROJECT_PARTNERS_PG = "Partners_PG";
	String STATE_FROZEN = "Frozen";
	String RELATIONSHIP_RELATED_PROJECTS = PropertyUtil.getSchemaProperty("relationship_RelatedProjects");
	String ATTRIBUTE_PGAUTHORINGAPPLICATION = PropertyUtil.getSchemaProperty("attribute_pgAuthoringApplication");
	String SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION = "attribute[" + ATTRIBUTE_PGAUTHORINGAPPLICATION + "]";
	String RANGE_PGAUTHORINGAPPLICATION_LPD = "LPD";
	String CONST_CHECKED = "checked";
	String CONST_CONTENT = "Content";
	String CONST_STRING_PRODUCED_BY = "Produced By";
	String CONST_STRING_ALTERNATES = "Alternates";
	String CONST_STRING_MATERIAL_COMPOSITION = "Materials & Composition";
	String CONST_STRING_PROJECTS = "Projects";
	String CONST_STRING_CONNECTSAMECO = "Connect Same CO";
	String CONST_STRING_PGPRODUCTSTRUCTURECOPYFORM = "pgProductStructureCopyForm";
	String ATTRIBUTE_PGMARKINGFORCOSVALUE = PropertyUtil.getSchemaProperty("attribute_pgMarkingForCOSValue");
	String SELECT_ATTRIBUTE_PGMARKINGFORCOSVALUE = "attribute[" + ATTRIBUTE_PGMARKINGFORCOSVALUE + "]";
	String ATTRIBUTE_PGMARKINGFORCOS = PropertyUtil.getSchemaProperty("attribute_pgMarkingForCOS");
	String SELECT_ATTRIBUTE_PGMARKINGFORCOS = "attribute[" + ATTRIBUTE_PGMARKINGFORCOS + "]";
	String ATTRIBUTE_PGPACKINGSITE = PropertyUtil.getSchemaProperty("attribute_pgPackingSite");
	String SELECT_ATTRIBUTE_PGPACKINGSITE = "attribute[" + ATTRIBUTE_PGPACKINGSITE + "]";
	String ATTRIBUTE_PGMANUFACTURINGSITE = PropertyUtil.getSchemaProperty("attribute_pgManufacturingSite");
	String SELECT_ATTRIBUTE_PGMANUFACTURINGSITE = "attribute[" + ATTRIBUTE_PGMANUFACTURINGSITE + "]";
	String ATTRIBUTE_PGHASCOSFPPOVERRIDDEN = PropertyUtil.getSchemaProperty("attribute_pgHasCOSFPPOverridden");
	String SELECT_ATTRIBUTE_PGHASCOSFPPOVERRIDDEN = "attribute[" + ATTRIBUTE_PGHASCOSFPPOVERRIDDEN + "]";
	String ATTRIBUTE_PGCOSOVERRIDEFPP = PropertyUtil.getSchemaProperty("attribute_pgCOSOverrideFPP");
	String SELECT_ATTRIBUTE_PGCOSOVERRIDEFPP = "attribute[" + ATTRIBUTE_PGCOSOVERRIDEFPP + "]";
	String ATTRIBUTE_PGCOSOVERRIDECOUNTRIES = PropertyUtil.getSchemaProperty("attribute_pgCOSOverrideCountries");
	String SELECT_ATTRIBUTE_PGCOSOVERRIDECOUNTRIES = "attribute[" + ATTRIBUTE_PGCOSOVERRIDECOUNTRIES + "]";
	String ATTRIBUTE_PGCOSOVERRIDEREASONFORCHANGE = PropertyUtil
			.getSchemaProperty("attribute_pgCOSOverrideReasonForChange");
	String SELECT_ATTRIBUTE_PGCOSOVERRIDEREASONFORCHANGE = "attribute[" + ATTRIBUTE_PGCOSOVERRIDEREASONFORCHANGE + "]";
	String ATTRIBUTE_PGCOSOVERRIDEAPPROVERNAME = PropertyUtil.getSchemaProperty("attribute_pgCOSOverrideApproverName");
	String SELECT_ATTRIBUTE_PGCOSOVERRIDEAPPROVERNAME = "attribute[" + ATTRIBUTE_PGCOSOVERRIDEAPPROVERNAME + "]";
	String ATTRIBUTE_PGCOSOVERRIDETASKAPPROVAL = PropertyUtil.getSchemaProperty("attribute_pgCOSOverrideTaskApproval");
	String SELECT_ATTRIBUTE_PGCOSOVERRIDETASKAPPROVAL = "attribute[" + ATTRIBUTE_PGCOSOVERRIDETASKAPPROVAL + "]";
	String ATTRIBUTE_PGCOSOVERRIDEEXPIRATIONDATE = PropertyUtil
			.getSchemaProperty("attribute_pgCOSOverrideExpirationDate");
	String SELECT_ATTRIBUTE_PGCOSOVERRIDEEXPIRATIONDATE = "attribute[" + ATTRIBUTE_PGCOSOVERRIDEEXPIRATIONDATE + "]";
	String RELATIONSHIP_PGCOUNTRYOFSALEOVERRIDE = PropertyUtil
			.getSchemaProperty("relationship_pgCountryOfSaleOverride");
	String TYPE_PGCOSOVERRIDE = PropertyUtil.getSchemaProperty("type_pgCOSOverride");
	String PACKINGSITE = "PackingSite";
	String MANUFACTURINGSITE = "ManufacturingSite";
	String NEWOBJECTID = "newObjectId";
	String LANGUAGESTR = "languageStr";
	String DESCRIPTION = "Description";
	String COUNTRIESLIST = "CountriesList";
	String APPROVERNAME = "ApproverName";
	String APPROVERNAMEOID = "ApproverNameOID";
	String TASKAPPROVAL = "TaskApproval";
	String TASKDUEDATE = "TaskDueDate";
	String EXPIRATIONDATE = "ExpirationDate";
	String AUTONAMECHECK = "autoNameCheck";
	String SELSCOPE = "selscope";
	String ALL = "All";
	String TRUE = "true";
	String ROUTECOMPLETIONACTION = "RouteCompletionAction";
	String PROMOTE_CONNECTED_OBJECT = "Promote Connected Object";
	String ROUTEBASEPURPOSE = "RouteBasePurpose";
	String STANDARD = "Standard";
	String AUTOSTOPONREJECTION = "AutoStopOnRejection";
	String IMMEDIATE = "Immediate";
	String ALLOWDELEGATION = "allowDelegation";
	String CAPS_TRUE = "TRUE";
	String ROUTEMEMBERSTRING = "routeMemberString";
	String ROUTEINSTRUCTIONS = "routeInstructions";
	String FORMATTEDDUEDATE = "formattedDueDate";
	String ROUTEACTION = "routeAction";
	String APPROVE = "Approve";
	String ROUTEINITIATEMANNER = "routeInitiateManner";
	String START = "start";
	String SCOPEID = "scopeId";
	String ROUTESTART = "routeStart";
	String ROUTEID = "routeId";
	String PERSONID = "PersonId";
	String PERSONNAME = "PersonName";
	String APPROVER_ROLE = "Approver Role";
	String ONE = "1";
	String TEMPLATEFLAG = "templateFlag";
	String ROLE = "Role";
	String GROUP = "Group";
	String TYPE = "type";
	String PROJECTLEAD = "projectLead";
	String CREATEROUTE = "createRoute";
	String ORGANIZATIONNAME = "OrganizationName";
	String ACCESS = "access";
	String LASTFIRSTNAME = "LastFirstName";
	String NAME = "name";
	String READ = "Read";
	String ADD_REMOVE = "Add Remove";
	String ROUTENAME = "routeName";
	String ROUTEAUTONAME = "routeAutoName";
	String TEMPLATEID = "templateId";
	String TEMPLATENAME = "templateName";
	String VISBLTOPARENT = "visblToParent";
	String FALSE = "false";
	String ROUTEDESCRIPTION = "routeDescription";
	String ROUTEDUEDATE = "routeDueDate";
	String TYPE_ROUTE = "type_Route";
	String POLICY_ROUTE = "policy_Route";
	String ANY = "Any";
	String ATTRIBUTE_ROUTECOMPLETIONACTION = PropertyUtil.getSchemaProperty("attribute_RouteCompletionAction");
	String SELECT_ATTRIBUTE_ROUTECOMPLETIONACTION = "attribute[" + ATTRIBUTE_ROUTECOMPLETIONACTION + "]";
	String ATTRIBUTE_PARALLELNODEPROCESSIONRULE = PropertyUtil
			.getSchemaProperty("attribute_ParallelNodeProcessionRule");
	String SELECT_ATTRIBUTE_PARALLELNODEPROCESSIONRULE = "attribute[" + ATTRIBUTE_PARALLELNODEPROCESSIONRULE + "]";
	String ATTRIBUTE_CREATEROUTE = PropertyUtil.getSchemaProperty("attribute_CreateRoute");
	String SELECT_ATTRIBUTE_CREATEROUTE = "attribute[" + ATTRIBUTE_CREATEROUTE + "]";
	String ATTRIBUTE_PGAPPROVERROLE = PropertyUtil.getSchemaProperty("attribute_pgApproverRole");
	String SELECT_ATTRIBUTE_PGAPPROVERROLE = "attribute[" + ATTRIBUTE_PGAPPROVERROLE + "]";
	String SELECT_STATE_APPROVED_ACTUAL = "state[Approved].actual";
	String ATTRIBUTE_DUEDATEOFFSET = PropertyUtil.getSchemaProperty("attribute_DueDateOffset");
	String SELECT_ATTRIBUTE_DUEDATEOFFSET = "attribute[" + ATTRIBUTE_DUEDATEOFFSET + "]";
	String ATTRIBUTE_REVIEWTASK = PropertyUtil.getSchemaProperty("attribute_ReviewTask");
	String SELECT_ATTRIBUTE_REVIEWTASK = "attribute[" + ATTRIBUTE_REVIEWTASK + "]";
	String ATTRIBUTE_ROUTEACTION = PropertyUtil.getSchemaProperty("attribute_RouteAction");
	String SELECT_ATTRIBUTE_ROUTEACTION = "attribute[" + ATTRIBUTE_ROUTEACTION + "]";
	String COUNTRIES = "Countries";
	String ATTRIBUTE_START_EFFECTIVITY = PropertyUtil.getSchemaProperty("attribute_StartEffectivity");
	String SELECT_ATTRIBUTE_START_EFFECTIVITY = "attribute[" + ATTRIBUTE_START_EFFECTIVITY + "]";
	String STR_RELEASE_PHASE = PropertyUtil.getSchemaProperty("attribute_ReleasePhase");
	String SELECT_ATTRIBUTE_RELEASE_PHASE = "attribute[" + STR_RELEASE_PHASE + "].value";
	String SELECT_EBOM_SUBSTITUTE_ID = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to.id";
	String SELECT_EBOM_SUBSTITUTE_TYPE = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to.type";
	String SELECT_EBOM_SUBSTITUTE_NAME = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to.name";
	String SELECT_EBOM_SUBSTITUTE_REVISION = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to.revision";
	String SELECT_EBOM_SUBSTITUTE_CURRENT = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to.current";
	String SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to."
			+ SELECT_ATTRIBUTE_PGASSEMBLYTYPE;
	String SELECT_EBOM_SUBSTITUTE_PGSAPTYPE = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to."
			+ SELECT_ATTRIBUTE_PGSAPTYPE;
	String SELECT_EBOM_SUBSTITUTE_REL_ID = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].id";
	String SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "]."
			+ SELECT_ATTRIBUTE_START_EFFECTIVITY;
	String SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "]."
			+ SELECT_ATTRIBUTE_PGVALIDUNTILDATE;
	String SELECT_EBOM_SUBSTITUTE_COMMENT = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "]." + SELECT_ATTRIBUTE_COMMENT;
	String SELECT_EBOM_SUBSTITUTE_MIN_QUANTITY = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "]."
			+ SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET;
	String SELECT_EBOM_SUBSTITUTE_MAX_QUANTITY = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "]."
			+ SELECT_ATTRIBUTE_MAXACTUALPERCENTWET;
	String SELECT_EBOM_SUBSTITUTE_QUANTITY = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "]."
			+ SELECT_ATTRIBUTE_QUANTITY;
	String SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "]."
			+ SELECT_ATTRIBUTE_OPTIONAL_COMPONENT;
	String SELECT_EBOM_SUBSTITUTE_PG_BOM_BASEQUANTITY = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to."
			+ SELECT_ATTRIBUTE_PGBOMBASEQUANTITY;
	String SELECT_EBOM_SUBSTITUTE_EFFECTIVITY_DATE = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to."
			+ SELECT_ATTRIBUTE_EFFECTIVITYDATE;
	String SELECT_FBOM_SUBSTITUTE_ID = "frommid[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].to.from[" + RELATIONSHIP_PLBOM
			+ "].to.id";
	String SELECT_FBOM_SUBSTITUTE_NAME = "frommid[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].to.from[" + RELATIONSHIP_PLBOM
			+ "].to.name";
	String SELECT_FBOM_SUBSTITUTE_TYPE = "frommid[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].to.from[" + RELATIONSHIP_PLBOM
			+ "].to.type";
	String SELECT_FBOM_SUBSTITUTE_REL_ID = "frommid[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].to.from[" + RELATIONSHIP_PLBOM
			+ "].id";
	String SELECT_FBOM_SUBSTITUTE_BASE_UOM = "frommid[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].to.from["
			+ RELATIONSHIP_PLBOM + "].to." + SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE;
	String SELECT_FBOM_SUBSTITUTE_EFFECTIVITY_DATE = "frommid[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].to.from["
			+ RELATIONSHIP_PLBOM + "].to." + SELECT_ATTRIBUTE_EFFECTIVITYDATE;
	String SELECT_FBOM_SUBSTITUTE_FORMULATION_TYPE = "frommid[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].to.from["
			+ RELATIONSHIP_PLBOM + "].to.to[" + RELATIONSHIP_FORMULATIONPROPAGATE + "].from."
			+ SELECT_ATTRIBUTE_FORMULATIONTYPE;
	String RELATIONSHIP_ALTERNATE = PropertyUtil.getSchemaProperty("relationship_Alternate");
	String SELECT_ALTERNATE_ID = "from[" + RELATIONSHIP_ALTERNATE + "].to.id";
	String SELECT_ALTERNATE_TYPE = "from[" + RELATIONSHIP_ALTERNATE + "].to.type";
	String SELECT_ALTERNATE_NAME = "from[" + RELATIONSHIP_ALTERNATE + "].to.name";
	String SELECT_ALTERNATE_EFFECTIVITY_DATE = "from[" + RELATIONSHIP_ALTERNATE + "].to."
			+ SELECT_ATTRIBUTE_EFFECTIVITYDATE;
	String SELECT_ALTERNATE_BASE_UOM = "from[" + RELATIONSHIP_ALTERNATE + "].to."
			+ SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE;
	String ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED = PropertyUtil.getSchemaProperty("attribute_pgExpandBOMonSAPBOMAsFed");
	String SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED = "attribute[" + ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED + "]";
	String ATTRIBUTE_PGPRODUCTPARTPHYSICALID = PropertyUtil.getSchemaProperty("attribute_pgProductPartPhysicalId");
	String RELATIONSHIP_PGCOUNTRIESCERTIED = PropertyUtil.getSchemaProperty("relationship_pgCountriesCertified");
	String RELATIONSHIP_PGCOUNTRIESCERTICATIONCLAIMED = PropertyUtil
			.getSchemaProperty("relationship_pgCountriesCertificationClaimed");
	String TYPE_PGPLIWAREHOUSEINGCLASSIFICATION = PropertyUtil.getSchemaProperty("type_pgPLIWarehousingClassification");
	String TYPE_COPYLIST = PropertyUtil.getSchemaProperty("type_CopyList");
	String ATTRIBUTE_COPYTEXT = PropertyUtil.getSchemaProperty("attribute_CopyText");
	String ATTRIBUTE_PGCORROSIVE = PropertyUtil.getSchemaProperty("attribute_pgCorrosive");
	String ATTRIBUTE_COPYTEXTRTE = "Copy Text_RTE";
	String STATE_APPROVED = "Approved";
	String ATTRIBUTE_PGMARKFORROLLUP = PropertyUtil.getSchemaProperty("attribute_pgMarkforRollup");
	String ATTRIBUTE_PGEVENTFORROLLUP = PropertyUtil.getSchemaProperty("attribute_pgEventforRollup");
	String ATTRIBUTE_PGDGCROLLUPFLAG = PropertyUtil.getSchemaProperty("attribute_pgDGCRollupFlag");
	String ATTRIBUTE_PGGHSROLLUPFLAG = PropertyUtil.getSchemaProperty("attribute_pgGHSRollupFlag");
	String ATTRIBUTE_PGSLROLLUPFLAG = PropertyUtil.getSchemaProperty("attribute_pgSLRollupFlag");
	String ATTRIBUTE_PGSRROLLUPFLAG = PropertyUtil.getSchemaProperty("attribute_pgSRRollupFlag");
	String ATTRIBUTE_PGCERTIFICATIONSROLLUPFLAG = PropertyUtil
			.getSchemaProperty("attribute_pgCertificationsRollupFlag");
	String ATTRIBUTE_PGWAREHOUSEROLLUPFLAG = PropertyUtil.getSchemaProperty("attribute_pgWarehouseRollupFlag");
	String TYPE_PGPLIMATERIALCERTIFICATIONS = PropertyUtil.getSchemaProperty("type_pgPLIMaterialCertifications");
	String TYPE_PGSTABILITYREPORT = PropertyUtil.getSchemaProperty("type_pgStabilityReport");
	String TYPE_PGSMARTLABEL = PropertyUtil.getSchemaProperty("type_pgSmartLabel");
	String RELATIONSHIP_PGROLLEDUPSTABILITYREPORT = PropertyUtil
			.getSchemaProperty("relationship_pgRolledUpStabilityResult");
	String RELATIONSHIP_PGROLLEDUPDGC = PropertyUtil.getSchemaProperty("relationship_pgRolledUpDGC");
	String RELATIONSHIP_PGROLLEDUPMATERIALCERTIFICATION = PropertyUtil
			.getSchemaProperty("relationship_pgRolledUpMaterialCertifications");
	String RELATIONSHIP_PGROLLEDUPGHS = PropertyUtil.getSchemaProperty("relationship_pgRolledUpGHS");
	String RELATIONSHIP_PGROLLEDUPSMARTLABEL = PropertyUtil.getSchemaProperty("relationship_pgRolledUpSmartLabel");
	String RELATIONSHIP_PGCOUNTRIESCERTIFIED = PropertyUtil.getSchemaProperty("relationship_pgCountriesCertified");
	String TYPE_PGSTABILITYRESULTS = PropertyUtil.getSchemaProperty("type_pgStabilityResults");
	String ATTRIBUTE_PGSHIPMENTLIMITEDQUANTITY = PropertyUtil.getSchemaProperty("attribute_pgShipmentLimitedQuantity");
	String ATTRIBUTE_PGDGCOPLABELREQUIRED = PropertyUtil.getSchemaProperty("attribute_pgDGCOPLabelRequired");
	String ATTRIBUTE_PGDGCUPLABELREQUIRED = PropertyUtil.getSchemaProperty("attribute_pgDGCUPLabelRequired");
	String ATTRIBUTE_PGCONSUMERWEIGHTVOLUME = PropertyUtil.getSchemaProperty("attribute_pgConsumerWeightVolume");
	String ATTRIBUTE_PGCUSTOMERWEIGHTVOLUME = PropertyUtil.getSchemaProperty("attribute_pgCustomerWeightVolume");
	String TYPE_PGDANGEROUSGOODS = PropertyUtil.getSchemaProperty("type_pgDangerousgoods");
	String TYPE_PGPLIHAZARDCLASS = PropertyUtil.getSchemaProperty("type_pgPLIHazardClass");
	String TYPE_PGPLIPACKINGGROUP = PropertyUtil.getSchemaProperty("type_pgPLIPackingGroup");
	String RELATIONSHIP_PGDANGEROUSGOODS = PropertyUtil.getSchemaProperty("relationship_pgDangerousgoods");
	String RELATIONSHIP_COPYLISTCOUNTRY = PropertyUtil.getSchemaProperty("relationship_CopyListCountry");
	String RELATIONSHIP_COPYLISTLOCALLANGUAGE = PropertyUtil.getSchemaProperty("relationship_CopyListLocalLanguage");
	String SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID = "attribute[" + ATTRIBUTE_PGPRODUCTPARTPHYSICALID + "]";
	String RELATIONSHIP_PGHAZARDCLASS = PropertyUtil.getSchemaProperty("relationship_pgHazardClass");
	String RELATIONSHIP_PGPACKINGGROUP = PropertyUtil.getSchemaProperty("relationship_pgPackingGroup");
	String ATTRIBUTE_PGBOUNDARYCONDITIONS = PropertyUtil.getSchemaProperty("attribute_pgBoundaryConditions");
	String ATTRIBUTE_PGARTWORKUSAGE = PropertyUtil.getSchemaProperty("attribute_ArtworkUsage");
	String ATTRIBUTE_PGISMANDATORY = PropertyUtil.getSchemaProperty("attribute_IsMandatory");
	String RELATIONSHIP_ASSOCIATEDCOPYLIST = PropertyUtil.getSchemaProperty("relationship_AssociatedCopyList");
	String ATTRIBUTE_PGDOESDEVICECONTAINFLAMMABLELIQUID = PropertyUtil
			.getSchemaProperty("attribute_pgDoesDeviceContainFlammableLiquid");
	String SELECT_ATTRIBUTE_PGDOESDEVICECONTAINFLAMMABLELIQUID = "attribute["
			+ ATTRIBUTE_PGDOESDEVICECONTAINFLAMMABLELIQUID + "]";
	String ATTRIBUTE_PGSTUDYRELATEDPROJECTS = PropertyUtil.getSchemaProperty("attribute_pgStudyRelatedProjects");
	String SELECT_ATTRIBUTE_PGSTUDYRELATEDPROJECTS = "attribute[" + ATTRIBUTE_PGSTUDYRELATEDPROJECTS + "]";
	String RELATIONSHIP_PGGPSTASKASSESSMENTCOUNTRY = PropertyUtil
			.getSchemaProperty("relationship_pgGPSTaskAssessmentCountry");
	String RELATIONSHIP_PGSTUDYPROTOCOLTOASSEMBLYSTATE = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToAssemblyState");
	String RELATIONSHIP_PGSTUDYPROTOCOLTOSURPLUSDISPOSITION = PropertyUtil
			.getSchemaProperty("relationship_pgStudyProtocolToSurplusDisposition");
	String RELATIONSHIP_PGSTUDYLEGTOFREQUENCYUOM = PropertyUtil
			.getSchemaProperty("relationship_pgStudyLegToFrequencyUoM");
	String RELATIONSHIP_PGSTUDYLEGTOWASHOUTTIMEUOM = PropertyUtil
			.getSchemaProperty("relationship_pgStudyLegToWashoutTimeUoM");
	String RELATIONSHIP_PGSTUDYLEGTOREGULATORYCLASSIFICATION = PropertyUtil
			.getSchemaProperty("relationship_pgStudyLegToRegulatoryClassification");
	String RELATIONSHIP_PGSTUDYLEGTODOSAGEUOM = PropertyUtil.getSchemaProperty("relationship_pgStudyLegToDosageUoM");
	String RELATIONSHIP_PGSTUDYLEGTOUSAGETIMEUOM = PropertyUtil
			.getSchemaProperty("relationship_pgStudyLegToUsageTimeUoM");
	String RELATIONSHIP_PGSTUDYLEGTOPRODUCTSOURCE = PropertyUtil
			.getSchemaProperty("relationship_pgStudyLegToProductSource");
	String ATTRIBUTE_PGPLATFORMTYPE = PropertyUtil.getSchemaProperty("attribute_pgPlatformType");
	String SELECT_ATTRIBUTE_PGPLATFORMTYPE = "attribute[" + ATTRIBUTE_PGPLATFORMTYPE + "]";
	String ATTRIBUTE_PGCHASSISTYPE = PropertyUtil.getSchemaProperty("attribute_pgChassisType");
	String SELECT_ATTRIBUTE_PGCHASSISTYPE = "attribute[" + ATTRIBUTE_PGCHASSISTYPE + "]";
	String RELATIONSHIP_PARAMETER_AGGREGATION = PropertyUtil.getSchemaProperty("relationship_ParameterAggregation");
	String TYPE_PLM_PARAMETER = PropertyUtil.getSchemaProperty("type_PlmParameter");
	String ATTR_REFERENCE_TYPE = PropertyUtil.getSchemaProperty("attribute_ReferenceType");
	String RELATIONSHIP_SHARED_TABLE = PropertyUtil.getSchemaProperty("relationship_SharedTable");
	String RELATIONSHIP_COMPONENT_SUBSTANCE = PropertyUtil.getSchemaProperty("relationship_ComponentSubstance");
	String CONSTANT_PRODUCT = "Product";
	String CONST_TRUE = "TRUE";
	String ATTRIBUTE_INTERNAL_MATERIAL_FOR = PropertyUtil.getSchemaProperty("attribute_pgInternalMaterialFor");
	String FORMAT_DECIMAL_SIX = "0.000000";
	String TYPE_PGPLIPLATFORM = PropertyUtil.getSchemaProperty("type_pgPLIPlatform");
	String TYPE_PGPLICHASSIS = PropertyUtil.getSchemaProperty("type_pgPLIChassis");
	String ATTRIBUTE_PGPLBATTERYWEIGHTLIUOM = PropertyUtil.getSchemaProperty("attribute_pgPLBatteryWeightLiUOM");
	String ATTRIBUTE_PGPLBATTERYENRUOM = PropertyUtil.getSchemaProperty("attribute_pgPLBatteryEnRUOM");
	String ATTRIBUTE_PGPLBATTERYVOLUOM = PropertyUtil.getSchemaProperty("attribute_pgPLBatteryVolUOM");
	String ATTRIBUTE_PGPLBATTERYTCUOM = PropertyUtil.getSchemaProperty("attribute_pgPLBatteryTCUOM");
	String PILOT = "Pilot";
	String DEVELOPMENT = "Development";
	String TYPE_PG_TMRD_TYPES = TYPE_PGQUALITYSPECIFICATION + "," + TYPE_PGSTANDARDOPERATINGPROCEDURE + ","
			+ TYPE_PGILLUSTRATION;
	String TEST_METHOD_SPECIFICATION = "Test Method Specification";
	String SELECT_ATTRIBUTE_PGSHIPMENTLIMITEDQUANTITY = "attribute[" + ATTRIBUTE_PGSHIPMENTLIMITEDQUANTITY + "]";
	String SELECT_ATTRIBUTE_PGCONSUMERWEIGHTVOLUME = "attribute[" + ATTRIBUTE_PGCONSUMERWEIGHTVOLUME + "]";
	String SELECT_ATTRIBUTE_PGCUSTOMERWEIGHTVOLUME = "attribute[" + ATTRIBUTE_PGCUSTOMERWEIGHTVOLUME + "]";
	String SELECT_ATTRIBUTE_PGDGCOPLABELREQUIRED = "attribute[" + ATTRIBUTE_PGDGCOPLABELREQUIRED + "]";
	String SELECT_ATTRIBUTE_PGDGCUPLABELREQUIRED = "attribute[" + ATTRIBUTE_PGDGCUPLABELREQUIRED + "]";
	String SELECT_HAZARDCLASS = "from[" + RELATIONSHIP_PGHAZARDCLASS + "].to.name";
	String SELECT_PACKINGGROUP = "from[" + RELATIONSHIP_PGPACKINGGROUP + "].to.name";
	String ATTRIBUTE_REACH_STATUS = PropertyUtil.getSchemaProperty("attribute_ReachStatus");
	String SELECT_ATTRIBUTE_REACH_STATUS = "attribute[" + ATTRIBUTE_REACH_STATUS + "]";
	String RELATIONSHIP_PGMEPSEPCERTIFICATION = PropertyUtil.getSchemaProperty("relationship_pgMEPSEPCertification");
	String SELECT_ATTRIBUTE_PGARTWORKUSAGE = "attribute[" + ATTRIBUTE_PGARTWORKUSAGE + "]";
	String SELECT_ATTRIBUTE_PGISMANDATORY = "attribute[" + ATTRIBUTE_PGISMANDATORY + "]";
	String SELECT_ATTRIBUTE_PGCORROSIVE = "attribute[" + ATTRIBUTE_PGCORROSIVE + "]";
	String RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD = PropertyUtil
			.getSchemaProperty("relationship_pgGlobalHarmonizedStandard");
	String ATTRIBUTE_PGCOLOR = PropertyUtil.getSchemaProperty("attribute_pgColor");
	String SELECT_ATTRIBUTE_PGCOLOR = "attribute[" + ATTRIBUTE_PGCOLOR + "]";
	String ATTRIBUTE_PG_COLOR_INTENSITY = PropertyUtil.getSchemaProperty("attribute_pgColorIntensity");
	String SELECT_ATTRIBUTE_PG_COLOR_INTENSITY = "attribute[" + ATTRIBUTE_PG_COLOR_INTENSITY + "]";
	String ATTRIBUTE_PG_ODOUR = PropertyUtil.getSchemaProperty("attribute_pgOdour");
	String SELECT_ATTRIBUTE_PG_ODOUR = "attribute[" + ATTRIBUTE_PG_ODOUR + "]";
	String ATTRIBUTE_PG_CLOSEDCUPFLASHPOINTVALUE = PropertyUtil
			.getSchemaProperty("attribute_pgClosedCupFlashpointValue");
	String SELECT_ATTRIBUTE_PG_CLOSEDCUPFLASHPOINTVALUE = "attribute[" + ATTRIBUTE_PG_CLOSEDCUPFLASHPOINTVALUE + "]";
	String ATTRIBUTE_PG_BOILINGPOINTVALUE = PropertyUtil.getSchemaProperty("attribute_pgBoilingPointValue");
	String SELECT_ATTRIBUTE_PG_BOILINGPOINTVALUE = "attribute[" + ATTRIBUTE_PG_BOILINGPOINTVALUE + "]";
	String ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION = PropertyUtil
			.getSchemaProperty("attribute_pgDoesBaseProductSustainCombustion");
	String SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION = "attribute[" + ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION
			+ "]";
	String ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE = PropertyUtil
			.getSchemaProperty("attribute_pgOxidizerSodiumPerCarbonate");
	String SELECT_ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE = "attribute[" + ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE
			+ "]";
	String ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE = PropertyUtil
			.getSchemaProperty("attribute_pgOxidizerHydrogenPeroxide");
	String SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE = "attribute[" + ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE + "]";
	String ATTRIBUTE_PG_ORGANIC_PEROXIDE = PropertyUtil.getSchemaProperty("attribute_pgOrganicPeroxide");
	String SELECT_ATTRIBUTE_PG_ORGANIC_PEROXIDE = "attribute[" + ATTRIBUTE_PG_ORGANIC_PEROXIDE + "]";
	String ATTRIBUTE_PG_AVAILABLE_OXYGEN_CONTENT = PropertyUtil.getSchemaProperty("attribute_pgAvailableOxygenContent");
	String SELECT_ATTRIBUTE_PG_AVAILABLE_OXYGEN_CONTENT = "attribute[" + ATTRIBUTE_PG_AVAILABLE_OXYGEN_CONTENT + "]";
	String ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT = PropertyUtil
			.getSchemaProperty("attribute_pgDoesBaseProductContainEmulsifiedLiquefiedNonFlammableGasPropellant");
	String SELECT_ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT = "attribute[" + ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT + "]";
	String ATTRIBUTE_PG_PROPELLANT = PropertyUtil.getSchemaProperty("attribute_pgPropellantemulsifiedforlifeofproduct");
	String SELECT_ATTRIBUTE_PG_PROPELLANT = "attribute[" + ATTRIBUTE_PG_PROPELLANT + "]";
	String ATTRIBUTE_PG_PH_DILUTION = PropertyUtil.getSchemaProperty("attribute_pgPHDilution");
	String SELECT_ATTRIBUTE_PG_PH_DILUTION = "attribute[" + ATTRIBUTE_PG_PH_DILUTION + "]";
	String ATTRIBUTE_PG_LIQUID_CORROSIVE_TO_METAL = PropertyUtil
			.getSchemaProperty("attribute_pgLiquidCorrosiveToMetal");
	String SELECT_ATTRIBUTE_PG_LIQUID_CORROSIVE_TO_METAL = "attribute[" + ATTRIBUTE_PG_LIQUID_CORROSIVE_TO_METAL + "]";
	String ATTRIBUTE_PG_TECHNICAL_CTM = PropertyUtil
			.getSchemaProperty("attribute_pgTechnicalBasisForTheCorrosiveToMetals");
	String SELECT_ATTRIBUTE_PG_TECHNICAL_CTM = "attribute[" + ATTRIBUTE_PG_TECHNICAL_CTM + "]";
	String ATTRIBUTE_PG_FLAMMABLE_LIQUID = PropertyUtil
			.getSchemaProperty("attribute_pgFlammableLiquidAbsorbedOrContainedWithInTheSolid");
	String SELECT_ATTRIBUTE_PG_FLAMMABLE_LIQUID = "attribute[" + ATTRIBUTE_PG_FLAMMABLE_LIQUID + "]";
	String ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES = PropertyUtil
			.getSchemaProperty("attribute_pgProductHaveAnySelfReactiveProperties");
	String SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES = "attribute[" + ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES + "]";
	String ATTRIBUTE_PG_PH_AVAILABILITY = PropertyUtil.getSchemaProperty("attribute_pgPHAvailability");
	String SELECT_ATTRIBUTE_PG_PH_AVAILABILITY = "attribute[" + ATTRIBUTE_PG_PH_AVAILABILITY + "]";
	String ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL = PropertyUtil
			.getSchemaProperty("attribute_pgDoesTheBaseProductContainEthanolPlusISOPropanol");
	String SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL = "attribute[" + ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL + "]";
	String ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS = PropertyUtil
			.getSchemaProperty("attribute_pgDoesBaseProductContainEmulsifiedLiquefiedFlammableGasPropellant");
	String SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS = "attribute[" + ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS + "]";
	String ATTRIBUTE_PG_HEAT_OF_COMBUSTION = PropertyUtil.getSchemaProperty("attribute_pgHeatOfCombustion");
	String SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION = "attribute[" + ATTRIBUTE_PG_HEAT_OF_COMBUSTION + "]";
	String ATTRIBUTE_PG_CAN_CONSTRUCTION = PropertyUtil.getSchemaProperty("attribute_pgCanConstruction");
	String SELECT_ATTRIBUTE_PG_CAN_CONSTRUCTION = "attribute[" + ATTRIBUTE_PG_CAN_CONSTRUCTION + "]";
	String ATTRIBUTE_PG_AEROSOLTYPE = PropertyUtil.getSchemaProperty("attribute_pgAerosolType");
	String SELECT_ATTRIBUTE_PG_AEROSOLTYPE = "attribute[" + ATTRIBUTE_PG_AEROSOLTYPE + "]";
	String ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST = PropertyUtil.getSchemaProperty("attribute_pgIsAerosolTestDataNeeded");
	String SELECT_ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST = "attribute[" + ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST + "]";
	String ATTRIBUTE_PG_FLAMEHEIGHT = PropertyUtil.getSchemaProperty("attribute_pgFlameHeight");
	String SELECT_ATTRIBUTE_PG_FLAMEHEIGHT = "attribute[" + ATTRIBUTE_PG_FLAMEHEIGHT + "]";
	String ATTRIBUTE_PG_FLAME_DURATION = PropertyUtil.getSchemaProperty("attribute_pgFlameDuration");
	String SELECT_ATTRIBUTE_PG_FLAME_DURATION = "attribute[" + ATTRIBUTE_PG_FLAME_DURATION + "]";
	String ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY = PropertyUtil
			.getSchemaProperty("attribute_pgAerosolConductivityOfTheContents");
	String SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY = "attribute[" + ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY + "]";
	String ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE = PropertyUtil
			.getSchemaProperty("attribute_pgPercentByWeightOfFlammablePropellantInAerosolContainer");
	String SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE = "attribute[" + ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE
			+ "]";
	String ATTRIBUTE_VAPOUR_DENSITY = PropertyUtil.getSchemaProperty("attribute_VaporDensity");
	String SELECT_ATTRIBUTE_VAPOUR_DENSITY = "attribute[" + ATTRIBUTE_VAPOUR_DENSITY + "]";
	String ATTRIBUTE_PG_PH = PropertyUtil.getSchemaProperty("attribute_pgPH");
	String SELECT_ATTRIBUTE_PG_PH = "attribute[" + ATTRIBUTE_PG_PH + "]";
	String KEY_YES_VALUE = "Yes";
	String KEY_NO_VALUE = "No";
	String KEY_H314 = "H314";
	String PHYSICALID = "physicalid";
	String KEY_ROLLUPOBJECTLIST = "RollUpObjectIdList";
	String KEY_GHS = "pgGHS";
	String CORROSIVE = "Corrosive";
	String ATTRIBUTE_PGCONFIGCOMMONDENDEDDATE = PropertyUtil.getSchemaProperty("attribute_pgConfigCommonEndedDate");
	String SELECT_ATTRIBUTE_PGCONFIGCOMMONDENDEDDATE = "attribute[" + ATTRIBUTE_PGCONFIGCOMMONDENDEDDATE + "]";
	String RELATIONSHIP_ARTWORKASSEMBLY = PropertyUtil.getSchemaProperty("relationship_ArtworkAssembly");
	String TYPE_WARNINGSTATEMENTSCOPY = PropertyUtil.getSchemaProperty("type_WarningStatementsCopy");
	String ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS = PropertyUtil
			.getSchemaProperty("attribute_pgOtherPackagingRequirements");
	String SELECT_ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS = "attribute[" + ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS + "]";
	String TYPE_PGPKGSTABILITYREPORT = PropertyUtil.getSchemaProperty("type_pgPKGStabilityReport");
	String RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP = PropertyUtil
			.getSchemaProperty("relationship_pgStabilitytoHumidityGrp");
	String RELATIONSHIP_PGSTABILITYTOTEMPGRP = PropertyUtil.getSchemaProperty("relationship_pgStabilitytoTempGrp");
	String SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS = "attribute[" + ATTRIBUTE_PGBOUNDARYCONDITIONS + "]";
	String RELATIONSHIP_PGTOWAREHOUSECLASSIFICATION = PropertyUtil
			.getSchemaProperty("relationship_pgToWarehousingClassification");
	String ATTRIBUTE_PGGHSCODE = PropertyUtil.getSchemaProperty("attribute_pgGHSCode");
	String TYPE_WARNINGSTATEMENTSMASTERCOPY = PropertyUtil.getSchemaProperty("type_WarningStatementsMasterCopy");
	String RELATIONSHIP_COPYLISTARTWORKMASTER = PropertyUtil.getSchemaProperty("relationship_CopyListArtworkMaster");
	String ATTRIBUTE_STORAGECONDITIONS = PropertyUtil.getSchemaProperty("attribute_StorageConditions");
	String SELECT_ATTRIBUTE_STORAGECONDITIONS = "attribute[" + ATTRIBUTE_STORAGECONDITIONS + "]";
	String ATTRIBUTE_ODOUR = PropertyUtil.getSchemaProperty("attribute_Odour");
	String SELECT_ATTRIBUTE_ODOUR = "attribute[" + ATTRIBUTE_ODOUR + "]";
	String ATTRIBUTE_PG_DSM_PRODUCTSIZE = PropertyUtil.getSchemaProperty("attribute_pgDSMProductSize");
	String SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE = "attribute[" + ATTRIBUTE_PG_DSM_PRODUCTSIZE + "]";
	String ATTRIBUTE_PGPRODUCTOXIDIZER = PropertyUtil.getSchemaProperty("attribute_pgProductOxidizer");
	String SELECT_ATTRIBUTE_PGPRODUCTOXIDIZER = "attribute[" + ATTRIBUTE_PGPRODUCTOXIDIZER + "]";
	String ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS = PropertyUtil
			.getSchemaProperty("attribute_pgDoesBaseProductContainByVolumeWaterMiscibleAlcohols");
	String SELECT_ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS = "attribute[" + ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS + "]";
	String ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT = PropertyUtil
			.getSchemaProperty("attribute_pgDoesBaseProductHaveAFirePoint");
	String SELECT_ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT = "attribute[" + ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT + "]";
	String ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS = PropertyUtil
			.getSchemaProperty("attribute_pgAerosolCanCorrosiveToMetals");
	String SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS = "attribute[" + ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS
			+ "]";
	String ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE = PropertyUtil.getSchemaProperty("attribute_pgFlammableOrNonFlammable");
	String SELECT_ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE = "attribute[" + ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE + "]";
	String SHIPPABLE_HALB = "Shippable HALB";
	String KEY_TRUE = "True";
	String KEY_FALSE = "False";
	String ATTRIBUTE_REGISTRATIONRENEWALLEADTIME = PropertyUtil
			.getSchemaProperty("attribute_pgRegistrationRenewalLeadTime");
	String ATTRIBUTE_REGISTRTATIONRENEWALSTATUS = PropertyUtil
			.getSchemaProperty("attribute_pgRegistrationRenewalStatus");
	String REGISTRATION_RENEWAL_LEAD_TIME = "RegistrationRenewalLeadTime";
	String REGISTRATION_RENEWAL_STATUS = "RegistrationRenewalStatus";
	String BUOM_EACH = "EACH";
	String BUOM_KILOGRAM = "KILOGRAM";
	String SELECT_ALTERNATE_PGASSEMBLYTYPE = "from[" + RELATIONSHIP_ALTERNATE + "].to."
			+ SELECT_ATTRIBUTE_PGASSEMBLYTYPE;
	String SELECT_ALTERNATE_PGSAPTYPE = "from[" + RELATIONSHIP_ALTERNATE + "].to." + SELECT_ATTRIBUTE_PGSAPTYPE;
	String VALIDATE_PARAMETER = "Validate";
	int IVALIDATE_ZERO = 0;
	int IVALIDATE_TWO = 2;
	int IVALIDATE_THREE = 3;
	int IVALIDATE_FOUR = 4;
	int IVALIDATE_FIVE = 5;
	int IVALIDATE_SIX = 6;
	int IVALIDATE_SEVEN = 7;
	int IVALIDATE_EIGHT = 8;
	String DENIED = "#DENIED!";
	String READSHOW_ACCESS = "read,show";
	String INTERFACE_DUMMYMEPSEP = PropertyUtil.getSchemaProperty("interface_Dummy_MEPSEP");
	String MMM_DATE_FORMAT = "MMM dd, yyyy";
	String YYYY_DATE_FORMAT = "yyyy-MM-dd";
	String MM_DATE_FORMAT = "MM/dd/yyyy";
	String CAPS_TYPE = "TYPE";
	String CAPS_TYPES = "TYPES";
	String POLICY = "policy";
	String INDEXED = "Indexed";
	String OFF = "Off";
	String TYPE_PGPRODUCTPLATFORM = PropertyUtil.getSchemaProperty("type_pgProductPlatform");
	String MARKETS = "Markets";
	String MARKET = "Market";
	String VEEVA = "Veeva";
	String ATTRIBUTE_REGISTEREDPRODUCTNAME = PropertyUtil.getSchemaProperty("attribute_pgRegisteredProductName");
	String REGISTERED_PRODUCT_NAME = "RegisteredProductName";
	String SELECT_FORMULATION_PROCESS_ID = "from[" + RELATIONSHIP_PLANNEDFOR + "].to.id";
	String SELECT_FORMULATION_PROCESS_REVISION = "from[" + RELATIONSHIP_PLANNEDFOR + "].to.revision";
	String SELECT_FORMULATION_PROCESS_RELEASE_PHASE = "from[" + RELATIONSHIP_PLANNEDFOR + "].to."
			+ SELECT_ATTRIBUTE_RELEASE_PHASE;
	String SELECT_FORMULATION_PROCESS_ORIGINATED = "from[" + RELATIONSHIP_PLANNEDFOR + "].to.originated";
	String SELECT_SUBSTITUTE_PRIMARY_COMPONENTS = "from.to[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].fromrel.to";
	String SELECT_PRIMARY_COMPONENT_SUBSTITUTED_WET_PERCENT = "from.to[" + RELATIONSHIP_PLBOMSUBSTITUTE + "]."
			+ SELECT_ATTRIBUTE_QUANTITY;
	String SELECT_SUBSTITUTE_FROM_TYPE = "from.to[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].fromrel.from.to["
			+ RELATIONSHIP_PLBOM + "].from.type";
	String ATTRIBUTE_TARGET_PERCENT_AS_CONSUMED = PropertyUtil.getSchemaProperty("attribute_TargetPercentAsConsumed");
	String SELECT_ATTRIBUTE_TARGET_PERCENT_AS_CONSUMED = "attribute[" + ATTRIBUTE_TARGET_PERCENT_AS_CONSUMED + "]";
	String SELECTABLE_FROMMID = "frommid[";
	String ON = "On";
	String ADLIB_CONFIGOBJECT = "pgAdlibServerConfiguration";
	String GENDOC_ENABLEDISABLE_CONFIGOBJECT = "pgGenDocCreationEnableDisable";
	String SELECT_ATTRIBUTE_PGPROTOCOLGENDOC = "attribute[" + ATTRIBUTE_PGPROTOCOLGENDOC + "]";
	String SELECT_ATTRIBUTE_PGFTPINPUTFOLDERPATHGENDOC = "attribute[" + ATTRIBUTE_PGFTPINPUTFOLDERPATHGENDOC + "]";
	String SELECT_ATTRIBUTE_PGHOSTNAMEGENDOC = "attribute[" + ATTRIBUTE_PGHOSTNAMEGENDOC + "]";
	String SELECT_ATTRIBUTE_PGRENDERPDFGENDOC = "attribute[" + ATTRIBUTE_PGRENDERPDFGENDOC + "]";
	String SELECT_ATTRIBUTE_PGFTPOUTPUTFOLDERPATHGENDOC = "attribute[" + ATTRIBUTE_PGFTPOUTPUTFOLDERPATHGENDOC + "]";
	String SELECT_ATTRIBUTE_PGFTPROOTFOLDERPATHGENDOC = "attribute[" + ATTRIBUTE_PGFTPROOTFOLDERPATHGENDOC + "]";
	String SELECT_ATTRIBUTE_PGADLIBUSERNAMEGENDOC = "attribute[" + ATTRIBUTE_PGADLIBUSERNAMEGENDOC + "]";
	String SELECT_ATTRIBUTE_PGPORTGENDOC = "attribute[" + ATTRIBUTE_PGPORTGENDOC + "]";
	String SELECT_ATTRIBUTE_PGADLIBPASSWORDGENDOC = "attribute[" + ATTRIBUTE_PGADLIBPASSWORDGENDOC + "]";
	String ROLLUPPAGEFILE = "pgRollUpConfig";
	String TYPE_PGPKGTECHNICALRATIONALE = PropertyUtil.getSchemaProperty("type_pgPKGTechnicalRationale");
	String ATTRIBUTE_PGSMARTLABELREADY = PropertyUtil.getSchemaProperty("attribute_pgSmartLabelReady");
	String ATTRIBUTE_PGDANGEROUSGOODSREADY = PropertyUtil.getSchemaProperty("attribute_pgDangerousGoodsReady");
	String SELECT_ATTRIBUTE_PGSMARTLABELREADY = "attribute[" + ATTRIBUTE_PGSMARTLABELREADY + "]";
	String SELECT_ATTRIBUTE_PGDANGEROUSGOODSREADY = "attribute[" + ATTRIBUTE_PGDANGEROUSGOODSREADY + "]";
	String INTERMEDIATE = "Intermediate";
	String SELECT_EBOM_SUBSTITUTE_FROMID = "to[" + RELATIONSHIP_EBOMSUBSTITUTE + "].fromrel.to.id";
	String SELECT_EBOM_SUBSTITUTE_FROMTYPE = "to[" + RELATIONSHIP_EBOMSUBSTITUTE + "].fromrel.to.type";
	String SELECT_PGDEFINESMATERIAL_TOID = "from[" + RELATIONSHIP_PGDEFINESMATERIAL + "].to.id";
	String SELECT_PRODUCTPARTID_FROM_MASTER = "to[" + RELATIONSHIP_CLASSIFIEDITEM + "].tomid["
			+ RELATIONSHIP_PARTFAMILYREFERENCE + "].fromrel.to.id";
	String SELECT_PRODUCTPARTTYPE_FROM_MASTER = "to[" + RELATIONSHIP_CLASSIFIEDITEM + "].tomid["
			+ RELATIONSHIP_PARTFAMILYREFERENCE + "].fromrel.to.type";
	String SELECT_ALTERNATE_FROMID = "to[" + RELATIONSHIP_ALTERNATE + "].from.id";
	String SELECT_ATTRIBUTE_PGDGCROLLUPFLAG = "attribute[" + ATTRIBUTE_PGDGCROLLUPFLAG + "]";
	String SELECT_ATTRIBUTE_PGGHSROLLUPFLAG = "attribute[" + ATTRIBUTE_PGGHSROLLUPFLAG + "]";
	String SELECT_ATTRIBUTE_PGSLROLLUPFLAG = "attribute[" + ATTRIBUTE_PGSLROLLUPFLAG + "]";
	String SELECT_ATTRIBUTE_PGSRROLLUPFLAG = "attribute[" + ATTRIBUTE_PGSRROLLUPFLAG + "]";
	String SELECT_ATTRIBUTE_PGCERTIFICATIONSROLLUPFLAG = "attribute[" + ATTRIBUTE_PGCERTIFICATIONSROLLUPFLAG + "]";
	String SELECT_ATTRIBUTE_PGWAREHOUSEROLLUPFLAG = "attribute[" + ATTRIBUTE_PGWAREHOUSEROLLUPFLAG + "]";
	String SELECT_PLBOMSUBSTITUTE_FROMID = "to[" + RELATIONSHIP_PLBOM + "].from.to[" + RELATIONSHIP_PLBOMSUBSTITUTE
			+ "].fromrel[" + RELATIONSHIP_PLBOM + "].from.id";
	String SELECT_ATTRIBUTE_PGMARKFORROLLUP = "attribute[" + ATTRIBUTE_PGMARKFORROLLUP + "]";
	String SELECT_ATTRIBUTE_PGEVENTFORROLLUP = "attribute[" + ATTRIBUTE_PGEVENTFORROLLUP + "]";
	String ZERO = "0";
	String SELECT_EBOM_SUBSTITUTE_PHYSICALID = "frommid[" + RELATIONSHIP_EBOMSUBSTITUTE + "].to.physicalid";
	String SELECT_FBOM_SUBSTITUTE_PHYSICALID = "frommid[" + RELATIONSHIP_PLBOMSUBSTITUTE + "].to.from["
			+ RELATIONSHIP_PLBOM + "].to.physicalid";
	String SELECT_CERTIFICATION_COUNTRYID = "tomid[" + RELATIONSHIP_PGCOUNTRIESCERTICATIONCLAIMED + "].from.id";
	String SELECT_MASTERID_FROMPRODUCTPART = "frommid[" + RELATIONSHIP_PARTFAMILYREFERENCE + "].torel.to.id";
	String SELECT_MASTERPHYSICALID_FROMPRODUCTPART = "frommid[" + RELATIONSHIP_PARTFAMILYREFERENCE
			+ "].torel.to.physicalid";
	String SELECT_MASTERSTATE_FROMPRODUCTPART = "frommid[" + RELATIONSHIP_PARTFAMILYREFERENCE + "].torel.to.current";
	String SELECT_MASTERTYPE_FROMPRODUCTPART = "frommid[" + RELATIONSHIP_PARTFAMILYREFERENCE + "].torel.to.type";
	String SELECT_ATTRIBUTE_PGGHSCODE = "attribute[" + ATTRIBUTE_PGGHSCODE + "]";
	String AREAS = "Areas";
	String REGIONS = "Regions";
	String GROUPS = "Groups";
	String RELATIONSHIP_PGPLIAREATOPGPLIMATERIALCERTIFICATIONS = PropertyUtil
			.getSchemaProperty("relationship_pgPLIAreaTopgPLIMaterialCertifications");
	String RELATIONSHIP_PGPLIREGIONTOPGPLIMATERIALCERTIFICATIONS = PropertyUtil
			.getSchemaProperty("relationship_pgPLIRegionTopgPLIMaterialCertifications");
	String RELATIONSHIP_PGPLIGROUPTOPGPLIMATERIALCERTIFICATIONS = PropertyUtil
			.getSchemaProperty("relationship_pgPLIGroupTopgPLIMaterialCertifications");
	String SELECT_CERTIFICATION_AREAID = "tomid[" + RELATIONSHIP_PGPLIAREATOPGPLIMATERIALCERTIFICATIONS + "].from.id";
	String SELECT_CERTIFICATION_REGIONID = "tomid[" + RELATIONSHIP_PGPLIREGIONTOPGPLIMATERIALCERTIFICATIONS
			+ "].from.id";
	String SELECT_CERTIFICATION_GROUPID = "tomid[" + RELATIONSHIP_PGPLIGROUPTOPGPLIMATERIALCERTIFICATIONS + "].from.id";
	String RELATIONSHIP_PGPLIREGIONCERTIFIED = PropertyUtil.getSchemaProperty("relationship_pgPLIRegionCertified");
	String RELATIONSHIP_PGPLIAREACERTIFIED = PropertyUtil.getSchemaProperty("relationship_pgPLIAreaCertified");
	String RELATIONSHIP_PGPLIGROUPCERTIFIED = PropertyUtil.getSchemaProperty("relationship_pgPLIGroupCertified");
	String ATTRIBUTE_PGTECHNICALNAME1 = PropertyUtil.getSchemaProperty("attribute_pgTechnicalName1");
	String SELECT_ATTRIBUTE_PGTECHNICALNAME1 = "attribute[" + ATTRIBUTE_PGTECHNICALNAME1 + "]";
	String ATTRIBUTE_PGTECHNICALNAME2 = PropertyUtil.getSchemaProperty("attribute_pgTechnicalName2");
	String SELECT_ATTRIBUTE_PGTECHNICALNAME2 = "attribute[" + ATTRIBUTE_PGTECHNICALNAME2 + "]";
	String SELECT_ROLLUP_CERTIFICATION_COUNTRY = "tomid[" + RELATIONSHIP_PGCOUNTRIESCERTIFIED + "].from.name";
	String SELECT_ROLLUP_CERTIFICATION_REGION = "tomid[" + RELATIONSHIP_PGPLIREGIONCERTIFIED + "].from.name";
	String SELECT_ROLLUP_CERTIFICATION_AREA = "tomid[" + RELATIONSHIP_PGPLIAREACERTIFIED + "].from.name";
	String SELECT_ROLLUP_CERTIFICATION_GROUPTOCOUNTRY = "tomid[" + RELATIONSHIP_PGPLIGROUPCERTIFIED + "].from.name";
	String SELECT_FROMID = "from.id";
	String SELECT_FROMTYPE = "from.type";
	String SELECT_FROMNAME = "from.name";
	String SELECT_FROMREVISION = "from.revision";
	String RELATIONSHIP = "relationship";
	String LEVEL = "level";
	String CONST_OPEN_BRACKET = "(";
	String CONST_CLOSED_BRACKET = ")";
	String CONST_SYMBOL_EQUAL = "==";
	String DUMMY_ARG = "Dummy";
	String OBJECT_PG_EMEA_PLANTS_LIST = "pgEMEAPlantsList";
	String TABLE_PARAM_CHECK_AU = "AU";
	String TABLE_PARAM_CHECK_AP = "AP";
	String PLANTS_DELIMITER = "\\|";
	String ATTRIBUTE_PG_EMEA_PLANTS_LIST = PropertyUtil.getSchemaProperty("attribute_pgEMEAPlantsList");
	String SELECT_ATTRIBUTE_PG_EMEA_PLANTS_LIST = "attribute[" + ATTRIBUTE_PG_EMEA_PLANTS_LIST + "]";
	String ATTRIBUTE_PG_CHECK_IN_EMEA_PLANTS_LIST = PropertyUtil.getSchemaProperty("attribute_pgCheckInEMEAPlants");
	String SELECT_ATTRIBUTE_PG_CHECK_IN_EMEA_PLANTS_LIST = "attribute[" + ATTRIBUTE_PG_CHECK_IN_EMEA_PLANTS_LIST + "]";
	String ATTRIBUTE_PG_RETRIGGER_BOMeDElivery_FOR_CATIA_APP = PropertyUtil
			.getSchemaProperty("attribute_pgRetriggerBOMeDeliveryForCATIAAPP");
	String SELECT_ATTRIBUTE_PG_RETRIGGER_BOMeDElivery_FOR_CATIA_APP = "attribute["
			+ ATTRIBUTE_PG_RETRIGGER_BOMeDElivery_FOR_CATIA_APP + "]";
	String OBJECT_PG_RETRIGGER_BOMeDElivery_FOR_CATIA_APP = "pgRetriggerBOMeDeliveryForCATIAAPP";
	String SELECT_PREVIOUS_ID = "previous.id";
	String SELECT_CATIA_APP_EBOM_SUBSTITUTE_EXISTS = "to[" + RELATIONSHIP_EBOMSUBSTITUTE + "]";
	String SELECT_CATIA_APP_EBOM_SUBSTITUTE_EXPAND_ID = "to[" + RELATIONSHIP_EBOMSUBSTITUTE + "].fromrel.from.id";
	String SELECT_CATIA_APP_EBOM_SUBSTITUTE_EXPAND_TYPE = "to[" + RELATIONSHIP_EBOMSUBSTITUTE + "].fromrel.from.type";
	String SELECT_CATIA_APP_EBOM_SUBSTITUTE_EXPAND_NAME = "to[" + RELATIONSHIP_EBOMSUBSTITUTE + "].fromrel.from.name";
	String SELECT_CATIA_APP_EBOM_SUBSTITUTE_EXPAND_REVISION = "to[" + RELATIONSHIP_EBOMSUBSTITUTE
			+ "].fromrel.from.revision";
	String SELECT_CATIA_APP_EBOM_SUBSTITUTE_EXPAND_CURRENT = "to[" + RELATIONSHIP_EBOMSUBSTITUTE
			+ "].fromrel.from.current";
	String SELECT_CATIA_APP_EBOM_SUBSTITUTE_EXPAND_POLICY = "to[" + RELATIONSHIP_EBOMSUBSTITUTE
			+ "].fromrel.from.policy";
	String SELECT_CATIA_APP_EBOM_SUBSTITUTE_EXPAND_PREVIOUS = "to[" + RELATIONSHIP_EBOMSUBSTITUTE
			+ "].fromrel.from.previous";
	String SELECT_CATIA_APP_EBOM_SUBSTITUTE_EXPAND_ASSEMBLY_TYPE = "to[" + RELATIONSHIP_EBOMSUBSTITUTE
			+ "].fromrel.from." + SELECT_ATTRIBUTE_PGASSEMBLYTYPE;
	String SELECT_CATIA_APP_EBOM_EXISTS = "to[" + RELATIONSHIP_EBOM + "]";
	String SELECT_CATIA_APP_EBOM_EXPAND_ID = "to[" + RELATIONSHIP_EBOM + "].from.id";
	String SELECT_CATIA_APP_EBOM_EXPAND_TYPE = "to[" + RELATIONSHIP_EBOM + "].from.type";
	String SELECT_CATIA_APP_EBOM_EXPAND_NAME = "to[" + RELATIONSHIP_EBOM + "].from.name";
	String SELECT_CATIA_APP_EBOM_EXPAND_REVISION = "to[" + RELATIONSHIP_EBOM + "].from.revision";
	String SELECT_CATIA_APP_EBOM_EXPAND_CURRENT = "to[" + RELATIONSHIP_EBOM + "].from.current";
	String SELECT_CATIA_APP_EBOM_EXPAND_POLICY = "to[" + RELATIONSHIP_EBOM + "].from.policy";
	String SELECT_CATIA_APP_EBOM_EXPAND_PREVIOUS = "to[" + RELATIONSHIP_EBOM + "].from.previous";
	String SELECT_CATIA_APP_EBOM_EXPAND_ASSEMBLY_TYPE = "to[" + RELATIONSHIP_EBOM + "].from."
			+ SELECT_ATTRIBUTE_PGASSEMBLYTYPE;
	String SELECT_CATIA_APP_ALTERNATE_EXISTS = "from[" + RELATIONSHIP_ALTERNATE + "]";
	String SELECT_CATIA_APP_ALTERNATE_EXPAND_ID = "from[" + RELATIONSHIP_ALTERNATE + "].to.id";
	String SELECT_CATIA_APP_ALTERNATE_EXPAND_TYPE = "from[" + RELATIONSHIP_ALTERNATE + "].to.type";
	String SELECT_CATIA_APP_ALTERNATE_EXPAND_NAME = "from[" + RELATIONSHIP_ALTERNATE + "].to.name";
	String SELECT_CATIA_APP_ALTERNATE_EXPAND_REVISION = "from[" + RELATIONSHIP_ALTERNATE + "].to.revision";
	String SELECT_CATIA_APP_ALTERNATE_EXPAND_CURRENT = "from[" + RELATIONSHIP_ALTERNATE + "].to.current";
	String SELECT_CATIA_APP_ALTERNATE_EXPAND_POLICY = "from[" + RELATIONSHIP_ALTERNATE + "].to.policy";
	String SELECT_CATIA_APP_ALTERNATE_EXPAND_PREVIOUS = "from[" + RELATIONSHIP_ALTERNATE + "].to.previous";
	String SELECT_CATIA_APP_ALTERNATE_EXPAND_ASSEMBLY_TYPE = "from[" + RELATIONSHIP_ALTERNATE + "].to."
			+ SELECT_ATTRIBUTE_PGASSEMBLYTYPE;
	String MAP_KEY_SUBSTITUTE_FLAG_COP_IN_COP = "COPinCOP";
	String MAP_KEY_COP_BULK_SUBS_QUANTITY = "COPBULKSubsQty";
	String BULK_INTERMEDIATE_UNIT = "Bulk Intermediate Unit";
	String SELECT_COP_BULK_SUBSTITUTE_QUANTITY = "to[" + RELATIONSHIP_EBOMSUBSTITUTE + "]." + SELECT_ATTRIBUTE_QUANTITY;
	String ATTR_STAMPING_VERTICAL_LENGTH = PropertyUtil.getSchemaProperty("attribute_pgVerticalLength");
	String ATTR_STAMPING_ROTATION_LENGTH = PropertyUtil.getSchemaProperty("attribute_pgRotationLength");
	String ATTR_RESTRICTED_FOOTER = PropertyUtil.getSchemaProperty("attribute_pgGenDocRestrictedFooter");
	String ATTR_NON_RESTRICTED_FOOTER = PropertyUtil.getSchemaProperty("attribute_pgGenDocNonRestrictedFooter");
	String STAMP_NEW_LINE = "NewLine";
	String ATTRIBUTE_PGSPECREADERROLES = PropertyUtil.getSchemaProperty("attribute_pgSpecReaderRoles");
	String SELECT_ATTRIBUTE_PGSPECREADERROLES = "attribute[" + ATTRIBUTE_PGSPECREADERROLES + "]";
	String ATTRIBUTE_PGSPECREADERURL = PropertyUtil.getSchemaProperty("attribute_pgSpecReaderURL");
	String SELECT_ATTRIBUTE_PGSPECREADERURL = "attribute[" + ATTRIBUTE_PGSPECREADERURL + "]";
	String PGDSMSUPPORTTEAM_CONFIGOBJECT = "pgDSMSupportTeam";
	String OBJECT_PG_BOMEDELIVERY_MAIL_INFO = "pgBOMeDeliveryMailInfo";
	String ATTRIBUTE_PG_BOMeDELIVERY_FROM_MAIL_ID = PropertyUtil
			.getSchemaProperty("attribute_pgBOMeDeliveryMailFromID");
	String SELECT_ATTRIBUTE_PG_BOMeDELIVERY_FROM_MAIL_ID = "attribute[" + ATTRIBUTE_PG_BOMeDELIVERY_FROM_MAIL_ID + "]";
	String ATTRIBUTE_PG_BOMeDELIVERY_TO_MAIL_ID = PropertyUtil.getSchemaProperty("attribute_pgBOMeDeliveryMailToID");
	String SELECT_ATTRIBUTE_PG_BOMeDELIVERY_TO_MAIL_ID = "attribute[" + ATTRIBUTE_PG_BOMeDELIVERY_TO_MAIL_ID + "]";
	String SELECT_FROM_CURRENT = "from.current[connection]";
	String SELECT_TO_CURRENT = "to.current[connection]";
	
	//Added by Jwala for 22x.06 Requirement 8277 - START
	public static final String CONFIG_OBJECT_PGBOMEDELIVERYCONFIG = "pgBOMeDeliveryConfiguration";
	//Added by Jwala for 22x.06 Requirement 8277 - END
}