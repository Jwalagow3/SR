package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface PromotionalItemPartCompService {
	HashMap<String, HashMap<String, Map<String, String>>> getPIPPartCompData(String sObjectName, Environment env);
}
