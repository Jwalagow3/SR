package com.pg.us.specanywhere_enovia.service.comp;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaPackagingAssemblyPart;
import com.pg.us.specanywhere_enovia.service.EnoviaPackagingAssemblyPartCompService;
import com.pg.us.specanywhere_enovia.service.impl.PackagingAssemblyPartImpl;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;

public class EnoviaPackagingAssemblyPartCompServiceImpl implements EnoviaPackagingAssemblyPartCompService {
	private static Logger LOGGER = Logger.getLogger(PackagingAssemblyPartImpl.class);
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	
	@Autowired
	private EnoviaConnectionPool pool;
	
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private EnoviaPackagingAssemblyPart pap;
	@Override
	public HashMap<String, HashMap<String, Map<String, String>>> getPAPPartCompData(String sObjid,Environment env) {
		// TODO Auto-generated method stub
		
		
		HashMap<String, HashMap<String, Map<String, String>>> hmAttrib = new HashMap<String,HashMap<String, Map<String, String>>>();
		HashMap<String, Map<String, String>> hmfinalrel = new HashMap<String, Map<String, String>>();
		HashMap<String, Map<String, String>> hmAttribObj = new HashMap<String, Map<String, String>>();
		StringValidatorUtil validator = new StringValidatorUtil();
		StopWatch sp = new StopWatch();
		sp.start();
		
		Context context = null;
		
		try {
			
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			swContext.stop();
			
			
			String sComp=ConstantsUtilIRM.PAP_COMPARE;
			if(UIUtil.isNotNullAndNotEmpty(sObjid)){
				hmfinalrel = pap.getPAPdata(sObjid,sComp, env);
				DomainObject doRMP = DomainObject.newInstance(context, sObjid);
				sComp=ConstantsUtilIRM.COMPARE;
				String sDocPreviousRevId  = doRMP.getPreviousRevision(context).getObjectId();
				if(UIUtil.isNotNullAndNotEmpty(sDocPreviousRevId))
					hmAttribObj = pap.getPAPdata(sDocPreviousRevId, sComp,env);
			}
			hmAttrib.put(ConstantsUtilIRM.RELEASEOBJECT, hmfinalrel);
			hmAttrib.put(ConstantsUtilIRM.OBSOLETEOBJECT,hmAttribObj);
		}catch(Exception e) {
			LOGGER.error("Exception From PAP COMPARISION Service IMPL Class "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		
		return hmAttrib;
	}
}
