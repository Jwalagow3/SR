package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.FileUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import com.matrixone.apps.common.CommonDocument;


import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;
import matrix.util.Pattern;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;

public class POAARTBO {
	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(FinishedProductPartBO.class);
	static StringValidatorUtil validator = new StringValidatorUtil();
	static BusObjectAttribUtil util = new BusObjectAttribUtil();
	
	public POAARTBO() {
		// empty constructor
	}
	
	
	/**
	 * Method Name 			: formatData
	 * Method Description 	:
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	
	
	/**
	 * Method Name 			: getPoaartBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getPoaartBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getPoaartDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getPoaartDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			if (doObj.exists(context))
				return doObj;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getMPSSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getPOAARTSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();
		
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_SAP_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);	
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.APPROVER_FULLNAME);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CPSNAME);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		
		busSelect.add(ConstantsUtil.ATL_IPCLASSIFICATION);
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_ID);
		busSelect.add(ConstantsUtil.ATL_REVISION);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);

		busSelect.add(ConstantsUtil.SELECT_SAP_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);
		
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYOFPRODUCTIS);
		// Guna Added for Defect 38237  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		// Guna Added for Defect 38237  18x.5.2 Release -- END
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList() {
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.ATL_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_TITLE);
		slMultiSelects.add(ConstantsUtil.ATL_ID);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		slMultiSelects.add(ConstantsUtil.ATL_REVISION);
		slMultiSelects.add(ConstantsUtil.ATL_TYPE);
		slMultiSelects.add(ConstantsUtil.ATL_RELEASE_PHASE);
		
		slMultiSelects.add(ConstantsUtil.ATL_IPCLASSIFICATION);

		slMultiSelects.add(ConstantsUtil.REL_ATS_NAME);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TITLE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_ID);
		slMultiSelects.add(ConstantsUtil.REL_ATS_STATE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_REV);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_RELEASE_PHASE);
		
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);

		
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);

		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);
		slMultiSelects.add(ConstantsUtil.STR_IPCLASS);
		
		return slMultiSelects;
	}   
	
	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	: Removing multi selects from
	 * 						  DomainConstants after getting the information
	 */
	public  void removeMultiList() {
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_IPCLASSIFICATION);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_REV);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_RELEASE_PHASE);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);


		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
	}
	
	
	/**
	 * Method Name 			: getMpsRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getPOAARTRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getCommonDataBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);

		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		
		busSelect.add(ConstantsUtil.SELECT_CONNECTION_ID);
		busSelect.add(ConstantsUtil.SELECT_PARENT);
		busSelect.add(ConstantsUtil.SELECT_LEVEL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);
		
		return busSelect;
	}
	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
	
		relSelect.add("to."+ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET); 			
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM);				
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR);	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION); 	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT); 			
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMBINATION_NUMBER);
		
		return relSelect;
	}
	
	
	/**
	 * Method Name 			: updateRefDocs
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map updateRefDocs(Context context, Map resultMaps) {
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();
		CommonDocBO commonDoc = new CommonDocBO();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		//SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- START
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
       //SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- END

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(ConstantsUtil.SYMBL_COMMA);
		StringBuilder sbCompany = new StringBuilder();
		int intLength = aCompany.length;
		if ( intLength > -1) {
			for (int i = 0; i < intLength; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(ConstantsUtilIRM.SPACEPLANT, ConstantsUtil.EMPTY_STRING)).append(ConstantsUtil.SYMBL_PIPE);
				}
			}
		}
		String sObjectId = validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		Map<String, String> mpRefDoc = new HashMap();

		try {
			DomainObject dobCdoc = new DomainObject(sObjectId);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			dobCdoc.close(context);
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbDispType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbDescription = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			StringBuilder sbGendocName = new StringBuilder();
			StringBuilder sbGendocPath = new StringBuilder();
			StringBuilder sbIsIRM = new StringBuilder();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sLangName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
				String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
				String sCurrent = (String) objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				//SPEC: Release SR18x.6. Modified by Dominic  for Defect 42267 on Date 12/04/2021 --START
				//SPEC: <09.08.2022>: Guna Modified for 49856 Defect   Dev 22x    -- START
				if((sType.equals(ConstantsUtil.TYPE_PGPOADOCUMENT) || (sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT))) && sRev.equalsIgnoreCase(ConstantsUtilIRM.RENDITION)) {
					continue;
				}
				//SPEC: <09.08.2022>: Guna Modified for 49856 Defect   Dev 22x    -- END
				boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 42267 on Date 12/04/2021 --END
				String sName = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.STR_FILE_NAME));
				String sCSSType = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE));
				String Display_Type = sType;
				String sGendocPath=validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.STR_FILE_CAPTURED));
				//SPEC: <06.04.2021>: Guna Added for 41858 Defect  Dev 18x.6   -- START
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				//SPEC: <06.04.2021>: Guna Added for 41858 Defect  Dev 18x.6   -- END
				if(ConstantsUtilIRM.RENDITION.equalsIgnoreCase(sRev))
				{
					DomainObject doRefDoc = new DomainObject(sId);
					StringList slBusSelect = new StringList(3);
					slBusSelect.add(ConstantsUtil.STR_FILE_NAME);
					slBusSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
					Map mpFiles = doRefDoc.getInfo(context,slBusSelect);
					doRefDoc.close(context);
					sName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
				
				}
				//SPEC: <06.04.2021>: Guna Added for 41858 Defect  Dev 18x.6   -- START
				String sLangBuffer = ConstantsUtil.EMPTY_STRING;
				if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
					sLangBuffer=sPGLangBuffer;
				else 
					sLangBuffer=sPLangBuffer;
				//SPEC: <06.04.2021>: Guna Added for 41858 Defect  Dev 18x.6   -- END
				if (!sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR)) {
					if (sLangName.contains(ConstantsUtilIRM.STARTSWITHLR))
						sLangBuffer = sRev;
					else
						sLangBuffer = ConstantsUtil.EMPTY_STRING;

					if (ConstantsUtilIRM.REFERENCEFILE.equalsIgnoreCase(sCSSType)) {

						Display_Type = ConstantsUtilIRM.REFERENCEFILE;

					} else if (ConstantsUtilIRM.QECFILE.equalsIgnoreCase(sCSSType)) {
						Display_Type = ConstantsUtilIRM.QUALEVOLUTIONCHARTFILE;

					} else if (ConstantsUtilIRM.DESIGN_FILE.equalsIgnoreCase(sCSSType)) {
						Display_Type =ConstantsUtilIRM. DESIGNFILE;

					} else if (ConstantsUtilIRM.LANG_RENDITION.equalsIgnoreCase(sCSSType)) {
						Display_Type = ConstantsUtilIRM.LANGRENDITION;

					}
					boolean showData = util.checkHasAccess(context, null, sId);
					//SPEC: Release SR18x.6.0.1 Modified by Dominic for REQ 33248 on Date 07/05/2021 --START
					if(!showData && util.isModificatinRequired()){
						continue;
					}
					//SPEC: Release SR18x.6.0.1 Modified by Dominic for REQ 33248 on Date 07/05/2021 --END
					//SPEC: <06.04.2021>: Guna Added for 42137 Defect  Dev 18x.6   -- START
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_EXISTS)) {
						//sId = ConstantsUtil.EMPTY_STRING;
						sId = ConstantsUtil.NO_ACCESS;
					}
					//SPEC: <06.04.2021>: Guna Added for 42137 Defect  Dev 18x.6   -- END
					if(sType.equals(ConstantsUtilIRM.TYPE_CIC)) {
						sId = ConstantsUtil.NO_ACCESS;
						sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
						showData=true;
					}
					if (showData) {
						if(ConstantsUtilIRM.RENDITION.equalsIgnoreCase(sRev))
						{
							util.formatData(sbType,sType);
						}
						else
						{
							util.formatData(sbType, util.mapType(sType));
						}
						util.formatData(sbDispType, Display_Type);
						util.formatData(sbName, sLangName);
						util.formatData(sbDescription, sDesc);
						util.formatData(sbCurrent, sCurrent);
						util.formatData(sbId, sId);
						util.formatData(sbRev, sRev);
						util.formatData(sbTitle, sTitle);
						util.formatData(sbSource, ConstantsUtil.EMPTY_STRING);
						util.formatData(sbLangBuffer, sLangBuffer);
						util.formatData(sbGendocName, sName);
						util.formatData(sbGendocPath, sGendocPath);
						util.formatData(sbIsIRM, String.valueOf(bisIRMDoc));
					}
					//SPEC: <06.04.2021>: Guna Added for 42137 Defect  Dev 18x.6   -- START
					else{
						util.formatData(sbType, util.mapType(sType));
						util.formatData(sbName, sName);
						util.formatData(sbDescription, ConstantsUtil.NO_ACCESS);
						util.formatData(sbCurrent, ConstantsUtil.NO_ACCESS);
						util.formatData(sbId, ConstantsUtil.NO_ACCESS);
						util.formatData(sbRev, sRev);
						util.formatData(sbTitle, ConstantsUtil.NO_ACCESS);
						util.formatData(sbSource, ConstantsUtil.NO_ACCESS);
						util.formatData(sbLangBuffer, ConstantsUtil.NO_ACCESS);
						util.formatData(sbGendocName, ConstantsUtil.NO_ACCESS);
						util.formatData(sbGendocPath, ConstantsUtil.NO_ACCESS);
						util.formatData(sbIsIRM, String.valueOf(bisIRMDoc));
						
					}
					//SPEC: <06.04.2021>: Guna Added for 42137 Defect  Dev 18x.6   -- END
				}
			}
			mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
			mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpRefDoc.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
			mpRefDoc.put(ConstantsUtil.DISPLAY_TYPE, sbDispType.toString());
			mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLangBuffer.toString());
			mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
			mpRefDoc.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
		} catch (Exception e) {

			LOGGER.error("Exception in Program : POAARTBO Method :updateRefDocs " + e);
			return new HashMap();
		}

		return mpRefDoc;
	}
	//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 04/03/2021 -- START
	/**
	 * Method Name 			: getPOALanguages
	 * Method Description 	: Getting POA Languages
	 * @param context
	 * @param domPOA
	 * @return String
	 */
	public String getPOALanguages(Context context,DomainObject domPOA) throws Exception {
		StringBuilder sbLanguage = new StringBuilder();
		MapList mlLanguageList   = null;
		StringList busSelects = new StringList(1);
		busSelects.addElement(DomainConstants.SELECT_NAME);
		if(null!=domPOA){
			Map mpLang = null;
			String strLangName=null;
			mlLanguageList = domPOA.getRelatedObjects(context,
					ConstantsUtilIRM.REL_POALANGUAGES,
					ConstantsUtil.SYMBL_ASTERISK,
					busSelects, //objectSelects,
					null,// relationshipSelects,
					false,// getTo,
					true,// getFrom,
					(short)1, // recursionLevel,
					ConstantsUtil.EMPTY_STRING,// busWhereClause,
					ConstantsUtil.EMPTY_STRING,// relWhereClause,
					ConstantsUtil.ZERO_LEVEL);
				if(mlLanguageList != null && mlLanguageList.size() > 0) {
					for(Iterator mpListItr = mlLanguageList.iterator(); mpListItr.hasNext();) {
						mpLang = (Map) mpListItr.next();
						strLangName =  (String)mpLang.get(DomainConstants.SELECT_NAME);
						if(sbLanguage.length()==0){
							sbLanguage.append(strLangName);
						}
						else{

							sbLanguage = sbLanguage.append(", ").append(strLangName);
						}
					}			
				}
			}			
		return sbLanguage.toString();
	}
	/**
	 * Method Name 			: getPOASecondaryPrinterData
	 * Method Description 	: Getting POA Secondary Printer
	 * @param context
	 * @param strCustomIPMS
	 * * @param strIPMS
	 * @return String
	 */
	public String getPOASecondaryPrinterData(Context context, String strCustomIPMS, String strIPMS) throws Exception {
		
		String strSupplierName = DomainConstants.EMPTY_STRING;
		String strIPMSId = DomainConstants.EMPTY_STRING;
		StringList slPrinterUniqueList = new StringList();
		StringList busSelects = new StringList(4);
		busSelects.addElement(DomainConstants.SELECT_NAME);
		busSelects.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_ADDRESS);
		busSelects.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_CITY);
		busSelects.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_COUNTRY);	
		StringBuilder relPatternPrinterMEPSEPEquivalent = new StringBuilder( ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT).append(ConstantsUtil.SYMBL_COMMA).append(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
		StringBuilder relPatternPrinterMEPSEPResp = new StringBuilder(ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY).append(ConstantsUtil.SYMBL_COMMA).append(ConstantsUtil.RELATIONSHIP_SUPPLYRESPONSIBILITY);
		String strAllowedTypes = ConstantsUtil.TYPE_PGONLINEPRINTINGPART+","+ConstantsUtil.TYPE_PACKINGMATERIAL+","+ConstantsUtil.TYPE_PACKAGINGMATERIALPART;		
		StringBuilder postTypePatternPrinter = new StringBuilder(ConstantsUtil.TYPE_PGSUPPLIER).append(ConstantsUtil.SYMBL_COMMA).append(ConstantsUtil.TYPE_COMPANY);	
		String strWhereClause = "current!=Obsolete";
		StringBuilder sbRelWhereClause = new StringBuilder("attribute["+ConstantsUtilIRM.STR_ATTR_PG_ARTWORK_SECONDARY+"]==TRUE");
		MapList mlMEPList   = null;
		DomainObject doMEP  = null;
		Map mpMEP           = null;
		String strMEPID     = null;
		String str_Add		= null;
		String str_City		= null;
		String str_Country	= null;
		Map mpSupplier          = null;
		MapList mlSuppliersList        = new MapList();
		MapList mlSuppliersListInfo    = null;
		StringBuilder sbPrinterDetails = new StringBuilder();
		if(ConstantsUtilIRM.STR_CUSTOMSPEC.equals(strCustomIPMS)) {
			
			strIPMSId=(String)getPOAIPMS(context, strIPMS);
			if(UIUtil.isNotNullAndNotEmpty(strIPMSId)){
				DomainObject domPackingMaterial = DomainObject.newInstance(context);
				domPackingMaterial.setId(strIPMSId);
				StringList slBusSelect = new StringList(3);
				slBusSelect.add(DomainConstants.SELECT_TYPE);
				slBusSelect.add(DomainConstants.SELECT_ID);
				Map mIPMSInfo = domPackingMaterial.getInfo(context,slBusSelect);
				if(!mIPMSInfo.isEmpty()) {	
					mlMEPList = domPackingMaterial.getRelatedObjects(context,
							relPatternPrinterMEPSEPEquivalent.toString(),
								strAllowedTypes,
								false,// getTo,
								true,// getFrom,
								(short)1, // recursionLevel,
								new StringList(DomainConstants.SELECT_ID), //objectSelects,
								null,// relationshipSelects,
								strWhereClause,// busWhereClause,
								sbRelWhereClause.toString(),// relWhereClause,
								null,// postRelPattern,
								null,//postTypePattern,
								null ); //postPatterns
								
						if(mlMEPList != null && mlMEPList.size() > 0) {
							for(Iterator mepListItr = mlMEPList.iterator(); mepListItr.hasNext();) {
								mpMEP = (Map) mepListItr.next();
								strMEPID =  (String)mpMEP.get(DomainConstants.SELECT_ID);
								doMEP = DomainObject.newInstance(context,strMEPID);
								mlSuppliersListInfo = doMEP.getRelatedObjects(context,
										relPatternPrinterMEPSEPResp.toString(),
										postTypePatternPrinter.toString(),
										true,// getTo,
										false,// getFrom,
										(short)1, // recursionLevel,
										busSelects, //objectSelects,
										null,// relationshipSelects,
										strWhereClause,// busWhereClause,
										null,// relWhereClause,
										null,// postRelPattern,
										postTypePatternPrinter.toString(),//postTypePattern,
										null ); //postPatterns
							mlSuppliersList.addAll(mlSuppliersListInfo);				
							}
						}					
					    if(mlSuppliersList != null && mlSuppliersList.size() > 0) {
						   for(Iterator supplierMapListIterator = mlSuppliersList.iterator(); supplierMapListIterator.hasNext();) {
								mpSupplier = (Map) supplierMapListIterator.next();
								
								strSupplierName =  (String)mpSupplier.get(DomainConstants.SELECT_NAME);
								
								str_Add = (String)mpSupplier.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ADDRESS);

								str_City = (String)mpSupplier.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CITY);

								str_Country = (String)mpSupplier.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COUNTRY);

							    if(!slPrinterUniqueList.contains(strSupplierName)){
									if(sbPrinterDetails.length()>0){
										
										sbPrinterDetails.append(", ");
									}
									
									sbPrinterDetails.append(strSupplierName).append(ConstantsUtil.SYMBL_TILDA).append(str_Add).append(ConstantsUtil.SYMBL_TILDA).append(str_City).append(ConstantsUtil.SYMBL_TILDA).append(str_Country);
									
								    slPrinterUniqueList.add(strSupplierName);	
								}
						   }
						}
					}
					strSupplierName = sbPrinterDetails.toString();
					if(strSupplierName == null) {
						strSupplierName = DomainConstants.EMPTY_STRING;
					}
				} else {
					strSupplierName = DomainConstants.EMPTY_STRING;
				}
		}
		return strSupplierName;
	}
	/**
	 * Method Name 			: getPOAIPMS
	 * Method Description 	: Getting POA IPMS
	 * @param context
	 *  @param strIPMS
	 * @return String
	 */
	public String getPOAIPMS(Context context, String strIPMS) throws Exception {
		
		String strIPMSId = DomainConstants.EMPTY_STRING;
		String strRevisionPattern = DomainConstants.QUERY_WILDCARD;
		String strIPMSName = DomainConstants.EMPTY_STRING;
		String strIPMSType = DomainConstants.EMPTY_STRING;
		StringList slIPMS = FrameworkUtil.split(strIPMS,ConstantsUtil.SYMBL_DOT);
		Map mIPMS = null;
		if(slIPMS.size() > 2) {
			if(slIPMS.size() > 3) {
				strRevisionPattern = slIPMS.get(2);
				strIPMSName = slIPMS.get(1);
				strIPMSType = slIPMS.get(0);
			} else if(slIPMS.size() == 3){
				//SPEC: 24-08-2022: Pooja Modified for Defect 50276-- START
				strIPMSName = slIPMS.get(0);
				strRevisionPattern = slIPMS.get(1);
				//SPEC: 24-08-2022: Pooja Modified for Defect 50276-- END
				strIPMSType = ConstantsUtilIRM.TYPE_PGPACKINGMATERIAL;
			}
			MapList mlIPMS = DomainObject.findObjects(context,  //Context
					strIPMSType, //type
					strIPMSName, //name
					strRevisionPattern, //revision
					DomainConstants.QUERY_WILDCARD, //owner
					ConstantsUtil.USER_VAULT, //vault
					null, //where clause
					false, //expand type for Sub types of strIPMSType
					new StringList(DomainObject.SELECT_ID) //Bus obj selectables
					);
			// Modified by Jwala for Internal POA defect -- START
			//if(null!=mlIPMS) {
			if(mlIPMS.size()!=0){
				mIPMS = (Map) mlIPMS.get(0);
				strIPMSId = (String)mIPMS.get(DomainObject.SELECT_ID);

			}
		}
		return 	strIPMSId;
	}
	
	
	/**
	 * Method Name 			: getCUPGrossWeight
	 * Method Description 	: get CU Gross weight
	 * @param context
	 * @param domain object
	 * @return String
	 */
	 
	public String getCUPGrossWeight(Context context, DomainObject doIPMS) {

		String strReturnValue = ConstantsUtil.EMPTY_STRING; 
		try {
		BusObjectAttribUtil objBusAttrb = new BusObjectAttribUtil();
		 StringList slCUPAttr = new StringList(2);
	        slCUPAttr.add(ConstantsUtil.NAME);
	        slCUPAttr.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
	        slCUPAttr.add(ConstantsUtil.SELECT_CURRENT);
	        slCUPAttr.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
	        
        MapList mlCUPList = doIPMS.getRelatedObjects(context, //context
        		DomainConstants.RELATIONSHIP_EBOM, //rel
        		ConstantsUtil.SYMBL_ASTERISK, //type 
        		slCUPAttr, //object selectables
        		null, //rel selectables 
        		true, //expand To
        		false, //expand From
        		(short)2, //recurse level
        		ConstantsUtil.EMPTY_STRING, //Object where
        		ConstantsUtil.EMPTY_STRING //rel where
        		);
        if (null != mlCUPList && mlCUPList.size() > 0) {
          Iterator<Map> iterator = mlCUPList.iterator();
          Map mCUP = null;
          String strType = ConstantsUtil.EMPTY_STRING;
          String strGross = ConstantsUtil.EMPTY_STRING;
          String strGrossUoM = ConstantsUtil.EMPTY_STRING;
          String strCUPCurrent = ConstantsUtil.EMPTY_STRING;
          while (iterator.hasNext()) {
            mCUP = iterator.next();
            strType = (String)mCUP.get(ConstantsUtil.TYPE);
            strCUPCurrent = (String)mCUP.get(ConstantsUtil.SELECT_CURRENT);
            if (!ConstantsUtil.EMPTY_STRING.equals(strType) && ConstantsUtil.TYPE_PG_CUSTOMERUNIT.equals(strType) && 
            		UIUtil.isNotNullAndNotEmpty(strCUPCurrent) && !ConstantsUtil.STATE_OBSOLETE.equals(strCUPCurrent)) {
              strGross = (String)mCUP.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
              strGrossUoM = (String)mCUP.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
              break;
            } 
          } 
         StringBuilder sbGrossWeightRealWithUoM = new StringBuilder();
          if (UIUtil.isNotNullAndNotEmpty(strGross))
            sbGrossWeightRealWithUoM.append(strGross).append(ConstantsUtil.EMPTY_SPACE).append(strGrossUoM); 
          strReturnValue = sbGrossWeightRealWithUoM.toString();
        } 
		} catch (Exception ex) {
			LOGGER.info("Exception in method getCUPGrossWeight:"+ex);
		}
        return strReturnValue;
	}
	
	/**
	 * Method Name 			: getManufacturingPlantsConnToPOA
	 * Method Description 	: get manufacturing plant
	 * @param context
	 * @param String
	 * @return String
	 */
	
	 public String getManufacturingPlantsConnToPOA(Context context, String sIPMSId) {
		    String sManufacturingPlant = ConstantsUtil.EMPTY_STRING;
		    try {
		    	StringValidatorUtil validator = new StringValidatorUtil();
		        if (UIUtil.isNotNullAndNotEmpty(sIPMSId)) {
		          DomainObject domIPMS = DomainObject.newInstance(context, sIPMSId);
		          MapList mlPlantDetails = domIPMS.getRelatedObjects(context,//context
		        		  DomainConstants.RELATIONSHIP_MANUFACTURING_RESPONSIBILITY,//relationship
		        		  ConstantsUtil.TYPE_PLANT,//type
		        		  new StringList(ConstantsUtil.NAME), //type selects
		        		  null, //rel selects
		        		  true, //to
		        		  false,//from 
		        		  (short)1, //recurse
		        		  ConstantsUtil.EMPTY_STRING, // Objwhere
		        		  ConstantsUtil.EMPTY_STRING, //relWhere
		        		  ConstantsUtilIRM.ZERO // limit
		        		  );
		          if (!mlPlantDetails.isEmpty()) {
		            StringList slPlantList = validator.toStringList(mlPlantDetails, ConstantsUtil.NAME);
		            sManufacturingPlant = FrameworkUtil.join(slPlantList, ConstantsUtil.SYMBL_COMMA);
		          } 
		        } 
		    } catch (Exception ex) {
		      LOGGER.info("Error occured while executing method getManufacturingPlantsConnToPOA ", ex);
		    } 
		    return sManufacturingPlant;
		  }
	
	
	/**
	 * Method Name 			: getReferenceFileObjects
	 * Method Description 	: Getting POA Files
	 * @param context
	 * @param objectId
	 * @return MapList
	 */
	public MapList getReferenceFileObjects(Context context,String objectId) {
		MapList returnList= new MapList();
		try {
			DomainObject dObjPOA = new DomainObject(objectId);
			MapList mlRevisionInfo = dObjPOA.getRevisionsInfo(context,new StringList(DomainObject.SELECT_ID),new StringList());
			Iterator itrRevisions = mlRevisionInfo.iterator();
			String strRevisionId = null;
			Map mpRevisionInfo = null;
			StringList slDataList = new StringList();
			slDataList.add( DomainObject.SELECT_CURRENT);
			slDataList.add( DomainObject.SELECT_REVISION);
			slDataList.add(DomainConstants.SELECT_DESCRIPTION);
			slDataList.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
			while(itrRevisions.hasNext()) 
			{
				mpRevisionInfo = (Map)itrRevisions.next();
				strRevisionId = (String)mpRevisionInfo.get(DomainConstants.SELECT_ID);
				dObjPOA = DomainObject.newInstance(context,strRevisionId);
				String strArtworkFileId = dObjPOA.getInfo(context, "relationship["+DomainConstants.RELATIONSHIP_PART_SPECIFICATION+"].to.id");
				Map mDataList = dObjPOA.getInfo(context, slDataList);
				String strPOAState = (String) mDataList.get(DomainObject.SELECT_CURRENT);
				String strPOARevision = (String) mDataList.get(DomainObject.SELECT_REVISION);
				String strPOADesc = (String) mDataList.get(DomainConstants.SELECT_DESCRIPTION);
				String strPOATitle = (String) mDataList.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				String strArtworkFileName = dObjPOA.getInfo(context, "relationship["+DomainConstants.RELATIONSHIP_PART_SPECIFICATION+"].to.name");
				if(null != strArtworkFileId && !"".equals(strArtworkFileId)){
					MapList mlPOAFiles = (MapList)getPOAFiles(context,strArtworkFileId);
					for(int i=0;i<mlPOAFiles.size();i++) {
						Map mData = (Map)mlPOAFiles.get(i);
						mData.put("ObjectType","Final Art");
						mData.put("ObjectState",strPOAState);
						mData.put("ObjectRevision",strPOARevision);
						mData.put("ObjectName","<a href='javascript:showNonModalDialog(\"../common/emxTree.jsp?objectId="+objectId+"\",780, 570, true);'>"+strArtworkFileName+"</a>");
						mData.put("ObjectTitle",strPOATitle);
						mData.put("ObjectDescription",strPOADesc);
					}
					returnList.addAll(mlPOAFiles);
				}
			}
			dObjPOA = DomainObject.newInstance(context,objectId);
			String strConnectedCICId = null;
			String strConnectedCICName = null;
			StringList slCICSelectable = new StringList(3);
			slCICSelectable.addElement(DomainConstants.SELECT_ID);
			slCICSelectable.addElement(DomainConstants.SELECT_NAME);
			MapList mlCICList = dObjPOA.getRelatedObjects(context, DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT, ConstantsUtilIRM.TYPE_CIC, slCICSelectable, null, false, true, (short) 1, null, null, 0);
			if(!mlCICList.isEmpty()){
				Map mapCIC = (Map) mlCICList.get(0);
				strConnectedCICId = (String) mapCIC.get(DomainConstants.SELECT_ID);
				strConnectedCICName = (String) mapCIC.get(DomainConstants.SELECT_NAME);
			}
			
			if(validator.isNotNullOrEmpty(strConnectedCICId))
			{
				DomainObject dObj = DomainObject.newInstance(context,strConnectedCICId);
				Map mArtworkDataList = dObj.getInfo(context, slDataList);
				String strCICState = (String) mArtworkDataList.get(DomainObject.SELECT_CURRENT);
				String strCICRevision = (String) mArtworkDataList.get(DomainObject.SELECT_REVISION);
				String strCICDesc = (String) mArtworkDataList.get(DomainConstants.SELECT_DESCRIPTION);
				String strCICTitle = (String) mArtworkDataList.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				if(null != strConnectedCICId && !"".equals(strConnectedCICId)){
					MapList mlCICFiles = (MapList)getPOAFiles(context,strConnectedCICId);
					for(int i=0;i<mlCICFiles.size();i++) {
						Map mData = (Map)mlCICFiles.get(i);
						mData.put("ObjectType","CIC");
						mData.put("ObjectState",strCICState);
						mData.put("ObjectRevision",strCICRevision);
						mData.put("ObjectName","<a href='javascript:showNonModalDialog(\"../common/emxTree.jsp?objectId="+strConnectedCICId+"\",780, 570, true);'>"+strConnectedCICName+"</a>");
						mData.put("ObjectTitle",strCICTitle);
						mData.put("ObjectDescription",strCICDesc);
					}
					returnList.addAll(mlCICFiles);
				}
			}
			String strArtworkTemplateId = dObjPOA.getInfo(context,"to["+ConstantsUtilIRM.RELATIONSHIP_ARTWORK_TEMPLATE_TO_POA+"].from."+DomainObject.SELECT_ID);
			String strArtworkTemplateName = dObjPOA.getInfo(context,"to["+ConstantsUtilIRM.RELATIONSHIP_ARTWORK_TEMPLATE_TO_POA+"].from."+DomainObject.SELECT_NAME);
			if(validator.isNotNullOrEmpty(strArtworkTemplateId))
			{
				DomainObject dObj = DomainObject.newInstance(context,strArtworkTemplateId);
				Map mArtworkDataList = dObj.getInfo(context, slDataList);
				String strArtworkTemplateState = (String) mArtworkDataList.get(DomainObject.SELECT_CURRENT);
				String strArtworkTemplateRevision = (String) mArtworkDataList.get(DomainObject.SELECT_REVISION);
				String strArtworkTemplateDesc = (String) mArtworkDataList.get(DomainConstants.SELECT_DESCRIPTION);
				String strArtworkTemplateTitle = (String) mArtworkDataList.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				if(null != strArtworkTemplateId && !"".equals(strArtworkTemplateId)){
					MapList mlArtworkTemplateFiles = (MapList)getPOAFiles(context,strArtworkTemplateId);
					for(int i=0;i<mlArtworkTemplateFiles.size();i++) {
						Map mData = (Map)mlArtworkTemplateFiles.get(i);
						mData.put("ObjectType","CIC");
						mData.put("ObjectState",strArtworkTemplateState);
						mData.put("ObjectRevision",strArtworkTemplateRevision);
						mData.put("ObjectName","<a href='javascript:showNonModalDialog(\"../common/emxTree.jsp?objectId="+strArtworkTemplateId+"\",780, 570, true);'>"+strArtworkTemplateName+"</a>");
						mData.put("ObjectTitle",strArtworkTemplateTitle);
						mData.put("ObjectDescription",strArtworkTemplateDesc);
					}
					returnList.addAll(mlArtworkTemplateFiles);
				}
			}
			StringList slArtworkTemplateReferenceIdList = dObjPOA.getInfoList(context,"to["+ConstantsUtilIRM.RELATIONSHIP_ARTWORK_TEMPLATE_TO_POA+"].from.from["+ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT+"].to."+DomainObject.SELECT_ID);
			StringList slArtworkTemplateReferenceNameList = dObjPOA.getInfoList(context,"to["+ConstantsUtilIRM.RELATIONSHIP_ARTWORK_TEMPLATE_TO_POA+"].from.from["+ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT+"].to."+DomainObject.SELECT_NAME);
			for(int i=0;i<slArtworkTemplateReferenceIdList.size();i++) {
				String strArtworkTemplateReferenceId = (String)slArtworkTemplateReferenceIdList.get(i);
				String strArtworkTemplateReferenceName = (String)slArtworkTemplateReferenceNameList.get(i);
				DomainObject dOmj = DomainObject.newInstance(context,strArtworkTemplateReferenceId);
				Map mReferencDocumentList = dOmj.getInfo(context, slDataList);
				String strReferenceDocumentState = (String) mReferencDocumentList.get(DomainObject.SELECT_CURRENT);
				String strReferenceDocumentRevision = (String) mReferencDocumentList.get(DomainObject.SELECT_REVISION);
				String strReferenceDocumentDesc = (String) mReferencDocumentList.get(DomainConstants.SELECT_DESCRIPTION);
				String strReferenceDocumentTitle = (String) mReferencDocumentList.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");

				MapList mlDesignTemplateFiles = (MapList)getPOAFiles(context,strArtworkTemplateReferenceId);
				for(int j=0;j<mlDesignTemplateFiles.size();j++) {
					Map mData = (Map)mlDesignTemplateFiles.get(j);
					mData.put("ObjectType","Design Template");
					mData.put("ObjectState",strReferenceDocumentState);
					mData.put("ObjectRevision",strReferenceDocumentRevision);
					mData.put("ObjectName","<a href='javascript:showNonModalDialog(\"../common/emxTree.jsp?objectId="+strArtworkTemplateReferenceId+"\",780, 570, true);'>"+strArtworkTemplateReferenceName+"</a>");
					mData.put("ObjectTitle",strReferenceDocumentTitle);
					mData.put("ObjectDescription",strReferenceDocumentDesc);
				}
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				dObjPOA.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				returnList.addAll(mlDesignTemplateFiles);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnList;
	}
	
	//SPEC: Defect 92006-Download of Files from POA not working as Expected Added by Jwala -- START
	/**
     * This method is used to get the list of files in
     * master (i.e. document holder) object
     *
     *        0 - objectList MapList
     * @returns Object
     * @throws Exception if the operation fails
     * @since Common 10.5
     * @grade 0
     */

    @SuppressWarnings("unchecked")
	@com.matrixone.apps.framework.ui.ProgramCallable
    public Object getPOAFiles(Context context, String masterObjectId) throws Exception
    {
    	try
    	{
    		DomainObject masterObject  = DomainObject.newInstance(context, masterObjectId);

    		//Added to make a single database call to
    		StringList masterObjectSelectList = new StringList(14);
    		masterObjectSelectList.add(CommonDocument.SELECT_ID);
    		masterObjectSelectList.add(CommonDocument.SELECT_TYPE);
    		masterObjectSelectList.add(CommonDocument.SELECT_NAME);
    		masterObjectSelectList.add(CommonDocument.SELECT_REVISION);
    		masterObjectSelectList.add(CommonDocument.SELECT_OWNER);
    		masterObjectSelectList.add(CommonDocument.SELECT_FILE_NAME);
    		masterObjectSelectList.add(CommonDocument.SELECT_FILE_FORMAT);
    		masterObjectSelectList.add(CommonDocument.SELECT_FILE_MODIFIED);
    		masterObjectSelectList.add(CommonDocument.SELECT_FILE_SIZE);
    		masterObjectSelectList.add(CommonDocument.SELECT_MOVE_FILES_TO_VERSION);
    		masterObjectSelectList.add(CommonDocument.SELECT_LATEST_REVISION);
    		masterObjectSelectList.add(CommonDocument.SELECT_CURRENT);
    		masterObjectSelectList.add(ConstantsUtil.STR_FILE_CAPTURED);

    		// get the Master Object data
    		Map masterObjectMap = masterObject.getInfo(context,masterObjectSelectList,addFilesMultiList());
    		// Version Object seletcs
    		StringList versionSelectList = new StringList(12);
    		versionSelectList.add(CommonDocument.SELECT_ID);
    		versionSelectList.add(CommonDocument.SELECT_REVISION);
    		versionSelectList.add(CommonDocument.SELECT_DESCRIPTION);
    		versionSelectList.add(CommonDocument.SELECT_LOCKED);
    		versionSelectList.add(CommonDocument.SELECT_TITLE);
    		versionSelectList.add(CommonDocument.SELECT_FILE_NAME);
    		versionSelectList.add(ConstantsUtil.STR_FILE_CAPTURED);
    		versionSelectList.add(CommonDocument.SELECT_FILE_FORMAT);
    		versionSelectList.add(CommonDocument.SELECT_FILE_MODIFIED);
    		versionSelectList.add(CommonDocument.SELECT_FILE_SIZE);
    		versionSelectList.add(DomainConstants.SELECT_ORIGINATED);
    		versionSelectList.add(DomainConstants.SELECT_TYPE);

    		// get the file (Version Object) data
    		MapList versionList = masterObject.getRelatedObjects(context,
    				CommonDocument.RELATIONSHIP_ACTIVE_VERSION,
    				CommonDocument.TYPE_DOCUMENTS,
    				versionSelectList,
    				null,
    				false,
    				true,
    				(short)1,
    				null,
    				null,
    				null,
    				null,
    				null);

    		// get all the files in the Master Object
    		StringList fileList   =getStringListValue(masterObjectMap,CommonDocument.SELECT_FILE_NAME);
    		StringList fileFormatList   =getStringListValue(masterObjectMap,CommonDocument.SELECT_FILE_FORMAT);
    		StringList fileSizeList   =getStringListValue(masterObjectMap,CommonDocument.SELECT_FILE_SIZE);
    		StringList filePathList   =getStringListValue(masterObjectMap,ConstantsUtil.STR_FILE_CAPTURED);
    		StringList fileModifiedList   =getStringListValue(masterObjectMap,CommonDocument.SELECT_FILE_MODIFIED);
    		StringList tempfileFormatList = new StringList();
    		StringList tempfileList  = new StringList();
    		for(int ii =0; ii< fileFormatList.size(); ii++){
    			String format = (String)fileFormatList.get(ii);
    			if(!DomainObject.FORMAT_MX_MEDIUM_IMAGE.equalsIgnoreCase(format)){
    				tempfileFormatList.add(format);
    				tempfileList.add(fileList.get(ii));
    			}
    		}
    		fileFormatList =tempfileFormatList;
    		fileList =tempfileList;

    		// get the Master Object meta data
    		String strName    = validator.getStringEquivalentForStringList(masterObjectMap.get(CommonDocument.SELECT_NAME));
    		String strState    =validator.getStringEquivalentForStringList(masterObjectMap.get(CommonDocument.SELECT_CURRENT));
    		String strRevision    = validator.getStringEquivalentForStringList(masterObjectMap.get(CommonDocument.SELECT_REVISION));
    		boolean isLatestRevision=(validator.getStringEquivalentForStringList(masterObjectMap.get(CommonDocument.SELECT_REVISION)).equalsIgnoreCase(validator.getStringEquivalentForStringList(masterObjectMap.get(CommonDocument.SELECT_LATEST_REVISION))));
    		boolean moveFilesToVersion = (Boolean.valueOf(validator.getStringEquivalentForStringList(masterObjectMap.get(CommonDocument.SELECT_MOVE_FILES_TO_VERSION)))).booleanValue();

    		// to store the object ID of the object where file resides
    		// this can be either master object Id or version object Id depending on the "Moves Files To Version" attribute value
    		String fileId    = validator.getStringEquivalentForStringList(masterObjectMap.get(CommonDocument.SELECT_ID));

    		// loop thru each file to build MapList, each Map corresponds to one file
    		MapList fileMapList = new MapList();
    		String fileFormat = DomainConstants.EMPTY_STRING;
    		String fileSize   = DomainConstants.EMPTY_STRING;
    		String filePath   = DomainConstants.EMPTY_STRING;
    		String fileModified   = DomainConstants.EMPTY_STRING;
    		Iterator versionItr  = versionList.iterator();
    		while(versionItr.hasNext())
    		{
    			Map fileVersionMap     = (Map)versionItr.next();
    			String versionFileName = (String)fileVersionMap.get(CommonDocument.SELECT_TITLE);
    			String versionFileRevision = (String)fileVersionMap.get(CommonDocument.SELECT_REVISION);
    			fileFormat = CommonDocument.FORMAT_GENERIC;
    			fileSize   = DomainConstants.EMPTY_STRING;
    			fileModified = DomainConstants.EMPTY_STRING;
    			filePath = DomainConstants.EMPTY_STRING;
    			DomainObject fileObject = DomainObject.newInstance(context, fileId);
    			boolean fileObjectIsKindOfCAD=false;
    			String SYMBOLIC_type_MCADDrawing="type_MCADDrawing";
    			String mCADDrawing = PropertyUtil.getSchemaProperty(context,SYMBOLIC_type_MCADDrawing);
    			String mCADModel = PropertyUtil.getSchemaProperty(context,DomainSymbolicConstants.SYMBOLIC_type_MCADModel);
    			if(fileObject.isKindOf(context, mCADModel)||fileObject.isKindOf(context, mCADDrawing)) {
    				fileObjectIsKindOfCAD=true;
    			}
    			if(fileObjectIsKindOfCAD) {
    				moveFilesToVersion=false;
    			}
    			if( moveFilesToVersion )
    			{
    				fileId = (String)fileVersionMap.get(CommonDocument.SELECT_ID);
    				try
    				{
    					fileFormat = (String) fileVersionMap.get(CommonDocument.SELECT_FILE_FORMAT);
    					fileSize = (String) fileVersionMap.get(CommonDocument.SELECT_FILE_SIZE);
    					filePath = (String) fileVersionMap.get(ConstantsUtil.STR_FILE_CAPTURED);
    					fileModified = (String) fileVersionMap.get(CommonDocument.SELECT_FILE_MODIFIED);
    				} catch (ClassCastException cex) {
    					StringList versionFilesList = (StringList)fileVersionMap.get(CommonDocument.SELECT_FILE_NAME);
    					StringList versionFileSize = (StringList)fileVersionMap.get(CommonDocument.SELECT_FILE_SIZE);
    					StringList versionFileFormat = (StringList)fileVersionMap.get(CommonDocument.SELECT_FILE_FORMAT);
    					StringList versionFileModified = (StringList)fileVersionMap.get(CommonDocument.SELECT_FILE_MODIFIED);
    					StringList versionFilePath = (StringList)fileVersionMap.get(ConstantsUtil.STR_FILE_CAPTURED);

    					// get the file corresponding to this Version by filtering the above fileList
    					int index = versionFilesList.indexOf(versionFileName.trim());

    					// get the File Format
    					if (index != -1 && versionFileFormat != null && versionFileFormat.size() >= index ) {
    						fileFormat = (String)versionFileFormat.get(index);
    					}

    					// get the File Size
    					if (index != -1 && versionFileSize != null && versionFileSize.size() >= index ) {
    						fileSize = (String)versionFileSize.get(index);
    					}
    					
    					// get the File Path
        				if (index != -1 && versionFilePath != null && versionFilePath.size() >= index ) {
        					filePath = (String)versionFilePath.get(index);
        				}

    					// get the File Modified date
    					if (index != -1 && versionFileModified != null && versionFileModified.size() >= index ) {
    						fileModified = (String)versionFileModified.get(index);
    					}
    				}
    			} else {
    				// get the file corresponding to this Version by filtering the above fileList
    				int index = fileList.indexOf(versionFileName);

    				// get the File Format
    				if (index != -1 && fileFormatList != null && fileFormatList.size() >= index )
    				{
    					fileFormat = (String)fileFormatList.get(index);
    				}

    				// get the File Size
    				if (index != -1 && fileSizeList != null && fileSizeList.size() >= index )
    				{
    					fileSize = (String)fileSizeList.get(index);
    				}
    				
    				// get the File Path
    				if (index != -1 && filePathList != null && filePathList.size() >= index )
    				{
    					filePath = (String)filePathList.get(index);
    				}

    				// get the File Modified date
    				if (index != -1 && fileModifiedList != null && fileModifiedList.size() >= index )
    				{
    					fileModified = (String)fileModifiedList.get(index);
    				}
    			}
    			fileVersionMap.put(ConstantsUtil.SELECT_NAME, strName);
    			fileVersionMap.put(ConstantsUtil.STR_FILE_CAPTURED, filePath);
    			fileVersionMap.put(ConstantsUtil.SELECT_CURRENT, strState);
    			fileVersionMap.put(ConstantsUtil.SELECT_REVISION, strRevision);
    			fileVersionMap.put(ConstantsUtil.OBJECT_MAP_FILE_ID, fileId);
    			fileVersionMap.put(CommonDocument.SELECT_FILE_FORMAT, fileFormat);
    			fileVersionMap.put(CommonDocument.SELECT_FILE_MODIFIED, fileModified);
    			fileVersionMap.put(CommonDocument.SELECT_FILE_NAME, versionFileName);
    			fileVersionMap.put(ConstantsUtilIRM.SELECT_ACTIVEVERSION, versionFileRevision);
    			fileVersionMap.put(CommonDocument.SELECT_FILE_SIZE, fileSize);
    			fileVersionMap.put(ConstantsUtilIRM.ISLATESTVERSION, isLatestRevision);  
    			fileMapList.add(fileVersionMap);
    		}
    		return fileMapList;
    	}
    	catch (Exception ex)
    	{
    		LOGGER.error("Unable to getPOAFiles : Program getPOAFiles " + ex);
    		ex.printStackTrace();
    		throw ex;
    	}
    }
    
    public StringList getStringListValue(Map masterObjectMap, String sKey) {
    	Object oFileModified   = masterObjectMap.get(sKey);
    	StringList slReturn = new StringList();
    	if(oFileModified != null) {
    		if(oFileModified instanceof String) {
    			String sFileModified =  (String)oFileModified;
    			slReturn.add(sFileModified);
    		}else if(oFileModified instanceof StringList) {
    			slReturn = (StringList)oFileModified;
    		}
    	}
    	return slReturn;
    }
    
  //SPEC: Defect 92006-Download of Files from POA not working as Expected Added by Jwala -- END
	/**
	 * Method Name 			: getFiles
	 * Method Description 	: Getting POA Files
	 * @param context
	 * @param masterObjectId
	 * @return Object
	 */
	 public Object getFiles(Context context, String masterObjectId) throws Exception
	    {
		 MapList fileMapList = new MapList();
	        try
	        {
	            DomainObject masterObject  = DomainObject.newInstance(context, masterObjectId);

	            //Added to make a single database call to
	            StringList masterObjectSelectList = new StringList(12);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_ID);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_TYPE);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_NAME);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_REVISION);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_OWNER);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_FILE_NAME);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_FILE_FORMAT);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_FILE_MODIFIED);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_FILE_SIZE);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_LATEST_REVISION);
	            masterObjectSelectList.add(ConstantsUtil.SELECT_CURRENT);
	            masterObjectSelectList.add(ConstantsUtilIRM.SELECT_ACTIVEVERSION);
	          //SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- START
	            masterObjectSelectList.add(ConstantsUtil.STR_FILE_CAPTURED);
	          //SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- END

	            // get the Master Object data
	            //Map masterObjectMap = masterObject.getInfo(context,masterObjectSelectList);
	            Map masterObjectMap = masterObject.getInfo(context, masterObjectSelectList,addFilesMultiList());
	                       
	            fileMapList.add(masterObjectMap);
	        }
	        catch (Exception ex)
	        {
	            ex.printStackTrace();
	            throw ex;
	        }
            return fileMapList;
	    }
	 /**
		 * Method Name 			: parseMaplistForFiles
		 * Method Description 	:Parse Files
		 * @param context
		 * @param mapList
		 * @return Map
		 */
	 public Map<String, String> parseMaplistForFiles(Context context, MapList mapList) throws Exception {
		 Map<String, String> mpFiles = new HashMap<String, String>();
		 try {
			 Iterator objectListItr = mapList.iterator();
			 StringBuilder sbId = new StringBuilder();
			 StringBuilder sbType = new StringBuilder();
			 StringBuilder sbTitle = new StringBuilder();
			 StringBuilder sbRevision = new StringBuilder();
			 StringBuilder sbState = new StringBuilder();
			 StringBuilder sbDescription = new StringBuilder();
			 StringBuilder sbFiles= new StringBuilder();
			 StringBuilder sbVersion = new StringBuilder();
			 //SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 10/03/2021 -- START
			 StringBuilder sbName = new StringBuilder();
			 //SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 10/03/2021 -- END
			 //SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- START
			 StringBuilder sbFileName = new StringBuilder();
			 StringBuilder sbFilePath = new StringBuilder();
			 //SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- END
			 while (objectListItr.hasNext()) {
				 Map objectMap = (Map) objectListItr.next();
					/*
					 * String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID); String sName =
					 * (String) objectMap.get(ConstantsUtil.SELECT_NAME); String sRevision =
					 * (String) objectMap.get(ConstantsUtil.SELECT_REVISION); String sType =
					 * (String) objectMap.get("ObjectType"); String sTitle = (String)
					 * objectMap.get("ObjectTitle"); String sCurrent = (String)
					 * objectMap.get(ConstantsUtil.SELECT_CURRENT); String sDescription = (String)
					 * objectMap.get("ObjectDescription");
					 */
				 
				 String sId =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				 String sName =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				 String sRevision =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				 String sType =  validator.getStringEquivalentForStringList(objectMap.get("ObjectType"));
				 String sTitle =  validator.getStringEquivalentForStringList(objectMap.get("ObjectTitle"));
				 String sCurrent =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				 String sDescription =  validator.getStringEquivalentForStringList(objectMap.get("ObjectDescription"));

				 String sVersion =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ACTIVEVERSION));              
				 String sFiles =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_NAME));
				 String sFileName =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_NAME));
				 String sFilePath =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_CAPTURED));


				 formatData(sbId, sId);
				 formatData(sbType, sType);
				 //SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 10/03/2021 -- START
				 formatData(sbName, sName);
				 //SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 10/03/2021 -- END
				 formatData(sbTitle, sTitle);
				 formatData(sbRevision, sRevision);
				 formatData(sbState, sCurrent);
				 formatData(sbDescription, sDescription);
				 formatData(sbFiles, sFiles);
				 formatData(sbVersion, sVersion);
				 //SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- START
				 formatData(sbFileName, sFileName);
				 formatData(sbFilePath, sFilePath);
				 //SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- END
			 }
			 mpFiles.put(ConstantsUtil.ID, sbId.toString());
			 mpFiles.put(ConstantsUtil.TYPE, sbType.toString());
			 //SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 10/03/2021 -- START
			 mpFiles.put(ConstantsUtil.NAME, sbName.toString());
			 //SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 10/03/2021 -- END
			 mpFiles.put(ConstantsUtil.TITLE, sbTitle.toString());
			 mpFiles.put(ConstantsUtil.REVISION, sbRevision.toString());
			 mpFiles.put(ConstantsUtil.STATE, sbState.toString());
			 mpFiles.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			 mpFiles.put(ConstantsUtil.FILES, sbFiles.toString());
			 mpFiles.put(ConstantsUtilIRM.FILEVERSION, sbVersion.toString());
			 //SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- START
			 mpFiles.put(ConstantsUtil.FILESNAMES, sbFileName.toString());
			 mpFiles.put(ConstantsUtil.FILESPATH, sbFilePath.toString());
			 //SPEC: Release SR18x.6.0 - Modified for Defect 40903  by Dominic on Date 16/03/2021 -- END
		 } catch (Exception e) {
			 LOGGER.error("Unable to parseMaplistForFiles : Program POAARTBO " + e);
			 return new HashMap();
		 }
		 return util.filterMapList(mpFiles);
	 }
	 /**
		 * Method Name 			: getCaseCountValue
		 * Method Description 	: Getting Case Count Value
		 * @param context
		 * @param strPOAId
		 * @return String
		 */
	 public String getCaseCountValue(Context context,String strPOAId)throws Exception {

			String strCustomSpec = DomainConstants.EMPTY_STRING;
			String strIPMSId = DomainConstants.EMPTY_STRING;
			String strFPPData = DomainConstants.EMPTY_STRING;
			String strFPCCode = DomainConstants.EMPTY_STRING;
			String strCaseCount = DomainConstants.EMPTY_STRING;
			String strCaseCountValue = DomainConstants.EMPTY_STRING;
			String strFPPName = DomainConstants.EMPTY_STRING;
			StringList slSelectable = new StringList();
			slSelectable.addElement(DomainObject.SELECT_ID);
			StringList strFPPList= new StringList();
			StringList slConnectedFPPList= new StringList();
			StringBuilder sbCaseCount;
			DomainObject domFPP=null;
			StringList slCaseCount = new StringList();
			String strType = ConstantsUtil.TYPE_PGONLINEPRINTINGPART+","+ConstantsUtil.TYPE_PACKINGMATERIAL+","+ConstantsUtil.TYPE_PACKAGINGMATERIALPART;
			StringList slPOASelectable = new StringList();
			slPOASelectable.addElement("attribute["+ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE+"]");
			slPOASelectable.addElement("attribute["+ConstantsUtilIRM.ATTRIBUTE_CASECOUNT+"]");
			slPOASelectable.addElement("attribute["+ConstantsUtilIRM.ATTRIBUTE_CUSTOMIPMS+"]");
			if(validator.isNotNullOrEmpty(strPOAId)){
				DomainObject domPOA = DomainObject.newInstance(context,strPOAId);
				Map mpPOA = domPOA.getInfo(context,slPOASelectable);
				if(!mpPOA.isEmpty()){
					strCustomSpec = (String)mpPOA.get("attribute["+ConstantsUtilIRM.ATTRIBUTE_CUSTOMIPMS+"]");
					if(ConstantsUtilIRM.STR_CUSTOMSPEC.equalsIgnoreCase(strCustomSpec)){
						MapList mlIPMS = domPOA.getRelatedObjects(context,
																DomainConstants.RELATIONSHIP_PART_SPECIFICATION, //relationship
																strType, //Type Pattern
																slSelectable,  //objectSelects
																null, //relationshipSelects
																true, //getTo
																false, //getFrom
																(short)1, //recurseToLevel
																null, //objectWhere
																null);	//relationshipWhere
						if(mlIPMS.size()>0){
							Map mpIPMS = (Map)mlIPMS.get(0);
							strIPMSId = (String) mpIPMS.get(DomainObject.SELECT_ID);
							if(validator.isNotNullOrEmpty(strIPMSId)) {
								strFPPData 	= getFPPFromPMP(context,strIPMSId);
								if(validator.isNotNullOrEmpty(strFPPData))
								{
									strFPPList.addElement(strFPPData);
								}else{
												
									DomainObject domPackingMaterial = DomainObject.newInstance(context,strIPMSId);
									strFPPList = getAllConnectedFPCToIPMS(context,domPackingMaterial);
									}
							
								}
								if(!strFPPList.isEmpty()){
									for(int i=0;i<strFPPList.size();i++){
										strFPPName = (String)strFPPList.get(i);
										strCaseCountValue = getCaseCountFromFPP(context,strFPPName,domFPP);
									if(validator.isNotNullOrEmpty(strCaseCountValue))
										slCaseCount.addElement(strCaseCountValue);
									}
									//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43138 on Date 01/06/2021 --START
									strCaseCount = FrameworkUtil.join(slCaseCount, ConstantsUtil.SYMBL_COMMA);
									//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43138 on Date 01/06/2021 --END
								}else{
									strCaseCount = ConstantsUtilIRM.CASECOUNTKEY;
								}
							}
						//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43008 on Date 25/05/2021 --START
							else{
								strCaseCount = ConstantsUtilIRM.CASECOUNTKEY;			
							}
						/*}else{
							strCaseCount = ConstantsUtilIRM.CASECOUNTKEY;			
						}*/
							//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43138 on Date 01/06/2021 --START
							if(strCaseCount.contains(","))
							{
								strCaseCount = ConstantsUtilIRM.CASECOUNTKEY;			
							}
							//SPEC: Release SR18x.6.0.1 Commented by Dominic for Defect 43138 on Date 01/06/2021 --END
						}else{
							strCaseCount = (String)mpPOA.get("attribute["+ConstantsUtilIRM.ATTRIBUTE_CASECOUNT+"]");
						}
					}
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43008 on Date 25/05/2021 --END
				}
			return strCaseCount;
		}
	 /**
		 * Method Name 			: getAllConnectedFPCToIPMS
		 * Method Description 	: Getting FPC
		 * @param context
		 * @param doIPMSObject
		 * @return StringList
		 */
	public StringList getAllConnectedFPCToIPMS(Context context,DomainObject doIPMSObject) throws Exception{
		
		StringList finalList = new StringList();
		DomainObject doCOPObject =null;
		StringList slFPPList = new StringList();
		StringList slBOMList = new StringList();
		StringList slList1=null;
		String strCOPId = DomainConstants.EMPTY_STRING;
		String objectWhere ="previous.id!=''&&previous.current==Release";
		StringList slFPPList1 = new StringList();
		Pattern postTypePattern1 = new Pattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
		postTypePattern1.addPattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
	
	try{
		if(doIPMSObject != null){ 										
			StringList slList = new StringList(3);
			slList.addElement(DomainConstants.SELECT_ID);
			slList.addElement(DomainConstants.SELECT_NAME);
			slList.addElement(DomainConstants.SELECT_IS_LAST);
			Map postMap = new HashMap();
			postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");
			Pattern postTypePattern = new Pattern(ConstantsUtil.TYPE_FINISHEDPRODUCTPART);
			MapList mlFPP = doIPMSObject.getRelatedObjects(context,
															DomainConstants.RELATIONSHIP_EBOM,
															ConstantsUtil.TYPE_PRODUCTDATAPART,
															true, //getTo
															false, //getFrom
															(short)0,	// recursionLevel
															slList,	//objectSelects
															null, 	//relSelects
															null,// busWhereClause,
															null,// relWhereClause,
															null,// postRelPattern,
															postTypePattern.getPattern(),	//postTypePattern
															postMap);
			if(!mlFPP.isEmpty()) {
					slBOMList = validator.toStringList(mlFPP, DomainConstants.SELECT_NAME);
			
			StringList slqueryresult = doIPMSObject.getInfoList(context, "relationship["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].fromrel.from.id");
			int StrSize = slqueryresult.size();
			if(!(slqueryresult).isEmpty()){
				MapList mlFPP1 = null;
				for(int i=0;i<StrSize;i++){
					strCOPId= (String)slqueryresult.get(i);
					doCOPObject = DomainObject.newInstance(context,strCOPId);   					
					mlFPP1 = doCOPObject.getRelatedObjects(context,
															DomainConstants.RELATIONSHIP_EBOM,
															ConstantsUtil.TYPE_PRODUCTDATAPART,
															true, //getTo
															false, //getFrom
															(short)0,	// recursionLevel
															slList,	//objectSelects
															null, 	//relSelects
															null,// busWhereClause,
															null,// relWhereClause,
															null,// postRelPattern,
															postTypePattern.getPattern(),	//postTypePattern
															postMap);
					if(!mlFPP1.isEmpty()){
						slFPPList = validator.toStringList(mlFPP1, DomainConstants.SELECT_NAME);
					}
					finalList.addAll(slFPPList);
				}					
			} 
			MapList mlCOPIdList = doIPMSObject.getRelatedObjects(context,
																DomainConstants.RELATIONSHIP_EBOM,
																ConstantsUtil.TYPE_PRODUCTDATAPART,
																true, //getTo
																false, //getFrom
																(short)1,	//recursionLevel
																new StringList("previous.id"),	//objectSelects
																null, 	//relSelects
																objectWhere,// busWhereClause,
																null,// relWhereClause,
																null,// postRelPattern,
																postTypePattern1.getPattern(),	//postTypePattern
																null); 
	    	if(!mlCOPIdList.isEmpty()){
				for(int i=0;i<mlCOPIdList.size();i++){
					Map mpCOP = (Map)mlCOPIdList.get(i);
					String strPreviousCOPId = (String)mpCOP.get("previous.id");
					if(validator.isNotNullOrEmpty(strPreviousCOPId)){
						slFPPList1 = getFPPList(context, finalList, postTypePattern,slFPPList1, strPreviousCOPId);
						finalList.addAll(slFPPList1);
					}
				}
			}
			finalList.addAll(slBOMList);
			}
		}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	return finalList;
	}
	 /**
	 * Method Name 			: getCaseCountFromFPP
	 * Method Description 	: Getting FPC Case Count
	 * @param context
	 * @param strFPCName
	 * @param domFPP
	 * @return String
	 */
	public String getCaseCountFromFPP(Context context, String strFPCName,DomainObject domFPP) throws Exception 
	{
		String strCaseCount = DomainConstants.EMPTY_STRING;
		String strFPPId = DomainConstants.EMPTY_STRING;
		String strQuantity = DomainConstants.EMPTY_STRING;
		MapList mlFPPList =null;
		MapList mlCOPList =null;
		Map mTemp = null;
		String sBusWhere = "revision==last";
		Pattern postTypePattern = new Pattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
		postTypePattern.addPattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
		StringList slRelSelects = new StringList();
		slRelSelects.addElement("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"]");
		try{
			mlFPPList = DomainObject.findObjects(context,
												ConstantsUtil.TYPE_FINISHEDPRODUCTPART, // Type
												strFPCName,										// Name
												DomainConstants.QUERY_WILDCARD,					// Revision
												null,											// owner pattern
												ConstantsUtil.USER_VAULT,	// vault
												sBusWhere,										// bus where
												false,											// expand type
												new StringList(DomainConstants.SELECT_ID));		// bus select
			if(!mlFPPList.isEmpty()){
				mTemp = (Map)mlFPPList.get(0);
			}else{
				mlFPPList = DomainObject.findObjects(context,
													ConstantsUtil.TYPE_FINISHEDPRODUCTPART, // Type
													ConstantsUtilIRM.FPPKEY+strFPCName,							// Name
													DomainConstants.QUERY_WILDCARD,				    // Revision
													null,											// owner pattern
													ConstantsUtil.USER_VAULT, 	// vault
													sBusWhere,										// bus where
													false, 											// expand type		
													new StringList(DomainConstants.SELECT_ID)) ;	// bus select
				if(!mlFPPList.isEmpty()){
					mTemp = (Map)mlFPPList.get(0);
				}											
			}
			if(mTemp != null && !mTemp.isEmpty() ){
				strFPPId =(String)mTemp.get(DomainConstants.SELECT_ID);
				if(validator.isNotNullOrEmpty(strFPPId))
				{
					MapList mlBOMStructure = getPackingUnitWeightsAndDiamensionsData(context,strFPPId);
					if(mlBOMStructure != null && !mlBOMStructure.isEmpty()){
						StringList slQuantity = getNumberPerCustomerUnit(context,mlBOMStructure);
						strCaseCount = slQuantity.get(0);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return strCaseCount;
	}
	/**
	 * Method Name 			: getFPPFromPMP
	 * Method Description 	: Getting FPP from  PMP
	 * @param context
	 * @param strIPMSID
	 * @return String
	 */
	public String getFPPFromPMP(Context context, String strIPMSID) throws Exception {
	
		StringList finalList = new StringList();
		    String strMutlipleFPC=null;
		DomainObject doCOPObject =null;
		DomainObject doIPMSObject=null;
	    MapList mlFPP = null;
		MapList mlFPP1 = null;
		StringList slFPPList = new StringList();
		StringList slBOMList = new StringList();
		String strQuery=null;
		StringList slList1=null;
		StringList slqueryresult =null;
		String strCOPId = DomainConstants.EMPTY_STRING;
		Pattern postTypePattern = new Pattern(ConstantsUtil.TYPE_FINISHEDPRODUCTPART);
		 Map postMap = null;
		String strFPPValue = ConstantsUtil.EMPTY_STRING;
		StringList slCOPList = new StringList(1);
		String objectWhere ="previous.id!=''&&previous.current==Release";
		StringList slFPPList1 = new StringList();
		Pattern postTypePattern1 = new Pattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
		postTypePattern1.addPattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
		try {
		strFPPValue = validateOrchestrationFPC(context,strIPMSID);
		if(validator.isNotNullOrEmpty(strIPMSID) && !validator.isNotNullOrEmpty(strFPPValue)){
				strIPMSID = getPrimaryPMP(context,strIPMSID);
				doIPMSObject = DomainObject.newInstance(context,strIPMSID);   					
				StringList slList = new StringList(3);
				slList.addElement(DomainConstants.SELECT_ID);
				slList.addElement(DomainConstants.SELECT_NAME);
			   	slList.addElement(DomainConstants.SELECT_IS_LAST);
				postMap = new HashMap();
				postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");
				mlFPP = doIPMSObject.getRelatedObjects(context,
							DomainConstants.RELATIONSHIP_EBOM,
							ConstantsUtil.TYPE_PRODUCTDATAPART,
							true, //getTo
							false, //getFrom
							(short)0,	// recursionLevel
							slList,	//objectSelects
							null, 	//relSelects
							null,// busWhereClause,
							null,// relWhereClause,
							null,// postRelPattern,
							postTypePattern.getPattern(),	//postTypePattern
							postMap); 
					if(!mlFPP.isEmpty()) {
						slBOMList = validator.toStringList(mlFPP, DomainConstants.SELECT_NAME);
					}
			strQuery =  "relationship["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].fromrel.from.id";
			if(validator.isNotNullOrEmpty(strQuery)){
			 slqueryresult = doIPMSObject.getInfoList(context,strQuery);
			}
			int StrSize = slqueryresult.size();
		if(!(slqueryresult).isEmpty()){
			for (int i=0;i<StrSize;i++){
	        strCOPId= (String)slqueryresult.get(i);
		    doCOPObject = DomainObject.newInstance(context,strCOPId);   					
				slList1 = new StringList(3);
					slList1.addElement(DomainConstants.SELECT_ID);
				slList1.addElement(DomainConstants.SELECT_NAME);
				slList1.addElement(DomainConstants.SELECT_IS_LAST);
				postMap = new HashMap();
				postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");
				mlFPP1 = doCOPObject.getRelatedObjects(context,
							DomainConstants.RELATIONSHIP_EBOM,
							ConstantsUtil.TYPE_PRODUCTDATAPART,
							true, //getTo
							false, //getFrom
							(short)0,	// recursionLevel
							slList1,	//objectSelects
							null, 	//relSelects
							null,// busWhereClause,
							null,// relWhereClause,
							null,// postRelPattern,
							postTypePattern.getPattern(),	//postTypePattern
							postMap); //
				if(!mlFPP1.isEmpty()){
						slFPPList = validator.toStringList(mlFPP1, DomainConstants.SELECT_NAME);
					}
				finalList.addAll(slFPPList);
			}					
		}
			slCOPList.addElement("previous.id");
			MapList mlCOPIdList = doIPMSObject.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_EBOM,
					ConstantsUtil.TYPE_PRODUCTDATAPART,
					true, //getTo
					false, //getFrom
					(short)1,	//recursionLevel
					slCOPList,	//objectSelects
					null, 	//relSelects
					objectWhere,// busWhereClause,
					null,// relWhereClause,
					null,// postRelPattern,
					postTypePattern1.getPattern(),	//postTypePattern
					null); 
		    if(!mlCOPIdList.isEmpty())
		   	{
		   		for(int i=0;i<mlCOPIdList.size();i++)
		   		{
		   			Map mpCOP = (Map)mlCOPIdList.get(i);
		       		String strPreviousCOPId = (String)mpCOP.get("previous.id");
					if(validator.isNotNullOrEmpty(strPreviousCOPId)){
			    		slFPPList1 = getFPPList(context, finalList, postTypePattern,slFPPList1, strPreviousCOPId);
			    		finalList.addAll(slFPPList1);
					}
		   		}
			}
			finalList.addAll(slBOMList);
			if (!(finalList).isEmpty() && finalList.size()>1){
					 strMutlipleFPC="True";
			}
			else{
				strMutlipleFPC="False";
			}
	
		}
	   if(validator.isNotNullOrEmpty(strMutlipleFPC) && finalList.size()==1 && "False".equalsIgnoreCase(strMutlipleFPC)){
			strFPPValue =(String)finalList.get(0);
	   }
	 
		}catch(Exception ex)
		{
				ex.printStackTrace();
		}
		return strFPPValue;
	}
	/**
	 * Method Name 			: /**
	 * Method Name 			: getFPPFromPMP
	 * Method Description 	: Getting FPP List
	 * @param context
	 * @param strIPMSID
	 * @return StringList
	 */
	 
	public StringList getFPPList(Context context, StringList finalList,
			Pattern postTypePattern, StringList slFPPList1,	String strPreviousCOPId) throws FrameworkException {
		MapList mlFPP1 = null;
		Map postMap = null;
		DomainObject domPrevCOPObject;
		StringList slList2 = new StringList(3);
		try{
			if(validator.isNotNullOrEmpty(strPreviousCOPId)){
				domPrevCOPObject = DomainObject.newInstance(context,strPreviousCOPId);
			
				slList2.addElement(DomainConstants.SELECT_ID);
				slList2.addElement(DomainConstants.SELECT_NAME);
				slList2.addElement(DomainConstants.SELECT_IS_LAST);
				postMap = new HashMap();
				postMap.put(DomainConstants.SELECT_IS_LAST, "TRUE");
	
				mlFPP1 = domPrevCOPObject.getRelatedObjects(context,
						DomainConstants.RELATIONSHIP_EBOM,
						ConstantsUtil.TYPE_PRODUCTDATAPART,
						true, //getTo
						false, //getFrom
						(short)0,	// recursionLevel
						slList2,	//objectSelects
						null, 	//relSelects
						null,// busWhereClause,
						null,// relWhereClause,
						null,// postRelPattern,
						postTypePattern.getPattern(),	//postTypePattern
						postMap); 
				if(!mlFPP1.isEmpty()){
					slFPPList1 = validator.toStringList(mlFPP1, DomainConstants.SELECT_NAME);
				}
			}
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return slFPPList1;
	}
	/**
	 * Method Name 			: /**
	 * Method Name 			: getPackingUnitWeightsAndDiamensionsData
	 * Method Description 	: Getting Weighs and Diamensions
	 * @param context
	 * @param objectId
	 * @return MapList
	 */
	public MapList getPackingUnitWeightsAndDiamensionsData(Context context, String objectId) throws Exception 
	
	{
	
		MapList tempList = new MapList();
		
		MapList objList = null;
		MapList finalBomList = new MapList();
		String sLevelPrev = "0";
	
		String sLevelNext = "0";
	
		try{
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add(DomainConstants.SELECT_TYPE);
			busSelects.add(DomainConstants.SELECT_ID);
			StringList relSelects = new StringList();
			relSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
	
	        relSelects.add(DomainObject.SELECT_ATTRIBUTE_QUANTITY);
	
			String typePattern =  ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART+","+ConstantsUtil.TYPE_PGCONSUMERUNITPART;
			String relPattern = DomainConstants.RELATIONSHIP_EBOM;
	
			DomainObject domObject = DomainObject.newInstance(context, objectId);
	
			objList = domObject.getRelatedObjects(
					context, 
					relPattern,
					typePattern, 
					busSelects, 
					relSelects, 
					false, 
					true, 
					(short) 0,
					null, 
					null, 
					0);		
		String	strObjectType = null;
		
		String strLevel = null;
		
		String strCOPId = null;
		
		StringList listCOPLevel=new StringList();
		
		StringList listCOPDetails=new StringList();
		
		StringList COPIgnoreList=new StringList();
		
		MapList listFinalCharacteristics = new MapList();
			
		if(!objList.isEmpty())
		{
			Iterator listCharacteristicsIterator = objList.iterator();
	
			while (listCharacteristicsIterator.hasNext())
	
			{
				Map    listCharacteristicsMap = (Map) listCharacteristicsIterator.next();
	
				strObjectType=(String)listCharacteristicsMap.get(DomainConstants.SELECT_TYPE);
				if(strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNITPART))
				{
					strLevel=(String)listCharacteristicsMap.get(DomainConstants.SELECT_LEVEL);
					strCOPId=(String)listCharacteristicsMap.get(DomainConstants.SELECT_ID);
					
					listCOPLevel.add(strLevel);
					listCOPDetails.add(strLevel+"-"+strCOPId);
					
				}
			}
			if(listCOPLevel.isEmpty())
			{
				return objList;
			}
			listCOPLevel.sort();
			
			String strFirstLevel = (String)listCOPLevel.get(0);
			
			for(int i=0;i<listCOPDetails.size();i++)
	
			{
	
				String strCOPDetails=(String)listCOPDetails.get(i);
				
				String[] COPDetails = strCOPDetails.split("-");
				
				if(!strFirstLevel.equals(COPDetails[0]))
				{
					COPIgnoreList.add(COPDetails[1]);
				}
	
			}
			
			Iterator listRemoveCharacteristicsIterator = objList.iterator();
	
			while (listRemoveCharacteristicsIterator.hasNext())
	
			{
	
				Map    listRemoveCharacteristicsMap = (Map) listRemoveCharacteristicsIterator.next();
				
				if(!COPIgnoreList.contains((String)listRemoveCharacteristicsMap.get(DomainConstants.SELECT_ID)))
				{
					listFinalCharacteristics.add(listRemoveCharacteristicsMap);
				}
				
				
			}
		}
	
		if(listFinalCharacteristics.size()>0)
		{
			Iterator objItr=listFinalCharacteristics.iterator();
	
			while(objItr.hasNext())
	
			{
	
				Map objMap = (Map) objItr.next();
	
				Map objects = new HashMap();
	
				objects.put(DomainConstants.SELECT_NAME, (String)objMap.get(DomainConstants.SELECT_NAME));
	
				objects.put("relationship", (String)objMap.get("relationship"));
	
				objects.put("level", (String)objMap.get("level"));
	
				objects.put(DomainConstants.SELECT_ID, (String)objMap.get(DomainConstants.SELECT_ID));
		
				objects.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)objMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
	
				objects.put(DomainConstants.SELECT_TYPE, (String)objMap.get(DomainConstants.SELECT_TYPE));
	
	            objects.put(DomainConstants.SELECT_ATTRIBUTE_QUANTITY, (String)objMap.get(DomainConstants.SELECT_ATTRIBUTE_QUANTITY));
				 
				finalBomList.add(objects);
	
			}
	
		}
	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return finalBomList;
	}
	/**
	 * Method Name 			: /**
	 * Method Name 			: getNumberPerCustomerUnit
	 * Method Description 	: Getting Number Per Customer Unit
	 * @param context
	 * @param objectId
	 * @return MapList
	 */
	public StringList getNumberPerCustomerUnit(Context context, MapList mlObjectList) throws Exception
	
	{
	
	    String sReturn = "";
	
	    StringList slReturnVal = new StringList();
	
	    String sObjectId = "";
	
	    String strLevel ="";
	
	    String strQuantity="";
	
	    String strType="";
	
	    String iPrevious="";
	
	    Double dQuantity=0.0;
	
	    boolean ipLevel2= false;
	
	    boolean cupLevel1=false;
	
	    try
	
	    {
	        mlObjectList.sort("level", "ascending", "integer");
	
	        Iterator objListItr = mlObjectList.iterator();
	
	        while (objListItr.hasNext())
	
	        {
	
	            Map perMap = (Map) objListItr.next();
	
	            strType=(String)perMap.get(DomainConstants.SELECT_TYPE);
	
	            sObjectId = (String)perMap.get(DomainConstants.SELECT_ID);
	
	            strLevel=(String)perMap.get(ConstantsUtil.SELECT_LEVEL);
	
	            strQuantity=(String)perMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
	        	
	            DomainObject bomObject = DomainObject.newInstance(context,sObjectId);
	
	            if(UIUtil.isNullOrEmpty(strType) || UIUtil.isNullOrEmpty(strLevel) || UIUtil.isNullOrEmpty(strQuantity) ||  mlObjectList.size()==1)
	
	            {
	
	                slReturnVal.addElement("");
	
	            }
	
	            else
	
	            {
	
	                if(strType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART) && "1".equals(strLevel))
	
	                {
	
	                     cupLevel1=true;
	
	                }
	
	                else if(strType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) && "2".equals(strLevel) && cupLevel1)
	
	                {
	
	                    slReturnVal.addElement(strQuantity);
	
	                    slReturnVal.addElement("");
	
	                    cupLevel1=false;
	
	                }
	
	                else if(strType.equals(ConstantsUtil.TYPE_PGINNERPACKUNITPART) && "2".equals(strLevel) && cupLevel1)
	                {
	                    iPrevious=strQuantity;
	                    ipLevel2=true;
				        slReturnVal.addElement("");
				        slReturnVal.addElement("");
	                }
	                else if(strType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) && "3".equals(strLevel) && ipLevel2)
	                {
	                    dQuantity=Double.parseDouble(iPrevious) * Double.parseDouble(strQuantity);
	                    slReturnVal.removeAllElements();
	                    slReturnVal.addElement(Double.toString(dQuantity));
	                    slReturnVal.addElement(strQuantity);
	                    slReturnVal.addElement("");
	                    ipLevel2=false;
	                }
	                else
	                {
	                    slReturnVal.addElement("");
	                }
	            }
	        }
	    } catch(Exception e){
	        e.printStackTrace();
	    }
	    return slReturnVal;
	}
	/**
	 * Method Name 			: /**
	 * Method Name 			: validateOrchestrationFPC
	 * Method Description 	: Validate FPC
	 * @param context
	 * @param strIPMSID
	 * @return String
	 */
	public String validateOrchestrationFPC(Context context, String strIPMSID)throws Exception {
		
		String strFPPName = DomainConstants.EMPTY_STRING;
		try{
		if(validator.isNotNullOrEmpty(strIPMSID)) {
		    DomainObject dobPMP = DomainObject.newInstance(context,strIPMSID);  
		    StringList objectSelects = new StringList(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_NAME);
			StringList relSelects = new StringList();
		    MapList mPOADetails = dobPMP.getRelatedObjects(context, //ematrix context
		            ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION, //String relationship
		            ConstantsUtil.TYPE_POA, //String type
		            objectSelects, //Stringlist Object selects
		            relSelects,//Stringlist Relationship selects
		            false, //boolean getTo
		            true, //boolean getFrom
		            (short)1, //int Recurse to level
		            DomainConstants.EMPTY_STRING, // String objectWhere
		            DomainConstants.EMPTY_STRING,// String relationshipWhere
		            0, //int limit
		            null,// String postRelPattern
		            null,// String postTypePatter
		            null);// Map postPatterns
	   
		    if(!(mPOADetails).isEmpty()){
		    	String sPOAId = validator.getString((Map) mPOADetails.get(0),DomainConstants.SELECT_ID);
		    	DomainObject dPOA = DomainObject.newInstance(context,sPOAId);
				StringList selectsData = new StringList();
				selectsData.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE);
				selectsData.add(DomainConstants.SELECT_ORIGINATOR);
				Map dataMap = dPOA.getInfo(context, selectsData);
		    	String sFPCVal = (String)dataMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE);
		    	String sOriginator = (String)dataMap.get(DomainConstants.SELECT_ORIGINATOR);
		    	
		    	if(validator.isNotNullOrEmpty(sFPCVal)) {
		    		sFPCVal = sFPCVal.replace("CS:", "");
		    		sFPCVal = sFPCVal.replace("IT:", "");
		    		sFPCVal = sFPCVal.replace("SW:", "");
					sFPCVal = sFPCVal.replace("NGTIN:", "");
					StringList sFPCList = com.matrixone.apps.domain.util.StringUtil.splitString(sFPCVal, "|");
		    		for(int i=0;i<sFPCList.size();i++) {
		    			strFPPName = sFPCList.get(i);
		    			if(validator.isNotNullOrEmpty(strFPPName)) {
		    				break;
		    			}
		    		}
		    	}
		    }
		}
		} catch(Exception e){
			throw e;			
		}

	return strFPPName;
	}
	/**
	 * Method Name 			: /**
	 * Method Name 			: getPrimaryPMP
	 * Method Description 	: Get Primary PMP
	 * @param context
	 * @param strPMPId
	 * @return String
	 */
	public String getPrimaryPMP(Context context, String strPMPId)throws FrameworkException  {
		String strPriPMPId = strPMPId;
		
		if(validator.isNotNullOrEmpty(strPMPId)){
			DomainObject doPMPObject	= DomainObject.newInstance(context,strPMPId);
			String strType = doPMPObject.getInfo(context,DomainConstants.SELECT_TYPE);
			
			if(ConstantsUtil.TYPE_PGONLINEPRINTINGPART.equals(strType) || ConstantsUtil.TYPE_PACKAGINGMATERIALPART.equals(strType))
				{
				StringList slPriPMP = doPMPObject.getInfoList(context,"to["+ConstantsUtil.RELATIONSHIP_ALTERNATE+"].from.id");
						
				if(null != slPriPMP && !slPriPMP.isEmpty()) {
					strPriPMPId = (String)slPriPMP.get(0);
				}
			}
		
		}
		return strPriPMPId;
	}
	//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 04/03/2021 -- END

	/**
	 * Method Name 			: getPartsAssociated
	 * Method Description 	: Getting POA Associated Parts
	 * @param context
	 * @param domPOA
	 * @return Maplist
	 */
	public Map getPartsAssociated(Context context,DomainObject domPOA) throws Exception {
		Map<String, String> mpPartsAssociated = new HashMap<String, String>();
		boolean isExternal=util.isModificatinRequired();
		boolean showData = false;
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String sUserType = util.getUserType();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbPrimOrg = new StringBuilder();
		StringBuilder sbOwner = new StringBuilder ();
		StringBuilder sbOriginated = new StringBuilder ();
		StringBuilder sbModified= new StringBuilder ();
		StringBuilder sbDescription = new StringBuilder ();
		StringList busSelects = new StringList(1);
		busSelects.add(ConstantsUtil.SELECT_ID);
		busSelects.add(ConstantsUtil.SELECT_NAME);
		busSelects.add(ConstantsUtil.SELECT_TYPE);
		busSelects.add(ConstantsUtil.SELECT_REVISION);
		busSelects.add(ConstantsUtil.SELECT_CURRENT);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelects.add(ConstantsUtil.OWNER);
		busSelects.add(ConstantsUtil.ORIGINATED);
		busSelects.add(ConstantsUtil.MODIFIED);
		busSelects.add(ConstantsUtil.DESCRIPTION);
		if(null!=domPOA){
			MapList mapList;
			Map resultMapIPMS=new HashMap();
			mapList = domPOA.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION,
						ConstantsUtil.SYMBL_ASTERISK,
						busSelects, //objectSelects,
						null,// relationshipSelects,
						true,// getTo,
						false,// getFrom,
						(short)1, // recursionLevel,
						ConstantsUtilIRM.CURRENT_RELEASE,// busWhereClause,
						ConstantsUtil.EMPTY_STRING,// relWhereClause,
						ConstantsUtil.ZERO_LEVEL);
			if(mapList != null && mapList.size() > 0) {
				String strSST = "";
				for(Iterator mpListItr = mapList.iterator(); mpListItr.hasNext();) {
					resultMapIPMS = (Map) mpListItr.next();
					String strId=validator.getStringEquivalentForStringList(resultMapIPMS.get(ConstantsUtil.SELECT_ID));
					showData = util.checkHasAccess(context, sUserType, strId);
					
					//Added by Pooja for 22x Defect 50464 -- START
					if(isExternal && !showData)
						continue;
					
					if (!showData) {
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
					}
					else {
						util.formatData(sbId,strId);
					}
					//Added by Pooja for 22x Defect 50464 -- END
					util.formatData(sbName,validator.getStringEquivalentForStringList(resultMapIPMS.get(ConstantsUtil.SELECT_NAME)));
					String strType=(String)validator.getStringEquivalentForStringList(resultMapIPMS.get(ConstantsUtil.SELECT_TYPE));
					util.formatData(sbType,util.mapType(strType));
					util.formatData(sbState,validator.getStringEquivalentForStringList(resultMapIPMS.get(ConstantsUtil.SELECT_CURRENT)));
					util.formatData(sbRev,validator.getStringEquivalentForStringList(resultMapIPMS.get(ConstantsUtil.SELECT_REVISION)));
					util.formatData(sbTitle,validator.isNotNullOrEmpty((String)resultMapIPMS.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))?(String)resultMapIPMS.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
					strSST = util.UpdateSpecSubType(context, strId);
					util.formatData(sbSubType,validator.isNotNullOrEmpty(strSST)?strSST:ConstantsUtil.EMPTY_STRING);
					util.formatData(sbPrimOrg,validator.isNotNullOrEmpty((String)resultMapIPMS.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME))?(String)resultMapIPMS.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					util.formatData(sbOwner,PersonUtil.getFullName(context,validator.isNotNullOrEmpty((String)resultMapIPMS.get(ConstantsUtil.OWNER))?(String)resultMapIPMS.get(ConstantsUtil.OWNER) : ConstantsUtil.EMPTY_STRING));
					util.formatData(sbOriginated,validator.DateFormatterParse(validator.isNotNullOrEmpty((String)resultMapIPMS.get(ConstantsUtil.ORIGINATED))?(String)resultMapIPMS.get(ConstantsUtil.ORIGINATED) : ConstantsUtil.EMPTY_STRING));
					util.formatData(sbModified,validator.DateFormatterParse(validator.isNotNullOrEmpty((String)resultMapIPMS.get(ConstantsUtil.MODIFIED))?(String)resultMapIPMS.get(ConstantsUtil.MODIFIED) : ConstantsUtil.EMPTY_STRING));
					util.formatData(sbDescription,validator.isNotNullOrEmpty((String)resultMapIPMS.get(ConstantsUtil.DESCRIPTION))?(String)resultMapIPMS.get(ConstantsUtil.DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				}			
			}
			mpPartsAssociated.put(ConstantsUtil.ID, sbId.toString());
			mpPartsAssociated.put(ConstantsUtil.NAME,sbName.toString());
			mpPartsAssociated.put(ConstantsUtil.TYPE, sbType.toString());
			mpPartsAssociated.put(ConstantsUtil.REVISION, sbRev.toString());
			mpPartsAssociated.put(ConstantsUtil.STATE, sbState.toString());
			mpPartsAssociated.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpPartsAssociated.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpPartsAssociated.put(ConstantsUtil.PRIMARYORGANIZATION, sbPrimOrg.toString());
			mpPartsAssociated.put(ConstantsUtil.OWNER, sbOwner.toString());
			mpPartsAssociated.put(ConstantsUtil.ORIGINATED, sbOriginated.toString());
			mpPartsAssociated.put(ConstantsUtil.MODIFIED, sbModified.toString());
			mpPartsAssociated.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
		}			
		return mpPartsAssociated;
	}
	
	//SPEC: Release SR18x.6. Modified by Dominic for Defect 42039 on Date 01/04/2021 --START
	/**
	 * Method Name 			: getPOAPrinterData
	 * Method Description 	: Getting POA  Printer
	 * @param context
	 * @param strCustomIPMS
	 * * @param strIPMS
	 * @return String
	 */
	public String getPOAPrinterData(Context context, String strCustomIPMS, String strIPMS) throws Exception {
		
		DomainObject domPackingMaterial = DomainObject.newInstance(context);
		String strIPMSId = null;
		String strSupplierName = "";
		String strRevisionPattern = "*";
		String strIPMSName = "";
		String strIPMSType = "";
		if(ConstantsUtilIRM.STR_CUSTOMSPEC.equals(strCustomIPMS)) {
			StringList slIPMS = FrameworkUtil.split(strIPMS,".");    
			if(slIPMS.size() > 2) {
				if(slIPMS.size() > 3) {
					strRevisionPattern = (String)slIPMS.get(2);
					strIPMSName = (String)slIPMS.get(1);
					strIPMSType = (String)slIPMS.get(0);
				} else if(slIPMS.size() == 3){
					strRevisionPattern = (String)slIPMS.get(2);
					strIPMSName = (String)slIPMS.get(1);
					strIPMSType = ConstantsUtil.TYPE_PGPACKINGMATERIAL;
				}
			}
			StringBuffer sbWhereCond = new StringBuffer(4);
			sbWhereCond.append("(");
			sbWhereCond.append(DomainObject.SELECT_CURRENT);
			sbWhereCond.append("==");
			sbWhereCond.append(ConstantsUtil.STATE_RELEASE);
			sbWhereCond.append("&& next.current != Release ) || revision == last");
			MapList mlIPMS = DomainObject.findObjects(context,  strIPMSType, strIPMSName, strRevisionPattern, "*", ConstantsUtil.VAULT_ESERVICEPRODUCTION, sbWhereCond.toString(), false, new StringList(DomainObject.SELECT_ID));
			if(mlIPMS.size() > 0) {
				Map mIPMS = (Map) mlIPMS.get(0);
				strIPMSId = (String)mIPMS.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strIPMSId)){
					domPackingMaterial.setId(strIPMSId);
					strSupplierName = getPrinterName(context, domPackingMaterial);
				}
			}
		} 
		return strSupplierName;
	}
	/**
	 * Method Name 			: getPrinterName
	 * Method Description 	: Getting POA  Printer
	 * @param context
	 * @param domPackingMaterial
	 * @return String
	 */
	public String getPrinterName(Context context,DomainObject domPackingMaterial) throws Exception {

		MapList mlPrinterUniqueList = new MapList();
		StringList busSelects = new StringList(4);
		String strManufacturingPlantRel     = ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY;
		String strManufacturerEquivalentRel = ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT;
		String strApprovedSupplierListRel   = ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		String strApprovedSupplierListRowRel= ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLISTROW;
		String strSupplyResponsibilityRel   = ConstantsUtil.RELATIONSHIP_SUPPLYRESPONSIBILITY;
		String strSupplierEquivalentRel 	= ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT;
		String strApprovedSupplierListType  =ConstantsUtil. TYPE_PGAPPROVEDSUPPLIERLIST;
		busSelects.addElement(DomainConstants.SELECT_NAME);
		busSelects.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_ADDRESS);
		busSelects.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_CITY);
		busSelects.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_COUNTRY);		
		String str_Add				= null;
		String str_City				= null;
		String str_Country			= null;
		String strSupplierName  = null;
		MapList mlSuppliersList = null;
		Map mpSupplier = null;
		MapList mlASLPrinters = null;
		StringBuilder strPrinterDetails = new StringBuilder();
		try{
			if(null!=domPackingMaterial){
				StringList slBusSelect = new StringList(3);
				slBusSelect.add(DomainConstants.SELECT_TYPE);
				slBusSelect.add(DomainConstants.SELECT_ID);
				Map mIPMSInfo = domPackingMaterial.getInfo(context,slBusSelect);
				if(!mIPMSInfo.isEmpty()) {
					String sObjectType = (String)mIPMSInfo.get(DomainConstants.SELECT_TYPE);
					if(ConstantsUtil.TYPE_PGONLINEPRINTINGPART.equals(sObjectType)){
						String strTempFPC = null;
						MapList mlFPPList,mlConnectedPlants =null;
						Map mTemp = null;
						DomainObject domObjFPC = null;
						StringList slFPPList = new StringList();
						String sBusWhere = "revision==last";
						String sSelectForPlant = "to[" + ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY +"].from.name";
						String sFPCCode = getFPPFromPMP(context,domPackingMaterial.getId());
						if(validator.isNotNullOrEmpty(sFPCCode)){
							slFPPList.add(sFPCCode);
						}
						else{
							slBusSelect.add("to["+ConstantsUtilIRM.RELATIONSHIP_PGAAA_PROJECTTOPOA+"].from["+DomainObject.TYPE_PROJECT_SPACE+"].id");
							slBusSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE);
							MapList mlPOA = domPackingMaterial.getRelatedObjects(context, 							 // context
																		DomainObject.RELATIONSHIP_PART_SPECIFICATION, // rel pattern
																		ConstantsUtil.tPOA,					  // type pattern
																		slBusSelect,								 // bus select
																		null,										 // rel select
																		false,										// getTo
																		true,										// getFrom
																		(short)1,									// recurse level
																		sBusWhere,									// bus where
																		null);										// rel where
							if(!mlPOA.isEmpty()){
								Map mPOA = (Map)mlPOA.get(0);
								String sProjectId = (String)mPOA.get("to["+ConstantsUtilIRM.RELATIONSHIP_PGAAA_PROJECTTOPOA+"].from["+DomainObject.TYPE_PROJECT_SPACE+"].id");
								sFPCCode = (String)mPOA.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE);
								if (validator.isNotNullOrEmpty(sProjectId)){
									if (validator.isNotNullOrEmpty(sFPCCode)){
		
										slFPPList =getFPCName(context,sFPCCode);
									}
								}else{ 
									slFPPList = getAllConnectedFPCToIPMS(context,domPackingMaterial);
								}
							}
						}
						if(!slFPPList.isEmpty()){
						int iSize = slFPPList.size();
						int itotalPlant;
						Map mPlantTemp = null;
						StringList slListOfPlants = new StringList();
						String sPlantName =DomainConstants.EMPTY_STRING;
							for (int i=0;i<iSize;i++){
								strTempFPC = (String)slFPPList.get(i);
								mlFPPList = DomainObject.findObjects(context,											// context
																	ConstantsUtil.TYPE_FINISHEDPRODUCTPART, // Type
																	strTempFPC, 									   // Name
																	DomainConstants.QUERY_WILDCARD,					   // revison
																	null,												// owner pattern
																	ConstantsUtil.VAULT_ESERVICEPRODUCTION, 		// vault
																	sBusWhere,											// bus where
																	false, 												// expand type
																	new StringList(DomainConstants.SELECT_ID));			// bus select
								if(!mlFPPList.isEmpty()){
									mTemp = (Map)mlFPPList.get(0);
								}else{
									mlFPPList = DomainObject.findObjects(context,										   // context
													ConstantsUtil.TYPE_FINISHEDPRODUCTPART, // Type
													ConstantsUtilIRM.FPPKEY+strTempFPC,								// Name
																		DomainConstants.QUERY_WILDCARD,						// revison
																		null,												// owner pattern
																		ConstantsUtil.VAULT_ESERVICEPRODUCTION, 		// vault
																		sBusWhere,											// bus where
																		false, 												// expand type
																		new StringList(DomainConstants.SELECT_ID)) ;		// bus select
									if(!mlFPPList.isEmpty()){
										mTemp = (Map)mlFPPList.get(0);
									}											
								}
								if(!mTemp.isEmpty()){
									domObjFPC = DomainObject.newInstance(context,(String)mTemp.get(DomainConstants.SELECT_ID));
									if(domObjFPC != null){
										 mlConnectedPlants = domObjFPC.getRelatedObjects(context, 
																						ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY, // Rel pattern
																						ConstantsUtil.TYPE_PLANT, 								// Type pattern
																						new StringList(DomainConstants.SELECT_NAME), 			// bus select
																						null, 													// rel select
																						true, 													// getTo
																						false, 													// getFrom
																						(short)1, 												// recurse level
																						null, 													// bus where
																						DomainConstants.EMPTY_STRING, 							// rel where
																						0);														// limit
										if(!mlConnectedPlants.isEmpty()){
											itotalPlant =mlConnectedPlants.size();
											for(int j=0;j<itotalPlant;j++){
												mPlantTemp = (Map)mlConnectedPlants.get(j);
												sPlantName = (String)mPlantTemp.get(DomainConstants.SELECT_NAME);
												if(!slListOfPlants.contains(sPlantName))
													slListOfPlants.add(sPlantName);
											}
										}
									}
								}
							}
							strPrinterDetails.append(FrameworkUtil.join(slListOfPlants,","));
						}			
					}else{
						StringBuilder relPatternPrinterMEPWithArtwork = new StringBuilder(strManufacturerEquivalentRel).append(",").append(strSupplierEquivalentRel);
						StringBuilder relPatternPrinterMEPRespWithArtwork = new StringBuilder(strManufacturingPlantRel).append(",").append(strSupplyResponsibilityRel);
						StringBuilder relPatternPrinterASL = new StringBuilder(strApprovedSupplierListRel).append(",").append( strApprovedSupplierListRowRel).append(",").append(strSupplyResponsibilityRel);
						StringBuilder relPatternPrinterMEPWOArtwork = new StringBuilder(strManufacturerEquivalentRel).append(",").append(strManufacturingPlantRel);
						relPatternPrinterMEPWOArtwork.append(",").append(strSupplierEquivalentRel).append(",").append(strSupplyResponsibilityRel);
						String strAllowedTypes = ConstantsUtil.TYPE_PGONLINEPRINTINGPART+","+ConstantsUtil.TYPE_PACKINGMATERIAL+","+ConstantsUtil.TYPE_PACKAGINGMATERIALPART;
						StringBuilder typePatternPrinter = new StringBuilder(strAllowedTypes).append(",").append(ConstantsUtil.TYPE_PGSUPPLIER).append(",").append(DomainConstants.TYPE_COMPANY);
						StringBuilder typePatternPrinterASL = new StringBuilder(strApprovedSupplierListType).append(",").append(ConstantsUtil.TYPE_PGMANUFACTURERMATERIAL).append(",").append(ConstantsUtil.TYPE_PGSUPPLIER).append(",").append(DomainConstants.TYPE_COMPANY);		
						StringBuilder postTypePatternPrinter = new StringBuilder(ConstantsUtil.TYPE_PGSUPPLIER+","+DomainConstants.TYPE_COMPANY);	
						String strWhereClause = "current !=Obsolete";						
						StringBuilder sbRelWhereClause = new StringBuilder("attribute[").append(ConstantsUtil.ATTR_PG_ARTWORK_PRIMARY).append("]==TRUE");
						MapList mlMEPList = null;
						DomainObject doMEP	= null;
						Map mpMEP = null;
						String strMEPID =  null;
						mlMEPList = domPackingMaterial.getRelatedObjects(context,
							relPatternPrinterMEPWithArtwork.toString(),
							strAllowedTypes,
							false,// getTo,
							true,// getFrom,
							(short)1, // recursionLevel,
							new StringList(DomainConstants.SELECT_ID), //objectSelects,
							null,// relationshipSelects,
							strWhereClause,// busWhereClause,
							sbRelWhereClause.toString(),// relWhereClause,
							null,// postRelPattern,
							null,//postTypePattern,
							null ); //postPatterns
					if(mlMEPList != null && mlMEPList.size() > 0) {
						for(Iterator mepListItr = mlMEPList.iterator(); mepListItr.hasNext();) {
							mpMEP = (Map) mepListItr.next();
							strMEPID =  (String)mpMEP.get(DomainConstants.SELECT_ID);
							doMEP = DomainObject.newInstance(context,strMEPID);
							mlSuppliersList = doMEP.getRelatedObjects(context,
									relPatternPrinterMEPRespWithArtwork.toString(),
									postTypePatternPrinter.toString(),
									true,// getTo,
									false,// getFrom,
									(short)1, // recursionLevel,
									busSelects, //objectSelects,
									null,// relationshipSelects,
									strWhereClause,// busWhereClause,
									null,// relWhereClause,
									null,// postRelPattern,
									postTypePatternPrinter.toString(),//postTypePattern,
									null ); //postPatterns					
						}
					}
					if(mlSuppliersList == null) {
						mlSuppliersList = domPackingMaterial.getRelatedObjects(context,
								relPatternPrinterMEPWOArtwork.toString(),
								typePatternPrinter.toString(),
								true,// getTo,
								true,// getFrom,
								(short)2, // recursionLevel,
								busSelects, //objectSelects,
								null,// relationshipSelects,
								strWhereClause,// busWhereClause,
								null,// relWhereClause,
								null,// postRelPattern,
								postTypePatternPrinter.toString(),//postTypePattern,
								null ); //postPatterns
					}
					
					if(mlSuppliersList == null || (mlSuppliersList != null && mlSuppliersList.size() == 0)) {
						mlASLPrinters = domPackingMaterial.getRelatedObjects(context,
								relPatternPrinterASL.toString(),
								typePatternPrinterASL.toString(),
								true,// getTo,
								true,// getFrom,
								(short)3, // recursionLevel,
								busSelects, //objectSelects,
								null,// relationshipSelects,
								strWhereClause,// busWhereClause,
								null,// relWhereClause,
								null,// postRelPattern,
								postTypePatternPrinter.toString(), //postTypePattern,
								null ); //postPatterns
					}
					if(mlASLPrinters != null && mlASLPrinters.size() > 0) {
						for(Iterator supplierMapListIterator = mlASLPrinters.iterator(); supplierMapListIterator.hasNext();) {
							mpSupplier = (Map) supplierMapListIterator.next();
							mlSuppliersList.add(mpSupplier);
						}
					}

				if(mlSuppliersList != null && mlSuppliersList.size() > 0) {
					for(Iterator supplierMapListIterator = mlSuppliersList.iterator(); supplierMapListIterator.hasNext();) {
						mpSupplier = (Map) supplierMapListIterator.next();
						strSupplierName =  (String)mpSupplier.get(DomainConstants.SELECT_NAME);

						str_Add = (String)mpSupplier.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ADDRESS);

						str_City = (String)mpSupplier.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CITY);

						str_Country = (String)mpSupplier.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COUNTRY);

						if(!mlPrinterUniqueList.contains(strSupplierName)){
							if(strPrinterDetails.length()==0){

								strPrinterDetails.append(strSupplierName).append("~").append(str_Add).append("~").append(str_City).append("~").append(str_Country);
							}
							else{

									strPrinterDetails = strPrinterDetails.append(", ").append(strSupplierName).append("~").append(str_Add).append("~").append(str_City).append("~").append(str_Country);
								}
								 mlPrinterUniqueList.add(strSupplierName);
							}
						}
					}
				}
				}
					
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strPrinterDetails.toString();
	}
	public StringList getFPCName(Context context,String strFPCCode) throws FrameworkException {
		String strFPCInfo = null;
		String strFPCInfoDetails = null;
		StringList strFPPList= new StringList();
		StringList slFPCList = new StringList();
		StringList slFPCListDetails = new StringList();
		try{
				if(validator.isNotNullOrEmpty(strFPCCode)) {
					slFPCList = FrameworkUtil.split(strFPCCode, "|");
					for(int i=0;i<slFPCList.size();i++){
						strFPCInfoDetails = (String)slFPCList.get(i);
						slFPCListDetails = FrameworkUtil.split(strFPCInfoDetails, ",");
						for(int j=0;j<slFPCListDetails.size();j++){
							strFPCInfo = (String)slFPCListDetails.get(j);
							strFPCInfo = strFPCInfo.substring(strFPCInfo.indexOf(":")+1, strFPCInfo.length());
							if(validator.isNotNullOrEmpty(strFPCInfo)&& !strFPPList.contains(strFPCInfo)) {
								strFPPList.addElement(strFPCInfo);
							}
						}
					}
				}
					
		}catch(Exception ex){
			throw new FrameworkException(ex);
		}
		return strFPPList;
	}
	/**
	 * This method populates the Packaging Material Type for POA Properties
	 * @param Context object which have logged in user info
	 * @param String array containing input parameters
	 */
	public String getPackagingMaterialType(Context context,String strPOAId) throws Exception {
		String strPackingMaterialType = null;
		try{
			if(validator.isNotNullOrEmpty(strPOAId)){
				DomainObject domPOA = DomainObject.newInstance(context,strPOAId);
				String strIPMSAttribute = domPOA.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_IPMS);
				String strCustomIPMSAttribute = domPOA.getAttributeValue(context, ConstantsUtilIRM.ATTRIBUTE_CUSTOMIPMS);
				StringList slSelectable = new StringList();
				slSelectable.addElement(DomainObject.SELECT_ID);
				String strType = ConstantsUtil.TYPE_PGPACKINGMATERIAL;
				MapList mlIPMS = domPOA.getRelatedObjects(context,DomainConstants.RELATIONSHIP_PART_SPECIFICATION, strType,slSelectable,null, false, true, (short)1, null, null);
					
				if(mlIPMS.size()>0){
					for(int k=0; k<mlIPMS.size(); k++){
						Map mpIPMS = (Map)mlIPMS.get(0);
						String strIPMSId = (String) mpIPMS.get(DomainObject.SELECT_ID);
						DomainObject domIPMS = DomainObject.newInstance(context,strIPMSId);
						String PackagingMaterialType = domIPMS.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
						strPackingMaterialType = PackagingMaterialType;
					}
				} else {
					if(("No".equalsIgnoreCase(strCustomIPMSAttribute)) && (!"".equalsIgnoreCase(strIPMSAttribute))){
							StringList slSelectables = new StringList(2);
							slSelectables.addElement(DomainObject.SELECT_ID);
							slSelectables.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
							String strRevisionPattern = "*";
							String strIPMSType = "";
							String strIPMSName = "";
							StringList slIPMS = FrameworkUtil.split(strIPMSAttribute,".");
							if(slIPMS.size() > 2) {
								if(slIPMS.size() > 3) {
									strIPMSType= (String)slIPMS.get(0);
									strIPMSName = (String)slIPMS.get(1);
									strRevisionPattern = (String)slIPMS.get(2);
								} else if(slIPMS.size() == 3 ){
									strIPMSType= ConstantsUtilIRM.TYPE_PGPACKINGMATERIAL;
									strIPMSName = (String)slIPMS.get(0);
									strRevisionPattern = (String)slIPMS.get(1);
								}
								
							}
							MapList mlConnectedIPMS = domPOA.findObjects(context, strIPMSType, strIPMSName, strRevisionPattern, "*", ConstantsUtil.VAULT_ESERVICEPRODUCTION, DomainObject.SELECT_CURRENT+"=='"+ConstantsUtil.STATE_RELEASE+"'", false, slSelectables);
							if(mlConnectedIPMS.size()>0){
								for(int k=0; k<mlConnectedIPMS.size(); k++){
									Map mpConnectedIPMS = (Map)mlConnectedIPMS.get(0);
									String strConnectedIPMSId = (String) mpConnectedIPMS.get(DomainObject.SELECT_ID);
									String strConnectedPackagingMaterialTypeAttribute = (String) mpConnectedIPMS.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
									strPackingMaterialType  = strConnectedPackagingMaterialTypeAttribute;
								}
							}
						}
					}
				
			}
			if(!validator.isNotNullOrEmpty(strPackingMaterialType)){
				strPackingMaterialType = "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strPackingMaterialType;
	}
	//SPEC: Release SR18x.6. Modified by Dominic for Defect 42039 on Date 01/04/2021 --END
	//SPEC: Release SR18x.6. Modified by Dominic for Defect 42039 on Date 01/04/2021 --START
	/**
	 * This method gets id of POA and pass it to getPrintingProcessForPOA() to get connected Printing Process
	 * @param context
	 * @param args
	 * @return StringList
	 * @throws Exception
	 */
	public String getPrintingProcessForPOA(Context context,String strPOAObjectId) throws Exception {
		String strPrintingProcess = DomainConstants.EMPTY_STRING;
		try	{
			String strPrintingProcessName = DomainConstants.EMPTY_STRING;
			String strPGOriginatingSource =DomainConstants.EMPTY_STRING;
			DomainObject domPOAObj = DomainObject.newInstance(context);
			String strPrintingProcessRel = PropertyUtil.getSchemaProperty(context, "relationship_pgAAA_POATopgPLIPrintingProcess");
			String strPrintingProcessType = PropertyUtil.getSchemaProperty(context, "type_pgPLIPrintingProcess");
			String strCustomIPMS = null;
			
			StringList objectSelects = new StringList(2);
			objectSelects.addElement("attribute["+ConstantsUtil.ATTRIBUTE_IPMS+"]");
			objectSelects.addElement("attribute["+ConstantsUtilIRM.ATTRIBUTE_CUSTOMIPMS+"]");
			Map objMap = null;
			Map mpPOAInfo = null;
			Map mpArgs = null;
			Map mConnectedObjecttype = null;

			MapList mlConnectedObject = null;
			domPOAObj = DomainObject.newInstance(context,strPOAObjectId);
			mpPOAInfo = domPOAObj.getInfo(context, objectSelects);
				strCustomIPMS = (String) mpPOAInfo.get("attribute["+ConstantsUtilIRM.ATTRIBUTE_CUSTOMIPMS+"]");
				if(validator.isNotNullOrEmpty(strCustomIPMS) && "No".equalsIgnoreCase(strCustomIPMS)) {
					String strIPMSCustom = (String) mpPOAInfo.get("attribute["+ConstantsUtil.ATTRIBUTE_IPMS+"]");
					strPGOriginatingSource = getOriginatingSourceForIPMS(context, strIPMSCustom);
					if(validator.isNotNullOrEmpty(strPGOriginatingSource) && strPGOriginatingSource.equals(ConstantsUtil.TYPE_PACKINGMATERIAL))
					{
						mlConnectedObject = domPOAObj.getRelatedObjects(context, strPrintingProcessRel, strPrintingProcessType, new StringList(DomainObject.SELECT_NAME),new StringList(DomainObject.SELECT_RELATIONSHIP_ID), false, true, (short)1, "", "",0);
						if(mlConnectedObject.size()>0) {
							mConnectedObjecttype = (Map) mlConnectedObject.get(0);
							strPrintingProcessName = (String) mConnectedObjecttype.get(DomainObject.SELECT_NAME);
						}
					} else {
						strPrintingProcessName = loadPrintingProcessForPOA(context, strIPMSCustom);
					}
				} else {
					mlConnectedObject = domPOAObj.getRelatedObjects(context, strPrintingProcessRel, strPrintingProcessType, new StringList(DomainObject.SELECT_NAME),new StringList(DomainObject.SELECT_RELATIONSHIP_ID), false, true, (short)1, "", "",0);
					if(mlConnectedObject.size()>0) {
						mConnectedObjecttype = (Map) mlConnectedObject.get(0);
						strPrintingProcessName = (String) mConnectedObjecttype.get(DomainObject.SELECT_NAME);
					}
				}
			strPrintingProcess =strPrintingProcessName;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strPrintingProcess;
	}
	public String getOriginatingSourceForIPMS(Context context, String strIPMS) throws Exception {
		String strOriginatingSourceIPMS = DomainConstants.EMPTY_STRING;
		try {
			Map mpIPMSDetails =  getExactIPMSInfo(context,strIPMS);
			strOriginatingSourceIPMS = (String)mpIPMSDetails.get(DomainConstants.SELECT_TYPE);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strOriginatingSourceIPMS;
	}
	public Map getExactIPMSInfo(Context context, String strIPMS) throws Exception {
		Map mpIPMSInfo 				= new HashMap();
		try {
			String strRevisionPattern 	= "";
			String strIPMSName 			= "";
			String strIPMSType 			= "";
			StringList slSelect = new StringList(6);
			slSelect.addElement(DomainObject.SELECT_ID);
			slSelect.addElement(DomainObject.SELECT_TYPE);
			slSelect.addElement(DomainObject.SELECT_NAME);
			slSelect.addElement(DomainObject.SELECT_REVISION);
			slSelect.addElement(DomainObject.SELECT_DESCRIPTION);
			if (validator.isNotNullOrEmpty(strIPMS))
			{
				StringList slIPMS = FrameworkUtil.split(strIPMS,".");
				if(slIPMS.size() > 2) {
					if(slIPMS.size() > 3) {
						strRevisionPattern = (String)slIPMS.get(2);
					    strIPMSName = (String)slIPMS.get(1);
						  strIPMSType = (String)slIPMS.get(0);
					} else if(slIPMS.size() == 3 ){
							strRevisionPattern = (String)slIPMS.get(1);
						    strIPMSName = (String)slIPMS.get(0);
							strIPMSType = ConstantsUtilIRM.TYPE_PGPACKINGMATERIAL;;
					}
					MapList	mlIPMS = DomainObject.findObjects(context,  strIPMSType, strIPMSName, strRevisionPattern, "*", ConstantsUtil.VAULT_ESERVICEPRODUCTION, "", false, slSelect);		
					if(mlIPMS != null && mlIPMS.size() > 0) {
						mpIPMSInfo = (Map)mlIPMS.get(0);
					}
				}
			}
		} catch(Exception ex){
			throw ex;
		}
			return mpIPMSInfo;
		}

	public String loadPrintingProcessForPOA(Context context, String strIPMS) throws Exception {
		String strIllustrationName = DomainConstants.EMPTY_STRING;
		try {
			StringBuffer strIllustrationBuff = new StringBuffer();
			String strPrintingProcessName = DomainConstants.EMPTY_STRING;
			Map mPrintingProcessMap = null;
			Map mpIPMSDetails =  getExactIPMSInfo(context,strIPMS);
			String strPMPId = (String)mpIPMSDetails.get(DomainConstants.SELECT_ID);
			if(validator.isNotNullOrEmpty(strPMPId)){
				DomainObject domPMPObj = DomainObject.newInstance(context, strPMPId);
				String strTypeIllustration = PropertyUtil.getSchemaProperty(context, "type_pgPLIPrintingProcess");
				StringList selectBusSelects = new StringList(3);
				selectBusSelects.addElement(DomainObject.SELECT_NAME);
				selectBusSelects.addElement(DomainObject.SELECT_REVISION);
				selectBusSelects.addElement(DomainObject.SELECT_DESCRIPTION);
				MapList mlIllustration = domPMPObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGPDTEMPLATESTOPGPLIPRINTINGPROCESS, strTypeIllustration,selectBusSelects, null, false, true, (short) 1, null, null,0);
				if (mlIllustration.size() > 0) {
					int sSize=mlIllustration.size();
						for(int i=0;i<sSize;i++)
						{
							mPrintingProcessMap = (Map)mlIllustration.get(i);
							strPrintingProcessName = (String)mPrintingProcessMap.get(DomainObject.SELECT_NAME);
							strIllustrationBuff.append(strPrintingProcessName);
							if(i<sSize-1)
							{
								strIllustrationBuff.append(",");
							}
						}
						strIllustrationName = strIllustrationBuff.toString();
			
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strIllustrationName;
	}
	//SPEC: Release SR18x.6. Modified by Dominic for Defect 42039 on Date 01/04/2021 --END
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addFilesMultiList() {
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.SELECT_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_OWNER);
		slMultiSelects.add(ConstantsUtil.SELECT_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_FILE_FORMAT);
		slMultiSelects.add(ConstantsUtil.SELECT_FILE_MODIFIED);
		slMultiSelects.add(ConstantsUtil.SELECT_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.SELECT_LATEST_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_CURRENT);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_ACTIVEVERSION);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		
		return slMultiSelects;
	}
}

