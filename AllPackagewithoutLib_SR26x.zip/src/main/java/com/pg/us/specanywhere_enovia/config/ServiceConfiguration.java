package com.pg.us.specanywhere_enovia.config;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.pg.us.specanywhere_enovia.service.EnoviaAPMPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaAPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaAPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaARMPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaARMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaASLService;
import com.pg.us.specanywhere_enovia.service.EnoviaBSFService;
import com.pg.us.specanywhere_enovia.service.EnoviaCDBService;
import com.pg.us.specanywhere_enovia.service.EnoviaCMService;
import com.pg.us.specanywhere_enovia.service.EnoviaCOPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaCOPService;
import com.pg.us.specanywhere_enovia.service.EnoviaCUPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaCUPService;
import com.pg.us.specanywhere_enovia.service.EnoviaCommonDocCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaCommonDocService;
import com.pg.us.specanywhere_enovia.service.EnoviaDPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaFABService;
import com.pg.us.specanywhere_enovia.service.EnoviaFOPService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPCategoriesService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaFormulaCardService;
import com.pg.us.specanywhere_enovia.service.EnoviaGenDocloadService;
import com.pg.us.specanywhere_enovia.service.EnoviaGetFileService;
import com.pg.us.specanywhere_enovia.service.EnoviaIMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaINGSTMTService;
import com.pg.us.specanywhere_enovia.service.EnoviaIPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaIPService;
import com.pg.us.specanywhere_enovia.service.EnoviaIRMSService;
import com.pg.us.specanywhere_enovia.service.EnoviaListVendorService;
import com.pg.us.specanywhere_enovia.service.EnoviaMCOPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMCPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMCUPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMEPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMIPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPAPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPSService;
import com.pg.us.specanywhere_enovia.service.EnoviaMRMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaOPPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaOPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaPDFPayloadService;
import com.pg.us.specanywhere_enovia.service.EnoviaPDFService;
import com.pg.us.specanywhere_enovia.service.EnoviaPGContactService;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaPOAARTService;
import com.pg.us.specanywhere_enovia.service.EnoviaPOAService;
import com.pg.us.specanywhere_enovia.service.EnoviaPQRService;
import com.pg.us.specanywhere_enovia.service.EnoviaPSUBService;
import com.pg.us.specanywhere_enovia.service.EnoviaPackagingAssemblyPart;
import com.pg.us.specanywhere_enovia.service.EnoviaPackagingAssemblyPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaPriliminaryPayloadService;
import com.pg.us.specanywhere_enovia.service.EnoviaPriliminarydataloadService;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSBPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSEPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSISService;
import com.pg.us.specanywhere_enovia.service.EnoviaSMLService;
import com.pg.us.specanywhere_enovia.service.EnoviaSWPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaSWPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSearchService;
import com.pg.us.specanywhere_enovia.service.EnoviaSecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaSpecPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaTUPService;
import com.pg.us.specanywhere_enovia.service.EnoviaVendorSpecsService;
import com.pg.us.specanywhere_enovia.service.EnoviaWhereUsedService;
import com.pg.us.specanywhere_enovia.service.PromotionalItemPartCompService;
import com.pg.us.specanywhere_enovia.service.PromotionalItemPartService;
import com.pg.us.specanywhere_enovia.service.EnoviaEMPService;//Added by Ganesh for Dev 18x.6 <5 Mar 2021>
import com.pg.us.specanywhere_enovia.service.EnoviaFABCompService;
import com.pg.us.specanywhere_enovia.service.impl.ENoviaDPPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaAPMPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaAPPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaARMPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaASLServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaBSFServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaCDBServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaCOPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaCUPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaCharacteristicMasterImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaCommonDocServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaFABServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaFOPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaFPPCategoriesServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaFPPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaFormulaCardServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaGenDocloadServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaGetFileServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaIMPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaINGSTMTServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaIPPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaIPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaIRMSServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaListVendorServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMCOPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMCPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMCUPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMEPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMIPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMPAPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMPMPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMPPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMPSServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaMRMPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaOPPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPDFPayloadServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPDFServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPGContactServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaAPMPCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaARMPCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaCOPCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaCUPCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaCommonDocCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaFABCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaFPPCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaOPPCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaPMPPartCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaPackagingAssemblyPartCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaPriliminaryPayloadServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaPriliminarydataloadServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaPromotionalItemPartCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaRMPPartCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaSWPCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPMPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPOAARTServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPOAServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPQRServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPSUBServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPromotionalItemPartServiceImpl;
import com.pg.us.specanywhere_enovia.service.comp.EnoviaSpecPartCompServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaRMPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaSBPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaSEPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaSISServiceImpl; // Added by Govind for Req #35943
import com.pg.us.specanywhere_enovia.service.impl.EnoviaSMLServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaSWPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaSearchServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaSecurityServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaTUPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaVendorSpecsServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaWhereUsedServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.PackagingAssemblyPartImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaEMPServiceImpl;//Added by ganesh for Dev SR18x.6
import com.pg.us.specanywhere_enovia.service.EnoviaDSService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaDSServiceImpl;
import com.pg.us.specanywhere_enovia.service.EnoviaDSSearchService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaDSSearchServiceImpl;
import com.pg.us.specanywhere_enovia.service.EnoviaDSMReportService;
import com.pg.us.specanywhere_enovia.service.EnoviaDSMReportValidationService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaDSMReportServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaDSMReportValidationServiceImpl;
import com.pg.us.specanywhere_enovia.service.EnoviaEBPService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaEBPServiceImpl;

@Configuration
public class ServiceConfiguration {


	@Bean
	@Qualifier("SearchService")
	public EnoviaSearchService getSearchTemplateWebService() {
		return new EnoviaSearchServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaFPPService getFPPTemplateWebService() {
		return new EnoviaFPPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaCUPService getCUPTemplateWebService() {
		return new EnoviaCUPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaCOPService getCOPTemplateWebService() {
		return new EnoviaCOPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaRMPService getRMPTemplateWebService() {
		return new EnoviaRMPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaPMPService getPMPTemplateWebService() {
		return new EnoviaPMPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaFOPService getFOPTemplateWebService() {
		return new EnoviaFOPServiceImpl();
	}
	


	@Bean
	@Qualifier("SearchService")
	public EnoviaIPService getIPTemplateWebService() {
		return new EnoviaIPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaTUPService getTUPTemplateWebService() {
		return new EnoviaTUPServiceImpl();
	}


	@Bean
	@Qualifier("searchService")
	public EnoviaGetFileService getFilePathTemplateWebService() {
		return new EnoviaGetFileServiceImpl();
	}

	@Bean
	@Qualifier("searchService")
	public EnoviaSecurityService getSecurityClassificationTemplateWebService() {
		return new EnoviaSecurityServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaAPPService getAPPTemplateWebService() {
		return new EnoviaAPPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaPackagingAssemblyPart getPAPTemplateWebService() {
		return new PackagingAssemblyPartImpl();
	}


	@Bean
	@Qualifier("SearchService")
	public EnoviaMIPService getMIPTemplateWebService() {
		return new EnoviaMIPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaMPAPService getMPAPTemplateWebService() {
		return new EnoviaMPAPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaIPPService getIPPTemplateWebService() {
		return new EnoviaIPPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaAPMPService getAPMPTemplateWebService() {
		return new EnoviaAPMPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaMCOPService getMCOPTemplateWebService() {
		return new EnoviaMCOPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaMCUPService getMCUPTemplateWebService() {
		return new EnoviaMCUPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaCDBService getCDBTemplateWebService() {
		return new EnoviaCDBServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaASLService getASLTemplateWebService() {
		return new EnoviaASLServiceImpl();
	}

	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

	@Bean
	@Qualifier("SearchService")
	public PromotionalItemPartService getPIPTemplateWebService() {
		return new EnoviaPromotionalItemPartServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaOPPService getOPPTemplateWebService() {
		return new EnoviaOPPServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaFABService getFABTemplateWebService() {
		return new EnoviaFABServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaIRMSService getIRMSTemplateWebService() {
		return new EnoviaIRMSServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaMRMPService getMRMPTemplateWebService() {
		return new EnoviaMRMPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaMPPService getMPPTemplateWebService() {
		return new EnoviaMPPServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaMPMPService getMPMPTemplateWebService() {
		return new EnoviaMPMPServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaDPPService getDPPTemplateWebService() {
		return new ENoviaDPPServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaMEPService getMEPTemplateWebService() {
		return new EnoviaMEPServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaSEPService getSEPTemplateWebService() {
		return new EnoviaSEPServiceImpl();
	}


	@Bean
	@Qualifier("SearchService")
	public EnoviaCommonDocService getDOCTemplateWebService() {
		return new EnoviaCommonDocServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaVendorSpecsService getVendorTemplateWebService() {
		return new EnoviaVendorSpecsServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaPOAService getPOAWebService() {
		return new EnoviaPOAServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaMCPService getMCPemplateWebService() {
		return new EnoviaMCPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaIMPService getIMPWebService() {
		return new EnoviaIMPServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaARMPService getARMPWebService() {
		return new EnoviaARMPServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaPSUBService getPSUBWebService() {
		return new EnoviaPSUBServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaMPSService getMPSTemplateWebService() {
		return new EnoviaMPSServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaFormulaCardService getFormulaCardWebService() {
		return new EnoviaFormulaCardServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaPOAARTService getPOAARTWebService() {
		return new EnoviaPOAARTServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaPQRService getPQRWebService() {
		return new EnoviaPQRServiceImpl();
	}

	@Bean
	@Qualifier("SearchService")
	public EnoviaSWPService getSWPWebService() {
		return new EnoviaSWPServiceImpl();
	}

	//SPEC: <01.08.2021>: Added by Govind for Req #35943
	@Bean
	@Qualifier("SearchService")
	public EnoviaSISService getSISWebService() {
		return new EnoviaSISServiceImpl();
	}

	//Added by Aditya 36071
	@Bean
	@Qualifier("SearchService")
	public EnoviaBSFService getBSFWebService() {
		return new EnoviaBSFServiceImpl();
	}
	//Added by Jwala for Dev SR18x.6
	@Bean
	@Qualifier("SearchService")
	public EnoviaINGSTMTService geEnoviaINGSTMTService() {
		return new EnoviaINGSTMTServiceImpl();
	}
	//Added by Guna for Dev SR18x.6
	@Bean
	@Qualifier("SearchService")
	public EnoviaSMLService geEnoviaSMLService() {
		return new EnoviaSMLServiceImpl();
	}
	//SPEC: <05.03.2021>: Chandra Added for Dev 18x.6   -- START	
	@Bean
	@Qualifier("SearchService")
	public EnoviaSBPService geEnoviaSBPService() {
		return new EnoviaSBPServiceImpl();
	}
	//SPEC: <05.03.2021>: Chandra Added for Dev 18x.6   -- END
	//Added by Ganesh for Dev SR18x.6
	@Bean
	@Qualifier("SearchService")
	public EnoviaEMPService geEnoviaEMPService() {
		return new EnoviaEMPServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaDSService geEnoviaDSService() {
		return new EnoviaDSServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaDSSearchService geEnoviaDSSearchService() {
		return new EnoviaDSSearchServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaDSMReportService geEnoviaDSMReportService() {
		return new EnoviaDSMReportServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaDSMReportValidationService geEnoviaDSMReportValidationService() {
		return new EnoviaDSMReportValidationServiceImpl();
	}

	//Added by Jwala for Dev SR18x.6
	@Bean
	@Qualifier("SearchService")
	public EnoviaCMService geEnoviaCMService() {
		return new EnoviaCharacteristicMasterImpl();
	}
	
	//Added by Manikanta for Dev SR22x_Dec Development
	@Bean
	@Qualifier("SearchService")
	public EnoviaEBPService geEnoviaEBPService() {
		return new EnoviaEBPServiceImpl();
	}
	
	//Added by Jwala for Dev SR22x_Dec Development
	@Bean
	@Qualifier("SearchService")
	public EnoviaPGContactService geEnoviaUserService() {
		return new EnoviaPGContactServiceImpl();
	}
	
	//Added by Ketan for Req. no. 5327
	@Bean
	@Qualifier("SearchService")
	public EnoviaPDFService getEnoviaPDFService() {
		return new EnoviaPDFServiceImpl();
	}
	
	//Added by Ketan for Req. no. 7093 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaWhereUsedService getEnoviaWhereUsedService() {
		return new EnoviaWhereUsedServiceImpl();
	}
	//Added by Ketan for Req. no. 7093 -- END
	
	//Added by Ajay for Req. no. 8268 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaListVendorService getVendorList() {
		return new EnoviaListVendorServiceImpl();
	}
	//Added by Ajay for Req. no. 8268 -- END
	
	//SPEC: Added by Ajay for Req. no. 5228 START
	@Bean
	@Qualifier("SearchService")
	public EnoviaFPPCategoriesService getFPPCategoriesdata() {
		return new EnoviaFPPCategoriesServiceImpl();
	}
	//SPEC: Added by Ajay for Req. no. 5228 END
	
	//SPEC: Added by Ajay for Req. no. 21482 START
	@Bean
	@Qualifier("SearchService")
	public EnoviaSpecPartCompService getSpecPartCompData() {
		return new EnoviaSpecPartCompServiceImpl();
	}
	//SPEC: Added by Ajay for Req. no. 21482 END
	
	@Bean
	@Qualifier("SearchService")
	public EnoviaRMPPartCompService getRMPPartCompData() {
		return new EnoviaRMPPartCompServiceImpl();
	}
	
	@Bean
	@Qualifier("SearchService")
	public EnoviaPMPPartCompService getPMPPartCompData() {
		return new EnoviaPMPPartCompServiceImpl();
	}
	//SPEC: Added by Ajay for Req. no. 23961 START
	@Bean
	@Qualifier("SearchService")
	public EnoviaPackagingAssemblyPartCompService getPAPPartCompData() {
		return new EnoviaPackagingAssemblyPartCompServiceImpl();
	}
	//SPEC: Added by Ajay for Req. no. 23961 END
	//SPEC: Added by Ajay for Req. no. 23960 - START
	@Bean
	@Qualifier("SearchService")
	public EnoviaFABCompService getFABCompdata() {
		return new EnoviaFABCompServiceImpl();
	}
	//SPEC: Added by Ajay for Req. no. 23960 - END
	
	//SPEC: Modified by Ajay for Req. no. 78405 START
	@Bean
	@Qualifier("SearchService")
	public EnoviaFPPCompService getFPPCompService() {
		return new EnoviaFPPCompServiceImpl();
	}
	//SPEC: Modified by Ajay for Req. no. 78405 END
	
	//SPEC: Added by Ajay for Req. no. 23970 START
		@Bean
		@Qualifier("SearchService")
		public EnoviaCommonDocCompService getCommonCompService() {
			return new EnoviaCommonDocCompServiceImpl();
		}
	//SPEC: Added by Ajay for Req. no. 23970 END
	//SPEC: Added by Ajay for Req. no. 23970 START
	@Bean
	@Qualifier("SearchService")
	public EnoviaARMPCompService getArmpCompService() {
			return new EnoviaARMPCompServiceImpl();
		}
		//SPEC: Added by Ajay for Req. no. 23970 END
	//SPEC: Added by Ajay for Req. no. 23975 START
	@Bean
	@Qualifier("SearchService")
	public PromotionalItemPartCompService getPIPPartCompData() {
		return new EnoviaPromotionalItemPartCompServiceImpl();
	}
	//SPEC: Added by Ajay for Req. no. 23975 END
	//Added by Ajay for Req No. 23973 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaAPMPCompService getAPMPCompdata() {
		return new EnoviaAPMPCompServiceImpl();
	}
	//Added by Ajay for Req No. 23973 -- END
	//Added by Ajay for Req No. 23973 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaSWPCompService getSWCompService() {
		return new EnoviaSWPCompServiceImpl();
	}
	//Added by Ajay for Req No. 23973 -- END
	//Added by Ajay for Req No. 23966 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaOPPCompService getOPPCompService() {
		return new EnoviaOPPCompServiceImpl();
	}
	//Added by Ajay for Req No. 23966 -- END

	//Added by Ajay for Req No. 11878 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaGenDocloadService getGendocPayloaddata() {
		return new EnoviaGenDocloadServiceImpl();
	}
	//Added by Ajay for Req No. 11878 -- END
	//Added by Ajay for Req No. 23966 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaPDFPayloadService getPDFPayloaddata() {
		return new EnoviaPDFPayloadServiceImpl();
	}
	//Added by Ajay for Req No. 23966 -- END
	//Added by Ajay for Req No. 122489 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaCUPCompService getCUPCompdata() {
		return new EnoviaCUPCompServiceImpl();
	}
	//Added by Ajay for Req No. 122489 -- END
	//Added by Ajay for Req No. 125736 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaCOPCompService getCOPCompdata() {
		return new EnoviaCOPCompServiceImpl();
	}
	//Added by Ajay for Req No. 125736 -- END
	//Added by Ajay for Req No. 118924 -- START
	@Bean
	@Qualifier("SearchService")
	public EnoviaPriliminarydataloadService getPriliminarydata() {
		return new EnoviaPriliminarydataloadServiceImpl();
	}
	@Bean
	@Qualifier("SearchService")
	public EnoviaPriliminaryPayloadService getPriliminaryPayLoaddata() {
		return new EnoviaPriliminaryPayloadServiceImpl();
	}
	//Added by Ajay for Req No. 118924 -- END
	

}
