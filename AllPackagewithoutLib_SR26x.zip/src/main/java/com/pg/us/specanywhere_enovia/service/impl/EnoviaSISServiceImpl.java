/*
 * SPEC: <01.08.2021>: SIS template has been Implemented for Req #35943 
 * Date : Jan 8th 2021
 */

package com.pg.us.specanywhere_enovia.service.impl;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaCardBO;
import com.pg.us.specanywhere_enovia.bo.PackingSubassemblyBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaSISService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaSISServiceImpl implements EnoviaSISService {


	private static Logger LOGGER = Logger.getLogger(EnoviaSISServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	@Override
	public HashMap<String, Map<String,String>> getSISdata(String objId, Environment env) throws Exception {
		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		//EnoviaConnectionPool pool = new EnoviaConnectionPool(USER,PASS,VAULT);
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("SIS CONTEXT ELAPSED TIME : "+swContext.getTime());

		try {

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START

			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			//SPEC: <08-13-2021>: Guna Modified for Stress Testing Defect 44365  -- START
			if (UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BObjutil.getUserView(context, objId);
				}
			}
			//SPEC: <08-13-2021>: Guna Modified for Stress Testing Defect 44365  -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}


			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);

			PackingSubassemblyBO psubbo = new PackingSubassemblyBO();
			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			FormulaCardBO fcBO = new FormulaCardBO();

			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mapAttribResult = new HashMap<String,String>();				
			Map<String,String> mpIsATS = new HashMap<String,String>();				
			Map<String,String> mpTechnicalSupersedes = new HashMap<String,String>();							
			Map<String,String> mapPartSpecification = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpSecurity = null;
			Map<String,String> mpIPClass =null;

			// Added by Jwala to send role info to Integration
			mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			// Added by Jwala to send role info to Integration

			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtil.SELECT_ID);
			slSelects.add(ConstantsUtil.SELECT_TYPE);
			slSelects.add(ConstantsUtil.SELECT_NAME);
			slSelects.add(ConstantsUtil.SELECT_REVISION);
			slSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			slSelects.add(ConstantsUtil.SELECT_CURRENT);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REASON_FOR_CHANGE);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);

			slSelects.add(ConstantsUtil.SELECT_SAP_TYPE); 			
			slSelects.add(ConstantsUtil.SELECT_SAP_PHASE); 			
			slSelects.add(ConstantsUtil.SELECT_SAP_TITLE);	
			slSelects.add(ConstantsUtil.SELECT_SAP_CURRENT);
			slSelects.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);
			slSelects.add(ConstantsUtil.SELECT_SAP_NAME);
			slSelects.add(ConstantsUtil.SELECT_SAP_REVISION);

			slSelects.add(ConstantsUtil.REL_ATS_ID);		
			slSelects.add(ConstantsUtil.REL_ATS_TYPE); 			
			slSelects.add(ConstantsUtil.REL_ATS_RELEASE_PHASE); 			
			slSelects.add(ConstantsUtil.REL_ATS_TITLE);	
			slSelects.add(ConstantsUtil.REL_ATS_STATE); 
			slSelects.add(ConstantsUtil.REL_ATS_NAME);
			slSelects.add(ConstantsUtil.REL_ATS_REV);

			// SPEC: Release SR18x.5.2: Added for Defect 38338 by Amman -- START
			slSelects.add(ConstantsUtil.SELECT_SUPERSEDESONDATE);
			// SPEC: Release SR18x.5.2: Added for Defect 38338 by Amman -- END
			//START :: gaikwad.tg :: Defect#3833838338
			slSelects.add(ConstantsUtil.ATTRIBUTE_PGORIGINATINGSOURCE);
			slSelects.add(ConstantsUtil.ATL_STATE);
			//END :: gaikwad.tg :: Defect#38162
			//Added by Pooja for the req 35943 -- START
			slSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
			slSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
			slSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
			slSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
			slSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
			slSelects.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);
			//Added by Pooja for the req 35943 -- END
			StringValidatorUtil validator = new StringValidatorUtil();
			DomainObject doObj = new DomainObject(objId);
			FinishedProductPartBO fppBO = new FinishedProductPartBO();

			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMap = doObj.getInfo(context, slSelects);
			Map resultMap = doObj.getInfo(context, slSelects,psubbo.addMultiList());
			doObj.close(context);
			swAttributes.stop();
			LOGGER.info("SIS GETINFO ELAPSED TIME : "+swAttributes.getTime());

			/**
			 * LOAD HEADER SECTION
			 * */
			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)))?busUtil.mapType((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			String sClassification = busUtil.getClassification(resultMap);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));

			/**
			 * LOAD BASIC ATTRIBUTES SECTION
			 * */
			mapAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID)))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			//mapAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.REERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.REERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);


			/**
			 * Is ATS
			 */
			//START :: gaikwad.tg :: Defect#38338
			/*mpIsATS = busUtil.checkIsATS(context,resultMap);

				if(!mpIsATS.isEmpty()){
					mpHeaderResult.put(ConstantsUtil.ISATS, ConstantsUtil.SYMBL_YES);
				}else{
					mpHeaderResult.put(ConstantsUtil.ISATS, ConstantsUtil.SYMBL_NO);
				}

				Map<String,String> mpHasATS = new HashMap<String,String>();
				mpHasATS = busUtil.checkHasATS(context,resultMap);
				if(!mpHasATS.isEmpty()){
					mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
				}*/
			String strAsATS = busUtil.checkIsATSForSIS(context,resultMap);
			mpHeaderResult.put(ConstantsUtil.ISATS, strAsATS);
			String sHasATSAttrVal = busUtil.checkHasATSForSIS(context,resultMap);
			mpHeaderResult.put(ConstantsUtil.HASATS, sHasATSAttrVal);
			//END :: gaikwad.tg :: Defect#38338
			//Added by Pooja for the req 35943 -- START
			/**
			 * LOAD IP CLASSES SECTION
			 */

			StringList slIpSelects = new StringList();
			slIpSelects.add(DomainConstants.SELECT_NAME);
			slIpSelects.add(DomainConstants.SELECT_ID);
			slIpSelects.add(DomainConstants.SELECT_CURRENT);
			slIpSelects.add(DomainConstants.SELECT_TYPE);
			slIpSelects.add(DomainConstants.SELECT_DESCRIPTION);

			CommonBusUtilBO commonBO = new CommonBusUtilBO();
			mpIPClass =CommonBusUtilBO.getIpClass(context, doObj, slIpSelects);
			/**
			 * LOAD SECURITY SECTION
			 * */
			StopWatch swSecurity = new StopWatch();

			swSecurity.start();
			mpSecurity =commonBO.updateSecurity(context, resultMap);
			swSecurity.stop();
			//Added by Pooja for the req 35943 -- END
			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */

			StopWatch sisReference= new StopWatch();
			sisReference.start();
			mapReferenceDocs = fcBO.updateRefDocs(context, resultMap);
			sisReference.stop();
			LOGGER.info("SIS  REFERENCE DOCS ELAPSED TIME : "+sisReference.getTime());					

			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mapAttribResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
			hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			//LOGGER.info("SIS RESPONSE MESSAGE:: \n" + hmAttrib);

			ContextUtil.popContext(context);
			pool.checkIn(context);
			sp.stop();
			LOGGER.info("SIS MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "SIS OBJECT NAME::"+resultMap.get(ConstantsUtil.SELECT_NAME));

		} catch (IOException e) {
			LOGGER.error("IOException from SIS "+e);
		} catch (MatrixException e) {
			LOGGER.error("MatrixException from SIS "+e);
		}
		context.close();
		return hmAttrib;
	}
}

