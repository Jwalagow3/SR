package com.pg.us.specanywhere_enovia.utility;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;

import jakarta.xml.soap.SOAPConnection;
import jakarta.xml.soap.SOAPConnectionFactory;
import jakarta.xml.soap.SOAPException;
import jakarta.xml.soap.SOAPMessage;

import java.io.*;
import java.util.concurrent.*;

public class SAPGTINFetcher {
	private static final ExecutorService executor = Executors.newSingleThreadExecutor();

	public String getGTIN(SOAPMessage message, String strSAPSystemURL) {
		Future<String> future = executor.submit(() -> {
			SOAPConnection soapConnection = null;
			try {
				SOAPConnectionFactory soapConnFactory = SOAPConnectionFactory.newInstance();
				soapConnection = soapConnFactory.createConnection();

				// Blocking SAP call
				SOAPMessage response = soapConnection.call(message, strSAPSystemURL);

				// Convert SOAP response to String
				TransformerFactory transformerFac = TransformerFactory.newInstance();
				Transformer transf = transformerFac.newTransformer();
				Source sc = response.getSOAPPart().getContent();

				StringWriter outWriter = new StringWriter();
				StreamResult result = new StreamResult(outWriter);
				transf.transform(sc, result);
				String output = outWriter.toString();

				return output;

			} catch (Exception e) {
				System.err.println("SAP call failed: " + e.getMessage());
				return null;
			} finally {
				if (soapConnection != null) {
					try {
						soapConnection.close();
					} catch (SOAPException e) {
						System.err.println("SOAP connection close failed: " + e.getMessage());
					}
				}
			}
		});

		try {
			// Set timeout here (e.g., 5 seconds)
			return future.get(10, TimeUnit.SECONDS);
		} catch (TimeoutException e) {
			System.err.println("SAP call timed out");
			future.cancel(true);
			return ConstantsUtilIRM.SAP_TIMEOUT;
		} catch (Exception e) {
			System.err.println("SAP call error: " + e.getMessage());
		}

		return null;
	}
}
