package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.pg.us.specanywhere_enovia.bo.PQRBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class PQRService {
	private static Logger LOGGER = Logger.getLogger(PQRService.class);

	public static void main(String[] args) throws Exception {
	
		//String objId = "20336.41905.64714.24396";
		String objId =  "20336.41905.21259.6316"; //UNIT TESTED ONE
		
		EnoviaConnectionPool pool = new EnoviaConnectionPool();
		Context context = pool.checkOut();
		
			HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
			StopWatch sp = new StopWatch();
			sp.start();
			
				Map<String,String> mpHeaderContent = new HashMap<String,String>();
				Map<String,String> mpAttribResult = new HashMap<String,String>();
				Map<String,String> mpOrganization = new HashMap<String,String>();
				Map<String,String> mpOwnershipResult = new HashMap<String,String>();
				Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
				Map<String,String> mpReferenceDocs = new HashMap<String,String>();
				Map<String,String> mpSpecResult = new HashMap<String,String>();
				Map<String,String> mpTransportUnitResult = new HashMap<String,String>();
				Map<String,String> mpPackingUnit = new HashMap<String,String>();
				Map<String,String> mpWnDResult = new HashMap<String,String>();
				Map<String,String> mpPerformChar= new HashMap<String,String>();
				Map<String,String> mpNotes = new HashMap<String,String>();
				//Map<String,String> mpSubstitute = new HashMap<String,String>();
				Map<String,String> mpBOMResult = new HashMap<String,String>();
				Map<String,String> mpHasATS = new HashMap<String,String>();
				Map<String,String> mpISATS = new HashMap<String,String>();
				Map<String,String> mpTechnicalSupersedes = new HashMap<String,String>();
				Map<String,String> mpTechnicalSupersedesBy = new HashMap<String,String>();
				Map<String,String> mpSecurity = new HashMap<String,String>();
				Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
				Map<String,String> mpIPClass = new HashMap<String, String>();
				Map<String,String> mpQualifiedEqu = new HashMap<String, String>();
				Map<String,String> mpPlants = new HashMap<String, String>();
				
				BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
				StringValidatorUtil validator = new StringValidatorUtil();
				
				ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);

				PQRBO pqrBO = new PQRBO();
				Map BusinessObjectSelectableMap = pqrBO.getPQRSelectableMap(context);
				StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
				
				DomainObject doPQR = pqrBO.getPqrDO(context, objId);
				if (null == doPQR) {
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.info("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
					//return hmAttrib;
				}
				
				StopWatch swAttributes = new StopWatch();
				swAttributes.start();			
				//pqrBO.addMultiList();
				Map resultMap = doPQR.getInfo(context, slSelects);
				swAttributes.stop();
				LOGGER.info("PQR GETINFO ELAPSED TIME : "+swAttributes.getTime());
				//pqrBO.removeMultiList();
				Map BusinessObjectRelSelectableMap = pqrBO.getPqrRelatedObjsSelectableMap(context);
				
				String sType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
				String sID = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

				StringList slEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.BUS_SELECTS);
				StringList slRelEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.REL_SELECTS);
				
				
				/**
				 * ATTRIBUTES SECTION
				 */
				mpAttribResult.put(ConstantsUtil.QUALIFICATIONNAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMap.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREFERENCE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREFERENCESCORE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCESCORE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PREFERENCESCORE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.QUALIFICATIONDESC, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MANUFACTURER, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PQRMANUFACTURER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MANUFACTURERLINES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURERLINES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURERLINES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCATIONSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCATIONSTATUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCATIONSTATUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BUSINESSAREA, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA)))?(String)resultMap.get(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA) : ConstantsUtil.EMPTY_STRING);
				
	
				/**
				 * Logic for Product Category Platform
				 */
				StringList busSelect = new StringList();
				busSelect.add(ConstantsUtil.SELECT_ID);
				busSelect.add(ConstantsUtil.SELECT_TYPE);
				busSelect.add(ConstantsUtil.SELECT_NAME);
				
				StringList relSelect = new StringList();
				relSelect.add(ConstantsUtil.EMPTY_STRING);
				
				DomainObject dom = new DomainObject(sID);
				MapList mlPCP = dom.getRelatedObjects(context,ConstantsUtil.RELATIONSHIP_PGDOCUMENTTOPLATFORM, ConstantsUtil.QUERY_WILDCARD, busSelect,
						relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
				
				Iterator objectListItr = mlPCP.iterator();
				String slPCPDetails = ConstantsUtil.EMPTY_STRING;
				StringBuilder PCP = new StringBuilder();
				while(objectListItr.hasNext())
				{
					Map mpTemp = (Map) objectListItr.next();
					slPCPDetails = (String)mpTemp.get(ConstantsUtil.SELECT_NAME);
					pqrBO.formatDataforPCP(PCP,slPCPDetails);
					
				}
				String ProductCategoryPlatform = PCP.toString();
				
				if(!ProductCategoryPlatform.isEmpty())
				ProductCategoryPlatform = ProductCategoryPlatform.substring(0, ProductCategoryPlatform.length()-1);
				
				mpAttribResult.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM, ProductCategoryPlatform);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				
				
				/**
				 * REFERENCE DOCUMENTS SECTION
				 */
				/*
				StopWatch swReference= new StopWatch();
				swReference.start();
				mpReferenceDocs = pqrBO.updateRefDocs(context, resultMap);
				swReference.stop();
				LOGGER.info("PQR REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());
				*/
				
				
				/**
				 * QUALIFIED EQUIVALENTS SECTION
				 */
				//mpQualifiedEqu = pqrBO.getQualifiedEquivalent(context,resultMap);
				
				
				/**
				 * PLANTS SECTION
				 */
				mpPlants.put(ConstantsUtil.PLANTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME)))?(String)resultMap.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME) : ConstantsUtil.EMPTY_STRING);
				
				
				hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
				hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mpReferenceDocs);
				hmAttrib.put(ConstantsUtil.QUALIFIEDEQUIVALENT, mpQualifiedEqu);
				hmAttrib.put(ConstantsUtil.PLANTS, mpPlants);
				
				System.out.println("hmAttrib------------------------"+hmAttrib);
				ContextUtil.popContext(context);
				pool.checkIn(context);
				sp.stop();
				System.out.println("Execution TIME::" + sp.getTime());
				//Subhajit Added for Memory Leakage Analysis - Start
				context.close();
				//Subhajit Added for Memory Leakage Analysis - End
	}
}
