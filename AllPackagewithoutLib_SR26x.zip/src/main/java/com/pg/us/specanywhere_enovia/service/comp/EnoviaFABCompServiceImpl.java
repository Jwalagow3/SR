package com.pg.us.specanywhere_enovia.service.comp;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaFABCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaFABService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaFABServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.PackagingAssemblyPartImpl;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;

public class EnoviaFABCompServiceImpl implements EnoviaFABCompService {
	private static Logger LOGGER = Logger.getLogger(EnoviaFABServiceImpl.class);
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	
	@Autowired
	private EnoviaConnectionPool pool;
	
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private EnoviaFABService fab;
	@Override
	public HashMap<String, HashMap<String, Map<String, String>>> getFABCompdata(String objId, Environment env) throws Exception {
		HashMap<String, HashMap<String, Map<String, String>>> hmAttrib = new HashMap<String, HashMap<String, Map<String, String>>>();
		HashMap<String, Map<String, String>> hmfinalrel = new HashMap<String, Map<String, String>>();
		HashMap<String, Map<String, String>> hmAttribObj = new HashMap<String, Map<String, String>>();
		StringValidatorUtil validator = new StringValidatorUtil();
		StopWatch sp = new StopWatch();
		sp.start();
		
		Context context = null;
		
		try {
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			swContext.stop();
			String sComp=ConstantsUtilIRM.FAB_COMPARE;
			if(UIUtil.isNotNullAndNotEmpty(objId)){
				hmfinalrel = fab.getFABdata(objId,sComp, env);
				DomainObject doFAB = DomainObject.newInstance(context, objId);
				sComp=ConstantsUtilIRM.COMPARE;
				String sDocPreviousRevId  = doFAB.getPreviousRevision(context).getObjectId();
				if(UIUtil.isNotNullAndNotEmpty(sDocPreviousRevId))
					hmAttribObj = fab.getFABdata(sDocPreviousRevId, sComp,env);
			}
			hmAttrib.put(ConstantsUtilIRM.RELEASEOBJECT, hmfinalrel);
			hmAttrib.put(ConstantsUtilIRM.OBSOLETEOBJECT,hmAttribObj);
		}catch(Exception e) {
			LOGGER.error("Exception From FAB COMPARISION Service IMPL Class "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		
		return hmAttrib;
	}

}
