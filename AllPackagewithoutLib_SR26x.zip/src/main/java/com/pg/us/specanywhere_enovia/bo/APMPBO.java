/**
 * Project 		: SpecsAnywhere
 * Program 		: APMPBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class APMPBO extends BusinessObject {

	BusObjectAttribUtil util = new BusObjectAttribUtil();
	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(APMPBO.class);

	public APMPBO() {
		// empty constructor
	}

	public APMPBO(String oid) {
		this.setObjectId(oid);
	}

	/**
	 * Method Name 			: getAPMPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getAPMPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID in APMPBO: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getAPMPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */	
	public DomainObject getAPMPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID in APMPBO: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getAPMPPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getAPMPPartSelectables(Context context) {
		StringList busSelect = new StringList(100);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getPlantSelects(context));
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.addAll(getFileSelects(context));
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		//SPEC : Modified by Chandra on 05-Jan-2021 for  Requirement 38258  --START
		//busSelect.addAll(getSubstanceSelectables(context));
		//SPEC : Modified by Chandra on 05-Jan-2021 for  Requirement 38258  --END
		busSelect.addAll(getSecuritySelects(context));

		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
	
	/**
	 * Method Name 			: getAPMPRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getAPMPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}

	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: Fetching attribute details like - title, UOM, comment and state
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList(4);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	: Fetching attribute details like - quantity, comment, etc.
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList(7);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
	
		

		return relSelect;
	}

	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	: Fetching business object details
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList(70);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPARTCOLOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_CONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDECORATIONDETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY);
		busSelect.add(ConstantsUtil.LEGACYENVCLASSNAME);
		
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		
		//SPEC: 11/07/2020: Added for Defect 37180 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		//SPEC: 11/07/2020: Added for Defect 37180 -- END
		
		

		return busSelect;

	}

	
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 * SPEC: Chandra commented  on 05-Jan-2020 for regularizing this section
	 */
	
/*	public static StringList getSubstanceSelectables (Context context) {
		StringList busSelect = new StringList(24);
		busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID); 
		busSelect.add(ConstantsUtil.COMP_NAME);  
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC); 
		busSelect.add(ConstantsUtil.COMP_TITLE); 
		busSelect.add(ConstantsUtil.COMP_STATE); 
		busSelect.add(ConstantsUtil.COMP_CASNUM);  		
		busSelect.add(ConstantsUtil.COMP_SUBNAME);  		
		busSelect.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);  		
		busSelect.add(ConstantsUtil.COMP_QTY);  			
		busSelect.add(ConstantsUtil.COMP_MAXHGHT);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT);  		
		busSelect.add(ConstantsUtil.COMP_QUOM);  			
		busSelect.add(ConstantsUtil.COMP_METALENVCLASS); 
		busSelect.add(ConstantsUtil.COMP_POSTCONSUMER); 
		busSelect.add(ConstantsUtil.COMP_MANUF);  		
		busSelect.add(ConstantsUtil.COMP_COMENT);  		
		busSelect.add(ConstantsUtil.COMP_MARKETNAME);  	
		busSelect.add(ConstantsUtil.COMP_SEQUENCE);  		
		busSelect.add(ConstantsUtil.COMP_MATELAYER);
		busSelect.add(ConstantsUtil.COMP_POSTINDUSTRIAL);
		busSelect.add(ConstantsUtil.COMP_RPRSTATUS);
		busSelect.add(ConstantsUtil.COMP_ECNUMBER);
		busSelect.add(ConstantsUtil.COMP_REACHSTATUS);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_CURRENT);
		
		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		
			
		//<11.21.2020>: Added for #37507 START
		busSelect.add(ConstantsUtil.COMP_RELCOMMENT);
		//<11.21.2020>: Added for #37507 END

		return busSelect;
	}
*/
	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching PLANT related details
	 * @param context
	 * @return
	 */
	public static StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		return busSelect;
	}

	
	/**
	 * Method Name 			: getSubstancesforSupplier
	 * Method Description 	: Fetching SUBSTANCE details for Supplier
	 * @param resultMaps
	 * @return
	 */
	
	//SPEC : Modified by Chandra on 05-Jan-2021 for  Requirement 38258 --START
	
	//public Map getSubstancesforSupplier(Map resultMaps)
	public Map getSubstancesforSupplier(Context context,Map mpContextMap)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		CommonBusUtilBO comBus= new CommonBusUtilBO();
		StringList slBusSelect = new StringList();
		
		slBusSelect.add(ConstantsUtil.SELECT_NAME);
		slBusSelect.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelect.add(ConstantsUtil.SELECT_TYPE);
		slBusSelect.add(ConstantsUtil.SELECT_ID);
		slBusSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
		slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ECNUMBER);
		slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONSTATUS);
		slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACHPREREGISTRATIONSTATUS);
		slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		
		StringList slRelSelect = new StringList();
		slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId=new StringBuilder();
		StringBuilder sbDesc=new StringBuilder();
		StringBuilder sbCasNum=new StringBuilder();
		StringBuilder sbECN = new StringBuilder();
		StringBuilder sbQTY=new StringBuilder();
		StringBuilder sbMReachSts = new StringBuilder();
		StringBuilder sbRPRSts = new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		
		try
		{
			
			
			String strContextType	 =  validator.getStringEquivalentForStringList(mpContextMap.get(ConstantsUtil.SELECT_TYPE));
			String strContextName	 =  validator.getStringEquivalentForStringList(mpContextMap.get(ConstantsUtil.SELECT_NAME));
			String strContextID	 =  validator.getStringEquivalentForStringList(mpContextMap.get(ConstantsUtil.SELECT_ID));
			String strContextDesc	 =  validator.getStringEquivalentForStringListWithComma(mpContextMap.get(ConstantsUtil.SELECT_DESCRIPTION));
			String strContextcurrent	 =  validator.getStringEquivalentForStringList(mpContextMap.get(ConstantsUtil.SELECT_CURRENT));
			
			util.formatData(sbType,util.mapType(strContextType));
			util.formatData(sbName,strContextName);
			util.formatData(sbDesc,strContextDesc);
			util.formatData(sbCurrent,strContextcurrent);
			util.formatData(sbId,strContextID);
			util.formatData(sbCasNum,ConstantsUtil.EMPTY_STRING);
			util.formatData(sbECN,ConstantsUtil.EMPTY_STRING);
			util.formatData(sbQTY,ConstantsUtil.EMPTY_STRING);
			util.formatData(sbMReachSts,ConstantsUtil.EMPTY_STRING);
			util.formatData(sbRPRSts,ConstantsUtil.EMPTY_STRING);
			util.formatData(sbPhase,ConstantsUtil.EMPTY_STRING);
			
			
			/*String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String strCasNum	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			String strECNum	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ECNUMBER));
			String strQty	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String strReachStatus	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REACHSTATUS));
			String strReachPreStatus	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RPRSTATUS));
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String strOrignSource	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CURRENT));
			
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);
		*/
			MapList mlObjList = comBus.getRelatedObjects(context,strContextID,ConstantsUtil.QUERY_WILDCARD,ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,slBusSelect,slRelSelect);
			
			Iterator objectListItr = mlObjList.iterator();

			while(objectListItr.hasNext())
			{
				Map resultMaps = (Map) objectListItr.next();
				
				String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
				String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
				String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
				String strDesc	 =  validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
				String strCasNum	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
				String strECNum	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ECNUMBER));
				String strQty	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
				String strReachStatus	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONSTATUS));
				String strReachPreStatus	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACHPREREGISTRATIONSTATUS));
				String strcurrent	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
				String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
				
				boolean bHasAccess = util.checkHasAccess(context, null, strID);
				
				if (!bHasAccess) {
					strID=ConstantsUtil.NO_ACCESS;
				}
				util.formatData(sbType,util.mapType(strType));
				util.formatData(sbName,strName);
				util.formatData(sbDesc,strDesc);
				util.formatData(sbCurrent,strcurrent);
				util.formatData(sbId,strID);
				util.formatData(sbCasNum,strCasNum);
				util.formatData(sbECN,strECNum);
				util.formatData(sbQTY,strQty);
				util.formatData(sbMReachSts,strReachStatus);
				util.formatData(sbRPRSts,strReachPreStatus);
				util.formatData(sbPhase,strReachPreStatus);
			
			
			}
			/*mpSubStanceResult.put(ConstantsUtil.NAME, strName);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			mpSubStanceResult.put(ConstantsUtil.CAS, strCasNum);
			mpSubStanceResult.put(ConstantsUtil.ECNUMBER, strECNum);
			mpSubStanceResult.put(ConstantsUtil.QUANTITY, strQty);
			mpSubStanceResult.put(ConstantsUtil.TYPE, strType);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION, strDesc);
			mpSubStanceResult.put(ConstantsUtil.REACHREGISTATUS, strReachStatus);
			mpSubStanceResult.put(ConstantsUtil.REACHPREREGSTATUS, strReachPreStatus);
			mpSubStanceResult.put(ConstantsUtil.PHASE, strPhase);
			mpSubStanceResult.put(ConstantsUtil.STATE, strOrignSource);*/
			
			mpSubStanceResult.put(ConstantsUtil.NAME,  sbName.toString());
			mpSubStanceResult.put(ConstantsUtil.ID,  sbId.toString());
			mpSubStanceResult.put(ConstantsUtil.CAS,  sbType.toString());
			mpSubStanceResult.put(ConstantsUtil.ECNUMBER,  sbCasNum.toString());
			mpSubStanceResult.put(ConstantsUtil.QUANTITY,  sbQTY.toString());
			mpSubStanceResult.put(ConstantsUtil.TYPE, sbType.toString());
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,  sbDesc.toString());
			mpSubStanceResult.put(ConstantsUtil.REACHREGISTATUS,  sbMReachSts.toString());
			mpSubStanceResult.put(ConstantsUtil.REACHPREREGSTATUS,  sbRPRSts.toString());
			mpSubStanceResult.put(ConstantsUtil.PHASE,  sbPhase.toString());
			mpSubStanceResult.put(ConstantsUtil.STATE,  sbCurrent.toString());
			
			//SPEC : Modified by Chandra on 05-Jan-2021 for  Requirement 38258 --END
			
		}catch(Exception ex){
			LOGGER.error("Error from APMPBO:  getSubstancesforSupplier"+ex);
			return new HashMap();
		}
		return mpSubStanceResult;
	}

	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	: 
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Context context, Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		// Guna Added for Defect 37743  18x.5.2 Release -- START
		BigDecimal dDefaultValue = BigDecimal.valueOf(0.0);
		// Guna Added for Defect 37743  18x.5.2 Release -- END
		try
		{
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			
			//Added for Defect #37503 by Amman on 11/25/2020 -- START
			//String sDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sDesc	 =  util.getTheValueWithCommas(resultMaps,ConstantsUtil.COMP_DESC);
			//Added for Defect #37503 by Amman on 11/25/2020 -- END
			
			String sTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sQTY      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			String sQTYUom   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT));
			String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT));
			String sMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			String sMFR     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MANUF));
			//<11.21.2020>: Added for #37507 START
			//String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELCOMMENT));
			//<11.21.2020>: Added for #37507 END	
			String sTrN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sPCID    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTINDUSTRIAL));
			String sPhase   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String strCurrent	 =  validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.COMP_CURRENT));
			
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			
			// Guna Added for Defect 37743  18x.5.2 Release -- START

			sPCED =util.getPostRecycledContent(new BigDecimal(sPCED),dDefaultValue);
			sPCID =util.getPostRecycledContent(new BigDecimal(sPCID),dDefaultValue);
		
			// Guna Added for Defect 37743  18x.5.2 Release -- END
			
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);
			
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
			//mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.SEQ,sFN);
			//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			mpSubStanceResult.put(ConstantsUtil.QTYUOM,sQTYUom);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.POST_INDUSTRIAL,sPCID);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.PHASE,sPhase);
			mpSubStanceResult.put(ConstantsUtil.STATE, strCurrent);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			
			//mpSubStanceResult=util.verifyOwnership(context,mpSubStanceResult);
			
			
		}catch(Exception e){
			LOGGER.error("Error from APMPBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	: 
	 */
	// Modified for the 2022x Requirement Multi Values List -- START
	public StringList addMultiList(){

		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.COMP_RELCOMMENT);
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		
		return slMultiSelects;
		// Modified for the 2022x Requirement Multi Values List -- END
	}
	
	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	: 
	 */
	public  void removeMultiList(){

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		//SPEC : Modified by Chandra on 05-Jan-2021 for  Requirement 38258  --START

		/*DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REACHSTATUS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RPRSTATUS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SUBNAME);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QSTCOMPOSITE);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ISCONTAM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_METALENVCLASS); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_POSTCONSUMER); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MANUF);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_COMENT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MARKETNAME);  	
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SEQUENCE);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MATELAYER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_POSTINDUSTRIAL);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CURRENT);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

				//<11.21.2020>: Added for #37507 START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELCOMMENT);*/
		//<11.21.2020>: Added for #37507 END

		//SPEC : Modified by Chandra on 05-Jan-2021 for  Requirement 38258  --END

		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END

	}


}
