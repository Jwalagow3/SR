package com.pg.us.specanywhere_enovia.bo;

import java.util.Map;
import java.util.concurrent.Callable;

import org.springframework.core.env.Environment;

import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;

import matrix.db.Context;

public class GTINTextsExecutor implements Callable<Map> {

	private static String Id;
	private static String Type;
	private static String Name;
	private static Context context;
	private static Environment Env;
	
	@Override
	public Map call() throws Exception 
	{
		BusExtractUtil util = new BusExtractUtil();
		//String sGtinValue = util.getGTINValue(context, mlPackingChars, Id, Type,Name, bFlag,Env);
		return util.getGTINFromSoapPO(context, Id,Type,Name,Env);
	}
	
	public GTINTextsExecutor(Context context,String Id, String Type,String Name,Environment Env)
	{
		super();
		this.Id =Id;
		this.Name =Name;
		this.Type =Type;
		this.Env =Env;
		this.context =context;
		
	}
	
	
	
	
}