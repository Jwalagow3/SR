package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaDSMReportService {
	public HashMap<String, Map<String, String>> getDSMReportData(Environment env, String sKey, String sObjId) throws Exception;
}
