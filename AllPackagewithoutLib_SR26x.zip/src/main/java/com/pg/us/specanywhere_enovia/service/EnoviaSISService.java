/*
 * SPEC: <01.08.2021>: SIS template has been Implemented for Req #35943 
 * Date : Jan 8th 2021
 */
package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaSISService {
	public HashMap<String, Map<String, String>> getSISdata(String objId, Environment env) throws Exception;
}
