/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaIRMSServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.IRMSBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaIRMSService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import com.matrixone.apps.domain.DomainConstants;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;


public class EnoviaIRMSServiceImpl  implements EnoviaIRMSService{

	private static Logger LOGGER = Logger.getLogger(EnoviaIRMSServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END

	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
	private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getIRMSdata(String objId, Environment env) throws Exception {

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("IRMS CONTEXT ELAPSED TIME : "+swContext.getTime());
		//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- END
		try {
			//SPEC: <03-11-2021>: Manikanta Commented for  Defect 45181  -- START
			/*StopWatch swContext = new StopWatch();
			swContext.start();
			Context context = pool.checkOut();
			swContext.stop();
			LOGGER.info("IRMS CONTEXT ELAPSED TIME : "+swContext.getTime());*/
			//SPEC: <03-11-2021>: Manikanta Commented for  Defect 45181  -- END
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- START
				context.close();
				//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			IRMSBO irmsbo = new IRMSBO();	
			DomainObject doIRMS =  irmsbo.getIRMSDO(context, objId);
			String strCurrent = doIRMS.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- START
					context.close();
					//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();

			Map<String, StringList> BusinessObjectSelectableMap = irmsbo.getIRMSPartSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			//modified by Ganesh for defect 39729 <2/19/2021> ------->start
			slContextSelects.add(ConstantsUtil.PSUB_PGMASTERID);
			slContextSelects.add(ConstantsUtil.PSUB_PGMASTER);
			slContextSelects.add(ConstantsUtil.PSUB_PGMASTERTYPE);
			//modified by Ganesh for defect 39729 <2/19/2021> ------->END
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			//SPEC: Release SR18x.6.0 - Commented for IRMS  by Manikanta on Date 02/03/2021 -- START
			//Map<String,String> mpWeightResult = new HashMap<String,String>();
			//SPEC: Release SR18x.6.0 - Commented for IRMS  by Manikanta on Date 02/03/2021 -- END
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
			Map<String,String> mpDerivedToResult = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpMasterAttribute = new HashMap<String,String>();
			Map<String,String> mpSpecifications = new HashMap<String,String>();
			Map<String,String> mpStartingMaterials = new HashMap<String,String>();
			Map<String,String> mpMaerialsProduced = new HashMap<String,String>();
			
			//SPEC: <10.20.2020>: Added for the Defect ## -- START
			
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			//SPEC: <10.20.2020>: Added for the Defect ## -- END
			if (null == doIRMS) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- START
				context.close();
				//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- END
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doIRMS.getInfo(context, slContextSelects);
			Map resultMaps = doIRMS.getInfo(context, slContextSelects,irmsbo.addMultiList());
			swAttributes.stop();
			LOGGER.info("IRMS GETINFO ELAPSED TIME : "+swAttributes.getTime());
			
			String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;
			String sClassifictaion = util.getClassification(resultMaps);
			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			if(bAllInfoView || bSupplierView || bManufacturerView) {
				//Basic  Data
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				//SPEC: Release SR18x.6.0 - Modified for Defect 41699  by Manikanta on Date 26/03/2021 -- START
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, ConstantsUtil.SPEC_SUB_TYPE);
				//SPEC: Release SR18x.6.0 - Modified for Defect 41699  by Manikanta on Date 26/03/2021 -- END
				//SPEC: Release SR18x.6.0 - Modified for Defect 42002  by Manikanta on Date 01/04/2021 -- START
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Modified for Defect 42002  by Manikanta on Date 01/04/2021 -- END
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MATERIALCERTIFICATIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHELFLIFE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				
				
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
				
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED) : ConstantsUtil.EMPTY_STRING);
				//Commented for Internal EBP Defect by Manikanta START
				//mpAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
				//Commented for Internal EBP Defect by Manikanta END
				String sSAPValue =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
				//SPEC: Release SR18x.6.0 - Commented for Defect 41703  by Manikanta on Date 26/03/2021 -- START
				//Jwala: 41703 this defect is talking about they need the below attribute on UI as per template. we should not comment this
				mpAttribResult.put(ConstantsUtil.PRODUCEDBYFORMULA, ConstantsUtil.CONSTANT_STRING_ROH.equals(sSAPValue)?ConstantsUtil.SYMBL_NO: ConstantsUtil.SYMBL_YES);
				//SPEC: Release SR18x.6.0 - Commented for Defect 41703  by Manikanta on Date 26/03/2021 -- END
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
				//SPEC: 07/18/2022: Added for Defect#42009 by Pooja-- START
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 07/18/2022: Added for Defect#42009 by Pooja-- END
				
				
				//HeaderContent
				mpHeaderContent.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				//Modified by Manikanta for internal defect 28/04/2021 START
				if(!bManufacturerView && !bSupplierView){
					mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				}
				//Modified by Manikanta for internal defect 28/04/2021 END
				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
				//SPEC: <30.08.2022>: Guna Modified for 50469 Defect   Dev 22x    -- START
				String masterId = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.PSUB_PGMASTERID));
				String masterName = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.PSUB_PGMASTER));
				if (UIUtil.isNotNullAndNotEmpty(masterId)) {
					DomainObject obj =  DomainObject.newInstance(context,masterId);
					String masterState = obj.getInfo(context, DomainConstants.SELECT_CURRENT);
					obj.close(context);
					
					boolean showData = util.checkHasAccess(context, sUserType, masterId);
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
					if(util.isModificatinRequired() && !showData) {
							masterId = ConstantsUtil.EMPTY_STRING;
							masterName =ConstantsUtil.EMPTY_STRING;
					}else {
					if (!showData) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
					}
					
					if(masterState.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
						masterName = DomainConstants.EMPTY_STRING;
						masterId = ConstantsUtil.EMPTY_STRING;
					}
				}
				mpHeaderContent.put(ConstantsUtil.MASTERPARTID, masterId);
				mpHeaderContent.put(ConstantsUtil.MASTERPARTNAME, masterName);
				mpHeaderContent.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.PSUB_PGMASTERTYPE))));
				//SPEC: <30.08.2022>: Guna Modified for 50469 Defect   Dev 22x    -- END
				//Notes 
				MasterCOPBO mcop = new MasterCOPBO();
				mpNotes=mcop.updateNotes(context, resultMaps);
				
				//Starting Materials 
				mpStartingMaterials.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpStartingMaterials.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_NAME) : ConstantsUtil.EMPTY_STRING);
				mpStartingMaterials.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpStartingMaterials.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpStartingMaterials.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_TITLE)  : ConstantsUtil.EMPTY_STRING);
				mpStartingMaterials.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_STATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_STARTINGMATERIAL_STATE) : ConstantsUtil.EMPTY_STRING);		
				//SPEC: Release SR18x.6.0 - Added for IRMS  by Manikanta on Date 10/03/2021 -- START
				//SPEC: Release SR18x.6.0 - Modified for Req- 33481 by Manikanta on Date 20/03/2021 -- START
				if(bSupplierView || bManufacturerView) {
				//SPEC: Release SR18x.6.0 - Modified for Req- 33481 by Manikanta on Date 20/03/2021 -- END
					mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: Release SR18x.6.0 - Added for IRMS  by Manikanta on Date 10/03/2021 -- END
				if(bSupplierView || bManufacturerView) {
					mpStartingMaterials=util.filterPhase(mpStartingMaterials);
				}

				
				//Weight
				//SPEC: Release SR18x.6.0 - Commented for IRMS  by Manikanta on Date 02/03/2021 -- START
				/*
				mpWeightResult.put(ConstantsUtil.TYPE, util.mapType(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpWeightResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult = util.filterMapList(mpWeightResult);*/
				//SPEC: Release SR18x.6.0 - Commented for IRMS  by Manikanta on Date 02/03/2021 -- END
				
				//Reference Docs
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = irmsbo.updateRefDocs(context, resultMaps);
				swReference.stop();
				LOGGER.info("IRMS Reference ELAPSED TIME : "+swReference.getTime());
				
				//Master Attribute Data
				String sMasterID= (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID) : ConstantsUtil.EMPTY_STRING);
				if(validator.isNotNullOrEmpty(sMasterID)){
					StopWatch swMasterAttrib = new StopWatch();
					swMasterAttrib.start();
					mpMasterAttribute = irmsbo.getMasterAttributeData(context,sMasterID);
					if(bSupplierView || bManufacturerView) {
						mpMasterAttribute=util.filterPhase(mpMasterAttribute);
					}
					swMasterAttrib.stop();
					LOGGER.info("IRMS GET MASTER ATTRIB ELAPSED TIME : "+swMasterAttrib.getTime());
				}
				
			}
			
			if(bAllInfoView){
				
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: 11/29/2020: Commented for #37653 -- START
				//mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
				//mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_SAP_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_SAP_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 11/29/2020: Commented for #37653 -- START
				
				mpAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Commented for IRMS Supplier View by Manikanta on Date 15/03/2021 -- START
				//mpProfileIdResult.put(ConstantsUtil.STANDARDCOSTPERKG, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STANDARDCOSTPERKG)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STANDARDCOSTPERKG) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Commented for IRMS Supplier View by Manikanta on Date 15/03/2021 -- END
				//SPEC: <10.20.2020>: Commented for req 18x.5 ## -- START
				
				//mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING));
				//mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_SAP_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_SAP_CURRENT) : ConstantsUtil.EMPTY_STRING);
				//mpAttribResult.put(ConstantsUtil.ONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				//mpAttribResult.put(ConstantsUtil.ISBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
				//mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
				//mpAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING));
				//mpAttribResult.put(ConstantsUtil.PGASLALLOCATION, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING));
				
				//SPEC: <10.20.2020>: Commented for req 18x.5 ## -- END
				
				/**
				 * Organization Data
				 */
				//SPEC: Release SR18x.5.2: Modified for Defect 38797 by Amman ## -- START
				/*
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				// SPEC: 02/04/2021: Added for Defect 38797 -- START
				//mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				StringBuilder sbSecondaryOrg = irmsbo.getSecondaryOrganization(context, doIRMS);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, sbSecondaryOrg.toString());
				// SPEC: 02/04/2021: Added for Defect 38797 -- END
				*/
				//SPEC: <08-19-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
				//mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)));
				//mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)));
				
				if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {
					
					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} 
					else 
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
				}
				
				if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {
				
					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
					{
						mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
					} else 
					{
						mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					}
				} else {
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, DomainConstants.EMPTY_STRING);
				}
				//SPEC: <08-19-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
				//SPEC: Release SR18x.5.2: Modified for Defect 38797 by Amman ## -- END
				
				mpOrganization = util.filterMapList(mpOrganization);
				
				//Specifications
				mpSpecifications = irmsbo.getSpecifications(context, resultMaps);
				mpSpecifications = util.filterMapList(mpSpecifications);
				
				//Derived Data
				StopWatch swDerived = new StopWatch();
				swDerived.start();
				String sDName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
				String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
				String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING;
				
				mpDerivedFromResult = irmsbo.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doIRMS,true,false);
				mpDerivedToResult = irmsbo.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doIRMS,false,true);
				
				
				mpDerivedFromResult = util.filterMapList(mpDerivedFromResult);
				mpDerivedToResult = util.filterMapList(mpDerivedToResult);
				swDerived.stop();
				LOGGER.info("IRMS Derived ELAPSED TIME : "+swDerived.getTime());

				//Security
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO commonBo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =commonBo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				LOGGER.info("IRMS Security ELAPSED TIME : "+swSecurity.getTime());

				//Materials Produced
				StopWatch swMaterial = new StopWatch();
				swMaterial.start();
				IRMSBO irmsBo = new IRMSBO();
				mpMaerialsProduced = irmsBo.getMaterialProduced(context,sContextObjectId);
				if(bManufacturerView) {
					mpMaerialsProduced=util.filterPhase(mpMaerialsProduced);
				}
				mpMaerialsProduced = util.filterMapList(mpMaerialsProduced);
				swMaterial.stop();
				LOGGER.info("IRMS MATERIALS ELAPSED TIME : "+swMaterial.getTime());
				
				/**
				 * LOAD IP CLASSES SECTION
				 */
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
				
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIpSecuritySetting =IRMSBO.getIpClass(context, doIRMS, slIpSelects);
				
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
				
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
				
				//R&D SITES
				StringList objectSelects = new StringList();
				objectSelects.add(ConstantsUtil.SELECT_ID);
				objectSelects.add(ConstantsUtil.SELECT_CURRENT);
				objectSelects.add(ConstantsUtil.SELECT_NAME);
				objectSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHORTCODE);
				//Release SR18x.5.2 - Modified for Defect#39299 by Govind On Date 10/02/2021 start
				objectSelects.add(ConstantsUtil.SELECT_TYPE);
				StringBuilder sbtype = new StringBuilder();
				//Release SR18x.5.2 - Modified for Defect#39299 by Govind On Date 10/02/2021 end
				StringList lstRelSelects = new StringList(ConstantsUtil.SELECT_RELATIONSHIP_ID);

				MapList returnMapList=doIRMS.getRelatedObjects(context, 
						ConstantsUtil.RELATIONSHIP_ALLOCATION_RESPONSIBILITY,
						"*", 
						objectSelects, 
						lstRelSelects, 
						true,
						false,
						(short) 1,
						ConstantsUtil.EMPTY_STRING, 
						ConstantsUtil.EMPTY_STRING,
						0);
				Iterator objectListItr = returnMapList.iterator();
				//Iterator objectListItr = returnMapList.iterator();
				StringBuilder sbName = new StringBuilder();
				StringBuilder sbDesc = new StringBuilder();
				StringBuilder sbState = new StringBuilder();
				StringBuilder sbShortCode = new StringBuilder();
				StringBuilder sbId = new StringBuilder();
				
				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					String sState = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
					String sDesc = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
					String sId = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sShortCode = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHORTCODE));
					util.formatData(sbName, sName);
					util.formatData(sbState, sState);
					util.formatData(sbDesc, sDesc);
					util.formatData(sbShortCode, sShortCode);
					util.formatData(sbId, sId);
					//Release SR18x.5.2 - Modified for Defect#39299 by Govind On Date 10/02/2021 start
					String stype = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
					util.formatData(sbtype, stype);
					//Release SR18x.5.2 - Modified for Defect#39299 by Govind On Date 10/02/2021 end
				}
								
				//SPEC: <10.12.2020>: Added for req 18x.5 ## -- END
				
			}
			
			//SPEC: Release SR18x.6.0 - Modified for IRMS Supplier View by Manikanta on Date 15/03/2021 -- START
			//SPEC: Release SR18x.6.0 - Modified for Req- 33481 by Manikanta on Date 20/03/2021 -- START
			if(bSupplierView || bManufacturerView) {
			//SPEC: Release SR18x.6.0 - Modified for Req- 33481 by Manikanta on Date 20/03/2021 -- END
				
				//Security
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO commonBo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =commonBo.updateSecurity(context,resultMaps);
				swSecurity.stop();
				LOGGER.info("IRMS Security ELAPSED TIME : "+swSecurity.getTime());
				//IP Class
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIpSecuritySetting =IRMSBO.getIpClass(context, doIRMS, slIpSelects);
				//Organization
				//SPEC: <08-19-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
				//mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)));
				//mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)));
				
				if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {
					
					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} 
					else 
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
				}
				
				if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {
				
					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
					{
						mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
					} else 
					{
						mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					}
				}
				//SPEC: <08-19-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
				mpOrganization = util.filterMapList(mpOrganization);
			}
			//SPEC: Release SR18x.6.0 - Modified for IRMS Supplier View by Manikanta on Date 15/03/2021 -- END

			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- START
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- END
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			//SPEC: Release SR18x.6.0 - Modified for IRMS  by Manikanta on Date 12/03/2021 -- START
			//SPEC: Release SR18x.6.0 - Modified for Req- 33481 by Manikanta on Date 20/03/2021 -- START
			if(!bSupplierView && !bManufacturerView) {
			//SPEC: Release SR18x.6.0 - Modified for Req- 33481 by Manikanta on Date 20/03/2021 -- END
				hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			}
			//SPEC: Release SR18x.6.0 - Modified for IRMS  by Manikanta on Date 12/03/2021 -- END
			//SPEC: Release SR18x.6.0 - Commented for IRMS  by Manikanta on Date 02/03/2021 -- START
			//hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
			//SPEC: Release SR18x.6.0 - Commented for IRMS  by Manikanta on Date 02/03/2021 -- END
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- START
			if(bAllInfoView) {
				mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			}
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- END
			
			//SPEC: <10.20.2020>: Commented for req 18x.5 ## -- START
			
//			hmAttrib.put(ConstantsUtil.MASTERATTRIBUTES, mpMasterAttribute);
//			hmAttrib.put(ConstantsUtil.MATERIALPRODUCED, mpMaerialsProduced);
//			hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
//			hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO,mpDerivedToResult);
//			hmAttrib.put(ConstantsUtil.STARTINGMATERIALS, mpStartingMaterials);
//			hmAttrib.put(ConstantsUtil.SPECIFICATIONS, mpSpecifications);
		
			//SPEC: <10.20.2020>: Commented for req 18x.5 ## -- END
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- START
			if(bAllInfoView) {
				mpIpSecuritySetting.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
			}
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- END
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			pool.checkIn(context);
			sp.stop();
			//SPEC: <08-13-2021>: Manikanta Added for Stress Testing Defect 44365  -- START
			doIRMS.close(context);
			//SPEC: <08-13-2021>: Manikanta Added for Stress Testing Defect 44365  -- END
			LOGGER.info("IRMS MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "IRMS OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));

		} catch (IOException e) {
			LOGGER.error("Unable to getIRMSdata"+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getIRMSdata"+e);
		}
		//LOGGER.info("IRMS RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- START
		context.close();
		//SPEC: <03-11-2021>: Manikanta Added for  Defect 45181  -- END
		return hmAttrib;
	}

}