package com.pg.us.specanywhere_enovia.utility;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class CryptoUtil {

	private static final String ENCRYPT_ALG = "AES/GCM/NoPadding";
	private static final int KEY_SIZE = 32; // 256 bits = 32 bytes
	private static final int GCM_IV_LENGTH = 12;
	private static final int GCM_TAG_LENGTH = 128;

	public static String encryptString(String sClearText, String sKey, String sFile) throws Exception {

		try {
			byte[] decodedKey;

			// Read key
			if (sFile == null || sFile.trim().isEmpty()) {
				decodedKey = sKey.getBytes(StandardCharsets.UTF_8);
			} else {
				try (FileInputStream in = new FileInputStream(sFile)) {
					String fileKey = new String(in.readAllBytes(),StandardCharsets.UTF_8).trim();
					decodedKey = fileKey.getBytes(StandardCharsets.UTF_8);

				}
			}

			// Validate AES-256 key
			if (decodedKey.length != KEY_SIZE) {
				throw new IllegalArgumentException(
						"Invalid AES key length. Expected 32 bytes."
						);
			}

			SecretKey key = new SecretKeySpec(decodedKey, "AES");

			// Generate IV
			byte[] iv = new byte[GCM_IV_LENGTH];
			SecureRandom secureRandom = new SecureRandom();
			secureRandom.nextBytes(iv);

			// Encrypt
			Cipher cipher = Cipher.getInstance(ENCRYPT_ALG);

			GCMParameterSpec gcmSpec =
					new GCMParameterSpec(GCM_TAG_LENGTH, iv);

			cipher.init(Cipher.ENCRYPT_MODE, key, gcmSpec);

			byte[] cipherText =
					cipher.doFinal(sClearText.getBytes(StandardCharsets.UTF_8));

			int totalLength = Math.addExact(iv.length, cipherText.length);
			byte[] encryptedData =
					new byte[totalLength];
			
			System.arraycopy(iv, 0,
					encryptedData, 0,
					iv.length);

			System.arraycopy(cipherText, 0,
					encryptedData, iv.length,
					cipherText.length);

			return Base64.getEncoder()
					.encodeToString(encryptedData);

		} catch (GeneralSecurityException e) {
			throw new GeneralSecurityException("Encryption failed",e);
		}
	}

	public static String decryptString(String sEncrypted, String sKey, String sFile) throws Exception {

		try {

			byte[] decodedKey;

			// Read key
			if (sFile == null || sFile.trim().isEmpty()) {
				decodedKey =
						sKey.trim().getBytes(StandardCharsets.UTF_8);

			} else {
				try (FileInputStream in =
						new FileInputStream(sFile)) {

					String fileKey =
							new String(
									in.readAllBytes(),
									StandardCharsets.UTF_8)
							.trim();

					decodedKey =
							fileKey.getBytes(
									StandardCharsets.UTF_8);
				}
			}

			// Validate key length
			if (decodedKey.length != 32) {
				throw new IllegalArgumentException(
						"Invalid AES key length. Expected 32 bytes.");
			}

			SecretKey key =
					new SecretKeySpec(decodedKey, "AES");

			// Decode encrypted data
			byte[] encryptedBytes =
					Base64.getDecoder()
					.decode(sEncrypted);

			// Extract IV
			byte[] iv =
					Arrays.copyOfRange(
							encryptedBytes,
							0,
							GCM_IV_LENGTH);

			// Extract CipherText
			byte[] cipherText =
					Arrays.copyOfRange(
							encryptedBytes,
							GCM_IV_LENGTH,
							encryptedBytes.length);

			Cipher cipher =
					Cipher.getInstance(ENCRYPT_ALG);

			GCMParameterSpec gcmSpec =
					new GCMParameterSpec(
							GCM_TAG_LENGTH,
							iv);

			cipher.init(
					Cipher.DECRYPT_MODE,
					key,
					gcmSpec);

			byte[] decrypted =
					cipher.doFinal(cipherText);

			return new String(
					decrypted,
					StandardCharsets.UTF_8);

		} catch (GeneralSecurityException e) {
			throw new GeneralSecurityException("Decrypted failed",e);
		}
	}

	public static String makeSecretKey(String sFile) throws Exception {

		try {
			//Added by Jwala for the defect 139678 - START
			// Generate AES key
			KeyGenerator generator = KeyGenerator.getInstance(ENCRYPT_ALG);
			generator.init(KEY_SIZE, SecureRandom.getInstanceStrong());
			SecretKey secretKey = generator.generateKey();
			//Added by Jwala for the defect 139678 - END
			
			//Commented by Jwala for the defect 139678 - START
			//KeyGenerator generator = KeyGenerator.getInstance(ENCRYPT_ALG, "SunJCE");
			//byte[] encodedKey = secretkey.getEncoded();
			//String b64encodedKey = new String(java.util.Base64.getMimeEncoder().encode(encodedKey));
			//Commented by Jwala for the defect 139678 - START

			// Convert key to Base64
			String b64EncodedKey =Base64.getEncoder().encodeToString(secretKey.getEncoded());

			//Commented by Jwala for the defect 139678 - START
			/*
			 * if (!sFile.equals("")) { try(FileOutputStream out = new
			 * FileOutputStream(sFile)) { out.write(b64EncodedKey.getBytes()); out.flush();
			 * } }
			 */
			//Commented by Jwala for the defect 139678 - END

			// Write to file if path provided
			if (sFile != null && !sFile.trim().isEmpty()) {
				try (FileOutputStream out = new FileOutputStream(sFile)) {
					out.write(b64EncodedKey.getBytes(StandardCharsets.UTF_8));
				}
			}

			return b64EncodedKey;

		} catch (Exception e) {
			throw new Exception("Failed to generate secret key", e);
		}
	}
}
