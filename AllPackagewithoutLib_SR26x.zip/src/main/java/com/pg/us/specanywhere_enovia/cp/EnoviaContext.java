package com.pg.us.specanywhere_enovia.cp;

import org.apache.log4j.Logger;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.matrixone.apps.domain.util.ContextUtil;

import matrix.db.Context;
import matrix.util.MatrixException;

//@Component
public class EnoviaContext {
	
	private static Logger LOGGER = Logger.getLogger(EnoviaContext.class);
	private static Context context;
	private static String user;
	private static String pass;
	private static String vault;
	

	public EnoviaContext(String USER, String PASS, String VAULT) {
		super();
		this.user = USER;
		this.pass = PASS;
		this.vault = VAULT;
	}
	
	public Context getEnoviaContext() {
		try {
			LOGGER.info("CLASS: EnoviaContext : METHID: getEnoviaContext");
			System.out.println("getEnoviaContext");
			context = new Context("");
			context.setUser(user);
			context.setPassword(pass);
			context.setVault(vault);
			System.out.println("-------------------");
			System.out.println("*CP CONTEXT NEW START*");
			System.out.println("-------------------");
			context.connect();
			LOGGER.info("SessionID: "+context.getSession().getSessionId());
			System.out.println("-------------------");
			System.out.println("----CP CONTEXT CONNECTED----");
			System.out.println("-------------------");

		} catch (MatrixException ex) {
			LOGGER.info("EXCEPTION IN ENOVIACONTEXT::getEnoviaContext : "+ex);
			ex.printStackTrace();
		}
		return context;
	}
	
	public Context getEnoviaContextThread()  {

		try {
			System.out.println("getEnoviaContextThread");
			
				context = getEnoviaContext();
			
		} catch (Exception e) {
			System.out.println("Exception:getEnoviaContextThread() ");
			LOGGER.info("EXCEPTION IN ENOVIACONTEXT::getEnoviaContextThread : "+e);
			e.printStackTrace();
			
		}
		return context;
	}
}
