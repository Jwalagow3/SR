package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaPOAARTService {
	public HashMap<String, Map<String, String>> getPOAARTData(String objId, String SComp, Environment env) throws Exception;
}
