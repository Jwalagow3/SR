/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaIMPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.EMPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaEMPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaEMPServiceImpl implements EnoviaEMPService{

	private static Logger LOGGER = Logger.getLogger(EnoviaEMPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
	private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getEMPdata(String objId, Environment env)
			throws Exception 
	{

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("EMP SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());
		SecurityService sct = new SecurityService();
		//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
		String sUserType = sct.getUserType();
		BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
		//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
		if (UIUtil.isNotNullAndNotEmpty(sUserType)) {
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
		}
		//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
		//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END

		EMPBO empbo = new EMPBO();
		try 
		{
			/**
			 * User Profile Section
			 * */
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;

			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);

			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				bManufacturerView = true;
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				bSupplierView = true;
			} else {
				switch (sUserType) {
				case ConstantsUtil.PG:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PGSTAFF:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PG_CM:
					bManufacturerView = true;
					break;

				case ConstantsUtil.PG_SP:
					bSupplierView = true;
					break;
				}

			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpMaterialResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpHeaderResult = new HashMap<String,String>();

			BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = empbo.getEMPSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

			DomainObject dobEMP = new DomainObject(objId);
			StopWatch swInfo = new StopWatch();
			swInfo.start();
			Map resultMaps = dobEMP.getInfo(context, slContextSelects);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobEMP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			swInfo.stop();
			LOGGER.info("EMP SERVICE GETINFO ELAPSED TIME : "+swInfo.getTime());


			//Header Content
			StopWatch sHeader = new StopWatch();
			sHeader.start();

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING));		
			mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			String sClassification = util.getClassification(resultMaps);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
			sHeader.stop();
			LOGGER.info("EMP Header ELAPSED TIME : "+sHeader.getTime());


			//Attribute Data
			mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));

			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);

			String user = (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_OWNER)));
			String owner = PersonUtil.getFullName(context,user);
			mpAttribResult.put(ConstantsUtil.OWNER, owner);
			//Added by Pooja for the req 42769,34417 -- START
			if(!bAllInfoView)
			{
				mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty(((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)).replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED)))?((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)).replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED) : ConstantsUtil.EMPTY_STRING);
			}
			//Added by Pooja for the req 42769,34417 -- END
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.POLICY)))?(String)resultMaps.get(ConstantsUtil.POLICY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.VAULT)))?(String)resultMaps.get(ConstantsUtil.VAULT) : ConstantsUtil.EMPTY_STRING);
			String sClassFiedID=validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID) : ConstantsUtil.EMPTY_STRING;
			String sClassFiedName=validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME) : ConstantsUtil.EMPTY_STRING;
			if(bAllInfoView)
			{
				String sMaterial = util.getMaterial(context,sClassFiedID,sClassFiedName);
				mpAttribResult.put(ConstantsUtil.MATERIALFAMILY,sMaterial); 
			}
			String sClassifictaion = util.getClassification(resultMaps);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MANUFACTURER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GPSORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_MCPRF)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_MCPRF) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.POST_INDUSTRIAL, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtilIRM.EXTERNALREVISIONLEVEL, ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtilIRM.EXTERNALREVISIONDATE,((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONDATE)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONDATE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtilIRM.INTERNALMATERIALNUMBER, ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALNUMBER)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALNUMBER) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtilIRM.STANDARDMATERIALNUMBER, ((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER) : ConstantsUtil.EMPTY_STRING));

			/**
			 *  MATERIALS SECTION
			 * 
			 * */
			mpMaterialResult = empbo.getMaterialComposition(context, resultMaps);
			if(bSupplierView || bManufacturerView) 
			{
				mpMaterialResult=util.filterPhase(mpMaterialResult);
				mpMaterialResult = util.filterMapList(mpMaterialResult);
			}

			String strMaterial = validator.getStringEquivalentForStringList(mpMaterialResult.get(DomainConstants.SELECT_NAME));
			strMaterial = strMaterial.substring(0, strMaterial.length() -1);

			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */
			StopWatch swReference= new StopWatch();
			swReference.start();
			MasterCOPBO mcop = new MasterCOPBO();
			mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);

			swReference.stop();
			LOGGER.info("EMP REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());

			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);

			if(mpMaterialResult.size()!=1 && !(strMaterial.equalsIgnoreCase(mpHeaderResult.get(DomainConstants.SELECT_NAME)))) {
				hmAttrib.put(ConstantsUtil.MATERIALS, mpMaterialResult);
			}
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
			dobEMP.close(context);
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
			context.close();
			//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
			pool.checkIn(context);
			sp.stop();
		}catch (Exception e) {
			LOGGER.error("Exception in EMP Service IMPL: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}

		//LOGGER.info("EMP SERVICE RESPONSE MESSAGE:: \n" + hmAttrib);
		if(null!=context) {
			context.close();//Added for Defect 45181
		}
		return hmAttrib;


	}

}
