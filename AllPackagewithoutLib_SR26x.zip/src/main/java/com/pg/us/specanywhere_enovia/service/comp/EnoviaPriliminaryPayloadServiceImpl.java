package com.pg.us.specanywhere_enovia.service.comp;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaPriliminaryPayloadService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaAPPServiceImpl;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaPriliminaryPayloadServiceImpl implements EnoviaPriliminaryPayloadService {
	private static Logger LOGGER = Logger.getLogger(EnoviaAPPServiceImpl.class);
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	
	@Autowired
	private EnoviaConnectionPool pool;
	@Override
	public Map<String, String> getPriliminaryPayLoaddata(Environment env, String sObjectName) {
		// TODO Auto-generated method stub
		Map<String, String> hmAttrib = new HashMap<String, String>();
		MapList finalMapList = new MapList();
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();

		try {
			StringList slObjectsSelect = new StringList();
			slObjectsSelect.add(DomainConstants.SELECT_ID);
			slObjectsSelect.add(DomainConstants.SELECT_TYPE);
			slObjectsSelect.add(DomainConstants.SELECT_NAME);
			
			
			finalMapList = DomainObject.findObjects
						(context, //MatrixContext
						DomainConstants.QUERY_WILDCARD, //typePattern
						sObjectName, //namePattern
						DomainConstants.QUERY_WILDCARD, //revPattern
						DomainConstants.QUERY_WILDCARD, //ownerPattern
						ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
						ConstantsUtilIRM.CURRENT_ST_PRELIMINARY, //whereExpression
						false, //expandType
						slObjectsSelect); 
			
			hmAttrib = (Map<String, String>)finalMapList.get(0);
			String sType = util.mapType((validator.isNotNullOrEmpty((String)hmAttrib.get(ConstantsUtil.SELECT_TYPE)))?(String)hmAttrib.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
			
			if((sType.contains(ConstantsUtilIRM.ASL)) || (sType.contains(ConstantsUtilIRM.BSF)) || (sType.contains(ConstantsUtilIRM.FC)) || (sType.contains(ConstantsUtilIRM.MPS)) || (sType.contains(ConstantsUtilIRM.tPSUB)) || (sType.contains(ConstantsUtilIRM.SIS)) ) {
				
				hmAttrib.put(ConstantsUtilIRM.E120, ConstantsUtilIRM.ERROR_CSSTYPES);
				
			}
			else {
				sType = getTypeCode(sType.trim());
				hmAttrib.put(DomainConstants.SELECT_TYPE, sType);
			}
			
		} catch (Exception ex) {
			LOGGER.error("Error from BusObjAttribUtil: getPriliminaryData" + ex);
			
		}
		context.close();
		return hmAttrib;
		
	}
	public String getTypeCode(String typeName)
	{
	    switch(typeName)
	    {
	        case "Ancillary Packaging Material Part":
	            return "APMP";
	        case "Ancillary Raw Material Part":
	            return "ARMP";
	        case "Approved Supplier List":
	            return "ASL";
	        //Added for Defect 137172   -- START
	        case "Art":
	            return "POA";
	        //Added for Defect 137172   -- END
	        case "Assembled Product Part":
	            return "APP";
	        case "Authorized Configuration Standard":
	            return "COM/ACS";
	        case "Authorized Temporary Specification":
	            return "COM/ATS";
	        case "Base Formula":
	            return "BSF";
	        case "Consumer Unit Part":
	            return "COP";
	        case "Customer Unit Part":
	            return "CUP";
	        case "Device Product Part":
	            return "DPP";
	        case "Fabricated Part":
	            return "FAB";
	        case "Finished Product":
	            return "FP";
	        case "Finished Product Part":
	            return "FPP";
	        case "Formula Card":
	            return "FC";
	        case "Formulation Part":
	            return "FOP";
	        case "Illustration":
	            return "COM/ILST";
	        case "Inner Pack":
	            return "IP";
	        case "Intermediate Assembled Product Specification":
	            return "COM/IAPS";
	        case "Intermediate Product Part":
	            return "IPP";
	        case "IRM Documents":
	            return "IRMDOC";
	        case "Laboratory Index Specification":
	            return "COM/LIS";
	        case "Making Instruction":
	            return "COM/MI";
	        case "Master Consumer Unit Part":
	            return "MCOP";
	        case "Master Customer Unit Part":
	            return "MCUP";
	        case "Master Inner Pack":
	            return "MIP";
	        case "Master Packaging Assembly Part":
	            return "MPAP";
	        case "Master Packaging Material Part":
	            return "MPMP";
	        case "Master Packaging Material Specification":
	            return "MPMS";
	        case "Master Packing Standard":
	            return "MPS";
	        case "Master Product Part":
	            return "MPP";
	        case "Master Raw Material Part":
	            return "MRMP";
	        case "Master Raw Material Specification":
	            return "MRMS";
	        case "Online Printing Part":
	            return "OPP";
	        case "Piece of Art":
	            return "POA";
	        case "Packaging Assembly Part":
	            return "PAP";
	        case "Packaging Material Part":
	            return "PMP";
	        case "Packing Instruction":
	            return "COM/PI";
	        case "Packing Subassembly":
	            return "PSUB";
	        case "Process Standard":
	            return "COM/PROS";
	        case "Promotional Item Part":
	            return "PIP";
	        case "Quality Specification":
	            return "COM/QUAL";
	        case "Raw Material":
	            return "RMP";
	        case "Raw Material IRMS":
	            return "RM-IRMS";
	        case "Standard Operating Procedure":
	            return "COM/SOP";
	        case "Supplier Information Sheet":
	            return "SIS";
	        case "Test Method Specification":
	            return "COM/TMS";
	        case "Transport Unit Part":
	            return "TUP";
	        case "Stacking Pattern Specification":
	            return "COM/SP";
	        case "Raw Material Plant Instruction":
	            return "COM/RMPI";
	        case "Innovation Record":
	        case "Consumer Research":
	        case "Stability Report":
	        case "General Innovation Record":
	        case "Validation Protocol":
	        case "Core Innovation Record":
	        case "Stability Out Of Spec Report":
	        case "Validation Report":
	        case "Stability Other":
	        case "Validation Other":
	        case "Translation File":
	        case "Stability Protocol":
	        case "Technical Rationale":
	        case "Packaging Minimization Report":
	            return "COM/IRM";
	        //Added for Defect 137172   -- START
	        case "Software Part":
	            return "SWP";
	        //Added for Defect 137172   -- END
	        default:
	            return "Null";
	    }
	}

}
