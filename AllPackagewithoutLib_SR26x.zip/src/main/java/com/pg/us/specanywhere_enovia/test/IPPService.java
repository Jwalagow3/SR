package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.pg.us.specanywhere_enovia.bo.APMPBO;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.InnerPackBO;
import com.pg.us.specanywhere_enovia.bo.IntermediateProductPartBO;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class IPPService {

	private static Logger LOGGER = Logger.getLogger(IPPService.class);
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();
		
		String oid = "20336.41905.23040.62726";
		EnoviaConnectionPool pool = new EnoviaConnectionPool();
	    Context context = pool.checkOut();
	    
	    HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
	    
	    Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mapPlantResult = new HashMap<String,String>();
		
		
		
		IntermediateProductPartBO IPPBO = new IntermediateProductPartBO();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, StringList> BusinessObjectSelectableMap = IPPBO.getIPPPartSelectables(context);
		Map<String, StringList> ChilsObjectSelectableMap = InnerPackBO.getIPRelatedObjsSelectableMap(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get("busSelect");
		StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get("busSelect");
		StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get("relSelect");
		StringValidatorUtil validator = new StringValidatorUtil();
		DomainObject doIPP =  IPPBO.getIPPDO(context, oid);
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_HISTORY);
		DomainConstants.MULTI_VALUE_LIST.add("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_NAME);
		DomainConstants.MULTI_VALUE_LIST.add("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.add("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.add("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to.from["
				+ ConstantsUtil.RELATIONSHIP_PGPRIMARYORGANIZATION + "].to." + ConstantsUtil.SELECT_NAME);
		DomainConstants.MULTI_VALUE_LIST.add("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_REVISION);
		DomainConstants.MULTI_VALUE_LIST.add("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_OWNER);
		DomainConstants.MULTI_VALUE_LIST.add("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_ORIGINATED);
		DomainConstants.MULTI_VALUE_LIST.add("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"].from."+ConstantsUtil.SELECT_NAME);
		DomainConstants.MULTI_VALUE_LIST.add("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"]."+ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
		DomainConstants.MULTI_VALUE_LIST.add("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"]."+ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
		DomainConstants.MULTI_VALUE_LIST.add("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"]."+ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.add("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"]."+ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);		
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doIPP.getInfo(context, slContextSelects);
		swAttributes.stop();
		System.out.println("IPP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_HISTORY);
		DomainConstants.MULTI_VALUE_LIST.remove("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to.from["
				+ ConstantsUtil.RELATIONSHIP_PGPRIMARYORGANIZATION + "].to." + ConstantsUtil.SELECT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_OWNER);
		DomainConstants.MULTI_VALUE_LIST.remove("from[" + ConstantsUtil.RELATIONSHIP_DERIVED + "].to." + ConstantsUtil.SELECT_ORIGINATED);
		DomainConstants.MULTI_VALUE_LIST.remove("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"].from."+ConstantsUtil.SELECT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"]."+ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
		DomainConstants.MULTI_VALUE_LIST.remove("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"]."+ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"]."+ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove("to["+ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY+"]."+ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);

		StringList slHistoryInfo = (StringList)resultMaps.get(ConstantsUtil.SELECT_HISTORY);
		String lastUpdatedUser = util.getLastUpdateUser(slHistoryInfo);
		//BOM
		StopWatch swBom = new StopWatch();
		swBom.start();
		MapList mapList = doIPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, "*", slChildBusSelects , slChildRelSelects, false, true, (short)1,"","", 0);
		pool.checkIn(context);
		swBom.stop();
		System.out.println("IPP BOM ELAPSED TIME : "+swBom.getTime());
		//Basic  Data
		//mpAttribResult.put("title", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_V_NAME)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_V_NAME) : ConstantsUtil.EMPTY_STRING);
		//mpAttribResult.put("description", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_V_NAME)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_V_NAME) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("IsBattery", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("DoesBatteryContains", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("batteryType", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("printingprocess", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.strPRINTINGPROSS)))?(String)resultMaps.get(ConstantsUtil.strPRINTINGPROSS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("type", util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put("specificationSubType", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("originator", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("lastUpdateUser", (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("revision", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("originated", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("phase", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("owner", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("releaseDate", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("effectiveDate", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("expirationDate", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("previousRevisionObsoleteDate", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("isProductCertificationOrLocalStandardsComplianceStatementRequired", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("productDosePerUse", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("productDosePerUseUom", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("expectedFrequencyofUse", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("expectedFrequencyofUseUom", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("modeOfProductDisposal", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("partFamily", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("reasonForChange", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("brand", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("marketingSize", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("baseUnitOfMeasure", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("localDescription", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("otherNames", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("comments", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("grossWeight", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("grossWeightUnitofMeasure", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("netWeightofProductinCu", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("netWeightofProductinCuUom", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("crushIndex", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("id", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("name", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("state", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("policy", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("modified", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("vault", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_VAULT)))?(String)resultMaps.get(ConstantsUtil.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("status", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("comment", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("obsoleteDate", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("obsoleteComment", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		//mpAttribResult.put(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put("alternativeUnitofMeasure", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		//mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
		String sClassifictaion = util.getClassification(resultMaps);
		mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
		mpAttribResult.put(ConstantsUtil.DIMENSIONUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DIMENSTION_UOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DIMENSTION_UOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONHEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONDEPTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={oid,sPhysicalId};
		StopWatch swLifecycle = new StopWatch();
		swLifecycle.start();
		mpLifeCycleApproval = util.getCOName(context, changeargs);
		swLifecycle.stop();
		System.out.println("IPP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
		mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
		String strApproverName = (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER) : ConstantsUtil.EMPTY_STRING;
		if(!strApproverName.isEmpty())
			strApproverName = (String)PersonUtil.getFullName(context,strApproverName);
		mapOwnerShipResult.put(ConstantsUtil.APPROVERS, strApproverName);
		
		//Lifecycle
		
		//Organization Data
		//mpOrganization.put("Template Segment", (validator.isNotNullOrEmpty((String)resultMap.get("from["+ConstantsUtil.RELATIONSHIP_PGPDTEMPLATESTOPGPLISEGMENT+"].to.name")))?(String)resultMap.get("from["+ConstantsUtil.RELATIONSHIP_PGPDTEMPLATESTOPGPLISEGMENT+"].to.name") : ConstantsUtil.EMPTY_STRING);
		mpOrganization.put("primaryOrganization", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization.put("secondaryOrganization", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization = util.filterMapList(mpOrganization);
		
		
		//Ownership
		mapOwnerShipResult.put("originator", (validator.isNotNullOrEmpty((String)resultMaps.get("attribute[Originator]")))?(String)resultMaps.get("attribute[Originator]") : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put("segment", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put("lastUpdateUser", (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put("lastUpdateDate", (validator.isNotNullOrEmpty((String)resultMaps.get("modified")))?(String)resultMaps.get("modified") : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
		
		
		//Derived From Data
		/*String strSourceName = (validator.isNotNullOrEmpty((String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
		mpDerivedFromResult.put("sourceName", strSourceName);
		mpDerivedFromResult.put("derivedName", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpDerivedFromResult.put("derivedDescription", (validator.isNotNullOrEmpty((String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpDerivedFromResult.put("derivedPartState", (validator.isNotNullOrEmpty((String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpDerivedFromResult.put("derivedPartSecurityCategory", (validator.isNotNullOrEmpty((String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from.from["+ConstantsUtil.RELATIONSHIP_PGPRIMARYORGANIZATION+"].to."+ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from.from["+ConstantsUtil.RELATIONSHIP_PGPRIMARYORGANIZATION+"].to."+ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpDerivedFromResult.put("sourcePartRevision", (validator.isNotNullOrEmpty((String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpDerivedFromResult.put("creator", (validator.isNotNullOrEmpty((String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpDerivedFromResult.put("createDate", (validator.isNotNullOrEmpty((String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get("to["+ConstantsUtil.RELATIONSHIP_DERIVED+"].from."+ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpDerivedFromResult = util.filterMapList(mpDerivedFromResult);*/
		
		
		//PLANTS
		mapPlantResult = util.updatePlantInfo(resultMaps);
				
		//Derived To Data
		//mpDerivedToResult = IPPBO.updateDerivedToPart(context,resultMaps);
		
		//HeaderContent
		mpHeaderContent.put("type", util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpHeaderContent.put("name", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put("revision", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put("state", (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
		mpHeaderContent.put("hasATS", ConstantsUtil.EMPTY_STRING);

		
		if(mapList.size()!=0){
			mpEBOMResult =util.parseMaplist(context,mapList);
			
		}
		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
		hmAttrib.put(ConstantsUtil.PLANTS, mapPlantResult);
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
	
		sp.stop();
		//System.out.println("IPP MESSAGE ELAPSED TIME::" + sp.getTime());
				
		//sp.stop();
		//System.out.println("Execution TIME::" + sp.getTime());
		System.out.println("RESULT:: \n" + hmAttrib);
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
	
	}
}
