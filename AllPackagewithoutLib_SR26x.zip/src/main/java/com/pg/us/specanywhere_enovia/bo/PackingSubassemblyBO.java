package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;
import matrix.util.UUID;

public class PackingSubassemblyBO {
	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(PackingSubassemblyBO.class);
	static BusObjectAttribUtil util = new BusObjectAttribUtil();
	FormulaCardBO fcBO = new FormulaCardBO();
	static StringValidatorUtil validator = new StringValidatorUtil();
	public PackingSubassemblyBO() {
		// empty constructor
	}

	/**
	 * Method Name 			: getPSUBBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getPSUBBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	/**
	 * Method Name 			: getPSUBDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getPSUBDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			if (doObj.exists(context))
				return doObj;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}

	/**
	 * Method Name 			: getPackingSubassemblySelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getPackingSubassemblySelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		busSelect.addAll(getWndBusSelectable(context));
		busSelect.addAll(getCosSelectable(context));
		busSelect.addAll(getPlantBusSelectable(context));
		busSelect.addAll(getSecuritySelects(context));
		//busSelect.addAll(getMasterSpecs());
		busSelect.addAll(BusObjectAttribUtil.getPackingUnitSelectables(context));
		busSelect.addAll(BusObjectAttribUtil.getTUPCharSelectables(context));
		busSelect.addAll(getTransportCharSelectables());
		busSelect.addAll(getPackagingCharBusSelectables());
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}

	/**
	 * Method Name 			: getPlantBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getPlantBusSelectable(Context context) {
		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		return busSelect;
	}

	/**
	 * Method Name 			: getPackagingCharBusSelectables
	 * Method Description 	:
	 * @return
	 */
	private static StringList getPackagingCharBusSelectables() {
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);


		return slBusSelects;

	}

	/**
	 * Method Name 			: getTransportCharSelectables
	 * Method Description 	:
	 * @return
	 */
	private static StringList getTransportCharSelectables() {
		StringList slBusSelects = new StringList();

		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);
		slBusSelects.add(ConstantsUtil.SELECT_REF_DOC_TONAME);

		//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --START
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE);
		//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --END

		//SPEC: Release SR18x.5.2: Jwala Added for Defect :39716 ## --START
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME);
		//SPEC: Release SR18x.5.2: Jwala Added for Defect :39716 ## --END

		//SPEC: Release SR18x.5.2: Amman Added for Defect :39191 ## --START
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID_FROM_REFDOCS);
		slBusSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE_FROM_REFDOCS);
		//SPEC: Release SR18x.5.2: Amman Added for Defect :39191 ## --END

		return slBusSelects;

	}



	/**
	 * Method Name 			: getFppRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getPSUBRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getCommonDataBusSelectable(context));
		relSelect.addAll(getTransportRelSelectables());
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);

		return mapSelecables;
	}

	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);

		busSelect.add(ConstantsUtil.SELECT_CONNECTION_ID);
		busSelect.add(ConstantsUtil.SELECT_PARENT);
		busSelect.add(ConstantsUtil.SELECT_LEVEL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);

		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		//busSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);

		//SPEC: Release SR18x.5.2 - Added for Defect# 39346  by Amman on Feb 16, 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYFORPRODUCTIS);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39346  by Amman on Feb 16, 2021 -- END

		return busSelect;
	}
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

		//relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_PSUBSUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCSSTYPE);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY); 
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET); 
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY); 
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM);	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_BASEUNITOFMEASURE); // Added for Defect#39068
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR);	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION); 	
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT); 			
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMBINATION_NUMBER);

		return relSelect;
	}

	/**
	 * Method Name 			: getTransportRelSelectables
	 * Method Description 	:
	 * @return
	 */
	private static StringList getTransportRelSelectables() {
		StringList slRelSelects = new StringList();
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHPALLETREAL);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTWITHOUTPALLETREAL);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);

		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY);

		return slRelSelects;
	}


	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION);
		busSelect.add(DomainConstants.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_SAP_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORM);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.APPROVER_FULLNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.PSUB_PGMASTER);

		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_ID);
		busSelect.add(ConstantsUtil.ATL_REVISION);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);

		busSelect.add(ConstantsUtil.REL_ATS_NAME);
		busSelect.add(ConstantsUtil.REL_ATS_TITLE);
		busSelect.add(ConstantsUtil.REL_ATS_ID);
		busSelect.add(ConstantsUtil.REL_ATS_STATE);
		busSelect.add(ConstantsUtil.REL_ATS_TYPE);
		busSelect.add(ConstantsUtil.REL_ATS_REV);
		busSelect.add(ConstantsUtil.REL_ATS_RELEASE_PHASE);

		busSelect.add(ConstantsUtil.SELECT_SAP_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		busSelect.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		busSelect.add(ConstantsUtil.SELECT_SAP_TO_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		//Chandra Added
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS);

		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.PSUB_PGMASTERTYPE);
		busSelect.add(ConstantsUtil.PSUB_PGMASTERID);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

		//SPEC: Release 18x.5.2: Added for Defect 38524 by Amman ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		//SPEC: Release 18x.5.2: Added for Defect 38524 by Amman ## -- END

		//SPEC: Release SR18x.5.2 - Added for Defect# 39346  by Amman on Feb 16, 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYFORPRODUCTIS);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39346  by Amman on Feb 16, 2021 -- END

		return busSelect;
	}
	/**
	 * Method Name 			: getCosSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getCosSelectable(Context context) {

		StringList relSelect = new StringList(2);
		relSelect.add(ConstantsUtil.SELECT_COS_NAME);
		relSelect.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		return relSelect;
	}
	/**
	 * Method Name 			: getWndBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getWndBusSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM);

		return busSelect;
	}

	/**
	 * Method Name : getPhaseBOM Method Description :
	 * 
	 * @param context
	 * @param mlEBOMList
	 * @return
	 */
	public Map<String, String> getPhaseBOM(Context context, MapList mlEBOMList, Map resultMap)throws Exception {
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		Map MPFinalEBOMSubStitute = new TreeMap();
		Map mpFinalEBOM = new TreeMap();
		Map mpFinalSubstitute = new TreeMap();


		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership = util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		StringValidatorUtil validator = new StringValidatorUtil();

		StringBuilder sbEBOMBaseQty = new StringBuilder();
		StringBuilder sbEBOMPCTBaseQty = new StringBuilder();
		StringBuilder sbEBOMBaseUOM = new StringBuilder();

		//SPEC: Release SR18x.5.2 - Added for Defect# 39346  by Amman on Feb 16, 2021 -- START
		StringBuilder sbHeaderOfBOM = new StringBuilder();
		//SPEC: Release SR18x.5.2 - Added for Defect# 39346  by Amman on Feb 16, 2021 -- END

		//SPEC : Commented by Jwala for the defect 39996 -- START 
		//mlEBOMList = removeDuplicates(mlEBOMList);
		//SPEC : Commented by Jwala for the defect 39996 -- END

		FormulaCardBO fcBO= new FormulaCardBO();
		int index=0;
		Iterator objectListItr = mlEBOMList.iterator();
		Map<String, String> mpHeaderEBOMResult = new HashMap<String, String>();
		try 
		{

			String sHeaderBOMBaseQty = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			String sHeaderPCTBaseQty = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
			String sHeaderBaseUOM = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

			util.formatData(sbEBOMBaseQty, sHeaderBOMBaseQty);
			util.formatData(sbEBOMPCTBaseQty, sHeaderPCTBaseQty);
			util.formatData(sbEBOMBaseUOM, sHeaderBaseUOM);

			mpHeaderEBOMResult.put(ConstantsUtil.BASEQUANTITY, sbEBOMBaseQty.toString());
			mpHeaderEBOMResult.put(ConstantsUtil.PCTBASEQUANTITY, sbEBOMPCTBaseQty.toString());
			mpHeaderEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBaseUOM.toString());

			//SPEC: Release SR18x.5.2 - Added for Defect# 39346  by Amman on Feb 16, 2021 -- START
			String sHeaderOfBOM  = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYFORPRODUCTIS));
			util.formatData(sbHeaderOfBOM, sHeaderOfBOM);
			mpHeaderEBOMResult.put(ConstantsUtil.ISQUANTITYFOR, sbHeaderOfBOM.toString());
			//SPEC: Release SR18x.5.2 - Added for Defect# 39346  by Amman on Feb 16, 2021 -- END

			while (objectListItr.hasNext()) 
			{
				Map<String, String> mpSubstituteResult = new HashMap<String, String>();
				Map<String, String> mpEBOMResult = new HashMap<String, String>();

				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMDisplayType = new StringBuilder();
				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMSapDes = new StringBuilder();
				StringBuilder sbEBOMFileDesc = new StringBuilder();
				StringBuilder sbEBOMSpecSubType = new StringBuilder();
				StringBuilder sbEBOMSubStitute = new StringBuilder();
				StringBuilder sbEBOMUOM = new StringBuilder();
				StringBuilder sbEBOMCmt = new StringBuilder();
				StringBuilder sbEBOMPkgLevel = new StringBuilder();
				StringBuilder sbEBOMQTY = new StringBuilder();

				Map mpPhase = (Map) objectListItr.next();
				String sId = (String) mpPhase.get(ConstantsUtil.SELECT_ID);

				MapList mlPhaseEBOMList = new MapList();
				if (UIUtil.isNotNullAndNotEmpty(sId)) 
				{
					DomainObject doPSUB = new DomainObject(sId);
					mlPhaseEBOMList = doPSUB.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
							ConstantsUtil.QUERY_WILDCARD, getBomBusSelect(context), getBomRelSelect(context), false, true,
							(short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doPSUB.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					mlPhaseEBOMList.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER,ConstantsUtil.ASCENDING,ConstantsUtil.INTEGER);

				}

				String sType = (String) mpPhase.get(ConstantsUtil.SELECT_TYPE);
				String sOid = (String) mpPhase.get(ConstantsUtil.SELECT_ID);
				String sName = (String) mpPhase.get(ConstantsUtil.SELECT_NAME);
				String sChg = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sDesc = (String) mpPhase.get(ConstantsUtil.SELECT_DESCRIPTION);

				String sSAPDesc = (String) mpPhase.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sPCTDesc = (String) mpPhase.get(ConstantsUtil.SELECT_DESCRIPTION);
				//SPEC: <02.16.2021>: Sumit Added for Defect :39172 ## --START
				sSAPDesc = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				if(!sType.equals(ConstantsUtil.TYPE_PGPHASE))
					sPCTDesc=sSAPDesc;
				//SPEC: <02.16.2021>: Sumit Added for Defect :39172 ## --ENDS
				String sDispType="";
				String sSpecSubType = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				String sSubstitute = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.SELECT_SUBSTITUTE));
				
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- START
				if(!util.isModificatinRequired()) {
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- END
					// Added by Jwala for the defect 42640 -- START
					if("No".equalsIgnoreCase(sSubstitute))
						sSubstitute= ConstantsUtil.EMPTY_STRING;
					// Added by Jwala for the defect 42640 -- END
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- START
				}
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 19, 2021 for Defect raised by Internal Testing Team -- END
				
				String sComment = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				String sPPkgLevel = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);
				String sPQty = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
				String sUOM = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				String strClassFiedParent = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.STR_IPCLASS));

				boolean bHasOwnership = false;
				String sFormulaPropagate = sId;
				//commented by Ganesh start
				/*if (util.isModificatinRequired()) 
				{

					// Formulation part does not have ownership on itself, hence
					// expand to get it from the Cosmetic formulation
					if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sId);
					}

					if (!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}
					if (!bHasOwnership) {

						sId = ConstantsUtil.NO_ACCESS;
						sType = ConstantsUtil.NO_ACCESS;
						sChg = ConstantsUtil.NO_ACCESS;
						sSAPDesc = ConstantsUtil.NO_ACCESS;
						sPCTDesc = ConstantsUtil.NO_ACCESS;
						sSpecSubType = ConstantsUtil.NO_ACCESS;
						sSubstitute = ConstantsUtil.NO_ACCESS;
						sComment = ConstantsUtil.NO_ACCESS;
						sUOM = ConstantsUtil.NO_ACCESS;
						sPPkgLevel = ConstantsUtil.NO_ACCESS;
						sPQty = ConstantsUtil.NO_ACCESS;
					}
				} else 
				{

					StringList slHIRTypes = new StringList();

					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

					boolean showData = true;
					if (slHIRTypes.contains(sType)) {

						String sFormulaClassif = strClassFiedParent;

						if (!sec.isExternalUser()) {
							if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							}
							if (null != sUserlicense && null != sFormulaClassif
									&& !sUserlicense.contains(sFormulaClassif)) {
								showData = false;
							}
						}

						if (!showData) {

							sId = ConstantsUtil.NO_ACCESS;
							sType = ConstantsUtil.NO_ACCESS;
							sChg = ConstantsUtil.NO_ACCESS;
							sSAPDesc = ConstantsUtil.NO_ACCESS;
							sPCTDesc = ConstantsUtil.NO_ACCESS;
							sSpecSubType = ConstantsUtil.NO_ACCESS;
							sSubstitute = ConstantsUtil.NO_ACCESS;
							sComment = ConstantsUtil.NO_ACCESS;
							sUOM = ConstantsUtil.NO_ACCESS;
							sPPkgLevel = ConstantsUtil.NO_ACCESS;
							sPQty = ConstantsUtil.NO_ACCESS;
						}
					}
				}commented by Ganesh stop*/
				//Added by Ganesh start
				boolean showData = util.checkHasAccess(context, null, sId);
				//SPEC: Release SR18x.5.2 - Modified for Defect# 38911  by Bala on Date Feb 10, 2021 -- START
				//if (!showData) {
				if (!showData && !sType.equals(ConstantsUtil.TYPE_PGPHASE)) {
					//SPEC: Release SR18x.5.2 - Modified for Defect# 38911  by Bala on Date Feb 10, 2021 -- END					
					sId = ConstantsUtil.NO_ACCESS;
					sChg = ConstantsUtil.NO_ACCESS;
					/*sId = ConstantsUtil.NO_ACCESS;
					sType = ConstantsUtil.NO_ACCESS;
					sChg = ConstantsUtil.NO_ACCESS;
					sSAPDesc = ConstantsUtil.NO_ACCESS;
					sPCTDesc = ConstantsUtil.NO_ACCESS;
					sSpecSubType = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sComment = ConstantsUtil.NO_ACCESS;
					sUOM = ConstantsUtil.NO_ACCESS;
					sPPkgLevel = ConstantsUtil.NO_ACCESS;
					sPQty = ConstantsUtil.NO_ACCESS;*/
				}
				//Added by Ganesh stop
				//sType = util.mapPsubType(sType);

				util.formatData(sbEBOMId, sId);
				util.formatData(sbEBOMType, sType);
				util.formatData(sbEBOMDisplayType, sDispType);
				util.formatData(sbEBOMName, sName);
				util.formatData(sbEBOMChg, sChg);
				util.formatData(sbEBOMSapDes, sSAPDesc);
				util.formatData(sbEBOMFileDesc, sPCTDesc);
				util.formatData(sbEBOMSubStitute, sSubstitute);
				util.formatData(sbEBOMSpecSubType, sSpecSubType);
				util.formatData(sbEBOMCmt, sComment);
				util.formatData(sbEBOMUOM, sUOM);
				util.formatData(sbEBOMPkgLevel, sPPkgLevel);
				util.formatData(sbEBOMQTY, sPQty);

				Iterator objectPhaseListItr = mlPhaseEBOMList.iterator();

				//mpSubstituteResult = getPSUBSubstitutes(context,mlPhaseEBOMList,sName,sDesc);

				mpSubstituteResult = getPSUBSubstitutes(context,mlPhaseEBOMList,sName,sPCTDesc,sId,sType);


				while (objectPhaseListItr.hasNext()) 
				{
					Map objectMap = (Map) objectPhaseListItr.next();

					sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
					sOid = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					sDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
					sChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
					sSAPDesc = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					//Chandra Modified--START
					//sPCTDesc = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					sPCTDesc = (String) objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
					//SPEC: <02.16.2021>: Sumit Added for Defect :39172 ## --START
					if(!sType.equals(ConstantsUtil.TYPE_PGPHASE))
						sPCTDesc=sSAPDesc;
					//SPEC: <02.16.2021>: Sumit Added for Defect :39172 ## --ENDS
					sSpecSubType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					String strAttrPgCSSType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
					// Guna Modified for Defect 38208  18x.5.2 Release -- START
					sSpecSubType =fcBO. getSpecificationSubtype(context, sType, sSpecSubType, strAttrPgCSSType,sOid);
					// Guna Modified for Defect 38208  18x.5.2 Release -- END
					//sSpecSubType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
					// if(sSpecSubType!=null){
					// sSpecSubType = util.mapPsubType(sSpecSubType);
					// }
					//Chandra Modified--END
					sSubstitute = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
					sComment = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					sPPkgLevel = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);
					sUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
					sPQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
					//strSCN = validator.getStringEquivalentForStringList( objectMap.get("from[EBOM].frommid[EBOM Substitute].attribute[pgSubstituteCombinationNumber]"));				
					strClassFiedParent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
					sDispType =fcBO.getMappedType(sType);
					//SPEC: <02.09.2021>: Commented for Defect : 39151 by Sumit --START
					//if(sType.equals(ConstantsUtil.TYPE_PGNONGCASPART)){
					//sName = ConstantsUtil.NONGCASNAME;
					//}
					//SPEC: <02.09.2021>: Commented for Defect : 39151 by Sumit --ENDS
					if(sType.equals(ConstantsUtil.TYPE_PGPHASE)){
						// sUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
						//SPEC: <30.04.2021>: Guna Modified for External Defect Dev 18x.6.0.1   -- START
						//sDispType="Fil";
						sDispType="FIL";
						//SPEC: <30.04.2021>: Guna Modified for External Defect Dev 18x.6.0.1   -- END
					}
					String	strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));

					//commented by Ganesh start
					/*if (util.isModificatinRequired()) {
						// Formulation part does not have ownership on itself,
						// hence expand to get it from the Cosmetic formulation
						if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaPropagate = util.getFormulaPropagate(context, sOid);
						}

						if (!sFormulaPropagate.isEmpty()) {
							bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
						}
						if (!bHasOwnership) {
							sOid = ConstantsUtil.NO_ACCESS;
							sType = ConstantsUtil.NO_ACCESS;
							sChg = ConstantsUtil.NO_ACCESS;
							sSAPDesc = ConstantsUtil.NO_ACCESS;
							sPCTDesc = ConstantsUtil.NO_ACCESS;
							sSpecSubType = ConstantsUtil.NO_ACCESS;
							sSubstitute = ConstantsUtil.NO_ACCESS;
							sComment = ConstantsUtil.NO_ACCESS;
							sUOM = ConstantsUtil.NO_ACCESS;
							sPPkgLevel = ConstantsUtil.NO_ACCESS;
							sPQty = ConstantsUtil.NO_ACCESS;
								}
					} else {

						StringList slHIRTypes = new StringList();

						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

						boolean showData = true;
						if (slHIRTypes.contains(sType)) {

							String sFormulaClassif = strClassFied;

							if (!sec.isExternalUser()) {
								if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
									sFormulaClassif = util.getFormulaPropagateClassification(context, sOid);
								}
								if (null != sUserlicense && null != sFormulaClassif
										&& !sUserlicense.contains(sFormulaClassif)) {
									showData = false;
								}
							}

							if (!showData) {
								sOid = ConstantsUtil.NO_ACCESS;
								sType = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								sSAPDesc = ConstantsUtil.NO_ACCESS;
								sPCTDesc = ConstantsUtil.NO_ACCESS;
								sSpecSubType = ConstantsUtil.NO_ACCESS;
								sSubstitute = ConstantsUtil.NO_ACCESS;
								sComment = ConstantsUtil.NO_ACCESS;
								sUOM = ConstantsUtil.NO_ACCESS;
								sPPkgLevel = ConstantsUtil.NO_ACCESS;
								sPQty = ConstantsUtil.NO_ACCESS;

							}

						}
					} commented by Ganesh stop*/
					//Added by Ganesh start
					//SPEC:  Modified for  Defect 38911 on 02/03/2021 by Chandra -- START
					//showData = util.checkHasAccess(context, null, sId);
					showData = util.checkHasAccess(context, null, sOid);
					//SPEC:  Modified for Defect 38911  on 02/03/2021 by Chandra -- END

					//SPEC: Release SR18x.6.0 Defect#39996 - Added  by gopal.m on Date 09 April 2021 -- START
					if (!showData && !sType.equals(ConstantsUtil.TYPE_PGPHASE)) {
					//SPEC: Release SR18x.6.0 Defect#39996 - Added  by gopal.m on Date 09 April 2021 -- START	


						sOid = ConstantsUtil.NO_ACCESS;
						sChg = ConstantsUtil.NO_ACCESS;
						/*sOid = ConstantsUtil.NO_ACCESS;
						sType = ConstantsUtil.NO_ACCESS;
						sChg = ConstantsUtil.NO_ACCESS;
						sSAPDesc = ConstantsUtil.NO_ACCESS;
						sPCTDesc = ConstantsUtil.NO_ACCESS;
						sSpecSubType = ConstantsUtil.NO_ACCESS;
						sSubstitute = ConstantsUtil.NO_ACCESS;
						sComment = ConstantsUtil.NO_ACCESS;
						sUOM = ConstantsUtil.NO_ACCESS;
						sPPkgLevel = ConstantsUtil.NO_ACCESS;
						sPQty = ConstantsUtil.NO_ACCESS;*/

					}
					//Added by Ganesh stop
					//SPEC: <02.08.2021>: Modified for Defect : 39186 by Sumit --START
					//sType = util.mapPsubType(sType);
					sType = util.mapType(sType);
					//SPEC: <02.08.2021>: Modified for Defect : 39186 by Sumit --ENDS
					util.formatData(sbEBOMId, sOid);
					util.formatData(sbEBOMType, sType);
					util.formatData(sbEBOMDisplayType, sDispType);
					util.formatData(sbEBOMName, sName);
					util.formatData(sbEBOMChg, sChg);
					util.formatData(sbEBOMSapDes, sSAPDesc);
					util.formatData(sbEBOMFileDesc, sPCTDesc);
					util.formatData(sbEBOMSpecSubType, sSpecSubType);
					util.formatData(sbEBOMSubStitute, sSubstitute);
					util.formatData(sbEBOMUOM, sUOM);
					util.formatData(sbEBOMCmt, sComment);
					util.formatData(sbEBOMPkgLevel, sPPkgLevel);
					formatData(sbEBOMQTY, sPQty);

				}

				mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbEBOMSapDes.toString());
				mpEBOMResult.put(ConstantsUtil.PCTDESC, sbEBOMFileDesc.toString());
				mpEBOMResult.put(ConstantsUtil.SS, sbEBOMSpecSubType.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				//mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sDispType.toString());
				mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbEBOMDisplayType.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubStitute.toString());
				mpEBOMResult.put(ConstantsUtil.UOM, sbEBOMUOM.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCmt.toString());
				mpEBOMResult.put(ConstantsUtil.PACKINGLEVEL, sbEBOMPkgLevel.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());

				mpFinalEBOM.put(String.valueOf(index), mpEBOMResult);
				mpFinalSubstitute.put(String.valueOf(index), mpSubstituteResult);
				index++;
			}
			MPFinalEBOMSubStitute.put(ConstantsUtil.BILLOFMATERIALS, mpFinalEBOM);
			MPFinalEBOMSubStitute.put(ConstantsUtil.SUBSTITUTEPARTS, mpFinalSubstitute);
			MPFinalEBOMSubStitute.put(ConstantsUtil.HEADER, mpHeaderEBOMResult);

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in PackingSubassemblyBO:  getPhaseBOM: " + e);
		}
		return MPFinalEBOMSubStitute;

		//return util.filterMapList(mpFinal);
	}

	/**
	 * Getting the Substitutes of Formula Card
	 * @param context
	 * @param mapList
	 * @param sDesc 
	 * @param sFilName 
	 * @return
	 * @throws Exception
	 */

	/*public Map<String, String> getPSUBSubstitutes(Context context, MapList mapList, String sFilName, String sFilDesc) throws Exception 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil  util = new BusObjectAttribUtil();
		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

		StringBuilder sbFilName = new StringBuilder();
		StringBuilder sbFilDesc = new StringBuilder();

		util.formatData(sbFilName, sFilName);
		util.formatData(sbFilDesc, sFilDesc);

		Map mpFinal = new TreeMap();
		try 
		{
			SecurityService sec = new SecurityService();
			String sComp = sec.getUserCauthorities();
			StringList slUserOwnership = util.filterOwnerShip(sComp);
			String sUserlicense = sec.getUserLicense();

			Iterator objectListItr = mapList.iterator();
			int j=0;
			while (objectListItr.hasNext()) 
			{

				Map<String, String> mpEBOMResult = new HashMap<String, String>();
				StringBuilder sbSubPartType = new StringBuilder();
				StringBuilder sbSubPartName = new StringBuilder();
				StringBuilder sbSubPartId = new StringBuilder();
				StringBuilder sbSubPartTitle = new StringBuilder();
				StringBuilder sbSubPartSpecSubType = new StringBuilder();	
				StringBuilder sbSubPartValidUntiltDt = new StringBuilder();
				StringBuilder sbSubstituteChg = new StringBuilder();
				StringBuilder sbSubstituteSCN = new StringBuilder();
				StringBuilder sbSubstituteUOM = new StringBuilder();
				StringBuilder sbSubstituteCMT = new StringBuilder();
				StringBuilder sbSubstituteQuantity = new StringBuilder();

				StringBuilder sbSubForType = new StringBuilder();
				StringBuilder sbSubForName = new StringBuilder();
				StringBuilder sbSubForId = new StringBuilder();
				StringBuilder sbSubForTitle = new StringBuilder();



				Map objectMap = (Map) objectListItr.next();

				if (objectMap.containsKey(ConstantsUtil.SELECT_SUBSTITUTE))
				{
					String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
					String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
					String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);


					String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
					boolean isExternal =util.isModificatinRequired(); 
					String sFormulaPropagate =sId;
					//commented by Ganesh start

					if (isExternal)
					{
						if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							 sFormulaPropagate = util.getFormulaPropagate(context, sFormulaPropagate);
						}
						boolean bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
						if (!bHasOwnership) 

							continue;
					}else if (!isExternal) 
					{
						if (slHIRTypes.contains(sType)) 
						{
							String sFormulaClassif = strClassFied;
							if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							}

							if (null != sUserlicense && null != sFormulaClassif
									&& !sUserlicense.contains(sFormulaClassif)) {

								continue;
							}

						}

					}commented by Ganesh stop
					//added by Ganesh start
					boolean bHasOwnership = util.checkHasAccess(context, null, sId);
					if (!bHasOwnership)
						continue;
					//added by Ganesh stop
					String sHasSubstitute = validator.getStringEquivalentForStringList((String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));

					if (sHasSubstitute.contains("No") || sHasSubstitute.contains("NO")) {
						continue;
					}

					util.formatData(sbSubForType, util.mapType(sType));
					util.formatData(sbSubForName, sName);
					util.formatData(sbSubForId, sId);
					util.formatData(sbSubForTitle, sTitle);

					StringList slSubType = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCSSTYPE)));
					StringList sltrValidUntilDt = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
					StringList slSubstituteName = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME)));
					StringList slSubstituteType = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)));
					StringList slSubstituteSCN = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.REL_PSUBSUBSTITUTE_COMBINATION_NUMBER)));
					StringList slSubstituteUOM = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM)));
					StringList slSubstituteQuantity = util.getStringList(validator.getStringEquivalentForStringList(
							objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY)));


					StringList slSubstituteCMT = new StringList();

					if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT)){

						String clClass = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT).getClass().getSimpleName();
						if (clClass.equals(ConstantsUtil.STRING)) 
						{
							String sSubstituteCMT = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT))?(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT) : ConstantsUtil.EMPTY_STRING;
							slSubstituteCMT= util.getStringList(sSubstituteCMT);
						}else
						{
							slSubstituteCMT = validator.isNotNullOrEmpty((StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						}

					}

					StringList slSubstituteTitle = new StringList();

				if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE)){

					String clClass = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE).getClass().getSimpleName();
					if (clClass.equals(ConstantsUtil.STRING)) 
					{
						String sSubstituteTitle = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE))?(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE) : ConstantsUtil.EMPTY_STRING;
						slSubstituteTitle=util.getStringList(sSubstituteTitle);
					}else
					{
						slSubstituteTitle = validator.isNotNullOrEmpty((StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
					}

				}

					StringList slSubstitutePart = util.getStringList(validator
							.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID)));
					StringList slSubstitutePartCHG = util.getStringList(validator
							.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG)));

						for (int i = 0; i < slSubstituteName.size(); i++) 
						{
							if (UIUtil.isNotNullAndNotEmpty(sHasSubstitute)
									&& (sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)
											|| sHasSubstitute.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE))) 
							{
								String sSubstituteAssemblyType = util.getValueFromStringList(slSubType,i);
								String sSubstituteUntilDate = util.getValueFromStringList(sltrValidUntilDt,i);
								String sSubstituteName = util.getValueFromStringList(slSubstituteName,i);
								String sSubstituteType = util.getValueFromStringList(slSubstituteType,i);
								String sSubstituteTitle = util.getValueFromStringList(slSubstituteTitle,i);
								String sSubstitutePartId = util.getValueFromStringList(slSubstitutePart,i);
								String sSubstituteSCN = util.getValueFromStringList(slSubstituteSCN,i);
								String sSubstituteUOM = util.getValueFromStringList(slSubstituteUOM,i);
								String sSubstituteCMT = util.getValueFromStringList(slSubstituteCMT,i);
								String sSubstituteChg = util.getValueFromStringList(slSubstitutePartCHG,i);
								String sSubstituteQuantity = util.getValueFromStringList(slSubstituteQuantity,i);

								sSubstituteType = util.mapPsubType(sSubstituteType);
								sSubstituteAssemblyType = util.mapPsubType(sSubstituteAssemblyType);

								util.formatData(sbSubPartType, sSubstituteType);
								util.formatData(sbSubPartName, sSubstituteName);


								boolean bSubstuteHasAccess = false;
								//commented by Ganesh start
								if (isExternal)
								{
									if (sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										sSubstitutePartId = util.getFormulaPropagate(context, sSubstitutePartId);
									}
									bSubstuteHasAccess = util.checkOwnerShip(context, slUserOwnership, sSubstitutePartId);
									if (!bSubstuteHasAccess) 

										util.formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteChg, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteUOM, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteCMT, ConstantsUtil.NO_ACCESS);
										util.formatData(sbSubstituteQuantity, ConstantsUtil.NO_ACCESS);

										continue;
								}else if (!isExternal) 
								{
									if (slHIRTypes.contains(sType)) 
									{
										String sSubstituteIPClass = validator.getStringEquivalentForStringList(
												objectMap.get(ConstantsUtil.STR_IPCLASS));

										String sSubFormulalassif = sSubstituteIPClass;
										if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
											sSubFormulalassif = util.getFormulaPropagateClassification(context, sSubstitutePartId);
										}

										if (null != sUserlicense && null != sSubFormulalassif
												&& !sUserlicense.contains(sSubFormulalassif))
										{
											util.formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteChg, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteUOM, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteCMT, ConstantsUtil.NO_ACCESS);
											util.formatData(sbSubstituteQuantity, ConstantsUtil.NO_ACCESS);

											continue;
										}

									}

								}commented by Ganesh stop
								//Added by Ganesh Strat
								bSubstuteHasAccess = util.checkHasAccess(context, null, sSubstitutePartId);
								if (!bSubstuteHasAccess) 
								{	
									util.formatData(sbSubPartId, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubPartTitle, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubPartSpecSubType, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubPartValidUntiltDt, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteChg, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteSCN, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteUOM, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteCMT, ConstantsUtil.NO_ACCESS);
									util.formatData(sbSubstituteQuantity, ConstantsUtil.NO_ACCESS);


							}
								//Added by Ganesh stop

								util.formatData(sbSubPartId, sSubstitutePartId);
								util.formatData(sbSubPartTitle, sSubstituteTitle);
								util.formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
								util.formatData(sbSubPartValidUntiltDt, sSubstituteUntilDate);
								util.formatData(sbSubstituteChg, sSubstituteChg);
								util.formatData(sbFilName, sFilName);
								util.formatData(sbFilDesc, sFilDesc);
								util.formatData(sbSubstituteSCN, sSubstituteSCN);
								util.formatData(sbSubstituteUOM, sSubstituteUOM);
								util.formatData(sbSubstituteCMT, sSubstituteCMT);
								util.formatData(sbSubstituteQuantity, sSubstituteQuantity);

							}

						}
				} 

				mpEBOMResult.put(ConstantsUtil.SF_ID, sbSubForId.toString());
				mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbSubForType.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubForName.toString());
				mpEBOMResult.put(ConstantsUtil.HEADERSAPDESC, sbSubForTitle.toString());
				mpEBOMResult.put(ConstantsUtil.PCTDESC, sFilDesc.toString());
				mpEBOMResult.put(ConstantsUtil.USEDINPCT, sFilName.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
				mpEBOMResult.put(ConstantsUtil.ID, sbSubPartId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbSubPartName.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbSubstituteChg.toString());
				mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubPartTitle.toString());
				mpEBOMResult.put(ConstantsUtil.SS, sbSubPartSpecSubType.toString());
				mpEBOMResult.put(ConstantsUtil.COMBINATIONNUMBER, sbSubstituteSCN.toString());
				mpEBOMResult.put(ConstantsUtil.UOM, sbSubstituteUOM.toString());
				mpEBOMResult.put(ConstantsUtil.VALIDUNTILDATE, sbSubPartValidUntiltDt.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbSubstituteCMT.toString());
				mpEBOMResult.put(ConstantsUtil.QUANTITY, sbSubstituteQuantity.toString());
				mpFinal.put(j, mpEBOMResult);
				j++;

			}

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in Formula Card : getFormulaSubstitutes : "+ e);
			return new HashMap();
		}
		return mpFinal;
		//return filterMapList(mpEBOMResult);
	}

	 */
	/**
	 * Method Name 			: parsePGPhaseBOMMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @param mpPhase
	 * @return
	 */
	public Map<String, String> parsePGPhaseBOMMaplist(Context context,MapList mapList, Map mpPhase, Map resultMap) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();

		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);
		String sUserlicense = sec.getUserLicense();
		StringValidatorUtil validator = new StringValidatorUtil();


		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Iterator objectListItr = mapList.iterator();

		StringBuilder sbEBOMBaseqty = new StringBuilder();
		StringBuilder sbEBOMPCTBaseqty = new StringBuilder();
		StringBuilder sbEBOMPkgLevel = new StringBuilder();
		StringBuilder sbEBOMPId = new StringBuilder();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMREV = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbSUBQTY = new StringBuilder();
		StringBuilder sbEBOMComment = new StringBuilder();
		StringBuilder sbEBOMSubtype = new StringBuilder();
		StringBuilder sbEBOMSubstute = new StringBuilder();
		StringBuilder sbEBOMuom = new StringBuilder();
		StringBuilder sbEBOMsubstitutes = new StringBuilder();
		StringBuilder sbEBOMSCN = new StringBuilder();


		String sPId = (String) mpPhase.get(ConstantsUtil.SELECT_ID);
		//String strSub =(String) mpPhase.get("from[EBOM].frommid[EBOM Substitute].to.name");
		String strSub = validator.getStringEquivalentForStringList( mpPhase.get("from[EBOM].frommid[EBOM Substitute].to.id"));
		String strsubqty = validator.getStringEquivalentForStringList( mpPhase.get("from[EBOM].frommid[EBOM Substitute].attribute[Quantity]"));
		String strSCN = validator.getStringEquivalentForStringList( mpPhase.get("from[EBOM].frommid[EBOM Substitute].attribute[pgSubstituteCombinationNumber]"));
		String sBaseqty = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		String sPCTBaseqty = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		String sPBuom = (String) resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		String sPuom = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE); 
		String sPName = (String) mpPhase.get(ConstantsUtil.SELECT_NAME);
		String sPPkgLevel = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);
		String sSubtype = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		String sPRevision = (String) mpPhase.get(ConstantsUtil.SELECT_REVISION);
		String sPReleaseDate = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		String sPRevRelease = sPRevision + ConstantsUtil.SYMBL_COLON+ sPReleaseDate;
		String sPpgChg = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		String sPFN = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		String sPTitle = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		String sPType = (String) mpPhase.get(ConstantsUtil.SELECT_TYPE);
		String sPSubstitute = (String) mpPhase.get(ConstantsUtil.SELECT_SUBSTITUTE);
		sPSubstitute =util.replaceSpecialSymbols(sPSubstitute);
		String sPQty = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
		//String sPComments = validator.isNotNullOrEmpty((String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT))?(String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT):ConstantsUtil.EMPTY_STRING;
		String sPComment = (String) mpPhase.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		String strClassFiedParent = validator.getStringEquivalentForStringList(mpPhase.get(ConstantsUtil.STR_IPCLASS));


		boolean bHasOwnership = false;

		String sFormulaPropagate = sPId;
		if(util.isModificatinRequired())
		{
			//commented by Ganesh for security impl------>start
			//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
			/*if(sPType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
				sFormulaPropagate = util.getFormulaPropagate(context, sPId);
			}

			if(!sFormulaPropagate.isEmpty()) {
				bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
			}*/
			//commented by Ganesh for security impl------>end
			//modified by Ganesh for security impl------>start
			bHasOwnership = util.checkHasAccess(context, null, sPId);
			//modified by Ganesh for security impl------>end
			if(!bHasOwnership)
			{
				sPTitle = ConstantsUtil.NO_ACCESS;
				sPpgChg = ConstantsUtil.NO_ACCESS;
				sPFN    = ConstantsUtil.NO_ACCESS;
				sPSubstitute = ConstantsUtil.NO_ACCESS;
				sPComment = ConstantsUtil.NO_ACCESS;
				sPId = ConstantsUtil.NO_ACCESS;
				sPReleaseDate = ConstantsUtil.NO_ACCESS;
				sPQty = ConstantsUtil.NO_ACCESS;
				sPBuom = ConstantsUtil.NO_ACCESS;
				sPRevRelease = sPRevision+ConstantsUtil.SYMBL_COLON+sPReleaseDate;

			}
		}else{
			//commented by Ganesh for security impl------>start
			/*StringList slHIRTypes = new StringList();

			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

			boolean showData = true;
			if(slHIRTypes.contains(sPType) ){

				String sFormulaClassif =strClassFiedParent;

				if(!sec.isExternalUser()){
					if (sPType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaClassif = util.getFormulaPropagateClassification(context, sPId);
					}
					if(null!=sUserlicense && null!=sFormulaClassif && !sUserlicense.contains(sFormulaClassif)) {
						showData=false;
					}
				}*/
			//commented by Ganesh for security impl------>end
			//modified by Ganesh for security impl------>start
			boolean showData = util.checkHasAccess(context, null, sPId);
			//modified by Ganesh for security impl------>end

			if(!showData){

				sPTitle = ConstantsUtil.NO_ACCESS;
				sPpgChg = ConstantsUtil.NO_ACCESS;
				sPFN    = ConstantsUtil.NO_ACCESS;
				sPSubstitute = ConstantsUtil.NO_ACCESS;
				sPComment = ConstantsUtil.NO_ACCESS;
				sPId = ConstantsUtil.NO_ACCESS;
				sPReleaseDate = ConstantsUtil.NO_ACCESS;
				sPQty = ConstantsUtil.NO_ACCESS;
				sPRevRelease = sPRevision+ConstantsUtil.SYMBL_COLON+sPReleaseDate;
			}

			//}
		}

		formatData(sbEBOMBaseqty, sBaseqty);
		formatData(sbEBOMsubstitutes, strSub);
		formatData(sbEBOMSCN, strSCN);
		formatData(sbSUBQTY, strsubqty);
		formatData(sbEBOMuom, sPuom);
		formatData(sbEBOMPkgLevel, sPPkgLevel);
		formatData(sbEBOMPCTBaseqty, sPCTBaseqty);
		formatData(sbEBOMType, sPType);
		formatData(sbEBOMName, sPName);
		formatData(sbEBOMREV, sPRevision);
		formatData(sbEBOMQTY, sPQty);
		formatData(sbEBOMBuom, sPBuom);
		formatData(sbEBOMSubtype, sSubtype);

		formatData(sbEBOMPId, sPId);
		formatData(sbEBOMChg, sPpgChg);
		formatData(sbEBOMTitle, sPTitle);
		formatData(sbEBOMSubstute, sPSubstitute);
		formatData(sbEBOMComment, sPComment);

		while (objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
			int iLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));
			String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
			String sId = (String) objectMap.get(ConstantsUtil.SELECT_ID);
			String sName = (String) objectMap.get(ConstantsUtil.SELECT_NAME);
			String sRevision = (String) objectMap.get(ConstantsUtil.SELECT_REVISION);
			String sPkgLevel = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGLEVEL);
			String strSubtype = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			String ssPuom = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
			String spgChg = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
			String sTitle = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			String sType = (String) objectMap.get(ConstantsUtil.SELECT_TYPE);
			String sSubstitute = (String) objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
			sSubstitute =util.replaceSpecialSymbols(sSubstitute);
			String sQty = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
			String sComment = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);


			if(util.isModificatinRequired())
			{
				//commented by Ganesh for security impl------->start
				//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
				/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
					sFormulaPropagate = util.getFormulaPropagate(context, sId);
				}

				if(!sFormulaPropagate.isEmpty()) {
					bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
				}*/
				//commented by Ganesh for security impl------->end
				//modified by Ganesh for security impl------->start
				bHasOwnership = util.checkHasAccess(context, null, sId);
				//modified by Ganesh for security impl------->end
				if(!bHasOwnership)
				{
					sTitle = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sComment = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
					sQty = ConstantsUtil.NO_ACCESS;

				}
			}else{
				//commented by Ganesh for security impl------->start
				/*StringList slHIRTypes = new StringList();

				slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
				slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

				boolean showData = true;
				if(slHIRTypes.contains(sType) )
				{

					String sFormulaClassif =strClassFied;

					if(!sec.isExternalUser())
					{
						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}
						if(null!=sUserlicense && null!=sFormulaClassif && !sUserlicense.contains(sFormulaClassif)) {
							showData=false;
						}
					}

					if(!showData)
					{
						sTitle = ConstantsUtil.NO_ACCESS;
						spgChg = ConstantsUtil.NO_ACCESS;
						sSubstitute = ConstantsUtil.NO_ACCESS;
						sComment = ConstantsUtil.NO_ACCESS;
						sId = ConstantsUtil.NO_ACCESS;
						sQty = ConstantsUtil.NO_ACCESS;
					}

				}*/
				//commented by Ganesh for security impl------->end
				//modified by Ganesh for security impl------->start
				boolean showData = util.checkHasAccess(context, null, sId);
				if(!showData)
				{
					sTitle = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sComment = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
					sQty = ConstantsUtil.NO_ACCESS;
				}
				//modified by Ganesh for security impl------->end
			}

			sType = util.mapPsubType(sType);
			strSubtype = util.mapPsubType(strSubtype); 
			//Security req -33193 HIR Components Attributes to Show
			//formatData(sbEBOMBaseqty, sBaseqty);
			formatData(sbEBOMSubtype, strSubtype);
			formatData(sbEBOMuom, ssPuom);
			formatData(sbEBOMPkgLevel, sPkgLevel);
			formatData(sbEBOMType, sType);
			formatData(sbEBOMName, sName);
			formatData(sbEBOMREV, sRevision);
			formatData(sbEBOMQTY, sQty);
			formatData(sbEBOMId, sId);
			formatData(sbEBOMChg, spgChg);
			formatData(sbEBOMTitle, sTitle);
			formatData(sbEBOMSubstute, sSubstitute);
			formatData(sbEBOMComment, sComment);

		}

		mpEBOMResult.put(ConstantsUtil.PSUBSUBSTITUTES, sbEBOMsubstitutes.toString());
		mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMSCN.toString());
		mpEBOMResult.put(ConstantsUtil.SUBQTY, sbSUBQTY.toString());
		mpEBOMResult.put(ConstantsUtil.PID, sbEBOMPId.toString());
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.BASEQUANTITY, sbEBOMBaseqty.toString());
		mpEBOMResult.put(ConstantsUtil.PCTBASEQUANTITY, sbEBOMPCTBaseqty.toString());
		mpEBOMResult.put(ConstantsUtil.PCTBASEQUANTITY, sbEBOMPCTBaseqty.toString());
		mpEBOMResult.put(ConstantsUtil.PACKINGLEVEL, sbEBOMPkgLevel.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.SS, sbEBOMSubtype.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.SAPDESORPCTDES, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.UNITOFMEASURE, sbEBOMuom.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMComment.toString());

		return  util.filterMapList(mpEBOMResult);
	}
	/**
	 * Method Name 			: getSubstitute
	 * Method Description 	: Fetching "Substitute" details
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> getSubstitute(Context context,Map mpResult) 
	{

		Map<String,String> mpSUBResult = new HashMap<String,String>();

		StringBuilder sbSubID = new StringBuilder();
		StringBuilder sbSubName = new StringBuilder();
		StringBuilder sbSubCHG = new StringBuilder();
		StringBuilder sbSubTitle = new StringBuilder();
		StringBuilder sbSubSS = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbSubUOM = new StringBuilder();
		StringBuilder sbSubVUDate = new StringBuilder();
		StringBuilder sbSubComments = new StringBuilder();
		StringBuilder sbSubFor = new StringBuilder();

		String strSubFor = ConstantsUtil.EMPTY_STRING;
		try{
			String strSubstitutes = (String)mpResult.get("substitutes");
			String strSCN = (String)mpResult.get("scn");
			String strQty = (String)mpResult.get("subqty");
			String strSubfor = (String)mpResult.get("id");
			String[] sID = strSubfor.split("\\|");
			String [] arrySubstitutes = strSubstitutes.split("\\|");
			for(int j=0;j<sID.length;j++){
				String sSubForID = sID[j];
				for(int i=0; i<arrySubstitutes.length;i++){

					if(UIUtil.isNotNullAndNotEmpty(sSubForID)){
						DomainObject doSubfor = new DomainObject(sSubForID);
						strSubFor = doSubfor.getName(context);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
						doSubfor.close(context);
						//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
						String strSubId = arrySubstitutes[i].trim();

						StringList slBusList = new StringList();
						slBusList.addElement(ConstantsUtil.SELECT_NAME);
						slBusList.addElement(ConstantsUtil.SELECT_ID);
						slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
						slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
						slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
						slBusList.addElement(ConstantsUtil.SELECT_TYPE);
						slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
						slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
						slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_VALID_UNTIL_DATE);
						slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
						if(UIUtil.isNotNullAndNotEmpty(strSubId)){
							DomainObject doSubInfo = new DomainObject(strSubId);

							Map mpSubDetails = doSubInfo.getInfo(context, slBusList);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
							doSubInfo.close(context);
							//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

							String strId = (String) mpSubDetails.get(ConstantsUtil.SELECT_ID);
							String strName = (String) mpSubDetails.get(ConstantsUtil.SELECT_NAME);
							String strCHG = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
							String strSapDec = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							String strSS = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
							String strType = (String) mpSubDetails.get(ConstantsUtil.SELECT_TYPE);
							String strUOM = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
							String strVUDate = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_VALID_UNTIL_DATE);
							String strComments = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

							strType = util.mapPsubType(strType);
							strSS = util.mapPsubType(strSS);

							formatData(sbSubFor, strSubFor);
							formatData(sbSubID, strId);
							formatData(sbSubName, strName);
							formatData(sbSubCHG, strCHG);
							formatData(sbSubTitle, strSapDec);
							formatData(sbSubSS, strSS);
							formatData(sbSubType, strType);
							formatData(sbSubUOM, strUOM);
							formatData(sbSubVUDate, strVUDate);
							formatData(sbSubComments, strComments);
						}
					}
				}
			}

			mpSUBResult.put(ConstantsUtil.SCN,strSCN);
			mpSUBResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubFor.toString());
			mpSUBResult.put(ConstantsUtil.ID, sbSubID.toString());
			mpSUBResult.put(ConstantsUtil.NAME, sbSubName.toString());
			mpSUBResult.put(ConstantsUtil.CHG, sbSubCHG.toString());
			mpSUBResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubTitle.toString());
			mpSUBResult.put(ConstantsUtil.SS, sbSubSS.toString());
			mpSUBResult.put(ConstantsUtil.TYPE, sbSubType.toString());
			mpSUBResult.put(ConstantsUtil.QUANTITY, strQty);
			mpSUBResult.put(ConstantsUtil.UNITOFMEASURE,sbSubUOM.toString() );
			mpSUBResult.put(ConstantsUtil.VALIDUNTILDATE, sbSubVUDate.toString());
			mpSUBResult.put(ConstantsUtil.COMMENTS, sbSubComments.toString());
		} catch(Exception e)
		{
			LOGGER.error("Error from PackingSubassemblyBO:  getSubstitute" + e);
			return new HashMap();
		}
		return util.filterMapList(mpSUBResult);
	}

	/**
	 * Method Name 			: getSubstitute
	 * Method Description 	: 
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> getSubstitute(Context context,MapList mapList) 
	{

		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpSUBResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();
		try{
			StringBuilder sbSubID = new StringBuilder();
			StringBuilder sbSubName = new StringBuilder();
			StringBuilder sbSubCHG = new StringBuilder();
			StringBuilder sbSubTitle = new StringBuilder();
			StringBuilder sbSubSS = new StringBuilder();
			StringBuilder sbSubType = new StringBuilder();
			StringBuilder sbSubUOM = new StringBuilder();
			StringBuilder sbSubVUDate = new StringBuilder();
			StringBuilder sbSubComments = new StringBuilder();
			StringBuilder sbSubFor = new StringBuilder();
			StringBuilder sbSubSCN = new StringBuilder();
			StringBuilder sbSubQty = new StringBuilder();

			String strSubSCN = ConstantsUtil.EMPTY_STRING;
			String strSubQty = ConstantsUtil.EMPTY_STRING;
			String strSCN = ConstantsUtil.EMPTY_STRING;
			String strQty = ConstantsUtil.EMPTY_STRING;
			String strSubFor = ConstantsUtil.EMPTY_STRING;

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get("substitution"));
				String [] arrysChildExists = sChildExists.split("\\|");
				String strPName = validator.getStringEquivalentForStringList(objectMap.get("name"));
				for(int j=0; j<arrysChildExists.length;j++){
					String strSubstitution = arrysChildExists[j].trim();
					if(strSubstitution.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| strSubstitution.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						String strsubstitutes = validator.getStringEquivalentForStringList(objectMap.get("substitutes"));
						strSCN = (String)objectMap.get("scn");
						strQty = (String)objectMap.get("subqty");
						String [] arrySubstitutes = strsubstitutes.split("\\|");
						String [] arrySCN = strSCN.split("\\|");
						String [] arrQty = strQty.split("\\|");
						String [] arrSubFor = strPName.split("\\|");

						for(int i=0; i<arrySubstitutes.length;i++){
							String strSubId = arrySubstitutes[i].trim();
							strSubSCN = arrySCN[i].trim();
							strSubQty = arrQty[i].trim();
							// strSubFor = arrSubFor[i].trim();

							StringList slBusList = new StringList();
							slBusList.addElement(ConstantsUtil.SELECT_NAME);
							slBusList.addElement(ConstantsUtil.SELECT_ID);
							slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
							slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
							slBusList.addElement(ConstantsUtil.SELECT_TYPE);
							slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
							slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
							slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_VALID_UNTIL_DATE);
							slBusList.addElement(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

							if(UIUtil.isNotNullAndNotEmpty(strSubId)){
								DomainObject doSubInfo = new DomainObject(strSubId);

								Map mpSubDetails = doSubInfo.getInfo(context, slBusList);
								//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
								doSubInfo.close(context);
								//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

								String strId = (String) mpSubDetails.get(ConstantsUtil.SELECT_ID);
								String strName = (String) mpSubDetails.get(ConstantsUtil.SELECT_NAME);
								String strCHG = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
								String strSapDec = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
								String strSS = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
								String strType = (String) mpSubDetails.get(ConstantsUtil.SELECT_TYPE);
								String strUOM = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
								String strVUDate = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_VALID_UNTIL_DATE);
								String strComments = (String) mpSubDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

								strType = util.mapPsubType(strType);
								strSS = util.mapPsubType(strSS);

								//formatData(sbSubFor, strSubFor);
								formatData(sbSubID, strId);
								formatData(sbSubName, strName);
								formatData(sbSubCHG, strCHG);
								formatData(sbSubTitle, strSapDec);
								formatData(sbSubSS, strSS);
								formatData(sbSubType, strType);
								formatData(sbSubUOM, strUOM);
								formatData(sbSubVUDate, strVUDate);
								formatData(sbSubComments, strComments);
								formatData(sbSubSCN, strSubSCN);
								formatData(sbSubQty, strSubQty);
								formatData(sbSubFor, strSubFor);
							}
						}
					}

				}
			}

			mpSUBResult.put(ConstantsUtil.SCN,sbSubSCN.toString());
			mpSUBResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubFor.toString());
			mpSUBResult.put(ConstantsUtil.ID, sbSubID.toString());
			mpSUBResult.put(ConstantsUtil.NAME, sbSubName.toString());
			mpSUBResult.put(ConstantsUtil.CHG, sbSubCHG.toString());
			mpSUBResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubTitle.toString());
			mpSUBResult.put(ConstantsUtil.SS, sbSubSS.toString());
			mpSUBResult.put(ConstantsUtil.TYPE, sbSubType.toString());
			mpSUBResult.put(ConstantsUtil.QUANTITY, strSubQty);
			mpSUBResult.put(ConstantsUtil.UNITOFMEASURE,sbSubUOM.toString() );
			mpSUBResult.put(ConstantsUtil.VALIDUNTILDATE, sbSubVUDate.toString());
			mpSUBResult.put(ConstantsUtil.COMMENTS, sbSubComments.toString());

		} catch(Exception e)
		{
			LOGGER.error("Error from PackingSubassemblyBO:  getSubstitute" + e);
			return new HashMap();
		}

		return mpSUBResult;
	}
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	public Map<String, String> parseMaplist(Context context, MapList mapList) {
		Map<String, String> mpEBOMResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		if(mapList.isEmpty()){
			return new HashMap();
		}
		Iterator objectSubListItr = mapList.iterator();

		StringBuilder sbSS = new StringBuilder();
		StringBuilder sbCHG = new StringBuilder();
		StringBuilder sbsubstitution = new StringBuilder();
		StringBuilder sbcomments = new StringBuilder();
		StringBuilder sbsubstitutes = new StringBuilder();
		StringBuilder sbsubqty = new StringBuilder();
		StringBuilder sbtype = new StringBuilder();
		StringBuilder sbname = new StringBuilder();
		StringBuilder sbparentid = new StringBuilder();
		StringBuilder sbSCN = new StringBuilder();
		StringBuilder sbbaseQuantity = new StringBuilder();
		StringBuilder sbpackinglevel = new StringBuilder();
		StringBuilder sbunitofMeasure = new StringBuilder();
		StringBuilder sbbaseUnitOfMeasure = new StringBuilder();
		StringBuilder sbqty = new StringBuilder();
		StringBuilder sbPCTbaseQuantity = new StringBuilder();
		StringBuilder sbid = new StringBuilder();
		StringBuilder sbstrsapdescriptionorpctDescription = new StringBuilder();

		while (objectSubListItr.hasNext()) {
			Map objectsubMap = (Map) objectSubListItr.next();

			if(!objectsubMap.isEmpty()){
				String strSS = validator.getStringEquivalentForStringList(objectsubMap.get("ss"));
				String strchg = validator.getStringEquivalentForStringList(objectsubMap.get("chg"));
				String strsubstitution = validator.getStringEquivalentForStringList(objectsubMap.get("substitution"));
				String strcomments = validator.getStringEquivalentForStringList(objectsubMap.get("comments"));
				String strsubstitutes = validator.getStringEquivalentForStringList(objectsubMap.get("substitutes"));
				String strsubqty = validator.getStringEquivalentForStringList(objectsubMap.get("subqty"));
				String strtype = validator.getStringEquivalentForStringList(objectsubMap.get("type"));
				String strparentid = validator.getStringEquivalentForStringList(objectsubMap.get("parentid"));
				String strsapdescriptionorpctDescription = validator.getStringEquivalentForStringList(objectsubMap.get("sapdescriptionorpctDescription"));
				String strbaseQuantity = validator.getStringEquivalentForStringList(objectsubMap.get("baseQuantity"));
				String strpackinglevel = validator.getStringEquivalentForStringList(objectsubMap.get("packinglevel"));
				String strunitofMeasure = validator.getStringEquivalentForStringList(objectsubMap.get("unitofMeasure"));
				String strbaseUnitOfMeasure = validator.getStringEquivalentForStringList(objectsubMap.get("baseUnitOfMeasure"));
				String strqty = validator.getStringEquivalentForStringList(objectsubMap.get("qty"));
				String strname = validator.getStringEquivalentForStringList(objectsubMap.get("name"));
				String strPCTbaseQuantity = validator.getStringEquivalentForStringList(objectsubMap.get("PCTbaseQuantity"));
				String strid = validator.getStringEquivalentForStringList(objectsubMap.get("id"));
				String strscn = validator.getStringEquivalentForStringList(objectsubMap.get("scn"));

				strtype = util.mapPsubType(strtype);
				strSS = util.mapPsubType(strSS);

				formatData(sbSS, strSS);
				formatData(sbCHG, strchg);
				formatData(sbsubstitution, strsubstitution);
				formatData(sbcomments, strcomments);
				formatData(sbsubstitutes, strsubstitutes);
				formatData(sbsubqty, strsubqty);
				formatData(sbtype, strtype);
				formatData(sbname, strname);
				formatData(sbparentid, strparentid);
				formatData(sbstrsapdescriptionorpctDescription, strsapdescriptionorpctDescription);
				formatData(sbbaseQuantity, strbaseQuantity);
				formatData(sbpackinglevel, strpackinglevel);
				formatData(sbbaseUnitOfMeasure, strbaseUnitOfMeasure);
				formatData(sbqty, strqty);
				formatData(sbPCTbaseQuantity, strPCTbaseQuantity);
				formatData(sbid, strid);
				formatData(sbSCN, strscn);
				formatData(sbunitofMeasure, strunitofMeasure);

			}
		}
		mpEBOMResult.put(ConstantsUtil.SS, sbSS.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbCHG.toString());
		mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbsubstitution.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbcomments.toString());
		mpEBOMResult.put(ConstantsUtil.PSUBSUBSTITUTES, sbsubstitutes.toString());
		mpEBOMResult.put(ConstantsUtil.QUANTITY, sbqty.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbtype.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbname.toString());
		mpEBOMResult.put(ConstantsUtil.SCN, sbSCN.toString());
		mpEBOMResult.put(ConstantsUtil.SUBQTY, sbsubqty.toString());
		mpEBOMResult.put(ConstantsUtil.PID, sbparentid.toString());
		mpEBOMResult.put(ConstantsUtil.ID, sbid.toString());
		mpEBOMResult.put(ConstantsUtil.BASEQUANTITY, sbbaseQuantity.toString());
		mpEBOMResult.put(ConstantsUtil.PCTBASEQUANTITY, sbPCTbaseQuantity.toString());
		mpEBOMResult.put(ConstantsUtil.PACKINGLEVEL, sbpackinglevel.toString());
		mpEBOMResult.put(ConstantsUtil.SAPDESORPCTDES, sbstrsapdescriptionorpctDescription.toString());
		mpEBOMResult.put(ConstantsUtil.UNITOFMEASURE, sbunitofMeasure.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbbaseUnitOfMeasure.toString());

		return mpEBOMResult;
	}
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList() {
		
		StringList slMultiSelects = new StringList();

		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);
		slMultiSelects.add(ConstantsUtil.STR_IPCLASS);

		slMultiSelects.add(ConstantsUtil.SELECT_COS_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);

		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);

		slMultiSelects.add(ConstantsUtil.ATL_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_TITLE);
		slMultiSelects.add(ConstantsUtil.ATL_ID);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		slMultiSelects.add(ConstantsUtil.ATL_REVISION);
		slMultiSelects.add(ConstantsUtil.ATL_TYPE);
		slMultiSelects.add(ConstantsUtil.ATL_RELEASE_PHASE);

		slMultiSelects.add(ConstantsUtil.REL_ATS_NAME);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TITLE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_ID);
		slMultiSelects.add(ConstantsUtil.REL_ATS_STATE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_REV);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_RELEASE_PHASE);

		slMultiSelects.add(ConstantsUtil.SELECT_SAP_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);

		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID_FROM_REFDOCS);
		slMultiSelects.add(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE_FROM_REFDOCS);
		
		return slMultiSelects;

	}

	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	: Removing multi selects from
	 * 						 DomainConstants after getting the information
	 */
	public  void removeMultiList() {

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CSS_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GTIN); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DEPTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_WIDTH); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_HEIGHT); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DIM_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GWEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSS_UOM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CONSUMER_PER_PACKING_UNIT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_PRODUCTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_NET_WEIGHT_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFFICIENCY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_SAP_BOM_FEED);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_RELEASE_PHASE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_REV);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_RELEASE_PHASE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TO_EXPIRATION_DATE);

		//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE);
		//SPEC: Release SR18x.5.2: Amman Added for Defect :39140 ## --END

		//SPEC: Release SR18x.5.2: Jwala Added for Defect :39716 ## --START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME);
		//SPEC: Release SR18x.5.2: Jwala Added for Defect :39716 ## --END

		//SPEC: Release SR18x.5.2: Amman Added for Defect :39191 ## --START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID_FROM_REFDOCS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE_FROM_REFDOCS);
		//SPEC: Release SR18x.5.2: Amman Added for Defect :39191 ## --END
	}


	/**
	 * Method Name 			: getEDList
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public static String getEDList(Map resultMaps,String ldapuser,String ldappwd) {
		String sAttrVal =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION) : ConstantsUtil.EMPTY_STRING;
		String strAttrValue=ConstantsUtil.EMPTY_STRING;
		String strValue=ConstantsUtil.EMPTY_STRING;
		StringTokenizer newValues=null;
		StringList strList=new StringList();

		if (sAttrVal != null && sAttrVal.trim().length() > 0) {
			newValues=new StringTokenizer(sAttrVal,ConstantsUtil.SYMBL_PIPE);
			while(newValues.hasMoreTokens())
			{
				strAttrValue=newValues.nextToken();
				if(null!=strAttrValue && (!strAttrValue.isEmpty())){
					strAttrValue = util.getLDAPInfo(strAttrValue.trim(), true,ldapuser,ldappwd);
					strList.addElement(strAttrValue);
					strList.sort();
					//<SPEC> 05/02/2021 Modified by Govind for Defect #39074 start
					//strValue = FrameworkUtil.join(strList, ConstantsUtil.SYMBL_PIPE);
					strValue = FrameworkUtil.join(strList, ConstantsUtil.SYMBL_NEWLINE);
					//<SPEC> 05/02/2021 Modified by Govind for Defect #39074 end
				}
			}

		}
		return strValue;
	}

	//SPEC : Commented by Jwala for the defect 39996 -- START 
	/*public MapList removeDuplicates (MapList inputMapList) throws Exception {
		MapList retMapList = new MapList();
		String name = "";
		String ids = null;
		if(inputMapList != null && inputMapList.size() > 0){
			Iterator itr = inputMapList.iterator();
			Map itrMap = null;
			while (itr.hasNext()){
				itrMap = (Map)itr.next();
				name = (String)itrMap.get(DomainConstants.SELECT_NAME);
				if (ids == null){
					retMapList.add(itrMap);
				}
				if (ids != null && ids.indexOf("|"+name+"|") == -1){
					retMapList.add(itrMap);
				}
				ids = ids + "|"+ name + "|";
			}
		}
		return retMapList;
	}
	 */
	//SPEC : Commented by Jwala for the defect 39996 -- END

	public Map<String, String> getPSUBSubstitutes(Context context, MapList mapList, String sFilName, String sFilDesc,String sFilId, String sFilType) throws Exception 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil  util = new BusObjectAttribUtil();

		Map mpFinal = new TreeMap();

		try 
		{

			Iterator objectListItr = mapList.iterator();
			int j=0;
			while (objectListItr.hasNext()) 
			{
				Map<String, String> mpEBOMResult = new HashMap<String, String>();
				StringBuilder sbSubPartType = new StringBuilder();
				StringBuilder sbSubPartDisplayType = new StringBuilder();
				StringBuilder sbSubPartName = new StringBuilder();
				StringBuilder sbSubPartId = new StringBuilder();
				StringBuilder sbSubPartTitle = new StringBuilder();
				StringBuilder sbSubPartSpecSubType = new StringBuilder();	
				StringBuilder sbSubPartValidUntiltDt = new StringBuilder();
				StringBuilder sbSubstituteMinQTY = new StringBuilder();
				StringBuilder sbSubstituteChg = new StringBuilder();
				StringBuilder sbSubstituteSCN = new StringBuilder();
				StringBuilder sbSubstituteQTY = new StringBuilder();
				StringBuilder sbSubstituteUOM = new StringBuilder();
				StringBuilder sbSubstituteBaseUOM = new StringBuilder(); // Added for Defect#39068
				StringBuilder sbSubstituteCMT = new StringBuilder();

				StringBuilder sbFilType = new StringBuilder();
				StringBuilder sbFilID = new StringBuilder();
				StringBuilder sbFilName = new StringBuilder();
				StringBuilder sbFilDesc = new StringBuilder();
				StringBuilder sbSubForType = new StringBuilder();
				StringBuilder sbSubForName = new StringBuilder();
				StringBuilder sbSubForId = new StringBuilder();
				StringBuilder sbSubForDesc = new StringBuilder();

				Map objectMap = (Map) objectListItr.next();

				if (objectMap.containsKey(ConstantsUtil.SELECT_SUBSTITUTE))
				{
					if (!objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME)) {
						continue;
					}

					String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME).getClass().getSimpleName();
					if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
					{

						String sSubstituteForPartId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sSubstituteForPartType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
						String sSubstituteForPartName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						//SPEC: <07.05.2020>: Modified for Defect :44014 by Madhana ## --START	
						String sSubstituteForPartTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC: <07.05.2020>: Modified for Defect :44014 by Madhana ## --END	
						String sSubstitutePartId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						String sSubstituteType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						String sSubstituteName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));

						String sSubstituteChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						String sSubstituteSCN=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
						String sSubstituteTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));

						String sSubstituteDisplayType =fcBO.getMappedType(sSubstituteType.trim());
						String sSubstituteAssemblyType =fcBO.getSpecificationSubtypeForSubstitutes(context,sSubstitutePartId,sSubstituteType);
						// SPEC: Modified for 18x.5.2 DEV --Guna -- START
						//<SPEC> 06/02/2021 Added by Govind for Defect #39068 start
						String sSubstituteQTY=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET));
						String sSubstituteQTY2=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
						if(UIUtil.isNullOrEmpty(sSubstituteQTY)) {
							sSubstituteQTY=sSubstituteQTY2;
						}
						if (sSubstituteQTY == null){
							sSubstituteQTY = "";
						}
						String sSubstituteBaseUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_BASEUNITOFMEASURE));
						//<SPEC> 06/02/2021 Added by Govind for Defect #39068 end
						// SPEC: Modified for 18x.5.2 DEV --Guna -- END
						String sSubstituteUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM));

						String sSubstituteValidDate =validator.DateFormatter(validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
						String sSubstituteComment =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));

						boolean bSubstituteHasAccess = util.checkHasAccess(context,null,sSubstitutePartId);

						//SPEC: <02.02.2021>: Modified for Defect: 38803 by Sumit --START
						sSubstituteType = util.mapType(sSubstituteType);
						//SPEC: <02.02.2021>: Modified for Defect: 38803 by Sumit --ENDS

						if(!bSubstituteHasAccess) {
							sSubstitutePartId    = ConstantsUtil.NO_ACCESS;
							sSubstituteChg = ConstantsUtil.NO_ACCESS;
						}

						util.formatData(sbSubPartId, sSubstitutePartId);
						util.formatData(sbSubPartName, sSubstituteName);
						util.formatData(sbSubPartTitle, sSubstituteTitle);
						util.formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
						util.formatData(sbSubPartValidUntiltDt, sSubstituteValidDate);
						util.formatData(sbSubstituteChg, sSubstituteChg);

						util.formatData(sbFilName, sFilName);
						util.formatData(sbFilDesc, sFilDesc);
						util.formatData(sbFilType, sFilType);
						util.formatData(sbFilID, sFilId);
						util.formatData(sbSubForDesc, sSubstituteForPartTitle);
						util.formatData(sbSubForId, sSubstituteForPartId);
						util.formatData(sbSubForType, sSubstituteForPartType);
						util.formatData(sbSubForName, sSubstituteForPartName);

						util.formatData(sbSubPartDisplayType, sSubstituteDisplayType);
						util.formatData(sbSubPartType, sSubstituteType);
						util.formatData(sbSubstituteSCN, sSubstituteSCN);
						util.formatData(sbSubstituteQTY, sSubstituteQTY);
						util.formatData(sbSubstituteUOM, sSubstituteUOM);
						util.formatData(sbSubstituteBaseUOM, sSubstituteBaseUOM); // Added for Defect#39068
						util.formatData(sbSubstituteCMT, sSubstituteComment);


						mpEBOMResult.put(ConstantsUtil.HEADERSAPDESC, sbSubForDesc.toString());
						mpEBOMResult.put(ConstantsUtil.USEDINPCT, sbFilName.toString());
						mpEBOMResult.put(ConstantsUtil.FIL_TYPE, sbFilType.toString());
						mpEBOMResult.put(ConstantsUtil.FIL_ID, sbFilID.toString());
						mpEBOMResult.put(ConstantsUtil.PCTDESC, sbFilDesc.toString());
						mpEBOMResult.put(ConstantsUtil.SF_ID, sbSubForId.toString());
						mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbSubForType.toString());
						mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubForName.toString());

						mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbSubPartDisplayType.toString());
						mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
						mpEBOMResult.put(ConstantsUtil.ID, sbSubPartId.toString());
						mpEBOMResult.put(ConstantsUtil.NAME, sbSubPartName.toString());
						mpEBOMResult.put(ConstantsUtil.CHG, sbSubstituteChg.toString());
						mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubPartTitle.toString());
						mpEBOMResult.put(ConstantsUtil.SS, sbSubPartSpecSubType.toString());
						mpEBOMResult.put(ConstantsUtil.COMBINATIONNUMBER, sbSubstituteSCN.toString());
						mpEBOMResult.put(ConstantsUtil.QUANTITY, sbSubstituteQTY.toString());
						mpEBOMResult.put(ConstantsUtil.UOM, sbSubstituteUOM.toString());
						mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbSubstituteBaseUOM.toString());// Added for Defect#39068
						mpEBOMResult.put(ConstantsUtil.VALIDUNTILDATE, sbSubPartValidUntiltDt.toString());
						mpEBOMResult.put(ConstantsUtil.COMMENTS, sbSubstituteCMT.toString());
						mpFinal.put(j, util.filterMapList(mpEBOMResult));
						j++;
					}else
					{

						String sSubstituteForPartId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sSubstituteForPartType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
						String sSubstituteForPartName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						//SPEC: <07.05.2020>: Modified for Defect :44014 by Madhana ## --START
						String sSubstituteForPartTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC: <07.05.2020>: Modified for Defect :44014 by Madhana ## --END
						StringList slSubstituteId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						StringList slSubstituteType = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
						StringList slSubstituteName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
						StringList slSubstituteChg=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						StringList slSubstituteSCN=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
						StringList slSubstituteTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						//SPEC: 07/04/2021: Modified for 18x.6 Defect #42087 by Bala-- START
						StringList slSubstituteQTY2=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
						StringList slSubstituteQTY=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET));
						//SPEC: <26.05.2021>: Guna Modified for 43162 Defect  Dev 18x.6.0.1   -- START
						if (/*slSubstituteQTY== null && slSubstituteQTY.size()==0 && */slSubstituteQTY.contains(ConstantsUtil.EMPTY_STRING) ) {
							slSubstituteQTY = slSubstituteQTY2;
						}
						//SPEC: <26.05.2021>: Guna Modified for 43162 Defect  Dev 18x.6.0.1   -- END
						//SPEC: 07/04/2021: Modified for 18x.6 Defect #42087 by Bala-- END
						StringList slSubstituteUOM =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM));
						StringList slSubstituteBaseUOM =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_BASEUNITOFMEASURE)); // Added for Defect#39068
						StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
						StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						for(int i =0; i<slSubstituteId.size(); i++) 
						{
							String sSubstitutePartId = validator.getStringEquivalentForStringList(slSubstituteId.getElement(i));										
							String sSubstitutePartType=validator.getStringEquivalentForStringList(slSubstituteType.getElement(i));		

							String sSubstituteChg = validator.getStringEquivalentForStringList(slSubstituteChg.getElement(i));										
							String sSubstituteSCN=validator.getStringEquivalentForStringList(slSubstituteSCN.getElement(i));										
							String sSubstituteName =validator.getStringEquivalentForStringList(slSubstituteName.getElement(i));											
							String sSubstituteTitle =validator.getStringEquivalentForStringListWithComma(slSubstituteTitle.getElement(i));								

							String sSubstituteDisplayType =fcBO.getMappedType(sSubstitutePartType.trim());
							String sSubstituteAssemblyType =fcBO.getSpecificationSubtypeForSubstitutes(context,sSubstitutePartId,sSubstitutePartType);
							String sSubstituteQTY=validator.getStringEquivalentForStringList(slSubstituteQTY.getElement(i));		
							String sSubstituteUOM =validator.getStringEquivalentForStringList(slSubstituteUOM.getElement(i));
							String sSubstituteBaseUOM =validator.getStringEquivalentForStringList(slSubstituteBaseUOM.getElement(i)); // Added for Defect#39068
							String sSubstituteValidDate =validator.DateFormatter(validator.getStringEquivalentForStringListWithComma(slUntilDate.getElement(i)));	
							String sSubstituteComment =validator.getStringEquivalentForStringListWithComma(slComments.getElement(i));		

							boolean bSubstituteHasAccess = util.checkHasAccess(context,null,sSubstitutePartId);

							if(!bSubstituteHasAccess) {
								sSubstitutePartId    = ConstantsUtil.NO_ACCESS;
								sSubstituteChg = ConstantsUtil.NO_ACCESS;
							}

							util.formatData(sbSubPartId, sSubstitutePartId);
							util.formatData(sbSubPartTitle, sSubstituteTitle);
							util.formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
							util.formatData(sbSubPartValidUntiltDt, sSubstituteValidDate);
							util.formatData(sbSubstituteChg, sSubstituteChg);

							util.formatData(sbSubPartDisplayType, sSubstituteDisplayType);
							util.formatData(sbSubPartType, sSubstitutePartType);
							util.formatData(sbSubPartName, sSubstituteName);
							util.formatData(sbSubstituteSCN, sSubstituteSCN);
							util.formatData(sbSubstituteQTY, sSubstituteQTY);
							util.formatData(sbSubstituteUOM, sSubstituteUOM);
							util.formatData(sbSubstituteBaseUOM, sSubstituteBaseUOM);// Added for Defect#39068
							util.formatData(sbSubstituteCMT, sSubstituteComment);
						}
						util.formatData(sbFilName, sFilName);
						util.formatData(sbFilDesc, sFilDesc);
						util.formatData(sbFilType, sFilType);
						util.formatData(sbFilID, sFilId);
						util.formatData(sbSubForDesc, sSubstituteForPartTitle);
						util.formatData(sbSubForId, sSubstituteForPartId);
						util.formatData(sbSubForType, sSubstituteForPartType);
						util.formatData(sbSubForName, sSubstituteForPartName);	
						mpEBOMResult.put(ConstantsUtil.HEADERSAPDESC, sbSubForDesc.toString());
						mpEBOMResult.put(ConstantsUtil.USEDINPCT, sbFilName.toString());
						mpEBOMResult.put(ConstantsUtil.FIL_TYPE, sbFilType.toString());
						mpEBOMResult.put(ConstantsUtil.FIL_ID, sbFilID.toString());
						mpEBOMResult.put(ConstantsUtil.PCTDESC, sbFilDesc.toString());
						mpEBOMResult.put(ConstantsUtil.SF_ID, sbSubForId.toString());
						mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbSubForType.toString());
						mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbSubForName.toString());

						mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbSubPartDisplayType.toString());
						mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
						mpEBOMResult.put(ConstantsUtil.ID, sbSubPartId.toString());
						mpEBOMResult.put(ConstantsUtil.NAME, sbSubPartName.toString());
						mpEBOMResult.put(ConstantsUtil.CHG, sbSubstituteChg.toString());
						mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubPartTitle.toString());
						mpEBOMResult.put(ConstantsUtil.SS, sbSubPartSpecSubType.toString());
						mpEBOMResult.put(ConstantsUtil.COMBINATIONNUMBER, sbSubstituteSCN.toString());
						mpEBOMResult.put(ConstantsUtil.QUANTITY, sbSubstituteQTY.toString());
						mpEBOMResult.put(ConstantsUtil.UOM, sbSubstituteUOM.toString());
						mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbSubstituteBaseUOM.toString());// Added for Defect#39068
						mpEBOMResult.put(ConstantsUtil.VALIDUNTILDATE, sbSubPartValidUntiltDt.toString());
						mpEBOMResult.put(ConstantsUtil.COMMENTS, sbSubstituteCMT.toString());

						mpFinal.put(j, util.filterMapList(mpEBOMResult));
						j++;

					}


				}

			}

		} catch (Exception e) {
			LOGGER.error("Exception in PackingSubassemblyBO : getFormulaSubstitutes : "+ e);
			return new HashMap();
		}
		return mpFinal;
	}


	//SPEC: Release SR18x.5.2: Amman added for Defect :39191 ## -- START
	/**
	 * Method Name 			: UpdateTransportChar
	 * Method Description 	:
	 * @param context
	 * @param objectMap
	 * @return
	 */
	public Map UpdateTransportChar(Context context , Map objectMap){
		FinishedProductPartBO fppBO = new FinishedProductPartBO();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String,String> mpTransportUnit = new HashMap<String,String>();

		try 
		{
			StringList slPalletType =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_PALLET_TYPE));
			StringList slGtin=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDED_DATA_GTIN));
			StringList slOutDimDepth =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_LENGTH));
			StringList slOutDimWidth =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_WIDTH));
			StringList slOutDimHght=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_OUTER_DIM_HEIGHT));
			StringList slOutDimUOM=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_DIMENSION_UOM));
			StringList slTUP_VOLUME=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME));
			StringList slITUP_UOM =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRANSPORT_UNIT_VOLUME_UOM));
			StringList slGW_UOM =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_GROSSwEIGHT_UOM));
			StringList slCustomlayerperTup =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUSTOMUNITS_PER_LAYER));
			StringList sllayerperTup=  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_LAYERS_PER_TUP));
			StringList slCUPPerTUp =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUP_PER_TUP));
			StringList slcubeEff =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CUBE_EFF));
			StringList slPalletMXhgt =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_PALLET_STACK_MAXHGHT));
			StringList slCASMaxHGt =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_CAS_MAX_HGHT));
			StringList slTruckMXHGT =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_TRUCK_PALLET_MAXHGHT));

			StringList slStackPatternfromRefDocs =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN));
			StringList slStackPatternIdfromRefDocs =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID_FROM_REFDOCS));
			StringList slStackPatternTypefromRefDocs =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE_FROM_REFDOCS));

			StringList slStackPatterntoRefDocs =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_NAME));
			StringList slStackPatternIdtoRefDocs =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_ID));
			StringList slStackPatternTypetoRefDocs =  validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.REL_EXTENDEDDATA_STACK_PATTERN_TYPE));

			StringList slStackPattern = new StringList();
			StringList slStackPatternId = new StringList();
			StringList slStackPatternType = new StringList();
			//SPEC: <16.11.2021>: Guna Modified for  Defect 45787 18x.6.0.2   -- START
			if(slStackPatterntoRefDocs.size()==0 && slStackPatternfromRefDocs.size()!=0) {
				//slStackPattern = slStackPatternfromRefDocs;
				//slStackPatternId = slStackPatternIdfromRefDocs;
				Map<String,StringList> spsMap = checkSecurityAccess(context,slStackPatternIdfromRefDocs,slStackPatternfromRefDocs);
				slStackPatternId =spsMap.get("objID");
				slStackPattern =spsMap.get("objName");
				slStackPatternType = slStackPatternTypefromRefDocs;
			}
			else if (slStackPatternfromRefDocs.size()==0 && slStackPatterntoRefDocs.size()!=0) {
				//slStackPattern = slStackPatterntoRefDocs;
				//SPEC: Release SR18x5.2- modified for Defect #39191 by Govind on Date 20/02/2021 start
				//slStackPatternId = slStackPatterntoRefDocs;
				//slStackPatternId = slStackPatternIdtoRefDocs;
				Map<String,StringList> spsMap = checkSecurityAccess(context,slStackPatternIdtoRefDocs,slStackPatterntoRefDocs);
				slStackPatternId =spsMap.get("objID");
				slStackPattern =spsMap.get("objName");
				
				//SPEC: Release SR18x5.2- modified for Defect #39191 by Govind on Date 20/02/2021 start
				slStackPatternType = slStackPatternTypetoRefDocs;
			}
			//SPEC: <16.11.2021>: Guna Modified for  Defect 45787 18x.6.0.2   -- END
			String sPalletType = validator.isNotNullOrEmpty(slPalletType.toString()) ? slPalletType.toString(): ConstantsUtil.EMPTY_STRING;
			String sGtin = validator.isNotNullOrEmpty(slGtin.toString()) ? slGtin.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimDepth = validator.isNotNullOrEmpty(slOutDimDepth.toString()) ? slOutDimDepth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimWidth = validator.isNotNullOrEmpty(slOutDimWidth.toString()) ? slOutDimWidth.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimHght = validator.isNotNullOrEmpty(slOutDimHght.toString()) ? slOutDimHght.toString(): ConstantsUtil.EMPTY_STRING;
			String sOutDimUOM = validator.isNotNullOrEmpty(slOutDimUOM.toString()) ? slOutDimUOM.toString(): ConstantsUtil.EMPTY_STRING;
			String sTUP_VOLUME = validator.isNotNullOrEmpty(slTUP_VOLUME.toString()) ? slTUP_VOLUME.toString(): ConstantsUtil.EMPTY_STRING; 
			String sITUP_UOM = validator.isNotNullOrEmpty(slITUP_UOM.toString()) ? slITUP_UOM.toString(): ConstantsUtil.EMPTY_STRING;
			String sGW_UOM = validator.isNotNullOrEmpty(slGW_UOM.toString()) ? slGW_UOM.toString(): ConstantsUtil.EMPTY_STRING;
			String sCustomlayerperTup = validator.isNotNullOrEmpty(slCustomlayerperTup.toString()) ? slCustomlayerperTup.toString(): ConstantsUtil.EMPTY_STRING;
			String slayerperTup = validator.isNotNullOrEmpty(sllayerperTup.toString()) ? sllayerperTup.toString(): ConstantsUtil.EMPTY_STRING;
			String sCUPPerTUp = validator.isNotNullOrEmpty(slCUPPerTUp.toString()) ? slCUPPerTUp.toString(): ConstantsUtil.EMPTY_STRING;
			String scubeEff = validator.isNotNullOrEmpty(slcubeEff.toString()) ? slcubeEff.toString(): ConstantsUtil.EMPTY_STRING;
			String sPalletMXhgt = validator.isNotNullOrEmpty(slPalletMXhgt.toString()) ? slPalletMXhgt.toString(): ConstantsUtil.EMPTY_STRING;
			String sCASMaxHGt = validator.isNotNullOrEmpty(slCASMaxHGt.toString()) ? slCASMaxHGt.toString(): ConstantsUtil.EMPTY_STRING;
			String sTruckMXHGT = validator.isNotNullOrEmpty(slTruckMXHGT.toString()) ? slTruckMXHGT.toString(): ConstantsUtil.EMPTY_STRING;
			String sStackPattern  = validator.isNotNullOrEmpty(slStackPattern.toString()) ? slStackPattern.toString(): ConstantsUtil.EMPTY_STRING;
			String sStackPatternId  = validator.isNotNullOrEmpty(slStackPatternId.toString()) ? slStackPatternId.toString(): ConstantsUtil.EMPTY_STRING;
			String sStackPatternType  = validator.isNotNullOrEmpty(slStackPatternType.toString()) ? slStackPatternType.toString(): ConstantsUtil.EMPTY_STRING;

			sPalletType = util.replaceSpecialSymbols(sPalletType);
			sGtin = util.replaceSpecialSymbols(sGtin);
			sOutDimDepth = util.replaceSpecialSymbols(sOutDimDepth);
			sOutDimWidth = util.replaceSpecialSymbols(sOutDimWidth);
			sOutDimHght = util.replaceSpecialSymbols(sOutDimHght);
			sOutDimUOM = util.replaceSpecialSymbols(sOutDimUOM);
			sTUP_VOLUME = util.replaceSpecialSymbols(sTUP_VOLUME);
			sITUP_UOM = util.replaceSpecialSymbols(sITUP_UOM);

			String sGW_WITH_Pallet=fppBO.getDataWithComma(objectMap, ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITH_PALLET);
			String sGW_WITHout_Pallet=fppBO.getDataWithComma(objectMap, ConstantsUtil.REL_EXTENDEDDATA_GROSSWEIGHT_WITHOUT_PALLET);

			sGW_UOM = util.replaceSpecialSymbols(sGW_UOM);
			sCustomlayerperTup = util.replaceSpecialSymbols(sCustomlayerperTup);
			slayerperTup = util.replaceSpecialSymbols(slayerperTup);
			sCUPPerTUp = util.replaceSpecialSymbols(sCUPPerTUp);
			scubeEff = util.replaceSpecialSymbols(scubeEff);
			sPalletMXhgt = util.replaceSpecialSymbols(sPalletMXhgt);
			sCASMaxHGt = util.replaceSpecialSymbols(sCASMaxHGt);
			sTruckMXHGT = util.replaceSpecialSymbols(sTruckMXHGT);
			sStackPattern = util.replaceSpecialSymbols(sStackPattern);
			sStackPatternId = util.replaceSpecialSymbols(sStackPatternId);
			sStackPatternType = util.replaceSpecialSymbols(sStackPatternType);

			mpTransportUnit.put(ConstantsUtil.PALLETTYPE,sPalletType);
			mpTransportUnit.put(ConstantsUtil.GTIN,sGtin);
			mpTransportUnit.put(ConstantsUtil.DEPTH,sOutDimDepth);
			mpTransportUnit.put(ConstantsUtil.WIDTH,sOutDimWidth);
			mpTransportUnit.put(ConstantsUtil.HEIGHT,sOutDimHght);
			mpTransportUnit.put(ConstantsUtil.TUPVOLUME,sTUP_VOLUME);
			mpTransportUnit.put(ConstantsUtil.TUPUOM,sITUP_UOM);
			mpTransportUnit.put(ConstantsUtil.DIMENSIONUNITOFMEASURE,sOutDimUOM);
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHPALLET,sGW_WITH_Pallet);
			mpTransportUnit.put(ConstantsUtil.GROSSWEIGHTWITHOUTPALLET,sGW_WITHout_Pallet);
			mpTransportUnit.put(ConstantsUtil.UNITOFMEASURE1,sGW_UOM);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERLAYER,sCustomlayerperTup);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFLAYERSPERTRANSPORTUNIT,slayerperTup);
			mpTransportUnit.put(ConstantsUtil.NUMBEROFCUSTOMERUNITSPERTRANSPORTUNIT,sCUPPerTUp);
			mpTransportUnit.put(ConstantsUtil.WAREHOUSEPALLETSTACKHEIGHTMAXIMUM,sPalletMXhgt);
			mpTransportUnit.put(ConstantsUtil.WAREHOUSECASESTACKHEIGHTMAXIMUM,sCASMaxHGt);
			mpTransportUnit.put(ConstantsUtil.TRUCKPALLETSTACKHEIGHTMAXIMUM,sTruckMXHGT);
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODE,sStackPattern);
			mpTransportUnit.put(ConstantsUtil.CUBEEFFICIENCY,scubeEff);
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODEID,sStackPatternId);
			mpTransportUnit.put(ConstantsUtil.STACKINGPATTERNGCASCODETYPE,sStackPatternType);

		} catch (Exception e) {
			LOGGER.error("Exception in Program : PackingSubAssemblyBO Method :UpdateTransportChar "+e);
			return new HashMap();

		}
		return mpTransportUnit;
	}
	//SPEC: Release SR18x.5.2: Amman added for Defect :39191 ## -- END

	//SPEC: Added for Defect #41616 by Jwala -- START
	public String getUserName(Context context, String strOriginator) {
		String strUserName=DomainConstants.EMPTY_STRING;	
		try{			
			if (UIUtil.isNotNullAndNotEmpty(strOriginator) && !strOriginator.contains(ConstantsUtil.SYMBL_COMMA)) {
				StringList slObjSelects = new StringList(5);
				slObjSelects.addElement(DomainConstants.SELECT_ID);
				slObjSelects.addElement(DomainConstants.SELECT_NAME);
				slObjSelects.addElement(DomainConstants.SELECT_ATTRIBUTE_FIRSTNAME);
				slObjSelects.addElement(DomainConstants.SELECT_ATTRIBUTE_LASTNAME);
				slObjSelects.addElement("attribute[pgTNumber]");
				String strWhere="attribute[pgTNumber]"+"==\""+strOriginator+"\" && revision==last";				
				MapList mlDataList = DomainObject.findObjects(context, DomainConstants.TYPE_PERSON,
						ConstantsUtil.SYMBL_ASTERISK, ConstantsUtil.SYMBL_ASTERISK, ConstantsUtil.SYMBL_ASTERISK,
						ConstantsUtil.VAULT_ESERVICEPRODUCTION, strWhere, false, slObjSelects);
				if(null!=mlDataList && !mlDataList.isEmpty()){
					Map dataMap= (Map)mlDataList.get(0);
					strUserName=(String)dataMap.get(DomainConstants.SELECT_ATTRIBUTE_FIRSTNAME)+" "+(String)dataMap.get(DomainConstants.SELECT_ATTRIBUTE_LASTNAME);
				}else{
					strUserName = strOriginator;
				}
			} else {
				StringList slValues =  StringUtil.split(strOriginator,ConstantsUtil.SYMBL_COMMA);
				if(null != slValues && !slValues.isEmpty()) 
					strUserName = slValues.get(0);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : PackingSubAssemblyBO Method :getUserName "+e);
		} 
		return strUserName;
	}
	//SPEC: Added for Defect #41616 by Jwala -- END
	//SPEC: Added for External Defect by Bala on 26/05/2021 -- START
	public Pattern getTypePatternforSpecification(boolean readaccess_structured) {
		String asterik = "*";
		Pattern sbTypePattern = new Pattern(ConstantsUtil.tILST);
		try {
			if (readaccess_structured) {
				sbTypePattern.addPattern(ConstantsUtil.tQUAL);
				// Added by Jwala for the defect 43496 -- START 
				sbTypePattern.addPattern(ConstantsUtil.tTAMU);
				sbTypePattern.addPattern(ConstantsUtil.tSPS);
				// Added by Jwala for the defect 43496 -- END
				sbTypePattern.addPattern(ConstantsUtil.tPI);
				sbTypePattern.addPattern(ConstantsUtil.tPROS);
				sbTypePattern.addPattern(ConstantsUtil.tSOP);
				sbTypePattern.addPattern(ConstantsUtil.TYPE_PGCONSUMERDESIGNBASIS);
				sbTypePattern.addPattern(ConstantsUtil.tASL);				
				sbTypePattern.addPattern("pgConsumerDesignBasis");
				//SPEC: Release SR18x.6.0.1 - Added by Amman on June 17, 2021 for Defect #43688 -- START
				sbTypePattern.addPattern(ConstantsUtil.tMPS);
				//SPEC: Release SR18x.6.0.1 - Added by Amman on June 17, 2021 for Defect #43688 -- END
				return sbTypePattern;
			} else {
				sbTypePattern.addPattern(ConstantsUtil.tMPMS);
				sbTypePattern.addPattern(ConstantsUtil.tMRMS);
				sbTypePattern.addPattern(ConstantsUtil.tQUAL);
				// Added by Jwala for the defect 43496 -- START 
				sbTypePattern.addPattern(ConstantsUtil.tTAMU);
				sbTypePattern.addPattern(ConstantsUtil.tSPS);
				// Added by Jwala for the defect 43496 -- END
				sbTypePattern.addPattern(ConstantsUtil.tPI);
				sbTypePattern.addPattern(ConstantsUtil.tTM);
				sbTypePattern.addPattern(ConstantsUtil.tPROS);
				sbTypePattern.addPattern(ConstantsUtil.tSOP);
				sbTypePattern.addPattern(ConstantsUtil.tFPP);
				sbTypePattern.addPattern(ConstantsUtil.tMPS);
				return sbTypePattern;
			}
		} catch (Exception e) {
			LOGGER.error("Exception :: PackingSubassemblyBO : getTypePattern" + e);
			return sbTypePattern;
		}
	}
	//SPEC: Added for External Defect by Bala on 26/05/2021 -- END
	
	//SPEC: <16.11.2021>: Guna Added for  Defect 45787 18x.6.0.2   -- START
	/**
	 * Method Name : checkSecurityAccess
	 * Method Description : TO Check security for SPS parts
	 * @param context
	 * @param slStackPatternfromRefDocs 
	 * @param StingList
	 * @return
	 */
	private Map<String,StringList> checkSecurityAccess(Context context, StringList slStackPatternIdfromRefDocs, StringList slStackPatternfromRefDocs) {
		// TODO Auto-generated method stub
		StringList rtnList1 =new StringList();
		StringList rtnList2 =new StringList();
		Map<String,StringList> rtnMap =new HashMap<String,StringList>();
		boolean bHasOwnership=false;
		try {
			SecurityService sct = new SecurityService();
			if(slStackPatternIdfromRefDocs.size() !=0){
				String sUserType=sct.getUserType();
				for(int j=0;j<slStackPatternIdfromRefDocs.size();j++){
					if(util.isModificatinRequired())
					{
					bHasOwnership=util.checkHasAccess(context, sUserType, (String)slStackPatternIdfromRefDocs.get(j));
					if(bHasOwnership){
						rtnList1.add(slStackPatternfromRefDocs.get(j));
						rtnList2.add(slStackPatternIdfromRefDocs.get(j));
					}else{
						rtnList1.add(ConstantsUtil.EMPTY_STRING);
						rtnList2.add(ConstantsUtil.EMPTY_STRING);
					}
				}else{
					bHasOwnership=util.checkHasAccess(context, sUserType, (String)slStackPatternIdfromRefDocs.get(j));
					if(bHasOwnership){
						rtnList1.add(slStackPatternfromRefDocs.get(j));
						rtnList2.add(slStackPatternIdfromRefDocs.get(j));
					}else{
						rtnList1.add(slStackPatternfromRefDocs.get(j));
						rtnList2.add(ConstantsUtil.NO_ACCESS);
					}
				}
				}
			}
			rtnMap.put("objName", rtnList1);
			rtnMap.put("objID", rtnList2);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : PackingSubAssemblyBO Method :checkSecurityAccess "+e);
		}
		return rtnMap;
	}	
	//SPEC: <16.11.2021>: Guna Added for  Defect 45787 18x.6.0.2   -- END
}
