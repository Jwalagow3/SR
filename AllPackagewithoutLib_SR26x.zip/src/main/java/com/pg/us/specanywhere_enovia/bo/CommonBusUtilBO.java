/**
 * Project 		: SpecsAnywhere
 * Program 		: CommonBusUtilBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.io.StringReader;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

public class CommonBusUtilBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(CommonBusUtilBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();

	public CommonBusUtilBO() {
		// empty constructor
	}

	public CommonBusUtilBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: updateSecurity
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> updateSecurity(Context context,Map objectMap) {
		
		Map<String, String> mpSecurity = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			String sName=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME));
			String sCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE));
			String sType=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE));
			String sDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC));
			
			mpSecurity.put(ConstantsUtil.TYPE, sType);
			mpSecurity.put(ConstantsUtil.NAME, sName);
			mpSecurity.put(ConstantsUtil.STATE, sCurrent);
			mpSecurity.put(ConstantsUtil.DESCRIPTION, sDesc);
			
		}catch(Exception e){
			LOGGER.error("Error from CommonBusUtil: updateSecurity"+e);
			return new HashMap();
		}
		return  util.filterMapList(mpSecurity);
	}
	
	//Modified by JWALA for the ADO defect #7839 -- START 
	/**
	 * Method Name 			: getVendorInfo
	 * Method Description 	: Fetching "Vendor" information
	 * @param context
	 * @param domObj
	 * @return
	 */
	public MapList getVendorInfo(Context context, DomainObject domObj, String sRelationShip) {
		MapList mlObjList = new MapList();
		StringList objectVendorSelects = new StringList(7);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATIONID);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ADDRESS);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ORGANIZATION_NAME);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CITY);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_STATEREGION);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COUNTRY);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHOUSENUMBER);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		objectVendorSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_POSTALCODE);
		objectVendorSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ORGANIZATIONTYPE);
		
		try {
			mlObjList = domObj.getRelatedObjects(context, sRelationShip,
					ConstantsUtil.TYPE_COMPANY, objectVendorSelects, null, true, false, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
		} catch (FrameworkException e) {
			LOGGER.error("Error from CommonBusUtil: getVendorInfo" + e);
			return new MapList();
		}
		
	return mlObjList;
	}
	
	
	/**
	 * Method Name : getCertificationClaims
	 * Method Description : Getting the Certification Claims connect for the Product
	 * @param context
	 * @param strObjectID
	 * @return
	 * @throws Exception
	 */
    public MapList getCertificationClaims (Context context,String strObjectID)throws Exception
    {
      MapList relatedPartList = new MapList();
      boolean isContextPushed = false;
      try
      {
		if(UIUtil.isNotNullAndNotEmpty(strObjectID))
		{
			DomainObject domObj =  DomainObject.newInstance(context, strObjectID) ;
			StringList selectStmts = new StringList();                     // putting elements to StringList
			selectStmts.add(ConstantsUtil.SELECT_ID);
			selectStmts.add(ConstantsUtil.SELECT_NAME);
			selectStmts.add(ConstantsUtil.SELECT_TYPE);
			selectStmts.add(ConstantsUtil.SELECT_REVISION);
			selectStmts.add(ConstantsUtil.SELECT_DESCRIPTION);
			selectStmts.add(ConstantsUtil.SELECT_CURRENT);
			selectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
			selectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
			StringList selectRelStmts = new StringList();
			selectRelStmts.add(ConstantsUtil.SELECT_RELATIONSHIP_NAME);
			
			// Retrieving related item
			Pattern relPattern = new Pattern(ConstantsUtil.REL_PG_PLI_MATERIAL_CERTIFICATIONS);
			Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PG_PLI_MATERIAL_CERTIFICATIONS);
			isContextPushed = true;
			relatedPartList = domObj.getRelatedObjects(context,
			            relPattern.getPattern(),  //relationship pattern
			            typePattern.getPattern(),  // object pattern
			            selectStmts,                 // object selects
			            selectRelStmts,              // relationship selects
			            false,                        // to direction
			            true,                       // from direction
			            (short)1,                    // recursion level
			            null,                        // object where clause
			            null,
			            0);
          }
      }
      catch(Exception e)
      {
            LOGGER.error("Error from CommonBusUtil: getCertificationClaims" + e);
			return new MapList();
      }
      return relatedPartList ;
    }
    
 // Guna Modified for Defect 37250  18x.5.2 Release --START
    public MapList getCertifications (Context context,String strObjectID)throws Exception
    {
    	MapList relatedPartList = new MapList();
    	boolean isContextPushed = false;
    	//SPEC: Added for Defect 42402 by Jwala ## -- START
    	//SPEC: <10.05.2021>: Bala Added for External Requirement 33248 Dev 18x.6.0.1-- START
    	//String sWhere = "current!=Obsolete";
    	String sWhere = ConstantsUtil.EMPTY_STRING;
    	if (util.isModificatinRequired()) {
    		sWhere = "current==Release";
    	}else {
    		sWhere = "current!=Obsolete";
    	}
    	//SPEC: <10.05.2021>: Bala Added for External Requirement 33248 Dev 18x.6.0.1-- END
    	//SPEC: Added for Defect 42402 by Jwala ## -- END
    	try
    	{
    		if(UIUtil.isNotNullAndNotEmpty(strObjectID))
    		{
    			DomainObject domObj =  DomainObject.newInstance(context, strObjectID) ;

    			String strPolicy = domObj.getInfo(context, DomainConstants.SELECT_POLICY);
    			boolean bToDir = false;
    			boolean bFromDir = true;
    			if(UIUtil.isNotNullAndNotEmpty(strPolicy) && (ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT.equals(strPolicy) || ConstantsUtil.POLICY_SUPPLIEREQUIVALENT.equals(strPolicy))){
    				bToDir = true;
    				bFromDir = false;
    			}

    			StringList selectStmts = new StringList(); // putting elements to StringList
    			selectStmts.addElement(ConstantsUtil.SELECT_ID);
    			selectStmts.addElement(ConstantsUtil.SELECT_NAME);
    			selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
    			selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
    			selectStmts.addElement(ConstantsUtil.SELECT_DESCRIPTION);
    			selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);
    			selectStmts.addElement(ConstantsUtil.SELECT_MANUFACTURINGRESPONSIBILITY_NAME);
    			selectStmts.addElement(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_NAME);

    			StringList selectRelStmts = new StringList();
    			selectRelStmts.addElement(ConstantsUtil.SELECT_CERTIFICATION_VALUE);
    			selectRelStmts.addElement(ConstantsUtil.SELECT_CERTIFICATION_EXPIRATION_DATE);
    			selectRelStmts.addElement(ConstantsUtil.SELECT_CERTIFICATION_STATUS);
    			//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- START
    			selectRelStmts.add(ConstantsUtilIRM.SELECT_CERTIFICATION_SOURCE);
    			//SPEC: <19.04.2022>: Guna Added for Req 41754 22x Release  -- END
    			// Retrieving related item
    			Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT);
    			relPattern.addPattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
    			//Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PG_PLI_MATERIAL_CERTIFICATIONS);
    			isContextPushed = true;
    			relatedPartList = domObj.getRelatedObjects(context,
    					relPattern.getPattern(),        //relationship pattern
    					ConstantsUtil.QUERY_WILDCARD,   // object pattern
    					selectStmts,                    // object selects
    					selectRelStmts,                 // relationship selects
    					bToDir,                         // to direction
    					bFromDir,                       // from direction
    					(short)1,                       // recursion level
    					sWhere,                         // relationshipWhere Clause 
    					null,
    					0);
    			//Modified Added for Defect 42402 by Jwala object where clause
    		}
    	}
    	catch(Exception e)
    	{
    		LOGGER.error("Error from CommonBusUtil: getCertifications" + e);
    		return new MapList();
    	}
    	return relatedPartList ;
    }
 // Guna Modified for Defect 37250  18x.5.2 Release --END
   
  
  //SPEC: Release SR18x.5.2 - Added for Defect 39406 by Sanjeeva ## -- START
    public MapList getCertifications (Context context,String strObjectID,String strType)throws Exception
    {
      MapList relatedPartList = new MapList();
      String sWhere = ConstantsUtil.EMPTY_STRING;
      
      //Added by Jwala for the defect 41004 -- START
      if (util.isModificatinRequired()) {
			sWhere = "current==Release";
		}else {
			sWhere = "current!=Obsolete";
		}
      //Added by Jwala for the defect 41004 -- END
      
      try
      {
		if(UIUtil.isNotNullAndNotEmpty(strObjectID))
		{
			DomainObject domObj =  DomainObject.newInstance(context, strObjectID) ;
			
			String strPolicy = domObj.getInfo(context, DomainConstants.SELECT_POLICY);
			  boolean bToDir = false;
			  boolean bFromDir = true;
			  if(UIUtil.isNotNullAndNotEmpty(strPolicy) && (ConstantsUtil.POLICY_MANUFACTUREREQUIVALENT.equals(strPolicy) || ConstantsUtil.POLICY_SUPPLIEREQUIVALENT.equals(strPolicy))){
				  bToDir = true;
				  bFromDir = false;
			  }
			
			StringList selectStmts = new StringList(); // putting elements to StringList
			selectStmts.add(ConstantsUtil.SELECT_ID);
			selectStmts.add(ConstantsUtil.SELECT_NAME);
			selectStmts.add(ConstantsUtil.SELECT_TYPE);
			selectStmts.add(ConstantsUtil.SELECT_REVISION);
			selectStmts.add(ConstantsUtil.SELECT_DESCRIPTION);
			selectStmts.add(ConstantsUtil.SELECT_CURRENT);
			selectStmts.add(ConstantsUtil.SELECT_MANUFACTURINGRESPONSIBILITY_NAME);
			selectStmts.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_NAME);
			
			StringList selectRelStmts = new StringList();
			selectRelStmts.add(ConstantsUtil.SELECT_CERTIFICATION_VALUE);
			selectRelStmts.add(ConstantsUtil.SELECT_CERTIFICATION_EXPIRATION_DATE);
			selectRelStmts.add(ConstantsUtil.SELECT_CERTIFICATION_STATUS);
			//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
			selectRelStmts.add(ConstantsUtilIRM.SELECT_CERTIFICATION_SOURCE);
			//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- END
			
			// Retrieving related item
			Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT);
			relPattern.addPattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
			//Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PG_PLI_MATERIAL_CERTIFICATIONS);
			
			relatedPartList = domObj.getRelatedObjects(context,
			            relPattern.getPattern(),  //relationship pattern
			            ConstantsUtil.QUERY_WILDCARD,  // object pattern
			            selectStmts,                 // object selects
			            selectRelStmts,              // relationship selects
			            bToDir,                        // to direction
			            bFromDir,                       // from direction
			            (short)1,                     // recursion level
			            sWhere,                       // object where clause (Modified by Jwala for the defect 41004 -- START)
			            null,
			            0);
			
          }
      }
      catch(Exception e)
      {
            LOGGER.error("Error from CommonBusUtil: getCertifications" + e);
			return new MapList();
      }
      return relatedPartList ;
    }
  //SPEC: Release SR18x.5.2 - Added for Defect 39406 by Sanjeeva ## -- END

    
    
    /**
     * Method Name 			: getIpClass
     * Method Description 	: Get IP Classification
     * @param context
     * @param doFormObj  - domain object of part
     * @param slIpSelects - Selectable
     */
    public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
    	MapList mlIPCLass;
    	try {
    		mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
    				null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
    				ConstantsUtil.ZERO_LEVEL);
    		Iterator itr = mlIPCLass.iterator();
    		Map mpIpClass = new HashMap();
    		StringBuilder sbIpName = new StringBuilder();
    		//Commented By Jwala for REQ 41754 on 19/04/2022 START
    		//StringBuilder sbHasClassAccess = new StringBuilder();
    		//Commented By Jwala for REQ 41754 on 19/04/2022 END
    		StringBuilder sbIpType = new StringBuilder();
    		StringBuilder sbIpDesc = new StringBuilder();
    		StringBuilder sbIpState = new StringBuilder();
    		StringBuilder sbIpLibrary = new StringBuilder();
    		StringBuilder sbIpClassPath = new StringBuilder();
    		//Added by Manikanta for EBP internal defect on 29/04/2021 START
    		BusObjectAttribUtil Butil = new BusObjectAttribUtil();
    		//Added by Manikanta for EBP internal defect on 29/04/2021 END
    		while(itr.hasNext()) {
    			mpIpClass = (Map)itr.next();
    			String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
    			sbIpName.append(sIpClassName);
    			sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
    			sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
    			sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
    			String strIpClass="";
    			if(sIpClassName.contains(ConstantsUtil.HIR)) {
    				strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
    				sbIpLibrary.append(strIpClass);
    			} else {
    				strIpClass= ConstantsUtil.BUSINESS_USE;
    				sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
    			}
    			if(!strIpClass.isEmpty()) {
    				StringBuilder sbIpClassTemp = new StringBuilder();
    				sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
    				sbIpClassPath.append(sbIpClassTemp.toString());
    			}
    			//Compare user classification against IPName
    			//sbHasClassAccess.append("TRUE");
    			//Commented By Jwala for REQ 41754 on 19/04/2022 START
    			//String sHasAccess = ConstantsUtil.EMPTY_STRING;
    			//Commented By Jwala for REQ 41754 on 19/04/2022 END
    			SecurityService sct = new SecurityService();
    			String sUserlicense = sct.getUserLicense();
    			
    			//Commented By Jwala for REQ 41754 on 19/04/2022 START
				/*
				 * if (sUserlicense.contains(sIpClassName)) {
				 * sHasAccess=ConstantsUtil.TRUE.toUpperCase(); }else{
				 * sHasAccess=ConstantsUtil.FALSE.toUpperCase(); }
				 * 
				 * sbHasClassAccess.append(sHasAccess);
				 */
    			//Commented By Jwala for REQ 41754 on 19/04/2022 END

    			if(itr.hasNext()) {
    				sbIpName.append("|");
    				sbIpType.append("|");
    				sbIpDesc.append("|");
    				sbIpState.append("|");
    				sbIpLibrary.append("|");
    				sbIpClassPath.append("|");
    				//Commented By Jwala for REQ 41754 on 19/04/2022 START
    				//sbHasClassAccess.append("|");
    				//Commented By Jwala for REQ 41754 on 19/04/2022 END
    			}
    		}
    		mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
    		mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
    		mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
    		mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
    		mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
    		mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
    		//Commented By Jwala for REQ 41754 on 19/04/2022 START
    		//mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
    		//Commented By Jwala for REQ 41754 on 19/04/2022 END
    	} catch (FrameworkException e) {
    		e.printStackTrace();
    		LOGGER.error("Error from CommonBusUtil: getIpClass" + e);
    	}
    	return mpIpSecuritySetting;

    }
    
    
    /**
     * Method Name 			: formatData
     * Method Description 	: 
     * @param slData
     * @param sData
     */
    public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
    
    public Map<String, String> getSubstitute(Context context,MapList mapList) 
	{

		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();
		
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentRev = new StringBuilder();
		StringBuilder sbEBOMParentTitle = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMRefDoc= new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMSubType= new StringBuilder();
		StringBuilder sbEBOMEffectDate= new StringBuilder();
		StringBuilder sbEBOMUntilDate= new StringBuilder();
		StringBuilder sbEBOMCobNum= new StringBuilder();
		StringBuilder sbEBOMChildRev= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMSubFor= new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		SecurityService sct = new SecurityService();
		
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();

			String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
			
			
			if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
				String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				StringTokenizer token = new StringTokenizer(sChildName,ConstantsUtil.SYMBL_PIPE);
				/*while(token.hasMoreTokens()) {
				sChildName=token.nextToken().toString().trim();*/
				String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
				String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --START
				//String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --END
				String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
				String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
				
				String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
				String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
				//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --START
				//String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
				String sChildTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
				//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --END
				String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
				//SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --START
				String sSUBType = "";//validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
					

				     if (null != sParentType && ("Raw Material").equals(sParentType)) 
					 {       
				    	sSUBType="Raw";  
				     }
				     else if (null != sParentType && ("pgPackingMaterial").equals(sParentType)) 
					 {
				    	sSUBType="Packaging";
				     } 
				     else {
				    	//Added for Defect# 37591 -- START
				    	//sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
				    	 sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
				    	//Added for Defect# 37591 -- END
				     }
				   //SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --END
				//SPEC: <11.26.2020>: Modified for Defect :37556 by Madhana ## --START		
				//String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
				String sQTY = "";
				sQTY = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
          
		           if (UIUtil.isNullOrEmpty(sQTY))
		          {
		        	   sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
		          }
		           if (sQTY == null)
		           {
		        	   sQTY = "";
		           }
		        //SPEC: <11.26.2020>: Modified for Defect :37556 by Madhana ## --END
				String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
				String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
				String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
				String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
				String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
				String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sOC = util.replaceSpecialSymbols(sOC);
				String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
				String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
				boolean showData = false;
				boolean bHasOwnership=false;
				String sUserlicense = sct.getUserLicense();
				
				if(util.isModificatinRequired())
				{
					//commented by Ganesh for security impl ---->start
					/*SecurityService sec = new SecurityService();
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);

					bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sChildId);*/
					//commented by Ganesh for security impl ---->end
					//modified by Ganesh for security impl-->start
					bHasOwnership = util.checkHasAccess(context, null, sChildId);
					//modified by Ganesh for security impl-->end
					if(!bHasOwnership)
					{
						sParentType = ConstantsUtil.NO_ACCESS;
						sParentID = ConstantsUtil.NO_ACCESS;
						sChildId    = ConstantsUtil.NO_ACCESS;
						sParentName = ConstantsUtil.NO_ACCESS;
						sParentRev = ConstantsUtil.NO_ACCESS;
						sParentTitle = ConstantsUtil.NO_ACCESS;
						sCombinationNum = ConstantsUtil.NO_ACCESS;
						sChildTitle = ConstantsUtil.NO_ACCESS;
						sSUBType = ConstantsUtil.NO_ACCESS;
						sEffectvityDate = ConstantsUtil.NO_ACCESS;
						sRevRelease = ConstantsUtil.NO_ACCESS;
						sUntilDate = ConstantsUtil.NO_ACCESS;
						sRDOC = ConstantsUtil.NO_ACCESS;
						sQTY = ConstantsUtil.NO_ACCESS;
						sBASEUOM = ConstantsUtil.NO_ACCESS;
						sChildRev = ConstantsUtil.NO_ACCESS;
				    }
				}else 
				{
					showData = util.checkHasAccess(context, null, sChildId);
				}
				
				if(!showData){
					sParentType = ConstantsUtil.NO_ACCESS;
					sParentID = ConstantsUtil.NO_ACCESS;
					sChildId    = ConstantsUtil.NO_ACCESS;
					sParentName = ConstantsUtil.NO_ACCESS;
					sParentRev = ConstantsUtil.NO_ACCESS;
					sParentTitle = ConstantsUtil.NO_ACCESS;
					sCombinationNum = ConstantsUtil.NO_ACCESS;
					sChildTitle = ConstantsUtil.NO_ACCESS;
					sSUBType = ConstantsUtil.NO_ACCESS;
					sEffectvityDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sUntilDate = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
				}
				
			
				sChildType = util.mapType(sChildType);

				formatData(sbEBOMName,sChildName);
				formatData(sbEBOMType,sChildType);
				formatData(sbEBOMQTY,sQTY);
				formatData(sbEBOMBuom,sBASEUOM);
				formatData(sbEBOMChildRev,sChildRev);

				formatData(sbEBOMParentType,sParentType);
				formatData(sbEBOMParentId,sParentID);
				formatData(sbEBOMId,sChildId);
				formatData(sbEBOMParentName,sParentName);
				formatData(sbEBOMParentRev,sParentRev);
				formatData(sbEBOMParentTitle,sParentTitle);
				formatData(sbEBOMCobNum,sCombinationNum);
				formatData(sbEBOMTitle,sChildTitle);
				formatData(sbEBOMSubType,sSUBType);
				formatData(sbEBOMRevRelDt,sRevRelease);
				formatData(sbEBOMEffectDate,sEffectvityDate);
				formatData(sbEBOMUntilDate,sUntilDate);
				formatData(sbEBOMRefDoc,sRDOC);
				formatData(sbEBOMCommnts,sComments);
				formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
			}
		}
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
		mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
		mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
		mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
		mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());

		return util.filterMapList(mpEBOMResult);
	}
    

  //SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  	public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
  	{
      	StringValidatorUtil validator = new StringValidatorUtil();
  		Map<String,String> mpEBOMResult = new HashMap<String,String>();
      	try {
  			Iterator objectListItr = mapList.iterator();
  			StringBuilder sbEBOMName = new StringBuilder();
  			StringBuilder sbEBOMParentName = new StringBuilder();
  			StringBuilder sbEBOMParentRev = new StringBuilder();
  			StringBuilder sbEBOMParentTitle = new StringBuilder();
  			StringBuilder sbEBOMId = new StringBuilder();
  			StringBuilder sbEBOMParentId = new StringBuilder();
  			StringBuilder sbEBOMRefDoc= new StringBuilder();
  			StringBuilder sbEBOMTitle = new StringBuilder();
  			StringBuilder sbEBOMType = new StringBuilder();
  			StringBuilder sbEBOMQTY = new StringBuilder();
  			StringBuilder sbEBOMBuom = new StringBuilder();
  			StringBuilder sbEBOMCommnts = new StringBuilder();
  			StringBuilder sbEBOMSubType= new StringBuilder();
  			StringBuilder sbEBOMEffectDate= new StringBuilder();
  			StringBuilder sbEBOMUntilDate= new StringBuilder();
  			StringBuilder sbEBOMCobNum= new StringBuilder();
  			StringBuilder sbEBOMChildRev= new StringBuilder();
  			StringBuilder sbEBOMRevRelDt= new StringBuilder();
  			StringBuilder sbEBOMSubFor= new StringBuilder();
  			StringBuilder sbEBOMParentType = new StringBuilder();
  			StringBuilder sbEBOMChg = new StringBuilder();
  			StringBuilder sbEBOMSFSubType= new StringBuilder();
  			//Added by Subhajit for Req 46464 - Start
  			StringBuilder sbRelRestriction = new StringBuilder();
  			StringBuilder sbRelRestrictionComment= new StringBuilder();
  			//Added by Subhajit for Req 46464 - End
  			
  			SecurityService sct = new SecurityService();
  			String sUserlicense = sct.getUserLicense();
  			while(objectListItr.hasNext())
  			{
  				Map objectMap = (Map) objectListItr.next();
  				boolean showData = false;
  				boolean bHasOwnership=false;
  	
  				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
  				if (!objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
  					continue;
  				}
					
				
  				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
  				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
  				{
  					//String
  					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
  						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
  						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
  						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
  						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
  						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
  						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
  						String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
  						String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE));
  						//Modified for Defect #37282 -- START
  						
  						boolean bChildHasAccess = util.checkHasAccess(context,null,sChildId);
  						
  						
  						sReleaseDate =validator.DateFormatter(sReleaseDate);
  						String sRevRelease = sReleaseDate;
  						
  						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
  						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
  						String sChildTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  						String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
  					     
  						FormulaCardBO FCBO = new FormulaCardBO();
  						String sSUBType =FCBO.getSpecificationSubtypeForSubstitutes(context,sChildId,sChildType);
  					//Added by Ganesh for Internal Defect ----->END
	  					//Added by Subhajit for Req 46464 - Start
  						String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
  						String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
	  					//Added by Subhajit for Req 46464 - End
  						String sQTY = "";
  						sQTY = (String) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGQUANTITY);
  						// <SPEC> 04/02/2021 Modified by Govind for Defect #38628 start
  				           if (UIUtil.isNullOrEmpty(sQTY))
  				          {
  				        	   sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  				          }
  				           if (sQTY == null)
  				           {
  				        	   sQTY = "";
  				           }
  				         String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
  				           if(validator.isNotNullOrEmpty((String)(objectMap.get(ConstantsUtil.CONTEXT_TYPE)))){
  				        	 if(ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase((String)(objectMap.get(ConstantsUtil.CONTEXT_TYPE)))){  
  				            sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM));
  				        	 }
  				         }
  				         //SPEC: Release SR18x.5.2 - Modified for Defect# 38083  by Guna on Date 11/02/2021 -- END
  						String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  						String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
  						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  						
  						//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- START
  						//String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  						String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  						//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- END
  						
	  					//SPEC: 11/09/2020: Modified for Defect : 37019 -- START
	  						String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT));
  						
  						String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
  						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
  						
  						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
  					
  						String sSFSubType =FCBO.getSpecificationSubtypeForSubstitutes(context,sParentID,sParentType); 
  					//Modified by Ganesh for Internal Defect ----->END  
 					     
 					  //SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --END
  						if(!bChildHasAccess) {
  							sChildId    = ConstantsUtil.NO_ACCESS;
  							sChg = ConstantsUtil.NO_ACCESS;
  						}
  						
  						
  						 showData = util.checkHasAccess(context,null,sParentID);
  						
  						
  			
  						
  						if(!showData){
  							sParentID = ConstantsUtil.NO_ACCESS;
  							
  						}
					    sParentType = util.mapType(sParentType.trim());	
  						sChildType = util.mapType(sChildType.trim());
  						
  						util.formatData(sbEBOMName,sChildName);
  						util.formatData(sbEBOMType,sChildType);
  						util.formatData(sbEBOMQTY,sQTY);
  						util.formatData(sbEBOMBuom,sBASEUOM);
  						util.formatData(sbEBOMChildRev,sChildRev);
  						
  						util.formatData(sbEBOMParentType,sParentType);
  						util.formatData(sbEBOMParentId,sParentID);
  						util.formatData(sbEBOMId,sChildId);
  						util.formatData(sbEBOMParentName,sParentName);
  						util.formatData(sbEBOMParentRev,sParentRev);
  						util.formatData(sbEBOMParentTitle,sParentTitle);
  						util.formatData(sbEBOMCobNum,sCombinationNum);
  						util.formatData(sbEBOMTitle,sChildTitle);
  						util.formatData(sbEBOMSubType,sSUBType);
  						util.formatData(sbEBOMRevRelDt,sRevRelease);
  						util.formatData(sbEBOMEffectDate,validator.DateFormatter(sEffectvityDate));
  						util.formatData(sbEBOMUntilDate,validator.DateFormatter(sUntilDate));
  						util.formatData(sbEBOMRefDoc,sRDOC);
  						util.formatData(sbEBOMCommnts,sComments);
  						util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  					    //Added by Subhajit for Req 46464 - Start
				        util.formatData(sbRelRestriction,sRelRestriction);
	  					util.formatData(sbRelRestrictionComment,sRelRestrictionComment);
	  					//Added by Subhajit for Req 46464 - End
  						
  						//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  						util.formatData(sbEBOMChg,sChg);
  						util.formatData(sbEBOMSFSubType,sSFSubType);
  						//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
  					//}
  					}
  				}else {
  					//StringList
  					String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
  					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
  					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
  					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
  					//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --START
  					String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						 showData = util.checkHasAccess(context,null,sParentID);
  					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
  						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
  						for(int i =0; i<slChildId.size(); i++) 
  						{
  							String sEachChildId = slChildId.getElement(i);
  							
  							StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
  							String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
  							
  							//Added for Defect #37282 -- START
  							String strEachChildType = slChildType.getElement(i);
  							
  							boolean 	bChildHasAccess = util.checkHasAccess(context,null,sEachChildId);
  	  						 
  							String sChildSubType ="";
  							StringList slReleaseDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE));
  							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
  							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
  							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
  							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  							
  							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  							//Modified for Defect# 37591 -- END
  							
  							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  							//Release SR18x.5.2 - Added for Defect#39820 by Govind On Date 17/02/2021 start
  							StringList slpgQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGQUANTITY));
  							StringList slBASEUOM =new StringList();
  							 slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
    				           if(validator.isNotNullOrEmpty((String)(objectMap.get(ConstantsUtil.CONTEXT_TYPE)))){
    				        	   if(ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase((String)(objectMap.get(ConstantsUtil.CONTEXT_TYPE)))){  
    				        	   slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM));
    				        	   }
    				          }
  	  					    //SPEC: Release SR18x.5.2 - Modified for Defect# 38083  by Guna on Date 11/02/2021 -- END
  							
  							StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
  							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  							
  							//SPEC: 11/09/2020: Modified for Defect : 37019 -- START
  							//String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  							StringList slOCs =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT));
  							StringList slRefDoc =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  							//SPEC: 11/09/2020: Modified for Defect : 37019 -- END
  							/*String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
  							sOC = util.replaceSpecialSymbols(sOC);*/
  							
  							String sRDOC = slRefDoc.get(i)+ConstantsUtil.SYMBL_COLON+slOCs.get(i);
  							
  							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
  							//SPEC: 11/07/2020: Modified for Defect : 37019 -- START
  							String sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
  							//SPEC: 11/07/2020: Modified for Defect : 37019-- END
  							//Added by Ketan for Defect no. 52797 - Start
  							StringList slRelRestriction =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR));
  							StringList slRelRestrictionComment =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC));
  							//String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
  							//String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
  							//Added by Ketan for Defect no. 52797 - End
  							String sReleaseDate =validator.DateFormatter(slReleaseDate.get(i));
  		  				//SPEC: Release SR18x.6.0 - #Defect#42159 Added  by gaikwad.tg on Date 06 April 2021 -- START
  	  						//String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
  	  		  				String sRevRelease = sReleaseDate;
  	  					//SPEC: Release SR18x.6.0 - #Defect#42159 Added  by gaikwad.tg on Date 06 April 2021 -- END
  		  					
  							//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  							if(bChildHasAccess) {
  								String sChildType = util.mapType(slChildType.get(i));
  								util.formatData(sbEBOMName,slChildName.get(i));
  								util.formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMId,sEachChildId);
  								util.formatData(sbEBOMTitle,slChildTitle.get(i));
  								util.formatData(sbEBOMChg,sChg.get(i));
  								//Added by Ketan for Defect no. 52797,52808 - Start
  								util.formatData(sbRelRestriction,slRelRestriction.get(i));
  								util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
  								//Added by Ketan for Defect no. 52797,52808 - Start
  								//SPEC: <11.27.2020>: Added for Defect #36617 Start
  								if(null!=slBASEUOM) {	
  									util.formatData(sbEBOMBuom,slBASEUOM.get(i));  									
  								}else {
  									util.formatData(sbEBOMBuom,ConstantsUtil.EMPTY_STRING);	
  								} 
  								// SPEC: <11.27.2020>: Added for Defect #36617 End
  							}
  							else
  							{
  								String sChildType = util.mapType(slChildType.get(i));
  								util.formatData(sbEBOMName,slChildName.get(i));
  								util.formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMTitle,slChildTitle.get(i));
  								util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
  							util.formatData(sbRelRestriction,slRelRestriction.get(i));
  							util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
  								if(null!=slBASEUOM) {
  									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
  								}else {
  									util.formatData(sbEBOMBuom,ConstantsUtil.EMPTY_STRING);	
  								}
  							}
  							
								if(null!=slSUBType)
								{
									sChildSubType=slSUBType.get(i);
									String sChildType=slChildType.get(i);
									
			 					     if (null != sChildType && ("Raw Material").equals(sChildType)) 
			 						 {       
			 					    	sChildSubType="Raw";  
			 					     }
			 					     else if (null != sChildType && ("pgRawMaterial").equals(sChildType)) 
									 {       
			 					    	sChildSubType="Raw";  
								     }
			 					     else if (null != sChildType && ("pgPackingMaterial").equals(sChildType)) 
			 						 {
			 					    	sChildSubType="Packaging";
			 					     } 

			 					    else {
			 					    	//Added by Ketan for Defect no. 52944 -- START  
		  								 if("".equals(sChildSubType)) {
		  									FormulaCardBO FCBO = new FormulaCardBO(); 
		  									sChildSubType =FCBO.getSpecificationSubtypeForSubstitutes(context,sEachChildId,sChildType); 
		  								 } 
		  								//Added by Ketan for Defect no. 52944 -- START
			 					     }
			 					    
			 					     if ("pgFinishedProduct".equals(sChildType))
			  						{
			  							if("".equals(sChildSubType)){
			  							sChildSubType="Finished Product";
			  							}
			  							else if("FWIP-Finished Work in Process".equals(sChildSubType)) {
			  							sChildSubType="FWIP-Finished Work in Process";		
			  							}
			  							else if("Purchased Subassembly".equals(sChildSubType)){
			  							sChildSubType="Purchased Subassembly";
			  							}
			  							else if("Purchased and/or Produced Subassembly".equals(sChildSubType)){
			  							sChildSubType="Purchased and/or Produced Subassembly";	
			  							}				
			  						}
								}
								

  								if (null != sParentType && ("Raw Material").equals(sParentType)) 
  								 {       
  							    	sSFSubType="Raw";  
  							     }
  								     else if (null != sParentType && ("pgRawMaterial").equals(sParentType)) 
  								 {       
  								    	sSFSubType="Raw";  
  							     }
  							     else if (null != sParentType && ("pgPackingMaterial").equals(sParentType)) 
  								 {
  							    	sSFSubType="Packaging";
  							     }
  								
  							   else {
  								 //Added by Ketan for Defect no. 52944 -- START  
  								 if("".equals(sSFSubType)) {
  									FormulaCardBO FCBO = new FormulaCardBO(); 
  									sSFSubType =FCBO.getSpecificationSubtypeForSubstitutes(context,sParentID,sParentType); 
  								 } 
  								//Added by Ketan for Defect no. 52944 -- START
		 					     }
  								
  							  if ("pgFinishedProduct".equals(sParentType))
  								{
  									if("".equals(sSFSubType)){
  										sSFSubType="Finished Product";
  									}
  									else if("FWIP-Finished Work in Process".equals(sSFSubType)) {
  										sSFSubType="FWIP-Finished Work in Process";		
  									}
  									else if("Purchased Subassembly".equals(sSFSubType)){
  										sSFSubType="Purchased Subassembly";
  									}
  									else if("Purchased and/or Produced Subassembly".equals(sSFSubType)){
  										sSFSubType="Purchased and/or Produced Subassembly";	
  									}				
  								}
  								
  								
  							//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
  							
  							if(showData) {
  								
  								if(null==slpgQTY || UIUtil.isNullOrEmpty(slpgQTY.get(i))) {
  									if(null!=slQTY) {
  										util.formatData(sbEBOMQTY,validator.getStringEquivalentForStringList(slQTY.get(i)));
  	  								}else {
  	  									util.formatData(sbEBOMQTY,ConstantsUtil.EMPTY_STRING);	
  	  								}
  								//SPEC: <02.19.2021>: Sumit Modified for Defect :36617 ## --START
  								}else {
  									util.formatData(sbEBOMQTY,validator.getStringEquivalentForStringList(slpgQTY.get(i)));
  								}
  							
  								util.formatData(sbEBOMParentType,util.mapType(sParentType));
  								util.formatData(sbEBOMParentId,sParentID);
  								//formatData(sbEBOMId,sEachChildId);
  								util.formatData(sbEBOMParentName,sParentName);
  								util.formatData(sbEBOMParentRev,sParentRev);
  								util.formatData(sbEBOMParentTitle,sParentTitle);
  								if(null!=slCombinationNum) {
  									util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
  								}else {
  									util.formatData(sbEBOMCobNum,ConstantsUtil.EMPTY_STRING);	
  								}
  								
  								util.formatData(sbEBOMSubType,sChildSubType);  
  							
  								util.formatData(sbEBOMRevRelDt,sRevRelease);
  								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
  								util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
  								util.formatData(sbEBOMRefDoc,sRDOC);
  								if(null!=slComments) {
  									util.formatData(sbEBOMCommnts,slComments.get(i));
  								}else {
  									util.formatData(sbEBOMCommnts,ConstantsUtil.EMPTY_STRING);	
  								}
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								
  							
  								util.formatData(sbEBOMSFSubType,sSFSubType);
  							//SPEC: 11/07/2020: Modified for Defect : 37019 -- END
  								
  							}else {
  								
  								if(null==slpgQTY || UIUtil.isNullOrEmpty(slpgQTY.get(i))) {
  									if(null!=slQTY) {
  										util.formatData(sbEBOMQTY,validator.getStringEquivalentForStringList(slQTY.get(i)));
  	  								}else {
  	  									util.formatData(sbEBOMQTY,ConstantsUtil.EMPTY_STRING);	
  	  								}
  								}else {
  									util.formatData(sbEBOMQTY,validator.getStringEquivalentForStringList(slpgQTY.get(i)));
  								}
  								
  								util.formatData(sbEBOMParentType,util.mapType(sParentType));
  								util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMParentName,sParentName);
  								util.formatData(sbEBOMParentRev,sParentRev);
								util.formatData(sbEBOMParentTitle,sParentTitle);
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
  								util.formatData(sbEBOMSubType,sChildSubType);
  								util.formatData(sbEBOMRevRelDt,sRevRelease);
  								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
  								util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
  								util.formatData(sbEBOMRefDoc,sRDOC);
  								util.formatData(sbEBOMCommnts,slComments.get(i));
  								util.formatData(sbEBOMSFSubType,sSFSubType);
  								
  							}
  						}
  					}
  				}

  			}
  			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
  			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
  			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
  			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
  			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
  			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
  			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
  			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
  			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
  			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
  			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
  			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
  		//SPEC: <23.09.2021>: Guna Modified for 37083 and 44189 Defect  Dev 18x.6.0.2   -- START
  		//Reverted the changes 
  			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
  			mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRefDoc.toString());
  		//SPEC: <23.09.2021>: Guna Modified for 37083 and 44189 Defect  Dev 18x.6.0.2   -- END
  			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
  			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
  			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
  			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
  			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
  			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
  			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
  			//Added by Subhajit for Req 46464 - Start
  			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
  			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
  			//Added by Subhajit for Req 46464 - End
      	}catch(Exception e) {
      		
      		e.printStackTrace();
      		LOGGER.info("Exception In CommonBusUtilBO : parseSubstitute: "+e);
      	}
  		return util.filterMapList(mpEBOMResult);
  	
  	}
  	
  	//Modified for Defect #37282 -- START
  	//public boolean checkSubstituteHasAccess(Context context, Map objectMap) {
  	
  	public boolean checkSubstituteHasAccess(Context context, Map objectMap, String strChildType, String strChildId) {
  		
  	//Modified for Defect #37282 -- END
  		StringBuilder  sbReturnVal = new StringBuilder();
  		boolean showData = false;
  		try
  		{
  			StringValidatorUtil validator = new StringValidatorUtil();
  			
  			StringList slHIRTypes = new StringList();
  			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
  			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
  			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
  			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
  			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
  			slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);

  			SecurityService sct = new SecurityService();
  			String sUserlicense = sct.getUserLicense();
  			String sComp = sct.getUserCauthorities();
  			StringList slUserOwnership=util.filterOwnerShip(sComp);
  			//Added for Defect #37282 -- START
			String strSubPartType = new String();
			String strSubPartId = new String();
			//Added for Defect #37282 -- END
  		if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))
  			{
  				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName();
  				//Modified for Defect #37282 -- START
  				//if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
  				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING) || sClassName.equalsIgnoreCase(ConstantsUtil.STRINGLIST))
  				{
  					if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
	  					strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
	  					strSubPartId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
  					} else
  					{
  						
  						strSubPartType = strChildType;
  						strSubPartId = strChildId;
  						
  					}
  					//Modified for Defect #37282 -- END
  					//DomainObject doEachChild = new DomainObject(strSubPartId);
  					DomainObject doEachChild = DomainObject.newInstance(context, strSubPartId);
  					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
  					StringList slSelect = new StringList();
  					slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
  					Map mpIpClass = doEachChild.getInfo(context, slSelect);
  					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
  					doEachChild.close(context);
  					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
  					StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
  					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
  					showData = util.checkHasAccess(context, null, strSubPartId);
 						
  				}//close bracket for string
  				
  				}else
  			{	//If no Substitue found
  				return showData;
  			}
  			
  		}catch(Exception e){
  			
  			LOGGER.error("Error from CommonBusUtil :  checkSubstituteHasAccess" + e);
  			return showData;
  		}
  		return showData;
  	}
  	//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
  	
  	
  	public MapList getRMPCertifications (Context context,String strObjectID)throws Exception
    {
      MapList relatedPartList = new MapList();
      boolean isContextPushed = false;
      try
      {
		if(UIUtil.isNotNullAndNotEmpty(strObjectID))
		{
			DomainObject domObj =  DomainObject.newInstance(context, strObjectID) ;
			StringList selectStmts = new StringList();                     // putting elements to StringList
			selectStmts.addElement(ConstantsUtil.SELECT_ID);
			selectStmts.addElement(ConstantsUtil.SELECT_NAME);
			selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
			selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
			selectStmts.addElement(ConstantsUtil.SELECT_DESCRIPTION);
			selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);
			selectStmts.addElement(ConstantsUtil.SELECT_MANUFACTURINGRESPONSIBILITY_NAME);
			selectStmts.addElement(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
			selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
			/*StringList selectRelStmts = new StringList();
			selectRelStmts.addElement(ConstantsUtil.SELECT_RELATIONSHIP_NAME);*/
			
			// Retrieving related item
			Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_MANUFACTUREREQUIVALENT);
			relPattern.addPattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
			//Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PG_PLI_MATERIAL_CERTIFICATIONS);
			isContextPushed = true;
			relatedPartList = domObj.getRelatedObjects(context,
			            relPattern.getPattern(),  //relationship pattern
			            ConstantsUtil.QUERY_WILDCARD,  // object pattern
			            selectStmts,                 // object selects
			            new StringList(),              // relationship selects
			            false,                        // to direction
			            true,                       // from direction
			            (short)1,                    // recursion level
			            null,                        // object where clause
			            null,
			            0);
          }
      }
      catch(Exception e)
      {
            LOGGER.error("Error from CommonBusUtil: getRMPCertifications" + e);
			return new MapList();
      }
      return relatedPartList ;
    }
  	
  	/** added for Defect 37243
	 * Method Name : getCertificationForSEP
	 * Method Description : Getting the Certification  connect to SEP type
	 * @param context
	 * @param strObjectID
	 * @return
	 * @throws Exception
	 */
    public MapList getCertificationForSEP (Context context,String strObjectID)throws Exception
    {
      MapList relatedPartList = new MapList();
      boolean isContextPushed = false;
      try
      {
		if(UIUtil.isNotNullAndNotEmpty(strObjectID))
		{
			DomainObject domObj =  DomainObject.newInstance(context, strObjectID) ;
			StringList selectStmts = new StringList();                     // putting elements to StringList
			selectStmts.addElement(ConstantsUtil.SELECT_ID);
			selectStmts.addElement(ConstantsUtil.SELECT_NAME);
			selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
			selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
			selectStmts.addElement(ConstantsUtil.SELECT_DESCRIPTION);
			selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);
			selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
			selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
			
			StringList selectRelStmts = new StringList();
			selectRelStmts.addElement(ConstantsUtil.SELECT_RELATIONSHIP_NAME);
			
			// Retrieving related item
			Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
			//Commented for Defect 37243
			//Pattern typePattern = new Pattern(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART);
			isContextPushed = true;
			relatedPartList = domObj.getRelatedObjects(context,
			            relPattern.getPattern(),  //relationship pattern
			            ConstantsUtil.SYMBL_ASTERISK,  // object pattern
			            selectStmts,                 // object selects
			            selectRelStmts,              // relationship selects
			            true,                        // to direction
			            false,                       // from direction
			            (short)0,                    // recursion level
			            "current == Release",                        // object where clause
			            null,
			            0);
          }
      }
      catch(Exception e)
      {
            LOGGER.error("Error from CommonBusUtil: getCertificationForSEP" + e);
			return new MapList();
      }
      return relatedPartList ;
    }
    
    /**
     * Added for getting teh SpecSubTYpe Value.
     * It needs more type values to be added
     * @param Type
     * @param sSFSubTypeValue
     * @return
     */
    
    
    public String getSubstituteSpecSUbType(String Type ,	String sSFSubTypeValue){
    	
			String sSFSubType = "";
				
	     if (null != Type && ("Raw Material").equals(Type)) 
		 {       
	    	sSFSubType="Raw";  
	     }
		     else if (null != Type && ("pgRawMaterial").equals(Type)) 
		 {       
		    	sSFSubType="Raw";  
	     }
	     else if (null != Type && ("pgPackingMaterial").equals(Type)) 
		 {
	    	sSFSubType="Packaging";
	     } 
		   else  if ("pgFinishedProduct".equals(Type))
		{
			if("".equals(sSFSubType)){
				sSFSubType="Finished Product";
			}
			else if("FWIP-Finished Work in Process".equals(sSFSubType)) {
				sSFSubType="FWIP-Finished Work in Process";		
			}
			else if("Purchased Subassembly".equals(sSFSubType)){
				sSFSubType="Purchased Subassembly";
			}
			else if("Purchased and/or Produced Subassembly".equals(sSFSubType)){
				sSFSubType="Purchased and/or Produced Subassembly";	
			}				
		}else if("Packaging Material Part".equals(Type)) {
			sSFSubType="Packaging";
		}
	   else {
	    	sSFSubType =sSFSubType;
	     }   
			 
	     return sSFSubType;
			
    }
    
    /**
	 * Method Name 			: getAlternates
	 * Method Description 	: Added new method for Defect#37664 1.0.2 Release - Jwala
	 * @param resultMaps
	 * @return
	 * @throws Exception 
	 */
    // SPEC: <12.29.2020>: Govind Modified for Requirement #36391 Start
    
	public Map getAlternates(Context context, String sContextObjectId) throws Exception {
		
		Map<String, String> mpAlternates = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID	 =  new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		StringBuilder sbCertifications = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
		StringBuilder sbWeight = new StringBuilder();
		//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END
		
		//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		try {
		//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			SecurityService sec = new SecurityService();
			String sComp = sec.getUserCauthorities();
			StringList slUserOwnership=util.filterOwnerShip(sComp);
			
			StringList slRelSelects = new StringList();
			//SPEC: Release SR18x.6.0 - Modified for REQ#38400  by Dominic on Date 17/03/2021 -- START
			String strWhere = "current==Release";
			
			//DomainObject doAlternates = new DomainObject(sContextObjectId);
			DomainObject doAlternates = DomainObject.newInstance(context, sContextObjectId);
			
			MapList mlAlternates = doAlternates.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_ALTERNATE,
					DomainConstants.QUERY_WILDCARD, slBusSelects, null, false, true, (short) 1,
					strWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL); 
			
			//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
			 String strContextObjectGrossWeightUOM = doAlternates.getAttributeValue(context,ConstantsUtil.ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			 
			// SPEC <17/03/2021>Guna Modified for Defect 40790  18x.6 Release -- START
			 String strContextObjectGrossWeight=doAlternates.getAttributeValue(context,ConstantsUtil.ATTRIBUTE_PGGROSSWEIGHTREAL);
			 BigDecimal contextGrossWeight = new BigDecimal(0.0);
			 if(UIUtil.isNotNullAndNotEmpty(strContextObjectGrossWeight)) {
					contextGrossWeight =new BigDecimal(strContextObjectGrossWeight);
				}	
			
			// SPEC <25.03.2021>Guna Modified for Defect 40790  18x.6 Release -- START
			 String strContextObjectBaseUOM=doAlternates.getAttributeValue(context, ConstantsUtil.ATTRIBUTE_PGBASEUNITOFMEASURE);
			// SPEC <25.03.2021>Guna Modified for Defect 40790  18x.6 Release -- END
			
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			 doAlternates.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			 
			Iterator objectListItr = mlAlternates.iterator();
			
			while(objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				
				String strID = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ID));
				String strName = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_NAME));
				String strType = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_TYPE));
				String strRev = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_REVISION));
				String strState = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String strDec = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				//SPEC: <23.02.2021>: Guna Modified for Dev 18x.6   -- START
				//String strCerti = getCertification(context,sContextObjectId);
				String strCerti = getCertification(context,strID);
				//SPEC: <23.02.2021>: Guna Modified for Dev 18x.6   -- END
				String strPhase = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
				//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
				String strGrossWeight = ConstantsUtil.EMPTY_STRING;
				  strGrossWeight = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
				 String strBaseUOM = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
				 String strweightUOM = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
				 BigDecimal grossWeight = new BigDecimal(strGrossWeight);
				// SPEC <25.03.2021>Guna Added for Defect 40790  18x.6 Release -- START
				String  sWeight =ConstantsUtil.EMPTY_STRING;
				 if(!strBaseUOM.equals(strContextObjectBaseUOM)) {
					 sWeight = ConstantsUtilIRM.BASEUOMNOTSAME;
					}
					else 
					{
						if( contextGrossWeight.compareTo( new BigDecimal(0.0))==0) {
							//If Context part s primary and Gross weigh is 0 the % Change cannot be calculated.				
							 sWeight = ConstantsUtilIRM.PRIMARYWEIGHTZERO;
						}
						else 
						{							
							if(UIUtil.isNullOrEmpty(strGrossWeight)) 
							{
								 sWeight = ConstantsUtilIRM.PRIMARYWEIGHTZERO;
							}
							else{
				      BigDecimal strCalculatedPercent =calculatePercentage(context, contextGrossWeight, strweightUOM, grossWeight, strContextObjectGrossWeightUOM);
				      sWeight = strCalculatedPercent.toString() + " %";
							}
						}
					}
				// SPEC <25.03.2021>Guna Modified for Defect 40790  18x.6 Release -- END
				 // SPEC <17/03/2021>Guna Modified for Defect 40790  18x.6 Release -- END
				
				 //SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END
				SecurityService sct = new SecurityService();
				boolean showData = false;
				boolean bHasOwnership = false;
				
				String sUserType = sct.getUserType();
				showData = util.checkHasAccess(context, sUserType, strID);
				
				if(!showData){
					//SPEC: 01-09-2022: Dominic Added for SR22x.0_NovemberCW Defect 50442-- START	
					if(util.isModificatinRequired()){
						continue;
					}
					else
					{
					//SPEC: 01-09-2022: Dominic Added for SR22x.0_NovemberCW Defect 50442-- END
						strID = ConstantsUtil.NO_ACCESS;
						strDec =ConstantsUtil.NO_ACCESS;
						strCerti =ConstantsUtil.NO_ACCESS;
						strState =ConstantsUtil.NO_ACCESS;
						strPhase =ConstantsUtil.NO_ACCESS;
						sWeight =ConstantsUtil.NO_ACCESS;
					//SPEC: 01-09-2022: Dominic Added for SR22x.0_NovemberCW Defect 50442-- START
					}
					//SPEC: 01-09-2022: Dominic Added for SR22x.0_NovemberCW Defect 50442-- ENDs
				}
				// SPEC <25.03.2021>Guna Modified for Defect 41673  18x.6 Release -- END
				if(!ConstantsUtil.RELEASED.equalsIgnoreCase(strState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strState))){
					strID = ConstantsUtil.NO_ACCESS;
				}
				
				util.formatData(sbType, util.mapType(strType));
				util.formatData(sbName, strName);
				util.formatData(sbID, strID);
				util.formatData(sbRev, strRev);
				util.formatData(sbDesc, strDec);
				util.formatData(sbCertifications, strCerti);
				util.formatData(sbCurrent, strState);
				util.formatData(sbPhase, strPhase);
				//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
				// SPEC <25.03.2021>Guna Modified for Defect 40790  18x.6 Release -- START
				//util.formatData(sbWeight, strCalculatedPercent.toString() + " %");
				util.formatData(sbWeight,sWeight);
				// SPEC <25.03.2021>Guna Modified for Defect 40790  18x.6 Release -- END
				//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END
				
			}
			
			mpAlternates.put(ConstantsUtil.NAME,sbName.toString() );
			mpAlternates.put(ConstantsUtil.REV, sbRev.toString());
			mpAlternates.put(ConstantsUtil.TYPE, sbType.toString());
			mpAlternates.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpAlternates.put(ConstantsUtil.PHASE, sbPhase.toString());
			mpAlternates.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
			mpAlternates.put(ConstantsUtil.CERTIFICATIONS, sbCertifications.toString());
			mpAlternates.put(ConstantsUtil.ID, sbID.toString());
			//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
			mpAlternates.put(ConstantsUtil.WEIGHTDIFFERENCE, sbWeight.toString());
			//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END
		//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		}catch(Exception e)
		{
			LOGGER.error("Error from CommonBusUtilBO:  getAlternates"+e);
			return new HashMap();
		}
		//SPEC: <08-11-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
		return mpAlternates;
	}
	// SPEC: <12.29.2020>: Govind Modified for Requirement #36391 END
	
	//SPEC: Added for Defect#37664 1.0.2 Release - Jwala -- START
	/**
	 * 
	 * @param context
	 * @param sobjId
	 * @return
	 */
	public String getCertification(Context context,String sobjId) 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbRF = new StringBuilder();
		String sSForCertificatins=ConstantsUtil.EMPTY_STRING;
		try
		{
			//DomainObject dob = new DomainObject(sobjId);
			DomainObject dob = DomainObject.newInstance(context, sobjId);
			 sSForCertificatins=	validator.getStringEquivalentForStringList(dob.getInfo(context, ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME));
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			 dob.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if(UIUtil.isNotNullAndNotEmpty(sSForCertificatins)) 
			{
				sSForCertificatins = ConstantsUtil.SYMBL_YES;
			}else 
			{
				sSForCertificatins = ConstantsUtil.SYMBL_NO;
			}
										
		}catch(Exception e)
		{
			LOGGER.error("Error from CommonBusUtilBO:  getCertification"+e);
			return ConstantsUtil.EMPTY_STRING;
		}
		return sSForCertificatins;
		}
	//SPEC: Added for Defect#37664 1.0.2 Release - Jwala -- END
	
	//SPEC: <01.04.2021>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
  	public Map<String, String> parseSubstitutes(Context context,MapList mapList) throws Exception 
  	{
      	StringValidatorUtil validator = new StringValidatorUtil();
  		Map<String,String> mpEBOMResult = null;
  		Map mpFinal = new HashMap();
      	try {
  			Iterator objectListItr = mapList.iterator();
  			SecurityService sct = new SecurityService();
  			String sUserlicense = sct.getUserLicense();
  			int j=0;
			while(objectListItr.hasNext())
			{
				mpEBOMResult = new HashMap<String,String>();
				StringBuilder sbEBOMName = new StringBuilder();
	  			StringBuilder sbEBOMParentName = new StringBuilder();
	  			StringBuilder sbEBOMParentRev = new StringBuilder();
	  			StringBuilder sbEBOMParentTitle = new StringBuilder();
	  			StringBuilder sbEBOMId = new StringBuilder();
	  			StringBuilder sbEBOMParentId = new StringBuilder();
	  			StringBuilder sbEBOMRefDoc= new StringBuilder();
	  			StringBuilder sbEBOMTitle = new StringBuilder();
	  			StringBuilder sbEBOMType = new StringBuilder();
	  			StringBuilder sbEBOMQTY = new StringBuilder();
	  			StringBuilder sbEBOMBuom = new StringBuilder();
	  			StringBuilder sbEBOMCommnts = new StringBuilder();
	  			StringBuilder sbEBOMSubType= new StringBuilder();
	  			StringBuilder sbEBOMEffectDate= new StringBuilder();
	  			StringBuilder sbEBOMUntilDate= new StringBuilder();
	  			StringBuilder sbEBOMCobNum= new StringBuilder();
	  			StringBuilder sbEBOMChildRev= new StringBuilder();
	  			StringBuilder sbEBOMRevRelDt= new StringBuilder();
	  			StringBuilder sbEBOMSubFor= new StringBuilder();
	  			StringBuilder sbEBOMParentType = new StringBuilder();
	  			StringBuilder sbEBOMChg = new StringBuilder();
	  			StringBuilder sbEBOMSFSubType= new StringBuilder();
  			
  				Map objectMap = (Map) objectListItr.next();
  				boolean showData = false;
  				boolean bHasOwnership=false;
  	
  				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
  				if (!objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
  					continue;
  				}
					
				
  				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
  				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
  				{
  					//String
  					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
  						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
  						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
  						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
  						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
  						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
  						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
  						//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --START
  						//String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
  						String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
  						//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --END
  						String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE));

  						boolean bChildHasAccess = util.checkHasAccess(context,null,sChildId);
  						
  						
  						//Modified for Defect #37282 -- END
  						
  						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- START
  						sReleaseDate =validator.DateFormatter(sReleaseDate);
  						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- END
  						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
  						
  						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
  						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
  						//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --START	
  						//String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  						String sChildTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  						//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --END
  						String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
  						//SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --START
  						String sSUBType = "";


  						if (null != sChildType && ("Raw Material").equals(sChildType)) 
  						{       
  							sSUBType="Raw";  
  						}
  						else if (null != sChildType && ("pgRawMaterial").equals(sChildType)) 
  						{       
  							sSUBType="Raw";  
  						}
  						else if (null != sChildType && ("pgPackingMaterial").equals(sChildType)) 
  						{
  							sSUBType="Packaging";
  						} 

  						else 
  						{
  							//sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
  							sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  						}
 						
  					     if ("pgFinishedProduct".equals(sChildType))
  						{
  							if("".equals(sSUBType)){
  								sSUBType="Finished Product";
  							}
  							else if("FWIP-Finished Work in Process".equals(sSUBType)) {
  								sSUBType="FWIP-Finished Work in Process";		
  							}
  							else if("Purchased Subassembly".equals(sSUBType)){
  								sSUBType="Purchased Subassembly";
  							}
  							else if("Purchased and/or Produced Subassembly".equals(sSUBType)){
  								sSUBType="Purchased and/or Produced Subassembly";	
  							}				
  						}
  					     
  					     //SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --END	
  					  
  						//SPEC: <11.26.2020>: Modified for Defect :37556 by Madhana ## --START		
  						//String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  						String sQTY = "";
  						sQTY = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
  		          
  				           if (UIUtil.isNullOrEmpty(sQTY))
  				          {
  				        	   sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  				          }
  				           if (sQTY == null)
  				           {
  				        	   sQTY = "";
  				           }
  				        //SPEC: <11.26.2020>: Modified for Defect :37556 by Madhana ## --END
  						String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
  						String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  						String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
  						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  						
  						//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- START
  						//String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  						String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  						//SPEC: <11.11.2020>: Modified for Defect 37085 ## -- END
  						
	  					//SPEC: 11/09/2020: Modified for Defect : 37019 -- START
	  						String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT));
	  						/*String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
	  						sOC = util.replaceSpecialSymbols(sOC);*/
	  					//SPEC: 11/09/2020: Modified for Defect : 37019 -- END
  						
  						String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
  						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
  						
  						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
  						
  					//SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --START
  						//String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
  						
  						
  						String sSFSubType = "";
		  					
 					     if (null != sParentType && ("Raw Material").equals(sParentType)) 
 						 {       
 					    	sSFSubType="Raw";  
 					     }
 					     else if (null != sParentType && ("pgRawMaterial").equals(sParentType)) 
						 {       
 					    	sSFSubType="Raw";  
					     }
 					     else if (null != sParentType && ("pgPackingMaterial").equals(sParentType)) 
 						 {
 					    	sSFSubType="Packaging";
 					     } 
 					    /*else if("Packaging Material Part".equalsIgnoreCase(sParentType)) {
 					   	sSFSubType="Packaging";
 					    }*/
 							
 					    else {
 					    	sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
 					     }
 					    
 					     if ("pgFinishedProduct".equals(sParentType))
  						{
  							if("".equals(sSFSubType)){
  								sSFSubType="Finished Product";
  							}
  							else if("FWIP-Finished Work in Process".equals(sSFSubType)) {
  								sSFSubType="FWIP-Finished Work in Process";		
  							}
  							else if("Purchased Subassembly".equals(sSFSubType)){
  								sSFSubType="Purchased Subassembly";
  							}
  							else if("Purchased and/or Produced Subassembly".equals(sSFSubType)){
  								sSFSubType="Purchased and/or Produced Subassembly";	
  							}				
  						}
 					     
 					     
 					     
 					  //SPEC: <11.27.2020>: Modified for Defect :37591 by Madhana ## --END
  						if(!bChildHasAccess) {
  							sChildId    = ConstantsUtil.NO_ACCESS;
  							sChg = ConstantsUtil.NO_ACCESS;
  						}
  						
  						
  						 showData = util.checkHasAccess(context,null,sParentID);
  						
  						
  			
  						
  						if(!showData){
  							sParentID = ConstantsUtil.NO_ACCESS;
  						}
  					
  						sChildType = util.mapType(sChildType.trim());
  						sParentType = util.mapType(sParentType.trim());
  	
  						util.formatData(sbEBOMName,sChildName);
  						util.formatData(sbEBOMType,sChildType);
  						util.formatData(sbEBOMQTY,sQTY);
  						util.formatData(sbEBOMBuom,sBASEUOM);
  						util.formatData(sbEBOMChildRev,sChildRev);
  						
  						util.formatData(sbEBOMParentType,sParentType);
  						util.formatData(sbEBOMParentId,sParentID);
  						util.formatData(sbEBOMId,sChildId);
  						util.formatData(sbEBOMParentName,sParentName);
  						util.formatData(sbEBOMParentRev,sParentRev);
  						util.formatData(sbEBOMParentTitle,sParentTitle);
  						util.formatData(sbEBOMCobNum,sCombinationNum);
  						util.formatData(sbEBOMTitle,sChildTitle);
  						util.formatData(sbEBOMSubType,sSUBType);
  						util.formatData(sbEBOMRevRelDt,sRevRelease);
  						util.formatData(sbEBOMEffectDate,validator.DateFormatter(sEffectvityDate));
  						util.formatData(sbEBOMUntilDate,validator.DateFormatter(sUntilDate));
  						util.formatData(sbEBOMRefDoc,sRDOC);
  						util.formatData(sbEBOMCommnts,sComments);
  						util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  						
  						//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
  						util.formatData(sbEBOMChg,sChg);
  						util.formatData(sbEBOMSFSubType,sSFSubType);
  						//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
  					//}
  					}
  				}else {
  					//StringList
  					String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
  					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
  					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
  					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
  					//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --START
  					String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
  					//SPEC: <11.30.2020>: Modified for Defect :37591 by Govind ## --END
						 showData = util.checkHasAccess(context,null,sParentID);
  					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
  						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
  						for(int i =0; i<slChildId.size(); i++) 
  						{
  							String sEachChildId = slChildId.getElement(i);
  							
  							StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
  							String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
  							
  							String strEachChildType = slChildType.getElement(i);
  							boolean 	bChildHasAccess = util.checkHasAccess(context,null,sEachChildId);
  							
  							String sChildSubType ="";
  							StringList slReleaseDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE));
  							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
  							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
  							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
  							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
  							
  							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  							
  							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
  							StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
  							StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
  							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
  							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
  							
  							StringList slOCs =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT));
  							StringList slRefDoc =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
  							
  							String sRDOC = slRefDoc.get(i)+ConstantsUtil.SYMBL_COLON+slOCs.get(i);
  							
  							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
  							String sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
  							
  							String sReleaseDate =validator.DateFormatter(slReleaseDate.get(i));
  		  					String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;

  							if(bChildHasAccess) {
  								String sChildType = util.mapType(slChildType.get(i));
  								util.formatData(sbEBOMName,slChildName.get(i));
  								util.formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMId,sEachChildId);
  								util.formatData(sbEBOMTitle,slChildTitle.get(i));
  								util.formatData(sbEBOMChg,sChg.get(i));
  								if(null!=slBASEUOM) {	
  									util.formatData(sbEBOMBuom,slBASEUOM.get(i));  									
  								}else {
  									util.formatData(sbEBOMBuom,ConstantsUtil.EMPTY_STRING);	
  								} 
  							}
  							else
  							{
  								String sChildType = util.mapType(slChildType.get(i));
  								util.formatData(sbEBOMName,slChildName.get(i));
  								util.formatData(sbEBOMType,sChildType);
  								util.formatData(sbEBOMChildRev,slChildRev.get(i));
  								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMTitle,slChildTitle.get(i));
  								util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
  							}
  						
								if(null!=slSUBType)
								{
									sChildSubType=slSUBType.get(i);
									String sChildType=slChildType.get(i);
									
			 					     if (null != sChildType && ("Raw Material").equals(sChildType)) 
			 						 {       
			 					    	sChildSubType="Raw";  
			 					     }
			 					     else if (null != sChildType && ("pgRawMaterial").equals(sChildType)) 
									 {       
			 					    	sChildSubType="Raw";  
								     }
			 					     else if (null != sChildType && ("pgPackingMaterial").equals(sChildType)) 
			 						 {
			 					    	sChildSubType="Packaging";
			 					     } 
			 					    else {
			 					    	sChildSubType =sChildSubType;
			 					     }
			 					    
			 					     if ("pgFinishedProduct".equals(sChildType))
			  						{
			  							if("".equals(sChildSubType)){
			  							sChildSubType="Finished Product";
			  							}
			  							else if("FWIP-Finished Work in Process".equals(sChildSubType)) {
			  							sChildSubType="FWIP-Finished Work in Process";		
			  							}
			  							else if("Purchased Subassembly".equals(sChildSubType)){
			  							sChildSubType="Purchased Subassembly";
			  							}
			  							else if("Purchased and/or Produced Subassembly".equals(sChildSubType)){
			  							sChildSubType="Purchased and/or Produced Subassembly";	
			  							}				
			  						}
								}
								

  								if (null != sParentType && ("Raw Material").equals(sParentType)) 
  								 {       
  							    	sSFSubType="Raw";  
  							     }
  								     else if (null != sParentType && ("pgRawMaterial").equals(sParentType)) 
  								 {       
  								    	sSFSubType="Raw";  
  							     }
  							     else if (null != sParentType && ("pgPackingMaterial").equals(sParentType)) 
  								 {
  							    	sSFSubType="Packaging";
  							     } 
  							   else {
  								 sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
		 					     }
  								
  							  if ("pgFinishedProduct".equals(sParentType))
  								{
  									if("".equals(sSFSubType)){
  										sSFSubType="Finished Product";
  									}
  									else if("FWIP-Finished Work in Process".equals(sSFSubType)) {
  										sSFSubType="FWIP-Finished Work in Process";		
  									}
  									else if("Purchased Subassembly".equals(sSFSubType)){
  										sSFSubType="Purchased Subassembly";
  									}
  									else if("Purchased and/or Produced Subassembly".equals(sSFSubType)){
  										sSFSubType="Purchased and/or Produced Subassembly";	
  									}				
  								}
  							
  							if(showData) {
  								if(null!=slQTY) {
  									util.formatData(sbEBOMQTY,slQTY.get(i));
  								}else {
  									util.formatData(sbEBOMQTY,ConstantsUtil.EMPTY_STRING);	
  								}
  								
  								if(null!=slBASEUOM) {
  									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
  								}else {
  									util.formatData(sbEBOMBuom,ConstantsUtil.EMPTY_STRING);	
  								}
  								
  								util.formatData(sbEBOMParentType,util.mapType(sParentType));
  								util.formatData(sbEBOMParentId,sParentID);
  								util.formatData(sbEBOMParentName,sParentName);
  								util.formatData(sbEBOMParentRev,sParentRev);
  								util.formatData(sbEBOMParentTitle,sParentTitle);
  								if(null!=slCombinationNum) {
  									util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
  								}else {
  									util.formatData(sbEBOMCobNum,ConstantsUtil.EMPTY_STRING);	
  								}
  								
  								util.formatData(sbEBOMSubType,sChildSubType);  
  							
  								util.formatData(sbEBOMRevRelDt,sRevRelease);
  								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
  								util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
  								util.formatData(sbEBOMRefDoc,sRDOC);
  								if(null!=slComments) {
  									util.formatData(sbEBOMCommnts,slComments.get(i));
  								}else {
  									util.formatData(sbEBOMCommnts,ConstantsUtil.EMPTY_STRING);	
  								}
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								
  								util.formatData(sbEBOMSFSubType,sSFSubType);
  								
  							}else {
  								util.formatData(sbEBOMQTY,slQTY.get(i));
  								if(null!=slBASEUOM) {
  									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
  								}else {
  									util.formatData(sbEBOMBuom,ConstantsUtil.EMPTY_STRING);	
  								}
  								util.formatData(sbEBOMParentType,util.mapType(sParentType));
  								util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
  								util.formatData(sbEBOMParentName,sParentName);
  								util.formatData(sbEBOMParentRev,sParentRev);
								util.formatData(sbEBOMParentTitle,sParentTitle);
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
  								util.formatData(sbEBOMSubType,sChildSubType);
  								util.formatData(sbEBOMRevRelDt,sRevRelease);
  								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
  								util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
  								util.formatData(sbEBOMRefDoc,sRDOC);
  								util.formatData(sbEBOMCommnts,slComments.get(i));
  								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
  								util.formatData(sbEBOMSFSubType,sSFSubType);
  								
  							}
  						}
  					}
  				}
  			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
  			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
  			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
  			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
  			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
  			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
  			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
  			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
  			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
  			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
  			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
  			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
  			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
  			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
  			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
  			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
  			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
  			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
  			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
  			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
  			mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
  			if(!(util.filterMapList(mpEBOMResult)).isEmpty()) {
				mpFinal.put(j, mpEBOMResult);
				j++;
			}
			}
  			
      	}catch(Exception e) {
      		
      		e.printStackTrace();
      		LOGGER.error("Exception In CommonBusUtilBO : parseSubstitutes: "+e);
      		return new HashMap();
      	}
  		return mpFinal;
  	
  	}
  //SPEC: <01.04.2021>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS
  	
  	
  	
	/**
	 * Added on 05 -Jan-2020 by Infosys  on 6-Jan-2021 for  Requirement 38258 --START
	 * @param context
	 * @param sId
	 * @param sType
	 * @param sRelationship
	 * @param sMethodType
	 * @param slBusSelects
	 * @param slRelSelects
	 * @return MapList
	 */
	
	
	public MapList getRelatedObjects(Context context,String sId,String sType,String sRelationship,
			StringList slBusSelects,StringList slRelSelects){
		
		try
		{
			if(UIUtil.isNotNullAndNotEmpty(sId))
			{
				DomainObject contextObj= new DomainObject().newInstance(context,sId);
				SecurityService sec= new SecurityService();
				String sUserType =sec.getUserType();
				String sWhere=ConstantsUtil.EMPTY_STRING;
				
				if (sUserType.equals(ConstantsUtil.PG_CM) || sUserType.equals(ConstantsUtil.PG_SP)) {
					sWhere=(String) ConstantsUtil.RELEASE;
				}
				return  contextObj.getRelatedObjects(context, sRelationship,
						sType, slBusSelects, slRelSelects, false, true, (short) 0,
						sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				
			}else{
				return new MapList();
			}	
		}catch(Exception e)
		{
			LOGGER.error("Error from CommonBusUtilBO:  getRelatedObjects"+e);
			return new MapList();
		}
		
	}
	
	 public static BigDecimal calculatePercentage(Context context, BigDecimal bdPrimaryGrossWeight, String strAlternateUOM, BigDecimal bdAlternateGrossWeight, String strPrimaryUOM) throws Exception {
		    BigDecimal bigDecimalDifference = new BigDecimal(0.0D);
		    
		    try {
		        if (!strAlternateUOM.equals(strPrimaryUOM)) {
		          bdAlternateGrossWeight = new BigDecimal(convertValues(context, bdAlternateGrossWeight.toString(), strAlternateUOM, strPrimaryUOM));
		        }
		        BigDecimal bigDecimalLocal = new BigDecimal(0.0D);
		        if (bdPrimaryGrossWeight.compareTo(bigDecimalLocal) != 0) {
		        	
		         bigDecimalLocal = bdAlternateGrossWeight.subtract(bdPrimaryGrossWeight);
		          bigDecimalDifference = bigDecimalLocal.multiply(new BigDecimal(100.0D)).divide(bdPrimaryGrossWeight, 2, RoundingMode.UP);
		        } 
		      } catch (Exception ex) {
		      
		       ex.printStackTrace();
		      throw ex;
		     } 
		     return bigDecimalDifference;
		   }
	 public static String convertValues (Context context, String strValue, String strSourceUOM, String strtargetUOM) throws Exception
	   {
			String strReturnstring = ConstantsUtil.EMPTY_STRING;
		  	try
		   {			   
			   if(UIUtil.isNotNullAndNotEmpty(strSourceUOM) && UIUtil.isNotNullAndNotEmpty(strtargetUOM) && UIUtil.isNotNullAndNotEmpty(strValue))
			   {  
				   Map uomMap = loadUOMs(context,strSourceUOM, strtargetUOM);
				   String strSourceFactor =(String)uomMap.get("sourceFactor");
				   String strTargetFactor =(String)uomMap.get("targetFactor");
				   if(UIUtil.isNotNullAndNotEmpty(strSourceFactor)&& UIUtil.isNotNullAndNotEmpty(strTargetFactor))
				   {					   
					   BigDecimal bstrValue = new BigDecimal(strValue);
					   BigDecimal bSourceFactor = new BigDecimal(strSourceFactor);
					   BigDecimal bTargetFactor = new BigDecimal(strTargetFactor);				   
					   BigDecimal bdConvertedValue = new BigDecimal("0.0");				   
					   bdConvertedValue=bstrValue.multiply(bSourceFactor, MathContext.DECIMAL128);	
					   if(bTargetFactor.compareTo(new BigDecimal("0.0"))!=0)
					   {
						   bdConvertedValue=bdConvertedValue.divide(bTargetFactor, MathContext.DECIMAL128);
					   }
					   else
					   {
						   bdConvertedValue=new BigDecimal("0.0");
					   }				   
					   strReturnstring =bdConvertedValue.toString();
				   }			   
			   }
		   }
		   catch(Exception e) {
			   e.printStackTrace();
			   throw e;
		   }		   
		   return strReturnstring;
		   
	   }
	
	
	 private static Map loadUOMs(Context context , String strSourceUOM , String strTargetUOM) throws Exception
	   {		  
		   Map returnMap =new HashMap();
		   try 
		   {
			   strSourceUOM = strSourceUOM.toUpperCase();
			   strTargetUOM = strTargetUOM.toUpperCase();
			   
			   Map propertyMap =geValueMapfromProperty(context , "pgApolloConfigurations" , "pgConvertUtitily.UOM.");
			   Set keySet =propertyMap.keySet();
			   Iterator keySetItr = keySet.iterator();
			   String strPropertyKey = null;
			   String strPrpertyValue = null;
			   StringList UOMList =null;
			   StringBuffer strFactorKeyBuffer = new StringBuffer();
			   String strFactorKey= null;
			   while(keySetItr.hasNext()) {
				   strPropertyKey =(String)keySetItr.next();
				   strPrpertyValue = (String)propertyMap.get(strPropertyKey);
				   UOMList =FrameworkUtil.split(strPrpertyValue, ConstantsUtil.SYMBL_PIPE);
				   if(UOMList.contains(strSourceUOM) && UOMList.contains(strTargetUOM))
				   {
					   strFactorKeyBuffer.append(strPropertyKey);
					   strFactorKeyBuffer.append(".Factor");
					   strFactorKey=strFactorKeyBuffer.toString();
					   StringList factorlist =FrameworkUtil.split((String)propertyMap.get(strFactorKey), ConstantsUtil.SYMBL_PIPE);
					   returnMap.put("sourceFactor", factorlist.get(UOMList.indexOf(strSourceUOM)));
					   returnMap.put("targetFactor", factorlist.get(UOMList.indexOf(strTargetUOM)));
					   break;
				   }
			   }
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		   return returnMap;
	   }
	 public static Map geValueMapfromProperty(Context context, String strPageName , String strKeyPattern) throws Exception {
	 		Map returnMap = new HashMap();
	 		try
	 		{
	 			String isPageExists	= MqlUtil.mqlCommand(context, "list page $1", strPageName);
	 			String strProperties= UIUtil.isNotNullAndNotEmpty(isPageExists) ? MqlUtil.mqlCommand(context, "print page $1 select content dump", strPageName) : "";
	 			if(UIUtil.isNotNullAndNotEmpty(strProperties))
	 			{
		 			Properties properties = new Properties();
		 			properties.load(new StringReader(strProperties));
		 			Set allPropertyset = properties.stringPropertyNames();
		 			Iterator allPropertysetItr =allPropertyset.iterator();
		 			String strKey = ConstantsUtil.EMPTY_STRING;
		 			while(allPropertysetItr.hasNext())
		 			{
		 				strKey =(String)allPropertysetItr.next();
		 				if(strKey.contains(strKeyPattern)) {
		 					returnMap.put(strKey, properties.getProperty(strKey));
		 				}
		 			}
	 			}
	 		}catch(Exception ex)
	 		{
	 			ex.printStackTrace();
	 			throw ex;
	 		}
	 		return returnMap;
	 	}
	//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- END
/**
	 * Method Name 			: getRegistrationDetails
	 * Method Description 	: SPEC: Release SR18x.6. Added new method for Registration Details by Dominic on Date 25/02/2021
	 * @param resultMaps
	 * @return
	 * @throws Exception 
	 */
  
	public Map getRegistrationDetails(Context context, String sContextObjectId) throws Exception {
		
		Map<String, String> mpRegistrationDetails = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID	 =  new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbPackingSite = new StringBuilder();
		StringBuilder sbGpsComments = new StringBuilder();
		StringBuilder sbRestriction = new StringBuilder();
		StringBuilder sbRegisteredProductName = new StringBuilder();
		StringBuilder sbRegistrationExpirationDate = new StringBuilder();
		StringBuilder sbRegistrationStatus = new StringBuilder();
		StringBuilder sbProductRegistrationNumber = new StringBuilder();
		StringBuilder sbPackSizeUom = new StringBuilder();
		StringBuilder sbPackSize = new StringBuilder();
		StringBuilder sbBusinessChannel = new StringBuilder();
		StringBuilder sbLegalEntity = new StringBuilder();
		StringBuilder sbMarketApprovalHolder = new StringBuilder();
		StringBuilder sbBulkMakingManufacturingSite = new StringBuilder();
		StringBuilder sbPrimaryPart = new StringBuilder();
		StringBuilder sbSubstitutePart = new StringBuilder();
		StringBuilder sbAlternate = new StringBuilder();
		StringBuilder sbRegisteredCountry = new StringBuilder();
		StringBuilder sbClearenceStatus = new StringBuilder();
		StringBuilder sbGPSApproval = new StringBuilder();
		StringBuilder sbClearenceNumber = new StringBuilder();
		//SPEC: Release SR18x.6.0 - Added for Registration Details  by Dominic on Date 17/03/2021 -- END
			
		//SPEC: Release SR18x.6.0 - Added  by Dominic on Date 16/03/2021 -- START
		String strRegisteredCountry = ConstantsUtil.EMPTY_STRING;
		//SPEC: Release SR18x.6.0 - Added  by Dominic on Date 16/03/2021 -- END
		
		
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			
		StringList relSelects = new StringList();
		relSelects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		relSelects.addElement(ConstantsUtil.SELECT_RELATIONSHIP_ID);
		relSelects.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMOSROLLEDUPASSEMBLEDTYPE);
		
		//DomainObject doRegistration = new DomainObject(sContextObjectId);
		DomainObject doRegistration = DomainObject.newInstance(context, sContextObjectId);
		MapList mlRegistration = doRegistration.getRelatedObjects(context, ConstantsUtilIRM.RELATIONSHIP_MOSROLLEDUPREGISTRATION,
				ConstantsUtilIRM.TYPEPATTERN_PGMARKETREGISTRATION, slBusSelects, relSelects, false, true, (short) 1,
				ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		doRegistration.close(context);
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		mlRegistration = getConnectedMarkets(context,mlRegistration);
		Iterator objectListItr = mlRegistration.iterator();
		
		while(objectListItr.hasNext()) {
			Map objectMap = (Map) objectListItr.next();
						
			String strID = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ID));
			String strName = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_NAME));
			String strType = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_TYPE));
			String strRev = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_REVISION));
			String strState = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_CURRENT));
			String strDec = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
			String strTitle = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
			//SPEC: Release SR18x.6. Modified by Dominic on Date 09/03/2021 --START
			MapList mlCountryList=(MapList)objectMap.get(ConstantsUtilIRM.COUNTRIESLIST);
			String strPackingSite = ConstantsUtil.EMPTY_STRING;
			String strGpsComments = ConstantsUtil.EMPTY_STRING;
			String strRestriction = ConstantsUtil.EMPTY_STRING;
			String strRegisteredProductName = ConstantsUtil.EMPTY_STRING;
			String strRegistrationExpirationDate = ConstantsUtil.EMPTY_STRING;
			String strRegistrationStatus = ConstantsUtil.EMPTY_STRING;
			String strProductRegistrationNumber = ConstantsUtil.EMPTY_STRING;
			String strPackSizeUom = ConstantsUtil.EMPTY_STRING;
			String strPackSize = ConstantsUtil.EMPTY_STRING;
			String strBusinessChannel = ConstantsUtil.EMPTY_STRING;
			String strLegalEntity = ConstantsUtil.EMPTY_STRING;
			String strMarketApprovalHolder = ConstantsUtil.EMPTY_STRING;
			String strBulkMakingManufacturingSite = ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.6.0 - Added for Registration Details  by Dominic on Date 17/03/2021 -- START
			String strClearenceStatus = ConstantsUtil.EMPTY_STRING;
			String strGPSApproval = ConstantsUtil.EMPTY_STRING;
			String strClearenceNumber = ConstantsUtil.EMPTY_STRING;
			String strAssembledType=ConstantsUtil.EMPTY_STRING;
			//SPEC: Release SR18x.6.0 - Added for Registration Details  by Dominic on Date 17/03/2021 -- END
			
			String strAlternate=ConstantsUtil.SYMBL_NO;
			String strPrimaryPart=ConstantsUtil.SYMBL_NO;
			String strSubstitutePart=ConstantsUtil.SYMBL_NO;
			strAssembledType = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMOSROLLEDUPASSEMBLEDTYPE));
			//String strPrimaryPart="";
			//SPEC: Release SR18x.6. Modified by Dominic on Date 09/03/2021 --START
			if(UIUtil.isNotNullAndNotEmpty(strAssembledType) && ConstantsUtilIRM.KEY_EBOMCHILDREN.equalsIgnoreCase(strAssembledType)){
				strPrimaryPart=ConstantsUtil.SYMBL_YES;		
			}else if(UIUtil.isNotNullAndNotEmpty(strAssembledType) && ConstantsUtilIRM.KEY_SUBSTITUTE.equalsIgnoreCase(strAssembledType)){
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 41526 on Date 24/03/2021 --START
				//strAlternate=ConstantsUtil.SYMBL_YES;
				strSubstitutePart=ConstantsUtil.SYMBL_YES;
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 41526 on Date 24/03/2021 --END
			}else if(UIUtil.isNotNullAndNotEmpty(strAssembledType) && ConstantsUtilIRM.KEY_ALTERNATE.equalsIgnoreCase(strAssembledType)){
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 41526 on Date 24/03/2021 --START
				//strSubstitutePart=ConstantsUtil.SYMBL_YES;
				strAlternate=ConstantsUtil.SYMBL_YES;
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 41526 on Date 24/03/2021 --END
			}
			//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43950 on Date 01/07/2021 --START
			else if(UIUtil.isNotNullAndNotEmpty(strAssembledType) && strAssembledType.contains(ConstantsUtilIRM.KEY_ALTERNATE)){
				strAlternate=ConstantsUtil.SYMBL_YES;
			}
			//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43950 on Date 01/07/2021 --END
			Iterator objectListItr1 = mlCountryList.iterator();
			while(objectListItr1.hasNext()) {
				Map objectMap1 = (Map) objectListItr1.next();
				strPackingSite = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE));
				strGpsComments = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT));
				strRestriction = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION));
				strRegisteredProductName = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME));
				strRegistrationExpirationDate = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE));
				strRegistrationStatus = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS));
				strProductRegistrationNumber = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER));
				strPackSizeUom = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKSIZEUOM));
				strPackSize = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKSIZE));
				strBusinessChannel = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL));
				strLegalEntity = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLEGALENTITY));
				strMarketApprovalHolder = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMARKETAPPROVERHOLER));
				strBulkMakingManufacturingSite = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE));
				//SPEC: Release SR18x.6.0 - Added for Registration Details  by Dominic on Date 17/03/2021 -- START
				strClearenceStatus = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS));
				strGPSApproval = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS));
				strClearenceNumber = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER));
				
				strRegisteredProductName = strRegisteredProductName.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strProductRegistrationNumber = strProductRegistrationNumber.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSizeUom = strPackSizeUom.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSize = strPackSize.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegistrationExpirationDate = strRegistrationExpirationDate.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegistrationStatus = strRegistrationStatus.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strBusinessChannel = strBusinessChannel.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strLegalEntity = strLegalEntity.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strMarketApprovalHolder = strMarketApprovalHolder.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strBulkMakingManufacturingSite = strBulkMakingManufacturingSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strGPSApproval = strGPSApproval.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strBulkMakingManufacturingSite = strBulkMakingManufacturingSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				int iSize = 0;
				for(int i = 0; i < strClearenceNumber.length(); i++) {
				    if(strClearenceNumber.charAt(i) == ',') iSize++;
				}
				strClearenceNumber = strClearenceNumber.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegisteredCountry = validator.getStringEquivalentForSubstituteString(objectMap1.get(ConstantsUtil.SELECT_NAME));
				strPackingSite = strPackingSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strGpsComments = strGpsComments.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRestriction = strRestriction.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackingSite = strPackingSite.replaceAll("\\"+ConstantsUtilIRM.SYMBOL_CAP,ConstantsUtil.SYMBL_COMMA);
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43956 on Date 01/07/2021 --START
				if (strPackingSite.endsWith(", ")) {
					strPackingSite = strPackingSite.substring(0, strPackingSite.length() - 2);
				}
				if (strRestriction.startsWith(", ")) {
					strRestriction = strRestriction.substring(2, strRestriction.length());
				}
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43955 on Date 01/07/2021 --END
				strBulkMakingManufacturingSite = strBulkMakingManufacturingSite.replaceAll("\\"+ConstantsUtilIRM.SYMBOL_CAP,ConstantsUtil.SYMBL_COMMA);
				//SPEC: Release SR18x.6.0 - Modified  by Dominic on Date 15/04/2021 -- END
				util.formatData(sbPackingSite,strPackingSite);
				util.formatData(sbGpsComments,strGpsComments);
				util.formatData(sbRestriction,strRestriction);
				util.formatData(sbRegisteredProductName,strRegisteredProductName);
				util.formatData(sbRegistrationExpirationDate,strRegistrationExpirationDate);
				util.formatData(sbRegistrationStatus,strRegistrationStatus);
				util.formatData(sbProductRegistrationNumber,strProductRegistrationNumber);
				util.formatData(sbPackSizeUom,strPackSizeUom);
				util.formatData(sbPackSize,strPackSize);
				util.formatData(sbBusinessChannel,strBusinessChannel);
				util.formatData(sbLegalEntity,strLegalEntity);
				util.formatData(sbMarketApprovalHolder,strMarketApprovalHolder);
				util.formatData(sbBulkMakingManufacturingSite,strBulkMakingManufacturingSite);
				util.formatData(sbGPSApproval,strGPSApproval);
				util.formatData(sbClearenceNumber,strClearenceNumber);
						
			SecurityService sct = new SecurityService();
			boolean showData = false;
			boolean bHasOwnership = false;
			if(util.isModificatinRequired())
			{   
				bHasOwnership = util.checkHasAccess(context, null, strID);
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43957 on Date 01/07/2021 --START
				showData=bHasOwnership;
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43957 on Date 01/07/2021 --END
				if(!bHasOwnership){
					strID = ConstantsUtil.NO_ACCESS;
				}
			}
			else{
				showData=util.checkHasAccess(context, sct.getUserType(),strID);
			}
			
			if(!showData){
			
				strID = ConstantsUtil.NO_ACCESS;
			}
			
			if(!ConstantsUtil.RELEASED.equalsIgnoreCase(strState) && !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(strState))){
				strID = ConstantsUtil.NO_ACCESS;
			}
			//strType= util.mapType(strType);
			for (int i = 0; i <= iSize; i++) {
				util.formatData(sbName, strName);
				util.formatData(sbID, strID);
				util.formatData(sbRev, strRev);
				util.formatData(sbDesc, strDec);
				util.formatData(sbCurrent, strState);
				util.formatData(sbType, strType);
				util.formatData(sbTitle, strTitle);
				util.formatData(sbPrimaryPart, strPrimaryPart);
				util.formatData(sbSubstitutePart, strSubstitutePart);
				util.formatData(sbAlternate, strAlternate);
				util.formatData(sbRegisteredCountry,strRegisteredCountry);
				util.formatData(sbClearenceStatus,strClearenceStatus);
			}
				
			}
		}
		mpRegistrationDetails.put(ConstantsUtilIRM.PGPRODUCTPARTNAME,sbName.toString() );
		mpRegistrationDetails.put(ConstantsUtilIRM.PGPRODUCTPARTREVISION, sbRev.toString());
		mpRegistrationDetails.put(ConstantsUtil.ID, sbID.toString());
		mpRegistrationDetails.put(ConstantsUtil.TYPE, sbType.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.PGPRODUCTPARTTITLE, sbTitle.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.PRIMARYPART, sbPrimaryPart.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.SUBSTITUTEPART, sbSubstitutePart.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.ALTERNATE, sbAlternate.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.REGISTEREDCOUNTRY, sbRegisteredCountry.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.MARKETAPPROVALHOLDER, sbMarketApprovalHolder.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.LEGALENTITY, sbLegalEntity.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.BUSINESSCHANNEL, sbBusinessChannel.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.PACKSIZE, sbPackSize.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.PACKSIZEUOM, sbPackSizeUom.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.PRODUCTREGISTRATIONNUMBER, sbProductRegistrationNumber.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.REGISTRATIONSTATUS, sbRegistrationStatus.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.REGISTRATIONEXPDATE, sbRegistrationExpirationDate.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.PGREGISTEREDPRODUCTNAME, sbRegisteredProductName.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.RESTRICTION, sbRestriction.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.GPSCOMMENTS, sbGpsComments.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.PACKINGSITE, sbPackingSite.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.BULKMANUFACTURINGSITE, sbBulkMakingManufacturingSite.toString());
		//SPEC: Release SR18x.6.0 - Added for Registration Details  by Dominic on Date 17/03/2021 -- START
		mpRegistrationDetails.put(ConstantsUtilIRM.OVERALLCLEARANCESTATUS, sbClearenceStatus.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.GPSAPPROVALSTATUS, sbGPSApproval.toString());
		mpRegistrationDetails.put(ConstantsUtilIRM.CLEARANCENUMBER, sbClearenceNumber.toString());
		//SPEC: Release SR18x.6.0 - Added for Registration Details  by Dominic on Date 17/03/2021 -- END
		
		return mpRegistrationDetails;
	}
	//SPEC: <21.06.2022>: Guna Added for req 41754 22x Release  -- START
	private String getFilteredString(StringList siteList) {
       StringList rtnList =new StringList();
		try {
			if(!siteList.isEmpty()) {
				for(int j=0;j<siteList.size();j++) {
					String strSite =siteList.get(j);
					if(UIUtil.isNotNullAndNotEmpty(strSite)) {
						rtnList.add(strSite);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error in CommonBusUtil: getFilteredString "+e);
		}
	return util.replaceSquareBracketsOnly(rtnList.toString());
}
	//SPEC: <21.06.2022>: Guna Added for req 41754 22x Release  -- END
	/**
	 * Method Name 			: getConnectedMarkets
	 * Method Description 	: SPEC: Release SR18x.6. Added new method for Registration Details by Dominic on Date 25/02/2021
	 * @param mlProductData
	 * @return
	 * @throws Exception 
	 */
	public MapList getConnectedMarkets(Context context, MapList mlProductData)throws FrameworkException {
		MapList mlCountries = new MapList();
		try {
			if (null != mlProductData) {
				int iSize = mlProductData.size();
				Map objMap;
				String oId;
				MapList mlRegistration = new MapList();
								
				String strRelPattern = ConstantsUtil.RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE;
				String strTypePattern = ConstantsUtil.TYPE_COUNTRY;
				StringList slObjectSelect = new StringList(7);
				slObjectSelect.addElement(ConstantsUtil.SELECT_NAME);
				slObjectSelect.addElement(ConstantsUtil.SELECT_TYPE);
				slObjectSelect.addElement(ConstantsUtil.SELECT_ID);
				slObjectSelect.addElement(ConstantsUtil.SELECT_REVISION);
				slObjectSelect.addElement(ConstantsUtil.SELECT_CURRENT);
				slObjectSelect.addElement(ConstantsUtil.SELECT_DESCRIPTION);
				slObjectSelect.addElement(ConstantsUtil.TITLE);


				StringList slRelSelect = new StringList(13);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER);
				slRelSelect.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKSIZEUOM);
				slRelSelect.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKSIZE);
				slRelSelect.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL);
				slRelSelect.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLEGALENTITY);
				slRelSelect.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMARKETAPPROVERHOLER);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER);
				MapList mlConnectedCountries;
				
				for (int i = 0; i < iSize; i++) {
					objMap = (Map) mlProductData.get(i);
					oId = (String) objMap.get(DomainConstants.SELECT_ID);
					if (UIUtil.isNotNullAndNotEmpty(oId)) {
						DomainObject domObj = DomainObject.newInstance(context,oId);
						mlConnectedCountries = domObj.getRelatedObjects(context, 
																		strRelPattern, 
																		strTypePattern,
																		slObjectSelect,
																		slRelSelect, 
																		false, 
																		true,
																		(short) 1, 
																		"",
																		null,
																		0);
						
						//SPEC: 29/03/2021: Modified for 18x.6 Defect #41422 by Bala-- START 
						mlConnectedCountries.sort(DomainConstants.SELECT_NAME, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
						//SPEC: 29/03/2021: Modified for 18x.6 Defect #41422 by Bala-- END 
						if (null != mlConnectedCountries) {
							if (!mlConnectedCountries.isEmpty()&& mlConnectedCountries.size() > 0) {
								objMap.put(ConstantsUtilIRM.COUNTRIESLIST,mlConnectedCountries);
							} else {
								objMap.put(ConstantsUtilIRM.COUNTRIESLIST,new MapList());
							}
						}
						mlRegistration.add(objMap);
					}
				}

				mlCountries.addAll(mlRegistration);
			}
		} catch (FrameworkException ex) {
			LOGGER.error("Error in CommonBusUtil: getConnectedMarkets "+ex);
		}
		return mlCountries;
	}
  	
}
