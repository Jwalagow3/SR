/**
 * Project 		: SpecsAnywhere
 * Program 		: IMPBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class EMPBO {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(EMPBO.class);
	BusObjectAttribUtil util  = new BusObjectAttribUtil();

	public EMPBO() {
		// empty constructor
	}

	
	/**
	 * Method Name 			: getEMPBBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getEMPBBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getEMPBDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getEMPBDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			return doObj;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getEMPSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getEMPSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	private static StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
		busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_REL_MCPRF);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONDATE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALNUMBER);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER);
		//Modified by Ganesh for Internal Defect <16/Mar/2021> ---->start
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT);
		//Modified by Ganesh for Internal Defect <16/Mar/2021> ---->End
		return busSelect;
	}

	
	/**
	 * Method Name 			: updateMaterials
	 * Method Description 	:
	 * @param context
	 * @param dob
	 * @return
	 */
	public Map<String, String> updateMaterials(Context context ,DomainObject dob)
	{
		Map<String, String> mpComp = new HashMap<String, String>();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID= new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbQUOM = new StringBuilder();
		
		StringBuilder sbTitle=new StringBuilder();
		StringBuilder sbDesc=new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbQTY=new StringBuilder();
		StringBuilder sbMaxPercent=new StringBuilder();
		StringBuilder sbMinPercent=new StringBuilder();
		
		StringBuilder sbApplicaton=new StringBuilder();

		StringBuilder sbQST = new StringBuilder();
		StringBuilder sbFlags = new StringBuilder();
		
		StringBuilder sbIsCont = new StringBuilder();
		StringBuilder sbCAS = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbClassfied = new StringBuilder();
		StringBuilder sbIPClassAttr = new StringBuilder();
		
		
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCENAME);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		StringList slRelSelects = new StringList();
		
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
		slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
		slRelSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
		StringList list = StringList.create(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG,
				ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT,
				ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
		slRelSelects.addAll(list);
		
		MapList mlCopmonentsList = new MapList();;
		try 
		{
			mlCopmonentsList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, false, true, (short) 0,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				if (util.isModificatinRequired()) {
					mlCopmonentsList=util.filterPhase(mlCopmonentsList);
				}
				if(ConstantsUtil.PG_CM.equals(util.getUserType())){
					mlCopmonentsList=util.filterPhase(mlCopmonentsList);
				}		
			
			mlCopmonentsList=getUsageFlags(mlCopmonentsList);
				
			Iterator objectListItr = mlCopmonentsList.iterator();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sID=(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sTitle=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCENAME);
				String sMin=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
				String sQTY=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				String sMax=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
				String  strQST	=ConstantsUtil.EMPTY_STRING;
				String sQSTOCOMP=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
				String sFlags=(String)objectMap.get(ConstantsUtil.FLAGS);
				String sIsTarget=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
				
				String sQUOM=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
				String sISCont=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
				String sCAS=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);

				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev=(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);

				
				String strClassFied=(String)objectMap.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);
				String sIPClassfication=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
						
				util.formatData(sbClassfied,strClassFied);
				util.formatData(sbIPClassAttr,sIPClassfication);
				
				
				util.formatData(sbName,sName);
				util.formatData(sbID,sID);
				util.formatData(sbType,sType);
				util.formatData(sbTitle,sTitle);
				util.formatData(sbMinPercent,sMin);
				util.formatData(sbQTY,sQTY);
				util.formatData(sbMaxPercent,sMax);
				util.formatData(sbQUOM,sQUOM);
				util.formatData(sbIsCont,sISCont);
				util.formatData(sbFlags,sFlags);
				util.formatData(sbCAS,sCAS);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbRev,sRev);
				util.formatData(sbDesc,sDesc);
				util.formatData(sbApplicaton,ConstantsUtil.EMPTY_STRING);
				
				if(UIUtil.isNotNullAndNotEmpty(sQSTOCOMP) && UIUtil.isNotNullAndNotEmpty(sIsTarget)){
					 strQST	 = (sQSTOCOMP.equalsIgnoreCase("TRUE"))? ConstantsUtil.QS:
									(sIsTarget.equalsIgnoreCase("TRUE"))? ConstantsUtil.TARGET_COMPONENT : "";
						}
				util.formatData(sbQST,strQST);
			}

			mpComp.put(ConstantsUtil.NAME, sbName.toString());
			
			mpComp.put(ConstantsUtil.TYPE,sbType.toString());
			mpComp.put(ConstantsUtil.TITLE, sbTitle.toString());
			
			mpComp.put(ConstantsUtil.MIN, sbMinPercent.toString());
			mpComp.put(ConstantsUtil.DRYWEIGHT, sbQTY.toString());
			mpComp.put(ConstantsUtil.MAX, sbMaxPercent.toString());
			mpComp.put(ConstantsUtil.QUANTITY,sbQUOM.toString());
			
			mpComp.put(ConstantsUtil.QSTARGET,sbQST.toString());
			mpComp.put(ConstantsUtil.FLAGS, sbFlags.toString());
			
			mpComp.put(ConstantsUtil.IMPURITY,sbIsCont.toString());
			mpComp.put(ConstantsUtil.CAS,sbCAS.toString());
			mpComp.put(ConstantsUtil.FUNCTIONS,sbApplicaton.toString());
			mpComp.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpComp.put(ConstantsUtil.REV,sbRev.toString());
			mpComp.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
			
			mpComp.put(ConstantsUtil.SECURITY, sbClassfied.toString());
			mpComp.put(ConstantsUtil.IPCLASSES,sbIPClassAttr.toString());
			mpComp=util.verifyOwnership(context,mpComp);
			
		} catch (Exception e) {
			LOGGER.error("Exception in Program : EMPBO Method :updateMaterials "+e);
			return new HashMap();
		}
		
		return util.filterMapList(mpComp);
	}

	/**
	 * Method Name 			: getUsageFlags
	 * Method Description 	: Getting the Flags on the Materials
	 * @param resultMap
	 * @return
	 * @throws Exception
	 */
	public MapList getUsageFlags(MapList resultMap) throws Exception{
		
		String 	strResult = ConstantsUtil.EMPTY_STRING;
		StringList strList = new StringList();
		MapList mlfinalList = new MapList();
		try{

			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- START
			//Map mpTemp = new HashMap();
			//SPEC: <08-18-2021>: Bala Removed the unused code for Stress Testing Defect 44365 -- START
			Iterator itr = resultMap.iterator();
			while(itr.hasNext())
			{
				Map resMap = (Map) itr.next();
				String	 drugActive = (String) resMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
				String	 Colorant = (String) resMap.get(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
				String	 Preservative  = (String) resMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
				String	 rel = (String) resMap.get(DomainConstants.SELECT_NAME);
			
					if( UIUtil.isNotNullAndNotEmpty(drugActive) && UIUtil.isNotNullAndNotEmpty(Colorant) && UIUtil.isNotNullAndNotEmpty(Preservative))
					{
						if(drugActive.equalsIgnoreCase("Yes"))
							strList.add(ConstantsUtil.DRUG_ACTIVE);;
						 if(Colorant.equalsIgnoreCase("TRUE"))
							 strList.add(ConstantsUtil.COLORANT);;
						 if(Preservative.equalsIgnoreCase("Yes"))
							 strList.add(ConstantsUtil.PRESERVATIVE);;
					}
				resMap.put(ConstantsUtil.FLAGS, FrameworkUtil.join(strList, ","));
				mlfinalList.add(resMap);
		   } 	
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}
		
		return mlfinalList;
	}
	
	
	
	/**
	 * Method Name 			: getMaterialComposition
	 * Method Description 	:
	 * @param context
	 * @param dob
	 * @return
	 */
	public Map<String, String> getMaterialComposition(Context context, Map resultMaps)
	{
		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		String sRawMatId = (String) resultMaps.get(ConstantsUtil.SELECT_ID);
		
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID	 =  new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbCAS = new StringBuilder();
		StringBuilder sbCont = new StringBuilder();
		StringBuilder sbMAXWt = new StringBuilder();
		StringBuilder sbMInWt = new StringBuilder();
		StringBuilder sbQUOM = new StringBuilder();
		StringBuilder sbDRY = new StringBuilder();
		StringBuilder sbFunctions = new StringBuilder();
		StringBuilder sbtrClassFied = new StringBuilder();
		StringBuilder sbIPClassfication = new StringBuilder();
		StringBuilder sbQTS = new StringBuilder();
		StringBuilder sbUF = new StringBuilder();
		StringBuilder sbTradeName = new StringBuilder();
		StringBuilder sbPostConsumer = new StringBuilder();
		StringBuilder sbCompanyName = new StringBuilder();
		StringBuilder sbCompanyId = new StringBuilder();
		StringBuilder sbMTLayer = new StringBuilder();
		StringBuilder sbENVClass = new StringBuilder();
		StringBuilder sbParentName = new StringBuilder();//Added by Ajay for 22x.06 Req.9264
		
		try
		{
			DomainObject doComponent = new DomainObject(sRawMatId);
			StringList slBusSelects = new StringList();
			slBusSelects.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
			slBusSelects.add(ConstantsUtil.COMP_CLASSIITEM);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT);
			slBusSelects.add(ConstantsUtilIRM.REL_COMPANY_NAME);
			slBusSelects.add(ConstantsUtilIRM.REL_ATTRIBUTE_COMPANY_ID);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
			
			
			StringList slRelSelects = new StringList();
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_USAGE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER);
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_NAME);
			slRelSelects.add(ConstantsUtilIRM.SELECT_EBOM_NAME);//Added by Ajay for 22x.06 Req.9264
			Pattern objType = new Pattern(ConstantsUtil.TYPE_MATERIAL);
            objType.addPattern(ConstantsUtil.TYPE_SUBSTANCE); 

            Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL);
            relType.addPattern(ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE);
            relType.addPattern(ConstantsUtil.RELATIONSHIP_SECURE_COMPONENT_SUBSTANCE);
           //Added by Ganesh for Dev 6.0.1----->START
            String sWhere=ConstantsUtil.EMPTY_STRING;
            if(util.isModificatinRequired())
            {
			 sWhere="current==Approved || current==Active";
            }
          //Added by Ganesh for Dev 6.0.1----->STOP
			MapList mlComponentsAnSubstance = doComponent.getRelatedObjects(context, 
					relType.getPattern(),
					objType.getPattern(), 
					slBusSelects, 
					slRelSelects, 
					false, 
					true, 
					(short) 0, //Expand level to all
					//ConstantsUtil.EMPTY_STRING, 
					sWhere,
					ConstantsUtil.EMPTY_STRING, 
					ConstantsUtil.ZERO_LEVEL);
			
			
			mlComponentsAnSubstance = util.getSortedMaplistWithSequence(context, mlComponentsAnSubstance, sRawMatId);
			
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- START
			doComponent.close(context);
			//SPEC: <08-18-2021>: Bala Added for Stress Testing Defect 44365  -- END
			String pType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
			String pName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
			String pID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
			String pRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
			String pDesc = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
			
			String pTitle = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING;
			//Modified by Ganesh for Internal Defect <16/Mar/2021> ---->start
			String pPostConsumer=validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT));
			//Modified by Ganesh for Internal Defect <16/Mar/2021> ---->End
			//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- START
			String pState = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
			//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- END
			util.formatData(sbType, util.mapType(pType));
			util.formatData(sbName, pName);
			util.formatData(sbID, pID);
			util.formatData(sbRev, pRev);
			util.formatData(sbDesc, pDesc);
			
			util.formatData(sbTitle, pTitle);
			//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- START
			//util.formatData(sbCurrent, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbCurrent,pState);
			//SPEC: Release SR18x.6.0 - Added by Ganesh on Mar 18, 2021 -- END
			util.formatData(sbCAS, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbQTS, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbUF, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbCont, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbMAXWt, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbMInWt, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbTradeName,ConstantsUtil.EMPTY_STRING);
			//Modified by Ganesh for Internal Defect <16/Mar/2021> ---->start
			//util.formatData(sbPostConsumer,ConstantsUtil.EMPTY_STRING);
			util.formatData(sbPostConsumer,pPostConsumer);
			//Modified by Ganesh for Internal Defect <16/Mar/2021> ----end
			util.formatData(sbCompanyName,ConstantsUtil.EMPTY_STRING);
			util.formatData(sbCompanyId,ConstantsUtil.EMPTY_STRING);
			
			//Modified by Ganesh <19/Mar/2021> ----start
			/*if(mlComponentsAnSubstance.size()>0)
				util.formatData(sbDRY, "100.0");
			else 
				util.formatData(sbDRY, ConstantsUtil.EMPTY_STRING);
			*/
			util.formatData(sbDRY, ConstantsUtil.EMPTY_STRING);
			//Modified by Ganesh <19/Mar/2021> ----end
			util.formatData(sbQUOM,ConstantsUtil.EMPTY_STRING);
			util.formatData(sbFunctions, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbtrClassFied, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbIPClassfication, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbParentName, ConstantsUtil.EMPTY_STRING);//Added by Ajay for 22x.06 Req.9264
			
			
		
			mlComponentsAnSubstance = util.getUsageFlags(context, mlComponentsAnSubstance);
			
			
			Iterator objectListItr2 = mlComponentsAnSubstance.iterator();
	
			while(objectListItr2.hasNext())
			{
				Map objectMap2 = (Map) objectListItr2.next();
				String sType = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_TYPE));
				String sName = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_NAME));
				String strID	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ID));
				String sRev = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_REVISION));
				String sParentName	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtilIRM.SELECT_EBOM_NAME));
			
				String sDesc = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_DESCRIPTION));
				//Modified by Ganesh for Defect 44005 ------START
				//String sTitle = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME));
			    String sTitle = validator.isNotNullOrEmpty((String)objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME))?(String)objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME) : ConstantsUtil.EMPTY_STRING;
			  //Modified by Ganesh for Defect 44005 ------END
				
				String sCurrent = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_CURRENT));
				sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
				
				 //Modified by Ganesh <19/Mar/2021> ---->start
				if (sType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL)) {
					if (sCurrent.equals(ConstantsUtil.DEVELOPMENT)) {
						sCurrent = ConstantsUtil.STATE_INWORK;
					}
				}
				 //Modified by Ganesh <19/Mar/2021> ---->end
				String sCAS = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
				
				
				String sCont = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
				String sMAXWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
				String sMInWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
				String sQUOM = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
				String sDRY = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
				String sTradeName=validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME));
				String sPostConsumer=validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT));
				String sCompanyName=validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtilIRM.REL_COMPANY_NAME));
				String sCompanyId=validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtilIRM.REL_ATTRIBUTE_COMPANY_ID));
				String strMlyr =validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER));
				String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION));
				if (UIUtil.isNotNullAndNotEmpty(sFunctions)) 
				{
					sFunctions=util.getIdFromPhysicalIdFunction(context,sFunctions);
					
				}
				
				
				String strClassFied = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.COMP_CLASSIITEM));
				String sIPClassfication = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String sQTS = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL));
				
				String sUF	 =  validator.getStringEquivalentForStringListWithComma(objectMap2.get(ConstantsUtil.FLAGS));
				
				String sTarget = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL));
				
				
				String sFill = (String)objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_FILL);

				sQTS = sFill.equalsIgnoreCase("TRUE") ?  ConstantsUtil.QS : (sTarget.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ? ConstantsUtil.TARGET_MATERIAL : "");
				//Modified by Ganesh  <19/Mar/2021> ---->start
				   if(sType.equalsIgnoreCase("Internal Material") && sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_INWORK) )
				   {
					  continue; 
				   }
				   //Modified by Ganesh <19/Mar/2021> ---->end
				 //commented by Ganesh ---->START
				/*util.formatData(sbType, util.mapType(sType));
				util.formatData(sbName, sName);*/
				//commented by Ganesh ------>STOP
				//Modified by Ganesh  <19/Mar/2021> ---->start
				boolean bHasAccess = false;
				
				if (!sType.equals(ConstantsUtil.TYPE_SUBSTANCE) && !sType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL)) 
				{
					bHasAccess = util.checkHasAccess(context, null, strID);	
				} else 
				{
					bHasAccess = true;
				}
				//SPEC: Release SR18x.6.0.1 - Modified by Ganesh on June 03, 2021 for Req #39652
				if(!bHasAccess) {
					strID = ConstantsUtil.NO_ACCESS;	
				}
				//SPEC: Release SR18x.6.0.1 - Modified by Ganesh on June 03, 2021 for Req #39652
				if (!sCurrent.equals(ConstantsUtil.RELEASE) &&  !sCurrent.equals(ConstantsUtil.RELEASED)) {
					strID = ConstantsUtil.NO_ACCESS;
				}
				//Modified by Ganesh  <19/Mar/2021> ---->end
				//Added by Ganesh for Dev 6.0.1 ------->START
				util.formatData(sbType, util.mapType(sType));
				util.formatData(sbName, sName);
				//Added by Ganesh for Dev 6.0.1 ------->STOP
				util.formatData(sbID, strID);
				util.formatData(sbRev, sRev);
				util.formatData(sbDesc, sDesc);
				util.formatData(sbTitle, sTitle);
				util.formatData(sbCurrent, sCurrent);
				util.formatData(sbCAS, sCAS);
				util.formatData(sbQTS, sQTS);
				util.formatData(sbUF, sUF);
				util.formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
				
				if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
					sCont = ConstantsUtil.SYMBL_CAPTRUE;
				} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
					sCont = ConstantsUtil.SYMBL_CAPFALSE;
				}
				
				util.formatData(sbCont, sCont);
				
				if(!validator.isNotNullOrEmpty(sMInWt) || sMInWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sMInWt = ConstantsUtil.EMPTY_SPACE;
				}
				//Commented by Ganesh for Internal defect---->START
				/*if(!validator.isNotNullOrEmpty(sDRY) || sDRY.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sDRY = ConstantsUtil.EMPTY_SPACE;
				}*/
				//Commented by Ganesh for Internal defect---->STOP
				if(!validator.isNotNullOrEmpty(sMAXWt) || sMAXWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sMAXWt = ConstantsUtil.EMPTY_SPACE;
				}
					util.formatData(sbMAXWt, sMAXWt);
					util.formatData(sbMInWt, sMInWt);
				//Modified by Ganesh for Internal Defect------->START
				/*if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPTRUE)) {
					util.formatData(sbDRY, sMAXWt);
				} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPFALSE)) {
					util.formatData(sbDRY, sDRY);
				}*/
				String strTempDry = util.getDryValueToDisplay(context, objectMap2);
				strTempDry = util.formattingDryValueToDisplay(context,strTempDry);
				util.formatData(sbDRY, strTempDry);
				//Modified by Ganesh for Internal Defect------->STOP
				String sENVClass = validator.getStringEquivalentForSubstituteString(
						objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS));
				
				util.formatData(sbENVClass, sENVClass);
				util.formatData(sbQUOM,sQUOM);
				util.formatData(sbFunctions, sFunctions);
				util.formatData(sbtrClassFied, strClassFied);
				util.formatData(sbIPClassfication, sIPClassfication);
				util.formatData(sbTradeName,sTradeName);
				util.formatData(sbPostConsumer,sPostConsumer);
				util.formatData(sbCompanyName,sCompanyName);
				util.formatData(sbCompanyId,sCompanyId);
				util.formatData(sbMTLayer,strMlyr);
				
		}
		mpSubStanceResult.put(ConstantsUtil.SECURITY, sbtrClassFied.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sbIPClassfication.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.REV,sbRev.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.CAS,sbCAS.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.IP,sbCont.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.MAX,sbMAXWt.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.MIN,sbMInWt.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.UOM,sbQUOM.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sbDRY.toString().trim());
		mpSubStanceResult.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString().trim());//Added by Ajay for 22x.06 Req.9264
		if(ConstantsUtil.PG.equals(util.getUserType())|| ConstantsUtil.PGSTAFF.equals(util.getUserType())) {
		mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sbFunctions.toString().trim());
		}
		mpSubStanceResult.put(ConstantsUtil.ID, sbID.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.QSTARGET,sbQTS.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.UF, sbUF.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.TRADENAME,sbTradeName.toString());
		mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sbPostConsumer.toString());
		mpSubStanceResult.put(ConstantsUtilIRM.MATERIALCOMPANYNAME,sbCompanyName.toString());
		mpSubStanceResult.put(ConstantsUtilIRM.MATERIALCOMPANYID,sbCompanyId.toString());
		mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sbMTLayer.toString());
		mpSubStanceResult.put(ConstantsUtil.LEGACY_ENV_CLASS, sbENVClass.toString());
		
	}catch(Exception e){
	
		LOGGER.error("Error from EMPBO:  getMaterialComposition"+e);
		return new HashMap();
	}
	return mpSubStanceResult;
	}
	
}
