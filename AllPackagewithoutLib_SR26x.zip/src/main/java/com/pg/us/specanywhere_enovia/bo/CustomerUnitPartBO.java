/**
 * Project 		: SpecsAnywhere
 * Program 		: CustomerUnitPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class CustomerUnitPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(CustomerUnitPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();

	public CustomerUnitPartBO() {
		// empty constructor
	}

	public CustomerUnitPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getCupBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getCupBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getCupDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getCupDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getCustmerUnitPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getCustmerUnitPartSelectables(Context context) {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getStorageTrasportSelectable(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getCommonPartSpecSelects(context));
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.addAll(getWeightCharSelectables(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getFileSelects(context));
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);

		return mapSelecables;
	}

	//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
	/**
	 * Method Name 			: getWeightCharSelectables
	 * Method Description 	: Fetching "Weight Characteristics" data
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LEGACYWEIGHTFACTORUOM);
		return busSelect;
	}
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching PLANT related details
	 * @param context
	 * @return
	 */
	public static StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		return busSelect;
	}
	
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}


	/**
	 * Method Name 			: getCupRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getCupRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);

		return mapSelecables;

	}

	
	/**
	 * Method Name : getBomBusSelect
	 * Method Description : 
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		//Added by Pooja for the req 35902,41754,33476 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		//Added by Pooja for the req 35902,41754,33476 -- END
		//Added by Ketan for Req. no. 46464 - START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		//Added by Ketan for Req. no. 46464 - END
		return busSelect;
	}


	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		//Added by Ketan for Req. no. 46464 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC);
		//Added by Ketan for Req. no. 46464 -- END
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
	
		//Modified for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Modified for Defect# 37591 -- END
		//Added by Pooja for the req 35902,41754,33476 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
		//Added by Pooja for the req 35902,41754,33476 -- END
		
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		return relSelect;
	}


	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(DomainConstants.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);

		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);

		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPAKAGINGTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

		return busSelect;

	}


	/**
	 * Method Name 			: getCommonPartSpecSelects
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getCommonPartSpecSelects(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.STR_PARTSPEC_TYPE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_NAME);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_STATE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_ORIGINATOR);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_TITLE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_ID);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_IPCLASS);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_SUBTYPE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_ATTRIB_SHARING);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_ATTRIB_ORIGIN_SOURCE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_ATTRIB_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		
		
		return busSelect;
	}


	/**
	 * Method Name 			: getStorageTrasportSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getStorageTrasportSelectable(Context context) {
		StringList busSelect = new StringList();
		
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context,MapList mapList) 
	{
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMTupName= new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbEBOMAlt = new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbEBOMOSPD = new StringBuilder();
		StringBuilder sbEBOMDUOM = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START

		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		
		//Added by Pooja for the req 35902,41754 -- START
		StringBuilder sbGrossWeightReal = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder ();
		StringBuilder sbEBOMpgNSPCG= new StringBuilder();
		//Added by Pooja for the req 35902,41754 -- end
		//Added by Ketan for Req. no. 46464 - START
		StringBuilder sbRelRestriction = new StringBuilder();
		StringBuilder sbRelRestrictionComment = new StringBuilder();
		//Added by Ketan for Req. no. 46464 - END
				
		SecurityService sct = new SecurityService();
		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
			String sParentId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID)));
			String sParentName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME)));
			String sParentRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV)));
			String sParentType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE)));
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
			String sId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ID)));
			String sName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_NAME)));
			String sRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_REVISION)));
			String sReleaseDate = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			String sRevRelease = "";
			if (validator.isNotNullOrEmpty(sRevision)){
			//String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			String spgChg = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE)));
			String sFN = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER)));
			String sTitle = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
			String sType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_TYPE)));
			String sTupName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.TUPNAME)));
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//String sSubstitute = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE)));
			//sSubstitute = util.replaceSpecialSymbols(sSubstitute);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			String sQty = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY)));
			String sBuom = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)));
			//Modified by Ganesh for Defect 42375 on Date <14/April/2021>------>START
			//String sComments = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)));
			String sComments = validator.getStringEquivalentForStringListWithComma((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)));
			//Modified by Ganesh for Defect 42375 on Date <14/April/2021>------>END
			String sCurrent = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_CURRENT)));
			//modified by Ganesh for defect 41385 on date <23/Mar/2021> ---->start
			sCurrent =util.mapType(sCurrent);
			//modified by Ganesh for defect 41385 on date <23/Mar/2021> ---->end
			String sStage = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)));
			String sRD = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR)));
			sRD = util.replaceSpecialSymbols(sRD);
			String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
			
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			if (validator.isNotNullOrEmpty(strSubPart)){
				strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			//Added by Pooja for the req 35902,41754,33476 -- START
			String spgNSPCG = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG)));
			String strGrossWeightReal = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
			String strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
			//Added by Pooja for the req 35902,41754,33476 -- END
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			if (validator.isNotNullOrEmpty(strSubPartType)){
			strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//String strAlt =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT));
			//strAlt = strAlt.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			if (validator.isNotNullOrEmpty(strAltName)){
			strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			String strAltID = util.checkAlternateHasAccess(context,objectMap);	
			String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			if (validator.isNotNullOrEmpty(strAltType)){
			strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);	
			}
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			
			String strOSPD = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
			String strDUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			//Added by Ketan for Req. no. 46464 - START
			String sRelRestriction = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))? (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
			String sRelRestrictionComment = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))? (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
			//Added by Ketan for Req. no. 46464 - END
			
			boolean showData = false;
			boolean bHasOwnership=false;
			//SPEC: <08-04-2021>: Sanjeeva modified for Stress Testing Defect 44365  -- START
			//String sUserlicense = sct.getUserLicense();
			//SPEC: <08-04-2021>: Sanjeeva modified for Stress Testing Defect 44365  -- END
			String sOC = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT)));
			sOC = util.replaceSpecialSymbols(sOC);
			String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
			if(util.isModificatinRequired())
			{
				/*SecurityService sec = new SecurityService();
				String sComp = sec.getUserCauthorities();
				StringList slUserOwnership=util.filterOwnerShip(sComp);

				//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
				if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")) {
					String sFormulaPropagate = util.getFormulaPropagate(context, sId);
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}

				}else {
					bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);
				}*/
				//Added by Ganesh 1.0.2 Release start
				bHasOwnership=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End

				if(!bHasOwnership)
				{
					//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- START
					//sTitle = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					//sFN    = ConstantsUtil.NO_ACCESS;
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
					//sSubstitute = ConstantsUtil.NO_ACCESS;
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
					/*sComments = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sReleaseDate = ConstantsUtil.NO_ACCESS;*/
					sId = ConstantsUtil.NO_ACCESS;
					//sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					//strSubPart = ConstantsUtil.NO_ACCESS;
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//strAlt = ConstantsUtil.NO_ACCESS;
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
				/*	strOSPD = ConstantsUtil.NO_ACCESS;
					strDUOM = ConstantsUtil.NO_ACCESS;*/
					//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
					//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- END

				}
			}else if(sct.isStaffAUGUser()) {

				/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
					String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
					showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
				}else {
					showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
				}*/
				//Added by Ganesh 1.0.2 Release start
				showData=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End
				
				// Added by Jwala for the defect 36209 - START
				if(!showData){
					spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
				} 
				// Added by Jwala for the defect 36209 - END
			} else{

				/*StringList slHIRTypes = new StringList();
				slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
				slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

				if(slHIRTypes.contains(sType)) {
					//SPEC: <10.29.2020>: Added for req 18x.5 ## -- START
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
					}
					//SPEC: <10.29.2020>: Added for req 18x.5 ## -- END
				}else {
					showData=true;
				}*/
				//Added by Ganesh 1.0.2 Release start
				showData=util.checkHasAccess(context, null, sId);
				//Added by Ganesh 1.0.2 Release End
				
				// Added by Jwala for the defect 36209 - START
				if(!showData){
					spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
				}
				// Added by Jwala for the defect 36209 - END
			}
			//Commented by Jwala for the defect - 36209 - START
			/*if(!showData){
				spgChg = ConstantsUtil.NO_ACCESS;
				sId = ConstantsUtil.NO_ACCESS;
				sTitle = ConstantsUtil.NO_ACCESS;
				sFN    = ConstantsUtil.NO_ACCESS;
				sSubstitute = ConstantsUtil.NO_ACCESS;
				sComments = ConstantsUtil.NO_ACCESS;
				sStage = ConstantsUtil.NO_ACCESS;
				sRDOC = ConstantsUtil.NO_ACCESS;
				sTupName = ConstantsUtil.NO_ACCESS;
				sReleaseDate = ConstantsUtil.NO_ACCESS;
				sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
			} */
			//Commented by Jwala for the defect - 36209 - END
			
			//Added by Ketan for Internal Defect -- START
			boolean bHasOwnershipParent = false;
			boolean showDataParent = false;
			if(validator.isNotNullOrEmpty(sParentId)) {
				if(util.isModificatinRequired())
				{
					bHasOwnershipParent = util.checkHasAccess(context, null, sParentId);

					if(!bHasOwnershipParent)
					{
						sParentId = ConstantsUtil.NO_ACCESS;
					}
				}else if(sct.isStaffAUGUser())
				{
					showDataParent = util.checkHasAccess(context, null, sParentId);
				}else
				{	
					showDataParent = util.checkHasAccess(context, null, sParentId);
				}

				if(!util.isModificatinRequired()) {
					if(!showDataParent){
						sParentId = ConstantsUtil.NO_ACCESS;
					}
				}
				
			}
			//Added by Ketan for Internal Defect -- END
			
			sType = util.mapType(sType);
			sParentType = util.mapType(sParentType);
			// Security req -33193 HIR Components Attributes to Show
			formatData(sbEBOMType,sType);
			formatData(sbEBOMName,sName);
			formatData(sbEBOMQTY,sQty);
			formatData(sbEBOMBuom,sBuom);
			formatData(sbEBOMState,sCurrent);

			formatData(sbEBOMId,sId);
			formatData(sbEBOMChg,spgChg);
			formatData(sbEBOMFN,sFN);
			formatData(sbEBOMTitle,sTitle);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//formatData(sbEBOMSubstute,sSubstitute);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			formatData(sbEBOMCommnts,sComments);
			formatData(sbEBOMStage,sStage);
			formatData(sbEBOMRDOC,sRDOC);
			formatData(sbEBOMRevRelDt,sRevRelease);
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//formatData(sbEBOMAlt, strAlt);
			util.formatData(sbAltName,strAltName);
			util.formatData(sbAltID,strAltID);
			util.formatData(sbAltType,strAltType);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			formatData(sbEBOMOSPD, strOSPD);
			formatData(sbEBOMDUOM, strDUOM);
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
			formatData(sbEBOMParentId,sParentId);
			formatData(sbEBOMParentName,sParentName);
			formatData(sbEBOMParentRevision,sParentRevision);
			formatData(sbEBOMParentType,sParentType);
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
			
			if(null!=sTupName && !sTupName.isEmpty()) {
				formatData(sbEBOMTupName,sTupName);
			}
			
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
			util.formatData(sbEBOMSubstitutePart, strSubPart);
			util.formatData(sbEBOMSubPartID, strSubPartId);
			util.formatData(sbEBOMSubPartType, strSubPartType);
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
			//Added by Pooja for the req 35902,41754,33476 -- START
			formatData(sbEBOMpgNSPCG,spgNSPCG);
			formatData(sbGrossWeightReal, strGrossWeightReal);
			formatData(sbGrossWeightUOM, strGrossWeightUOM);
			//Added by Pooja for the req 35902,41754,33476 -- end
			//Added by Ketan for Req. no. 46464 - START
			util.formatData(sbRelRestriction, sRelRestriction);
			util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
			//Added by Ketan for Req. no. 46464 - END
			

		}
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		//mpEBOMResult.put(ConstantsUtil.SUBSTITUTION, sbEBOMSubstute.toString());
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbEBOMAlt.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		mpEBOMResult.put(ConstantsUtil.OSPD, sbEBOMOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbEBOMDUOM.toString());
		
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
		//Added by Pooja for the req 35902,41754,33476 -- START
	    mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbEBOMpgNSPCG.toString());
	    mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
		//Added by Pooja for the req 35902,41754,33476 -- END
		//Added by Ketan for Req. no. 46464 - START
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
		//Added by Ketan for Req. no. 46464 - END		
				
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		return mpEBOMResult;
	}
	
	
	/**
	 * Method Name 			: formatData
	 * Method Description 	: 
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
	/**
	 * Method Name 			: addMultiSelects
	 * Method Description 	: 
	 */
	public StringList addMultiSelects() {

		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
		return slMultiSelects;
	}
	/**
	 * Method Name 			: removeMultiSelects
	 * Method Description 	: For removing the multiselects from DomainCOnstants
	 */
	public void removeMultiSelects()
	{

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
	}
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

}
