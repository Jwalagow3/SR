/**
 * Project 		: SpecsAnywhere
 * Program 		: ARMPBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.fop.FormulationAttribute;
import com.pg.us.specanywhere_enovia.fop.FormulationRelationship;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class ARMPBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(ARMPBO.class);
	static StringValidatorUtil validator = new StringValidatorUtil();
	static BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
	public ARMPBO() {
		// empty constructor
	}

	public ARMPBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name : getArmpBO
	 * Method Description : Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getArmpBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name : getArmpDO
	 * Method Description : Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getArmpDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getARMPPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getARMPPartSelectables(Context context) {
		StringList busSelect = new StringList(150);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getProfileIdentificationSelectables(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getOrgSelects(context));
		busSelect.addAll(getChemicalClassficationsSelectables(context));
		busSelect.addAll(getPhysicalPropertiesSelectables(context));
		busSelect.addAll(getPerfumePropertiesSelectables(context));
		busSelect.addAll(getChemicalMolecularSelectables(context));
		busSelect.addAll(getDetergentSurfactantSelectables(context));
		busSelect.addAll(getReachSelectables(context));
		busSelect.addAll(getSubstanceSelectables(context));
		busSelect.addAll(getStartingMaterialsSelectables(context));
		busSelect.addAll(getWeightCharSelectables(context));
		busSelect.addAll(getMEPS(context));
		busSelect.addAll(getSEPS(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getAlternateSelects(context));
		busSelect.addAll(getFileSelects(context));
		busSelect.addAll(getRegSafetySelectables());
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}

	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		//busSelect.add(ConstantsUtil.SELECT_HISTORY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);

		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.STR_TEMPLATE);
		
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.ATL_ORGNSOURCE);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);

		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACH_EXEMPT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION);

		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		// Guna Added for Defect 38533  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		// Guna Added for Defect 38533  18x.5.2 Release -- END
		
		// Jwala Added for Defect 41554 -- START
		busSelect.add(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
		// Jwala Added for Defect 41554 -- END
		return busSelect;

	}

	
	/**
	 * Method Name : getProfileIdentificationSelectables
	 * Method Description : Fetching "Profile Identification" related data
	 * @param context
	 * @return
	 */
	public static StringList getProfileIdentificationSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INCINAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICALNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EMPIRICALFORMULA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STANDARDCOSTPERKG);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COLORINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRMCISPRONUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPERIMENTALNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALUSAGEGUIDANCE);
		return busSelect;
	}

	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	/**
	 * Method Name : getOrgSelects
	 * Method Description : Fetching "Organization" related data
	 * @param context
	 * @return
	 */
	public static StringList getOrgSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		return busSelect;

	}
	
	
	/**
	 * Method Name 			: getChemicalClassficationsSelectables
	 * Method Description 	: Fetching "Chemical CLassification" related data
	 * @param context
	 * @return
	 */
	public static StringList getChemicalClassficationsSelectables (Context context) {
		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EINECSNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTIONGLOBAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getRegSafetySelectables
	 * Method Description 	: Fetching "Safety" related data
	 * @return
	 */
	public static StringList getRegSafetySelectables () {
		StringList busSelect = new StringList(5);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCASNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIAL_ORIGIN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COLOR_INDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGVALENCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CHEMICAL_REACTIVITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEINECSELINCSNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHEMICALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MOLECULAR_FORMULA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_RPHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_SPHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAFETYSYMBOL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGERCATEGORY);
		return busSelect;
	}

	
	/**
	 * Method Name 			: getPhysicalPropertiesSelectables
	 * Method Description 	: Fetching "Physical Properties" related data
	 * @param context
	 * @return
	 */
	public static StringList getPhysicalPropertiesSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_APPEARANCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COLOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SPECIFICGRAVITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MELTINGPOINT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_BOILINGPOINT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VISCOSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PHYSICALFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_GRADE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRMAQUEOUSSOLUBILITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_AUTOIGNITIONTEMPERATURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FLASHPOINT);
		return busSelect;
	}


	/**
	 * Method Name 			: getPerfumePropertiesSelectables
	 * Method Description 	: Fetching "Perfume Properties" related data
	 * @param context
	 * @return
	 */
	public static StringList getPerfumePropertiesSelectables(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGODORFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYODORDESCRIPTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYODORDESCRIPTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGODORDESCRIPTION);
		return busSelect;

	}

	
	/**
	 * Method Name 			: getChemicalMolecularSelectables
	 * Method Description 	: Fetching "Chemical Molecular" related data
	 * @param context
	 * @return
	 */
	public static StringList getChemicalMolecularSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HYDROPHILICLIPOPHILICBALANCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SAPONIFICATIONVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHYDROPHILICINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HYDROXYLVALUE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACTIVITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_IUSPERGRAM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ALKALINITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ISANIMALDERIVED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PHVALUE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getDetergentSurfactantSelectables
	 * Method Description 	: Fetching "Detergent Substance" related data
	 * @param context
	 * @return
	 */
	public static StringList getDetergentSurfactantSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SO3CONTRIBUTOR);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getReachSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getReachSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACH_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REACHREGISTRATIONNUMBER);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getStartingMaterialsSelectables
	 * Method Description 	: Fetching "Starting Materials" related data
	 * @param context
	 * @return
	 */
	public static StringList getStartingMaterialsSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_TYPE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_REVISION);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_PHASE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_TITLE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_STATE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_STARTINGMATERIAL_ORIGIN_SOURCE);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	: Fetching "Substances" related data
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) 
	{
		StringList busSelect = new StringList();
		
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		/*busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID);
		busSelect.add(ConstantsUtil.COMP_NAME);
		busSelect.add(ConstantsUtil.COMP_SUBNAME);
		busSelect.add(ConstantsUtil.COMP_TITLE);
		busSelect.add(ConstantsUtil.COMP_MAXHGHT);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT);
		busSelect.add(ConstantsUtil.COMP_QUOM);
		busSelect.add(ConstantsUtil.COMP_QTY);
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);
		busSelect.add(ConstantsUtil.COMP_CASNUM);
		busSelect.add(ConstantsUtil.COMP_STATE);
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC);
		busSelect.add(ConstantsUtil.COMP_DRYWEIGHT);
		busSelect.add(ConstantsUtil.COMP_FUNCTIONS);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_ORIGINSOURCE);*/
		
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_TYPE); 
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ID);  
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCENAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.COMP_DRYWEIGHT); 
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_CLASSIITEM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START

		return busSelect;
	}
	
	/**
	 * Method Name 			: getSubstanceRelSelectables
	 * Method Description 	: New Method has been added for 18x.5 to get Substance Rel Selectables
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceRelSelectables (Context context) 
	{
		StringList relSelects = new StringList();
		
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);  		
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
		
		return relSelects;
		
	}
	
	/**
	 * Method Name 			: getWeightCharSelectables
	 * Method Description 	: Fetching "Weight Characteristic" related data
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_TYPE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching "Plants" related data
	 * @param context
	 * @return
	 */
	public static StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		return busSelect;
	}


	/**
	 * Method Name 			: getLifeCycleSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getLifeCycleSelectables (Context context) {
		StringList busSelect = new StringList();
		return busSelect;
	}

	
	/**
	 * Method Name 			: getMEPS
	 * Method Description 	: Fetching "Manufacturing Equivalent" data
	 * @param context
	 * @return
	 */
	public static StringList getMEPS(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURER_NAME);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_ORIGINSOURCE);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_RELEASE_PHASE);
		
		return busSelect;
	}

	
	/**
	 * Method Name 			: getSEPS
	 * Method Description 	: Fetching "Supplier Equivalent" information
	 * @param context
	 * @return
	 */
	public static StringList getSEPS(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_NAME);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME); 
		busSelect.add(ConstantsUtil.SELECT_SUPPLIER_NAME);
		busSelect.add(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_ORIGINSOURCE);
		
		return busSelect;
	}


	/**
	 * Method Name 			: getAlternateSelects
	 * Method Description 	: Fetching "Alternate" data
	 * @param context
	 * @return
	 */
	public static StringList getAlternateSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE_BASE_UOM);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE__RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ALTERNATE__ORIGIN_SOURCE);

		return busSelect;
	}


	/**
	 * Method Name 			: getRMPConnectedObjectBusPerformanceSpecs
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getRMPConnectedObjectBusPerformanceSpecs(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SHAREDTABLECHARACTERISTICSEQUENCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	: Fetching "Substances" related data
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			String sType    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REVS));
			String sDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sCurrent =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_STATE));
			sCurrent=sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String sCAS 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			String sSub 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SUBNAME));
			String sQTS 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QSTCOMPOSITE));
			String sCont    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ISCONTAM));
			String sQTY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT));
			String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT));
			String sQUOM    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));	

			String sMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			String sMFR     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sTrN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sDRY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DRYWEIGHT));
			String sFunctions =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_FUNCTIONS));
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String strOrignSource	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ORIGINSOURCE));

			sType = util.mapType(sType);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.REV,sRev);
			mpSubStanceResult.put(ConstantsUtil.STATE,sCurrent);
			mpSubStanceResult.put(ConstantsUtil.CAS,sCAS);
			mpSubStanceResult.put(ConstantsUtil.SUBSTANCENAME,sSub);
			mpSubStanceResult.put(ConstantsUtil.QSTARGET,sQTS);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			mpSubStanceResult.put(ConstantsUtil.IC,sCont);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.UOM,sQUOM);

			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sDRY);
			mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sFunctions);
			mpSubStanceResult.put(ConstantsUtil.PHASE, strPhase);
			mpSubStanceResult.put(ConstantsUtil.ORIGINSOURCE, strOrignSource);


		}catch(Exception e){

			LOGGER.error("Error from ARMPBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	/**
	 * Method Name 			: getMaterialComposition
	 * Method Description 	: Fetching "Material Composition" information
	 * @param resultMaps
	 * @return
	 */
	public Map getMaterialComposition(Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REVS));
			String sDesc = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sTitle = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_STATE));
			sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String sCAS = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CASNUM));
			String sSub = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SUBNAME));
			String sCont = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ISCONTAM));
			String sQTY = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sMAXWt = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT));
			String sMInWt = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT));
			String sQUOM = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));
			String sDRY = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DRYWEIGHT));
			String sFunctions = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_FUNCTIONS));
			

			sType=util.mapType(sType);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.REV,sRev);
			mpSubStanceResult.put(ConstantsUtil.STATE,sCurrent);
			mpSubStanceResult.put(ConstantsUtil.CAS,sCAS);
			mpSubStanceResult.put(ConstantsUtil.SUBSTANCENAME,sSub);
			mpSubStanceResult.put(ConstantsUtil.QUANTITYTYPE,sQTY);
			mpSubStanceResult.put(ConstantsUtil.IC,sCont);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.UOM,sQUOM);
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sDRY);
			mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sFunctions);


		}catch(Exception e){

			LOGGER.error("Error from ARMPBO:  getMaterialComposition"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	/**
	 * Method Name 			: getManufacturerEquivalents
	 * Method Description 	: Fetching "Manufacturer Equivalent" information
	 * @param resultMaps
	 * @return
	 */
	public Map getManufacturerEquivalents(Map resultMaps)
	{

		Map<String, String> mpManufacturerEquivalents = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_TYPE));
			String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_NAME));
			String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_REVISION));
			String sDesc = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_DESCRIPTION));
			String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_CURRENT));
			sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String strMfr = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURER_NAME));
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_RELEASE_PHASE));
			String strOrignSource	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_ORIGINSOURCE));
			
			sType=util.mapType(sType);
			mpManufacturerEquivalents.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpManufacturerEquivalents.put(ConstantsUtil.TYPE,sType);
			mpManufacturerEquivalents.put(ConstantsUtil.NAME,sName);
			mpManufacturerEquivalents.put(ConstantsUtil.REV,sRev);
			mpManufacturerEquivalents.put(ConstantsUtil.STATE,sCurrent);
			mpManufacturerEquivalents.put(ConstantsUtil.MANUFACTURER,strMfr);
			mpManufacturerEquivalents.put(ConstantsUtil.PHASE, strPhase);
			mpManufacturerEquivalents.put(ConstantsUtil.ORIGINSOURCE, strOrignSource);
			
		}catch(Exception e){

			LOGGER.error("Error from ARMPBO:  getManufacturerEquivalents"+e);
			return new HashMap();
		}
		return mpManufacturerEquivalents;
	}
	
	
	/**
	 * Method Name 			: getSupplierEquivalents
	 * Method Description 	: Fetching "Supplier Equivalent" data
	 * @param resultMaps
	 * @return
	 */
	public Map getSupplierEquivalents(Map resultMaps)
	{

		Map<String, String> mpSupplierEquivalents = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			
			String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_TYPE));
			String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_NAME));
			String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_REVISION));
			String sDesc = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_DESCRIPTION));
			String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_CURRENT));
			sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
			String strSupplier = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_SUPPLIER_NAME));
			String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_RELEASE_PHASE));
			String strOrignSource	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_ORIGINSOURCE));
			
			sType=util.mapType(sType);
			mpSupplierEquivalents.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSupplierEquivalents.put(ConstantsUtil.TYPE,sType);
			mpSupplierEquivalents.put(ConstantsUtil.NAME,sName);
			mpSupplierEquivalents.put(ConstantsUtil.REV,sRev);
			mpSupplierEquivalents.put(ConstantsUtil.STATE,sCurrent);
			mpSupplierEquivalents.put(ConstantsUtil.SUPPLIER,strSupplier);
			mpSupplierEquivalents.put(ConstantsUtil.PHASE, strPhase);
			mpSupplierEquivalents.put(ConstantsUtil.ORIGINSOURCE, strOrignSource);
			
		}catch(Exception e){

			LOGGER.error("Error from ARMPBO:  getSupplierEquivalents"+e);
			return new HashMap();
		}
		return mpSupplierEquivalents;
	}
	
	
	/**
	 * Method Name 			: getMasterAttributeData
	 * Method Description 	: Fetching "Master Attribute" information
	 * @param context
	 * @param sMasterID
	 * @return
	 * @throws Exception
	 */
	public Map getMasterAttributeData(Context context, String sMasterID) throws Exception {

		Map<String, Object> mpAttribResult = new HashMap<String, Object>();
		StringList busSelect = new StringList();	
		DomainObject doRMP =  getArmpDO(context, sMasterID);
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		Map resultMaps = doRMP.getInfo(context,busSelect);
		StringValidatorUtil validator = new StringValidatorUtil();
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE, BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_TEMPLATE)))?(String)resultMaps.get(ConstantsUtil.STR_TEMPLATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		
		//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
		String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String strBrand = util.getBrandInformationValue(context,sID);
		if(strBrand.isEmpty()) {
			strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
		}
		mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
		
		mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_VAULT)))?(String)resultMaps.get(ConstantsUtil.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ALTERNATIVEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);

		return mpAttribResult;
	}


	/**
	 * Method Name 			: addMultiList
	 * Method Description 	: 
	 */
	public StringList addMultiList(){
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.COMP_TYPE); 
		slMultiSelects.add(ConstantsUtil.COMP_ID); 
		slMultiSelects.add(ConstantsUtil.COMP_NAME);
		slMultiSelects.add(ConstantsUtil.COMP_SUBNAME);
		slMultiSelects.add(ConstantsUtil.COMP_TITLE);
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT);
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);
		slMultiSelects.add(ConstantsUtil.COMP_QTY);
		slMultiSelects.add(ConstantsUtil.COMP_ISCONTAM);
		slMultiSelects.add(ConstantsUtil.COMP_CASNUM);
		slMultiSelects.add(ConstantsUtil.COMP_STATE);
		slMultiSelects.add(ConstantsUtil.COMP_REVS);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC);
		slMultiSelects.add(ConstantsUtil.COMP_DRYWEIGHT);
		slMultiSelects.add(ConstantsUtil.COMP_FUNCTIONS);
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_ORIGINSOURCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLIER_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_ORIGINSOURCE);

		slMultiSelects.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME);
		slMultiSelects.add(ConstantsUtil.SELECT_MANUFACTURER_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_ORIGINSOURCE);

		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);

		// Guna Added for Defect 38533  18x.5.2 Release -- START
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		// Guna Modified for Defect 38533  18x.5.2 Release -- END

		// Jwala Added for Defect 41554 -- START
		slMultiSelects.add(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
		// Jwala Added for Defect 41554 -- END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
		
		return slMultiSelects;

	}


	/**
	 * Method Name 			: removeMultiValueList
	 * Method Description 	: 
	 */
	public void removeMultiValueList() 
	{

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SUBNAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ISCONTAM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DRYWEIGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_FUNCTIONS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ORIGINSOURCE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLIEREQUIVALENT_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLIER_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT__SUPPLIEREQUIVALENT_ORIGINSOURCE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MANUFACTURER_NAME);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_MANUFACTURINGEQUIVALENT_ORIGINSOURCE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		// Guna Added for Defect 38533  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		// Guna Modified for Defect 38533  18x.5.2 Release -- END

		// Jwala Added for Defect 41554 -- START
		DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME);
		//Jwala Added for Defect 41554 -- END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END

	}

	
	/**
	 * Method Name 			: getEDList
	 * Method Description 	: Fetching "Electronic Distribution" data
	 * @param resultMaps
	 * @return
	 * Updated with LDAP Changes
	 */
	public static String getEDList(Map resultMaps,String ldapuser,String ldappwd) {
		String sAttrVal =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION) : ConstantsUtil.EMPTY_STRING;
		String strAttrValue=ConstantsUtil.EMPTY_STRING;
		String strValue=ConstantsUtil.EMPTY_STRING;
		StringTokenizer newValues=null;
		StringList strList=new StringList();

		if (sAttrVal != null && sAttrVal.trim().length() > 0) {
			newValues=new StringTokenizer(sAttrVal,ConstantsUtil.SYMBL_PIPE);
			while(newValues.hasMoreTokens())
			{
				strAttrValue=newValues.nextToken();
				if(null!=strAttrValue && (!strAttrValue.isEmpty())){
					strAttrValue = BbUtil.getLDAPInfo(strAttrValue.trim(), true,ldapuser,ldappwd);
					strList.addElement(strAttrValue);
					strList.sort();
					strValue = FrameworkUtil.join(strList, ConstantsUtil.SYMBL_PIPE);
				}
			}

		}
		return strValue;

	}
	
	
	/**
	 * Method Name : updateDerivedDataInfo
	 * Method Description :
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sCreatedDate, String sCreator,DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();


		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, getTo, getFrom, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : ARMPBO Method :updateDerivedDataInfo "+e);
			return new HashMap();
		}
		return mpDerived;
	}
	
	/**
	 * Method Name 			: formatData
	 * Method Description 	: New Method has been added for 18x.5 to formatData
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	: New Method has been added for 18x.5 to get Substance for ARMP
	 * @param context
	 * @return
	 */
	public Map getSubstances(Context context,String strObjId)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId=new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbRevision=new StringBuilder();
		StringBuilder sbDesc=new StringBuilder();
		StringBuilder sbCAS=new StringBuilder();
		StringBuilder sbCont = new StringBuilder();
		StringBuilder sbMaxWt = new StringBuilder();
		StringBuilder sbMinWt = new StringBuilder();
		StringBuilder sbQOM=new StringBuilder();
		StringBuilder sbDry=new StringBuilder();
		StringBuilder sbFunction=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		StringBuilder sbQST = new StringBuilder();
		StringBuilder sbFlags = new StringBuilder();
		StringBuilder sbClasssified=new StringBuilder();
		StringBuilder sbIPClass=new StringBuilder();

		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strObjId))
			{
				DomainObject contextObj = DomainObject.newInstance(context,strObjId);

				MapList mlRelatedIAPSList = contextObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,
						ConstantsUtil.SYMBL_ASTERISK, getSubstanceSelectables(context), getSubstanceRelSelectables(context), false, true, (short) 0,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				
				mlRelatedIAPSList=getUsageFlags(mlRelatedIAPSList);

				Iterator objectListItr = mlRelatedIAPSList.iterator();

				while(objectListItr.hasNext()){

					Map resultMaps = (Map) objectListItr.next();

					String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
					String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
					String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
					
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//String strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
					String strDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
					//String strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String strTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
					
					String strRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
					String strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
					
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//String strCAS	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
					String strCAS	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
					
					String sIsImpurity	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
					String strMaxWt	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
					String strMinWt	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
					String strQom	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
					String strDry	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
					
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//String strFunctions	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
					String strFunctions	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
					
					String sPhase   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
					String sQSTOCOMP	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE));
					String sIsTarget	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL));
					String strQST = ConstantsUtil.EMPTY_STRING;
					String sFlags	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.FLAGS));
					String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIITEM));
					String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));

					if(strMinWt.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
						strMinWt = ConstantsUtil.EMPTY_STRING;

					if(strMaxWt.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
						strMaxWt = ConstantsUtil.EMPTY_STRING;

					formatData(sbType,strType);
					formatData(sbName,strName);
					formatData(sbDesc,strDesc);
					formatData(sbCurrent,strState);
					formatData(sbId,strID);
					formatData(sbRevision,strRev);
					formatData(sbCAS,strCAS);
					formatData(sbTitle,strTitle);
					formatData(sbCont,sIsImpurity);
					formatData(sbMaxWt,strMaxWt);
					formatData(sbMinWt,strMinWt);
					formatData(sbQOM,strQom);
					formatData(sbDry,strDry);
					formatData(sbFunction,strFunctions);
					formatData(sbPhase,sPhase);
					formatData(sbClasssified,strClassFied);
					formatData(sbIPClass,sIPClassfication);
					formatData(sbFlags,sFlags);
					
					if(UIUtil.isNotNullAndNotEmpty(sQSTOCOMP) && UIUtil.isNotNullAndNotEmpty(sIsTarget)){
						strQST	 = (sQSTOCOMP.equalsIgnoreCase("TRUE"))? ConstantsUtil.QS:
										(sIsTarget.equalsIgnoreCase("TRUE"))? ConstantsUtil.TARGET_COMPONENT : "";
							}
					formatData(sbQST,strQST);

				}
				mpSubStanceResult.put(ConstantsUtil.SECURITY, sbClasssified.toString());
				mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sbIPClass.toString());
				mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString());
				mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString());
				mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString());
				mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString());
				mpSubStanceResult.put(ConstantsUtil.REV,sbRevision.toString());
				mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString());
				mpSubStanceResult.put(ConstantsUtil.PHASE,sbPhase.toString());
				mpSubStanceResult.put(ConstantsUtil.CAS,sbCAS.toString());
				mpSubStanceResult.put(ConstantsUtil.ISIMPURITY,sbCont.toString());
				mpSubStanceResult.put(ConstantsUtil.MAX,sbMaxWt.toString());
				mpSubStanceResult.put(ConstantsUtil.MIN,sbMinWt.toString());
				mpSubStanceResult.put(ConstantsUtil.UOM,sbQOM.toString());
				mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sbDry.toString());
				mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sbFunction.toString());
				mpSubStanceResult.put(ConstantsUtil.QSTARGET,sbQST.toString());
				mpSubStanceResult.put(ConstantsUtil.FLAGS, sbFlags.toString());
				mpSubStanceResult.put(ConstantsUtil.ID, sbId.toString());
				
			}
		}catch(Exception e){

			LOGGER.error("Error from ARMPBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	/**
	 * Method Name 			: getUsageFlags
	 * Method Description 	: Getting the Flags on the Materials
	 * @param resultMap
	 * @return
	 * @throws Exception
	 */
	public MapList getUsageFlags(MapList resultMap) throws Exception{
		
		String 	strResult = ConstantsUtil.EMPTY_STRING;
		StringList strList = new StringList();
		MapList mlfinalList = new MapList();
		try{

			Map mpTemp = new HashMap();
			Iterator itr = resultMap.iterator();
			while(itr.hasNext())
			{
				Map resMap = (Map) itr.next();
				String	 drugActive = (String) resMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
				String	 Colorant = (String) resMap.get(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
				String	 Preservative  = (String) resMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
				String	 rel = (String) resMap.get(DomainConstants.SELECT_NAME);
			
					if( UIUtil.isNotNullAndNotEmpty(drugActive) && UIUtil.isNotNullAndNotEmpty(Colorant) && UIUtil.isNotNullAndNotEmpty(Preservative))
					{
						if(drugActive.equalsIgnoreCase("Yes"))
							strList.add(ConstantsUtil.DRUG_ACTIVE);;
						 if(Colorant.equalsIgnoreCase("TRUE"))
							 strList.add(ConstantsUtil.COLORANT);;
						 if(Preservative.equalsIgnoreCase("Yes"))
							 strList.add(ConstantsUtil.PRESERVATIVE);;
					}
				resMap.put(ConstantsUtil.FLAGS, FrameworkUtil.join(strList, ","));
				mlfinalList.add(resMap);
		   } 	
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}
		
		return mlfinalList;
	}
	
	
	/**
	 * Method Name 			: getMaterialCompositionAndSubstance
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getMaterialCompositionAndSubstance(Context context, Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String sRawMatId = (String) resultMaps.get(ConstantsUtil.SELECT_ID);
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID	 =  new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbCAS = new StringBuilder();
		StringBuilder sbCont = new StringBuilder();
		StringBuilder sbMAXWt = new StringBuilder();
		StringBuilder sbMInWt = new StringBuilder();
		StringBuilder sbQUOM = new StringBuilder();
		StringBuilder sbDRY = new StringBuilder();
		StringBuilder sbFunctions = new StringBuilder();
		StringBuilder sbtrClassFied = new StringBuilder();
		StringBuilder sbIPClassfication = new StringBuilder();
		
		//Added for Defect #37436 by Amman on 11/19/2020 -- START
		StringBuilder sbQTS = new StringBuilder();
		StringBuilder sbUF = new StringBuilder();
		StringBuilder sbFN = new StringBuilder();
		//Added for Defect #37436 by Amman on 11/19/2020 -- END
		StringBuilder sbParentName = new StringBuilder();//Added by Ajay for 22x.06 Req.9264
		//Modified by Ganesh for Defect 41560 on Date <15/April/2021>---->START
		DecimalFormat decimalformatter = new DecimalFormat(ConstantsUtil.PATTERN_DECIMALFORMAT);
		//Modified by Ganesh for Defect 41560 on Date <15/April/2021>---->END
		try
		{
			DomainObject doObj = new DomainObject(sRawMatId);
			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_NAME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slBusSelects.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slBusSelects.add(ConstantsUtil.COMP_CLASSIITEM);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
			//START :: gaikwad.tg :: Defect#37283
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME);
			//END :: gaikwad.tg :: Defect#37283
			//Added by Ganesh for Defect 41560 on Date <15/April/2021>---->START
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
			//Added by Ganesh for Defect 41560 on Date <15/April/2021>---->END
			StringList slRelSelects = new StringList();
			//Modified for Defect #37311 -- START
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			
			//Added for Defect #37436 by Amman on 11/19/2020 -- START
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_USAGE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
			//Added for Defect #37436 by Amman on 11/19/2020 -- END
			//Modified for Defect #37311 -- END
			
			////SPEC : Modified by Ganesh on 6-Jan-2021 for  Requirement 38258 --START
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_NAME);
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			//START :: gaikwad.tg
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
			slRelSelects.add("from.name");
			slRelSelects.add("from.id");
			
			//SPEC: Modified for Defect #38180 by Chandra on 01/22/2021 -- START
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
			
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
			
			SecurityService sec = new SecurityService();
			boolean bIsComplainceEngineer =sec.isComplainceEngineer();
			
			//SPEC: Modified for Defect #38180 by Chandra on 01/22/2021 -- END
			//END :: gaikwad.tg
			/*MapList mlComponentsAnMaterials = doObj.getRelatedObjects(context, 
			 * ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, true, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);*/
			
			Pattern objType = new Pattern(ConstantsUtil.TYPE_MATERIAL);
			objType.addPattern(ConstantsUtil.TYPE_SUBSTANCE);

			Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL);
			relType.addPattern(ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE);
			relType.addPattern(ConstantsUtil.RELATIONSHIP_SECURE_COMPONENT_SUBSTANCE);
			
			MapList mlComponentsAnMaterials = doObj.getRelatedObjects(context, 
					relType.getPattern(),
					objType.getPattern(), 
					slBusSelects, 
					slRelSelects, 
					false, 
					true, 
					(short) 0, //Expand level to all
					ConstantsUtil.EMPTY_STRING, 
					ConstantsUtil.EMPTY_STRING, 
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doObj.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			
			ARMPBO armpbo = new ARMPBO();
			
			//SPEC : Modified for Defect #38180 by Chandra on 01/22/2021 -- START
			//mlComponentsAnMaterials=armpbo.getUsageFlags(mlComponentsAnMaterials);
			mlComponentsAnMaterials = util.getUsageFlags(context, mlComponentsAnMaterials);
			//SPEC : Modified for Defect #38180 by Chandra on 01/22/2021 -- END
			
			//mlComponentsAnMaterials.sort(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,ConstantsUtil.ASCENDING,ConstantsUtil.STRING);
			//START :: gaikwad.tg
			mlComponentsAnMaterials = util.getSortedMaplistWithSequence(context, mlComponentsAnMaterials, sRawMatId);
			//END :: gaikwad.tg
			//mlComponentsAnMaterials.sort("relationship",ConstantsUtil.ASCENDING,ConstantsUtil.STRING);
			
			String pType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
			String pName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
			String pID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
			String pRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
			String pDesc = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
			String pCurrent1 = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
			//START :: gaikwad.tg :: Defect#37283
			String pTitle = validator.getStringEquivalentForSubstituteStringTitle(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
			//END :: gaikwad.tg :: Defect#37283
			//START :: gaikwad.tg
			if(mlComponentsAnMaterials!=null && mlComponentsAnMaterials.size()>0)
			{
				util.formatData(sbType, util.mapType(pType));
				util.formatData(sbName, pName);
				util.formatData(sbID, pID);
				util.formatData(sbRev, pRev);
				util.formatData(sbDesc, pDesc);
				//START :: gaikwad.tg :: Defect#37283
				util.formatData(sbTitle, pTitle);
				//START :: gaikwad.tg :: Defect#37283
				util.formatData(sbCurrent, pCurrent1);
				util.formatData(sbCAS, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbQTS, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbUF, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbCont, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbMAXWt, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbMInWt, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbDRY, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbQUOM,ConstantsUtil.EMPTY_STRING);
				util.formatData(sbFunctions, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbtrClassFied, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbIPClassfication, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbParentName, ConstantsUtil.EMPTY_STRING);//Added by Ajay for 22x.06 Req.9264
				//util.formatData(sbFN, ConstantsUtil.EMPTY_STRING);
			}
			//END :: gaikwad.tg
		//END :: gaikwad.tg
			
			//SPEC : Modified by Ganesh on 6-Jan-2021 for  Requirement 38258 --END
			
			Iterator objectListItr = mlComponentsAnMaterials.iterator();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				
				//SPEC : Modified by Ganesh on 6-Jan-2021 for  Requirement 38258 --START
               String relName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_NAME));
			
				if(relName.equals(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL)) {
				
				//strValue	 = (qsComposite.equalsIgnoreCase("TRUE"))? CPNUIUtil.getProperty(context, "emxCPN.Range.QSComposite"):
				//(isTargetMaterial.equalsIgnoreCase("TRUE"))? CPNUIUtil.getProperty(context, "emxCPN.Range.TargetMaterial") : "";
				String sType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
				String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String strID	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sDesc = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sDesc = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				//String sTitle = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sTitle = validator.getStringEquivalentForSubstituteStringTitle(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sCurrent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sCAS = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
				String sCAS = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sCont = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
				//SPEC: <13.10.2020>: Commented for the Release 18x5 -- START--
				//String sSub = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_SUBNAME));
				//String sQTY = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.COMP_QTY));
				//SPEC: <13.10.2020>: Commented for the Release 18x5 -- END --
				String sMAXWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
				String sMInWt = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
				String sQUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
				String sDRY = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
				String sParentName	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME));//Added by Ajay for 22x.06 Req.9264
				//SPEC: Modified for Defect #38263 by Chandra on 01/25/2021 -- START
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sFunctions = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
			    //String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION));
				if (UIUtil.isNotNullAndNotEmpty(sFunctions)) 
				{
					sFunctions=util.getIdFromPhysicalIdFunction(context,sFunctions);
					
				}
				//SPEC: Modified for Defect #38263 by Chandra on 01/25/2021 -- END
				
				String strClassFied = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.COMP_CLASSIITEM));
				String sIPClassfication = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				
				//Modified for Defect #37436 by Amman on 11/24/2020 -- START
				String sQTS = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL));
				//String sUF = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_USAGE));
				String sTarget = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL));
				//Modified for Defect #37436 by Amman on 11/24/2020 -- END
				
				
				//SPEC : Modified for Defect #38180 by Chandra on 01/22/2021 -- START
				//String sUF = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_USAGE));
				String sUF	 =  validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.FLAGS));
				String isTargetMaterial = (String) objectMap.get(FormulationAttribute.IS_TARGET_MATERIAL.getAttributeSelect(context));
				String sFill = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
				String rel = (String) objectMap.get("relationship");
				
				
				if(UIUtil.isNotNullAndNotEmpty(rel) && !bIsComplainceEngineer && rel.equalsIgnoreCase(FormulationRelationship.SECURE_COMPONENT_SUBSTANCE.getRelationship(context)) ){
					sQTS="";;
				}else
				{
					if(UIUtil.isNotNullAndNotEmpty(sFill) && UIUtil.isNotNullAndNotEmpty(isTargetMaterial)){
						sQTS	 = (sFill.equalsIgnoreCase("TRUE"))? ConstantsUtil.QS:
								(isTargetMaterial.equalsIgnoreCase("TRUE"))? ConstantsUtil.TARGET_COMPONENT : "";
					}
				}
				
				//SPEC: Modified for Defect #38180 by Chandra on 01/22/2021 -- END
					
				
				//START :: gaikwad.tg
				String sFN      =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));
				//START :: gaikwad.tg
				util.formatData(sbFN,sFN);
				//END :: gaikwad.tg
				util.formatData(sbType, util.mapType(sType));
				util.formatData(sbName, sName);
				util.formatData(sbID, strID);
				util.formatData(sbRev, sRev);
				util.formatData(sbDesc, sDesc);
				util.formatData(sbTitle, sTitle);
				util.formatData(sbCurrent, sCurrent);
				util.formatData(sbCAS, sCAS);
				
				//Added for Defect #37436 by Amman on 11/19/2020 -- START
				util.formatData(sbQTS, sQTS);
				util.formatData(sbUF, sUF);
				//Added for Defect #37436 by Amman on 11/19/2020 -- END
				
				//Modified for Defect #37311 -- START
				if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
					sCont = ConstantsUtil.SYMBL_CAPTRUE;
				} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
					sCont = ConstantsUtil.SYMBL_CAPFALSE;
				}
				
				util.formatData(sbCont, sCont);
				
				if(!validator.isNotNullOrEmpty(sMInWt) || sMInWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sMInWt = ConstantsUtil.EMPTY_SPACE;
				}
				//commented by Ganesh for Defect 41560 on Date <15/April/2021>---->START
				/*if(!validator.isNotNullOrEmpty(sDRY) || sDRY.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					//START :: gaikwad.tg :: Defect#37283
					//sDRY = ConstantsUtil.EMPTY_SPACE;
					sDRY = "0";
					//START :: gaikwad.tg :: Defect#37283
				}*/
				//commented by Ganesh for Defect 41560 on Date <15/April/2021>---->END
				if(!validator.isNotNullOrEmpty(sMAXWt) || sMAXWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sMAXWt = ConstantsUtil.EMPTY_SPACE;
				}
				//Modified for Defect #37311 -- END
				
				util.formatData(sbMAXWt, sMAXWt);
				util.formatData(sbMInWt, sMInWt);
				util.formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
				
				//Modified for Defect #37311 -- START
				//util.formatData(sbMInWt, sMInWt);
				//Modified for Defect #37311 -- END
				//commented by Ganesh for Defect 41560 on Date <15/April/2021>---->START
				//Added for Defect #37436 by Amman on 11/24/2020 -- START
				//Reason/Logic : With the Substance(s) now added to the IMP, enter a Dry % (w/w) for each. These values must add up to 100.
				/*if(sDRY.equalsIgnoreCase("1.0")) {
					sDRY="100.0";
				}*/
				//Added for Defect #37436 by Amman on 11/24/2020 -- END
				//commented by Ganesh for Defect 41560 on Date <15/April/2021>---->END
				//Modified by Ganesh for Defect 41560 on Date <15/April/2021>---->START
				String strTempDry = util.getDryValueToDisplay(context, objectMap);
				if(!validator.isNotNullOrEmpty(sDRY) && sDRY.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
					strTempDry = "0";
				else if(sDRY.equalsIgnoreCase("1.0"))
				    strTempDry="1";
				util.formatData(sbDRY, strTempDry);
				//util.formatData(sbDRY, sDRY);
				//Modified by Ganesh for Defect 41560 on Date <15/April/2021>---->END
				//Added for Defect #37311 -- START
				util.formatData(sbQUOM,sQUOM);
				//Added for Defect #37311 -- END
				
				util.formatData(sbFunctions, sFunctions);
				util.formatData(sbtrClassFied, strClassFied);
				util.formatData(sbIPClassfication, sIPClassfication);
				}else if(relName.equalsIgnoreCase("Component Substance")|| relName.equalsIgnoreCase("Secure Component Substance")){
				//DomainObject doComponent = new DomainObject(strID);
				slBusSelects = new StringList();
				slBusSelects.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
				slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME);
				slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
				slBusSelects.add(ConstantsUtil.COMP_CLASSIITEM);
				
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
				
				//Added for Defect #37436 by Amman on 11/25/2020 -- START
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_USAGE);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
				//Added for Defect #37436 by Amman on 11/25/2020 -- END
				
				//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- START
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
				slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
				//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- END
				
				//commented by Ganesh on 6-Jan-2021 for  Requirement 38258 start
				/*MapList mlComponentsAnSubstance = doComponent.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE,
						ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, true, true, (short) 1,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				
				//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- START
				mlComponentsAnSubstance=getUsageFlags(mlComponentsAnSubstance);
				//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- END
				
				
				Iterator objectListItr2 = mlComponentsAnSubstance.iterator();

				while(objectListItr2.hasNext())
				{*/
				//commented by Ganesh on 6-Jan-2021 for  Requirement 38258 end
					Map objectMap2 = objectMap;//(Map) objectListItr2.next();
					String sType = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_TYPE));
					String sName = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_NAME));
					String strID	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ID));
					String sRev = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_REVISION));
					
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//sDesc = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_DESCRIPTION));
					String sDesc = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_DESCRIPTION));
					//Modified for Defect #37436 by Amman on 11/24/2020-- START
					//sTitle = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME));
					//sTitle = validator.getStringEquivalentForStringListWithComma(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME));
					String sTitle = validator.getStringEquivalentForSubstituteStringTitle(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME));
					//Modified for Defect #37436 by Amman on 11/24/2020-- END
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
					
					String sCurrent = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_CURRENT));
					       sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
					
					//Modified for Defect #37436 by Amman on 11/24/2020-- START
					//sCAS = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
					//sCAS = validator.getStringEquivalentForStringListWithComma(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
					String sCAS = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
					//Modified for Defect #37436 by Amman on 11/24/2020-- END
					
					String sCont = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
					String sMAXWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
					String sMInWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
					String sQUOM = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
					String sDRY = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
					String sParentName	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtilIRM.SELECT_EBOM_NAME));//Added by Ajay for 22x.06 Req.9264
					//SPEC: Modified for Defect #38263 by Chandra on 01/25/2021 -- START	
					
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//sFunctions = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
					//String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
					String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION));
					if (UIUtil.isNotNullAndNotEmpty(sFunctions)) 
					{
						sFunctions=util.getIdFromPhysicalIdFunction(context,sFunctions);
						
					}
					//SPEC: Modified for Defect #38263 by Chandra on 01/25/2021 -- END
					String strClassFied = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.COMP_CLASSIITEM));
					String sIPClassfication = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
					
					//Modified for Defect #37436 by Amman on 11/25/2020 -- START
					String sQTS = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL));
					//SPEC: Modified for Defect#37618 1.0.2 Release - Jwala -- START
					//sUF = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_USAGE));
					String sUF	 =  validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.FLAGS));
					//SPEC: Modified for Defect#37618 1.0.2 Release - Jwala -- END
					String sTarget = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL));
					
					//SPEC : Modified for Defect #38180 by Chandra on 01/22/2021 -- START
					String isTargetMaterial = (String) objectMap.get(FormulationAttribute.IS_TARGET_MATERIAL.getAttributeSelect(context));
					String sFill = (String)objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
					String rel = (String) objectMap.get("relationship");
					
					if(UIUtil.isNotNullAndNotEmpty(rel) && !bIsComplainceEngineer && rel.equalsIgnoreCase(FormulationRelationship.SECURE_COMPONENT_SUBSTANCE.getRelationship(context)) ){
						sQTS="";;
					}else
					{
						if(UIUtil.isNotNullAndNotEmpty(sFill) && UIUtil.isNotNullAndNotEmpty(isTargetMaterial)){
							sQTS	 = (sFill.equalsIgnoreCase("TRUE"))? ConstantsUtil.QS:
									(isTargetMaterial.equalsIgnoreCase("TRUE"))? ConstantsUtil.TARGET_COMPONENT : "";
						}
					}
					//SPEC: Modified for Defect #38180 by Chandra on 01/22/2021 -- END
					
					/*
					if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
						if(sTarget.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
							sQTS = ConstantsUtil.TARGET_MATERIAL;
						}else {
							sQTS = ConstantsUtil.QS;
						}
					}
					*/
					//Modified for Defect #37436 by Amman on 11/25/2020 -- END
					//START :: gaikwad.tg
					String sFN      =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));
					//START :: gaikwad.tg

					//START :: gaikwad.tg
					util.formatData(sbFN,sFN);
					//END :: gaikwad.tg
					util.formatData(sbType, util.mapType(sType));
					util.formatData(sbName, sName);
					util.formatData(sbID, strID);
					util.formatData(sbRev, sRev);
					util.formatData(sbDesc, sDesc);
					util.formatData(sbTitle, sTitle);
					util.formatData(sbCurrent, sCurrent);
					util.formatData(sbCAS, sCAS);
					util.formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
					
					//Added for Defect #37436 by Amman on 11/19/2020 -- START
					util.formatData(sbQTS, sQTS);
					util.formatData(sbUF, sUF);
					//Added for Defect #37436 by Amman on 11/19/2020 -- END
					
					//Modified for Defect #37311 -- START
					if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
						sCont = ConstantsUtil.SYMBL_CAPTRUE;
					} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
						sCont = ConstantsUtil.SYMBL_CAPFALSE;
					}
					
					util.formatData(sbCont, sCont);
					
					if(!validator.isNotNullOrEmpty(sMInWt) || sMInWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
						sMInWt = ConstantsUtil.EMPTY_SPACE;
					}
					//commented by Ganesh for Defect 41560 on Date <15/April/2021>---->START
					/*if(!validator.isNotNullOrEmpty(sDRY) || sDRY.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
						//START :: gaikwad.tg :: Defect#37283
						//sDRY = ConstantsUtil.EMPTY_SPACE;
						sDRY = "0";
						//START :: gaikwad.tg :: Defect#37283
					}*/
					//commented by Ganesh for Defect 41560 on Date <15/April/2021>---->END
					if(!validator.isNotNullOrEmpty(sMAXWt) || sMAXWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
						sMAXWt = ConstantsUtil.EMPTY_SPACE;
					}
					//Modified for Defect #37311 -- END
					
					//Modified for Defect #37436 by Amman on 11/24/2020-- START
					//util.formatData(sbMAXWt, sMAXWt);
					if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPTRUE)) {
						util.formatData(sbMAXWt, sDRY);
					} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPFALSE)) {
						util.formatData(sbMAXWt, sMAXWt);
					}
					//Modified for Defect #37436 by Amman on 11/24/2020 -- END
					
					util.formatData(sbMInWt, sMInWt);
					
					//Modified for Defect #37311 -- START
					//util.formatData(sbMInWt, sMInWt);
					//Modified for Defect #37311 -- END
					//commented by Ganesh for Defect 41560 on Date <15/April/2021>---->START
					//Modified for Defect #37436 by Amman on 11/24/2020 -- START
					//util.formatData(sbDRY, sDRY);
					/*if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPTRUE)) {
						util.formatData(sbDRY, sMAXWt);
					} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPFALSE)) {
						util.formatData(sbDRY, sDRY);
					}*/
					//Modified for Defect #37436 by Amman on 11/24/2020 -- END
					//commented by Ganesh for Defect 41560 on Date <15/April/2021>---->END
					//Added for Defect #37311 -- START
					util.formatData(sbQUOM,sQUOM);
					//Added for Defect #37311 -- END
					//Modified by Ganesh for Defect 41560 on Date <15/April/2021>---->START
					String strTempDry = util.getDryValueToDisplay(context, objectMap);
					util.formatData(sbDRY, strTempDry);
					//Modified by Ganesh for Defect 41560 on Date <15/April/2021>---->END
					util.formatData(sbFunctions, sFunctions);
					util.formatData(sbtrClassFied, strClassFied);
					util.formatData(sbIPClassfication, sIPClassfication);
				//}
				}
			}
			mpSubStanceResult.put(ConstantsUtil.SECURITY, sbtrClassFied.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sbIPClassfication.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.REV,sbRev.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.CAS,sbCAS.toString().trim());
			//SPEC: <13.10.2020>: Commented for the Release 18x5 -- START--
			//mpSubStanceResult.put(ConstantsUtil.SUBSTANCENAME,sSub);
			//mpSubStanceResult.put(ConstantsUtil.QUANTITYTYPE,sQTY);
			//SPEC: <13.10.2020>: Commented for the Release 18x5 -- END--
			
			//Modified for Defect #37436 by Amman on 11/19/2020 -- START
			//mpSubStanceResult.put(ConstantsUtil.IC,sbCont.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.IP,sbCont.toString().trim());
			//Modified for Defect #37436 by Amman on 11/19/2020 -- END
			
			mpSubStanceResult.put(ConstantsUtil.MAX,sbMAXWt.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.MIN,sbMInWt.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.UOM,sbQUOM.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sbDRY.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sbFunctions.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.ID, sbID.toString().trim());
			
			//Added for Defect #37436 by Amman on 11/19/2020 -- START
			mpSubStanceResult.put(ConstantsUtil.QSTARGET,sbQTS.toString().trim());
			mpSubStanceResult.put(ConstantsUtil.UF, sbUF.toString().trim());
			//Added for Defect #37436 by Amman on 11/19/2020 -- END
			//START :: gaikwad.tg
			mpSubStanceResult.put(ConstantsUtil.SEQ,sbFN.toString());
			//START :: gaikwad.tg
			mpSubStanceResult.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString().trim());//Added by Ajay for 22x.06 Req.9264

		}catch(Exception e){

			LOGGER.error("Error from ARMPBO:  getMaterialCompositionAndSubstance"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	//SPEC: 13 October 2021: Added for 18x.6.0.2 Defect #37214 by Bala-- START
	public Map updatePlantInfo(Context context, DomainObject doARMP) throws Exception {
	
		Map mPlantResultMap = new HashMap();
		StringList slBusSelect= new StringList();	 
		slBusSelect.add(ConstantsUtil.SELECT_NAME);			
		StringList slRelSelectStmts= new StringList();
		slRelSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
		slRelSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
		slRelSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED);
		slRelSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
	
		StringList slName = new StringList();
		StringList slAuthorizedToUse = new StringList();
		StringList slAuthorizedToProduce = new StringList();
		StringList slActivated = new StringList();
		StringList slAuthorizedToView = new StringList();
		MapList mlPlantList = doARMP.getRelatedObjects(context, 
				ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY,
				ConstantsUtil.SYMBL_ASTERISK, 
				slBusSelect, 
				slRelSelectStmts, 
				true,
				false,
				(short)1,
				ConstantsUtil.EMPTY_STRING, 
				ConstantsUtil.EMPTY_STRING,
				0);
		
		mlPlantList.sort(DomainConstants.SELECT_NAME, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
	    Iterator itrObjectList = mlPlantList.iterator();
		while(itrObjectList.hasNext()) 
		{
			mPlantResultMap = (Map) itrObjectList.next();
			slName.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_NAME));
			slAuthorizedToUse.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE));
			slAuthorizedToProduce.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE));
			slActivated.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED));
			slAuthorizedToView.add((String)mPlantResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW));	
		}
		mPlantResultMap = new HashMap();
		mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_NAME, slName);
		mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE, slAuthorizedToUse);
		mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE, slAuthorizedToProduce);
		mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED, slActivated);
		mPlantResultMap.put(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW, slAuthorizedToView);
		
		return mPlantResultMap;
	}
	//SPEC: 13 October 2021: Added for 18x.6.0.2 Defect #37214 by Bala-- END
}
