package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

import com.pg.us.specanywhere_enovia.utility.PDFView;

public interface EnoviaPDFService {
	public HashMap<String, Object> getPDFdata(Environment env, PDFView pdfView) throws Exception;
}
