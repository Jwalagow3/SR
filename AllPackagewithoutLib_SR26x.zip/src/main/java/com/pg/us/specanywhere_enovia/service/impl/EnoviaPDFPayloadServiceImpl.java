package com.pg.us.specanywhere_enovia.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.PDFBO;
import com.pg.us.specanywhere_enovia.service.EnoviaPDFPayloadService;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaPDFPayloadServiceImpl implements EnoviaPDFPayloadService {
	private static Logger LOGGER = Logger.getLogger(EnoviaMEPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	@Override
	public HashMap<String, Object> getPDFPayloaddata(Environment env, String sObjectName) {
		HashMap<String, Object> hmAttrib = new HashMap<String, Object>();
		Map<String,Object> mpData = new HashMap<String,Object>();
		String sView = ConstantsUtil.ALL;
		boolean bIsGendocView = false;
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		
		//User Profile
		StopWatch swUserType = new StopWatch();
		swUserType.start();
		SecurityService sct = new SecurityService();
		String sUserType = sct.getUserType();
		//swUserType.stop();
		BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
		PDFBO pdfBO = new PDFBO();
		MapList mlObjectList = new MapList();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try {
			StringList slObjectsSelect = new StringList();
			slObjectsSelect.add(DomainConstants.SELECT_ID);
			slObjectsSelect.add(DomainConstants.SELECT_REVISION);
			slObjectsSelect.add(DomainConstants.SELECT_TYPE);
			mlObjectList = DomainObject.findObjects
					(context, //MatrixContext
							DomainConstants.QUERY_WILDCARD, //typePattern
							sObjectName, //namePattern
							DomainConstants.QUERY_WILDCARD, //revPattern
							DomainConstants.QUERY_WILDCARD, //ownerPattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
							ConstantsUtilIRM.CURRENT_RELEASE, //whereExpression
							false, //expandType
							slObjectsSelect); //objectSelects
			Iterator<MapList> objectListItr = mlObjectList.iterator();
			String sId = DomainConstants.EMPTY_STRING;
			String sType = DomainConstants.EMPTY_STRING;
			String sRev = DomainConstants.EMPTY_STRING;
			while(objectListItr.hasNext())
			{
				Map<String, String> mpObject = (Map<String, String>)objectListItr.next();
				sId = mpObject.get(ConstantsUtil.ID);
				sType = util.mapType(mpObject.get(DomainConstants.SELECT_TYPE)).trim();//SPEC: Added by Ajay for Defect. no. 2642 
				//sType = mpObject.get(ConstantsUtil.TYPE);
				sRev = mpObject.get(ConstantsUtil.SELECT_REVISION);
			}
		if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
			sUserType = BObjutil.getUserView(context, sId);
		}
		swUserType.stop();
		LOGGER.info("PDF SERVICE USER TYPE ELAPSED TIME : "+swUserType.getTime());
		
		if(ConstantsUtil.PG_CM.equalsIgnoreCase(sUserType)) {
			sUserType = ConstantsUtilIRM.PDFCMVIEW;
		}
		else if(ConstantsUtil.PG_SP.equalsIgnoreCase(sUserType)) {
			sUserType = ConstantsUtilIRM.PDFSPVIEW;
		}
		else {
			sUserType = sUserType;
		}
		
		if(null==sUserType) {
			LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
			HashMap<String,String> errorMap = new HashMap<String,String>();
			String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
			errorMap.put(sError[0], sError[1]);
			hmAttrib.put(ConstantsUtil.ERROR, errorMap);
			context.close();
			return hmAttrib;
		}
			
		//Gendoc or PDF
		if(sType.equals(ConstantsUtil.tQUAL) || sType.equals(ConstantsUtil.tATS) || sType.equals(ConstantsUtil.tILST) || sType.equals(ConstantsUtil.tMI) || sType.equals(ConstantsUtil.tPI) || sType.equals(ConstantsUtil.tRMPI) || sType.equals(ConstantsUtil.tSPS) || sType.equals(ConstantsUtil.tIAPS) || sType.equals(ConstantsUtil.tLIS) || sType.equals(ConstantsUtil.tACS) || sType.equals(ConstantsUtil.tPROS) || sType.equals(ConstantsUtil.tSOP) || sType.equals(ConstantsUtil.tTM) || sType.equals(ConstantsUtilIRM.TIRM) || sType.equals("pgPKGProductReadiness") || sType.equals(ConstantsUtil.tART)) { //Modified by Ketan for Defect 6534
			bIsGendocView = true;
		}
		
		//Fetching 'Data' -- START
		//sections
		
		StopWatch swSections = new StopWatch();
		swSections.start();
		ArrayList<String> arrSections = new ArrayList<>();
		arrSections = pdfBO.getSections(context, sType, bIsGendocView);
		swSections.stop();
		LOGGER.info("PDF SERVICE SECTIONS ELAPSED TIME : "+swSections.getTime());
		
		boolean bIsFilterView = false; //Modified by Ketan for Defect no. 7498
		
		
		
	
		mpData.put(ConstantsUtilIRM.NAME, sObjectName);
		mpData.put(ConstantsUtilIRM.REV, sRev);
		mpData.put(ConstantsUtilIRM.SECTIONS, arrSections);
		mpData.put(ConstantsUtilIRM.ISFILTERVIEW, bIsFilterView);
		//Fetching 'Data' -- END
		
		hmAttrib.put(ConstantsUtilIRM.OBJECTTYPE, sType);
		hmAttrib.put(ConstantsUtilIRM.ROLE, sUserType);
		hmAttrib.put(ConstantsUtilIRM.DATA, mpData);
		hmAttrib.put(ConstantsUtilIRM.OBJECTID, sId);
		hmAttrib.put(ConstantsUtilIRM.VIEW, sView);
		hmAttrib.put(ConstantsUtilIRM.GENDOCVIEW, bIsGendocView);
		}catch(Exception e) {
			LOGGER.error("Unable to getPDFdata "+e);
		}
		context.close();
		return hmAttrib;
	}

}
