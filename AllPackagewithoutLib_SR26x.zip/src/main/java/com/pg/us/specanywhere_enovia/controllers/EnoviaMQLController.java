package com.pg.us.specanywhere_enovia.controllers;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pg.us.specanywhere_enovia.bo.SearchBO;
import com.pg.us.specanywhere_enovia.service.EnoviaAPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaAPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaARMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaASLService;
import com.pg.us.specanywhere_enovia.service.EnoviaBSFService;
import com.pg.us.specanywhere_enovia.service.EnoviaCDBService;
import com.pg.us.specanywhere_enovia.service.EnoviaCMService;
import com.pg.us.specanywhere_enovia.service.EnoviaCOPService;
import com.pg.us.specanywhere_enovia.service.EnoviaCUPService;
import com.pg.us.specanywhere_enovia.service.EnoviaCommonDocService;
import com.pg.us.specanywhere_enovia.service.EnoviaDPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaFABService;
import com.pg.us.specanywhere_enovia.service.EnoviaFOPService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPCategoriesService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaFormulaCardService;
import com.pg.us.specanywhere_enovia.service.EnoviaGenDocloadService;
import com.pg.us.specanywhere_enovia.service.EnoviaGetFileService;
import com.pg.us.specanywhere_enovia.service.EnoviaIMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaINGSTMTService;
import com.pg.us.specanywhere_enovia.service.EnoviaIPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaIPService;
import com.pg.us.specanywhere_enovia.service.EnoviaIRMSService;
import com.pg.us.specanywhere_enovia.service.EnoviaListVendorService;
import com.pg.us.specanywhere_enovia.service.EnoviaMCOPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMCPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMCUPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMEPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMIPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPAPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPSService;
import com.pg.us.specanywhere_enovia.service.EnoviaMRMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaOPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaPDFPayloadService;
import com.pg.us.specanywhere_enovia.service.EnoviaPDFService;
import com.pg.us.specanywhere_enovia.service.EnoviaPGContactService;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaPOAService;
import com.pg.us.specanywhere_enovia.service.EnoviaPQRService;
import com.pg.us.specanywhere_enovia.service.EnoviaPOAARTService;
import com.pg.us.specanywhere_enovia.service.EnoviaPSUBService;
import com.pg.us.specanywhere_enovia.service.EnoviaPackagingAssemblyPart;
import com.pg.us.specanywhere_enovia.service.EnoviaPriliminaryPayloadService;
import com.pg.us.specanywhere_enovia.service.EnoviaPriliminarydataloadService;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSBPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSEPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSWPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSearchService;
import com.pg.us.specanywhere_enovia.service.EnoviaSecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaSpecPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaTUPService;
import com.pg.us.specanywhere_enovia.service.EnoviaVendorSpecsService;
import com.pg.us.specanywhere_enovia.service.EnoviaWhereUsedService;
import com.pg.us.specanywhere_enovia.service.EnoviaListVendorService;
import com.pg.us.specanywhere_enovia.service.PromotionalItemPartService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaFormulaCardServiceImpl;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.PDFView;
import com.pg.us.specanywhere_enovia.service.EnoviaSISService; // Added by Govind for Req #35943
import com.pg.us.specanywhere_enovia.service.EnoviaSMLService;
import com.pg.us.specanywhere_enovia.service.EnoviaEMPService;//Added by Ganesh for Dev 18x.6 <5 Mar 2021>
import com.pg.us.specanywhere_enovia.service.EnoviaDSService;
import com.pg.us.specanywhere_enovia.service.EnoviaDSSearchService;
import com.pg.us.specanywhere_enovia.service.EnoviaDSMReportService;
import com.pg.us.specanywhere_enovia.service.EnoviaDSMReportValidationService;
import com.pg.us.specanywhere_enovia.service.EnoviaEBPService;



@RestController(value = "/enovia-api")
@RequestMapping(value = "/enovia-api")
@CrossOrigin(origins = "*")
public class EnoviaMQLController {
	private static Logger LOGGER = Logger.getLogger(EnoviaMQLController.class);

	@Autowired
	EnoviaSearchService search;

	@Autowired
	Environment env;

	@GetMapping("/")
	public String imHealthy() {
		return "{healthy:true}";
	}

	@GetMapping("/search/{searchId}")
	public ResponseEntity<String> getSearchResult(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		List<SearchBO> list = search.getSearchResult(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(list);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getSearchResult :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}


	@Autowired
	EnoviaFPPService fpp;
	//SPEC: Modified by Ajay for Req. no. 78405 START
	@GetMapping("/fpp/{searchId}")
	public ResponseEntity<String> getFPPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************FPP***************");
		String sComp=ConstantsUtilIRM.FPP;
		HashMap<String,Map<String, String>> map = fpp.getFPPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getFPPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Modified by Ajay for Req. no. 78405 END
	//Modified by Ajay for Req No. 125736 -- START
	@Autowired
	EnoviaCOPService cop;

	@GetMapping("/cop/{searchId}")
	public ResponseEntity<String> getCOPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************COP***************");
		String sComp=ConstantsUtilIRM.COP;
		HashMap<String, Map<String, String>> map = cop.getCOPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getCOPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Modified by Ajay for Req No. 125736 -- END
	//Modified by Ajay for Req No. 122489 -- START
	@Autowired
	EnoviaCUPService cup;

	@GetMapping("/cup/{searchId}")
	public ResponseEntity<String> getCUPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************CUP***************");
		String sComp=ConstantsUtilIRM.CUP;
		HashMap<String, Map<String, String>> map = cup.getCUPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getCUPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Modified by Ajay for Req No. 122489 -- END
	//SPEC: Modified by Ajay for Req. no. 21482 START
	@Autowired
	EnoviaRMPService rmp;

	@GetMapping("/rmp/{searchId}")
	public ResponseEntity<String> getRMPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************RMP***************");
		String sComp=ConstantsUtilIRM.RMP;
		HashMap<String, Map<String, String>> map = rmp.getRMPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getRMPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Modified by Ajay for Req. no. 21482 END

	@Autowired
	EnoviaPMPService pmp;

	@GetMapping("/pmp/{searchId}")
	public ResponseEntity<String> getPMPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************PMP***************");
		String sComp=ConstantsUtilIRM.PMP;
		HashMap<String, Map> map = pmp.getPMPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPMPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	//SPEC: Added by Ajay for Defect. no. 108025 START
	@Autowired
	EnoviaFOPService fop;

	@GetMapping("/fop/{searchId}")
	public ResponseEntity<String> getFOPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************FOP***************");
		String sComp=ConstantsUtilIRM.FOP;
		HashMap<String, Map<String, String>> map = fop.getFOPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getFOPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Ajay for Defect. no. 108025 END

	@Autowired
	EnoviaIPService ip;

	@GetMapping("/ip/{searchId}")
	public ResponseEntity<String> getIPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************IP***************");
		String sComp = ConstantsUtil.IP;
		HashMap<String, Map<String, String>> map = ip.getIPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getIPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}


	@Autowired
	EnoviaTUPService tup;

	@GetMapping("/tup/{searchId}")
	public ResponseEntity<String> getTUPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************TUP***************");
		String sComp = ConstantsUtilIRM.TUP;
		HashMap<String, Map<String, String>> map = tup.getTUPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getTUPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaGetFileService fileService;

	@GetMapping("/getFilePath/{searchId}")
	public ResponseEntity<String> getFilePath(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************FilePath***************");
		Map<String, List> map = fileService.getFilePath(searchString,env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getFilePath :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}


	@Autowired
	EnoviaSecurityService securityService;

	@GetMapping("/getSecurityClassification/{searchId}")
	public ResponseEntity<String> getSecurityClassification(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************Security***************");
		HashMap<String,Map<String, String>> map = securityService.getSecurityClassification(searchString,env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getSecurityClassification :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaAPPService app;

	@GetMapping("/app/{searchId}")
	public ResponseEntity<String> getAPPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************APP***************");
		String sComp=ConstantsUtilIRM.APP;
		HashMap<String, Map<String, String>> map = app.getAPPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getAPPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Modified by Ajay for Req. no. 23961 START
	@Autowired
	EnoviaPackagingAssemblyPart pap;
	@GetMapping("/pap/{searchId}")
	public ResponseEntity<String> getPAPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************PAP***************");
		String sComp=ConstantsUtilIRM.PAP;
		HashMap<String, Map<String, String>> map = pap.getPAPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPAPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Modified by Ajay for Req. no. 23961 END
	@Autowired
	EnoviaMPAPService mpap;
	@GetMapping("/mpap/{searchId}")
	public ResponseEntity<String> getMPAPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MPAP***************");
		String sComp=ConstantsUtilIRM.MPAP;
		HashMap<String, Map<String, String>> map = mpap.getMPAPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getMPAPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaMIPService mip;
	@GetMapping("/mip/{searchId}")
	public ResponseEntity<String> getMIPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MIP***************");
		String sComp=ConstantsUtilIRM.MIP;
		HashMap<String, Map<String, String>> map = mip.getMIPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getMIPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaIPPService ipp;
	@GetMapping("/ipp/{searchId}")
	public ResponseEntity<String> getIPPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************IPP***************");
		String sComp=ConstantsUtilIRM.IPP;
		HashMap<String, Map<String, String>> map = ipp.getIPPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getIPPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Modified by Ajay for Req No. 23973 -- START
	@Autowired
	EnoviaAPMPService apmp;
	@GetMapping("/apmp/{searchId}")
	public ResponseEntity<String> getAPMPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************APMP***************");
		String sComp = ConstantsUtilIRM.APMP;
		HashMap<String, Map<String, String>> map = apmp.getAPMPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getAPMPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Modified by Ajay for Req No. 23973 -- END

	@Autowired
	EnoviaMCOPService mcop;
	@GetMapping("/mcop/{searchId}")
	public ResponseEntity<String> getMCOPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MCOP***************");
		String sComp = ConstantsUtilIRM.MCOP;
		HashMap<String, Map<String, String>> map = mcop.getMCOPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getMCOPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}


	@Autowired
	EnoviaMCUPService mcup;
	@GetMapping("/mcup/{searchId}")
	public ResponseEntity<String> getMCUPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MCUP***************");
		String sComp = ConstantsUtilIRM.MCUP;
		HashMap<String, Map<String, String>> map = mcup.getMCUPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getMCUPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}


	@Autowired
	EnoviaCDBService cdb;
	@GetMapping("/cdb/{searchId}")
	public ResponseEntity<String> getCDBData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************CDB***************");
		HashMap<String, Map<String, String>> map = cdb.getCDBdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getCDBData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	@Autowired
	EnoviaASLService asl;
	@GetMapping("/asl/{searchId}")
	public ResponseEntity<String> getASLData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************ASL***************");
		HashMap<String, Map<String, String>> map = asl.getASLdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getASLData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Added by Ajay for Req No. 23975 -- START
	@Autowired
	PromotionalItemPartService pip;
	@GetMapping("/pip/{searchId}")
	public ResponseEntity<String> getPIPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************PIP***************");
		String sComp = ConstantsUtilIRM.PIP;
		HashMap<String, Map<String, String>> map = pip.getPIPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPIPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Added by Ajay for Req No. 23975 -- END
	//Added by Ajay for Req No. 23966 -- START
	@Autowired
	EnoviaOPPService opp;
	@GetMapping("/opp/{searchId}")
	public ResponseEntity<String> getOPPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************OPP***************");
		String sComp = ConstantsUtilIRM.OPP;
		HashMap<String, Map<String, String>> map = opp.getOPPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getOPPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Added by Ajay for Req No. 23966 -- END
	//SPEC: Modified by Ajay for Req. no. 23960 START
	@Autowired
	EnoviaFABService fab;
	@GetMapping("/fab/{searchId}")
	public ResponseEntity<String> getFABData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************FAB***************");
		String sComp=ConstantsUtilIRM.FAB;
		HashMap<String, Map<String, String>> map = fab.getFABdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getFABData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Modified by Ajay for Req. no. 23960 END
	@Autowired
	EnoviaIRMSService irms;
	@GetMapping("/irms/{searchId}")
	public ResponseEntity<String> getIRMSData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************IRMS***************");
		
		HashMap<String, Map<String, String>> map = irms.getIRMSdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getIRMSData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}


	@Autowired
	EnoviaMRMPService mrmp;
	@GetMapping("/mrmp/{searchId}")
	public ResponseEntity<String> getMRMPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MRMP***************");
		String sComp=ConstantsUtilIRM.MRMP;
		HashMap<String, Map<String, String>> map = mrmp.getMRMPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getMRMPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaMPPService mpp;
	@GetMapping("/mpp/{searchId}")
	public ResponseEntity<String> getMPPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MPP***************");
		String sComp = ConstantsUtilIRM.MPP;
		HashMap<String, Map<String, String>> map = mpp.getMPPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getMPPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaMPMPService mpmp;
	@GetMapping("/mpmp/{searchId}")
	public ResponseEntity<String> getMPMPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MPMP***************");
		String sComp=ConstantsUtilIRM.MPMP;
		HashMap<String, Map<String, String>> map = mpmp.getMPMPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getMPMPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	@Autowired
	EnoviaDPPService dpp;
	@GetMapping("/dpp/{searchId}")
	public ResponseEntity<String> getDPPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************DPP***************");
		String sComp = ConstantsUtilIRM.DPP;
		HashMap<String, Map<String, String>> map = dpp.getDPPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getDPPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaMEPService mep;
	@GetMapping("/mep/{searchId}")
	public ResponseEntity<String> getMEPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MEP***************");
		String sComp = ConstantsUtilIRM.MEP;
		HashMap<String, Map<String, String>> map = mep.getMEPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getMEPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaSEPService sep;
	@GetMapping("/sep/{searchId}")
	public ResponseEntity<String> getSEPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************SEP***************");
		HashMap<String, Map<String, String>> map = sep.getSEPdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getSEPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaVendorSpecsService venSpec;
	@GetMapping("/vendor/{searchId}/{view}")
	public ResponseEntity<String> getVendorSpecs(@PathVariable(value = "searchId") String searchString, @PathVariable(value = "view") String view)
			throws Exception {
		LOGGER.info("****************Vendor Specs***************");
		HashMap<String, Map<String, String>> map = venSpec.getVendorSpecs(searchString, view, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getVendorSpecs :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	//SPEC: Modified by Ajay for Req. no. 23970 START
	@Autowired
	EnoviaCommonDocService cdoc;
	@GetMapping("/cdoc/{searchId}/{sType}")
	public ResponseEntity<String> getDocData(@PathVariable(value = "searchId") String searchString ,@PathVariable(value = "sType") String sType)
			throws Exception {
		LOGGER.info("****************CDOC***************");
		String sComp = ConstantsUtilIRM.TCOMMONDOC;
		HashMap<String, Map<String, String>> map = cdoc.getDocdata(searchString, env, sType, sComp);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getDocData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Modified by Ajay for Req. no. 23970 END
	@Autowired
	EnoviaPOAService poa;
	@GetMapping("/poa/{searchId}")
	public ResponseEntity<String> getPOAData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************POA***************");
		String sComp = ConstantsUtilIRM.POA;
		HashMap<String, Map<String, String>> map = poa.getPOAdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getDocData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaIMPService imp;
	@GetMapping("/imp/{searchId}")
	public ResponseEntity<String> getIMPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************IMP***************");
		HashMap<String, Map<String, String>> map = imp.getIMPdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getDocData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}


	@Autowired
	EnoviaMCPService mcp;
	@GetMapping("/mcp/{searchId}")
	public ResponseEntity<String> getMCPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MCP***************");
		HashMap<String, Map<String, String>> map = mcp.getMCPdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getDocData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Modified by Ajay for Req No. 23964 -- START
	@Autowired
	EnoviaARMPService armp;
	@GetMapping("/armp/{searchId}")
	public ResponseEntity<String> getARMPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************ARMP***************");
		String sComp = ConstantsUtilIRM.ARMP;
		HashMap<String, Map<String, String>> map = armp.getARMPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getARMPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Modified by Ajay for Req No. 23964 -- END
	@Autowired
	EnoviaPSUBService psub;
	@GetMapping("/psub/{searchId}")
	public ResponseEntity<String> getPSUBData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************PSUB***************");
		HashMap<String, Map<String, String>> map = psub.getPSUBdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPSUBData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaMPSService mps;
	@GetMapping("/mps/{searchId}")
	public ResponseEntity<String> getMPSData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************MPS***************");
		HashMap<String,Map<String, String>> map = mps.getMPSdata(searchString,env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getMPSData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaFormulaCardService formulacard;
	@GetMapping("/formulacard/{searchId}")
	public ResponseEntity<String> getFormulaCardData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************FC***************");
		
		HashMap<String, Map<String, String>> map = formulacard.getFormulaCardData(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getFormulaCardData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaPOAARTService poaart;
	@GetMapping("/poaart/{searchId}")
	public ResponseEntity<String> getPOAARTData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************POAART***************");
		String sComp = ConstantsUtilIRM.ART;
		HashMap<String, Map<String, String>> map = poaart.getPOAARTData(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPOAARTData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	@Autowired
	EnoviaPQRService pqr;
	@GetMapping("/pqr/{searchId}")
	public ResponseEntity<String> getPQRData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************PQR***************");
		HashMap<String, Map<String, String>> map = pqr.getPQRData(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPQRData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Modified by Ajay for Req No. 23974 -- START
	@Autowired
	EnoviaSWPService swp;
	@GetMapping("/swp/{searchId}")
	public ResponseEntity<String> getSWPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************SWP***************");
		String sComp = ConstantsUtilIRM.SWP;
		HashMap<String, Map<String, String>> map = swp.getSWPdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getSWPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//Modified by Ajay for Req No. 23974 -- END
	@Autowired
	EnoviaBSFService bsf;
	@GetMapping("/bsf/{searchId}")
	public ResponseEntity<String> getBSFData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************BSF***************");
		HashMap<String, Map<String, String>> map = bsf.getBSFdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getBSFData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	//SPEC: <01.08.2021>: Added and modified by Govind for Req #35943
	@Autowired
	EnoviaSISService sis;
	@GetMapping("/sis/{searchId}")
	public ResponseEntity<String> getSISData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************SIS***************");
		HashMap<String, Map<String, String>> map = sis.getSISdata(searchString, env); 
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getSISData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}

	//SPEC: Added by Jwala for SR18x.6 Development
	@Autowired
	EnoviaINGSTMTService cl;
	@GetMapping("/cl/{searchId}")
	public ResponseEntity<String> getINGSTMTdata(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************COPY LIST***************");
		HashMap<String, Map<String, String>> map = cl.getINGSTMTdata(searchString, env); 
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getCLData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	@Autowired
	EnoviaSMLService sml;
	//SPEC: <26.02.2021>: Guna Added for Dev 18x.6   -- START
	@GetMapping("/sml/{searchId}")
	public ResponseEntity<String> getSMLData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************SML***************");
		HashMap<String, Map<String, String>> map = sml.getSMLdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getSMLdata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: <26.02.2021>: Guna Added for Dev 18x.6   -- END
	
	
	
	@Autowired
	EnoviaSBPService sbp;
	@GetMapping("/sbp/{searchId}")
	public ResponseEntity<String> getSBPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************Software Build***************");
		HashMap<String, Map<String, String>> map = sbp.getSBPdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getSoftwareBuildPartdata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	
	@Autowired
	EnoviaEMPService emp;
	@GetMapping("/emp/{searchId}")
	public ResponseEntity<String> getEMPData(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************EMP***************");
		HashMap<String, Map<String, String>> map = emp.getEMPdata(searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getEMPdata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: <05 March 20221> Ganesh Added for Dev 18x.6   -- END
	@Autowired
	EnoviaDSService ds;
	@GetMapping("/ds/{sKey}/{searchId}")
	public ResponseEntity<String> getDSData (@PathVariable(value = "sKey") String sKey, @PathVariable(value = "searchId") String searchString )
			throws Exception {		
	
		LOGGER.info("****************DS***************");
		HashMap<String, Map<String, String>> map = ds.getDSData (env, sKey, searchString);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getDSdata :"+e);
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	@Autowired
	EnoviaDSSearchService dssearch;
	@PostMapping("/dssearch/{searchId}")
	public ResponseEntity<String> getDSSearchData(@PathVariable(value = "searchId") String sType ,@RequestBody Map<String, Object> mName)
			throws Exception {		
	
		LOGGER.info("****************DS Search***************");
		HashMap<String, Map<String, String>> map = dssearch.getDSSearchData (env, sType, mName);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getDSSearchdata :"+e);
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	@Autowired
	EnoviaDSMReportService DSMReport;
	@GetMapping("/DSMReport/{sKey}/{searchId}")
	public ResponseEntity<String> getDSMReportData(@PathVariable(value = "sKey") String sKey ,@PathVariable(value = "searchId") String searchString)
			throws Exception {		
	//SPEC: Added by Ajay for Req. no. 2642 START
		LOGGER.info("****************DSM Report***************");
		HashMap<String, Map<String, String>> map = DSMReport.getDSMReportData (env, sKey, searchString);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getDSMReportdata :"+e);
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	@Autowired
	EnoviaDSMReportValidationService DSMReportValidation;
	@PostMapping("/DSMReportValidation")
	public ResponseEntity<String> getDSMReportValidationData(@RequestBody Map<String, Object> mCAValidationRequest)
			throws Exception {		
	
		LOGGER.info("****************DSM Report Validation***************");
		HashMap<String, Map<String, String>> map = DSMReportValidation.getDSMReportValidationData (env, mCAValidationRequest);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getDSMReportValidationData :"+e);
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Jwala for SR22x Development -- START
	@Autowired
	EnoviaCMService cm;
	@GetMapping("/cm/{searchId}")
	public ResponseEntity<String> getCMdata(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************CM***************");
		HashMap<String, Map<String, String>> map = cm.getCMdata(searchString, env); 
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getCMData :"+e);
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Jwala for SR22x Development -- END
	//SPEC: Added by Manikanta for SR22x_Dec Development -- START
	//SPEC: Added by Ajay for SR22x_Dec Development -- MODIFIED
	@Autowired
	EnoviaEBPService ebp;

	@GetMapping("/ebp/{searchId}")
	public ResponseEntity<String> getEBPData(@RequestParam(value = "plantName") String plantName ,@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************EMP***************");
		plantName = URLDecoder.decode(plantName,StandardCharsets.UTF_8);

		HashMap<String, Map<String, String>> map = ebp.getEBPdata(plantName, searchString, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getEBPdata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Manikanta for SR22x_Dec Development -- END
	
	//SPEC: Added by Jwala for SR22x_Dec Development -- START
	@Autowired
	EnoviaPGContactService userpgcontact;
	//Modified by Ketan for Req no. 6581
	@PostMapping("/ebp")
	public ResponseEntity<String> getPersondata(@RequestBody Map<String, String> mUserDetails)
			throws Exception {
		LOGGER.info("****************USER PG CONTACT***************");
		HashMap<String, Map<String, String>> map = userpgcontact.getPersondata(env, mUserDetails);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPersondata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Jwala for SR22x_Dec Development -- END
		
	//SPEC: Added by Ketan for Req. no. 5327 -- START
	@Autowired
	EnoviaPDFService pdf;
	@PostMapping("/pdf")
	public ResponseEntity<String> getPDFdata(@RequestBody PDFView pdfView)
			throws Exception {
		LOGGER.info("****************PDF SERVICE PENDING VIEW***************");
		HashMap<String, Object> map = pdf.getPDFdata(env, pdfView);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPDFdata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Ketan for Req. no. 5327 -- END
	
	//SPEC: Added by Ketan for Req. no. 7093 -- START
	@Autowired
	EnoviaWhereUsedService whereused;
	@GetMapping("/ebp/whereUsed/{objectid}")
	public ResponseEntity<String> getWhereUseddata(@PathVariable(value = "objectid") String sObjectID)
			throws Exception {
		LOGGER.info("****************WHERE USED***************");
		HashMap<String, Map<String, String>> map = whereused.getWhereUsedData(sObjectID, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getWhereUseddata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	
	//SPEC: Added by Ajay for Req. no. 8268 START
	@Autowired
	EnoviaListVendorService vendorList;
	@PostMapping("/vendorlist")
	public ResponseEntity<String> getVendorList (@RequestBody Map<String, Object> vendorDetails)
			throws Exception {
		LOGGER.info("****************VENDOR LIST***************");
		HashMap<String, Map<String, String>> map = vendorList.getVendorList (env, vendorDetails);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getVendorList :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Ajay for Req. no. 8268 END
	
	//SPEC: Added by Ajay for Req. no. 5228 START
	//SPEC: Modified by Ajay for Req. no. 78405 START
	@Autowired
	EnoviaFPPCategoriesService fppcategories;

	@GetMapping("/fpp/categories/{searchId}")
	public ResponseEntity<String> getFPPCategoriesdata(@PathVariable(value = "searchId") String searchString)
			throws Exception {
		LOGGER.info("****************FPP***************");
		String sComp=ConstantsUtilIRM.FPP;
		HashMap<String,Map<String, String>> map = fppcategories.getFPPCategoriesdata(searchString, sComp, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getFPPData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Modified by Ajay for Req. no. 78405 END
	//SPEC: Added by Ajay for Req. no. 5228 END
	
	//SPEC: Added by Ajay for Req. no. 21482 START
	@Autowired
	EnoviaSpecPartCompService partcomp;
	@GetMapping("/specpartcomp/{searchName}")
	public ResponseEntity<String> getSpecPartCompData(@PathVariable(value = "searchName") String sObjectName)
			throws Exception {
		LOGGER.info("****************SPEC PART COMPARISION***************");
		HashMap<String, HashMap<String, Map>> map = partcomp.getSpecPartCompData(sObjectName, env);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getRMPPartCompData :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Ajay for Req. no. 21482 END	
	@Autowired
	EnoviaPDFPayloadService pdfPayload;
	@GetMapping("/pdf/{searchName}")
	public ResponseEntity<String> getPDFdata(@PathVariable(value = "searchName") String sObjectName)
			throws Exception {
		LOGGER.info("****************PDF SERVICE PAYLOAD***************");
		HashMap<String, Object> map = pdfPayload.getPDFPayloaddata(env, sObjectName);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPDFdata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Ajay for Req. no. 2642 START
	//SPEC: Added by Ajay for Req. no. 11878 START
	@Autowired
	EnoviaGenDocloadService genDocPayload;
	@GetMapping("/pdf/gendoc/{searchName}")
	public ResponseEntity<String> getGenDocdata(@PathVariable(value = "searchName") String sObjectName)
			throws Exception {
		LOGGER.info("****************PDF SERVICE PAYLOAD***************");
		String map = genDocPayload.getGendocPayloaddata(env, sObjectName);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPDFdata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	//SPEC: Added by Ajay for Req. no. 11878 END
	
	@Autowired
	EnoviaPriliminaryPayloadService prilmnary;
	@GetMapping("pdf/prelim/{searchName}")
	public ResponseEntity<String> getPriliminaryPayloaddata(@PathVariable(value = "searchName") String sObjectName)
			throws Exception {
		LOGGER.info("****************Preliminary SERVICE PAYLOAD***************");
		Map<String, String> map = prilmnary.getPriliminaryPayLoaddata(env, sObjectName);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPriliminarydata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
	@Autowired
	EnoviaPriliminarydataloadService prilmnaryData;
	@GetMapping("/priliminarydata/{searchName}")
	public ResponseEntity<String> getPriliminarydata(@PathVariable(value = "searchName") String sObjectName)
			throws Exception {
		LOGGER.info("****************PRELIMINARY SERVICE***************");
		HashMap<String, Map<String, String>> map = prilmnaryData.getPriliminarydata(env, sObjectName);
		ObjectMapper mapperObj = new ObjectMapper();
		String json = null;
		try {
			json = mapperObj.writeValueAsString(map);
		} catch (JsonProcessingException e) {
			LOGGER.error("ERROR:  Exception in controller : getPriliminarydata :"+e);
			e.printStackTrace();
			throw e;
		}
		return ResponseEntity.ok(json);
	}
}
