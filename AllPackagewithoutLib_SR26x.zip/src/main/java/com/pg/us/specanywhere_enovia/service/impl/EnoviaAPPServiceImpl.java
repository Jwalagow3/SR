/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaAPPServiceImpl.java
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.APPBO;
import com.pg.us.specanywhere_enovia.bo.ARMPBO;
import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.SapBomAsFed;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaAPPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;
//import jakarta.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletRequest;

public class EnoviaAPPServiceImpl implements EnoviaAPPService {

	private static Logger LOGGER = Logger.getLogger(EnoviaAPPServiceImpl.class);

	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
	private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	//Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;

	@Value("${container.docs}")
	private String container ;

	@Value("${connection.string}")
	private String connectionString ;
	
	@Value("${azure.store}")
	private String azureStore ;

	@Autowired
	private EnoviaConnectionPool pool;

	@SuppressWarnings("static-access")
	public HashMap<String, Map<String, String>> getAPPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		
		//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- END
		try
		{
			
			//SPEC: <03-11-2021>: Guna Commented for  Defect 45181  -- START
			/*StopWatch swContext = new StopWatch();
			swContext.start();
			Context context = pool.checkOut();
			swContext.stop();*/
			//SPEC: <03-11-2021>: Guna Commented for  Defect 45181  -- END
			LOGGER.info("APP CONTEXT ELAPSED TIME : "+swContext.getTime());
			
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			//SPEC: <08-10-2021>: Guna Modified for Stress Testing Defect 44365  -- START
			if (UIUtil.isNotNullAndNotEmpty(sUserType))
			{
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			}

			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- START
				context.close();
				//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- END
				return hmAttrib;
			}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
				
			if(bSupplierView) {
				//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- START
				context.close();
				//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- END
				return hmAttrib;
			}
			
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			APPBO APPBO = new APPBO();
			DomainObject doAPP =  APPBO.getAppDO(context, objId);
			String strCurrent = doAPP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType) &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY)
			{
				
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- START
					context.close();
					//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END			
			else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
			Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mapWeightCharResult = new HashMap<String,String>();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			Map<String,String> mpSubStanceResult = new HashMap<String,String>();
			Map<String,String> mapCountryClearanceResult = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mapPartSpecification = new HashMap<String,String>(); 
			Map<String,String> mpDangerousGoodsClf = new HashMap<String,String>();
			Map<String,String> mpGlobalHarStandard = new HashMap<String,String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mpStability = new HashMap<String,String>();
			Map<String,String> mpPerformChar = new HashMap<String,String>();
			Map<String,String> mpMaterialProduced = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mapCertifications = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpProductPartStabilityDoc = new HashMap<String,String>();
			Map<String,String> mpMasterPartStabilityDoc = new HashMap<String,String>();
			Map<String,String> mpAlternates = new HashMap<String,String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			Map<String,String> mpPhyChemEngWareHouse = new HashMap<String,String>();
			Map<String,String> mpPhysicalChemicalGHCProp = new HashMap<String,String>();
			Map<String,String> mpSmartLabel = new HashMap<String,String>();
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			Map<String,String> mpCertificationvalidation = new HashMap<String,String>();
			Map<String,String> mpIngredientstatement = new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			FormulaPartBO formulationPartBO = new FormulaPartBO();
			RawMaterialPartBO RawBO = new RawMaterialPartBO();
			ARMPBO armpbo = new ARMPBO();
			DeviceProductPartBO DPPBO = new DeviceProductPartBO();
			CommonBusUtilBO commonBO = new CommonBusUtilBO();
			Map<String, StringList> BusinessObjectSelectableMap = APPBO.getAPPSelectableMap(context);
			Map<String, StringList> ChilsObjectSelectableMap = APPBO.getAPPRelatedObjsSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
			ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context,ConstantsUtil.USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);

			if(null==doAPP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- START
				context.close();
				//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- END
				return hmAttrib;
			}

			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			Map resultMaps = doAPP.getInfo(context, slContextSelects,APPBO.addMultiSelects());
			swAttributes.stop();
			LOGGER.info("APP GETINFO ELAPSED TIME : "+swAttributes.getTime());

			boolean bGendocView = false;
			boolean bAuthorizedtoUse = util.isAuthorizedtoUse(context,doAPP,resultMaps,strPDFView);

			boolean bAuthorizedtoProduce = util.isAuthorizedtoProduce(context,doAPP,resultMaps,strPDFView);

			if((bManufacturerView && bAuthorizedtoProduce)) {
				bGendocView = true;
				mpHeaderContent.put(ConstantsUtil.VIEW,ConstantsUtil.GENDOCVIEW);
			}

			String sClassifictaion = util.getClassification(resultMaps);
			//Common usage Variables 
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sIsCATIAType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION) : ConstantsUtil.EMPTY_STRING;
			String strCertificationvalidation = DomainConstants.EMPTY_STRING;//SPEC: 06/24/2022: Added by Ketan for Req no. 38897
			//Added By Jwala for CATIA APP Page
			
			
			if(sIsCATIAType.equalsIgnoreCase(ConstantsUtil.RANGE_PGAUTHORINGAPPLICATION_LPD)){
				EnoviaCATIAAPPServiceimpl catiaAPP = new EnoviaCATIAAPPServiceimpl();
				hmAttrib = catiaAPP.getCatiaAPPdata(context, objId,strPDFView,container,connectionString,azureStore);
				//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- START
				context.close();
				//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- END
				return hmAttrib;
			}

			ContextUtil.popContext(context);

			// Added by Jwala to send role info to Integration
			mpHeaderContent.put(ConstantsUtilIRM.CATIAAPP, ConstantsUtil.SYMBL_FALSE);
			// Added by Jwala to send role info to Integration
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			

			//SPEC: <12.02.2020>: Guna Modified for Gendoc view -- START
			if(bAllInfoView || bManufacturerView || bGendocView) {
				//SPEC: <12.02.2020>: Guna Modified for Gendoc view -- END
				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: Modified related to Defect#37301 1.0.2 Release - Amman -- START
				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				//mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)));
				//SPEC: Modified related to Defect#37301 1.0.2 Release - Amman -- END
				
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- START
				mpAttribResult.put(ConstantsUtilIRM.SMARTLABELREADY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SMARTLABENREADY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SMARTLABENREADY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.CLONETRANSFERRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.PRODUCTDOSECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtilIRM.REASONFORMANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release -- END
				
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- END
				
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <16.03.2021>: Guna Modified for Dev 18x.6   -- START
				if(bAllInfoView || bGendocView) {
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: <16.03.2021>: Guna Modified for Dev 18x.6   -- END
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <17.06.2022>: Satyam Added for Internal Defect  -- START
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <17.06.2022>: Satyam Added for Internal Defect  -- END
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
				
				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
				
				mpAttribResult.put(ConstantsUtil.PROD_VARIANNT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ONSHELFPRODDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, (validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.strIntendedMarket))));
				mpAttribResult.put(ConstantsUtil.PROD_SIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.UNIQUE_FORMULA_IDENTIFIER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPLACEDPRODUCTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID) : ConstantsUtil.EMPTY_STRING);
				if(bAllInfoView) {
					mpAttribResult.put(ConstantsUtil.BUSINESSAREA, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA)));
					mpAttribResult.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM,validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA)));
					mpAttribResult.put(ConstantsUtil.PRODUCTTECHNOLOGYPLATFORM, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM)));
					mpAttribResult.put(ConstantsUtil.PRODUCTTECHNOLOGYCHASSIS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS)));
					mpAttribResult.put(ConstantsUtil.FRANCHISE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE)));
				}
				//SPEC: <12.02.2020>: Guna Modified  for Gendoc view -- END
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED))));
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DOESTHEPRODUCTCONTAINBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY) : ConstantsUtil.EMPTY_STRING));
				String strProductFormName= validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REL_MARKETNAME));
				if(UIUtil.isNullOrEmpty(strProductFormName)){
					strProductFormName= validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REL_OWNINGPRODUCTLINE));
				}
				mpAttribResult.put(ConstantsUtil.PRODUCTFORM, strProductFormName);
				mpAttribResult.put(ConstantsUtil.AUTHORINGAPPLICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <24.02.2021>: Guna Added for Dev 18x.6   -- END
				//Added by Ketan for Req. no. 46464 - START
				if(!bSupplierView) {
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				}
				//Added by Ketan for Req. no. 46464 - END
				
				/**
				 * LOAD HEADER CONTENT SECTION
				 * */
				mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 

				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
				mpHeaderContent.put(ConstantsUtil.PDF_VIEW, util.getPdfViewtype(bAllInfoView, bGendocView, bSupplierView));
				
				if((strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) && bGendocView)) {
					mpHeaderContent.put(ConstantsUtil.PDF_VIEW,ConstantsUtil.GENDOC_VIEW);
				}

				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				mpHeaderContent.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderContent.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				String masterId = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID));
				if (UIUtil.isNotNullAndNotEmpty(masterId)) {
					DomainObject obj = new DomainObject(masterId);
					String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					obj.close(context);
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
					boolean showData = util.checkHasAccess(context, sUserType, masterId);
					if (!showData) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
				}
				mpHeaderContent.put(ConstantsUtil.MASTERPARTID, masterId);
				if(bGendocView){
					mpHeaderContent.remove(ConstantsUtil.STATE);
				}
				/**
				 * LOAD STORAGE AND LABEL SECTION
				 * */
				mapStorageAndLabelResult.put(ConstantsUtil.TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.PRODUCTMARKETEDASCHILDREN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.PGDOESCILDSAFEDESIGN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.PRODUCT_EXPOSED_CHILD, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.EVAPORATION_RATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.RESERVE_ACIDITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.RESERVE_ALKANITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.PROPERSHIPPINGNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_REL_SHIPPINGCLASSIF)));
				mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);								
				mapStorageAndLabelResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.UNSPECIFICATIONPACKAGINGMATERIALREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
				if(!bGendocView) {
				mapStorageAndLabelResult.put(ConstantsUtil.DANGEROUSGOODSCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
				}
				mapStorageAndLabelResult.put(ConstantsUtil.CUSTOMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.CONSUMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
				mapStorageAndLabelResult.put(ConstantsUtil.UNNUMBER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER) : ConstantsUtil.EMPTY_STRING);
				
				
				/**
				 * LOAD DANGEROUS GOODS CLASSIFICATION SECTION
				 * */
				
				mpDangerousGoodsClf=DPPBO.getDangerousProdcutValue(context,resultMaps);
				
				
				/**
				 * LOAD GLOBAL HARMONIZED STANDARD SECTION
				 * */
				
				mpGlobalHarStandard = DPPBO.getGHSProdcutValue(context,resultMaps);
				
				/**
				 * LOAD STABILITY SECTION
				 * */
				
				mpStability =util.getWeightProdcutValue(context,resultMaps);
				mpStability.put(ConstantsUtil.PRODUCTEXPDATEREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TOTALSHELFLIFEDAYS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TEMPERATUREGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.HUMIDITYGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.TRANSPORTHEATPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.BOUNDARYCONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mpStability.put(ConstantsUtil.STABILITYREPORTLINK, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE) : ConstantsUtil.EMPTY_STRING);
				
				/**
				 * LOAD NOTES SECTION
				 * */ 
				
				MasterCOPBO mcop = new MasterCOPBO();
				mpNotes=mcop.updateNotes(context, resultMaps);

				/**
				 * LOAD PERFORMANCE CHAR SECTION
				 * */ 
				Map paramMap = new HashMap();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				PerformanceCharcteristics perform = new PerformanceCharcteristics();
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				if(!mlPerformChar.isEmpty())
				{
					FinishedProductPartBO fppBO = new FinishedProductPartBO();
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
					swPerfChar.stop();
					LOGGER.info("APP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
				}

				/**
				 * LOAD WEIGHT CHARACTERISTICS SECTION
				 * */ 
				StopWatch swWeightCharacteristics = new StopWatch();
				swWeightCharacteristics.start();
				mapWeightCharResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mapWeightCharResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mapWeightCharResult.put(ConstantsUtil.NETWEIGHT,  util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT) : ConstantsUtil.EMPTY_STRING));
				mapWeightCharResult.put(ConstantsUtil.ROLLUPNETWEIGHTTOCOP,  util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ROLLUPNETWEIGHTTOCOP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ROLLUPNETWEIGHTTOCOP) : ConstantsUtil.EMPTY_STRING));
				
				mapWeightCharResult = util.filterMapList(mapWeightCharResult);
				swWeightCharacteristics.stop();
				LOGGER.info("APP GET swWeightCharacteristics ELAPSED TIME : "+swWeightCharacteristics.getTime());
				//SPEC: <23.02.2021>: Guna Added for Dev 18x.6   -- START
				/**
				 * chemicalAndPhysicalPropertiesWarehouseClassification
				 */
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISTHEPROPELLANTFLAMABLEORNONFLAMMBLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMMABLEORNONFLAMMABLE) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.PERCENTBYWEIGHTOFFLAMMABLEPROPELLANTINAEROCONTAINER,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PERCENT_OF_WEIGHT_FLAMMABLE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTLESSWBYVOLANDBYWATERMISCALCHOL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPCBBYVWMISCIBLEALOHOLS) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTLESSWBYVOLANDBYWATERETPLUSISO,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_ETHANOL) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISTHEBASEPDTNOPROPELLANTSUSTAINCOMBUSTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BASEPRODUCTSUSTAINCOMBUSTION) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISTHEBASEPRODUCTHAVEAFIREPOINT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTHAVEAFIREPOINT) : ConstantsUtil.EMPTY_STRING);	
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTCONTAINGTWANDLESSTHBYWTLNIGP,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_GAS_PROPELLANT) : ConstantsUtil.EMPTY_STRING);
				mpPhyChemEngWareHouse.put(ConstantsUtil.ISPDTCONTAINGTWANDLESSBYWTLIGP,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PRODUCT_CONTAIN_GAS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- START
				mpPhyChemEngWareHouse = util.filterMapList(mpPhyChemEngWareHouse);
				//SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- END
				/**
				 * chemicalAndPhysicalPropertiesGHCDGCClassification
				 */
				
				//SPEC: 07.11.2024: Jwala Added for Req 11640 Sprint 12 Release  -- START
				mpPhysicalChemicalGHCProp =APPBO.getMeltingpointDetails(context, resultMaps);
				//SPEC: 07.11.2024: Jwala Added for Req 11640 Sprint 12 Release  -- END
				
				if(bManufacturerView && !bGendocView){
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.SUSTAINCOMBUSTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUSTAINCOMBUSTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUSTAINCOMBUSTION) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.OXIDIZER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOXIDIZER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOXIDIZER) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PERCENBYWEIGHTEMULSIFIELDLIQUFIEDFLAMAGASPROPELLANT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBYWEIGHT_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBYWEIGHT_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CORROSIVETOMETALS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVETOMETALS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVETOMETALS) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CONTENTCONDUCTIVITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTENTCONDUCTIVITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTENTCONDUCTIVITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
			    }
				
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.SELDACCELERATINGDECOMPOSITIONTEMPERATURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSELFACCELDECOMTEMP_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSELFACCELDECOMTEMP_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.EVAPORATION_RATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.BURNRATEINMMPERSEC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBURNRATE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBURNRATE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.RESERVE_ACIDITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.RESERVE_ALKANITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.KINEMATICVISCOSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.AVAILABLEOXYGENCONTENTINPARCENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AVAILABLE_OXYGEN_CONTENT_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AVAILABLE_OXYGEN_CONTENT_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.BOILINGPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOILINGPOINT) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CLASEDCUPFLASHPOINT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINT_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.RELATIVEDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELATIVEDENSITYORSPECIFICGRAVITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
			
				if(bManufacturerView && !bGendocView){
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PERCENTBYVOLUMETHANOLANDPROPANOL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBYVOLUME_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBYVOLUME_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				}
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.VAPORPRESSURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE_INPUTVALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPORPRESSURE_INPUTVALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PHAVAILABILITY,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_AVAILABILITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_AVAILABILITY) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PROPERTIESORISITTHERMALLYUNSTABLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.HEADOFDECOMPOSITIONINKJPERGRAM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHEATOFDECOMPOSITION_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTHAVEANYSPELFREACTIVE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_SELF_REACTIVE_PROPERTIES) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISAFLAMMABLELIQUIDABSORBEDORCONTAINEDWITHINTHESOLID,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_LIQUID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_FLAMMABLE_LIQUID) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CONDUCTIVITYOFTHELIQUID,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONDUCTIVITYOFTHELIQUID_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONDUCTIVITYOFTHELIQUID_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISTHELIQUIDCORROSIVETOMETAL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_LIQUID_CORROSIVE_TO_METAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_LIQUID_CORROSIVE_TO_METAL) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CLOSEDCUPFLASHPOINTVALUE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINTVALUE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLOSEDCUPFLASHPOINTVALUE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESPRODUCTCONTAINANORGANICPEROXIDEASRAWMATERIAL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ORGANIC_PEROXIDE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ORGANIC_PEROXIDE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTHAVETHEPOTENTIALTOINCREASETHEBURNINGRATEORINTENSITYOFACOMBUSTIBLESUBSTANCE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPOTENTIALTOINCREASEBURNINGRATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPOTENTIALTOINCREASEBURNINGRATE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISTHEOXIDIZERHYDROGENPEROXIDELESSTHANEIGHTPERSONT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERHYDROGENPEROXIDE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISTHEOXIDIZERSODIUMPERCARBONATELESSTHENSIXTYPERCENT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_OXIDIZERSODIUMPERCARBONATE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTCONTAINANOXIDIZERASRAWMATERIAL,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTOXIDIZER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTOXIDIZER) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DOESTHEPRODUCTSUSTAINCOMBUSTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTSUSTAINCOMBUSTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTSUSTAINCOMBUSTION) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.BOLINGPOINTVALUE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BOILINGPOINTVALUE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_BOILINGPOINTVALUE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CONDUCTIVITYOFTHECONTENTSINTHEAEROSOLCAN,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOL_CONDUCTIVITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.TECHNICALBASISFORTHECORROSIVETOMETALSDETERMINATIONPROVIDED,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_TECHNICAL_CTM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_TECHNICAL_CTM) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ARETHECONTENTSOFTHEAEROSOLCANCORROSIVETOMETALS,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAEROSOLCANCORROSIVETOMETALS) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PHDILUTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_DILUTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_PH_DILUTION) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- START
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.VAPORDENSITY,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPOUR_DENSITY_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_VAPOUR_DENSITY_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- END
				if(bAllInfoView || bManufacturerView || bGendocView) {
					mpPhysicalChemicalGHCProp.put(ConstantsUtilIRM.DOESTHEFORMULACONTAINWATER,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISTHELIQUIDANAQEOUSSOLUTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISTHELIQUIDANAQEOUSSOLUTION) : ConstantsUtil.EMPTY_STRING);
				}
				
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.FOAMFLAMMBILITYTESTFLAMEDUTIONINSEC,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEDURATION_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEDURATION_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.FOAMFLAMMABILITYTESTFLAMEHEIGHT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEHEIGHT_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFLAMEHEIGHT_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ENCLOSEDSPACEIGNITIONTIMEEQUIALENT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENCLOSEDSPACEIGNITION_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENCLOSEDSPACEIGNITION_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.IGNITIONDISTANCEINCM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIGNITIONDISTANCE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIGNITIONDISTANCE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ISAEROSOLTESTDATANEEDED,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_IS_AEROSOLTYPE_TEST) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.AEROSOLTYPE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOLTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_AEROSOLTYPE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.GAUGEPRESSUREINKPA,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGAUGEPRESSURE_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.CANCONSTRUCTION,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CAN_CONSTRUCTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CAN_CONSTRUCTION) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.HEATOFCOMBUSTIONONKJ,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_HEAT_OF_COMBUSTION_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				
				
				//SPEC: 07.04.2022: Jwala Added for Defect 20500  -- START
				//mpPhysicalChemicalGHCProp.put(ConstantsUtil.ODOUR,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR) : ConstantsUtil.EMPTY_STRING);
				String strODOUR = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_ODOUR));
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.ODOUR,strODOUR);
				//SPEC: 07.04.2022: Jwala Added for Defect 20500  -- END
				
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.COLORINTENSITY,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_COLOR_INTENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_COLOR_INTENSITY) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.COLOR,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOLOR_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOLOR_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGIPHDATAAVAILABLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPHDATAAVAILABLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPHDATAAVAILABLE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGPHMIN,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMIN_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMIN_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGPHMAX,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMAX_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHMAX_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGRESERVEALKALINITYUOM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYUOM) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.PGRESERVEALKALINITYTITRATIONENDPOINT,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYTITRATIONENDPOINT_INPUT_VALUE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEALKALINITYTITRATIONENDPOINT_INPUT_VALUE) : ConstantsUtil.EMPTY_STRING);
				mpPhysicalChemicalGHCProp.put(ConstantsUtil.DYNAMICVISCOSITY,((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE)))?((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGKINEMATICVISCOSITY_INPUT_VALUE)).concat(ConstantsUtilIRM.SPACE_C) : ConstantsUtil.EMPTY_STRING));//Modified By Ajay for the Defect 19156
				
				mpPhysicalChemicalGHCProp = util.filterMapList(mpPhysicalChemicalGHCProp);

				/**
				 * SMART LABEL SECTION
				 * */ 
				StopWatch swSmartLabel = new StopWatch();
				swSmartLabel.start();
				mpSmartLabel =APPBO.getConnectedSmartLabelForParts(context, objId);
				swSmartLabel.stop();
			
				/**
				 * LOAD MATERIALS PRODUCED SECTION
				 * */ 
				StopWatch swMaterial = new StopWatch();
				swMaterial.start();
				mpMaterialProduced = APPBO.getMaterialProduced(context,sContextObjectId);
				if(bManufacturerView) {
					mpMaterialProduced=util.filterPhase(mpMaterialProduced);
				}
				mpMaterialProduced = util.filterMapList(mpMaterialProduced);
				
				swMaterial.stop();
				LOGGER.info("APP MATERIALS ELAPSED TIME : "+swMaterial.getTime());
				
				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=util.getRelatedAts(context, doAPP);
				
				mpRelatedATS=util.filterMapList(mpRelatedATS);
				if(!mpRelatedATS.isEmpty()){
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
				}

				if(bManufacturerView) {
					mpRelatedATS=util.filterPhase(mpRelatedATS);
				}

				swAts.stop();
				LOGGER.info("APP ATS ELAPSED TIME : "+swAts.getTime());
				
				/**
				 * LOAD PART SPECIFICATION SECTION
				 * */ 
				mapPartSpecification = util.updatePartSpec(context,resultMaps);
				
				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
				swReference.stop();
				LOGGER.info("APP Reference ELAPSED TIME : "+swReference.getTime());
				
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- START
				if(bAllInfoView){
					/**
					 * LOAD GPSASSESSMENTS SECTION
					 * */
					StopWatch swgps= new StopWatch();
					swgps.start();
					mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
					mpGPSAssessments = util.filterMapList(mpGPSAssessments);
					swgps.stop();
					LOGGER.info("APP GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
				}
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- END
				
				/**
				 * LOAD CERTIFICATIONVALIDATION SECTION
				 * */
				StopWatch swCerVali= new StopWatch();
				swCerVali.start();
				
				MapList mlCertValidation = util.getConnectedRawMaterialfromPart(context,sContextObjectId);
				mpCertificationvalidation = util.getCertValidationMap(context, resultMaps, mlCertValidation);
				mpCertificationvalidation = util.filterMapList(mpCertificationvalidation);
				//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- START
				strCertificationvalidation = validator.getStringEquivalentForStringList(mpCertificationvalidation.get(ConstantsUtil.SELECT_NAME));
				strCertificationvalidation = strCertificationvalidation.substring(0, strCertificationvalidation.length() -1);
				//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- END
				
				swCerVali.stop();
				LOGGER.info("APP CERTIFICATIONVALIDATION ELAPSED TIME : "+swCerVali.getTime());
				
				/**
				 * LOAD INGREDIENT STATEMENT SECTION
				 * */
				//SPEC: <16.03.2021>: Guna Modified for Dev 18x.6   -- START
				if(bAllInfoView){
				StopWatch swIngredient = new StopWatch();
				swIngredient.start();
				
				mpIngredientstatement = DPPBO.getIngredientstatements(context, sContextObjectId);
				mpIngredientstatement = util.filterMapList(mpIngredientstatement);
				
				swIngredient.stop();
				LOGGER.info("APP INGREDIENT STATEMENT TIME : "+swIngredient.getTime());
				}
				
				if(bAllInfoView || bManufacturerView || bGendocView) {	
					//SPEC: <12.02.2020>: Guna Modified for Gendoc view -- END
					/**
					 * MASTER SPECIFICATION
					 * */
					StopWatch swmpMasterSpecs = new StopWatch();
					swmpMasterSpecs.start();
					mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
					mpMasterSpecs = util.filterMapList(mpMasterSpecs);
					swmpMasterSpecs.stop();
					LOGGER.info("APP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());

				}

			}

			if(bManufacturerView) {
				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PROD_DENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			}
			if(bGendocView){
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PROD_SIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_DSM_PRODUCTSIZE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				
			}
			
			if(bAllInfoView) {
				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.WAREHOUSEPALLETSTAKMAXGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PROD_DENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ENTRYBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ATS_NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_NAME)))?(String)resultMaps.get(ConstantsUtil.ATL_NAME) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ATS_TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TYPE)))?(String)resultMaps.get(ConstantsUtil.ATL_TYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ATS_TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TITLE)))?(String)resultMaps.get(ConstantsUtil.ATL_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ATS_STAGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_STAGE)))?(String)resultMaps.get(ConstantsUtil.ATL_STAGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.FORMULATIONTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
				
			}
			if(bAllInfoView || bGendocView || bManufacturerView) {
				/**
				 * LOAD ORGANIZATION DATA SECTION
				 * */
				
				if(bAllInfoView){
					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {

						if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} 
						else 
						{
							mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
					}

					if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {

						if (resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
						{
							mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
						} else 
						{
							mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
						}
					}
					//SPEC: <08-10-2021>: Guna Modified for Stress Testing Defect 44365  -- END

					mpOrganization = util.filterMapList(mpOrganization);
				}
				/**
				 * LOAD LIFECYCLE SECTION
				 * */
				//SPEC: <12.02.2020>: Guna Modified  for Gendoc view -- START
				if(bAllInfoView){
					String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
					String[] changeargs={objId,sPhysicalId};
					StopWatch swLifecycle = new StopWatch();
					swLifecycle.start();
					mpLifeCycleApproval = util.getCOName(context, changeargs);
					swLifecycle.stop();
					LOGGER.info("APP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				}
				if(bAllInfoView || bGendocView) {
				/**
				 * LOAD SUBSTANCES SECTION
				 * */
				mpSubStanceResult = RawBO.getMaterialCompositionAndSubstance(context, resultMaps);
				mpSubStanceResult =util.verifyOwnership(context,mpSubStanceResult);
				mpSubStanceResult = util.filterMapList(mpSubStanceResult);
				}
				//SPEC: <16.03.2021>: Guna Modified for Dev 18x.6   -- END
				
				/**
				 * LOAD PLANTS SECTION
				 * */
				//SPEC: <12.02.2020>: Guna Modified  for Gendoc view -- START
				if(bAllInfoView){
					mpPlantResult=util.updatePlantInfo(resultMaps);
					mpPlantResult = util.filterMapList(mpPlantResult);
				}
				//SPEC: <12.02.2020>: Guna Modified  for Gendoc view -- END

				
				/**
				 * LOAD CERTIFICATIONS SECTION
				 * */
				
				
				mapCertifications=APPBO.getCertificationClaims(context,objId);
				

				/**
				 * LOAD OWNERSHIP SECTION
				 * */
				if(bAllInfoView){
					mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
					mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
					mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				}
				if(bAllInfoView || bGendocView) {
				/**
				 * LOAD SAP BOM SECTION
				 * */
				
				StopWatch swSapBomAsFed = new StopWatch();
				swSapBomAsFed.start();
				CalculateBOM clBom = new CalculateBOM();
	           // mpSapBomAsFedcResult = formulationPartBO.getSapBOMasFed(context,sContextObjectId);
	            SapBomAsFed sapBom = new SapBomAsFed();
	            mpSapBomAsFedcResult = sapBom.getSapBOMasFed(context,sContextObjectId);
	    		//SPEC: <25.02.2021>: Guna Added for Dev 18x.6   -- START
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZED);
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOUSE);
				mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOPRODUCE);
				//SPEC: <25.02.2021>: Guna Added for Dev 18x.6   -- END
				mpSapBomAsFedcResult = util.filterMapList(mpSapBomAsFedcResult);
				swSapBomAsFed.stop();
				LOGGER.info("APP GET SapBomAsFed ELAPSED TIME : "+swSapBomAsFed.getTime());
				}
				//SPEC: <16.03.2021>: Guna Modified for Dev 18x.6   -- END
				
				/**
				 * LOAD MARKET CLEARANCE
				 * */
				StopWatch swcountry = new StopWatch();
				swcountry.start();
				
				mapCountryClearanceResult = APPBO.getCountryClearance(context,sContextObjectId);
				mapCountryClearanceResult = util.filterMapList(mapCountryClearanceResult);
				swcountry.stop();
				LOGGER.info("APP MARKET CLEARANCE TIME : "+swcountry.getTime());
				
				/**
				 * MASTER PART STABILITY DOC SECTION
				 */
				mpMasterPartStabilityDoc = formulationPartBO.getMasterPartStabilityDoc(context,resultMaps);
				
				
				/**
				 * PRODUCT PART STABILITY DOC SECTION
				 */
				mpProductPartStabilityDoc = formulationPartBO.getProductPartStabilityDoc(context,resultMaps);
				
				/**
				 * ALTERNATES
				 * */
				
				mpAlternates = commonBO.getAlternates(context, sContextObjectId);
				//SPEC: Modified for Defect#37664 1.0.2 Release - Jwala -- END
				
				if(bSupplierView || bManufacturerView) {
					mpAlternates=util.filterPhase(mpAlternates);
				}
				mpAlternates = util.filterMapList(mpAlternates);
				
				
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- START
				if(bAllInfoView){

					/**
					 * LOAD SECURITY SECTION
					 * */
					StopWatch swSecurity = new StopWatch();
					CommonBusUtilBO bo = new CommonBusUtilBO();
					swSecurity.start();
					mpSecurity =bo.updateSecurity(context,resultMaps);
					mpSecurity = util.filterMapList(mpSecurity);
					swSecurity.stop();
					LOGGER.info("APP  Security ELAPSED TIME : "+swSecurity.getTime());
					
					/**
					 * LOAD IP CLASSES SECTION
					 */
					//IP Class

					StringList slIpSelects = new StringList();
					slIpSelects.add(ConstantsUtil.SELECT_NAME);
					slIpSelects.add(ConstantsUtil.SELECT_ID);
					slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
					slIpSelects.add(ConstantsUtil.SELECT_TYPE);
					slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
					CommonBusUtilBO commonBo = new CommonBusUtilBO();
					mpIPClass =commonBo.getIpClass(context, doAPP, slIpSelects);
				}
				//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- END
				/**
				 * FILES SECTION
				 */
				
				if(bAllInfoView){

					String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
					String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
					String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
					String FileSize = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));

					StringBuilder sbFileSize = new StringBuilder();
					if(!FileSize.isEmpty()) {
						String[] strFileSize=FileSize.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						for (int i = 0; i < strFileSize.length; i++) {
							String strEachFileSize = strFileSize[i];
							double dFileSize = Double.parseDouble(strEachFileSize);
							dFileSize = dFileSize/1024;
							strEachFileSize=Double.toString(dFileSize).format("%.2f", dFileSize);
							sbFileSize.append(strEachFileSize).append(" KB").append(ConstantsUtil.SYMBL_PIPE);
						}
					}

					mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
					mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
					mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
					mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());
				}
				
			}
			
			/**
			 * LOAD BOM SECTION
			 * 
			 *if the user is CM and Plant AuthoriseToUse true he should not have access to BOM - 33221*/
			
			if (bGendocView || bAllInfoView ){
				StopWatch swBom = new StopWatch();
				swBom.start();
				
				MapList mapList = util.getExpandedBOM(context, doAPP, ConstantsUtil.RELATIONSHIP_EBOM, 
						ConstantsUtil.TYPE_PGPHASE, slChildBusSelects, slChildRelSelects, ConstantsUtil.SELECT_NAME+"=~~PCT*", "PCT");
				
				if(bManufacturerView) {
					mapList=util.filterPhase(mapList);
				}
				
				if(mapList.size()!=0){
					mpEBOMResult =	APPBO.parseMaplist(context,mapList, bGendocView);
				}
				if(!sIsCATIAType.equalsIgnoreCase(ConstantsUtil.RANGE_PGAUTHORINGAPPLICATION_LPD)){
					mpEBOMResult.remove(ConstantsUtil.LAYERNAME);
				}
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
				
				swBom.stop();
				LOGGER.info("APP BOM ELAPSED TIME : "+swBom.getTime());
			}
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			if(bAllInfoView || bManufacturerView || bGendocView){
				
				hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
				hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			}
						
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATAOBJECT, mapStorageAndLabelResult);
			hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mapWeightCharResult);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mapPartSpecification);
			hmAttrib.put(ConstantsUtil.DANGEROUSGOODCLASSIFICATION, mpDangerousGoodsClf);
			hmAttrib.put(ConstantsUtil.GLABALHARMONIZEDSTANDARD, mpGlobalHarStandard);
			hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			hmAttrib.put(ConstantsUtil.STABILITYRESULTS, mpStability);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			hmAttrib.put(ConstantsUtil.MATERIALPRODUCED, mpMaterialProduced);
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpSubStanceResult);
			hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.MARKETOFCLEARANCE, mapCountryClearanceResult);
			
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
			hmAttrib.put(ConstantsUtil.CERTIFICATIONS, mapCertifications);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);

			//SPEC: <10.09.2020>: Added for req 18x.5 ## -- START
			hmAttrib.put(ConstantsUtil.MASTERPARTSTABILITYDOC, mpMasterPartStabilityDoc);
			hmAttrib.put(ConstantsUtil.PRODUCTPARTSTABILITYDOC, mpProductPartStabilityDoc);
			hmAttrib.put(ConstantsUtil.ALTERNATES, mpAlternates);
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			hmAttrib.put(ConstantsUtil.CHEMICALANDPHYSLEGACYWAREHOUSEPROP, mpPhyChemEngWareHouse);
			hmAttrib.put(ConstantsUtil.CHEMICALANDPHYSLEGACYGHDCPROP, mpPhysicalChemicalGHCProp);
			hmAttrib.put(ConstantsUtil.SMARTLABEL, mpSmartLabel);
			//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- START
			if(bAllInfoView){
				hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- END
			
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- START
			if(mpCertificationvalidation.size()!=1 && !(strCertificationvalidation.equalsIgnoreCase(mpHeaderContent.get(DomainConstants.SELECT_NAME)))) {
				hmAttrib.put(ConstantsUtilIRM.CERTIFICATIONVALIDATION, mpCertificationvalidation);
			}
			//SPEC: 06/24/2022: Added by Ketan for Req no. 38897 -- END
			hmAttrib.put(ConstantsUtilIRM.INGREDIENTSTATEMENT, mpIngredientstatement);
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			//SPEC: <25.02.2021>: Guna Added for Dev 18x.6   -- END

			pool.checkIn(context);
			sp.stop();
			LOGGER.info("APP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "APP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		} catch (IOException e) {
			LOGGER.error("Unable to getFOPdata IOException"+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getFOPdata MatrixException"+e);
		}
		//LOGGER.info("APP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- START
		context.close();
		//SPEC: <03-11-2021>: Guna Added for  Defect 45181  -- END
		return hmAttrib;
	}

}
