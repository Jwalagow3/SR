/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaPOAServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaPOAService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import com.pg.us.specanywhere_enovia.bo.POAARTBO;
import com.pg.us.specanywhere_enovia.bo.PQRBO;

import matrix.db.Context;
import matrix.util.StringList;
import com.pg.us.specanywhere_enovia.bo.FormulaCardBO; // Added for by Govind for Defect #38143 

public class EnoviaPOAServiceImpl implements EnoviaPOAService
{

	private static Logger LOGGER = Logger.getLogger(EnoviaPOAServiceImpl.class);

	BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@Override
	public HashMap<String, Map<String, String>> getPOAdata(String objId, String sComp, Environment env)
			throws Exception 
	{

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("POA SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());


		CommonDocBO cdoc = new CommonDocBO();
		POAARTBO poaBO = new POAARTBO();
		Map resultMapIPMS=new HashMap();
		try 
		{
			/**
			 * User Profile Section
			 * */
			SecurityService sct = new SecurityService();
			String sUserType = BbUtil.getUserType();
			//SPEC: Release SR18x.6.0.1 - Added by Manikanta on June 17, 2021 for Defect #43415 -- START
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BbUtil.getUserView(context, objId);
			}
			//SPEC: Release SR18x.6.0.1 - Added by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bInternal = false;
			boolean bExternal = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bExternal = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bExternal = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bInternal = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bInternal = true;
						break;

					case ConstantsUtil.PG_CM:
						bExternal = true;
						break;

					case ConstantsUtil.PG_SP:
						bExternal = true;
						break;
					default:
						bInternal = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
				
			DomainObject doPOA = poaBO.getPoaartDO(context, objId);
			String strCurrent = doPOA.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START

			if(UIUtil.isNotNullAndNotEmpty(sUserType) && sComp!=ConstantsUtilIRM.STATE_PRILIMNARY)
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;

				}
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {

					HashMap<String, String> errorMap = new HashMap<String, String>();
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END

			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpPartSpecResult = new HashMap<String,String>();
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpOrganization = new HashMap<String, String>();
			Map<String,String> mpMarketsApproved = new HashMap<String, String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String, String>();
			Map<String,String> mpFiles = new HashMap<String, String>();
			//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 02/03/2021 -- START
			Map<String,String> mpPartsAssociationResult = new HashMap<String,String>();
			//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 02/03/2021 -- END
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();

			BusObjectAttribUtil util = new BusObjectAttribUtil();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			Map<String, StringList> BusinessObjectSelectableMap = cdoc.getDefaultPartSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			//SPEC: Release SR18x.6.0 - Modified for RTAPOA  by Dominic on Date 02/03/2021 -- START
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKINGLEVEL);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ARTWORKUSAGE);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ARTWORKBASIS);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_FPCCODE);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_OLDIPMS);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRINTER);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ADDDESCRIPTION);
			slContextSelects.add(ConstantsUtilIRM.SELECT_REL_SUPPLIERPOANAME);
			slContextSelects.add(ConstantsUtilIRM.SELECT_REL_PRINTINGPROCESS);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CUSTOMIPMS);
			slContextSelects.add(ConstantsUtilIRM.SELECT_REL_CASETYPE);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARTWORKLANGUAGE);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_POACOMMENTST);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ACTUAL_RELEASE_DATE);
			slContextSelects.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
			DomainObject dobCdoc = new DomainObject(objId);
			StopWatch swInfo = new StopWatch();
			swInfo.start();
			//Map resultMaps = dobCdoc.getInfo(context, slContextSelects);
			Map resultMaps = dobCdoc.getInfo(context, slContextSelects,cdoc.addMultiList());
			String strType=(String)BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
			String strCustomIPMS=(String) resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CUSTOMIPMS);
			String strIPMS=(String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ATTRIBUTE_IPMS);
			String strLanguages=(String) poaBO.getPOALanguages(context,dobCdoc);
			String strSecondPrinter=(String) poaBO.getPOASecondaryPrinterData(context,strCustomIPMS,strIPMS);
			String strPrinter=(String) poaBO.getPOAPrinterData(context,strCustomIPMS,strIPMS);
			String strPackagingMaterialType=(String) poaBO.getPackagingMaterialType(context,objId);
			String strPrintingProcess=(String) poaBO.getPrintingProcessForPOA(context,objId);
			String strCaseCount=ConstantsUtil.EMPTY_STRING;
			String strIPMSId=(String) poaBO.getPOAIPMS(context,strIPMS);
			if(UIUtil.isNotNullAndNotEmpty(strIPMSId)){
				DomainObject domPackingMaterial = DomainObject.newInstance(context);
				domPackingMaterial.setId(strIPMSId);
				slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
				slContextSelects.add(ConstantsUtil.SELECT_MODIFIED);
				StringList slMultiSelects = new StringList ();
				slMultiSelects.add(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
				resultMapIPMS = domPackingMaterial.getInfo(context, slContextSelects,slMultiSelects);
			}
			strCaseCount = (String)poaBO.getCaseCountValue(context,objId);
			swInfo.stop();
			LOGGER.info("POA SERVICE GETINFO ELAPSED TIME : "+swInfo.getTime());


			/**
			 * LOAD HEADER CONTENT SECTION
			 * */
			// Added by Jwala to send role info to Integration
			mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			// Added by Jwala to send role info to Integration

			mpHeaderContent.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.NOTAPPICABLE);//Modified by Ketan for Req no. 1137
			mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.effectvityDateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			String sClassification = util.getClassification(resultMaps);
			mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, (sClassification));
			
			
			if(strType.equals(ConstantsUtilIRM.ARTORPOA))
			{
				String sCurrent = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ATL_STATE));
				String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ATL_NAME));
				String sHasATS =BbUtil.checkIsATSAttribute(sName,sCurrent);
				mpHeaderContent.put(ConstantsUtil.HASATS, sHasATS);
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			}
			String sGendoc =util.getGenDocFile(context,dobCdoc);
			mpHeaderContent.put(ConstantsUtilIRM.GENDOC, sGendoc);

			//Organizations
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME))));
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME))));
			mpOrganization = util.filterMapList(mpOrganization);

			//ATTRIBUTE SECTION
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			mpAttribResult.put(ConstantsUtil.ID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID))));
			String sDocType = util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE)));
			mpAttribResult.put(ConstantsUtil.TYPE, sDocType);

			mpAttribResult.put(ConstantsUtil.NAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME))));
			String user = (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_OWNER)));
			String owner = PersonUtil.getFullName(context,user);
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			StopWatch swAts = new StopWatch();
			swAts.start();
			mpRelatedATS=util.getRelatedAts(context, dobCdoc);
			mpRelatedATS=util.filterMapList(mpRelatedATS);
			mpPartsAssociationResult=poaBO.getPartsAssociated(context,dobCdoc);
			if(strType.equals(ConstantsUtilIRM.ARTORPOA))
			{
				mpAttribResult.put(ConstantsUtil.OWNER, user);
				mpAttribResult.put(ConstantsUtil.DISPLAY_TYPE, "ART");
				mpAttribResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER,  util.getLastUpdatedUser(context, objId));
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGPLISEGMENT_NAME))));
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE))));
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE))));
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, validator.DateFormatterParse((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))));
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, validator.DateFormatter((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))));
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE))));
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION))));
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT))));
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE))));
				//Added by Ketan for Req. no. 46464 -- START
				if(!sUserType.equalsIgnoreCase(ConstantsUtil.SUPPLIER)) {
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				}
				//Added by Ketan for Req. no. 46464 -- END
				if(bInternal) {
					String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
					String[] changeargs={objId,sPhysicalId};
					StopWatch swLifecycle = new StopWatch();
					swLifecycle.start();
					mpLifeCycleApproval = util.getCOName(context, changeargs);
					swLifecycle.stop();
					mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				}
				mpAttribResult.put(ConstantsUtilIRM.ARTWORKLANGAUGE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARTWORKLANGUAGE))));
				mpPartsAssociationResult.remove(ConstantsUtil.DESCRIPTION);
				mpPartsAssociationResult.remove(ConstantsUtil.MODIFIED);
				mpPartsAssociationResult.remove(ConstantsUtil.ORIGINATED);
				mpPartsAssociationResult.remove(ConstantsUtil.OWNER);
				mpPartsAssociationResult.remove(ConstantsUtil.PRIMARYORGANIZATION);
			}
			else
			{
				
				mpAttribResult.put(ConstantsUtil.OWNER, owner);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_POACOMMENTST))));
				mpAttribResult.put(ConstantsUtilIRM.PACKINGLEVEL, (String)(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKINGLEVEL)));
				mpAttribResult.put(ConstantsUtilIRM.ARTWORKUSAGE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ARTWORKUSAGE))));
				mpAttribResult.put(ConstantsUtilIRM.ARTWORKBASIS, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ARTWORKBASIS))));
				
				
				//SPEC: 08-09-2022: Added for 22x Defect# 49806 by Sanjeeva -- START
				String strFPCCode = util.getFPCCodeForPOA(context,objId);
				mpAttribResult.put(ConstantsUtilIRM.FPCCODE, (validator.getStringEquivalentForStringList(strFPCCode)));
				//SPEC: 08-09-2022: Added for 22x Defect# 49806 by Sanjeeva -- END
				Map mpFPCCode = util.fetchGTINDataField(context,objId,env);
				mpAttribResult.put(ConstantsUtilIRM.FPCNAME, (String)mpFPCCode.get(ConstantsUtilIRM.FPCNAME));
				mpAttribResult.put(ConstantsUtilIRM.FPCDESCR, (String)mpFPCCode.get(ConstantsUtilIRM.FPCDESCR));
				mpAttribResult.put(ConstantsUtilIRM.FPCPACKLEVEL, (String)mpFPCCode.get(ConstantsUtilIRM.FPCPACKLEVEL));
				mpAttribResult.put(ConstantsUtilIRM.FPCGTIN, (String)mpFPCCode.get(ConstantsUtilIRM.FPCGTIN));
				
				mpAttribResult.put(ConstantsUtilIRM.OLDIPMS, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_OLDIPMS))));
				if(ConstantsUtilIRM.STR_CUSTOMSPEC.equals(strCustomIPMS))
				{
					mpAttribResult.put(ConstantsUtilIRM.PRINTER, strPrinter);
				}
				else {
					strPrinter=(String)(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRINTER)));
					if(UIUtil.isNullOrEmpty(strPrinter)) {
						strPrinter="NA";
					}
					mpAttribResult.put(ConstantsUtilIRM.PRINTER, strPrinter);
				}
				mpAttribResult.put(ConstantsUtilIRM.ADDDESCRIPTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ADDDESCRIPTION))));
				mpAttribResult.put(ConstantsUtilIRM.SUPPLIER, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_REL_SUPPLIERPOANAME))));
				mpAttribResult.put(ConstantsUtilIRM.PRINTINGPROCESS, strPrintingProcess);
				mpAttribResult.put(ConstantsUtilIRM.LANGUAGES, strLanguages);
				mpAttribResult.put(ConstantsUtilIRM.SECONDARYPRINTER, strSecondPrinter);
				mpAttribResult.put(ConstantsUtilIRM.PACKINGMATERIALTYPE, strPackagingMaterialType);
				mpAttribResult.put(ConstantsUtilIRM.CASECOUNT, strCaseCount);
				mpAttribResult.put(ConstantsUtilIRM.CASETYPE, (validator.getStringEquivalentForStringList(resultMapIPMS.get(ConstantsUtilIRM.SELECT_REL_CASETYPE))));
			
				DomainObject doIPMS = DomainObject.newInstance(context,strIPMSId);
				mpAttribResult.put(ConstantsUtilIRM.GROSS_WEIGHTUOM, poaBO.getCUPGrossWeight(context,doIPMS));
				if(ConstantsUtilIRM.STR_CUSTOMSPEC.equals(strCustomIPMS))
				{
					if (!bInternal) {
					StringList plantList = validator.getStringListEquivalentForString(resultMapIPMS.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
					 String strUserOwnership =sct.getUserCauthorities();
					 String[] aCompany = util.splitCompanyValues(context,strUserOwnership);
					 StringList slUserOwnership =new StringList();
					 if (aCompany.length > -1) {
							for (int i = 0; i < aCompany.length; i++) {
								if (null != aCompany[i]) {
									String company = aCompany[i];
									slUserOwnership.add(company.trim());
								}
							}
						}
					 PQRBO pqrBO = new PQRBO ();
					 StringBuilder plantBuilder =pqrBO.getManufacturerPlants(plantList,slUserOwnership);
					 mpAttribResult.put(ConstantsUtil.PLANTS,plantBuilder.toString().replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA));
					} else {
						
						mpAttribResult.put(ConstantsUtil.PLANTS,poaBO.getManufacturingPlantsConnToPOA(context,strIPMSId));
					}
					 
				} else {
					mpAttribResult.put(ConstantsUtil.PLANTS,ConstantsUtil.EMPTY_SPACE);
				}
				if(!bInternal) {
					mpPartsAssociationResult.remove(ConstantsUtil.MODIFIED);
					mpPartsAssociationResult.remove(ConstantsUtil.ORIGINATED);
					mpPartsAssociationResult.remove(ConstantsUtil.OWNER);
					mpPartsAssociationResult.remove(ConstantsUtil.PRIMARYORGANIZATION);
				}
			
			}
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR))));
			mpAttribResult.put(ConstantsUtil.ORIGINATED, validator.DateFormatterParse((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))));
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))));
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, validator.DateFormatterParse((validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ACTUAL_RELEASE_DATE)))));//SPEC: 24-08-2022: Pooja Modified for Defect 50276
			mpAttribResult.put(ConstantsUtil.NEWIPMSPMPOPP, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ATTRIBUTE_IPMS))));
			swAttributes.stop();
			LOGGER.info("POA SERVICE GET ATTRIBUTE ELAPSED TIME : "+swAttributes.getTime());

			/**
			 * LOAD MARKETS APPROVED SECTION
			 */
			mpMarketsApproved = cdoc.getMarketsApproved(context, resultMaps);

			String[] strtemp=mpMarketsApproved.get(ConstantsUtil.MARKETSAPPROVED).split("\\|");
			for(int i = 0; i<strtemp.length-1; i++)   
			{  
				for (int j = i+1; j<strtemp.length; j++)   
				{  
				if(strtemp[i].compareTo(strtemp[j])>0)   
					{  
					String temp = strtemp[i];  
					strtemp[i] = strtemp[j];  
					strtemp[j] = temp;  
					}  
				}
			}  
			String strmpMarketsApproved="";
			String strmpMarketsApprovedPOA="";
			for(int i = 0; i<strtemp.length; i++)   
			{  
				strmpMarketsApproved+=strtemp[i]+"|";
				if(strmpMarketsApprovedPOA.equals(""))
				{
					strmpMarketsApprovedPOA=strtemp[i];
				}
				else
				{
					strmpMarketsApprovedPOA+=","+strtemp[i];
				}
			}
			mpMarketsApproved.remove(ConstantsUtil.MARKETSAPPROVED);
			if(strType.equals(ConstantsUtil.tPOA)&& bExternal)
			{
				mpAttribResult.put(ConstantsUtil.MARKETSAPPROVED,strmpMarketsApprovedPOA);
			}
			else
			{
				mpMarketsApproved.put(ConstantsUtil.MARKETSAPPROVED,strmpMarketsApproved);
			}
			StopWatch swSpecs = new StopWatch();
			swSpecs.start();
			mpPartSpecResult = util.updatePartSpec(context, resultMaps);
			swSpecs.stop();
			LOGGER.info("POA SERVICE GET RELATED SPECIFICATIONS ELAPSED TIME : "+swSpecs.getTime());

			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */

			StopWatch swReferenceDoc= new StopWatch();
			swReferenceDoc.start();
			MasterCOPBO mcop = new MasterCOPBO();
			
			if(strType.equals(ConstantsUtilIRM.ARTORPOA))
			{
				FormulaCardBO fcBO = new FormulaCardBO();
				mapReferenceDocs =fcBO.updateRefDocs(context, resultMaps);
			}
			else
			{
				mapReferenceDocs=poaBO.updateRefDocs(context, resultMaps);
			}
			
			swReferenceDoc.stop();
			LOGGER.info("POA SERVICE  REFERENCE DOCS ELAPSED TIME : "+swReferenceDoc.getTime());


				if(strType.equals(ConstantsUtilIRM.ART))
				{
					String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
					String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
					String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
					StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
					//SPEC: 28-07-2022: Pooja Added for Internal Defect -- START
					String strFileSize = cdoc.updateFileSize(FileSize);
					//SPEC: 28-07-2022: Pooja Added for Internal Defect -- END
					StringTokenizer tokenizer = new StringTokenizer(FileFormats,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					StringBuilder sbTokenIndex = new StringBuilder();

					if(tokenizer.countTokens()>1) {
						int count = tokenizer.countTokens();
						for(int i = 0; i<count;i++) {
							String sFormat = tokenizer.nextToken();
							if(sFormat.trim().equalsIgnoreCase("generic")){
								sbTokenIndex.append(i).append(ConstantsUtil.SYMBL_COMMA);
							}
						}
					StringBuilder sbFilename = validator.tokenizeFiles(FileName,sbTokenIndex);
					StringBuilder sbFileCapturedFie = validator.tokenizeFiles(FileCapturedFie,sbTokenIndex);
					StringBuilder sbFileFormats = validator.tokenizeFiles(FileFormats,sbTokenIndex);
					StringBuilder sbFileSize = validator.tokenizeFiles(strFileSize,sbTokenIndex);

					mpFiles.put(ConstantsUtil.FILESPATH, sbFileCapturedFie.toString());
					mpFiles.put(ConstantsUtil.FILESFORMAT, sbFileFormats.toString());
					mpFiles.put(ConstantsUtil.FILESNAMES, sbFilename.toString());
					mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());
				} else {
					if(!FileFormats.contains("generic")) {
						mpFiles.put(ConstantsUtil.FILESPATH, FileCapturedFie.toString());
						mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats.toString());
						mpFiles.put(ConstantsUtil.FILESNAMES, FileName.toString());
						mpFiles.put(ConstantsUtil.FILESSIZES, FileSize.toString());
					}
				}
				}
				else
				{
					MapList mlFiles=(MapList)poaBO.getReferenceFileObjects(context,objId);
					mpFiles=poaBO.parseMaplistForFiles(context,mlFiles);
				}
						

			/**
			 * SECURITY
			 * */
			StopWatch swSecurity = new StopWatch();
			swSecurity.start();
			mpSecurity =commonBo.updateSecurity(context, resultMaps);
			swSecurity.stop();
			LOGGER.info("POA Services Security ELAPSED TIME : "+swSecurity.getTime());


			//IP Class
			StringList slIpSelects = new StringList();
			slIpSelects.add(ConstantsUtil.SELECT_NAME);
			slIpSelects.add(ConstantsUtil.SELECT_ID);
			slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
			slIpSelects.add(ConstantsUtil.SELECT_TYPE);
			slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			mpIPClass =commonBo.getIpClass(context, dobCdoc, slIpSelects);
			commonBo.close(context);
			if (mpIPClass.containsKey(ConstantsUtil.LIBRARY)) {
				mpIPClass.remove(ConstantsUtil.LIBRARY);
			}
			 if (mpIPClass.containsKey(ConstantsUtil.CLASSIFICATIONPATH)) {
				 mpIPClass.remove(ConstantsUtil.CLASSIFICATIONPATH);
			}
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BbUtil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			//Mandatory outputs
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.MARKETSAPPROVED,mpMarketsApproved);
			if(bInternal) {
				if(strType.equals(ConstantsUtilIRM.ARTORPOA)) {
					hmAttrib.put(ConstantsUtil.ORGANIZATIONS, mpOrganization);
				}
				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			}
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			if(strType.equals(ConstantsUtilIRM.ARTORPOA))
			{
				hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
				//hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS); //Commented by Ketan for Req. no. 46464
				hmAttrib.put(ConstantsUtilIRM.PARTSASSOCIATION, mpPartsAssociationResult);
			}
			else
			{
				hmAttrib.put(ConstantsUtilIRM.PARTSASSOCIATION, mpPartsAssociationResult);
			}
			LOGGER.info("POA MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "POA SERVICE OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			pool.checkIn(context);
			sp.stop();
		} catch (Exception e) {
			LOGGER.error("Exception in getPOAdata in POAServicesImpl.java: "+e.getMessage());
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		context.close();
		return hmAttrib;


	}

}
