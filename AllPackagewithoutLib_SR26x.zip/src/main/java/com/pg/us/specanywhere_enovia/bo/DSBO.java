/**
 * Project 		: SpecsAnywhere
 * Program 		: DSBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.ProgramCallable;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.SAPBOMConstants;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import com.matrixone.apps.domain.util.StringUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class DSBO {
	
	private static Logger dsLOGGER = Logger.getLogger(DSBO.class);
	BusObjectAttribUtil util  = new BusObjectAttribUtil();
	static StringValidatorUtil validator = new StringValidatorUtil();
	
	/**
	 * Method Name 			: getUserSubscriptions
	 * Method Description 	: Fetching "Dynamic Subscription Home Page Result List" related data
	 * @param context
	 * @param strPersonName
	 * @return Map - Send DS Object table Results depends on user name.
	 * @throws Exception If operation fails. 
	 */
	@SuppressWarnings("unchecked")
	@ProgramCallable
	 public Map<String, String> getUserSubscriptions(Context context, String strPersonName) {	 	
		
		Map<String, String> mDSConnectedObj = new HashMap<>();
	 	StringBuilder sbDSId = new StringBuilder();
		StringBuilder sbDSType = new StringBuilder();
		StringBuilder sbDSFrequency = new StringBuilder();
		StringBuilder sbDSPolicy = new StringBuilder();
		StringBuilder sbDSState = new StringBuilder();
		StringBuilder sbDSOrg = new StringBuilder();
		StringBuilder sbDSVendor = new StringBuilder();
		StringBuilder sbDSPlant = new StringBuilder();
		StringBuilder sbDSBrand = new StringBuilder();
		StringBuilder sbDSSegment = new StringBuilder();
		StringBuilder sbDSStatus = new StringBuilder();
		StringBuilder sbDSExpDate = new StringBuilder();
		StringBuilder sbDSGCASName = new StringBuilder();
		StringBuilder sbDSIRMDocOwner = new StringBuilder();
	 	try {	 
	 		String strPersonID = PersonUtil.getPersonObjectID(context, strPersonName);
	 		MapList mlConnectedObj = getSubscriptionMapList(context, strPersonID);	
		 	if(null != mlConnectedObj && !mlConnectedObj.isEmpty()) {
		 		Iterator<MapList> itrDSObjectList = mlConnectedObj.iterator();		 		
		 		while(itrDSObjectList.hasNext()) {		 			
					Map<String,String> mConnObj = (Map<String, String>) itrDSObjectList.next();
					String strDSLocation = validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MANUFACTURING_LOCATION))?mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MANUFACTURING_LOCATION) : ConstantsUtil.EMPTY_STRING;	
					String strDSVendor = getSubscriptionVendor(context, strDSLocation);
					util.formatData (sbDSId, validator.isNotNullOrEmpty(mConnObj.get(DomainConstants.SELECT_ID))?mConnObj.get(DomainConstants.SELECT_ID) : ConstantsUtil.EMPTY_STRING);       
					//Added for the req 127913 - START
					String sDSType = dsMapType(validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCT_DATA_TYPE))?mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCT_DATA_TYPE) : ConstantsUtil.EMPTY_STRING);
					if(sDSType.contains(ConstantsUtil.SYMBL_PIPE) && (sDSType.indexOf(ConstantsUtil.SYMBL_PIPE) < sDSType.length()-1)) {
						sDSType = ConstantsUtil.ALL;
					}
					String strDSGCASName = validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSGCASNAME))?mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSGCASNAME) : ConstantsUtil.EMPTY_STRING;
					strDSGCASName = strDSGCASName.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
					util.formatData (sbDSType, sDSType);
					//Added for the req 127913 - END
					util.formatData (sbDSFrequency, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SUBSCRIPTION_FREQUENCY))?mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SUBSCRIPTION_FREQUENCY) : ConstantsUtil.EMPTY_STRING);  
					util.formatData (sbDSPolicy, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPOLICY))?mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPOLICY) : ConstantsUtil.EMPTY_STRING);     
					util.formatData (sbDSState, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CPNSTATE))?mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CPNSTATE) : ConstantsUtil.EMPTY_STRING);      
					util.formatData (sbDSOrg, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONCATEGORY))?mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONCATEGORY) : ConstantsUtil.EMPTY_STRING);        
					util.formatData (sbDSVendor, strDSVendor);     
					util.formatData (sbDSPlant, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPLANT))?mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPLANT) : ConstantsUtil.EMPTY_STRING);      
					util.formatData (sbDSBrand, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONBRAND))?mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONBRAND) : ConstantsUtil.EMPTY_STRING);      
					util.formatData (sbDSSegment, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONSEGMENT))?mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONSEGMENT) : ConstantsUtil.EMPTY_STRING);    
					util.formatData (sbDSStatus, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONLIFECYCLE))?mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONLIFECYCLE) : ConstantsUtil.EMPTY_STRING);     
					util.formatData (sbDSExpDate, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONEXPIRATIONDATE))?mConnObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONEXPIRATIONDATE) : ConstantsUtil.EMPTY_STRING); 
					util.formatData (sbDSGCASName, strDSGCASName);//Added for the req 127913 - START
					util.formatData (sbDSIRMDocOwner, validator.isNotNullOrEmpty(mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSIRMDOCOWNER))?mConnObj.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSIRMDOCOWNER) : ConstantsUtil.EMPTY_STRING);
		 		}
		 		mDSConnectedObj.put(ConstantsUtil.ID, sbDSId.toString());			
				mDSConnectedObj.put(ConstantsUtil.TYPE, sbDSType.toString());
				mDSConnectedObj.put(ConstantsUtilIRM.FREQUENCY, sbDSFrequency.toString());
				mDSConnectedObj.put(ConstantsUtil.POLICY, sbDSPolicy.toString());
				mDSConnectedObj.put(ConstantsUtil.STATE, sbDSState.toString());
				mDSConnectedObj.put(ConstantsUtilIRM.ORGANIZATION, sbDSOrg.toString());
				mDSConnectedObj.put(ConstantsUtil.VENDOR, sbDSVendor.toString());
				mDSConnectedObj.put(ConstantsUtilIRM.PLANT, sbDSPlant.toString());
				mDSConnectedObj.put(ConstantsUtil.BRAND, sbDSBrand.toString());
				mDSConnectedObj.put(ConstantsUtil.SEGMENT, sbDSSegment.toString());
				mDSConnectedObj.put(ConstantsUtil.MANUFACTURINGSTATUS, sbDSStatus.toString());
				mDSConnectedObj.put(ConstantsUtil.EXPIRATIONDATE, sbDSExpDate.toString());
				mDSConnectedObj.put(ConstantsUtilIRM.STR_GCAS, sbDSGCASName.toString());
				mDSConnectedObj.put(ConstantsUtilIRM.STR_DSIRMDOCOWNER, sbDSIRMDocOwner.toString());
	 		}	 					
		}catch (Exception e) {
			dsLOGGER.error("Error from DSBO: getUserSubscriptions"+e);
		} 
	 	return mDSConnectedObj;
	 }
	 
	 /**
	 * Method Name 			: getSubscriptionMapList
	 * Method Description 	: Fetching "Dynamic Subscription Connected Objects list" related data
	 * @param context 
	 * @param strPersnId
	 * @return MapList - Send the list of connected DS Objects.
	 * @throws Exception If operation fails. 
	 */
	 public MapList getSubscriptionMapList(Context context, String strPersnId) {
	 
		 MapList mlConnectedObjList = new MapList();
		 StringList slDSSelects = new StringList();
		 slDSSelects.addAll(getDSDetailSelectables());
		 boolean getTo = false;
		 boolean getFrom = true;
		 try {
			 if(UIUtil.isNotNullAndNotEmpty(strPersnId)) {
				 DomainObject doObj = DomainObject.newInstance(context, strPersnId);			
				 mlConnectedObjList = doObj.getRelatedObjects
						 			(context, //MatrixContex
								 	ConstantsUtilIRM.RELATIONSHIP_DYNAMIC_SUBSCRIPTION, //relationshipPattern
								 	ConstantsUtilIRM.TYPE_USERSUBSCRIPTION, //typePattern
								 	slDSSelects, //objectSelects
								 	DomainConstants.EMPTY_STRINGLIST, //relationshipSelects
								 	getTo, //getTo
								 	getFrom, //getFrom
								 	(short) 1, //recurseToLevel
								 	ConstantsUtil.EMPTY_STRING, //objectWhere
								 	ConstantsUtil.EMPTY_STRING, //relationshipWhere
								 	ConstantsUtil.ZERO_LEVEL); //limit
			 }
		 }
		 catch (FrameworkException e) {
			 dsLOGGER.error("Error from DSBO: getSubscriptionMapList"+e);
		 } 
	 	 return mlConnectedObjList;
	 }	 
	 
	 /**
	 * Method Name 			: getDSDetailSelectables
	 * Method Description 	: Fetching "Dynamic Subscription Selectables" related data
	 * @return StringList
	 */
	public StringList getDSDetailSelectables() {
		
		StringList slSelectStmts = new StringList();
		slSelectStmts.addElement(DomainConstants.SELECT_ID);
		slSelectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCT_DATA_TYPE);
		slSelectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_SUBSCRIPTION_FREQUENCY);
		slSelectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPOLICY);
		slSelectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_CPNSTATE);
		slSelectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONCATEGORY);
		slSelectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_MANUFACTURING_LOCATION);
		slSelectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPLANT);
		slSelectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONBRAND);
		slSelectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONSEGMENT);
		slSelectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONLIFECYCLE);
		slSelectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONEXPIRATIONDATE);		
		slSelectStmts.addElement(ConstantsUtil.SELECT_NAME);
		slSelectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSGCASNAME);
		slSelectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSIRMDOCOWNER);
		return slSelectStmts;
	}
	
	/**
	 * Method Name 			: getSubscriptionDetails
	 * Method Description 	: Fetching "Dynamic Subscription view Details" related data
	 * @param context 
	 * @param strObjId
	 * @return Map - Send DS Object Details.
	 * @throws Exception If operation fails.
	 */
	 @SuppressWarnings("unchecked")
	 public Map<String, String> getSubscriptionDetails(Context context, String strObjId) {
		 	
		 Map<String, String> mDSDetails = new HashMap<>();
		 String strDSState = ConstantsUtil.EMPTY_STRING;
		 StringList slDSSelectDetails = new StringList();                     
		 slDSSelectDetails.addAll(getDSDetailSelectables());			
		 try {
			DomainObject doObjectDetails = DomainObject.newInstance(context,strObjId);
			Map<String, String> mObjDetails = doObjectDetails.getInfo(context,slDSSelectDetails);	
			mDSDetails.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_ID)))?mObjDetails.get(DomainConstants.SELECT_ID) : ConstantsUtil.EMPTY_STRING);			
			//dsMapType Added by Jwala for the defect 46879 6.0.3 -- START
			//Added schema type name to share actual type name to UI
			mDSDetails.put(ConstantsUtilIRM.SCHEMATYPE, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCT_DATA_TYPE)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCT_DATA_TYPE) : ConstantsUtil.EMPTY_STRING);
			String sDSType = dsMapType(validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCT_DATA_TYPE))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCT_DATA_TYPE) : ConstantsUtil.EMPTY_STRING);
			if(sDSType.contains(ConstantsUtil.SYMBL_PIPE) && (sDSType.indexOf(ConstantsUtil.SYMBL_PIPE) < sDSType.length()-1)) {
				sDSType = ConstantsUtil.ALL;
			}
			mDSDetails.put(ConstantsUtil.TYPE, sDSType);
			mDSDetails.put(ConstantsUtilIRM.SCHEMATYPE, sDSType);
			//Added for the req 127913 - END
			//dsMapType Added by Jwala for the defect 46879 6.0.3 -- END
			mDSDetails.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty(mObjDetails.get(DomainConstants.SELECT_NAME)))?mObjDetails.get(DomainConstants.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mDSDetails.put(ConstantsUtilIRM.FREQUENCY, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SUBSCRIPTION_FREQUENCY)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_SUBSCRIPTION_FREQUENCY) : ConstantsUtil.EMPTY_STRING);
			mDSDetails.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPOLICY)))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPOLICY) : ConstantsUtil.EMPTY_STRING);
			String strDSCurrent = validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CPNSTATE))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CPNSTATE) : ConstantsUtil.EMPTY_STRING;
			if (ConstantsUtilIRM.RANGE_BOTH.equals(strDSCurrent)) {
				strDSState = ConstantsUtilIRM.STATE_BOTH;
			} else {
				strDSState = strDSCurrent;
			}
			String strDSGCASName = validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSGCASNAME))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSGCASNAME) : ConstantsUtil.EMPTY_STRING;
			strDSGCASName = strDSGCASName.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
			mDSDetails.put(ConstantsUtil.STATE, strDSState);			
			mDSDetails.put(ConstantsUtilIRM.ORGANIZATION, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONCATEGORY)))?mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONCATEGORY) : ConstantsUtil.EMPTY_STRING);
			String strDSLocation = validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MANUFACTURING_LOCATION))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_MANUFACTURING_LOCATION) : ConstantsUtil.EMPTY_STRING;
			String strDSVendor = getSubscriptionVendor(context, strDSLocation);
			mDSDetails.put(ConstantsUtil.VENDOR, strDSVendor);			
			mDSDetails.put(ConstantsUtilIRM.PLANT, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPLANT)))?mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONPLANT) : ConstantsUtil.EMPTY_STRING);
			mDSDetails.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONBRAND)))?mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONBRAND) : ConstantsUtil.EMPTY_STRING);
			mDSDetails.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONSEGMENT)))?mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mDSDetails.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONLIFECYCLE)))?mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONLIFECYCLE) : ConstantsUtil.EMPTY_STRING);
			mDSDetails.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONEXPIRATIONDATE)))?mObjDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDYNAMICSUBSCRIPTIONEXPIRATIONDATE) : ConstantsUtil.EMPTY_STRING);
			mDSDetails.put(ConstantsUtilIRM.STR_GCAS, strDSGCASName);//Added for the req 127913 - START
			mDSDetails.put(ConstantsUtilIRM.STR_DSIRMDOCOWNER,validator.isNotNullOrEmpty(mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSIRMDOCOWNER))?mObjDetails.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDSIRMDOCOWNER) : ConstantsUtil.EMPTY_STRING);//Added for the req 127913 - START
		 } catch (Exception e) {
			 dsLOGGER.error("Error from DSBO: getSubscriptionDetails"+e);
		 } 
		 return mDSDetails;
	 }
	 
	 /**
	 * Method Name 			: getSubscriptionVendor
	 * Method Description 	: Fetching "Dynamic Subscription Vendor" related data
	 * @param context 
	 * @param strDSLocation
	 * @return String - Get the DS Company Name.
	 */
	 @SuppressWarnings("unchecked")
	 public String getSubscriptionVendor(Context context, String strDSLocation) {
		 
	 	String strDSVendorFinal = ConstantsUtil.EMPTY_STRING;
		String strWhereClause = ConstantsUtil.EMPTY_STRING;
		StringList slObjectSelects 	= new StringList();
		slObjectSelects.add(DomainConstants.SELECT_NAME);	
		try {		
			if (UIUtil.isNotNullAndNotEmpty(strDSLocation) ) {
			MapList mlCompanyData = DomainObject.findObjects
								(context, //MatrixContext
								DomainConstants.TYPE_COMPANY, //typePattern
								ConstantsUtil.SYMBL_ASTERISK + strDSLocation, //namePattern
								ConstantsUtil.SYMBL_DASH, //revPattern	
								ConstantsUtil.SYMBL_ASTERISK, //ownerPattern
								ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
								strWhereClause, //whereExpression
								false, //expandType
								slObjectSelects); //objectSelects
			
			if(!mlCompanyData.isEmpty()) {
				Iterator<MapList> itrCompany = mlCompanyData.iterator();
				while (itrCompany.hasNext()) {
					Map<String,String> mTemp = (Map<String, String>) itrCompany.next();
					strDSVendorFinal= mTemp.get(DomainConstants.SELECT_NAME);						
				}
			}
			}
		}
		catch (Exception e) {
			dsLOGGER.error("Error from DSBO: getSubscriptionVendor"+e);
		} 
		return strDSVendorFinal;
	 }
	 
	 /**
	 * Method Name 			: getDSSearchFields
	 * Method Description 	: Fetching "Dynamic Subscription" Search related data
	 * @param context 
	 * @param strType
	 * @param strName
	 * @param args 
	 * @return Map - Send DS Search Objects depends on type name.
	 * @throws Exception If operation fails.
	 */
	 @SuppressWarnings("unchecked")
	 public Map<String, String> getDSSearchFields(Context context, String strType, String strName) {
		Map<String, String> mDSSearchObject = new HashMap<>();
		String strDSSearchWhere = ConstantsUtil.EMPTY_STRING;		
		StringBuilder sbSearchName = new StringBuilder();
		StringBuilder sbSearchID = new StringBuilder();	
		StringList slDSObjectsSelect = new StringList();
	    slDSObjectsSelect.add(DomainConstants.SELECT_NAME);
	    slDSObjectsSelect.add(DomainConstants.SELECT_ID);
	    MapList mlObjectList = new MapList();
	    try {
	    	//SPEC: <10.03.2022>: Guna Modified for 46940&46941 Defects  Dev 18x.6.0.3   -- START
	    	String strDisplayType = getTypeDisplayName(strType);
	    	if(ConstantsUtilIRM.TYPE_PGPLILIFECYCLESTATUS.equals(strDisplayType) && strName.isEmpty()){
				strName = ConstantsUtilIRM.MANUFACTURING_STATUS;
			}
	    	strDSSearchWhere = getDSSearchObjectWhere(strName);
	    	//if(ConstantsUtilIRM.TYPE_PGPLILIFECYCLESTATUS.equals(strDisplayType) && strName.isEmpty()){
	    		//strName = ConstantsUtilIRM.MANUFACTURING_STATUS;
	    		 mlObjectList = DomainObject.findObjects
		    		   		(context, //MatrixContext
		    		   		strDisplayType, //typePattern
		    		   		ConstantsUtil.SYMBL_ASTERISK, //namePattern
		    		   		ConstantsUtil.SYMBL_ASTERISK, //revPattern
		    		   		ConstantsUtil.SYMBL_ASTERISK, //ownerPattern
		    		   		ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
		    		   		strDSSearchWhere, //whereExpression
		    		   		false, //expandType
		    		   		slDSObjectsSelect); //objectSelects
	    		 mlObjectList.sort(DomainConstants.SELECT_NAME, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
	    		 int mlObjectListSize = mlObjectList.size();
	    		//SPEC: <10.03.2022>: Guna Modified for 47184 Defects  Dev 18x.6.0.3   -- START
	    		 if (ConstantsUtilIRM.TYPE_PGPLILIFECYCLESTATUS.equals(strDisplayType) ) {
	    			 for (int j = 0; j < mlObjectListSize; j++) {
			       		 Map<String, String> manuMap = (Map<String, String>)mlObjectList.get(j);
			       		String strManuName =manuMap.get(DomainConstants.SELECT_NAME);
			       	 StringList manuList =FrameworkUtil.split(ConstantsUtilIRM.MANUFACTURING_STATUS, ConstantsUtil.SYMBL_COMMA);  
			       		if(manuList.contains(strManuName)) {
				         util.formatData(sbSearchName, manuMap.get(DomainConstants.SELECT_NAME));
				         util.formatData(sbSearchID, manuMap.get(DomainConstants.SELECT_ID));
			       		}
			       	}
				}else {
		       	 for (int i = 0; i < mlObjectListSize; i++) {
		       		 Map<String, String> mpObject = (Map<String, String>)mlObjectList.get(i);
			         util.formatData(sbSearchName, mpObject.get(DomainConstants.SELECT_NAME));
			         util.formatData(sbSearchID, mpObject.get(DomainConstants.SELECT_ID));
		       	}
				}
	    		//SPEC: <10.03.2022>: Guna Modified for 47184 Defects  Dev 18x.6.0.3   -- END
	    	/*}
	    	else {*/
	    		
	    		//SPEC: <08.03.2022>: Guna Modified for 46877 Defect  Dev 18x.6.0.3   -- START
	    		//String strDSSearchObjectList = MqlUtil.mqlCommand(context, ConstantsUtilIRM.MQL_STMT, strDisplayType, ConstantsUtil.SYMBL_ASTERISK, ConstantsUtil.SYMBL_ASTERISK, strDSSearchWhere, DomainConstants.SELECT_NAME, DomainConstants.SELECT_ID, ConstantsUtil.SYMBL_PIPE);
	    		//SPEC: <08.03.2022>: Guna Modified for 46877 Defect  Dev 18x.6.0.3   -- END
	    		/*StringList slMasterIds =StringUtil.split(strDSSearchObjectList, ConstantsUtil.SYMBL_NEWLINE);	
	    		Iterator<String> itrObjectList = slMasterIds.iterator();
	    		while(itrObjectList.hasNext()) {
	    			String strMaster=itrObjectList.next();
	    			StringList slResult = StringUtil.split(strMaster, ConstantsUtil.SYMBL_PIPE);
	    			if(ConstantsUtilIRM.TYPE_PGPLILIFECYCLESTATUS.equals(strDisplayType)){
	    				if(!(slResult.get(3).equalsIgnoreCase(ConstantsUtilIRM.IN_ASSESSMENT) ||  slResult.get(3).equalsIgnoreCase(ConstantsUtilIRM.EXPERIMENTAL) || slResult.get(3).equalsIgnoreCase(ConstantsUtilIRM.PLANNING))){
	    					util.formatData(sbSearchName, slResult.get(3));			    
	    					util.formatData(sbSearchID, slResult.get(4));
	    				}
	    			} else {
	    					util.formatData(sbSearchName, slResult.get(3));			    
	    					util.formatData(sbSearchID, slResult.get(4));
	    			}
	    		}
	    	}*/
		     //SPEC: <10.03.2022>: Guna Modified for 46940&46941 Defects  Dev 18x.6.0.3   -- END
			if (ConstantsUtilIRM.TYPE_PGPLIORGANIZATIONCHANGEMANAGEMENT.equals(strDisplayType)) {
				mDSSearchObject.put(ConstantsUtilIRM.ORGANIZATION, sbSearchName.toString());
				mDSSearchObject.put(ConstantsUtil.ID, sbSearchID.toString());
			}
			if (ConstantsUtilIRM.TYPE_PGPLISUPPLIER.equals(strDisplayType)) {
				mDSSearchObject.put(ConstantsUtil.VENDOR, sbSearchName.toString());
				mDSSearchObject.put(ConstantsUtil.ID, sbSearchID.toString());
			}
			if (strDisplayType.contains(ConstantsUtil.TYPE_PLANT)) {
				mDSSearchObject.put(ConstantsUtilIRM.PLANT, sbSearchName.toString());
				mDSSearchObject.put(ConstantsUtil.ID, sbSearchID.toString());
			}
			if (ConstantsUtil.TYPE_PGBRAND.equals(strDisplayType)) {
				mDSSearchObject.put(ConstantsUtil.BRAND, sbSearchName.toString());
				mDSSearchObject.put(ConstantsUtil.ID, sbSearchID.toString());
			}
			if (ConstantsUtil.TYPE_PGPLISEGMENT.equals(strDisplayType)) {
				mDSSearchObject.put(ConstantsUtil.SEGMENT, sbSearchName.toString());
				mDSSearchObject.put(ConstantsUtil.ID, sbSearchID.toString());
			}
			if (ConstantsUtilIRM.TYPE_PGPLILIFECYCLESTATUS.equals(strDisplayType)) {
				mDSSearchObject.put(ConstantsUtil.MANUFACTURINGSTATUS, sbSearchName.toString());
				mDSSearchObject.put(ConstantsUtil.ID, sbSearchID.toString());
			}		    
		} catch (Exception e) {
			  dsLOGGER.error("Error from DSBO: getDSSearchFields"+e);
		} 
		return mDSSearchObject;	
	 }
	 
	 /**
	 * Method Name 			: getDSSearchMatchCase
	 * Method Description 	: Fetching "Dynamic Subscription" Match Case
	 * @param context
	 * @param strMatchCase
	 * @return String - get DS Search Match case
	 * @throws Exception If operation fails.
	 */	
		
	 private String getDSSearchMatchCase(Context context, String strMatchCase) {		
		 String strReturn = ConstantsUtil.EMPTY_STRING;
		 try {
			strReturn = MqlUtil.mqlCommand(context, ConstantsUtilIRM.MQL_STMT_CASE, strMatchCase);
		 }catch (Exception e) {
			  dsLOGGER.error("Error from DSBO: getDSSearchMatchCase"+e);			 
		 }
		return strReturn;
	}

	/**
	 * Method Name 			: getTypeDisplayName
	 * Method Description 	: Private Method to get Dynamic Subscription Search exact Type Name
	 * @param strTypeName
	 * @return String - get DS Search Type Name
	 * @throws Exception If operation fails.
	 */	
	 private String getTypeDisplayName(String strTypeName) {
		
		String strTypeDisplayName = ConstantsUtil.EMPTY_STRING;
		try {
		  if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.ORGANIZATION)) {
			    strTypeDisplayName = ConstantsUtilIRM.TYPE_PGPLIORGANIZATIONCHANGEMANAGEMENT;
		  }
		  else if (strTypeName.equalsIgnoreCase(ConstantsUtil.VENDOR)) {
			    strTypeDisplayName = ConstantsUtilIRM.TYPE_PGPLISUPPLIER;
		  }
		  else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.PLANT)) {
			    strTypeDisplayName = ConstantsUtil.TYPE_PLANT;
		  }
		  else if (strTypeName.equalsIgnoreCase(ConstantsUtil.BRAND)) {
			    strTypeDisplayName = ConstantsUtil.TYPE_PGBRAND;
		  }
		  else if (strTypeName.equalsIgnoreCase(ConstantsUtil.SEGMENT)) {
			    strTypeDisplayName = ConstantsUtil.TYPE_PGPLISEGMENT;
		  }
		  else if (strTypeName.equalsIgnoreCase(ConstantsUtil.MANUFACTURINGSTATUS)) {
			    strTypeDisplayName = ConstantsUtilIRM.TYPE_PGPLILIFECYCLESTATUS;
		  }
		  else if(strTypeName.contains(ConstantsUtil.SYMBL_COMMA)){ 
			  StringList slTypeName= StringUtil.split(strTypeName, ConstantsUtil.SYMBL_COMMA);
			  strTypeDisplayName =getMappedType(slTypeName);
		  } 
		  //Added by Ketan for Req. no. 42791,42796 -- START
		  else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.MASTER_BUSAREA)) {
			  strTypeDisplayName = ConstantsUtilIRM.TYPE_PGPLIBUSINESSAREA;
		  }
		  else if (strTypeName.equalsIgnoreCase(ConstantsUtilIRM.CERT_BUSAREA)) {
			  strTypeDisplayName = ConstantsUtilIRM.TYPE_PGPLIMATERIALCERTIFICATIONS;
		  }
		  //Added by Ketan for Req. no. 42791,42796 -- END
		  else  { 
			  strTypeDisplayName = strTypeName;
		  } 
		} catch (Exception e) {
			 dsLOGGER.error("Error from DSBO: getTypeDisplayName"+e);
		} 
		return strTypeDisplayName;
	 }
		/**
		 * Method Name 			: getMappedType
		 * Method Description 	: Private Method to get mapped types.
		 * @param slTypeName
		 * @return String - to get mapped multiple types.
		 * @throws Exception If operation fails.
		 */	
	 private String getMappedType(StringList slTypeName) {
		 StringBuilder sbType =new StringBuilder();
		 try{
			 for(int j=0;j<slTypeName.size();j++){
				 if(j==0){
				   if(slTypeName.get(j).equalsIgnoreCase(ConstantsUtilIRM.PLANT)){
					sbType.append(ConstantsUtil.TYPE_PLANT);
				   }else {
					sbType.append(ConstantsUtilIRM.TYPE_PGPLIRDLAB);
				    }
				 }else{
					 if(slTypeName.get(j).equalsIgnoreCase(ConstantsUtilIRM.PLANT)){
							sbType.append(","+ConstantsUtil.TYPE_PLANT);
					 }else {
					 sbType.append(","+ConstantsUtilIRM.TYPE_PGPLIRDLAB);
					}
				 }
			}
		 }
		 catch (Exception e) {
			 dsLOGGER.error("Error from DSBO: getMappedType"+e);
		}
		return sbType.toString();
	}

	/**
	 * Method Name 			: getTypeDisplayName
	 * Method Description 	: Private Method to get Dynamic Subscription Search object where condition results.
	 * @param strName
	 * @return String - display DS Search object where condition
	 * @throws Exception If operation fails.
	 */	
	 private String getDSSearchObjectWhere (String strName) {
		 
		 String strObjectWhere = ConstantsUtil.EMPTY_STRING;
		 StringBuilder sbDSSFinalName = new StringBuilder();
		 try {	 
			 if (UIUtil.isNotNullAndNotEmpty(strName) || !ConstantsUtil.SYMBL_ASTERISK.equals(strName)) {
				 StringList slDSSName = StringUtil.split(strName, ConstantsUtil.SYMBL_COMMA);		    	
				 if (slDSSName.size()>1) {
					 Iterator<String> itrDSSName = slDSSName.iterator();
					 sbDSSFinalName.append(DomainConstants.SELECT_CURRENT).append(SAPBOMConstants.SYMBOL_SPACE).append(SAPBOMConstants.CONST_SYMBOL_EQUAL).append(SAPBOMConstants.SYMBOL_SPACE).append(ConstantsUtilIRM.STATE_ACTIVE).append(SAPBOMConstants.SYMBOL_SPACE).append(SAPBOMConstants.SYMBOL_AND).append(SAPBOMConstants.SYMBOL_SPACE);
					 while(itrDSSName.hasNext()) {
						 String strDSSFinalName = itrDSSName.next();
						//SPEC: <08.03.2022>: Guna Modified for 46877 Defect  Dev 18x.6.0.3   -- START
						 sbDSSFinalName.append(DomainConstants.SELECT_NAME).append(SAPBOMConstants.SYMBOL_SPACE).append(ConstantsUtilIRM.SYMBOL_MATCH).append(SAPBOMConstants.SYMBOL_SPACE).append(ConstantsUtilIRM.SINGLE_QUOTE).append(ConstantsUtil.SYMBL_ASTERISK).append(strDSSFinalName).append(ConstantsUtil.SYMBL_ASTERISK).append(ConstantsUtilIRM.SINGLE_QUOTE);
						//SPEC: <08.03.2022>: Guna Modified for 46877 Defect  Dev 18x.6.0.3   -- END
						 if (itrDSSName.hasNext()) {
							 sbDSSFinalName.append(SAPBOMConstants.SYMBOL_SPACE).append(SAPBOMConstants.SYMBOL_OR).append(SAPBOMConstants.SYMBOL_SPACE);
						 }
					 }
					 strObjectWhere = sbDSSFinalName.toString();					
				 } else {
					//SPEC: <08.03.2022>: Guna Modified for 46877 Defect  Dev 18x.6.0.3   -- START
					 strObjectWhere = new StringBuffer(DomainConstants.SELECT_CURRENT).append(SAPBOMConstants.CONST_SYMBOL_EQUAL).append(ConstantsUtilIRM.STATE_ACTIVE).append(SAPBOMConstants.SYMBOL_AND).append(DomainConstants.SELECT_NAME).append(SAPBOMConstants.SYMBOL_SPACE).append(ConstantsUtilIRM.SYMBOL_MATCH).append(SAPBOMConstants.SYMBOL_SPACE).append(ConstantsUtilIRM.SINGLE_QUOTE).append(ConstantsUtil.SYMBL_ASTERISK).append(strName).append(ConstantsUtil.SYMBL_ASTERISK).append(ConstantsUtilIRM.SINGLE_QUOTE).toString();
					//SPEC: <08.03.2022>: Guna Modified for 46877 Defect  Dev 18x.6.0.3   -- END
				 }
			 } else {
				 strObjectWhere = new StringBuffer(DomainConstants.SELECT_CURRENT).append(SAPBOMConstants.CONST_SYMBOL_EQUAL).append(ConstantsUtilIRM.STATE_ACTIVE).toString();
			 }
		 }
		 catch (Exception e) {
			 dsLOGGER.error("Error from DSBO: getTypeDisplayName"+e);
		 } 
		 return strObjectWhere;
	 }
	 /**
		 * Method Name 			: dsMapType
		 * Method Description 	: Public Method to get Dynamic Subscription Display types
		 * @param sType
		 * @return String - get Type Name
		 * @throws Exception If operation fails.
		 */	
	 public String dsMapType(String sType) {
		 try{
			if (UIUtil.isNotNullAndNotEmpty(sType)) {
				if(sType.equals(ConstantsUtil.TYPE_QUALIFICATION)){
					sType = ConstantsUtilIRM.QUALIFICATION_PQR;
				}else if(sType.equals(ConstantsUtil.TYPE_PGTESTMETHOD)){
					sType = ConstantsUtilIRM.TESTMETHOD_CSS;
				//SPEC: 03.07.2022: Modified for Defect- 46877 Dev 18x.6.0.3  -- START
				}else if(sType.equals(ConstantsUtil.TYPE_PGPROMOTIONALITEMPART)){
					sType = ConstantsUtilIRM.PROMOTIONAL_ITEM_PART;
				}else if(sType.equals(ConstantsUtil.TYPE_PGSUPPLIERINFORMATIONSHEET)){
					sType = ConstantsUtilIRM.SUPPLIER_INFORMATION_SHEET;
				}else{
					sType =util.mapType(sType);
				}
				//SPEC: 03.07.2022: Modified for Defect- 46877 Dev 18x.6.0.3  -- END
			}
		 }
		 catch (Exception e) {
			 dsLOGGER.error("Error from DSBO: dsMapType"+e);
		 } 
			return sType;
		}
	 
	//Added by Ketan for Req. no. 42791,42796 -- START
	public Map<String, String> getBusAreaOrCertClaimPickList(Context context, String strType) {
		Map<String, String> mBAObject = new HashMap<>();
		String strBAType = getTypeDisplayName(strType);
		String strBAWhere = new StringBuffer(DomainConstants.SELECT_CURRENT).append(SAPBOMConstants.CONST_SYMBOL_EQUAL).append(ConstantsUtilIRM.STATE_ACTIVE).toString();
		StringList slBAObjectsSelect = new StringList();
	    slBAObjectsSelect.add(DomainConstants.SELECT_NAME);
	    slBAObjectsSelect.add(DomainConstants.SELECT_ID);
	    StringBuilder sbBAName = new StringBuilder();
		StringBuilder sbBAid = new StringBuilder();
		MapList mlObjectList = new MapList();
		try {
			mlObjectList = DomainObject.findObjects
			   		(context, //MatrixContext
			   		strBAType, //typePattern
			   		ConstantsUtil.SYMBL_ASTERISK, //namePattern
			   		ConstantsUtil.SYMBL_ASTERISK, //revPattern
			   		ConstantsUtil.SYMBL_ASTERISK, //ownerPattern
			   		ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
			   		strBAWhere, //whereExpression
			   		false, //expandType
			   		slBAObjectsSelect); //objectSelects
		mlObjectList.sort(DomainConstants.SELECT_NAME, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
   		int mlObjectListSize = mlObjectList.size();
   		for (int i = 0; i < mlObjectListSize; i++) {
      		 Map<String, String> mpObject = (Map<String, String>)mlObjectList.get(i);
	         util.formatData(sbBAName, mpObject.get(DomainConstants.SELECT_NAME));
	         util.formatData(sbBAid, mpObject.get(DomainConstants.SELECT_ID));
      	}
   		mBAObject.put(strType, sbBAName.toString());
   		mBAObject.put(ConstantsUtil.ID, sbBAid.toString());
		} catch (Exception e) {
			  dsLOGGER.error("Error from DSBO: getBusinessAreaPickList"+e);
		}
		return mBAObject;
	}
	//Added by Ketan for Req. no. 42791,42796 -- END
}
