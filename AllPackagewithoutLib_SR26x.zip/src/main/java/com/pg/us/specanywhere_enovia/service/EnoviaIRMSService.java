package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaIRMSService {
	public HashMap<String, Map<String, String>> getIRMSdata(String objId, Environment env) throws Exception;
}