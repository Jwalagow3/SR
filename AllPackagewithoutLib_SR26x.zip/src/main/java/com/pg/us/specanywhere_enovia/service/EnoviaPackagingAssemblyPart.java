package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaPackagingAssemblyPart {

	public HashMap<String, Map<String, String>> getPAPdata(String objId, String sComp, Environment env) throws Exception; 
}
