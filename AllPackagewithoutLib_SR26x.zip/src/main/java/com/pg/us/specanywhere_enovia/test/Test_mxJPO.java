package com.pg.us.specanywhere_enovia.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class Test_mxJPO {

	public static final String TYPE_PG_FINISHEDPRODUCTPART = PropertyUtil.getSchemaProperty("type_FinishedProductPart");
	public static final String TYPE_ESERVICE_OBJECT_GENERATOR = PropertyUtil.getSchemaProperty("type_eServiceObjectGenerator");
	public static final String ATTRIBUTE_ESERVICE_NAME_PREFIX = PropertyUtil.getSchemaProperty("attribute_eServiceNamePrefix");
	
	public static void main(String[] args) throws Exception
	{
		EnoviaConnectionPool pool = new EnoviaConnectionPool();
	    Context context = pool.checkOut();
		
		StringList slSelects = new StringList(DomainConstants.SELECT_NAME);
		
		slSelects.add(DomainConstants.SELECT_REVISION);

		String strFPCCodePadding="";
		try
		{
			BusObjectAttribUtil utill = new BusObjectAttribUtil();
			String objId = "20336.41905.62173.59533";
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			DomainObject doObj = DomainObject.newInstance(context, objId);
			String	strObjectType = doObj.getInfo(context, DomainConstants.SELECT_TYPE);
			DomainObject dob = new DomainObject(objId);
			
			
			CalculateBOM clBom = new CalculateBOM();
           Map  mpSapBomAsFedcResult = clBom.getSapBOMasFed(context,objId);
			
			if(UIUtil.isNotNullAndNotEmpty(objId) && TYPE_PG_FINISHEDPRODUCTPART.equalsIgnoreCase(strObjectType))

			{

				

				Map MapObjDetails = (Map)doObj.getInfo(context, slSelects);

			String	strObjectName = (String)MapObjDetails.get(DomainConstants.SELECT_NAME);

			String	strObjRevision = (String)MapObjDetails.get(DomainConstants.SELECT_REVISION);

			String	strName = FrameworkUtil.getAliasForAdmin(context, "type", TYPE_PG_FINISHEDPRODUCTPART, true);



			String	strMQLCommand = "print bus '" + TYPE_ESERVICE_OBJECT_GENERATOR + "' " + strName + " A select attribute["+ ATTRIBUTE_ESERVICE_NAME_PREFIX +"].value dump";



			String	strNamePrefix = MqlUtil.mqlCommand(context, strMQLCommand);



				if(UIUtil.isNotNullAndNotEmpty(strNamePrefix) && !strObjectName.contains(strNamePrefix))

				{

					 strFPCCodePadding = strObjectName;

					if (strFPCCodePadding.length() > 0 && strFPCCodePadding.length() <= 18)

					{

						while (strFPCCodePadding.length() < 18)

						{

							strFPCCodePadding = '0' + strFPCCodePadding;

						}

					}
				}
			}

					Map<String,String> mpProgramMap = new HashMap<String,String>();

					mpProgramMap.put("FPCCode", strFPCCodePadding);



					// Actual method to fetch the GPDB Information for the object from SAP system

					/*pgDSOWebService_mxJPO webServiceInstance = new pgDSOWebService_mxJPO();

					HashMap plValueMap = (HashMap)webServiceInstance.validateFPC(context, JPO.packArgs(mpProgramMap));
*/


					
					
			//${CLASS:TestSap} test = new ${CLASS:TestSap} (context,args);
			
					//HashMap plValueMap =JPO.invoke(context, "pgDSOWebService", null,"validateFPC", JPO.packArgs(mpProgramMap), HashMap.class);
		
	//	HashMap plValueMap = (HashMap)webServiceInstance.validateFPC(context, JPO.packArgs(mpProgramMap));
					//System.out.println("plValueMap---------------------"+plValueMap);
		
			//String sPreSelectedVendorId = MqlUtil.mqlCommand(context,
					//"execute prog 'pgDSOWebService' -method 'validateFPC' " );
			
			//System.out.println("sPreSelectedVendorId-------------"+sPreSelectedVendorId);
			
		}catch(Exception e){

			e.printStackTrace();
			
		}
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
	}

}
