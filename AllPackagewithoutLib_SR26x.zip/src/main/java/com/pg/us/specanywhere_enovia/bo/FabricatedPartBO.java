/**
 * Project 		: SpecsAnywhere
 * Program 		: FabricatedPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class FabricatedPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(FabricatedPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();

	public FabricatedPartBO() {
		// empty constructor
	}

	public FabricatedPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getFABBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getFABBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: getFABBO : Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getFABDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getFABDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: getFABDO : Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getFabricatedPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getFabricatedPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getCosSelectable(context));
		busSelect.addAll(getSapBomAsFedBusSelectable(context));
		
		//SPEC: <10.12.2020>: Added for req 18x.5 ## -- START
		busSelect.addAll(getSubstanceSelectables(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getFileSelects(context));
		//SPEC: <10.12.2020>: Added for req 18x.5 ## -- START
		
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) {
		StringList busSelect = new StringList(24);
		busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID); 
		busSelect.add(ConstantsUtil.COMP_NAME);  
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC); 
		busSelect.add(ConstantsUtil.COMP_TITLE); 
		busSelect.add(ConstantsUtil.COMP_STATE); 
		busSelect.add(ConstantsUtil.COMP_CASNUM);  		
		busSelect.add(ConstantsUtil.COMP_SUBNAME);  		
		busSelect.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);  		
		busSelect.add(ConstantsUtil.COMP_QTY);  			
		busSelect.add(ConstantsUtil.COMP_MAXHGHT);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT);  		
		busSelect.add(ConstantsUtil.COMP_QUOM);  			
		busSelect.add(ConstantsUtil.COMP_METALENVCLASS); 
		busSelect.add(ConstantsUtil.COMP_POSTCONSUMER); 
		busSelect.add(ConstantsUtil.COMP_MANUF);  		
		busSelect.add(ConstantsUtil.COMP_COMENT);  		
		busSelect.add(ConstantsUtil.COMP_MARKETNAME);  	
		busSelect.add(ConstantsUtil.COMP_SEQUENCE);  		
		busSelect.add(ConstantsUtil.COMP_MATELAYER);
		busSelect.add(ConstantsUtil.COMP_POSTINDUSTRIAL);
		busSelect.add(ConstantsUtil.COMP_RPRSTATUS);
		busSelect.add(ConstantsUtil.COMP_ECNUMBER);
		busSelect.add(ConstantsUtil.COMP_REACHSTATUS);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_CURRENT);
		
		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	
	
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END
	
	
	/**
	 * Method Name 			: getCosSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getCosSelectable(Context context) {

		StringList relSelect = new StringList(2);
		relSelect.add(ConstantsUtil.SELECT_COS_NAME);
		relSelect.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		return relSelect;
	}

	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching "Plant" related information
	 * @param context
	 * @return
	 */
	private StringList getPlantSelects(Context context) 
	{
		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.ATTRIBUTE_PGPRODUCTFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_REL_DERIVED_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE);
		busSelect.add(ConstantsUtil.STRPRINTINGPROSS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.STR_TEMPLATE);
		busSelect.add(ConstantsUtil.COMP_METALENVCLASS);

		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.ATL_ORGNSOURCE);

		busSelect.add(ConstantsUtil.SELECT_COS_NAME);
		busSelect.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		
		//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ);
		//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END
		//SPEC: <11.23.2020>: shashank Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.STR_AUTOCADIPCLASS);
		//SPEC: <11.23.2020>: shashank Added for req 18x.5 ## -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		//<12.24.2020>: Lingeswari Added as reference for 37755 -----start-------
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		//<12.24.2020>: Lingeswari Added as reference for 37755 -----End-------
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - Start
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - End
		//Added by Ketan for Req. no. 48322 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
		//Added by Ketan for Req. no. 48322 -- END
		
		return busSelect;
	}

	
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	: 
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();


		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, getTo, getFrom, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : FabricatedPartBO Method :updateDerivedDataInfo "+e);
			return new HashMap();
		}
		return mpDerived;
	}
	
	
	/**
	 * Method Name 			: getFABRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getFABRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		relSelect.addAll(getSubselects());
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}

	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//SPEC 10.29.2020 added for 18X.5--START
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		//SPEC 10.29.2020 added for 18X.5--END
		
		//SPEC 10.29.2020 added by Jwala for 44296 --START
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_BOM);
		//SPEC 10.29.2020 added by Jwala for 44296 -- END
		//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - Start
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - End
		
		return busSelect;
	}

	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		//Added by Ketan for Req. no. 46464 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC);
		//Added by Ketan for Req. no. 46464 -- END
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
	
		//Modified for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Modified for Defect# 37591 -- END
		// Guna Added for Defect 37304  18x.5.2 Release -- START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
		// Guna Added for Defect 37304  18x.5.2 Release -- END
		//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
		relSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
		//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- END
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		return relSelect;
	}

	
	/**
	 * Method Name 			: getSubselects
	 * Method Description 	:
	 * @return
	 */
	public static StringList getSubselects (){
		
		StringList busselect = new StringList();
		
		busselect.add(ConstantsUtil.SELECT_REVISION);
		//busselect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		busselect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		//Modified for Defect# 37591 -- START
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Modified for Defect# 37591 -- END
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		busselect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		//busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		//busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		busselect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		busselect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busselect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		
		return busselect;
	}
	public static StringList getSapBomAsFedBusSelectable(Context context) {

		StringList busSelect = new StringList(7);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_NAME);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_TYPE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_SAPSUBTYPE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_TITLE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_BOMQTY);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_BUOM);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.STR_SAPBOM__OCP);
		busSelect.add(ConstantsUtil.STR_FORMULA_INGR_CURRENT);

		return busSelect;
	}
	
	/**
	 * Method Name 			: getSubTYpe
	 * Method Description 	:
	 * @param slData
	 * @return
	 */

	private StringList getSubTYpe(StringList slData) {
		StringList slMapType = new StringList();
		String sType = ConstantsUtil.SPEC_SUB_TYPE;
		for(int i=0 ;i<slData.size();i++){
			String sDType = slData.get(i);
			if(!ConstantsUtil.DSO.equals(sDType)){
				slMapType.add(sType);
			}else{
				slMapType.add(ConstantsUtil.EMPTY_STRING);
			}

		}

		return slMapType;
	}
	
	/**
	 * Method Name 			: calculateBOMQty
	 * Method Description 	: 
	 * @param slData
	 * @return
	 */
	public String calculateBOMQty(StringList slData){
		StringBuilder sbbomQuantity = new StringBuilder();
		String sQty = DomainConstants.EMPTY_STRING;

		for(int i=0 ;i<slData.size();i++)
		{
			sQty = slData.get(i);
			if(UIUtil.isNotNullAndNotEmpty(sQty))
			{
				float sQuantity = Float.parseFloat(sQty);
				sQuantity*=10;
				sbbomQuantity.append(sQuantity);
				sbbomQuantity.append(ConstantsUtil.SYMBL_PIPE);
			}
		}
		return sbbomQuantity.toString();

	}
	
	
	/**
	 * Method Name 			: getSapBomAsFed
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
	public Map getSapBomAsFed(Map objectMap){

		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String,String> mpPartSpecs = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			String sType    =   validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_TYPE));
			String sName    =   validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_NAME));
			String sState   =   validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_CURRENT));
			String sSapType		=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE));
			String sSapSubType		=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE));
			String sBomQty	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_BOMQTY));
			String[] saBomQty=sBomQty.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			if (saBomQty.length!=0) {
				StringList	slBomQty=util.MapsType(saBomQty);
				sBomQty =calculateBOMQty(slBomQty);
			}
			
			String sBuom	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_BUOM));
			String sDSO		=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE));
			String sRelPhase	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_RELEASE_PHASE));
			StringList slDSO= validator.isNotNullOrEmpty((StringList)objectMap.get(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE));
			
			StringList	slSapSubType=getSubTYpe(slDSO);
			
			sSapSubType = validator.isNotNullOrEmpty(slSapSubType.toString()) ? slSapSubType.toString(): ConstantsUtil.EMPTY_STRING;
			String sTitle	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FORMULA_INGR_TITLE));
			String strOCP	=	validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SAPBOM__OCP));
			
			sSapSubType=util.replaceSpecialSymbols(sSapSubType);
			
			mpPartSpecs.put(ConstantsUtil.NAME, sName);
			mpPartSpecs.put(ConstantsUtil.TITLE, sTitle);
			mpPartSpecs.put(ConstantsUtil.TYPE, sType.toString());
			mpPartSpecs.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sSapSubType);
			mpPartSpecs.put(ConstantsUtil.SAPTYPE, sSapType);
			mpPartSpecs.put(ConstantsUtil.SUBSTITUTIONGROUPING, ConstantsUtil.EMPTY_STRING);
			mpPartSpecs.put(ConstantsUtil.BOMQUANTITY, sBomQty);
			mpPartSpecs.put(ConstantsUtil.BASEUNITOFMEASURE, sBuom);
			mpPartSpecs.put(ConstantsUtil.OPTIONALCOMPONENTS, strOCP);
			mpPartSpecs.put(ConstantsUtil.PHASE, sRelPhase);
			mpPartSpecs.put(ConstantsUtil.STATE, sState);

		} catch (Exception e) {
			LOGGER.error("Exception in: Program : FabricatedPaBO Method :getSapBomAsFed "+e);
			return new HashMap();
		}

		return mpPartSpecs;
	}

	
	
	/**
	 * Method Name 			: getMasterAttributeData
	 * Method Description 	:
	 * @param context
	 * @param sMasterID
	 * @return
	 * @throws Exception
	 */
	public Map getMasterAttributeData(Context context, String sMasterID) throws Exception {
		Map<String, Object> mpAttribResult = new HashMap<String, Object>();
		StringList busSelect = new StringList();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		DomainObject doFAB =  getFABDO(context, sMasterID);

		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		Map resultMaps = doFAB.getInfo(context,busSelect);
		StringValidatorUtil validator = new StringValidatorUtil();

		String lastUpdatedUser =ConstantsUtil.EMPTY_STRING;
		//SPEC: Release SR18x.5.2 - Added for Defect #39951  by Bala on Feb 18, 2021 -- START
		lastUpdatedUser = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		//SPEC: Release SR18x.5.2 - Added for Defect #39951  by Bala on Feb 18, 2021 -- END
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.NAME,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_TEMPLATE)))?(String)resultMaps.get(ConstantsUtil.STR_TEMPLATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ONSHELFPRODDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY) : ConstantsUtil.EMPTY_STRING);
		//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION) : ConstantsUtil.EMPTY_STRING);
		String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String strBrand = util.getBrandInformationValue(context,sID);
		if(strBrand.isEmpty()) {
			strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
		}
		mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
		
		mpAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGPRODUCTFORM)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGPRODUCTFORM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PROD_VARIANNT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ISBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.ISBATTERYCONTAINS, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PROD_DENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);		
		mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);

		return mpAttribResult;
	}

	
	/**
	 * Method Name 			: replaceSpecialSymbols
	 * Method Description 	:
	 * @param sData
	 * @return
	 */
	public String replaceSpecialSymbols(String sData)
	{
		if(!UIUtil.isNotNullAndNotEmpty(sData)){
			return ConstantsUtil.EMPTY_STRING;
		}
		sData= sData.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
		sData= sData.replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES).replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO);
		sData= sData.replace(ConstantsUtil.SYMBL_CAPTRUE, ConstantsUtil.SYMBL_YES).replace(ConstantsUtil.SYMBL_CAPFALSE, ConstantsUtil.SYMBL_NO);
		return sData;
	}
	
	
	/**
	 * Method Name 			: updatePlantInfo
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
	public Map updatePlantInfo(Map objectMap) {
		Map<String, String> mpPlant = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			String sPlantName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_NAME));
			String sAuthorize = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE));
			String sProduce = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE));
			String sIsActivated = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED));

			mpPlant.put(ConstantsUtil.PLANTS, sPlantName);
			mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOUSE, sAuthorize);
			mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOPRODUCE, sProduce);
			mpPlant.put(ConstantsUtil.PLANTSISACTIVATED, sIsActivated);

		}catch(Exception e){
			LOGGER.error("Error from FabricatedPaBO:  updatePlantInfo"+e);
			return new HashMap();
		}

		//SPEC: Commented for Dev 18x.6 Release by Jwala -- START
		//return  util.filterMapList(mpPlant);
		return mpPlant;
		//SPEC: Commented for Dev 18x.6 Release by Jwala -- END
	}

	
	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	: 
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context,MapList mapList) {
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMRev = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMChg = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMState= new StringBuilder();
		StringBuilder sbEBOMStage= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder(); 
		StringBuilder sbEBOMTupName= new StringBuilder();		 
		StringBuilder sbMinqty= new StringBuilder();
		StringBuilder sbMaxqty= new StringBuilder();
		StringBuilder sbNetWUOM= new StringBuilder();
		StringBuilder sbNetWet= new StringBuilder();
		StringBuilder sbLoss= new StringBuilder();
		StringBuilder sbMF= new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//StringBuilder sbAlt= new StringBuilder();
		StringBuilder sbAltName = new StringBuilder();
		StringBuilder sbAltID = new StringBuilder();
		StringBuilder sbAltType = new StringBuilder();
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		StringBuilder sbNet= new StringBuilder();
		StringBuilder sbOSPD= new StringBuilder();
		StringBuilder sbDen= new StringBuilder();
		StringBuilder sbIntended= new StringBuilder();
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		
		//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
		//SPEC: <13.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- START	
		StringBuilder sbRefDes =new StringBuilder();
		//SPEC: <13.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- END	
		SecurityService sec = new SecurityService();
		String sComp = sec.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);

		StringBuilder sbEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbEBOMSubPartID = new StringBuilder();
		StringBuilder sbEBOMSubPartType = new StringBuilder();
		
		//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
		//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- START
		StringBuilder sbGrossWeight = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder();
		StringBuilder sbNSPCG = new StringBuilder();
		//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- END
		//Added by Subhajit for Req 46464 - Start
		StringBuilder sbRelRestriction = new StringBuilder();
		StringBuilder sbRelRestrictionComment = new StringBuilder();
		//Added by Subhajit for Req 46464 - End
		//SPEC 10.29.2020 modifed: brought from if clause and made as global--START
		String sUserlicense = sec.getUserLicense();
		
		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		
				
		//SPEC 10.29.2020 modifed: brought from if clause and made as global--END
		

		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();
			//Added by Subhajit for Req 46464 - Start
			String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
			String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
			//Added by Subhajit for Req 46464 - End
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
			String sParentId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID)));
			String sParentName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME)));
			String sParentRevision = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV)));
			String sParentType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE)));
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
			String sId =(String)objectMap.get(ConstantsUtil.SELECT_ID);
			String sName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
			String sRevision =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
			String sIntendedMarket =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
			String spgChg =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
			String sFN =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			String sTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			String sType =(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
			String sTupName =(String)objectMap.get(ConstantsUtil.TUPNAME);
			
			String sSubstitute=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
			sSubstitute = sSubstitute.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String sQty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			String sBuom =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			String sComments=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			String sCurrent =(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
			String sStage =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			String sRD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
			sRD = sRD.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
			sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
			String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
			String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
			String strNetWUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
			String strNetWet =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
			//SPEC: Release SR18x.6. Added by Dominic for Defect 41392 on Date 24/03/2021 --START
			if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE))
			{
				if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART)||sType.equalsIgnoreCase(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART))
					sCurrent=ConstantsUtil.RELEASED;
			}
			//SPEC: Release SR18x.6. Added by Dominic for Defect 41392 on Date 24/03/2021 --END
			//SPEC: <01.28.2021>: Modified for Defect :38227 by Sumit --START
			//Commented by Ketan for Req. no. 47950
			/*if(null!=strNetWet && strNetWet.isEmpty() || strNetWet.equalsIgnoreCase("0.0")) {
				//strNetWet="0.0";
				strNetWet="0";
			}*/
			//SPEC: <01.28.2021>: Modified for Defect :38227 by Sumit --ENDS
			String strLoss =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
			//SPEC: <01.28.2021>: Added for Defect :38227 by Sumit --START
			//Commented by Ketan for Req. no. 47950
			/*if(null!=strLoss && strLoss.isEmpty() || strLoss.equalsIgnoreCase("0.0")) {
				strLoss="0";
			}*/
			//SPEC: <01.28.2021>: Added for Defect :38227 by Sumit --ENDS
			// Guna Modified for Defect 37304  18x.5.2 Release -- START
			//String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
			String strMF =ConstantsUtil.EMPTY_STRING;
			String strPhysicalId =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
			if(UIUtil.isNotNullAndNotEmpty(strPhysicalId)){
				strMF =util.getIdFromPhysicalIdFunction(context, strPhysicalId);
			}
			// Guna Modified for Defect 37304  18x.5.2 Release -- END
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			
			//String strAlt =(String)objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
			//strAlt = strAlt.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
			String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
			strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strAltID = util.checkAlternateHasAccess(context,objectMap);	
			String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
			strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			String strNet =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
			//SPEC: <01.28.2021>: Added for Defect :38227 by Sumit --START
			//Commented by Ketan for Req. no. 47950
			/*if(null!=strNet && strNet.isEmpty() || strNet.equalsIgnoreCase("0.0")) {
				strNet="0";
			}*/
			//SPEC: <01.28.2021>: Added for Defect :38227 by Sumit --ENDS
			//String strOSPD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
			// Added by Jwala for defect 44296 - START
			String strOSPD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_BOM);
			String strDenUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
			// Added by Jwala for defect 44296 - END
			
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
			strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
			strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
			String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			
			String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- START
			String sGrossWeight= (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			String sGrossWeightUOM = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			String sNSPCG = (String) objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNSPCG);
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- END
			boolean showData = true;
			boolean bHasOwnership = true;
			if(util.isModificatinRequired())
		    {
				//SPEC: <10.20.2020>: Commented for req 18x.5 ## -- START
				/*boolean bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);*/
				//SPEC: <10.20.2020>: Commented for req 18x.5 ## -- START
				
				//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
				/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")) {
					String sFormulaPropagate = util.getFormulaPropagate(context, sId);
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}

				}else {
					bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);
				}*/
				//Added by Ganesh Start
				bHasOwnership = util.checkHasAccess(context, null, sId);
				//Added by Ganesh Stop
		
				if(!bHasOwnership)
				{
					//SPEC: Release SR18x.6. Modified by Dominic on Date 16/03/2021 --START
					//sTitle = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					//sFN    = ConstantsUtil.NO_ACCESS;
					//sSubstitute = ConstantsUtil.NO_ACCESS;
					//sComments = ConstantsUtil.NO_ACCESS;
					//sStage = ConstantsUtil.NO_ACCESS;
					//sRDOC = ConstantsUtil.NO_ACCESS;
					//strMinqty = ConstantsUtil.NO_ACCESS;
					//strMaxqty = ConstantsUtil.NO_ACCESS;
					//strNetWUOM = ConstantsUtil.NO_ACCESS;
					//strNetWet = ConstantsUtil.NO_ACCESS;
					//strLoss = ConstantsUtil.NO_ACCESS;
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//strAlt = ConstantsUtil.NO_ACCESS;
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					//strNet = ConstantsUtil.NO_ACCESS;
					//strOSPD = ConstantsUtil.NO_ACCESS;
					//strDenUOM = ConstantsUtil.NO_ACCESS;
					//sTupName = ConstantsUtil.NO_ACCESS;
					//sIntendedMarket = ConstantsUtil.NO_ACCESS;
					//strMF = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
					//sBuom = ConstantsUtil.NO_ACCESS;
					//sCurrent = ConstantsUtil.NO_ACCESS;
					//sQty = ConstantsUtil.NO_ACCESS;
					//sRevision = ConstantsUtil.NO_ACCESS;
					//SPEC: Release SR18x.6. Modified by Dominic on Date 16/03/2021 --END
					
					}
			
			  /* }else if(sec.isStaffAUGUser())
			   {
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}
					
					if(!showData){
						sTitle = ConstantsUtil.NO_ACCESS;
						sFN    = ConstantsUtil.NO_ACCESS;
						sSubstitute = ConstantsUtil.NO_ACCESS;
						sComments = ConstantsUtil.NO_ACCESS;
						sStage = ConstantsUtil.NO_ACCESS;
						sRDOC = ConstantsUtil.NO_ACCESS;
						strMinqty = ConstantsUtil.NO_ACCESS;
						strMaxqty = ConstantsUtil.NO_ACCESS;
						strNetWUOM = ConstantsUtil.NO_ACCESS;
						strNetWet = ConstantsUtil.NO_ACCESS;
						strLoss = ConstantsUtil.NO_ACCESS;
						strAlt = ConstantsUtil.NO_ACCESS;
						strNet = ConstantsUtil.NO_ACCESS;
						strOSPD = ConstantsUtil.NO_ACCESS;
						strDenUOM = ConstantsUtil.NO_ACCESS;
						sTupName = ConstantsUtil.NO_ACCESS;
						sIntendedMarket = ConstantsUtil.NO_ACCESS;
						strMF = ConstantsUtil.NO_ACCESS;
						spgChg = ConstantsUtil.NO_ACCESS;
						sId = ConstantsUtil.NO_ACCESS;
					}
				}else
				{
					if(slHIRTypes.contains(sType))
					{
						String sFormulaClassif =strClassFied;
						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}
						//Verifying the classified Item of object against with User profile
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}	
					if(!showData){
					sTitle = ConstantsUtil.NO_ACCESS;
					sFN    = ConstantsUtil.NO_ACCESS;
					sSubstitute = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
					sStage = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					strMinqty = ConstantsUtil.NO_ACCESS;
					strMaxqty = ConstantsUtil.NO_ACCESS;
					strNetWUOM = ConstantsUtil.NO_ACCESS;
					strNetWet = ConstantsUtil.NO_ACCESS;
					strLoss = ConstantsUtil.NO_ACCESS;
					strAlt = ConstantsUtil.NO_ACCESS;
					strNet = ConstantsUtil.NO_ACCESS;
					strOSPD = ConstantsUtil.NO_ACCESS;
					strDenUOM = ConstantsUtil.NO_ACCESS;
					sTupName = ConstantsUtil.NO_ACCESS;
					sIntendedMarket = ConstantsUtil.NO_ACCESS;
					strMF = ConstantsUtil.NO_ACCESS;
					spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
				}*/
			//SPEC: <01.28.2021>: Added for Defect :38227 by Sumit --START
		    } else {
			
				//Added by Ganesh Start
				showData=util.checkHasAccess(context, null, sId);
		    }
			//SPEC: <01.28.2021>: Added for Defect :38227 by Sumit --ENDS
				if(!showData)
				{
					spgChg = ConstantsUtil.NO_ACCESS;
					sId = ConstantsUtil.NO_ACCESS;
					//SPEC: <01.28.2021>: Added for Defect :38227 by Sumit --START
					/*if(strNetWet.equalsIgnoreCase("0")) {
						strNetWet="0.0";
					}
					if(strLoss.equalsIgnoreCase("0")) {
						strLoss="0.0";
					}
					if(strNet.equalsIgnoreCase("0")) {
						strNet="0.0";
					}*/
					//SPEC: <01.28.2021>: Added for Defect :38227 by Sumit --ENDS
				}
				//Added by Ganesh stop
			//SPEC: <01.28.2021>: Commented for Defect :38227 by Sumit --START
			//}
			//SPEC: <01.28.2021>: Commented for Defect :38227 by Sumit --ENDS
				
				//Added by Ketan for Internal Defect -- START
				boolean bHasOwnershipParent = false;
				boolean showDataParent = false;
				if(validator.isNotNullOrEmpty(sParentId)) {
					if(util.isModificatinRequired())
					{
						bHasOwnershipParent = util.checkHasAccess(context, null, sParentId);

						if(!bHasOwnershipParent)
						{
							sParentId = ConstantsUtil.NO_ACCESS;
						}
					}else if(sec.isStaffAUGUser())
					{
						showDataParent = util.checkHasAccess(context, null, sParentId);
					}else
					{	
						showDataParent = util.checkHasAccess(context, null, sParentId);
					}

					if(!util.isModificatinRequired()) {
						if(!showDataParent){
							sParentId = ConstantsUtil.NO_ACCESS;
						}
					}
					
				}
				//Added by Ketan for Internal Defect -- END
			sType = util.mapType(sType);
			sParentType = util.mapType(sParentType);
			// Security req -33193 HIR Components Attributes to Show
			util.formatData(sbEBOMType,sType);
			util.formatData(sbEBOMName,sName);
			util.formatData(sbEBOMRev,sRevision);
			util.formatData(sbEBOMQTY,sQty);
			util.formatData(sbEBOMBuom,sBuom);
			util.formatData(sbEBOMState,sCurrent);
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
			util.formatData(sbEBOMParentId,sParentId);
			util.formatData(sbEBOMParentName,sParentName);
			util.formatData(sbEBOMParentRevision,sParentRevision);
			util.formatData(sbEBOMParentType,sParentType);
			//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
			util.formatData(sbIntended,sIntendedMarket);
			util.formatData(sbEBOMId,sId);
			util.formatData(sbEBOMChg,spgChg);
			util.formatData(sbEBOMFN,sFN);
			util.formatData(sbEBOMTitle,sTitle);
			util.formatData(sbEBOMCommnts,sComments);
			util.formatData(sbEBOMStage,sStage);
			util.formatData(sbEBOMRDOC,sRDOC);
			util.formatData(sbMinqty,strMinqty);
			util.formatData(sbMaxqty,strMaxqty);
			util.formatData(sbNetWUOM,strNetWUOM);
			util.formatData(sbNetWet,strNetWet);
			util.formatData(sbLoss,strLoss);
			util.formatData(sbMF,strMF);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
			//util.formatData(sbAlt,strAlt);
			util.formatData(sbAltName,strAltName);
			util.formatData(sbAltID,strAltID);
			util.formatData(sbAltType,strAltType);
			// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
			util.formatData(sbNet,strNet);
			util.formatData(sbOSPD,strOSPD);
			util.formatData(sbDen,strDenUOM);

			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
			util.formatData(sbEBOMSubstitutePart, strSubPart);
			util.formatData(sbEBOMSubPartID, strSubPartId);
			util.formatData(sbEBOMSubPartType, strSubPartType);
			//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
			
			if(null!=sTupName && !sTupName.isEmpty()) {
				util.formatData(sbEBOMTupName,sTupName);
			}
			//SPEC: <13.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- START	
			util.formatData(sbRefDes, sRD);
			//SPEC: <13.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- END
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- START
			util.formatData(sbGrossWeight, sGrossWeight);
			util.formatData(sbGrossWeightUOM, sGrossWeightUOM);
			util.formatData(sbNSPCG, sNSPCG);
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- END
			//Added by Subhajit for Req 46464 - Start
			util.formatData(sbRelRestriction, sRelRestriction);
			util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
			//Added by Subhajit for Req 46464 - End
		}
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
		mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.REV, sbEBOMRev.toString());
		mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
		mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
		mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
		mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
		
		//SPEC: <10.11.2020>: Commented for req 18x.5 ## -- START
		/*
		mpEBOMResult.put(ConstantsUtil.MIN, sbMinqty.toString());
		mpEBOMResult.put(ConstantsUtil.MAX, sbMaxqty.toString());
		*/
		// Guna Modified for Defect 37304  18x.5.2 Release -- START
		mpEBOMResult.put(ConstantsUtil.MATERIALFUNCTION, sbMF.toString());
		// Guna Modified for Defect 37304  18x.5.2 Release -- END
		//SPEC: <10.11.2020>: Commented for req 18x.5 ## -- END
		
		
		mpEBOMResult.put(ConstantsUtil.NETWEIGHTUOM, sbNetWUOM.toString());
		mpEBOMResult.put(ConstantsUtil.NETWEIGHT, sbNetWet.toString());
		mpEBOMResult.put(ConstantsUtil.LOSS, sbLoss.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//mpEBOMResult.put(ConstantsUtil.ALT, sbAlt.toString());
		mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
		mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
		mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		mpEBOMResult.put(ConstantsUtil.NET, sbNet.toString());
		mpEBOMResult.put(ConstantsUtil.OSPD, sbOSPD.toString());
		mpEBOMResult.put(ConstantsUtil.DUOM, sbDen.toString());
		mpEBOMResult.put(ConstantsUtil.I, sbIntended.toString());
		
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
		//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END

		//SPEC: <13.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- START				
		mpEBOMResult.put(ConstantsUtilIRM.REFDESC, sbRefDes.toString());			
		//SPEC: <13.10.2021>: Guna Added for Internal Defect  Dev 18x.6.0.2   -- END
		if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
			mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
		}
		//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- START
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeight.toString());
		mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
		mpEBOMResult.put(ConstantsUtilIRM.NSPCG, sbNSPCG.toString());
		//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- END
		
		//Added by Subhajit for Req 46464 - Start
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
		mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
		//Added by Subhajit for Req 46464 - End
		
		return util.filterMapList(mpEBOMResult);
	}

	
	/**
	 * Method Name 			: getSubstitute
	 * Method Description 	: 
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> getSubstitute(Context context,MapList mapList) 
	{
		StringValidatorUtil validator = new StringValidatorUtil();

		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentRev = new StringBuilder();
		StringBuilder sbEBOMParentTitle = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMRefDoc= new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMSubType= new StringBuilder();
		StringBuilder sbEBOMEffectDate= new StringBuilder();
		StringBuilder sbEBOMUntilDate= new StringBuilder();
		StringBuilder sbEBOMCobNum= new StringBuilder();
		StringBuilder sbEBOMChildRev= new StringBuilder();
		StringBuilder sbIntended= new StringBuilder();
		StringBuilder sbMF= new StringBuilder();
		StringBuilder sbEBOMRDOC= new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		
		try{
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				String sChildExists=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
				if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)){
					String sParentName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
					String sParentRev =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sParentTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sChildName =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
					String sChildRev=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
					String sCombinationNum=(String)objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
					String sChildTitle =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
					String sChildType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
					
					//Modified for Defect# 37591 -- START
					//String sSUBType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
					String sSUBType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
					//Modified for Defect# 37591 -- END
					
					String sQTY =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
					String sBASEUOM =(String)objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
					String sEffectvityDate =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
					String sUntilDate=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
					String sRefDoc =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
					String sComments=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
					String sIntendedMarket =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
					String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
					String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
					sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);

					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
					
					if(util.isModificatinRequired())
					{
						SecurityService sec = new SecurityService();
						String sComp = sec.getUserCauthorities();
						StringList slUserOwnership=util.filterOwnerShip(sComp);

						boolean bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sChildId);
				
					
						if(!bHasOwnership)
						{
							sParentID = ConstantsUtil.NO_ACCESS;
							sChildId = ConstantsUtil.NO_ACCESS;
							sParentName    = ConstantsUtil.NO_ACCESS;
							sParentRev = ConstantsUtil.NO_ACCESS;
							sComments = ConstantsUtil.NO_ACCESS;
							sParentTitle = ConstantsUtil.NO_ACCESS;
							sChildName = ConstantsUtil.NO_ACCESS;
							sCombinationNum = ConstantsUtil.NO_ACCESS;
							sChildTitle = ConstantsUtil.NO_ACCESS;
							sSUBType = ConstantsUtil.NO_ACCESS;
							sEffectvityDate = ConstantsUtil.NO_ACCESS;
							sUntilDate = ConstantsUtil.NO_ACCESS;
							sRefDoc = ConstantsUtil.NO_ACCESS;
							sIntendedMarket = ConstantsUtil.NO_ACCESS;
							sIntendedMarket = ConstantsUtil.NO_ACCESS;
							sComments = ConstantsUtil.NO_ACCESS;
							sOC = ConstantsUtil.NO_ACCESS;
							sBASEUOM = ConstantsUtil.NO_ACCESS;
							sQTY = ConstantsUtil.NO_ACCESS;
							
					    }
					}	

					StringList slHIRTypes = new StringList();

					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

					if(slHIRTypes.contains(sChildType)){
						sParentID = ConstantsUtil.NO_ACCESS;
						sChildId = ConstantsUtil.NO_ACCESS;
						sParentName    = ConstantsUtil.NO_ACCESS;
						sParentRev = ConstantsUtil.NO_ACCESS;
						sComments = ConstantsUtil.NO_ACCESS;
						sParentTitle = ConstantsUtil.NO_ACCESS;
						sChildName = ConstantsUtil.NO_ACCESS;
						sCombinationNum = ConstantsUtil.NO_ACCESS;
						sChildTitle = ConstantsUtil.NO_ACCESS;
						sSUBType = ConstantsUtil.NO_ACCESS;
						sEffectvityDate = ConstantsUtil.NO_ACCESS;
						sUntilDate = ConstantsUtil.NO_ACCESS;
						sRefDoc = ConstantsUtil.NO_ACCESS;
						sIntendedMarket = ConstantsUtil.NO_ACCESS;
						sIntendedMarket = ConstantsUtil.NO_ACCESS;
						sComments = ConstantsUtil.NO_ACCESS;
						sOC = ConstantsUtil.NO_ACCESS;
						
					}
					sChildType = util.mapType(sChildType);


					util.formatData(sbEBOMParentId,sParentID);
					util.formatData(sbEBOMId,sChildId);
					util.formatData(sbEBOMParentName,sParentName);
					util.formatData(sbEBOMParentRev,sParentRev);
					util.formatData(sbEBOMParentTitle,sParentTitle);
					util.formatData(sbEBOMName,sChildName);
					util.formatData(sbEBOMChildRev,sChildRev);
					util.formatData(sbEBOMCobNum,sCombinationNum);
					util.formatData(sbEBOMTitle,sChildTitle);
					util.formatData(sbEBOMType,sChildType);
					util.formatData(sbEBOMSubType,sSUBType);
					util.formatData(sbEBOMQTY,sQTY);
					util.formatData(sbEBOMBuom,sBASEUOM);
					util.formatData(sbEBOMEffectDate,sEffectvityDate);
					util.formatData(sbEBOMUntilDate,sUntilDate);
					util.formatData(sbEBOMRefDoc,sRefDoc);
					util.formatData(sbEBOMCommnts,sComments);
					util.formatData(sbIntended,sIntendedMarket);
					util.formatData(sbMF,strMF);
					util.formatData(sbEBOMRDOC,sOC);

				}
			}
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
			mpEBOMResult.put(ConstantsUtil.INTENDEDFUNCTION, sbIntended.toString());
			mpEBOMResult.put(ConstantsUtil.OC, sbEBOMRDOC.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());

			//return filterMapList(mpEBOMResult);

		}catch(Exception ex){
			LOGGER.error("Error from FabricatedPartBO:  getSubstitute "+ex);
			return new HashMap();
		}
		return mpEBOMResult;
	}

	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	: 
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		try
		{
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sMFR     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			String sTrN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sMINWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT));
			String sQTY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT));
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			String sPCID    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTINDUSTRIAL));
			String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));


			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMINWt);								  
			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.POST_INDUSTRIAL,sPCID);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);


		}catch(Exception e){

			LOGGER.error("Error from FabricatedPartBO:  getSubstances "+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}


	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList(){
		
		StringList slMultiSelects = new StringList();

		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_NAME);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_CURRENT);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_TITLE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_TYPE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_SAPSUBTYPE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_BOMQTY);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_BUOM);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE);
		slMultiSelects.add(ConstantsUtil.STR_FORMULA_INGR_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.STR_SAPBOM__OCP);

		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE); 
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED); 

		slMultiSelects.add(ConstantsUtil.SELECT_COS_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		slMultiSelects.add(ConstantsUtil.COMP_NAME);
		slMultiSelects.add(ConstantsUtil.COMP_TYPE);
		slMultiSelects.add(ConstantsUtil.COMP_ID);
		slMultiSelects.add(ConstantsUtil.COMP_DESC);
		slMultiSelects.add(ConstantsUtil.COMP_TITLE);
		slMultiSelects.add(ConstantsUtil.COMP_QTY);
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT);
		slMultiSelects.add(ConstantsUtil.COMP_METALENVCLASS);
		slMultiSelects.add(ConstantsUtil.COMP_POSTCONSUMER);
		slMultiSelects.add(ConstantsUtil.COMP_MANUF);
		slMultiSelects.add(ConstantsUtil.COMP_COMENT);
		slMultiSelects.add(ConstantsUtil.COMP_MARKETNAME);
		slMultiSelects.add(ConstantsUtil.COMP_SEQUENCE);
		slMultiSelects.add(ConstantsUtil.COMP_MATELAYER);
		slMultiSelects.add(ConstantsUtil.COMP_POSTINDUSTRIAL);
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_CURRENT);
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);


		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
		
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		
		
		return slMultiSelects;

	}

	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	:
	 */
	public  void removeMultiList(){

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_SAPTYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_SAPSUBTYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_BOMQTY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_BUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_ORIGINATING_SOURCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SAPBOM__OCP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMULA_INGR_RELEASE_PHASE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);


		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_METALENVCLASS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_POSTCONSUMER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MANUF);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_COMENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MARKETNAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SEQUENCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MATELAYER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_POSTINDUSTRIAL);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);

		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END

	}

	
	//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
	/**
	 * Method Name 			: getSapBOMasFed
	 * Method Description 	: It will return the connected SAP BOM
	 * @param context
	 * @param sID
	 * @return
	 */
	public Map getSapBOMasFed(Context context ,String sID){
		
		CalculateBOM clBom = new CalculateBOM();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mapSapBomAsFedResult = new HashMap();
		
		SecurityService sct = new SecurityService();
		boolean isStaffAUg = sct.isStaffAUGUser();
		
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbSapType = new StringBuilder();
		StringBuilder sbSpecSubType = new StringBuilder();
		StringBuilder sbSpecGroup = new StringBuilder();
		StringBuilder sbBOMQTY = new StringBuilder();
		StringBuilder sbBuom = new StringBuilder();
		StringBuilder sbComnt = new StringBuilder();
		StringBuilder sbSAPDesc = new StringBuilder();
		StringBuilder sbAuthorized = new StringBuilder();
		StringBuilder sbAuthorizedToUse = new StringBuilder();
		StringBuilder sbAuthorizedToProduce = new StringBuilder();
		StringBuilder sbOC = new StringBuilder();
		StringBuilder sbTUType = new StringBuilder();
		StringBuilder sbTUName = new StringBuilder();
		StringBuilder sbTUId = new StringBuilder();
		
		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

		
		try
		{
			ArrayList alSapBom = performDataReadFromEnovia(context,sID);
			MapList ml = getTableData(context,alSapBom);
			
			sbSpecSubType = clBom.getSpecificationSubtype(context ,ml);
			Iterator objectListItr = ml.iterator();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sId =(String)objectMap.get(ConstantsUtil.MAP_KEY_ID);
				String sName =(String)objectMap.get(ConstantsUtil.NAME);
				String sTitle =(String)objectMap.get(ConstantsUtil.DESCRIPTION);
				String sType =(String)objectMap.get(ConstantsUtil.TYPE);
				String sSapType =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPTYPE);
				String sSpecGroup =(String)objectMap.get(ConstantsUtil.MAP_KEY_SUBSTITUTE);
				String sQty =(String)objectMap.get(ConstantsUtil.MAP_KEY_BOMQTY);
				String sBuom =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPUOM);
				String strClassFied = (String)objectMap.get(ConstantsUtil.SECURITY);
				String strControlClass = (String)objectMap.get(ConstantsUtil.OBJECTSECURITYCLASS);
				String strComment = (String)objectMap.get(ConstantsUtil.ATTRIBUTE_COMMENT);
				String strSAPDesc = (String)objectMap.get(ConstantsUtil.SAPDESCRIPTION);
				/*String strAuthorized = (String)objectMap.get(ConstantsUtil.AUTHORIZED);
				String strAuthorizedToUse = (String)objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE);
				String strAuthorizedToProduce = (String)objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE);
				String strOC = (String)objectMap.get(ConstantsUtil.OC);*/
				
				String strOC = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.OC));
				 String strAuthorizedToProduce =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE));
				String strAuthorizedToUse = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE));
				String strAuthorized = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZED));
				
				strOC = strOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				
				String strTUType = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_TYPE);
				String strTUName = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_NAME);
				String strTUId = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_ID);
				
				
				
				boolean bHasOwnership = false;
				String sUserlicense = sct.getUserLicense();
				String sFormulaPropagate = sId;
				
				if(sType.equals(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT) || sType.equals(ConstantsUtil.TYPE_FORMULA_CARD))
				{
					sId =ConstantsUtil.NO_ACCESS;
					sTitle =ConstantsUtil.NO_ACCESS;
					//sSapType =ConstantsUtil.NO_ACCESS;
					//sSpecGroup =ConstantsUtil.NO_ACCESS;
					//sQty =ConstantsUtil.NO_ACCESS;
					//sBuom =ConstantsUtil.NO_ACCESS;
					//strComment=ConstantsUtil.NO_ACCESS;
					
					strAuthorized=ConstantsUtil.NO_ACCESS;
					strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
					strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
					
					
			}
			else
			{
				if(util.isModificatinRequired())
				{
					//commented by Ganesh for security impl---->start
					/*SecurityService sec = new SecurityService();
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);

					//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sId);
					}
					
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}*/
					//commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl---->start
					bHasOwnership = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl---->end
					if(!bHasOwnership)
					{
						sTitle = ConstantsUtil.NO_ACCESS;
						sId =ConstantsUtil.NO_ACCESS;
						sTitle =ConstantsUtil.NO_ACCESS;
						sSapType =ConstantsUtil.NO_ACCESS;
						sSpecGroup =ConstantsUtil.NO_ACCESS;
						sQty =ConstantsUtil.NO_ACCESS;
						sBuom =ConstantsUtil.NO_ACCESS;
						strComment=ConstantsUtil.NO_ACCESS;
						strSAPDesc=ConstantsUtil.NO_ACCESS;
						strAuthorized=ConstantsUtil.NO_ACCESS;
						strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
						strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
						strOC=ConstantsUtil.NO_ACCESS;
					}
				}else if(isStaffAUg)
				{
					boolean showData = true;
					//commented by Ganesh for security impl---->start
					/*String sFormulaClassif =strControlClass;
					
						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}
						
						showData= util.checkLicenses(sUserlicense,sFormulaClassif);*/
					//commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl---->start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl---->end
						if(!showData)
						{
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}
							
						}
					
				}else{
					
					boolean showData = true;
					//commented by Ganesh for security impl---->start
					/*if(slHIRTypes.contains(sType) )
					{
						String sFormulaClassif =strClassFied;
						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) 
						{
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}
							showData= util.checkLicenses(sUserlicense,sFormulaClassif);
					}*/
					//commented by Ganesh for security impl---->start
					//modified by Ganesh for security impl---->start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl---->start

						if(!showData){
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}
							
						}

				}
			}	
				util.formatData(sbId,sId);
				util.formatData(sbName,sName);
				util.formatData(sbTitle,sTitle);
				util.formatData(sbType,util.mapType(sType));
				util.formatData(sbSapType,sSapType);
				util.formatData(sbSpecGroup,sSpecGroup);
				util.formatData(sbBOMQTY,sQty);
				util.formatData(sbBuom,sBuom);
				util.formatData(sbComnt,strComment);
				util.formatData(sbSAPDesc,strSAPDesc);
				util.formatData(sbAuthorized,strAuthorized);
				util.formatData(sbAuthorizedToUse,strAuthorizedToUse);
				util.formatData(sbAuthorizedToProduce,strAuthorizedToProduce);
				util.formatData(sbOC,strOC);

				util.formatData(sbTUType,strTUType);
				util.formatData(sbTUName,strTUName);
				util.formatData(sbTUId,strTUId);
				
			}

			mapSapBomAsFedResult.put(ConstantsUtil.NAME, sbName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.ID, sbId.toString());
			//mapSapBomAsFedResult.put(ConstantsUtil.TITLE, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TYPE, sbType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPTYPE, sbSapType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONGROUP, sbSpecGroup.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BOMQUANTITY, sbBOMQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbBuom.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.COMMENTS, sbComnt.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPDESCRIPTION, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZED, sbAuthorized.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOUSE, sbAuthorizedToUse.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, sbAuthorizedToProduce.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.OC,sbOC.toString());
			
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_NAME,sbTUName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_TYPE,sbTUType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_ID,sbTUId.toString());

		}catch(Exception e){
			LOGGER.error("Exception in program FabricatedPartBO :getSapBOMasFed ");
		}
		return mapSapBomAsFedResult;
	}
	
	
	/**
	 * Method Name 			: performDataReadFromEnovia
	 * Method Description 	: 
	 * @param context
	 * @param sPartObjectID
	 * @return
	 * @throws Exception
	 */
	public synchronized ArrayList performDataReadFromEnovia(Context context,String sPartObjectID) throws Exception {

		Map 	mapPartDetails				= new HashMap();

		ArrayList alPartRelatedObjects 		= new ArrayList();
		String strSpecSubType = DomainConstants.EMPTY_STRING;
		String strFormulationType = DomainConstants.EMPTY_STRING;

		StringValidatorUtil BusinessUtil= new StringValidatorUtil();
		CalculateBOM clBom = new CalculateBOM();
		
		try {

			if(BusinessUtil.isNotNullOrEmpty(sPartObjectID)){

				DomainObject doPart = DomainObject.newInstance(context,sPartObjectID);
				StringList slBusSelect = new StringList(12);
				slBusSelect.add(DomainConstants.SELECT_TYPE);
				slBusSelect.add(DomainConstants.SELECT_NAME);
				slBusSelect.add(DomainConstants.SELECT_ID);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slBusSelect.add(ConstantsUtil.STR_IPCLASS);
				
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slBusSelect.add("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
				slBusSelect.add("next.id");
				mapPartDetails = doPart.getInfo(context, slBusSelect);

				if(null != mapPartDetails && mapPartDetails.size()>0) {

					strSpecSubType = (String) mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					Object OFormulationType = (Object)mapPartDetails.get("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);

					StringList slFormulationType = new StringList();

					if (null != OFormulationType) {
						if (OFormulationType instanceof StringList) {
							slFormulationType = (StringList) OFormulationType;
						} else if (OFormulationType instanceof String) {
							slFormulationType.add(OFormulationType.toString());
						}
					}								
					if(clBom.doProdUsageCheckForeDelivery(context,mapPartDetails)) {

						String strPartType	=	(String)mapPartDetails.get(DomainConstants.SELECT_TYPE);

						if(BusinessUtil.isNotNullOrEmpty(strPartType)) {

							if(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equalsIgnoreCase(strPartType)) {

								alPartRelatedObjects = clBom.getPartObjectsFromEBOM(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_FORMULATIONPART.equalsIgnoreCase(strPartType) && !slFormulationType.isEmpty() && !slFormulationType.contains(ConstantsUtil.THIRD_PARTY_FORMULA) ) {
								alPartRelatedObjects = clBom.getObjectsForFOPFromFormulaIngredient(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(strPartType) || (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strPartType) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromIntermediateBOM(context,sPartObjectID);
							} else if(ConstantsUtil.TYPE_FABRICATEDPART.equalsIgnoreCase(strPartType) ||   ConstantsUtil.TYPE_INTERMEDIATEPRODUCTPART.equalsIgnoreCase(strPartType) || ((ConstantsUtil.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strPartType)) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromBOM(context,sPartObjectID);
							}
						}
					}
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return alPartRelatedObjects;
	}
	
	
	/**
	 * Method Name 			: getTableData
	 * Method Description 	: 
	 * @param context
	 * @param alPartObjectsWithGroupAndQty
	 * @return
	 * @throws Exception
	 */
	public MapList getTableData(Context context, ArrayList alPartObjectsWithGroupAndQty) throws Exception {
		MapList mpReturnList = new MapList();
		boolean isContextPushed = false;
		int OBJECT_ID = 27;
		int SUBSTITUTE_FLAG = 14;
		int QUANTITY = 10;
		int FC_MIN_QTY = 23;
		int FC_MAX_QTY = 25;
		int SORT_STRING = 13;
		int TUP_ID = 28;
		int OPT_COMPONENT = 29;
		
		//SPEC 11/05/2020 added for defect:37077 ##--START
		int INDEX_TPU_TYPE = 34;
		int INDEX_TPU_NAME = 35;
		//SPEC 11/05/2020 added for defect: 37077##--END
		
		try {
			StringList slPartSelect = new StringList(7);
			slPartSelect.addElement(DomainConstants.SELECT_NAME);
			slPartSelect.addElement(DomainConstants.SELECT_TYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slPartSelect.addElement(ConstantsUtil.STR_IPCLASS);
			slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
			//slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
			
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_IPCLASS);
			ContextUtil.pushContext(context);
			isContextPushed = true;
			if(null != alPartObjectsWithGroupAndQty) 
			{
				int alsize=alPartObjectsWithGroupAndQty.size();
				StringValidatorUtil validator = new StringValidatorUtil();
				String strObjID = null;
				String strSubstitute=null;
				String strBOMQuantity = null;
				String strMin = null;
				String strMax = null;
				String strPosInd = null;
				String strObjectType = null;
				String strSAPUOM = null;
				String strSAPType = null;
				String strPGCSSType = null;
				String strTUPObjID = null;
				String strIPClass = null;
				String strOptComponent = null;
				//String strAuthorized = null;
				//String strOC = null;
				//String strAuthorizedToUse = null;
				//String strAuthorizedToProduce = null;
				String strTransportUnit = null;
				DomainObject domObject = null;
				Map mpPartObjectInfo = null;
				int COMMENT = 30;
				String strComment = DomainConstants.EMPTY_STRING; 
				String strName = DomainConstants.EMPTY_STRING; 
				String strDescription = DomainConstants.EMPTY_STRING; 
				
				String strTUPObjName = DomainConstants.EMPTY_STRING; 
				String strTUPObjType = DomainConstants.EMPTY_STRING;
				
				//SPEC 11/05/2020 added for defect: ##--START
				CalculateBOM clBom = new CalculateBOM();
				
				StringList slRelSelect = new StringList();
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
				//SPEC 11/05/2020 added for defect: ##--END
				
				HashMap hmTemp = null;
				for (int i=0; i<alsize; i++) {
					String [] satemp = (String[]) alPartObjectsWithGroupAndQty.get(i);
					strObjID = satemp[OBJECT_ID];
					strSubstitute= satemp[SUBSTITUTE_FLAG];
					strBOMQuantity = satemp[QUANTITY];
					strMin = satemp[FC_MIN_QTY];
					strMax = satemp[FC_MAX_QTY];
					strPosInd = satemp[SORT_STRING];
					strTUPObjID = satemp[TUP_ID];
					String sqty = satemp[ConstantsUtil.INDEX_TARGET] ;	
					strOptComponent = satemp[OPT_COMPONENT];
					domObject = DomainObject.newInstance(context,strObjID);
					mpPartObjectInfo = domObject.getInfo(context, slPartSelect);
					strObjectType = (String)mpPartObjectInfo.get(DomainConstants.SELECT_TYPE);
					strSAPUOM = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					strSAPType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
					strPGCSSType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
					strComment = satemp[COMMENT];
					strName = (String)mpPartObjectInfo.get(DomainConstants.SELECT_NAME);
					strDescription = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					/*strAuthorized = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					strAuthorizedToUse = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					strAuthorizedToProduce = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));*/
					strTransportUnit = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					//strOC = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
					
					//SPEC 11/05/2020 added for defect: 37077##--START
					strTUPObjID = validator.getStringEquivalentForStringList(satemp[TUP_ID]);
					strTUPObjName = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_NAME]);
					strTUPObjType = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_TYPE]);
					//SPEC 11/05/2020 added for defect: 37077##--END
					
					boolean bTUPAccess=false;
					if(UIUtil.isNotNullAndNotEmpty(strTUPObjID)){
					 bTUPAccess = clBom.checkHasAccess(context,strTUPObjID);
					}
					
					if(!bTUPAccess){
						strTUPObjID=ConstantsUtil.NO_ACCESS;
					}
					
					strIPClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.STR_IPCLASS));
					String strIPControlClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
				
					
					//SPEC 11/05/2020 added for defect: ##--START
					MapList mlParentPlantList = clBom.getConnectedPlantList(context, strObjID, slRelSelect, null);
					
					
					StringList	slAVPlantList = new StringList();
					StringList	slAUPlantList = new StringList();
					StringList	slAPPlantList = new StringList();
					if(mlParentPlantList!=null && mlParentPlantList.size()>0)
					{
						for(int ip=0;ip<mlParentPlantList.size();ip++)
						{
							Map mapSAPBOMComponent = (Map)mlParentPlantList.get(ip);
							String	sAVAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
							String	sAUAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
							String	sAPAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
							String	sSAPBOMComponentPlantName = (String)mapSAPBOMComponent.get(DomainObject.SELECT_NAME);
							
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAVAttributeValue) && strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAVPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAUAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAUPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAPAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAPPlantList.add(sSAPBOMComponentPlantName);
							}
						}
					}
					
					String	strAVPlantList = DomainConstants.EMPTY_STRING;
					String	strAUPlantList = DomainConstants.EMPTY_STRING;
					String	strAPPlantList = DomainConstants.EMPTY_STRING;
					
					if(slAVPlantList!= null && slAVPlantList.size()>0)
					{
						strAVPlantList = FrameworkUtil.join(slAVPlantList, "&&&");
					}

					if(slAUPlantList!= null && slAUPlantList.size()>0)
					{
						strAUPlantList = FrameworkUtil.join(slAUPlantList, "&&&");
					}
					
					if(slAPPlantList!= null && slAPPlantList.size()>0)
					{
						strAPPlantList = FrameworkUtil.join(slAPPlantList, "&&&");
					}
					
					//SPEC 11/05/2020 added for defect: ##--END
					
					
					
					hmTemp = new  HashMap();
					hmTemp.put("id",strObjID);  
					hmTemp.put("type",strObjectType);  
					hmTemp.put("substitute",strSubstitute);
					hmTemp.put("BOMQty",strBOMQuantity);
					hmTemp.put("Min",strMin);
					hmTemp.put("Max",strMax);
					hmTemp.put("PosInd",strPosInd);
					hmTemp.put("SAPUOM",strSAPUOM);
					hmTemp.put("SAPType",strSAPType);
					hmTemp.put("SSType",strPGCSSType);
					hmTemp.put("dispId", strObjID);
					hmTemp.put("OptComponent", strOptComponent);
					hmTemp.put(ConstantsUtil.ATTRIBUTE_COMMENT, strComment);
					hmTemp.put(DomainConstants.SELECT_NAME, strName);
					hmTemp.put(DomainConstants.SELECT_DESCRIPTION, strDescription);
					hmTemp.put(ConstantsUtil.SECURITY, strIPClass);
					hmTemp.put(ConstantsUtil.OBJECTSECURITYCLASS, strIPControlClass);
					hmTemp.put(ConstantsUtil.AUTHORIZED, strAVPlantList);
					hmTemp.put(ConstantsUtil.OC, strOptComponent);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOUSE, strAUPlantList);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, strAPPlantList);
					
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_TYPE, strTUPObjType);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_NAME, strTUPObjName);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_ID, strTUPObjID);
					
					mpReturnList.add(hmTemp);
				}
			}
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(isContextPushed) {
				ContextUtil.popContext(context);
				isContextPushed = false;
			}
		}
		return mpReturnList;
	}
	
	
	/**
     * Method Name 			: parseSubstitute
     * Method Description 	: Fetching "Substitute" details
     * @param context
     * @param mapList
     * @return
     * @throws Exception 
     */
	
	public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
	{
    	StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
    	try {
			Iterator objectListItr = mapList.iterator();
			StringBuilder sbEBOMName = new StringBuilder();
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentRev = new StringBuilder();
			StringBuilder sbEBOMParentTitle = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			StringBuilder sbEBOMRefDoc= new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMCommnts = new StringBuilder();
			StringBuilder sbEBOMSubType= new StringBuilder();
			StringBuilder sbEBOMEffectDate= new StringBuilder();
			StringBuilder sbEBOMUntilDate= new StringBuilder();
			StringBuilder sbEBOMCobNum= new StringBuilder();
			StringBuilder sbEBOMChildRev= new StringBuilder();
			StringBuilder sbEBOMRevRelDt= new StringBuilder();
			StringBuilder sbEBOMSubFor= new StringBuilder();
			StringBuilder sbEBOMParentType = new StringBuilder();
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			StringBuilder sbEBOMChg = new StringBuilder();
			StringBuilder sbEBOMSFSubType= new StringBuilder();
			StringBuilder sbMF= new StringBuilder();
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			//Added by Subhajit for Req 46464 - Start
			StringBuilder sbRelRestriction= new StringBuilder();
			StringBuilder sbRelRestrictionComment= new StringBuilder();
			//Added by Subhajit for Req 46464 - End
			
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --START
			String sUserProjectLicense = sct.getProjectLicenses();
			//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --END
			//SPEC: <02.04.2021>: Sumit Added for Defect :38706 ## --START
			FormulaCardBO fcBOM = new FormulaCardBO();
			//SPEC: <02.04.2021>: Sumit Added for Defect :38706 ## --END
						
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				boolean showData = false;
				boolean bHasOwnership=false;
				boolean bProjectLicense=false;
				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
				if(null!=objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {
	
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
					//String
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
						//SPEC: Release SR18x.6. Added by Dominic for Defect 41395 on Date 23/03/2021 --START
						//SPEC: Release SR18x.6.0.1 Modified by Dominic  on Date 18/05/2021 --START
						String sParentType=util.mapType((String)objectMap.get(ConstantsUtil.SELECT_TYPE));
						//String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						//SPEC: Release SR18x.6.0.1 Modified by Dominic  on Date 18/05/2021 --END
						//SPEC: Release SR18x.6. Added by Dominic for Defect 41395 on Date 23/03/2021 --END
						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
					
						String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
						
						//SPEC: <11.19.2020>: Chandra Modified for Defect :37446 ## --START
						//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
						boolean bChildHasAccess =util.checkHasAccess(context, sct.getUserType(),sChildId);
						//SPEC: <11.19.2020>: Chandra Modified for Defect :37446 ## --END
						
						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- START
						sReleaseDate =validator.DateFormatter(sReleaseDate);
						//SPEC: <10.27.2020>: Added for req 18x.5 ## -- END
						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						
						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//	String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						String sChildTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
						
						String sChildType =util.mapType((validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE))));
						//Chandra
						//Modified for Defect# 37591 -- START
						//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
						String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
						//Modified for Defect# 37591 -- END
						
						String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
						String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
						//SPEC: Release SR18x.6.0 - Modified for FAB  by Dominic on Date 11/03/2021 -- START
						//String sEffectvityDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY)));
						//String sUntilDate=validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
						String sEffectvityDate =validator.effectvityDateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY)));
						String sUntilDate=validator.effectvityDateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
						//SPEC: <02.09.2021>: Added for Defect #38706 by Sumit -- START
						//sUntilDate =validator.DateFormatter(sUntilDate);
						//sEffectvityDate =validator.DateFormatter(sEffectvityDate);
						//SPEC: <02.09.2021>: Added for Defect #38706 by Sumi -- END
						//SPEC: Release SR18x.6.0 - Modified for FAB  by Dominic on Date 11/03/2021 -- END
						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END
						//SPEC: 09/04/2021: Modified for 18x.6 Defect #37300 by Bala-- START
						//String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
						String sOC =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
						//SPEC: 09/04/2021: Modified for 18x.6 Defect #37300 by Bala-- END
						String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
						
						//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --START
						String strProjSecClass = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME));
						//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --END
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
						//Added by Subhajit for Req 46464 - Start
						String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
						String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
						//Added by Subhajit for Req 46464 - End
						//SPEC: <20.11.2020>: Modified for Defect 37440 Spec Reader 1.0.1 --  Start 
						//String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY);
						//String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY);
						//String strRF =(String)objectMap.get("from[pgPDTemplatestopgPLIReportedFunction].to.name");
						String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MIN_QUANTITY);
						String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MAX_QUANTITY);
						String strRF =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RF));
						//SPEC: <20.11.2020>: Modified for Defect 37440 Spec Reader 1.0.1 --  End
						String sFunction =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
						
						//SPEC: Release SR18x.5.2: Amman Added for Defect :34059 ## -- START
						//SPEC: <17.05.2021>: Guna Modified for Internal Defect Dev 18x.6.0.1   -- START
  						/*if (null != validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)) && ("Raw Material").equals(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)))) 
  						{       
  							sSUBType="Raw";  
  						}*/
						
  						 if (null != validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)) && ("pgRawMaterial").equals(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)))) 
  						{   
  							//SPEC: <17.05.2021>: Guna Modified for Internal Defect Dev 18x.6.0.1   -- END
  							sSUBType="Raw";  
  						}
  						else if (null != validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)) && ("pgPackingMaterial").equals(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)))) 
  						{
  							sSUBType="Packaging";
  						} 
  						/*else if("Packaging Material Part".equalsIgnoreCase(sChildType)) {
  							sSUBType="Packaging";
  						}*/
  						else 
  						{
  							//sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
  							sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
  						}
 						
  					     if ("pgFinishedProduct".equals(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE))))
  					     {
  							if("".equals(sSUBType)){
  								sSUBType="Finished Product";
  							}
  							else if("FWIP-Finished Work in Process".equals(sSUBType)) {
  								sSUBType="FWIP-Finished Work in Process";		
  							}
  							else if("Purchased Subassembly".equals(sSUBType)){
  								sSUBType="Purchased Subassembly";
  							}
  							else if("Purchased and/or Produced Subassembly".equals(sSUBType)){
  								sSUBType="Purchased and/or Produced Subassembly";	
  							}				
  					     }
  					    //SPEC: <02.04.2021>: Sumit Added/Modified for Defect :38706 ## --START
  						sSFSubType = fcBOM.getSpecificationSubtypeForSubstitutes(context, sParentID, sParentType);
					     /*if (null != (String)objectMap.get(ConstantsUtil.SELECT_TYPE) && ("Raw Material").equals((String)objectMap.get(ConstantsUtil.SELECT_TYPE))) 
						 {       
					    	sSFSubType="Raw";  
					     }
					     else if (null != (String)objectMap.get(ConstantsUtil.SELECT_TYPE) && ("pgRawMaterial").equals((String)objectMap.get(ConstantsUtil.SELECT_TYPE))) 
						 {       
					    	sSFSubType="Raw";  
					     }
					     else if (null != (String)objectMap.get(ConstantsUtil.SELECT_TYPE) && ("pgPackingMaterial").equals((String)objectMap.get(ConstantsUtil.SELECT_TYPE))) 
						 {
					    	sSFSubType="Packaging";
					     } 
					    /*else if("Packaging Material Part".equalsIgnoreCase(sParentType)) {
					   	sSFSubType="Packaging";
					    }
							
					    else {
					    	sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
					     }
					    
					     if ("pgFinishedProduct".equals((String)objectMap.get(ConstantsUtil.SELECT_TYPE)))
						{
							if("".equals(sSFSubType)){
								sSFSubType="Finished Product";
							}
							else if("FWIP-Finished Work in Process".equals(sSFSubType)) {
								sSFSubType="FWIP-Finished Work in Process";		
							}
							else if("Purchased Subassembly".equals(sSFSubType)){
								sSFSubType="Purchased Subassembly";
							}
							else if("Purchased and/or Produced Subassembly".equals(sSFSubType)){
								sSFSubType="Purchased and/or Produced Subassembly";	
							}				
						}*/
						//SPEC: <02.04.2021>: Sumit Added/Modified for Defect :38706 ## --ENDS
  					    //SPEC: Release SR18x.5.2: Amman Added for Defect :34059 ## -- END
						
						if(!bChildHasAccess) {
							sChildId    = ConstantsUtil.NO_ACCESS;
							sChg = ConstantsUtil.NO_ACCESS;
							//sChildTitle = ConstantsUtil.NO_ACCESS;
							//sChildRev = ConstantsUtil.NO_ACCESS;
						}
						
						if(util.isModificatinRequired())
						{
							//commented by Ganesh for security impl---->start
							/*SecurityService sec = new SecurityService();
							String sComp = sec.getUserCauthorities();
							StringList slUserOwnership=util.filterOwnerShip(sComp);
							
							String sFormulaPropagate = sParentID;
							if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
							}
							
							if(!sFormulaPropagate.isEmpty()) {
								bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
							}*/
							//commented by Ganesh for security impl---->end
							//modified by Ganesh for security impl---->start
							bHasOwnership = util.checkHasAccess(context, null, sParentID);
							//modified by Ganesh for security impl---->end
							
							if(!bHasOwnership)
							{
								//SPEC: Release SR18x.6.0.1 - Added for Defect #43176 by Madhan on Date June/04/2021 -- START				
								//sParentType = ConstantsUtil.NO_ACCESS;
								sParentID = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								//sChildId    = ConstantsUtil.NO_ACCESS;
								//sParentName = ConstantsUtil.NO_ACCESS;
								//sParentRev = ConstantsUtil.NO_ACCESS;
								//sParentTitle = ConstantsUtil.NO_ACCESS;
								//sCombinationNum = ConstantsUtil.NO_ACCESS;
								//sChildTitle = ConstantsUtil.NO_ACCESS;
								//sSUBType = ConstantsUtil.NO_ACCESS;
								//sEffectvityDate = ConstantsUtil.NO_ACCESS;
								//sRevRelease = ConstantsUtil.NO_ACCESS;
								//sUntilDate = ConstantsUtil.NO_ACCESS;
								//sRDOC = ConstantsUtil.NO_ACCESS;
								//sQTY = ConstantsUtil.NO_ACCESS;
								//sBASEUOM = ConstantsUtil.NO_ACCESS;
								//sChildRev = ConstantsUtil.NO_ACCESS;
								//sSFSubType = ConstantsUtil.NO_ACCESS;
								//strRF = ConstantsUtil.NO_ACCESS;
								//sFunction = ConstantsUtil.NO_ACCESS;
								//strMinqty = ConstantsUtil.NO_ACCESS;
								//strMaxqty = ConstantsUtil.NO_ACCESS;
								//SPEC: Release SR18x.6.0.1 - Added for Defect #43176 by Madhan on Date June/04/2021 -- END	
						    }
							//SPEC: Release SR18x.6.0.1 Modified by Dominic  on Date 18/05/2021 --START
							else
							{
								showData= true;
							}
							//SPEC: Release SR18x.6.0.1 Modified by Dominic  on Date 18/05/2021 --END
						}/*else if(sct.isStaffAUGUser()) 
						{
							
							if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}
							//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --START	
							if (showData && UIUtil.isNotNullAndNotEmpty(strProjSecClass.trim())) 
							{
								//For Project License Check
								bProjectLicense=util.checkLicenses(sUserProjectLicense,strProjSecClass);
								
								if (bProjectLicense)
								{ 
									showData= true;
								}else
								{
									showData= false;
								}
							}
							else if (showData && UIUtil.isNullOrEmpty(strProjSecClass.trim()))
							{
								showData= true;
							}else
							{
								showData= false;
							}
							
						//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --END
						}else {
							StringList slHIRTypes = new StringList();
							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
							slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
							slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
							
							if(slHIRTypes.contains(sParentType)) 
							{
								if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
								}
								//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --START	
								if (showData && UIUtil.isNotNullAndNotEmpty(strProjSecClass.trim())) 
								{
									//For Project License Check
									bProjectLicense=util.checkLicenses(sUserProjectLicense,strProjSecClass);
									
									if (bProjectLicense)
									{ 
										showData= true;
									}else
									{
										showData= false;
									}
								}
								else if (showData && UIUtil.isNullOrEmpty(strProjSecClass.trim()))
								{
									showData= true;
								}else
								{
									showData= false;
								}
								
							}else {
								showData=true;
							}
							//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --END
						}*///commented by Ganesh for security impl--->start

						//SPEC: Release 18x.5.2: Amman commented ## -- START
						//It is  temporarily blocked 
						/*
						if (sParentType.equals(ConstantsUtil.TYPE_FORMULA_CARD) ||sParentType.equals(ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY)) {
							sParentID=ConstantsUtil.NO_ACCESS;
						}	
						*/
						//SPEC: Release 18x.5.2: Amman commented ## -- END
						//modified by Ganesh for security impl--->start
						else {
							showData  = util.checkHasAccess(context, null, sParentID);
						}
						//modified by Ganesh for security impl--->end
						if(!showData){
							sParentID = ConstantsUtil.NO_ACCESS;
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
							//sChildId    = ConstantsUtil.NO_ACCESS;
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
							
							/*sParentType = ConstantsUtil.NO_ACCESS;
							sParentID = ConstantsUtil.NO_ACCESS;
							sChildId    = ConstantsUtil.NO_ACCESS;
							//sParentName = ConstantsUtil.NO_ACCESS;
							//sParentRev = ConstantsUtil.NO_ACCESS;
							sParentTitle = ConstantsUtil.NO_ACCESS;
							sCombinationNum = ConstantsUtil.NO_ACCESS;
							sChildTitle = ConstantsUtil.NO_ACCESS;
							sSUBType = ConstantsUtil.NO_ACCESS;
							sEffectvityDate = ConstantsUtil.NO_ACCESS;
							sRevRelease = ConstantsUtil.NO_ACCESS;
							sUntilDate = ConstantsUtil.NO_ACCESS;
							sRDOC = ConstantsUtil.NO_ACCESS;
							sComments = ConstantsUtil.NO_ACCESS;*/
						}
					
						sChildType = util.mapType(sChildType);
	
						util.formatData(sbEBOMName,sChildName);
						util.formatData(sbEBOMType,sChildType);
						util.formatData(sbEBOMQTY,sQTY);
						util.formatData(sbEBOMBuom,sBASEUOM);
						util.formatData(sbEBOMChildRev,sChildRev);
						
						util.formatData(sbEBOMParentType,sParentType);
						util.formatData(sbEBOMParentId,sParentID);
						util.formatData(sbEBOMId,sChildId);
						util.formatData(sbEBOMParentName,sParentName);
						util.formatData(sbEBOMParentRev,sParentRev);
						util.formatData(sbEBOMParentTitle,sParentTitle);
						util.formatData(sbEBOMCobNum,sCombinationNum);
						util.formatData(sbEBOMTitle,sChildTitle);
						util.formatData(sbEBOMSubType,sSUBType);
						util.formatData(sbEBOMRevRelDt,sRevRelease);
						util.formatData(sbEBOMEffectDate,sEffectvityDate);
						util.formatData(sbEBOMUntilDate,sUntilDate);
						util.formatData(sbEBOMRefDoc,sRDOC);
						util.formatData(sbEBOMCommnts,sComments);
						util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
						
						//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
						util.formatData(sbEBOMChg,sChg);
						util.formatData(sbEBOMSFSubType,sSFSubType);
						//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
						//Added by Subhajit for Req 46464 - Start
						util.formatData(sbRelRestriction,sRelRestriction);
						util.formatData(sbRelRestrictionComment,sRelRestrictionComment);
						//Added by Subhajit for Req 46464 - End
					//}
					}
				} else {
					//StringList
					//SPEC: Release SR18x.6. Added by Dominic for Defect 41395 on Date 23/03/2021 --START
					//String sParentType=util.mapType((String)objectMap.get(ConstantsUtil.SELECT_TYPE));
					String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					//SPEC: Release SR18x.6. Added by Dominic for Defect 41395 on Date 23/03/2021 --END
					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					
					//SPEC: Release 18x.5.2: Amman commented ## -- START
					//It is  temporarily blocked 
					/*
					if (sParentType.equals(ConstantsUtil.TYPE_FORMULA_CARD) ||sParentType.equals(ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY)) {
						sParentID=ConstantsUtil.NO_ACCESS;
					}
					*/
					//SPEC: Release 18x.5.2: Amman commented ## -- END
					
					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
					//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
					//String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
					String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					
					String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
					
					//SPEC: <11.19.2020>: Chandra Commented for Defect :37446 ## --START
					//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
					String strProjSecClass = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME));
					//SPEC: <11.19.2020>: Chandra Commented for Defect :37446 ## --END
					//commented by Ganesh for security impl---->start
					/*if(util.isModificatinRequired())
					{
						SecurityService sec = new SecurityService();
						String sComp = sec.getUserCauthorities();
						StringList slUserOwnership=util.filterOwnerShip(sComp);
						
						String sFormulaPropagate = sParentID;
						if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
						}
						
						if(!sFormulaPropagate.isEmpty()) {
							bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
						}
						
						if(bHasOwnership)
						{
							showData=true;
					    }
					}else if(sct.isStaffAUGUser()) 
					{
						if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) 
						{
							String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else
						{
							showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
						}
						//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --START	
						if (showData && UIUtil.isNotNullAndNotEmpty(strProjSecClass.trim())) 
						{
							//For Project License Check
							bProjectLicense=util.checkLicenses(sUserProjectLicense,strProjSecClass);
							
							if (bProjectLicense)
							{ 
								showData= true;
							}else
							{
								showData= false;
							}
						}
						else if (showData && UIUtil.isNullOrEmpty(strProjSecClass.trim()))
						{
							showData= true;
						}else
						{
							showData= false;
						}
						
					//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --END
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
							slHIRTypes.add(ConstantsUtil.STRING_TYPE_APP);
							
						if(slHIRTypes.contains(sParentType)) {
							if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART))
							{
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
							
							//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --START	
							if (showData && UIUtil.isNotNullAndNotEmpty(strProjSecClass.trim())) 
							{
								//For Project License Check
								bProjectLicense=util.checkLicenses(sUserProjectLicense,strProjSecClass);
								
								if (bProjectLicense)
								{ 
									showData= true;
								}else
								{
									showData= false;
								}
							}
							else if (showData && UIUtil.isNullOrEmpty(strProjSecClass.trim()))
							{
								showData= true;
							}else
							{
								showData= false;
							}
							
						//SPEC: <11.19.2020>: Chandra Added for Defect :37446 ## --END
							
						}else {
							showData=true;
						}
						
					}*/
					//commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl---->start
					showData = util.checkHasAccess(context, null, sParentID);
					//modified by Ganesh for security impl---->end
					
					
					//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
					
					String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
					String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						//SPEC: 09/04/2021: Modified for 18x.6 Defect #37300 by Bala-- START
						String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT));
						sOC=sOC.replace("| ", "|");
						StringList slOC =FrameworkUtil.split(sOC, "|");
						String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
						slRefDoc=slRefDoc.replace("| ", "|");
						StringList slRefDocList =FrameworkUtil.split(slRefDoc, "|");
						//SPEC: 09/04/2021: Modified for 18x.6 Defect #37300 by Bala-- END
						
						//SPEC: 06/04/2021: Modified for 18x.6.0.1 Defect #43003 by Sanjeeva-- START
						int intRefDocSize = slRefDocList.size();
						int intslOCSize = slOC.size();
						//SPEC: 06/04/2021: Modified for 18x.6.0.1 Defect #43003 by Sanjeeva-- END
						
						for(int i =0; i<slChildId.size(); i++) 
						{
							String sEachChildId = slChildId.getElement(i);
							
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
//							DomainObject doEachChild = new DomainObject(sEachChildId);
//							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//							StringList slSelect = new StringList();
//							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//							Map mpIpClass = doEachChild.getInfo(context, slSelect);
//							StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//							StringsIpClass = doEachChild.getInfo(contexts"to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
//							DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
							
							StringList slChildType =util.MapSlType((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
							/*if(!showData) {
								sEachChildId=ConstantsUtil.NO_ACCESS;
							}*/
							//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
							
							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							
							//Modified for Defect# 37591 -- START
							//StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41395 on Date 23/03/2021 --START
							//StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41395 on Date 23/03/2021 --END
							//Modified for Defect# 37591 -- END
							//Added by Subhajit for Req 46464 - Start
							StringList slRelRestriction =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR));
  							StringList slRelRestrictionComment =(StringList)(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC));
							//String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR) : ConstantsUtil.EMPTY_STRING;
							//String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC))?(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC) : ConstantsUtil.EMPTY_STRING;
							//Added by Subhajit for Req 46464 - End
							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
							StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
							StringList slEffectvityDate = (StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							//SPEC: 09/04/2021: Modified for 18x.6 Defect #37300 by Bala-- START
							//String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
							//String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
							
							//SPEC: 06/04/2021: Modified for 18x.6.0.1 Defect #43003 by Sanjeeva-- START
							if (intRefDocSize > i) {
							slRefDoc=(String)slRefDocList.get(i);
							}
							if (intslOCSize > i) {
								sOC=(String)slOC.get(i);								
							}
							//SPEC: 06/04/2021: Modified for 18x.6.0.1 Defect #43003 by Sanjeeva-- END
							
							//SPEC: 09/04/2021: Modified for 18x.6 Defect #37300 by Bala-- START
							
							sOC = util.replaceSpecialSymbols(sOC);
							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
							
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41395 on Date 26/03/2021 --START
							if(slRefDoc.equalsIgnoreCase(ConstantsUtil.SYMBL_PIPE+" "))
							{
								slRefDoc=ConstantsUtil.EMPTY_STRING;
							}
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41395 on Date 26/03/2021 --END
							String sRDOC = slRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
							
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
							
							boolean bChildHasAccess =util.checkHasAccess(context, sct.getUserType(),sEachChildId);
							
							//SPEC: 21/11/2020: Added by Jwala for the Defect #37528 -- START
							//StringList sSFSubType = (StringList) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							String sSFSubType = (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
  							
							//SPEC: Release SR18x.5.2: Amman Added for Defect :34059 ## -- START
							String sChildSubType =ConstantsUtil.EMPTY_STRING;
							if(null!=slSUBType)
							{
								sChildSubType=slSUBType.get(i);
								String sChildType=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE)).get(i);
								
		 					     if (null != sChildType && ("Raw Material").equals(sChildType)) 
		 						 {       
		 					    	sChildSubType="Raw";  
		 					     }
		 					     else if (null != sChildType && ("pgRawMaterial").equals(sChildType)) 
								 {       
		 					    	sChildSubType="Raw";  
							     }
		 					     else if (null != sChildType && ("pgPackingMaterial").equals(sChildType)) 
		 						 {
		 					    	sChildSubType="Packaging";
		 					     } 
		 					    /*else if("Packaging Material Part".equalsIgnoreCase(sChildType)) {
		 					    	sChildSubType="Packaging";
		 	 					    }*/
		 					    else {
		 					    	sChildSubType =sChildSubType;
		 					     }
		 					    
		 					     if ("pgFinishedProduct".equals(sChildType))
		  						{
		  							if("".equals(sChildSubType)){
		  							sChildSubType="Finished Product";
		  							}
		  							else if("FWIP-Finished Work in Process".equals(sChildSubType)) {
		  							sChildSubType="FWIP-Finished Work in Process";		
		  							}
		  							else if("Purchased Subassembly".equals(sChildSubType)){
		  							sChildSubType="Purchased Subassembly";
		  							}
		  							else if("Purchased and/or Produced Subassembly".equals(sChildSubType)){
		  							sChildSubType="Purchased and/or Produced Subassembly";	
		  							}				
		  						}
							}
							
							//SPEC: <02.04.2021>: Sumit Added/Modified for Defect :38706 ## --START
							//SPEC: Release SR18x.6.0 - Added for Defect 41395  by Dominic on Date 23/03/2021 -- START
							if(!sParentType.equals(ConstantsUtil.TYPE_FORMULATIONPART))
							//SPEC: Release SR18x.6.0 - Added for Defect 41395  by Dominic on Date 23/03/2021 -- END
							sSFSubType = fcBOM.getSpecificationSubtypeForSubstitutes(context, sParentID, sParentType);
							
							
								/*if (null != (String)objectMap.get(ConstantsUtil.SELECT_TYPE) && ("Raw Material").equals((String)objectMap.get(ConstantsUtil.SELECT_TYPE))) 
								 {       
							    	sSFSubType="Raw";  
							     }
								     else if (null != (String)objectMap.get(ConstantsUtil.SELECT_TYPE) && ("pgRawMaterial").equals((String)objectMap.get(ConstantsUtil.SELECT_TYPE))) 
								 {       
								    	sSFSubType="Raw";  
							     }
							     else if (null != (String)objectMap.get(ConstantsUtil.SELECT_TYPE) && ("pgPackingMaterial").equals((String)objectMap.get(ConstantsUtil.SELECT_TYPE))) 
								 {
							    	sSFSubType="Packaging";
							     } 
							   /*else if("Packaging Material Part".equalsIgnoreCase(sParentType)) {
			 					   	sSFSubType="Packaging";
			 					    }
							   else {
								 sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
	 					     }
								
							  if ("pgFinishedProduct".equals((String)objectMap.get(ConstantsUtil.SELECT_TYPE)))
								{
									if("".equals(sSFSubType)){
										sSFSubType="Finished Product";
									}
									else if("FWIP-Finished Work in Process".equals(sSFSubType)) {
										sSFSubType="FWIP-Finished Work in Process";		
									}
									else if("Purchased Subassembly".equals(sSFSubType)){
										sSFSubType="Purchased Subassembly";
									}
									else if("Purchased and/or Produced Subassembly".equals(sSFSubType)){
										sSFSubType="Purchased and/or Produced Subassembly";	
									}				
								}*/
							//SPEC: <02.04.2021>: Sumit Added/Modified for Defect :38706 ## --ENDS
							  	//SPEC: Release SR18x.5.2: Amman Added for Defect :34059 ## -- END
							
							
							String sChildType = util.mapType(slChildType.get(i));
							//SPEC: 21/11/2020: Added by Jwala for the Defect #37528 -- START
  							//StringList sFunction =(StringList)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE_MATERIAL_FUNCTION);
							StringList sFunction =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION);
							//SPEC: 21/11/2020: Added by Jwala for the Defect #37528 -- END
							
							if(bChildHasAccess) {
								
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMId,sEachChildId);
								util.formatData(sbEBOMTitle,slChildTitle.get(i));
								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
  								util.formatData(sbEBOMChg,sChg.get(i));
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
  								//Added by Ketan for Req. no. 46464 - START
  								util.formatData(sbRelRestriction,slRelRestriction.get(i));
  								util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
  								//Added by Ketan for Req. no. 46464 - END
							}
							else
							{
								util.formatData(sbEBOMName,slChildName.get(i));
								util.formatData(sbEBOMType,sChildType);
								util.formatData(sbEBOMChildRev,slChildRev.get(i));
								util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMTitle,slChildTitle.get(i));
								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
  								/*util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);*/
  								util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
  								//Added by Ketan for Req. no. 46464 - START
  								util.formatData(sbRelRestriction,slRelRestriction.get(i));
  								util.formatData(sbRelRestrictionComment,slRelRestrictionComment.get(i));
  								//Added by Ketan for Req. no. 46464 - END
							}
							
							//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
							
							if(showData) {
								util.formatData(sbEBOMQTY,slQTY.get(i));
								util.formatData(sbEBOMBuom,slBASEUOM.get(i));
								util.formatData(sbEBOMParentType,sParentType);
								util.formatData(sbEBOMParentId,sParentID);
								util.formatData(sbEBOMParentName,sParentName);
								util.formatData(sbEBOMParentRev,sParentRev);
								util.formatData(sbEBOMParentTitle,sParentTitle);
								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
								
								//util.formatData(sbEBOMSubType,slSUBType.get(i));
								util.formatData(sbEBOMSubType,sChildSubType);
								
								util.formatData(sbEBOMRevRelDt,sRevRelease);
								//SPEC: <02.09.2021>: Added for Defect #38706 by Sumit -- START
								//util.formatData(sbEBOMEffectDate,slEffectvityDate.get(i));
								//util.formatData(sbEBOMUntilDate,slUntilDate.get(i));
								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
								util.formatData(sbEBOMUntilDate,validator.DateFormatter(slUntilDate.get(i)));
								//SPEC: <02.09.2021>: Added for Defect #38706 by Sumi -- END
								util.formatData(sbEBOMRefDoc,sRDOC);
								util.formatData(sbEBOMCommnts,slComments.get(i));
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								util.formatData(sbEBOMSFSubType,sSFSubType);
								util.formatData(sbMF,sFunction.get(i));
								
							}else {
								util.formatData(sbEBOMQTY,slQTY.get(i));
								util.formatData(sbEBOMBuom,slBASEUOM.get(i));
								util.formatData(sbEBOMParentType,sParentType);
								util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbEBOMParentName,sParentName);
								util.formatData(sbEBOMParentRev,sParentRev);
								util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								util.formatData(sbEBOMParentTitle,sParentTitle);
								util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
  								
								//util.formatData(sbEBOMSubType,slSUBType.get(i));
								util.formatData(sbEBOMSubType,sChildSubType);
								
  								util.formatData(sbEBOMRevRelDt,sRevRelease);
  								util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
  								util.formatData(sbEBOMUntilDate,validator.DateFormatter((slUntilDate.get(i))));
  								util.formatData(sbEBOMRefDoc,sRDOC);
  								util.formatData(sbEBOMCommnts,slComments.get(i));
  								util.formatData(sbEBOMSFSubType,sSFSubType);
  								util.formatData(sbMF,sFunction.get(i));

  								//SPEC: 11/19/2020: Added for 18x.5 DEV -- END
  								
							}
						}
					}
				}
				}

			}
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
			mpEBOMResult.put(ConstantsUtil.FUNCTION, sbMF.toString());
			//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
			
			//Added by Subhajit for Req 46464 - Start
			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
			mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
			//Added by Subhajit for Req 46464 - End
    	}catch(Exception e) {
    		//SPEC: 06/04/2021: Modified for 18x.6.0.1 Defect #43003 by Sanjeeva-- START
    		//LOGGER.info("EXCEPTION IN APPBO : parseSubstitute: "+e.getMessage());
    		LOGGER.error("EXCEPTION IN FAB BO : parseSubstitute: "+e.getMessage());
    		//SPEC: 06/04/2021: Modified for 18x.6.0.1 Defect #43003 by Sanjeeva-- END
    	}
		return util.filterMapList(mpEBOMResult);
	}
	
    
    
    /**
     * Method Name 			: updatePartSpec
     * Method Description 	:
     * @param context
     * @param objectMap
     * @return
     */
    public Map updatePartSpec(Context context, Map objectMap) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpPartSpecs = new HashMap<String, String>();
		try {

			String sID = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ID))
					? (String) objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
					String sType = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_TYPE))
							? (String) objectMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

							mpPartSpecs = getPartSpecifications(context, sType, sID);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FAB BO Method :updatePartSpec " + e);
			return new HashMap();

		}
		return util.filterMapList(mpPartSpecs);
	}
    
    
    /**
     * Method Name 			: getPartSpecifications
     * Method Description 	:
     * @param context
     * @param sParentType
     * @param sObjectID
     * @return
     * @throws Exception
     */
    public HashMap getPartSpecifications(Context context, String sParentType, String sObjectID) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbRevision = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		boolean showData = false;
		
		String sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION+","+ConstantsUtil.REL_PG_INHERITED_CAD_SPEC;
		
		if (sParentType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
			sRelationPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION + ","
					+ ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLIST;
		}

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context, sRelationPattern, ConstantsUtil.SYMBL_ASTERISK,
					slPartSpecSelects, null, false, true, (short) 1, sWhere, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doAPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strRevision = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_REVISION));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strAutocadClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				/*if (util.isModificatinRequired()) {
					if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) {

						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteString(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							}

						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

						}

					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = util.updateReferences(context, strId);
								LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
									String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

								}
							}
						}else
						{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);

						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					}

				} else {
					if(sct.isStaffAUGUser()) {
						
						if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else if("ArtiosCAD Component".equalsIgnoreCase(strType)){
							showData=util.checkInternalUserAcess(sUserlicense,strAutocadClassFied);
						}else{
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}
					}else {
						StringList slHIRTypes = new StringList();
						slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
						slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
						slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
						slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
						
						if(slHIRTypes.contains(strType)) {
							showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						}else {
							showData=true;
						}
						
					}
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						//temporary fix to prevent users from downloading a Physical product(VPMReference)
						if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
							sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
						}else {
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

					}

					
				}*/
				// Added by Ganesh Start
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}
				
				//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
				showData=util.checkHasAccess(context, sUserType, strId);
				if (showData) {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
					String strTitle = validator.getStringEquivalentForSubstituteString(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
					String strOrig = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
					sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
					//temporary fix to prevent users from downloading a Physical product(VPMReference)
					if(strType.equals(ConstantsUtil.TYPE_VPMREFERENCE)) {
						sbId.append("").append(ConstantsUtil.SYMBL_PIPE);
					}else {
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --START
						/*String strState = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));*/
						//sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
						//SPEC: <12.21.2020>: Chandra Added for Defect :37569 ## --END
					}
				} else {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					sbRevision.append(strRevision).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

				}//Added by Ganesh stop


			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.REVISION, sbRevision.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.DESCRIPTION, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			if (!sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGANCILLARYPACKAGINGMATERIALPART)) {
				mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
				mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			}

		} catch (FrameworkException e) {
			LOGGER.error("Exception in FAB BO getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}
    
    
    /**
     * Method Name 			: getMasterSpecs
     * Method Description 	:
     * @param context
     * @param sObjectId
     * @return
     */
    public Map<String, String> getMasterSpecs(Context context, String sObjectId) {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String, String> mpMasterSpecs = new HashMap<String, String>();
		String sMasterObjectId = ConstantsUtil.EMPTY_STRING;
		String sMasterObjectClassfiedItem = ConstantsUtil.EMPTY_STRING;
		try {
			DomainObject domChild = new DomainObject(sObjectId);
			sMasterObjectId = domChild.getInfo(context, ConstantsUtil.STR_MASTER_ID);

			StringList slSelects = new StringList();
			slSelects.add(ConstantsUtil.STR_MASTER_ID);
			slSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			Map mp = domChild.getInfo(context, slSelects);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			domChild.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			if (!mp.isEmpty()) {
				sMasterObjectId = validator.getStringEquivalentForStringList(mp.get(ConstantsUtil.STR_MASTER_ID));
				sMasterObjectClassfiedItem = validator
						.getStringEquivalentForStringList(mp.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME));
			}

			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);

			if (UIUtil.isNotNullAndNotEmpty(sMasterObjectId)) {
				mpMasterSpecs = getMasterPartSpecifications(context, sMasterObjectId, sMasterObjectClassfiedItem);
			} else {
				return new HashMap();
			}
		} catch (Exception e) {
			LOGGER.error("Exception in Program : FAB BO Method :getMasterSpecs " + e);
			return new HashMap();
		}
		return mpMasterSpecs;
	}
    
    
    /**
     * Method Name 			: getMasterPartSpecifications
     * Method Description 	:
     * @param context
     * @param sObjectID
     * @param sMasterObjectClassfiedItem
     * @return
     * @throws Exception
     */
    public Map<String, String> getMasterPartSpecifications(Context context, String sObjectID,
			String sMasterObjectClassfiedItem) throws Exception {
		HashMap mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringBuilder sbOwnership = new StringBuilder();
		StringBuilder sbMasterPartName = new StringBuilder();
		StringBuilder sbMasterPartId = new StringBuilder();
		StringBuilder sbMasterPartType = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();

		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		if (util.isModificatinRequired()) {
			sWhere = "current!=Obsolete";
		}
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		StringList slPartSpecSelects = BusObjectAttribUtil.getPartSpecSelects();
		MapList mapList;
		try {
			DomainObject doAPP = new DomainObject(sObjectID);

			mapList = doAPP.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_PART_SPECIFICATION + "," + ConstantsUtil.REL_PG_INHERITED_CAD_SPEC,
					ConstantsUtil.SYMBL_ASTERISK, slPartSpecSelects, null, false, true, (short) 1, sWhere,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			for (int j = 0; j < mapList.size(); j++) {
				Map mpEachObj = (Map) mapList.get(j);
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				// Split this to get only the companies
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String sIpClass =validator.getStringEquivalentForStringList((mpEachObj.get(ConstantsUtil.STR_IPCLASS)));
				String strAutocadClassFied = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_AUTOCADIPCLASS));
				String strSource = util.getSource(context, strId);
				String strSubType = util.UpdateSpecSubType(context, strId);
				
				String strMasterPartName = ConstantsUtil.EMPTY_STRING;
				String strMasterPart = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.strPARTSPEC));
				strMasterPartName = doAPP.getName();
				String strMasterPartType = doAPP.getType(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doAPP.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				String strMasterPartId = sObjectID;
				if(strMasterPart.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART)) {
					strMasterPartName = strMasterPart;
				}
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;

				if (util.isModificatinRequired())
				{
					//commented by Ganesh for security impl---->start

					/*if (strType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)) 
					{
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								String strState = validator
										.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
								sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
								String strTitle = validator.getStringEquivalentForSubstituteString(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
								sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
								String strOrig = validator.getStringEquivalentForStringList(
										mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
								sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							}
						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else if (strType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)
							|| strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE)) {
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) 
						{
							if (!ConstantsUtil.SYMBL_YES.equalsIgnoreCase(strSharable)) {
								sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
								sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
								sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							} else {
								String sView = util.updateReferences(context, strId);
								LOGGER.info("COMMON DOC SERVICE  SOP VIEW:" + sView + "User :" + sUserType);

								if (!sView.equals(sUserType) && !sView.equals("NO Connection Exists")
										&& !sView.equals(ConstantsUtil.ALLOW_FOR_ALL)) {
									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								} else {

									sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
									sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
									String strState = validator
											.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
									sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
									sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
									String strTitle = validator.getStringEquivalentForSubstituteString(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
									sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
									sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
									sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
									String strOrig = validator.getStringEquivalentForStringList(
											mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
									sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
									sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
								}
							}
						}else{
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else 
					{
						bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
						if (bHasOwnerShip) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							String strPhase = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartId.append(strMasterPartId).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartType.append(strMasterPartType).append(ConstantsUtil.SYMBL_PIPE);

						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}

					}*/
					//commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl---->start
					bHasOwnerShip = util.checkHasAccess(context, sUserType, strId);
					if (bHasOwnerShip) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						String strPhase = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartId.append(strMasterPartId).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartType.append(strMasterPartType).append(ConstantsUtil.SYMBL_PIPE);

					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					}
					//modified by Ganesh for security impl---->end
				}else if(sct.isStaffAUGUser()) {
                   //commented by Ganesh for security impl---->start
					/*if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else if("ArtiosCAD Component".equalsIgnoreCase(strType)){
						showData=util.checkInternalUserAcess(sUserlicense,strAutocadClassFied);
					} else {
						showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
					}*/
					//commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl---->start
					showData = util.checkHasAccess(context, null, strId);
					//modified by Ganesh for security impl---->end
						if (showData) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartId.append(strMasterPartId).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartType.append(strMasterPartType).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					
				} else {
					//commented by Ganesh for security impl----->start
					/*if (sIPClassfication.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED)) {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						if (null != sUserlicense && null != strClassFied && !sUserlicense.contains(strClassFied.trim())) {
							showData = false;
						}

						if (showData) {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							String strState = validator
									.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
							sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
							String strTitle = validator.getStringEquivalentForSubstituteString(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
							String strOrig = validator.getStringEquivalentForStringList(
									mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
							sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartId.append(strMasterPartId).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartType.append(strMasterPartType).append(ConstantsUtil.SYMBL_PIPE);
						} else {
							sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
							sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
							sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
							sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						}
					} else {

						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator
								.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartId.append(strMasterPartId).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartType.append(strMasterPartType).append(ConstantsUtil.SYMBL_PIPE);
					}*/
					//commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl---->start
					showData = util.checkHasAccess(context, sUserType, strId);
					if (showData) {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						String strState = validator
								.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
						sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
						String strTitle = validator.getStringEquivalentForSubstituteString(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(strSource).append(ConstantsUtil.SYMBL_PIPE);
						String strOrig = validator.getStringEquivalentForStringList(
								mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
						sbOrig.append(strOrig).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartId.append(strMasterPartId).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartType.append(strMasterPartType).append(ConstantsUtil.SYMBL_PIPE);
					} else {
						sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
						sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
						sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbSource.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartName.append(strMasterPartName).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
						sbMasterPartType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					}
					//modified by Ganesh for security impl---->end

				}

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());
			mpFinalList.put(ConstantsUtil.MASTERPARTNAME, sbMasterPartName.toString());
			mpFinalList.put(ConstantsUtil.MASTERPARTID, sbMasterPartId.toString());
			mpFinalList.put(ConstantsUtil.MASTERPARTTYPE, sbMasterPartType.toString());

		} catch (FrameworkException e) {
			LOGGER.error("Exception in FAB BO getMasterPartSpecifications: " + e);
			return new HashMap();
		}
		return util.filterMapList(mpFinalList);
	}
    
    
    /**
     * Method Name 			: getCOName
     * Method Description 	: 
     * @param context
     * @param changeargs
     * @return
     * @throws Exception
     */
	   /*// SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- START
    public Map getCOName(Context context, String[]changeargs) throws Exception{

    	
		Map mpLifecycle= new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();

		StringList slObjectSelects = new StringList();
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_NAME);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_ID);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_TITLE);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_APPROVER);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_STATUS);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_COMPL_DATE);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVER_NAME);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_STATUS);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_DATE);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_TITLE);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_COMMENTS);

		StringBuilder sbCOName= new StringBuilder();
		StringBuilder sbTaskName = new StringBuilder();			
		StringBuilder sbTaskApprover = new StringBuilder();
		StringBuilder sbTaskApproverFullName = new StringBuilder();
		StringBuilder sbTaskTitle = new StringBuilder();			
		StringBuilder sbTaskStatus = new StringBuilder();			
		StringBuilder sbTaskCompletionDate = new StringBuilder();
		StringBuilder sbTaskId = new StringBuilder();
		StringBuilder sbTaskComments = new StringBuilder();

		String sCAName = ConstantsUtil.EMPTY_STRING;
		String sCAId = ConstantsUtil.EMPTY_STRING;
		String sCOName = ConstantsUtil.EMPTY_STRING;
		try {
			if (UIUtil.isNullOrEmpty(changeargs[1])) {
				return new HashMap();
			}
			String sQuery =BusExtractUtil.createQueryPath(changeargs[1]);
			String sQueryResult =BusExtractUtil.executeTempQuery(context,sQuery);

			if(UIUtil.isNullOrEmpty(sQueryResult)){
				return new HashMap();
			}
			String[] sQueResult = sQueryResult.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

			if (sQueResult.length > 2) {
				sCAName = sQueResult[1];
				sCAId = sQueResult[2];
			}

			if (sQueResult.length > 3) {
				sCOName = sQueResult[3];
			}

			if (UIUtil.isNotNullAndNotEmpty(sCAId)) {

				DomainObject domChangeAction = new DomainObject(sCAId);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_NAME);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_ID);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_TITLE);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_APPROVER);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_STATUS);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_COMPL_DATE);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_COMMENTS);

				Map mapCAInfo = domChangeAction.getInfo(context, slObjectSelects);

				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_NAME);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_ID);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_TITLE);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_APPROVER);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_STATUS);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_COMPL_DATE);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_COMMENTS);

				if (mapCAInfo.isEmpty()) {
					return new HashMap();
				}
				sbTaskName
				.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_NAME)));
				sbTaskId.append(validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_ID)));
				sbTaskTitle.append(
						validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_TITLE)));
				sbTaskStatus.append(
						validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_STATUS)));
				sbTaskApprover.append(
						validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_APPROVER)));
				sbTaskComments.append(
						validator.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.REL_TASK_COMMENTS)));
				
				String sApproverName = validator
						.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVER_NAME));
				String sApprovalStatus = validator
						.getStringEquivalentForStringList(mapCAInfo.get(ConstantsUtil.SO_APPROVAL_STATUS));

				if (sApprovalStatus.equalsIgnoreCase(ConstantsUtil.TRUE)
						|| sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
					sApprovalStatus = ConstantsUtil.APPROVED;
				} else if (sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_FALSE)
						|| sApprovalStatus.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
					sApprovalStatus = ConstantsUtil.IGNORED;
				} else {
					sApprovalStatus = "";

				}

				String sApprovedDate = validator
						.isNotNullOrEmpty((String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_DATE))
						? (String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_DATE) : ConstantsUtil.EMPTY_STRING;
						String sApprovalTitle = validator
								.isNotNullOrEmpty((String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE))
								? (String) mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE) : ConstantsUtil.EMPTY_STRING;

								sbTaskName.append(ConstantsUtil.SYMBL_PIPE);
								sbTaskName.append(ConstantsUtil.SO_APPROVAL_SIGNATURE);

								sbTaskStatus.append(ConstantsUtil.SYMBL_PIPE);
								sbTaskStatus.append(sApprovalStatus);
								sbTaskTitle.append(ConstantsUtil.SYMBL_PIPE);
								sbTaskTitle.append(sApprovalTitle);

								// For eliminating the SO Approver name in Ownership
								mpLifecycle.put(ConstantsUtil.APPROVER_FULLNAME, sbTaskApprover.toString());

								sbTaskApprover.append(ConstantsUtil.SYMBL_PIPE);
								sbTaskApprover.append(sApproverName);

								StringList slTaskApproverFullName = util.getPersonFullName(context, sbTaskApprover);

								// slTaskApprover.remove(sApproverName);
								StringBuilder sbTaskStatusRendered = util.MapSlType(sbTaskStatus);

								StringList slTaskCompletionDate = validator
										.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_COMPL_DATE));
								slTaskCompletionDate.add(sApprovedDate);

								String strTaskApproverFullName = validator.isNotNullOrEmpty(slTaskApproverFullName.toString())
										? slTaskApproverFullName.toString() : ConstantsUtil.EMPTY_STRING;
										String strTaskCompletionDate = validator.isNotNullOrEmpty(slTaskCompletionDate.toString())
												? slTaskCompletionDate.toString() : ConstantsUtil.EMPTY_STRING;

												strTaskApproverFullName = util.replaceSpecialSymbols(strTaskApproverFullName);
												strTaskCompletionDate = util.replaceSpecialSymbols(strTaskCompletionDate);
												

												mpLifecycle.put(ConstantsUtil.NAME, sbTaskName.toString());
												mpLifecycle.put(ConstantsUtil.APPROVER, strTaskApproverFullName);

												mpLifecycle.put(ConstantsUtil.TITLE, sbTaskTitle.toString());
												mpLifecycle.put(ConstantsUtil.APPROVALSTATUS, sbTaskStatusRendered.toString());
												mpLifecycle.put(ConstantsUtil.APPROVALDATE, strTaskCompletionDate);
												mpLifecycle.put(ConstantsUtil.CO, sCOName.trim() + ConstantsUtil.SYMBL_PIPE + sCAName.trim());
												mpLifecycle.put(ConstantsUtil.COMMENTS, sbTaskComments.toString());
			}

		} catch (Exception e) {
			LOGGER.info("Error in InnerPackBO method getCOName " + e);
			return new HashMap();
		}
		return mpLifecycle;
	}
   // SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- END
*/    
    /**
   	 * Method Name 			: updateSecurity
   	 * Method Description 	: 
   	 * @param objectMap
   	 * @return
   	 */
   	public Map<String, String> updateSecurity(Map objectMap) {
   		
   		Map<String, String> mpSecurity = new HashMap<String, String>();
   		StringValidatorUtil validator = new StringValidatorUtil();
   		try
   		{
   			String sName=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME));
   			String sLibrary=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME));
   			String sCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE));
   			String sType=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE));
   			String sDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC));
   			String Name[]=sName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
   			String Library[]=sLibrary.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
   			String Type[]=sType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
   			
   			StringBuilder sbHasAccess = new StringBuilder();
   			
   			if(!sType.isEmpty()){

   				for (int i = 0; i < Type.length; i++)
   				{
   					/*
   					if(UIUtil.isNotNullAndNotEmpty(Name[i]) && UIUtil.isNotNullAndNotEmpty(Library[i]))
   					{
   						sbSecurityClasspath.append(Library[i]).append(ConstantsUtil.SYMBL_ARROW).append(Name[i]);
   						mpSecurity.put(ConstantsUtil.CLASSPATH, sbSecurityClasspath.toString());
   					}else
   					{
   						sbSecurityClasspath.append(ConstantsUtil.EMPTY_STRING);
   					}
   					*/
   					if (UIUtil.isNotNullAndNotEmpty(Type[i])) {
   						if ((sType).equalsIgnoreCase(ConstantsUtil.TYPE_SECURITYCONTROLCLASS)) {
   							sbHasAccess.append("TRUE");
   							
   						}
   						else {
   							sbHasAccess.append("FALSE");
   						}
   					}
   				}
   			} 
   			
   			mpSecurity.put(ConstantsUtil.TYPE, sType);
   			mpSecurity.put(ConstantsUtil.NAME, sName);
   			mpSecurity.put(ConstantsUtil.STATE, sCurrent);
   			mpSecurity.put(ConstantsUtil.DESCRIPTION, sDesc);
   			//mpSecurity.put(ConstantsUtil.LIBRARY, sLibrary);
   			mpSecurity.put(ConstantsUtil.HASCLASSACCESS, sbHasAccess.toString());
   		
   		}catch(Exception e){
   			LOGGER.error("Error from FAB BO: updateSecurity"+e);
   			return new HashMap();
   		}
   		return  mpSecurity;
   	}
   	
   	
   	/**
	 * Method Name 			: getSubstances
	 * Method Description 	: 
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Context context, Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		// Guna Added for Defect 37743  18x.5.2 Release -- START
		BigDecimal dDefaultValue = BigDecimal.valueOf(0.0);
		// Guna Added for Defect 37743  18x.5.2 Release -- END
		try
		{
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_DESC));
			//String sTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_TITLE));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sQTY     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT));
			String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sMlLgc   =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));			
			
			String sMFR= util.getTheValueWithComma(resultMaps);
			
			/*String sMFR     =  validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.COMP_MANUF));
			sMFR.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);*/
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sCMT     =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_COMENT));
			//String sTrN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sTrN     =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sMLyr    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sPCID    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTINDUSTRIAL));
			String sPhase   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String strCurrent	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CURRENT));
			String sQTYuom	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));
			
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			// Guna Added for Defect 37743  18x.5.2 Release -- START

			sPCED =util.getPostRecycledContent(new BigDecimal(sPCED),dDefaultValue);
			sPCID =util.getPostRecycledContent(new BigDecimal(sPCID),dDefaultValue);
		
			// Guna Added for Defect 37743  18x.5.2 Release -- END
			
			
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);
			
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			//mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.SEQ,sFN);
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.POST_INDUSTRIAL,sPCID);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.PHASE,sPhase);
			mpSubStanceResult.put(ConstantsUtil.STATE, strCurrent);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			mpSubStanceResult.put(ConstantsUtil.QUANTITYUOM, sQTYuom);
			
			//mpSubStanceResult=util.verifyOwnership(context,mpSubStanceResult);
			
		}catch(Exception e){
			LOGGER.error("Error from FAB BO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	/**
     * Method Name 			: getIpClass
     * Method Description 	: Get IP Classification
     * @param context
     * @param doFormObj  - domain object of part
     * @param slIpSelects - Selectable
     */
    public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
    	Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
    	MapList mlIPCLass;
		try {
			mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
					null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			Iterator itr = mlIPCLass.iterator();
			Map mpIpClass = new HashMap();
			StringBuilder sbIpName = new StringBuilder();
			StringBuilder sbHasClassAccess = new StringBuilder();
			StringBuilder sbIpType = new StringBuilder();
			StringBuilder sbIpDesc = new StringBuilder();
			StringBuilder sbIpState = new StringBuilder();
			StringBuilder sbIpLibrary = new StringBuilder();
			StringBuilder sbIpClassPath = new StringBuilder();
			
			while(itr.hasNext()) {
				mpIpClass = (Map)itr.next();
				String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
				sbIpName.append(sIpClassName);
				sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
				sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
				sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
				String strIpClass="";
				if(sIpClassName.contains(ConstantsUtil.HIR)) {
					strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
					sbIpLibrary.append(strIpClass);
				} else {
					strIpClass= ConstantsUtil.BUSINESS_USE;
					sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
				}
				if(!strIpClass.isEmpty()) {
					StringBuilder sbIpClassTemp = new StringBuilder();
					sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
					sbIpClassPath.append(sbIpClassTemp.toString());
				}
				
				//Compare user classification against IPName
				sbHasClassAccess.append("TRUE");
				
				if(itr.hasNext()) {
					sbIpName.append("|");
					sbIpType.append("|");
					sbIpDesc.append("|");
					sbIpState.append("|");
					sbIpLibrary.append("|");
					sbIpClassPath.append("|");
					sbHasClassAccess.append("|");
				}
			}
			mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
			mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
			mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
			mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
			//mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
			//mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
			mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
		} catch (FrameworkException e) {
			e.printStackTrace();
			LOGGER.error("Error from FAB BO: getIpClass" + e);
		}
		return mpIpSecuritySetting;
    }
	//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END
    
  //SPEC: 11/04/2020: Added for 18x.5 DEV -- START
    public boolean checkSubstituteHasAccess(Context context, Map objectMap) {
    	
		StringBuilder  sbReturnVal = new StringBuilder();
		boolean showData = false;
		try
		{
			StringValidatorUtil validator = new StringValidatorUtil();
			
			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership=util.filterOwnerShip(sComp);
			
		if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))
			{
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
				{
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
					String strSubPartId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
					
					DomainObject doEachChild = new DomainObject(strSubPartId);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					StringList slSelect = new StringList();
					slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					Map mpIpClass = doEachChild.getInfo(context, slSelect);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doEachChild.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					//commented by Ganesh for security impl ---->start
					/*if(util.isModificatinRequired())
					{
						//For EBP User
						showData = util.checkOwnerShip(context, slUserOwnership, strSubPartId);
						
					}else if(sct.isStaffAUGUser())
					{
						//For Staff Aug USer check 
						if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							//Validation for Hir checks on Formulation
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else
						{
							//Validation for Hir checks for other than Formulation
							showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
						}
					}else 
					{
						//For Internal User check
						if(slHIRTypes.contains(strSubPartType)) 
						{
							//Validation for Hir checks on Formulation
							if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else 
							{
								//Validation for Hir checks for other than Formulation
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
						}else 
						{
							//If it is Non-Hir we can show without checks for internal user
							showData=true;
						}
					}*/
					//commented by Ganesh for security impl ---->end
					//modified by Ganesh for security impl ---->start
					showData = util.checkHasAccess(context, null, strSubPartId);
					//modified by Ganesh for security impl ---->end
					
					
//						
				}//close for string
				}else
			{	//If no Substitue found
				return showData;
			}
			
		}catch(Exception e){
			
			LOGGER.error("Error from FAB BO :  checkSubstituteHasAccess" + e);
			return showData;
		}
		return showData;
	}
	//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
    
    //SPEC:11/21/2020: Added for defect 37032 by Jwala## -- START
	  /**
		 * Method Name 			: getMarketofSale
		 * Method Description 	: 
		 * @param resultMaps
		 * @return
		 */
    public Map getMarketOfSale(Context context,String sContextObjectId)
    {
    	Map<String, String> mapMarketOfSale = new HashMap<String, String>();

    	StringBuilder sbCos = new StringBuilder();
    	StringBuilder sbCosRestriction = new StringBuilder();
    	//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- START
    	StringBuilder sbPOAOverride = new StringBuilder();
    	//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- END
    	StringValidatorUtil validator = new StringValidatorUtil();

    	StringList busSelect = new StringList();
    	busSelect.add(ConstantsUtil.SELECT_NAME);
    	

    	StringList relSelect = new StringList();
    	relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRESTRICTION);
    	//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- START
    	relSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMOSPOAOVERRIDELRR);
    	//SPEC: <20.05.2022>: Guna Added for Req 41754 22x Release  -- END
    	try
    	{
    		DomainObject doFAB = new DomainObject(sContextObjectId);
    		
    		String strContextType = doFAB.getType(context);

    		MapList mapMarketList = doFAB.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGCOUNTRYOFSALE, ConstantsUtil.SYMBL_ASTERISK,
    				busSelect, relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
    				ConstantsUtil.ZERO_LEVEL);
    		//SPEC: Release SR18x.6.0.1 Added by Dominic  on Date 18/05/2021 --START
    		StringList parentInfoSelect = new StringList(1);
			parentInfoSelect.add(DomainConstants.SELECT_TYPE);
			parentInfoSelect.add(DomainConstants.SELECT_CURRENT);
			parentInfoSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINCLUDEINCOS);
			Map parentInfoList = doFAB.getInfo(context, parentInfoSelect);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doFAB.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			String strParentpgIncludeInCOS = (String) parentInfoList.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINCLUDEINCOS);
			String strState = (String) parentInfoList.get(DomainConstants.SELECT_CURRENT);
			String strObjectType = (String) parentInfoList.get(DomainConstants.SELECT_TYPE);
			String noCountryText ="";
    		if(mapMarketList.size()<1)
			{
				Map countryMap = new HashMap();
				if("False".equalsIgnoreCase(strParentpgIncludeInCOS))
				{
					if(!DomainConstants.STATE_PART_RELEASE.equalsIgnoreCase(strState) && !ConstantsUtil.STATE_COMPLETE.equalsIgnoreCase(strState) && (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strObjectType) || ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(strObjectType) || ConstantsUtil.TYPE_FABRICATEDPART.equalsIgnoreCase(strObjectType)))
					{
						MapList mlBOM = getCOSBOM(context,sContextObjectId);
						
						boolean blIsPreliminaryChild = false;
						if(null != mlBOM && mlBOM.size() > 0)
						{
							for(int i=0;i<mlBOM.size();i++)
							{
								Map mapTempEBOM = (Map)mlBOM.get(i);
								String strCurrent = (String)mapTempEBOM.get(DomainConstants.SELECT_CURRENT);
								if(!"Release".equalsIgnoreCase(strCurrent) && !"Complete".equalsIgnoreCase(strCurrent) && !"Obsolete".equalsIgnoreCase(strCurrent))
								{
									blIsPreliminaryChild = true;
									break;
								}
							}
						}
						
						
						if (blIsPreliminaryChild) {
							noCountryText = "No MOS, Contains MOS Components in Preliminary State";
						} else {
							noCountryText = "Contains no components that impact MOS";
						}
						mapMarketOfSale.put(ConstantsUtil.MARKETOFSALE, noCountryText);
						mapMarketOfSale.put(ConstantsUtil.MARKETOFSALERESTRICTIONS, ConstantsUtil.EMPTY_STRING);
						
					}
					else
					{
						noCountryText = "Contains no components that impact MOS";
						mapMarketOfSale.put(ConstantsUtil.MARKETOFSALE, noCountryText);
						mapMarketOfSale.put(ConstantsUtil.MARKETOFSALERESTRICTIONS, ConstantsUtil.EMPTY_STRING);
						
					}
				}
				else
				{
					noCountryText = "No Market";
					mapMarketOfSale.put(ConstantsUtil.MARKETOFSALE, noCountryText);
					mapMarketOfSale.put(ConstantsUtil.MARKETOFSALERESTRICTIONS, ConstantsUtil.EMPTY_STRING);
					
				}
			}
    		//SPEC: Release SR18x.6.0.1 Added by Dominic  on Date 18/05/2021 --END
    	 		mapMarketList.sort(DomainConstants.SELECT_NAME, "ascending", "String");
    	 		for (int i = 0; i < mapMarketList.size(); i++) {
    			
	    			Map resultMaps = (Map) mapMarketList.get(i);
	    			
	    			String strCos = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
	    			String strCosRestriction = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRESTRICTION));
	    			//SPEC: <20.05.2022>: Guna Modified for Req 41754 22x Release  -- START
	    			String strPOAOverride = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMOSPOAOVERRIDELRR));
	    			util.formatData(sbCos, strCos);
					util.formatData(sbCosRestriction, strCosRestriction);
					util.formatData(sbPOAOverride, strPOAOverride);
					
					mapMarketOfSale.put(ConstantsUtil.MARKETOFSALE, sbCos.toString());
					mapMarketOfSale.put(ConstantsUtil.MARKETOFSALERESTRICTIONS, sbCosRestriction.toString());
					mapMarketOfSale.put(ConstantsUtilIRM.POAOVERRIDELEGALREWORKREQUIRED, sbPOAOverride.toString());
					//SPEC: <20.05.2022>: Guna Modified for Req 41754 22x Release  -- END
    	 		}
    	 	
    	}catch(Exception e){

    		LOGGER.error("Error from FABBO:  getMarketOfSale"+e);
    		return new HashMap();
    	}

    	return mapMarketOfSale;
    }
  //SPEC: Release SR18x.6.0.1 Added by Dominic  on Date 18/05/2021 --START
    /** to get latest released revision
	 * @param context
	 * @param strIPS
	 * @return
	 * @throws Exception
	 */
	public MapList getCOSBOM(Context context,String strIPS) throws Exception {
		String strid="";
		String current="";
		MapList mlBOM = new MapList();
		if (strIPS != null && strIPS.length() >0) {
			DomainObject dom = DomainObject.newInstance(context, strIPS);
			StringList obselect=new StringList(2);
			obselect.add(ConstantsUtil.SELECT_ID);
			obselect.add(ConstantsUtil.SELECT_CURRENT);
			String objectWhere =  DomainObject.SELECT_CURRENT+ " != " + ConstantsUtil.STATE_PART_OBSOLETE;
			mlBOM = dom.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_EBOM,
							"*",
							false,
							true,
							(short)1,
							obselect,
							new StringList(),
							objectWhere,"",
							(short)0,
							"",
							null,
							null);
		}
		
		return mlBOM;
	}
	//SPEC: Release SR18x.6.0.1 Added by Dominic  on Date 18/05/2021 --END
}


