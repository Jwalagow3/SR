package com.pg.us.specanywhere_enovia.service.comp;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaAPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaAPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaARMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaASLService;
import com.pg.us.specanywhere_enovia.service.EnoviaCOPCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaCOPService;
import com.pg.us.specanywhere_enovia.service.EnoviaCUPService;
import com.pg.us.specanywhere_enovia.service.EnoviaCommonDocService;
import com.pg.us.specanywhere_enovia.service.EnoviaDPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaFABService;
import com.pg.us.specanywhere_enovia.service.EnoviaFOPService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPCategoriesService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaFormulaCardService;
import com.pg.us.specanywhere_enovia.service.EnoviaIPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaIPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMCOPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMCUPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMEPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMIPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPAPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaMRMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaOPPService;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaPOAARTService;
import com.pg.us.specanywhere_enovia.service.EnoviaPackagingAssemblyPart;
import com.pg.us.specanywhere_enovia.service.EnoviaPriliminarydataloadService;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaSWPService;
import com.pg.us.specanywhere_enovia.service.EnoviaTUPService;
import com.pg.us.specanywhere_enovia.service.PromotionalItemPartService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaAPPServiceImpl;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaPriliminarydataloadServiceImpl implements EnoviaPriliminarydataloadService {
	private static Logger LOGGER = Logger.getLogger(EnoviaAPPServiceImpl.class);
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	
	@Autowired
	private EnoviaConnectionPool pool;
	@Autowired
	private HttpServletRequest request;
	@Autowired
	private EnoviaAPMPService apmp;
	
	@Autowired
	private EnoviaARMPService armp;
	
	@Autowired
	private EnoviaCOPService cop;
	
	@Autowired
	private EnoviaOPPService opp;
	
	@Autowired
	private EnoviaCUPService cup;
	
	@Autowired
	private EnoviaFABService fab;
	
	@Autowired
	private EnoviaRMPService rmp;
	
	@Autowired
	private EnoviaPMPService pmp;
	
	
	@Autowired
	private EnoviaCommonDocService commondoc;
	
	@Autowired
	private EnoviaPackagingAssemblyPart pap;
	
	@Autowired
	private PromotionalItemPartService pip;
	
	@Autowired
	private EnoviaSWPService swp;
	
	@Autowired
	private EnoviaFPPService fpp;
	
	@Autowired
	private EnoviaFPPCategoriesService fppcat;
	
	@Autowired
	private EnoviaASLService asl;
	
	@Autowired
	private EnoviaPOAARTService poa;
	@Autowired
	private EnoviaAPPService app;
	
	@Autowired
	private EnoviaDPPService dpp;
	
	@Autowired
	private EnoviaIPService ip;
	
	@Autowired
	private EnoviaIPPService ipp;
	@Autowired
	private EnoviaMCOPService mcop;
	
	@Autowired
	private EnoviaMCUPService mcup;
	
	@Autowired
	private EnoviaMEPService mep;
	
	@Autowired
	private EnoviaMIPService mip;
	
	@Autowired
	private EnoviaMPMPService mpmp;
	
	
	@Autowired
	private EnoviaMPAPService mpap;
	
	@Autowired
	private EnoviaMPPService mpp;
	
	@Autowired
	private EnoviaFormulaCardService fc;
	
	@Autowired
	private EnoviaMRMPService mrmp;
	
	@Autowired
	private EnoviaFOPService fop;
	
	@Autowired
	private EnoviaTUPService tup;
	@SuppressWarnings("unchecked")
	@Override
	public HashMap<String, Map<String, String>> getPriliminarydata(Environment env, String sObjectName) {
		// TODO Auto-generated method stub
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		HashMap<String, Map<String, String>> hmAttribCat = new HashMap<String, Map<String, String>>();
		HashMap<String, Map> hmMap = new HashMap<String, Map>();
	
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		MapList mlObjectList = new MapList();
		try {
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			StringValidatorUtil validator = new StringValidatorUtil();
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			if(sUserType.contains(ConstantsUtil.PG)) {
				
				mlObjectList = getPriliminaryData(context,sObjectName);
				
				
				Iterator<MapList> objectListItr = mlObjectList.iterator();
				Map<String, String> mpObject = (Map<String, String>)mlObjectList.get(0);
				String sId = mpObject.get(ConstantsUtil.ID);
				String sType = util.mapType((validator.isNotNullOrEmpty((String)mpObject.get(ConstantsUtil.SELECT_TYPE)))?(String)mpObject.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
				if(sType.contains(ConstantsUtilIRM.PG_APMP)) {
					hmAttrib = apmp.getAPMPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(sType.equals(ConstantsUtilIRM.PG_COP)) {
					hmAttrib = cop.getCOPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				
				if(sType.equals(ConstantsUtilIRM.PG_CUP)) {
					hmAttrib = cup.getCUPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(sType.contains(ConstantsUtilIRM.TP_ARMP)) {
					hmAttrib = armp.getARMPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(sType.contains(ConstantsUtilIRM.PG_OPP)) {
					hmAttrib = opp.getOPPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(sType.contains(ConstantsUtilIRM.PG_FAB)) {
					hmAttrib = fab.getFABdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(sType.equals(ConstantsUtil.tRMP)) {
					hmAttrib = rmp.getRMPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(sType.equals(ConstantsUtil.TYPE_PACKAGING_MATERIAL_PART)) {
					hmMap = pmp.getPMPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);

					for (String key : hmMap.keySet()) {
						hmAttrib.put(key, (Map<String, String>) hmMap.get(key));
					}
				}
				if (sType.equals(ConstantsUtilIRM.INNOVATION_RECORD) ||
			            sType.equals(ConstantsUtilIRM.CONSUMER_RESEARCH) ||
			            sType.equals(ConstantsUtilIRM.STABILITY_REPORT) ||
			            sType.equals(ConstantsUtilIRM.GENERAL_INNOVATION_RECORD) ||
			            sType.equals(ConstantsUtilIRM.VALIDATION_PROTOCOL) ||
			            sType.equals(ConstantsUtilIRM.CORE_INNOVATION_RECORD) ||
			            sType.equals(ConstantsUtilIRM.STABILITY_OUT_OF_SPEC_REPORT) ||
			            sType.equals(ConstantsUtilIRM.VALIDATION_REPORT) ||
			            sType.equals(ConstantsUtilIRM.STABILITY_OTHER) ||
			            sType.equals(ConstantsUtilIRM.VALIDATION_OTHER) ||
			            sType.equals(ConstantsUtilIRM.TRANSLATION_FILE) ||
			            sType.equals(ConstantsUtilIRM.STABILITY_PROTOCOL) ||
			            sType.equals(ConstantsUtilIRM.TECHNICAL_RATIONALE) ||
			            sType.equals(ConstantsUtilIRM.PACKAGING_MINIMIZATION_REPORT)) {
					sType = ConstantsUtilIRM.IRM;
					hmAttrib= commondoc.getDocdata(sId, env, sType, ConstantsUtilIRM.STATE_PRILIMNARY);
				}
				if(sType.equals(ConstantsUtil.FIRST_LEVEL_DOC_QUAL) || sType.equals(ConstantsUtil.FIRST_LEVEL_DOC_ATS) || sType.equals(ConstantsUtil.FIRST_LEVEL_DOC_ILST) || sType.equals(ConstantsUtil.FIRST_LEVEL_DOC_MI) || sType.equals(ConstantsUtil.PACKING_INSTRUCTION) || sType.equals(ConstantsUtil.TYPE_RMPI) || sType.equals(ConstantsUtil.FIRST_LEVEL_DOC_SP) || sType.equals(ConstantsUtil.FIRST_LEVEL_DOC_IAPS) || sType.equals(ConstantsUtil.FIRST_LEVEL_DOC_LIS) || sType.equals(ConstantsUtil.FIRST_LEVEL_DOC_ACS) || sType.equals(ConstantsUtil.FIRST_LEVEL_DOC_PROS) || sType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE) || sType.equals(ConstantsUtil.tTM) || sType.equals(ConstantsUtilIRM.tSTD) || sType.equals("pgPKGProductReadiness")) {
					hmAttrib= commondoc.getDocdata(sId, env, sType, ConstantsUtilIRM.STATE_PRILIMNARY);
				}
				if(sType.equals(ConstantsUtil.tPAP)) {
					hmAttrib = pap.getPAPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(sType.contains(ConstantsUtil.tFOP)) {
					hmAttrib = fop.getFOPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(sType.contains(ConstantsUtilIRM.PROMOTIONAL_ITEM_PART)) {
					hmAttrib = pip.getPIPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(sType.contains(ConstantsUtilIRM.PG_SWP)) {
					hmAttrib = swp.getSWPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(ConstantsUtil.tFPP.contains(sType)) {
					hmAttrib = fppcat.getFPPCategoriesdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
					hmAttribCat = fpp.getFPPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
					hmAttrib.putAll(hmAttribCat);
				}
				if(sType.contains(ConstantsUtilIRM.ART)) {
					hmAttrib = poa.getPOAARTData(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtil.tAPP).contains(sType)) {
					hmAttrib = app.getAPPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.PG_DPP).contains(sType)) {
					hmAttrib = dpp.getDPPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.TYPE_INNER_PACK).equals(sType)) {
					hmAttrib = ip.getIPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.PG_IPP).contains(sType)) {
					hmAttrib = ipp.getIPPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.PG_MCOP).equals(sType)) {
					hmAttrib = mcop.getMCOPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.tMCUP).equals(sType)) {
					hmAttrib = mcup.getMCUPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtil.tMEP).contains(sType)) {
					hmAttrib = mep.getMEPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.PG_MASTER_INNER_PACK).equals(sType)) {
					hmAttrib = mip.getMIPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.PG_MPMP).equals(sType)) {
					hmAttrib = mpmp.getMPMPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.PG_MPAP).equals(sType)) {
					hmAttrib = mpap.getMPAPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.PG_MPP).contains(sType)) {
					hmAttrib = mpp.getMPPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if((ConstantsUtilIRM.PG_MRMP).equals(sType)) {
					hmAttrib = mrmp.getMRMPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}

				if(ConstantsUtil.TYPE_POA.contains(sType)) {
					hmAttrib = poa.getPOAARTData(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(ConstantsUtil.tTUP.contains(sType)) {
					hmAttrib = tup.getTUPdata(sId, ConstantsUtilIRM.STATE_PRILIMNARY, env);
				}
				if(UIUtil.isNotNullAndNotEmpty(sType)) {
					Map<String,String> mpHeaderContent =hmAttrib.get(ConstantsUtil.HEADERCONTENT);
					hmAttrib.remove(mpHeaderContent);
					boolean bAllInfoView = false;
					boolean bSupplierView = false;
					boolean bManufacturerView = false;
					boolean bGendocView = false;
					
					String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
					LOGGER.info("PDF VIEW Info : "+strPDFView);
					
						if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PRELIMINARY_CM)) {
							bManufacturerView = true;
						} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PRELIMINARY_SP)){
							bSupplierView = true;
						} else {
							switch (sUserType) {
							case ConstantsUtil.PG:
								bAllInfoView = true;
								break;

							case ConstantsUtil.PGSTAFF:
								bAllInfoView = true;
								break;

							case ConstantsUtil.PG_CM:
								bManufacturerView = true;
								break;

							case ConstantsUtil.PG_SP:
								bSupplierView = true;
								break;
							}

						}
					mpHeaderContent.put(ConstantsUtilIRM.GENDOCHIDE, ConstantsUtil.TRUE);
					mpHeaderContent.remove(ConstantsUtilIRM.ROLEINFO);
					mpHeaderContent.remove(ConstantsUtil.PDF_VIEW);
					LOGGER.info("PDF VIEW Info : "+strPDFView);
					if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PRELIMINARY_CM)) {
						mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
					} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PRELIMINARY_SP)){
						mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
					} else {
						mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
					}
					
					mpHeaderContent.put(ConstantsUtil.PDF_VIEW, util.getPdfViewtype(bAllInfoView, bGendocView, bSupplierView));// Added for  Defect 135846  by Ajay
					
					hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in getPreliminarydata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		context.close();
		return hmAttrib;
	}
	
	public MapList getPriliminaryData(Context context, String sObjectName) 
	{	
		MapList finalMapList = new MapList();

		try {
			StringList slObjectsSelect = new StringList();
			slObjectsSelect.add(DomainConstants.SELECT_ID);
			slObjectsSelect.add(DomainConstants.SELECT_TYPE);
			slObjectsSelect.add(DomainConstants.SELECT_NAME);
	
			
			finalMapList = DomainObject.findObjects
						(context, //MatrixContext
						DomainConstants.QUERY_WILDCARD, //typePattern
						sObjectName, //namePattern
						DomainConstants.QUERY_WILDCARD, //revPattern
						DomainConstants.QUERY_WILDCARD, //ownerPattern
						ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
						ConstantsUtilIRM.CURRENT_ST_PRELIMINARY, //whereExpression
						false, //expandType
						slObjectsSelect); 
			

		} catch (Exception ex) {
			LOGGER.error("Error from BusObjAttribUtil: getPriliminaryData" + ex);
			return finalMapList;
		}
		return finalMapList;
	}

}
