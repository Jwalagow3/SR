package com.pg.us.specanywhere_enovia.service;

import java.util.List;
import java.util.Map;
import org.springframework.core.env.Environment;


public interface EnoviaGetFileService {

	public Map<String, List> getFilePath(String strName, Environment env) throws Exception; 
}
