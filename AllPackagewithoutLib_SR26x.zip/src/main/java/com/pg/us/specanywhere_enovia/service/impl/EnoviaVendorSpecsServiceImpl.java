/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaVendorSpecsServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaVendorSpecsService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaVendorSpecsServiceImpl implements EnoviaVendorSpecsService {

	private static Logger LOGGER = Logger.getLogger(EnoviaVendorSpecsServiceImpl.class);

	@Value("${env.profile}")
   	private String envProfile;
	
	private  HttpServletRequest request;
	@Autowired
	private EnoviaConnectionPool pool;
	@Autowired
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public HashMap<String, Map<String,String>> getVendorSpecs(String sCompany,String sView, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmVendorSpecs = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <08-11-2021>>: Bala Added for Defect 45181  -- START
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		//SPEC: <08-11-2021>>: Bala Added for Defect 45181  -- END
		try 
		{
			//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- END
			LOGGER.info("VENDOR SPECS SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());

			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			Map<String, String> mpPartTemp = new HashMap<String, String>();

			SecurityService sct = new SecurityService();
			boolean isExternalUser = sct.isExternalUser();

			String sUserCompanies = sct.getUserCauthorities();
			String[] aCompany = sUserCompanies.split(",");
			StringBuilder sbCompany = new StringBuilder();
			StringList slCompanies = new StringList();
			if(aCompany.length>-1) {
				for(int i=0;i<aCompany.length;i++) {
					if(null!=aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
						slCompanies.add(Company);
					}
				}
			}

			StringBuilder sbName = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbForLinkType = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			StringBuilder sbSubType = new StringBuilder();
			StringBuilder sbRelDate = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbSapDesc = new StringBuilder();

			if(isExternalUser) {
				String sUser = getName();
				StopWatch swFetchData = new StopWatch();
				swFetchData.start();
				ContextUtil.pushContext(context, ConstantsUtil.USERAGENT, DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
				boolean bHasOwnerShip = false;
				//SPEC: 09-23-2021: Modified for 18x.6.0.1x for Defects# 45038,45039 by Sanjeeva -- END
				MapList mlDataList = busUtil.getVendorViews(context,sUser,sCompany,sView,getName());
				Iterator objectListItr = mlDataList.iterator();
				//SPEC: 09-23-2021: Modified for 18x.6.0.1x for Defects# 45038,45039 by Sanjeeva -- END
				String strLocale = context.getLocale().getLanguage();
				//SPEC: 06-02-2020: Added for 18x.6.0.1 Defect# 43058 by Sanjeeva -- END
				Map mpSSTMap = new HashMap();

				while(objectListItr.hasNext()) 
				{
					Map mpPart = (Map) objectListItr.next();

					//SPEC: 06-07-2020: Modified for 18x.6.0.1 Internal Defect by Sanjeeva -- START
					mpSSTMap=(Map) getSpecificationSubtype(context, mpPart);
					//SPEC: 06-07-2020: Modified for 18x.6.0.1 Internal Defect by Sanjeeva -- END

					bHasOwnerShip = busUtil.checkHasAccess(context, null, (String)mpPart.get(ConstantsUtil.SELECT_ID));
					//modified by Ganesh for security impl---->end

					//SPEC: 09-23-2021: Modified for 18x.6.0.1x for Defects# 45038,45039 by Sanjeeva -- START
					if(bHasOwnerShip)

					{
						formatData(sbName,(String)mpPart.get(ConstantsUtil.SELECT_NAME));
						String sType = (String)mpPart.get(ConstantsUtil.SELECT_TYPE);

						formatData(sbForLinkType, sType);


						//SPEC: 06-07-2020: Added for 18x.6.0.1 Internal Defect by Sanjeeva -- START
						formatData(sbSubType, (String)mpSSTMap.get(sType));
						//SPEC: 06-07-2020: Added for 18x.6.0.1 Internal Defect by Sanjeeva -- END
						sType=busUtil.mapVendorServiceType(sType,strLocale);
						//SPEC: 06-02-2020: Added for 18x.6.0.1 Defect# 43058 by Sanjeeva -- END

						formatData(sbType, sType);
						formatData(sbRev, (String)mpPart.get(ConstantsUtil.SELECT_REVISION));
						formatData(sbSapDesc, (String)mpPart.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						formatData(sbRelDate, (String)mpPart.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
						formatData(sbId, (String)mpPart.get(ConstantsUtil.SELECT_ID));

						//SPEC: 06-02-2020: Added for 18x.6.0.1 Defect# 43058 by Sanjeeva -- START

					}
				}
				mpPartTemp.put(ConstantsUtil.NAME, sbName.toString());
				mpPartTemp.put(ConstantsUtil.TYPE, sbType.toString());
				mpPartTemp.put(ConstantsUtil.DISPLAY_TYPE, sbForLinkType.toString());
				mpPartTemp.put(ConstantsUtil.REVISION, sbRev.toString());
				mpPartTemp.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
				mpPartTemp.put(ConstantsUtil.SAPDESCRIPTION, sbSapDesc.toString());
				mpPartTemp.put(ConstantsUtil.RELEASEDATE, sbRelDate.toString());
				mpPartTemp.put(ConstantsUtil.ID, sbId.toString());
				hmVendorSpecs.put(ConstantsUtil.VENDORSPECS, mpPartTemp);
			}else {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE :");
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmVendorSpecs.put(ConstantsUtil.ERROR, errorMap);
			}


			pool.checkIn(context);
			sp.stop();
			LOGGER.info("VENDOR SPECS SERVICE MESSAGE ELAPSED TIME : "+sp.getTime());
		} catch (IOException e) {
			e.printStackTrace();
			LOGGER.error("IOException from VENDOR SPECS "+e);
		} catch (MatrixException e) {
			e.printStackTrace();
			LOGGER.error("MatrixException from VENDOR SPECS "+e);
		}
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
		context.close();
		//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
		return hmVendorSpecs;
	}

	public void formatData(StringBuilder sbData, String sData) {
		sbData.append(sData);
		sbData.append(ConstantsUtil.SYMBL_PIPE);
	}


	public String getName() {
		String accessToken = request.getHeader("access_token");  
		String name="";

		if(accessToken!=null) {
			String usernameClaimKey = ConstantsUtilIRM.READONLYENVIRONMENT.equalsIgnoreCase(envProfile)?ConstantsUtilIRM.USERNAMEREADONLY:ConstantsUtilIRM.USERNAME;
			DecodedJWT jwt = JWT.decode(accessToken);
			name=jwt.getClaim(usernameClaimKey).asString();
		}
		LOGGER.info("Application Login User  : "+name);
		return name;
	}

	public Map getSpecificationSubtype(Context context, Map mpPart) throws Exception
	{
		Map<String, String> mpSST= new HashMap<String, String>();

		Map<String, String> mapDataMapping = null;

		String strAttributeName = ConstantsUtil.ATTRIBUTE_PGASSEMBLYTYPE; 
		String strTypepgFinishedProduct = ConstantsUtil.TYPE_PGFINISHEDPRODUCT;
		String strTypepgQualitySpecification = ConstantsUtil.TYPE_PGQUALITYSPECIFICATION;
		String strAttrPgAssemblyType = DomainConstants.EMPTY_STRING; 
		String strSpecSubTypeValue = DomainConstants.EMPTY_STRING;  
		String strID=DomainConstants.EMPTY_STRING;
		String strRootNode=DomainConstants.EMPTY_STRING;
		String strSpecSubType = DomainConstants.EMPTY_STRING;
		String strType = DomainConstants.EMPTY_STRING;
		String strAttrPgCSSType = DomainConstants.EMPTY_STRING;
		boolean isContextPush = false;
		ContextUtil.pushContext(context, ConstantsUtil.USERAGENT, DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
		isContextPush = true;
		mapDataMapping = new HashMap();
		mapDataMapping.put(ConstantsUtil.TYPE_PACKINGMATERIAL,ConstantsUtil.PACKAGING);
		strID=(String) mpPart.get(ConstantsUtil.ID);			
		DomainObject dom = new DomainObject(strID);
		DomainObject dom1 = new DomainObject(strID);
		boolean isDSO = false;
		String strDSOAttrValue = (String)dom1.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);

		if (ConstantsUtil.DSO.equalsIgnoreCase(strDSOAttrValue)) {
			isDSO = true;
		}
		strType = (String)mpPart.get(DomainConstants.SELECT_TYPE);

		if (strTypepgFinishedProduct.equals(strType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equals(strType))
		{
			strAttrPgAssemblyType = dom.getInfo(context, //context
					"attribute["+strAttributeName+"]");//java.lang.String select
			if("".equals(strAttrPgAssemblyType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGFINISHEDPRODUCT,"Finished Product");
			}
			else if("FWIP-Finished Work in Process".equals(strAttrPgAssemblyType)) {
				mapDataMapping.put("pgFinishedProduct","FWIP-Finished Work in Process");			
			}
			else if("Purchased Subassembly".equals(strAttrPgAssemblyType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY,"Purchased Subassembly");	
			}
			else if("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY,"Purchased and/or Produced Subassembly");	
			}else{
				mapDataMapping.put(ConstantsUtil.TYPE_PGFINISHEDPRODUCT,strAttrPgAssemblyType);	
			}				
		}
		if (strTypepgQualitySpecification.equals(strType) && !isDSO){
			strAttrPgCSSType = dom.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);

			if(ConstantsUtilIRM.STR_AMAT.equals(strAttrPgCSSType)) {
				mapDataMapping.put(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION,ConstantsUtilIRM.STR_APPROVAL_MATRIX);			
			}
			else if (ConstantsUtilIRM.STR_CBA.equals(strAttrPgCSSType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION,ConstantsUtilIRM.STR_CURRENT_BEST_APPROCH);	
			}
			else if (ConstantsUtilIRM.STR_GPMS.equals(strAttrPgCSSType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION,ConstantsUtilIRM.STR_GENERAL_PMS);	
			}
			else if (ConstantsUtilIRM.STR_GPS.equals(strAttrPgCSSType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION,ConstantsUtilIRM.STR_GENERAL_PACKING_STANDARD);	
			}
			else if (ConstantsUtilIRM.STR_IAS.equals(strAttrPgCSSType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION,ConstantsUtilIRM.STR_INCOMMING_ACCEPT_SPEC);
			}
			else if (ConstantsUtilIRM.STR_MOC.equals(strAttrPgCSSType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION,ConstantsUtilIRM.STR_MATERIAL_OF_CONSTRUCTION);
			}
			else if (ConstantsUtilIRM.STR_QAC.equals(strAttrPgCSSType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION,ConstantsUtilIRM.STR_QUALITY_ACCEPTANCE_CRITERIA);
			}
			else if (ConstantsUtilIRM.STR_RMPI.equals(strAttrPgCSSType)){
				mapDataMapping.put(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION,ConstantsUtilIRM.STR_RAWMATERIAL_PLANT_INSTRUCTION);
			}else{
				mapDataMapping.put(ConstantsUtil.TYPE_PGQUALITYSPECIFICATION,strAttrPgCSSType);
			}		
		}
		if(ConstantsUtil.TYPE_PGRAWMATERIAL.equals(strType)){
			if(!isDSO){
				mapDataMapping.put(ConstantsUtil.TYPE_PGRAWMATERIAL,ConstantsUtil.SPEC_SUB_TYPE);
			}
		}
		if (isDSO){
			if(ConstantsUtil.tFOP.equals(strType)){
				strSpecSubTypeValue =  (String)dom.getInfo(context,"to[Formulation Propagate].from.attribute[Formulation Type]");
			} else {
				strSpecSubTypeValue =  (String)dom.getInfo(context,"attribute["+strAttributeName+"]");
			}
		}else {
			strSpecSubTypeValue= DomainConstants.EMPTY_STRING;
		}
		if (ConstantsUtil.tTM.equals(strType))
		{  
			strAttrPgCSSType =  (String)dom.getInfo(context, "attribute[pgAssemblyType]");
			mapDataMapping.put(ConstantsUtil.tTM,strAttrPgCSSType);
		}								
		strRootNode=(String)mpPart.get("Root Node");
		if(!ConstantsUtil.TRUE.equalsIgnoreCase(strRootNode))
		{
			strSpecSubType = (String)mapDataMapping.get(strType);
			if(strSpecSubType != null)
			{
				mpSST.put(strType, strSpecSubType);
			}
			else if(UIUtil.isNotNullAndNotEmpty(strSpecSubTypeValue))
			{
				mpSST.put(strType, strSpecSubTypeValue);
			}
			else
			{
				mpSST.put(strType, DomainConstants.EMPTY_STRING);
			}
		}else{
			mpSST.put(strType, DomainConstants.EMPTY_STRING);
		}
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
		dom.close(context);
		dom1.close(context);
		//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		if(isContextPush){
			ContextUtil.popContext(context);
			isContextPush = false;
		}
		return mpSST;
	}

	//SPEC: 06-07-2020: Modified for 18x.6.0.1 Internal Defect on SST issue, by Sanjeeva -- START
}
