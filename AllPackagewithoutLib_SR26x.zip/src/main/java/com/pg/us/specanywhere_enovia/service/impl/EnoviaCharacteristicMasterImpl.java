/**
 * Program 		: EnoviaCharacteristicMasterImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.PersonUtil;
import com.pg.us.specanywhere_enovia.bo.CMBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaCMService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaCharacteristicMasterImpl implements EnoviaCMService{

	private static Logger LOGGER = Logger.getLogger(EnoviaCharacteristicMasterImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	@Override
	public HashMap<String, Map<String, String>> getCMdata(String objId, Environment env)throws MatrixException,IOException{
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		Context context = null;
		
		try 
		{
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			swContext.stop();
			LOGGER.info("CM CONTEXT ELAPSED TIME : "+swContext.getTime());

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();

			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				context.close();//Added for Defect 45181
				return hmAttrib;
			}

			Map<String,String> mpAttribResult = new HashMap<>();
			Map<String,String> mpHeaderContent = new HashMap<>();
			Map<String,String> mpCharacteristicInfo = new HashMap<>();
			Map<String,String> mpValues = new HashMap<>();


			CMBO cmbo = new CMBO();
			BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = cmbo.getCMPartSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = cmbo.getCMRelatedObjsSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
			StringValidatorUtil validator = new StringValidatorUtil();
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			DomainObject doDPP =  cmbo.getCMDO(context, objId);

			if (null == doDPP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				context.close();//Added for Defect 45181
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			Map resultMaps = doDPP.getInfo(context, slContextSelects);
			swAttributes.stop();
			LOGGER.info("CM GETINFO ELAPSED TIME : "+swAttributes.getTime());

			/**
			 * BLOCK USER IF OBJECT IS NOT RELEASED
			 */
			if (sct.isExternalUser() || sct.isStaffAUGUser()) {
				String strState = (validator.isNotNullOrEmpty((String) resultMaps.get(DomainConstants.SELECT_CURRENT)))
						? (String) resultMaps.get(DomainConstants.SELECT_CURRENT)
								: ConstantsUtil.EMPTY_STRING;

				if ((!strState.equals(ConstantsUtil.RELEASED) || strState.equals(ConstantsUtil.RELEASE)) && (!strState.isEmpty()) ) {
					HashMap<String, String> errorMap = new HashMap<>();
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strState.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					context.close();//Added for Defect 45181
					return hmAttrib;
				}
			}

			/**
			 * LOAD HEADER SECTION
			 * */
			mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_TYPE)))?(String)resultMaps.get(DomainConstants.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_NAME)))?(String)resultMaps.get(DomainConstants.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_REVISION)))?(String)resultMaps.get(DomainConstants.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_CURRENT)))?(String)resultMaps.get(DomainConstants.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);

			/**
			 * LOAD ATTRIBUTE FED SECTION
			 * */
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_DESCRIPTION)))?(String)resultMaps.get(DomainConstants.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(DomainConstants.SELECT_TYPE)))?(String)resultMaps.get(DomainConstants.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(DomainConstants.SELECT_OWNER)));
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);

			/**
			 * CHARACTERISTC INFORMATION SECTION
			 * */
			mpCharacteristicInfo=cmbo.getCharacteristicInformation(context,resultMaps);
			mpCharacteristicInfo = util.filterMapList(mpCharacteristicInfo);

			/**
			 * VALUES SECTION
			 * */
			mpValues=cmbo.getValues(context,resultMaps);
			mpValues = util.filterMapList(mpValues);

			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtilIRM.CHARACTERISTICINFORMATION, mpCharacteristicInfo);
			hmAttrib.put(ConstantsUtilIRM.VALUES, mpValues);

			pool.checkIn(context);
			sp.stop();
			LOGGER.info("CM MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "CM OBJECT NAME::"+resultMaps.get(DomainConstants.SELECT_NAME));
		} catch (MatrixException e) {
			LOGGER.error("Unable to getCMdata MatrixException"+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		return hmAttrib;
	}

}
