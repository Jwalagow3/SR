/**
 * Project 		: SpecsAnywhere
 * Program 		: MasterPackagingMaterialPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class MasterPackagingMaterialPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(MasterPackagingMaterialPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();

	public MasterPackagingMaterialPartBO() {
		// empty constructor
	}

	public MasterPackagingMaterialPartBO(String oid) {
		this.setObjectId(oid);
	}

	/**
	 * Method Name 			: getMPMPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getMPMPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: getMPMPBO : Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getMPMPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public DomainObject getMPMPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: getMPMPDO : Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getMasterPackagingMaterialPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getMasterPackagingMaterialPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getSubstanceSelectables(context));
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.addAll(getFileSelects(context));
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
				
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
	/**
	 * Method Name 			: getMPMPRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getMPMPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}
	
	
	/**
	 * Method Name 			: getCOName
	 * Method Description 	:
	 * @param context
	 * @param changeargs
	 * @return
	 * @throws Exception
	 */
   /* //SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- START
	public Map getCOName(Context context, String[]changeargs) throws Exception{
		Map mpLifecycle= new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		

		StringList slObjectSelects = new StringList();
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_NAME);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_ID);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_TITLE);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_APPROVER);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_STATUS);
		slObjectSelects.addElement(ConstantsUtil.REL_TASK_COMPL_DATE);
		

		slObjectSelects.addElement(ConstantsUtil.SO_APPROVER_NAME);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_STATUS);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_DATE);
		slObjectSelects.addElement(ConstantsUtil.SO_APPROVAL_TITLE);


		StringBuilder sbCOName= new StringBuilder();
		StringBuilder sbTaskName = new StringBuilder();			
		StringBuilder sbTaskApprover = new StringBuilder();
		StringBuilder sbTaskApproverFullName = new StringBuilder();
		StringBuilder sbTaskTitle = new StringBuilder();			
		StringBuilder sbTaskStatus = new StringBuilder();			
		StringBuilder sbTaskCompletionDate = new StringBuilder();


		String sCAName =ConstantsUtil.EMPTY_STRING;
		String sCAId =ConstantsUtil.EMPTY_STRING;
		String sCOName =ConstantsUtil.EMPTY_STRING;
		try
		{
			if(UIUtil.isNullOrEmpty(changeargs[1])){
				return new HashMap();
			}
			String sQuery =BusExtractUtil.createQueryPath(changeargs[1]);
			String sQueryResult =BusExtractUtil.executeTempQuery(context,sQuery);
			
			if(UIUtil.isNullOrEmpty(sQueryResult)){
				 return new HashMap();
			 }
				String[] sQueResult=sQueryResult.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
								
				if (sQueResult.length>2) 
				{
					sCAName =sQueResult[1];
					sCAId =sQueResult[2];
				}
				
				if (sQueResult.length>3)
				{
					sCOName =sQueResult[3];
				}
				

				if(UIUtil.isNotNullAndNotEmpty(sCAId)){
				 
				DomainObject domChangeAction = new DomainObject(sCAId);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_NAME);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_ID);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_TITLE);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_APPROVER);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_STATUS);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.REL_TASK_COMPL_DATE);
				
				Map mapCAInfo = domChangeAction.getInfo(context, slObjectSelects);
				
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_NAME);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_ID);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_TITLE);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_APPROVER);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_STATUS);
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_TASK_COMPL_DATE);
			
				
				if(mapCAInfo.isEmpty()){
					return new HashMap();
				}
				StringList slTaskName = validator.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_NAME));
				StringList slTaskId = validator.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_ID));
				StringList slTaskTitle= validator.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_TITLE));
				StringList slTaskStatus = validator.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_STATUS));
				StringList slTaskApprover = validator.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_APPROVER));

				String sApproverName = validator.isNotNullOrEmpty((String)mapCAInfo.get(ConstantsUtil.SO_APPROVER_NAME))?(String)mapCAInfo.get(ConstantsUtil.SO_APPROVER_NAME) : ConstantsUtil.EMPTY_STRING;
				String sApprovalStatus = validator.isNotNullOrEmpty((String)mapCAInfo.get(ConstantsUtil.SO_APPROVAL_STATUS))?(String)mapCAInfo.get(ConstantsUtil.SO_APPROVAL_STATUS) : ConstantsUtil.EMPTY_STRING;
				if(sApprovalStatus.equalsIgnoreCase(ConstantsUtil.TRUE)){
					sApprovalStatus=ConstantsUtil.APPROVED;
				}
				else{
					sApprovalStatus=ConstantsUtil.EMPTY_STRING;
				}
				String sApprovedDate = validator.isNotNullOrEmpty((String)mapCAInfo.get(ConstantsUtil.SO_APPROVAL_DATE))?(String)mapCAInfo.get(ConstantsUtil.SO_APPROVAL_DATE) : ConstantsUtil.EMPTY_STRING;
				String sApprovalTitle = validator.isNotNullOrEmpty((String)mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE))?(String)mapCAInfo.get(ConstantsUtil.SO_APPROVAL_TITLE) : ConstantsUtil.EMPTY_STRING;

				slTaskName.add(ConstantsUtil.SO_APPROVAL_SIGNATURE);
				slTaskApprover.add(sApproverName);
				slTaskStatus.add(sApprovalStatus);
				slTaskTitle.add(sApprovalTitle);
				StringList slTaskApproverFullName =util.getPersonFullName(context,slTaskApprover);
				slTaskApprover.remove(sApproverName);
				slTaskStatus = util.MapSlType(slTaskStatus);


				StringList slTaskCompletionDate= validator.isNotNullOrEmpty((StringList) mapCAInfo.get(ConstantsUtil.REL_TASK_COMPL_DATE));
				slTaskCompletionDate.add(sApprovedDate);

				String strTaskName = validator.isNotNullOrEmpty(slTaskName.toString())?slTaskName.toString():ConstantsUtil.EMPTY_STRING;
				String strTaskId = validator.isNotNullOrEmpty(slTaskId.toString())?slTaskId.toString():ConstantsUtil.EMPTY_STRING;
				String strTaskTitle = validator.isNotNullOrEmpty(slTaskTitle.toString())?slTaskTitle.toString():ConstantsUtil.EMPTY_STRING;
				String strTaskStatus = validator.isNotNullOrEmpty(slTaskStatus.toString())?slTaskStatus.toString():ConstantsUtil.EMPTY_STRING;
				String strTaskApprover = validator.isNotNullOrEmpty(slTaskApprover.toString())?slTaskApprover.toString():ConstantsUtil.EMPTY_STRING;
				String strTaskApproverFullName = validator.isNotNullOrEmpty(slTaskApproverFullName.toString())?slTaskApproverFullName.toString():ConstantsUtil.EMPTY_STRING;
				String strTaskCompletionDate = validator.isNotNullOrEmpty(slTaskCompletionDate.toString())?slTaskCompletionDate.toString():ConstantsUtil.EMPTY_STRING;

				strTaskName= util.replaceSpecialSymbols(strTaskName);
				strTaskId= util.replaceSpecialSymbols(strTaskId);
				strTaskTitle= util.replaceSpecialSymbols(strTaskTitle);
				strTaskStatus= util.replaceSpecialSymbols(strTaskStatus);
				strTaskApprover= util.replaceSpecialSymbols(strTaskApprover);
				strTaskApproverFullName= util.replaceSpecialSymbols(strTaskApproverFullName);
				strTaskCompletionDate= util.replaceSpecialSymbols(strTaskCompletionDate);;	

				mpLifecycle.put(ConstantsUtil.NAME, strTaskName);
				mpLifecycle.put(ConstantsUtil.APPROVER, strTaskApproverFullName);
				mpLifecycle.put(ConstantsUtil.APPROVER_FULLNAME, strTaskApprover);
				mpLifecycle.put(ConstantsUtil.TITLE, strTaskTitle);
				mpLifecycle.put(ConstantsUtil.APPROVALSTATUS, strTaskStatus);
				mpLifecycle.put(ConstantsUtil.APPROVALDATE, strTaskCompletionDate);
				mpLifecycle.put(ConstantsUtil.CO, sCOName.trim()+ConstantsUtil.SYMBL_PIPE+sCAName.trim());
				}
			
		}catch(Exception e){
			LOGGER.info("Unable to MPMPBO method getCOName "+e);
			return new HashMap();
		}
		return mpLifecycle;
	}
    //SPEC: 03-31-2020: Added for 18x.6 DEV by Sanjeeva -- END
*/	
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.COMP_NAME); 
		busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID); 
		busSelect.add(ConstantsUtil.COMP_DESC); 
		busSelect.add(ConstantsUtil.COMP_CASNUM);  		
		busSelect.add(ConstantsUtil.COMP_QTY);  			
		busSelect.add(ConstantsUtil.COMP_RPRSTATUS);
		busSelect.add(ConstantsUtil.COMP_ECNUMBER);
		busSelect.add(ConstantsUtil.COMP_REACHSTATUS);  		

		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
        busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
        
		return busSelect;
	}

	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.STRPRINTINGPROSS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDECORATIONDETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);
		
		busSelect.add(ConstantsUtil.OWNERSHIP);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOAIMPACTCONFIRMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PROJECTMILESTONE);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		
		//SPEC: 04/11/2020: Added for 18x.5 Defect 37084 -- START
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: 04/11/2020: Added for 18x.5 Defect 37084 -- END
		//SPEC: <11.20.2020>: Chandra Added for Defect :37490 ## --START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
		//SPEC: <11.20.2020>: Chandra Added for Defect :37490 ## --END
		//SPEC: Release SR18x.5.2 - Added for Defect# 39147  by Guna on Date 12/02/2021 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGUNIT);
		//SPEC: Release SR18x.5.2 - Added for Defect# 39147  by Guna on Date 12/02/2021 -- END
		
		//SPEC: 04/23/2020: Added for 18x6.0 Defect# 42725 by Sanjeeva-- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS);
		//SPEC: 04/23/2020: Added for 18x6.0 Defect# 42725 by Sanjeeva-- END
		
		//SPEC: 06/11/2021: Added for 18x6.1 Defect# 43499 by Manikanta-- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		//SPEC: 06/11/2021: Added for 18x6.1 Defect# 43499 by Manikanta-- END
		
		//SPEC: 06/24/2021: Added for 18x6.1 Defect# 43817 by Manikanta-- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		//SPEC: 06/24/2021: Added for 18x6.1 Defect# 43817 by Manikanta-- END
		
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPOSTCOSUMERRECYCLEDCONTENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		
		//Added for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
	
		

		
		return relSelect;
	}
	
	
	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(MapList mapList) {
		Map<String,String> mpEBOMResult = new HashMap<String,String>();

		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMDesc = new StringBuilder();
		StringBuilder sbEBOMTW = new StringBuilder();
		StringBuilder sbEBOMLegacyEnvClass = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMLayer = new StringBuilder();
		StringBuilder sbEBOMTradedName = new StringBuilder();
		StringBuilder sbEBOMMfr = new StringBuilder();
		StringBuilder sbEBOMPostCon = new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbMinqty= new StringBuilder();
		StringBuilder sbMaxqty= new StringBuilder();
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		try {
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				String sId =(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String strDesc =(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String strMfr =(String)objectMap.get(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME);
				String strLayer =(String)objectMap.get(ConstantsUtil.COMP_MATELAYER);
				String strLegacyEnv =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
				String strTW =(String)objectMap.get(ConstantsUtil.SELECT_COMP_MATERIAL_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
				String strPostCon =(String)objectMap.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPOSTCOSUMERRECYCLEDCONTENT);
				String strTradename =(String)objectMap.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_TARGET);
				String sFN =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				String sTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sComments=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				String sRD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				sRD = sRD.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
				String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
	
				
				util.formatData(sbEBOMName,sName);
				util.formatData(sbEBOMDesc,strDesc);
				util.formatData(sbEBOMMfr,strMfr);
				util.formatData(sbEBOMLegacyEnvClass,strLegacyEnv);
				util.formatData(sbEBOMPostCon,strPostCon);
				util.formatData(sbEBOMTW,strTW);
				util.formatData(sbEBOMLayer,strLayer);
				util.formatData(sbEBOMTradedName,strTradename);
				util.formatData(sbEBOMId,sId);
				util.formatData(sbEBOMFN,sFN);
				util.formatData(sbEBOMTitle,sTitle);
				util.formatData(sbEBOMCommnts,sComments);
				util.formatData(sbMinqty,strMinqty);
				util.formatData(sbMaxqty,strMaxqty);
	
			}
			
			mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.DESCRIPTION, sbEBOMDesc.toString());
			mpEBOMResult.put(ConstantsUtil.MANUFACTURER, sbEBOMMfr.toString());
			mpEBOMResult.put(ConstantsUtil.POSTCONSUMERRECYCLED, sbEBOMPostCon.toString());
			mpEBOMResult.put(ConstantsUtil.TARGET_PERCEN_WBW, sbEBOMTW.toString());
			mpEBOMResult.put(ConstantsUtil.TRADENAME, sbEBOMTradedName.toString());
			mpEBOMResult.put(ConstantsUtil.LEGACYENVCLASS, sbEBOMLegacyEnvClass.toString());
			mpEBOMResult.put(ConstantsUtil.LAYER_DESC, sbEBOMLayer.toString());
			mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.MIN, sbMinqty.toString());
			mpEBOMResult.put(ConstantsUtil.MAX, sbMaxqty.toString());
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		}catch(Exception e){

			LOGGER.error("Error from MasterPackagingMaterialPartBO:  parseMaplist"+e);
			return new HashMap();
		}
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
		return mpEBOMResult;
		
	}
	
	
	/**
	 * Method Name 			: getSubstitute
	 * Method Description 	:
	 * @param mapList
	 * @return
	 */
	public Map<String, String> getSubstitute(MapList mapList) 
	{
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();
		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentRev = new StringBuilder();
		StringBuilder sbEBOMParentTitle = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMRefDoc= new StringBuilder();
		StringBuilder sbEBOMFN = new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMSubType= new StringBuilder();
		StringBuilder sbEBOMEffectDate= new StringBuilder();
		StringBuilder sbEBOMUntilDate= new StringBuilder();
		StringBuilder sbEBOMCobNum= new StringBuilder();
		StringBuilder sbEBOMChildRev= new StringBuilder();
		StringBuilder sbMF= new StringBuilder();
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		try {
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				String sChildExists=(String)objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE);
				if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)){
					String sParentName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
					String sParentRev =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
					String sParentTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					String sChildName =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
					String sChildRev=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
					String sCombinationNum=(String)objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
					String sChildTitle =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
					String sChildType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
					sChildType = util.mapType(sChildType);
					//Modified for Defect# 37591 -- START
					//String sSUBType =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
					String sSUBType =(String)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
					//Modified for Defect# 37591 -- END
					String sQTY =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
					String sBASEUOM =(String)objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
					String sEffectvityDate =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
					String sUntilDate=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
					String sRefDoc =(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
					String sComments=(String)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
					String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
	
					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
					
					util.formatData(sbEBOMParentId,sParentID);
					util.formatData(sbEBOMId,sChildId);
					util.formatData(sbEBOMParentName,sParentName);
					util.formatData(sbEBOMParentRev,sParentRev);
					util.formatData(sbEBOMParentTitle,sParentTitle);
					util.formatData(sbEBOMName,sChildName);
					util.formatData(sbEBOMId,sChildId);
					util.formatData(sbEBOMChildRev,sChildRev);
					util.formatData(sbEBOMCobNum,sCombinationNum);
					util.formatData(sbEBOMTitle,sChildTitle);
					util.formatData(sbEBOMType,sChildType);
					util.formatData(sbEBOMSubType,sSUBType);
					util.formatData(sbEBOMQTY,sQTY);
					util.formatData(sbEBOMBuom,sBASEUOM);
					util.formatData(sbEBOMEffectDate,sEffectvityDate);
					util.formatData(sbEBOMUntilDate,sUntilDate);
					util.formatData(sbEBOMRefDoc,sRefDoc);
					util.formatData(sbEBOMCommnts,sComments);
					util.formatData(sbMF,strMF);
	
				}
			}
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		} catch(Exception e) {

			LOGGER.error("Error from MasterPackagingMaterialPartBO:  getSubstitute"+e);
			return new HashMap();
		}
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
		return mpEBOMResult;

	}

	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	: 
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Context context, Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			String sDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sQTY      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			String sQTYUom   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT));
			String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT));
			String sMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			String sMFR     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sTrN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sPCID    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTINDUSTRIAL));
			String sPhase   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String strCurrent	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CURRENT));
			
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);
			
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
			//mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.SEQ,sFN);
			//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			mpSubStanceResult.put(ConstantsUtil.QTYUOM,sQTYUom);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.POST_INDUSTRIAL,sPCID);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.PHASE,sPhase);
			mpSubStanceResult.put(ConstantsUtil.STATE, strCurrent);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			
			mpSubStanceResult=util.verifyOwnership(context,mpSubStanceResult);
			
		}catch(Exception e){
			LOGGER.error("Error from MasterPackagingMaterialPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}

	
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();


		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, getTo, getFrom, (short)0,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			
			if(mlDerivedList.isEmpty()){
				return new HashMap();
			}
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				StringValidatorUtil validator = new StringValidatorUtil();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent= util.mapType((String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);
				}else{
					
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);
			}

			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : MasterPackagingMaterialPartBO Method :updateDerivedDataInfo "+e);
			return new HashMap();
		}
		return mpDerived;
	}

	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList(){
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.COMP_NAME); 
		slMultiSelects.add(ConstantsUtil.COMP_TYPE); 
		slMultiSelects.add(ConstantsUtil.COMP_ID);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC); 
		slMultiSelects.add(ConstantsUtil.COMP_CASNUM);  		
		slMultiSelects.add(ConstantsUtil.COMP_QTY);  			
		slMultiSelects.add(ConstantsUtil.COMP_RPRSTATUS);
		slMultiSelects.add(ConstantsUtil.COMP_ECNUMBER);
		slMultiSelects.add(ConstantsUtil.COMP_REACHSTATUS); 	
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_CURRENT);

		slMultiSelects.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
        slMultiSelects.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
        
        slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
        slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
        slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
        slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
        slMultiSelects.add(ConstantsUtil.ATL_STATE);
        slMultiSelects.add(ConstantsUtil.STRPRINTINGPROSS);
        
        return slMultiSelects;
	}

	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	:
	 */
	public  void removeMultiList(){
		

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RPRSTATUS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ECNUMBER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REACHSTATUS);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CLASSIFIED_ITEM);
        DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
        
      //SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--START
        DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
        DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
        DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
        DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
        //SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END

	}
	
	
	//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
	public static StringList getSecuritySelects(Context context) {
		
		StringList slIpSelects = new StringList();
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		
		return slIpSelects;

	}
	//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
	
	
	
	
	//SPEC : Modified by Chandra on 6-Jan-2021 for  Requirement 38258 --START
	public Map<String, String> updateMaterials(Context context, DomainObject dob, boolean bFlag) throws Exception {
		Map<String, String> mpComp = new HashMap<String, String>();

		StringValidatorUtil validator = new StringValidatorUtil();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbENVClass = new StringBuilder();
		StringBuilder sbPostCust = new StringBuilder();
		StringBuilder sbManuf = new StringBuilder();
		StringBuilder sbQTY = new StringBuilder();
		StringBuilder sbMaxPercent = new StringBuilder();
		StringBuilder sbMinPercent = new StringBuilder();
		StringBuilder sbMateLayer = new StringBuilder();
		StringBuilder sbGenerationNum = new StringBuilder();
		StringBuilder sbComment = new StringBuilder();
		StringBuilder sbSeq = new StringBuilder();
		StringBuilder sbTarget = new StringBuilder();
		StringBuilder sbPCID = new StringBuilder();
		StringBuilder sbID = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbQTYUom = new StringBuilder();
		StringBuilder sbParentName = new StringBuilder();//Added by Ajay for 22x.06 Req.9264


		StringBuilder sbClassfied = new StringBuilder();
		StringBuilder sbIPClassAttr = new StringBuilder();

		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		slBusSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		//SPEC: Release 18x.5.2: Added for Defect 37166 by Amman -- START
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME);
		//SPEC: Release 18x.5.2: Added for Defect 37166 by Amman -- END
		//SPEC: Release SR18x.5.2: Amman Added for Defect :39322 ## --START
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALTOPGPLIENVIRONMENTALCLASS);
		//SPEC: Release SR18x.5.2: Amman Added for Defect :39322 ## --END

		StringList slRelSelects = new StringList();
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
		//SPEC: Release 18x.5.2: Commented for Defect 37166 by Amman -- START
		//slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME);
		//SPEC: Release 18x.5.2: Commented for Defect 37166 by Amman -- END
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		slRelSelects.add("attribute[Quantity Unit Of Measure]");
		// Guna Added for Defect 37743  18x.5.2 Release -- START
		//START :: gaikwad.tg
		slRelSelects.add("from.name");
		slRelSelects.add("from.id");
		//END :: gaikwad.tg
		BigDecimal dDefaultValue = BigDecimal.valueOf(0.0);
		// Guna Added for Defect 37743  18x.5.2 Release -- END
		MapList mlCopmonentsList = new MapList();
		//SPEC: <11.05.2021>: Bala Modified for 33248 External Req  Dev 18x.6.0.1   -- START
		SecurityService sec= new SecurityService();
		String sUserType =sec.getUserType();
		String sWhere=ConstantsUtil.EMPTY_STRING;
		
		if (sUserType.equals(ConstantsUtil.PG_CM) || sUserType.equals(ConstantsUtil.PG_SP)) {
			sWhere= "current==Approved || current==Release || current==Released";
		}
		try {
			mlCopmonentsList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, false, true, (short) 0,
					sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
		//SPEC: <11.05.2021>: Bala Modified for 33248 External Req Dev 18x.6.0.1   -- END
			if (bFlag) {
				mlCopmonentsList = util.filterPhase(mlCopmonentsList);
			}

			/*
			 * if(mlCopmonentsList.isEmpty()){ return new HashMap(); }
			 */
			//SPEC: Release SR18x.6.0 - Added for Defect# 40358  by gaikwad.tg on Date 19 April 2021 -- START
			//SPEC: Release 18x.5.2: Added for Defect 37166 by Amman -- START
			//mlCopmonentsList.sort(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE,"ascending","string");
			//SPEC: Release 18x.5.2: Added for Defect 37166 by Amman -- END
			String strTempId = dob.getObjectId(context);
			mlCopmonentsList = util.getSortedMaplistWithSequence(context, mlCopmonentsList, strTempId);
			//SPEC: Release SR18x.6.0 - Added for Defect# 40358  by gaikwad.tg on Date 19 April 2021 -- END
			String pID = DomainConstants.EMPTY_STRING;
			Map resultMapsNew = new HashMap<>();
			try 
			{
				resultMapsNew = dob.getInfo(context,slBusSelects);
				 pID	 =  validator.getStringEquivalentForStringList(resultMapsNew.get(ConstantsUtil.SELECT_ID));
				mlCopmonentsList = util.getSortedMaplistWithSequence(context, mlCopmonentsList, pID);
				//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
				dob.close(context);
				//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
			} catch (MatrixException e)
			{
				e.printStackTrace();
			}
			String pType = validator.getStringEquivalentForStringList(resultMapsNew.get(ConstantsUtil.SELECT_TYPE));
			//SPEC: Release SR18x.5.2 - Added for Defect #38221 and #38630 by Bala on Date Feb 12, 2021 -- START
			pType= util.mapType(pType);
			//SPEC: Release SR18x.5.2 - Added for Defect #38221 and #38630 by Bala on Date Feb 12, 2021 -- END
			String pName = validator.getStringEquivalentForStringList(resultMapsNew.get(ConstantsUtil.SELECT_NAME));
			String pRev = validator.getStringEquivalentForStringList(resultMapsNew.get(ConstantsUtil.SELECT_REVISION));
			String pDesc = validator.getStringEquivalentForSubstituteString(resultMapsNew.get(ConstantsUtil.SELECT_DESCRIPTION));
			String pCurrent1 = validator.getStringEquivalentForSubstituteString(resultMapsNew.get(ConstantsUtil.SELECT_CURRENT));
			String pTitle = validator.getStringEquivalentForSubstituteString(resultMapsNew.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
			String sPPostCon = validator.getStringEquivalentForStringList(  resultMapsNew.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT));
			String sPPCID = validator.getStringEquivalentForStringList(  resultMapsNew.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT));
			//START :: gaikwad.tg :: Defect#38630,37743
			/*if(UIUtil.isNotNullAndNotEmpty(sPPostCon))
			sPPostCon =util.getPostRecycledContent(new BigDecimal(sPPostCon),dDefaultValue);
			if(UIUtil.isNotNullAndNotEmpty(sPPCID))
			sPPCID =util.getPostRecycledContent(new BigDecimal(sPPCID),dDefaultValue);
			*/
			String strTempPostConsumerRecycled = DomainConstants.EMPTY_STRING;
			String strTempPostIndustrialRecycled = DomainConstants.EMPTY_STRING;
			//END :: gaikwad.tg :: Defect#38630,37743
			if(mlCopmonentsList!=null && mlCopmonentsList.size()>0)
			{
				//START :: gaikwad.tg :: Defect#38630,37743
				strTempPostConsumerRecycled = util.getPostRecycledContent(context, mlCopmonentsList, ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT);
				strTempPostIndustrialRecycled = util.getPostRecycledContent(context, mlCopmonentsList, ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
				//END :: gaikwad.tg :: Defect#38630,37743
				util.formatData(sbClassfied, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbIPClassAttr, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbName, pName);
				util.formatData(sbType, pType);
				util.formatData(sbTitle, pTitle);
				util.formatData(sbDesc, pDesc);
				util.formatData(sbCurrent, pCurrent1);
				util.formatData(sbENVClass, ConstantsUtil.EMPTY_STRING);
				//START :: gaikwad.tg :: Defect#38630,37743
				//util.formatData(sbPostCust, (UIUtil.isNotNullAndNotEmpty(sPPostCon)?sPPostCon:ConstantsUtil.EMPTY_STRING));
				util.formatData(sbPostCust,strTempPostConsumerRecycled);
				//END :: gaikwad.tg :: Defect#38630,37743
				util.formatData(sbManuf, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbQTY, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbMaxPercent, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbMinPercent, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbMateLayer, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbComment, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbSeq, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbTarget, ConstantsUtil.EMPTY_STRING);
				//START :: gaikwad.tg :: Defect#38630,37743
				//util.formatData(sbPCID, (UIUtil.isNotNullAndNotEmpty(sPPCID)?sPPCID:ConstantsUtil.EMPTY_STRING));
				util.formatData(sbPCID,strTempPostIndustrialRecycled);
				//END :: gaikwad.tg :: Defect#38630,37743
				//START :: gaikwad.tg :: Defect#38905
				util.formatData(sbID, pID);
				//END :: gaikwad.tg :: Defect#38905
				util.formatData(sbQTYUom, ConstantsUtil.EMPTY_STRING);
				util.formatData(sbParentName, ConstantsUtil.EMPTY_STRING);//Added by Ajay for 22x.06 Req.9264
			}
			//END :: gaikwad.tg
			Iterator objectListItr = mlCopmonentsList.iterator();

			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();

				String sName = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_NAME));
				String sType = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.TYPE));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sTitle = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sTitle = validator.getStringEquivalentForSubstituteString(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				//String sDesc = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sDesc = validator.getStringEquivalentForSubstituteString(  objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				String sParentName	 =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME));//Added by Ajay for 22x.06 Req.9264

				String sCurrent = validator.getStringEquivalentForString(  objectMap.get(ConstantsUtil.SELECT_CURRENT));
				//Added for Defect #37260 -- START
				if (sCurrent.equalsIgnoreCase(ConstantsUtil.APPROVED)) {
					sCurrent = ConstantsUtil.RELEASED;
				}
				//Added for Defect #37260 -- END
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sENVClass = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS));
				//SPEC: Release SR18x.5.2: Amman Added for Defect :39322 ## --START
				//String sENVClass = validator.getStringEquivalentForSubstituteString(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS));
				String sENVClass = validator.getStringEquivalentForSubstituteString(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALTOPGPLIENVIRONMENTALCLASS));
				//SPEC: Release SR18x.5.2: Amman Added for Defect :39322 ## --END
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sID = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ID));
				String sQTY = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
				//SPEC: <13.05.2021>: Bala Added for External Defect Dev 18x.6.0.1   -- START
				if (sQTY.endsWith(".0"))
				{
					Float objF = new Float(sQTY);
					sQTY =  String.valueOf(objF.intValue());
				}
				//SPEC: <13.05.2021>: Bala Added for External Defect Dev 18x.6.0.1   -- END
				String sMax = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT));
				String sMin = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sMaterialLayer = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER));
				String sMaterialLayer = validator.getStringEquivalentForSubstituteString(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sPostCon = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sManuf = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER));
				String sManuf = validator.getStringEquivalentForSubstituteString(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sPCID = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sComment = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
				String sComment = validator.getStringEquivalentForSubstituteString(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sSequence = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sTarget = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME));
				String sTarget = validator.getStringEquivalentForSubstituteString(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String strClassFied = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME));
				String sIPClassfication = validator.getStringEquivalentForStringList(  objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String sQTYUom = validator.getStringEquivalentForStringList(  objectMap.get("attribute[Quantity Unit Of Measure]"));
				// Guna Added for Defect 37743  18x.5.2 Release -- START

				sPostCon =util.getPostRecycledContent(new BigDecimal(sPostCon),dDefaultValue);
				sPCID =util.getPostRecycledContent(new BigDecimal(sPCID),dDefaultValue);
			
				// Guna Added for Defect 37743  18x.5.2 Release -- END
				
				//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- START
				//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
				/*boolean showData=util.checkHasAccess(context, null, sID);
				if (!showData && util.isModificatinRequired()) {
				
					continue;
				}*/
				//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
				//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- END

				util.formatData(sbClassfied, strClassFied);
				util.formatData(sbIPClassAttr, sIPClassfication);
				util.formatData(sbName, sName);
				util.formatData(sbType, sType);
				util.formatData(sbTitle, sTitle);
				util.formatData(sbDesc, sDesc);
				util.formatData(sbCurrent, sCurrent);
				util.formatData(sbENVClass, sENVClass);
				util.formatData(sbPostCust, sPostCon);
				util.formatData(sbManuf, sManuf);
				util.formatData(sbQTY, sQTY);
				util.formatData(sbMaxPercent, sMax);
				util.formatData(sbMinPercent, sMin);
				util.formatData(sbMateLayer, sMaterialLayer);
				util.formatData(sbComment, sComment);
				util.formatData(sbSeq, sSequence);
				util.formatData(sbTarget, sTarget);
				util.formatData(sbPCID, sPCID);
				util.formatData(sbID, sID);
				util.formatData(sbQTYUom, sQTYUom);
				util.formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
			}

			mpComp.put(ConstantsUtil.ID, sbID.toString());
			mpComp.put(ConstantsUtil.NAME, sbName.toString());
			mpComp.put(ConstantsUtil.TYPE, sbType.toString());
			mpComp.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpComp.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
			mpComp.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpComp.put(ConstantsUtil.LEGACY_ENV_CLASS, sbENVClass.toString());
			mpComp.put(ConstantsUtil.TARGET_PERCEN_WBW, sbQTY.toString());
			mpComp.put(ConstantsUtil.MIN_PERCEN_WBW, sbMinPercent.toString());
			mpComp.put(ConstantsUtil.MAX_PERCEN_WBW, sbMaxPercent.toString());
			mpComp.put(ConstantsUtil.LAYER, sbMateLayer.toString());
			mpComp.put(ConstantsUtil.POSTCONSUMERRECYCLED, sbPostCust.toString());
			mpComp.put(ConstantsUtil.MANUFACTURER, sbManuf.toString());
			mpComp.put(ConstantsUtil.COMP_COMMENTS, sbComment.toString());
			mpComp.put(ConstantsUtil.FN, sbSeq.toString());
			mpComp.put(ConstantsUtil.TRADENAME, sbTarget.toString());
			mpComp.put(ConstantsUtil.POST_INDUSTRIAL, sbPCID.toString());
			mpComp.put(ConstantsUtil.SECURITY, sbClassfied.toString());
			mpComp.put(ConstantsUtil.IPCLASSES, sbIPClassAttr.toString());
			mpComp.put(ConstantsUtil.QTYUOM, sbQTYUom.toString());
			mpComp.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString().trim());//Added by Ajay for 22x.06 Req.9264

		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : MasterPackagingMaterialPartBO Method :updateMaterials " + e);
			return new HashMap();
		}

		return mpComp;

		//return filterMapList(mpComp);
	}
	
	//SPEC : Modified by Chandra on 6-Jan-2021 for  Requirement 38258 --END
}