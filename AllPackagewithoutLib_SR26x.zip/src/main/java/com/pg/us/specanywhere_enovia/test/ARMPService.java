/*package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.ARMPBO;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class ARMPService {

	private static Logger LOGGER = Logger.getLogger(ARMPService.class);

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();

		//String objId = "20336.41905.18433.18227";
		String objId = "20336.41905.32496.24384";
		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
		Context context = pool.checkOut();

		boolean bAllInfoView = true;
		boolean bSupplierView = true;
		boolean bManufacturerView = true;

		
		 * User Profile
		 * 
	    SecurityService sct = new SecurityService();
	    String sUserType = sct.getUserType();
	    boolean bAllInfoView = false;
	    boolean bSupplierView = false;
	    boolean bManufacturerView = false;

	    switch (sUserType) {
	    	case ConstantsUtil.PG:
	    		bAllInfoView = true;
	    		break;

	    	case ConstantsUtil.PGSTAFF:
	    		bAllInfoView = true;
	    		break;

	    	case ConstantsUtil.PG_CM:
	    		bManufacturerView = true;
	    		break;

	    	case ConstantsUtil.PG_SP:
	    		bSupplierView = true;
	    		break;
	    }


		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpPlantResult = new HashMap<String,String>();
		Map<String,String> mpWeightResult = new HashMap<String,String>();
		Map<String,String> mpPartSpecResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mpMasterSpecs = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mpPerformChar = new HashMap<String,String>();			
		Map<String,String> mpNotes = new HashMap<String,String>();
		Map<String,String> mpStartingMaterials = new HashMap<String,String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
		Map<String,String> mpDerivedToResult = new HashMap<String,String>();
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		Map<String,String> mpSecurity = new HashMap<String,String>();
		Map<String,String> mpCertification = new HashMap<String,String>();
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		//Map<String,String> mpRelatedATS = new HashMap<String,String>();
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		Map<String,String> mpMaterialComposition = new HashMap<String,String>();
		
		ARMPBO RawBO = new ARMPBO();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		CommonBusUtilBO commonBo = new CommonBusUtilBO();


		Map<String, StringList> BusinessObjectSelectableMap = RawBO.getARMPPartSelectables(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringValidatorUtil validator = new StringValidatorUtil();
		*//**
		 * Get Attribute Info
		 * *//*
		DomainObject doARMP =  RawBO.getArmpDO(context, objId);
		RawBO.addMultiList();
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doARMP.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("ARMP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		RawBO.removeMultiValueList();

		String lastUpdatedUser = "";
		//Common usage Variables
		String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sClassifictaion = util.getClassification(resultMaps);

		if(bManufacturerView || bAllInfoView || bSupplierView) {

			*//**
			 * LOAD HEADER SECTION
			 * *//*
			mpHeaderContent.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			
			//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
			mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			if(!bManufacturerView && !bSupplierView){
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
			}
			//SPEC: 10/09/2020: Modified for 18x.5 DEV -- END
			
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			mpHeaderContent.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
			mpHeaderContent.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
			mpHeaderContent.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))));
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

			String sClassification = util.getClassification(resultMaps);
			mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, (sClassification));
			
			*//**
			 * LOAD ATTRIBUTE SECTION
			 * *//*
			//Contract Manufacturer View && All Info View
			if(!bSupplierView){
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER,  ConstantsUtil.EMPTY_STRING);
			}
			mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_TEMPLATE)))?(String)resultMaps.get(ConstantsUtil.STR_TEMPLATE) : ConstantsUtil.EMPTY_STRING);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SHELFLIFE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MATERIALCERTIFICATIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS) : ConstantsUtil.EMPTY_STRING);
			
			mpAttribResult.put(ConstantsUtil.APPLICATION_AUTHORIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED))));
			mpAttribResult.put(ConstantsUtil.MATERIALRESTRICTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION))));
			mpAttribResult.put(ConstantsUtil.MATERIALRESTRICTIONCOMMENTS, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS))));
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			
			if(bSupplierView){
				mpAttribResult.put(ConstantsUtil.REACHEXEMPT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_EXEMPT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_EXEMPT) : ConstantsUtil.EMPTY_STRING);
			}
			
			*//**
			 * LOAD PERFORMANCE CHAR SECTION
			 * *//* 
			Map paramMap = new HashMap();
			paramMap.put(ConstantsUtil.OBJECT_ID, objId);
			paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
			paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
			paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

			PerformanceCharcteristics perform = new PerformanceCharcteristics();
			StopWatch swPerfChar = new StopWatch();
			swPerfChar.start();
			MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
			if(!mlPerformChar.isEmpty())
			{
				FinishedProductPartBO fppBO = new FinishedProductPartBO();
				MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
				//mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
				swPerfChar.stop();
				LOGGER.info("ARMP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
			}


			*//**
			 * LOAD WEIGHT SECTION
			 * *//*
			//Contract Manufacturer View & All Info View
			mpWeightResult.put(ConstantsUtil.TYPE, util.mapType(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpWeightResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult = util.filterMapList(mpWeightResult);

			*//**
			 * LOAD PART-SPEC SECTION
			 * *//*
			//Contract Manufacturer View & All Info View
			//mpPartSpecResult = util.updatePartSpec(context,resultMaps);
			
			*//**
			 * LOAD REFERENCE DOCS SECTION
			 * *//*
			StopWatch swReference= new StopWatch();
			swReference.start();
			MasterCOPBO mcop = new MasterCOPBO();
			//mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
			swReference.stop();
			LOGGER.info("ARMP  Reference ELAPSED TIME : "+swReference.getTime());
			
			*//**
			 * LOAD MASTER SPECS SECTION
			 * *//*
			//Contract Manufacturer View & All Info View
			StopWatch swmpMasterSpecs = new StopWatch();
			swmpMasterSpecs.start();
			mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
			
			swmpMasterSpecs.stop();
			LOGGER.info("ARMP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());

			*//**
			 * LOAD NOTES
			 * *//*
			mpNotes=mcop.updateNotes(context, resultMaps);
			
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			*//**
			 * LOAD MATERIAL RESULTS SECTION
			 * *//*
			StopWatch swMaterial = new StopWatch();
			swMaterial.start();
			mpMaterialComposition = RawBO.getSubstances(context,sContextObjectId);
			//mpMaterialComposition =util.verifyOwnership(context,mpMaterialComposition);
			swMaterial.stop();
			LOGGER.info("ARMP MATERIAL ELAPSED TIME : "+swMaterial.getTime());
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			
			mpMaterialComposition.put(ConstantsUtil.NAME, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_NAME)));	
			mpMaterialComposition.put(ConstantsUtil.TYPE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE)));	
			mpMaterialComposition.put(ConstantsUtil.TITLE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE)));
			mpMaterialComposition.put(ConstantsUtil.SUBSTANCENAME, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SUBNAME)));		
			mpMaterialComposition.put(ConstantsUtil.MIN_PERCEN_WBW, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPGMINIMUMPERCENTWEIGHTBYWEIGHT)));	
			mpMaterialComposition.put(ConstantsUtil.MAX_PERCEN_WBW, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMAXIMUMPERCENTWEIGHTBYWEIGHT)));	
			mpMaterialComposition.put(ConstantsUtil.UOM, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM)));				
			mpMaterialComposition.put(ConstantsUtil.QTY, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY)));				
			mpMaterialComposition.put(ConstantsUtil.FUNCTIONS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.FUNCTIONS)));				
			mpMaterialComposition.put(ConstantsUtil.DRYWEIGHT, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DRYWEGHT)));		
			mpMaterialComposition.put(ConstantsUtil.IC, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ISCONTAM)));				
			mpMaterialComposition.put(ConstantsUtil.CAS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CASNUM)))	;			
			mpMaterialComposition.put(ConstantsUtil.STATE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_STATE)));				
			mpMaterialComposition.put(ConstantsUtil.REVISION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REVS)))	;			
			mpMaterialComposition.put(ConstantsUtil.DESCRIPTION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC)));			
			mpMaterialComposition.put(ConstantsUtil.PHASE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE)));		
			mpMaterialComposition.put(ConstantsUtil.ID, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID)));
			//SPEC: 10/09/2020: Modified for 18x.5 DEV -- END
			if(bSupplierView || bManufacturerView) {
				mpMaterialComposition=util.filterPhase(mpMaterialComposition);
				mpMaterialComposition = util.filterMapList(mpMaterialComposition);
				
			}

			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			*//**
			 * LOAD RELATED ATS SECTION
			 * *//*
			StopWatch swAts = new StopWatch();
			swAts.start();
			mpRelatedATS=util.getRelatedAts(context, doARMP);
			
			mpRelatedATS=util.filterMapList(mpRelatedATS);
			if(!mpRelatedATS.isEmpty()){
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
			}else{
				mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
			}

			if(bManufacturerView) {
				mpRelatedATS=util.filterPhase(mpRelatedATS);
			}

			swAts.stop();
			LOGGER.info("ARMP ATS ELAPSED TIME : "+swAts.getTime());
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		}

		if(bAllInfoView ) {
			*//**
			 * LOAD CERTIFICATIONS SECTION
			 * *//*
			MapList mlCertifications = commonBo.getCertificationClaims(context, objId);
			Iterator itrCerts = mlCertifications.iterator();
			StringBuilder sbCertName = new StringBuilder();
			StringBuilder sbCertRev = new StringBuilder();
			StringBuilder sbCertType = new StringBuilder();
			StringBuilder sbCertDesc = new StringBuilder();
			StringBuilder sbCertState = new StringBuilder();
			StringBuilder sbCertifications = new StringBuilder();
			StringBuilder sbStatus = new StringBuilder();
			StringBuilder sbCExpirationDate = new StringBuilder();

			while (itrCerts.hasNext()) {
				Map objectMap = (Map) itrCerts.next();
				formatData(sbCertName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
				formatData(sbCertRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
				formatData(sbCertType, util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
				formatData(sbCertDesc, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION)));
				formatData(sbCertState, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
				formatData(sbCertifications, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS)));
				formatData(sbStatus, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)));
				formatData(sbStatus, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)));
			}
			mpCertification.put(ConstantsUtil.NAME, sbCertName.toString());
			mpCertification.put(ConstantsUtil.REVISION, sbCertRev.toString());
			mpCertification.put(ConstantsUtil.TYPE, sbCertType.toString());
			mpCertification.put(ConstantsUtil.DESCRIPTION, sbCertDesc.toString());
			mpCertification.put(ConstantsUtil.STATE, sbCertState.toString());
			mpCertification.put(ConstantsUtil.CERTIFICATION, sbCertifications.toString());
			mpCertification.put(ConstantsUtil.STATUS, sbStatus.toString());
			mpCertification.put(ConstantsUtil.EXPIRATIONDATE, sbCExpirationDate.toString());
		
		

		
			//All Info View
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
			
			//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
			String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String strBrand = util.getBrandInformationValue(context,sID);
			if(strBrand.isEmpty()) {
				strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
			}
			mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
			
			mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_VAULT)))?(String)resultMaps.get(ConstantsUtil.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ALTERNATIVEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
			mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.SHIPRECEIVEINFO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PGASLALLOCATION, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.RERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.RERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ISBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER,  ConstantsUtil.EMPTY_STRING);


			*//**
			 * LOAD LIFECYCLE SECTION
			 * *//*
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			mpLifeCycleApproval= util.getCOName(context, changeargs);
			swLifecycle.stop();
			LOGGER.info("ARMP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
			mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);


			*//**
			 * LOAD ORGANIZATION SECTION
			 *//*
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = util.filterMapList(mpOrganization);


			*//**
			 * LOAD PLANT SECTION
			 * *//*
			mpPlantResult = util.updatePlantInfo(resultMaps);


			*//**
			 * LOAD OWNERSHIP SECTION
			 * *//*
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.MODIFIED)) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.OSO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
			StopWatch swGetEDL = new StopWatch();
			swGetEDL.start();
			String sEDList =RawMaterialPartBO.getEDList(resultMaps);
			swGetEDL.stop();
			LOGGER.info("ARMP GET EDL ELAPSED TIME : "+swGetEDL.getTime());
			mapOwnerShipResult.put(ConstantsUtil.EDL, sEDList);
			mapOwnerShipResult.put(ConstantsUtil.ODL, util.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST) : ConstantsUtil.EMPTY_STRING));
			mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
			
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			*//**
			 * DERIVED PARTS (RELATED PARTS)
			 * *//*
			StopWatch swDerived = new StopWatch();
			swDerived.start();
			String sDName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING;
			String sCreator = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING;
			
			mpDerivedFromResult = RawBO.updateDerivedDataInfo(context,sDName, sRev, sCreatedDate, sCreator,doARMP,true,false);
			mpDerivedToResult = RawBO.updateDerivedDataInfo(context,sDName, sRev, sCreatedDate, sCreator,doARMP,false,true);
			swDerived.stop();
			LOGGER.info("ARMP  Derived ELAPSED TIME : "+swDerived.getTime());
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END

			*//**
			 * SECURITY
			 * *//*
			StopWatch swSecurity = new StopWatch();
			swSecurity.start();
			mpSecurity =commonBo.updateSecurity(context,resultMaps);
			swSecurity.stop();
			LOGGER.info("ARMP  Security ELAPSED TIME : "+swSecurity.getTime());
			

		}

		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
		hmAttrib.put(ConstantsUtil.STARTINGMATERIALS, mpStartingMaterials);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
		hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		//hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
		//hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO, mpDerivedToResult);
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
		hmAttrib.put(ConstantsUtil.CERTIFICATION, mpCertification);
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		//hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
		hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialComposition);

		pool.checkIn(context);
		sp.stop();
		System.out.println("Execution TIME::" + sp.getTime());
		System.out.println("RESULT:: \n" + hmAttrib);

	}// main method
	public static void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}

}//End of Class
*/