package com.pg.us.specanywhere_enovia.test;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.IRMSBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.bo.PromotionalItemPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

public class PackagingMaterialPartService {

	private static Logger LOGGER = Logger.getLogger(PackagingMaterialPartService.class);

	public static void main(String[] args) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();
		String objId = "20336.41905.10738.45260"; //95794370 004
		//String oid = "20336.41905.45829.12016";//95557414 003
		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
		Context context = pool.checkOut();
		HashMap<String, Map> hmAttrib = new HashMap();
		PackagingMaterialPartBO pmpBO = new PackagingMaterialPartBO();
		DomainObject doPmp = pmpBO.getPmpDO(context,objId);
		Map BusinessObjectSelectableMap = pmpBO.getPackagingMaterialPartSelectables(context);
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		/*
		 * User Profile
		 * 
		SecurityService sct = new SecurityService();
		String sUserType = sct.getUserType();
		if(null==sUserType) {
			throw new Exception("Error in Log-In User Profile");
		}*/

		boolean bAllInfoView = true;
		boolean bSupplierView = false;
		boolean bManufacturerView = false;

		/*switch (sUserType) {
		case ConstantsUtil.PG:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PGSTAFF:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PG_CM:
			bManufacturerView = true;
			break;

		case ConstantsUtil.PG_SP:
			bSupplierView = true;
			break;
		}*/

		Map<String,String> mpHeaderResult = new HashMap<String,String>();
		Map<String,String> mapAttribResult = new HashMap<String,String>();
		Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
		Map<String,String> mpDerivedToResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mapPlantResult = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mapManufEquivResult = new HashMap<String,String>();
		Map<String,String> mapSupEquivResult = new HashMap<String,String>();
		Map<String,String> mapMaterialResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mpPerformChar= new HashMap<String,String>();
		Map<String,String> mpSubstitute = new HashMap<String,String>();
		Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
		Map<String,String> mpMasterSpecs = new HashMap<String,String>();
		Map<String,String> mpMasterAttributes = new HashMap<String,String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mpSecurity = new HashMap<String,String>();
		Map<String,String> mpRelatedATS = new HashMap<String,String>();
		Map<String,String> mpFiles = new HashMap<String, String>();

		StringValidatorUtil validator = new StringValidatorUtil();
		MasterCOPBO mcop = new MasterCOPBO();
		StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

		Map<String, StringList> ChilsObjectSelectableMap = pmpBO.getPMPRelatedObjsSelectableMap(context);
		StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);



		pmpBO.addMultiValueConstants();
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultsMap = doPmp.getInfo(context, slSelects);
		System.out.println("resultsMap---->"+resultsMap);
		swAttributes.stop();
		LOGGER.info("PMP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		pmpBO.removeMultiValueConstants();

		//Common usage Variables
		String sContextObjectId = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ID))?(String)resultsMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		BusExtractUtil utill = new BusExtractUtil();

		/*Map mpPerform =  utill.getPerformanceSpecifications(context, sContextObjectId);*/
		String sClassifictaion = util.getClassification(resultsMap);

		if(bAllInfoView) {
			String FileCapturedFie = validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.STR_FILE_CAPTURED));
			String FileFormats = validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.STR_FORMAT_FILE));
			String FileName = validator.getStringEquivalentForSubstituteString(resultsMap.get(ConstantsUtil.STR_FILE_NAME));
			String FileSize = validator.getStringEquivalentForSubstituteString(resultsMap.get(ConstantsUtil.STR_FILE_SIZE));
			
			mpFiles.put(ConstantsUtil.FILESPATH, FileCapturedFie);
			mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
			mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
			mpFiles.put(ConstantsUtil.FILESSIZES, FileSize);
			System.out.println("mpFiles---->"+mpFiles);
		}
		
		
		
		if(bAllInfoView || bSupplierView || bManufacturerView) {

			//Header Content
			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultsMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultsMap.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);

			if(!bManufacturerView && !bSupplierView){
				mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
			}

			//mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			String sClassification = util.getClassification(resultsMap);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));

			String sHasATS = "";
			String sCurrent = validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.ATL_STATE));
			String sName = validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.ATL_NAME));
			
			sHasATS =util.checkIsATSAttribute(sName,sCurrent);
			mpHeaderResult.put(ConstantsUtil.HASATS, sHasATS);
			
			
			/**
			 * LOAD ATTRIBUTE SECTION
			 * */
			mapAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultsMap.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultsMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_OWNER)))?(String)resultsMap.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);

			//mapAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
			String sID = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ID))?(String)resultsMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String strBrand = util.getBrandInformationValue(context,sID);
			if(strBrand.isEmpty()) {
				strBrand = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultsMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
			}
			mapAttribResult.put(ConstantsUtil.BRAND, strBrand);

			mapAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultsMap.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PARTCOLOR, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.DECORATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.LEGACY_ENV_CLASS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMATERIALLEGACYENVCLASS)))?(String)resultsMap.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMATERIALLEGACYENVCLASS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PRINTINGPROCESS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.STRPRINTINGPROSS)))?(String)resultsMap.get(ConstantsUtil.STRPRINTINGPROSS) : ConstantsUtil.EMPTY_STRING);


			/**
			 * Peformance Charcteristics
			 */
			Map paramMap = new HashMap();
			paramMap.put(ConstantsUtil.OBJECT_ID, objId);
			paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
			paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
			paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

			StopWatch swPerfChar = new StopWatch();
			swPerfChar.start();

			MapList mlPerformAttrib = new MapList();

			PefromChar perform = new PefromChar();
			MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));

			if(mlPerformChar.isEmpty())
			{
				String sRevision = (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultsMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
				String sPCName = (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
				mlPerformAttrib = util.getExtendedPerformChar(context,doPmp,sRevision,sPCName,resultsMap);
				//mpPerformChar =  util.updatePerformCharcteristic(context,mlPerformAttrib,resultsMap);
			}
			else
			{
				FinishedProductPartBO fppBO = new FinishedProductPartBO();
				mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
				//mpPerformChar =  util.updatePerformCharcteristic(context,mlPerformAttrib,resultsMap);

			}

			swPerfChar.stop();
			LOGGER.info("PMP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

			/**
			 * Materials Section
			 */

			StopWatch swMaterial = new StopWatch();
			swMaterial.start();

			if(bSupplierView || bManufacturerView) {
				//mapMaterialResult=util.updateMaterials(context,doPmp,true);
			}else{
				//mapMaterialResult=util.updateMaterials(context,doPmp,false);
			}
			swMaterial.stop();
			LOGGER.info("PMP  Material ELAPSED TIME : "+swMaterial.getTime());

			//RelatedSpec
			StopWatch swRelatedSpec = new StopWatch();
			swRelatedSpec.start();
			//mpRelatedSpecResult = util.updatePartSpec(context, resultsMap);
			swRelatedSpec.stop();
			LOGGER.info("PMP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());

			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */
			StopWatch swReference= new StopWatch();
			swReference.start();
			//mapReferenceDocs = mcop.updateRefDocs(context, resultsMap);
			swReference.stop();
			LOGGER.info("PMP  Reference ELAPSED TIME : "+swReference.getTime());
			mapReferenceDocs = util.filterMapList(mapReferenceDocs);

			/**
			 * MASTER SPECIFICATION
			 * */
			StopWatch swmpMasterSpecs = new StopWatch();
			swmpMasterSpecs.start();
			//mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
			swmpMasterSpecs.stop();
			LOGGER.info("PMP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());


			/**
			 * LOAD MASTER ATTRIBUTE DATA SECTION
			 * */

			StopWatch swMasterAttrib = new StopWatch();
			swMasterAttrib.start();
			mpMasterAttributes = util.getMasterAttributes(context,sContextObjectId,"PMP");
			if(bSupplierView || bManufacturerView) {
				
				if(mpMasterAttributes.containsKey(ConstantsUtil.ORIGINATED)){
					mpMasterAttributes.remove(ConstantsUtil.ORIGINATED);
				}
				
				mpMasterAttributes=util.filterPhase(mpMasterAttributes);
			}
			swMasterAttrib.stop();
			LOGGER.info("PMP GET MASTER ATTRIB ELAPSED TIME : "+swMasterAttrib.getTime());

		}

		/**
		 * Bom section
		 */
		if(bSupplierView || bManufacturerView) {
			//Substitutes
			MapList mapList = doPmp.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.SYMBL_ASTERISK, slChildBusSelects , slChildRelSelects, false, true, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			mapList=util.filterPhase(mapList);

			if(mapList.size()!=0){
				//mpSubstitute =  util.getSubstitute(context,mapList);
			}
		}

		if(bAllInfoView) {

			//ATTRIBUTES
			mapAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ID)))?(String)resultsMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_POLICY)))?(String)resultsMap.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultsMap.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.CUSTOMIZATIONTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PRIMARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SECONDARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
			
			/**
			 * Life cycle section
			 */
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultsMap.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			mpLifeCycleApproval = util.getCOName(context, changeargs);
			swLifecycle.stop();
			LOGGER.info("PMP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
			mapAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);

			/**
			 * Plant section
			 */
			mapPlantResult = util.updatePlantInfo(resultsMap);


			/**
			 * LOAD DERIVED DATA(RELATED PARTS) SECTION
			 * */
			StopWatch swDerived = new StopWatch();
			swDerived.start();
			IRMSBO irmsbo = new IRMSBO();
			String sDName = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_NAME))?(String)resultsMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sRev = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_REVISION))?(String)resultsMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sCreatedDate = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING;
			//mpDerivedFromResult = pmpBO.updateDerivedDataInfo(context,sDName, sRev, sCreatedDate, doPmp,true,false);
			//mpDerivedToResult = pmpBO.updateDerivedDataInfo(context,sDName, sRev, sCreatedDate, doPmp,false,true);
			swDerived.stop();
			LOGGER.info("PMP  Derived ELAPSED TIME : "+swDerived.getTime());

			/**
			 * LOAD SECURITY SECTION
			 * */
			StopWatch swSecurity = new StopWatch();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			swSecurity.start();
			//mpSecurity =commonBo.updateSecurity(resultsMap);
			swSecurity.stop();
			LOGGER.info("PMP  Security ELAPSED TIME : "+swSecurity.getTime());

			/**
			 * LOAD RELATED ATS SECTION
			 * */
			mpRelatedATS.put(ConstantsUtil.ATS_NAME, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.ATL_NAME)))?(String)resultsMap.get(ConstantsUtil.ATL_NAME) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.ATL_ID)))?(String)resultsMap.get(ConstantsUtil.ATL_ID) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.ATL_TYPE)))? util.mapType((String)resultsMap.get(ConstantsUtil.ATL_TYPE)) : ConstantsUtil.EMPTY_STRING));
			mpRelatedATS.put(ConstantsUtil.ATS_TITLE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.ATL_TITLE)))?(String)resultsMap.get(ConstantsUtil.ATL_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_STATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.ATL_STATE)))?(String)resultsMap.get(ConstantsUtil.ATL_STATE) : ConstantsUtil.EMPTY_STRING);
		
			/**
			 * Organization section
			 */
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = util.filterMapList(mpOrganization);


			/**
			 * Ownership Section
			 */
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.STRSEGMENT)))?(String)resultsMap.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.COOWNERS)))?(String)resultsMap.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);

			/**
			 * This Method is for getting the MEPS
			 * @param context
			 * @param Relationship
			 * @param objectMap
			 * @param bMEP
			 * @return
			 * @throws Exception
			 */

			BusExtractUtil busExtct = new BusExtractUtil();
			mapManufEquivResult = busExtct.getEquivalents(context, resultsMap, true, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT);

			/**
			 * This Method is for getting the SEPS 
			 * @param context
			 * @param Relationship
			 * @param objectMap
			 * @param bSEP
			 * @return
			 * @throws Exception
			 */

			mapSupEquivResult = busExtct.getEquivalents(context, resultsMap, false, ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
		}


		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mapAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.MATERIALS, mapMaterialResult);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO,mpDerivedToResult);
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
		hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mapManufEquivResult);
		hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mapSupEquivResult);
		hmAttrib.put(ConstantsUtil.PLANTS, mapPlantResult);
		hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
		hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
		hmAttrib.put(ConstantsUtil.MASTERATTRIBUTES, mpMasterAttributes);
		hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
		hmAttrib.put(ConstantsUtil.FILES, mpFiles);

		pool.checkIn(context);
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
		sp.stop();
		System.out.println("Execution TIME::" + sp.getTime());

		System.out.println("RESULT:: \n" + hmAttrib);
	}
}
