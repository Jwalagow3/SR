/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaPMPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.ConsumerUnitPartBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaCardBO;
import com.pg.us.specanywhere_enovia.bo.ManufacturingEquivalentPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PefromChar;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;


public class EnoviaPMPServiceImpl implements EnoviaPMPService {


	private static Logger LOGGER = Logger.getLogger(EnoviaPMPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
	
	@Override
	public HashMap<String, Map> getPMPdata(String objId, String sComp, Environment env) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();
		//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- START
		Context context = null;
		//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- END
		HashMap<String, Map> hmAttrib = new HashMap();
		try
		{
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			ContextUtil.startTransaction(context, true);
			swContext.stop();
			
			LOGGER.info("PMP CONTEXT ELAPSED TIME : "+swContext.getTime());
			PackagingMaterialPartBO pmpBO = new PackagingMaterialPartBO();
			//DomainObject doPmp = new DomainObject(objId);
			DomainObject doPmp = DomainObject.newInstance(context, objId);
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- START
			ConsumerUnitPartBO CopBO = new ConsumerUnitPartBO();
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- END

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			if (UIUtil.isNotNullAndNotEmpty(sUserType))
			{
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BObjutil.getUserView(context, objId);
				}
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			}
			//SPEC: <07-29-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- START
				context.close();
				//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
			
			String strCurrent = doPmp.getInfo(context, DomainConstants.SELECT_CURRENT);
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				//BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR IN PMP: "+hmAttrib);
					//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- START
					context.close();
					//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- END
					return hmAttrib;
				
				}
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {

					HashMap<String, String> errorMap = new HashMap<String, String>();
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- START
					context.close();
					//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			else {
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			Map BusinessObjectSelectableMap = pmpBO.getPackagingMaterialPartSelectables(context);
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mapAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mapPlantResult = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mapMaterialResult = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpPerformChar= new HashMap<String,String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mapWeightCharResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpIpSecurity = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String, String>();
			Map<String,String> mpMEPResult = new HashMap<String,String>();
			Map<String,String> mpSEPResult = new HashMap<String,String>();
			Map<String,String> mpAlternates = new HashMap<String,String>();
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			Map<String,String> mpSustainability = new HashMap<>();
			Map<String,String> mpCertification = new HashMap<>();
			Map<String,String> mpPerformChar1= new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			
			MasterCOPBO mcop = new MasterCOPBO();
			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 12 Feb 2021 -- START
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slSelects.add(ConstantsUtil.ATL_STATE);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 12 Feb 2021 -- END
			//SPEC: 21/04/2022: Added by Manikanta for 22x DEV Req 41754-- START
			slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL);
			slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES);
			slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMINERALOILSADDEDTOPRINTINGINKS);
			slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGEDURABILITY);
			slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALTHICKNESS);
			slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALDENSITY);
			slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY);
			//SPEC: 21/04/2022: Added by Manikanta for 22x DEV Req 41754-- END
			//SPEC: <13.07.2022>: Satyam added for Internal Defect  -- START
			slSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERWETSTRENGTH);
			//SPEC: <13.07.2022>: Satyam modified for Internal Defect  -- END
			Map<String, StringList> ChilsObjectSelectableMap = pmpBO.getPMPRelatedObjsSelectableMap(context);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
			
			//SPEC: <21.06.2022>: Guna Added for req 41754 22x Release  -- START
              StringList multiSelect =new StringList();
              multiSelect.addAll(pmpBO.getPlantBusSelectable(context));
              multiSelect.addAll(pmpBO.getFileSelects(context));
            //SPEC: <21.06.2022>: Guna Added for req 41754 22x Release  -- END
              
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultsMap = doPmp.getInfo(context, slSelects,multiSelect);
			Map resultsMap = doPmp.getInfo(context, slSelects,pmpBO.addMultiValueConstants());
			swAttributes.stop();
			LOGGER.info("PMP GETINFO ELAPSED TIME : "+swAttributes.getTime());

			
			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultsMap.get(DomainConstants.SELECT_ID))?(String)resultsMap.get(DomainConstants.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sContextObjecttype = validator.isNotNullOrEmpty((String)resultsMap.get(DomainConstants.SELECT_TYPE))?(String)resultsMap.get(DomainConstants.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			String sContextObjectName = validator.isNotNullOrEmpty((String)resultsMap.get(DomainConstants.SELECT_NAME))?(String)resultsMap.get(DomainConstants.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sContextObjectPolicy = validator.isNotNullOrEmpty((String)resultsMap.get(DomainConstants.SELECT_POLICY))?(String)resultsMap.get(DomainConstants.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING;
			
			BusExtractUtil utill = new BusExtractUtil();

			/*Map mpPerform =  utill.getPerformanceSpecifications(context, sContextObjectId);*/
			String sClassifictaion = util.getClassification(resultsMap);

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			if(bAllInfoView || bSupplierView || bManufacturerView) {

				//Header Content
				mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultsMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultsMap.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
				mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
				//if(!bManufacturerView && !bSupplierView){
				//SPEC: 28/04/2021: Added for Development External Requirement 33481 by Bala-- START
				if(bAllInfoView) {
					mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				}
				//SPEC: 28/04/2021: Added for Development External Requirement 33481 by Bala-- END
				//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
				//mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				String sClassification = util.getClassification(resultsMap);
				mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));

				String sHasATS = "";
				String sCurrent = validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.ATL_STATE));
				String sName = validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.ATL_NAME));
				
				sHasATS =util.checkIsATSAttribute(sName,sCurrent);
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 14 Feb 2021 -- START
				//mpHeaderResult.put(ConstantsUtil.HASATS, sHasATS);
				String sHasATSAttrVal = util.checkHasATSForSIS(context,resultsMap);
				mpHeaderResult.put(ConstantsUtil.HASATS, sHasATSAttrVal);
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 14 Feb 2021 -- END
				
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				// Guna Modified for Defect 39147  18x.5.2 Release -- START
				/*mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_MASTERPARTID))));
				*/
				// Modified by Bala for Defect #43322 & #43440  18x.6.0.1 Release -- 10 June 2021 -->START
				//Modified by Ganesh for Defect 38137  18x.5.2 Release --2/16/21-->Start				
				//mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTER))));
				//mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTERTYPE))));
				//mpHeaderResult.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTERID))));
				//mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				//mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				//mpHeaderResult.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTERID))));
				String strMasterID= validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTERID));
				if (UIUtil.isNotNullAndNotEmpty(strMasterID)) {
					mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTER))));
					mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTERTYPE))));
					//Commented by Jwala for the Internal defect -- START
					//mpHeaderResult.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTERID))));
					//Commented by Jwala for the Internal defect -- END
				} else {	
					mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
					mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
					//Modified by Jwala for the Internal defect -- START
					//mpHeaderResult.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTERID))));
					strMasterID =(validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_MASTERPARTID)));
					//Modified by Jwala for the Internal defect -- END
				}
				//Modified by Ganesh for Defect 38137  18x.5.2 Release --2/10/21-->Start
				// Modified by Bala for Defect #43322 & #43440  18x.6.0.1 Release -- 10 June 2021 -->END
				
				//Commented by Jwala for the defect 43421 -- START
				/*String masterId = validator
						.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.PSUB_PGMASTERID));*/
				/*String masterId = validator
						.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_MASTERPARTID));*/
				
				//Commented by Jwala for the defect 43421 -- END
				
				//Modified by Jwala for the Internal defect -- START 
				 //Modified by Ganesh for Defect 38137  18x.5.2 Release --2/16/21-->end
				if (UIUtil.isNotNullAndNotEmpty(strMasterID)) {
					//DomainObject obj = new DomainObject(strMasterID);
					DomainObject obj = DomainObject.newInstance(context, strMasterID);
					String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					obj.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
						strMasterID = ConstantsUtil.NO_ACCESS;
					}
					boolean showData = util.checkHasAccess(context, sUserType, strMasterID);
					if (!showData) {
						strMasterID = ConstantsUtil.NO_ACCESS;
					}
				}
				//Modified by Jwala for the Internal defect -- END
				mpHeaderResult.put(ConstantsUtil.MASTERPARTID, strMasterID);
				// Modified by Ganesh for Defect 38137 18x.5.2 Release --2/10/21-->END
				// Guna Modified for Defect 39147  18x.5.2 Release -- END
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

				/**
				 * LOAD ATTRIBUTE SECTION
				 * */
				mapAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultsMap.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				//SPEC: Release SR18x.6.0.1 - Modified for Defect #35742 by Bala on Date May 27, 2021 -- START
				//mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0.1 - Modified for Defect #43469 by Bala on Date June 11, 2021 -- START
				//mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, ConstantsUtil.PACKAGING);
				EnoviaVendorSpecsServiceImpl vend = new EnoviaVendorSpecsServiceImpl();
				Map mpSubType=vend.getSpecificationSubtype(context,resultsMap);
				String strSubType  = validator.getStringEquivalentForStringListWithComma(
								mpSubType.get(ConstantsUtil.TYPE_PGPACKINGMATERIAL));
				if(UIUtil.isNullOrEmpty(strSubType)) {
					strSubType  = validator.getStringEquivalentForStringListWithComma(
							mpSubType.get(ConstantsUtil.TYPE_PACKAGINGMATERIALPART));
				}
				mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, strSubType);
				//SPEC: Release SR18x.6.0.1 - Modified for Defect #43469 by Bala on Date June 11, 2021 -- END
				//SPEC: Release SR18x.6.0.1 - Modified for Defect #35742 by Bala on Date May 27, 2021 -- END
				mapAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultsMap.get(ConstantsUtil.SELECT_OWNER)));
				mapAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);

				//mapAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ID))?(String)resultsMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultsMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mapAttribResult.put(ConstantsUtil.BRAND, strBrand);

				mapAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultsMap.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
				//SELECT_ATTRIBUTE_PGPACKAGINGUNIT
				// Guna Modified for Defect 39147  18x.5.2 Release -- START
				// Jwala Modified for Defect 42419  18x.5.2 Release -- START
				if(sContextObjecttype.equalsIgnoreCase("pgPackingMaterial")){
					mapAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGUNIT)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGUNIT) : ConstantsUtil.EMPTY_STRING);
				}else{
					mapAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
				}
				// Jwala Modified for Defect 42419  18x.5.2 Release -- END
				// Guna Modified for Defect 39147  18x.5.2 Release -- END
				mapAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PACKAGING_TECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.PARTCOLOR, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.DECORATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 22/03/2021: Commented for 18x.6 Dev by Bala-- START
				//mapAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 22/03/2021: Commented for 18x.6 Dev by Bala-- END
				mapAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Modified for Defect#37755 1.0.2 Release - Jwala -- START
				//mapAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Modified for Defect#37755 1.0.2 Release - Jwala -- START
				mapAttribResult.put(ConstantsUtil.LEGACY_ENV_CLASS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.LEGACYENVCLASSNAME)))?(String)resultsMap.get(ConstantsUtil.LEGACYENVCLASSNAME) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Modified for Defect#38623 1.0.2 Release - Jwala -- START
				//mapAttribResult.put(ConstantsUtil.PRINTINGPROCESS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.STRPRINTINGPROSS)))?(String)resultsMap.get(ConstantsUtil.STRPRINTINGPROSS) : ConstantsUtil.EMPTY_STRING);
				String strPP = util.getPrintingProcessValue(context,sID);
				mapAttribResult.put(ConstantsUtil.PRINTINGPROCESS, strPP);
				//SPEC: Modified for Defect#38623 1.0.2 Release - Jwala -- END
				//SPEC: Added for Defect#37755 1.0.2 Release - Jwala -- START
				mapAttribResult.put(ConstantsUtil.STORAGECONDITIONS, util.mapType((validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING));
				//SPEC: Added for Defect#37755 1.0.2 Release - Jwala -- END
				//SPEC: <06.03.2023>: Satyam Added for Req 46464 -- START
				mapAttribResult.put(ConstantsUtilIRM.COMPONENTPACKFAMILY1, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENTPACKFAMILY1)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENTPACKFAMILY1) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtilIRM.COMPONENTPACKFAMILY2, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENTPACKFAMILY2)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENTPACKFAMILY2) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtilIRM.COMPONENTPACKFAMILY3, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENTPACKFAMILY3)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_COMPONENTPACKFAMILY3) : ConstantsUtil.EMPTY_STRING);
				if(!bSupplierView) {
					mapAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mapAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: <06.03.2023>: Satyam Added for Req 46464 -- END
				//SPEC: 21/04/2022: Added by Manikanta for 22x DEV Req 41754-- START
				mapAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGPACKAGECOMPOPTPROPERTIES, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGMINERALOILADDEDTOPRINTINKS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMINERALOILSADDEDTOPRINTINGINKS)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMINERALOILSADDEDTOPRINTINGINKS) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGPACKAGEDURABILITY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGEDURABILITY)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGEDURABILITY) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGMATERIALTHICKNESS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALTHICKNESS)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALTHICKNESS) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGMATERIALDENSITY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALDENSITY)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALDENSITY) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGPAPERDISSOLVABILITY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <13.07.2022>: Satyam added for Internal Defect  -- START
				if(bSupplierView || bManufacturerView) {
				mpSustainability.put(ConstantsUtilIRM.PGPAPERWETSTRENGTH, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERWETSTRENGTH)))?(String)resultsMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERWETSTRENGTH) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: <13.07.2022>: Satyam added for Internal Defect  -- END
				hmAttrib.put(ConstantsUtilIRM.SUSTAINABILITY, mpSustainability);
				//SPEC: 21/04/2022: Added by Manikanta for 22x DEV Req 41754-- END
				/**
				 * Peformance Charcteristics
				 */
				Map paramMap = new HashMap();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				
				MapList mlPerformAttrib = new MapList();
				RawMaterialPartBO RawBO = new RawMaterialPartBO();
				PefromChar perform = new PefromChar();
				MapList mlPerformChar = new MapList();
				MapList mlPerformChar1 = new MapList();
				MapList mlPerformAttrib1 = new MapList();
				
				mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				if(mlPerformChar.isEmpty())
				{
					String sRevision = (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultsMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
					String sPCName = (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
					mlPerformAttrib = util.getExtendedPerformChar(context,doPmp,sRevision,sPCName,resultsMap);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39416  by gaikwad.tg on Date 17 Feb 2021 -- START
					//mpPerformChar =  util.updatePerformCharcteristic(context,mlPerformAttrib,resultsMap);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39416  by gaikwad.tg on Date 17 Feb 2021 -- END
				}
				else
				{
					FinishedProductPartBO fppBO = new FinishedProductPartBO();
					mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					//LOGGER.info("PMP Perf attributes:"+mlPerformAttrib);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39416  by gaikwad.tg on Date 17 Feb 2021 -- START
					//mpPerformChar =  util.updatePerformCharcteristic(context,mlPerformAttrib,resultsMap);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39416  by gaikwad.tg on Date 17 Feb 2021 -- END

				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39416,40056  by gaikwad.tg on Date 20 Feb 2021 -- END
				String strType = (String)resultsMap.get(ConstantsUtil.SELECT_TYPE);
				if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_PACKINGMATERIAL))
				{
					FormulaCardBO fcardBo = new FormulaCardBO();
					mpPerformChar =  fcardBo.updatePerformCharcteristic(context,mlPerformAttrib,resultsMap);
					
				}
				else
				{
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
					//mpPerformChar =  util.updatePerformCharcteristic(context,mlPerformAttrib,resultsMap);
					mpPerformChar =  util.updatePerformCharcteristic(context,mlPerformAttrib,resultsMap,objId);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
					
					
				}
				//Added by Ajay for the defect 77978 -- START
				if(sComp.equals(ConstantsUtilIRM.COMPARE)) {
					
					mlPerformChar1 = RawBO.getPerformanceCharCompare(context,JPO.packArgs(paramMap));
					if(mlPerformChar1.isEmpty())
					{
						String sRevision = (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultsMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
						String sPCName = (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
						mlPerformAttrib1 = util.getExtendedPerformChar(context,doPmp,sRevision,sPCName,resultsMap);
						
					}
					else
					{
						FinishedProductPartBO fppBO1 = new FinishedProductPartBO();
						mlPerformAttrib1 =fppBO1.getAttributes(context, mlPerformChar1);

					}
					
					mpPerformChar1 =  util.updatePerformCharcteristic(context,mlPerformAttrib1,resultsMap,objId);
					for (Map.Entry<String, String> entry : mpPerformChar1.entrySet()) {
						mpPerformChar.putIfAbsent(entry.getKey(), entry.getValue());
					}
				}
				//Added by Ajay for the defect 77978 -- END
				//SPEC: Release SR18x.5.2 - Added for Defect# 39416,40056  by gaikwad.tg on Date 20 Feb 2021 -- END
				swPerfChar.stop();
				LOGGER.info("PMP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

				/**
				 * Materials Section
				 */

				StopWatch swMaterial = new StopWatch();
				swMaterial.start();
				if(bSupplierView || bManufacturerView) {
					
					//mapMaterialResult=util.updateMaterials(context,doPmp,true);
					mapMaterialResult=util.updateMaterials(context,doPmp,true,resultsMap);
					//SPEC: 10/05/2021: Added for Development External by Bala-- START
					String strQunatityUOM = (String)mapMaterialResult.get(ConstantsUtil.QTYUOM);
					String strFN = (String)mapMaterialResult.get(ConstantsUtil.FN);
					String strTW = (String)mapMaterialResult.get(ConstantsUtil.TARGET_PERCEN_WBW);
					String strMin = (String)mapMaterialResult.get(ConstantsUtil.MIN_PERCEN_WBW);
					String strMax = (String)mapMaterialResult.get(ConstantsUtil.MAX_PERCEN_WBW);
					String strTrade = (String)mapMaterialResult.get(ConstantsUtil.TRADENAME);
					String strManufact = (String)mapMaterialResult.get(ConstantsUtil.MANUFACTURER);
					String strComments = (String)mapMaterialResult.get(ConstantsUtil.COMMMENTS);
					String strPostConsumer = (String)mapMaterialResult.get(ConstantsUtil.POSTCONSUMERRECYCLED);
					String strLegacyEnv = (String)mapMaterialResult.get(ConstantsUtil.LEGACY_ENV_CLASS);
					String strLayer= (String)mapMaterialResult.get(ConstantsUtil.LAYER);
					String sParentName= (String)mapMaterialResult.get(ConstantsUtilIRM.PARENT_NAME);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.QTYUOM)?mapMaterialResult.remove(ConstantsUtil.QTYUOM) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.FN)?mapMaterialResult.remove(ConstantsUtil.FN) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.TARGET_PERCEN_WBW)?mapMaterialResult.remove(ConstantsUtil.TARGET_PERCEN_WBW) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.MIN_PERCEN_WBW)?mapMaterialResult.remove(ConstantsUtil.MIN_PERCEN_WBW) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.MAX_PERCEN_WBW)?mapMaterialResult.remove(ConstantsUtil.MAX_PERCEN_WBW) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.TRADENAME)?mapMaterialResult.remove(ConstantsUtil.TRADENAME) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.MANUFACTURER)?mapMaterialResult.remove(ConstantsUtil.MANUFACTURER) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.COMMMENTS)?mapMaterialResult.remove(ConstantsUtil.COMMMENTS) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.POSTCONSUMERRECYCLED)?mapMaterialResult.remove(ConstantsUtil.POSTCONSUMERRECYCLED) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.LEGACY_ENV_CLASS)?mapMaterialResult.remove(ConstantsUtil.LEGACY_ENV_CLASS) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.remove(mapMaterialResult.containsKey(ConstantsUtil.LAYER)?mapMaterialResult.remove(ConstantsUtil.LAYER) :ConstantsUtil.EMPTY_STRING);
					mapMaterialResult.put(ConstantsUtil.QUANTITYUOM, strQunatityUOM);
					mapMaterialResult.put(ConstantsUtil.SEQ, strFN);
					mapMaterialResult.put(ConstantsUtil.TW, strTW);
					mapMaterialResult.put(ConstantsUtil.MIN, strMin);
					mapMaterialResult.put(ConstantsUtil.MAX, strMax);
					mapMaterialResult.put(ConstantsUtil.TRADE_NAME, strTrade);
					mapMaterialResult.put(ConstantsUtil.COMP_MANUFACTURER, strManufact);
					mapMaterialResult.put(ConstantsUtil.COMP_COMMENTS, strComments);
					mapMaterialResult.put(ConstantsUtil.POST_CONNSUMER, strPostConsumer);
					mapMaterialResult.put(ConstantsUtil.LEGACYENVCLASS, strLegacyEnv);
					mapMaterialResult.put(ConstantsUtil.LAYER_DESC, strLayer);
					mapMaterialResult.put(ConstantsUtilIRM.PARENT_NAME, sParentName);
					//SPEC: 10/05/2021: Added for Development External by Bala-- END
				}else{
					//mapMaterialResult=util.updateMaterials(context,doPmp,false);
					//mapMaterialResult=pmpBO.getSubstances(context,sContextObjectId);
					mapMaterialResult=pmpBO.getSubstances(context,resultsMap);
					
					
				}
				swMaterial.stop();
				LOGGER.info("PMP  Material ELAPSED TIME : "+swMaterial.getTime());

				//RelatedSpec
				StopWatch swRelatedSpec = new StopWatch();
				swRelatedSpec.start();
				
				//SPEC: 11/18/2020: Modified for Defect 37047 -- START
				// Guna modified for Defect 35928  18x.5.2 Release -- START
				 mpRelatedSpecResult = util.updatePartSpec(context, resultsMap);
				//mpRelatedSpecResult = pmpBO.updatePartSpec(context, resultsMap);
				// Guna modified for Defect 35928  18x.5.2 Release -- END
				//SPEC: 11/18/2020: Modified for Defect 37047 -- END
				
				swRelatedSpec.stop();
				LOGGER.info("PMP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());

				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = mcop.updateRefDocs(context, resultsMap);
				swReference.stop();
				LOGGER.info("PMP  Reference ELAPSED TIME : "+swReference.getTime());
				mapReferenceDocs = util.filterMapList(mapReferenceDocs);

				/**
				 * MASTER SPECIFICATION
				 * */
				StopWatch swmpMasterSpecs = new StopWatch();
				swmpMasterSpecs.start();
				mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
				swmpMasterSpecs.stop();
				LOGGER.info("PMP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());


				/**
				 * LOAD MASTER ATTRIBUTE DATA SECTION
				 * */
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
				/*StopWatch swMasterAttrib = new StopWatch();
				swMasterAttrib.start();
				mpMasterAttributes = util.getMasterAttributes(context,sContextObjectId,"PMP");
				if(bSupplierView || bManufacturerView) {
					
					if(mpMasterAttributes.containsKey(ConstantsUtil.ORIGINATED)){
						mpMasterAttributes.remove(ConstantsUtil.ORIGINATED);
					}
					
					mpMasterAttributes=util.filterPhase(mpMasterAttributes);
				}
				swMasterAttrib.stop();
				LOGGER.info("PMP GET MASTER ATTRIB ELAPSED TIME : "+swMasterAttrib.getTime());*/
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			}

			/**
			 * Bom section
			 */
			
			//if(bAllInfoView || bSupplierView) {
			mapAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			//SPEC: <06.07.2021>: Guna Added for 44054 Defect  Dev 18x.6.0.1   -- START
			String formatedBoolean = ConstantsUtil.EMPTY_STRING;
			String strPrefMaterial =(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
			//SPEC: <07.09.2021>: Bala Modified for 44263 Defect  Dev 18x.6.0.2   -- START
			if (strPrefMaterial != null && strPrefMaterial.trim().length() > 0) {				
				if (strPrefMaterial.equalsIgnoreCase("True")) {
					formatedBoolean = "Yes";
				} else if (strPrefMaterial.equalsIgnoreCase("False")) {
					formatedBoolean = "No";
				} else {
					formatedBoolean = strPrefMaterial;
				}
			}
			//SPEC: <07.09.2021>: Bala Modified for 44263 Defect  Dev 18x.6.0.2   -- END
			//mapAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, formatedBoolean);
			String strHasArt = (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART)))?validator.replaceSpecialSymbols((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART)) : ConstantsUtil.EMPTY_STRING;	
			mapAttribResult.put(ConstantsUtil.HASART, strHasArt);
			//SPEC: <07.09.2021>: Bala Modified for 43026 Defect  Dev 18x.6.0.2   -- END
			mapAttribResult.put(ConstantsUtil.HASMUTIPLEGTIN, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASMULTIPLEGTINS)))?validator.replaceSpecialSymbols((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHASMULTIPLEGTINS)) : ConstantsUtil.EMPTY_STRING);				
			mapAttribResult.put(ConstantsUtil.POAIMPACTCONFIRMATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOAIMPACTCONFIRMATION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOAIMPACTCONFIRMATION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED))));
			mapAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
			/**
			 * LOAD SECURITY SECTION
			 * */
			StopWatch swSecurity = new StopWatch();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			swSecurity.start();
			mpSecurity =commonBo.updateSecurity(context, resultsMap);
			swSecurity.stop();
			LOGGER.info("PMP  Security ELAPSED TIME : "+swSecurity.getTime());
			/**
			 * LOAD IP SECTION
			 * */
			StopWatch swIpSecurity = new StopWatch();
			swIpSecurity.start();
			String strType = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_TYPE))?(String)resultsMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			mpIpSecurity =util.getIpClass(context, strType, doPmp, pmpBO.getIpSelects());
			//SPEC: 29/04/2021: Added for Development External Requirement 33481 by Bala-- START
			String strHasClass = (String)mpIpSecurity.get(ConstantsUtil.HASCLASSACCESS);
			StringList slHasClassAccess =FrameworkUtil.split(strHasClass, "|");
			String strHasClassAccess = ConstantsUtil.EMPTY_STRING;
			StringBuilder sbHasClassAccess = new StringBuilder();
			Iterator itrHasClassAccess = slHasClassAccess.iterator();
			while (itrHasClassAccess.hasNext()) {
				strHasClassAccess = itrHasClassAccess.next().toString();
				if (strHasClassAccess.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPTRUE)) {
					strHasClassAccess=ConstantsUtil.SYMBL_CAPTRUE;
				}else if (strHasClassAccess.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPFALSE)) {
					strHasClassAccess=ConstantsUtil.SYMBL_CAPFALSE;
				}
				sbHasClassAccess.append(strHasClassAccess);
				if (itrHasClassAccess.hasNext()) {
					sbHasClassAccess.append("|");
				}
			}
			mpIpSecurity.replace(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
			//SPEC: 29/04/2021: Added for Development External Requirement 33481 by Bala-- END
			swIpSecurity.stop();
			LOGGER.info("PMP  Security ELAPSED TIME : "+swIpSecurity.getTime());
			/**
			 * LOAD RELATED ATS SECTION
			 * */
			StopWatch swAts = new StopWatch();
			swAts.start();
			mpRelatedATS=util.getRelatedAts(context, doPmp);				
			mpRelatedATS=util.filterMapList(mpRelatedATS);
			swAts.stop();
			LOGGER.info("PMP ATS ELAPSED TIME : "+swAts.getTime());
			/**
			 * Organization section
			 */
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			//mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			//mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			
			//SPEC: <07.09.2021>: Bala Modified for 44284 Defect Dev 18x.6.0.2   -- START
			/*if (resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {
			
				if (resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
					{
						mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
					} 
				else 
					{
						mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					}
			}*/
			
			StringBuilder sbPrimaryOrg = new StringBuilder();
			StringList slPrimaryOrganization = doPmp.getInfoList(context, ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);	
			if (null != slPrimaryOrganization && slPrimaryOrganization.size() > 0) {
				for (int i=0; i<slPrimaryOrganization.size(); i++) {
					String strPrimaryOrg = slPrimaryOrganization.getElement(i);
					if(i == 0){
					sbPrimaryOrg.append(strPrimaryOrg);
					}else{
						sbPrimaryOrg.append(ConstantsUtil.SYMBL_PIPE);
						sbPrimaryOrg.append(strPrimaryOrg);
					}				
				}
			}			
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, sbPrimaryOrg.toString());
						
			/*if (resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {
			
				if (resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
				{
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
				} else 
				{
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				}
			}*/
			StringBuilder sbSecondOrg = new StringBuilder();
			StringList slSecondOrganization = doPmp.getInfoList(context, ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);			
			if (null != slSecondOrganization && slSecondOrganization.size() > 0) {
				for (int j=0; j<slSecondOrganization.size(); j++) {
					String strSecondOrg = slSecondOrganization.getElement(j);
					if(j == 0){
					sbSecondOrg.append(strSecondOrg);
					}else{
						sbSecondOrg.append(ConstantsUtil.SYMBL_PIPE);
						sbSecondOrg.append(strSecondOrg);
					}				
				}
			}			
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, sbSecondOrg.toString());
			//SPEC: <07.09.2021>: Bala Modified for 44284 Defect  Dev 18x.6.0.2   -- END
			//SPEC: <08-04-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- END
			mpOrganization = util.filterMapList(mpOrganization);
			/**
			 * This Method is for getting the MEPS
			 * @param context
			 * @param Relationship
			 * @param objectMap
			 * @param bMEP
			 * @return
			 * @throws Exception
			 */
			
			//Added by Jwala for 22x Development Req 42996 -- START
			boolean isUserCMandSP = BObjutil.isUserCMandSP(context, objId);
			//Added by Jwala for 22x Development Req 42996 -- END
			mpMEPResult = util.getPQREquivalents(context, resultsMap, true, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT,sUserType);
			
			// Added by Jwala for Req/Defect 35581 43951 -- START
			if(bManufacturerView || bSupplierView){
				mpMEPResult.remove(ConstantsUtil.PQRBA);
				mpMEPResult.remove(ConstantsUtil.PQRPCP);
				//Modified by Jwala for 22x Development Req 42996 -- START
				if(bSupplierView && !isUserCMandSP){
					mpMEPResult.remove(ConstantsUtil.PQRPLANTS);
				}
				//Modified by Jwala for 22x Development Req 42996 -- END
			}
			
			//SPEC: 23-12-2022: Ketan added for Req 34055 -- START
            if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
            	mpMEPResult = new HashMap<String,String>();
            }
            //SPEC: 23-12-2022: Ketan added for Req 34055 -- END
            
			// Added by Jwala for Req/Defect 35581 43951 -- END
			//SPEC: <07.09.2021>: Bala Modified for 43026 Defect  Dev 18x.6.0.2   -- START
			if(strHasArt.equals(ConstantsUtil.SYMBL_NO)){
				mpMEPResult.replace(ConstantsUtil.ARTWORKPRIMARY, ConstantsUtil.EMPTY_STRING);
				mpMEPResult.replace(ConstantsUtilIRM.ARTWORKSECONDARY, ConstantsUtil.EMPTY_STRING);
			}
			//SPEC: <07.09.2021>: Bala Modified for 43026 Defect  Dev 18x.6.0.2   -- END
			
			/**
			 * This Method is for getting the SEPS 
			 * @param context
			 * @param Relationship
			 * @param objectMap
			 * @param bSEP
			 * @return
			 * @throws Exception
			 */
			
			mpSEPResult = util.getPQREquivalents(context, resultsMap, false, ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT,sUserType);

			// Added by Jwala for Req/Defect 35581 43951 -- START
			if(bManufacturerView || bSupplierView){
				mpSEPResult.remove(ConstantsUtil.PQRBA);
				mpSEPResult.remove(ConstantsUtil.PQRPCP);
				//SPEC: <21.12.2021>: Guna Modified for 42013 Req  Dev 18x.6.0.3 Release --- START
				//Modified by Jwala for 22x Development Req 42996 -- START
				if(bSupplierView && !isUserCMandSP){
					mpSEPResult.remove(ConstantsUtil.PQRPLANTS);
				}
				//Modified by Jwala for 22x Development Req 42996 -- END
			}
			// Added by Jwala for Req/Defect 35581 43951 -- END
			
			//SPEC: 23-12-2022: Ketan added for Req 34055 -- START
            if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
                mpSEPResult = new HashMap<String,String>();
            }
            //SPEC: 23-12-2022: Ketan added for Req 34055 -- END
            
			//SPEC: <07.09.2021>: Bala Modified for 43026 Defect  Dev 18x.6.0.2   -- START
			if(strHasArt.equals(ConstantsUtil.SYMBL_NO)){
				mpSEPResult.replace(ConstantsUtil.ARTWORKPRIMARY, ConstantsUtil.EMPTY_STRING);
				mpSEPResult.replace(ConstantsUtilIRM.ARTWORKSECONDARY, ConstantsUtil.EMPTY_STRING);
			}
			//SPEC: <07.09.2021>: Bala Modified for 43026 Defect  Dev 18x.6.0.2   -- END

			//SPEC: 02/03/2021: Added for 18x.5 DEV by Bala-- START
			/**
			 * LOAD ALTERNATES SECTION
			 * */
			CommonBusUtilBO commonBO = new CommonBusUtilBO();			
			mpAlternates = commonBO.getAlternates(context, sContextObjectId);
			mpAlternates = Bbutil.filterMapList(mpAlternates);				
			if (!mpAlternates.isEmpty()) {
				if (mpAlternates.containsKey(ConstantsUtil.PHASE)) {
					mpAlternates.remove(ConstantsUtil.PHASE);
				}if (mpAlternates.containsKey(ConstantsUtil.CERTIFICATIONS)) {
					mpAlternates.remove(ConstantsUtil.CERTIFICATIONS);
				}if (mpAlternates.containsKey(ConstantsUtil.WEIGHTDIFFERENCE)) {
					mpAlternates.remove(ConstantsUtil.WEIGHTDIFFERENCE);
				}
			}
			//}
			
			if(bAllInfoView) {

				//ATTRIBUTES
				mapAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ID)))?(String)resultsMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_POLICY)))?(String)resultsMap.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultsMap.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.5.2 - Added for Defect# 39257  by Amman on 10th Feb,2021 -- START
				//mapAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.5.2 - Added for Defect# 39257  by Amman on 10th Feb,2021 -- END
				//mapAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				//mapAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				//mapAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.CUSTOMIZATIONTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.PRIMARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRIMARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.SECONDARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				
				
				/**
				 * Life cycle section
				 */
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultsMap.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("PMP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				
				//SPEC: 02/03/2021: Modified for 18x.6 DEV by Bala-- START
				mapAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 02/03/2021: Modified for 18x.6 DEV by Bala-- END
				//SPEC: <11-10-2020>: Added for 18x5 Release -- START --
				//mapAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				//mapAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <11-10-2020>: Added for 18x5 Release -- END --
				/**
				 * Plant section
				 */
				mapPlantResult = util.updatePlantInfo(resultsMap);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doPmp.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

				/**
				 * DERIVED PARTS (RELATED PARTS)
				 * *//*
				StopWatch swDerived = new StopWatch();
				swDerived.start();
				String sDName = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_NAME))?(String)resultsMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
				String sRev = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_REVISION))?(String)resultsMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
				String sType = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_TYPE))?(String)resultsMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
				String sCreatedDate = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING;
				mpDerivedFromResult = pmpBO.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doPmp,true,false);
				mpDerivedToResult = pmpBO.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doPmp,false,true);

				mpDerivedFromResult = util.filterMapList(mpDerivedFromResult);
				mpDerivedToResult = util.filterMapList(mpDerivedToResult);
				LOGGER.info("PMP  Derived ELAPSED TIME : "+swDerived.getTime());
				  */
				/**
				 * LOAD SECURITY SECTION
				 * */
				/*StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO commonBo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =commonBo.updateSecurity(context, resultsMap);
				swSecurity.stop();
				LOGGER.info("PMP  Security ELAPSED TIME : "+swSecurity.getTime());*/

				//SPEC: <11-10-2020>: Added for 18x5 Release -- START
				/**
				 * LOAD IP SECTION
				 * */
				/*StopWatch swIpSecurity = new StopWatch();
				swIpSecurity.start();
				String strType = validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_TYPE))?(String)resultsMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
				mpIpSecurity =util.getIpClass(context, strType, doPmp, pmpBO.getIpSelects());
				swIpSecurity.stop();
				LOGGER.info("PMP  Security ELAPSED TIME : "+swIpSecurity.getTime());*/
				//SPEC: <11-10-2020>: Added for 18x5 Release -- END
				
				/**
				 * LOAD RELATED ATS SECTION
				 * */
				/*StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=util.getRelatedAts(context, doPmp);
				
				mpRelatedATS=util.filterMapList(mpRelatedATS);
				if(!mpRelatedATS.isEmpty()){
					mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					//SPEC: Release SR18x.5.2 - Added for Defect# 39257  by Amman on 10th Feb,2021 -- START
					//mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
					mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
					//SPEC: Release SR18x.5.2 - Added for Defect# 39257  by Amman on 10th Feb,2021 -- END
				}

				if(bManufacturerView || bSupplierView) {
					mpRelatedATS=util.filterPhase(mpRelatedATS);
				}
				swAts.stop();
				LOGGER.info("PMP ATS ELAPSED TIME : "+swAts.getTime());*/
				
				
				/**
				 * Organization section
				 */
				/*mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultsMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = util.filterMapList(mpOrganization);*/
				//SPEC: 15/03/2021: Modified for 18x.6 Dev by Bala-- END

				/**
				 * Ownership Section
				 */
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultsMap.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER,  Bbutil.getLastUpdatedUser(context, sContextObjectId));
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultsMap.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.COOWNERS)))?(String)resultsMap.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);

				
			}

		//SPEC: <11-10-2020>: Added for 18x5 Release -- START
			/**
			 * LOAD WEIGHT CHARACTERISTICS SECTION
			 * */ 
			StopWatch swWeightCharacteristics = new StopWatch();
			swWeightCharacteristics.start();
			mapWeightCharResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
			mapWeightCharResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultsMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			//SPEC: 15/03/2021: Modified for 18x.6 Dev by Bala-- END
			mapWeightCharResult = util.filterMapList(mapWeightCharResult);
			swWeightCharacteristics.stop();
			LOGGER.info("PMP GET swWeightCharacteristics ELAPSED TIME : "+swWeightCharacteristics.getTime());
			//SPEC: <11-10-2020>: Added for 18x5 Release -- END
			if(bAllInfoView) {
			
				String FileCapturedFie = validator.getEquivalentString(resultsMap.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultsMap.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultsMap.get(ConstantsUtil.STR_FILE_NAME));
				StringList FileSize = validator.getStringListEquivalentForString(resultsMap.get(ConstantsUtil.STR_FILE_SIZE));
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
				CommonDocBO cdoc = new CommonDocBO();
				String strFileSize = cdoc.updateFileSize(FileSize);
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);
				
				/**
				 * LOAD GPSASSESSMENTS SECTION
				 * */
				StopWatch swgps= new StopWatch();
				swgps.start();
				DeviceProductPartBO DPPBO = new DeviceProductPartBO();
				mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
				mpGPSAssessments = Bbutil.filterMapList(mpGPSAssessments);
				swgps.stop();
				LOGGER.info("PMP  GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
				//SPEC: 22/03/2021: Modified for 18x.6 Dev by Bala-- START
				hmAttrib.put(ConstantsUtil.FILES, mpFiles);
				hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
				hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
				hmAttrib.put(ConstantsUtil.PLANTS, mapPlantResult);
				hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
				//SPEC: 22/03/2021: Modified for 18x.6 Dev by Bala-- END
			}
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- START
			/**
			 * LOAD PACKAGING CERTIFICATIONS
			 * */
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				StopWatch swPkgCert = new StopWatch();
				swPkgCert.start();
				ManufacturingEquivalentPartBO mep = new ManufacturingEquivalentPartBO();
				MapList mpPackagingCert =mep.getPackagingCertificationsList(context,objId,sContextObjectName,sContextObjecttype,sContextObjectPolicy);
				mpCertification =mep.getCertificationDetails(context,mpPackagingCert,(String)resultsMap.get(DomainConstants.SELECT_NAME),doPmp,sContextObjecttype);
				//mpCertification = CopBO.getPackagingCertificationsList(context, objId,(String)resultsMap.get(ConstantsUtil.SELECT_TYPE));
				swPkgCert.stop();
				LOGGER.info("PACKAGING CERTIFICATIONS ELAPSED TIME : "+swPkgCert.getTime());
			}
			
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				hmAttrib.put(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS, mpCertification);
			}
			// Added by Jwala for the req 4945 - END
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- END
			
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mapAttribResult);
			//SPEC: 21/04/2022: Modified by Manikanta for 22x DEV Req 33476-- START
			if (bAllInfoView) {
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: 21/04/2022: Modified by Manikanta for 22x DEV Req 33476-- END
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			hmAttrib.put(ConstantsUtil.MATERIALS, mapMaterialResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			
			if (bAllInfoView) {
				mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			}
			
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mapWeightCharResult);
			if (bAllInfoView) {
				mpIpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.IPSECURITY, mpIpSecurity);
			}
			hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
			hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult); 
			hmAttrib.put(ConstantsUtil.ALTERNATES, mpAlternates);			
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189

			pool.checkIn(context);
			sp.stop();

			LOGGER.info("PMP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "PMP OBJECT NAME::"+resultsMap.get(ConstantsUtil.SELECT_NAME));
		} catch (IOException e) {
			LOGGER.error("Unable to getPMPdata IOException: "+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getPMPdata MatrixException: "+e);
		}catch (Exception e) {
			LOGGER.error("Unable to getPMPdata MatrixException: "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		//LOGGER.info("PMP RESPONSE MESSAGE:: \n" + hmAttrib);
		//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- START
		if(sComp.equals(ConstantsUtilIRM.PMP)) {
			context.close();
		}
		//SPEC: <03-11-2021>: Bala Added for  Defect 45181  -- END
		return hmAttrib;
	}
}
