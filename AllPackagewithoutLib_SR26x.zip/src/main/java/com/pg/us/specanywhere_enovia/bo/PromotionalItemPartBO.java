/**
 * Project 		: SpecsAnywhere
 * Program 		: PromotionalItemPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class PromotionalItemPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(PromotionalItemPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	public PromotionalItemPartBO() {
		// empty constructor
	}
	
	public PromotionalItemPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getPIPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getPIPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getPIPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getPIPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}
	
		
	/**
	 * Method Name 			: getPromotionalItemPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getPromotionalItemPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getFileSelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getPIPRelatedObjsSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getPIPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}
	
	
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);

		return busSelect;
	}

	/**
	 * Method Name 			: getBomRelSelect
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		
		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
	
		//Added for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Added for Defect# 37591 -- END
		
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		//SPEC: <12.22.2020>: Chandra Added for Defect :34059 ## --END
		
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		//SPEC: <18.11.2022>: Satyam Added for Req 45642 -- END

		return relSelect;
	}
	
	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" details
	 * @param context
	 * @return
	 */
	private StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching "Plant" details
	 * @param context
	 * @return
	 */
	public StringList getPlantSelects(Context context) 
	{
		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context)
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPARTCOLOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		
		
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		//SPEC: 10/22/2020: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		
		//SPEC: 10/22/2020: Added for req 18x.5 ## -- END
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//SPEC: <03.03.2023>: Satyam Added for Req 46464 -- END
		
		
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceType,  String sSourceRev, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();

		String sSourceid = dob.getObjectId();
		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, getTo, getFrom, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			if(mlDerivedList.isEmpty()){
				return new HashMap();
			}
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbDerivedId = new StringBuilder();
			StringBuilder sbDerivedType = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbSourceId=new StringBuilder();
			StringBuilder sbSourceType=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				StringValidatorUtil validator = new StringValidatorUtil();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDerivedId=(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sDerivedType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);
				String sOriginated=(String)objectMap.get(ConstantsUtil.SELECT_ORIGINATED);
				StringValidatorUtil dateUtil = new StringValidatorUtil();
				sOriginated = dateUtil.DateFormatter(sOriginated);
				
				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
				util.formatData(sbDerivedName,sSourceName);
				util.formatData(sbDerivedId,sSourceid);
				util.formatData(sbDerivedType,sSourceType);
				util.formatData(sbSourceName,sDerivedName);
				util.formatData(sbSourceId,sDerivedId);
				util.formatData(sbSourceType,sDerivedType);
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbDerivedId,sDerivedId);
					util.formatData(sbDerivedType,sDerivedType);
					util.formatData(sbSourceName,sSourceName);
					util.formatData(sbSourceId,sSourceid);
					util.formatData(sbSourceType,sSourceType);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sOriginated);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.SOURCEID, sbSourceId.toString());
			mpDerived.put(ConstantsUtil.SOURCETYPE, sbSourceType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDID, sbDerivedId.toString());
			mpDerived.put(ConstantsUtil.DERIVEDTYPE, sbDerivedType.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.ORIGINATED, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (Exception e) {
			LOGGER.error("Error from PromotionalItemBO: updateDerivedDataInfo"+e);
			return new HashMap();
		}
		return util.filterMapList(mpDerived);
	}
	
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList(){
		 
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW); 
		
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);
		
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		
		return slMultiSelects;
		
	}
	
	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	:
	 */
	public  void removeMultiList(){
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		

	}
	
	//SPEC: 11/24/2020: Added for Defect #37543 -- START
	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	//SPEC: 11/24/2020: Added for Defect #37543 -- END
	
}