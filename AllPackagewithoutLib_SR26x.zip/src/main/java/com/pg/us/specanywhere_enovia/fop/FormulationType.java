package com.pg.us.specanywhere_enovia.fop;

import com.matrixone.apps.domain.util.PropertyUtil;
import matrix.db.Context;
public enum FormulationType {
	

		FORMULATION_FAMILY("type_FormulationFamily"), FORMULATION_PART("type_FormulationPart"), FORMULATION_PROPAGATE(
				"type_FormulationPropagate"), FORMULATION_PROCESS("type_FormulationProcess"), FORMULATION_PHASE(
						"type_FormulationPhase"), CHARACTERISTIC("type_Characteristic"), RAWMATERIAL_PART(
								"type_RawMaterial"), MATERIAL("type_Material"), SUBSTANCE(
										"type_Substance"), EXTERNAL_MATERIAL("type_ExternalMaterial"), INTERNAL_MATERIAL(
												"type_InternalMaterial"), INTERNAL_CORE_MATERIAL(
														"type_InternalCoreMaterial"), INTERNAL_COVERING_MATERIAL(
																"type_InternalCoveringMaterial"), PRODUCT_DATA_PART(
																		"type_ProductDataPart"), TECHNICAL_SPECIFICATION(
																				"type_TechnicalSpecification"), TEST_METHOD(
																						"type_TestMethod"), TEST_METHOD_SPECIFICATION(
																								"type_TestMethodSpecification"), CPNGLOBALSUBSCRIPTIONCONFIGURATION(
																										"type_CPNGlobalSubscriptionConfiguration"), PART(
																												"type_Part"), FORMULATION(
																														"type_Formulation"), MEMBER_LIST(
																																"type_MemberList"), PRODUCT_LINE(
																																		"type_ProductLine"), COUNTRY(
																																				"type_Country"), LOCATION(
																																						"type_Location"), PROCESSING_INSTRUCTION(
																																								"type_ProcessingInstruction"), TEMPLATE(
																																										"type_Template"), PARENT_SUB(
																																												"type_ParentSub"), COSMETIC_FORMULATION(
																																														"type_CosmeticFormulation"), FOOD_FORMULATION(
																																																"type_FoodFormulation"), DRUG_FORMULATION(
																																																		"type_DrugFormulation"), FRAGRANCE_FORMULATION(
																																																				"type_FragranceFormulation"), HOUSEHOLD_CLEANING_PRODUCT_FORMULATION(
																																																						"type_HouseholdCleaningProductFormulation"), VIRTUAL_INTERMEDIATE(
																																																								"type_VirtualIntermediate"), MATERIAL_FUNCTIONALITY(
																																																										"type_MaterialFunctionality");

		private final String _name;

		private FormulationType(String var3) {
			this._name = var3;
		}

		public String getType(Context var1) {
			return PropertyUtil.getSchemaProperty(var1, this._name);
		}

		public String toString() {
			return this._name;
		}
}
