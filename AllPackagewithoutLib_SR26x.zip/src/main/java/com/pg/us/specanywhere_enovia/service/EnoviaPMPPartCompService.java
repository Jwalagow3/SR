package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaPMPPartCompService {

	HashMap<String, HashMap<String, Map>> getPMPPartCompData(String sObjectName, Environment env);

}
