/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaEBPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.EBPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaEBPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaEBPServiceImpl implements EnoviaEBPService{

	private static Logger LOGGER = Logger.getLogger(EnoviaEBPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	@Override
	public HashMap<String, Map<String, String>> getEBPdata(String strPlant, String objName, Environment env)
			throws Exception 
	{
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("EBP SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());
		EBPBO ebpbo = new EBPBO();
		try 
		{	
			Map<String,String> mapImpactedParts = new HashMap<String, String>();
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			StringValidatorUtil validator = new StringValidatorUtil();
			//Added by Ketan for Defect no. 6630 -- START
			Map<String,String> mapFinalImpactedParts = new HashMap<String, String>();
			BusObjectAttribUtil util  = new BusObjectAttribUtil();
			StringBuilder sbName=new StringBuilder();
			StringBuilder sbID = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbDisType = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			//Added by Ketan for Defect no. 6630 -- END
			//test
			StopWatch swInfotime = new StopWatch();
			swInfotime.start();
			String objId = DomainConstants.EMPTY_STRING;
			String strObjName = objName.toUpperCase(); //Added by Ketan for Defect no. 6256
			MapList mlObjectList = new MapList();
			StringList slObjectsSelect = new StringList();
			slObjectsSelect.add("to[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].from.name");
			slObjectsSelect.add("to[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].from.id");
			slObjectsSelect.add(DomainConstants.SELECT_NAME);
			mlObjectList = DomainObject.findObjects
					(context, //MatrixContext
							ConstantsUtil.SYMBL_ASTERISK, //typePattern
							strObjName, //namePattern
							ConstantsUtil.SYMBL_ASTERISK, //revPattern
							ConstantsUtil.SYMBL_ASTERISK, //ownerPattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
							ConstantsUtilIRM.CURRENT_RELEASE, //whereExpression
							false, //expandType
							slObjectsSelect); //objectSelects
			Iterator<MapList> objectListItr = mlObjectList.iterator(); 
			while(objectListItr.hasNext())
			{
				@SuppressWarnings("unchecked")
				Map<String, String> mpObject = (Map<String, String>)objectListItr.next();
				String strName = validator.isNotNullOrEmpty(mpObject.get("to[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].from.name"))?(mpObject.get("to[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].from.name")) : ConstantsUtil.EMPTY_STRING;
				String strId = validator.isNotNullOrEmpty(mpObject.get("to[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].from.id"))?(mpObject.get("to[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].from.id")) : ConstantsUtil.EMPTY_STRING;
				String [] strReturnCompVal = new String [10];
				String [] strReturnCompId = new String [10];
				strReturnCompVal = strName.split(ConstantsUtil.SYMBL_BOX);
				strReturnCompId = strId.split(ConstantsUtil.SYMBL_BOX);
				String [] slPlant = new String [10];
				String [] slCompany = new String [10];
				if (strReturnCompVal.length > -1) {
					for (int i = 0; i < strReturnCompVal.length; i++) {
						if (null != strReturnCompVal[i]) {
							String sCompany = strReturnCompVal[i].toString();
							if (!sCompany.isEmpty()) {
								String sCompanyId = strReturnCompId[i].toString();
								slPlant = strPlant.split(ConstantsUtil.SYMBL_TILDA);
								slCompany = sCompany.split(ConstantsUtil.SYMBL_TILDA);
								if (slPlant[1].equals(slCompany[1])) {
									objId = sCompanyId;
								}
							}
						}
					}
				}
			}
			swInfotime.stop();
			LOGGER.info("EBP SERVICE GET EBP OBJECT ELAPSED TIME : "+swInfotime.getTime());
			if(UIUtil.isNotNullAndNotEmpty(objId)) {
				StringList slContextSelects = ebpbo.getEBPSelectableMap(context);
				DomainObject dobEBP = new DomainObject(objId);
				Map resultMaps = dobEBP.getInfo(context, slContextSelects);
				String strState = (String) resultMaps.get("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.current");
				String strSpecId = (String) resultMaps.get("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.id");
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,null,strSpecId);
				if (!bObjectHasAccess && (strState.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					context.close();
					return hmAttrib;

				}
				else if(!strState.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strState.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + strSpecId);
					context.close();
					return hmAttrib;
				}
				String strType = (String) resultMaps.get("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.type");
				mpHeaderResult.put(ConstantsUtil.ID, validator.getStringEquivalentForStringList(resultMaps.get("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.id")));
				mpHeaderResult.put(ConstantsUtil.NAME, validator.getStringEquivalentForStringList(resultMaps.get("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.name")));	
				mpHeaderResult.put(ConstantsUtil.TYPE, Bbutil.mapType(validator.getStringEquivalentForStringList(resultMaps.get("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.type"))));
				//Added by Ketan for Req. no. 1563 -- START
				String sDisplayType = Bbutil.getMappedTypeforMPS(validator.getStringEquivalentForStringList(resultMaps.get("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.type")));
				if((ConstantsUtil.PACKING_INSTRUCTION).equals(sDisplayType)) {
					sDisplayType = ConstantsUtil.PI_SHORT;
				}
				mpHeaderResult.put(ConstantsUtilIRM.DISPLAY_TYPE, sDisplayType);
				//Added by Ketan for Req. no. 1563 -- END
				mpHeaderResult.put(ConstantsUtil.REVISION, validator.getStringEquivalentForStringList(resultMaps.get("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.revision")))	;			
				mpHeaderResult.put(ConstantsUtil.TITLE, validator.getStringEquivalentForStringListWithComma(resultMaps.get("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to." +ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
				mpHeaderResult.put(ConstantsUtil.ERROR, ConstantsUtil.EMPTY_STRING);
				if(ConstantsUtilIRM.WHERE_USED_TYPE.contains(strType)) {
					//Added by Ketan for Req. no. 7090 -- END
					mapImpactedParts = ebpbo.getImpactedParts(context,strSpecId,strType);
					//Added by Ketan for Req. no. 7090 -- END
				} else if(ConstantsUtilIRM.IMPACTED_PART_TYPE.contains(strType)) {
					mapImpactedParts = ebpbo.getSpecImpactedPartDetails(context,strSpecId,strType);
					String sError = mapImpactedParts.get(ConstantsUtil.ERROR);
					mpHeaderResult.put(ConstantsUtil.ERROR, sError);
				} 
				//Added by Ketan for Req no. 1589,2180 -- START
				else if(ConstantsUtil.TYPE_PGAUTHORIZEDTEMPORARYSTANDARD.equalsIgnoreCase(strType)) {
					mapImpactedParts = ebpbo.getRelatedPartDetails(context,strSpecId,strType);
				} 
				//Added by Ketan for Req no. 1589,2180 -- END
				else {
					mapImpactedParts = ebpbo.getImpactedPartDetails(context,strSpecId,strType,DomainConstants.EMPTY_STRING,DomainConstants.EMPTY_STRING,DomainConstants.EMPTY_STRING,false);
				}

				//Added by Ketan for Defect no. 6630 -- START
				String strId = validator.getStringEquivalentForStringList(mapImpactedParts.get(ConstantsUtil.ID));
				String stType = validator.getStringEquivalentForStringList(mapImpactedParts.get(ConstantsUtil.TYPE));
				String strDisplayType = validator.getStringEquivalentForStringList(mapImpactedParts.get(ConstantsUtilIRM.DISPLAY_TYPE));
				String strName = validator.getStringEquivalentForStringList(mapImpactedParts.get(ConstantsUtil.NAME));
				String strRev = validator.getStringEquivalentForStringList(mapImpactedParts.get(ConstantsUtil.REVISION));
				String strTitle = validator.getStringEquivalentForStringList(mapImpactedParts.get(ConstantsUtil.TITLE));

				if(!strId.isEmpty()) {
					String[] strIdArr = strId.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strTypeArr = stType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strDisplayTypeArr = strDisplayType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strNameArr = strName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strRevArr = strRev.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strTitleArr = strTitle.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

					for(int i=0;i<strIdArr.length;i++) {

						DomainObject doObj = DomainObject.newInstance(context,strIdArr[i]);
						StringList slObjSelect = new StringList();
						slObjSelect.add(DomainConstants.SELECT_NAME);

						MapList mlPlantList = doObj.getRelatedObjects(context, 
								ConstantsUtilIRM.REL_MANUFACTURING_RESPONSIBILITY, // Rel Pattern
								ConstantsUtil.SYMBL_ASTERISK, // Type Pattern
								slObjSelect, // Object Select
								null, // rel Select
								true, // get To
								false, // get From
								(short) 0, // recurse level
								null, // where Clause
								null, // relationshipWhere Clause
								0);

						MapList mlCompanyList = doObj.getRelatedObjects(context, 
								ConstantsUtil.RELATIONSHIP_PGEXTERNALBUSINESSPARTNERS, // Rel Pattern
								ConstantsUtil.SYMBL_ASTERISK, // Type Pattern
								slObjSelect, // Object Select
								null, // rel Select
								false, // get To
								true, // get From
								(short) 0, // recurse level
								null, // where Clause
								null, // relationshipWhere Clause
								0);

						mlPlantList.addAll(mlCompanyList);
						DeviceProductPartBO DPPBO = new DeviceProductPartBO();
						mlPlantList = DPPBO.removeDuplicates(mlPlantList);

						Iterator objListItr = mlPlantList.iterator();
						StringBuilder sbFName=new StringBuilder();

						while(objListItr.hasNext())
						{
							Map objectMap = (Map) objListItr.next();
							String sFName=(String)objectMap.get(DomainConstants.SELECT_NAME);
							util.formatData(sbFName,sFName);
						}

						if(sbFName.toString().contains(strPlant)) {
							util.formatData(sbName,strNameArr[i]);
							util.formatData(sbID,strIdArr[i]);
							util.formatData(sbDisType,strDisplayTypeArr[i]);
							util.formatData(sbTitle,strTitleArr[i]);
							util.formatData(sbRev,strRevArr[i]);
							util.formatData(sbType,strTypeArr[i]);
						}
					}
				}

				mapFinalImpactedParts.put(ConstantsUtil.ID, sbID.toString());
				mapFinalImpactedParts.put(ConstantsUtil.TYPE,sbType.toString());
				mapFinalImpactedParts.put(ConstantsUtilIRM.DISPLAY_TYPE,sbDisType.toString());
				mapFinalImpactedParts.put(ConstantsUtil.NAME, sbName.toString());
				mapFinalImpactedParts.put(ConstantsUtil.REVISION, sbRev.toString());
				mapFinalImpactedParts.put(ConstantsUtil.TITLE, sbTitle.toString());
				//Added by Ketan for Defect no. 6630 -- END

				dobEBP.close(context);
			}
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtilIRM.IMPACTEDPARTS, mapFinalImpactedParts); //Modified by Ketan for Defect no. 6630
			pool.checkIn(context);
			sp.stop();
		}catch (Exception e) {
			LOGGER.error("Exception in EBP Service IMPL: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}

		LOGGER.info("EBP MESSAGE ELAPSED TIME:: "+sp.getTime());
		context.close();
		return hmAttrib;


	}

}
