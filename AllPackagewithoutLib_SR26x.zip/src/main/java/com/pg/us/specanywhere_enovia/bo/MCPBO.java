/**
 * Project 		: SpecsAnywhere
 * Program 		: MCPBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class MCPBO {

	
	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(MCPBO.class);
	BusObjectAttribUtil util  = new BusObjectAttribUtil();

	public MCPBO() {
		// empty constructor
	}

	
	/**
	 * Method Name 			: getMCPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getMCPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getMCPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public DomainObject getMCPDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			return doObj;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getMCPSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getMCPSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	private static StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
		busSelect.add(ConstantsUtil.RELATIONSHIP_MATERIAL_SUB_CLASS_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCONSUMERRECYCLEDCONTENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
		busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_REL_MCPRF);
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SPECIFICGRAVITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED);
		// SPEC : Added for Defect #42724 by Jwala -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT);
		// SPEC : Added for Defect #42724 by Jwala -- END
		//added by Ganesh for the External Defect ------>START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALNUMBER);
		//added by Ganesh for the External Defect ------>END
		//SPEC: 24-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50296-- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER);
		//SPEC: 24-08-2022: Dominic Added for SR22x.0_NovemberCW Defect 50296-- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME);
		return busSelect;
	}

	
	/**
	 * Method Name 			: updateMaterials
	 * Method Description 	: For Materials and Composition
	 * @param context
	 * @param dob
	 * @return
	 */
	public Map<String, String> updateMaterials(Context context ,DomainObject dob)
	{
		Map<String, String> mpComp = new HashMap<String, String>();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID= new StringBuilder();
		StringBuilder sbQUOM = new StringBuilder();
		StringBuilder sbDesc=new StringBuilder();
		StringBuilder sbManfact=new StringBuilder();
		StringBuilder sbTarget=new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbSeq=new StringBuilder();
		
		StringBuilder sbClassfied = new StringBuilder();
		StringBuilder sbIPClassAttr = new StringBuilder();
		
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
		slBusSelects.add(ConstantsUtil.SELECT_TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		slBusSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		StringList slRelSelects = new StringList();
		
		
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
		
		MapList mlCopmonentsList = new MapList();;
		try 
		{
			mlCopmonentsList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, false, true, (short)0,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				if (util.isModificatinRequired()) {
					mlCopmonentsList=util.filterPhase(mlCopmonentsList);
				}
		
			Iterator objectListItr = mlCopmonentsList.iterator();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sID=(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sQUOM=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sManuf=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
				String sTargt=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGETPERCENTAGEWEIGHTBYWEIGHT);
				String sType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sSeq=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
				
				String strClassFied=(String)objectMap.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);
				String sIPClassfication=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
				
				util.formatData(sbName,sName);
				util.formatData(sbID,sID);
				util.formatData(sbQUOM,sQUOM);
				util.formatData(sbDesc,sDesc);
				
				util.formatData(sbManfact,sManuf);
				util.formatData(sbTarget,sTargt);
				util.formatData(sbType,sType);
				util.formatData(sbSeq,sSeq);
				
				util.formatData(sbClassfied,strClassFied);
				util.formatData(sbIPClassAttr,sIPClassfication);
				
			}

			mpComp.put(ConstantsUtil.ID, sbID.toString());
			mpComp.put(ConstantsUtil.NAME, sbName.toString());
			mpComp.put(ConstantsUtil.UOM,sbQUOM.toString());
			mpComp.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
			mpComp.put(ConstantsUtil.MANUFACTURER,sbManfact.toString());
			mpComp.put(ConstantsUtil.TARGET_PERCEN_WBW, sbTarget.toString());
			mpComp.put(ConstantsUtil.TYPE,sbType.toString());
			mpComp.put(ConstantsUtil.SEQUENCENUMBER, sbSeq.toString());
			mpComp.put(ConstantsUtil.SECURITY, sbClassfied.toString());
			mpComp.put(ConstantsUtil.IPCLASSES,sbIPClassAttr.toString());
			
			mpComp=util.verifyOwnership(context,mpComp);
		} catch (Exception e) {
			LOGGER.error("Exception in Program : MCPBO Method :updateMaterials "+e);
			return new HashMap();
		}
		return mpComp;
	}
	public StringList getPostIndustrialValue(Context context, DomainObject dob) {
		
		String strPostRecycledContent= ConstantsUtil.EMPTY_STRING;
		StringList postIndustrialValues=new StringList();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
		StringList slRelSelects = new StringList();
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
		
		try 
		{
		BigDecimal dDefaultValue = BigDecimal.valueOf(0.0);
		BigDecimal dTempPostRecycledContent = dDefaultValue;
    	BigDecimal dFinalPostRecycledContent = dDefaultValue;
    	BigDecimal dTargetPercent = dDefaultValue;
    	BigDecimal dDivideByHundred = new BigDecimal(100.0);
    	String strTargetPercentage = ConstantsUtil.EMPTY_STRING;
    	BigDecimal dPostRecycledContent = dDefaultValue;
		MapList mlCopmonentsList = new MapList();
		
		mlCopmonentsList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,
				ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, false, true, (short) 1,
				ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
		
		DomainObject domChildPart=DomainObject.newInstance(context);
		if (mlCopmonentsList != null && mlCopmonentsList.size() > 0) {
			Iterator objectListItr = mlCopmonentsList.iterator();

			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String strChildObjId = (String)objectMap.get(ConstantsUtil.SELECT_ID);
    			String strChildType = (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
    			strTargetPercentage=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
    			if (UIUtil.isNotNullAndNotEmpty(strTargetPercentage))
				{
					dTargetPercent = new BigDecimal(strTargetPercentage);
					dTargetPercent = dTargetPercent.divide(dDivideByHundred);
				}
    			if (UIUtil.isNotNullAndNotEmpty(strChildObjId))
    			domChildPart.setId(strChildObjId);
    			strPostRecycledContent = (String)domChildPart.getInfo(context,ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
    			if(UIUtil.isNotNullAndNotEmpty(strPostRecycledContent))
				{
					dPostRecycledContent = new BigDecimal(strPostRecycledContent);  
				}
    			dTempPostRecycledContent = dPostRecycledContent.multiply(dTargetPercent);
				dFinalPostRecycledContent = dFinalPostRecycledContent.add(dTempPostRecycledContent);
			}
		}
		else{
			String strPostRecycledCt=dob.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTINDUSTRIALRECYCLEDCONTENT);
			if (UIUtil.isNotNullAndNotEmpty(strPostRecycledCt))
				dFinalPostRecycledContent = new BigDecimal(strPostRecycledCt);
		}
		if(dFinalPostRecycledContent.compareTo(dDefaultValue)!=0){
			String strTotalPostRecycledContent = String.valueOf(dFinalPostRecycledContent);
		
			postIndustrialValues.add(strTotalPostRecycledContent);
		}else{
			postIndustrialValues.add(ConstantsUtil.EMPTY_STRING);
		}
		return postIndustrialValues;
		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : MCPBO Method :getPostIndustrialValue " + e);
			return new StringList();
		}
	}
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	: 
	 */
	public StringList addMultiList() { 
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
		return slMultiSelects;
	}
}
