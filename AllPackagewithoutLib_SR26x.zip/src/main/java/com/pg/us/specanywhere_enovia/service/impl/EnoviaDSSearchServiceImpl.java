/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaDSSearchServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.DSBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaDSSearchService;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import matrix.db.Context;

public class EnoviaDSSearchServiceImpl implements EnoviaDSSearchService{

	private static Logger dsLOGGER = Logger.getLogger(EnoviaDSSearchServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	@Override
	public HashMap<String, Map<String, String>> getDSSearchData(Environment env, String strType, Map<String, Object> mName) throws Exception {
		
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		dsLOGGER.info("DS SEARCH SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());		
		
		DSBO dsbo = new DSBO();
		try 
		{
			/**
			 * User Profile Section
			 * */
			if(UIUtil.isNullOrEmpty(strType)) {
				dsLOGGER.error("ERROR: INVALID Key FROM INTEGRATION SERVICE : "+strType);
				HashMap<String,String> errorMap = new HashMap<>();
				String[] sError = ConstantsUtil.E102.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				context.close(); // Added for Defect 45181
				return hmAttrib;
			}
			
			/**
			 *  LOAD DYNAMIC SUBSCRIPTION SEARCH
			 * */			
			StopWatch swDSSearch = new StopWatch();
			swDSSearch.start();
			String strName = (String) mName.get(DomainConstants.SELECT_NAME);
			//Added by Ketan for Req. no. 42791,42796 -- START
			if(strType.equalsIgnoreCase(ConstantsUtilIRM.MASTER_BUSAREA) || strType.equalsIgnoreCase(ConstantsUtilIRM.CERT_BUSAREA)) {
			Map<String,String> mBAorCCpicklist = dsbo.getBusAreaOrCertClaimPickList(context, strType);
			hmAttrib.put(ConstantsUtilIRM.SUBSCRIPTIONFIELDS, mBAorCCpicklist);
			}
			//Added by Ketan for Req. no. 42791,42796 -- END
			else {
			Map<String,String> mSearchSubscription = dsbo.getDSSearchFields(context, strType, strName);	
			swDSSearch.stop();
			dsLOGGER.info("DS SEARCH SERVICE GET SEARCH RESULTS ELAPSED TIME : "+swDSSearch.getTime());
			hmAttrib.put(ConstantsUtilIRM.SUBSCRIPTIONFIELDS, mSearchSubscription);
			}
						
		}catch (Exception e) {
			dsLOGGER.error("Exception in DS Search Service IMPL: "+e);
		}
		pool.checkIn(context);
		sp.stop();
		dsLOGGER.info("DS Search SERVICE GETINFO ELAPSED TIME : "+sp.getTime());
		dsLOGGER.info("DS Search MESSAGE:: \n" + hmAttrib);
		//SPEC: <25-07-2022>: Manikanta Added for Defect 45181  -- START
		context.close();
		//SPEC: <25-07-2022>: Manikanta Added for Defect 45181  -- END
		return hmAttrib;		
	}
	
}
