package com.pg.us.specanywhere_enovia.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.SearchBO;

import matrix.db.Context;
import matrix.db.MQLCommand;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class BusSearchUtil {
	
	
	private static Logger LOGGER = Logger.getLogger(BusSearchUtil.class);
	
	public void BusSearchUtil() {
		//empty constructor
	}
	
	/*public static void main(String args[]) throws IOException, MatrixException {
		Context context = ContextUtility.getEnoviaContext();
		String strName="81673541";
		StringList objSelects = BusObjectAttribUtil.getBasicInfoBusSelectable(context);
		MapList mlSearch = DomainObject.findObjects(context, "*", strName.trim(), "*", "*", ConstantsUtil.VAULT_ESERVICEPRODUCTION, "current==Release",false,objSelects);
		int i;
		StringValidatorUtil validator = new StringValidatorUtil();
		List<SearchBO> lsearchObs = new ArrayList();
		for(i=0;i<mlSearch.size();i++) {
			SearchBO searchObj = new SearchBO();
			Map mp = (Map) mlSearch.get(i);
			searchObj.setName((validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_NAME)))?(String)mp.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			searchObj.setCreationDate(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_ORIGINATED))?(String)mp.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			searchObj.setDescription(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_DESCRIPTION))?(String)mp.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			searchObj.setLastModification(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_MODIFIED))?(String)mp.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			searchObj.setMaturityState(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_CURRENT))?(String)mp.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			searchObj.setRevision(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_REVISION))?(String)mp.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			searchObj.setType(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_TYPE))?(String)mp.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
			searchObj.setId(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_ID))?(String)mp.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			lsearchObs.add(searchObj);
		}
	}*/
	
	public List<SearchBO> search(Context context, String strName) throws FrameworkException{
		StopWatch sp = new StopWatch();
		sp.start();
		StringList objSelects = BusObjectAttribUtil.getBasicInfoBusSelectable(context);
		MapList mlSearch = DomainObject.findObjects(context, "*", strName.trim(), "*", "*", ConstantsUtil.VAULT_ESERVICEPRODUCTION, "current==Release",false,objSelects);
		int i;
		StringValidatorUtil validator = new StringValidatorUtil();
		List<SearchBO> lsearchObs = new ArrayList();
		for(i=0;i<mlSearch.size();i++) {
			SearchBO searchObj = new SearchBO();
			Map mp = (Map) mlSearch.get(i);
			searchObj.setName((validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_NAME)))?(String)mp.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			searchObj.setCreationDate(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_ORIGINATED))?(String)mp.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			searchObj.setDescription(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_DESCRIPTION))?(String)mp.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			searchObj.setLastModification(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_MODIFIED))?(String)mp.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			searchObj.setMaturityState(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_CURRENT))?(String)mp.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
			searchObj.setRevision(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_REVISION))?(String)mp.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			searchObj.setType(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_TYPE))?(String)mp.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
			searchObj.setId(validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_ID))?(String)mp.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			lsearchObs.add(searchObj);
		}
		sp.stop();
		LOGGER.info("SearchgetTime:"+sp.getTime());
		return lsearchObs;
	}
	
	
	private String createTempQuery(String sType, String sName, String sRev, String sSelectables) {

		StringBuffer sbQuery = new StringBuffer("temp query bus ");
		sbQuery.append(sType).append("Finished Product Part");
		sbQuery.append(sName).append("");
		sbQuery.append(sRev).append(" ");
		sbQuery.append("select ");
		sbQuery.append("id ").append(sSelectables);
		sbQuery.append(";");

		return sbQuery.toString();
	}
	
	
	private String executeTempQuery(Context context, String sQuery) throws MatrixException {

		
		MQLCommand cmd = new MQLCommand();
		cmd.executeCommand(context, sQuery);
		String result = cmd.getResult();

		return sQuery;
	}

}
