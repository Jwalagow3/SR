/**
 * Project 		: SpecsAnywhere
 * Program 		: DeviceProductPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class DeviceProductPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(DeviceProductPartBO.class);
	static StringValidatorUtil validator = new StringValidatorUtil();
	static BusObjectAttribUtil util = new BusObjectAttribUtil();
	public DeviceProductPartBO() {
		// empty constructor
	}

	public DeviceProductPartBO(String oid) {
		this.setObjectId(oid);
	}


	/**
	 * Method Name : getDPPBO
	 * Method Description : Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getDPPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name : getDPPDO
	 * Method Description : Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getDPPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getDPPPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getDPPPartSelectables(Context context) {
		StringList busSelect = new StringList(150);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getDangerousgoodsSpecSelects(context));
		busSelect.addAll(getGlobalHarmonizedStandard(context));
		busSelect.addAll(getCountryClearanceSelectable(context));
		busSelect.addAll(getStorageTrasportSelectable(context));
		busSelect.addAll(getStabilityResults(context));
		//busSelect.addAll(getWeightCharSelectables(context));
		busSelect.addAll(getSecuritySelects(context));
		busSelect.addAll(getFileSelects(context));
		//SPEC: Added for Dev 18x.6 Release by Jwala -- START
		//busSelect.addAll(getIngredientStatementsSelects(context));
		//SPEC: Added for Dev 18x.6 Release by Jwala -- END
		//busSelect.addAll(getMEPS(context));
		//busSelect.addAll(getSEPS(context));
		//busSelect.addAll(getSubstanceSelectables(context));
		busSelect.addAll(getPlantSelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	/**
	 * getFiles Selectables
	 * @param context
	 * @return StringList
	 */
	public static StringList getFileSelects(Context context) {

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		return busSelect;

	}
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESDEVICECONTAINFLAMMABLELIQUID);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_ID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);

		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);

		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_NAME);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_TITLE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_ASSEMBLYTYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_APPROVEDSUPLIST_CURRENT);

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);

		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_STATE);


		busSelect.add(ConstantsUtil.SELECT_COS_NAME);
		busSelect.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);

		busSelect.add(ConstantsUtil.SELECT_REL_MATERIAL_CERTIFICATIONS_CERTIFICATIONCLAIM);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS);

		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE);

		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ROLLUPNETWEIGHTTOCOP);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		busSelect.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTRECHNOLOGYCHASSIS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.STRPGPDTTOPGPLIREFUN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSREADY);
		//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END
		// Guna Added for Defect 38531  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.strIntendedMarket);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME);
		// Guna Added for Defect 38531  18x.5.2 Release -- END
		//SPEC: <14.04.2021>: Guna Added for 41220 Defect  Dev 18x.6   -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS);
		//SPEC: <14.04.2021>: Guna Added for 41220 Defect  Dev 18x.6   -- END

		//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_SMARTLABENREADY);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCLONETRANSFERRED);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_REASONFORMANUFACTURINGSTATUS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSENUMERIC);
		//SPEC: 07.04.2022: Jwala Added for Req 34415,35902 22x Release  -- END
		//Added by Subhajit for Req 46464 - Start
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		//Added by Subhajit for Req 46464 - End
		//Added by Ajay for Req 7790 - START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION);
		//Added by Ajay for Req 7790 - END
		return busSelect;

	}


	/**
	 * Method Name 			: getDangerousgoodsSpecSelects
	 * Method Description 	: Fetching "Dangerous Goods" related information
	 * @param context
	 * @return
	 */
	public static StringList getDangerousgoodsSpecSelects(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);

		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP);
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

		return busSelect;
	}


	/**
	 * Method Name 			: getGlobalHarmonizedStandard
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getGlobalHarmonizedStandard(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID);

		return busSelect;
	}



	/**
	 * Method Name 			: getCountryClearanceSelectable
	 * Method Description 	: Fetching "Country" related data
	 * @param context
	 * @return
	 */
	public static StringList getCountryClearanceSelectable(Context context) {

		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.STR_COUNTRY_NAME); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_CT_NUM); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS); 	
		busSelect.add(ConstantsUtil.STR_COUNTRY_MANU_SITE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PACK_SITE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PLANT_REST); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_REG_DATE); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_REG_STATUS); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS); 
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE);
		busSelect.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY);

		return busSelect;
	}


	/**
	 * Method Name 			: getStorageTrasportSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getStorageTrasportSelectable(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYCHEMISTRY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYLITHUM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTLIUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYWHRATING);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYENRUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYVOLTAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLYESNO);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCELLS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCAPACITY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYTCUOM);
		//SPEC: Commented for Dev 18x.6 Release by Jwala -- START
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTHEPRODUCTABATTERY);
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTCONTAINABATTERY);
		//SPEC: Commented for Dev 18x.6 Release by Jwala -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE);
		//SPEC: Commented for Dev 18x.6 Release by Jwala -- START
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDOUTSIDEDEVICE);
		//busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAREBATTERIESREQUIRED);
		//SPEC: Commented for Dev 18x.6 Release by Jwala -- END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		//SPEC <12/03/2020> Modified for defect #37730 START 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGHAZARDCLASSIFICATION);
		//SPEC <12/03/2020> Modified for defect #37730 END 
		// Guna Added for Defect 38533  18x.5.2 Release -- START
		busSelect.add(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		// Guna Added for Defect 38533  18x.5.2 Release -- END

		//SPEC: Added for Dev 18x.6 Release by Jwala -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_NUMBEROFBATTERIESREQUIRED);
		//SPEC: Added for Dev 18x.6 Release by Jwala -- END
		//SPEC: <23.12.2021>: Guna Added for 42892 Defect  Dev 18x.6.0.3 Release --- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN);
		//SPEC: <23.12.2021>: Guna Added for 42892 Defect  Dev 18x.6.0.3 Release --- END
		//Added By Ajay for the Req 15195 : START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTYPENUMBER);
		//Added By Ajay for the Req 15195 : END
		return busSelect;
	}


	/**
	 * Method Name 			: getStabilityResults
	 * Method Description 	: Fetching "Stability" related information
	 * @param context
	 * @return
	 */
	public static StringList getStabilityResults(Context context) {
		StringList busSelect = new StringList();

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTPARTPHYSICALID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP);
		busSelect.add(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION);
		busSelect.add(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS);

		return busSelect;
	}


	/**
	 * Method Name 			: getDPPRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getDPPRelatedObjsSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
		busSelect.addAll(getBomBusSelect(context));
		relSelect.addAll(getBomRelSelect(context));
		//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- START
		relSelect.addAll(getSubRelSelects());
		//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- END
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}

	//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- START
	/**
	 * Method Name 			: getSubRelSelects
	 * Method Description 	: 
	 * @return
	 */
	public static StringList getSubRelSelects(){

		StringList busselect = new StringList();

		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		busselect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		busselect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
		busselect.add(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS);
		busselect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//SPEC: <06.07.2022>: Manikanta Modified for Req 41754 22x Release  -- START
		busselect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_PGLIFECYCLE_STATUS);
		busselect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_MATERIALRESTRICTION);
		busselect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_PGMATERIALRESTRICTIONCOMMENTS);
		busselect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_PGORIGINATINGSOURCE);
		//SPEC: <06.07.2022>: Manikanta Modified for Req 41754 22x Release  -- END

		return busselect;
	}
	//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- END
	/**
	 * Method Name 			: getBomBusSelect
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getBomBusSelect(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
		//busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_ID);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE);
		// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
		
		// Added by Jwala for defect 44271 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_BOM);
		// Added by Jwala for defect 44271 -- END
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//Added for defect #37046 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
		//Added for defect #37046 -- END

		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME);
		busSelect.add(ConstantsUtil.CERTIFICATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGCSSTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		//Added By Jwala for req 41754 template fix -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_PGLIFECYCLE_STATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALRESTRICTIONCOMMENTS);
		//Added By Jwala for req 41754 template fix -- START

		return busSelect;
	}


	/**
	 * Method Name : getBomRelSelect
	 * Method Description : 
	 * @param context
	 * @return
	 */
	public static StringList getBomRelSelect(Context context) {
		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
		relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);

		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		//Added for Defect #37046 - START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_VALUE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_VALUE);
		//Added for Defect #37046 - END

		//SPEC: 11/09/2020: Added for Defect : 37019 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_OPT_COMPONENT);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
		//SPEC: 11/09/2020: Added for Defect : 37019 -- END
		relSelect.add(ConstantsUtil.REPORTED_FUNCTION);

		//Modified for Defect# 37591 -- START
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE);
		//Modified for Defect# 37591 -- END

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MIN_QUANTITY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MAX_QUANTITY);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RF);
		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);

		relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_VALUE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_VALUE);
		//Added by Ketan for Req. no. 46464 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RR);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_SUBSTITUTE_RRC);
		//Added by Ketan for Req. no. 46464 -- END

		//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- START
		relSelect.add(ConstantsUtil.RELATIONSHIP_EBOM_SUBSTITUTE_FROMREL_TO_APPLICATION);
		//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- END
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_ID);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_REV);
		relSelect.add(ConstantsUtilIRM.SELECT_EBOM_TYPE);
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END

		return relSelect;
	}


	/**
	 * Method Name 			: getMEPS
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getMEPS(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMNAME);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMREVISION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMCURRENT);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_FROMTONAME);
		return busSelect;
	}


	/**
	 * Method Name 			: getSEPS
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getSEPS(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPTYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPNAME);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPREVISION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPCURRENT);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SEPDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_SUPNAME);
		return busSelect;
	}


	/**
	 * Method Name 			: getWeightCharSelectables
	 * Method Description 	: Fetching "Weight Characteristics" information
	 * @param context
	 * @return
	 */
	public static StringList getWeightCharSelectables (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_TYPE);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_NAME);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_GROSSWEIGHTUOM);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_GROSSWEIGHTREAL);
		busSelect.add(ConstantsUtil.SELECT_REL_COMPOMATERIAL_COMMENTS);

		return busSelect;
	}


	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related details
	 * @param context
	 * @return
	 */
	private StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}


	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching "Plant" related information
	 * @param context
	 * @return
	 */
	public static StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		return busSelect;
	}


	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) 
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_TYPE); 
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ID);  
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCENAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.COMP_DRYWEIGHT); 
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_CLASSIITEM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SUBSTANCE_TYPE);
		busSelect.add(ConstantsUtil.SUBSTANCE_NAME);
		busSelect.add(ConstantsUtil.SUBSTANCE_ID);
		busSelect.add(ConstantsUtil.SUBSTANCE_DESCRIPTION);
		busSelect.add(ConstantsUtil.SUBSTANCE_MAXHGHT);  		
		busSelect.add(ConstantsUtil.SUBSTANCE_MINHGHT);
		busSelect.add(ConstantsUtil.SUBSTANCE_TITLE);
		busSelect.add(ConstantsUtil.SUBSTANCE_REVISION);
		busSelect.add(ConstantsUtil.SUBSTANCE_RELEASEPHASE);
		busSelect.add(ConstantsUtil.SUBSTANCE_DRYWEIGHT);
		busSelect.add(ConstantsUtil.SUBSTANCE_QUOM);
		busSelect.add(ConstantsUtil.SUBSTANCE_QTY);
		busSelect.add(ConstantsUtil.SUBSTANCE_FUNCTIONS);
		busSelect.add(ConstantsUtil.SUBSTANCE_ISCONTAM);
		busSelect.add(ConstantsUtil.SUBSTANCE_CASNUM);
		busSelect.add(ConstantsUtil.SUBSTANCE_SUBSTANCENAME);
		busSelect.add(ConstantsUtil.SUBSTANCE_STATE);
		busSelect.add(ConstantsUtil.SUBSTANCE_ORIGINSOURCE);
		busSelect.add(ConstantsUtil.SUBSTANCE_CLASSIFIED_ITEM);
		busSelect.add(ConstantsUtil.SUBSTANCE_IPCALSS);

		return busSelect;
	}
	public static StringList getSubstanceRelSelectables (Context context) 
	{
		StringList relSelects = new StringList();

		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);  		
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
		relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);

		return relSelects;

	}

	/**
	 * Method Name 			: getSubstances
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Context context,String strObjId)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId=new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbRevision=new StringBuilder();
		StringBuilder sbDesc=new StringBuilder();
		StringBuilder sbCAS=new StringBuilder();
		StringBuilder sbSub = new StringBuilder();
		StringBuilder sbCont = new StringBuilder();
		StringBuilder sbQty=new StringBuilder();
		StringBuilder sbMaxWt = new StringBuilder();
		StringBuilder sbMinWt = new StringBuilder();
		StringBuilder sbQOM=new StringBuilder();
		StringBuilder sbDry=new StringBuilder();
		StringBuilder sbFunction=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		StringBuilder sbClasssified=new StringBuilder();
		StringBuilder sbIPClass=new StringBuilder();

		StringBuilder sbUF=new StringBuilder();

		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strObjId))
			{
				DomainObject contextObj = DomainObject.newInstance(context,strObjId);

				MapList mlRelatedIAPSList = contextObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,
						ConstantsUtil.SYMBL_ASTERISK, getSubstanceSelectables(context), getSubstanceRelSelectables(context), false, true, (short) 0,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

				Iterator objectListItr = mlRelatedIAPSList.iterator();

				while(objectListItr.hasNext()){

					Map resultMaps = (Map) objectListItr.next();

					String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
					String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
					String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));

					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//String strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
					String strDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
					//String strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String strTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					String strRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
					String strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));

					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//String strCAS	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
					String strCAS	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					String strSub	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCENAME));
					String strCont	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
					String strQty	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
					String strMaxWt	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
					String strMinWt	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
					String strQom	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
					String strDry	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));

					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//String strFunctions	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
					String strFunctions	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					String sPhase   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
					String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIITEM));
					String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));

					String sUF = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.EMPTY_STRING));

					if(strMinWt.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
						strMinWt = ConstantsUtil.EMPTY_STRING;

					if(strMaxWt.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
						strMaxWt = ConstantsUtil.EMPTY_STRING;

					formatData(sbType,strType);
					formatData(sbName,strName);
					formatData(sbDesc,strDesc);
					formatData(sbCurrent,strState);
					formatData(sbId,strID);
					formatData(sbRevision,strRev);
					formatData(sbCAS,strCAS);
					formatData(sbTitle,strTitle);
					formatData(sbSub,strSub);
					formatData(sbCont,strCont);
					formatData(sbQty,strQty);
					formatData(sbMaxWt,strMaxWt);
					formatData(sbMinWt,strMinWt);
					formatData(sbQOM,strQom);
					formatData(sbDry,strDry);
					formatData(sbFunction,strFunctions);
					formatData(sbPhase,sPhase);
					formatData(sbClasssified,strClassFied);
					formatData(sbIPClass,sIPClassfication);
					formatData(sbUF,sUF);

					strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_TYPE));

					if(!strType.equalsIgnoreCase("Substance")) {
						strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_TITLE));
					}
					else{
						strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_SUBSTANCENAME));
					}

					strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_ID));
					strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_NAME));

					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_DESCRIPTION));
					strDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SUBSTANCE_DESCRIPTION));
					//strRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_REVISION));
					strRev	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SUBSTANCE_REVISION));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_STATE));

					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//strCAS	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_CASNUM));
					strCAS	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SUBSTANCE_CASNUM));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					strSub	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_SUBSTANCENAME));
					strCont	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SUBSTANCE_ISCONTAM));
					strQty	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_QTY));
					strMaxWt	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_MAXHGHT));
					strMinWt	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_MINHGHT));
					strQom	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_QUOM));
					strDry	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_DRYWEIGHT));

					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//strFunctions	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_FUNCTIONS));
					strFunctions	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SUBSTANCE_FUNCTIONS));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					sPhase   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_RELEASEPHASE));
					strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.SUBSTANCE_CLASSIFIED_ITEM));
					sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.SUBSTANCE_IPCALSS));

					sUF = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.EMPTY_STRING));

					if(strMinWt.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
						strMinWt = ConstantsUtil.EMPTY_STRING;

					if(strMaxWt.trim().equalsIgnoreCase(ConstantsUtil.ZERO_SIZE))
						strMaxWt = ConstantsUtil.EMPTY_STRING;

					formatData(sbType,strType);
					formatData(sbName,strName);
					formatData(sbDesc,strDesc);
					formatData(sbCurrent,strState);
					formatData(sbId,strID);
					formatData(sbRevision,strRev);
					formatData(sbCAS,strCAS);
					formatData(sbTitle,strTitle);
					formatData(sbSub,strSub);
					formatData(sbCont,strCont);
					formatData(sbQty,strQty);
					formatData(sbMaxWt,strMaxWt);
					formatData(sbMinWt,strMinWt);
					formatData(sbQOM,strQom);
					formatData(sbDry,strDry);
					formatData(sbFunction,strFunctions);
					formatData(sbPhase,sPhase);
					formatData(sbClasssified,strClassFied);
					formatData(sbIPClass,sIPClassfication);
					formatData(sbUF,sUF);
				}
				mpSubStanceResult.put(ConstantsUtil.SECURITY, sbClasssified.toString());
				mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sbIPClass.toString());
				mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString());
				mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString());
				mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString());
				mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString());
				mpSubStanceResult.put(ConstantsUtil.REV,sbRevision.toString());
				mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString());
				mpSubStanceResult.put(ConstantsUtil.PHASE,sbPhase.toString());
				mpSubStanceResult.put(ConstantsUtil.CAS,sbCAS.toString());
				//mpSubStanceResult.put(ConstantsUtil.SUBSTANCENAME,sbSub.toString());
				//mpSubStanceResult.put(ConstantsUtil.QUANTITYTYPE,sbQty.toString());
				//mpSubStanceResult.put(ConstantsUtil.IC,sbCont.toString());
				mpSubStanceResult.put(ConstantsUtil.IP,sbCont.toString());
				mpSubStanceResult.put(ConstantsUtil.MAX,sbMaxWt.toString());
				mpSubStanceResult.put(ConstantsUtil.MIN,sbMinWt.toString());
				mpSubStanceResult.put(ConstantsUtil.UOM,sbQOM.toString());
				mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sbDry.toString());
				mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sbFunction.toString());
				mpSubStanceResult.put(ConstantsUtil.ID, sbId.toString());

				mpSubStanceResult.put(ConstantsUtil.UF, sbUF.toString());

			}
		}catch(Exception e){

			LOGGER.error("Error from DeviceProductPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}


	/**
	 *  Method Name : getMaterialProduced
	 *  Method Description : Get "Materials Produced" related data
	 * @param context
	 * @param strObjId
	 * @returns materials Produced
	 */
	public Map getMaterialProduced(Context context,String strObjId)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();

		StringBuilder sbId=new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();

		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbRevision=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();

		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strObjId))
			{
				DomainObject contextObj = DomainObject.newInstance(context,strObjId);
				StringList selectStmts = new StringList(5);                     
				selectStmts.addElement(ConstantsUtil.SELECT_ID);
				selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
				selectStmts.addElement(ConstantsUtil.SELECT_NAME);
				selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
				selectStmts.addElement(ConstantsUtil.SELECT_DESCRIPTION);
				selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);		
				selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

				selectStmts.add(ConstantsUtil.SUBSTANCE_TYPE);
				selectStmts.add(ConstantsUtil.SUBSTANCE_ID);
				selectStmts.add(ConstantsUtil.SUBSTANCE_NAME);
				selectStmts.add(ConstantsUtil.SUBSTANCE_DESCRIPTION);
				selectStmts.add(ConstantsUtil.SUBSTANCE_TITLE);
				selectStmts.add(ConstantsUtil.SUBSTANCE_REVISION);
				selectStmts.add(ConstantsUtil.SUBSTANCE_STATE);
				selectStmts.add(ConstantsUtil.SUBSTANCE_RELEASEPHASE);

				MapList mlRelatedIAPSList = contextObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,
						ConstantsUtil.SYMBL_ASTERISK, selectStmts, null, false, true, (short) 0,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

				Iterator objectListItr = mlRelatedIAPSList.iterator();

				while(objectListItr.hasNext())
				{
					Map resultMaps = (Map) objectListItr.next();

					String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.TYPE));
					String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ID));
					String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.NAME));
					String strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.DESCRIPTION));
					String strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String strRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
					String strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
					String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

					formatData(sbType,strType);
					formatData(sbName,strName);
					formatData(sbDesc,strDesc);
					formatData(sbCurrent,strState);
					formatData(sbId,strID);
					formatData(sbRevision,strRev);
					formatData(sbPhase,strPhase);
					formatData(sbTitle,strTitle);

					strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_TYPE));
					strID	 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_ID));
					strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_NAME));
					strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_DESCRIPTION));
					strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_TITLE));
					strRev	 		=  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_REVISION));
					strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_STATE));
					strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_RELEASEPHASE));

					formatData(sbType,strType);
					formatData(sbName,strName);
					formatData(sbDesc,strDesc);
					formatData(sbCurrent,strState);
					formatData(sbId,strID);
					formatData(sbRevision,strRev);
					formatData(sbPhase,strPhase);
					formatData(sbTitle,strTitle);

				}

				mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString());
				mpSubStanceResult.put(ConstantsUtil.TITLE,sbDesc.toString());
				mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString());
				mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString());
				mpSubStanceResult.put(ConstantsUtil.REV,sbRevision.toString());
				mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString());
				mpSubStanceResult.put(ConstantsUtil.PHASE, sbPhase.toString());
				mpSubStanceResult.put(ConstantsUtil.ID, sbId.toString());
			}

		}catch(Exception e){

			LOGGER.error("Error from DeviceProductPartBO:  getMaterialProduced"+e);
			return new HashMap();
		}
		return util.filterMapList(mpSubStanceResult);
	}


	/**
	 *  Method Name : getMaterialProducedforDPP
	 *  Method Description : Get "Materials Produced" related data
	 * @param context
	 * @param strObjId
	 * @returns materials Produced
	 */
	public Map getMaterialProducedforDPP(Context context,String strObjId)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();

		StringBuilder sbId=new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();

		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbRevision=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		StringBuilder sbParentName = new StringBuilder();//Added by Ajay for 22x.06 Req.9264
		
		//SPEC: Release SR18x.6. Added by Dominic for Defect 41690 on Date 29/03/2021 --START
		boolean showData = false;
		String sUserType = util.getUserType();
		//SPEC: Release SR18x.6. Added by Dominic for Defect 41690 on Date 29/03/2021 --END

		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strObjId))
			{
				DomainObject contextObj = DomainObject.newInstance(context,strObjId);
				StringList selectStmts = new StringList(5);                     
				selectStmts.addElement(ConstantsUtil.SELECT_ID);
				selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
				selectStmts.addElement(ConstantsUtil.SELECT_NAME);
				selectStmts.addElement(ConstantsUtil.SELECT_REVISION);
				selectStmts.addElement(ConstantsUtil.SELECT_DESCRIPTION);
				selectStmts.addElement(ConstantsUtil.SELECT_CURRENT);		
				selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				selectStmts.addElement(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

				selectStmts.add(ConstantsUtil.SUBSTANCE_TYPE);
				selectStmts.add(ConstantsUtil.SUBSTANCE_ID);
				selectStmts.add(ConstantsUtil.SUBSTANCE_NAME);
				selectStmts.add(ConstantsUtil.SUBSTANCE_DESCRIPTION);
				selectStmts.add(ConstantsUtil.SUBSTANCE_TITLE);
				selectStmts.add(ConstantsUtil.SUBSTANCE_REVISION);
				selectStmts.add(ConstantsUtil.SUBSTANCE_STATE);
				selectStmts.add(ConstantsUtil.SUBSTANCE_RELEASEPHASE);
				StringList relSelects = new StringList(1);
				relSelects.add("from.name");

				MapList mlRelatedIAPSList = contextObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGDEFINESMATERIAL,
						ConstantsUtil.SYMBL_ASTERISK, selectStmts, relSelects, false, true, (short) 0,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

				Iterator objectListItr = mlRelatedIAPSList.iterator();

				while(objectListItr.hasNext())
				{
					Map resultMaps = (Map) objectListItr.next();

					String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.TYPE));
					String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.ID));
					String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.NAME));

					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//String strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.DESCRIPTION));
					String strDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.DESCRIPTION));
					//String strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String strTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					String strRev	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
					String strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
					String strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
					String sParentName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_EBOM_NAME));//Added by Ajay for 22x.06 Req.9264
					//SPEC: 01/29/2021: Modified for Defect 38188 by Chandra -- START

					if (! (strState.equals(ConstantsUtil.RELEASE) &&  !strState.equals(ConstantsUtil.RELEASED)) ) {
						strID=ConstantsUtil.NO_ACCESS;
					}
					strState=util.mapType(strState);
					strType=util.mapType(strType);

					if (UIUtil.isNotNullAndNotEmpty(strID)) {
						//SPEC: Release SR18x.6. Added by Dominic for Defect 41690 on Date 29/03/2021 --START
						showData = util.checkHasAccess(context, sUserType, strID);
						
						//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- START
						//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
						/*if (!showData && util.isModificatinRequired()) {
							continue;
						}*/
						//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
						//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- END
						
						//Added by Jwala for the defect 43736 -- START
						if(!showData && util.isModificatinRequired()){
							continue;
						}
						//Added by Jwala for the defect 43736 -- END
						if (!showData) {
							formatData(sbType,strType);
							formatData(sbName,strName);
							formatData(sbDesc,ConstantsUtil.NO_ACCESS);
							formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
							formatData(sbId,ConstantsUtil.NO_ACCESS);
							formatData(sbRevision,strRev);
							formatData(sbPhase,ConstantsUtil.NO_ACCESS);
							formatData(sbTitle,ConstantsUtil.NO_ACCESS);
							formatData(sbParentName, ConstantsUtil.EMPTY_STRING);
						}
						else {
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41690 on Date 29/03/2021 --END	
							formatData(sbType,strType);
							formatData(sbName,strName);
							formatData(sbDesc,strDesc);
							formatData(sbCurrent,strState);
							formatData(sbId,strID);
							formatData(sbRevision,strRev);
							formatData(sbPhase,strPhase);
							formatData(sbTitle,strTitle);
							formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41690 on Date 29/03/2021 --START
							}
							//SPEC: Release SR18x.6. Added by Dominic for Defect 41690 on Date 29/03/2021 --END
					}
					//SPEC: 01/29/2021: Modified for Defect 38188 by Chandra -- END

					strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_TYPE));
					strID	 	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_ID));
					strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_NAME));
					sParentName =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtilIRM.SELECT_EBOM_NAME));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
					//strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_DESCRIPTION));
					strDesc	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SUBSTANCE_DESCRIPTION));
					//strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_TITLE));
					strTitle	 =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SUBSTANCE_TITLE));
					//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END

					strRev	 		=  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_REVISION));
					strState	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_STATE));
					strPhase	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SUBSTANCE_RELEASEPHASE));

					//SPEC: 01/29/2021: Modified for Defect 38188 by Chandra -- START
					if (! (strState.equals(ConstantsUtil.RELEASE) ||  !strState.equals(ConstantsUtil.RELEASED)) ) {
						strID=ConstantsUtil.NO_ACCESS;
					}
					strState=util.mapType(strState);
					strType=util.mapType(strType);


					if (UIUtil.isNotNullAndNotEmpty(strID)) {
						formatData(sbType,strType);
						formatData(sbName,strName);
						formatData(sbDesc,strDesc);
						formatData(sbCurrent,strState);
						formatData(sbId,strID);
						formatData(sbRevision,strRev);
						formatData(sbPhase,strPhase);
						formatData(sbTitle,strTitle);
						formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264
					}

					//SPEC: 01/29/2021: Modified for Defect 38188 by Chandra -- END
				}

				mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString());
				//SPEC: Release SR18x.5.2 - Added for Defect# 38188  by Ganesh on Date 2/12/2021 -- START
				//mpSubStanceResult.put(ConstantsUtil.TITLE,sbDesc.toString());
				mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString());
				//SPEC: Release SR18x.5.2 - Added for Defect# 38188  by Ganesh on Date 2/12/2021 -- END
				mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString());
				mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString());
				mpSubStanceResult.put(ConstantsUtil.REV,sbRevision.toString());
				mpSubStanceResult.put(ConstantsUtil.STATE,sbCurrent.toString());
				mpSubStanceResult.put(ConstantsUtil.PHASE, sbPhase.toString());
				mpSubStanceResult.put(ConstantsUtil.ID, sbId.toString());
				mpSubStanceResult.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString().trim());//Added by Ajay for 22x.06 Req.9264
			}

		}catch(Exception e){

			LOGGER.error("Error from DeviceProductPartBO:  getMaterialProducedforDPP"+e);
			return new HashMap();
		}
		return util.filterMapList(mpSubStanceResult);
	}

	/**
	 * Method Name 			: getCountryClearanceResult
	 * Method Description 	: 
	 * @param resultMaps
	 * @return
	 */
	public Map getCountryClearanceResult(Context context, String sContextObjectId)
	{

		Map<String, String> mapCountryClearanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();

		StringBuilder sbMarketName = new StringBuilder();
		StringBuilder sbClearanceNum = new StringBuilder();
		StringBuilder sbOveralClearence = new StringBuilder();
		StringBuilder sbGPSApproval = new StringBuilder();
		StringBuilder sbManuSite = new StringBuilder();
		StringBuilder sbPackSite = new StringBuilder();
		StringBuilder sbComments = new StringBuilder();
		StringBuilder sbRestrictions = new StringBuilder();
		StringBuilder sbRegExpDate = new StringBuilder();
		StringBuilder sbRegStatus = new StringBuilder();
		StringBuilder sbMPDTNumber = new StringBuilder();
		StringBuilder sbPRODRegClass = new StringBuilder();
		StringBuilder sbRegrewlleadTime = new StringBuilder();
		StringBuilder sbRegirewlStatus = new StringBuilder();
		StringBuilder sbRegProductName = new StringBuilder();
		//SPEC: Added for Dev 18x.6 Release by Jwala -- START
		StringBuilder sbMarketAppproverHolder = new StringBuilder();
		StringBuilder sbLegalEntity = new StringBuilder();
		StringBuilder sbBusinessChannel = new StringBuilder();
		StringBuilder sbPackSize = new StringBuilder();
		StringBuilder sbPackSizeUOM = new StringBuilder();
		//SPEC: Added for Dev 18x.6 Release by Jwala -- END

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_NAME);

		StringList relSelect = new StringList();
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALLEADTIME);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME);
		//SPEC: Added for Dev 18x.6 Release by Jwala -- START
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETAPPROVERHOLDER);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLEGALENTITY);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZE);
		relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZEUOM);
		//SPEC: Added for Dev 18x.6 Release by Jwala -- END

		try
		{

			MapList mapList;

			DomainObject doDPP = new DomainObject(sContextObjectId);

			mapList = doDPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE, ConstantsUtil.SYMBL_ASTERISK,
					busSelect, relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doDPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			mapList.sort(DomainConstants.SELECT_NAME, "ascending", "String");

			for (int i = 0; i < mapList.size(); i++) {
				Map resultMaps = (Map) mapList.get(i);
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 40640 on Date 26/03/2021 --START
				String strMarketName    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_NAME));
				String strClearanceNum    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER));
				String strOveralClearence    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS));
				String strGPSApproval   =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS));
				String strManuSite    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE));
				String strPackSite    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE));
				String strComments    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT));
				String strRestrictions    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION));
				String strRegExpDate    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE));
				String strRegStatus    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS));
				strRegStatus=strRegStatus.replace(ConstantsUtil.REGISTRATIONRELEASEDAPP, ConstantsUtil.REGISTRATIONAPPROVEDAPP);
				String strMPDTNumber    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER));
				String strPRODRegClass    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION));
				String strRegrewlleadTime    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALLEADTIME));
				String strRegirewlStatus    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONRENEWALSTATUS));
				String strRegProductName    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME));

				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				String strMarketAppproverHolder    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETAPPROVERHOLDER));
				String strLegalEntity    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLEGALENTITY));
				String strBusinessChannel    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSCHANNEL));
				String strPackSize    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZE));
				String strPackSizeUOM    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKSIZEUOM));
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 40640 on Date 26/03/2021 --END
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41661 on Date 12/04/2021 --START
				int iSize = 0;
				for(int k = 0; k < strClearanceNum.length(); k++) {
				    if(strClearanceNum.charAt(k) == ',') iSize++;
				}
				strClearanceNum    =  strClearanceNum.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strGPSApproval   =  strGPSApproval.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strManuSite    =  strManuSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSite    =  strPackSite.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strComments    =  strComments.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRestrictions    =  strRestrictions.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegExpDate    =  strRegExpDate.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegStatus    =  strRegStatus.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strMPDTNumber    =  strMPDTNumber.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPRODRegClass    =  strPRODRegClass.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegProductName    =  strRegProductName.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegrewlleadTime    =  strRegrewlleadTime.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strRegirewlStatus    =  strRegirewlStatus.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strMarketAppproverHolder    =  strMarketAppproverHolder.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strLegalEntity    =  strLegalEntity.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strBusinessChannel    =  strBusinessChannel.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSize    =  strPackSize.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				strPackSizeUOM    =  strPackSizeUOM.replace(ConstantsUtil.SYMBL_COMMA,ConstantsUtil.SYMBL_PIPE);
				for (int j = 0; j <= iSize; j++) {
					formatData(sbMarketName, strMarketName);
					formatData(sbOveralClearence, strOveralClearence);
				}
				//SPEC: Release SR18x.6. Added by Dominic for Defect 41661 on Date 12/04/2021 --END

				//util.formatData(sbMarketName, strMarketName);
				util.formatData(sbClearanceNum, strClearanceNum);
				//util.formatData(sbOveralClearence, strOveralClearence);
				util.formatData(sbGPSApproval, strGPSApproval);
				util.formatData(sbManuSite, strManuSite);
				util.formatData(sbPackSite, strPackSite);
				util.formatData(sbComments, strComments);
				util.formatData(sbRestrictions, strRestrictions);
				//SPEC: Modified by Jwala for Internal defect fixes -- START
				//util.formatData(sbRegExpDate, strRegExpDate);
				util.formatData(sbRegExpDate, validator.DateFormatter(strRegExpDate));
				//SPEC: Modified by Jwala for Internal defect fixes -- END
				util.formatData(sbRegStatus, strRegStatus);
				util.formatData(sbMPDTNumber, strMPDTNumber);
				util.formatData(sbPRODRegClass, strPRODRegClass);
				util.formatData(sbRegrewlleadTime, strRegrewlleadTime);
				util.formatData(sbRegirewlStatus, strRegirewlStatus);
				util.formatData(sbRegProductName, strRegProductName);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				util.formatData(sbMarketAppproverHolder, strMarketAppproverHolder);
				util.formatData(sbLegalEntity, strLegalEntity);
				util.formatData(sbBusinessChannel, strBusinessChannel);
				util.formatData(sbPackSize, strPackSize);
				util.formatData(sbPackSizeUOM, strPackSizeUOM);
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END

				mapCountryClearanceResult.put(ConstantsUtil.MARKET_NAME, sbMarketName.toString());
				mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, sbClearanceNum.toString());
				mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, sbOveralClearence.toString());
				mapCountryClearanceResult.put(ConstantsUtil.GPS_APPROVAL, sbGPSApproval.toString());
				mapCountryClearanceResult.put(ConstantsUtil.MANU_SITE, sbManuSite.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PACK_SITE, sbPackSite.toString());
				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				//mapCountryClearanceResult.put(ConstantsUtil.COMMENTS, sbComments.toString());
				mapCountryClearanceResult.put(ConstantsUtil.GPSCOMMENTS, sbComments.toString());
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END
				mapCountryClearanceResult.put(ConstantsUtil.RESTRICTIONS, sbRestrictions.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, sbRegExpDate.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, sbRegStatus.toString());
				mapCountryClearanceResult.put(ConstantsUtil.MARKETPRODUCTNUMBER, sbMPDTNumber.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PROD_REG_CLASS, sbPRODRegClass.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALLEADTIME, sbRegrewlleadTime.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALSTATUS, sbRegirewlStatus.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTEREDPRODUCTNAME, sbRegProductName.toString());

				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				mapCountryClearanceResult.put(ConstantsUtil.MARKETAPPROVALHOLDER, sbMarketAppproverHolder.toString());
				mapCountryClearanceResult.put(ConstantsUtil.LEGALENTITY, sbLegalEntity.toString());
				mapCountryClearanceResult.put(ConstantsUtil.BUSINESSCHANNEL, sbBusinessChannel.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PACKSIZE, sbPackSize.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PACKSIZEUOM, sbPackSizeUOM.toString());
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END
			}

		}catch(Exception e){

			LOGGER.error("Error from DeviceProductPartBO:  getCountryClearanceResult"+e);
			return new HashMap();
		}

		return mapCountryClearanceResult;
	}


	/**
	 * Method Name 			: parseMaplist
	 * Method Description 	:
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> parseMaplist(Context context ,MapList mapList, boolean bSupplierView) {
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		BusObjectAttribUtil util = new BusObjectAttribUtil();

		//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --START
		//Iterator objectListItr = mapList.iterator();
		Map MPFinalEBOMSubStitute = new HashMap();
		Map mpFinalEBOM = new HashMap();
		Map mpFinalSubstitute = new HashMap();
		//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
		int index=1;
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMParentRevision = new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
		StringBuilder sbFEBOMName = new StringBuilder();
		StringBuilder sbFEBOMId = new StringBuilder();
		StringBuilder sbFEBOMRev = new StringBuilder();
		StringBuilder sbFEBOMChg = new StringBuilder();
		StringBuilder sbFEBOMFN = new StringBuilder();
		StringBuilder sbFEBOMTitle = new StringBuilder();
		StringBuilder sbFEBOMType = new StringBuilder();
		StringBuilder sbFEBOMQTY = new StringBuilder();
		StringBuilder sbFEBOMBuom = new StringBuilder();
		StringBuilder sbFEBOMCommnts = new StringBuilder();
		StringBuilder sbFEBOMState= new StringBuilder();
		StringBuilder sbFEBOMStage= new StringBuilder();
		StringBuilder sbFEBOMRDOC= new StringBuilder();
		StringBuilder sbFEBOMSubstute= new StringBuilder();
		StringBuilder sbFEBOMRevRelDt= new StringBuilder();
		StringBuilder sbFEBOMTupName= new StringBuilder();		 
		StringBuilder sbFMinqty= new StringBuilder();
		StringBuilder sbFMaxqty= new StringBuilder();
		StringBuilder sbFNetWUOM= new StringBuilder();
		StringBuilder sbFNetWet= new StringBuilder();
		StringBuilder sbFLoss= new StringBuilder();
		StringBuilder sbFMF= new StringBuilder();
		StringBuilder sbFGW= new StringBuilder();
		StringBuilder sbFAltName = new StringBuilder();
		StringBuilder sbFAltID = new StringBuilder();
		StringBuilder sbFAltType = new StringBuilder();
		StringBuilder sbFNet= new StringBuilder();
		StringBuilder sbFOSPD= new StringBuilder();
		StringBuilder sbFDen= new StringBuilder();
		StringBuilder sbFCerti= new StringBuilder();
		StringBuilder sbFRF= new StringBuilder();
		StringBuilder sbFEBOMSubstitutePart = new StringBuilder();
		StringBuilder sbFEBOMSubPartID = new StringBuilder();
		StringBuilder sbFEBOMSubPartType = new StringBuilder();
		StringBuilder sbGrossWeightReal = new StringBuilder();
		StringBuilder sbGrossWeightUOM = new StringBuilder();
		StringBuilder sbManufacturingStatus = new StringBuilder();
		//Added by Subhajit for Req 46464 - Start
		StringBuilder sbRelRestriction = new StringBuilder();
		StringBuilder sbRelRestrictionComment = new StringBuilder();
		//StringBuilder sbMaterialRestriction = new StringBuilder();
		//StringBuilder sbMRComments = new StringBuilder();
		//Added by Subhajit for Req 46464 - End
		MapList mlEBOMSubList = new MapList();
		//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
		APPBO APPBO = new APPBO();
		try 
		{
			Map objectMap = null;
			Map<String, String> mpSubstituteResult = null;
			MapList mlPhaseEBOMList = null;
			int iParentLevel = 0;
			StringList slParentId = new StringList();
			String sParentId = ConstantsUtil.EMPTY_STRING;

			for(int i =0; i<mapList.size(); i++)
			{
				objectMap = (Map) mapList.get(i);
				iParentLevel = Integer.parseInt((String) objectMap.get(ConstantsUtil.SELECT_LEVEL));

				mpSubstituteResult = new HashMap<String, String>();
				mpEBOMResult = new HashMap<String, String>();
				mlPhaseEBOMList = new MapList();
				sParentId = ConstantsUtil.EMPTY_STRING;
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS

				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMRev = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMFN = new StringBuilder();
				StringBuilder sbEBOMTitle = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMQTY = new StringBuilder();
				StringBuilder sbEBOMBuom = new StringBuilder();
				StringBuilder sbEBOMCommnts = new StringBuilder();
				StringBuilder sbEBOMState= new StringBuilder();
				StringBuilder sbEBOMStage= new StringBuilder();
				StringBuilder sbEBOMRDOC= new StringBuilder();
				StringBuilder sbEBOMSubstute= new StringBuilder();
				StringBuilder sbEBOMRevRelDt= new StringBuilder();
				StringBuilder sbEBOMTupName= new StringBuilder();		 
				StringBuilder sbMinqty= new StringBuilder();
				StringBuilder sbMaxqty= new StringBuilder();
				StringBuilder sbNetWUOM= new StringBuilder();
				StringBuilder sbNetWet= new StringBuilder();
				StringBuilder sbLoss= new StringBuilder();
				StringBuilder sbMF= new StringBuilder();
				StringBuilder sbGW= new StringBuilder();
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
				//StringBuilder sbAlt= new StringBuilder();
				StringBuilder sbAltName = new StringBuilder();
				StringBuilder sbAltID = new StringBuilder();
				StringBuilder sbAltType = new StringBuilder();
				// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
				StringBuilder sbNet= new StringBuilder();
				StringBuilder sbOSPD= new StringBuilder();
				StringBuilder sbDen= new StringBuilder();
				StringBuilder sbCerti= new StringBuilder();

				StringBuilder sbRF= new StringBuilder();

				//SPEC 10.29.2020 modifed: brought from if clause and made as global--START
				SecurityService sec = new SecurityService();
				String sComp = sec.getUserCauthorities();
				StringList slUserOwnership=util.filterOwnerShip(sComp);
				String sUserlicense = sec.getUserLicense();

				StringList slHIRTypes = new StringList();
				slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
				slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
				//SPEC 10.29.2020 modifed: brought from if clause and made as global--END

				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
				StringBuilder sbEBOMSubstitutePart = new StringBuilder();
				StringBuilder sbEBOMSubPartID = new StringBuilder();
				StringBuilder sbEBOMSubPartType = new StringBuilder();
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END


				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --START		
				//while(objectListItr.hasNext())
				//{
				//Map objectMap = (Map) objectListItr.next();
				String sPId =(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sFormulaPropagate = sPId;
				//SPEC: <12.30.2020>: Modified for Req :36032 by Sumit #(BOM Expansion)# --ENDS
				String sName =(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sRevision =(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sReleaseDate =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
				String sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
				String spgChg =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
				String sFN =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				String sTitle =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sPType =(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sTupName =(String)objectMap.get(ConstantsUtil.TUPNAME);
				String sQty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				String sBuom =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				String sComments=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				String sCurrent =(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				//Modified for Defect #37046 -- START
				if(null!=sCurrent && sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {

					sCurrent=ConstantsUtil.RELEASED;
				}
				//Modified for Defect #37046 -- 
				String sStage =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				String sRD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
				sRD = sRD.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
				String sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
				String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
				String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
				String strNetWUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
				String strNetWet =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
				//Modified for Defect #37046 -- START
				//Commented by Ketan for Req. no. 47950
				/*if(null!=strNetWet && strNetWet.isEmpty() || strNetWet.equalsIgnoreCase("0.0")) {

					//strNetWet="0.0";
					strNetWet="0";
				}*/

				//String strLoss =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
				String strLoss =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_VALUE);
				//Commented by Ketan for Req. no. 47950
				/*if(null!=strLoss && strNetWet.isEmpty() || strLoss.equalsIgnoreCase("0.0")) {
					strLoss="0";

				}*/
				//SPEC: 04-08-2022: Dominic Added for Internal Defect -- START
				String strMF =ConstantsUtil.EMPTY_STRING;
				String strMFObjId =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);

				try
				{
					if (UIUtil.isNotNullAndNotEmpty(strMFObjId)) 
					{
						strMF=util.getIdFromPhysicalIdFunction(context,strMFObjId);
					}
				}catch(Exception e){
					strMF=ConstantsUtil.EMPTY_STRING;
				}
				//SPEC: 04-08-2022: Dominic Added for Internal Defect -- END
				String strGW =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);
				String strAltName =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
				strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strAltID = util.checkAlternateHasAccess(context,objectMap);	
				String strAltType =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
				strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strNet =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_VALUE);
				//Commented by Ketan for Req. no. 47950
				/*if(null!=strNet && strNetWet.isEmpty() || strNet.equalsIgnoreCase("0.0")) {
					strNet="0";
				}*/
				String strOSPD =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY_BOM);
				
				String strDenUOM =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
				String strCertifications =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS);
				//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 29, 2021 for Defect# 41724-- START
				if(ConstantsUtil.TYPE_RAWMATERIALPART.equalsIgnoreCase(sPType) || ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART.equalsIgnoreCase(sPType)){
					DomainObject dObj = DomainObject.newInstance(context,sPId);
					String strCertificationConnected = dObj.getInfo(context, "from[" + ConstantsUtil.REL_PG_PLI_MATERIAL_CERTIFICATIONS + "].to.id");
					if(UIUtil.isNotNullAndNotEmpty(strCertificationConnected)) {
						strCertifications = ConstantsUtil.SYMBL_YES;
					}else {
						strCertifications = ConstantsUtil.SYMBL_NO;
					}
				}
				String strSubPart = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
				strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
				String strSubPartId = util.checkSubstituteHasAccess(context,objectMap);

				String sRF = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STRPGPDTTOPGPLIREFUN));
				String strClassFied = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));
				//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
				String sEBOMParentId =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_ID);
				String sEBOMParentName =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_NAME);
				String sEBOMParentRevision =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_REV);
				String sEBOMParentType =(String)objectMap.get(ConstantsUtilIRM.SELECT_EBOM_TYPE);
				//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
				
				// Added by Jwala for the req 41754 22x Template Fix -- START
				String strGrossWeightReal = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL));
				String strGrossWeightUOM = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE));
				String strManufacturingStatus = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_PGLIFECYCLE_STATUS));
				//Added by Subhajit for Req 46464 - Start
				//String strMaterialRestriction  = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION));
				//String strMRComments = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALRESTRICTIONCOMMENTS));
				String sRelRestriction  = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
				String sRelRestrictionComment = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
				// Added by Jwala for the req 41754 22x Template Fix -- START
				//Added by Subhajit for Req 46464 - End
				boolean showData = true;
				boolean bHasOwnership = false;
				if(util.isModificatinRequired())
				{
					bHasOwnership = util.checkHasAccess(context, null, sPId);

					if(!bHasOwnership)
					{
						spgChg = ConstantsUtil.NO_ACCESS;
						sPId = ConstantsUtil.NO_ACCESS;
						
					}
				}else if(sec.isStaffAUGUser())
				{
					showData = util.checkHasAccess(context, null, sPId);
				}else
				{	
					showData = util.checkHasAccess(context, null, sPId);
				}


				if(!showData){
					spgChg = ConstantsUtil.NO_ACCESS;
					sPId = ConstantsUtil.NO_ACCESS;
				}
				
				//Added by Ketan for Internal Defect -- START
				boolean bHasOwnershipParent = false;
				boolean showDataParent = false;
				if(validator.isNotNullOrEmpty(sParentId)) {
					if(util.isModificatinRequired())
					{
						bHasOwnershipParent = util.checkHasAccess(context, null, sParentId);

						if(!bHasOwnershipParent)
						{
							sParentId = ConstantsUtil.NO_ACCESS;
						}
					}else if(sec.isStaffAUGUser())
					{
						showDataParent = util.checkHasAccess(context, null, sParentId);
					}else
					{	
						showDataParent = util.checkHasAccess(context, null, sParentId);
					}

					if(!util.isModificatinRequired()) {
						if(!showDataParent){
							sParentId = ConstantsUtil.NO_ACCESS;
						}
					}
					
				}
				//Added by Ketan for Internal Defect -- END

				sPType = util.mapType(sPType);
				sEBOMParentType = util.mapType(sEBOMParentType);
				//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
				mlPhaseEBOMList.add(objectMap);
				if(!sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1) {
					util.formatData(sbFEBOMType,sPType);
					util.formatData(sbFEBOMName,sName);
					util.formatData(sbFEBOMRev,sRevision);
					util.formatData(sbFEBOMQTY,sQty);
					util.formatData(sbFEBOMBuom,sBuom);
					util.formatData(sbFEBOMState,sCurrent);

					util.formatData(sbFEBOMId,sPId);
					util.formatData(sbFEBOMChg,spgChg);
					util.formatData(sbFEBOMFN,sFN);
					util.formatData(sbFEBOMTitle,sTitle);
					util.formatData(sbFEBOMCommnts,sComments);
					util.formatData(sbFEBOMStage,sStage);
					util.formatData(sbFEBOMRDOC,sRDOC);
					util.formatData(sbFEBOMRevRelDt,sRevRelease);
					util.formatData(sbFMinqty,strMinqty);
					util.formatData(sbFMaxqty,strMaxqty);
					util.formatData(sbFNetWUOM,strNetWUOM);
					util.formatData(sbFNetWet,strNetWet);
					util.formatData(sbFLoss,strLoss);
					util.formatData(sbFMF,strMF);
					util.formatData(sbFGW,strGW);
					util.formatData(sbFAltName,strAltName);
					util.formatData(sbFAltID,strAltID);
					util.formatData(sbFAltType,strAltType);
					util.formatData(sbFNet,strNet);
					util.formatData(sbFOSPD,strOSPD);
					util.formatData(sbFDen,strDenUOM);
					util.formatData(sbFCerti,strCertifications);
					util.formatData(sbFEBOMSubstitutePart, strSubPart);
					util.formatData(sbFEBOMSubPartID, strSubPartId);
					util.formatData(sbFEBOMSubPartType, strSubPartType);
					util.formatData(sbFRF,sRF);
					// Added by Jwala for the req 41754 22x Template Fix -- START
					util.formatData(sbGrossWeightReal, strGrossWeightReal);
					util.formatData(sbGrossWeightUOM, strGrossWeightUOM);
					util.formatData(sbManufacturingStatus, strManufacturingStatus);
					//Added by Subhajit for Req 46464 - Start
					//util.formatData(sbMaterialRestriction, strMaterialRestriction);
					//util.formatData(sbMRComments, strMRComments);
					util.formatData(sbRelRestriction, sRelRestriction);
					util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
					//Added by Subhajit for Req 46464 - End
					// Added by Jwala for the req 41754 22x Template Fix -- END
					//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
					util.formatData(sbEBOMParentId,sEBOMParentId);
					util.formatData(sbEBOMParentName,sEBOMParentName);
					util.formatData(sbEBOMParentRevision,sEBOMParentRevision);
					util.formatData(sbEBOMParentType,sEBOMParentType);
					//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
					if(null!=sTupName && !sTupName.isEmpty()) {
						util.formatData(sbFEBOMTupName,sTupName);
					}

					if(!mlPhaseEBOMList.isEmpty()) {
						mlEBOMSubList.addAll(mlPhaseEBOMList);
					}

				} else {
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS
					// Security req -33193 HIR Components Attributes to Show
					util.formatData(sbEBOMType,sPType);
					util.formatData(sbEBOMName,sName);
					util.formatData(sbEBOMRev,sRevision);
					util.formatData(sbEBOMQTY,sQty);
					util.formatData(sbEBOMBuom,sBuom);
					util.formatData(sbEBOMState,sCurrent);

					util.formatData(sbEBOMId,sPId);
					util.formatData(sbEBOMChg,spgChg);
					util.formatData(sbEBOMFN,sFN);
					util.formatData(sbEBOMTitle,sTitle);
					util.formatData(sbEBOMCommnts,sComments);
					util.formatData(sbEBOMStage,sStage);
					util.formatData(sbEBOMRDOC,sRDOC);
					util.formatData(sbEBOMRevRelDt,sRevRelease);
					util.formatData(sbMinqty,strMinqty);
					util.formatData(sbMaxqty,strMaxqty);
					util.formatData(sbNetWUOM,strNetWUOM);
					util.formatData(sbNetWet,strNetWet);
					util.formatData(sbLoss,strLoss);
					util.formatData(sbMF,strMF);
					util.formatData(sbGW,strGW);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//util.formatData(sbAlt,strAlt);
					util.formatData(sbAltName,strAltName);
					util.formatData(sbAltID,strAltID);
					util.formatData(sbAltType,strAltType);
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					util.formatData(sbNet,strNet);
					util.formatData(sbOSPD,strOSPD);
					util.formatData(sbDen,strDenUOM);
					util.formatData(sbCerti,strCertifications);

					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
					util.formatData(sbEBOMSubstitutePart, strSubPart);
					util.formatData(sbEBOMSubPartID, strSubPartId);
					util.formatData(sbEBOMSubPartType, strSubPartType);
					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
					
					// Added by Jwala for the req 41754 22x Template Fix -- START
					util.formatData(sbGrossWeightReal, strGrossWeightReal);
					util.formatData(sbGrossWeightUOM, strGrossWeightUOM);
					util.formatData(sbManufacturingStatus, strManufacturingStatus);
					//Added by Subhajit for Req 46464 - Start
					//util.formatData(sbMaterialRestriction, strMaterialRestriction);
					//util.formatData(sbMRComments, strMRComments);
					util.formatData(sbRelRestriction, sRelRestriction);
					util.formatData(sbRelRestrictionComment, sRelRestrictionComment);
					//Added by Subhajit for Req 46464 - End
					// Added by Jwala for the req 41754 22x Template Fix -- END
					//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
					util.formatData(sbEBOMParentId,sEBOMParentId);
					util.formatData(sbEBOMParentName,sEBOMParentName);
					util.formatData(sbEBOMParentRevision,sEBOMParentRevision);
					util.formatData(sbEBOMParentType,sEBOMParentType);
					//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
					util.formatData(sbRF,sRF);

					if(null!=sTupName && !sTupName.isEmpty()) {
						util.formatData(sbEBOMTupName,sTupName);
					}
					//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
				}
				//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --ENDS

				//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
				int j = 0;
				int iNextLevel = 0;
				Map objectMaps =null;
				//SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --START
				//if(sPType.equals(ConstantsUtil.TYPE_PGPHASE) || iParentLevel == 1){
				if(sPType.equals(ConstantsUtil.TYPE_PGPHASE)){
					sParentId=sFormulaPropagate;
					//SPEC: <02.02.2021>: Modified for Defect: 38357 by Sumit --ENDS

					for(j =i+1; j<mapList.size(); j++)
					{
						iNextLevel = 0;
						objectMaps = (Map) mapList.get(j);
						int iCurrLevel = Integer.parseInt((String) objectMaps.get(ConstantsUtil.SELECT_LEVEL));
						if(j < mapList.size()-1) {
							Map objectNxtMaps = (Map) mapList.get(j+1);
							iNextLevel = Integer.parseInt((String) objectNxtMaps.get(ConstantsUtil.SELECT_LEVEL));
						}
						if((iParentLevel+1 == iCurrLevel) && sPType.equals(ConstantsUtil.TYPE_PGPHASE)) {

							mlPhaseEBOMList.add(objectMaps);
							String sId =(String)objectMaps.get(ConstantsUtil.SELECT_ID);
							sName =(String)objectMaps.get(ConstantsUtil.SELECT_NAME);
							sRevision =(String)objectMaps.get(ConstantsUtil.SELECT_REVISION);
							sReleaseDate =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
							sRevRelease = sRevision+ConstantsUtil.SYMBL_COLON+sReleaseDate;
							spgChg =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
							sFN =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
							sTitle =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							String sType =(String)objectMaps.get(ConstantsUtil.SELECT_TYPE);
							sTupName =(String)objectMaps.get(ConstantsUtil.TUPNAME);
							sQty =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
							sBuom =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
							sComments=(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
							sCurrent =(String)objectMaps.get(ConstantsUtil.SELECT_CURRENT);
							if(null!=sCurrent && sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {

								sCurrent=ConstantsUtil.RELEASED;
							}
							sStage =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
							sRD =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
							sRD = sRD.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
							sOC =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
							sOC = sOC.replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO).replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES);
							sRDOC = sRD+ConstantsUtil.SYMBL_COLON+sOC;
							strMinqty =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
							strMaxqty =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
							strNetWUOM =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTUNITOFMEASURE);
							strNetWet =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHT);
							/*if(null!=strNetWet && strNetWet.isEmpty() || strNetWet.equalsIgnoreCase("0.0")) {

								strNetWet="0";
							}*/
							strLoss =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS_VALUE);
							/*if(null!=strLoss && strNetWet.isEmpty() || strLoss.equalsIgnoreCase("0.0")) {
								strLoss="0";
							}*/
							//SPEC: 08-08-2022: Pooja Added for Internal Defect -- START
							strMF =ConstantsUtil.EMPTY_STRING;
						    strMFObjId =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);

							try
							{
								if (UIUtil.isNotNullAndNotEmpty(strMFObjId)) 
								{
									strMF=util.getIdFromPhysicalIdFunction(context,strMFObjId);
								}
							}catch(Exception e){
								strMF=ConstantsUtil.EMPTY_STRING;
							}
							//SPEC: 08-08-2022: Pooja Added for Internal Defect -- END
							strGW =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHT);
							strAltName =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_NAME));
							strAltName=strAltName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strAltID = util.checkAlternateHasAccess(context,objectMaps);	
							strAltType =validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.RELATIONSHIP_ALTERNATE_SELECT_TYPE));
							strAltType=strAltType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strNet =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TOTAL_VALUE);
							/*if(null!=strNet && strNetWet.isEmpty() || strNet.equalsIgnoreCase("0.0")) {
								strNet="0";
							}*/
							strOSPD =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY);
							strDenUOM =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM);
							strCertifications =(String)objectMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS);
							//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 29, 2021 for Defect# 41724-- START
							if(ConstantsUtil.TYPE_RAWMATERIALPART.equalsIgnoreCase(sType) || ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART.equalsIgnoreCase(sType)){
								DomainObject dObj = DomainObject.newInstance(context,sId);
								String strCertificationConnected = dObj.getInfo(context, "from[" + ConstantsUtil.REL_PG_PLI_MATERIAL_CERTIFICATIONS + "].to.id");
								if(UIUtil.isNotNullAndNotEmpty(strCertificationConnected)) {
									strCertifications = ConstantsUtil.SYMBL_YES;
								}else {
									strCertifications = ConstantsUtil.SYMBL_NO;
								}
							}
							//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 29, 2021 for Defect# 41724-- END
							strSubPart = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							strSubPart=strSubPart.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMaps.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							strSubPartType=strSubPartType.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);
							strSubPartId = util.checkSubstituteHasAccess(context,objectMaps);

							sRF = validator.getStringEquivalentForStringList(objectMaps.get(ConstantsUtil.STRPGPDTTOPGPLIREFUN));
							strClassFied = validator.getStringEquivalentForStringList((objectMaps.get(ConstantsUtil.STR_IPCLASS)));
							
							showData = true;
							bHasOwnership = false;
							if(util.isModificatinRequired())
							{
								bHasOwnership = util.checkHasAccess(context, null, sId);

								if(!bHasOwnership)
								{
									spgChg = ConstantsUtil.NO_ACCESS;
									sId = ConstantsUtil.NO_ACCESS;
								}
							}else if(sec.isStaffAUGUser())
							{
								showData = util.checkHasAccess(context, null, sId);

							}else
							{	
								showData = util.checkHasAccess(context, null, sId);
							}


							if(!showData){
								spgChg = ConstantsUtil.NO_ACCESS;
								sId = ConstantsUtil.NO_ACCESS;
							}

							sType = util.mapType(sType);

							util.formatData(sbEBOMType,sType);
							util.formatData(sbEBOMName,sName);
							util.formatData(sbEBOMRev,sRevision);
							util.formatData(sbEBOMQTY,sQty);
							util.formatData(sbEBOMBuom,sBuom);
							util.formatData(sbEBOMState,sCurrent);

							util.formatData(sbEBOMId,sId);
							util.formatData(sbEBOMChg,spgChg);
							util.formatData(sbEBOMFN,sFN);
							util.formatData(sbEBOMTitle,sTitle);
							util.formatData(sbEBOMCommnts,sComments);
							util.formatData(sbEBOMStage,sStage);
							util.formatData(sbEBOMRDOC,sRDOC);
							util.formatData(sbEBOMRevRelDt,sRevRelease);
							util.formatData(sbMinqty,strMinqty);
							util.formatData(sbMaxqty,strMaxqty);
							util.formatData(sbNetWUOM,strNetWUOM);
							util.formatData(sbNetWet,strNetWet);
							util.formatData(sbLoss,strLoss);
							util.formatData(sbMF,strMF);
							util.formatData(sbGW,strGW);
							util.formatData(sbAltName,strAltName);
							util.formatData(sbAltID,strAltID);
							util.formatData(sbAltType,strAltType);
							util.formatData(sbNet,strNet);
							util.formatData(sbOSPD,strOSPD);
							util.formatData(sbDen,strDenUOM);
							util.formatData(sbCerti,strCertifications);

							util.formatData(sbEBOMSubstitutePart, strSubPart);
							util.formatData(sbEBOMSubPartID, strSubPartId);
							util.formatData(sbEBOMSubPartType, strSubPartType);
							util.formatData(sbRF,sRF);

							if(null!=sTupName && !sTupName.isEmpty()) {
								util.formatData(sbEBOMTupName,sTupName);
							}
						}
						if(iParentLevel+1 > iNextLevel || iParentLevel == iCurrLevel) {
							break;
						} 		
					}
					
					mpEBOMResult.put(ConstantsUtil.ID, sbEBOMId.toString());
					mpEBOMResult.put(ConstantsUtil.NAME, sbEBOMName.toString());
					mpEBOMResult.put(ConstantsUtil.REVISION, sbEBOMRev.toString());
					mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
					mpEBOMResult.put(ConstantsUtil.FN, sbEBOMFN.toString());
					mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMTitle.toString());
					mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
					mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
					mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
					mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
					mpEBOMResult.put(ConstantsUtil.STATE, sbEBOMState.toString());
					mpEBOMResult.put(ConstantsUtil.PHASE, sbEBOMStage.toString());
					mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbEBOMRDOC.toString());
					mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
					mpEBOMResult.put(ConstantsUtil.MIN, sbMinqty.toString());
					mpEBOMResult.put(ConstantsUtil.MAX, sbMaxqty.toString());
					mpEBOMResult.put(ConstantsUtil.NETWEIGHTUOM, sbNetWUOM.toString());
					mpEBOMResult.put(ConstantsUtil.NETWEIGHT, sbNetWet.toString());
					mpEBOMResult.put(ConstantsUtil.LOSS, sbLoss.toString());
					//mpEBOMResult.put(ConstantsUtil.MATERIALFUNCTION, sbMF.toString());
					mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbMF.toString());
					mpEBOMResult.put(ConstantsUtil.GW, sbGW.toString());
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - START
					//mpEBOMResult.put(ConstantsUtil.ALT, sbAlt.toString());
					mpEBOMResult.put(ConstantsUtil.ALTNAME, sbAltName.toString());
					mpEBOMResult.put(ConstantsUtil.ALTID, sbAltID.toString());
					mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbAltType.toString());
					// SPEC: <12.29.2020>: Govind Modified for Requirement :36391 - END
					mpEBOMResult.put(ConstantsUtil.NET, sbNet.toString());
					mpEBOMResult.put(ConstantsUtil.OSPD, sbOSPD.toString());
					mpEBOMResult.put(ConstantsUtil.DUOM, sbDen.toString());
					mpEBOMResult.put(ConstantsUtil.CERTIFICATION, sbCerti.toString());
					mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbRF.toString());

					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- START
					mpEBOMResult.put(ConstantsUtil.SP, sbEBOMSubstitutePart.toString());
					mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMSubPartType.toString());
					mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMSubPartID.toString());
					//SPEC: <10.13.2020>: Added for req 18x.5 ## -- END
					// Added by Jwala for the req 41754 22x Template Fix -- START
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
					mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
					mpEBOMResult.put(ConstantsUtil.MANUFACTURINGSTATUS, sbManufacturingStatus.toString());
					//Added by Subhajit for Req 46464 - Start
					//mpEBOMResult.put(ConstantsUtil.MATERIALRESTRICTION, sbMaterialRestriction.toString());
					//mpEBOMResult.put(ConstantsUtil.MATERIALRESTRICTIONCOMMENTS, sbMRComments.toString());
					mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
					mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
					//Added by Subhajit for Req 46464 - End
					// Added by Jwala for the req 41754 22x Template Fix -- END

					if (null != sbEBOMTupName && sbEBOMTupName.length()>0) {
						mpEBOMResult.put(ConstantsUtil.TUPNAME, sbEBOMTupName.toString());
					}
					//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --START
				}
				//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --START
				if(!mpEBOMResult.isEmpty() && validator.isNotNullOrEmpty(sParentId) && (!slParentId.contains(sParentId) || (slParentId.contains(sParentId) && !sPType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPHASE) && iParentLevel == 1))) {
					//SPEC: <01.27.2021>: Modified for Defect :38356 by Sumit --ENDS
					slParentId.add(sParentId);
					mpFinalEBOM.put(String.valueOf(index), mpEBOMResult);
					//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --START
					if(!mlPhaseEBOMList.isEmpty()) {
						//mpFinalSubstitute.put(String.valueOf(index), mpSubstituteResult);
						mlEBOMSubList.addAll(mlPhaseEBOMList);
					}
					//SPEC: <02.02.2021>: Modified for Defect: 38367 by Sumit --ENDS
					index++;
				}
			}

			//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
			mpEBOMResult = new HashMap();
			if(null != sbFEBOMId && sbFEBOMId.length()>0) {
				mpEBOMResult.put(ConstantsUtil.ID, sbFEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.NAME, sbFEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.REVISION, sbFEBOMRev.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbFEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.FN, sbFEBOMFN.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbFEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbFEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbFEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbFEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbFEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.STATE, sbFEBOMState.toString());
				mpEBOMResult.put(ConstantsUtil.PHASE, sbFEBOMStage.toString());
				mpEBOMResult.put(ConstantsUtil.REFDESRDOPTIONALCOMPONENTSOC, sbFEBOMRDOC.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbFEBOMRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.MIN, sbFMinqty.toString());
				mpEBOMResult.put(ConstantsUtil.MAX, sbFMaxqty.toString());
				mpEBOMResult.put(ConstantsUtil.NETWEIGHTUOM, sbFNetWUOM.toString());
				mpEBOMResult.put(ConstantsUtil.NETWEIGHT, sbFNetWet.toString());
				mpEBOMResult.put(ConstantsUtil.LOSS, sbFLoss.toString());
				mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbFMF.toString());
				mpEBOMResult.put(ConstantsUtil.GW, sbFGW.toString());
				mpEBOMResult.put(ConstantsUtil.ALTNAME, sbFAltName.toString());
				mpEBOMResult.put(ConstantsUtil.ALTID, sbFAltID.toString());
				mpEBOMResult.put(ConstantsUtil.ALTTYPE, sbFAltType.toString());
				mpEBOMResult.put(ConstantsUtil.NET, sbFNet.toString());
				mpEBOMResult.put(ConstantsUtil.OSPD, sbFOSPD.toString());
				mpEBOMResult.put(ConstantsUtil.DUOM, sbFDen.toString());
				mpEBOMResult.put(ConstantsUtil.CERTIFICATION, sbFCerti.toString());
				mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbFRF.toString());
				mpEBOMResult.put(ConstantsUtil.SP, sbFEBOMSubstitutePart.toString());
				mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbFEBOMSubPartType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbFEBOMSubPartID.toString());
				// Added by Jwala for the req 41754 22x Template Fix -- START
				mpEBOMResult.put(ConstantsUtil.GROSSWEIGHT, sbGrossWeightReal.toString());
				mpEBOMResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, sbGrossWeightUOM.toString());
				mpEBOMResult.put(ConstantsUtil.MANUFACTURINGSTATUS, sbManufacturingStatus.toString());
				//Added by Subhajit for Req 46464 - Start
				//mpEBOMResult.put(ConstantsUtil.MATERIALRESTRICTION, sbMaterialRestriction.toString());
				//mpEBOMResult.put(ConstantsUtil.MATERIALRESTRICTIONCOMMENTS, sbMRComments.toString());
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbRelRestriction.toString());
				mpEBOMResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbRelRestrictionComment.toString());
				//Added by Subhajit for Req 46464 - End
				// Added by Jwala for the req 41754 22x Template Fix -- END
				//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- START
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_ID, sbEBOMParentId.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_NAME, sbEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_REVISION, sbEBOMParentRevision.toString());
				mpEBOMResult.put(ConstantsUtilIRM.PARENT_TYPE, sbEBOMParentType.toString());
				//SPEC: <18.11.2022>: Ketan Added for Req 45642 -- END
				if (null != sbFEBOMTupName && sbFEBOMTupName.length()>0) {
					mpEBOMResult.put(ConstantsUtil.TUPNAME, sbFEBOMTupName.toString());
				}
				
				//Added by Ketan for Req. no. 46464 -- START
				if(bSupplierView) {
					mpEBOMResult.remove(ConstantsUtil.MANUFACTURINGSTATUS);
					mpEBOMResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTION);
					mpEBOMResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS);
				}
				//Added by Ketan for Req. no. 46464 -- END
				
				if(!mpEBOMResult.isEmpty()) {
					mpFinalEBOM.put(String.valueOf(0), mpEBOMResult);
				}
			}
			mpSubstituteResult = APPBO.parseSubstitute(context,mlEBOMSubList, false);
			
			//Added by Ketan for Req. no. 46464 -- START
			if(bSupplierView) {
				mpSubstituteResult.remove(ConstantsUtil.MANUFACTURINGSTATUS);
				mpSubstituteResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTION);
				mpSubstituteResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS);
			}
			//Added by Ketan for Req. no. 46464 -- END
			
			if(!mpSubstituteResult.isEmpty()) {
				HashMap mpSubstitute = new HashMap();
				mpSubstitute.put(String.valueOf(0), mpSubstituteResult);
				mpFinalSubstitute.put(String.valueOf(0), mpSubstitute);
			}
			//SPEC: <02.02.2021>: Added for Defect: 38357 by Sumit --START
			MPFinalEBOMSubStitute.put(ConstantsUtil.BILLOFMATERIALS, mpFinalEBOM);
			MPFinalEBOMSubStitute.put(ConstantsUtil.SUBSTITUTEPARTS, mpFinalSubstitute);

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception in DPPBO:  parseMaplist: " + e);
		}
		return MPFinalEBOMSubStitute;
		//return util.filterMapList(mpEBOMResult);
		//SPEC: <12.30.2020>: Added for Req :36032 by Sumit #(BOM Expansion)# --ENDS
	}


	/**
	 * Method Name 			: formatData
	 * Method Description 	: 
	 * @param slData
	 * @param sData
	 */
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}


	/**
	 * Method Name 			: getSubstitute
	 * Method Description 	: 
	 * @param context
	 * @param mapList
	 * @return
	 */
	public Map<String, String> getSubstitute(Context context,MapList mapList) 
	{

		StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Iterator objectListItr = mapList.iterator();

		StringBuilder sbEBOMName = new StringBuilder();
		StringBuilder sbEBOMParentName = new StringBuilder();
		StringBuilder sbEBOMParentRev = new StringBuilder();
		StringBuilder sbEBOMParentTitle = new StringBuilder();
		StringBuilder sbEBOMId = new StringBuilder();
		StringBuilder sbEBOMParentId = new StringBuilder();
		StringBuilder sbEBOMRefDoc= new StringBuilder();
		StringBuilder sbEBOMTitle = new StringBuilder();
		StringBuilder sbEBOMType = new StringBuilder();
		StringBuilder sbEBOMQTY = new StringBuilder();
		StringBuilder sbEBOMBuom = new StringBuilder();
		StringBuilder sbEBOMCommnts = new StringBuilder();
		StringBuilder sbEBOMSubType= new StringBuilder();
		StringBuilder sbEBOMEffectDate= new StringBuilder();
		StringBuilder sbEBOMUntilDate= new StringBuilder();
		StringBuilder sbEBOMCobNum= new StringBuilder();
		StringBuilder sbEBOMChildRev= new StringBuilder();
		StringBuilder sbEBOMRevRelDt= new StringBuilder();
		StringBuilder sbEBOMSubFor= new StringBuilder();
		StringBuilder sbEBOMParentType = new StringBuilder();
		StringBuilder sbCerti= new StringBuilder();
		StringBuilder sbMF= new StringBuilder();

		while(objectListItr.hasNext())
		{
			Map objectMap = (Map) objectListItr.next();

			String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
			if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
				String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
				String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));
				String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
				String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));

				String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
				String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
				String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
				String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
				String strCertifications =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CERTIFICATIONS));
				//SPEC: 08-08-2022: Pooja Added for Internal Defect -- START
				String strMF =ConstantsUtil.EMPTY_STRING;
				String strMFObjId =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);

				try
				{
					if (UIUtil.isNotNullAndNotEmpty(strMFObjId)) 
					{
						strMF=util.getIdFromPhysicalIdFunction(context,strMFObjId);
					}
				}catch(Exception e){
					strMF=ConstantsUtil.EMPTY_STRING;
				}
				//SPEC: 08-08-2022: Pooja Added for Internal Defect -- END
				//Modified for Defect# 37591 -- START
				//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
				String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
				//Modified for Defect# 37591 -- END

				String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
				String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
				String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
				String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
				String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
				String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
				String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
				sOC = util.replaceSpecialSymbols(sOC);
				String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;

				if(util.isModificatinRequired())
				{
					//commented by Ganesh for security impl---->start
					/*SecurityService sec = new SecurityService();
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);

					boolean bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sChildId);
					 */
					//commented by Ganesh for security impl---->end
					//modified by Ganesh for security impl ---->start
					boolean bHasOwnership = util.checkHasAccess(context, null, sChildId);
					//modified by Ganesh for security impl ---->end
					if(!bHasOwnership)
					{
						sParentType = ConstantsUtil.NO_ACCESS;
						sParentID = ConstantsUtil.NO_ACCESS;
						sChildId    = ConstantsUtil.NO_ACCESS;
						sParentName = ConstantsUtil.NO_ACCESS;
						sParentRev = ConstantsUtil.NO_ACCESS;
						sParentTitle = ConstantsUtil.NO_ACCESS;
						sCombinationNum = ConstantsUtil.NO_ACCESS;
						sChildTitle = ConstantsUtil.NO_ACCESS;
						sSUBType = ConstantsUtil.NO_ACCESS;
						sEffectvityDate = ConstantsUtil.NO_ACCESS;
						sRevRelease = ConstantsUtil.NO_ACCESS;
						sUntilDate = ConstantsUtil.NO_ACCESS;
						sRDOC = ConstantsUtil.NO_ACCESS;
						sQTY = ConstantsUtil.NO_ACCESS;
						sBASEUOM = ConstantsUtil.NO_ACCESS;
						sChildRev = ConstantsUtil.NO_ACCESS;


					}
				}
				//commented by Ganesh for security impl ----start
				/*StringList slHIRTypes = new StringList();

				slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
				slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

				if(slHIRTypes.contains(sChildType)){
					sParentType = ConstantsUtil.NO_ACCESS;
					sParentID = ConstantsUtil.NO_ACCESS;
					sChildId    = ConstantsUtil.NO_ACCESS;
					sParentName = ConstantsUtil.NO_ACCESS;
					sParentRev = ConstantsUtil.NO_ACCESS;
					sParentTitle = ConstantsUtil.NO_ACCESS;
					sCombinationNum = ConstantsUtil.NO_ACCESS;
					sChildTitle = ConstantsUtil.NO_ACCESS;
					sSUBType = ConstantsUtil.NO_ACCESS;
					sEffectvityDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sUntilDate = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;
				}*/
				//commented by Ganesh for security impl ----end
				//modified by Ganesh for security impl ----start
				boolean showData = util.checkHasAccess(context, null, sChildId);
				if(!showData) {
					sParentType = ConstantsUtil.NO_ACCESS;
					sParentID = ConstantsUtil.NO_ACCESS;
					sChildId    = ConstantsUtil.NO_ACCESS;
					sParentName = ConstantsUtil.NO_ACCESS;
					sParentRev = ConstantsUtil.NO_ACCESS;
					sParentTitle = ConstantsUtil.NO_ACCESS;
					sCombinationNum = ConstantsUtil.NO_ACCESS;
					sChildTitle = ConstantsUtil.NO_ACCESS;
					sSUBType = ConstantsUtil.NO_ACCESS;
					sEffectvityDate = ConstantsUtil.NO_ACCESS;
					sRevRelease = ConstantsUtil.NO_ACCESS;
					sUntilDate = ConstantsUtil.NO_ACCESS;
					sRDOC = ConstantsUtil.NO_ACCESS;
					sComments = ConstantsUtil.NO_ACCESS;	
				}
				//modified by Ganesh for security impl ----start
				sChildType = util.mapType(sChildType);

				formatData(sbEBOMName,sChildName);
				formatData(sbEBOMType,sChildType);
				formatData(sbEBOMQTY,sQTY);
				formatData(sbEBOMBuom,sBASEUOM);
				formatData(sbEBOMChildRev,sChildRev);

				formatData(sbEBOMParentType,sParentType);
				formatData(sbEBOMParentId,sParentID);
				formatData(sbEBOMId,sChildId);
				formatData(sbEBOMParentName,sParentName);
				formatData(sbEBOMParentRev,sParentRev);
				formatData(sbEBOMParentTitle,sParentTitle);
				formatData(sbEBOMCobNum,sCombinationNum);
				formatData(sbEBOMTitle,sChildTitle);
				formatData(sbEBOMSubType,sSUBType);
				formatData(sbEBOMRevRelDt,sRevRelease);
				formatData(sbEBOMEffectDate,sEffectvityDate);
				formatData(sbEBOMUntilDate,sUntilDate);
				formatData(sbEBOMRefDoc,sRDOC);
				formatData(sbEBOMCommnts,sComments);
				formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
				formatData(sbCerti,strCertifications);
				formatData(sbMF,strMF);
			}
		}
		mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
		mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
		mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
		mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
		mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
		mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
		mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
		mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
		mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
		mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
		mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
		mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
		mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
		mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
		mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
		mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
		mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
		mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
		mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
		mpEBOMResult.put(ConstantsUtil.CERTIFICATION, sbCerti.toString());
		mpEBOMResult.put(ConstantsUtil.MATERIALFUNCTION, sbMF.toString());

		return util.filterMapList(mpEBOMResult);
	}


	/**
	 * Method Name 			: addMultiList
	 * Method Description 	: 
	 */
	public StringList addMultiList() { 
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_ACTIVATED);
		
		slMultiSelects.add(ConstantsUtil.COMP_TYPE); 
		slMultiSelects.add(ConstantsUtil.COMP_NAME);  
		slMultiSelects.add(ConstantsUtil.COMP_ID);  
		slMultiSelects.add(ConstantsUtil.COMP_REVS);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC); 
		slMultiSelects.add(ConstantsUtil.COMP_TITLE); 
		slMultiSelects.add(ConstantsUtil.COMP_STATE);
		slMultiSelects.add(ConstantsUtil.COMP_PHASE); 
		slMultiSelects.add(ConstantsUtil.COMP_CASNUM);  		
		slMultiSelects.add(ConstantsUtil.COMP_SUBNAME);  		
		slMultiSelects.add(ConstantsUtil.COMP_ISCONTAM);  		
		slMultiSelects.add(ConstantsUtil.COMP_QTY);  			
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);
		slMultiSelects.add(ConstantsUtil.COMP_FUNCTIONS);
		slMultiSelects.add(ConstantsUtil.COMP_DRYWEIGHT);
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);  		

		slMultiSelects.add(ConstantsUtil.SELECT_COS_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);

		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_NAME); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_CT_NUM); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS); 	
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_MANU_SITE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PACK_SITE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PLANT_REST); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REG_DATE); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_REG_STATUS); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM); 
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE);
		slMultiSelects.add(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY);


		slMultiSelects.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		slMultiSelects.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);

		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS);
		slMultiSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE);


		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		slMultiSelects.add(ConstantsUtil.strIntendedMarket);
		slMultiSelects.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);

		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS);

		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slMultiSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);

		return slMultiSelects;

	}
	/**
	 * 
	 * @param context
	 * @param resultMaps
	 * @return
	 */

	public Map getDangerousProdcutValue(Context context,Map resultMaps)
	{
		Map mpDangerousProdcut = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();	
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		//StringBuilder sbName = new StringBuilder();
		//StringBuilder sbRev = new StringBuilder();
		//StringBuilder sbTitle = new StringBuilder();
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END


		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();

		String strRev = ConstantsUtil.EMPTY_STRING;
		String strName = ConstantsUtil.EMPTY_STRING;
		String strTitle = ConstantsUtil.EMPTY_STRING;
		String strId = ConstantsUtil.EMPTY_STRING;
		String strTyp = ConstantsUtil.EMPTY_STRING;
		String strState = ConstantsUtil.EMPTY_STRING;
		String strPhase = ConstantsUtil.EMPTY_STRING;

		StringBuilder sbDGD = new StringBuilder();
		StringBuilder sbUNN = new StringBuilder();
		StringBuilder sbPSN = new StringBuilder();
		StringBuilder sbHC = new StringBuilder();
		StringBuilder sbPgroup = new StringBuilder();
		StringBuilder sbShipqty = new StringBuilder();
		StringBuilder sbCON = new StringBuilder();
		StringBuilder sbOPR = new StringBuilder();
		StringBuilder sbUSPGreq = new StringBuilder();
		StringBuilder sbCust = new StringBuilder();
		StringBuilder sbGCUP = new StringBuilder();
		StringBuilder sbGCOP = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		StringBuilder sbTN1 = new StringBuilder();
		StringBuilder sbTN2 = new StringBuilder();
		StringBuilder sbNo = new StringBuilder();
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

		StringList slProductSelects = new StringList();
		slProductSelects.add(ConstantsUtil.SELECT_NAME);
		slProductSelects.add(ConstantsUtil.SELECT_TYPE);
		slProductSelects.add(ConstantsUtil.SELECT_CURRENT);
		slProductSelects.add(ConstantsUtil.SELECT_REVISION);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

		//SPEC: 10/29/2020: Added for 18x.5 DEV -- START

		slProductSelects.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
		SecurityService sct = new SecurityService();
		String sUserlicense = sct.getUserLicense();
		String sComp = sct.getUserCauthorities();
		StringList slUserOwnership=util.filterOwnerShip(sComp);


		StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);


		//SPEC: 10/29/2020: Added for 18x.5 DEV -- END

		StringList slHCPGSelects = new StringList();
		slHCPGSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC);
		slHCPGSelects.add(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP);

		String strIdsObjectId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID));

		StringList slsObjectId = FrameworkUtil.split(strIdsObjectId, ConstantsUtil.SYMBL_PIPE);
		try
		{
			for(String strID:slsObjectId){

				String sObjectId = strID.trim();

				if(UIUtil.isNotNullAndNotEmpty(sObjectId))
				{
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- START
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- END
					DomainObject doProductPart = new DomainObject(sObjectId);
					Map mpTemp = doProductPart.getInfo(context, slProductSelects);
					
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doProductPart.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END

					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
					//SPEC: 10/29/2020: Added for 18x.5 DEV -- END
					//strRev = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
					//strName = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
					//strTitle = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END

					strId = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ID));
					strTyp = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
					strState = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_CURRENT));
					strPhase = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

					//SPEC: 10/29/2020: Added for 18x.5 DEV -- START
					String sIpClass = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));

					boolean bHasOwnership =false;
					boolean showData =true;

					if(util.isModificatinRequired())
					{
						//bHasOwnership = util.checkOwnerShip(context, slUserOwnership, strId);
						//Added by Ganesh 1.0.2 Release Start
						bHasOwnership=util.checkHasAccess(context, null, strId);
						//Added by Ganesh 1.0.2 Release End
						if(!bHasOwnership)
						{
							strId = ConstantsUtil.NO_ACCESS;
						}
					}else if(sct.isStaffAUGUser()) 
					{
						/*if(strTyp.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || strTyp.equalsIgnoreCase("Formulation Part") ) {
							String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else {
							showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
						}*/
						//Added by Ganesh 1.0.2 Release Start
						showData=util.checkHasAccess(context, null, strId);
						//Added by Ganesh 1.0.2 Release End
					}else 
					{
						/*if(slHIRTypes.contains(strTyp)) 
						{
							if(strTyp.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)|| strTyp.equalsIgnoreCase("Formulation Part")) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}
						}else {
							showData=true;
						}*/
						//Added by Ganesh 1.0.2 Release Start
						showData=util.checkHasAccess(context, null, strId);
						//Added by Ganesh 1.0.2 Release End
					}

					if(!showData){
						strId = ConstantsUtil.NO_ACCESS;
					}

					//SPEC: 10/29/2020: Added for 18x.5 DEV -- END	
					
					//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- START
					//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
					/*if (!showData && util.isModificatinRequired()) {
					
						continue;
					}*/
					//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
					//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- END

					//formatData(sbName, strName);
					//formatData(sbRev, strRev);
					//formatData(sbTitle, strTitle);
					formatData(sbId, strId);
					formatData(sbType, strTyp);
					formatData(sbState, strState);
					formatData(sbPhase, strPhase);
				}
			}
			//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	

			/*	String strDGD = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP));
			String strUNN = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP));
			String strPSN = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP));
			String strShipqty = validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP));
			String strCON = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP));
			String strOPR = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP));
			String strUSPGreq = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP));
			String strCUST = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP));
			String strSDgcup = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP));
			String strSDgcop = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP));
			String strHC  = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP));
			String strPGGroup = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP));
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			String strTN1 = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP));
			String strTN2 = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP));
			String strNo = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP));*/

			//SPEC: Release SR18x.6.0 - Added for Defect#42817 by gaikwad.tg on Date 28 April 2021 -- START
			String strContextId = (String)resultMaps.get(ConstantsUtil.SELECT_ID);
			DomainObject dobDG = new DomainObject(strContextId);

			StringList slBusSelects = new StringList();
			slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPMENTLIMITEDQUANTITY);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERWEIGHTVOLUME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXCONSUMERUNITSIZE);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERWEIGHTVOLUME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCUPLABELREQUIRED);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCOPLABELREQUIRED);
			slBusSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_HAZARDCLASS);
			slBusSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_PACKINGGGROPUP);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME1);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME2);
			
			StringList slRelSelects = new StringList();
			slRelSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSEQNO);
			MapList mlDGDList = dobDG.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGDANGEROUSGOODSDPP,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobDG.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator objectListItr = mlDGDList.iterator();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String strDGD = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String strUNN = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER));
				String strPSN = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME));
				String strShipqty = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPMENTLIMITEDQUANTITY));
					
				if(strShipqty.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
					strShipqty = ConstantsUtil.SYMBL_CAPTRUE;
				}
				else if(strShipqty.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
					strShipqty = ConstantsUtil.SYMBL_CAPFALSE;
				}
				
				String strCON = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERWEIGHTVOLUME));
				String strOPR = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERPACKAGINGREQUIREMENTS));
				String strUSPGreq = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXCONSUMERUNITSIZE));
				String strCUST = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERWEIGHTVOLUME));
				String strSDgcup = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCUPLABELREQUIRED));
				String strSDgcop = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDGCOPLABELREQUIRED));
				String strHC  = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_HAZARDCLASS));
				String strPGGroup = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGDANGEROUSGOODS_PACKINGGGROPUP));
				String strTN1 = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME1));
				String strTN2 = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNICALNAME2));
				String strNo = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSEQNO));

			formatData(sbHC, strHC);
			formatData(sbPgroup, strPGGroup);
			formatData(sbDGD, strDGD);
			formatData(sbUNN, strUNN);
			formatData(sbPSN, strPSN);
			formatData(sbShipqty, strShipqty);
			formatData(sbCON, strCON);
			formatData(sbOPR, strOPR);
			formatData(sbUSPGreq, strUSPGreq);
			formatData(sbCust, strCUST);
			formatData(sbGCUP, strSDgcup);
			formatData(sbGCOP, strSDgcop);
			formatData(sbTN1, strTN1);
			formatData(sbTN2, strTN2);
			formatData(sbNo, strNo);
			}
			//SPEC: Release SR18x.6.0 - Added for Defect#42817 by gaikwad.tg on Date 28 April 2021 -- END
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//mpDangerousProdcut.put(ConstantsUtil.PPN, sbName.toString());
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			mpDangerousProdcut.put(ConstantsUtil.ID, sbId.toString());
			mpDangerousProdcut.put(ConstantsUtil.TYPE, sbType.toString());
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//mpDangerousProdcut.put(ConstantsUtil.PPR,sbRev.toString());
			//mpDangerousProdcut.put(ConstantsUtil.PPT,sbTitle.toString());
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			mpDangerousProdcut.put(ConstantsUtil.DGD,sbDGD.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNN,sbUNN.toString());
			mpDangerousProdcut.put(ConstantsUtil.PSN,sbPSN.toString());
			mpDangerousProdcut.put(ConstantsUtil.HC,sbHC.toString());
			mpDangerousProdcut.put(ConstantsUtil.PGGROUP,sbPgroup.toString());
			mpDangerousProdcut.put(ConstantsUtil.SHIPPINGQTY,sbShipqty.toString());
			mpDangerousProdcut.put(ConstantsUtil.CON,sbCON.toString());
			mpDangerousProdcut.put(ConstantsUtil.OPR,sbOPR.toString());
			mpDangerousProdcut.put(ConstantsUtil.UNSPECPACKGGREQUIRED,sbUSPGreq.toString());
			mpDangerousProdcut.put(ConstantsUtil.CUST,sbCust.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCUP,sbGCUP.toString());
			mpDangerousProdcut.put(ConstantsUtil.SDGCOP,sbGCOP.toString());
			mpDangerousProdcut.put(ConstantsUtil.PHASE,sbPhase.toString());
			mpDangerousProdcut.put(ConstantsUtil.STATE,sbState.toString());
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			mpDangerousProdcut.put(ConstantsUtil.TN1,sbTN1.toString());
			mpDangerousProdcut.put(ConstantsUtil.TN2,sbTN2.toString());
			mpDangerousProdcut.put(ConstantsUtil.NO,sbNo.toString());
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END



		}catch(Exception e){
			LOGGER.error("Error from DPPBO:  getDangerousProdcutValue"+e);
			return new HashMap();
		}
		return mpDangerousProdcut;
	}

	/**
	 * 
	 * @param context
	 * @param resultMaps
	 * @return
	 */

	public Map getGHSProdcutValue(Context context,Map resultMaps)
	{
		Map mpGlobalHarStandard = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
		/*StringBuilder sbName = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		*/
		//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbPhase = new StringBuilder();
		StringBuilder sbGName = new StringBuilder();
		StringBuilder sbGTitle = new StringBuilder();
		StringBuilder sbGRev = new StringBuilder();
		StringBuilder sbGDec = new StringBuilder();
		StringBuilder sbMarkets = new StringBuilder();
		StringBuilder sbLang = new StringBuilder();
		StringBuilder sbID = new StringBuilder();
		//StringBuilder sbGType = new StringBuilder();
		StringBuilder sbState = new StringBuilder();

		String strRev = ConstantsUtil.EMPTY_STRING;
		String strName = ConstantsUtil.EMPTY_STRING;
		String strTitle = ConstantsUtil.EMPTY_STRING;
		String strId = ConstantsUtil.EMPTY_STRING;
		String strState = ConstantsUtil.EMPTY_STRING;
		String strPhase = ConstantsUtil.EMPTY_STRING;
		String strType = ConstantsUtil.EMPTY_STRING;

		/*StringList slProductSelects = new StringList();
		slProductSelects.add(ConstantsUtil.SELECT_NAME);
		slProductSelects.add(ConstantsUtil.SELECT_TYPE);
		slProductSelects.add(ConstantsUtil.SELECT_REVISION);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slProductSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		slProductSelects.add(ConstantsUtil.SELECT_CURRENT);
		 */
		/*String strIdsObjectId = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID));

		StringList slsObjectId = FrameworkUtil.split(strIdsObjectId, ConstantsUtil.SYMBL_PIPE);*/
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 09 March 2021 -- START
		StringList slObjSelectsTup = new StringList();
		slObjSelectsTup.add(ConstantsUtil.SELECT_ID);
		slObjSelectsTup.add(ConstantsUtil.SELECT_NAME);
		slObjSelectsTup.add(ConstantsUtil.SELECT_TYPE);
		slObjSelectsTup.add(ConstantsUtil.SELECT_REVISION);
		slObjSelectsTup.add(ConstantsUtil.SELECT_DESCRIPTION);
		slObjSelectsTup.add(ConstantsUtil.SELECT_CURRENT);
		slObjSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		slObjSelectsTup.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		slObjSelectsTup.add("from["+ConstantsUtil.RELATIONSHIP_COPYLISTCOUNTRY+"].to.name");
		slObjSelectsTup.add("from["+ConstantsUtil.RELATIONSHIP_COPYLISTLOCALLANGUAGE+"].to.name");


		try
		{
			String sParentID = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
			if(UIUtil.isNotNullAndNotEmpty(sParentID))
			{
				DomainObject doParent = DomainObject.newInstance(context, sParentID);
				
				MapList mlGlobalHarSTD = doParent.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD,
						ConstantsUtil.QUERY_WILDCARD, slObjSelectsTup, DomainConstants.EMPTY_STRINGLIST, false, true,
						(short) 0, "", "", 0);
				
				if (mlGlobalHarSTD.isEmpty()) {
					return new HashMap();
				}
				Iterator objectListItr = mlGlobalHarSTD.iterator();
				while (objectListItr.hasNext()) 
				{
					Map objectMap = (Map) objectListItr.next();
					String sID = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					strType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
					String sTitle = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String sRev = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
					String sDec = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
					String sMarkets = validator.getEquivalentStringFromMapValue(objectMap.get("from["+ConstantsUtil.RELATIONSHIP_COPYLISTCOUNTRY+"].to.name"));
					String sLanguage = validator.getStringEquivalentForStringList(objectMap.get("from["+ConstantsUtil.RELATIONSHIP_COPYLISTLOCALLANGUAGE+"].to.name"));
					String sState = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
					strPhase = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
					
					if (!sState.equals(ConstantsUtil.RELEASE) && !sState.equals(ConstantsUtil.RELEASED)) {
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- START
						if(util.isModificatinRequired())
							continue;
						else
						//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- END
						sID=ConstantsUtil.NO_ACCESS;
					}

					formatData(sbGName, sName);
					formatData(sbGTitle, sTitle);
					formatData(sbGRev, sRev);
					formatData(sbGDec, sDec);
					formatData(sbMarkets, sMarkets);
					formatData(sbLang, sLanguage);
					formatData(sbID, sID);
					formatData(sbState, sState);
					formatData(sbType, strType);
					formatData(sbPhase, strPhase);
				}
			}
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 09 March 2021 -- END
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			/*for(String strID:slsObjectId){

				String sObjectId = strID.trim();
				if(UIUtil.isNotNullAndNotEmpty(sObjectId))
				{
					DomainObject doProductPart = new DomainObject(sObjectId);
					Map mpTemp = doProductPart.getInfo(context, slProductSelects);

					strRev = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_REVISION));
					strName = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_NAME));
					strType = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_TYPE));
					strTitle = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					strId = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.ID));
					strState = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_CURRENT));
					strPhase = validator.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

					formatData(sbName, strName);
					formatData(sbType, strType);
					formatData(sbRev, strRev);
					formatData(sbTitle, strTitle);
					formatData(sbId, strId);
					formatData(sbState, strState);
					formatData(sbPhase, strPhase);
				}
			}*/
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 09 March 2021 -- START :: Commented
			/*String sID = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID));
			//String sType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TYPE));
			String sName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME));
			String sTitle = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE));
			String sRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION));
			String sDec = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION));
			String sMarkets = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS));
			String sLanguage = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE));
			String sState = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT));

			formatData(sbGName, sName);
			formatData(sbGTitle, sTitle);
			formatData(sbGRev, sRev);
			formatData(sbGDec, sDec);
			formatData(sbMarkets, sMarkets);
			formatData(sbLang, sLanguage);
			formatData(sbID, sID);
			//formatData(sbGType, sType);
			formatData(sbState, sState);*/
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 09 March 2021 -- END :: Commented
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			/*//mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTNAME, sbName.toString());
			//mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTTYPE, sbType.toString());
			//mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTID, sbId.toString());
			//mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTREVISION,sbRev.toString());
			//mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTTITLE,sbTitle.toString());
			//mpGlobalHarStandard.put(ConstantsUtil.PHASE,sbPhase.toString());
			//);*/
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			//SPEC: 10/09/2020: Commented for Defect #42138 DEV -- START
			//mpGlobalHarStandard.put(ConstantsUtil.TYPE,sbType.toString());
			//SPEC: 10/09/2020: Commented for Defect #42138 DEV -- END
			mpGlobalHarStandard.put(ConstantsUtil.ID,sbID.toString());
			mpGlobalHarStandard.put(ConstantsUtil.NAME,sbGName.toString());
			mpGlobalHarStandard.put(ConstantsUtil.TITLE,sbGTitle.toString());
			mpGlobalHarStandard.put(ConstantsUtil.REVISION,sbGRev.toString());
			mpGlobalHarStandard.put(ConstantsUtil.DESCRIPTION,sbGDec.toString());
			mpGlobalHarStandard.put(ConstantsUtil.MARKETS,sbMarkets.toString());
			mpGlobalHarStandard.put(ConstantsUtil.LANGUAGE,sbLang.toString());
			mpGlobalHarStandard.put(ConstantsUtil.STATE,sbState.toString());
			mpGlobalHarStandard.put(ConstantsUtil.PHASE,sbPhase.toString());

		}catch(Exception e){
			LOGGER.error("Error from DPPBO:  getGHSProdcutValue"+e);
			return new HashMap();
		}
		return mpGlobalHarStandard;
	}

	/**
	 * Method Name 			: removeMultiValueList
	 * Method Description 	: 
	 */
	public void removeMultiValueList() 
	{


		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SUBNAME);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DRYWEIGHT);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ISCONTAM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_FUNCTIONS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);  		

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_NAME); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_CT_NUM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS); 	
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_MANU_SITE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PACK_SITE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PLANT_REST); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REG_DATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_REG_STATUS); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PARTPHYSICALID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTIONDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBERDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSNDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HCDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUPDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTYDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CONDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUSTDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPRDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZEDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUPDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOPDPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN1DPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TN2DPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NODPP);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE);

		/*DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE);*/

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHAR_PARTPHYSICALID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_MARKETS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARDAPP_LANGUAGE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		// Guna Added for Defect 38531  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_BUSINESS_AREA);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_FRANCHISE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.strIntendedMarket);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME);
		// Guna Added for Defect 38531  18x.5.2 Release -- END
		// Guna Added for Defect 38533  18x.5.2 Release -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS);
		// Guna Modified for Defect 38533  18x.5.2 Release -- END

		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Jwala -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_PRODUCT_PLATFORM_AREA);
		//SPEC:  Modified for  Defect 38811 on 02/03/2021 by Jwala -- END
		//SPEC: <14.04.2021>: Guna Added for 41220 Defect  Dev 18x.6   -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS);
		//SPEC: <14.04.2021>: Guna Added for 41220 Defect  Dev 18x.6   -- END

		//SPEC: Added for Defect 43707 by Jwala ## -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		//SPEC: Added for Defect 43707 by Jwala ## -- END
	}


	//SPEC: <10.22.2020>: Added for req 18x.5 ## -- START
	/**
	 * Method Name 			: getIpClass
	 * Method Description 	: Get IP Classification
	 * @param context
	 * @param doFormObj  - domain object of part
	 * @param slIpSelects - Selectable
	 */
	public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
		Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
		MapList mlIPCLass;
		try {
			mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
					null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			Iterator itr = mlIPCLass.iterator();
			Map mpIpClass = new HashMap();
			StringBuilder sbIpName = new StringBuilder();
			StringBuilder sbIpType = new StringBuilder();
			StringBuilder sbIpDesc = new StringBuilder();
			StringBuilder sbIpState = new StringBuilder();
			
			while(itr.hasNext()) {
				mpIpClass = (Map)itr.next();
				String sIpClassName = (String)mpIpClass.get(DomainConstants.SELECT_NAME);
				sbIpName.append(sIpClassName);
				sbIpType.append((String)mpIpClass.get(DomainConstants.SELECT_TYPE));
				sbIpDesc.append((String)mpIpClass.get(DomainConstants.SELECT_DESCRIPTION));
				sbIpState.append((String)mpIpClass.get(DomainConstants.SELECT_CURRENT));
				
				if(itr.hasNext()) {
					sbIpName.append("|");
					sbIpType.append("|");
					sbIpDesc.append("|");
					sbIpState.append("|");
					
				}
			}
			mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
			mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
			mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
			mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
			
		} catch (FrameworkException e) {
			e.printStackTrace();
			LOGGER.error("Error from DPPBO: getIpClass" + e);
		}
		return mpIpSecuritySetting;
	}


	/**
	 * Method Name 			: parseSubstitute
	 * Method Description 	: Fetching "Substitute" details
	 * @param context
	 * @param mapList
	 * @return
	 * @throws Exception 
	 */
	/* public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
	{
    	StringValidatorUtil validator = new StringValidatorUtil();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
    	try {
			Iterator objectListItr = mapList.iterator();
			StringBuilder sbEBOMName = new StringBuilder();
			StringBuilder sbEBOMParentName = new StringBuilder();
			StringBuilder sbEBOMParentRev = new StringBuilder();
			StringBuilder sbEBOMParentTitle = new StringBuilder();
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMParentId = new StringBuilder();
			StringBuilder sbEBOMRefDoc= new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMCommnts = new StringBuilder();
			StringBuilder sbEBOMSubType= new StringBuilder();
			StringBuilder sbEBOMEffectDate= new StringBuilder();
			StringBuilder sbEBOMUntilDate= new StringBuilder();
			StringBuilder sbEBOMCobNum= new StringBuilder();
			StringBuilder sbEBOMChildRev= new StringBuilder();
			StringBuilder sbEBOMRevRelDt= new StringBuilder();
			StringBuilder sbEBOMSubFor= new StringBuilder();
			StringBuilder sbEBOMParentType = new StringBuilder();

			StringBuilder sbEBOMChg = new StringBuilder();
			StringBuilder sbEBOMSFSubType= new StringBuilder();
			StringBuilder sbMinqty= new StringBuilder();
			StringBuilder sbMaxqty= new StringBuilder();
			StringBuilder sbRF= new StringBuilder();
			StringBuilder sbMF= new StringBuilder();
			StringBuilder sbCert= new StringBuilder();

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				boolean showData = false;
				boolean bHasOwnership=false;

				String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
				if(null!=objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {

				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
					//String
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
						String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sReleaseDate =validator.getStringEquivalentForStringList(validator.DateFormatter((String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;

						String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
						String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
						String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
						String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
						String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
						String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
						String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
						String sEffectvityDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY)));
						String sUntilDate=validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
						String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
						String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
						String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
						sOC = util.replaceSpecialSymbols(sOC);
						String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
						String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));

						String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
						String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
						String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
						String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
						String strRF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);


						if(util.isModificatinRequired())
						{
							SecurityService sec = new SecurityService();
							String sComp = sec.getUserCauthorities();
							StringList slUserOwnership=util.filterOwnerShip(sComp);

							bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sChildId);

							if(!bHasOwnership)
							{
								sParentType = ConstantsUtil.NO_ACCESS;
								sParentID = ConstantsUtil.NO_ACCESS;
								sChildId    = ConstantsUtil.NO_ACCESS;
								sParentName = ConstantsUtil.NO_ACCESS;
								sParentRev = ConstantsUtil.NO_ACCESS;
								sParentTitle = ConstantsUtil.NO_ACCESS;
								sCombinationNum = ConstantsUtil.NO_ACCESS;
								sChildTitle = ConstantsUtil.NO_ACCESS;
								sSUBType = ConstantsUtil.NO_ACCESS;
								sEffectvityDate = ConstantsUtil.NO_ACCESS;
								sRevRelease = ConstantsUtil.NO_ACCESS;
								sUntilDate = ConstantsUtil.NO_ACCESS;
								sRDOC = ConstantsUtil.NO_ACCESS;
								sQTY = ConstantsUtil.NO_ACCESS;
								sBASEUOM = ConstantsUtil.NO_ACCESS;
								sChildRev = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								strMinqty = ConstantsUtil.NO_ACCESS;
								strMaxqty = ConstantsUtil.NO_ACCESS;
								strMF = ConstantsUtil.NO_ACCESS;
								strRF = ConstantsUtil.NO_ACCESS;
						    }
						}else if(sct.isStaffAUGUser()) {

							if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								String sFormulaClassif = util.getFormulaPropagateClassification(context, sChildId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}
						}else {
							StringList slHIRTypes = new StringList();
							slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
							slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
							slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

							if(slHIRTypes.contains(sChildType)) {
								showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
							}else {
								showData=true;
							}

						}

						if(!showData){
							sParentID = ConstantsUtil.NO_ACCESS;
							sChildId    = ConstantsUtil.NO_ACCESS;
							sParentType = ConstantsUtil.NO_ACCESS;
							sParentID = ConstantsUtil.NO_ACCESS;
							sChildId    = ConstantsUtil.NO_ACCESS;
							//sParentName = ConstantsUtil.NO_ACCESS;
							//sParentRev = ConstantsUtil.NO_ACCESS;
							sParentTitle = ConstantsUtil.NO_ACCESS;
							sCombinationNum = ConstantsUtil.NO_ACCESS;
							sChildTitle = ConstantsUtil.NO_ACCESS;
							sSUBType = ConstantsUtil.NO_ACCESS;
							sEffectvityDate = ConstantsUtil.NO_ACCESS;
							sRevRelease = ConstantsUtil.NO_ACCESS;
							sUntilDate = ConstantsUtil.NO_ACCESS;
							sRDOC = ConstantsUtil.NO_ACCESS;
							sComments = ConstantsUtil.NO_ACCESS;
						}

						sChildType = util.mapType(sChildType);

						formatData(sbEBOMName,sChildName);
						formatData(sbEBOMType,sChildType);
						formatData(sbEBOMQTY,sQTY);
						formatData(sbEBOMBuom,sBASEUOM);
						formatData(sbEBOMChildRev,sChildRev);

						formatData(sbEBOMParentType,sParentType);
						formatData(sbEBOMParentId,sParentID);
						formatData(sbEBOMId,sChildId);
						formatData(sbEBOMParentName,sParentName);
						formatData(sbEBOMParentRev,sParentRev);
						formatData(sbEBOMParentTitle,sParentTitle);
						formatData(sbEBOMCobNum,sCombinationNum);
						formatData(sbEBOMTitle,sChildTitle);
						formatData(sbEBOMSubType,sSUBType);
						formatData(sbEBOMRevRelDt,sRevRelease);
						formatData(sbEBOMEffectDate,sEffectvityDate);
						formatData(sbEBOMUntilDate,sUntilDate);
						formatData(sbEBOMRefDoc,sRDOC);
						formatData(sbEBOMCommnts,sComments);
						formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
						formatData(sbEBOMChg,sChg);
						//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
					//}
					}
				} else {
					//StringList
					String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
					String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
					String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
					if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
						StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
						for(int i =0; i<slChildId.size(); i++) {
							String sEachChildId = slChildId.getElement(i);
							DomainObject doEachChild = new DomainObject(sEachChildId);
							DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							StringList slSelect = new StringList();
							slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							Map mpIpClass = doEachChild.getInfo(context, slSelect);
							StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
							//String sIpClass = doEachChild.getInfo(context, "to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
							DomainConstants.MULTI_VALUE_LIST.remove("to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
							StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
							if(util.isModificatinRequired())
							{
								SecurityService sec = new SecurityService();
								String sComp = sec.getUserCauthorities();
								StringList slUserOwnership=util.filterOwnerShip(sComp);

								bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sEachChildId);
								if(bHasOwnership)
								{
									showData=true;
							    }
							}else if(sct.isStaffAUGUser()) {
								if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sEachChildId);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
								}
							}else {
								StringList slHIRTypes = new StringList();
								slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
								slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
								if(slHIRTypes.contains(slChildType.getElement(i))) {
									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
								}else {
									showData=true;
								}
							}

							if(!showData) {
								sEachChildId=ConstantsUtil.NO_ACCESS;
							}
							StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
							StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
							StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
							StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
							StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
							StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
							StringList slEffectvityDate = (StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
							StringList slUntilDate= (StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
							String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = slRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
							StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
							//StringList sSFSubType = (StringList) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
							//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

							if(showData) {
								String sChildType = util.mapType(slChildType.get(i));
								formatData(sbEBOMName,slChildName.get(i));
								formatData(sbEBOMType,sChildType);
								formatData(sbEBOMQTY,slQTY.get(i));
								formatData(sbEBOMBuom,slBASEUOM.get(i));
								formatData(sbEBOMChildRev,slChildRev.get(i));
								formatData(sbEBOMParentType,sParentType);
								formatData(sbEBOMParentId,sParentID);
								formatData(sbEBOMId,sEachChildId);
								formatData(sbEBOMParentName,sParentName);
								formatData(sbEBOMParentRev,sParentRev);
								formatData(sbEBOMParentTitle,sParentTitle);
								formatData(sbEBOMCobNum,slCombinationNum.get(i));
								formatData(sbEBOMTitle,slChildTitle.get(i));
								formatData(sbEBOMSubType,slSUBType.get(i));
								formatData(sbEBOMRevRelDt,sRevRelease);
								formatData(sbEBOMEffectDate,slEffectvityDate.get(i));
								formatData(sbEBOMUntilDate,slUntilDate.get(i));
								formatData(sbEBOMRefDoc,sRDOC);
								formatData(sbEBOMCommnts,slComments.get(i));
								formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
								formatData(sbEBOMChg,sChg.get(i));
								//formatData(sbEBOMSFSubType,sSFSubType.get(i));
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
							}else {
								String sChildType = util.mapType(slChildType.get(i));
								formatData(sbEBOMName,slChildName.get(i));
								formatData(sbEBOMType,sChildType);
								formatData(sbEBOMQTY,slQTY.get(i));
								formatData(sbEBOMBuom,slBASEUOM.get(i));
								formatData(sbEBOMChildRev,slChildRev.get(i));
								formatData(sbEBOMParentType,sParentType);
								formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMParentName,sParentName);
								formatData(sbEBOMParentRev,sParentRev);
								formatData(sbEBOMParentTitle,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMCobNum,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMSubType,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMRevRelDt,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMEffectDate,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMUntilDate,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMRefDoc,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMCommnts,ConstantsUtil.NO_ACCESS);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
								formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
								formatData(sbEBOMSFSubType,ConstantsUtil.NO_ACCESS);
								//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
								formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
							}
						}
					}
				}
				}

			}
			mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
			mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
			mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
			mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
			mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
			mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
			mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
			mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
			mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
			mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
			mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
			mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
			mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
			mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
			mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
			mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
			mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
			mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
			mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
			mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
			mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());
			mpEBOMResult.put(ConstantsUtil.MIN, sbMinqty.toString());
			mpEBOMResult.put(ConstantsUtil.MAX, sbMaxqty.toString());
			mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbRF.toString());
			mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbMF.toString());
			mpEBOMResult.put(ConstantsUtil.CERTIFICATIONS, sbCert.toString());

    	}catch(Exception e) {
    		LOGGER.info("EXCEPTION IN APPBO : parseSubstitute: "+e.getMessage());
    	}
		return util.filterMapList(mpEBOMResult);
	}*/


	/**
	 * Method Name 			: getSapBOMasFed
	 * Method Description 	: It will return the connected SAP BOM
	 * @param context
	 * @param sID
	 * @return
	 */
	public Map getSapBOMasFed(Context context ,String sID){

		CalculateBOM clBom = new CalculateBOM();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mapSapBomAsFedResult = new HashMap();

		SecurityService sct = new SecurityService();
		boolean isStaffAUg = sct.isStaffAUGUser();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbSapType = new StringBuilder();
		StringBuilder sbSpecSubType = new StringBuilder();
		StringBuilder sbSpecGroup = new StringBuilder();
		StringBuilder sbBOMQTY = new StringBuilder();
		StringBuilder sbBuom = new StringBuilder();
		StringBuilder sbComnt = new StringBuilder();
		StringBuilder sbSAPDesc = new StringBuilder();
		StringBuilder sbAuthorized = new StringBuilder();
		StringBuilder sbAuthorizedToUse = new StringBuilder();
		StringBuilder sbAuthorizedToProduce = new StringBuilder();
		StringBuilder sbOC = new StringBuilder();
		StringBuilder sbMinQTY = new StringBuilder();
		StringBuilder sbMaxQTY = new StringBuilder();
		StringBuilder sbTUType = new StringBuilder();
		StringBuilder sbTUName = new StringBuilder();
		StringBuilder sbTUId = new StringBuilder();

		try
		{
			ArrayList alSapBom = performDataReadFromEnovia(context,sID);
			MapList ml = getTableData(context,alSapBom);

			sbSpecSubType = clBom.getSpecificationSubtype(context ,ml);
			Iterator objectListItr = ml.iterator();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sId =(String)objectMap.get(ConstantsUtil.MAP_KEY_ID);
				String sName =(String)objectMap.get(ConstantsUtil.NAME);
				String sTitle =(String)objectMap.get(ConstantsUtil.DESCRIPTION);
				String sType =(String)objectMap.get(ConstantsUtil.TYPE);
				String sSapType =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPTYPE);
				String sSpecGroup =(String)objectMap.get(ConstantsUtil.MAP_KEY_SUBSTITUTE);
				String sQty =(String)objectMap.get(ConstantsUtil.MAP_KEY_BOMQTY);
				String sBuom =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPUOM);
				String strClassFied = (String)objectMap.get(ConstantsUtil.SECURITY);
				String strControlClass = (String)objectMap.get(ConstantsUtil.OBJECTSECURITYCLASS);
				String strComment = (String)objectMap.get(ConstantsUtil.ATTRIBUTE_COMMENT);
				String strSAPDesc = (String)objectMap.get(ConstantsUtil.SAPDESCRIPTION);
				/*String strAuthorized = (String)objectMap.get(ConstantsUtil.AUTHORIZED);
				String strAuthorizedToUse = (String)objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE);
				String strAuthorizedToProduce = (String)objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE);
				String strOC = (String)objectMap.get(ConstantsUtil.OC);*/
				String strTU = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT);
				if(UIUtil.isNullOrEmpty(strTU)){
					strTU=ConstantsUtil.EMPTY_STRING;
				}
				String strMaxQTY = (String)objectMap.get(ConstantsUtil.MAX);
				String strMinQTY = (String)objectMap.get(ConstantsUtil.MIN);

				String strOC = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.OC));
				String strAuthorizedToProduce =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE));
				String strAuthorizedToUse = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE));
				String strAuthorized = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZED));
				String strTUType = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_TYPE);
				String strTUName = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_NAME);
				String strTUId = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_ID);

				boolean bHasOwnership = false;
				String sUserlicense = sct.getUserLicense();
				String sFormulaPropagate = sId;

				if(sType.equals(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT) || sType.equals(ConstantsUtil.TYPE_FORMULA_CARD))
				{
					sId =ConstantsUtil.NO_ACCESS;
					sTitle =ConstantsUtil.NO_ACCESS;
					//sSapType =ConstantsUtil.NO_ACCESS;
					//sSpecGroup =ConstantsUtil.NO_ACCESS;
					//sQty =ConstantsUtil.NO_ACCESS;
					//sBuom =ConstantsUtil.NO_ACCESS;
					//strComment=ConstantsUtil.NO_ACCESS;

					strAuthorized=ConstantsUtil.NO_ACCESS;
					strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
					strAuthorizedToUse=ConstantsUtil.NO_ACCESS;


				}
				else
				{
					if(util.isModificatinRequired())
					{
						//commented by Ganesh for security impl--->start
						/*SecurityService sec = new SecurityService();
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);

					//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sId);
					}

					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}*/
						//commented by Ganesh for security impl--->end
						//modified by Ganesh for security impl--->start
						bHasOwnership = util.checkHasAccess(context, null, sId);
						//modified by Ganesh for security impl--->end
						if(!bHasOwnership)
						{
							sTitle = ConstantsUtil.NO_ACCESS;
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							sSapType =ConstantsUtil.NO_ACCESS;
							sSpecGroup =ConstantsUtil.NO_ACCESS;
							sQty =ConstantsUtil.NO_ACCESS;
							sBuom =ConstantsUtil.NO_ACCESS;
							strComment=ConstantsUtil.NO_ACCESS;
							strSAPDesc=ConstantsUtil.NO_ACCESS;
							strAuthorized=ConstantsUtil.NO_ACCESS;
							strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							strOC=ConstantsUtil.NO_ACCESS;
							strTU=ConstantsUtil.NO_ACCESS;
							strMaxQTY=ConstantsUtil.NO_ACCESS;
							strMinQTY=ConstantsUtil.NO_ACCESS;
						}
					}else if(isStaffAUg)
					{
						boolean showData = true;
						//commented by Ganesh for security impl --->start
						/*String sFormulaClassif =strControlClass;

						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}

						showData= util.checkLicenses(sUserlicense,sFormulaClassif);*/
						//commented by Ganesh for security impl --->end
						//commented by Ganesh for security impl --->start
						showData = util.checkHasAccess(context, null, sId);
						//commented by Ganesh for security impl --->end
						if(!showData)
						{
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;

							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}

							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}

							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}

						}

					}else{
						//commented by Ganesh for security impl---->start
						/*StringList slHIRTypes = new StringList();

					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

					boolean showData = true;
					if(slHIRTypes.contains(sType) )
					{
						if(slHIRTypes.contains(sType) )
						{
							String sFormulaClassif =strClassFied;
								if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) 
								{
										sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
								}
									showData= util.checkLicenses(sUserlicense,sFormulaClassif);
						}			

					}*/
						//commented by Ganesh for security impl---->end
						//modified by Ganesh for security impl---->start
						boolean showData = util.checkHasAccess(context, null, sId);
						//modified by Ganesh for security impl---->end
						if(!showData){
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;

							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}

							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}

							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}

						}

					}
				}	
				util.formatData(sbId,sId);
				util.formatData(sbName,sName);
				util.formatData(sbTitle,sTitle);
				util.formatData(sbType,util.mapType(sType));
				util.formatData(sbSapType,sSapType);
				util.formatData(sbSpecGroup,sSpecGroup);
				util.formatData(sbBOMQTY,sQty);
				util.formatData(sbBuom,sBuom);
				util.formatData(sbComnt,strComment);
				util.formatData(sbSAPDesc,strSAPDesc);
				util.formatData(sbAuthorized,strAuthorized);
				util.formatData(sbAuthorizedToUse,strAuthorizedToUse);
				util.formatData(sbAuthorizedToProduce,strAuthorizedToProduce);
				util.formatData(sbOC,strOC);
				util.formatData(sbMaxQTY,strMaxQTY);
				util.formatData(sbMinQTY,strMinQTY);

				util.formatData(sbTUType,strTUType);
				util.formatData(sbTUName,strTUName);
				util.formatData(sbTUId,strTUId);
			}

			mapSapBomAsFedResult.put(ConstantsUtil.NAME, sbName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.ID, sbId.toString());
			//mapSapBomAsFedResult.put(ConstantsUtil.TITLE, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TYPE, sbType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPTYPE, sbSapType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONGROUP, sbSpecGroup.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BOMQUANTITY, sbBOMQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbBuom.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.COMMENTS, sbComnt.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPDESCRIPTION, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZED, sbAuthorized.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOUSE, sbAuthorizedToUse.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, sbAuthorizedToProduce.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.OC,sbOC.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_NAME,sbTUName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_TYPE,sbTUType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_ID,sbTUId.toString());

			mapSapBomAsFedResult.put(ConstantsUtil.MAX,sbMaxQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.MIN,sbMinQTY.toString());

		}catch(Exception e){
			LOGGER.error("Exception in program FabricatedPartBO :getSapBOMasFed ");
		}
		return mapSapBomAsFedResult;
	}


	/**
	 * Method Name 			: performDataReadFromEnovia
	 * Method Description 	: 
	 * @param context
	 * @param sPartObjectID
	 * @return
	 * @throws Exception
	 */
	public synchronized ArrayList performDataReadFromEnovia(Context context,String sPartObjectID) throws Exception {

		Map 	mapPartDetails				= new HashMap();

		ArrayList alPartRelatedObjects 		= new ArrayList();
		String strSpecSubType = DomainConstants.EMPTY_STRING;
		String strFormulationType = DomainConstants.EMPTY_STRING;

		StringValidatorUtil BusinessUtil= new StringValidatorUtil();
		CalculateBOM clBom = new CalculateBOM();

		try {

			if(BusinessUtil.isNotNullOrEmpty(sPartObjectID)){

				DomainObject doPart = DomainObject.newInstance(context,sPartObjectID);
				StringList slBusSelect = new StringList(12);
				slBusSelect.add(DomainConstants.SELECT_TYPE);
				slBusSelect.add(DomainConstants.SELECT_NAME);
				slBusSelect.add(DomainConstants.SELECT_ID);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slBusSelect.add(ConstantsUtil.STR_IPCLASS);

				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slBusSelect.add("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
				slBusSelect.add("next.id");
				mapPartDetails = doPart.getInfo(context, slBusSelect);

				if(null != mapPartDetails && mapPartDetails.size()>0) {

					strSpecSubType = (String) mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					Object OFormulationType = (Object)mapPartDetails.get("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);

					StringList slFormulationType = new StringList();

					if (null != OFormulationType) {
						if (OFormulationType instanceof StringList) {
							slFormulationType = (StringList) OFormulationType;
						} else if (OFormulationType instanceof String) {
							slFormulationType.add(OFormulationType.toString());
						}
					}								
					if(clBom.doProdUsageCheckForeDelivery(context,mapPartDetails)) {

						String strPartType	=	(String)mapPartDetails.get(DomainConstants.SELECT_TYPE);

						if(BusinessUtil.isNotNullOrEmpty(strPartType)) {

							if(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equalsIgnoreCase(strPartType)) {

								alPartRelatedObjects = clBom.getPartObjectsFromEBOM(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_FORMULATIONPART.equalsIgnoreCase(strPartType) && !slFormulationType.isEmpty() && !slFormulationType.contains(ConstantsUtil.THIRD_PARTY_FORMULA) ) {
								alPartRelatedObjects = clBom.getObjectsForFOPFromFormulaIngredient(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(strPartType) || (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strPartType) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromIntermediateBOM(context,sPartObjectID);
							} else if(ConstantsUtil.TYPE_FABRICATEDPART.equalsIgnoreCase(strPartType) ||   ConstantsUtil.TYPE_INTERMEDIATEPRODUCTPART.equalsIgnoreCase(strPartType) || ((ConstantsUtil.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strPartType)) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = clBom.getPartObjectsFromBOM(context,sPartObjectID);
							}
						}
					}
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return alPartRelatedObjects;
	}


	/**
	 * Method Name 			: getTableData
	 * Method Description 	: 
	 * @param context
	 * @param alPartObjectsWithGroupAndQty
	 * @return
	 * @throws Exception
	 */
	public MapList getTableData(Context context, ArrayList alPartObjectsWithGroupAndQty) throws Exception {
		MapList mpReturnList = new MapList();
		boolean isContextPushed = false;
		int OBJECT_ID = 27;
		int SUBSTITUTE_FLAG = 14;
		int QUANTITY = 10;
		int FC_MIN_QTY = 23;
		int FC_MAX_QTY = 25;
		int SORT_STRING = 13;
		int TUP_ID = 28;
		int OPT_COMPONENT = 29;

		//SPEC 11/05/2020 added for defect:37077 ##--END
		int INDEX_TPU_TYPE = 34;
		int INDEX_TPU_NAME = 35;
		//SPEC 11/05/2020 added for defect: 37077##--END

		try {
			StringList slPartSelect = new StringList(7);
			slPartSelect.addElement(DomainConstants.SELECT_NAME);
			slPartSelect.addElement(DomainConstants.SELECT_TYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slPartSelect.addElement(ConstantsUtil.STR_IPCLASS);
			slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			//slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME);
			//slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);

			CalculateBOM clBom = new CalculateBOM();
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_IPCLASS);
			ContextUtil.pushContext(context);
			isContextPushed = true;
			if(null != alPartObjectsWithGroupAndQty) 
			{
				int alsize=alPartObjectsWithGroupAndQty.size();
				StringValidatorUtil validator = new StringValidatorUtil();
				String strObjID = null;
				String strSubstitute=null;
				String strBOMQuantity = null;
				String strMin = null;
				String strMax = null;
				String strPosInd = null;
				String strObjectType = null;
				String strSAPUOM = null;
				String strSAPType = null;
				String strPGCSSType = null;
				String strTUPObjID = null;
				String strIPClass = null;
				String strOptComponent = null;
				//String strAuthorized = null;
				//String strOC = null;
				//String strAuthorizedToUse = null;
				//String strAuthorizedToProduce = null;
				String strTransportUnit = null;
				DomainObject domObject = null;
				Map mpPartObjectInfo = null;
				int COMMENT = 30;
				String strComment = DomainConstants.EMPTY_STRING; 
				String strName = DomainConstants.EMPTY_STRING; 
				String strDescription = DomainConstants.EMPTY_STRING; 
				String strTUPObjName = DomainConstants.EMPTY_STRING; 
				String strTUPObjType = DomainConstants.EMPTY_STRING;
				//SPEC 11/05/2020 added for defect: ##--START
				StringList slRelSelect = new StringList();
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
				slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
				//SPEC 11/05/2020 added for defect: ##--END

				HashMap hmTemp = null;
				for (int i=0; i<alsize; i++) {
					String [] satemp = (String[]) alPartObjectsWithGroupAndQty.get(i);
					strObjID = satemp[OBJECT_ID];
					strSubstitute= satemp[SUBSTITUTE_FLAG];
					strBOMQuantity = satemp[QUANTITY];
					strMin = satemp[FC_MIN_QTY];
					strMax = satemp[FC_MAX_QTY];
					strPosInd = satemp[SORT_STRING];
					String sqty = satemp[ConstantsUtil.INDEX_TARGET] ;	
					strOptComponent = satemp[OPT_COMPONENT];
					domObject = DomainObject.newInstance(context,strObjID);
					mpPartObjectInfo = domObject.getInfo(context, slPartSelect);
					strObjectType = (String)mpPartObjectInfo.get(DomainConstants.SELECT_TYPE);
					strSAPUOM = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					strSAPType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
					strPGCSSType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
					strComment = satemp[COMMENT];
					strName = (String)mpPartObjectInfo.get(DomainConstants.SELECT_NAME);
					strDescription = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					/*strAuthorized = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					strAuthorizedToUse = validator.getStringEquivalentForStringListWithComma(mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_MANUFACTURER_NAME));
					strAuthorizedToProduce =  validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));*/
					strTransportUnit =  validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.EMPTY_STRING));
					//strOC = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
					strIPClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.STR_IPCLASS));
					String strIPControlClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));

					//SPEC 11/05/2020 added for defect: 37077##--START
					strTUPObjID = validator.getStringEquivalentForStringList(satemp[TUP_ID]);
					strTUPObjName = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_NAME]);
					strTUPObjType = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_TYPE]);
					//SPEC 11/05/2020 added for defect: 37077##--END

					//SPEC 11/05/2020 added for defect: ##--START
					MapList mlParentPlantList = clBom.getConnectedPlantList(context, strObjID, slRelSelect, null);

					boolean bTUPAccess=false;
					if(UIUtil.isNotNullAndNotEmpty(strTUPObjID)){
						bTUPAccess = clBom.checkHasAccess(context,strTUPObjID);
					}

					if(!bTUPAccess){
						strTUPObjID=ConstantsUtil.NO_ACCESS;
					}


					StringList	slAVPlantList = new StringList();
					StringList	slAUPlantList = new StringList();
					StringList	slAPPlantList = new StringList();
					if(mlParentPlantList!=null && mlParentPlantList.size()>0)
					{
						for(int ip=0;ip<mlParentPlantList.size();ip++)
						{
							Map mapSAPBOMComponent = (Map)mlParentPlantList.get(ip);
							String	sAVAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
							String	sAUAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
							String	sAPAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
							String	sSAPBOMComponentPlantName = (String)mapSAPBOMComponent.get(DomainObject.SELECT_NAME);

							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAVAttributeValue) && strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAVPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAUAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAUPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAPAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAPPlantList.add(sSAPBOMComponentPlantName);
							}
						}
					}

					String	strAVPlantList = DomainConstants.EMPTY_STRING;
					String	strAUPlantList = DomainConstants.EMPTY_STRING;
					String	strAPPlantList = DomainConstants.EMPTY_STRING;

					if(slAVPlantList!= null && slAVPlantList.size()>0)
					{
						strAVPlantList = FrameworkUtil.join(slAVPlantList, "&&&");
					}

					if(slAUPlantList!= null && slAUPlantList.size()>0)
					{
						strAUPlantList = FrameworkUtil.join(slAUPlantList, "&&&");
					}

					if(slAPPlantList!= null && slAPPlantList.size()>0)
					{
						strAPPlantList = FrameworkUtil.join(slAPPlantList, "&&&");
					}

					//SPEC 11/05/2020 added for defect: ##--END


					hmTemp = new  HashMap();
					hmTemp.put("id",strObjID);  
					hmTemp.put("type",strObjectType);  
					hmTemp.put("substitute",strSubstitute);
					hmTemp.put("BOMQty",strBOMQuantity);
					hmTemp.put("Min",strMin);
					hmTemp.put("Max",strMax);
					hmTemp.put("PosInd",strPosInd);
					hmTemp.put("SAPUOM",strSAPUOM);
					hmTemp.put("SAPType",strSAPType);
					hmTemp.put("SSType",strPGCSSType);
					hmTemp.put("dispId", strObjID);
					hmTemp.put("OptComponent", strOptComponent);
					hmTemp.put(ConstantsUtil.ATTRIBUTE_COMMENT, strComment);
					hmTemp.put(DomainConstants.SELECT_NAME, strName);
					hmTemp.put(DomainConstants.SELECT_DESCRIPTION, strDescription);
					hmTemp.put(ConstantsUtil.SECURITY, strIPClass);
					hmTemp.put(ConstantsUtil.OBJECTSECURITYCLASS, strIPControlClass);
					hmTemp.put(ConstantsUtil.AUTHORIZED, strAVPlantList);
					hmTemp.put(ConstantsUtil.OC, strOptComponent);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOUSE, strAUPlantList);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, strAPPlantList);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_TYPE, strTUPObjType);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_NAME, strTUPObjName);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_ID, strTUPObjID);
					mpReturnList.add(hmTemp);
				}
			}

			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);

		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(isContextPushed) {
				ContextUtil.popContext(context);
				isContextPushed = false;
			}
		}
		return mpReturnList;
	}


	/**
	 * Method Name 			: getMasterPartStabilityDoc
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getMasterPartStabilityDoc(Context context,Map resultMaps) 
	{
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.STR_IPCLASS);

		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTREVISION);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);

		//boolean bHasOwnerShip = false;

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		//Added for Requirement #38398 by Manikanta -- START
		boolean bHasMasterPartAccess = false;
		//Added for Requirement #38398 by Manikanta -- END
		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;


		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			DomainObject doFOP = new DomainObject(sObjectId);

			//<11.20.2020>: Added for #37451 START
			//SPEC: <25.08.2022>: Satyam Added for Defect 50306 -- START
			String sSelectMasterId = ConstantsUtil.SELECT_MASTERPARTID;
			//SPEC: <25.08.2022>: Satyam Added for Defect 50306 -- END
			//SPEC: Added for Defect 41340 by Jwala -- START	
			StringList slMasters = new StringList();
			slMasters.add(sSelectMasterId);
			slMasters.add(ConstantsUtil.SELECT_MASTERPARTNAME);
			slMasters.add(ConstantsUtil.SELECT_MASTERPARTREVISION);
			slMasters.add(ConstantsUtil.SELECT_MASTERPARTTITLE);
			slMasters.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
			//SPEC: Added for Defect 41340 by Jwala -- END
			//String sMPPId = doFOP.getInfo(context, sSelectMasterId);
			//SPEC: Modified for Defect 41340 by Jwala -- START
			Map mpMasters = doFOP.getInfo(context, slMasters);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doFOP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			String sMPPId = (String)mpMasters.get(sSelectMasterId);
			//SPEC: Modified for Defect 41340 by Jwala -- START
			
			if(!validator.isNotNullOrEmpty(sMPPId)){

				mpRefDoc.put(ConstantsUtil.ID, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTNAME, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTREV, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTTITLE, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.PRODUCTEXPDATEREQ, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.TOTALSHELFLIFEDAYS, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.TEMPERATUREGROUP, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.HUMIDITYGROUP, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.TRANSPORTHEATPROTECTION, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.BOUNDARYCONDITIONS, ConstantsUtil.EMPTY_STRING);
				mpRefDoc.put(ConstantsUtil.STABILITYDOCUMENT, ConstantsUtil.EMPTY_STRING);
				return mpRefDoc;
			}

			DomainObject doMPP = new DomainObject(sMPPId);
			
			// Modified by Jwala for the defect 42869 --  START
			/*MapList mlRefDocs = doMPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.TYPE_PGPKGSTABILITYREPORT, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);*/
			//SPEC: <05.07.2021>: Guna Modified for Defect 44040 Dev 18x.6.0.1   -- START
            String sWhere ="current!=Approved";
			MapList mlRefDocs = doMPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.TYPE_PGPKGSTABILITYREPORT.concat(",").concat(ConstantsUtil.TYPE_PGTECHNICALRATIONAL), busSelect, new StringList(), false, true, (short) 1,
					 sWhere,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <05.07.2021>: Guna Modified for Defect 44040 Dev 18x.6.0.1   -- END
			// Modified by Jwala for the defect 42869 --  END
			
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doMPP.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			
			/*
			MapList mlRefDocs = doFOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL); */

			//<11.20.2020>: Added for #37451 END
			//Added for Requirement #38398 by Manikanta -- START
			bHasMasterPartAccess = util.checkHasAccess(context, null, sMPPId);
			//Added for Requirement #38398 by Manikanta -- END
			String sUser = util.getUserType();

			if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}

			if(util.isModificatinRequired()) 
			{
				mlRefDocs=util.filterPhase(mlRefDocs);
			}
			Iterator objectListItr = mlRefDocs.iterator();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbMasterProductPartName = new StringBuilder();
			StringBuilder sbMasterProductPartRevision = new StringBuilder();
			StringBuilder sbMasterProductPartTitle =new StringBuilder();
			//SPEC: Added for Defect 41340 by Jwala -- START	
			StringBuilder sbMasterProductPartID = new StringBuilder();
			StringBuilder sbMasterProductPartType = new StringBuilder();
			//SPEC: Added for Defect 41340 by Jwala -- END
			StringBuilder sbProductExpirationDataRequired=new StringBuilder();
			StringBuilder sbTotalShelfLifeDays=new StringBuilder();
			StringBuilder sbTemperatureGroup=new StringBuilder();
			StringBuilder sbHumidityGroup=new StringBuilder();
			StringBuilder sbTransportFreezeProtection = new StringBuilder();
			StringBuilder sbTransportHeatProtection = new StringBuilder();
			StringBuilder sbBoundaryConditions = new StringBuilder();
			StringBuilder sbStabilityDocument = new StringBuilder();
			//SPEC: <26.03.2021>: Guna Added for Defect 41790 Dev 18x.6   -- START
			StringBuilder sbStabilityDocumentType = new StringBuilder();
			//SPEC: <26.03.2021>: Guna Added for Defect 41790 Dev 18x.6   -- END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sId    =  (String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	 =	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				//SPEC: Added for Defect 41340 by Jwala -- START	
				String sMasterProductPartName    =  validator.isNotNullOrEmpty((String)mpMasters.get(ConstantsUtil.SELECT_MASTERPARTNAME))?(String)mpMasters.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartType    =  validator.isNotNullOrEmpty((String)mpMasters.get(ConstantsUtil.SELECT_MASTERPARTTYPE))?(String)mpMasters.get(ConstantsUtil.SELECT_MASTERPARTTYPE) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartRevision    =   validator.isNotNullOrEmpty((String)mpMasters.get(ConstantsUtil.SELECT_MASTERPARTREVISION))?(String)mpMasters.get(ConstantsUtil.SELECT_MASTERPARTREVISION) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartTitle		=	validator.isNotNullOrEmpty((String)mpMasters.get(ConstantsUtil.SELECT_MASTERPARTTITLE))?(String)mpMasters.get(ConstantsUtil.SELECT_MASTERPARTTITLE) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductID		=	validator.isNotNullOrEmpty((String)mpMasters.get(sSelectMasterId))?(String)mpMasters.get(sSelectMasterId) : ConstantsUtil.EMPTY_STRING;
				//SPEC: Added for Defect 41340 by Jwala -- END
				String sProductExpirationDataRequired	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
				String sTotalShelfLifeDays		=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
				String sTemperatureGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
				String sHumidityGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
				String sTransportFreezeProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
				String sTransportHeatProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
				String sBoundaryConditions = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
				String sStabilityDocument = (String)objectMap.get(ConstantsUtil.SELECT_NAME);

				StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;

				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}

				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					String sLangBuffer =ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;

					if (util.isModificatinRequired()) 
					{
						//Added by Ganesh 1.0.2 Release Start
						//bHasOwnerShip = util.checkOwnerShip(sbCompany,slEachOwnership);
						//Modified by Jwala for the defect #43828 -- START
						//bHasOwnerShip = util.checkHasAccess(context, null, sId);
						showData = util.checkHasAccess(context, null, sId);
						//Modified by Jwala for the defect #43828 -- END
						//Added by Ganesh 1.0.2 Release End
						if(!sCurrent.equals(ConstantsUtil.RELEASE)) {
							showData=false;
						}
					}else if(sct.isStaffAUGUser()) {
						/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}*/
						//Added by Ganesh 1.0.2 Release Start
						showData = util.checkHasAccess(context, null, sId);
						//Added by Ganesh 1.0.2 Release End
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							showData=false;
						}
					}else {
						/*StringList slHIRTypes = new StringList();
					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

					if(slHIRTypes.contains(sType)) {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}else {
						showData=true;
					}*/
						//Added by Ganesh 1.0.2 Release Start
						showData = util.checkHasAccess(context, null, sId);
						//Added by Ganesh 1.0.2 Release End
						
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							showData=false;
						}
					}	
					
					//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- START
					//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
					/*if (!showData && util.isModificatinRequired()) {
						continue;
					}*/
					//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
					//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- END

					if(showData) 
					{
						util.formatData(sbId,sId);
						util.formatData(sbMasterProductPartName,sMasterProductPartName);
						util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
						util.formatData(sbMasterProductPartType,sMasterProductPartType);
						//Modified for Requirement #38398 by Manikanta -- START
						if(!bHasMasterPartAccess) {
							util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
							//SPEC: Added for Defect 41340 by Jwala -- START	
							util.formatData(sbMasterProductPartID,ConstantsUtil.NO_ACCESS);
							//SPEC: Added for Defect 41340 by Jwala -- END
							
							//Added by Jwala for the defect #43828 -- START
							util.formatData(sbMasterProductPartName,ConstantsUtil.NO_ACCESS);
							util.formatData(sbMasterProductPartRevision,ConstantsUtil.NO_ACCESS);
							util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
							util.formatData(sbMasterProductPartType,ConstantsUtil.NO_ACCESS);
							util.formatData(sbMasterProductPartID,ConstantsUtil.NO_ACCESS);
							util.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
							util.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
							util.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
							util.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
							util.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
							util.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
							util.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
							util.formatData(sbId,ConstantsUtil.NO_ACCESS);
							util.formatData(sbStabilityDocumentType,ConstantsUtil.NO_ACCESS);
							util.formatData(sbStabilityDocument,sStabilityDocument);
							//Added by Jwala for the defect #43828 -- END
						}else {
							util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
							//SPEC: Added for Defect 41340 by Jwala -- START	
							util.formatData(sbMasterProductPartID,sMasterProductID);
							//SPEC: Added for Defect 41340 by Jwala -- END
						}
						//Modified for Requirement #38398 by Manikanta -- END
						util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						util.formatData(sbTemperatureGroup,sTemperatureGroup);
						util.formatData(sbHumidityGroup,sHumidityGroup);
						util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						util.formatData(sbBoundaryConditions,sBoundaryConditions);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						//SPEC: <26.03.2021>: Guna Added for Defect 41790 Dev 18x.6   -- START
						util.formatData(sbStabilityDocumentType,sType);
						//SPEC: <26.03.2021>: Guna Added for Defect 41790 Dev 18x.6   -- END

					}else
					{
						if(util.isModificatinRequired()) 
						{  
							//Modified by Jwala for the defect #44028 -- START
							if(!bHasMasterPartAccess){
								util.formatData(sbMasterProductPartName,ConstantsUtil.NO_ACCESS);
								util.formatData(sbMasterProductPartRevision,ConstantsUtil.NO_ACCESS);
								util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
								util.formatData(sbMasterProductPartType,ConstantsUtil.NO_ACCESS);
								util.formatData(sbMasterProductPartID,ConstantsUtil.NO_ACCESS);
							}else{
								util.formatData(sbMasterProductPartName,sMasterProductPartName);
								util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
								util.formatData(sbMasterProductPartType,sMasterProductPartType);
								util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
								util.formatData(sbMasterProductPartID,sMasterProductID);
							}
							//Modified by Jwala for the defect #44028 -- END
							util.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
							util.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
							util.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
							util.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
							util.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
							util.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
							util.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
							util.formatData(sbId,ConstantsUtil.NO_ACCESS);
							util.formatData(sbStabilityDocumentType,ConstantsUtil.NO_ACCESS);
							util.formatData(sbStabilityDocument,sStabilityDocument);
						}else{
							util.formatData(sbId,ConstantsUtil.NO_ACCESS);
							util.formatData(sbMasterProductPartName,sMasterProductPartName);
							util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
							//SPEC: Added for Defect 41340 by Jwala -- START	
							util.formatData(sbMasterProductPartID,ConstantsUtil.NO_ACCESS);
							//Modified by Ganesh for Defect 42381 on Date <15/April/2021> ---->START
							//util.formatData(sbMasterProductPartType,sMasterProductPartType);
							util.formatData(sbMasterProductPartType,ConstantsUtil.NO_ACCESS);
							//Modified by Ganesh for Defect 42381 on Date <15/April/2021> ---->END
							//SPEC: Added for Defect 41340 by Jwala -- END
							util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
							//Modified by Ganesh for Defect 42381 on Date <15/April/2021> ---->START
							//util.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
							//util.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
							//util.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
							//util.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
							//util.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
							//util.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
							//util.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
							//util.formatData(sbStabilityDocument,ConstantsUtil.NO_ACCESS);
							util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
							util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
							util.formatData(sbTemperatureGroup,sTemperatureGroup);
							util.formatData(sbHumidityGroup,sHumidityGroup);
							util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
							util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
							util.formatData(sbBoundaryConditions,sBoundaryConditions);
							util.formatData(sbStabilityDocument,sStabilityDocument);
							//Modified by Ganesh for Defect 42381 on Date <15/April/2021> ---->END
							//SPEC: <26.03.2021>: Guna Added for Defect 41790 Dev 18x.6   -- START
							util.formatData(sbStabilityDocumentType,ConstantsUtil.NO_ACCESS);
							//SPEC: <26.03.2021>: Guna Added for Defect 41790 Dev 18x.6   -- END
						}
					}
					
				}
			}
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTNAME, sbMasterProductPartName.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTREV, sbMasterProductPartRevision.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPRODUCTPARTTITLE, sbMasterProductPartTitle.toString());
			//SPEC: Added for Defect 41340 by Jwala -- START	
			mpRefDoc.put(ConstantsUtil.MASTERPARTID, sbMasterProductPartID.toString());
			mpRefDoc.put(ConstantsUtil.MASTERPARTTYPE, sbMasterProductPartType.toString());
			//SPEC: Added for Defect 41340 by Jwala -- END
			mpRefDoc.put(ConstantsUtil.PRODUCTEXPDATEREQ, sbProductExpirationDataRequired.toString());
			mpRefDoc.put(ConstantsUtil.TOTALSHELFLIFEDAYS, sbTotalShelfLifeDays.toString());
			mpRefDoc.put(ConstantsUtil.TEMPERATUREGROUP, sbTemperatureGroup.toString());
			mpRefDoc.put(ConstantsUtil.HUMIDITYGROUP, sbHumidityGroup.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, sbTransportFreezeProtection.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTHEATPROTECTION, sbTransportHeatProtection.toString());
			mpRefDoc.put(ConstantsUtil.BOUNDARYCONDITIONS, sbBoundaryConditions.toString());
			mpRefDoc.put(ConstantsUtil.STABILITYDOCUMENT, sbStabilityDocument.toString());
			//SPEC: <26.03.2021>: Guna Added for Defect 41790 Dev 18x.6   -- START
			mpRefDoc.put(ConstantsUtilIRM.STABILITYTYPE, sbStabilityDocumentType.toString());
			//SPEC: <26.03.2021>: Guna Added for Defect 41790 Dev 18x.6   -- END

		}catch(Exception e){

			LOGGER.error("Exception in Program : DPPBO Method :getMasterPartStabilityDoc "+e);
			return new HashMap();
		}
		//return util.filterMapList(mpRefDoc);
		return mpRefDoc;
	}


	/**
	 * Method Name 			: getProductPartStabilityDoc
	 * Method Description 	: Getting the Reference Documents of the Part
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getProductPartStabilityDoc(Context context,Map resultMaps) 
	{
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();

		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.STR_IPCLASS);

		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTREVISION);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);

		boolean bHasOwnerShip = false;

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();

		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;


		Map<String, String> mpRefDoc = new HashMap();
		try
		{
			DomainObject doFOP = new DomainObject(sObjectId);
			//<11.20.2020>: Updated for #37451 START
			/*MapList mlRefDocs = doFOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			 */
			// Modified for the defect #41421 & 42902 By Jwala -- START
			MapList mlRefDocs = doFOP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.TYPE_PGPKGSTABILITYREPORT.concat(",").concat(ConstantsUtil.TYPE_PGTECHNICALRATIONAL), busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//<11.20.2020>: Updated for #37451 END
			// Modified for the defect #41421 & 42902 By Jwala -- END

			String sUser = util.getUserType();

			if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}

			if(util.isModificatinRequired()) 
			{
				mlRefDocs=util.filterPhase(mlRefDocs);
			}
			Iterator objectListItr = mlRefDocs.iterator();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbMasterProductPartName = new StringBuilder();
			StringBuilder sbMasterProductPartRevision = new StringBuilder();
			StringBuilder sbMasterProductPartTitle =new StringBuilder();
			StringBuilder sbProductExpirationDataRequired=new StringBuilder();
			StringBuilder sbTotalShelfLifeDays=new StringBuilder();
			StringBuilder sbTemperatureGroup=new StringBuilder();
			StringBuilder sbHumidityGroup=new StringBuilder();
			StringBuilder sbTransportFreezeProtection = new StringBuilder();
			StringBuilder sbTransportHeatProtection = new StringBuilder();
			StringBuilder sbBoundaryConditions = new StringBuilder();
			StringBuilder sbStabilityDocument = new StringBuilder();
			// Guna Added for Defect 38534  18x.5.2 Release -- START
			StringBuilder sbStabilityDocumentType = new StringBuilder();
			// Guna Added for Defect 38534  18x.5.2 Release -- END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sId    =  (String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	 =	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));

				String sMasterProductPartName    =  validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartRevision    =   validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTREVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME) : ConstantsUtil.EMPTY_STRING;
				String sMasterProductPartTitle		=	validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTITLE))?(String)resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTITLE) : ConstantsUtil.EMPTY_STRING;
				String sProductExpirationDataRequired	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
				String sTotalShelfLifeDays		=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
				String sTemperatureGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
				String sHumidityGroup	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
				String sTransportFreezeProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
				String sTransportHeatProtection	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
				String sBoundaryConditions = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
				String sStabilityDocument = (String)objectMap.get(ConstantsUtil.SELECT_NAME);

				StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				boolean showData = false;
				
				//Added for 37451 - Start
				if(sType.equalsIgnoreCase("pgPKGDevelopmentOther") || sType.equalsIgnoreCase("pgPKGProductReadiness")){
					continue;
				}
				//Added for 37451 - ENd

				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}
				//Added by Jwala for Defect 42316 -- START
				if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
					continue;
				}
				//Added by Jwala for Defect 42316 -- END

				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)&& !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					String sLangBuffer =ConstantsUtil.EMPTY_STRING;
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;

					if (util.isModificatinRequired()) 
					{
						//Added by Ganesh 1.0.2 Release Start
						//bHasOwnerShip = util.checkOwnerShip(sbCompany,slEachOwnership);
						//bHasOwnerShip = util.checkHasAccess(context, null, sId);
						//Added by Ganesh 1.0.2 Release End
						showData=util.checkHasAccess(context, null, sId);
						//Modified by Jwala for Internal Defect fixes -- START
						/*if(sCurrent!=ConstantsUtil.STATE_RELEASE) {
							bHasOwnerShip=false;
						}
						*/
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							bHasOwnerShip=false;
						}
						//Modified by Jwala for Internal Defect fixes -- END
						
						//Commented by Jwala for Defect 43737 fixes -- START
						/*if(bHasOwnerShip) 
						{
							util.formatData(sbId,sId);
							util.formatData(sbMasterProductPartName,sMasterProductPartName);
							util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
							util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
							util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
							util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
							util.formatData(sbTemperatureGroup,sTemperatureGroup);
							util.formatData(sbHumidityGroup,sHumidityGroup);
							util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
							util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
							util.formatData(sbBoundaryConditions,sBoundaryConditions);
							util.formatData(sbStabilityDocument,sStabilityDocument);
							// Guna Added for Defect 38534  18x.5.2 Release -- START
							util.formatData(sbStabilityDocumentType,sType);
							// Guna Added for Defect 38534  18x.5.2 Release -- END
						}*/
						//Commented by Jwala for Defect 43737 fixes -- END
					}else if(sct.isStaffAUGUser()) {
						/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}*/
						//Added by Ganesh 1.0.2 Release Start
						showData=util.checkHasAccess(context, null, sId);
						//Added by Ganesh 1.0.2 Release End
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							showData=false;
						}
					}else {
						/*StringList slHIRTypes = new StringList();
					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

					if(slHIRTypes.contains(sType)) {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}else {
						showData=true;
					}*/
						//Added by Ganesh 1.0.2 Release Start
						showData=util.checkHasAccess(context, null, sId);
						//Added by Ganesh 1.0.2 Release End
					}	
					
					//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- START
					//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
					/*if (!showData && util.isModificatinRequired()) {
						continue;
					}*/
					//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
					//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- END

					if(showData) 
					{
						util.formatData(sbId,sId);
						util.formatData(sbMasterProductPartName,sMasterProductPartName);
						util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
						util.formatData(sbMasterProductPartTitle,sMasterProductPartTitle);
						util.formatData(sbProductExpirationDataRequired,sProductExpirationDataRequired);
						util.formatData(sbTotalShelfLifeDays,sTotalShelfLifeDays);
						util.formatData(sbTemperatureGroup,sTemperatureGroup);
						util.formatData(sbHumidityGroup,sHumidityGroup);
						util.formatData(sbTransportFreezeProtection,sTransportFreezeProtection);
						util.formatData(sbTransportHeatProtection,sTransportHeatProtection);
						util.formatData(sbBoundaryConditions,sBoundaryConditions);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						// Guna Added for Defect 38534  18x.5.2 Release -- START
						util.formatData(sbStabilityDocumentType,sType);
						// Guna Added for Defect 38534  18x.5.2 Release -- END

					}else
					{
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbMasterProductPartName,sMasterProductPartName);
						util.formatData(sbMasterProductPartRevision,sMasterProductPartRevision);
						util.formatData(sbMasterProductPartTitle,ConstantsUtil.NO_ACCESS);
						util.formatData(sbProductExpirationDataRequired,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTotalShelfLifeDays,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTemperatureGroup,ConstantsUtil.NO_ACCESS);
						util.formatData(sbHumidityGroup,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTransportFreezeProtection,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTransportHeatProtection,ConstantsUtil.NO_ACCESS);
						util.formatData(sbBoundaryConditions,ConstantsUtil.NO_ACCESS);
						// Jwala Modified for Defect 42884  18x.5.2 Release -- START
						//util.formatData(sbStabilityDocument,ConstantsUtil.NO_ACCESS);
						util.formatData(sbStabilityDocument,sStabilityDocument);
						// Jwala Modified for Defect 42884  18x.5.2 Release -- END
						// Guna Added for Defect 38534  18x.5.2 Release -- START
						util.formatData(sbStabilityDocumentType,sType);
						// Guna Added for Defect 38534  18x.5.2 Release -- END
					}
				}
			}
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.PRODUCTEXPDATEREQ, sbProductExpirationDataRequired.toString());
			mpRefDoc.put(ConstantsUtil.TOTALSHELFLIFEDAYS, sbTotalShelfLifeDays.toString());
			mpRefDoc.put(ConstantsUtil.TEMPERATUREGROUP, sbTemperatureGroup.toString());
			mpRefDoc.put(ConstantsUtil.HUMIDITYGROUP, sbHumidityGroup.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, sbTransportFreezeProtection.toString());
			mpRefDoc.put(ConstantsUtil.TRANSPORTHEATPROTECTION, sbTransportHeatProtection.toString());
			mpRefDoc.put(ConstantsUtil.BOUNDARYCONDITIONS, sbBoundaryConditions.toString());
			mpRefDoc.put(ConstantsUtil.STABILITYDOCUMENT, sbStabilityDocument.toString());
			// Guna Added for Defect 38534  18x.5.2 Release -- START
			mpRefDoc.put(ConstantsUtil.TYPE, sbStabilityDocumentType.toString());
			// Guna Added for Defect 38534  18x.5.2 Release -- END
		}catch(Exception e){

			LOGGER.error("Exception in Program : DPPBO Method :getProductPartStabilityDoc "+e);
			return new HashMap();
		}
		//return util.filterMapList(mpRefDoc);
		return mpRefDoc;
	}


	/**
	 * Method Name 			: getCountryClearanceResult
	 * Method Description 	: 
	 * @param resultMaps
	 * @return
	 */
	public Map getMarketClearanceResult(Context context, DomainObject doDPP)
	{

		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODIFIEDDATE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODIFIEDBY);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME);

		StringList slRelSelects = new StringList();

		StringBuilder sbMarketName = new StringBuilder();
		StringBuilder sbClearanceNum = new StringBuilder();
		StringBuilder sbOveralClearence = new StringBuilder();
		StringBuilder sbGPSApproval = new StringBuilder();
		StringBuilder sbManuSite = new StringBuilder();
		StringBuilder sbPackSite = new StringBuilder();
		StringBuilder sbComments = new StringBuilder();
		StringBuilder sbRestrictions = new StringBuilder();
		StringBuilder sbRegExpDate = new StringBuilder();
		StringBuilder sbRegStatus = new StringBuilder();
		StringBuilder sbMPDTNumber = new StringBuilder();
		StringBuilder sbPRODRegClass = new StringBuilder();
		StringBuilder sbRegrewlleadTime = new StringBuilder();
		StringBuilder sbRegirewlStatus = new StringBuilder();
		StringBuilder sbRegProductName = new StringBuilder();

		Map<String, String> mapCountryClearanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			MapList mapList = doDPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PGPRODUCTCOUNTRYCLEARANCE, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, false, true, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			Iterator objectListItr = mapList.iterator();
			while(objectListItr.hasNext())
			{
				Map resultMaps = (Map) objectListItr.next();

				/*
				String strMarketName    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_NAME));
				String strClearanceNum    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_CT_NUM));
				String strOveralClearence    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_OVERALL_CLEARENCE));
				String strGPSApproval   =  validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.STR_COUNTRY_APPROVAL_STATUS));
				String strManuSite    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_MANU_SITE));
				String strPackSite    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PACK_SITE));
				String strComments    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_CLEAR_COMMENT));
				String strRestrictions    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PLANT_REST));
				String strRegExpDate    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_REG_DATE));
				String strRegStatus    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_REG_STATUS));
				String strMPDTNumber    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_REG_NUM));
				String strPRODRegClass    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_REG_CLASS));
				String strRegrewlleadTime    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDDATE));
				String strRegirewlStatus    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_PROD_PGMODIFIEDBY));
				String strRegProductName    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_COUNTRY_REGISTEREDPRODUCTNAME));
				 */

				String strMarketName    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_NAME));
				String strClearanceNum    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCTNUMBER));
				String strOveralClearence    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERALLCLEARANCESTATUS));
				String strGPSApproval   =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPSRAAPPROVALSTATUS));
				String strManuSite    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMANUFACTURINGSITE));
				String strPackSite    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGSITE));
				String strComments    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLEARANCECOMMENT));
				String strRestrictions    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTRESTRICTION));
				String strRegExpDate    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONENDDATE));
				String strRegStatus    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTRATIONSTATUS));
				String strMPDTNumber    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOUNTRYPRODUCTREGISTRATIONNUMBER));
				String strPRODRegClass    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTREGULATORYCLASSIFICATION));
				String strRegrewlleadTime    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODIFIEDDATE));
				String strRegirewlStatus    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODIFIEDBY));
				String strRegProductName    =  validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREGISTEREDPRODUCTNAME));

				util.formatData(sbMarketName, strMarketName);
				util.formatData(sbClearanceNum, strClearanceNum);
				util.formatData(sbOveralClearence, strOveralClearence);
				util.formatData(sbGPSApproval, strGPSApproval);
				util.formatData(sbManuSite, strManuSite);
				util.formatData(sbPackSite, strPackSite);
				util.formatData(sbComments, strComments);
				util.formatData(sbRestrictions, strRestrictions);
				util.formatData(sbRegExpDate, strRegExpDate);
				util.formatData(sbRegStatus, strRegStatus);
				util.formatData(sbMPDTNumber, strMPDTNumber);
				util.formatData(sbPRODRegClass, strPRODRegClass);
				util.formatData(sbRegrewlleadTime, strRegrewlleadTime);
				util.formatData(sbRegirewlStatus, strRegirewlStatus);
				util.formatData(sbRegProductName, strRegProductName);

				mapCountryClearanceResult.put(ConstantsUtil.MARKET_NAME, sbMarketName.toString());
				mapCountryClearanceResult.put(ConstantsUtil.CLEARANCE_NUMBER, sbClearanceNum.toString());
				mapCountryClearanceResult.put(ConstantsUtil.OVERALL_CLEARENCE, sbOveralClearence.toString());
				mapCountryClearanceResult.put(ConstantsUtil.GPS_APPROVAL, sbGPSApproval.toString());
				mapCountryClearanceResult.put(ConstantsUtil.MANU_SITE, sbManuSite.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PACK_SITE, sbPackSite.toString());
				mapCountryClearanceResult.put(ConstantsUtil.COMMENTS, sbComments.toString());
				mapCountryClearanceResult.put(ConstantsUtil.RESTRICTIONS, sbComments.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_EXP_DATE, sbRegExpDate.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REG_STATUS, sbRegStatus.toString());
				mapCountryClearanceResult.put(ConstantsUtil.MARKETPRODUCTNUMBER, sbMPDTNumber.toString());
				mapCountryClearanceResult.put(ConstantsUtil.PROD_REG_CLASS, sbPRODRegClass.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALLEADTIME, sbRegrewlleadTime.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTRATIONRENEWALSTATUS, sbRegirewlStatus.toString());
				mapCountryClearanceResult.put(ConstantsUtil.REGISTEREDPRODUCTNAME, sbRegProductName.toString());
			}
		}catch(Exception e){

			LOGGER.error("Error from DeviceProductPartBO:  getCountryClearanceResult"+e);
			return new HashMap();
		}
		return mapCountryClearanceResult;
	}

	//SPEC: <10.22.2020>: Added for req 18x.5 ## -- END

	//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
	/*public Map<String, String> parseSubstitute(Context context,MapList mapList) throws Exception 
		{
	    	StringValidatorUtil validator = new StringValidatorUtil();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
	    	try {
				Iterator objectListItr = mapList.iterator();

				StringBuilder sbEBOMName = new StringBuilder();
				StringBuilder sbEBOMParentName = new StringBuilder();
				StringBuilder sbEBOMParentRev = new StringBuilder();
				StringBuilder sbEBOMParentTitle = new StringBuilder();
				StringBuilder sbEBOMId = new StringBuilder();
				StringBuilder sbEBOMParentId = new StringBuilder();
				StringBuilder sbEBOMRefDoc= new StringBuilder();
				StringBuilder sbEBOMTitle = new StringBuilder();
				StringBuilder sbEBOMType = new StringBuilder();
				StringBuilder sbEBOMQTY = new StringBuilder();
				StringBuilder sbEBOMBuom = new StringBuilder();
				StringBuilder sbEBOMCommnts = new StringBuilder();
				StringBuilder sbEBOMSubType= new StringBuilder();
				StringBuilder sbEBOMEffectDate= new StringBuilder();
				StringBuilder sbEBOMUntilDate= new StringBuilder();
				StringBuilder sbEBOMCobNum= new StringBuilder();
				StringBuilder sbEBOMChildRev= new StringBuilder();
				StringBuilder sbEBOMRevRelDt= new StringBuilder();
				StringBuilder sbEBOMSubFor= new StringBuilder();
				StringBuilder sbEBOMParentType = new StringBuilder();
				StringBuilder sbEBOMChg = new StringBuilder();
				StringBuilder sbEBOMSFSubType= new StringBuilder();

				StringBuilder sbMinqty= new StringBuilder();
				StringBuilder sbMaxqty= new StringBuilder();
				StringBuilder sbRF= new StringBuilder();
				StringBuilder sbMF= new StringBuilder();
				StringBuilder sbCert= new StringBuilder();

				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					boolean showData = false;
					boolean bHasOwnership=false;

					String sChildExists=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
					if(null!=objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION)) {

					String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION).getClass().getSimpleName();
					if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) {
						//String
						if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
							String sChildName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
							String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
							String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
							String sChildId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
							String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
							//String sParentTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	

							String sReleaseDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE));

						//	boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
							//Access was corrected by Chandra but for EBP columns has to be confirmed which can be shown
	  						boolean bChildHasAccess = util.checkHasAccess(context,null,sChildId);

							//SPEC: <11.04.2020>: Added for req 18x.5 ## -- START
							sReleaseDate =validator.DateFormatter(sReleaseDate);
							//SPEC: <11.04.2020>: Added for req 18x.5 ## -- END
							String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;

							String sChildRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
							String sCombinationNum=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
							//	String sChildTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							String sChildTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	

							String sChildType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));

							//Modified for Defect# 37591 -- START
							//String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
							String sSUBType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
							//Modified for Defect# 37591 -- END

							String sQTY =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
							String sBASEUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
							String sEffectvityDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
							String sUntilDate=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							String sRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
							//String sComments=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
							String sComments=validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END

							String sOC =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
							sOC = util.replaceSpecialSymbols(sOC);
							String sRDOC = sRefDoc+ConstantsUtil.SYMBL_COLON+sOC;
							String sIpClass =validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS)));

							String sChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
							String sSFSubType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
							String strMinqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
							String strMaxqty =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
							String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
							String strRF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);

							if(!bChildHasAccess) {
								//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START
								sChildId    = ConstantsUtil.NO_ACCESS;
								sChg = ConstantsUtil.NO_ACCESS;
								//sChildTitle = ConstantsUtil.NO_ACCESS;
								//sChildRev = ConstantsUtil.NO_ACCESS;
								//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END
							}


							//Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
	  						 showData = util.checkHasAccess(context,null,sParentID);



							if(util.isModificatinRequired())
							{
								SecurityService sec = new SecurityService();
								String sComp = sec.getUserCauthorities();
								StringList slUserOwnership=util.filterOwnerShip(sComp);

								String sFormulaPropagate = sParentID;
								if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
								}

								if(!sFormulaPropagate.isEmpty()) {
									bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
								}

								if(!bHasOwnership)
								{
									sParentType = ConstantsUtil.NO_ACCESS;
									sParentID = ConstantsUtil.NO_ACCESS;
									//sChildId    = ConstantsUtil.NO_ACCESS;
									sParentName = ConstantsUtil.NO_ACCESS;
									sParentRev = ConstantsUtil.NO_ACCESS;
									sParentTitle = ConstantsUtil.NO_ACCESS;
									sCombinationNum = ConstantsUtil.NO_ACCESS;
									//sChildTitle = ConstantsUtil.NO_ACCESS;
									sSUBType = ConstantsUtil.NO_ACCESS;
									sEffectvityDate = ConstantsUtil.NO_ACCESS;
									sRevRelease = ConstantsUtil.NO_ACCESS;
									sUntilDate = ConstantsUtil.NO_ACCESS;
									sRDOC = ConstantsUtil.NO_ACCESS;
									sQTY = ConstantsUtil.NO_ACCESS;
									sBASEUOM = ConstantsUtil.NO_ACCESS;
									//sChildRev = ConstantsUtil.NO_ACCESS;
									sChg = ConstantsUtil.NO_ACCESS;
									sSFSubType = ConstantsUtil.NO_ACCESS;
									strMinqty = ConstantsUtil.NO_ACCESS;
									strMaxqty = ConstantsUtil.NO_ACCESS;
									strMF = ConstantsUtil.NO_ACCESS;
									strRF = ConstantsUtil.NO_ACCESS;

							    }
							}else if(sct.isStaffAUGUser()) {

								if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else {
									showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
								}
							}else {
								StringList slHIRTypes = new StringList();
								slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
								slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
								slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
								slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

								if(slHIRTypes.contains(sParentType)) {
									if(sChildType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
										showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
									}else {
										showData=util.checkInternalUserAcess(sUserlicense,sIpClass);
									}
								}else {
									showData=true;
								}

							}

							if(!showData){
								sParentID = ConstantsUtil.NO_ACCESS;

								//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
								//sChildId    = ConstantsUtil.NO_ACCESS;
								//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START

								sParentType = ConstantsUtil.NO_ACCESS;
								sParentID = ConstantsUtil.NO_ACCESS;
								sChildId    = ConstantsUtil.NO_ACCESS;
								//sParentName = ConstantsUtil.NO_ACCESS;
								//sParentRev = ConstantsUtil.NO_ACCESS;
								sParentTitle = ConstantsUtil.NO_ACCESS;
								sCombinationNum = ConstantsUtil.NO_ACCESS;
								sChildTitle = ConstantsUtil.NO_ACCESS;
								sSUBType = ConstantsUtil.NO_ACCESS;
								sEffectvityDate = ConstantsUtil.NO_ACCESS;
								sRevRelease = ConstantsUtil.NO_ACCESS;
								sUntilDate = ConstantsUtil.NO_ACCESS;
								sRDOC = ConstantsUtil.NO_ACCESS;
								sComments = ConstantsUtil.NO_ACCESS;
							}

							sChildType = util.mapType(sChildType);

							util.formatData(sbEBOMName,sChildName);
							util.formatData(sbEBOMType,sChildType);
							util.formatData(sbEBOMQTY,sQTY);
							util.formatData(sbEBOMBuom,sBASEUOM);
							util.formatData(sbEBOMChildRev,sChildRev);

							util.formatData(sbEBOMParentType,sParentType);
							util.formatData(sbEBOMParentId,sParentID);
							util.formatData(sbEBOMId,sChildId);
							util.formatData(sbEBOMParentName,sParentName);
							util.formatData(sbEBOMParentRev,sParentRev);
							util.formatData(sbEBOMParentTitle,sParentTitle);
							util.formatData(sbEBOMCobNum,sCombinationNum);
							util.formatData(sbEBOMTitle,sChildTitle);
							util.formatData(sbEBOMSubType,sSUBType);
							util.formatData(sbEBOMRevRelDt,sRevRelease);
							util.formatData(sbEBOMEffectDate,validator.DateFormatter(sEffectvityDate));
							util.formatData(sbEBOMUntilDate,validator.DateFormatter(sUntilDate));
							util.formatData(sbEBOMRefDoc,sRDOC);
							util.formatData(sbEBOMCommnts,sComments);
							util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);

							//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
							util.formatData(sbEBOMChg,sChg);
							util.formatData(sbEBOMSFSubType,sSFSubType);
							//SPEC: 11/04/2020: Added for 18x.5 DEV -- END
						//}
						}
					}else {
						//StringList
						String sParentType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
						String sParentName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						String sParentID =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
						String sParentRev =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						//String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
						String sParentTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));


						 //Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
	  						showData = util.checkHasAccess(context,null,sParentID);
	  						//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	
						String sReleaseDate =validator.DateFormatter(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)));
						String sRevRelease = sParentRev+ConstantsUtil.SYMBL_COLON+sReleaseDate;
						if(sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)|| sChildExists.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ){
							StringList slChildId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
							for(int i =0; i<slChildId.size(); i++) {
								String sEachChildId = slChildId.getElement(i);

								//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
//								DomainObject doEachChild = new DomainObject(sEachChildId);
//								DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//								StringList slSelect = new StringList();
//								slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//								Map mpIpClass = doEachChild.getInfo(context, slSelect);
//								StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
//								StringsIpClass = doEachChild.getInfo(contexts"to["+ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM+"].from.name");
//								DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM);
								//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END

								StringList slChildType =(StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
								//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--START	
								//Access was corrected by Chandra  but for EBP columns has to be confirmed which can be shown
								//boolean bChildHasAccess = checkSubstituteHasAccess(context,objectMap);
	  							boolean 	bChildHasAccess = util.checkHasAccess(context,null,sEachChildId);


								if(util.isModificatinRequired())
								{
									SecurityService sec = new SecurityService();
									String sComp = sec.getUserCauthorities();
									StringList slUserOwnership=util.filterOwnerShip(sComp);

									String sFormulaPropagate = sParentID;
									if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										sFormulaPropagate = util.getFormulaPropagate(context, sParentID);
									}

									if(!sFormulaPropagate.isEmpty()) {
										bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
									}

									if(bHasOwnership)
									{
										showData=true;
								    }
								}else if(sct.isStaffAUGUser()) {
									if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
										String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
										showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
									}else {
										showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
									}

								}else {
									StringList slHIRTypes = new StringList();
									slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
									slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
									slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
									slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
									slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
									if(slHIRTypes.contains(slChildType.getElement(i))) {
										if(slChildType.getElement(i).equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
											String sFormulaClassif = util.getFormulaPropagateClassification(context, sParentID);
											showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
										}else {
											showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
										}
									}else {
										showData=true;
									}

								}
	  							//SPEC Added on 12-Dec-2020 by Chandra for Defect 37782 ##--END	

								//SPEC: 11/04/2020: Commented for 18x.5 DEV -- START
								if(!showData) {
									sEachChildId=ConstantsUtil.NO_ACCESS;
								}
								//SPEC: 11/04/2020: Commented for 18x.5 DEV -- END
								String sChildSubType ="";
								StringList slChildName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
								StringList slChildRev=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION));
								StringList slCombinationNum=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
								StringList slChildTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
								//StringList slChildType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));

								//Modified for Defect# 37591 -- START
								//StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE));
								StringList slSUBType =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBST_PGASSEMBLYTYPE));
								//Modified for Defect# 37591 -- END

								StringList slQTY =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY));
								StringList slBASEUOM =(StringList)(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM));
								StringList slEffectvityDate =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY));
								StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
								String slRefDoc =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC));
								StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
								String sOC =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT));
								sOC = util.replaceSpecialSymbols(sOC);
								String sRDOC = slRefDoc+ConstantsUtil.SYMBL_COLON+sOC;

								StringList sChg = (StringList) objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
								//StringList sSFSubType = (StringList) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
								String sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
	  							//12/04/2020 Guna added for DPP defect -- START
								String strMF =(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
								DomainObject domSubstitute =DomainObject.newInstance(context, sEachChildId);
								//String strMFObjId =(String)objectMap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_APPLICATION);
								String sFunction = ConstantsUtil.EMPTY_STRING;
								sFunction =domSubstitute.getInfo(context, ConstantsUtil.REPORTED_FUNCTION);

								try
								{
									if (UIUtil.isNotNullAndNotEmpty(strMFObjId)) 
									{
										sFunction=util.getIdFromPhysicalIdFunction(context,strMFObjId);
									}
								}catch(Exception e){
									sFunction=ConstantsUtil.EMPTY_STRING;
								}
								//12/04/2020 Guna added for DPP defect -- END
								//SPEC: 11/04/2020: Added for 18x.5 DEV -- START
								if(bChildHasAccess) {
									String sChildType = util.mapType(slChildType.get(i));
									util.formatData(sbEBOMName,slChildName.get(i));
									util.formatData(sbEBOMType,sChildType);
									util.formatData(sbEBOMChildRev,slChildRev.get(i));
									util.formatData(sbEBOMId,sEachChildId);
									util.formatData(sbEBOMTitle,slChildTitle.get(i));
									//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
	  								util.formatData(sbEBOMChg,sChg.get(i));
	  								//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
								}
								else
								{
									//String sChildType = util.mapType(slChildType.get(i));
									util.formatData(sbEBOMName,slChildName.get(i));
									util.formatData(sbEBOMType,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMChildRev,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);

									String sChildType = util.mapType(slChildType.get(i));
									util.formatData(sbEBOMType,sChildType);
									util.formatData(sbEBOMChildRev,slChildRev.get(i));
									util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMTitle,slChildTitle.get(i));
									//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
									util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
		  							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
								}

								//SPEC: 11/30/2020: Modified by Chandra for Defect : 37607 -- START
								if(null!=slSUBType)
								{
									sChildSubType=slSUBType.get(i);
									String sChildType=slChildType.get(i);

			 					     if (null != sChildType && ("Raw Material").equals(sChildType)) 
			 						 {       
			 					    	sChildSubType="Raw";  
			 					     }
			 					     else if (null != sChildType && ("pgRawMaterial").equals(sChildType)) 
									 {       
			 					    	sChildSubType="Raw";  
								     }
			 					     else if (null != sChildType && ("pgPackingMaterial").equals(sChildType)) 
			 						 {
			 					    	sChildSubType="Packaging";
			 					     } 
			 					    else if("Packaging Material Part".equalsIgnoreCase(sChildType)) {
			 					    	sChildSubType="Packaging";
			 	 					    }
			 					    else {
			 					    	sChildSubType =sChildSubType;
			 					     }

			 					     if ("pgFinishedProduct".equals(sChildType))
			  						{
			  							if("".equals(sChildSubType)){
			  							sChildSubType="Finished Product";
			  							}
			  							else if("FWIP-Finished Work in Process".equals(sChildSubType)) {
			  							sChildSubType="FWIP-Finished Work in Process";		
			  							}
			  							else if("Purchased Subassembly".equals(sChildSubType)){
			  							sChildSubType="Purchased Subassembly";
			  							}
			  							else if("Purchased and/or Produced Subassembly".equals(sChildSubType)){
			  							sChildSubType="Purchased and/or Produced Subassembly";	
			  							}				
			  						}
								}


  								if (null != sParentType && ("Raw Material").equals(sParentType)) 
  								 {       
  							    	sSFSubType="Raw";  
  							     }
  								     else if (null != sParentType && ("pgRawMaterial").equals(sParentType)) 
  								 {       
  								    	sSFSubType="Raw";  
  							     }
  							     else if (null != sParentType && ("pgPackingMaterial").equals(sParentType)) 
  								 {
  							    	sSFSubType="Packaging";
  							     } 
  							   else if("Packaging Material Part".equalsIgnoreCase(sParentType)) {
  			 					   	sSFSubType="Packaging";
  			 					    }
  							   else {
  								 sSFSubType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
		 					     }

  							  if ("pgFinishedProduct".equals(sParentType))
  								{
  									if("".equals(sSFSubType)){
  										sSFSubType="Finished Product";
  									}
  									else if("FWIP-Finished Work in Process".equals(sSFSubType)) {
  										sSFSubType="FWIP-Finished Work in Process";		
  									}
  									else if("Purchased Subassembly".equals(sSFSubType)){
  										sSFSubType="Purchased Subassembly";
  									}
  									else if("Purchased and/or Produced Subassembly".equals(sSFSubType)){
  										sSFSubType="Purchased and/or Produced Subassembly";	
  									}				
  								}

								//SPEC: 11/04/2020: Added for 18x.5 DEV -- START

								if(showData) {
									//String sChildType = util.mapType(slChildType.get(i));
									//formatData(sbEBOMName,slChildName.get(i));
									//formatData(sbEBOMType,sChildType);
									util.formatData(sbEBOMQTY,slQTY.get(i));
									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
									//formatData(sbEBOMChildRev,slChildRev.get(i));
									util.formatData(sbEBOMParentType,sParentType);
									util.formatData(sbEBOMParentId,sParentID);
									//formatData(sbEBOMId,sEachChildId);
									util.formatData(sbEBOMParentName,sParentName);
									util.formatData(sbEBOMParentRev,sParentRev);
									util.formatData(sbEBOMParentTitle,sParentTitle);
									util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
									//formatData(sbEBOMTitle,slChildTitle.get(i));
									//util.formatData(sbEBOMSubType,slSUBType.get(i));
									util.formatData(sbEBOMSubType,sChildSubType);
									util.formatData(sbEBOMRevRelDt,sRevRelease);
									util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
									util.formatData(sbEBOMUntilDate,validator.DateFormatter(slUntilDate.get(i)));
									util.formatData(sbEBOMRefDoc,sRDOC);

									//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- START
									//util.formatData(sbMF,strMF);
									//util.formatData(sbRF,sFunction);
									util.formatData(sbRF,strRF.get(i));
									util.formatData(sbMF,sFunction);
									//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- END

									util.formatData(sbEBOMCommnts,slComments.get(i));
									util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
									util.formatData(sbEBOMChg,sChg.get(i));
									util.formatData(sbEBOMSFSubType,sSFSubType);

								}else {
									///String sChildType = util.mapType(slChildType.get(i));
									//formatData(sbEBOMName,slChildName.get(i));
									//formatData(sbEBOMType,sChildType);
									util.formatData(sbEBOMQTY,slQTY.get(i));
									util.formatData(sbEBOMBuom,slBASEUOM.get(i));
									//formatData(sbEBOMChildRev,slChildRev.get(i));
									util.formatData(sbEBOMParentType,sParentType);
									util.formatData(sbEBOMParentId,ConstantsUtil.NO_ACCESS);
									//util.formatData(sbEBOMId,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMParentName,sParentName);
									util.formatData(sbEBOMParentRev,sParentRev);

									//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- START
									//util.formatData(sbMF,strMF);
									//util.formatData(sbRF,sFunction);
									util.formatData(sbRF,strRF.get(i));
									util.formatData(sbMF,sFunction);
									//SPEC: Modified for Defect#37293 1.0.2 Release - Jwala -- END

									//<12.04.2020> Guna modified -- START
									util.formatData(sbEBOMParentTitle,sParentTitle);
									util.formatData(sbEBOMCobNum,slCombinationNum.get(i));
									//formatData(sbEBOMTitle,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMSubType,sChildSubType);
									util.formatData(sbEBOMRevRelDt,sRevRelease);
									util.formatData(sbEBOMEffectDate,validator.DateFormatter(slEffectvityDate.get(i)));
									util.formatData(sbEBOMUntilDate,validator.DateFormatter(slUntilDate.get(i)));
									util.formatData(sbEBOMRefDoc,sRDOC);
									util.formatData(sbEBOMCommnts,slComments.get(i));
									util.formatData(sbEBOMSubFor,sParentName+ConstantsUtil.SYMBL_COLON+sParentRev);
									util.formatData(sbEBOMChg,ConstantsUtil.NO_ACCESS);
									util.formatData(sbEBOMSFSubType,sSFSubType);
									//<12.04.2020> Guna modified -- END

								}
							}
						}
					}
					}

				}
				mpEBOMResult.put(ConstantsUtil.SP, sbEBOMName.toString());
				mpEBOMResult.put(ConstantsUtil.SF_TYPE, sbEBOMParentType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SP_ID, sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.SF_ID, sbEBOMParentId.toString());
				mpEBOMResult.put(ConstantsUtil.REV, sbEBOMChildRev.toString());
				mpEBOMResult.put(ConstantsUtil.SCN, sbEBOMCobNum.toString());
				mpEBOMResult.put(ConstantsUtil.SCNTITLE, sbEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.SST, sbEBOMSubType.toString());
				mpEBOMResult.put(ConstantsUtil.QTY, sbEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbEBOMBuom.toString());
				mpEBOMResult.put(ConstantsUtil.STARTDATE, sbEBOMEffectDate.toString());
				mpEBOMResult.put(ConstantsUtil.ENDDATE, sbEBOMUntilDate.toString());
				mpEBOMResult.put(ConstantsUtil.REFDES, sbEBOMRefDoc.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS, sbEBOMCommnts.toString());
				mpEBOMResult.put(ConstantsUtil.SF, sbEBOMParentName.toString());
				mpEBOMResult.put(ConstantsUtil.SFREV, sbEBOMParentRev.toString());
				mpEBOMResult.put(ConstantsUtil.TITLE, sbEBOMParentTitle.toString());
				mpEBOMResult.put(ConstantsUtil.RELEASEDATE, sbEBOMRevRelDt.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sbEBOMSubFor.toString());
				mpEBOMResult.put(ConstantsUtil.CHG, sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.SF_SST, sbEBOMSFSubType.toString());

				mpEBOMResult.put(ConstantsUtil.MIN, sbMinqty.toString());
				mpEBOMResult.put(ConstantsUtil.MAX, sbMaxqty.toString());
				mpEBOMResult.put(ConstantsUtil.REPORTEDFUNCTION, sbRF.toString());
				mpEBOMResult.put(ConstantsUtil.FUNCTIONS, sbMF.toString());
				mpEBOMResult.put(ConstantsUtil.CERTIFICATIONS, sbCert.toString());

	    	}catch(Exception e) {
	    		LOGGER.info("EXCEPTION IN InnerPackBO : parseSubstitute: "+e);
	    	}
			return util.filterMapList(mpEBOMResult);

		}*/


	public boolean checkSubstituteHasAccess(Context context, Map objectMap) {

		StringBuilder  sbReturnVal = new StringBuilder();
		boolean showData = false;
		try
		{
			StringValidatorUtil validator = new StringValidatorUtil();

			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			String sComp = sct.getUserCauthorities();
			StringList slUserOwnership=util.filterOwnerShip(sComp);

			if(objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID))
			{
				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID).getClass().getSimpleName();
				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
				{
					String strSubPartType = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
					String strSubPartId = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));

					DomainObject doEachChild = new DomainObject(strSubPartId);
					DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					StringList slSelect = new StringList();
					slSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					Map mpIpClass = doEachChild.getInfo(context, slSelect);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					doEachChild.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					StringList sIpClass = (StringList) mpIpClass.get(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
					//commented by Ganesh for security impl----->start
					/*if(util.isModificatinRequired())
						{
							//For EBP User
							showData = util.checkOwnerShip(context, slUserOwnership, strSubPartId);

						}else if(sct.isStaffAUGUser())
						{
							//For Staff Aug USer check 
							if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
								//Validation for Hir checks on Formulation
								String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
								showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
							}else
							{
								//Validation for Hir checks for other than Formulation
								showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
							}
						}else 
						{
							//For Internal User check
							if(slHIRTypes.contains(strSubPartType)) 
							{
								//Validation for Hir checks on Formulation
								if(strSubPartType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
									String sFormulaClassif = util.getFormulaPropagateClassification(context, strSubPartId);
									showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
								}else 
								{
									//Validation for Hir checks for other than Formulation
									showData=util.checkInternalUserAcess(sUserlicense,validator.replaceSpecialSymbols(sIpClass.toString()));
								}
							}else 
							{
								//If it is Non-Hir we can show without checks for internal user
								showData=true;
							}
						}*/
					//commented by Ganesh for security impl----->end
					//commented by Ganesh for security impl----->start
					showData = util.checkHasAccess(context, null, strSubPartId);
					//commented by Ganesh for security impl----->end

					//							
				}//close bracket for string
			}else
			{	//If no Substitue found
				return showData;
			}

		}catch(Exception e){

			LOGGER.error("Error from DPPBO :  checkSubstituteHasAccess" + e);
			return showData;
		}
		return showData;
	}
	//SPEC: 11/04/2020: Added for 18x.5 DEV -- END

	/**
	 * Added by Jwala for SR2018x.6 Dev getGPSAssessments method used to get ALL connected
	 * GPS Assessments*
	 * 
	 * @param context
	 * @param sObjectId
	 * @return
	 * @throws Exception 
	 */
	public Map<String, String> getGPSAssessments(Context context, String strObjectId) throws Exception {

		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpGPSAssessments = new HashMap<String, String>();
		MapList mlGPSAssessmentsList = new MapList();

		StringBuilder sbStatus = new StringBuilder();
		StringBuilder sbTaskName = new StringBuilder();
		StringBuilder sbNRQID = new StringBuilder();
		StringBuilder sbGPSAssCate = new StringBuilder();
		StringBuilder sbTaskDec = new StringBuilder();
		StringBuilder sbGPSAssState = new StringBuilder();
		StringBuilder sbBussinessArea = new StringBuilder();
		StringBuilder sbPRDCatFrmPart = new StringBuilder();
		StringBuilder sbPRDType = new StringBuilder();
		StringBuilder sbNRQoid = new StringBuilder();
		StringBuilder sbNRQType = new StringBuilder();

		StringList slObjSel = new StringList(9);
		slObjSel.add(DomainConstants.SELECT_ID);
		slObjSel.add(DomainConstants.SELECT_TYPE);
		slObjSel.add(DomainConstants.SELECT_NAME);
		slObjSel.add(DomainConstants.SELECT_CURRENT);
		slObjSel.add(DomainConstants.SELECT_DESCRIPTION);
		slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_GPSSTATUS);
		slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ORIGINALTASKNAME);
		slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNRQID);
		slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_GPSASSESSMENTCATEGORY);
		//Added by Manikanta for 22x Defect 50325 -- START
				MapList mlGPSAssessmentList1 = new MapList();
				int imlDeliverablesSize;
				String strDeliverableId = DomainConstants.EMPTY_STRING;
				MapList mlGPSAssessmentList2 = new MapList();
				Map docMap = null;
				CommonDocBO commonDoc = new CommonDocBO();
				//Added by Manikanta for 22x Defect 50325 -- END
		try{
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				String sUserType = util.getUserType();
				DomainObject domObj = DomainObject.newInstance(context, strObjectId);

				String strContextType = domObj.getType(context);

				mlGPSAssessmentsList = domObj.getRelatedObjects(context,
						ConstantsUtilIRM.REL_GPSASSESSMENTTASK_INPUTS,
						ConstantsUtil.TYPE_PGGPSASSESSMENTTASK,
						slObjSel, //objectSelects
						null, //relationshipSelects
						true, //getTo
						false, //getFrom
						(short)1, //recurseToLevel
						null, //objectWhere
						null, //relationshipWhere
						0);
				//Added by Manikanta for 22x Defect 50325 -- START
				boolean bisIRMDoc = commonDoc.isIRMDoc(strContextType);
				if(bisIRMDoc){
				mlGPSAssessmentList1 = domObj.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
						ConstantsUtilIRM.TYPE_DOCUMENT,
						slObjSel, //objectSelects
						null, //relationshipSelects
						true, //getTo
						false, //getFrom
						(short)1, //recurseToLevel
						null, //objectWhere
						null, //relationshipWhere
						0);
				if (mlGPSAssessmentList1 != null && !mlGPSAssessmentList1.isEmpty()) {
					imlDeliverablesSize = mlGPSAssessmentList1.size();
					for (int iDeliverables = 0; iDeliverables < imlDeliverablesSize; iDeliverables++) {
						docMap = (Map) mlGPSAssessmentList1.get(iDeliverables);
						strDeliverableId = (String) docMap.get(DomainObject.SELECT_ID);
						if(UIUtil.isNotNullAndNotEmpty(strDeliverableId))
						{
							DomainObject domObj1 = DomainObject.newInstance(context, strDeliverableId);
							mlGPSAssessmentList2 = domObj1.getRelatedObjects(context,
									ConstantsUtilIRM.REL_GPSASSESSMENTTASK_INPUTS,
									ConstantsUtil.TYPE_PGGPSASSESSMENTTASK,
									slObjSel, //objectSelects
									null, //relationshipSelects
									true, //getTo
									false, //getFrom
									(short)1, //recurseToLevel
									null, //objectWhere
									null, //relationshipWhere
									0);
						}
						mlGPSAssessmentsList.addAll(mlGPSAssessmentList2);
					}
				}
				}
				//Added by Manikanta for 22x Defect 50325 -- END
				//Added by Jwala for the Defect 51186 -- 2022x.1_FEBCW -- START
				mlGPSAssessmentsList = removeDuplicates(mlGPSAssessmentsList);
				//Added by Jwala for the Defect 51186 -- 2022x.1_FEBCW -- END
				Iterator objectListItr = mlGPSAssessmentsList.iterator();

				while(objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					boolean showData = false;

					String strStatus = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_GPSSTATUS));
					String strTaskName = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ORIGINALTASKNAME));
					String strNRQID = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNRQID));
					String strGPSASSCate = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_GPSASSESSMENTCATEGORY));
					//Modified By Jwala for the defect 42388 2022x Release 
					String strTaskDec = validator.getStringEquivalentForSubstituteStringTitle(objectMap.get(DomainConstants.SELECT_DESCRIPTION));
					String strGPSASSState = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_CURRENT));
					String strNRQoid = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ID));
					String strNRQtype= validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_TYPE));

					String strBusArea = ConstantsUtil.EMPTY_STRING;
					String strPRDCatFrmPart = ConstantsUtil.EMPTY_STRING;

					// Modified for the Defect 50585
					
					showData = util.checkHasAccess(context, sUserType, strNRQoid);
					
					if((strGPSASSState.equalsIgnoreCase(ConstantsUtilIRM.STATE_REVIEW) && util.isModificatinRequired())){
						continue;
					}

					if (strGPSASSState.equalsIgnoreCase(ConstantsUtilIRM.STATE_CANCEL)
							|| (strGPSASSState.equalsIgnoreCase(ConstantsUtilIRM.STATE_CREATE)
									|| strGPSASSState.equalsIgnoreCase(ConstantsUtilIRM.STATE_ASSIGN))) {
						continue;
					}
					
					//We Need to Pass NRQ ID to get below Please do not change. Below fields
					strBusArea = getBusinessAreaFromPart(context, strNRQoid);
					strPRDCatFrmPart = getProductCategoryPlatformFromPart(context, strNRQoid);
					String strPRDType = getConnectedBrand(context,strNRQoid);
					
					if (!strGPSASSState.equalsIgnoreCase((ConstantsUtilIRM.STATE_COMPLETE).trim())) {
						strNRQoid = ConstantsUtil.NO_ACCESS;
					}
					
					if (showData) {
						util.formatData(sbStatus, strStatus);
						util.formatData(sbTaskName, strTaskName);
						util.formatData(sbNRQID, strNRQID);
						util.formatData(sbGPSAssCate, strGPSASSCate);
						util.formatData(sbTaskDec, strTaskDec);
						util.formatData(sbGPSAssState, strGPSASSState);
						util.formatData(sbBussinessArea, strBusArea);
						util.formatData(sbPRDCatFrmPart, strPRDCatFrmPart);
						util.formatData(sbPRDType, strPRDType);
						util.formatData(sbNRQoid, strNRQoid);
						util.formatData(sbNRQType, strNRQtype);
					} else {
						util.formatData(sbStatus, strStatus);
						util.formatData(sbTaskName, strTaskName);
						util.formatData(sbNRQID, strNRQID);
						util.formatData(sbNRQoid, ConstantsUtil.NO_ACCESS);
						util.formatData(sbNRQType, strNRQtype);
						util.formatData(sbGPSAssCate, strGPSASSCate);
						util.formatData(sbTaskDec, strTaskDec);
						util.formatData(sbGPSAssState, strGPSASSState);
						util.formatData(sbBussinessArea, strBusArea);
						util.formatData(sbPRDCatFrmPart, strPRDCatFrmPart);
						util.formatData(sbPRDType, strPRDType);
					}

				}

				mpGPSAssessments.put(ConstantsUtil.STATUS,sbStatus.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.GPSTASKNAME,sbTaskName.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.NRQID,sbNRQID.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.GPSASSESSMENTREQCATEGORY,sbGPSAssCate.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.TASKDECRIPTION,sbTaskDec.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.GPSASSTASKSTATE,sbGPSAssState.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.BUSINESSAREAFROMPART,sbBussinessArea.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.PRODUCTCATEPLATFORMFRMPART,sbPRDCatFrmPart.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.GPSPRODUCTTYPE,sbPRDType.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.GPSNRQOID,sbNRQoid.toString());
				mpGPSAssessments.put(ConstantsUtilIRM.GPSNRQTYPE,sbNRQType.toString());

			}
		}catch(Exception e){
			LOGGER.error("Error from DeviceProductPartBO :  getGPSAssessments" + e);
			return new HashMap();
		}
		return mpGPSAssessments;

	}

	/**Added by Jwala for SR2018x.6 Dev -- START
	 *
	 * This method returns connected Brand to the context Product Data
	 * @param context the matrix context
	 * @param args
	 * @throws Exception if operation fails
	 * @return nothing
	 * @since DSO.
	 */
	public String getConnectedBrand(Context context, String strObjectId) throws Exception{
		StringBuilder sbBrand = new StringBuilder();
		StringList slConnectedBrand = new StringList();

		try{
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject doCtxtObject = DomainObject.newInstance(context, strObjectId);
				String strRelationshipName = ConstantsUtilIRM.REL_GPSTOPRODUCTTYPE;
				if(UIUtil.isNotNullAndNotEmpty(strRelationshipName)){
					slConnectedBrand = doCtxtObject.getInfoList(context,
							"from[" + ConstantsUtilIRM.REL_GPSTOPRODUCTTYPE + "].to." + DomainConstants.SELECT_NAME);
				}
				if(slConnectedBrand != null && !slConnectedBrand.isEmpty())
				{
					for(Object objBrand : slConnectedBrand)
					{
						if(UIUtil.isNotNullAndNotEmpty(sbBrand.toString()))
						{
							sbBrand.append(ConstantsUtil.SYMBL_COMMA).append(" ");
						}
						sbBrand.append(objBrand);
					}
				}
			}
		}catch(Exception e){
			LOGGER.error("Error from DeviceProductPartBO :  getConnectedBrand" + e);
			return new StringBuilder().toString();
		}
		return sbBrand.toString();
	}
	/**Added by Jwala for SR2018x.6 Dev -- START
	 *
	 * This method returns NRQ#Details to the context Product Data
	 * @param context the matrix context
	 * @param args
	 * @throws Exception if operation fails
	 * @return nothing
	 * @since DSO.
	 */
	public Map getNRQoid(Context context,String NRQName)throws Exception{

		Map mpNrqData = new HashMap();
		String strNRQOdata = ConstantsUtil.EMPTY_STRING;
		String strNRQoid = ConstantsUtil.EMPTY_STRING;
		String strNRQoType = ConstantsUtil.EMPTY_STRING;

		try{
			strNRQOdata = MqlUtil.mqlCommand(context,"temp query bus pgGPSAssessmentTask "+"\""+NRQName+"\""+" *  select id dump |");
			if (UIUtil.isNotNullAndNotEmpty(strNRQOdata))
				strNRQoType = FrameworkUtil.split(strNRQOdata,"|").get(0).toString();
			strNRQoid = FrameworkUtil.split(strNRQOdata,"|").get(3).toString();

			mpNrqData.put(ConstantsUtilIRM.GPSTYPE, strNRQoType);
			mpNrqData.put(ConstantsUtilIRM.GPSID, strNRQoid);
		}catch(Exception ex){
			LOGGER.error("Error from DeviceProductPartBO :  getNRQoid" + ex);
			return new HashMap();
		}
		return mpNrqData;
	}
	/**Added by Jwala for SR2018x.6 Dev -- START
	 *
	 * This method returns BusinessAreaFromPart to the context Product Data
	 * @param context the matrix context
	 * @param args
	 * @throws Exception if operation fails
	 * @return nothing
	 * @since DSO.
	 */
	public String getBusinessAreaFromPart(Context context,String strObjectId)throws Exception{

		StringBuilder sfinalBuilder = new StringBuilder();
		StringBuilder sRelBuilder = new StringBuilder();
		try{
			sRelBuilder.append("from[").append(ConstantsUtil.RELATIONSHIP_PGDOCUMENTTOBUSINESSAREA).append("].to.name");

			StringList busSelects  = new StringList(2);
			busSelects.addElement(DomainConstants.SELECT_ID);
			busSelects.addElement(sRelBuilder.toString());
			DomainObject domObj = null;
			Map mpObj = null;
			StringList slBusinessArea = new StringList();
			Object objBA = null;

			HashSet hSetUniqueString = new HashSet();
			StringList strNonDuplicateList = new StringList();
			//SPEC: Commented  by Jwala for Defect #42082 (its created a regression)-- START
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START
			String sUserType = util.getUserType();
			boolean showData = false;
			//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END
			//SPEC: Commented  by Jwala for Defect #42082 (its created a regression)-- END

			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				domObj = DomainObject.newInstance(context, strObjectId);
				MapList mlObjectDetails = domObj.getRelatedObjects(context,
						ConstantsUtilIRM.REL_GPSASSESSMENTTASK_INPUTS, 				// relationship pattern
						ConstantsUtilIRM.GPSALLOWED_TYPES,                 // object pattern
						busSelects,                       // object selects
						null,                   		 // relationship selects
						false,                              // to direction
						true,                             // from direction
						(short) 1,                         // recursion level
						null,                      // object where clause
						null,0);  
				
				if(mlObjectDetails != null && !mlObjectDetails.isEmpty())
				{	
					for(int i =0; i < mlObjectDetails.size(); i ++)
					{
						slBusinessArea.clear();
						mpObj = (Map)mlObjectDetails.get(i);
						objBA = (Object)mpObj.get(sRelBuilder.toString());
						
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START
						showData = util.checkHasAccess(context, sUserType, (String)mpObj.get(DomainConstants.SELECT_ID));
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 20 March 2021 -- START (FOr Internal Defect)
						/*if(showData)
						{*/
						if(objBA!=null)
						{
							if(objBA instanceof String)
								slBusinessArea.addElement((String)objBA);
							else
								slBusinessArea.addAll((StringList) objBA);
						}
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START (FOr Internal Defect)
						/*}
						else
						{
							slBusinessArea.addElement("#DENIED!");
						}*/
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END (FOr Internal Defect)
						 	
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END
						
							if(i>0 && UIUtil.isNotNullAndNotEmpty(sfinalBuilder.toString()))
								sfinalBuilder.append(ConstantsUtilIRM.CONSTANT_STRING_COMMA);

							if(null != slBusinessArea && !slBusinessArea.isEmpty())
							{
								for(String strBAName : slBusinessArea)
								{
									if(hSetUniqueString.add(strBAName))
									strNonDuplicateList.addElement(strBAName);
								}
							}
					}
					//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 20 March 2021 -- END
					sfinalBuilder.append(FrameworkUtil.join(strNonDuplicateList,", "));
				}
			}
		}catch(Exception ex){
			LOGGER.error("Error from DeviceProductPartBO :  getBusinessAreaFromPart" + ex);
			return ConstantsUtil.EMPTY_STRING;
		}
		return sfinalBuilder.toString();
	}
	
	/**Added by Jwala for SR2018x.6 Dev -- START
	/** DSM (DS) 2018x.1.1 : Method from GPS Assessement Task form field- To get "Product Category Platform" from Input Parts.
	 * @param context 
	 * @param args - information from the properties webform
	 * @return String - with PCP ids
	 * @throws Exception If operation fails.
	 */
	public String getProductCategoryPlatformFromPart(Context context, String strObjectId)throws Exception
	{
		
		StringBuilder sfinalBuilder = new StringBuilder();
		StringBuilder sRelBuilder = new StringBuilder();	
		
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START (FOr Internal Defect)
		String sUserType = util.getUserType();
		boolean showData = false;
		//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END (FOr Internal Defect)
		
		try
		{
			sRelBuilder.append("from[").append(ConstantsUtil.RELATIONSHIP_PGDOCUMENTTOPLATFORM).append("].to.name");
			
			StringBuilder sRelationshipBuilderAttr = new StringBuilder("from[")
					.append(ConstantsUtil.RELATIONSHIP_PGDOCUMENTTOPLATFORM).append(ConstantsUtil.SYMBL_PIPE)
					.append(DomainObject.getAttributeSelect(ConstantsUtil.ATTRIBUTE_PGPLATFORMTYPE))
					.append("~~ \"").append(ConstantsUtilIRM.CONST_PRODUCTCATEGORYPLATFORM).append("\"")
					.append("].to.").append(DomainConstants.SELECT_NAME);
			
			StringList busSelects  = new StringList(2);
			busSelects.addElement(DomainConstants.SELECT_ID);
			busSelects.addElement(sRelationshipBuilderAttr.toString());
			
			DomainObject domObj = null;
			Map mpObj = null;
			StringList slPCP  = new StringList();
			Object objPCP = null;
			HashSet hSetUniqueString = new HashSet();
			StringList strNonDuplicateList = new StringList();
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				domObj = DomainObject.newInstance(context, strObjectId);
				MapList mlObjectDetails = domObj.getRelatedObjects(context,
						ConstantsUtilIRM.REL_GPSASSESSMENTTASK_INPUTS, 				// relationship pattern
						ConstantsUtilIRM.GPSALLOWED_TYPES,                 // object pattern
						busSelects,                       // object selects
						null,                   		 // relationship selects
						false,                              // to direction
						true,                             // from direction
						(short) 1,                         // recursion level
						null,                      // object where clause
						null,0);                     // relationship where clause
				
				if(mlObjectDetails != null && !mlObjectDetails.isEmpty())
				{	
					for(int i =0; i < mlObjectDetails.size(); i ++)
					{
						slPCP.clear();
						mpObj = (Map)mlObjectDetails.get(i);
						
						//Commented By Jwala (COP-00160422)
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- START (FOr Internal Defect)
						//showData = util.checkHasAccess(context, sUserType, (String)mpObj.get(DomainConstants.SELECT_ID));
						//if(!showData)
						//continue;
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 10 March 2021 -- END (FOr Internal Defect)
						
						objPCP = (Object)mpObj.get(sRelBuilder.toString());
						if(objPCP!=null){
							if(objPCP instanceof String)
							{
								slPCP.addElement((String)objPCP);
							}
							else
							{
								slPCP.addAll((StringList) objPCP);
							}
							if(i>0 && UIUtil.isNotNullAndNotEmpty(sfinalBuilder.toString()))
								sfinalBuilder.append(ConstantsUtilIRM.CONSTANT_STRING_COMMA);

							if(null != slPCP && !slPCP.isEmpty())
							{
								for(String strPCPName : slPCP)
								{
									if(hSetUniqueString.add(strPCPName))
									{
										strNonDuplicateList.addElement(strPCPName);
									}
								}
							}
							strNonDuplicateList.sort();
						}
					}
					sfinalBuilder.append(FrameworkUtil.join(strNonDuplicateList,", "));
				}
			}
			
		}catch(Exception ex){
			LOGGER.error("Error from DeviceProductPartBO :  getProductCategoryPlatformFromPart" + ex);
			return ConstantsUtil.EMPTY_STRING;
		}
		return sfinalBuilder.toString();
	}
	
	/**
	 * Added by Jwala for SR2018x.6 Dev Ingredient Statements/CopyList method used to get ALL connected
	 * GPS Assessments*
	 * 
	 * @param context
	 * @param sObjectId
	 * @return
	 * @throws Exception 
	 */
	public Map<String, String> getIngredientstatements(Context context, String strObjectId) throws Exception {

		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, String> mpIngredientstatements = new HashMap<String, String>();
		MapList mlIngredientstatements = new MapList();

		StringBuilder sbMarkets = new StringBuilder();
		StringBuilder sbNRQ = new StringBuilder();
		StringBuilder sbGPSSourceIngrtList = new StringBuilder();
		StringBuilder sbGPSSourceIngrtState = new StringBuilder();
		StringBuilder sbGPSSourceIngrtType = new StringBuilder();
		StringBuilder sbGPSSourceIngrtID = new StringBuilder();
		StringBuilder sbGPSSourceIngrtName = new StringBuilder();

		StringList slObjSel = new StringList();

		slObjSel.add(ConstantsUtilIRM.INGREDIENTSTMT_COPYLIST_COUNTRY);
		slObjSel.add(ConstantsUtil.SELECT_NAME);
		slObjSel.add(ConstantsUtil.SELECT_CURRENT);
		slObjSel.add(ConstantsUtil.SELECT_TYPE);
		slObjSel.add(ConstantsUtil.SELECT_ID);

		StringList srelSel = new StringList();
		srelSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNRQID);
		srelSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_GPSASSESSMENTSTATEMENT);
		
		//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- START
		boolean isExternal=util.isModificatinRequired();
		//SPEC: Release SR18x.6.0 - Req#33248 Added  by gaikwad.tg on Date 11 May 2021 -- END

		try{
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				DomainObject domObj = DomainObject.newInstance(context, strObjectId);

				mlIngredientstatements = domObj.getRelatedObjects(context,
						ConstantsUtilIRM.REL_INGREDIENTSTMT,
						ConstantsUtil.TYPE_COPYLIST,
						slObjSel, //objectSelects
						srelSel, //relationshipSelects
						false, //getTo
						true, //getFrom
						(short)1, //recurseToLevel
						null, //objectWhere
						null, //relationshipWhere
						0);

				Iterator objectListItr = mlIngredientstatements.iterator();

				while(objectListItr.hasNext()) {
					Map objectMap = (Map) objectListItr.next();
					String sUserType = util.getUserType();
					boolean showData = false;
					String strMarkets = validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtilIRM.INGREDIENTSTMT_COPYLIST_COUNTRY));
					String strNRQ = validator.getStringEquivalentForString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNRQID));
					String strGPSList = validator.getStringEquivalentForString(objectMap.get(ConstantsUtil.SELECT_NAME));
					String strGPSTYPE = validator.getStringEquivalentForString(objectMap.get(ConstantsUtil.SELECT_TYPE));
					String strGPSID = validator.getStringEquivalentForString(objectMap.get(ConstantsUtil.SELECT_ID));
					String strIngredientName = validator.getStringEquivalentForString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_GPSASSESSMENTSTATEMENT));
					String strGPSState = validator.getStringEquivalentForString(objectMap.get(ConstantsUtil.SELECT_CURRENT));

					showData = util.checkHasAccess(context, sUserType, strGPSID);
					
					if (!strGPSState.equals(ConstantsUtil.RELEASE) &&  !strGPSState.equals(ConstantsUtil.RELEASED)) {
						strGPSID=ConstantsUtil.NO_ACCESS;

					}

					if (strGPSState.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
						continue;
					}
					
					//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- START
					//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
					/*if (!showData && util.isModificatinRequired()) {
					
						continue;
					}*/
					//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
					//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- END

					if (showData) {
						util.formatData(sbMarkets, strMarkets);
						util.formatData(sbNRQ, strNRQ);
						util.formatData(sbGPSSourceIngrtList, strGPSList);
						util.formatData(sbGPSSourceIngrtType, strGPSTYPE);
						util.formatData(sbGPSSourceIngrtID, strGPSID);
						util.formatData(sbGPSSourceIngrtName, strIngredientName);
						util.formatData(sbGPSSourceIngrtState, strGPSState);
					}else{
						if(isExternal)
							continue;
						else
						{
							util.formatData(sbMarkets, strMarkets);
							util.formatData(sbNRQ, strNRQ);
							util.formatData(sbGPSSourceIngrtList, strGPSList);
							util.formatData(sbGPSSourceIngrtType, strGPSTYPE);
							util.formatData(sbGPSSourceIngrtID, ConstantsUtil.NO_ACCESS);
							util.formatData(sbGPSSourceIngrtName, strIngredientName);
							util.formatData(sbGPSSourceIngrtState, strGPSState);
						}
					}
				}

				mpIngredientstatements.put(ConstantsUtil.MARKETS,sbMarkets.toString());
				mpIngredientstatements.put(ConstantsUtilIRM.NRQ,sbNRQ.toString());
				mpIngredientstatements.put(ConstantsUtilIRM.GPSSOURCEINGREDIENTLIST,sbGPSSourceIngrtList.toString());
				mpIngredientstatements.put(ConstantsUtilIRM.GPSSOURCEINGREDIENTLISTSTATE,sbGPSSourceIngrtState.toString());
				mpIngredientstatements.put(ConstantsUtilIRM.GPSSOURCEINGREDIENTLISTTYPE,sbGPSSourceIngrtType.toString());
				mpIngredientstatements.put(ConstantsUtilIRM.GPSSOURCEINGREDIENTLISTID,sbGPSSourceIngrtID.toString());
				mpIngredientstatements.put(ConstantsUtilIRM.GPSINGREDIENTSTMTNAME,sbGPSSourceIngrtName.toString());

			}
		}catch(Exception e){
			LOGGER.error("Error from DeviceProductPartBO :  getIngredientstatements" + e);
			return new HashMap();
		}

		return mpIngredientstatements;
	}
	
	//Added by Jwala for the Defect 51186 -- 2022x.1_FEBCW -- START
	public MapList removeDuplicates (MapList inputMapList) throws Exception {
		MapList retMapList = new MapList();
		String name = "";
		String ids = null;
		if(inputMapList != null && inputMapList.size() > 0){
			Iterator itr = inputMapList.iterator();
			Map itrMap = null;
			while (itr.hasNext()){
				itrMap = (Map)itr.next();
				name = (String)itrMap.get(DomainConstants.SELECT_NAME);
				if (ids == null){
					retMapList.add(itrMap);
				}
				if (ids != null && ids.indexOf("|"+name+"|") == -1){
					retMapList.add(itrMap);
				}
				ids = ids + "|"+ name + "|";
			}
		}
		return retMapList;
	}
	//Added by Jwala for the Defect 51186 -- 2022x.1_FEBCW -- END

}
