/**
 * Project 		: SpecsAnywhere
 * Program 		: OnlinePrintingPartBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class OnlinePrintingPartBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(OnlinePrintingPartBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	public OnlinePrintingPartBO() {
		// empty constructor
	}

	public OnlinePrintingPartBO(String oid) {
		this.setObjectId(oid);
	}

	/**
	 * Method Name 			: getOPPBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getOPPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: getOPPBO : Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getOPPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public DomainObject getOPPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: getOPPDO : Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getOnlinePrintingPartSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getOnlinePrintingPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getSubstanceSelectables(context));
		
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
				
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	
	/**
	 * Method Name 			: getSubstanceSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getSubstanceSelectables (Context context) 
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.COMP_TYPE); 
		busSelect.add(ConstantsUtil.COMP_ID); 
		busSelect.add(ConstantsUtil.COMP_NAME);  
		busSelect.add(ConstantsUtil.COMP_REVS);  
		busSelect.add(ConstantsUtil.COMP_DESC); 
		busSelect.add(ConstantsUtil.COMP_TITLE); 
		busSelect.add(ConstantsUtil.COMP_STATE); 
		busSelect.add(ConstantsUtil.COMP_CASNUM);  		
		busSelect.add(ConstantsUtil.COMP_SUBNAME);  		
		busSelect.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		busSelect.add(ConstantsUtil.COMP_ISCONTAM);  		
		busSelect.add(ConstantsUtil.COMP_QTY);  			
		busSelect.add(ConstantsUtil.COMP_MAXHGHT);  		
		busSelect.add(ConstantsUtil.COMP_MINHGHT);  		
		busSelect.add(ConstantsUtil.COMP_QUOM);  			
		busSelect.add(ConstantsUtil.COMP_METALENVCLASS); 
		busSelect.add(ConstantsUtil.COMP_POSTCONSUMER); 
		busSelect.add(ConstantsUtil.COMP_MANUF);  		
		busSelect.add(ConstantsUtil.COMP_COMENT);  		
		busSelect.add(ConstantsUtil.COMP_MARKETNAME);  	
		busSelect.add(ConstantsUtil.COMP_SEQUENCE);  		
		busSelect.add(ConstantsUtil.COMP_MATELAYER);
		busSelect.add(ConstantsUtil.COMP_POSTINDUSTRIAL);
		busSelect.add(ConstantsUtil.COMP_RPRSTATUS);
		busSelect.add(ConstantsUtil.COMP_ECNUMBER);
		busSelect.add(ConstantsUtil.COMP_REACHSTATUS);
		busSelect.add(ConstantsUtil.COMP_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.COMP_CURRENT);
		
		busSelect.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		busSelect.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	private StringList getPlantSelects(Context context) 
	{
		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
		busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONLENGTH);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONHEIGHT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE);
		busSelect.add(ConstantsUtil.STRPRINTINGPROSS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTNAME);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTID);
		busSelect.add(ConstantsUtil.SELECT_MASTERPARTTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHASART);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHASMULTIPLEGTINS);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_POAIMPACTCONFIRMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMINERALOILSADDEDTOPRINTINGINKS);
		//SPEC: <10.03.2023>: Manikanta Added for Req 46464 -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		//SPEC: <10.03.2023>: Manikanta Added for Req 46464 -- START
		
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- START
		busSelect.add(ConstantsUtil.ATL_STATE);
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- END
		
		return busSelect;
	}

	
	/**
	 * Method Name 			: updateDerivedDataInfo
	 * Method Description 	:
	 * @param context
	 * @param sSourceName
	 * @param sSourceRev
	 * @param sCreatedDate
	 * @param dob
	 * @param getTo
	 * @param getFrom
	 * @return
	 */
	public Map<String, String> updateDerivedDataInfo(Context context ,String sSourceName, String sSourceRev, String sCreatedDate, DomainObject dob, boolean getTo, boolean getFrom) {
		Map<String, String> mpDerived = new HashMap<String, String>();
		BusObjectAttribUtil util  = new BusObjectAttribUtil();
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.DERIVED_PRIM_ORG);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_ORIGINATED);
		slBusSelects.add(ConstantsUtil.SELECT_OWNER);
		StringList slRelSelects = new StringList();


		MapList mlDerivedList = new MapList();;
		try 
		{
			mlDerivedList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_DERIVED, ConstantsUtil.SYMBL_ASTERISK, slBusSelects , slRelSelects, getTo, getFrom, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			if(mlDerivedList.isEmpty()){
				return new HashMap();
			}
			Iterator objectListItr = mlDerivedList.iterator();
			StringBuilder sbDerivedName = new StringBuilder();
			StringBuilder sbSourceName=new StringBuilder();
			StringBuilder sbDesc=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbOrganization=new StringBuilder();
			StringBuilder sbRevision=new StringBuilder();
			StringBuilder sbOwner=new StringBuilder();
			StringBuilder sbOriginated=new StringBuilder();
			StringBuilder sbGenerationNum =new StringBuilder();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				StringValidatorUtil validator = new StringValidatorUtil();
				String sDerivedName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sOrganization=(String)objectMap.get(ConstantsUtil.DERIVED_PRIM_ORG);
				String sOwner=(String)objectMap.get(ConstantsUtil.SELECT_OWNER);

				String sGenerationNum =ConstantsUtil.GEN_NUM_ZERO;
				if(getTo){
					util.formatData(sbDerivedName,sSourceName);
					util.formatData(sbSourceName,sDerivedName);
				}else{
					util.formatData(sbDerivedName,sDerivedName);
					util.formatData(sbSourceName,sSourceName);
				}
				util.formatData(sbDesc,sDesc);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbOrganization,sOrganization);
				util.formatData(sbRevision,sSourceRev);
				util.formatData(sbOwner,sOwner);
				util.formatData(sbOriginated,sCreatedDate);
				util.formatData(sbGenerationNum,sGenerationNum);


			}

			mpDerived.put(ConstantsUtil.SOURCENAME, sbSourceName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDNAME, sbDerivedName.toString());
			mpDerived.put(ConstantsUtil.DERIVEDDESCRIPTION, sbDesc.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSTATE, sbCurrent.toString());
			mpDerived.put(ConstantsUtil.DERIVEDPARTSECURITYCATEGORY, sbOrganization.toString());
			mpDerived.put(ConstantsUtil.SOURCEPARTREVISION, sbRevision.toString());
			mpDerived.put(ConstantsUtil.CREATOR, sbOwner.toString());
			mpDerived.put(ConstantsUtil.CREATEDATE, sbOriginated.toString());
			mpDerived.put(ConstantsUtil.GENERATIONNUMBER, sbGenerationNum.toString());


		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : OnlinePrintingPartBO Method :updateDerivedDataInfo "+e);
			return new HashMap();
		}
		return mpDerived;
	}


	/**
	 * Method Name 			: getMasterAttributeData
	 * Method Description 	:
	 * @param context
	 * @param sMasterID
	 * @return
	 * @throws Exception
	 */
	public Map getMasterAttributeData(Context context, String sMasterID) throws Exception {
		Map<String, Object> mpAttribResult = new HashMap<String, Object>();
		StringList busSelect = new StringList();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		DomainObject doOPP =  getOPPDO(context, sMasterID);
		
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable(context));
		Map resultMaps = doOPP.getInfo(context,busSelect);
		StringValidatorUtil validator = new StringValidatorUtil();
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.NAME,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
		mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		
		//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION) : ConstantsUtil.EMPTY_STRING);
		String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String strBrand = util.getBrandInformationValue(context,sID);
		if(strBrand.isEmpty()) {
			strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
		}
		mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
		
		mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONHEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTERDIMENSIONDEPTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.INNERWIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINNERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.INNERLENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.INNERHEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.ATTRIBUTE_PGINNERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DIMENSIONUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PRINTINGPROCESS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRPRINTINGPROSS)))?(String)resultMaps.get(ConstantsUtil.STRPRINTINGPROSS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DECORATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);		
		mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		String sClassifictaion = util.getClassification(resultMaps);
		mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));
		//LifeCycle
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String objId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={objId,sPhysicalId};
		StopWatch swLifecycle = new StopWatch();
		swLifecycle.start();
		Map mpLifeCycleApproval = util.getCOName(context, changeargs);
		swLifecycle.stop();
		LOGGER.info("OPP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
		mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);


		return mpAttribResult;
	}

	
	/**
	 * Method Name 			: replaceSpecialSymbols
	 * Method Description 	:
	 * @param sData
	 * @return
	 */
	public String replaceSpecialSymbols(String sData)
	{
		if(!UIUtil.isNotNullAndNotEmpty(sData)){
			return ConstantsUtil.EMPTY_STRING;
		}
		sData= sData.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
		sData= sData.replace(ConstantsUtil.SYMBL_TRUE, ConstantsUtil.SYMBL_YES).replace(ConstantsUtil.SYMBL_FALSE, ConstantsUtil.SYMBL_NO);
		sData= sData.replace(ConstantsUtil.SYMBL_CAPTRUE, ConstantsUtil.SYMBL_YES).replace(ConstantsUtil.SYMBL_CAPFALSE, ConstantsUtil.SYMBL_NO);
		return sData;
	}
	
	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	:
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{

			String strName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			String strType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String strTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String strMFR     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String strTRN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String strMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String strMlyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String strMinWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT));
			String strMaxWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT));
			String strPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			String strCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String strtarget     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TARGETPER));
			String strFN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			String sPhase   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String strOrignSource	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ORIGINSOURCE));
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);

			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,strDesc);
			mpSubStanceResult.put(ConstantsUtil.TITLE,strTitle);
			mpSubStanceResult.put(ConstantsUtil.TYPE,strType);
			mpSubStanceResult.put(ConstantsUtil.NAME,strName);
			mpSubStanceResult.put(ConstantsUtil.TARGET_PERCEN_WBW,strtarget);
			mpSubStanceResult.put(ConstantsUtil.MAX,strMaxWt);
			mpSubStanceResult.put(ConstantsUtil.MIN,strMinWt);								  
			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,strMlLgc);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,strPCED);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,strMFR);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,strCMT);
			mpSubStanceResult.put(ConstantsUtil.FNUM,strFN);
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,strTRN);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,strMlyr);
			mpSubStanceResult.put(ConstantsUtil.PHASE,sPhase);
			mpSubStanceResult.put(ConstantsUtil.STATE, strOrignSource);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);


		}catch(Exception e){

			LOGGER.error("Error from OnlinePrintingPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}

	
	/**
	 * Method Name 			: getSubStanceResult
	 * Method Description 	:
	 * @param context
	 * @param doOPP
	 * @return
	 */
	public Map getSubStanceResult(Context context,DomainObject doOPP)
	{
		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		try
		{
			StringList slBusObjects = new StringList();
			slBusObjects.addElement(ConstantsUtil.SELECT_NAME);
			slBusObjects.addElement(ConstantsUtil.SELECT_TYPE);
			slBusObjects.addElement(ConstantsUtil.SELECT_ID);
			slBusObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slBusObjects.addElement(ConstantsUtil.SELECT_DESCRIPTION);
			slBusObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
			slBusObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME);
			slBusObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
			slBusObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT);
			slBusObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			slBusObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			slBusObjects.addElement(ConstantsUtil.SELECT_CURRENT);
			slBusObjects.addElement(ConstantsUtil.CLASSIFIED_ITEM);


			StringList slrelObjects = new StringList();
			//slrelObjects.addElement(ConstantsUtil.SELECT_ID);
			slrelObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
			slrelObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
			slrelObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
			slrelObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slrelObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER);
			slrelObjects.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);

			MapList mlMaterialList = doOPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,
					ConstantsUtil.SYMBL_ASTERISK, slBusObjects, slrelObjects, false, true, (short) 0,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			Iterator objectListItr = mlMaterialList.iterator();

			StringBuilder sbName = new StringBuilder();
			StringBuilder sbType = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbTitle = new StringBuilder();
			StringBuilder sbDes = new StringBuilder();
			StringBuilder sbMfr = new StringBuilder();
			StringBuilder sbstrTRN = new StringBuilder();
			StringBuilder sbLegacyCls = new StringBuilder();
			StringBuilder sbMTLayer = new StringBuilder();
			StringBuilder sbMIN = new StringBuilder();
			StringBuilder sbMAX = new StringBuilder();
			StringBuilder sbstrPCED = new StringBuilder();
			StringBuilder sbComment = new StringBuilder();
			StringBuilder sbTARWeight = new StringBuilder();
			StringBuilder sbSequence = new StringBuilder();
			StringBuilder sbReleasePhase = new StringBuilder();
			StringBuilder sbCurrent = new StringBuilder();
			StringBuilder sbCLassiItem = new StringBuilder();
			StringBuilder sbIPClass = new StringBuilder();

			while(objectListItr.hasNext()) {

				Map objectMap = (Map) objectListItr.next();

				String strName = (String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String strType = (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String strID   = (String)objectMap.get(ConstantsUtil.SELECT_ID);
				String strTitle = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String strDesc  = (String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String strMFR  = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
				String strTRN = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MARKETINGNAME);
				String strMlLgc = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
				String strMlyr = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLAYER);
				String strMinWt = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
				String strMaxWt = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
				String strPCED = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSTCOSUMERRECYCLEDCONTENT);
				String strCMT = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				String strtarget = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				String strFN = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEQUENCE);
				String sPhase = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				String strOrignSource = (String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String strClassFied = (String)objectMap.get(ConstantsUtil.CLASSIFIED_ITEM);
				String sIPClassfication = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);

				util.formatData(sbName,strName);
				util.formatData(sbType,strType);
				util.formatData(sbId,strID);
				util.formatData(sbTitle,strTitle);
				util.formatData(sbDes,strDesc);
				util.formatData(sbMfr,strMFR);
				util.formatData(sbstrTRN,strTRN);
				util.formatData(sbLegacyCls,strMlLgc);
				util.formatData(sbMTLayer,strMlyr);
				util.formatData(sbMIN,strMinWt);
				util.formatData(sbMAX,strMaxWt);
				util.formatData(sbstrPCED,strPCED);
				util.formatData(sbComment,strCMT);
				util.formatData(sbTARWeight,strtarget);
				util.formatData(sbSequence,strFN);
				util.formatData(sbReleasePhase,sPhase);
				util.formatData(sbCurrent,strOrignSource);
				util.formatData(sbCLassiItem,strClassFied);
				util.formatData(sbIPClass,sIPClassfication);

			}
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDes.toString());
			mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString());
			mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString());
			mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString());
			mpSubStanceResult.put(ConstantsUtil.TARGET_PERCEN_WBW,sbTARWeight.toString());
			mpSubStanceResult.put(ConstantsUtil.MAX,sbMIN.toString());
			mpSubStanceResult.put(ConstantsUtil.MIN,sbMAX.toString());								  
			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sbLegacyCls.toString());
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sbstrPCED.toString());
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sbMfr.toString());
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sbComment.toString());
			mpSubStanceResult.put(ConstantsUtil.FNUM,sbSequence.toString());
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sbstrTRN.toString());
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sbMTLayer.toString());
			mpSubStanceResult.put(ConstantsUtil.PHASE,sbReleasePhase.toString());
			mpSubStanceResult.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpSubStanceResult.put(ConstantsUtil.ID, sbId.toString());
			mpSubStanceResult.put(ConstantsUtil.SECURITY, sbCLassiItem.toString());
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sbCLassiItem.toString());

		}catch(Exception ex){
			LOGGER.error("Error from getSubStanceResult:"+ex);
			return new HashMap();
		}

		return mpSubStanceResult;
	}
	/*public Map updatePerformCharcteristicsss(Context context, MapList mlFinalList, Map resultMap,boolean bSupplierView) 
	{

		StringValidatorUtil validator = new StringValidatorUtil();
		String sType = validator.isNotNullOrEmpty((String) resultMap.get(ConstantsUtil.SELECT_TYPE))
				? (String) resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

				StringBuilder schg = new StringBuilder();
				StringBuilder sCharcteristic = new StringBuilder();
				StringBuilder sbPathId = new StringBuilder();
				StringBuilder sbPathType = new StringBuilder();
				StringBuilder sCharSpec = new StringBuilder();
				StringBuilder sPath = new StringBuilder();
				StringBuilder sTMNActual = new StringBuilder();
				StringBuilder sTMNActualID = new StringBuilder();
				StringBuilder sTMNActualType = new StringBuilder();
				StringBuilder sTMName = new StringBuilder();
				StringBuilder sTMLogic = new StringBuilder();
				StringBuilder sMethodOrigin = new StringBuilder();
				StringBuilder sMethodNumber = new StringBuilder();
				StringBuilder sMethodSpecific = new StringBuilder();
				StringBuilder sTMNameID = new StringBuilder();
				StringBuilder sTMNameType = new StringBuilder();
				StringBuilder sSampling = new StringBuilder();
				StringBuilder sSubGroup = new StringBuilder();

				StringBuilder sPlantTesting = new StringBuilder();
				StringBuilder sPlantRetesting = new StringBuilder();
				StringBuilder sTestingUOM = new StringBuilder();

				StringBuilder sLowerSpecLimit = new StringBuilder();
				StringBuilder sLowerRoutineReleaseLimit = new StringBuilder();
				StringBuilder sPGLowerTarget = new StringBuilder();
				StringBuilder sPGTarget = new StringBuilder();
				StringBuilder sPGUpperTarget = new StringBuilder();
				StringBuilder sUpperRoutineRL = new StringBuilder();
				StringBuilder sPGUpperSpecLimit = new StringBuilder();

				StringBuilder sUnitOfMeasure = new StringBuilder();
				StringBuilder sPGReportNear = new StringBuilder();
				StringBuilder sPGReportType = new StringBuilder();
				StringBuilder sReleseCriteria = new StringBuilder();

				StringBuilder sPGACtionRequired = new StringBuilder();
				StringBuilder sCriticalFactor = new StringBuilder();
				StringBuilder sPGBasis = new StringBuilder();

				StringBuilder sPTestGroup = new StringBuilder();
				StringBuilder sPApplication = new StringBuilder();
				StringBuilder sPMTitle = new StringBuilder();

				Iterator objectListItr = mlFinalList.iterator();
				Map<String, String> mpFinal = new HashMap<String, String>();

				
				 * if(mlFinalList.size()==0) { return new HashMap(); }
				 

				try {

					while (objectListItr.hasNext()) {
						Map objectMap = (Map) objectListItr.next();
						String sPchg = validator
								.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE))
								? ((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE))
										: ConstantsUtil.EMPTY_STRING;
								String sPCharcteristic = validator
										.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC))
										? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC)
												: ConstantsUtil.EMPTY_STRING;
										String sPCharSpec = validator.isNotNullOrEmpty(
												(String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS))
												? (String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS)
														: ConstantsUtil.EMPTY_STRING;
												String sPPath = validator.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.PATH))
														? (String) objectMap.get(ConstantsUtil.PATH)
																: ConstantsUtil.EMPTY_STRING;

														String sPTMName = ConstantsUtil.EMPTY_STRING;
														String sPTMNameActual = ConstantsUtil.EMPTY_STRING;
														String sPTMNameID = ConstantsUtil.EMPTY_STRING;
														String sPTMNameActualID = ConstantsUtil.EMPTY_STRING;
														String sPTMNameActualType = ConstantsUtil.EMPTY_STRING;
														String sPTMType = ConstantsUtil.EMPTY_STRING;

														boolean sClass = objectMap.containsKey(ConstantsUtil.SELECT_REF_DOC_TONAME);
														if (sClass) {
															String sClassName = objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME).getClass().getSimpleName();

															if (sClassName.equals(ConstantsUtil.STRING))
															{
																if (util.isModificatinRequired())
																{
																	sPTMName = validator
																			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
																			? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
																					: ConstantsUtil.EMPTY_STRING;
																			sPTMType = validator
																					.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
																					? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
																							: ConstantsUtil.EMPTY_STRING;
																					String sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap
																							.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS))
																							? (String) objectMap
																									.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS)
																									: ConstantsUtil.EMPTY_STRING;
																									sPTMNameID = validator
																											.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
																											? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
																													: ConstantsUtil.EMPTY_STRING;
																											//For TM Check With EBP
																											if ((sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION)))
																											{
                                                                                                               //modified by Ganesh for security impl------>start
																												//boolean bHasOwnership =util.checkOwnerShip(context,sPTMNameID);
																												boolean bHasOwnership = util.checkHasAccess(context, null, sPTMNameID);
																												//modified by Ganesh for security impl------>stop
																												if(bHasOwnership)
																												{
																													if (ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) 
																													{
																														formatData(sTMName, sPTMName);
																														formatData(sTMNameID, sPTMNameID);
																														formatData(sTMNameType, sPTMType);
																													} else {
																														formatData(sTMName, sPTMName);
																														formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																														formatData(sTMNameType, sPTMType);
																													}
																												}else
																												{
																													formatData(sTMName, sPTMName);
																													formatData(sTMNameID, ConstantsUtil.EMPTY_STRING);
																													formatData(sTMNameType, sPTMType);
																												}
																											}
																											//For SOP Check With EBP
																											if (sPTMType.equals(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE)) 
																											{
																												sPTMNameActual = validator
																														.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
																														? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
																																: ConstantsUtil.EMPTY_STRING;
																														sPTMNameActualType = validator
																																.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
																																? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
																																		: ConstantsUtil.EMPTY_STRING;
																																sTMHasSharedAccess = validator.isNotNullOrEmpty((String) objectMap
																																		.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS))
																																		? (String) objectMap.get(
																																				ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS)
																																				: ConstantsUtil.EMPTY_STRING;
																																				sPTMNameActualID = validator
																																						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
																																						? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
																																								: ConstantsUtil.EMPTY_STRING;
																																						//modified by Ganesh for security impl----->start
																																						boolean bHasOwnership =util.checkOwnerShip(context,sPTMNameID);
																																						bHasOwnership = util.checkHasAccess(context, null, sPTMNameID);
																																						//modified by Ganesh for security impl----->end
																																						if(bHasOwnership)
																																						{
																																							if (ConstantsUtil.TRUE.equalsIgnoreCase(sTMHasSharedAccess)) {
																																								formatData(sTMNActual, sPTMName);
																																								formatData(sTMNActualID, sPTMNameActual);
																																								formatData(sTMNActualType, sPTMType);
																																							} else {
																																								formatData(sTMNActual, sPTMName);
																																								formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																																								formatData(sTMNActualType, sPTMType);
																																							}

																																						}else {
																																							formatData(sTMNActual, sPTMName);
																																							formatData(sTMNActualID, ConstantsUtil.EMPTY_STRING);
																																							formatData(sTMNActualType, sPTMType);
																																						}
																											}
																} else 
																{
																	sPTMType = validator
																			.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
																			? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
																					: ConstantsUtil.EMPTY_STRING;
																			if (sPTMType.equals(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION))
																			{

																				sPTMName = validator
																						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
																						? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
																								: ConstantsUtil.EMPTY_STRING;
																						sPTMNameID = validator
																								.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
																								? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
																										: ConstantsUtil.EMPTY_STRING;

																								formatData(sTMName, sPTMName);
																								formatData(sTMNameID, sPTMNameID);
																								formatData(sTMNameType, sPTMType);
																			} else 
																			{
																				sPTMNameActual = validator
																						.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME))
																						? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME)
																								: ConstantsUtil.EMPTY_STRING;
																						sPTMNameActualType = validator
																								.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE))
																								? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE)
																										: ConstantsUtil.EMPTY_STRING;
																								sPTMNameActualID = validator
																										.isNotNullOrEmpty((String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID))
																										? (String) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID)
																												: ConstantsUtil.EMPTY_STRING;

																										formatData(sTMNActual, sPTMNameActual);
																										formatData(sTMNActualID, sPTMNameActualID);
																										formatData(sTMNActualType, sPTMNameActualType);
																			}
																}
															} else {

																StringList slTMName = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TONAME);
																StringList slTMType = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_TYPE);
																StringList slsChildObjectID = (StringList) objectMap.get(ConstantsUtil.SELECT_REF_DOC_TO_ID);
																StringList slTMHasSharedAccess = (StringList) objectMap
																		.get(ConstantsUtil.SELECT_REF_DOC_TO_ATTRIBUTE_SHAREWITHSUPPLIERS);
																if (util.isModificatinRequired()) {
																	Map<String, StringList> mpTemp = new HashMap<String, StringList>();
																	mpTemp.put(ConstantsUtil.TYPE, slTMType);
																	mpTemp.put(ConstantsUtil.NAME, slTMName);
																	mpTemp.put(ConstantsUtil.SECURITY, slTMHasSharedAccess);
																	mpTemp.put(ConstantsUtil.ID, slsChildObjectID);

																	Map mpTemp1 = util.showOrHideSOPAndTM(context, mpTemp);
																	slTMName = (StringList) mpTemp1.get(ConstantsUtil.NAME);
																	slTMType = (StringList) mpTemp1.get(ConstantsUtil.TYPE);
																	slsChildObjectID = (StringList) mpTemp1.get(ConstantsUtil.ID);
																}

																Map mpTemp2 = util.removeTestMethod(context,slTMName, slTMType, slsChildObjectID);

																StringList slTMFilteredName = (StringList) mpTemp2.get(ConstantsUtil.TMFILNAME);
																StringList slTMFilterID = (StringList) mpTemp2.get(ConstantsUtil.TMFILID);
																StringList slTMFilterType = (StringList) mpTemp2.get(ConstantsUtil.TMFILTYPE);

																slTMType = (StringList) mpTemp2.get(ConstantsUtil.BASETYPE);
																slTMName = (StringList) mpTemp2.get(ConstantsUtil.BASENAME);
																slsChildObjectID = (StringList) mpTemp2.get(ConstantsUtil.BASEID);

																sPTMName = validator.isNotNullOrEmpty(slTMName.toString()) ? slTMName.toString()
																		: ConstantsUtil.EMPTY_STRING;
																sPTMName = sPTMName.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																		.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																sPTMNameID = validator.isNotNullOrEmpty(slsChildObjectID.toString())
																		? slsChildObjectID.toString()
																				: ConstantsUtil.EMPTY_STRING;
																		sPTMNameID = sPTMNameID.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																		sPTMType = validator.isNotNullOrEmpty(slTMType.toString()) ? slTMType.toString()
																				: ConstantsUtil.EMPTY_STRING;
																		sPTMType = sPTMType.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																				.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																		formatData(sTMNActual, sPTMName);

																			StringList slTemp = FrameworkUtil.split(sPTMNameID, ConstantsUtil.SYMBL_AND);
						for(int i=0;i<slTemp.size();i++){
							String strPTMNameId = (String) slTemp.get(i);
							if(strPTMNameId !=null && !"".equals(strPTMNameId)){
								if(isModificatinRequired()) {
									boolean bHasOwnership = checkOwnerShip(context, strPTMNameId);
									if (bHasOwnership)
										sPTMNameID = sPTMNameID;
									else
										sPTMNameID = "";
								}
							}
						}

																		formatData(sTMNActualID, sPTMNameID);
																		formatData(sTMNActualType, sPTMType);

																		sPTMNameActual = validator.isNotNullOrEmpty(slTMFilteredName.toString())
																				? slTMFilteredName.toString()
																						: ConstantsUtil.EMPTY_STRING;
																				sPTMNameActual = sPTMNameActual
																						.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																				sPTMNameActualID = validator.isNotNullOrEmpty(slTMFilterID.toString()) ? slTMFilterID.toString()
																						: ConstantsUtil.EMPTY_STRING;
																				sPTMNameActualID = sPTMNameActualID
																						.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																						.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																				sPTMNameActualType = validator.isNotNullOrEmpty(slTMFilterType.toString())
																						? slTMFilterType.toString()
																								: ConstantsUtil.EMPTY_STRING;
																						sPTMNameActualType = sPTMNameActualType
																								.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING)
																								.replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING)
																								.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_AND);

																						formatData(sTMName, sPTMNameActual);
																						formatData(sTMNameID, sPTMNameActualID);
																						formatData(sTMNameType, sPTMNameActualType);

															}

														} else {
															formatData(sTMName, sPTMNameActual);
															formatData(sTMNameID, sPTMNameActualID);
															formatData(sTMNameType, sPTMNameActualType);

															formatData(sTMNActual, sPTMName);
															formatData(sTMNActualID, sPTMNameID);
															formatData(sTMNActualType, sPTMType);
														}

														String sPathId = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_ID));
														String sPathType = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_TYPE));

														String sPTMLogic = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC));
														String sPMethodOrigin = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN));
														String sPMethodNumber = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER));
														String sPMethodSpecific = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS));
														sPMethodSpecific = sPMethodSpecific.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_AND);
														String sPSampling = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING));
														String sPSubGroup = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP));
														String sPPlantTesting = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING));
														String sPPlantRetesting = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING));
														String sPTestingUOM = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM));
														String sPLowerSpecLimit = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT));
														String sPLowerRoutineReleaseLimit = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERROUTINRRELEASELIMIT));
														String sPPGLowerTarget = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERTARGET));
														String sPPGTarget = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTARGET));
														String sPPGUpperTarget = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERTARGET));
														String sPUpperRoutineRL = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERROUTINERELEASELIMIT));
														String sPPGUpperSpecLimit = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERSPECIFICATIONLIMIT));
														String sPUnitOfMeasure = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE));
														String sPPGReportNear = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST));
														String sPPGReportType = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE));
														String sPReleseCriteria = validator.getStringEquivalentForStringListWithComma(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA));
														String sPPGACtionRequired = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED));
														String sPCriticalFactor = validator.getStringEquivalentForStringList(
																objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR));
														String sPPGBasis = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS));
														String sTestGroup = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP));
														String sApplication = validator
																.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION));

														String sTitle = ConstantsUtil.EMPTY_STRING;

														boolean bPresent = objectMap.containsKey(ConstantsUtil.PERFORMCHAR_MPT_TITLE);
														if (bPresent) {
															sTitle = validator
																	.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.PERFORMCHAR_MPT_TITLE));
														} else {
															sTitle = validator
																	.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
														}

														formatData(sbPathId, sPathId);
														formatData(sbPathType, sPathType);
														formatData(sPath, sPPath);

														formatData(schg, sPchg);
														formatData(sCharcteristic, sPCharcteristic);
														formatData(sCharSpec, sPCharSpec);

														formatData(sTMLogic, sPTMLogic);
														formatData(sMethodOrigin, sPMethodOrigin);
														formatData(sMethodNumber, sPMethodNumber);
														formatData(sMethodSpecific, sPMethodSpecific);

														formatData(sSampling, sPSampling);
														formatData(sSubGroup, sPSubGroup);

														formatData(sPlantTesting, sPPlantTesting);
														formatData(sPlantRetesting, sPPlantRetesting);
														formatData(sTestingUOM, sPTestingUOM);

														formatData(sLowerSpecLimit, sPLowerSpecLimit);
														formatData(sLowerRoutineReleaseLimit, sPLowerRoutineReleaseLimit);
														formatData(sPGLowerTarget, sPPGLowerTarget);
														formatData(sPGTarget, sPPGTarget);
														formatData(sPGUpperTarget, sPPGUpperTarget);
														formatData(sUpperRoutineRL, sPUpperRoutineRL);
														formatData(sPGUpperSpecLimit, sPPGUpperSpecLimit);

														formatData(sUnitOfMeasure, sPUnitOfMeasure);
														formatData(sPGReportNear, sPPGReportNear);
														formatData(sPGReportType, sPPGReportType);
														formatData(sReleseCriteria, sPReleseCriteria);
														formatData(sPGACtionRequired, sPPGACtionRequired);
														formatData(sCriticalFactor, sPCriticalFactor);
														formatData(sPGBasis, sPPGBasis);

														formatData(sPTestGroup, sTestGroup);
														formatData(sPApplication, sApplication);
														formatData(sPMTitle, sTitle);

					}
					mpFinal.put(ConstantsUtil.CHG, schg.toString());
					mpFinal.put(ConstantsUtil.CHARACTERISTICCH, sCharcteristic.toString());
					mpFinal.put(ConstantsUtil.CS, sCharSpec.toString());
					if ((sType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)
							|| sType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) && util.isModificatinRequired()) {
						mpFinal.put(ConstantsUtil.CHARP, sPath.toString());
					} else if (!sType.equals(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)
							&& !sType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART)) {
						mpFinal.put(ConstantsUtil.CHARP, sPath.toString());
					}

					mpFinal.put(ConstantsUtil.REF, sTMNActual.toString());
					mpFinal.put(ConstantsUtil.REFID, sTMNActualID.toString());
					mpFinal.put(ConstantsUtil.REFTYPE, sTMNActualType.toString());

					mpFinal.put(ConstantsUtil.PATH_ID, sbPathId.toString());
					mpFinal.put(ConstantsUtil.PATH_TYPE, sbPathType.toString());

					mpFinal.put(ConstantsUtil.TMTYPE, sTMNameType.toString());
					mpFinal.put(ConstantsUtil.TESTMETHODNAME, sTMName.toString());
					mpFinal.put(ConstantsUtil.TESTMETHODNAMEID, sTMNameID.toString());

					mpFinal.put(ConstantsUtil.TML, sTMLogic.toString());
					mpFinal.put(ConstantsUtil.ORIGIN, sMethodOrigin.toString());
					mpFinal.put(ConstantsUtil.TM, sMethodNumber.toString());
					mpFinal.put(ConstantsUtil.SP, sMethodSpecific.toString());

					mpFinal.put(ConstantsUtil.SAMPLINGSM, sSampling.toString());
					mpFinal.put(ConstantsUtil.SG, sSubGroup.toString());
					
					mpFinal.put(ConstantsUtil.PLANTTESTING, sPlantTesting.toString());
					mpFinal.put(ConstantsUtil.RT, sPlantRetesting.toString());
					mpFinal.put(ConstantsUtil.UOM, sTestingUOM.toString());

					mpFinal.put(ConstantsUtil.LOWERSPECLIMIT, sLowerSpecLimit.toString());
					mpFinal.put(ConstantsUtil.LRRL, sLowerRoutineReleaseLimit.toString());
					mpFinal.put(ConstantsUtil.LTGT, sPGLowerTarget.toString());
					mpFinal.put(ConstantsUtil.TGT, sPGTarget.toString());
					mpFinal.put(ConstantsUtil.UTGT, sPGUpperTarget.toString());
					mpFinal.put(ConstantsUtil.URRL, sUpperRoutineRL.toString());
					mpFinal.put(ConstantsUtil.USL, sPGUpperSpecLimit.toString());

					mpFinal.put(ConstantsUtil.UNITOF, sUnitOfMeasure.toString());
					mpFinal.put(ConstantsUtil.RTN, sPGReportNear.toString());
					mpFinal.put(ConstantsUtil.RTT, sPGReportType.toString());
					mpFinal.put(ConstantsUtil.RELEASECRITERIA, sReleseCriteria.toString());

					mpFinal.put(ConstantsUtil.ACTIONREQUIRED, sPGACtionRequired.toString());
					mpFinal.put(ConstantsUtil.CAPSCR, sCriticalFactor.toString());
					mpFinal.put(ConstantsUtil.BA, sPGBasis.toString());

					mpFinal.put(ConstantsUtil.TESTGROUP, sPTestGroup.toString());
					mpFinal.put(ConstantsUtil.AP, sPApplication.toString());
					mpFinal.put(ConstantsUtil.MPT, sPMTitle.toString());

				} catch (Exception e) {
					LOGGER.error("Exception from BusObjectAttribUtil:  updatePerformCharcteristic" + e);
					return new HashMap();
				}
				if(bSupplierView){
					mpFinal.remove(ConstantsUtil.PLANTTESTING);
					mpFinal.remove(ConstantsUtil.RT);
					mpFinal.remove(ConstantsUtil.UOM);
				}
				
				return mpFinal = util.filterMapList(mpFinal);

	}*/
	
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList(){

		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW); 
		slMultiSelects.add(ConstantsUtil.COMP_TYPE); 
		slMultiSelects.add(ConstantsUtil.COMP_ID);  
		slMultiSelects.add(ConstantsUtil.COMP_NAME);  
		slMultiSelects.add(ConstantsUtil.COMP_REVS);  
		slMultiSelects.add(ConstantsUtil.COMP_DESC); 
		slMultiSelects.add(ConstantsUtil.COMP_TITLE); 
		slMultiSelects.add(ConstantsUtil.COMP_STATE); 
		slMultiSelects.add(ConstantsUtil.COMP_CASNUM);  		
		slMultiSelects.add(ConstantsUtil.COMP_SUBNAME);  		
		slMultiSelects.add(ConstantsUtil.COMP_QSTCOMPOSITE);  
		slMultiSelects.add(ConstantsUtil.COMP_ISCONTAM);  		
		slMultiSelects.add(ConstantsUtil.COMP_QTY);  			
		slMultiSelects.add(ConstantsUtil.COMP_MAXHGHT);  		
		slMultiSelects.add(ConstantsUtil.COMP_MINHGHT); 
		slMultiSelects.add(ConstantsUtil.COMP_TARGETPER); 		
		slMultiSelects.add(ConstantsUtil.COMP_QUOM);
		slMultiSelects.add(ConstantsUtil.COMP_METALENVCLASS);
		slMultiSelects.add(ConstantsUtil.COMP_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.COMP_ORIGINSOURCE);
		slMultiSelects.add(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		slMultiSelects.add(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		
		return slMultiSelects;
	}

	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	:
	 */
	public  void removeMultiList(){

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TYPE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_NAME); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ID);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_REVS);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_DESC); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TITLE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_STATE); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CASNUM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_SUBNAME);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QSTCOMPOSITE);  
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ISCONTAM);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QTY);  			
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MAXHGHT);  		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_MINHGHT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_TARGETPER); 
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_QUOM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_METALENVCLASS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ORIGINSOURCE);

		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_CLASSIFIED_ITEM);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS);
		
		
		//SPEC Added on 12-Dec-2020 by Chandra for Defect 37723 ##--START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
		//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END
	}

	
	/**
	 * Method Name 			: getSubstances
	 * Method Description 	: 
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getSubstances(Context context, Map resultMaps)
	{

		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			String sName	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_NAME));
			String sType	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TYPE));
			String strID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sDesc	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC));
			String sDesc	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_DESC));
			//String sTitle	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_TITLE));
			String sTitle	 =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_TITLE));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sQTY      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY));
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			String sQTYUom   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM));
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
			String sMAXWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MAXHGHT));
			String sMInWt   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MINHGHT));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sMlLgc   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			String sMlLgc   =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_METALENVCLASS));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sPCED    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTCONSUMER));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sMFR     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MANUF));
			String sMFR     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MANUF));
			//String sCMT     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_COMENT));
			String sCMT     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_COMENT));
			//String sTrN     =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			String sTrN     =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MARKETNAME));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sFN      =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SEQUENCE));
			
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
			//String sMLyr    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			String sMLyr    =  validator.getEquivalentString(resultMaps.get(ConstantsUtil.COMP_MATELAYER));
			//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
			
			String sPCID    =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_POSTINDUSTRIAL));
			String sPhase   =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE));
			String strCurrent	 =  validator.getStringEquivalentForString(resultMaps.get(ConstantsUtil.COMP_CURRENT));
			
			String strClassFied = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_CLASSIFIED_ITEM));
			String sIPClassfication = validator.getStringEquivalentForStringList( resultMaps.get(ConstantsUtil.COMP_ATTRIBUTE_IPCALSS));
			mpSubStanceResult.put(ConstantsUtil.SECURITY, strClassFied);
			mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sIPClassfication);
			
			mpSubStanceResult.put(ConstantsUtil.NAME,sName);
			mpSubStanceResult.put(ConstantsUtil.TYPE,sType);
			mpSubStanceResult.put(ConstantsUtil.TITLE,sTitle);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sDesc);
			mpSubStanceResult.put(ConstantsUtil.COMP_MANUFACTURER,sMFR);
			//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
			//mpSubStanceResult.put(ConstantsUtil.FNUM,sFN);
			mpSubStanceResult.put(ConstantsUtil.SEQ,sFN);
			//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
			mpSubStanceResult.put(ConstantsUtil.TRADE_NAME,sTrN);
			mpSubStanceResult.put(ConstantsUtil.LEGACYENVCLASS,sMlLgc);
			mpSubStanceResult.put(ConstantsUtil.LAYER_DESC,sMLyr);
			mpSubStanceResult.put(ConstantsUtil.MIN,sMInWt);
			mpSubStanceResult.put(ConstantsUtil.TW,sQTY);
			mpSubStanceResult.put(ConstantsUtil.QTYUOM,sQTYUom);
			mpSubStanceResult.put(ConstantsUtil.MAX,sMAXWt);
			mpSubStanceResult.put(ConstantsUtil.POST_CONNSUMER,sPCED);
			mpSubStanceResult.put(ConstantsUtil.POST_INDUSTRIAL,sPCID);
			mpSubStanceResult.put(ConstantsUtil.COMP_COMMENTS,sCMT);
			mpSubStanceResult.put(ConstantsUtil.PHASE,sPhase);
			mpSubStanceResult.put(ConstantsUtil.STATE, strCurrent);
			mpSubStanceResult.put(ConstantsUtil.ID, strID);
			
			mpSubStanceResult=util.verifyOwnership(context,mpSubStanceResult);
			
		}catch(Exception e){
			LOGGER.error("Error from OnlinePrintingPartBO:  getSubstances"+e);
			return new HashMap();
		}
		return mpSubStanceResult;
	}
	
	
	//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- START
	public static StringList getSecuritySelects(Context context) {
		
		StringList slIpSelects = new StringList();
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		slIpSelects.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		
		return slIpSelects;

	}
	//SPEC: Added for Defect#37726 1.0.2 Release - Amman -- END
}