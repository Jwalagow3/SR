package com.pg.us.specanywhere_enovia.utility;

import java.util.Properties;

import org.apache.log4j.Logger;

import java.nio.charset.StandardCharsets;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import matrix.db.Context;
import matrix.util.StringList;
import matrix.db.BusinessInterface;
import matrix.util.StringList;
import matrix.db.MQLCommand;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.FrameworkException;

public class InterfacePropertiesPageUtil {
	private final Context context;
	private final String pageName;
	private Properties properties;
	private static Logger LOGGER = Logger.getLogger(InterfacePropertiesPageUtil.class);
	
	private InterfacePropertiesPageUtil(Context context, String pageName) throws FrameworkException {
		this.context = context;
		this.pageName = pageName;
		this.properties = new Properties();
		if (pageFileExists()) {
			try {
				String	strMQLCommand = "print page $1 select $2 dump";
				String	strResult = MqlUtil.mqlCommand(this.context, strMQLCommand, new String[] { this.pageName, ConstantsUtilIRM.MQL_SELECT_CONTENT });
				this.properties.load(new ByteArrayInputStream(strResult.getBytes(StandardCharsets.ISO_8859_1)));
			}
			catch (Exception exception) {
				LOGGER.error("Exception in program InterfacePropertiesPageUtil :Inside Constructor");
			} 
		}
	}
	public static final InterfacePropertiesPageUtil getPagePropertiesContent(Context context, String pageName, String language) throws FrameworkException {
		String page = pageName + ((language == null || "".equals(language)) ? "" : ("_" + language)) + ConstantsUtilIRM.EXTENSION_PROPERTIES;
		return new InterfacePropertiesPageUtil(context, page);
	}

	private final boolean pageFileExists() throws FrameworkException {
		String strMQLCommand = "list page $1";
		String strResult = MqlUtil.mqlCommand(this.context, strMQLCommand, new String[] { this.pageName });
		return (strResult != null && this.pageName.equals(strResult.trim()));
	}
	
	public String getPropertyName(String strBackendName) {
		return this.properties.getProperty(strBackendName);
	}
	
}
