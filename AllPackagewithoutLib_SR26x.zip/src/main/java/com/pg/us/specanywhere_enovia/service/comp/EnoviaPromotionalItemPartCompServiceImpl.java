package com.pg.us.specanywhere_enovia.service.comp;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPService;
import com.pg.us.specanywhere_enovia.service.PromotionalItemPartCompService;
import com.pg.us.specanywhere_enovia.service.PromotionalItemPartService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPMPServiceImpl;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPromotionalItemPartServiceImpl;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;

public class EnoviaPromotionalItemPartCompServiceImpl implements PromotionalItemPartCompService {
	private static Logger LOGGER = Logger.getLogger(EnoviaPromotionalItemPartServiceImpl.class);
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	
	
	@Autowired
	private EnoviaConnectionPool pool;
	
	
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private PromotionalItemPartService pip;
	@Override
	public HashMap<String, HashMap<String, Map<String, String>>> getPIPPartCompData(String sObjectName, Environment env) {
		HashMap<String, HashMap<String, Map<String, String>>> hmAttrib = new HashMap<String, HashMap<String, Map<String, String>>>();
		HashMap<String, Map<String, String>> hmAttribRel = new HashMap();
		HashMap<String, Map<String, String>> hmAttribObj = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		StopWatch sp = new StopWatch();
		sp.start();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		try {
			
			String sComp=ConstantsUtilIRM.PIP_COMPARE;
			
			if(UIUtil.isNotNullAndNotEmpty(sObjectName)){
				hmAttribRel = pip.getPIPdata(sObjectName, sComp, env);
				DomainObject doPIP = DomainObject.newInstance(context, sObjectName);
				sComp=ConstantsUtilIRM.COMPARE;
				String sDocPreviousRevId  = doPIP.getPreviousRevision(context).getObjectId();
				if(UIUtil.isNotNullAndNotEmpty(sDocPreviousRevId)) {
					hmAttribObj = pip.getPIPdata(sDocPreviousRevId, sComp,env);
				}
			}
			hmAttrib.put(ConstantsUtilIRM.RELEASEOBJECT, hmAttribRel);
			hmAttrib.put(ConstantsUtilIRM.OBSOLETEOBJECT,hmAttribObj);
		}catch(Exception e) {
			LOGGER.error("Exception From PIP COMPARISION Service IMPL Class "+e);
		}
		context.close();
		return hmAttrib;
	}

}
