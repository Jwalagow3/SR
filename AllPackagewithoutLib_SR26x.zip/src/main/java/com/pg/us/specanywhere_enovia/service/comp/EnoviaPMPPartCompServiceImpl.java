package com.pg.us.specanywhere_enovia.service.comp;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPPartCompService;
import com.pg.us.specanywhere_enovia.service.EnoviaPMPService;
import com.pg.us.specanywhere_enovia.service.EnoviaRMPService;
import com.pg.us.specanywhere_enovia.service.impl.EnoviaPMPServiceImpl;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaPMPPartCompServiceImpl implements EnoviaPMPPartCompService {
	
	private static Logger LOGGER = Logger.getLogger(EnoviaPMPServiceImpl.class);
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	
	
	@Autowired
	private EnoviaConnectionPool pool;
	
	
	@Autowired
	private HttpServletRequest request;

	@Autowired
	private EnoviaPMPService pmp;
	@Override
	public HashMap<String, HashMap<String, Map>> getPMPPartCompData(String sObjid,
			Environment env) {
		
		
		HashMap<String, HashMap<String, Map>> hmAttrib = new HashMap<String,HashMap<String, Map>>();
		HashMap<String, Map> hmAttribRel = new HashMap();
		HashMap<String, Map> hmAttribObj = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		StopWatch sp = new StopWatch();
		sp.start();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		try {
			
			String sComp=ConstantsUtilIRM.PMP_COMPARE;
			
			if(UIUtil.isNotNullAndNotEmpty(sObjid)){
				hmAttribRel = pmp.getPMPdata(sObjid, sComp, env);
				DomainObject doPMP = DomainObject.newInstance(context, sObjid);
				sComp=ConstantsUtilIRM.COMPARE;
				
				String sDocPreviousRevId  = doPMP.getPreviousRevision(context).getObjectId();
				
				
				if(UIUtil.isNotNullAndNotEmpty(sDocPreviousRevId))
					hmAttribObj = pmp.getPMPdata(sDocPreviousRevId, sComp,env);
				
			}
			hmAttrib.put(ConstantsUtilIRM.RELEASEOBJECT, hmAttribRel);
			hmAttrib.put(ConstantsUtilIRM.OBSOLETEOBJECT,hmAttribObj);
		}catch(Exception e) {
			LOGGER.error("Exception From PMP COMPARISION Service IMPL Class "+e);
		}
		context.close();
		return hmAttrib;
	}
	}

