package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaCommonDocService
{

	public static void  main(String[] args)	throws Exception 
	{
		//String objId = "20336.41905.33089.62625";
		//String objId = "20336.41905.33792.15764";
		//String objId = "20336.41905.33792.42255";
		//String objId = "20336.41905.33280.21111";
		//String objId = "20336.41905.32931.54934"; //related acs
		String objId = "20336.41905.9657.11926"; //related iaps
		String sUserType = ConstantsUtil.PG_CM;
		
		String sType="";
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
		Logger LOGGER = Logger.getLogger(EnoviaCommonDocService.class);
		
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		StopWatch swContext = new StopWatch();
		swContext.start();
		EnoviaConnectionPool pool = new EnoviaConnectionPool();
	    Context context = pool.checkOut();
	    swContext.stop();
		LOGGER.info("COMMON DOC SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());

		BusObjectAttribUtil util = new BusObjectAttribUtil();
		CommonDocBO cdoc = new CommonDocBO();
		try 
		{
			/*
			 * User Profile Section
			 * */
			//String sUserType = BbUtil.getUserType();
			if(null==sUserType) {
				LOGGER.info("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
			}
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;

			/*switch (sUserType) {
			case ConstantsUtil.PG:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PGSTAFF:
				bAllInfoView = true;
				break;

			case ConstantsUtil.PG_CM:
				bManufacturerView = true;
				break;

			case ConstantsUtil.PG_SP:
				bSupplierView = true;
				break;
			}*/
			boolean isExternal=true;
			boolean isInternal=false;
			boolean userType=util.isModificatinRequired();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM) || sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP)){
				isExternal=true;
				isInternal=false;
			}
			
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpPartSpecResult = new HashMap<String,String>();
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpOrganization = new HashMap<String, String>();
			Map<String,String> mpPlant = new HashMap<String, String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mpRelatedAts = new HashMap<String, String>();
			Map<String,String> mpRelatedParts = new HashMap<String, String>();
			Map<String,String> mpAcs = new HashMap<String, String>();
			Map<String,String> mpIaps = new HashMap<String, String>();
			
			
			Map<String, StringList> BusinessObjectSelectableMap = cdoc.getDefaultPartSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			
			DomainObject dobCdoc = new DomainObject(objId);
			StopWatch swInfo = new StopWatch();
			cdoc.addMultiList();
			swInfo.start();
			
			Map resultMaps = dobCdoc.getInfo(context, slContextSelects);
			
			swInfo.stop();
			cdoc.removeMultiList();
			LOGGER.info("COMMON DOC SERVICE GETINFO ELAPSED TIME : "+swInfo.getTime());
			
			String sObjectId =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sObjectType = (String)resultMaps.get(ConstantsUtil.SELECT_TYPE);
			
			String sSharable = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS) : ConstantsUtil.EMPTY_STRING;
					
			
			/**
			 * Check SOP is a Universal Doc  
			 * */
			
			if(sType.equalsIgnoreCase("SOP") && (ConstantsUtil.TRUE.equalsIgnoreCase(sSharable))) 
			{
				StopWatch swReferences= new StopWatch();
				swReferences.start();
				String sView = BbUtil.updateReferences(context, sObjectId);
				LOGGER.info("COMMON DOC SERVICE  SOP VIEW:"+sView +"User :"+sUserType);
				
				if(!sView.equals(sUserType) && !sView.equals("NO Connection Exists") && !sView.equals(ConstantsUtil.ALLOW_FOR_ALL))
				{
					LOGGER.info("ERROR: "+ConstantsUtil.E106);
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E106.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//return hmAttrib;
				}
				
				swReferences.stop();
				LOGGER.info("COMMON DOC SERVICE  REFERENCE ELAPSED TIME : "+swReferences.getTime());
					
			}else if(sType.equalsIgnoreCase("SOP") && (!ConstantsUtil.TRUE.equalsIgnoreCase(sSharable))) {
				
				LOGGER.info("ERROR: "+ConstantsUtil.E101 +ConstantsUtil.SYMBL_COLON+sType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//return hmAttrib;
			}
			
			
			
			boolean bHIRComplaint = util.getHIRComplaintForSupplier(context,dobCdoc,resultMaps);
			
			if(!bHIRComplaint && sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP) && sType.equalsIgnoreCase("MI")){
				
				LOGGER.info("ERROR:"+ConstantsUtil.E101);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//return hmAttrib;
			}
			
			boolean isAts=false;
			boolean isAcs=false;
			boolean isIaps=false;
			if(ConstantsUtil.TYPE_PGAUTHORIZEDTEMPORARYSTANDARD.equalsIgnoreCase(sObjectType)) {
				isAts=true;
			}
			if(ConstantsUtil.TYPE_PGAUTHORIZEDCONFIGURATIONSTANDARD.equalsIgnoreCase(sObjectType)) {
				isAcs=true;
			}
			if(ConstantsUtil.TYPE_FORMULATECHNICALSPEC.equalsIgnoreCase(sObjectType)) {
				isIaps=true;
			}
			/*
			 * LOAD HEADER CONTENT SECTION
			 * */
			mpHeaderContent.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
			mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 

			if(isAts) {
				//Related Parts
				/*String sPartType = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.REL_ATS_TYPE)));
				String sPartName = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.REL_ATS_NAME)));
				String sPartState = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.REL_ATS_STATE)));
				String sPartTitle = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.REL_ATS_TITLE)));
				String sPartRev = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.REL_ATS_REV)));
				String sPartId = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.REL_ATS_ID)));
				String sPartOwnership = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.REL_ATS_OWNERSHIP)));
				String sPartPhase = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.REL_ATS_RELEASE_PHASE)));
				
				mpRelatedParts.put(ConstantsUtil.ID, sPartId);
				mpRelatedParts.put(ConstantsUtil.NAME, sPartName);
				mpRelatedParts.put(ConstantsUtil.TYPE, sPartType);
				mpRelatedParts.put(ConstantsUtil.STATE, sPartState);
				mpRelatedParts.put(ConstantsUtil.TITLE, sPartTitle);
				mpRelatedParts.put(ConstantsUtil.REV, sPartRev);
				mpRelatedParts.put(ConstantsUtil.PHASE, sPartPhase);
				mpRelatedParts.put(ConstantsUtil.OWNERSHIP, sPartOwnership);
				mpRelatedParts.put(ConstantsUtil.REV, sPartRev);*/
				
				mpRelatedParts=cdoc.getRelatedParts(context,resultMaps);
				
				if (userType){
					mpRelatedParts	 = cdoc.validateRelatedParts(context,mpRelatedParts);
					mpRelatedParts=util.filterPhase(mpRelatedParts);
				}
			}
			
			//Related ATS
			if(!isAts) {
				String sPartType = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.ATL_TYPE)));
				String sPartName = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.ATL_NAME)));
				String sPartState = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.ATL_STATE)));
				String sPartTitle = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.ATL_TITLE)));
				String sPartPhase = validator.getStringEquivalentForStringList((resultMaps.get(ConstantsUtil.ATL_RELEASE_PHASE)));
				
				mpRelatedAts.put(ConstantsUtil.NAME, sPartName);
				mpRelatedAts.put(ConstantsUtil.TYPE, sPartType);
				mpRelatedAts.put(ConstantsUtil.STATE, sPartState);
				mpRelatedAts.put(ConstantsUtil.TITLE, sPartTitle);
				mpRelatedAts.put(ConstantsUtil.PHASE, sPartPhase);
				
				if (userType){
					mpRelatedAts=util.filterPhase(mpRelatedAts);
				}
				
				mpRelatedAts=util.filterMapList(mpRelatedAts);
				if(!mpRelatedAts.isEmpty()){
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_TRUE); 
				}
				
			}
			//IP Class
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			StringList slIpSelects = new StringList();
			slIpSelects.add(ConstantsUtil.SELECT_NAME);
			slIpSelects.add(ConstantsUtil.SELECT_ID);
			slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
			slIpSelects.add(ConstantsUtil.SELECT_TYPE);
			slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			mpIPClass =commonBo.getIpClass(context, dobCdoc, slIpSelects);
			
			mpPlant.put(ConstantsUtil.PLANTS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_NAME)));
			mpPlant.put(ConstantsUtil.PLANTSAUTHORIZEDTOPRODUCE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE)));
			
			//Organizations
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME))));
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME))));
			
			
			//ATTRIBUTE SECTION
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			mpAttribResult.put(ConstantsUtil.ID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID))));
			String sDocType = util.mapType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE)));
			mpAttribResult.put(ConstantsUtil.TYPE, sDocType);
			//mpAttribResult.put(ConstantsUtil.NAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME))));
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION))));
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_OWNER))));
			mpAttribResult.put(ConstantsUtil.STATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT))));
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR))));
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))));
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);			mpAttribResult.put(ConstantsUtil.TITLE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))));
			mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT))));
			mpAttribResult.put(ConstantsUtil.SAPTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))));
			mpAttribResult.put(ConstantsUtil.RELEASEPHASE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE))));
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE))));
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE))));
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE))));
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE))));
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE))));
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION))));
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT))));
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE))));
			//mpAttribResult.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME))));
			mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE))));
			mpAttribResult.put(ConstantsUtil.IMPACTED_TYPE,ConstantsUtil.EMPTY_STRING );
			mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE))));
			
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION))));
			mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_TEMPLATE))));

			String sClassifictaion = util.getClassification(resultMaps);
			mpAttribResult.put(ConstantsUtil.SECURITY, (sClassifictaion));
			swAttributes.stop();
			LOGGER.info("COMMON DOC SERVICE GET ATTRIBUTE ELAPSED TIME : "+swAttributes.getTime());

			String 	sWhere =ConstantsUtil.EMPTY_STRING;
			if (isExternal)
			sWhere = "current!=Obsolete";
			else
			sWhere ="";
			
			if (!isAts) {
			StringList slParentOwnerShip = new StringList();
			StopWatch swSpecs = new StopWatch();
			swSpecs.start();
			StringList slBusSelects = cdoc.getContextObjectBusSelectable(context);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION,
					"Document", slBusSelects, new StringList(), false, true, (short) 1,
					sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			/*if (isExternal)
			{
				mlRelatedSpecs=util.filterPhase(mlRelatedSpecs);
				SecurityService sec = new SecurityService();
				
				String	 sParentOwnerShip =  sec.getUserCauthorities();//(StringList)mpOwnership.get(ConstantsUtil.REL_PARTSPEC_TO_FROM_OWNERSHIP);
				slParentOwnerShip = util.filterOwnerShip(sParentOwnerShip);
			}*/
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType=new StringBuilder();
			StringBuilder sbRev=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbDescription=new StringBuilder();
			StringBuilder sbTitle=new StringBuilder();
			StringBuilder sbOriginator=new StringBuilder();
			StringBuilder sbOriginatingSrc=new StringBuilder();
			StringBuilder sbPhase=new StringBuilder();
			StringBuilder sbSpecSubType=new StringBuilder();
				while(objectListItr.hasNext()) 
				{
					Map objectMap = (Map) objectListItr.next();
					String strType = (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
					String sShareWithSupplier = (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS);
					String sIPClassfication=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
					String	sOwnerShip= validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.OWNERSHIP));
					String sAttribShareWithEBP=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS);
					String soriginatingSource=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
					String soriginator=(String)objectMap.get(ConstantsUtil.SELECT_ORIGINATOR);
					
					String sPhase=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
					String specSubType=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE);
					
					if((strType.equalsIgnoreCase(ConstantsUtil.TYPE_TESTMETHODSPECIFCATION) || strType.equalsIgnoreCase(ConstantsUtil.TYPE_STANDARD_OPERATING_PROCEDURE) || strType.equals(ConstantsUtil.TYPE_PGSTANDARDOPERATINGPROCEDURE) ) && userType) 
					  {
							if (ConstantsUtil.HIGHLY_RESTRICTED.equalsIgnoreCase(sIPClassfication))
							{	
								String[] saOwnership =sOwnerShip.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
								boolean bHasOwnership = false;
								for (int i = 0; i < saOwnership.length; i++)
								{
									String sChildOwnerShip = saOwnership[i].trim();
									if(slParentOwnerShip.contains(sChildOwnerShip) && sChildOwnerShip.equals(ConstantsUtil.STR_MULTIPLE_OWNERSHIP)&& sChildOwnerShip.equals(ConstantsUtil.PROJECT_PARTNERS_PG))
										bHasOwnership=true;
										break;
								}
								//if does not macthed with ownership
								if (!bHasOwnership) 
								{
									util.formatData(sbId,ConstantsUtil.NO_ACCESS);
									util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
									util.formatData(sbType,ConstantsUtil.NO_ACCESS);
									util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
									util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
									util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
									util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
									util.formatData(sbPhase,ConstantsUtil.NO_ACCESS);
									util.formatData(sbSpecSubType,ConstantsUtil.NO_ACCESS);
									util.formatData(sbOriginator,ConstantsUtil.NO_ACCESS);
									util.formatData(sbOriginatingSrc,ConstantsUtil.NO_ACCESS);
									
								}else
								{
									//Ownershp not matches and sharable is false
									if (!ConstantsUtil.TRUE.equalsIgnoreCase(sAttribShareWithEBP))
									{
										util.formatData(sbId,ConstantsUtil.NO_ACCESS);
										util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
										util.formatData(sbType,ConstantsUtil.NO_ACCESS);
										util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
										util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
										util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
										util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
										util.formatData(sbPhase,ConstantsUtil.NO_ACCESS);
										util.formatData(sbSpecSubType,ConstantsUtil.NO_ACCESS);
										util.formatData(sbOriginator,ConstantsUtil.NO_ACCESS);
										util.formatData(sbOriginatingSrc,ConstantsUtil.NO_ACCESS);
									}else
									{
										//Ownershp matches and sharable is true
										util.formatData(sbId,(String)objectMap.get(ConstantsUtil.SELECT_ID));
										util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
										strType=util.mapType(strType);
										util.formatData(sbType,strType);
										util.formatData(sbRev,(String)objectMap.get(ConstantsUtil.SELECT_REVISION));
										util.formatData(sbDescription,(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
										util.formatData(sbTitle,(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
										util.formatData(sbCurrent,(String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
										util.formatData(sbPhase,ConstantsUtil.NO_ACCESS);
										util.formatData(sbSpecSubType,ConstantsUtil.NO_ACCESS);
										util.formatData(sbOriginator,ConstantsUtil.NO_ACCESS);
										util.formatData(sbOriginatingSrc,ConstantsUtil.NO_ACCESS);
									}
								}
						//Object is restricetd and checking the sharable attribute
						}else if(ConstantsUtil.TRUE.equalsIgnoreCase(sShareWithSupplier))
						{
							//Object is restricetd and checking the sharable attribute is true
							util.formatData(sbId,(String)objectMap.get(ConstantsUtil.SELECT_ID));
							util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
							strType=util.mapType(strType);
							util.formatData(sbType,strType);
							util.formatData(sbRev,(String)objectMap.get(ConstantsUtil.SELECT_REVISION));
							util.formatData(sbDescription,(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
							util.formatData(sbTitle,(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							util.formatData(sbCurrent,(String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
							util.formatData(sbPhase,sPhase);
							util.formatData(sbSpecSubType,specSubType);
							if(sType.equalsIgnoreCase("MI") || sType.equalsIgnoreCase("PROS") || sType.equalsIgnoreCase("LIS")) {
								util.formatData(sbOriginator,soriginator);
								util.formatData(sbOriginatingSrc,soriginatingSource);
							}else{
								util.formatData(sbOriginator,ConstantsUtil.EMPTY_STRING);
								util.formatData(sbOriginatingSrc,ConstantsUtil.EMPTY_STRING);
							}
						}
							else{
								//Object is restricetd and checking the sharable attribute is false/empty
								util.formatData(sbId,ConstantsUtil.NO_ACCESS);
								util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
								util.formatData(sbType,ConstantsUtil.NO_ACCESS);
								util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
								util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
								util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
								util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
								util.formatData(sbPhase,ConstantsUtil.NO_ACCESS);
								util.formatData(sbSpecSubType,ConstantsUtil.NO_ACCESS);
								util.formatData(sbOriginator,ConstantsUtil.NO_ACCESS);
								util.formatData(sbOriginatingSrc,ConstantsUtil.NO_ACCESS);
							}
				}else
					{
					  //For other types apart from TMS and SOP
						util.formatData(sbId,(String)objectMap.get(ConstantsUtil.SELECT_ID));
						util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
						strType=util.mapType(strType);
						util.formatData(sbType,strType);
						util.formatData(sbRev,(String)objectMap.get(ConstantsUtil.SELECT_REVISION));
						util.formatData(sbDescription,(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
						util.formatData(sbTitle,(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						util.formatData(sbCurrent,(String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
						if(sType.equalsIgnoreCase("MI") || sType.equalsIgnoreCase("PROS") || sType.equalsIgnoreCase("LIS")) {
							util.formatData(sbOriginator,soriginator);
							util.formatData(sbOriginatingSrc,soriginatingSource);
						}else{
							util.formatData(sbOriginator,ConstantsUtil.EMPTY_STRING);
							util.formatData(sbOriginatingSrc,ConstantsUtil.EMPTY_STRING);
						}
						util.formatData(sbPhase,sPhase);
						util.formatData(sbSpecSubType,specSubType);
					}
				}
				mpPartSpecResult.put(ConstantsUtil.ID, sbId.toString());
				mpPartSpecResult.put(ConstantsUtil.NAME, sbName.toString());
				mpPartSpecResult.put(ConstantsUtil.TYPE, sbType.toString());
				mpPartSpecResult.put(ConstantsUtil.REVISION, sbRev.toString());
				mpPartSpecResult.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
				mpPartSpecResult.put(ConstantsUtil.TITLE, sbTitle.toString());
				mpPartSpecResult.put(ConstantsUtil.STATE, sbCurrent.toString());
				mpPartSpecResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
				mpPartSpecResult.put(ConstantsUtil.PHASE, sbPhase.toString());
				mpPartSpecResult.put(ConstantsUtil.SOURCE, sbOriginatingSrc.toString());
				mpPartSpecResult.put(ConstantsUtil.ORIGINATOR, sbOriginator.toString());
				
				mpPartSpecResult=util.filterMapList(mpPartSpecResult);
				
				if(bManufacturerView) {
					Map<String,String> mpPartSpecResultTemp = new HashMap<String,String>();
					String sParentType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
					String sAllowedSpecs = util.getValidRelatedSpecsForPart(sParentType, sUserType);
					if(sAllowedSpecs.length()>0) {
						mpPartSpecResultTemp =  util.validatePartSpecsForEbp(context,mpPartSpecResult,sParentType,sAllowedSpecs);
						mpPartSpecResult=mpPartSpecResultTemp;
					}
				}
				
				swSpecs.stop();
				LOGGER.info("COMMON DOC SERVICE GET RELATED SPECIFICATIONS ELAPSED TIME : "+swSpecs.getTime());
			}else{
				
				mpPartSpecResult=cdoc.getPartSpecs(context,resultMaps, sType);
			}	
				/*
				 * LOAD REFERENCE DOCS SECTION
				 * */
			
					StopWatch swReferenceDoc= new StopWatch();
					swReferenceDoc.start();
					MasterCOPBO mcop = new MasterCOPBO();
					mapReferenceDocs = cdoc.updateRefDocs(context, resultMaps,false);
					mapReferenceDocs=util.filterMapList(mapReferenceDocs);
					swReferenceDoc.stop();
					LOGGER.info("COMMON DOC SERVICE  REFERENCE DOCS ELAPSED TIME : "+swReferenceDoc.getTime());
				
				//Related IAPS only for type ACS
				mpAcs.put(ConstantsUtil.NAME,  util.MapsType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ACS_NAME))));
				mpAcs.put(ConstantsUtil.TYPE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ACS_TYPE)));
				mpAcs.put(ConstantsUtil.REVISION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ACS_REV)));
				mpAcs.put(ConstantsUtil.STATE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ACS_STATE)));
				mpAcs.put(ConstantsUtil.TITLE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ACS_TITLE)));
				mpAcs.put(ConstantsUtil.ID, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ACS_ID)));
				mpAcs.put(ConstantsUtil.PHASE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ACS_PHASE)));
			
				if( sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP) &&  sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					
					mpAcs=util.filterPhase(mpAcs);
				}
				
				//Related ACS only for type IAPS
				mpIaps.put(ConstantsUtil.NAME, util.MapsType(validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_IAPS_NAME))));
				mpIaps.put(ConstantsUtil.TYPE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_IAPS_TYPE)));
				mpIaps.put(ConstantsUtil.REVISION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_IAPS_REV)));
				mpIaps.put(ConstantsUtil.STATE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_IAPS_STATE)));
				mpIaps.put(ConstantsUtil.TITLE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_IAPS_TITLE)));
				mpIaps.put(ConstantsUtil.ID, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_IAPS_ID)));
				mpIaps.put(ConstantsUtil.PHASE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_IAPS_PHASE)));
				
				if( sUserType.equalsIgnoreCase(ConstantsUtil.PG_SP) &&  sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
									
					mpIaps=util.filterPhase(mpIaps);
				}
				if(isAts && isExternal) {
					//part
					hmAttrib.put(ConstantsUtil.RELATEDPARTS, mpRelatedParts);
				} 
				else if(isAts && isInternal) {
					//part, plant, IPClass
					hmAttrib.put(ConstantsUtil.RELATEDPARTS, mpRelatedParts);
					hmAttrib.put(ConstantsUtil.PLANTS, mpPlant);
					hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
				} 
				else if(!isAts) {
					if(isExternal) {
						//ats
						mpRelatedAts=util.filterMapList(mpRelatedAts);
						if(!mpRelatedAts.isEmpty()){
							mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_TRUE); 
						}
						hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);
					}else {
						if (sObjectType.equalsIgnoreCase("pgPackingInstructions")
								|| sObjectType.equalsIgnoreCase("pgStackingPattern")
								|| sObjectType.equalsIgnoreCase("pgIllustration")
								|| sObjectType.equalsIgnoreCase("pgQualitySpecification")
								|| sObjectType.equalsIgnoreCase("pgRawMaterialPlantInstruction")
								|| sObjectType.equalsIgnoreCase("pgStandardOperatingProcedure")
								|| sObjectType.equalsIgnoreCase("Test Method Specification")) {
							//ats, ipclasss
							mpRelatedAts=util.filterMapList(mpRelatedAts);
							if(!mpRelatedAts.isEmpty()){
								mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_TRUE); 
							}
							hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
							hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);
						} 
						else if(sObjectType.equalsIgnoreCase("pgMakingInstructions")
								|| sObjectType.equalsIgnoreCase("pgProcessStandard")
								|| sObjectType.equalsIgnoreCase("pgLaboratoryIndexSpecification")) {
							//Plant, ats, IPclass
							hmAttrib.put(ConstantsUtil.PLANTS, mpPlant);
							hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);
							hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
						}
						else if(isAcs) {
							//plant, ats, IAPS, IPclass
							hmAttrib.put(ConstantsUtil.PLANTS, mpPlant);
							hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);
							hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
							hmAttrib.put(ConstantsUtil.RELIAPS, mpIaps);
						}
						else if(isIaps) {
							//plant, ats, ACS, IPclass
							hmAttrib.put(ConstantsUtil.PLANTS, mpPlant);
							hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedAts);
							hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
							hmAttrib.put(ConstantsUtil.RELACS, mpAcs);
						}
					}
					
				}
				
				//Mandatory outputs
				hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
				hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONS, mpOrganization);
				hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
				hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
				
				System.out.println("hmAttrib---------->"+hmAttrib);
				pool.checkIn(context);
			LOGGER.info("CommonDocument MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "COMMON DOC SERVICE OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		}catch (Exception e) {
			LOGGER.error("Exception in getCommonDocdata: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		//Subhajit Added for Memory Leakage Analysis - Start
		if(null!=context) {
		context.close();
		}
		//Subhajit Added for Memory Leakage Analysis - End
	}
}
