package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaCMService {
	
	public HashMap<String, Map<String, String>> getCMdata(String objId, Environment env) throws Exception;
}
