
/**
 * Project 		: SpecsAnywhere
 * Program 		: ApprovedSupplierListBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import javax.naming.CommunicationException;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.EncryptCrypto;
import com.pg.us.specanywhere_enovia.utility.FileUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.AttributeList;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class ApprovedSupplierListBO extends BusinessObject{

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(ApprovedSupplierListBO.class);

	public ApprovedSupplierListBO() {
		// empty constructor
	}

	public ApprovedSupplierListBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getASLBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getASLBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name : getASLDO
	 * Method Description : Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getASLDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getApprovedSupplierListBasisSelectables
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getApprovedSupplierListBasisSelectables(Context context) {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));  // Gets all basic attribute info selectables
		busSelect.addAll(getSAPSelectable(context));
		//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- START
		busSelect.addAll(getSecuritySelects(context));
		//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- END
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT); 
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_SAPDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS); 
		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE); 
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- START
		busSelect.add(ConstantsUtil.REL_ATS_STATE);
		busSelect.add(ConstantsUtil.REL_ATS_NAME);
		busSelect.add(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME);
		busSelect.add(ConstantsUtil.strSegment);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COCREATORS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- END

		return busSelect;
	}

	
	/**
	 * Method Name 			: getSAPSelectable
	 * Method Description 	: Fetching "SAP" related data
	 * @param context
	 * @return
	 */
	public static StringList getSAPSelectable (Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_SAP_NAME);
		busSelect.add(ConstantsUtil.SELECT_SAP_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_SAP_REVISION);
		busSelect.add(ConstantsUtil.SELECT_SAP_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);
		
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- START
		busSelect.add(ConstantsUtil.SELECT_SAP_ID);
		busSelect.add(ConstantsUtil.SELECT_SAP_TYPE);
		busSelect.add(ConstantsUtil.SELECT_SAP_PHASE);
		busSelect.add(ConstantsUtil.SELECT_SAP_TITLE);
		busSelect.add(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- END
		
		return busSelect;
	}

	
	//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- START
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList() {
		
		StringList slMultiSelects = new StringList();
		
		slMultiSelects.add(ConstantsUtil.ATL_NAME);
		slMultiSelects.add(ConstantsUtil.ATL_TITLE);
		slMultiSelects.add(ConstantsUtil.ATL_ID);
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		slMultiSelects.add(ConstantsUtil.ATTRIBUTE_PGORIGINATINGSOURCE);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		slMultiSelects.add(ConstantsUtil.ATL_REVISION);
		slMultiSelects.add(ConstantsUtil.ATL_TYPE);
		slMultiSelects.add(ConstantsUtil.ATL_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.ATL_IPCLASSIFICATION);

		slMultiSelects.add(ConstantsUtil.REL_ATS_NAME);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TITLE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_ID);
		slMultiSelects.add(ConstantsUtil.REL_ATS_STATE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_REV);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_RELEASE_PHASE);

		slMultiSelects.add(ConstantsUtil.STR_IPCLASS);

		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PLANT_LINE_SPECIFIC);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONSTATUS);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_CLASSIFICATION);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUPPLIERTRADENAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_COUNTRY);
		slMultiSelects.add(ConstantsUtil.STR_PARTSPEC_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_MANUFACTURER);
		slMultiSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_TRADERDISTRIBUTER);

		slMultiSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);

		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- START
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_DESCRIPTION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_REVISION);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_CURRENT);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_SAP_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- END
		
		return slMultiSelects;
		
	}
	
	
	/**
	 * Method Name 			: removeMultiList
	 * Method Description 	:
	 */
	public  void removeMultiList() {
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_RELEASE_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.ATL_IPCLASSIFICATION);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_REV);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_RELEASE_PHASE);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PLANT_LINE_SPECIFIC);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONSTATUS);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PG_CLASSIFICATION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_SUPPLIERTRADENAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_COUNTRY);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_PARTSPEC_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_MANUFACTURER);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_TRADERDISTRIBUTER);
		
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- START
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_NAME);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_DESCRIPTION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_REVISION);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_CURRENT);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_EXPIRATION_DATE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_ID);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TYPE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_PHASE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SAP_TITLE);
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_SUPERSEDESONDATE);
		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 1, 2021 -- END
	}
	
	
	/**
	 * Method Name 			: getEDList
	 * Method Description 	: 
	 * @param resultMaps
	 * @return
	 */
	public static String getEDList(Map resultMaps,String ldapuser,String ldappwd) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		String sAttrVal =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION) : ConstantsUtil.EMPTY_STRING;
		String strAttrValue=ConstantsUtil.EMPTY_STRING;
		String strValue=ConstantsUtil.EMPTY_STRING;
		StringTokenizer newValues=null;
		StringList strList=new StringList();

		if (sAttrVal != null && sAttrVal.trim().length() > 0) {
			newValues=new StringTokenizer(sAttrVal,ConstantsUtil.SYMBL_PIPE);
			while(newValues.hasMoreTokens())
			{
				strAttrValue=newValues.nextToken();
				if(null!=strAttrValue && (!strAttrValue.isEmpty())){
					strAttrValue = util.getLDAPInfo(strAttrValue.trim(), true,ldapuser,ldappwd);
					strList.addElement(strAttrValue);
					strList.sort();
					strValue = FrameworkUtil.join(strList, ConstantsUtil.SYMBL_PIPE);
				}
			}
		}
		return strValue;
	}
	
	
	/**
	 * Method Name 			: GetSupplierInfo
	 * Method Description 	: 
	 * @param context
	 * @param objectMap
	 * @return
	 * @throws Exception
	 */
	public Map GetSupplierInfo(Context context , Map objectMap) throws Exception{
		
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		Map<String,String> mpSuplierInfo = new HashMap<String,String>();
		
		StringBuilder sbChg = new StringBuilder();
		StringBuilder sbManufacturer = new StringBuilder();
		StringBuilder sbManufacturerVendorNo = new StringBuilder();
		StringBuilder sbManufacturerPlantLocationCityState = new StringBuilder();
		StringBuilder sbManufacturerPlantLocationMarket = new StringBuilder();
		StringBuilder sbManufacturerLines = new StringBuilder();
		StringBuilder sbTraderOrDistributer = new StringBuilder();
		StringBuilder sbTraderOrDistributerVendorNo = new StringBuilder();
		StringBuilder sbManufacturerQualificationStatus = new StringBuilder();
		StringBuilder sbManufacturerClassification = new StringBuilder();
		StringBuilder sbMaterialTradeName = new StringBuilder();
		StringBuilder sbSupplierInfoSheetName = new StringBuilder();
		//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- START
		StringBuilder sbSupplierInfoSheetId = new StringBuilder();
		StringBuilder sbSupplierInfoSheetType = new StringBuilder();
		//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- END
		
		StringList busSelects = new StringList();
		busSelects.add(ConstantsUtil.SELECT_ID);
		busSelects.add(ConstantsUtil.SELECT_TYPE);
		busSelects.add(ConstantsUtil.SELECT_NAME);
		busSelects.add(ConstantsUtil.SELECT_REVISION);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PLANT_LINE_SPECIFIC);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONSTATUS);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PG_CLASSIFICATION);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUPPLIERTRADENAME);
		busSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_NAME);
		busSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_ID);
		busSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY);
		busSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE);
		busSelects.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_COUNTRY);
		busSelects.add(ConstantsUtil.STR_PARTSPEC_NAME);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_MANUFACTURER);
		busSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_TRADERDISTRIBUTER);
		//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- START
		busSelects.add(ConstantsUtil.STR_PARTSPEC_ID);
		busSelects.add(ConstantsUtil.STR_PARTSPEC_TYPE);
		busSelects.add(ConstantsUtil.STR_PARTSPEC_STATE);
		//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- END
		
		StringList relSelects = new StringList();
		
		String sContextObjectId = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_ID))?(String)objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		
		try 
		{	
			DomainObject doASL = new DomainObject(sContextObjectId);
			MapList mlSupplierInfo = doASL.getRelatedObjects(context,ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLISTROW, ConstantsUtil.QUERY_WILDCARD, busSelects,
					relSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doASL.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator objectListItr = mlSupplierInfo.iterator();
			while(objectListItr.hasNext())
			{
				Map resultMap = (Map) objectListItr.next();
				
				String strChg = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
				
				String strClassType = validator.getClassType(resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_NAME));
				String strManufacturer = ConstantsUtil.EMPTY_STRING;
				String strManufacturerVendorNo = ConstantsUtil.EMPTY_STRING;
				String strManufacturerPlantLocationCity = ConstantsUtil.EMPTY_STRING;
				String strManufacturerPlantLocationState = ConstantsUtil.EMPTY_STRING;
				String strManufacturerPlantLocationCityState = ConstantsUtil.EMPTY_STRING;
				String strManufacturerPlantLocationMarket = ConstantsUtil.EMPTY_STRING;
				if(strClassType.equalsIgnoreCase(ConstantsUtil.STRING)) {
					strManufacturer = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_NAME));
					strManufacturerVendorNo = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_ID));
					strManufacturerPlantLocationCity = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY));
					strManufacturerPlantLocationState = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE));
					strManufacturerPlantLocationCityState = validator.getStringEquivalentForSubstituteString(strManufacturerPlantLocationCity+ConstantsUtil.SYMBL_COMMA+strManufacturerPlantLocationState);
					strManufacturerPlantLocationMarket = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_COUNTRY));
				}
				else {
					String strManufacturerDetails = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_MANUFACTURER));
					StringList strCSSManufacturerList = FrameworkUtil.split(strManufacturerDetails, ConstantsUtil.SYMBL_TILDA);
					if(!strCSSManufacturerList.isEmpty()){
						strManufacturer = validator.getStringEquivalentForSubstituteString(strCSSManufacturerList.get(0));
						strManufacturerPlantLocationCity = validator.getStringEquivalentForSubstituteString(strCSSManufacturerList.get(2));
						strManufacturerPlantLocationState = validator.getStringEquivalentForSubstituteString(strCSSManufacturerList.get(3));
						strManufacturerPlantLocationCityState = validator.getStringEquivalentForSubstituteString(strManufacturerPlantLocationCity+ConstantsUtil.SYMBL_COMMA+strManufacturerPlantLocationState);
						strManufacturerPlantLocationMarket = validator.getStringEquivalentForSubstituteString(strCSSManufacturerList.get(4));
						strManufacturerVendorNo = validator.getStringEquivalentForSubstituteString(strCSSManufacturerList.get(5));
					}
				}
				String strManufacturerLines = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PLANT_LINE_SPECIFIC));
				String strTraderDistributorDetails = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_TRADERDISTRIBUTER));
				StringList strCSSTraderDistributorList = FrameworkUtil.split(strTraderDistributorDetails, ConstantsUtil.SYMBL_TILDA);
				String strTraderOrDistributer = ConstantsUtil.EMPTY_STRING;
				String strTraderOrDistributerVendorNo = ConstantsUtil.EMPTY_STRING;
				if(!strCSSTraderDistributorList.isEmpty()){
					strTraderOrDistributer = validator.getStringEquivalentForSubstituteString(strCSSTraderDistributorList.get(0));
					strTraderOrDistributerVendorNo = validator.getStringEquivalentForSubstituteString(strCSSTraderDistributorList.get(5));
				}
				String strManufacturerQualificationStatus = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUALIFICATIONSTATUS));
				String strManufacturerClassification = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_CLASSIFICATION));
				String strMaterialTradeName = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SUPPLIERTRADENAME));
				String strSupplierInfoSheetName = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.STR_PARTSPEC_NAME));
				//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- START
				String strSupplierInfoSheetId = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.STR_PARTSPEC_ID));
				String strSupplierInfoSheetType = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.STR_PARTSPEC_TYPE));
				//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- END
				
				util.formatData(sbChg, strChg);
				util.formatData(sbManufacturer, strManufacturer);
				util.formatData(sbManufacturerVendorNo, strManufacturerVendorNo);
				util.formatData(sbManufacturerPlantLocationCityState, strManufacturerPlantLocationCityState);
				util.formatData(sbManufacturerPlantLocationMarket, strManufacturerPlantLocationMarket);
				util.formatData(sbManufacturerLines, strManufacturerLines);
				util.formatData(sbTraderOrDistributer, strTraderOrDistributer);
				util.formatData(sbTraderOrDistributerVendorNo, strTraderOrDistributerVendorNo);
				util.formatData(sbManufacturerQualificationStatus, strManufacturerQualificationStatus);
				util.formatData(sbManufacturerClassification, strManufacturerClassification);
				util.formatData(sbMaterialTradeName, strMaterialTradeName);
				util.formatData(sbSupplierInfoSheetName, strSupplierInfoSheetName);
				//SPEC: 04/28/2021: Modified for EBP SR18x.6 by Manikanta for Req# 35948-- START
				boolean bObjectHasAccess = util.checkHasAccess(context, null, sContextObjectId);
				//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- START
				if(bObjectHasAccess && (validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.STR_PARTSPEC_STATE)).equals(ConstantsUtil.RELEASE)||validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.STR_PARTSPEC_STATE)).equalsIgnoreCase(ConstantsUtil.RELEASED))) {
					util.formatData(sbSupplierInfoSheetId, strSupplierInfoSheetId);
				}
				else {
					util.formatData(sbSupplierInfoSheetId, ConstantsUtil.NO_ACCESS);
				}
				util.formatData(sbSupplierInfoSheetType, strSupplierInfoSheetType);
				//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- END
				//SPEC: 04/28/2021: Modified for EBP SR18x.6 by Manikanta for Req# 35948-- END
			}
			
			mpSuplierInfo.put(ConstantsUtil.CHANGE,sbChg.toString());
			mpSuplierInfo.put(ConstantsUtil.MANUFACTURER,sbManufacturer.toString());
			mpSuplierInfo.put(ConstantsUtil.MANUFACTURERNUMBER,sbManufacturerVendorNo.toString());
			mpSuplierInfo.put(ConstantsUtil.MANUFACTUREPLANTLOCATIONCITY,sbManufacturerPlantLocationCityState.toString());
			mpSuplierInfo.put(ConstantsUtil.MANUFACTUREPLANTLOCATIONCONTRY,sbManufacturerPlantLocationMarket.toString());
			mpSuplierInfo.put(ConstantsUtil.MANUFACTURERLINES,sbManufacturerLines.toString());
			mpSuplierInfo.put(ConstantsUtil.TRADERDISTIBUTOR,sbTraderOrDistributer.toString());
			mpSuplierInfo.put(ConstantsUtil.TRADERDISTIBUTORVENDORNUMBER,sbTraderOrDistributerVendorNo.toString());
			mpSuplierInfo.put(ConstantsUtil.MANUFACTURERQUALIFICATIONSTATUS,sbManufacturerQualificationStatus.toString());
			mpSuplierInfo.put(ConstantsUtil.MANUFACTURECLASSIFICATION,sbManufacturerClassification.toString());
			mpSuplierInfo.put(ConstantsUtil.MATERIALTRADENAME,sbMaterialTradeName.toString());
			mpSuplierInfo.put(ConstantsUtil.SUPPLIERINFOSHEETNAME,sbSupplierInfoSheetName.toString());
			//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- START
			mpSuplierInfo.put(ConstantsUtil.SUPPLIERINFOSHEETID,sbSupplierInfoSheetId.toString());
			mpSuplierInfo.put(ConstantsUtil.SUPPLIERINFOSHEETTYPE,sbSupplierInfoSheetType.toString());
			//SPEC: 01/18/2021: Added for SR18x.5.2 by Amman ## -- END
			
		} catch (Exception e) {
			LOGGER.error("Exception in Program : ASLBO Method :GetSupplierInfo "+e);
			return new HashMap();
		}
		return mpSuplierInfo;
	}
	
	
	/**
	 * Method Name 			: GetInternalInfo
	 * Method Description 	: 
	 * @param context
	 * @param objectMap
	 * @return
	 * @throws Exception
	 */
	public Map GetInternalInfo(Context context , Map objectMap) throws Exception{
		
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		Map<String,String> mpInternalInfo = new HashMap<String,String>();
		
		StringBuilder sbChg = new StringBuilder();
		StringBuilder sbManufacturer = new StringBuilder();
		StringBuilder sbManufacturerPlantLocationCityState = new StringBuilder();
		StringBuilder sbTraderOrDistributer = new StringBuilder();
		StringBuilder sbUsingPlantLocation = new StringBuilder();
		StringBuilder sbUsingGBU = new StringBuilder();
		StringBuilder sbCategory = new StringBuilder();
		StringBuilder sbBrand = new StringBuilder();
		StringBuilder sbProductName = new StringBuilder();
		StringBuilder sbPSRA = new StringBuilder();
		StringBuilder sbComments = new StringBuilder();
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
		busSelect.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY);
		busSelect.add(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE);
		busSelect.add(ConstantsUtil.SELECT_MANUFACTURINGRESPONSIBILITY_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGBU);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCATEGORY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PSRAINFORMATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_MANUFACTURER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_TRADERDISTRIBUTER);
		
		StringList relSelect = new StringList();
		
		String sContextObjectId = validator.isNotNullOrEmpty((String)objectMap.get(ConstantsUtil.SELECT_ID))?(String)objectMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		
		try 
		{
			DomainObject doASL = new DomainObject(sContextObjectId);
			MapList mlInternalInfo = doASL.getRelatedObjects(context,ConstantsUtil.RELATIONSHIP_PGAPPROVEDSUPPLIERLISTROW, ConstantsUtil.QUERY_WILDCARD, busSelect,
					relSelect, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doASL.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			Iterator objectListItr = mlInternalInfo.iterator();
			while(objectListItr.hasNext())
			{
				Map resultMap = (Map) objectListItr.next();
				
				String strChg = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
				
				String strClassType = validator.getClassType(resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_NAME));
				String strManufacturer = ConstantsUtil.EMPTY_STRING;
				String strManufacturerPlantLocationCity = ConstantsUtil.EMPTY_STRING;
				String strManufacturerPlantLocationState = ConstantsUtil.EMPTY_STRING;
				String strManufacturerPlantLocationCityState = ConstantsUtil.EMPTY_STRING;
				if(strClassType.equalsIgnoreCase(ConstantsUtil.STRING)) {
					strManufacturer = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_ORGANIZATION_NAME));
					strManufacturerPlantLocationCity = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY))?(String)resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_CITY):ConstantsUtil.EMPTY_STRING;
					strManufacturerPlantLocationState = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE))?(String)resultMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_STATE):ConstantsUtil.EMPTY_STRING;
					strManufacturerPlantLocationCityState = validator.getStringEquivalentForSubstituteString(strManufacturerPlantLocationCity+ConstantsUtil.SYMBL_COMMA+strManufacturerPlantLocationState);
				}
				else {
					String strManufacturerDetails = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_MANUFACTURER));
					StringList strCSSManufacturerList = FrameworkUtil.split(strManufacturerDetails, ConstantsUtil.SYMBL_TILDA);
					if(!strCSSManufacturerList.isEmpty()){
						strManufacturer = validator.getStringEquivalentForSubstituteString(strCSSManufacturerList.get(0));
						strManufacturerPlantLocationCity = validator.getStringEquivalentForSubstituteString(strCSSManufacturerList.get(2));
						strManufacturerPlantLocationState = validator.getStringEquivalentForSubstituteString(strCSSManufacturerList.get(3));
						strManufacturerPlantLocationCityState = validator.getStringEquivalentForSubstituteString(strManufacturerPlantLocationCity+ConstantsUtil.SYMBL_COMMA+strManufacturerPlantLocationState);
					}
				}
				String strTraderDistributorDetails = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSS_TRADERDISTRIBUTER));
				StringList strCSSTraderDistributorList = FrameworkUtil.split(strTraderDistributorDetails, ConstantsUtil.SYMBL_TILDA);
				String strTraderOrDistributer = ConstantsUtil.EMPTY_STRING;
				if(!strCSSTraderDistributorList.isEmpty()){
					strTraderOrDistributer = validator.getStringEquivalentForSubstituteString(strCSSTraderDistributorList.get(0));
				}
				String strUsingPlantLocation = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_MANUFACTURINGRESPONSIBILITY_NAME));
				String strUsingGBU = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGBU));
				String strCategory = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCATEGORY));
				String strBrand = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND));
				String strProductName = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCT));
				String strPSRA = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PSRAINFORMATION));
				String strComments = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
				
				util.formatData(sbChg, strChg);
				util.formatData(sbManufacturer, strManufacturer);
				util.formatData(sbManufacturerPlantLocationCityState, strManufacturerPlantLocationCityState);
				util.formatData(sbTraderOrDistributer, strTraderOrDistributer);
				util.formatData(sbUsingPlantLocation, strUsingPlantLocation);
				util.formatData(sbUsingGBU, strUsingGBU);
				util.formatData(sbCategory, strCategory);
				util.formatData(sbBrand, strBrand);
				util.formatData(sbProductName, strProductName);
				util.formatData(sbPSRA, strPSRA);
				util.formatData(sbComments, strComments);
			}
			
			mpInternalInfo.put(ConstantsUtil.CHANGE,sbChg.toString());
			mpInternalInfo.put(ConstantsUtil.MANUFACTURER,sbManufacturer.toString());
			mpInternalInfo.put(ConstantsUtil.MANUFACTUREPLANTLOCATIONCITY,sbManufacturerPlantLocationCityState.toString());
			mpInternalInfo.put(ConstantsUtil.TRADERDISTIBUTOR,sbTraderOrDistributer.toString());
			mpInternalInfo.put(ConstantsUtil.USINGPLANTLOCATION,sbUsingPlantLocation.toString());
			mpInternalInfo.put(ConstantsUtil.USINGGBU,sbUsingGBU.toString());
			mpInternalInfo.put(ConstantsUtil.CATEGORY,sbCategory.toString());
			mpInternalInfo.put(ConstantsUtil.BRAND,sbBrand.toString());
			mpInternalInfo.put(ConstantsUtil.PRODUCTNAME,sbProductName.toString());
			mpInternalInfo.put(ConstantsUtil.PSRA,sbPSRA.toString());
			mpInternalInfo.put(ConstantsUtil.COMMENTS,sbComments.toString());
			
		} catch (Exception e) {
			LOGGER.error("Exception in Program : ASLBO Method :GetInternalInfo "+e);
			return new HashMap();
		}
		return mpInternalInfo;
	}
	
	
	/**
	 * Method Name 			: getIpSelects
	 * Method Description 	:
	 * @return
	 */
	public static StringList getIpSelects() {
		
		StringList slIpSelects = new StringList();
		slIpSelects.add(ConstantsUtil.SELECT_NAME);
		slIpSelects.add(ConstantsUtil.SELECT_ID);
		slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
		slIpSelects.add(ConstantsUtil.SELECT_TYPE);
		slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		
		return slIpSelects;
	}
	
	
	/**
	 * Method Name 			: getIpClass
	 * Method Description 	:
	 * @param context
	 * @param doFormObj
	 * @param slIpSelects
	 * @return
	 */
	public static Map<String,String> getIpClass(Context context, DomainObject doFormObj, StringList slIpSelects) {
    	
		Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
    	MapList mlIPCLass;
    	
		try {
			mlIPCLass = doFormObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_CLASSIFIEDITEM, ConstantsUtil.TYPE_IPCONTROLCLASS, slIpSelects,
					null, true, false, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING,
					ConstantsUtil.ZERO_LEVEL);
			Iterator itr = mlIPCLass.iterator();
			Map mpIpClass = new HashMap();
			StringBuilder sbIpName = new StringBuilder();
			StringBuilder sbHasClassAccess = new StringBuilder();
			StringBuilder sbIpType = new StringBuilder();
			StringBuilder sbIpDesc = new StringBuilder();
			StringBuilder sbIpState = new StringBuilder();
			StringBuilder sbIpLibrary = new StringBuilder();
			StringBuilder sbIpClassPath = new StringBuilder();
			
			while(itr.hasNext()) {
				mpIpClass = (Map)itr.next();
				String sIpClassName = (String)mpIpClass.get(ConstantsUtil.SELECT_NAME);
				sbIpName.append(sIpClassName);
				sbIpType.append((String)mpIpClass.get(ConstantsUtil.SELECT_TYPE));
				sbIpDesc.append((String)mpIpClass.get(ConstantsUtil.SELECT_DESCRIPTION));
				sbIpState.append((String)mpIpClass.get(ConstantsUtil.SELECT_CURRENT));
				String strIpClass="";
				if(sIpClassName.contains(ConstantsUtil.HIR)) {
					strIpClass=ConstantsUtil.HIGHLY_RESTRICTED;
					sbIpLibrary.append(strIpClass);
				} else {
					strIpClass= ConstantsUtil.BUSINESS_USE;
					sbIpLibrary.append(ConstantsUtil.BUSINESS_USE);
				}
				if(!strIpClass.isEmpty()) {
					StringBuilder sbIpClassTemp = new StringBuilder();
					sbIpClassTemp.append(strIpClass).append("->").append(sIpClassName);
					sbIpClassPath.append(sbIpClassTemp.toString());
				}
				
				//Compare user classification against IPName
				sbHasClassAccess.append("TRUE");
				
				if(itr.hasNext()) {
					sbIpName.append("|");
					sbIpType.append("|");
					sbIpDesc.append("|");
					sbIpState.append("|");
					sbIpLibrary.append("|");
					sbIpClassPath.append("|");
					sbHasClassAccess.append("|");
				}
			}
			mpIpSecuritySetting.put(ConstantsUtil.NAME, sbIpName.toString());
			mpIpSecuritySetting.put(ConstantsUtil.TYPE, sbIpType.toString());
			mpIpSecuritySetting.put(ConstantsUtil.DESCRIPTION, sbIpDesc.toString());
			mpIpSecuritySetting.put(ConstantsUtil.STATE, sbIpState.toString());
			
			//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 1, 2021 -- START
			//mpIpSecuritySetting.put(ConstantsUtil.LIBRARY, sbIpLibrary.toString());
			//mpIpSecuritySetting.put(ConstantsUtil.CLASSIFICATIONPATH, sbIpClassPath.toString());
			//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 1, 2021 -- END
			
			mpIpSecuritySetting.put(ConstantsUtil.HASCLASSACCESS, sbHasClassAccess.toString());
			
		} catch (FrameworkException e) {
			e.printStackTrace();
			LOGGER.error("Error from ASLBO: getIpClass" + e);
		}
		return mpIpSecuritySetting;
    }
	
	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	private static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);

		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getOriginatorName
	 * Method Description 	: 
	 * @param context
	 * @param args
	 * @return
	 */
	public String getOriginatorName(Context context, Map resultMap,String ldapuser,String ldappwd) 
	{	
		String strOriginatorName = ConstantsUtil.EMPTY_STRING;
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		try {
			String objectId = (String)resultMap.get(ConstantsUtil.ID);
			DomainObject doj = DomainObject.newInstance(context, objectId);
			String strAttributeValue = (String)doj.getInfo(context,DomainConstants.SELECT_ORIGINATOR);
			//SPEC: Release 22x - Modified for Requirement 43397 - JVM Crash Issue, by Sanjeeva -- START
			strOriginatorName =	util.getUserName(context,strAttributeValue,ldapuser,ldappwd);
			//SPEC: Release 22x - Modified for Requirement 43397 - JVM Crash Issue, by Sanjeeva -- END
			
		} catch (Exception ex) {
			LOGGER.error("Error from ASLBO: getOriginatorName" + ex);
			strOriginatorName = ConstantsUtil.EMPTY_STRING;
		}
		return strOriginatorName;
	}
	
	
	/**
	 * Metgod Name 			: getCoOwnersList
	 * Method Description 	:
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public String getCoOwnersList(Context context, Map resultMap,String ldapuser,String ldappwd) throws Exception 
	{
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		String strValue = ConstantsUtil.EMPTY_STRING;

		try {
			String sAttrVal = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COCREATORS)) ? (String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COCREATORS) : ConstantsUtil.EMPTY_STRING;
			String strAttrValue = ConstantsUtil.EMPTY_STRING;
			StringTokenizer newValues = null;
			StringList strList=new StringList();

			if (sAttrVal != null && sAttrVal.trim().length() > 0) {
				newValues=new StringTokenizer(sAttrVal,ConstantsUtil.SYMBL_PIPE);
				while(newValues.hasMoreTokens()) {
					strAttrValue=newValues.nextToken();
					if(null!=strAttrValue && (!strAttrValue.isEmpty())) {
						strAttrValue = util.getLDAPInfo(strAttrValue.trim(), true,ldapuser,ldappwd);
					}
					strList.addElement(strAttrValue);
				}
			}
			strList.sort();
			strValue = FrameworkUtil.join(strList,ConstantsUtil.SYMBL_PIPE);
			
		} catch (Exception ex) {
			LOGGER.error("Error from ASLBO: getCoOwnersList " + ex);
			strValue = ConstantsUtil.EMPTY_STRING;
		}
		return strValue;
	}
	
	
	/**
	 * Method Name 			: updateRefDocs
	 * Method Description 	: 
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map updateRefDocs(Context context,Map resultMaps) 
	{
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		
		boolean bHasOwnerShip = false;
		
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		CommonDocBO commonDoc = new CommonDocBO();
		FileUtil fileUtil = new FileUtil();
		
		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sObjectType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

		Map<String, String> mpRefDoc = new HashMap();
		
		try
		{
			DomainObject dobCdoc = new DomainObject(sObjectId);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dobCdoc.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			String sUser = util.getUserType();
		
			if(sUser.equals(ConstantsUtil.PG_CM))
			{
				if(sObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)){
					return new HashMap();
				}
			}
			
			
			Iterator objectListItr = mlRelatedSpecs.iterator();
			
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType=new StringBuilder();
			StringBuilder sbRev=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbDescription=new StringBuilder();
			StringBuilder sbTitle=new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			StringBuilder sbSource = new StringBuilder();
			StringBuilder sbFilePath = new StringBuilder();
			StringBuilder sbCSSType = new StringBuilder();
			StringBuilder sbGendocName = new StringBuilder();
			StringBuilder sbGendocPath = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
			// : 02-08-2021 -- START
			StringBuilder sbIsIRM = new StringBuilder();
			StringBuilder sbGendocFormat = new StringBuilder();
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
			// : 02-08-2021 -- END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sCSSType    =  (String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
				
				if(sCSSType!=null) 
				{
					switch (sCSSType.trim())
					{
					case "Reference_File":
						sCSSType = "Reference File";
						break;

					case "QEC_File":
						sCSSType = "Quality Evolution Chart File";
						break;

					case "Design_File":
						sCSSType = "Design File";
						break;
						
					case "Language_Rendition":
						sCSSType = "Language Rendition";
						break;
						
					default:
						sCSSType = sCSSType;
						break;
					}
				}
				
				String sId		=	(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sName    =   (String)objectMap.get(ConstantsUtil.STR_FILE_NAME);

				if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sCurrent.equals("Exists") && sRev.equalsIgnoreCase("Rendition")) {
					sName    =   (String)objectMap.get(ConstantsUtil.SELECT_NAME);
				}
				
				String sFilePath    =   (String)objectMap.get(ConstantsUtil.STR_FILE_CAPTURED);
				String sDesc	=	(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sTitle	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String strClassFied = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				StringList eachOwnership = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);
				
				SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				
				boolean showData = false;
				if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_OBSOLETE)) {
					continue;
				}
				if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
					continue;
				}
				
				// SPEC: Added for 18x.5.2 DEV --Shashank -- START
				Map mpFiles = new HashMap();
				DomainObject doRefDoc = new DomainObject(sId);
				boolean bisIRMDoc = commonDoc.isIRMDoc(sType);
				String sGendocName="";
				String sGendocPath="";
				// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments
				// On : 02-08-2021 -- START
				String sGendocPathFormat = "";
				// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments
				// On : 02-08-2021 -- END
				if(bisIRMDoc) {
					mpFiles=fileUtil.getGendocForIRM(context, doRefDoc);
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
				}else {
					// SPEC: Modified for 18x.5.2 DEV -- Guna For ReferenceDocuments
					// On : 02-08-2021 -- START
					//mpFiles=fileUtil.getGendocForReferenceDocuments(context, doRefDoc);
					//Guna modified for defect 38266 release 18x.5.2 -- START
					//mpFiles=fileUtil.getGendocForReferenceDocuments(context, doRefDoc);
					mpFiles = fileUtil.getFilesForIPM(context, doRefDoc);
					//Guna modified for defect 38266 release 18x.5.2 -- END
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
					sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					sGendocPathFormat = validator
							.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
					// SPEC: Modified for 18x.5.2 DEV -- Guna For ReferenceDocuments
					// On : 02-08-2021 -- END
				}
				// SPEC: Added for 18x.5.2 DEV --Shashank -- END
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doRefDoc.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- START
				if(bisIRMDoc){
					sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				}
				//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- END
				String sLangBuffer =ConstantsUtil.EMPTY_STRING;
				if(!sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR))
				{
					
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
					{
						sLangBuffer=sPGLangBuffer;
					}
					else 
					{
						sLangBuffer=sPLangBuffer;
					}

				if (util.isModificatinRequired()) 
				{
					//bHasOwnerShip = util.checkOwnerShip(sbCompany,slEachOwnership);
					//Added by Ganesh start
					bHasOwnerShip = util.checkHasAccess(context, null, sId);
					//Added by Ganesh stop
					if(!ConstantsUtil.RELEASED.equalsIgnoreCase(sCurrent)
							&& !(ConstantsUtil.STATE_RELEASE.equalsIgnoreCase(sCurrent))) {
						bHasOwnerShip=false;
					}
					if(bHasOwnerShip) 
					{
						util.formatData(sbType,util.mapType(sType));
						util.formatData(sbCSSType,sCSSType);
						util.formatData(sbName,sName);
						util.formatData(sbDescription,sDesc);
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbId,sId);
						util.formatData(sbRev,sRev);
						util.formatData(sbTitle,sTitle);
						util.formatData(sbSource,ConstantsUtil.EMPTY_STRING);
						util.formatData(sbLangBuffer,sLangBuffer);
						util.formatData(sbFilePath,sFilePath);
						util.formatData(sbGendocName, sGendocName);
						util.formatData(sbGendocPath, sGendocPath);
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, sGendocPathFormat);
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
					}
				}else if(sct.isStaffAUGUser()) {
					/*if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART) || sType.equalsIgnoreCase("Formulation Part")){
						String sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}*/
					//Added by Ganesh start
					showData = util.checkHasAccess(context, null, sId);
					//Added by ganesh stop
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
						showData=false;
					}
				}else {
					/*StringList slHIRTypes = new StringList();
					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
					slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

					if(slHIRTypes.contains(sType)) {
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
					}else {
						showData=true;
					}*/
					//Added by Ganesh start
					showData = util.checkHasAccess(context, null, sId);
					//Added by Ganesh stop
				}	

				if(showData) 
				{
						util.formatData(sbType,util.mapType(sType));
						util.formatData(sbCSSType,sCSSType);
						util.formatData(sbName,sName);
						util.formatData(sbFilePath,sFilePath);
						util.formatData(sbDescription,sDesc);
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbRev,sRev);
						util.formatData(sbTitle,sTitle);
						util.formatData(sbSource,ConstantsUtil.SOURCE_DIRECT);
						util.formatData(sbLangBuffer,sLangBuffer);
						util.formatData(sbGendocName, sGendocName);
						util.formatData(sbGendocPath, sGendocPath);
						
						//This is a temporary addition to block IRM documents. This will be removed during Release 1.1
						/*if (sType.equals(ConstantsUtil.TYPE_PKDIPLATFORM)
								|| sType.equals(ConstantsUtil.TYPE_PGPKGSTUDYPROTOCOL)
								|| sType.equals(ConstantsUtil.TYPE_PGCONSUMERRESEARCH)
								|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONPROTOCOL)
								|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONOTHER)
								|| sType.equals(ConstantsUtil.TYPE_PGTECHNICALRATIONAL)
								|| sType.equals(ConstantsUtil.TYPE_PGPKGSTABILITYREPORT)
								|| sType.equals(ConstantsUtil.TYPE_PGSTABILITYOUTOFSPECREPORT)
								|| sType.equals(ConstantsUtil.TYPE_PGSTABILITYOTHER)
								|| sType.equals(ConstantsUtil.TYPE_PGRTAGENERICDOCUMENT)
								|| sType.equals(ConstantsUtil.TYPE_PGPKGDEVELOPMENTOTHER)
								|| sType.equals(ConstantsUtil.TYPE_PGCOREINNOVATIONRECORD)
								|| sType.equals(ConstantsUtil.TYPE_PGVALIDATIONREPORT)
								){
							sId = ConstantsUtil.EMPTY_STRING;
							util.formatData(sbId,sId);
						}else {*/
							util.formatData(sbId,sId);
						//}
							// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
							util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
							util.formatData(sbGendocFormat, sGendocPathFormat);
							// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
					}
					else
					{
						util.formatData(sbType,util.mapType(sType));
						util.formatData(sbCSSType,sCSSType);
						util.formatData(sbName,sName);
						util.formatData(sbFilePath,sFilePath);
						util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
						util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
						util.formatData(sbSource,ConstantsUtil.NO_ACCESS);
						util.formatData(sbLangBuffer,ConstantsUtil.NO_ACCESS);
						util.formatData(sbGendocName, ConstantsUtil.NO_ACCESS);
						util.formatData(sbGendocPath, ConstantsUtil.NO_ACCESS);
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
						sGendocPathFormat=ConstantsUtil.NO_ACCESS;
						// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
					}
				}
				else{
					// Added by Pooja for ALM Defect No. 50564 -- START
					showData = util.checkHasAccess(context, null, sId);
                    if(!showData ) {
                        util.formatData(sbType,ConstantsUtil.EMPTY_STRING);
                        util.formatData(sbCSSType,ConstantsUtil.EMPTY_STRING);
                        util.formatData(sbName,ConstantsUtil.EMPTY_STRING);
                        util.formatData(sbFilePath,ConstantsUtil.EMPTY_STRING);
                        util.formatData(sbDescription,ConstantsUtil.EMPTY_STRING);
                        util.formatData(sbCurrent,ConstantsUtil.EMPTY_STRING);
                        util.formatData(sbId,ConstantsUtil.EMPTY_STRING);
                        util.formatData(sbRev,ConstantsUtil.EMPTY_STRING);
                        util.formatData(sbTitle,ConstantsUtil.EMPTY_STRING);
                        util.formatData(sbSource,ConstantsUtil.EMPTY_STRING);
                    }
                    else {
                    util.formatData(sbType,util.mapType(sType));
                    util.formatData(sbCSSType,sCSSType);
                    util.formatData(sbName,sName);
                    util.formatData(sbFilePath,sFilePath);
                    util.formatData(sbDescription,sDesc);
                    util.formatData(sbCurrent,sCurrent);
                    util.formatData(sbId,sId);
                    util.formatData(sbRev,sRev);
                    util.formatData(sbTitle,sTitle);
                    util.formatData(sbSource,ConstantsUtil.SOURCE_DIRECT);
                    }
                 // Added by Pooja for ALM Defect No. 50564 -- END
					
					if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						sLangBuffer=sPGLangBuffer;
					else 
						sLangBuffer=sPLangBuffer;
					//<SPEC> 04/02/2021 Added by Govind For Defect #38266 start
					if (sName.contains("LR_"))
						sLangBuffer=sRev;
					else
						sLangBuffer=" ";					
					//<SPEC> 04/02/2021 Added by Govind For Defect #38266 end
					
					util.formatData(sbLangBuffer,sLangBuffer);
					util.formatData(sbGendocName, sGendocName);
					util.formatData(sbGendocPath, sGendocPath);
					// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- START
					util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
					util.formatData(sbGendocFormat, sGendocPathFormat);
					// SPEC: Added for 18x.5.2 DEV  -- Guna For ReferenceDocuments On : 02-08-2021 -- END
				}
			}
			mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
			mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpRefDoc.put(ConstantsUtil.SOURCE, sbSource.toString());
			mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
			mpRefDoc.put(ConstantsUtil.PGCSSTYPE, sbCSSType.toString());
			mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
			mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLangBuffer.toString());
			mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
			mpRefDoc.put(ConstantsUtil.FILESPATH, sbFilePath.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
			// : 02-08-2021 -- START
			mpRefDoc.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
			mpRefDoc.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());
			// SPEC: Added for 18x.5.2 DEV -- Guna For ReferenceDocuments On
			// : 02-08-2021 -- END
		}catch(Exception e){
			LOGGER.error("Exception in Program : ASLBO Method :updateRefDocs "+e);
			return new HashMap();
		}
		return util.filterMapList(mpRefDoc);
	}
	
	
	/**
	 * Method Name 			: updateSecurity
	 * Method Description 	: 
	 * @param objectMap
	 * @return
	 */
	public Map<String, String> updateSecurity(Context context,Map objectMap) {
		
		Map<String, String> mpSecurity = new HashMap<String, String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		try
		{
			String sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME));
			String sHasClassAccess = validator.getStringEquivalentForString(objectMap.get(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT));
			String sLibrary = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME));
			String sCurrent = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE));
			String sType = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE));
			String sDesc = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC));
			
			String Name[]=sName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			String Library[]=sLibrary.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;
			
			if(!sName.isEmpty()){
				
				StringBuilder sbSecurityClasspath = new StringBuilder();
				
				for (int i = 0; i < Name.length; i++)
				{
					if(UIUtil.isNotNullAndNotEmpty(Name[i]) && UIUtil.isNotNullAndNotEmpty(Library[i]))
					{
						sbSecurityClasspath.append(Library[i]).append(ConstantsUtil.SYMBL_ARROW).append(Name[i]);
						
						//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 1, 2021 -- START
						//mpSecurity.put(ConstantsUtil.CLASSPATH, sbSecurityClasspath.toString());
						//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 1, 2021 -- END
					}else
					{
						sbSecurityClasspath.append(ConstantsUtil.EMPTY_STRING);
					}
				}
			} 
			
			mpSecurity.put(ConstantsUtil.TYPE, sType);
			mpSecurity.put(ConstantsUtil.NAME, sName);
			mpSecurity.put(ConstantsUtil.STATE, sCurrent);
			mpSecurity.put(ConstantsUtil.DESCRIPTION, sDesc);
			
			//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 1, 2021 -- START
			//mpSecurity.put(ConstantsUtil.LIBRARY, sLibrary);
			//SPEC: Release SR18x.6.0 - Commented by Amman on Mar 1, 2021 -- END
			
			if(!sName.isEmpty()){
				mpSecurity.put(ConstantsUtil.HASCLASSACCESS, sHasClassAccess);
			} else{
				mpSecurity.put(ConstantsUtil.HASCLASSACCESS, ConstantsUtil.EMPTY_STRING);
			}
		
		}catch(Exception e){
			LOGGER.error("Error from ASLBO: updateSecurity"+e);
			return new HashMap();
		}
		return  util.filterMapList(mpSecurity);
	}
	//SPEC: 12/28/2020: Added for SR18x.5.2 by Amman ## -- END
}
