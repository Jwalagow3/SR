/**
 * Project 		: SpecsAnywhere
 * Program 		: 
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.CommonDocBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MPPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaMPPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaMPPServiceImpl implements EnoviaMPPService{

	private static Logger LOGGER = Logger.getLogger(EnoviaMPPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
	
	@Override
public HashMap<String, Map<String, String>> getMPPdata(String objId, String sComp, Environment env) throws Exception 
 {
	HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
	
	StopWatch sp = new StopWatch();
	sp.start();
	//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
	StopWatch swContext = new StopWatch();
	swContext.start();
	Context context = pool.checkOut();
	swContext.stop();
	//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
	try {
		//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- START
		/*StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();*/
		//SPEC: <08-11-2021>: Bala Commented for Defect 45181  -- END
		LOGGER.info("MPP CONTEXT ELAPSED TIME : "+swContext.getTime());

			ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context, ConstantsUtil.PERSON_USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			
			if (UIUtil.isNotNullAndNotEmpty(sUserType))
			{
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BObjutil.getUserView(context, objId);
				}
			}
			
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bManufacturerView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_SP:
						bManufacturerView = true;
						break;
						
					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			MPPBO MPPBO = new MPPBO();
			DomainObject doMPP =  MPPBO.getMPPDO(context, objId);
			String strCurrent = doMPP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType) &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY)
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mapPartSpecification = new HashMap<String,String>();
			Map<String,String> mpPerformChar= new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			Map<String,String> mpStabilityDoc =new HashMap<String,String>();
			//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- START
			Map<String,String> mpReferencePart = new HashMap<String,String>();
			//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- END
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = MPPBO.getMPPPartSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slContextSelects.add(ConstantsUtil.ATL_STATE);
			Map<String, StringList> ChilsObjectSelectableMap = MPPBO.getMPPRelatedObjsSelectableMap(context);
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);

			if (null == doMPP) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doMPP.getInfo(context, slContextSelects);
			Map resultMaps = doMPP.getInfo(context, slContextSelects,MPPBO.addMultiList());
			swAttributes.stop();
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 12 Feb 2021 -- END
			LOGGER.info("MPP GETINFO ELAPSED TIME : "+swAttributes.getTime());

			if(bAllInfoView || bManufacturerView) {
				//Attribute Data
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);

				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}

				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);

				//SPEC: <10.20.2020>: Added for the Defect ## -- START

				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED) : ConstantsUtil.EMPTY_STRING);

				//SPEC: <10.20.2020>: Added for the Defect ## -- END


				String sClassifictaion = util.getClassification(resultMaps);
				mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));

				/**
				 * LOAD NOTES SECTION
				 * */
				MasterCOPBO mcop = new MasterCOPBO();
				mpNotes=mcop.updateNotes(context, resultMaps);

				//Performance Car
				Map<String, String> paramMap = new HashMap<String, String>();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				PerformanceCharcteristics perform = new PerformanceCharcteristics();
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				if(!mlPerformChar.isEmpty())
				{
					FinishedProductPartBO fppBO = new FinishedProductPartBO();
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
					//mpPerformChar = util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
					mpPerformChar = util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
				}
				swPerfChar.stop();
				LOGGER.info("MPP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());


				//Reference Docs
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
				swReference.stop();
				LOGGER.info("MPP  Reference ELAPSED TIME : "+swReference.getTime());


				//LifeCycle
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("MPP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

				//SPEC: 12-03-2021: Added for 18x.6 DEV by Madhanagopal -- START
				if(bAllInfoView){
					mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				}
				//SPEC: 12-03-2021: Added for 18x.6 DEV by Madhanagopal -- END

				StopWatch swOwnerShip = new StopWatch();
				swOwnerShip.start();

				//SPEC: 04-12-2021: Added for 18x.6 Internal Defect by Sanjeeva -- START
				//mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 04-12-2021: Added for 18x.6 Internal Defect by Sanjeeva -- END

				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
				swOwnerShip.stop();
				LOGGER.info("MPP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());


				//BOM
				StopWatch swBom = new StopWatch();
				swBom.start();
				//SPEC: <02.09.2021>: Modified for Defect #39032 by Sumit #(BOM Expansion limited to 1)# --STARTS
				MapList mapList = doMPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slChildBusSelects , slChildRelSelects, false, true, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				//SPEC: <02.09.2021>: Modified for Defect #39032 by Sumit #(BOM Expansion limited to 1)# --ENDS
				if(util.isModificatinRequired()) {
					mapList=util.filterPhase(mapList);
				}
				if(mapList.size()!=0){
					FinishedProductPartBO fppBO= new FinishedProductPartBO();
					//mpEBOMResult =	fppBO.parseMaplist(context,mapList);
					mpEBOMResult = MPPBO.parseMaplistBOM(context, mapList);
					//mpSubstitute = MPPBO.getSubstitute(mapList);
					CommonBusUtilBO commonBO = new CommonBusUtilBO();
				}
				swBom.stop();
				LOGGER.info("MPP BOM ELAPSED TIME : "+swBom.getTime());

				//HeaderContent

				//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
				} else {
					mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
				}
				//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

				mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.STATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING));
				//SPEC: Release SR18x.5.2: Added for Defect 36563 by Amman -- START
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 12 Feb 2021 -- START
				String sHasATSAttrVal = util.checkHasATSForSIS(context,resultMaps);
				mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
				//mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.NOTAPPICABLE);
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 12 Feb 2021 -- END
				//SPEC: Release SR18x.5.2: Added for Defect 36563 by Amman -- END
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);

				//Part Spec Data
				// Guna modified for Defect 35928  18x.5.2 Release -- START
				mapPartSpecification = util.updatePartSpec(context, resultMaps);
				//mapPartSpecification = MPPBO.updatePartSpec(context, resultMaps);
				// Guna modified for Defect 35928  18x.5.2 Release -- END

				if(bAllInfoView){
					/**
					 * LOAD IP CLASSES SECTION
					 */
					//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START

					StringList slIpSelects = new StringList();
					slIpSelects.add(ConstantsUtil.SELECT_NAME);
					slIpSelects.add(ConstantsUtil.SELECT_ID);
					slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
					slIpSelects.add(ConstantsUtil.SELECT_TYPE);
					slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
					mpIpSecuritySetting =MPPBO.getIpClass(context, doMPP, slIpSelects);

					//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END

					//Security
					StopWatch swSecurity = new StopWatch();
					swSecurity.start();
					CommonBusUtilBO cbs = new CommonBusUtilBO();
					mpSecurity =cbs.updateSecurity(context,resultMaps);
					swSecurity.stop();
					LOGGER.info("MPP  Security ELAPSED TIME : "+swSecurity.getTime());

					//Organization Data
					StopWatch swOrganization = new StopWatch();
					swOrganization.start();
					mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					mpOrganization = util.filterMapList(mpOrganization);
					swOrganization.stop();
					LOGGER.info("MPP Organization ELAPSED TIME : "+swOrganization.getTime());
				}

				/**
				 * FILES SECTION
				 */

				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				StringList FileSize = validator.getStringListEquivalentForString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));

				//SPEC Added on 12-Dec-2020 by Chandra for Defect 37746 ##--END	
				//SPEC: 30-06-2022: Pooja Added for Internal Defect -- START
				CommonDocBO cdoc = new CommonDocBO();
				String strFileSize = cdoc.updateFileSize(FileSize);
				//SPEC: 30-06-2022: Pooja Added for Internal Defect -- END

				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, strFileSize);

				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END

				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
				mpStabilityDoc = MPPBO.getProductPartStabilityDoc(context,resultMaps);
				//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			}
			//SPEC: Release SR18x.5.2: Added for Defect 36563 by Amman -- START
			/**
			 * LOAD RELATED ATS SECTION
			 * */
			
			//SPEC: Release SR18x.5.2: Added for Defect 36563 by Amman -- END
			
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END

			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mapPartSpecification);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- START
			MapList mlReferencePartList = util.getReferencePart(context,objId, sUserType);
			mpReferencePart = util.parseReferencePart(context,mlReferencePartList);
			hmAttrib.put(ConstantsUtilIRM.REFERENCE, mpReferencePart);
			//SPEC: <09.03.2023>: Manikanta Added for Req 46672 -- END
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- START
			
			hmAttrib.put(ConstantsUtil.STABILITYDOCUMENT, mpStabilityDoc);
			//SPEC: <10.20.2020>: Added for req 18x.5 ## -- END
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			
		if(bAllInfoView) {
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);	
			
			hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
		}		

		//SPEC: 11-03-2021: Modified for 18x.6 DEV by Madhanagopal -- END

		ContextUtil.popContext(context);
		pool.checkIn(context);
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- START
		doMPP.close(context);
		//SPEC: <08-13-2021>: Manikanta Modified for Stress Testing Defect 44365  -- END
		sp.stop();
		
		LOGGER.info("MPP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "MPP OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
	} catch (IOException e) {
		LOGGER.error("IOException from MPP "+e);
	} catch (MatrixException e) {
		LOGGER.error("MatrixException from MPP "+e);
			}
	//LOGGER.info("MPP RESPONSE MESSAGE:: \n" + hmAttrib);
	//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
	context.close();
	//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
	return hmAttrib;
				
 }
		
}

