package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaSpecPartCompService {

	HashMap<String, HashMap<String, Map>> getSpecPartCompData(String sObjectName, Environment env);

}
