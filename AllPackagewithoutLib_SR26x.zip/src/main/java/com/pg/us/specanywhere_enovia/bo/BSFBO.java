package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class BSFBO extends BusinessObject {

	BusObjectAttribUtil util = new BusObjectAttribUtil();
	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(BSFBO.class);

	public BSFBO() {
		// empty constructor
	}

	public BSFBO(String oid) {
		this.setObjectId(oid);
	}

	/**
	 * Method Name 			: getBSFBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getBSFBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getBSFDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */	
	public DomainObject getBSFDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}
		
		/**
		 * Method Name 			: getBSFPartSelectables
		 * Method Description 	: 
		 * @param context
		 * @return
		 */
		public Map<String, StringList> getBSFSelectables(Context context) {
			StringList busSelect = new StringList(100);
			Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
			busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 
			busSelect.addAll(getContextObjectBusSelectable(context));
			
			mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
			return mapSelecables;
		}

		
		/**
		 * Method Name 			: getBSFRelatedObjsSelectableMap
		 * Method Description 	: 
		 * @param context
		 * @return
		 * @throws MatrixException
		 */
		public static Map<String, StringList> getBSFRelatedObjsSelectableMap(Context context) throws MatrixException {
			StringList busSelect = new StringList();
			StringList relSelect = new StringList();
			Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
			busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
			busSelect.addAll(getBomBusSelect(context));
			relSelect.addAll(getBomRelSelect(context));
			mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
			mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
			return mapSelecables;

		}
		/**
		 * Method Name 			: getBomBusSelect
		 * Method Description 	: Fetching attribute details like - title, UOM, comment and state
		 * @param context
		 * @return
		 */
		public static StringList getBomBusSelect(Context context) {
			StringList busSelect = new StringList(4);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

			return busSelect;
		}

		
		/**
		 * Method Name 			: getBomRelSelect
		 * Method Description 	: Fetching attribute details like - quantity, comment, etc.
		 * @param context
		 * @return
		 */
		public static StringList getBomRelSelect(Context context) {
			StringList relSelect = new StringList(7);
			relSelect.add(ConstantsUtil.SELECT_FROM_NAME);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
			relSelect.add(ConstantsUtil.SELECT_SUBSTITUTE);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOPTIONALCOMPONENT);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET); 			
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSS);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENTS);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
			relSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
			//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 10, 2021 -- START
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
			relSelect.add(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_QUANTITY);
			relSelect.add(ConstantsUtil.REL_SUBSTITUTE_BASE_UOM);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_START_EFFECTIVITY);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REFERENCE_DOC);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY);
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET); 			
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM);				
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR);	
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION); 	
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT); 			
			relSelect.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMBINATION_NUMBER);
			//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 10, 2021 -- END

			return relSelect;
		}

		
		/**
		 * Method Name 			: getContextObjectBusSelectable
		 * Method Description 	: Fetching business object details
		 * @param context
		 * @return
		 */
		public static StringList getContextObjectBusSelectable(Context context) {
			StringList busSelect = new StringList(70);
			busSelect.add(ConstantsUtil.SELECT_NAME);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL);
			busSelect.add(ConstantsUtil.STRSEGMENT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL);
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL);
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
			busSelect.add(ConstantsUtil.REPORTED_FUNCTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPARTCOLOR);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_CONDITIONS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGDECORATIONDETAILS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGELECTRONICDISTRIBUTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTAL);	
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);	
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
			// SPEC: Added for 18x.5.2 DEV --Guna -- START
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENTS);
			busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS);
			// SPEC: Added for 18x.5.2 DEV --Guna -- END
	
			return busSelect;

		}
		
		
		/**
		 * Method Name 			: getOriginatorName
		 * Method Description 	: 
		 * @param context
		 * @param args
		 * @return
		 */
		public String getOriginatorName(Context context, Map resultMap,String ldapuser,String ldappwd) 
		{	
			String strOriginatorName = ConstantsUtil.EMPTY_STRING;
			
			try {
				String objectId = (String)resultMap.get(ConstantsUtil.ID);
				DomainObject doj = DomainObject.newInstance(context, objectId);
				String strAttributeValue = (String)doj.getInfo(context,DomainConstants.SELECT_ORIGINATOR);
				strOriginatorName =	util.getUserName(context,strAttributeValue,ldapuser,ldappwd);
				
			} catch (Exception ex) {
				LOGGER.error("Error from BSFBO: getOriginatorName" + ex);
				strOriginatorName = ConstantsUtil.EMPTY_STRING;
			}
			return strOriginatorName;
		}
		
		/**
		 * Method Name 			: getUserName
		 * Method Description 	: 
		 * @param context
		 * @param strOriginator
		 * @return
		 * @throws Exception
		 */
		/*public String getUserName(Context context, String strOriginator) 
		{	
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			String strUserName=ConstantsUtil.EMPTY_STRING;

			try{
				StringList slObjSelects = new StringList(5);
				slObjSelects.addElement(DomainConstants.SELECT_ID);
				slObjSelects.addElement(DomainConstants.SELECT_NAME);
				slObjSelects.addElement("attribute[First Name]");
				slObjSelects.addElement("attribute[Last Name]");
				slObjSelects.addElement("attribute[pgTNumber]");
				String strNamePattern="*";
				String strRevisionPattern="*";
				String strWhere="attribute[pgTNumber]==\""+strOriginator+"\" && revision==last";

				MapList mlDataList =  DomainObject.findObjects(context,"Person",strNamePattern,strRevisionPattern,"*","eService Production", strWhere, false, slObjSelects);
				if(mlDataList.size()>0){
					Map dataMap= (Map)mlDataList.get(0);
					strUserName=(String)dataMap.get("attribute[First Name]")+" "+(String)dataMap.get("attribute[Last Name]");
				}else{
					strUserName = util.getLDAPInfo(strOriginator, true);
				}
			}catch (Exception ex) {
				LOGGER.error("Error from BSFBO: getUserName " + ex);
				strUserName=ConstantsUtil.EMPTY_STRING;
			} 
			return strUserName;
		}*/
		/**
		 * Method Name 			: getBSFBOM
		 * Method Description 	: 
		 * @param context
		 * @param mapList
		 * @param resultMaps
		 * @return
		 */
		public Map<String, String> getBSFBOM(Context context,MapList mapList, Map resultMaps) {
			
			StringValidatorUtil validator = new StringValidatorUtil();
			
			Map MPFinalEBOMResults = new TreeMap();
						
			FormulaCardBO fcbo= new FormulaCardBO ();
			//Passing Part Details	
			StringBuilder sbPName = new StringBuilder();
			StringBuilder sbPTitle = new StringBuilder();
			StringBuilder sbPEBOMQTY = new StringBuilder();
			StringBuilder sbPTotal= new StringBuilder();
			StringBuilder sbPSubTotal= new StringBuilder();
			StringBuilder sbPTotalUOM= new StringBuilder();
			StringBuilder sbPSubTotalUOM= new StringBuilder();
			StringBuilder sbPIngLoss= new StringBuilder();
			StringBuilder sbPIngLossUOM= new StringBuilder();
			StringBuilder sbPIngLossComment= new StringBuilder();
			StringBuilder sbPMinqty= new StringBuilder();
			StringBuilder sbPMaxqty= new StringBuilder();
			StringBuilder sbPSub= new StringBuilder();
			StringBuilder sbPChg = new StringBuilder();
			StringBuilder sbBatchUOM = new StringBuilder();
			StringBuilder sbPMF = new StringBuilder();
			StringBuilder sbPPI = new StringBuilder();
			StringBuilder sbTarget = new StringBuilder();
			
			//Passing EBOM Details
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbEBOMType = new StringBuilder();
			StringBuilder sbEBOMRev = new StringBuilder();
			//StringBuilder sbEBOMName = new StringBuilder();			
			StringBuilder sbEBOMId = new StringBuilder();
			StringBuilder sbEBOMChg = new StringBuilder();
			StringBuilder sbEBOMFN = new StringBuilder();
			StringBuilder sbEBOMTitle = new StringBuilder();
			
			StringBuilder sbEBOMQTY = new StringBuilder();
			StringBuilder sbEBOMBuom = new StringBuilder();
			StringBuilder sbEBOMComments = new StringBuilder();
			StringBuilder sbEBOMState= new StringBuilder();
			StringBuilder sbEBOMStage= new StringBuilder();
			StringBuilder sbSpecType= new StringBuilder();
			StringBuilder sbSpecSubType= new StringBuilder();	 
			StringBuilder sbMinqty= new StringBuilder();
			StringBuilder sbMaxqty= new StringBuilder();			
			StringBuilder sbLoss= new StringBuilder();
			StringBuilder sbMF= new StringBuilder();	
			StringBuilder sbPI= new StringBuilder();
			StringBuilder sbBaseUoM= new StringBuilder();
			
			
			StringBuilder sbDisplayType= new StringBuilder();
			StringBuilder sbDisplaySpecSubType= new StringBuilder();
			StringBuilder sbEBOMSub= new StringBuilder();
					
			Iterator objectListItr = mapList.iterator();
			Map<String, String> mpHeaderEBOMResult = new HashMap<String, String>();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			
		
			try {	
				
				String sPName = (String)resultMaps.get(ConstantsUtil.SELECT_NAME);
				String sPType = (String)resultMaps.get(ConstantsUtil.SELECT_TYPE);
				String sPRev = (String)resultMaps.get(ConstantsUtil.SELECT_REVISION);
				String sPId = (String)resultMaps.get(ConstantsUtil.SELECT_ID);
				String sPCurrent =(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT);
				String sPpgChg =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
				//String sPpgChg ="";
				String sPFN =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER));
				String sPSub =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_SUBSTITUTE));
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- START
				if("".equalsIgnoreCase(sPSub))
				{
					sPSub=ConstantsUtil.SYMBL_NO;
				}
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- END
				//String sPTotal =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTAL));					
				String sPTotal = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTAL);
				//String sPTotalUoM =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE));
				String sPTotalUoM = (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE);
				String sTotalConcat=sPTotal+" "+sPTotalUoM;				
				//String sPTotalUoM =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE));
				//String sPSubtotal =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL));
				//String sPSubtotalUoM =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE));
				String sPSubtotal = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTAL);
				String sPSubtotalUoM = (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTOTALUNITOFMEASURE);
				String sSubTotalConcat=sPSubtotal+" "+sPSubtotalUoM;
				//String sPIngLoss =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS));
				//String sPIngLossUOM =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE));
				String sPIngLoss = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_INGREDIENT_LOSS);
				String sPIngLossUOM = (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSUNITOFMEASURE);
				String sIngLossConcat=sPIngLoss+" "+sPIngLossUOM;
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 17/02/2021 -- START
				//String sPIngLossComment =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENTS));
				String sPIngLossComment =validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINGREDIENTLOSSCOMMENTS));
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 17/02/2021 -- END
				String sPTitle =(String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				String sPDisplayType ="";				
				String sPDisplaySpecSubType ="";
				String sPRangeMinqty =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY));
				String sPRangeMaxqty =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY));					
				String sPMinqty ="";
				String sPMaxqty ="";
				String sPMF = validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION));
				String sPPI = validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR));
				String sPQty =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY));
				String sPBaseUoM="";				
				//String sPBOMBaseQty = validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY));
				
				String sPBatchUOM = (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE);
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- START
				String sPComments ="Ingredient Loss Comment :"+sPIngLossComment;
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- END
				String sPTarget="";
				String sPStage = (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- START
				sPTarget ="Subtotal: "+sSubTotalConcat+"\n Ingredient Loss: "+sIngLossConcat+"\n Total: "+sTotalConcat;
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- END
				//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 10, 2021 -- START
				String sTotalBatch = (String) resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE);
				String sFinalBatch  ="Target: "+sTotalBatch+"\n Range Min: "+sPRangeMinqty +"\n Range Max:  "+sPRangeMaxqty+"\n Unit Of Measure: "+sPBatchUOM;
				//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 10, 2021 -- END
			util.formatData(sbName,sPName);
			util.formatData(sbEBOMType,sPType);
			util.formatData(sbEBOMRev,sPRev);
			util.formatData(sbEBOMId,sPId);
			util.formatData(sbEBOMState,sPCurrent);			
			util.formatData(sbEBOMChg,sPpgChg);
			util.formatData(sbEBOMFN,sPFN);
			util.formatData(sbEBOMSub,sPSub);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- START
			//util.formatData(sbPTotal,sTotalConcat);
			//util.formatData(sbPSubTotal,sSubTotalConcat);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- END
			//util.formatData(sbPTotalUOM,sPSubtotalUoM);
			//util.formatData(sbPSubTotalUOM,sPSubtotalUoM);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- START
			//util.formatData(sbPIngLoss,sIngLossConcat);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- END
			//util.formatData(sbPIngLossUOM,sPIngLossUOM);
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- START
			//util.formatData(sbPIngLossComment,sPIngLossComment);
			//util.formatData(sbEBOMTitle,sPTitle);
			util.formatData(sbEBOMTitle,"");
			util.formatData(sbDisplayType,"");
			util.formatData(sbDisplaySpecSubType,"");
			//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- END
			util.formatData(sbPMinqty,sPRangeMinqty);
			util.formatData(sbPMaxqty,sPRangeMaxqty);
			util.formatData(sbMinqty,sPMinqty);
			util.formatData(sbMaxqty,sPMaxqty);
			util.formatData(sbMF,sPMF);	
			util.formatData(sbPI,sPPI);				
			util.formatData(sbEBOMQTY,sPQty);
			util.formatData(sbBaseUoM,sPBaseUoM);
			//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 10, 2021 -- START
			util.formatData(sbBatchUOM,sFinalBatch);
			//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 10, 2021 -- END
			util.formatData(sbEBOMComments,sPComments);
			util.formatData(sbTarget,sPTarget);
			util.formatData(sbEBOMStage,sPStage);
							
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();
				
				String sName =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_NAME));
				String sType =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_TYPE));
				String sRevision =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_REVISION));				
				String sId =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ID));
				
				String sCurrent =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String spgChg =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHANGE));
				String sFN =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER));
				String strEBOMSub =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_SUBSTITUTE));
				// SPEC: Added for 18x.5.2 DEV --Guna -- START
				if (strEBOMSub.equalsIgnoreCase(ConstantsUtil.SYMBL_TRUE)) {

					strEBOMSub = ConstantsUtil.SYMBL_YES;

				} else if (strEBOMSub.equalsIgnoreCase(ConstantsUtil.SYMBL_FALSE)) {

					strEBOMSub = ConstantsUtil.SYMBL_NO;
				}
				// SPEC: Added for 18x.5.2 DEV --Guna -- END
				
				//String sPTotal =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTAL));					
				//String sPTotalUoM =validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE));
				String sTotal ="";					
				String sTotalUoM ="";
				String sEBOMTotalConcat=sTotal+sTotalUoM;
				String sSubtotal ="";
				String sSubtotalUoM ="";
				String sEBOMSubTotalConcat=sSubtotal+sSubtotalUoM;
				String sIngLoss ="";
				String sIngLossUOM ="";
				String sEBOMIngLossConcat=sIngLoss+sIngLossUOM;
				String sIngLossComment ="";
				String sTitle =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));				
				String sDisplayType =fcbo.getMappedType(sType.trim());
					String sSpecSubType = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE));
					String strAttrPgCSSType = validator.getStringEquivalentForSubstituteString( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE));
					// Guna Modified for Defect 38208  18x.5.2 Release -- START
				String sDisplaySpecSubType =fcbo.getSpecificationSubtype(context, sType, sSpecSubType, strAttrPgCSSType,sId);	
				// Guna Modified for Defect 38208  18x.5.2 Release -- END
				String sMinqty =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY));
				String sMaxqty =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY));	
				String sRangeMinqty = "";
				String sRangeMaxqty = "";					
				String sBOMBaseQty = "";
				String strMF =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALFUNCTION));
				String strPI = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR));		
				String sQty =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY));
				String sBaseUoM =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE));
				//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 10, 2021 -- START
				String sBatchUOM = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZEUNITOFMEASURE));
				//SPEC: Release SR18x.6.0 - Modified by Sumit on Mar 10, 2021 -- END
				String sComments=validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT));
				String sStage =validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));								
				//String sTarget = validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCHUNITSIZE));
				// SPEC: Modified for 18x.5.2 DEV --Guna -- START
				String sTarget =validator.getStringEquivalentForSubstituteString((String) objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY));
				// SPEC: Modified for 18x.5.2 DEV --Guna -- END	
				
				//SPEC: <02.03.2021>: Added for Defect: 38270 by Sumit --START
				boolean showData = true;
				//SPEC: <02.03.2021>: Added for Defect: 38270 by Sumit --ENDS
				if(util.isModificatinRequired())
				   {
						//SPEC: <02.03.2021>: Modified for Defect: 38270 by Sumit --START
						/*SecurityService sec = new SecurityService();
						String sComp = sec.getUserCauthorities();
						StringList slUserOwnership=util.filterOwnerShip(sComp);
			
						boolean bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sId);*/
						
						boolean bHasOwnership = util.checkHasAccess(context, null, sId);
						//SPEC: <02.02.2021>: Modified for Defect: 38270 by Sumit --ENDS
				
					if(!bHasOwnership)
					{
						//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- START
						sId = ConstantsUtil.NO_ACCESS;
						/*sRevision = ConstantsUtil.NO_ACCESS;
						sCurrent = ConstantsUtil.NO_ACCESS;	*/					
						spgChg = ConstantsUtil.NO_ACCESS;
						/*sFN    = ConstantsUtil.NO_ACCESS;
						sTitle = ConstantsUtil.NO_ACCESS;
						strEBOMSub = ConstantsUtil.NO_ACCESS;
						sDisplayType = ConstantsUtil.NO_ACCESS;
						sDisplaySpecSubType = ConstantsUtil.NO_ACCESS;						
						sMinqty = ConstantsUtil.NO_ACCESS;
						sMaxqty = ConstantsUtil.NO_ACCESS;												
						strMF = ConstantsUtil.NO_ACCESS;
						strPI = ConstantsUtil.NO_ACCESS;
						sQty = ConstantsUtil.NO_ACCESS;
						sBaseUoM = ConstantsUtil.NO_ACCESS;
						sComments = ConstantsUtil.NO_ACCESS;
						sStage = ConstantsUtil.NO_ACCESS;*/
						//SPEC: <27.04.2021>: Guna Modified  for External Defect  18x.6.0.1   -- END
						}
					
				   }
				//SPEC: <02.03.2021>: Modified for Defect: 38270 by Sumit --START
					else{
						
						showData=util.checkHasAccess(context, null, sId);
					}
				
					if(!showData){
						spgChg = ConstantsUtil.NO_ACCESS;
						//SPEC: 31/08/2021: Modified for 18x.6.0.2 Defect#42001 by Manikanta-- START
						sId = ConstantsUtil.NO_ACCESS;
						//SPEC: 31/08/2021: Modified for 18x.6.0.2 Defect#42001 by Manikanta-- END
					}
					
					/*StringList slHIRTypes = new StringList();

					slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
					slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
					slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);

					if(slHIRTypes.contains(sType)){
						sId = ConstantsUtil.NO_ACCESS;
						sRevision = ConstantsUtil.NO_ACCESS;
						sCurrent = ConstantsUtil.NO_ACCESS;						
						spgChg = ConstantsUtil.NO_ACCESS;
						sFN    = ConstantsUtil.NO_ACCESS;
						sTitle = ConstantsUtil.NO_ACCESS;
						strEBOMSub = ConstantsUtil.NO_ACCESS;
						sDisplayType = ConstantsUtil.NO_ACCESS;
						sDisplaySpecSubType = ConstantsUtil.NO_ACCESS;						
						sMinqty = ConstantsUtil.NO_ACCESS;
						sMaxqty = ConstantsUtil.NO_ACCESS;												
						strMF = ConstantsUtil.NO_ACCESS;
						strPI = ConstantsUtil.NO_ACCESS;
						sQty = ConstantsUtil.NO_ACCESS;
						sBaseUoM = ConstantsUtil.NO_ACCESS;
						sComments = ConstantsUtil.NO_ACCESS;
						sStage = ConstantsUtil.NO_ACCESS;
						
						
					}*/
					//SPEC: <02.03.2021>: Modified for Defect: 38270 by Sumit --ENDS
					sType = util.mapType(sType);
					util.formatData(sbName,sName);
					util.formatData(sbEBOMType,sType);
					util.formatData(sbEBOMRev,sRevision);
					util.formatData(sbEBOMId,sId);
					util.formatData(sbEBOMState,sCurrent);			
					util.formatData(sbEBOMChg,spgChg);
					util.formatData(sbEBOMFN,sFN);
					util.formatData(sbEBOMSub,strEBOMSub);
					//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- START
					//util.formatData(sbPTotal,sEBOMTotalConcat);
					//util.formatData(sbPSubTotal,sEBOMSubTotalConcat);
					//util.formatData(sbPTotalUOM,sPSubtotalUoM);
					//util.formatData(sbPSubTotalUOM,sPSubtotalUoM);
					//util.formatData(sbPIngLoss,sEBOMIngLossConcat);
					//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- END
					//util.formatData(sbPIngLossUOM,sPIngLossUOM);
					//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- START
					//util.formatData(sbPIngLossComment,sIngLossComment);
					//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- END
					util.formatData(sbEBOMTitle,sTitle);
					util.formatData(sbDisplayType,sDisplayType);
					util.formatData(sbDisplaySpecSubType,sDisplaySpecSubType);
					util.formatData(sbPMinqty,sRangeMinqty);
					util.formatData(sbPMaxqty,sRangeMaxqty);
					util.formatData(sbMinqty,sMinqty);
					util.formatData(sbMaxqty,sMaxqty);
					util.formatData(sbMF,strMF);
					util.formatData(sbPI,strPI);
					util.formatData(sbEBOMQTY,sQty);
					util.formatData(sbBaseUoM,sBaseUoM);
					util.formatData(sbBatchUOM,sBatchUOM);
					util.formatData(sbEBOMComments,sComments);
					util.formatData(sbTarget,sTarget);
					util.formatData(sbEBOMStage,sStage);
				}
				
				mpEBOMResult.put(ConstantsUtil.TYPE, sbEBOMType.toString());
				mpEBOMResult.put(ConstantsUtil.NAME,sbName.toString());
				mpEBOMResult.put(ConstantsUtil.REV,sbEBOMRev.toString());
				mpEBOMResult.put(ConstantsUtil.ID,sbEBOMId.toString());
				mpEBOMResult.put(ConstantsUtil.STATE,sbEBOMState.toString());
				mpEBOMResult.put(ConstantsUtil.CHG,sbEBOMChg.toString());
				mpEBOMResult.put(ConstantsUtil.FN,sbEBOMFN.toString());
				mpEBOMResult.put(ConstantsUtil.SUBSTITUTION,sbEBOMSub.toString());
				//mpEBOMResult.put(ConstantsUtil.TOTAL, sbPTotal.toString()+sbPTotalUOM.toString());	
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- START
				//mpEBOMResult.put(ConstantsUtil.TOTAL,sbPTotal.toString());
				//mpEBOMResult.put(ConstantsUtil.SUBTOTAL, sbPSubTotal.toString());				
				//mpEBOMResult.put(ConstantsUtil.INGREDIENTLOSS,sbPIngLoss.toString()+sbPIngLossUOM.toString() );			
				//mpEBOMResult.put(ConstantsUtil.INGREDIENTLOSS,sbPIngLoss.toString());
				//mpEBOMResult.put(ConstantsUtil.INGREDIENTLOSSCOMMENT,sbPIngLossComment.toString());
				//SPEC: Release SR18x.5.2 - Modified for Defect# 39338  by Dominic on Date 16/02/2021 -- END
				mpEBOMResult.put(ConstantsUtil.SAPDESORFILDES, sbEBOMTitle.toString());
				mpEBOMResult.put(ConstantsUtil.T,sbDisplayType.toString());
				mpEBOMResult.put(ConstantsUtil.SS,sbDisplaySpecSubType.toString());
				mpEBOMResult.put(ConstantsUtil.RANGEMIN,sbPMinqty.toString());
				mpEBOMResult.put(ConstantsUtil.RANGEMAX,sbPMaxqty.toString());
				mpEBOMResult.put(ConstantsUtil.MAX,sbMaxqty.toString());
				mpEBOMResult.put(ConstantsUtil.MIN,sbMinqty.toString());
				mpEBOMResult.put(ConstantsUtil.MF,sbMF.toString());
				mpEBOMResult.put(ConstantsUtil.PI,sbPI.toString());
				mpEBOMResult.put(ConstantsUtil.QTY,sbEBOMQTY.toString());
				mpEBOMResult.put(ConstantsUtil.UNITOFMEASURE,sbBaseUoM.toString());
				mpEBOMResult.put(ConstantsUtil.UOM,sbBatchUOM.toString());
				mpEBOMResult.put(ConstantsUtil.COMMENTS,sbEBOMComments.toString());
				mpEBOMResult.put(ConstantsUtil.TARGET,sbTarget.toString());
				mpEBOMResult.put(ConstantsUtil.PHASE,sbEBOMStage.toString());	
				
				//MPFinalEBOMResults.put(ConstantsUtil.HEADER, mpHeaderEBOMResult);
				//MPFinalEBOMResults.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
				
				
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.error("Exception in BSFBO:  getBSFBOM: " + e);
			}
			
			//return MPFinalEBOMResults;
			return mpEBOMResult;
				
				//return util.filterMapList(mpEBOMResult);
		}	
		//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 10, 2021 -- START
		/* * Getting the Substitutes of BSF
		 * @param context
		 * @param mapList
		 * @return
		 * @throws Exception
		 */

		public Map<String, String> getSubstitutes(Context context, MapList mapList) throws Exception 
		{
			StringValidatorUtil validator = new StringValidatorUtil();
			BusObjectAttribUtil  util = new BusObjectAttribUtil();
			Map mpEBOMResult = new HashMap<String,String>();
			Map mpRetEBOMResult = new HashMap<String,String>();
			
			try 
			{
				
				Iterator objectListItr = mapList.iterator();
				StringBuilder sbSubForName = new StringBuilder();
				StringBuilder sbSubForTitle = new StringBuilder();
				StringBuilder sbSubForFormulation = new StringBuilder();
				StringBuilder sbSubForComment = new StringBuilder ();
				StringBuilder sbSubPartType = new StringBuilder();
				StringBuilder sbSubPartDisplayType = new StringBuilder();
				StringBuilder sbSubPartName = new StringBuilder();
				StringBuilder sbSubPartId = new StringBuilder();
				StringBuilder sbSubPartTitle = new StringBuilder();
				StringBuilder sbSubPartSpecSubType = new StringBuilder();	
				StringBuilder sbSubPartValidUntiltDt = new StringBuilder();
				StringBuilder sbSubstituteMinQTY = new StringBuilder();
				StringBuilder sbSubstituteChg = new StringBuilder();
				StringBuilder sbSubstituteSCN = new StringBuilder();
				StringBuilder sbSubstituteMaxQTY = new StringBuilder();
				StringBuilder sbSubstituteTarget = new StringBuilder();
				StringBuilder sbSubstituteUOM = new StringBuilder();
				StringBuilder sbSubstitutePI = new StringBuilder();	
				StringBuilder sbSubstituteMF = new StringBuilder();
				StringBuilder sbSubstituteCMT = new StringBuilder();
				
				FormulaCardBO FCBO = new FormulaCardBO();
				int inCounter = 0;
				while (objectListItr.hasNext()) 
				{
					
					Map objectMap = (Map) objectListItr.next();

					if (objectMap.containsKey(ConstantsUtil.SELECT_SUBSTITUTE))
					{
		  				if (!objectMap.containsKey(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME)) {
		  					continue;
		  				}
		  				inCounter = inCounter +1;
		  				sbSubForName = new StringBuilder();
						sbSubForTitle = new StringBuilder();
						sbSubForFormulation = new StringBuilder();
						sbSubForComment = new StringBuilder();
		  				sbSubPartType = new StringBuilder();
						sbSubPartDisplayType = new StringBuilder();
						sbSubPartName = new StringBuilder();
						sbSubPartId = new StringBuilder();
						sbSubPartTitle = new StringBuilder();
						sbSubPartSpecSubType = new StringBuilder();	
						sbSubPartValidUntiltDt = new StringBuilder();
						sbSubstituteMinQTY = new StringBuilder();
						sbSubstituteChg = new StringBuilder();
						sbSubstituteSCN = new StringBuilder();
						sbSubstituteMaxQTY = new StringBuilder();
						sbSubstituteTarget = new StringBuilder();
						sbSubstituteUOM = new StringBuilder();
						sbSubstitutePI = new StringBuilder();	
						sbSubstituteMF = new StringBuilder();
						sbSubstituteCMT = new StringBuilder();
							
		  				String sClassName = objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME).getClass().getSimpleName();
		  				if(sClassName.equalsIgnoreCase(ConstantsUtil.STRING)) 
		  				{
		  					String sSubstituteForName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.NAME));
		  					String sSubstituteForTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
		  					String sSubstituteForFormulation =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_FROM_NAME));
		  					String sSubstituteForFILDescr =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
		  					String sSubstitutePartId =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID));
	  						String sSubstituteType =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE));
	  						String sSubstituteName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
	  						
	  						String sSubstituteChg = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
	  						String sSubstituteSCN=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
	  						String sSubstituteTitle =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
	  						
	  						String sSubstituteDisplayType =FCBO.getMappedType(sSubstituteType.trim());
	  					   //SPEC: Release SR18x.6.0 - Modified for Internal Defect  by Dominic on Date 23/04/2021 -- START
	  						String sSubstituteAssemblyType =FCBO.getSpecificationSubtypeForSubstitutes(context,sSubstitutePartId,sSubstituteType);
	  						sSubstituteType=util.mapType(sSubstituteType);
	  						//SPEC: Release SR18x.6.0 - Modified for Internal Defect  by Dominic on Date 23/04/2021 -- END
	  						String sSubstituteMinQty =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY));
	  						String sSubstituteTarget=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET));
	  						String sSubstituteMaxQty =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY));
	  						
	  						String sSubstituteUOM =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM));
	  						String sSubstitutePI =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR));
	  						String sSubstituteMF =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION));
	  						
	  						String sSubstituteValidDate =validator.DateFormatter(validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE)));
	  						String sSubstituteComment =validator.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
	  						
	  						boolean bSubstituteHasAccess = util.checkHasAccess(context,null,sSubstitutePartId);
	  						
	  						if(!bSubstituteHasAccess) {
	  							sSubstitutePartId    = ConstantsUtil.NO_ACCESS;
	  							sSubstituteChg = ConstantsUtil.NO_ACCESS;
	  						}
	  						
	  						util.formatData(sbSubPartId, sSubstitutePartId);
	  						util.formatData(sbSubPartName, sSubstituteName);
							util.formatData(sbSubPartTitle, sSubstituteTitle);
							util.formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
							util.formatData(sbSubPartValidUntiltDt, sSubstituteValidDate);
							//util.formatData(sbSubstituteChg, sSubstituteChg);				
							util.formatData(sbSubPartDisplayType, sSubstituteDisplayType);
							util.formatData(sbSubPartType, sSubstituteType);
							util.formatData(sbSubstituteMinQTY, sSubstituteMinQty);
							util.formatData(sbSubstituteSCN, sSubstituteSCN);
							util.formatData(sbSubstituteMaxQTY, sSubstituteMaxQty);
							util.formatData(sbSubstituteTarget, sSubstituteTarget);
							util.formatData(sbSubstituteUOM, sSubstituteUOM);
							util.formatData(sbSubstitutePI, sSubstitutePI);
							util.formatData(sbSubstituteMF, sSubstituteMF);
							util.formatData(sbSubstituteCMT, sSubstituteComment);
							
							mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sSubstituteForName);
							mpEBOMResult.put(ConstantsUtil.TITLE, sSubstituteForTitle);
							mpEBOMResult.put(ConstantsUtilIRM.FORMULATION, sSubstituteForFormulation);
							mpEBOMResult.put(ConstantsUtil.DESCRIPTION, sSubstituteForFILDescr);
							
							mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbSubPartDisplayType.toString());
							mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
							mpEBOMResult.put(ConstantsUtil.ID, sbSubPartId.toString());
							mpEBOMResult.put(ConstantsUtil.NAME, sbSubPartName.toString());
							mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubPartTitle.toString());
							mpEBOMResult.put(ConstantsUtil.SUBTYPE, sbSubPartSpecSubType.toString());
							mpEBOMResult.put(ConstantsUtil.COMBINATIONNUMBER, sbSubstituteSCN.toString());
							mpEBOMResult.put(ConstantsUtil.MIN, sbSubstituteMinQTY.toString());
							mpEBOMResult.put(ConstantsUtil.TARGET, sbSubstituteTarget.toString());
							mpEBOMResult.put(ConstantsUtil.MAX, sbSubstituteMaxQTY.toString());
							mpEBOMResult.put(ConstantsUtil.UOM, sbSubstituteUOM.toString());
							mpEBOMResult.put(ConstantsUtil.MF, sbSubstituteMF.toString());
							mpEBOMResult.put(ConstantsUtil.PI, sbSubstitutePI.toString());
							mpEBOMResult.put(ConstantsUtil.VALIDTILLDATE, sbSubPartValidUntiltDt.toString());
							mpEBOMResult.put(ConstantsUtil.COMMENT, sbSubstituteCMT.toString());
							
							LOGGER.info("BSF:::::IN STRING CLASS:::::mpEBOMResult:"+mpEBOMResult);
							
							mpRetEBOMResult.put(inCounter,mpEBOMResult);
							LOGGER.info("BSF:::::IN STRING CLASS:::::mpRetEBOMResult:"+mpRetEBOMResult);
	  						
		  				}else
		  				{
		  					String sSubstituteForName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.NAME));
		  					String sSubstituteForTitle =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
		  					String sSubstituteForFormulation =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_FROM_NAME));
		  					String sSubstituteForFILDescr =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
		  					StringList slSubstituteId = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_ID);
	  						StringList slSubstituteType = (StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TYPE);
							StringList slSubstituteName =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME));
							StringList slSubstituteChg=(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_CHG));
							StringList slSubstituteSCN=(StringList) (objectMap.get(ConstantsUtil.REL_SUBSTITUTE_COMBINATION_NUMBER));
							StringList slSubstituteTitle =(StringList) (objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE));
							StringList slSubstituteMinQty =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMINQTY));
							StringList slSubstituteTarget =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGTARGET));
							StringList slSubstituteMaxQty =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGMAXQTY));
							StringList slSubstituteUOM =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_UOM));
							StringList slSubstitutePI =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_POSITION_INDICATOR));
							StringList slSubstituteMF =(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_MATERIAL_FUNCTION));
							StringList slUntilDate=(StringList)(objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_VALID_UNTIL_DATE));
							StringList slComments=((StringList)objectMap.get(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_COMMENT));
	  						
							
	  						for(int i =0; i<slSubstituteId.size(); i++) 
	  						{
	  							
	  							mpEBOMResult = new HashMap<String,String>();
	  							String sSubstitutePartId = validator.getStringEquivalentForStringList(slSubstituteId.getElement(i));										
	  							String sSubstitutePartType=validator.getStringEquivalentForStringList(slSubstituteType.getElement(i));		
	  							
	  							String sSubstituteChg = validator.getStringEquivalentForStringList(slSubstituteChg.getElement(i));										
	  							String sSubstituteSCN=validator.getStringEquivalentForStringList(slSubstituteSCN.getElement(i));										
	  							String sSubstituteName =validator.getStringEquivalentForStringList(slSubstituteName.getElement(i));											
	  							String sSubstituteTitle =validator.getStringEquivalentForStringListWithComma(slSubstituteTitle.getElement(i));								

	  							String sSubstituteDisplayType =FCBO.getMappedType(sSubstitutePartType.trim());
	  							sSubstitutePartType=util.mapType(sSubstitutePartType);
	  	  						String sSubstituteAssemblyType =FCBO.getSpecificationSubtypeForSubstitutes(context,sSubstitutePartId,sSubstitutePartType);
	  							String sSubstituteMinQty =validator.getStringEquivalentForStringList(slSubstituteMinQty.getElement(i));										
	  							String sSubstituteTarget=validator.getStringEquivalentForStringList(slSubstituteTarget.getElement(i));										
	  							String sSubstituteMaxQty =validator.getStringEquivalentForStringListWithComma(slSubstituteMaxQty.getElement(i));								
	  							String sSubstituteUOM =validator.getStringEquivalentForStringList(slSubstituteUOM.getElement(i));											
	  							String sSubstitutePI =validator.getStringEquivalentForStringListWithComma(slSubstitutePI.getElement(i));									
	  							String sSubstituteMF =validator.getStringEquivalentForStringListWithComma(slSubstituteMF.getElement(i));									
	  							String sSubstituteValidDate =validator.DateFormatter(validator.getStringEquivalentForStringListWithComma(slUntilDate.getElement(i)));	
	  							String sSubstituteComment =validator.getStringEquivalentForStringListWithComma(slComments.getElement(i));		
	  							
	  							boolean bSubstituteHasAccess = util.checkHasAccess(context,null,sSubstitutePartId);
	  							
	  							if(!bSubstituteHasAccess) {
	  	  							sSubstitutePartId    = ConstantsUtil.NO_ACCESS;
	  	  							sSubstituteChg = ConstantsUtil.NO_ACCESS;
	  	  						}
	  	  						
	  	  						util.formatData(sbSubPartId, sSubstitutePartId);
	  							util.formatData(sbSubPartTitle, sSubstituteTitle);
	  							util.formatData(sbSubPartSpecSubType, sSubstituteAssemblyType);
	  							util.formatData(sbSubPartValidUntiltDt, sSubstituteValidDate);
	  							//util.formatData(sbSubstituteChg, sSubstituteChg);
	  							util.formatData(sbSubPartDisplayType, sSubstituteDisplayType);
	  							util.formatData(sbSubPartType, sSubstitutePartType);
	  							util.formatData(sbSubPartName, sSubstituteName);
	  							util.formatData(sbSubstituteMinQTY, sSubstituteMinQty);
	  							util.formatData(sbSubstituteSCN, sSubstituteSCN);
	  							util.formatData(sbSubstituteMaxQTY, sSubstituteMaxQty);
	  							util.formatData(sbSubstituteTarget, sSubstituteTarget);
	  							util.formatData(sbSubstituteUOM, sSubstituteUOM);
	  							util.formatData(sbSubstitutePI, sSubstitutePI);
	  							util.formatData(sbSubstituteMF, sSubstituteMF);
	  							util.formatData(sbSubstituteCMT, sSubstituteComment);
	  	  						
	  							
	  						}
	  						mpEBOMResult.put(ConstantsUtil.SUBSTITUTEFOR, sSubstituteForName);
							mpEBOMResult.put(ConstantsUtil.TITLE, sSubstituteForTitle);
							mpEBOMResult.put(ConstantsUtilIRM.FORMULATION, sSubstituteForFormulation);
							mpEBOMResult.put(ConstantsUtil.DESCRIPTION, sSubstituteForFILDescr);
							
	  						mpEBOMResult.put(ConstantsUtil.DISPLAY_TYPE, sbSubPartDisplayType.toString());
							mpEBOMResult.put(ConstantsUtil.TYPE, sbSubPartType.toString());
							mpEBOMResult.put(ConstantsUtil.ID, sbSubPartId.toString());
							mpEBOMResult.put(ConstantsUtil.NAME, sbSubPartName.toString());
							//mpEBOMResult.put(ConstantsUtil.CHG, sbSubstituteChg.toString());
							mpEBOMResult.put(ConstantsUtil.SAPDESCRIPTION, sbSubPartTitle.toString());
							mpEBOMResult.put(ConstantsUtil.SUBTYPE, sbSubPartSpecSubType.toString());
							mpEBOMResult.put(ConstantsUtil.COMBINATIONNUMBER, sbSubstituteSCN.toString());
							mpEBOMResult.put(ConstantsUtil.MIN, sbSubstituteMinQTY.toString());
							mpEBOMResult.put(ConstantsUtil.TARGET, sbSubstituteTarget.toString());
							mpEBOMResult.put(ConstantsUtil.MAX, sbSubstituteMaxQTY.toString());
							mpEBOMResult.put(ConstantsUtil.UOM, sbSubstituteUOM.toString());
							mpEBOMResult.put(ConstantsUtil.MF, sbSubstituteMF.toString());
							mpEBOMResult.put(ConstantsUtil.PI, sbSubstitutePI.toString());
							mpEBOMResult.put(ConstantsUtil.VALIDTILLDATE, sbSubPartValidUntiltDt.toString());
							mpEBOMResult.put(ConstantsUtil.COMMENT, sbSubstituteCMT.toString());
							
							mpRetEBOMResult.put(inCounter,mpEBOMResult);
		  				}
		  				
		  					
						
					}
					
				}
				

			} catch (Exception e) {
				LOGGER.error("Exception in BSFBO : getSubstitutes : "+ e);
				return new HashMap<String, String>();
			}
			return mpRetEBOMResult;
		}
		//SPEC: Release SR18x.6.0 - Added by Sumit on Mar 10, 2021 -- END
	
}

