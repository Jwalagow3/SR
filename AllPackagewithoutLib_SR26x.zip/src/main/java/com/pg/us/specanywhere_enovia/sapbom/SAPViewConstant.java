package com.pg.us.specanywhere_enovia.sapbom;

//Added by Subhajit for Defect 51896 - Starts
public enum SAPViewConstant {
	
	PARENT_EBOM_LIST("parentEBOMList"),
    ALTERNATE_LIST("alternateList"),
    SUBSTITUTE_LIST("substituteList"),
    RESHIPPER("Reshipper"),
    IDENTIFIER_DUMMY("Dummy"),
    IDENTIFIER_ASSEMBLY_TYPE("assemblyType"),
    CTRLM_PROPERTIES_FILE("sapbom/BOMeDelivery.properties"),
    ATTRIBUTE_PGBOMEDELIVERY("pgBOMeDelivery"),
    ATTRIBUTE_PGBOMEDELIVERYPARENT("pgBOMeDeliveryParent"),
    CONFIG_OBJECT_NAME("pgBOMeDeliveryConfiguration"),
    SAP_BOM_EDELIVERY_ATTR_INTERFACE("pgBOMeDeliveryInterface"),
    BOM_EDELIVERY_CONFIG_PARAMETER_ISSUE("SAP Client Number | SAP System Number is not configured on config object"),
    BOM_EDELIVERY_CONFIG_OBJECT_MAP_ISSUE("Querying config object resulted in null map"),
    BOM_EDELIVERY_CONFIG_OBJECT_NOT_FOUND("SAP BOM eDelivery Config Object not found"),
    BOM_PROCESSED_SUCCESS_MESSAGE("BOM Successfully Processed"), 
    BOM_EDELIVERY_MAIL_MESSAGE_BODY("Hi,\n\nSAP BOM eDelivery cron job is stuck and is not executed properly for last 2 scheduled runs. Please look into the issue.\n\nThanks."),
    BOM_EDELIVERY_MAIL_MESSAGE_SUBJECT("SAP BOM eDelivery scheduled job problem"),
    
	
    // Modified by Subhajit for Defect 51896 - Starts
    KEY_COMPONENT_TYPES_LIST("__ComponentTypesList__"),
    KEY_PARENT("__Parent__"),
    KEY_HAS_PARENT("__hasParent__"),
    KEY_HAS_COMPONENT("__hasComponent__"),
    KEY_COMPONENTS("_Components__"),
    KEY_PARENT_ID("__ParentID__"),
    KEY_PARENT_TYPE("__ParentType__"),
    KEY_IS_PARENT_COMPLEX_BOM("__isParentComplexBOM__"),
    KEY_IS_SELF_COMPLEX_BOM("__isSelfComplexBOM__");
	// Modified by Subhajit for Defect 51896 - Ends
    private final String value;

    /**
     * Constructor
     *
     * @param value - String
     */
    SAPViewConstant(String value) {
        this.value = value;
    }

    /**
     * Method to get value
     *
     */
    public String getValue() {
        return value;
    }
}


