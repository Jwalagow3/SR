package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.pg.us.specanywhere_enovia.bo.TransportUnitBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class TransPortUnitPartService {

	private static Logger LOGGER = Logger.getLogger(TransPortUnitPartService.class);
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		String objId = "20336.41905.29965.28089";
		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
	    Context context = pool.checkOut();
		
	    Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Map<String,String> mpPartSpecSelects = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mpBomMcupResult = new HashMap<String,String>();
		
		TransportUnitBO TupBO = new TransportUnitBO();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, StringList> BusinessObjectSelectableMap = TupBO.getTUPSelectables(context);
		Map<String, StringList> ChilsObjectSelectableMap = TupBO.getTupRelatedObjsSelectableMap(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
		
		StringValidatorUtil validator = new StringValidatorUtil();
		ContextUtil.pushContext(context,PropertyUtil.getSchemaProperty(context,ConstantsUtil.USER_AGENT),ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING);
		DomainObject doTUP =  TupBO.getTupDO(context, objId);
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doTUP.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("TUP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		
		//BOM
		StopWatch swBom = new StopWatch();
		swBom.start();
		MapList mapList = doTUP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slChildBusSelects , slChildRelSelects, false, true, (short)0,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
		
		if(mapList.size()!=0){
			mpEBOMResult =	TupBO.parseMaplist(context,mapList);
		}
		pool.checkIn(context);
		ContextUtil.popContext(context);
		swBom.stop();
		LOGGER.info("TUP BOM ELAPSED TIME : "+swBom.getTime());
		
		//Basic  Data
		mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));		
		mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STRPALLETTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPALLETTYPE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTER_DIM_DEPTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTER_DIM_LENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTER_DIM_WIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONWIDTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OUTER_DIM_HEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOUTERDIMENSIONHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.VOLUME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEREAL) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.VOLUME_UOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGVOLUMEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.VOLUME_MAX_LENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERHANGMAXLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERHANGMAXLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DIM_UOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDIMENSIONUOM) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.UNDER_MAX_WIDTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PPGUNDERHANGMAXWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PPGUNDERHANGMAXWIDTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.UNDER_MAX_LENGTH, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNDERHANGMAXLENGTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNDERHANGMAXLENGTH) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.UNDER_MAX_HEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSECASEMAXHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.WHSE_LOGSTICS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSELOGISTICS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSELOGISTICS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TRUCK_STACK_MAXHGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTRUCKPALLETSTACKMAXHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CUBE_EFF, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFECIENCY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUBEEFFECIENCY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CUSTOM_PER_LAYER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITSPERLAYERINTEGER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.AREA_EFF, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAREAEFFECIENCY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAREAEFFECIENCY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LAYERS_PER_TRANSPORT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLAYERSPERTRANSPORTUNITINTEGER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.WAREHOUSEPALLETSTAKMAXGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWHSEPALLETSTACKMAXHEIGHT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OVER_HANG_MAX_WIDTH,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERHANGMAXWIDTH)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOVERHANGMAXWIDTH): ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STACKINGPATTERN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STACK_PATTEREN)))?(String)resultMaps.get(ConstantsUtil.STACK_PATTEREN) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.MODIFIED)))?(String)resultMaps.get(ConstantsUtil.MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
		String sClassifictaion = util.getClassification(resultMaps);
		mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
		
		//Organization Data
		StopWatch swOrganization = new StopWatch();
		swOrganization.start();
		mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization = util.filterMapList(mpOrganization);
		swOrganization.stop();
		LOGGER.info("TUP Organization ELAPSED TIME : "+swOrganization.getTime());
		
		
		//Part Specs
		StopWatch swPartSpecs = new StopWatch();
		swPartSpecs.start();
		mpPartSpecSelects = util.updatePartSpec(context,resultMaps);
		swPartSpecs.stop();
		LOGGER.info("TUP  PartSpecs ELAPSED TIME : "+swPartSpecs.getTime());
		
		
		//HeaderContent
		mpHeaderContent.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
		mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
		
		//Lifecycle
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={objId,sPhysicalId};
		StopWatch swLifecycle = new StopWatch();
		swLifecycle.start();
		mpLifeCycleApproval = util.getCOName(context, changeargs);
		swLifecycle.stop();
		LOGGER.info("TUP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
		mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
		
		//BOM Master Unit Part 
		StopWatch swBOMMasterUnitPart  = new StopWatch();
		swBOMMasterUnitPart.start();
		mpBomMcupResult = TupBO.parseTUPMaplist(mapList);
		swBOMMasterUnitPart.stop();
		LOGGER.info("TUP  BOMMasterUnitPart ELAPSED TIME : "+swBOMMasterUnitPart.getTime());
		
		
		//Ownership
		StopWatch swOwnerShip = new StopWatch();
		swOwnerShip.start();
		mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.MODIFIED)))?(String)resultMaps.get(ConstantsUtil.MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
		swOwnerShip.stop();
		LOGGER.info("TUP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());
		
		
		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecSelects);
		hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERCUSTOMERUNIT, mpBomMcupResult);
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
		
		
		sp.stop();
		System.out.println("Execution TIME::" + sp.getTime());
		System.out.println("RESULT:: \n" + mpPartSpecSelects);
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
		
 
		
}// main method
	
}//End of Class
