/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaARMPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import jakarta.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.ARMPBO;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaARMPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaARMPServiceImpl implements EnoviaARMPService {


	private static Logger LOGGER = Logger.getLogger(EnoviaARMPServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	//Added by Jwala for Enovia Profiling -- START
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	//Added by Jwala for Enovia Profiling -- END

	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
	private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

	@SuppressWarnings("static-access")
	@Override
	public HashMap<String, Map<String, String>> getARMPdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		Context context = null;
		try {
			
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			swContext.stop();
			
			LOGGER.info("ARMP CONTEXT ELAPSED TIME : "+swContext.getTime());


			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			ARMPBO RawBO = new ARMPBO();
			DomainObject doARMP =  RawBO.getArmpDO(context, objId);
			String strState = doARMP.getInfo(context, DomainConstants.SELECT_CURRENT);
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			//SPEC : 10/19/2020 : Security Check added for granting the access  --START
			//Modified by Ajay for Req No. 23964 -- START
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strState.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
				//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strState.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strState.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <10.08.2022>: Satyam Added for Defect 49774 -- END
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//Modified by Ajay for Req No. 23964 -- END
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpHeaderContent = new HashMap<String,String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			//Map<String,String> mpWeightResult = new HashMap<String,String>();
			Map<String,String> mpPartSpecResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpPerformChar = new HashMap<String,String>();
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//Map<String,String> mpNotes = new HashMap<String,String>();
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			Map<String,String> mpStartingMaterials = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			/*Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
			Map<String,String> mpDerivedToResult = new HashMap<String,String>();*/
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpCertification = new HashMap<String,String>();
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//Map<String,String> mpRelatedATS = new HashMap<String,String>();
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			Map<String,String> mpMaterialComposition = new HashMap<String,String>();
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();

			
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			Map<String,String> mpMEPResult = new HashMap<String,String>();
			Map<String,String> mpSEPResult = new HashMap<String,String>();
			//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
			
			//SPEC: Added for Dev 18x.6 Release by Jwala -- START
			Map<String,String> mpGPSAssessments = new HashMap<String,String>();
			//SPEC: Added for Dev 18x.6 Release by Jwala -- END
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();


			Map<String, StringList> BusinessObjectSelectableMap = RawBO.getARMPPartSelectables(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			
			/**
			 * Get Attribute Info
			 * */
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doARMP.getInfo(context, slContextSelects);
			Map resultMaps = doARMP.getInfo(context, slContextSelects,RawBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("ARMP GETINFO ELAPSED TIME : "+swAttributes.getTime());
						
			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sClassifictaion = util.getClassification(resultMaps);

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderContent.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

			if(bManufacturerView || bAllInfoView || bSupplierView) {

				/**
				 * LOAD HEADER SECTION
				 * */
				mpHeaderContent.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.STATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING));		

				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- START
				BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
				String sHasATSAttrVal = busUtil.checkHasATSForSIS(context,resultMaps);
				mpHeaderContent.put(ConstantsUtil.HASATS, sHasATSAttrVal);
				//SPEC: Release SR18x.5.2: Added for Defect 36563 by Amman -- START
				//mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.NOTAPPICABLE);
				//SPEC: Release SR18x.5.2: Added for Defect 36563 by Amman -- END
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- END
				mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);

				//SPEC: 10/09/2020: Modified for 18x.5 DEV -- START
				//mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
				/*if(!bManufacturerView && !bSupplierView){
					mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				}*/
				//Added by Ganesh for External Defect ---->START
				if(!bManufacturerView && !bSupplierView){
					mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				}
				//Added by Ganesh for External Defect ---->STOP
					//SPEC: 10/09/2020: Modified for 18x.5 DEV -- END

				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				mpHeaderContent.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderContent.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				//mpHeaderContent.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))));
				String masterId = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID));
				if (UIUtil.isNotNullAndNotEmpty(masterId)) {
					DomainObject obj = new DomainObject(masterId);
					String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					obj.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
					boolean showData = util.checkHasAccess(context, sUserType, masterId);
					if (!showData) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
				}
				mpHeaderContent.put(ConstantsUtil.MASTERPARTID, masterId);
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END

				String sClassification = util.getClassification(resultMaps);
				mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, (sClassification));

				/**
				 * LOAD ATTRIBUTE SECTION
				 * */
				//Contract Manufacturer View && All Info View
				//SPEC: 10/09/2020: Commented by Jwala for 18x.6 DEV -- START
				//if(!bSupplierView){
				//SPEC: 10/09/2020: Commented by Jwala for 18x.6 DEV -- END

				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				//Modified by Ganesh for External Defect raised by Internal Testing Team---->START
				//mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				//Modified by Ganesh for External Defect raised by Internal Testing Team----->STOP
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 10/09/2020: Added by Jwala for 18x.6 DEV -- START
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatterParse((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 10/09/2020: Added by Jwala for 18x.6 DEV -- END

				//SPEC: 10/09/2020: Commented by Jwala for 18x.6 DEV -- START
				//}
				//SPEC: 10/09/2020: Commented by Jwala for 18x.6 DEV -- END

				mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
				//mpAttribResult.put(ConstantsUtil.TEMPLATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_TEMPLATE)))?(String)resultMaps.get(ConstantsUtil.STR_TEMPLATE) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHELFLIFE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHELFLIFE) : ConstantsUtil.EMPTY_STRING);
				// Guna Modified for Defect 38533  18x.5.2 Release -- START
				//mpAttribResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION,validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtil.RELATIONSHIP_SHIPPING_HAZARD_CLASS)));
				// Guna Modified for Defect 38533  18x.5.2 Release -- END
				mpAttribResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_TEMP_LIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGE_HUMIDITY_LIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				
				// Jwala Added for Defect 41554 -- START
				//mpAttribResult.put(ConstantsUtil.MATERIALCERTIFICATIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALCERTIFICATIONS) : ConstantsUtil.EMPTY_STRING);
				String strMaterialCer = validator.getEquivalentString(resultMaps.get(ConstantsUtil.SELECT_PG_PLI_MATERIAL_CERTIFICATIONS_NAME));
				strMaterialCer = strMaterialCer.replace(ConstantsUtil.SYMBL_PIPE,ConstantsUtil.SYMBL_COMMA);;
				
				//Added Null CHeck as art of 50277
				// Ketan added for Internal Defect -- START
				if(UIUtil.isNotNullAndNotEmpty(strMaterialCer)) {
				if(strMaterialCer.substring(strMaterialCer.length() -1).equals(ConstantsUtil.SYMBL_COMMA)) {
				strMaterialCer = strMaterialCer.substring(0, strMaterialCer.length() -1);
				}
				}
				// Ketan added for Internal Defect -- END
				mpAttribResult.put(ConstantsUtil.MATERIALCERTIFICATIONS, strMaterialCer);
				// Jwala Added for Defect 41554 -- START
				
				mpAttribResult.put(ConstantsUtil.APPLICATION_AUTHORIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION) : ConstantsUtil.EMPTY_STRING);
				//Modified by Jwala for Defect #41558 -- START
				//Preferedmaterial coming as "No" but its replacing with "FALSE". wWe have raised above defect for this
				//mpAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING);
				//Modified by Jwala for Defect #41558 -- END
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);

				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQURED, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STRUCTUREDRELEASECRITERIAREQURED))));
				
				if(!bSupplierView){
					//Added by Ketan for Req. no. 46464 - START
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
					//Added by Ketan for Req. no. 46464 - END
					}
				
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START

				//SPEC: 10/09/2020: Commented by Jwala for 18x.6 DEV -- START
				/*if(bSupplierView){
					mpAttribResult.put(ConstantsUtil.REACHEXEMPT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_EXEMPT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REACH_EXEMPT) : ConstantsUtil.EMPTY_STRING);
				}*/
				//SPEC: 10/09/2020: Commented by Jwala for 18x.6 DEV -- END

				/**
				 * LOAD PERFORMANCE CHAR SECTION
				 * */ 
				Map paramMap = new HashMap();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				PerformanceCharcteristics perform = new PerformanceCharcteristics();
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				if(!mlPerformChar.isEmpty())
				{
					FinishedProductPartBO fppBO = new FinishedProductPartBO();
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
					//mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
					mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
					swPerfChar.stop();
					LOGGER.info("ARMP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
				}


				/**
				 * LOAD WEIGHT SECTION
				 * *//*
				//Contract Manufacturer View & All Info View
				mpWeightResult.put(ConstantsUtil.TYPE, util.mapType(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpWeightResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpWeightResult = util.filterMapList(mpWeightResult);*/

				/**
				 * LOAD PART-SPEC SECTION
				 * */
				//Contract Manufacturer View & All Info View
				mpPartSpecResult = util.updatePartSpec(context,resultMaps);

				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				MasterCOPBO mcop = new MasterCOPBO();
				mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
				swReference.stop();
				LOGGER.info("ARMP  Reference ELAPSED TIME : "+swReference.getTime());

				/**
				 * LOAD MASTER SPECS SECTION
				 * */
				//Contract Manufacturer View & All Info View
				StopWatch swmpMasterSpecs = new StopWatch();
				swmpMasterSpecs.start();
				mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);

				swmpMasterSpecs.stop();
				LOGGER.info("ARMP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());

				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
				/**
				 * LOAD NOTES
				 * */
				//mpNotes=mcop.updateNotes(context, resultMaps);
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END

				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				/**
				 * LOAD MATERIAL RESULTS SECTION
				 * */
				StopWatch swMaterial = new StopWatch();
				swMaterial.start();

				//SPEC: Modified related to Defect#37311 1.0.2 Release - Amman -- START
				//mpMaterialComposition = RawBO.getSubstances(context,sContextObjectId);
				mpMaterialComposition = RawBO.getMaterialCompositionAndSubstance(context, resultMaps);
				//SPEC: Modified related to Defect#37311 1.0.2 Release - Amman -- END

				mpMaterialComposition =util.verifyOwnership(context,mpMaterialComposition);
				swMaterial.stop();
				LOGGER.info("ARMP MATERIAL ELAPSED TIME : "+swMaterial.getTime());
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START

				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START

				/*mpMaterialComposition.put(ConstantsUtil.NAME, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_NAME)));	
				mpMaterialComposition.put(ConstantsUtil.TYPE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_TYPE)));	
				mpMaterialComposition.put(ConstantsUtil.TITLE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_TITLE)));
				mpMaterialComposition.put(ConstantsUtil.SUBSTANCENAME, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_SUBNAME)));		
				mpMaterialComposition.put(ConstantsUtil.MIN_PERCEN_WBW, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGPGMINIMUMPERCENTWEIGHTBYWEIGHT)));	
				mpMaterialComposition.put(ConstantsUtil.MAX_PERCEN_WBW, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COMP_MATERIAL_ATTRIB_PGMAXIMUMPERCENTWEIGHTBYWEIGHT)));	
				mpMaterialComposition.put(ConstantsUtil.UOM, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QUOM)));				
				mpMaterialComposition.put(ConstantsUtil.QTY, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_QTY)));				
				mpMaterialComposition.put(ConstantsUtil.FUNCTIONS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.FUNCTIONS)));				
				mpMaterialComposition.put(ConstantsUtil.DRYWEIGHT, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_DRYWEGHT)));		
				mpMaterialComposition.put(ConstantsUtil.IC, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ISCONTAM)));				
				mpMaterialComposition.put(ConstantsUtil.CAS, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_CASNUM)))	;			
				mpMaterialComposition.put(ConstantsUtil.STATE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_STATE)));				
				mpMaterialComposition.put(ConstantsUtil.REVISION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_REVS)))	;			
				mpMaterialComposition.put(ConstantsUtil.DESCRIPTION, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_DESC)));			
				mpMaterialComposition.put(ConstantsUtil.PHASE, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_RELEASE_PHASE)));		
				mpMaterialComposition.put(ConstantsUtil.ID, validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.COMP_ID)));*/
				//SPEC: 10/09/2020: Modified for 18x.5 DEV -- END
				if(bSupplierView || bManufacturerView) {
					mpMaterialComposition=util.filterPhase(mpMaterialComposition);
					mpMaterialComposition = util.filterMapList(mpMaterialComposition);

				}

				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
				/**
				 * LOAD RELATED ATS SECTION
				 * *//*
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=util.getRelatedAts(context, doARMP);

				mpRelatedATS=util.filterMapList(mpRelatedATS);
				if(!mpRelatedATS.isEmpty()){
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
				}

				if(bManufacturerView) {
					mpRelatedATS=util.filterPhase(mpRelatedATS);
				}

				swAts.stop();
				LOGGER.info("ARMP ATS ELAPSED TIME : "+swAts.getTime());*/
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END

				//SPEC: Added for Dev 18x.6 Release by Jwala -- START
				/**
				 * LOAD GPSASSESSMENTS SECTION
				 * */
				StopWatch swgps= new StopWatch();
				swgps.start();
				DeviceProductPartBO DPPBO = new DeviceProductPartBO();
				mpGPSAssessments = DPPBO.getGPSAssessments(context, sContextObjectId);
				mpGPSAssessments = util.filterMapList(mpGPSAssessments);
				swgps.stop();
				LOGGER.info("ARMP GPS ASSESSMENTS ELAPSED TIME : "+swgps.getTime());
				//SPEC: Added for Dev 18x.6 Release by Jwala -- END

				//SPEC: Added for Dev 18x.6 External Release by Jwala -- START
				/**
				 * This Method is for getting the MEPS
				 * @param context
				 * @param Relationship
				 * @param objectMap
				 * @param bMEP
				 * @return
				 * @throws Exception
				 */

				//Added by Jwala for 22x Development Req 42996 -- START
				boolean isUserCMandSP = BObjutil.isUserCMandSP(context, objId);
				//Added by Jwala for 22x Development Req 42996 -- END
				
				mpMEPResult = util.getPQREquivalents(context, resultMaps, true, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT,sUserType);

				//SPEC: <10.22.2020>: Added for req 18x.6 External Dev ## -- START
				if(bManufacturerView || bSupplierView){
					mpMEPResult.remove(ConstantsUtil.PQRBA);
					mpMEPResult.remove(ConstantsUtil.PQRPCP);
					// Added by Jwala for Req/Defect 35581 43951 -- START
					//SPEC: <21.12.2021>: Guna Modified for 42013 Req  Dev 18x.6.0.3 Release --- START
					//Modified by Jwala for 22x Development Req 42996 -- START
					if(bSupplierView && !isUserCMandSP){
					mpMEPResult.remove(ConstantsUtil.PQRPLANTS);
					}
					//Modified by Jwala for 22x Development Req 42996 -- END
					//SPEC: <21.12.2021>: Guna Modified for 42013 Req  Dev 18x.6.0.3 Release --- END
					// Added by Jwala for Req/Defect 35581 43951 -- END
				}
				//SPEC: <10.22.2020>: Added for req 18x.6 External Dev ## -- END
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- START
				if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
					mpMEPResult = new HashMap<String,String>();
                }
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- END
				
				/**
				 * This Method is for getting the SEPS 
				 * @param context
				 * @param Relationship
				 * @param objectMap
				 * @param bSEP
				 * @return
				 * @throws Exception
				 */

				mpSEPResult = util.getPQREquivalents(context, resultMaps, false, ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT,sUserType);

				//SPEC: <10.22.2020>: Added for req 18x.6 External Dev ## -- START
				if(bManufacturerView || bSupplierView){
					mpSEPResult.remove(ConstantsUtil.PQRBA);
					mpSEPResult.remove(ConstantsUtil.PQRPCP);
					// Added by Jwala for Req/Defect 35581 43951 -- START
					//SPEC: <21.12.2021>: Guna Modified for 42013 Req  Dev 18x.6.0.3 Release --- START
					//Modified by Jwala for 22x Development Req 42996 -- START
					if(bSupplierView && !isUserCMandSP){
						mpSEPResult.remove(ConstantsUtil.PQRPLANTS);
					}
					//Modified by Jwala for 22x Development Req 42996 -- END
					//SPEC: <21.12.2021>: Guna Modified for 42013 Req  Dev 18x.6.0.3 Release --- END
					// Added by Jwala for Req/Defect 35581 43951 -- END
				}
				//SPEC: Added for Dev 18x.6 External Release by Jwala -- END
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- START
				if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
					mpSEPResult = new HashMap<String,String>();
                }
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- END
				//SPEC: <10.22.2020>: Added for req 18x.6 External Dev ## -- START

				/**
				 * LOAD CERTIFICATIONS SECTION
				 * */
				// Added by Jwala for the req 4945 - START
				if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					MapList mlCertifications  = new MapList();
					String strARMPTypeCheck = (String)resultMaps.get(ConstantsUtil.SELECT_TYPE);
					if (strARMPTypeCheck.equalsIgnoreCase(ConstantsUtil.tARMP))
					{
						mlCertifications = commonBo.getCertifications(context, objId,strARMPTypeCheck);
					} else {
						mlCertifications = commonBo.getCertifications(context, objId);
					}
					mlCertifications.sort(DomainConstants.SELECT_NAME, "ascending", "String");

					Iterator itrCerts = mlCertifications.iterator();
					StringBuilder sbCertName = new StringBuilder();
					StringBuilder sbCertRev = new StringBuilder();
					StringBuilder sbCertType = new StringBuilder();
					StringBuilder sbCertDesc = new StringBuilder();
					StringBuilder sbCertState = new StringBuilder();
					StringBuilder sbCertifications = new StringBuilder();
					StringBuilder sbStatus = new StringBuilder();
					StringBuilder sbCExpirationDate = new StringBuilder();
					StringBuilder sbCertId = new StringBuilder();
					StringBuilder sbManufacturer = new StringBuilder();
					//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
					StringBuilder sbCertificationSource = new StringBuilder();
					//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- END

					while (itrCerts.hasNext()) {
						Map objectMap = (Map) itrCerts.next();
						String strCertification  =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_VALUE));
						StringTokenizer tokenize = new StringTokenizer(strCertification,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						String strStatus =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_STATUS));
						String strExpireDate =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CERTIFICATION_EXPIRATION_DATE));
						StringTokenizer statusTokenize = new StringTokenizer(strStatus,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						StringTokenizer expireDateTokenize = new StringTokenizer(strExpireDate,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
						String strSource =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_CERTIFICATION_SOURCE));
						StringTokenizer sourceTokenize = new StringTokenizer(strSource,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
						//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- END
						while(tokenize.hasMoreTokens())
						{
							String strCert  = tokenize.nextToken().toString().trim();
							String relName =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.KEY_RELATIONSHIP));
							//Modified by Bala for External Defect 18x.6.0.1 Release -- 04/06/2021 -->START
							//formatData(sbCertName,validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME)));
							String strCertName=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
							//formatData(sbCertRev, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION)));
							String strCertRev=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
							//formatData(sbCertType, util.mapType(validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE))));
							String strCertType=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
							//Modified by Bala for External Defect 18x.6.0.1 Release -- 04/06/2021 -->END
							//formatData(sbCertDesc, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION)));
							String strCertDesc=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
							String strCurrent = (String)objectMap.get(ConstantsUtil.SELECT_CURRENT).toString();
							//LOGGER.info("NAME::::"+objectMap.get(ConstantsUtil.SELECT_NAME));
							if (objectMap.get(ConstantsUtil.SELECT_NAME).toString().contains("MEP-"))
							{
								if (objectMap.get(ConstantsUtil.SELECT_CURRENT).toString().equalsIgnoreCase(ConstantsUtil.STATE_RELEASE))
								{
									//formatData(sbCertState, ConstantsUtil.RELEASED);
									strCurrent=ConstantsUtil.RELEASED;
								}
								else if (objectMap.get(ConstantsUtil.SELECT_CURRENT).toString().equalsIgnoreCase(ConstantsUtil.STATE_PRELIMINARY))
								{
									//formatData(sbCertState, ConstantsUtil.STATE_INWORK);
									strCurrent=ConstantsUtil.STATE_INWORK;
								}
								else
								{
									//formatData(sbCertState, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
									strCurrent = strCurrent;
								}
							} else {
								//Modified by Bala for External Defect 18x.6.0.1 Release -- 04/06/2021 -->START
								//formatData(sbCertState, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT)));
								strCurrent=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
								//Modified by Bala for External Defect 18x.6.0.1 Release -- 04/06/2021 -->END
							}
							//formatData(sbCertifications, strCert);
							//Added by Ganesh for External defect---->START
							String sCertId=validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
							boolean showData=util.checkHasAccess(context, sUserType, sCertId);
							//Added by Ganesh for External defect---->STOP
							// SPEC :: Added by Jwala for  Defect#41654 -- START
							//String strCurrent = (String)objectMap.get(ConstantsUtil.SELECT_CURRENT).toString();
							if(!strCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !strCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
								//formatData(sbCertId,ConstantsUtil.NO_ACCESS);
								sCertId=ConstantsUtil.NO_ACCESS;
							}else{
								//formatData(sbCertId, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID)));
								sCertId=sCertId;
							}
							// SPEC :: Added by Jwala for  Defect#41654 -- END
							//Modified by Bala for External Defect 18x.6.0.1 Release -- 04/06/2021 -->START
							String sStatus=ConstantsUtil.EMPTY_STRING;
							String strCExpirationDate = ConstantsUtil.EMPTY_STRING;
							String strCManufacturer=ConstantsUtil.EMPTY_STRING;
							if(statusTokenize.hasMoreTokens() && expireDateTokenize.hasMoreTokens()){
								//formatData(sbStatus,statusTokenize.nextToken().toString().trim());
								sStatus=statusTokenize.nextToken().toString().trim();
								strCExpirationDate = validator.DateFormatterParse(expireDateTokenize.nextToken().toString().trim());
								//formatData(sbCExpirationDate,validator.DateFormatterParse(expireDateTokenize.nextToken().toString().trim()));
							}
							//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
							String sSource=ConstantsUtil.EMPTY_STRING;
							if(sourceTokenize.hasMoreTokens()) {
								sSource=sourceTokenize.nextToken().trim();
							}
							//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- END
							/*else{
							//formatData(sbStatus,ConstantsUtil.EMPTY_STRING);
							 sStatus= ConstantsUtil.EMPTY_STRING;
							formatData(sbCExpirationDate,ConstantsUtil.EMPTY_STRING);
						}*/
							if(relName.equals(ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT)){
								strCManufacturer = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_NAME));
								//formatData(sbManufacturer, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_SUPPLYRESPONSIBILITY_NAME)));
							}else{
								strCManufacturer = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_MANUFACTURINGRESPONSIBILITY_NAME));
								//formatData(sbManufacturer, validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_MANUFACTURINGRESPONSIBILITY_NAME)));
							}
							//Added by Ganesh for External defect---->START
							//SPEC: <03.06.2021>: Bala Modified for External Defect 33248 Revert Back changes Dev 18x.6.0.1-- START
							//SPEC: 21/05/2021: Modified for 18x.6.0.1 External Defect by Bala-- START
							if (!showData && util.isModificatinRequired()) {							
								continue;						
							}else if(!showData) {							
								/*sStatus=ConstantsUtil.NO_ACCESS;
							strCertDesc=ConstantsUtil.NO_ACCESS;
							strCurrent=ConstantsUtil.NO_ACCESS;*/							
								sCertId=ConstantsUtil.NO_ACCESS;
							} 
							//SPEC: 21/05/2021: Modified for 18x.6.0.1 External Defect by Bala-- END
							//SPEC: <03.06.2021>: Bala Modified for External Defect 33248 Revert Back changes Dev 18x.6.0.1-- END

							//SPEC: Added for 18x.6.0.1 ALM Defect 43436 by Jwala-- START
							strCertType = util.mapType(strCertType);
							//SPEC: Added for 18x.6.0.1 ALM Defect 43436 by Jwala-- START

							formatData(sbCertName, strCertName);
							formatData(sbCertRev, strCertRev);
							formatData(sbCertType, strCertType);
							formatData(sbCertifications, strCert);
							formatData(sbCExpirationDate, strCExpirationDate);
							formatData(sbManufacturer, strCManufacturer);
							//Modified by Bala for External Defect 18x.6.0.1 Release -- 04/06/2021 -->END
							formatData(sbStatus,sStatus);
							formatData(sbCertDesc,strCertDesc);
							formatData(sbCertState,strCurrent);
							formatData(sbCertId,sCertId);
							//Added by Ganesh for External defect---->STOP
							//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- START
							formatData(sbCertificationSource,sSource);
							//SPEC: <10.06.2022>: Manikanta Added for Req 41754 22x Release  -- END
						}
					}
					mpCertification.put(ConstantsUtil.NAME, sbCertName.toString());
					mpCertification.put(ConstantsUtil.REVISION, sbCertRev.toString());
					mpCertification.put(ConstantsUtil.TYPE, sbCertType.toString());
					mpCertification.put(ConstantsUtil.DESCRIPTION, sbCertDesc.toString());
					mpCertification.put(ConstantsUtil.STATE, sbCertState.toString());
					mpCertification.put(ConstantsUtil.CERTIFICATION, sbCertifications.toString());
					mpCertification.put(ConstantsUtil.STATUS, sbStatus.toString());
					mpCertification.put(ConstantsUtil.EXPIRATIONDATE, sbCExpirationDate.toString());
					mpCertification.put(ConstantsUtil.ID, sbCertId.toString());
					mpCertification.put(ConstantsUtil.MANUFACTURER, sbManufacturer.toString());
					//SPEC: 04/04/2022: Added by Manikanta for 18x.6.0.4 DEV -- START
					mpCertification.put(ConstantsUtilIRM.CERTIFICATIONSOURCE, sbCertificationSource.toString());
					//SPEC: 04/04/2022: Added by Manikanta for 18x.6.0.4 DEV -- END
				}
				// Added by Jwala for the req 4945 - END
				/**
				 * SECURITY
				 * */
				StopWatch swSecurity = new StopWatch();
				swSecurity.start();
				mpSecurity =commonBo.updateSecurity(context, resultMaps);
				swSecurity.stop();
				LOGGER.info("ARMP Security ELAPSED TIME : "+swSecurity.getTime());
				
				//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
				//IP Class
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIPClass =commonBo.getIpClass(context, doARMP, slIpSelects);
				
				/**
				 * LOAD ORGANIZATION SECTION
				 */
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = util.filterMapList(mpOrganization);
				
				//SPEC: <10.22.2020>: Added for req 18x.6 External Dev ## -- END

			}

			if(bAllInfoView ) {
				//SPEC: <10.22.2020>: Commented for req 18x.6 External Dev ## -- START
				
				
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
				
				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
				
				mpAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZEREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.GROSSWEIGHTUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCU, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITREAL) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NETWEIGHTOFPRODUCTINCUUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNETWEIGHTOFPRODUCTINCONSUMERUNITUOM) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CRUSHINDEX, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRUSHINDEX) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMaps.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.VAULT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_VAULT)))?(String)resultMaps.get(ConstantsUtil.SELECT_VAULT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ALTERNATIVEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGALTERNATEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
				mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				//mpAttribResult.put(ConstantsUtil.PREFERREDMATERIAL, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREFERREDMATERIAL) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.SHIPRECEIVEINFO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PGASLALLOCATION, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.RERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER,  util.getLastUpdatedUser(context, sContextObjectId));
				
				/**
				 * LOAD LIFECYCLE SECTION
				 * */
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval= util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("ARMP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);

				
				/**
				 * LOAD PLANT SECTION
				 * */
				//SPEC: 13 October 2021: Modified for 18x.6.0.2 Defect #37214 by Bala-- START
				//mpPlantResult = util.updatePlantInfo(resultMaps);
				Map mPlantResultMap = RawBO.updatePlantInfo(context, doARMP);
				mpPlantResult = util.updatePlantInfo(mPlantResultMap);
				//SPEC: 13 October 2021: Modified for 18x.6.0.2 Defect #37214 by Bala-- END
				//SPEC: 10/09/2020: Commented by Jwala for 18x.6 DEV -- END


				/**
				 * LOAD OWNERSHIP SECTION
				 * */
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.OSO, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
				StopWatch swGetEDL = new StopWatch();
				swGetEDL.start();
				String sEDList =RawMaterialPartBO.getEDList(resultMaps,ldapuser,ldappwd);
				swGetEDL.stop();
				LOGGER.info("ARMP GET EDL ELAPSED TIME : "+swGetEDL.getTime());
				mapOwnerShipResult.put(ConstantsUtil.EDL, sEDList);
				mapOwnerShipResult.put(ConstantsUtil.ODL, util.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST) : ConstantsUtil.EMPTY_STRING));
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
				
				/**
				 * FILES SECTION
				 */
				//SPEC: <10.12.2020>: Added for req 18x.5 ## -- START
				
				
				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				String FileSize = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));

				StringBuilder sbFileSize = new StringBuilder();
				if(!FileSize.isEmpty()) {
					String[] strFileSize=FileSize.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

					for (int i = 0; i < strFileSize.length; i++) {
						String strEachFileSize = strFileSize[i];
						double dFileSize = Double.parseDouble(strEachFileSize);
						dFileSize = dFileSize/1024;
						strEachFileSize = Double.toString(dFileSize).format("%.2f", dFileSize);
						sbFileSize.append(strEachFileSize).append(" KB").append(ConstantsUtil.SYMBL_PIPE);
					}
				}
				
				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());
				
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
				
			}
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END

			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			//SPEC: 04/04/2022: Modified by Manikanta for 18x.6.0.4 DEV -- START
			if(!bSupplierView){
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: 04/04/2022: Modified by Manikanta for 18x.6.0.4 DEV -- END
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			hmAttrib.put(ConstantsUtil.STARTINGMATERIALS, mpStartingMaterials);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			//hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
			
			//SPEC: 10/09/2020: Modified by Jwala for 18x.6 DEV -- START
			if(!bSupplierView){
			hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
			}
			//SPEC: 10/09/2020: Modified by Jwala for 18x.6 DEV -- END
			
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpPartSpecResult);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
			//hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO, mpDerivedToResult);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			//SPEC: 04/04/2022: Modified by Manikanta for 18x.6.0.4 DEV -- START
			if(!bSupplierView){
				mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			}
			//SPEC: 04/04/2022: Modified by Manikanta for 18x.6.0.4 DEV -- END
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				hmAttrib.put(ConstantsUtil.CERTIFICATION, mpCertification);
			}
			// Added by Jwala for the req 4945 - END
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			hmAttrib.put(ConstantsUtil.MATERIALCOMPOSITION, mpMaterialComposition);
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- START
			//SPEC: 04/04/2022: Modified by Manikanta for 18x.6.0.4 DEV -- START
			if(!bSupplierView){
				mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.IPCLASSES, mpIPClass);
			}
			//SPEC: 04/04/2022: Modified by Manikanta for 18x.6.0.4 DEV -- END
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
			hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult); 
			//SPEC: 10/09/2020: Commented for 18x.5 DEV -- END
			
			//SPEC: Added for Dev 18x.6 Release by Jwala -- START
			hmAttrib.put(ConstantsUtil.GPSASSESSMENTS, mpGPSAssessments);
			//SPEC: Added for Dev 18x.6 Release by Jwala -- END
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			pool.checkIn(context);
			sp.stop();
			
			if(sComp.equals(ConstantsUtilIRM.ARMP)) {
				context.close();
			}

			LOGGER.info("ARMP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		} catch (IOException e) {
			LOGGER.error("Unable to getRMPdata IOException: "+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getRMPdata MatrixException: "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		

		return hmAttrib;
	}
	public static void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
}
