package com.pg.us.specanywhere_enovia.bo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class FormulaCardUnStructured 
{
	private static Logger LOGGER = Logger.getLogger(FormulaCardUnStructured.class);
	public HashMap<String, Map<String, String>> getFormulaCardData(Context context ,String objId,String strPDFView) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		try
		{

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			String sUserType = sct.getUserType();

			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END

			if(null==sUserType) {
				LOGGER.info("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				return hmAttrib;
			}

			boolean bAllInfoView = false;
			boolean bManufacturerView = false;
			
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				bManufacturerView = true;
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				bManufacturerView = true;
			} else {
				switch (sUserType) {
				case ConstantsUtil.PG:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PGSTAFF:
					bAllInfoView = true;
					break;

				case ConstantsUtil.PG_CM:
					bManufacturerView = true;
					break;

				}

			}
		
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			StringValidatorUtil validator = new StringValidatorUtil();

			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpHasATS = new HashMap<String,String>();
			Map<String,String> mpIsATS = new HashMap<String,String>();
			Map<String,String> mpTechnicalSupersedes = new HashMap<String,String>();
			Map<String,String> mpTechnicalSupersedesBy = new HashMap<String,String>();
			Map<String,String> mpMaterialProduced  = new HashMap<String,String>();
			Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mpIPClass = new HashMap<String, String>();
			Map<String,String> mapCountryClearanceResult = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mpAcs = new HashMap<String,String>();
			Map<String,String> mapIAPS = new HashMap<String,String>();



			FormulaCardBO fcBO = new FormulaCardBO();
			StringList slContextSelects = fcBO.getFormulaCardSelects(context);
			DomainObject doFC=fcBO.getFormulaCardDO(context, objId);
			fcBO.addMultiList();
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			Map resultMaps = doFC.getInfo(context, slContextSelects);
			//SPEC: Release SR18x.5.2 - Added for Defect #39951  by Bala on Feb 18, 2021 -- START
			String strLastUpdateUser = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
			//SPEC: Release SR18x.5.2 - Added for Defect #39951  by Bala on Feb 18, 2021 -- END

			swAttributes.stop();
			LOGGER.info("Formula Card GETINFO ELAPSED TIME : "+swAttributes.getTime());
			fcBO.removeMultiList();


			Map BusinessObjectRelSelectableMap = fcBO.getBOMSelects(context);
			StringList slEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slRelEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.REL_SELECTS);


			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;


			/**
			 *Attribute Section
			 */
			if(bAllInfoView || bManufacturerView)
			{
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);

				String sClassifictaion = util.getClassification(resultMaps);
				mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));

				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);

				String strBrand=util.getMultiLineAttributeValueForBrandInformation(context,sContextObjectId);
				/*if(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION))) {
					strBrand = (String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
					String[] Brand=strBrand.split(ConstantsUtil.SYMBL_TILDA);
					strBrand = Brand[0].toString();
				}*/
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);

				mpAttribResult.put(ConstantsUtil.RERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);

				mpAttribResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_HAZARD_CLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);

			}
			if(bAllInfoView )
			{
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ISBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISBATTERY) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DOESTHEPRODUCTCONTAINBATTERY, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONTAINSBATTERY) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.MATERIAL_GROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALGROUP) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STR_TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);

				String sIntededMarket =validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING;
				if (UIUtil.isNotNullAndNotEmpty(sIntededMarket)) {
					sIntededMarket=sIntededMarket.replace(ConstantsUtil.SYMBL_PIPE,ConstantsUtil.SYMBL_BREAK);
				}
				mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, sIntededMarket);
				mpAttribResult.put(ConstantsUtil.PGASLALLOCATION, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASLALLOCATION) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, validator.DateFormatter((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING));

				mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);


				/**
				 * LOAD LIFECYCLE SECTION
				 * */
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				swLifecycle.stop();
				LOGGER.info("Formula Card Unstructered GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

				/**
				 * Has ATS
				 */
				mpHasATS = util.checkHasATS(context,resultMaps);

				/**
				 * Technical SupersedesBy 
				 */

				mpTechnicalSupersedesBy=util.getTechnicalSupersedesBy(context, resultMaps);


				/**
				 * LOAD ORGANIZATION DATA SECTION
				 * */

				StopWatch swOrganization = new StopWatch();
				swOrganization.start();
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = util.filterMapList(mpOrganization);
				swOrganization.stop();
				LOGGER.info("Formula Card Organization ELAPSED TIME : "+swOrganization.getTime());

				/**
				 * 
				 * LOAD SAP BOM as FED SECTION
				 *
				 * */
				mpSapBomAsFedcResult = fcBO.getFinalIngredients(context,sContextObjectId,resultMaps);


				/**
				 * LOAD REFERENCE DOCS SECTION
				 * 
				 * */

				StopWatch swReference= new StopWatch();
				swReference.start();
				MasterCOPBO mcop = new MasterCOPBO();
				mapReferenceDocs =  fcBO.updateRefDocs(context, resultMaps);
				swReference.stop();
				LOGGER.info("Formula Card  Reference ELAPSED TIME : "+swReference.getTime());


				/**
				 * LOAD COUNTRY CLEARANCE SECTION
				 * */

				
				APPBO APPBO = new APPBO();
				mapCountryClearanceResult =  APPBO.getCountryClearance(context, sContextObjectId);
				mapCountryClearanceResult = util.filterMapList(mapCountryClearanceResult);

				/**
				 * LOAD SECURITY SECTION
				 * */
				StopWatch swSecurity = new StopWatch();
				//CommonBusUtilBO bo = new CommonBusUtilBO();
				swSecurity.start();
				
				mpSecurity =fcBO.getSecurityClass(context,sContextObjectId,ConstantsUtil.TYPE_SECURITYCONTROLCLASS);
				swSecurity.stop();
				LOGGER.info("Formula Card  Security ELAPSED TIME : "+swSecurity.getTime());

				mpIPClass =fcBO.getSecurityClass(context,sContextObjectId,ConstantsUtil.TYPE_IPCONTROLCLASS);

			}

			if(bAllInfoView || bManufacturerView )
			{
				String sHasATS = "";
				String sIsATS = "";

				sHasATS =util.checkHasATSForSIS(context,resultMaps);

				sIsATS =util.checkIsATSForSIS(context,resultMaps);				
				//SPEC: Release SR18x.6.0.1 Modified by Dominic for Defect 43777 on Date 23/06/2021 --END

				/**
				 * LOAD HEADER SECTION
				 * */

				//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
				} else {
					mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
				}
				//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END

				mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?util.mapType((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);		
				mpHeaderResult.put(ConstantsUtil.HASATS, sHasATS);
				mpHeaderResult.put(ConstantsUtil.ISATS, sIsATS);
				mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
				String sClassification = util.getClassification(resultMaps);
				mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
				mpHeaderResult.put(ConstantsUtil.ISSTRUCTURED, ConstantsUtil.SYMBL_FALSE);
				mpHeaderResult.put(ConstantsUtil.PDF_VIEW, util.getPdfViewtype(bAllInfoView, false, false));

				/**
				 * Is ATS
				 */

				//SPEC: Release SR18x.5.2 - Added for Defect #39950 & #39469 by Bala on Date Feb 19, 2021 -- START
				MapList mlIsATSList = new MapList();
				Map mIsATSGResultMap = new HashMap();
				Pattern pRelPattern = new Pattern(ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION);	 
				String sWhere = "current!=Obsolete";

				StringList slSelectStmts= new StringList();	 
				slSelectStmts.add(ConstantsUtil.SELECT_ID);
				slSelectStmts.add(ConstantsUtil.SELECT_NAME);
				slSelectStmts.add(ConstantsUtil.SELECT_REVISION);
				slSelectStmts.add(ConstantsUtil.SELECT_TYPE);
				slSelectStmts.add(ConstantsUtil.SELECT_CURRENT);
				slSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slSelectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);

				StringList slId = new StringList();
				StringList slName = new StringList();
				StringList slRev = new StringList();
				StringList slType = new StringList();
				StringList slCurrent = new StringList();
				StringList slPhase = new StringList();
				StringList slTitle = new StringList();

				mlIsATSList = doFC.getRelatedObjects(context, pRelPattern.getPattern(),
						ConstantsUtil.SYMBL_ASTERISK, slSelectStmts, null, false, true, (short)1, 
						sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

				Iterator objectListItr = mlIsATSList.iterator();
				while(objectListItr.hasNext()) 
				{
					mIsATSGResultMap = (Map) objectListItr.next();
					slId.add((String)mIsATSGResultMap.get(ConstantsUtil.SELECT_ID));
					slName.add((String)mIsATSGResultMap.get(ConstantsUtil.SELECT_NAME));
					slRev.add((String)mIsATSGResultMap.get(ConstantsUtil.SELECT_REVISION));
					slType.add((String)mIsATSGResultMap.get(ConstantsUtil.SELECT_TYPE));
					slCurrent.add((String)mIsATSGResultMap.get(ConstantsUtil.SELECT_CURRENT));
					slPhase.add((String)mIsATSGResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
					slTitle.add((String)mIsATSGResultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));	
				}
				mIsATSGResultMap = new HashMap();
				mIsATSGResultMap.put(ConstantsUtil.REL_ATS_ID, slId);
				mIsATSGResultMap.put(ConstantsUtil.REL_ATS_NAME, slName);
				mIsATSGResultMap.put(ConstantsUtil.REL_ATS_REV, slRev);
				mIsATSGResultMap.put(ConstantsUtil.REL_ATS_TYPE, slType);
				mIsATSGResultMap.put(ConstantsUtil.REL_ATS_STATE, slCurrent);
				mIsATSGResultMap.put(ConstantsUtil.REL_ATS_RELEASE_PHASE, slPhase);
				mIsATSGResultMap.put(ConstantsUtil.REL_ATS_TITLE, slTitle);
				mpIsATS = util.checkIsATS(context,mIsATSGResultMap);
				//SPEC: Release SR18x.5.2 - Added for Defect #39950 & #39469 by Bala on Date Feb 19, 2021 -- END

				/**
				 * Technical Supersedes 
				 */

				mpTechnicalSupersedes=util.getTechnicalSupersedes(context, resultMaps);



				/**
				 * Materials Produced By this Formulation
				 */

				//SPEC: Jwala Modified for Defect 43146 Release 18x.6.0.1 -- START
				//mpMaterialProduced=util.getMaterialsProceeded(context, resultMaps);
				mpMaterialProduced=util.getMaterialsProceeded(context, sContextObjectId);
				//SPEC: Jwala Modified for Defect 43146 Release 18x.6.0.1 -- END

			}

			if(bAllInfoView || bManufacturerView )
			{
				hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
				hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
				hmAttrib.put(ConstantsUtil.ISATS, mpIsATS);
				hmAttrib.put(ConstantsUtil.MATERIALS, mpMaterialProduced);
			}

			//if(bAllInfoView)
			if(!bManufacturerView)
			{
				hmAttrib.put(ConstantsUtil.RELIAPS, mapIAPS);
				hmAttrib.put(ConstantsUtil.TECHSUPERSEDESBY, mpTechnicalSupersedesBy);
				hmAttrib.put(ConstantsUtil.HASATS, mpHasATS);
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
				hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
				//hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
				hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
				hmAttrib.put(ConstantsUtil.MARKETOFCLEARANCE, mapCountryClearanceResult);
				//SPEC: 31-03-2022: Added for Req 35904 DEV by Manikanta -- START
				mpSecurity.remove(ConstantsUtil.LIBRARY);
				mpSecurity.remove(ConstantsUtil.CLASSIFICATIONPATH);
				mpIPClass.remove(ConstantsUtil.LIBRARY);
				mpIPClass.remove(ConstantsUtil.CLASSIFICATIONPATH);
				//SPEC: 31-03-2022: Added for Req 35904 DEV by Manikanta -- END
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
				hmAttrib.put(ConstantsUtil.IPSECURITY, mpIPClass);
			}

			sp.stop();
			LOGGER.info("Formula Card Execution TIME::" + sp.getTime() +"  " + "Formula Card  OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));

		} catch (IOException e) {
			LOGGER.error("Unable to get Formula Card details "+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to get Formula Card details "+e);
		}
		LOGGER.info("Formula Card RESPONSE MESSAGE:: \n" + hmAttrib);
		return hmAttrib;

	}

}


