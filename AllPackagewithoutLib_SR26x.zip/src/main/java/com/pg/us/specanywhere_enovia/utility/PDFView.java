package com.pg.us.specanywhere_enovia.utility;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PDFView {
	@JsonProperty("Name")
	private String name;
	@JsonProperty("Rev")
	private String revision;
	@JsonProperty("Type")
	private String type;
	@JsonProperty("Id")
	private String objectId;

	public PDFView() {
		super();
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRevision() {
		return revision;
	}

	public void setRevision(String revision) {
		this.revision = revision;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	@Override
	public String toString() {
		return "PDFView [name=" + name + ", revision=" + revision + ", type=" + type + ", objectId=" + objectId + "]";
	}
}
