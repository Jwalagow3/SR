package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class SmartLabelBO {
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(SmartLabelBO.class);

	public SmartLabelBO() {
		// empty constructor
	}

	/**
	 * Method Name : getAPPSelectableMap Method Description :
	 * 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getSMLSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_POLICY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSMARTLABELSUBTYPE);
		busSelect.add(ConstantsUtilIRM.REL_SMARTLABELNAME);
		busSelect.add(ConstantsUtilIRM.REL_SMARTLABELREVISION);
		busSelect.add(ConstantsUtilIRM.REL_SMARTLABELSTATE);
		busSelect.add(ConstantsUtilIRM.REL_SMARTLABELID);
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);

		return mapSelecables;
	}

	/**
	 * Method Name : getSMLDO Method Description : Initialization of domain
	 * objects with their corresponding IDs
	 * 
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getSMLDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			return doObj;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}

	/**
	 * D This method is used to fetch the Smart Label Rows in Smart Label Rows
	 * tab
	 * 
	 * @param context
	 *            is the matrix context
	 * @param strSubType
	 * @param object
	 *            id has the required information
	 * @return Map
	 * @throws Exception
	 */
	public Map getConnectedSmartLabelRows(Context context, String partId, String strSubType) throws Exception {
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpSmartLabelRow = new HashMap();
		MapList mlSmartLabelRowList = new MapList();

		try {
			if (UIUtil.isNotNullAndNotEmpty(partId)) {
				StringBuilder sbIngredient = new StringBuilder();
				StringBuilder sbLayer = new StringBuilder();
				StringBuilder sbPurpose = new StringBuilder();
				StringBuilder sbCAS = new StringBuilder();
				StringBuilder sbChemical = new StringBuilder();
				StringBuilder sbConsumer = new StringBuilder();
				StringBuilder sbSeqNo = new StringBuilder();
				
				StringList genericTypeList = FrameworkUtil.split(ConstantsUtilIRM.GENERICTYPES,
						ConstantsUtil.SYMBL_COMMA);
				DomainObject domObj = DomainObject.newInstance(context, partId);
				StringList selectStmts = new StringList(); // putting elements
															// to StringList
				selectStmts.addElement(ConstantsUtil.SELECT_ID);
				selectStmts.addElement(ConstantsUtil.SELECT_TYPE);
				selectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGINGREDIENT);
				selectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLAYER);
				selectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_ATTRIBUTE_PGPURPOSE);
				selectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_ATTRIBUTE_CASNUMBER);
				selectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_ATTRIBUTE_PGCHEMICALSOFCONCERN);
				selectStmts.addElement(ConstantsUtilIRM.SELECT_DESCRIPTION);
				selectStmts.addElement(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSEQNO);
				selectStmts.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSEQNO);
				
				StringList selectRelStmts = new StringList(2);
				selectRelStmts.addElement(ConstantsUtil.SELECT_RELATIONSHIP_ID); // Relationship
																					// Selects
				// Retrieving related item
				Pattern relPattern = new Pattern(ConstantsUtilIRM.REL_PG_SMART_LABEL_ROW);
				Pattern typePattern = new Pattern(ConstantsUtilIRM.TYPE_PG_SMART_LABEL_ROW);
				mlSmartLabelRowList = domObj.getRelatedObjects(context, relPattern.getPattern(), // relationship pattern
						typePattern.getPattern(), // object pattern
						selectStmts, // object selects
						selectRelStmts, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						null, // object where clause
						null, 0);
				//SPEC: <01.08.2022>: Guna Added for 42006 Defect   Dev 22x    -- START
				mlSmartLabelRowList.sort(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSEQNO, ConstantsUtil.ASCENDING, ConstantsUtil.INTEGER);
				//SPEC: <01.08.2022>: Guna Added for 42006 Defect   Dev 22x    -- END
				if (mlSmartLabelRowList.size() != 0) {
					Iterator smartLabelItr = mlSmartLabelRowList.iterator();
					while (smartLabelItr.hasNext()) {
						Map mpSmartRow = (Map) smartLabelItr.next();
						//SPEC: <01.06.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
						/*String strIngredient = validator.getStringEquivalentForStringList(
								mpSmartRow.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGINGREDIENT));*/
						String strIngredient = validator.getStringEquivalentForSubstituteString(
								mpSmartRow.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGINGREDIENT));
						//SPEC: <01.06.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
						String strLayer = validator.getStringEquivalentForStringList(
								mpSmartRow.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLAYER));
						//MOdified by Jwala for the ALM defect 42849 -- START
						String strPurpose = validator.getStringEquivalentForSubstituteString(
								mpSmartRow.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ATTRIBUTE_PGPURPOSE));
						//MOdified by Jwala for the ALM defect 42849 -- END
						String strCAS = validator.getStringEquivalentForStringList(
								mpSmartRow.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ATTRIBUTE_CASNUMBER));
						//SPEC: <01.04.2021>: Guna Modified for 42006 Defect  Dev 18x.6   -- START
						/*String strChemicalsofConcern = validator.getStringEquivalentForStringList(
								mpSmartRow.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ATTRIBUTE_PGCHEMICALSOFCONCERN));*/
						String strChemicalsofConcern = validator.getStringEquivalentForSubstituteString(
								mpSmartRow.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ATTRIBUTE_PGCHEMICALSOFCONCERN));
						//SPEC: <01.04.2021>: Guna Modified for 42006 Defect  Dev 18x.6   -- END
						String strSequenceNo = validator.getStringEquivalentForSubstituteString(
								mpSmartRow.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSEQNO));
						//SPEC: <21.05.2021>: Guna Modified for 43112 Defect  Dev 18x.6.0.1   -- START
						/*String strDescription = validator
								.getStringEquivalentForStringList(mpSmartRow.get(ConstantsUtil.DESCRIPTION));*/
						
						String strDescription = validator
								.getStringEquivalentForSubstituteStringTitle(mpSmartRow.get(ConstantsUtil.DESCRIPTION));
						
						//SPEC: <29.07.2022>: Guna Added for 42006 Defect   Dev 22x    -- START
						strDescription =strDescription.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
						strChemicalsofConcern =strChemicalsofConcern.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
						strIngredient =strIngredient.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
						strPurpose =strPurpose.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
						//SPEC: <29.07.2022>: Guna Added for 42006 Defect  Dev 22x   -- END
						
						//SPEC: <21.05.2021>: Guna Modified for 43112 Defect  Dev 18x.6.0.1   -- END
						util.formatData(sbIngredient, strIngredient);
						util.formatData(sbLayer, strLayer);
						util.formatData(sbPurpose, strPurpose);
						util.formatData(sbCAS, strCAS);
						util.formatData(sbChemical, strChemicalsofConcern);
						util.formatData(sbConsumer, strDescription);
						util.formatData(sbSeqNo, strSequenceNo);
					}
				}
				//SPEC: <29.03.2021>: Guna Modified for Defect 41000 Dev 18x.6   -- START
				if (strSubType.equals(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART) ) {
					//SPEC: <29.03.2021>: Guna Modified for Defect 41000 Dev 18x.6   -- END
					mpSmartLabelRow.put(ConstantsUtilIRM.LAYER, sbLayer.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.MATERIALSINGREDIENT, sbIngredient.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.CONSUMERFRIENDLYDESCRIPTION, sbConsumer.toString());
					mpSmartLabelRow.put(ConstantsUtil.FUNCTION, sbPurpose.toString());
					mpSmartLabelRow.put(ConstantsUtil.STR_SEQUENCE, sbSeqNo.toString());

				} else if (strSubType.equals(ConstantsUtil.TYPE_DEVICEPRODUCTPART)){
					mpSmartLabelRow.put(ConstantsUtil.MATERIALS, sbIngredient.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.CONSUMERFRIENDLYDESCRIPTION, sbConsumer.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.FUNCTIONPURPOSE, sbPurpose.toString());
					mpSmartLabelRow.put(ConstantsUtil.STR_SEQUENCE, sbSeqNo.toString());
				} else if (strSubType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
					mpSmartLabelRow.put(ConstantsUtilIRM.INGREDIENT, sbIngredient.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.CONSUMERFRIENDLYDESCRIPTION, sbConsumer.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.PURPOSE, sbPurpose.toString());
					mpSmartLabelRow.put(ConstantsUtil.STR_SEQUENCE, sbSeqNo.toString());
				} else if (strSubType.equals(ConstantsUtilIRM.CACLEANING)) {
					mpSmartLabelRow.put(ConstantsUtilIRM.INGREDIENT, sbIngredient.toString());
					mpSmartLabelRow.put(ConstantsUtil.CAS, sbCAS.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.LISTOFCHEMICALS, sbChemical.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.CONSUMERFRIENDLYDESCRIPTION, sbConsumer.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.PURPOSE, sbPurpose.toString());
					mpSmartLabelRow.put(ConstantsUtil.STR_SEQUENCE, sbSeqNo.toString());
				} else if (genericTypeList.contains(strSubType)) {
					mpSmartLabelRow.put(ConstantsUtilIRM.FRAGRANCEINGREDIENT, sbIngredient.toString());
					mpSmartLabelRow.put(ConstantsUtil.CAS, sbCAS.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.LISTOFCHEMICALS, sbChemical.toString());
					mpSmartLabelRow.put(ConstantsUtilIRM.CONSUMERFRIENDLYDESCRIPTION, sbConsumer.toString());
					mpSmartLabelRow.put(ConstantsUtil.STR_SEQUENCE, sbSeqNo.toString());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return mpSmartLabelRow;
	}

}
