package com.pg.us.specanywhere_enovia.service;

import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaPriliminaryPayloadService {

	Map<String, String> getPriliminaryPayLoaddata(Environment env, String sObjectName);

}
