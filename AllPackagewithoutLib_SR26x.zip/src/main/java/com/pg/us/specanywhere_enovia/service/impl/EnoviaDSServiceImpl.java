/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaIMPServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.DSBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaDSService;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import matrix.db.Context;

public class EnoviaDSServiceImpl implements EnoviaDSService{

	private static Logger dsLOGGER = Logger.getLogger(EnoviaDSServiceImpl.class);
	
	private  HttpServletRequest request;
	@Autowired
	private EnoviaConnectionPool pool;
    @Autowired
    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

	@Override
	public HashMap<String, Map<String, String>> getDSData(Environment env, String strKey, String strObjId ) {		
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		dsLOGGER.info("DS SERVICE CONTEXT ELAPSED TIME : "+swContext.getTime());
		
		DSBO dsbo = new DSBO();
		try 
		{
			String strUserName = getName();
			
			/**
			 * User Profile Section
			 * */
			if(UIUtil.isNullOrEmpty(strKey)) {
				dsLOGGER.error("ERROR: INVALID Key FROM INTEGRATION SERVICE : "+strKey);
				HashMap<String,String> errorMap = new HashMap<>();
				String[] sError = ConstantsUtil.E102.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				context.close(); // Added for Defect 45181
				return hmAttrib;
			}
			/**
			 * LOAD DYNAMIC RESULTS SECTION
			 * */			
			if(strKey.equalsIgnoreCase(ConstantsUtilIRM.DYNLIST)) {
				StopWatch swDynList = new StopWatch();
				swDynList.start();
				Map<String,String> mDynList = dsbo.getUserSubscriptions(context, strUserName);
				swDynList.stop();
				dsLOGGER.info("DS SERVICE GET USER ELAPSED TIME : "+swDynList.getTime());
				hmAttrib.put(ConstantsUtilIRM.SUBSCRIPTIONRESULTS, mDynList);
			}
			/**
			 * LOAD DYNAMIC DETAILS SECTION
			 * */
			if(strKey.equalsIgnoreCase(ConstantsUtilIRM.DYNDETAIL)) {
				StopWatch swDynDetail = new StopWatch();
				swDynDetail.start();
				Map<String,String> mDynDetail = dsbo.getSubscriptionDetails (context, strObjId);				
				swDynDetail.stop();
				dsLOGGER.info("DS SERVICE GET OBJECT DETAILS ELAPSED TIME : "+swDynDetail.getTime());
				hmAttrib.put(ConstantsUtilIRM.SUBSCRIPTIONDETAILS, mDynDetail);
			}			
		}catch (Exception e) {
			dsLOGGER.error("Exception in DS Service IMPL: "+e);
			if(null!=context) {
				pool.checkIn(context);
			}
		}
		pool.checkIn(context);
		sp.stop();

		dsLOGGER.info("DS SERVICE GETINFO ELAPSED TIME : "+sp.getTime());
		//SPEC: <25-07-2022>: Manikanta Added for Defect 45181  -- START
		if(null != context){
			context.close();
		}
		//SPEC: <25-07-2022>: Manikanta Added for Defect 45181  -- END
		return hmAttrib;		
	}

	private String getName() {
		String strAccessToken = request.getHeader(ConstantsUtilIRM.ACCESSTOKEN);  
		String strName=ConstantsUtil.EMPTY_STRING;
		
		if(strAccessToken!=null) {
		DecodedJWT jwt = JWT.decode(strAccessToken);
		strName=jwt.getClaim(ConstantsUtilIRM.USERNAME).asString();
			}
		dsLOGGER.info("DS SERVICE Application Login User : "+strName);
		return strName;
		
	}	
}
