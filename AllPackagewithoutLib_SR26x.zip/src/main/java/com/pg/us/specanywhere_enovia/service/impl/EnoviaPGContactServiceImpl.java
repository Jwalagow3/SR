package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaPGContactService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class EnoviaPGContactServiceImpl implements EnoviaPGContactService{


	private static Logger LOGGER = Logger.getLogger(EnoviaPGContactServiceImpl.class);
	@Autowired
	private EnoviaConnectionPool pool;

	@Override
	public HashMap<String, Map<String, String>> getPersondata(Environment env, Map<String, String> mUserDetails)
			throws Exception 
	{
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();

		StopWatch swContext = new StopWatch();
		swContext.start();
		Context context = pool.checkOut();
		swContext.stop();
		LOGGER.info("PERSON PG Contact CONTEXT ELAPSED TIME : "+swContext.getTime());

		try {

			Map<String,String> mapUserDetails = new HashMap<String, String>();
			
			//Added by Ketan for Req no. 6581 -- START
			BusObjectAttribUtil util  = new BusObjectAttribUtil();
			Map<String,String> mpOrigUserInfo = new HashMap<String, String>();
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPersonName = validator.isNotNullOrEmpty((String)mUserDetails.get(ConstantsUtilIRM.USER_NAME))?(String)mUserDetails.get(ConstantsUtilIRM.USER_NAME) : ConstantsUtil.EMPTY_STRING;
			//Added by Ketan for Req no. 6581 -- END
			String sPersonId = PersonUtil.getPersonObjectID(context, strPersonName);
			StringBuilder sbPGContactEmail = new StringBuilder();

			Map<?, ?> mpUserInfo = new HashMap<>();

			String strFirstName = DomainConstants.EMPTY_STRING;
			String strLastName  = DomainConstants.EMPTY_STRING;
			String strEmailAddress = DomainConstants.EMPTY_STRING;

			StringList slPersonSelectables = new StringList(3);
			slPersonSelectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_FIRST_NAME);
			slPersonSelectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_LAST_NAME );
			slPersonSelectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_EMAIL_ADDRESS );

			String strPGContact = DomainConstants.EMPTY_STRING;
			String strCurrent = DomainConstants.EMPTY_STRING;

			StringList slPgCOntactSelectables = new StringList();
			slPgCOntactSelectables.add(DomainConstants.SELECT_NAME);
			slPgCOntactSelectables.add(DomainConstants.SELECT_CURRENT);

			DomainObject doPerson = DomainObject.newInstance(context, sPersonId);

			mpUserInfo = doPerson.getInfo(context,slPersonSelectables);

			strFirstName= (String)mpUserInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FIRST_NAME);
			strLastName= (String)mpUserInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_LAST_NAME);
			strEmailAddress= (String)mpUserInfo.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EMAIL_ADDRESS);

			MapList mlPersonList = doPerson.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_PGIPMPGCONTACT,  //pattern to match relationships
					ConstantsUtilIRM.TYPE_PERSON,               //pattern to match types
					slPgCOntactSelectables, 					//list of select statement pertaining to Business Objects
					null, 										//list of select statement pertaining to Rel Objects
					true, 										//get To relationships
					false, 										//get from relationships
					(short)1,									//short recurseToLev
					null, 										//objectWhereClause 
					null,										//relationshipWhereClause
					0);

			if(mlPersonList.size()>0){
				Iterator<?> userIterator =  mlPersonList.iterator();
				while(userIterator.hasNext()) {
					Map<?, ?> personMap = (Map<?, ?>)userIterator.next();
					strPGContact=(String)personMap.get(DomainConstants.SELECT_NAME);
					strCurrent=(String)personMap.get(DomainConstants.SELECT_CURRENT);
					matrix.db.Person pEachPerson = new matrix.db.Person(strPGContact);
					if(ConstantsUtilIRM.STATE_ACTIVE.equalsIgnoreCase(strCurrent) && (pEachPerson.isAssigned(context,ConstantsUtilIRM.ROLE_PGPGCONTACT))) {
						sbPGContactEmail.append(strPGContact.toString()).append(ConstantsUtilIRM.PGEMAIL).append(ConstantsUtil.SYMBL_PIPE);
					} 
				}
			}
			
			//Added by Ketan for Req no. 6581 -- START
			String sObjId = validator.isNotNullOrEmpty((String)mUserDetails.get(ConstantsUtilIRM.OBJECT_ID))?(String)mUserDetails.get(ConstantsUtilIRM.OBJECT_ID) : ConstantsUtil.EMPTY_STRING;
			String[] sObjIdArr = sObjId.split(ConstantsUtil.SYMBL_COMMA);
			StringBuilder sbOrigEmail	 =  new StringBuilder();
			StringList slMailId = new StringList();
			StringList slPersonsSelectables = new StringList(2);
			slPersonsSelectables.add(ConstantsUtilIRM.SELECT_ID );
			slPersonsSelectables.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_EMAIL_ADDRESS);
			
		      
			for(int i=0;i<sObjIdArr.length;i++) {
					DomainObject doObj = new DomainObject(sObjIdArr[i]);
					String strOriginator = doObj.getInfo(context, ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);
			
					StringBuilder sbWhere =new StringBuilder();
					sbWhere.append("(");
				    sbWhere.append(DomainConstants.SELECT_NAME);
				    sbWhere.append("==");
				      sbWhere.append(strOriginator);
				      sbWhere.append(" || "+ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTNUMBER+"=="+strOriginator+")");
					
					MapList mlDSMReportList = DomainObject.findObjects 
					   		 (context, //MatrixContext
							 ConstantsUtilIRM.TYPE_PERSON, //typePattern
							 ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
							 sbWhere.toString(), //whereExpression
							 slPersonsSelectables); //objectSelects
					
					Iterator itr = mlDSMReportList.iterator();
					String strEmailId = ConstantsUtil.EMPTY_STRING;
					while(itr.hasNext()) {
						Map mDSMReport = (Map) itr.next();
						
						strEmailId = (String) mDSMReport.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_EMAIL_ADDRESS);
					}
					//modified for defect no.8237 by Ajay
					if(!slMailId.contains(strEmailId) && UIUtil.isNotNullAndNotEmpty(strEmailId)){
						util.formatData(sbOrigEmail, strEmailId);
					}
					slMailId.add(strEmailId);
				}
			
			
			
			//Added by Ketan for Req. no. 6581 -- END
			
			mapUserDetails.put(ConstantsUtilIRM.STR_FIRSTNAME, strFirstName);
			mapUserDetails.put(ConstantsUtilIRM.STR_LASTNAME, strLastName);
			mapUserDetails.put(ConstantsUtilIRM.STR_EMAILADDRESS, strEmailAddress);
			mapUserDetails.put(ConstantsUtilIRM.STR_PGCONTACTEMAIL, sbPGContactEmail.toString());
			mapUserDetails.put(ConstantsUtilIRM.STR_ORIGEMAILADDRESS, sbOrigEmail.toString()); //Added by Ketan for Req no. 6581 
			
			hmAttrib.put(ConstantsUtilIRM.STR_USRINFORMATION, mapUserDetails);
			
			pool.checkIn(context);
			sp.stop();
			LOGGER.info("PERSON PG Contact MESSAGE ELAPSED TIME:: "+sp.getTime());
			LOGGER.info("PERSON PG Contact RESPONSE MESSAGE:: \n" + hmAttrib);

		}catch (Exception e) {
			LOGGER.error("Exception in PERSON PG Contact Service IMPL: "+e);
		}
		context.close();
		return hmAttrib;
	}

	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
}
