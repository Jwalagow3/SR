/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaSearchServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.util.FrameworkException;
import com.pg.us.specanywhere_enovia.bo.SearchBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.service.EnoviaSearchService;
import com.pg.us.specanywhere_enovia.utility.BusSearchUtil;
import com.pg.us.specanywhere_enovia.utility.EncryptCrypto;

import matrix.db.Context;

public class EnoviaSearchServiceImpl implements EnoviaSearchService {

	private static String USER;
	private static String PASS;
	private static String VAULT;
	private static Logger LOGGER = Logger.getLogger(EnoviaSearchServiceImpl.class);
	public List<SearchBO> getSearchResult(String strName, Environment env) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();
		EncryptCrypto encrpto = new EncryptCrypto();
		USER = env.getProperty("enovia.user.id");
		PASS = env.getProperty("enovia.user.pwd");
		VAULT = env.getProperty("enovia.user.vault");
		PASS = encrpto.decryptString(PASS);
		EnoviaConnectionPool pool = new EnoviaConnectionPool(USER, PASS, VAULT);
		Context context = pool.checkOut();
		List<SearchBO> lSearchResult = new ArrayList<>();
		BusSearchUtil searchUtil = new BusSearchUtil();
		try {
			lSearchResult = searchUtil.search(context, strName);
			
		} catch (FrameworkException e) {
			LOGGER.error("Exception in Search Service: "+e);
		}finally {
			pool.checkIn(context);
		}
		sp.stop();
		context.close();//Added for Defect 45181
		return lSearchResult;
	}

}
