package com.pg.us.specanywhere_enovia.service.impl;

import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPCategoriesService;
import com.pg.us.specanywhere_enovia.service.EnoviaFPPService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;



public class EnoviaFPPCategoriesServiceImpl implements EnoviaFPPCategoriesService{
	private static Logger LOGGER = Logger.getLogger(EnoviaFPPServiceImpl.class);
	@Value("${ldap.user}")
	private String ldapuser ;

	@Value("${ldap.pwd}")
	private String ldappwd ;
	
	@Autowired
    private HttpServletRequest request;

	@Autowired
	private EnoviaConnectionPool pool;
	@Override
	public HashMap<String, Map<String,String>> getFPPCategoriesdata(String objId, String sComp, Environment env) throws Exception {
		
		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		Context context = null;
		
		try {
			
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			ContextUtil.startTransaction(context, true);
			swContext.stop();
			LOGGER.info("FPP CONTEXT ELAPSED TIME : "+swContext.getTime());
			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			
			 
			if (UIUtil.isNotNullAndNotEmpty(sUserType))
			{
			 
				if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
					sUserType = BObjutil.getUserView(context, objId);
				}
			 
			}
			 
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				 
				context.close();
				 
				return hmAttrib;
			}

			 
			boolean bAllInfoView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bManufacturerView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					}

				}
			
			 
			
			 
			FinishedProductPartBO fppBO = new FinishedProductPartBO();	
			DomainObject doFPP = new DomainObject(objId);
			String sState = doFPP.getInfo(context, DomainConstants.SELECT_CURRENT);
			 
			//SPEC: Modified by Ajay for Req. no. 78405 START	
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (sState.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR IN FPP: "+hmAttrib);
					 
					context.close();
					 
					return hmAttrib;
				
				}
				 
				else if(!sState.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(sState.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					 
					context.close();
					 
					return hmAttrib;
				}
				 
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}
			//SPEC: Modified by Ajay for Req. no. 78405 END
			
			BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
			Map BusinessObjectSelectableMap = fppBO.getFinishedProductPartSelectableMap(context);
			StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			slSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slSelects.add(ConstantsUtil.ATL_STATE);
			Map<String,String> mapAttribResult = new HashMap<String,String>();
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mapBomResult = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			
			Map resultMap = doFPP.getInfo(context, slSelects,fppBO.addMultiList());
			
			
			 
			String sType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
			String sID = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

			/**
			 * LOAD Main BOM SECTION
			 * */
			StopWatch swBom = new StopWatch();
			swBom.start();
			//SPEC: <31.05.2022>: Guna Modified for Req 41754 22x Release  -- START
			MapList mlEBOMList = busUtil.getExpandedBOM(context, doFPP, ConstantsUtil.RELATIONSHIP_EBOM, 
					ConstantsUtil.TYPE_PGPHASE, fppBO.getBomBusSelect(context), fppBO.getBomRelSelect(context), ConstantsUtil.SELECT_NAME+"=~~PCT*", "PCT");
			//SPEC: <31.05.2022>: Guna Modified for Req 41754 22x Release  -- END
			swBom.stop();
			LOGGER.info("FPP BOM ELAPSED TIME : "+swBom.getTime());
			
			//Main BOM Section
			if(mlEBOMList.size()!=0){
				//SPEC: <02.10.2021>: Modified for Defect #39277 by Sumit  --START
				mapBomResult =	fppBO.parsePGPhaseBOMMaplist(context,mlEBOMList, resultMap);
				//SPEC: <02.10.2021>: Modified for Defect #39277 by Sumit  --ENDS
			
			}
			
			
			/**
			 * LOAD HEADER SECTION
			 * */
			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)))?busUtil.mapType((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)) : ConstantsUtil.EMPTY_STRING);		
			 
			mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING);
			
			 
			mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty(validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE))))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			 
			
			mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			
			 
			mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty(validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE))))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			 
			
			String sClassification = busUtil.getClassification(resultMap);
			mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, (sClassification));
			 
			mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
			mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
			String masterId = validator
					.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtil.SELECT_MASTERPARTID));
			if (UIUtil.isNotNullAndNotEmpty(masterId)) {
				DomainObject obj = new DomainObject(masterId);
				String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
				 
				obj.close(context);
				 
				if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
					masterId = ConstantsUtil.NO_ACCESS;
				}
				boolean showData = busUtil.checkHasAccess(context, sUserType, masterId);
				if (!showData) {
					masterId = ConstantsUtil.NO_ACCESS;
				}
			}
			mpHeaderResult.put(ConstantsUtil.MASTERPARTID, masterId);
			 
			
			 
			String pgSapType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
			if(sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT) && pgSapType.equalsIgnoreCase("HALB")) 
			{
				mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtilIRM.SELECT_MASTERPARTNAME_FP_HALB))));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtilIRM.SELECT_MASTERPARTTYPE_FP_HALB))));
				
				String mastersId = validator
						.getStringEquivalentForStringList((String)resultMap.get(ConstantsUtilIRM.SELECT_MASTERPARTID_FP_HALB));
				
				if (UIUtil.isNotNullAndNotEmpty(mastersId)) {
					DomainObject object = new DomainObject(mastersId);
					String mastersState = object.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					if (!mastersState.equals(ConstantsUtil.RELEASE) && !mastersState.equals(ConstantsUtil.RELEASED)) {
						mastersId = ConstantsUtil.NO_ACCESS;
					}
					boolean showData = busUtil.checkHasAccess(context, sUserType, mastersId);
					if (!showData) {
						mastersId = ConstantsUtil.NO_ACCESS;
					}
				}
				mpHeaderResult.put(ConstantsUtil.MASTERPARTID, mastersId);
			}
			/**
			 * Get the LifeCycle Section
			 * 
			 */
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			//if(bAllInfoView){
			
				//SPEC: <10.09.2020>: Modified for req 18x.5 ## -- START
				mpLifeCycleApproval = busUtil.getCOName(context, changeargs);
				//mpLifeCycleApproval = fppBO.getCOName(context, changeargs);
				//SPEC: <10.09.2020>: Modified for req 18x.5 ## -- START
				
			//}
			swLifecycle.stop();
			LOGGER.info("FPP LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
			if(bAllInfoView) {
				/**
				 * LOAD OWNERSHIP SECTION
				 * */
				//SPEC: <08-11-2021>: Manikanta Modified in SR18x.6.0.2 for  Defect 45644  -- START
				//mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				String sOriginator = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ORIGINATOR))?(String)resultMap.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING;
				String strOriginatorName = busUtil.getUserName(context, sOriginator,ldapuser,ldappwd);
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, strOriginatorName);
				//SPEC: <08-11-2021>: Manikanta Modified in SR18x.6.0.2 for  Defect 45644  -- END
				//SPEC: <01.04.2022>: Guna Modified for 22x Dev  -- START
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.STRSEGMENT)))?(String)resultMap.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <01.04.2022>: Guna Modified for 22x Dev  -- END
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 24, 2021 for Defect 41565 --- END
				
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = busUtil.filterMapList(mapOwnerShipResult);
			}
			
			if(bAllInfoView || bManufacturerView){

				/**
				 * LOAD IP CLASSES SECTION
				 */
				//SPEC: <10.19.2020>: Added for req 18x.5 ## -- START
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIpSecuritySetting =fppBO.getIpClass(context, doFPP, slIpSelects);
			}
			/**
			 * LOAD ORGANIZATION DATA SECTION
			 * */
			//SPEC: <07-28-2021>: Sanjeeva Modified for Stress Testing Defect 44365  -- START
			//mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			//mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			if (resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) != null) {
			
				if (resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
					{
						mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
					} 
				else 
					{
						mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
					}
			}
			
			if (resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) != null) {
			
				if (resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME).getClass().getSimpleName().equalsIgnoreCase("StringList"))
				{
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty(validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)) : ConstantsUtil.EMPTY_STRING));
				} else 
				{
					mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				}
			}

			
				mpOrganization = busUtil.filterMapList(mpOrganization);
			
			/**
			 * LOAD BASIC ATTRIBUTES SECTION
			 * */
			mapAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID)))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
			 
			 
			mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : "Finished Product");
			 
			mapAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.TYPE, busUtil.mapType((validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			
			 
			String SAPtype = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
			 
			if(SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB) || bManufacturerView || bAllInfoView) {
				mapAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMap.get(ConstantsUtil.SELECT_OWNER)));
			}
			 
			
			mapAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMap.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMap.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			
			 
			mapAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.ORIGINATED)))?validator.DateFormatterParse((String)resultMap.get(ConstantsUtil.ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
			 
			
			mapAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			
			 
			if(SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB) || bManufacturerView || bAllInfoView) {
				mapAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
			}
			 
			
			mapAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
			
			mapAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			 
			mapAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
			 
			
			 
			if(!bManufacturerView) {
			mapAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
			}
			 
			String strBrand = busUtil.getBrandInformationValue(context,sID);
			
			if(strBrand.isEmpty()) {
				strBrand = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMap.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
			}
			mapAttribResult.put(ConstantsUtil.BRAND, strBrand);
			 
			mapAttribResult.put(ConstantsUtil.REPLACEDPRODUCTNAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGREPLACEDPRODUCTNAME)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGREPLACEDPRODUCTNAME) : ConstantsUtil.EMPTY_STRING);
			 
			mapAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
			
			 
			if(!SAPtype.equalsIgnoreCase("HALB")) {
				mapAttribResult.put(ConstantsUtil.CUSTOMIZATIONTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE) : ConstantsUtil.EMPTY_STRING);
			}
			 
			
			mapAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
			
			
			 
			if(!SAPtype.equalsIgnoreCase("HALB")) {
				mapAttribResult.put(ConstantsUtil.STATISTICALUNIT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_STATISTICALUNIT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_STATISTICALUNIT) : ConstantsUtil.EMPTY_STRING);
			}
			 
			
			mapAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.strPGPDTTOPGPLIREFUN)))?(String)resultMap.get(ConstantsUtil.strPGPDTTOPGPLIREFUN) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			 
			 
			if(bManufacturerView && SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB)){
					mapAttribResult.remove(ConstantsUtil.ORIGINATOR); 
			}
			 
			 
			String pgSAPType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING;
			 
			
			mapAttribResult.put(ConstantsUtil.PRODUCTFORM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REL_OWNINGPRODUCTLINE)))?(String)resultMap.get(ConstantsUtil.SELECT_REL_OWNINGPRODUCTLINE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.STRSEGMENT)))?(String)resultMap.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			 
			
			 
			if(sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT) && pgSAPType.equalsIgnoreCase("HALB")) {
				mapAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
			}
			 
			
			mapAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQ, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ) : ConstantsUtil.EMPTY_STRING);
			
			 
			if(!SAPtype.equalsIgnoreCase("HALB")) {
				mapAttribResult.put(ConstantsUtil.RETAILERPUBLICATIONREADY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RETAILERPUBLICATIONREADY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RETAILERPUBLICATIONREADY) : ConstantsUtil.EMPTY_STRING);
			}
			 
			
			mapAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
			
			 
			mapAttribResult.put(ConstantsUtil.PRIMARYPACKAGINGTYPE,validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.PRIMARY_PACKAGING_TYPE)));
			 
			
		 
			mapAttribResult.put(ConstantsUtil.SECONDARYPACKAGINGTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECONDARYPACKAGINGTYPE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
			mapAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
			if(SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB)) {
			mapAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
			}
			 
			
			 
			if(!SAPtype.equalsIgnoreCase(ConstantsUtilIRM.CONST_HALB)) {
				StringList supportDocIdtemp = validator.isNotNullOrEmpty((StringList)resultMap.get(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC_ID));		
				String supportDocId = fppBO.checkSupportDocAccess(context,supportDocIdtemp);
				
				mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDVALEXCP)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDVALEXCP) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTIONCOMMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDEXCPCMT)))?(String)resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGWNDEXCPCMT) : ConstantsUtil.EMPTY_STRING);
				mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTIONSUPPORTDOC, (validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC))));
				mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTIONSUPPORTDOCTYPE, (validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtilIRM.SELECT_PGWNDEXCPSUPPORTDOC_TYPE))));
				mapAttribResult.put(ConstantsUtilIRM.WDVALIDATIONEXCEPTIONSUPPORTDOCID, supportDocId);
				}
		
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mapAttribResult);
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			if(bManufacturerView) 
			{
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mapBomResult);
				//SPEC: <12.30.2020>: Commented for Req :36032 by Sumit #(BOM Expansion)# --START
				//hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
				//SPEC: <12.30.2020>: Commented for Req :36032 by Sumit #(BOM Expansion)# --ENDS
			}
			if(bAllInfoView) 
			{
				hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mapBomResult);
			}
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.OWNERSHIPOBJECT, mapOwnerShipResult);
			}
			if(!bManufacturerView){
				hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
				}
			if(!bManufacturerView){
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			pool.checkIn(context);
			sp.stop();
		}catch(Exception e) {
			LOGGER.error("Exception From FPP Service IMPL Class "+e);
		}finally {
			if(context!=null) {
				context.close();
			}
		}
		//SPEC: Modified by Ajay for Req. no. 78405 START
		if(sComp.equals(ConstantsUtilIRM.FPP)) {
			context.close();
		}
		return hmAttrib;
}
}
