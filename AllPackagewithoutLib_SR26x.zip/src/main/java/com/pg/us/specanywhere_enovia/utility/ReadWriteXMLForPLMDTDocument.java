/*
 * Added by APOLLO Team For CATIA Automation Web Services
 * 2018x.2 Change to read and write XML for Base and Variant information
 */

package com.pg.us.specanywhere_enovia.utility;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.xml.XMLConstants;
//import javax.ws.rs.Path;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.util.StringList;
import com.matrixone.apps.domain.util.StringUtil;


//@Path("/xmlReadWriteService")
public class ReadWriteXMLForPLMDTDocument {
	static StringValidatorUtil validator = new StringValidatorUtil();
	private static Logger LOGGER = Logger.getLogger(ReadWriteXMLForPLMDTDocument.class);

	/**
	 * Method to delete checkedout file
	 * @param strFileName
	 * @throws Exception
	 */
	private static boolean deleteFile(String strFileName) throws Exception{
		boolean bFlag = false;
		try {
			File file = new File(strFileName);	
			bFlag = file.delete();
		} catch (Exception e) {
			LOGGER.error("Exception in ReadWriteXMLForPLMDTDocument deleteFile: "+e);
		}
		return bFlag;
	}

	
	public static StringList getFileSelectables() {
		
		StringList slFileObjSelect = new StringList();
		   slFileObjSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		   slFileObjSelect.add(ConstantsUtil.STR_FILE_NAME);
		  
			return slFileObjSelect;
		}
	
	/**
	 * Method read Configuration parameters APP 2.1 Solution
	 * This method is called from Design Parameters table and Comparison report functionaity to get all Design Parameters in the XML from APP / VPMReference.
	 * @param context
	 * @param updateFileName
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static Map getConfigXMLParameters(matrix.db.Context context, String strObjectId, boolean bSkipInactive, boolean bSkipHidden,String container,String connectionString,String azureStore) throws Exception {
		Map XMLParameterMap = new HashMap();
		String strFileName = DomainConstants.EMPTY_STRING;		
		String strAPPObjectId = DomainConstants.EMPTY_STRING;
		String objectType = DomainConstants.EMPTY_STRING;
		StringBuffer updateFileName = new StringBuffer();
		StringList slSelects= new StringList();
		slSelects.add(DomainConstants.SELECT_CURRENT);
		slSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slSelects.add(ConstantsUtil.STR_FILE_NAME);
		
		String strFilePath = DomainConstants.EMPTY_STRING;
		try 
		{
			DomainObject domObject = DomainObject.newInstance( context, strObjectId);
			objectType = (String)domObject.getInfo(context, DomainConstants.SELECT_TYPE);
			if(ConstantsUtilIRM.TYPE_VPMREFERENCE.equalsIgnoreCase(objectType))
			{
				strAPPObjectId = fetchAPPObject(context, domObject);
			}
			else
			{
				strAPPObjectId = strObjectId;
			}
			if(UIUtil.isNotNullAndNotEmpty(strAPPObjectId))
			{
				StringBuffer sbFileNameDP = new StringBuffer();
				StringBuffer sbFilePath = new StringBuffer();
				sbFileNameDP.append(ConstantsUtilIRM.STR_AUTOMATION_DESIGN_PARAMETER_FILE_NAME).append(ConstantsUtilIRM.CONSTANT_STRING_UNDERSCORE).append((String)domObject.getInfo(context, DomainConstants.SELECT_NAME)).append(ConstantsUtilIRM.STR_XMLFILE_EXTENSION);
				String strFileNameDP = sbFileNameDP.toString();
				InputStream stream = null;
				Properties properties = new Properties();
				stream = ReadWriteXMLForPLMDTDocument.class.getClassLoader().getResourceAsStream("CATIAAPP.properties");
				properties.load(stream);
				String sWorkspacePath = properties.getProperty("AZURE_FILE_DOWNLOAD_PATH");
				domObject = DomainObject.newInstance( context, strAPPObjectId);
				Map mpFileList = domObject.getInfo(context, slSelects, getFileSelectables());
				if(mpFileList!=null && mpFileList.size()>0)
				{
					String sFileName = validator.getEquivalentStringComma(mpFileList.get(ConstantsUtil.STR_FILE_NAME));
					String sFilePath = validator.getEquivalentStringComma(mpFileList.get(ConstantsUtil.STR_FILE_CAPTURED));
					StringList slFileList = StringUtil.split(sFileName, ConstantsUtil.SYMBL_COMMA) ;
					StringList slFilePath = StringUtil.split(sFilePath, ConstantsUtil.SYMBL_COMMA) ;
					//domObject.checkoutFiles(context, false, "generic", files, sWorkspacePath);
					MapList mlFileList = new MapList();
					Map<String, String> mpFile = new HashMap<>();
					int x =0;
					for (int i = 0; i < slFileList.size(); i++) {
						if(strFileNameDP.equals((String)slFileList.get(x))) {
							mpFile.put(ConstantsUtil.STR_FILE_NAME, (String)slFileList.get(x));
							mpFile.put(ConstantsUtil.STR_FILE_CAPTURED, (String)slFilePath.get(x));
							mlFileList.add(mpFile);
						}
				    	x++;
					}
					for (int j = 0; j < mlFileList.size(); j++)
					{
						Map objectMaps = (Map) mlFileList.get(j);
						strFileName = (String)objectMaps.get(ConstantsUtil.STR_FILE_NAME);
						strFilePath = (String)objectMaps.get(ConstantsUtil.STR_FILE_CAPTURED);
						if(UIUtil.isNotNullAndNotEmpty(strFileName) && strFileName.equals(strFileNameDP))
						{
							//domObject.checkoutFile(context, false, pgApolloConstants.FORMAT_NOT_RENDERABLE, strFileName, sWorkspacePath);
							sbFilePath = sbFilePath.append(azureStore).append(strFilePath);
							strFilePath	= sbFilePath.toString();
							AzureService azureService = new AzureService();
							azureService.ResponseEntity(strFilePath,strFileName,container,connectionString);
							updateFileName.append(sWorkspacePath).append(File.separator).append(strFileName);
							XMLParameterMap = getConfigXMLParametersMap(context, updateFileName.toString(), bSkipInactive, bSkipHidden);
							deleteFile(updateFileName.toString());
							break;
						}
					}			
				}
				//Subhajit Added for defect 45181 - Start
				stream.close();
				//Subhajit Added for defect 45181 - End
			}
		} catch (Exception e) {
			LOGGER.error("Exception in ReadWriteXMLForPLMDTDocument getConfigXMLParameters: "+e);
		}		
		return XMLParameterMap;
	}

	/**
	 * Method read Configuration parameters APP based on File Name 2.1 Solution
	 * @param context
	 * @param updateFileName
	 * @return
	 * @throws Exception
	 */
	public static Map getConfigXMLParametersMap(matrix.db.Context context, String updateFileName, boolean bSkipInActive, boolean bSkipHidden) throws Exception
	{
		Map XMLParameterMap = new HashMap();
		File file = new File(updateFileName);
		XPath xPath;
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc;

		try 
		{
			dbFactory = DocumentBuilderFactory.newInstance();
			dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
			dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
			dBuilder = dbFactory.newDocumentBuilder();

			doc = dBuilder.parse(file);
			doc.getDocumentElement().normalize();

			xPath = XPathFactory.newInstance().newXPath();
		} catch (Exception e) {
			LOGGER.error("Exception in ReadWriteXMLForPLMDTDocument getConfigXMLParameters: "+e);
			throw e;
		}
		StringBuffer sbXPath = new StringBuffer();
		sbXPath.append(ConstantsUtilIRM.STR_ROOT).append(ConstantsUtilIRM.CONSTANT_STRING_XMLPATH_SEPARATOR).append(ConstantsUtilIRM.STR_PRODUCT_DEFINITION);
		String strXPath = sbXPath.toString();
		
		try {
			Map parameterMap = new HashMap();
			NodeList nodeList = (NodeList) xPath.compile(strXPath).evaluate(doc, XPathConstants.NODESET);
			int nodeLength = nodeList.getLength();
			if(nodeLength>0)
			{
				Node nNode = nodeList.item(0);
				parameterMap = new HashMap();
				parameterMap = getParameterMap(xPath, doc, nNode, bSkipInActive, bSkipHidden);
				XMLParameterMap.put(ConstantsUtilIRM.STR_PRODUCT_DEFINITION, parameterMap);
				
				sbXPath = new StringBuffer();
				sbXPath.append(ConstantsUtilIRM.STR_ROOT).append(ConstantsUtilIRM.CONSTANT_STRING_XMLPATH_SEPARATOR).append(ConstantsUtilIRM.STR_VARIANTS);
				strXPath = sbXPath.toString();
				
				nodeList = (NodeList) xPath.compile(strXPath).evaluate(doc, XPathConstants.NODESET);
				nodeLength = nodeList.getLength();
				if(nodeLength>0)
				{
					nNode = nodeList.item(0);
					parameterMap = new HashMap();
					parameterMap = getParameterMap(xPath, doc, nNode, bSkipInActive, bSkipHidden);
					XMLParameterMap.put(ConstantsUtilIRM.STR_VARIANTS, parameterMap);
				}
				sbXPath = new StringBuffer();
				sbXPath.append(ConstantsUtilIRM.STR_ROOT).append(ConstantsUtilIRM.CONSTANT_STRING_XMLPATH_SEPARATOR).append(ConstantsUtilIRM.STR_PERFORMANCE_CHAR);
				strXPath = sbXPath.toString();
				
				nodeList = (NodeList) xPath.compile(strXPath).evaluate(doc, XPathConstants.NODESET);
				nodeLength = nodeList.getLength();
				if(nodeLength>0)
				{
					nNode = nodeList.item(0);
					parameterMap = new HashMap();parameterMap = getParameterMap(xPath, doc, nNode, bSkipInActive, bSkipHidden);
					XMLParameterMap.put(ConstantsUtilIRM.STR_PERFORMANCE_CHAR, parameterMap);
				}
				
				sbXPath = new StringBuffer();
				sbXPath.append(ConstantsUtilIRM.STR_ROOT).append(ConstantsUtilIRM.CONSTANT_STRING_XMLPATH_SEPARATOR).append(ConstantsUtilIRM.STR_VARIANTS_PERFORMANCE_CHAR);
				strXPath = sbXPath.toString();
				
				nodeList = (NodeList) xPath.compile(strXPath).evaluate(doc, XPathConstants.NODESET);
				nodeLength = nodeList.getLength();
				if(nodeLength>0)
				{
					nNode = nodeList.item(0);
					parameterMap = new HashMap();
					parameterMap = getParameterMap(xPath, doc, nNode, bSkipInActive, bSkipHidden);
					XMLParameterMap.put(ConstantsUtilIRM.STR_VARIANTS_PERFORMANCE_CHAR, parameterMap);
				}
				
			}
		} catch (Exception e) {
			LOGGER.error("Exception in ReadWriteXMLForPLMDTDocument getConfigXMLParametersMap: "+e);
		}		
		return XMLParameterMap;
	}

	/**
	 * Method to fetch APP Object Id connected to VPMReference 2.1 Solution
	 * @param context
	 * @param domVPMReference
	 * @return
	 * @throws Exception
	 */
	public static String fetchAPPObject(matrix.db.Context context, DomainObject domVPMReference) throws Exception 
	{		
		StringList objectSelects = new StringList();
		objectSelects.add(DomainConstants.SELECT_ID);		
		String strAPPObjectId = DomainConstants.EMPTY_STRING;		
		try 
		{
			//Get APP associated with VPMReference
			MapList mlRelatedAPP = domVPMReference.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_PART_SPECIFICATION,
					ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART,
					objectSelects,//Object Select
					null,//rel Select
					true,//get To
					false,//get From
					(short)1,//recurse level
					null,//where Clause
					null,
					0);	
			if(null != mlRelatedAPP && !mlRelatedAPP.isEmpty()) 
			{
				Map mpRelatedAPP = (Map)mlRelatedAPP.get(0);
				strAPPObjectId = (String)mpRelatedAPP.get(DomainConstants.SELECT_ID);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in ReadWriteXMLForPLMDTDocument fetchAPPObject: "+e);
		}
		return strAPPObjectId;
	}
	
	/**
	 * Method to return Parameter Map for specified node used in 2.1 Solution
	 * @param xPath
	 * @param doc
	 * @param configurationNode
	 * @return
	 */
	private static Map getParameterMap(XPath xPath, Document doc, Node ParentNode, boolean bSkipInActive, boolean bSkipHidden) {
		Map parameterMap = new HashMap();
		try {
			NodeList parameterNodeList;
			String strValue = DomainConstants.EMPTY_STRING;
			String strIsActiveValue = DomainConstants.EMPTY_STRING;
			StringBuffer sbParameter = new StringBuffer();
			String strIsActiveParameterKey = DomainConstants.EMPTY_STRING;
			sbParameter.append(ConstantsUtil.SYMBL_DOT).append(ConstantsUtilIRM.KEY_ISACTIVE);
			strIsActiveParameterKey = sbParameter.toString();
			String strIsHiddenValue = DomainConstants.EMPTY_STRING;
			sbParameter = new StringBuffer();
			String strIsHiddenParameterKey = DomainConstants.EMPTY_STRING;
			sbParameter.append(ConstantsUtil.SYMBL_DOT).append(ConstantsUtilIRM.KEY_HIDDEN);
			strIsHiddenParameterKey = sbParameter.toString();
			Node nNode;
			String parameterName = DomainConstants.EMPTY_STRING;
			parameterNodeList = ParentNode.getChildNodes();
			int length = parameterNodeList.getLength();
			if(length>0)
			{
				for (int n = 0; n < length; n++) {	
					nNode = parameterNodeList.item(n);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {	
						parameterName = nNode.getNodeName();
						Element eElement = (Element) nNode;
						if(bSkipInActive)
						{
							if(eElement.hasAttribute(ConstantsUtilIRM.KEY_ISACTIVE))
							{
								strIsActiveValue = eElement.getAttribute(ConstantsUtilIRM.KEY_ISACTIVE);
								if(ConstantsUtil.FALSE.equalsIgnoreCase(strIsActiveValue))
								{
									continue;
								}
							}						 
							if(null!=parameterName && parameterName.endsWith(strIsActiveParameterKey))
							{
								continue;
							}
						}
						if(bSkipHidden)
						{
							if(eElement.hasAttribute(ConstantsUtilIRM.KEY_HIDDEN))
							{
								strIsHiddenValue = eElement.getAttribute(ConstantsUtilIRM.KEY_HIDDEN);
								if(ConstantsUtil.TRUE.equalsIgnoreCase(strIsHiddenValue))
								{
									continue;
								}
							}						 
							if(null!=parameterName && parameterName.endsWith(strIsHiddenParameterKey))
							{
								continue;
							}
						}
						if(null!=parameterName)
						{
							parameterName = unescapeSpecialCharacterForDesignParameter(parameterName, true);
						}
						strValue = eElement.getAttribute("Value");
						strValue = unescapeSpecialCharacterForDesignParameter(strValue, false);
						parameterMap.put(parameterName, strValue);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception in ReadWriteXMLForPLMDTDocument getParameterMap: "+e);
		}		
		return parameterMap;
	}

	
	/**
	 * Method to unescape special character for Design Param
	 * @param strParamValue
	 * @return
	 */
	public static String unescapeSpecialCharacterForDesignParameter(String strParameter, boolean bIncludeParameterDecoding) 
	{
		if(UIUtil.isNotNullAndNotEmpty(strParameter))
		{
			if(bIncludeParameterDecoding)
			{
				strParameter = strParameter.replace(ConstantsUtilIRM.STR_SPACE_CHAR, ConstantsUtil.EMPTY_SPACE);	
			}
			strParameter = strParameter.replace(ConstantsUtilIRM.STR_TILDA_CHAR, ConstantsUtil.SYMBL_TILDA);	
			strParameter = StringEscapeUtils.unescapeXml(strParameter);
		}		
		return strParameter;
	}
	

}


