package com.pg.us.specanywhere_enovia.service;

import org.springframework.core.env.Environment;

public interface EnoviaGenDocloadService {

	String getGendocPayloaddata(Environment env, String sObjectName);

}
