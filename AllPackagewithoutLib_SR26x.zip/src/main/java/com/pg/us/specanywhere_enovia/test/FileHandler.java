package com.pg.us.specanywhere_enovia.test;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.Map;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;

import matrix.db.Context;
import matrix.util.StringList;

public class FileHandler {

	public static void main(String[] args) throws Exception
	{
		EnoviaConnectionPool pool = new EnoviaConnectionPool();
	    Context context = pool.checkOut();
		
	  /*  BufferedInputStream in = null;
	    FileOutputStream fout = null;*/
	    
		try
		{
			DomainObject document = DomainObject.newInstance(context, "20336.41905.8319.30910");
			
			String strWorkSpace = context.createWorkspace();
			String strFileName = DomainConstants.EMPTY_STRING;
			File fWorkspace = new File(strWorkSpace + File.separator + System.currentTimeMillis());
			fWorkspace.mkdirs();
			System.out.println("fWorkspace======================="+fWorkspace);
			
			DomainConstants.MULTI_VALUE_LIST.add("format.file.capturedfile");
			DomainConstants.MULTI_VALUE_LIST.add("format.file.name");
			
			StringList slBusSelcts = new StringList();
			slBusSelcts.add("format.file.capturedfile");
			slBusSelcts.add("format.file.name");
			
			Map mpInfo =document.getInfo(context, slBusSelcts);
			
			DomainConstants.MULTI_VALUE_LIST.remove("format.file.capturedfile");
			DomainConstants.MULTI_VALUE_LIST.remove("format.file.name");
			
			StringList slFileLoc =(StringList)mpInfo.get("format.file.capturedfile");
			StringList slFileName =(StringList)mpInfo.get("format.file.name");
			for (int i = 0; i < slFileName.size(); i++)
			{
				String sFName=slFileName.get(i);
				String sFNloc=slFileLoc.get(i);
				System.out.println("sFName=======76================="+sFName);
				System.out.println("sFNloc=======76================="+"file:/F:/Delivery/FCSFiles/"+sFNloc);
				//in = new BufferedInputStream(new URL("file:/F:/Chandra/PDF/TEST4.pdf").openStream());
				//in = new BufferedInputStream(new URL("file:/F:/Delivery/FCSFiles/"+sFNloc).openStream());
			//	fout = new FileOutputStream(fWorkspace.toString()+"//"+sFName);
			
			
			/* BufferedWriter out1 = new BufferedWriter(new FileWriter("srcfile"));
		      out1.write("string to be copied\n");
		      out1.close();*/
		      InputStream in = new FileInputStream(new File("F:/Delivery/FCSFiles/"+sFNloc));
		      OutputStream out = new FileOutputStream(new File(fWorkspace.toString()+"/"+sFName));
		      byte[] buf = new byte[1024];
		      int len;
		      
		      while ((len = in.read(buf)) > 0) {
		         out.write(buf, 0, len);
		      }
		      in.close();
		      out.close();
		      
			}
			/*MapList mpAllFiles = document.getAllFormatFiles(context);
			StringList slFiles = new StringList();
			FileList files = new FileList();
			if (mpAllFiles != null && !mpAllFiles.isEmpty())
			{
				DomainConstants.MULTI_VALUE_LIST.add("format.file.capturedfile");
				DomainConstants.MULTI_VALUE_LIST.add("format.file.name");
				
				StringList slBusSelcts = new StringList();
				slBusSelcts.add("format.file.capturedfile");
				slBusSelcts.add("format.file.name");
				
				Map mpInfo =document.getInfo(context, slBusSelcts);
				
				DomainConstants.MULTI_VALUE_LIST.remove("format.file.capturedfile");
				DomainConstants.MULTI_VALUE_LIST.remove("format.file.name");
				
				StringList slFileLoc =(StringList)mpInfo.get("format.file.capturedfile");
				StringList slFileName =(StringList)mpInfo.get("format.file.name");
				for (int i = 0; i < slFileName.size(); i++)
				{
					String sFName=slFileName.get(i);
					String sFNloc=slFileLoc.get(i);
					//System.out.println("sFName=======76================="+sFName);
					//System.out.println("sFNloc=======76================="+"file:/F:/Delivery/FCSFiles/"+sFNloc);
					//in = new BufferedInputStream(new URL("file:/F:/Chandra/PDF/TEST4.pdf").openStream());
					in = new BufferedInputStream(new URL("file:/F:/Delivery/FCSFiles/"+sFNloc).openStream());
					fout = new FileOutputStream(fWorkspace.toString()+"//"+sFName);
					
					byte data[] = new byte[1024];
					int count;
					while ((count = in.read(data, 0, 1024)) != -1) 
					{
						System.out.println("count=======76================="+count);
						
						fout.write(data, 0, count);
					}
					
					
					byte[] buf = new byte[1024];
				      int len;
				      
				      while ((len = in.read(buf)) > 0) {
				         out.write(buf, 0, len);
				      }
				      in.close();
				      out.close();
				      BufferedReader in1 = new BufferedReader(new FileReader("destnfile"));
				      String str;
				      
				      while ((str = in1.readLine()) != null) {
				         System.out.println(str);
				      }
				      in.close();
					
					
				}
				
			//}
			*/
			//return fWorkspace+"/"+strFileName;
		}catch(Exception e){
			
			e.printStackTrace();
		}
		
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
	}
			
			
}	    
		
			

	


