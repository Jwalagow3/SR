package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaSEPService {
	public HashMap<String, Map<String, String>> getSEPdata(String objId, Environment env) throws Exception;
}
