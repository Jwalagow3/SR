package com.pg.us.specanywhere_enovia.security;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.SpringSecurityCoreVersion;



public class CustomAuthority implements GrantedAuthority {
	

	private static final long serialVersionUID = SpringSecurityCoreVersion.SERIAL_VERSION_UID;

	private  String role;
	Map<String, Object> map; 
	public Map<String, Object> getMap() {
		return map;
	}

	public void setMap(Map<String, Object> map) {
		this.map = map;
	}

	public CustomAuthority() {
		
		super();
	
		// TODO Auto-generated constructor stub
	}
	
	  public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	
	  public CustomAuthority(String role) {
	
	  this.role = role; 
	  //setRole(this.role);
	  }
	 
	 

	public String getAuthority() {
		return role;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj instanceof CustomAuthority) {
			return role.equals(((CustomAuthority) obj).role);
		}

		return false;
	}

	public int hashCode() {
		return this.role.hashCode();
	}

	public String toString() {
		return this.role;
	}

}
