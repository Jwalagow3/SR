package com.pg.us.specanywhere_enovia.cp;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import matrix.db.Context;

@Component
public class EnoviaConnectionPool extends ObjectPool<Context> {

	private static Logger LOGGER = Logger.getLogger(EnoviaConnectionPool.class);
	@Value("user")
	private String user ;
	@Value("pass")
	private String pass ;
	@Value("vault")
	private String vault ;
	//@Autowired
	private EnoviaContext ev;

	
	public EnoviaConnectionPool() throws Exception{
		System.out.println("EnoviaConnectionPool - constructor");
	}
	
	public EnoviaConnectionPool( String USER, String PASS, String VAULT) {
		
		this.user = USER;
		this.pass = PASS;
		this.vault = VAULT;
		try {
			ev = new EnoviaContext(user, pass, vault);
		} catch (Exception me) {
			LOGGER.info("EXCEPTION IN EnoviaConnectionPool : "+me);
			me.printStackTrace();
		}
		
	}

	
	@Override
	public Context create() {
		try {
			System.out.println("CREATE POOL");
			Context context = ev.getEnoviaContextThread();
			return (context);
		} catch (Exception e) {
			LOGGER.info("EXCEPTION IN EnoviaConnectionPool::create : "+e);
			e.printStackTrace();
			return (null);
		}
	}

	@Override
	public void expire(Context o) {
		try {
			System.out.println("EXPIRE CTXT POOL");
			o.close();
		} catch (Exception e) {
			LOGGER.info("EXCEPTION IN EnoviaConnectionPool::expire : "+e);
			e.printStackTrace();
		}
	}

	@Override
	public boolean validate(Context o) {
		try {
			System.out.println("VALIDATE CTXT POOL");
			return o.isConnected();
		} catch (Exception me) {
			LOGGER.info("EXCEPTION IN EnoviaConnectionPool::validate : "+me);
			me.printStackTrace();
			return (false);
		}
	}

}
