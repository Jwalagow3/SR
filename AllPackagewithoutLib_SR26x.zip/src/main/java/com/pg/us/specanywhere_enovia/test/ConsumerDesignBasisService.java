/*package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.ConsumerDesignBasisBO;
import com.pg.us.specanywhere_enovia.bo.RawMaterialPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class ConsumerDesignBasisService {
	
private static Logger LOGGER = Logger.getLogger(ConsumerDesignBasisService.class);
	
	
	public static void main(String[] args) throws Exception {
		
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		
		//String oid = "20336.41905.32896.51058";
		String oid = "20336.41905.56071.22588";
		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
	    Context context = pool.checkOut();
	    
	    
	    BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
			
	    Map<String,String> mpHeaderResult = new HashMap<String,String>();
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mpPlantResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String, String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mpPerformChar = new HashMap<String, String>();
		
				
		ConsumerDesignBasisBO cdb = new ConsumerDesignBasisBO();
		DomainObject doCDB= cdb.getCDBDO(context,oid);
		
		cdb.addMultiList();
		Map BusinessObjectSelectableMap = cdb.getConsumerDesignBasisSelectables(context);
		StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

		Map resultMaps = doCDB.getInfo(context, slSelects);
		
		cdb.removeMultiList();
		
		//Header Content
		StopWatch sHeader = new StopWatch();
		sHeader.start();
		mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
		mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
		mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
		sHeader.stop();
		LOGGER.info("CDB  Header ELAPSED TIME : "+sHeader.getTime());
		
		//Lifecycle
		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
		String[] changeargs={oid,sPhysicalId};
		StopWatch swLifecycle = new StopWatch();
		swLifecycle.start();
		mpLifeCycleApproval = util.getCOName(context, changeargs);
		swLifecycle.stop();
		LOGGER.info("CDB  LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
		
		//Attribute Data
		StopWatch swAttrib = new StopWatch();
		swAttrib.start();
		mpAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SAPDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
		
		mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.STATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.ISSTANDARDTEMPLATE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTEMPLATE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
		mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.OBSOLETEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RERELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.RERELEASEREASON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNARCHIVEREASON) : ConstantsUtil.EMPTY_STRING);
		mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
		swAttrib.stop();
		LOGGER.info("CDB GET Attribute ELAPSED TIME : "+swAttrib.getTime());
		
		//Organization Data
		StopWatch swOrganization = new StopWatch();
		swOrganization.start();
		mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
		mpOrganization = util.filterMapList(mpOrganization);
		swOrganization.stop();
		LOGGER.info("CDB Organization ELAPSED TIME : "+swOrganization.getTime());
		
		//Plant Data
		StopWatch swPlant = new StopWatch();
		swPlant.start();
		mpPlantResult = util.updatePlantInfo(resultMaps);
		swPlant.stop();
		LOGGER.info("CDB Plant ELAPSED TIME : "+swPlant.getTime());
		
		//Ownership
		StopWatch swOwnerShip = new StopWatch();
		swOwnerShip.start();
		mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.ORIGINATORID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.OWNINGSTANDARDOFFICE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE)))?(String)resultMaps.get(ConstantsUtil.OWNING_STANDARD_OFFICE) : ConstantsUtil.EMPTY_STRING);
		String	strAttrValue = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOCREATORS) : ConstantsUtil.EMPTY_STRING;
		if(UIUtil.isNotNullAndNotEmpty(strAttrValue)){
		strAttrValue = "";
		}
		mapOwnerShipResult.put(ConstantsUtil.COOWNERS, strAttrValue);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
		String sEDList =RawMaterialPartBO.getEDList(resultMaps);
		mapOwnerShipResult.put(ConstantsUtil.EDL, sEDList);
		mapOwnerShipResult.put(ConstantsUtil.ODL, util.replaceSpecialSymbols((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERDISTRIBUTIONLIST) : ConstantsUtil.EMPTY_STRING));
		mapOwnerShipResult.put(ConstantsUtil.SECTOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSECTOR) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.PHCATEGORY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHCATEGORY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPHCATEGORY) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.SUBSECTOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBSECTOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBSECTOR) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.GLOBALFORM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGLOBALFORM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGLOBALFORM) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.BRAND, util.replacePIPE((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPH_BRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPH_BRAND) : ConstantsUtil.EMPTY_STRING));		mapOwnerShipResult.put(ConstantsUtil.PRODUCTFORMDETAIL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORMDETAIL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTFORMDETAIL) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.SUBBRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBBRAND) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
		mapOwnerShipResult.put(ConstantsUtil.PHUI, util.replacePIPE((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNODEID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNODEID) : ConstantsUtil.EMPTY_STRING));
		mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
		swOwnerShip.stop();
		LOGGER.info("CDB  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());
		
		//Performance Specs
		String sRevision = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
		String sName = (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
		StopWatch swPerfChar = new StopWatch();
		swPerfChar.start();
		mpPerformChar = cdb.updatePerformSpecs(doCDB,context);
		swPerfChar.stop();
		LOGGER.info("CDB PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
		
		
		//Reference Docs
		StopWatch swReference= new StopWatch();
		swReference.start();
		mapReferenceDocs=cdb.updateRefDocs(resultMaps);
		swReference.stop();
		LOGGER.info("CDB  Reference ELAPSED TIME : "+swReference.getTime());
		
		
		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		
		sp.stop();
		LOGGER.info("CDB MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "CDB OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
		
		System.out.println("Result:: \n"+hmAttrib);
		
		
	}

}
*/