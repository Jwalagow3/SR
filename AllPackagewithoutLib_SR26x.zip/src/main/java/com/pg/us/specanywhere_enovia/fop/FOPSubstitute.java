package com.pg.us.specanywhere_enovia.fop;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.SAPBOMConstants;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.SelectList;
import matrix.util.StringList;

public class FOPSubstitute {

	
	private static Logger LOGGER = Logger.getLogger(FOPSubstitute.class);
	
	final String REL_PLAN_FOR=PropertyUtil.getSchemaProperty("relationship_PlannedFor");
	final String ATTR_PREF_NAME=PropertyUtil.getSchemaProperty("attribute_PreferredName");
	final String ATTR_TITLE=PropertyUtil.getSchemaProperty("attribute_Title");
	final String REL_MAN_EQUE=PropertyUtil.getSchemaProperty("relationship_ManufacturerEquivalent");
	final String POL_MAN_EQUE=PropertyUtil.getSchemaProperty("policy_ManufacturerEquivalent");
	final String REL_FORM_PROCESS=PropertyUtil.getSchemaProperty("relationship_FormulationProcess");
	final String TYPE_COSM_FORMULATION=PropertyUtil.getSchemaProperty("type_CosmeticFormulation");
	
	public Map getFopSubstitute(Context context ,MapList mlFopSub)
	{
		
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util =new BusObjectAttribUtil();
		Map mpProces = new TreeMap();
		
		String	subPartName =ConstantsUtil.EMPTY_STRING;
		String	subPartId   = ConstantsUtil.EMPTY_STRING;
		String	subPartType =ConstantsUtil.EMPTY_STRING;
		String    subPartRev =ConstantsUtil.EMPTY_STRING;
		String    subPartCHG =ConstantsUtil.EMPTY_STRING;
		String    subPartRMN =ConstantsUtil.EMPTY_STRING;
		String    subPartPhase =ConstantsUtil.EMPTY_STRING;
		String    subPartForPhase =ConstantsUtil.EMPTY_STRING;
		String    subPartMinValue =ConstantsUtil.EMPTY_STRING;
		String    subPartMaxValue =ConstantsUtil.EMPTY_STRING;
		String    subPartWET =ConstantsUtil.EMPTY_STRING;
		String    subPartTWW =ConstantsUtil.EMPTY_STRING;
		
		String    subPartWEM =ConstantsUtil.EMPTY_STRING;
		String    subPartWWM =ConstantsUtil.EMPTY_STRING;
		String    subPartWD =ConstantsUtil.EMPTY_STRING;
		
		String    subPartRF =ConstantsUtil.EMPTY_STRING;
		String    subPartCertifications =ConstantsUtil.EMPTY_STRING;
		
			//SPEC: 12/03/2020 Added by Chandra For The Defect# 37681 --START
		String    sInstructions =ConstantsUtil.EMPTY_STRING;
		String    sDesc =ConstantsUtil.EMPTY_STRING;
		
		//Added by Subhajit for Req 46464 - Start
		String    sRelRestriction =ConstantsUtil.EMPTY_STRING;
		String    sRelRestrictionComment =ConstantsUtil.EMPTY_STRING;
		//Added by Subhajit for Req 46464 - End
		
		//SPEC: <02.17.2021>: Sumit Modified for Defect :38997 ## --START
		String    subFPartWEM =ConstantsUtil.EMPTY_STRING;
		String    subFPartWWM =ConstantsUtil.EMPTY_STRING;
		//SPEC: <02.17.2021>: Sumit Modified for Defect :38997 ## --ENDS
		StringList slSelects = new StringList();
		slSelects.add(ConstantsUtil.STRING_TO_DESCRIPTION);
		slSelects.add(ConstantsUtil.STRING_TO_ATTRIBUTE_SUBSTITUTE_INSTRUCTIONS);
		//SPEC: 12/03/2020 Added by Chandra For The Defect# 37681 --END
		
		
		int k=0;
		try
		{
			Iterator objectListItr =mlFopSub.iterator();
			while(objectListItr.hasNext())
			{
				
				Map mpSubstitutes = new HashMap();
				
				
				StringBuilder sbPId = new StringBuilder();
				StringBuilder sbPType = new StringBuilder();
				StringBuilder sbPRev = new StringBuilder();
				StringBuilder sbPName = new StringBuilder();
				
				StringBuilder sbFName = new StringBuilder();
				StringBuilder sbFId = new StringBuilder();
				StringBuilder sbFType = new StringBuilder();
				StringBuilder sbFRev = new StringBuilder();
				
				StringBuilder sbChg = new StringBuilder();
				StringBuilder sbPRMN = new StringBuilder();
				StringBuilder sbFRMN = new StringBuilder();
				
				StringBuilder sbFPhase = new StringBuilder();
				StringBuilder sbPPhase = new StringBuilder();
				
				StringBuilder sbPMIN = new StringBuilder();
				StringBuilder sbPMAX = new StringBuilder();
				
				StringBuilder sbPWET = new StringBuilder();
				StringBuilder sbTWW = new StringBuilder();
				
				
				StringBuilder sbPWEM = new StringBuilder();
				StringBuilder sbPWWM = new StringBuilder();
				
				StringBuilder sbFWEM = new StringBuilder();
				StringBuilder sbFWWM = new StringBuilder();
				
				StringBuilder sbPWD = new StringBuilder();

				StringBuilder sbPRF = new StringBuilder();
				StringBuilder sbPF = new StringBuilder();
				
				StringBuilder sbCert = new StringBuilder();
				StringBuilder sbProcessNote = new StringBuilder();
				
				StringBuilder sbCMT= new StringBuilder();

				StringBuilder sbVUD = new StringBuilder();
				StringBuilder sbVED= new StringBuilder();
				
				StringBuilder sbPInst= new StringBuilder();
				StringBuilder sbFInst= new StringBuilder();
				StringBuilder sbPDesc = new StringBuilder();
				//Added by Subhajit for Req 46464 - Start
				StringBuilder sbPRelRestriction= new StringBuilder();
				StringBuilder sbPRelRestrictionComment= new StringBuilder();
				//Added by Subhajit for Req 46464 - End
				
				
				FormulaPartBO fopBO = new FormulaPartBO();
          		Map mSubFor = (Map)objectListItr.next();
          		
				String sSubForType  = (String)mSubFor.get(ConstantsUtil.SELECT_TYPE);
				String sSubForID  = (String)mSubFor.get(ConstantsUtil.SELECT_ID);
				
				Vector vcSFORDIFF =	getAttributeOnEBOMRel(context,FormulationAttribute.QUANTITY.getAttribute(context),mSubFor);
				Vector vcFN =	getAttributeOnEBOMRel(context,FormulationAttribute.FIND_NUMBER.getAttribute(context),mSubFor);
				String sComment =getCommentColumnValue(context, mSubFor);
				
				String targetPercentConsumed = (String) mSubFor.get("targetPercentConsumed");
				double percentConsumed = 0;
				if (UIUtil.isNotNullAndNotEmpty(targetPercentConsumed)) {
				    percentConsumed = Double.parseDouble(targetPercentConsumed);
				}
				
				if (sSubForType.equals(FormulationType.PARENT_SUB.getType(context)))
				{
					
					MapList SubInFBOM1 = (MapList)mSubFor.get("SubInFBOM");
					
				//SPEC: 12/03/2020 Added by Chandra For The Defect# 37681 --START
					String sRelId = (String) mSubFor.get(ConstantsUtil.SELECT_RELATIONSHIP_ID);
					
				
					String [] arrRelIds={sRelId};
					MapList mlDescInfo = new MapList();
					if (UIUtil.isNotNullAndNotEmpty(sRelId))
					{
						DomainRelationship domRel = new DomainRelationship(sRelId);
						mlDescInfo = domRel.getInfo(context, arrRelIds, slSelects);
						Map mpTemp =(Map)mlDescInfo.get(0);
						sDesc = (String) mpTemp.get(ConstantsUtil.STRING_TO_DESCRIPTION);
						sInstructions = (String) mpTemp.get(ConstantsUtil.STRING_TO_ATTRIBUTE_SUBSTITUTE_INSTRUCTIONS);
					}
					
					
					/*String sInstructions = (String) mSubFor.get("Instructions");
					String sDesc = (String) mSubFor.get("Desc");*/
					//SPEC: <02.17.2021>: Sumit Added for Defect :38456 ## --STARTS
					boolean bNotNew = false;
					int iCount = 0;
					//SPEC: <02.17.2021>: Sumit Added for Defect :38456 ## --ENDS
					//SPEC: <02.17.2021>: Sumit Modified for Defect :38997 ## --START
					subFPartWEM = (String) mSubFor.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET+"]");
					//Commented by Ketan for Req. no. 47948
					/*if(UIUtil.isNotNullAndNotEmpty(subFPartWEM)){
						subFPartWEM = util.getFormatedDecimalValue(subFPartWEM, FormulationSubstituteConstants.FORMAT_DECIMAL_SIX); 
					}*/
					
					//WWM
					subFPartWWM = (String) mSubFor.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET+"]");
					//Commented by Ketan for Req. no. 47948
					/*if(UIUtil.isNotNullAndNotEmpty(subFPartWWM)){
						subFPartWWM = util.getFormatedDecimalValue(subFPartWWM, FormulationSubstituteConstants.FORMAT_DECIMAL_SIX); 
					}*/
					//SPEC: <02.17.2021>: Sumit Modified for Defect :38997 ## --ENDS
					
					
					util.formatData(sbPInst,sInstructions);
					util.formatData(sbPDesc,sDesc ); 
					
					String	 strVUD = getValidDate(context,mSubFor, FormulationSubstituteConstants.ATTR_VALID_START_DATE);
					String	 strVED = getValidDate(context,mSubFor, FormulationSubstituteConstants.ATTR_VALID_UNTIL_DATE);
				
					
					
					//SPEC: 12/03/2020 Added by Chandra For The Defect# 37681 --END
					Iterator itrSubInEbom = SubInFBOM1.iterator();
					while(itrSubInEbom.hasNext())
					{
						//SPEC: <02.17.2021>: Sumit Added for Defect :38456 ## --STARTS
						iCount++;
						//SPEC: <02.17.2021>: Sumit Added for Defect :38456 ## --ENDS
						Map	mEBOMObjects = (Map)itrSubInEbom.next();
						subPartName = (String)mEBOMObjects.get(ConstantsUtil.SELECT_NAME);
						subPartId   = (String)mEBOMObjects.get(ConstantsUtil.SELECT_ID);
						subPartType   = util.mapType((String)mEBOMObjects.get(ConstantsUtil.SELECT_TYPE));
						subPartRev   = (String)mEBOMObjects.get(ConstantsUtil.SELECT_REVISION);
						subPartCHG   = (String)mEBOMObjects.get(FormulationSubstituteConstants.ATTR_PG_CHANGE);
						subPartMinValue =fopBO.getMinMaxColumnDataForDSO(context,mEBOMObjects,"Min");
						subPartMaxValue =fopBO.getMinMaxColumnDataForDSO(context,mEBOMObjects,"Max");
						
						DomainObject dob = new DomainObject(subPartId);
						//Added by Subhajit for Req 46464 - Subhajit
						StringList slRelRestrictionSelects = new StringList(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
						slRelRestrictionSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
						
						Map mRelRestriction = dob.getInfo(context, slRelRestrictionSelects);
						sRelRestriction = validator.isNotNullOrEmpty((String)mRelRestriction.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION))?(String)mRelRestriction.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING;
						sRelRestrictionComment = validator.isNotNullOrEmpty((String)mRelRestriction.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS))?(String)mRelRestriction.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING;
						//Added by Subhajit for Req 46464 - End
						subPartRF=fopBO.getReportedFunction(context,subPartId);
						subPartCertifications=fopBO.getCertification(context,subPartId);
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 08 March 2021 -- START
						//SPEC: 09/09/2021: Commented for 18x.6.0.2 Defect#44321 by Manikanta-- START
						/*if(UIUtil.isNotNullAndNotEmpty(subPartCertifications) && subPartCertifications.equalsIgnoreCase(ConstantsUtil.SYMBL_NO))
							subPartCertifications = ConstantsUtil.EMPTY_STRING;*/
						//SPEC: 09/09/2021: Commented for 18x.6.0.2 Defect#44321 by Manikanta-- END
						//SPEC: Release SR18x.6.0 - Added  by gaikwad.tg on Date 08 March 2021 -- END
  						if (UIUtil.isNullOrEmpty(subPartCHG))
						{
  							subPartCHG=""; 
						}
  						
  					//SPEC: 12/03/2020 Commented by Chandra For The Defect# 37681 --START
  						/*String	strVUD = getValidDate(context,mEBOMObjects, FormulationSubstituteConstants.ATTR_VALID_START_DATE);
  						String	strVED = getValidDate(context,mEBOMObjects, FormulationSubstituteConstants.ATTR_VALID_UNTIL_DATE);*/
  					//SPEC: 12/03/2020 Commented by Chandra For The Defect# 37681 --END
  							
						boolean 	showSubPartData= util.checkHasAccess(context, null, subPartId);
						
						if(!showSubPartData) {
							subPartId=ConstantsUtil.NO_ACCESS;;
							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- START
							subPartCHG=ConstantsUtil.NO_ACCESS;;
							//SPEC: 12/04/2020: Modified By Chandra  for Defect : 37591 -- END
							
						}
						
						String subPartProcessNote   = (String)mEBOMObjects.get("attribute[Processing Note].value");
						if (UIUtil.isNullOrEmpty(subPartProcessNote))
						{
							subPartProcessNote=""; 
						}
						
						
						if(FormulationType.FORMULATION_PART.getType(context).equals((String)mEBOMObjects.get(ConstantsUtil.SELECT_TYPE))){
							subPartRMN = (String)DomainObject.newInstance(context,(String)mEBOMObjects.get("id")).getInfo(context,"from["+REL_PLAN_FOR+"].to["+FormulationType.FORMULATION_PROCESS.getType(context)+"].from["+REL_FORM_PROCESS+"].to["+TYPE_COSM_FORMULATION+"].attribute["+ATTR_TITLE+"]");
						}
						else{
							if(POL_MAN_EQUE.equals((String)DomainObject.newInstance(context,(String)mEBOMObjects.get("id")).getInfo(context,ConstantsUtil.SELECT_POLICY))){
								
								subPartRMN = (String)DomainObject.newInstance(context,(String)mEBOMObjects.get("id")).getInfo(context,"to["+REL_MAN_EQUE+"].from["+FormulationType.RAWMATERIAL_PART.getType(context)+"].attribute["+ATTR_TITLE+"]");
								if(UIUtil.isNullOrEmpty(subPartRMN))
								{
									subPartRMN = (String)DomainObject.newInstance(context,(String)mEBOMObjects.get("id")).getInfo(context,"to["+REL_MAN_EQUE+"].from["+FormulationType.RAWMATERIAL_PART.getType(context)+"].attribute["+ATTR_PREF_NAME+"]");
								}
								
							}
							else{
								subPartRMN = (String)DomainObject.newInstance(context,(String)mEBOMObjects.get("id")).getInfo(context,"attribute["+ATTR_TITLE+"]");
								if(UIUtil.isNullOrEmpty(subPartRMN))
								{
									subPartRMN = (String)DomainObject.newInstance(context,(String)mEBOMObjects.get("id")).getInfo(context,"attribute["+ATTR_PREF_NAME+"]");
								}
							}
						}
						
						String subId 	= (String)mEBOMObjects.get("from.id");
						 String strCmd1  		= "print bus $1 select $2 dump $3";
  						 String phaseId     	= MqlUtil.mqlCommand(context,strCmd1,subId,"to.fromrel.from.name","|");
						
  						 StringList slPhaseList = FrameworkUtil.split(phaseId, "|");
  						 StringList slPhaseUniqueList = new StringList();
  						 Iterator itr 			= slPhaseList.iterator();
  						 String phasename 		= "";
  						 while(itr.hasNext())
  						 {
  							 String sPhaseId1 = (String)itr.next();					 
  							 if(!slPhaseUniqueList.contains(sPhaseId1))
  							 {
  								 phasename = sPhaseId1;						 
  							 }
  						 }
  						 
  						subPartPhase=phasename;
  						subPartForPhase   = (String)mEBOMObjects.get("phase");
  						
  						
  						
  						//Wet%(w/w)
  						
  						subPartWET = (String)mEBOMObjects.get("attribute[".concat(FormulationAttribute.QUANTITY.getAttribute(context)).concat("].inputvalue"));
  						//Commented by Ketan for Req. no. 47948
  						/*subPartWET = util.getFormatedDecimalValue(subPartWET, FormulationSubstituteConstants.FORMAT_DECIMAL_SIX); 
						if (percentConsumed > 0 && UIUtil.isNotNullAndNotEmpty(subPartWET)) {
							subPartWET = Double.toString(Double.parseDouble(subPartWET)*percentConsumed/100);
						}*/
  						
						//SPEC: 12/03/2020 Added by Chandra For The Defect# 37681 --START	
						subPartTWW =fopBO.getMinMaxColumnDataForDSO(context,mEBOMObjects,"TargetWeightWet");
						
  						
					/*	//TWW Attribute
  						if(mEBOMObjects.containsKey("attribute[attribute_TargetWeightWet].inputvalue"))
						{
  							subPartTWW = (String)mEBOMObjects.get("attribute[attribute_TargetWeightWet].inputvalue");
  							
						}else{
							subPartTWW = (String)mEBOMObjects.get("attribute[attribute_TargetWeightWet].value");
							
						}
  						
  						if (UIUtil.isNotNullAndNotEmpty(subPartTWW))
						{
  							subPartTWW = util.getFormatedDecimalValue(subPartTWW, FormulationSubstituteConstants.FORMAT_DECIMAL_SIX); 
						}else{
							subPartTWW="";
						}*/
  						//SPEC: 12/03/2020 Added by Chandra For The Defect# 37681 --END	
  						//WEM
  						subPartWEM = (String) mEBOMObjects.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET+"].inputvalue");	
  						//Commented by Ketan for Req. no. 47948
  						/*if(UIUtil.isNotNullAndNotEmpty(subPartWEM)){
							subPartWEM = util.getFormatedDecimalValue(subPartWEM, FormulationSubstituteConstants.FORMAT_DECIMAL_SIX); 
						}*/
						
						//WWM
						subPartWWM = (String) mEBOMObjects.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET+"].inputvalue");
						//Commented by Ketan for Req. no. 47948
						/*if(UIUtil.isNotNullAndNotEmpty(subPartWWM)){
							subPartWWM = util.getFormatedDecimalValue(subPartWWM, FormulationSubstituteConstants.FORMAT_DECIMAL_SIX); 
						}*/
						//WET DIFF (WD)
						
						 subPartWD = (String)mEBOMObjects.get("attribute[".concat(FormulationAttribute.QUANTITY_ADJUSTMENT.getAttribute(context)).concat("].value"));
						//Commented by Ketan for Req. no. 47948
						/*if(UIUtil.isNotNullAndNotEmpty(subPartWD))
						{
							if (percentConsumed > 0) {
								subPartWD =  Double.toString(Double.parseDouble(subPartWD)*percentConsumed/100);
							}
							Double floatQtyAdj = new Double(0.0);
							floatQtyAdj = Double.parseDouble(subPartWD);
							Double absfloatQtyAdj = Math.abs(floatQtyAdj);
							String strfloatQtyAdj = String.format("%.6f", new BigDecimal(absfloatQtyAdj));
							
							strfloatQtyAdj = util.getFormatedDecimalValue(strfloatQtyAdj, FormulationSubstituteConstants.FORMAT_DECIMAL_SIX); 
							//if(floatQtyAdj < 0)
							//{
								subPartWD=strfloatQtyAdj;
							//}
							
						}*/
						
						String sFunction = "";
						String strApplication = (String)mEBOMObjects.get("attribute[Application].value");
						if (UIUtil.isNotNullAndNotEmpty(strApplication))
						{
							sFunction=util.getIdFromPhysicalIdFunction(context,strApplication);
						}else
						{
							sFunction=ConstantsUtil.EMPTY_STRING;
						}
						
				
						//Substitutes
						util.formatData(sbPId, subPartId);
						//Added by Subhajit for Req 46464 - Start
						util.formatData(sbPRelRestriction, sRelRestriction);
						util.formatData(sbPRelRestrictionComment, sRelRestrictionComment);
						//Added by Subhajit for Req 46464 - End
						util.formatData(sbPName, subPartName);
						util.formatData(sbPType, subPartType);
						util.formatData(sbChg, subPartCHG);
						util.formatData(sbPRev, subPartRev);
						util.formatData(sbPRMN, subPartRMN);
						util.formatData(sbPPhase, subPartPhase);
						util.formatData(sbPMIN, subPartMinValue);
						util.formatData(sbPMAX, subPartMaxValue);
						util.formatData(sbPWET, subPartWET);
						util.formatData(sbTWW, subPartTWW);
						util.formatData(sbPWEM, subPartWEM);
						util.formatData(sbPWWM, subPartWWM);
						util.formatData(sbPWD, subPartWD);
						util.formatData(sbPRF, subPartRF);
						util.formatData(sbPF, sFunction);
						util.formatData(sbCert, subPartCertifications);
						util.formatData(sbProcessNote, subPartProcessNote);
						util.formatData(sbVED, strVED);
						util.formatData(sbVUD, strVUD);
						util.formatData(sbCMT, sComment);
						
						//Substitute For
						if (mEBOMObjects.containsKey("notNew"))
						{
							//SPEC: <02.17.2021>: Sumit Added for Defect :38456 ## --STARTS
							bNotNew = true;
							//SPEC: <02.17.2021>: Sumit Added for Defect :38456 ## --ENDS
							util.formatData(sbFId, subPartId);
							util.formatData(sbFName, subPartName);
							util.formatData(sbFType, subPartType);
							util.formatData(sbFRev, subPartRev);
							util.formatData(sbFRMN, subPartRMN);
							util.formatData(sbFPhase, subPartForPhase);
						//	util.formatData(sbFWET, subPartWET);
							//SPEC: <02.17.2021>: Sumit Modified for Defect :38997 ## --START
							util.formatData(sbFWEM, subFPartWEM);
							util.formatData(sbFWWM, subFPartWWM);
							//SPEC: <02.17.2021>: Sumit Modified for Defect :38997 ## --ENDS
							util.formatData(sbFInst,sInstructions);
							
						}
						//SPEC: <02.17.2021>: Sumit Added for Defect :38456 ## --STARTS
						else {
							
							if (!bNotNew && iCount != 0 && iCount == SubInFBOM1.size()) {
								bNotNew = true;
								StringList slSubForParts = (StringList) mSubFor.get("SubForParts");
								String sBOMID = (String) mSubFor.get("EBOM ID");
								Iterator<String> ebomsubsItr = slSubForParts.iterator();
								String subRelId = null;
								String subRelandAtr = null;
								StringList slSelect = new StringList(4);
								slSelect.add(ConstantsUtil.SELECT_ID);
								slSelect.add(ConstantsUtil.SELECT_NAME);
								slSelect.add(ConstantsUtil.SELECT_TYPE);
								slSelect.add(ConstantsUtil.SELECT_REVISION);
								Map mpForDetails = new HashMap();
								while (ebomsubsItr.hasNext()) {

									subRelandAtr = ebomsubsItr.next();
									StringList subList = FrameworkUtil.split(subRelandAtr, ":");
									subRelId = (String) subList.get(0);
									DomainObject dObjSubFor = new DomainObject(subRelId);
									mpForDetails = dObjSubFor.getInfo(context, slSelect);

								}

								if (!mpForDetails.isEmpty() && mpForDetails != null) {

									String sID = (String) mpForDetails.get(ConstantsUtil.SELECT_ID);

									if (validator.isNotNullOrEmpty(sID)) {

										if (FormulationType.FORMULATION_PART.getType(context)
												.equals((String) mEBOMObjects.get(ConstantsUtil.SELECT_TYPE))) {
											subPartRMN = (String) DomainObject.newInstance(context, sID)
													.getInfo(context,
															"from[" + REL_PLAN_FOR + "].to["
																	+ FormulationType.FORMULATION_PROCESS
																			.getType(context)
																	+ "].from[" + REL_FORM_PROCESS + "].to["
																	+ TYPE_COSM_FORMULATION + "].attribute["
																	+ ATTR_TITLE + "]");
										} else {
											if (POL_MAN_EQUE.equals((String) DomainObject.newInstance(context, sID)
													.getInfo(context, ConstantsUtil.SELECT_POLICY))) {

												subPartRMN = (String) DomainObject.newInstance(context, sID).getInfo(
														context,
														"to[" + REL_MAN_EQUE + "].from["
																+ FormulationType.RAWMATERIAL_PART.getType(context)
																+ "].attribute[" + ATTR_TITLE + "]");
												if (UIUtil.isNullOrEmpty(subPartRMN)) {
													subPartRMN = (String) DomainObject.newInstance(context, sID)
															.getInfo(context,
																	"to[" + REL_MAN_EQUE + "].from["
																			+ FormulationType.RAWMATERIAL_PART
																					.getType(context)
																			+ "].attribute[" + ATTR_PREF_NAME + "]");
												}

											} else {
												subPartRMN = (String) DomainObject.newInstance(context, sID)
														.getInfo(context, "attribute[" + ATTR_TITLE + "]");
												if (UIUtil.isNullOrEmpty(subPartRMN)) {
													subPartRMN = (String) DomainObject.newInstance(context, sID)
															.getInfo(context, "attribute[" + ATTR_PREF_NAME + "]");
												}
											}
										}
										String strCommand1 = "print connection $1 select $2 dump $3";
										subPartForPhase = MqlUtil.mqlCommand(context, strCommand1, sBOMID, "from.name",
												"|");

										if (!util.checkHasAccess(context, null, sID))
											sID = ConstantsUtil.NO_ACCESS;

										util.formatData(sbFId, sID);
										util.formatData(sbFName, (String) mpForDetails.get(ConstantsUtil.SELECT_NAME));
										util.formatData(sbFType, util.mapType((String) mpForDetails.get(ConstantsUtil.SELECT_TYPE)));
										util.formatData(sbFRev,
												(String) mpForDetails.get(ConstantsUtil.SELECT_REVISION));
										util.formatData(sbFRMN, subPartRMN);
										util.formatData(sbFPhase, subPartForPhase);
										util.formatData(sbFWEM, subFPartWEM);
										util.formatData(sbFWWM, subFPartWWM);
										util.formatData(sbFInst, sInstructions);
									}
								}

							}
						}
						//SPEC: <02.17.2021>: Sumit Added for Defect :38456 ## --ENDS
					}
				
				}
				mpSubstitutes.put(ConstantsUtil.SP_ID, sbPId.toString());
				mpSubstitutes.put(ConstantsUtil.SP_TYPE, sbPType.toString());
				mpSubstitutes.put(ConstantsUtil.SP_NAME, sbPName.toString());
				mpSubstitutes.put(ConstantsUtil.SP_REVISION, sbPRev.toString());
				//Added by Subhajit for Req 46464 - Start
				mpSubstitutes.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, sbPRelRestriction.toString());
				mpSubstitutes.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, sbPRelRestrictionComment.toString());
				//Added by Subhajit for Req 46464 - End
				
				mpSubstitutes.put(ConstantsUtil.SF_REVISION, sbFRev.toString());
				mpSubstitutes.put(ConstantsUtil.SF_ID, sbFId.toString());
				mpSubstitutes.put(ConstantsUtil.SF_TYPE, sbFType.toString());
				mpSubstitutes.put(ConstantsUtil.SF_NAME, sbFName.toString());
				
				mpSubstitutes.put(ConstantsUtil.CHG, sbChg.toString());
				mpSubstitutes.put(ConstantsUtil.SF_RAWMATERIALNAME, sbFRMN.toString());
				mpSubstitutes.put(ConstantsUtil.SP_RAWMATERIALNAME, sbPRMN.toString());
				
				mpSubstitutes.put(ConstantsUtil.SP_PHASE, sbPPhase.toString());
				mpSubstitutes.put(ConstantsUtil.PHASE, sbFPhase.toString());
				
				mpSubstitutes.put(ConstantsUtil.MIN, sbPMIN.toString());
				mpSubstitutes.put(ConstantsUtil.MAX, sbPMAX.toString());

				mpSubstitutes.put(ConstantsUtil.SP_WET, sbPWET.toString());
				mpSubstitutes.put(ConstantsUtil.SF_WET, util.replaceSpecialSymbols(vcSFORDIFF.toString()));
				
				mpSubstitutes.put(ConstantsUtil.TWW, sbTWW.toString());

				mpSubstitutes.put(ConstantsUtil.SF_WEM, sbFWEM.toString());
				mpSubstitutes.put(ConstantsUtil.SF_WWM, sbFWWM.toString());
				
				mpSubstitutes.put(ConstantsUtil.WEM, sbPWEM.toString());
				mpSubstitutes.put(ConstantsUtil.WWM, sbPWWM.toString());

				mpSubstitutes.put(ConstantsUtil.DIFF, sbPWD.toString());
				
				mpSubstitutes.put(ConstantsUtil.FUNCTIONS, sbPF.toString());
				mpSubstitutes.put(ConstantsUtil.SF_REPORTEDFUNCTION, sbPRF.toString());
				
				
				mpSubstitutes.put(ConstantsUtil.CERT, sbCert.toString());
				mpSubstitutes.put(ConstantsUtil.PROCESS, sbProcessNote.toString());
				
				mpSubstitutes.put(ConstantsUtil.VALIDSTARTDATE, sbVUD.toString());
				mpSubstitutes.put(ConstantsUtil.VALIDUNTILDATE, sbVED.toString());
				mpSubstitutes.put(ConstantsUtil.SEQUENCENUMBER, util.replaceSpecialSymbols(vcFN.toString()));
				mpSubstitutes.put(ConstantsUtil.COMMENT, sbCMT.toString());
				  
				mpSubstitutes.put(ConstantsUtil.DESCRIPTION, sbPDesc.toString());
				mpSubstitutes.put(ConstantsUtil.INSTRUCTIONS, sbPInst.toString());
				mpSubstitutes.put(ConstantsUtil.INSTRUCTIONS_FOR, sbFInst.toString());
				  
				mpProces.put(k, mpSubstitutes);
				k++;
				
			}
			
			
			
		}catch(Exception e){
			
			 LOGGER.error("Exception in program FOPSubstitute :getFopSubstitute ");
			 e.printStackTrace();
			return new HashMap();
		}
	return mpProces;
}

	
	
	public MapList getSubstituteDetails(Context context, String[] args) throws Exception
	{
		
		StringValidatorUtil  BusinessUtil = new StringValidatorUtil();
		BusObjectAttribUtil util =new BusObjectAttribUtil();
		try
		{
			MapList _substitutePartList = new MapList();
			MapList _finalsubstitutePartList        = new MapList();
			Set<String> virtualIntermediateList = new HashSet<String>();
			HashMap paramMap = (HashMap)JPO.unpackArgs(args);
			String partId= (String) paramMap.get("objectId");
			//DSM (DS) 2018x.0 TF Validation Required (DSIS and Support) - PROCTER AND GAMBLE CO - CRITSR00511297-02 - STARTS 
			Map targetPercentConsumedMap = new HashMap();
			//DSM (DS) 2018x.0 TF Validation Required (DSIS and Support) - PROCTER AND GAMBLE CO - CRITSR00511297-02 - ENDS
    		String isVIFromFormulation= (String) paramMap.get("isVIFromFormulation");

			DomainObject domObj                     = new DomainObject(partId);
			String objName				= (String) domObj.getInfo(context, ConstantsUtil.SELECT_NAME);
			StringList slEBOMSubs                   = null;
			StringList relsel                       = new StringList();
			//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -starts
			StringBuilder strBuApplication = new StringBuilder("attribute[").append(FormulationAttribute.APPLICATION.getAttribute(context)).append("].value");
			//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -ends

			relsel.add(DomainRelationship.SELECT_ID);
			relsel.add(FormulationAttribute.QUANTITY.getAttributeSelect(context));
			//DSM (DS) 2015x.2 -  Added code to update value for Min and Max columns - Start
			//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - Start
			relsel.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MIN+"].inputvalue");
			relsel.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MAX+"].inputvalue");
			//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - End
			//DSM (DS) 2015X.5.1 - Add additional 3 columsn to display Target Wet Weight, Wet Weight Min and Wet Weight Max - Start
			relsel.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_TARGETWEIGHT_WET+"].inputvalue");
			relsel.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET+"].inputvalue");
			relsel.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET+"].inputvalue");
			//DSM (DS) 2015X.5.1 - Add additional 3 columsn to display Target Wet Weight, Wet Weight Min and Wet Weight Max - End
			//DSM (DS) 2015x.2 -  Added code to update value for Min and Max columns - End
			relsel.add(FormulationAttribute.QUANTITY.getAttributeSelect(context));
			//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -starts
			relsel.add(strBuApplication.toString());
			//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -ends
			//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - START
			relsel.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PROCESSING_NOTE+"].value");
			relsel.add("frommid[FBOM Substitute].to.description");
			relsel.add("frommid[FBOM Substitute].to.attribute[Substitute Instructions]");
			
			//relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESC);
			//relsel.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTITUTEINSTRUCTIONS);
			//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - END

			StringList strObjList                   = new StringList(6);
			strObjList.add(DomainConstants.SELECT_ID);
			strObjList.add(DomainConstants.SELECT_TYPE);
			strObjList.add(DomainConstants.SELECT_NAME);
			strObjList.add(DomainConstants.SELECT_REVISION);
			strObjList.add(DomainConstants.SELECT_DESCRIPTION);
			//relsel.add("to[FBOM Substitute].fromrel.to.description");
			
			
			//relsel.add(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_FROMREL_TO_TITLE);
			
			//DSM (DS) 2015x.2 - This method is overriden method to display the pgRawMaterial in View substitutes Page - START
			/*MapList substituteList = domObj.getRelatedObjects(context,
    		                                DomainConstants.RELATIONSHIP_PLBOM,
    		                                FormulationType.RAWMATERIAL_PART.getType(context).concat(",").concat(FormulationType.FORMULATION_PHASE.getType(context)).concat(",").concat(FormulationType.FORMULATION_PART.getType(context)),
    										strObjList,
    										relsel,
    										false,
    										true,
    										(short)0,
    										"",
    										"",
    		                                0);*/
			//DSM (DS) 2015x.2 Copy Substitute Issue - starts  
			//Modified by DSM(Sogeti)-2015x.5 for Formulation (Defect ID-14173) -Starts
			MapList substituteList = domObj.getRelatedObjects(context,
					//DSM (DS) 2018.0 FD02 Relationship change PLBOM to FBOM -starts
					FormulationSubstituteConstants.REL_FBOM,
					//DSM (DS) 2018.0 FD02 Relationship change PLBOM to FBOM -ends
					FormulationType.RAWMATERIAL_PART.getType(context).concat(",").concat(FormulationType.FORMULATION_PHASE.getType(context)).concat(",").concat(FormulationType.FORMULATION_PART.getType(context)).concat(",").concat(FormulationSubstituteConstants.TYPE_PG_RAWMATERIAL).concat(",").concat(ConstantsUtil.TYPE_PGMASTERRAWMATERIAL).concat(",").concat(FormulationSubstituteConstants.TYPE_PG_ANCILLARY_RAW_MATERIAL_PART),
					strObjList,
					relsel,
					false,
					true,
					(short)0,
					"",
					"",
					0);
			
			//DSM (DS) 2015x.2 Copy Substitute Issue - ends
			//DSM (DS) 2015x.2 - This method is overriden method to display the pgRawMaterial in View substitutes Page - END
			Iterator subsIterator = substituteList.iterator();
			while(subsIterator.hasNext())
			{
				Map temp = (Map)subsIterator.next();
				String sobjType = (String) temp.get(DomainConstants.SELECT_TYPE);
				//DSM (DS) 2015x.2 - This method is overriden method to display the pgRawMaterial in View substitutes Page - START
				//if(sobjType.equals(FormulationType.RAWMATERIAL_PART.getType(context)) || mxType.isOfParentType(context, sobjType, FormulationType.FORMULATION_PART.getType(context)))
				//DSM (DS) 2015x.2 Copy Substitute Issue - starts
				if(sobjType.equals(FormulationSubstituteConstants.TYPE_PG_RAWMATERIAL) || sobjType.equals(FormulationType.RAWMATERIAL_PART.getType(context)) || util.isOfParentType(context, sobjType, FormulationType.FORMULATION_PART.getType(context)) || util.isOfParentType(context, sobjType, FormulationSubstituteConstants.TYPE_PG_ANCILLARY_RAW_MATERIAL_PART) || sobjType.equals(SAPBOMConstants.TYPE_PGMASTERRAWMATERIAL))
				{       
					//DSM (DS) 2015x.2 Copy Substitute Issue - ends
					_substitutePartList.add((Map) temp);
				}    			
			}
			
			
			//Modified by DSM(Sogeti)-2015x.5 for Formulation (Defect ID-14173) -Ends
			Iterator itr1 = _substitutePartList.iterator();
			Map tempmap1 = null;
			StringList sIDList = new StringList();
			while (itr1.hasNext())
			{
				Map relmap                  = (Map) itr1.next();
				String sEBOMID              = (String)relmap.get("id[connection]");
				//DSM (DS) 2015x.2 -  Added code to update value for Min and Max columns - Start
				//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - Start
				String strMin = (String)relmap.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MIN+"].inputvalue");
				String strMax = (String)relmap.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MAX+"].inputvalue");
				//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - End
				//DSM (DS) 2015X.5.1 - Add additional 3 columsn to display Target Wet Weight, Wet Weight Min and Wet Weight Max - Start
				String strTargetWeightWet = (String)relmap.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_TARGETWEIGHT_WET+"].inputvalue");
				String strMinWeightWet = (String)relmap.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET+"].inputvalue");
				String strMaxWeightWet = (String)relmap.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET+"].inputvalue");
				//DSM (DS) 2015X.5.1 - Add additional 3 columsn to display Target Wet Weight, Wet Weight Min and Wet Weight Max - End
				//DSM (DS) 2015x.2 -  Added code to update value for Min and Max columns - End
				//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -starts
				String strApplication = (String)relmap.get(strBuApplication.toString());
				//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -ends
				//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - START
				String strProcessingNote = (String)relmap.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PROCESSING_NOTE+"].value");
				//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - END
				String strCommand           = "print connection $1 select $2 dump $3";
				//Modified for 2018x Upgrade STARTS
				//String strMessage           = MqlUtil.mqlCommand(context,strCommand,sEBOMID,"frommid[".concat(FormulationRelationship.PLBOM_SUBSTITUTE.getRelationship(context)).concat("].id"),"|");
				String strMessage           = MqlUtil.mqlCommand(context,strCommand,sEBOMID,"frommid[".concat(FormulationRelationship.FBOM_SUBSTITUTE.getRelationship(context)).concat("].id"),"|");
				//Modified for 2018x Upgrade ENDS
				
				StringValidatorUtil validator =  new StringValidatorUtil();
				//String	sSubForInstruction  = validator.getStringEquivalentForStringListWithComma(relmap.get("frommid[FBOM Substitute].to.attribute[Substitute Instructions]"));
				//String	sSubForRmn  = validator.getStringEquivalentForStringListWithComma(relmap.get("frommid[FBOM Substitute].to.description"));
				String sSubForInstruction="";
				if(null!=relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INSTRUCTIONS)) {
					String objectType = relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INSTRUCTIONS).getClass().getSimpleName();
					if(objectType.equalsIgnoreCase("String")) {
						sSubForInstruction  = validator.getStringEquivalentForStringListWithComma(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INSTRUCTIONS));
					}else {
						StringList slSubForInst = (StringList)relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_INSTRUCTIONS);
						sSubForInstruction = slSubForInst.get(0);
					}
				}
				
				
				String sSubForDesc="";
				if(null!=relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESCRIPTION)) {
					String objectType = relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESCRIPTION).getClass().getSimpleName();
					if(objectType.equalsIgnoreCase("String")) {
						sSubForDesc  = validator.getStringEquivalentForStringListWithComma(relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESCRIPTION));
					}else {
						StringList slSubForDesc = (StringList)relmap.get(ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE_DESCRIPTION);
						sSubForDesc = slSubForDesc.get(0);
					}
				}
				
				
				slEBOMSubs                  = FrameworkUtil.split(strMessage,"|");
				if(UIUtil.isNullOrEmpty(strMessage)){
					//DSM (DS) 2018x.0 TF Validation Required (DSIS and Support) - PROCTER AND GAMBLE CO - CRITSR00511297-02 - STARTS 
    				/*String viPhysicalId = MqlUtil.mqlCommand(context,strCommand,sEBOMID, FormulationAttribute.VIRTUAL_INTERMEDIATE_PHYSICAL_ID.getAttributeSelect(context) ,"|");
    				if(UIUtil.isNotNullAndNotEmpty(viPhysicalId)){
    					virtualIntermediateList.add(viPhysicalId);
    				}*/
					
					DomainRelationship domEBOMRel = new DomainRelationship(sEBOMID);
			        Map attributeMap = domEBOMRel.getAttributeMap(context, true);
			    	String viPhysicalId =(String) attributeMap.get(FormulationAttribute.VIRTUAL_INTERMEDIATE_PHYSICAL_ID.getAttribute(context));
			    	if(UIUtil.isNotNullAndNotEmpty(viPhysicalId)){
			    		virtualIntermediateList.add(viPhysicalId);
			    		String quantityInVI = (String) attributeMap.get(FormulationAttribute.TARGET_PERCENT_WET_IN_VIRTUAL_INTERMEDIATE.getAttribute(context));
			    		String currentQuantity = (String) attributeMap.get(FormulationAttribute.QUANTITY.getAttribute(context));
			    		double targetPercent = Double.parseDouble(currentQuantity)/Double.parseDouble(quantityInVI)*100.0;
			    		targetPercentConsumedMap.put(viPhysicalId, Double.toString(targetPercent));
			    	}

    				//DSM (DS) 2018x.0 TF Validation Required (DSIS and Support) - PROCTER AND GAMBLE CO - CRITSR00511297-02 - ENDS
     			}
				Iterator ebomsubsItr        = slEBOMSubs.iterator();
				String sEBOMSubstituteRelid = "";
				StringList slSubstituteForParentList = new StringList();
				while(ebomsubsItr.hasNext())
				{
					StringList slSubstituteForList = new StringList();
					StringList slSubForList = new StringList();

					tempmap1                        = new HashMap();
					tempmap1.put("EBOM ID",sEBOMID);
					
					
					//EBOM Substitute Id
					sEBOMSubstituteRelid            = (String) ebomsubsItr.next();
					//Putting EBOM Substitute Rel Id as id[connection]
					tempmap1.put("id[connection]",sEBOMSubstituteRelid);
					DomainRelationship domRel       = new DomainRelationship(sEBOMSubstituteRelid);
					//Getting relationship attribute on EBOM Substitute
					Map attEbomSubstitute           = domRel.getAttributeMap(context,sEBOMSubstituteRelid);
					//String strFindNumber            = (String) attEbomSubstitute.get(srealAttrFNName);
					//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - Start
					//String strQantity = (String) attEbomSubstitute.get(FormulationAttribute.QUANTITY.getAttribute(context));
					//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - End
					SelectList resultSelects        = new SelectList(1);
					String[] RelIdArray             = new String[1];
					RelIdArray[0]                   = sEBOMSubstituteRelid;
					resultSelects.add("to.".concat(DomainObject.SELECT_ID));
					resultSelects.add("to.".concat(DomainObject.SELECT_NAME));
					resultSelects.add("to.".concat(DomainObject.SELECT_TYPE));
					resultSelects.add("fromrel.to.".concat(DomainObject.SELECT_ID));
					resultSelects.add("fromrel.from.".concat(DomainObject.SELECT_ID));
					//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - Start
					resultSelects.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_QUANTITY+"].inputvalue");
					resultSelects.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET+"].inputvalue");
					resultSelects.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET+"].inputvalue");
					//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - START
					resultSelects.add(DomainObject.getAttributeSelect(FormulationSubstituteConstants.ATTR_PG_CHANGE));
					//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - END
					//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - End
					
					
					
					MapList resultList              = DomainRelationship.getInfo(context,
							RelIdArray,
							resultSelects);
					
					Iterator itr                    = resultList.iterator();
					Map map = (Map) itr.next();
					String strsubsPartId            = (String)map.get("to.id");
					String strsubsPartIdName            = (String)map.get("to.name");
					String strsubsPartIdType            = (String)map.get("to.type");
					
					tempmap1.put("id",strsubsPartId);
					tempmap1.put("name",strsubsPartIdName);
					tempmap1.put("type",strsubsPartIdType);
					tempmap1.put("Instructions",sSubForInstruction);
					tempmap1.put("Desc",sSubForDesc);
					
					//tempmap1.put("attribute[" + srealAttrFNName + "]",strFindNumber);
					//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - Start
					tempmap1.put("attribute[".concat(FormulationAttribute.QUANTITY.getAttribute(context)).concat("]"),(String)map.get("attribute["+FormulationSubstituteConstants.ATTRIBUTE_QUANTITY+"].inputvalue"));
					//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - End
					
					tempmap1.put("ParentOfPhase",objName);
					//DSM (DS) 2015x.2 -  Added code to update value for Min and Max columns - Start
					tempmap1.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MIN+"].value",strMin);
					tempmap1.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MAX+"].value",strMax);
					//DSM (DS) 2015x.2 -  Added code to update value for Min and Max columns - End
					//DSM (DS) 2015X.5.1 - Add additional 3 columsn to display Target Wet Weight, Wet Weight Min and Wet Weight Max - Start
					tempmap1.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_TARGETWEIGHT_WET+"].value",strTargetWeightWet);
					//SPEC: <02.17.2021>: Sumit Modified for Defect :38997 ## --START
					tempmap1.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET+"]",strMinWeightWet);
					tempmap1.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET+"]",strMaxWeightWet);
					//SPEC: <02.17.2021>: Sumit Modifed for Defect :38997 ## --ENDS
					//DSM (DS) 2015X.5.1 - Add additional 3 columsn to display Target Wet Weight, Wet Weight Min and Wet Weight Max - End
					//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -starts
					tempmap1.put(strBuApplication.toString(),strApplication);
					//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -ends
					//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - START
					tempmap1.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PROCESSING_NOTE+"].value",strProcessingNote);		   
					//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - END
					
					//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - START
					tempmap1.put(DomainObject.getAttributeSelect(FormulationSubstituteConstants.ATTR_PG_CHANGE), map.get(DomainObject.getAttributeSelect(FormulationSubstituteConstants.ATTR_PG_CHANGE)));
					//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - END
					tempmap1.put("Parent","Yes");
    				if(UIUtil.isNotNullAndNotEmpty(isVIFromFormulation)){
						tempmap1.put("disableSelection",isVIFromFormulation);
						//DSM (DS) 2018x.0 TF Validation Required (DSIS and Support) - PROCTER AND GAMBLE CO - CRITSR00511297-02 - STARTS
						tempmap1.put("targetPercentConsumed",(String) paramMap.get("targetPercentConsumed"));
						//DSM (DS) 2018x.0 TF Validation Required (DSIS and Support) - PROCTER AND GAMBLE CO - CRITSR00511297-02 - ENDS
					};
					DomainObject subsObj = new DomainObject(strsubsPartId);
					String subsType = (String) subsObj.getInfo(context, ConstantsUtil.SELECT_TYPE);
					if (!subsType.equals((String)PropertyUtil.getSchemaProperty(context, "type_ParentSub")))
					{
						_finalsubstitutePartList.add((Map)tempmap1);
					}
					else
					{
						//slSubstituteForList.add((String)map.get("fromrel.to.id"));
						if(sIDList.contains(strsubsPartId))
						{
							slSubstituteForParentList.add((String)map.get("fromrel.from.id")); 
						}
						else
						{
							slSubstituteForParentList.add((String)map.get("fromrel.from.id"));
							sIDList.add(strsubsPartId);
							StringList objectSelects = new StringList();
							StringList relSelects = new StringList();
							objectSelects.add(ConstantsUtil.SELECT_NAME);
							objectSelects.add(ConstantsUtil.SELECT_ID); 
							objectSelects.add(ConstantsUtil.SELECT_TYPE);
							objectSelects.add(ConstantsUtil.SELECT_REVISION);
							// 	Added by DSM-2015x.4 for PDF Views(Defect Id- 13773 ) - Starts
							objectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
							//	Added by DSM-2015x.4 for PDF Views(Defect Id- 13773 ) - Ends
							relSelects.add("from.".concat(DomainObject.SELECT_ID));	        			 	        			 
							relSelects.add(DomainRelationship.SELECT_ID);
							//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - Start
							relSelects.add("attribute[".concat(FormulationAttribute.QUANTITY.getAttribute(context)).concat("].inputvalue"));
							//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - End
							relSelects.add("attribute[".concat(FormulationAttribute.QUANTITY_ADJUSTMENT.getAttribute(context)).concat("].value"));
							relSelects.add("attribute[".concat(FormulationAttribute.NEEDS_UPDATE.getAttribute(context)).concat("].value"));
							//DSM (DS) 2015x.2 -  Added code to update value for Min and Max columns - Start
							//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - Start
							relSelects.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MIN+"].inputvalue");
							relSelects.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MAX+"].inputvalue");
							//DSM (DS) 2015X.5 - ALM 10353 - PDT Req 14780 - Using attribute.inputvalue instead of attribute.value - End
							//DSM (DS) 2015X.5.1 - Add additional 3 columsn to display Target Wet Weight, Wet Weight Min and Wet Weight Max - Start
							relSelects.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_TARGETWEIGHT_WET+"].inputvalue");
							relSelects.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET+"].inputvalue");
							relSelects.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET+"].inputvalue");
							//DSM (DS) 2015X.5.1 - Add additional 3 columsn to display Target Wet Weight, Wet Weight Min and Wet Weight Max - End
							//Modified by DSM-2015x.4 for PDF Views FOP Type(Req-11472) - Starts
							relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PROCESSINGNOTE);
							//Modified by DSM-2015x.4 for PDF Views FOP Type(Req-11472) - Ends
							//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - START
							relSelects.add("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PROCESSING_NOTE+"].value");
							//DSM(DS) 2015x.4 ALM 12503 - Formula Card Revise losing substitutes comments - END
							//DSM (DS) 2015x.2 -  Added code to update value for Min and Max columns - End
							//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -starts
							relSelects.add(strBuApplication.toString());
							//DSM (DS) 2015x.4 ALM 11689 - Material Function column does not display in Substitute page for APP, DPP, FAB,FOP -ends
							//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - START
							relSelects.addElement(DomainObject.getAttributeSelect(FormulationSubstituteConstants.ATTR_PG_CHANGE));
							//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - END
							
							
							MapList subInFBOM = subsObj.getRelatedObjects(context,
									//DSM (DS) 2018.0 FD02 Relationship change PLBOM to FBOM -starts
									FormulationSubstituteConstants.REL_FBOM,
									//DSM (DS) 2018.0 FD02 Relationship change PLBOM to FBOM -ends
									"*",
									objectSelects,
									relSelects,
									false,
									true,
									(short) 1,
									null,
									null,
									0);
							
							
							String sSubInEBOMSize = String.valueOf(subInFBOM.size());
							tempmap1.put("SubInEBOMSize",sSubInEBOMSize);   					
							String strCommand1  	= "print bus $1 select $2 $3 $4 $5 $6 $7 $8 $9 $10 $11 $12 $13 $14 $15 $16 $17 $18 dump $19";
							String phaseId     	= MqlUtil.mqlCommand(context,strCommand1,strsubsPartId,"to.attribute[".concat(FormulationAttribute.QUANTITY.getAttribute(context)).concat("].inputvalue"),
									"to.fromrel.to.type","to.fromrel.to.revision","to.attribute[".concat(FormulationAttribute.QUANTITY_ADJUSTMENT.getAttribute(context)).concat("].value"),"to.fromrel.to.name",
									"to.fromrel.to.id","to.attribute[".concat(FormulationAttribute.PRIMARY_REPLACEMENT_INGREDIENT.getAttribute(context)).concat("].value"),
									"to.attribute[".concat(FormulationAttribute.NEEDS_UPDATE.getAttribute(context)).concat("].value"),
									"to.fromrel.from.name","to.fromrel.attribute["+FormulationSubstituteConstants.ATTRIBUTE_MAX+"].inputvalue",
									"to.fromrel.attribute["+FormulationSubstituteConstants.ATTRIBUTE_MIN+"].inputvalue","to.fromrel."+BusinessUtil.strcat("attribute[",FormulationAttribute.APPLICATION.getAttribute(context),"].value"),"to.fromrel.attribute["+FormulationSubstituteConstants.ATTRIBUTE_PROCESSING_NOTE+"].value","to.fromrel.attribute["+FormulationSubstituteConstants.ATTRIBUTE_TARGETWEIGHT_WET+"].inputvalue","to.attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET+"].inputvalue","to.attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET+"].inputvalue",new StringBuilder("to.").append(DomainObject.getAttributeSelect(FormulationSubstituteConstants.ATTR_PG_CHANGE)).toString(),"|");
							
							StringList slSubForDetails = FrameworkUtil.split(phaseId, "|");
							
							int size = slSubForDetails.size();
							
							int iNoOfIterations = (size / 17);
							int iCounter = 0;
							int iTypeCounter 	= iNoOfIterations;
							int iRevCounter 	= 2*iNoOfIterations;
							int iQtyAdjCounter 	= 3*iNoOfIterations;
							int iNameCounter 	= 4*iNoOfIterations;
							int iIdCounter 		= 5*iNoOfIterations;
							int iPRICounter 	= 6*iNoOfIterations;
							int iDirtyCounter 	= 7*iNoOfIterations;
							int iPhaseCounter 	= 8*iNoOfIterations;
							int iMaxCounter 	= 9*iNoOfIterations;
							int iMinCounter 	= 10*iNoOfIterations;
							int iMaterialFunctionCounter 	= 11*iNoOfIterations;
							int iProcessingNoteCounter 	= 12*iNoOfIterations;
							int iTargetweightWetCounter 	= 13*iNoOfIterations;
							int iMinWeightWetCounter 	= 14*iNoOfIterations;
							int iMaxWeightWetCounter = 15*iNoOfIterations;
							int iChgCounter = 16*iNoOfIterations;
							while(iCounter < iNoOfIterations)
							{
								HashMap mp = new HashMap();
								mp.put(FormulationAttribute.QUANTITY.getAttributeSelect(context).concat(".inputvalue"), ((String) slSubForDetails.get(iCounter)).trim());
								mp.put(ConstantsUtil.SELECT_TYPE,((String) slSubForDetails.get(iTypeCounter)).trim() );
								mp.put(ConstantsUtil.SELECT_REVISION, ((String) slSubForDetails.get(iRevCounter)).trim());
								mp.put("attribute[".concat(FormulationAttribute.QUANTITY_ADJUSTMENT.getAttribute(context)).concat("].value"), ((String) slSubForDetails.get(iQtyAdjCounter)).trim());
								mp.put(ConstantsUtil.SELECT_NAME, ((String) slSubForDetails.get(iNameCounter)).trim());
								mp.put(ConstantsUtil.SELECT_ID, ((String) slSubForDetails.get(iIdCounter)).trim());
								mp.put("attribute[".concat(FormulationAttribute.PRIMARY_REPLACEMENT_INGREDIENT.getAttribute(context)).concat("].value"), ((String) slSubForDetails.get(iPRICounter)).trim());

								mp.put("attribute[".concat(FormulationAttribute.NEEDS_UPDATE.getAttribute(context)).concat("].value"), ((String) slSubForDetails.get(iDirtyCounter)).trim());
								mp.put("phase", ((String) slSubForDetails.get(iPhaseCounter)).trim());
								mp.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MAX+"].value", ((String) slSubForDetails.get(iMaxCounter)).trim());
								mp.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_MIN+"].value", ((String) slSubForDetails.get(iMinCounter)).trim());
								mp.put(BusinessUtil.strcat("attribute[",FormulationAttribute.APPLICATION.getAttribute(context),"].value"), ((String) slSubForDetails.get(iMaterialFunctionCounter)).trim());
								mp.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PROCESSING_NOTE+"].value", ((String) slSubForDetails.get(iProcessingNoteCounter)).trim());
								mp.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_TARGETWEIGHT_WET+"].value", ((String) slSubForDetails.get(iTargetweightWetCounter)).trim());
								mp.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MIN_ACTUAL_WEIGHT_WET+"].inputvalue", ((String) slSubForDetails.get(iMinWeightWetCounter)).trim());
								mp.put("attribute["+FormulationSubstituteConstants.ATTRIBUTE_PG_MAX_ACTUAL_WEIGHT_WET+"].inputvalue", ((String) slSubForDetails.get(iMaxWeightWetCounter)).trim());
								
								mp.put("from.id", strsubsPartId);
								mp.put("level", "1");
								mp.put("notNew", "true");
								//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - START
								mp.put(DomainObject.getAttributeSelect(FormulationSubstituteConstants.ATTR_PG_CHANGE),(String) slSubForDetails.get(iChgCounter));
								//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - END
								if(!((((String) slSubForDetails.get(iQtyAdjCounter)).trim()).equals("0") || (((String) slSubForDetails.get(iQtyAdjCounter)).trim()).equals("0.0")) || (((String) slSubForDetails.get(iDirtyCounter)).trim() == "Yes"))
								{
									subInFBOM.add(mp);
								}
								iCounter++;
								iRevCounter++;
								iTypeCounter++;
								iQtyAdjCounter++;
								iNameCounter++;
								iIdCounter++;
								iPRICounter++;
								iDirtyCounter++;
								iPhaseCounter++;
								iMaxCounter++;
								iMinCounter++;
								iMaterialFunctionCounter++;
								iProcessingNoteCounter++;
								iTargetweightWetCounter++;
								iMinWeightWetCounter++;
								iMaxWeightWetCounter++;
								//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - START
								iChgCounter++;
								//DSM (DS) 2018x.5 - ALM 34460 - changes to populate Chg column value on view FBOM Substitutes table - END
							}
							//Added by DSM(Sogeti)-2015x.5.1 Dec Fix for (Defect ID-23298) -Ends
						   //Added by DSM(Sogeti)-2015x.5.1 November Fix for (Defect ID-22367) -Ends
							//Commented by DSM(Sogeti)-2015x.5.1 Dec Fix for (Defect ID-23385) -starts
							//tempmap1.put("SubInPLBOM",subInFBOM);
							//Commented by DSM(Sogeti)-2015x.5.1 Dec Fix for (Defect ID-23385) -Ends
							//Added by DSM(Sogeti)-2015x.5.1 Dec Fix for (Defect ID-23385) -starts
							tempmap1.put("SubInFBOM",subInFBOM);
							//Added by DSM(Sogeti)-2015x.5.1 Dec Fix for (Defect ID-23385) -Ends
							MapList subEBOM = null;
							String strCmd           = "print bus $1 select $2 dump $3";
							//Modified for 2018x Upgrade STARTS
							//String strMessage1           = MqlUtil.mqlCommand(context,strCmd,strsubsPartId,"to[".concat(FormulationRelationship.PLBOM_SUBSTITUTE.getRelationship(context)).concat("].id"),"|");
							String strMessage1           = MqlUtil.mqlCommand(context,strCmd,strsubsPartId,"to[".concat(FormulationRelationship.FBOM_SUBSTITUTE.getRelationship(context)).concat("].id"),"|");
							//Modified for 2018x Upgrade ENDS

							StringList slEBOMSubs1       = FrameworkUtil.split(strMessage1,"|");
							Iterator ebomsubsItr1        = slEBOMSubs1.iterator();
							String subRelId = null;
							//String subId = null;
							while(ebomsubsItr1.hasNext())
							{
								subRelId			 			= (String) ebomsubsItr1.next();
								String strCmd1  		 	= "print connection $1 select $2 $3 $4";
								String subForParentId      	= MqlUtil.mqlCommand(context,strCmd1,subRelId,"fromrel.to.id","attribute[".concat(FormulationAttribute.NEEDS_UPDATE.getAttribute(context)).concat("].value"), "fromrel.id");
								StringList detailsList		= FrameworkUtil.split(subForParentId, "\n");
								int detailsListSize 		= detailsList.size() -1 ;
								int iItrSize				= (detailsListSize/2);
								int iIdCtr					= 1;
								int iNeedsUpdateCounter		= iItrSize + 1;
                                int ifbomCounter			= iItrSize + 2;
								while(iIdCtr <= iItrSize)
								{
									StringList slSubFor = FrameworkUtil.split((String)detailsList.get(iIdCtr), "=");
									((String) slSubFor.get(1)).trim();
									if(!slSubForList.contains(((String) slSubFor.get(1)).trim()))
									{
										slSubForList.add(((String) slSubFor.get(1)).trim());
										StringList slNeedsUpdate = FrameworkUtil.split((String)detailsList.get(iNeedsUpdateCounter), "=");
										StringList slFbom = FrameworkUtil.split((String)detailsList.get(ifbomCounter), "=");
										StringBuffer sbTemp = new StringBuffer(((String) slSubFor.get(1)).trim()).append(":").append(((String) slNeedsUpdate.get(1)).trim()).append(":").append(subRelId.trim()).append(":").append(((String) slFbom.get(1)).trim());
										slSubstituteForList.add(sbTemp.toString());	    							
									}
									iIdCtr++;
									iNeedsUpdateCounter++;
								}
							}
							tempmap1.put("SubForParts",slSubstituteForList);
							tempmap1.put("SubstituteForParentList",slSubstituteForParentList);
							_finalsubstitutePartList.add((Map)tempmap1);
						}
						slSubstituteForParentList = new StringList();
					}
				}
			}
			Iterator itr = virtualIntermediateList.iterator();
    		while(itr.hasNext()){
    			String virtualIntermediateId = (String)itr.next();
    			HashMap hm = new HashMap();
    			hm.put("objectId", virtualIntermediateId);
    			//below entry is setting a flag which indicate this VI is added in Formulation 
    			hm.put("isVIFromFormulation", "true");
    			//DSM (DS) 2018x.0 TF Validation Required (DSIS and Support) - PROCTER AND GAMBLE CO - CRITSR00511297-02 - STARTS
    			hm.put("targetPercentConsumed", targetPercentConsumedMap.get(virtualIntermediateId));
    			//DSM (DS) 2018x.0 TF Validation Required (DSIS and Support) - PROCTER AND GAMBLE CO - CRITSR00511297-02 - ENDS
    			_finalsubstitutePartList.addAll(getSubstituteDetails(context, JPO.packArgs(hm)));
    		}
			ContextUtil.startTransaction(context, false);
			ContextUtil.commitTransaction(context);
			return _finalsubstitutePartList;
		}// end of try
		catch (Exception e)
		{
			ContextUtil.abortTransaction(context);
			throw new FrameworkException(e);
		}
	}  
	//DSM (DS) 2015x.2 - This method is overriden method to display the pgRawMaterial in View substitutes Page - END

	
	
	
	
	
	

private Vector getAttributeOnEBOMRel(Context context,String sAttribute,Map m) throws Exception
{
    Vector columnVals 	= new Vector();
	try{
        String srealAttrName    = sAttribute;
       
            StringBuffer strBuffName		= new StringBuffer();
            StringBuffer strBuffForExport 	= new StringBuffer();
            String sID					 	= (String)m.get("id");
            DomainObject dObj			 	= new DomainObject(sID);
            String sType				 	= dObj.getInfo(context, ConstantsUtil.SELECT_TYPE);
            
            //StringList slSubstituteForParentList =(StringList) m.get("SubstituteForParentList");
            if (FormulationType.PARENT_SUB.getType(context).equals(sType))
            {
          		String targetPercentConsumed = (String) m.get("targetPercentConsumed");
          		double percentConsumed = 0;
          		if (UIUtil.isNotNullAndNotEmpty(targetPercentConsumed)) {
          			percentConsumed = Double.parseDouble(targetPercentConsumed);
          		}
				String strCommand       = "print bus $1 select $2 dump $3";
			    String strMessage       = MqlUtil.mqlCommand(context,strCommand,sID,"to[".concat(FormulationRelationship.FBOM_SUBSTITUTE.getRelationship(context)).concat("].id"),"|");
			    StringList slEBOMSubs	= FrameworkUtil.split(strMessage,"|");
			    Iterator ebomsubsItr 	= slEBOMSubs.iterator();
			    String subRelId 		= null;
			    String subId 			= null;
			    int counter 			= 0 ;
			    while(ebomsubsItr.hasNext())
			    {
			    	subRelId			 	= (String) ebomsubsItr.next();
    			    
			    	String strCommand1  		= "print connection $1 select $2 $3 dump $4";
			    	String strResult = MqlUtil.mqlCommand(context,strCommand1,subRelId,"fromrel.id","fromrel.from.id","|");
			    	StringList subIdAndPhaseId = FrameworkUtil.split(strResult,"|");
    			    subId           	 		= subIdAndPhaseId.get(0);
    			    DomainRelationship domRel	= new DomainRelationship(subId);
    			    String strAttributeValue    = domRel.getAttributeValue(context,subId,srealAttrName);
    			    
    			    // the below block is specific for Fin Number, as we need to show the find number display differently
    			    if(FormulationSubstituteConstants.ATTRIBUTE_FIND_NUMBER.equals(sAttribute)){
                		String phaseId = subIdAndPhaseId.get(1);
                		DomainObject phaseObj = new DomainObject(phaseId);                		
                		StringList strObjList  = StringList.create(DomainConstants.SELECT_ID, DomainConstants.SELECT_TYPE,
								DomainConstants.SELECT_NAME, DomainConstants.SELECT_REVISION);
                		
                		StringList relSelects 	= StringList.create(DomainRelationship.SELECT_ID, 
			  					  "attribute[".concat(FormulationSubstituteConstants.ATTRIBUTE_FIND_NUMBER).concat("].value"));
                		
                		MapList phaseInHierarchy = phaseObj.getRelatedObjects(context,
                				 FormulationRelationship.FBOM.getRelationship(context),
                                FormulationType.FORMULATION_PROCESS.getType(context).concat(",").concat(FormulationType.FORMULATION_PHASE.getType(context)),
								strObjList,
								relSelects,
								true,
								false,
								(short)0,
								"",
								"",
                                0); 
                		
                		phaseInHierarchy.sort("level", "descending", "integer");
                		Iterator phaseItr = phaseInHierarchy.iterator();
                			String strFindNumber ="";
                				while(phaseItr.hasNext()){
                					Map mp = (Hashtable)phaseItr.next();
                					String realFindNumber =(String)mp.get("attribute[".concat(FormulationSubstituteConstants.ATTRIBUTE_FIND_NUMBER).concat("].value"));
                					strFindNumber = strFindNumber.concat(realFindNumber).concat(".");
                				}                		
                		strAttributeValue = strFindNumber.concat(strAttributeValue);
                	}
    			    
      				if (percentConsumed > 0 && srealAttrName.equals(FormulationAttribute.QUANTITY.getAttribute(context)) 
      						&& UIUtil.isNotNullAndNotEmpty(strAttributeValue)) {
      					strAttributeValue = Double.toString(Double.parseDouble(strAttributeValue)*percentConsumed/100);
      				}
      				
      				strBuffName.append(strAttributeValue).append("|");
			    }
            }
            else
            {
	            String sEBOMSubsRelid       = (String)m.get("EBOM ID");
	            DomainRelationship domRel   = new DomainRelationship(sEBOMSubsRelid);
	            String strAttributeValue 	= domRel.getAttributeValue(context,sEBOMSubsRelid,srealAttrName);
	        	strBuffName.append(strAttributeValue).append("|");
            }
            
            columnVals.add(strBuffName.toString());
        
    }
    catch(Exception ex)
    {
        throw ex;
    }
	    
    return columnVals;
}

	
	
	
	
public String getCommentColumnValue(Context context, Map mapObjectData) throws Exception
{
	String strVUD = "";
	Vector vcVUDData = new Vector();
	try {
		DomainObject doParentSub = DomainObject.newInstance(context);
		String strRelationshipId = "";
		
		StringList slEBOMSubs = null;
		String strType = "";
		//For Each row, get the connection id and get the values
			strVUD = DomainConstants.EMPTY_STRING;
			if(mapObjectData != null && !mapObjectData.isEmpty()){
				strRelationshipId = (String)mapObjectData.get("id[connection]");
				String strCommand = "print connection $1 select $2 $3 dump $4";
				String strMessage = MqlUtil.mqlCommand(context,strCommand,strRelationshipId,"type","attribute[Comments].value","|");
				slEBOMSubs                  = FrameworkUtil.split(strMessage,"|");
				Iterator ebomsubsItr        = slEBOMSubs.iterator();
				String sEBOMSubstituteRelid = "";
				StringList slSubstituteForParentList = new StringList();
				while(ebomsubsItr.hasNext())
				{
					//Get the Type
					strType = (String) ebomsubsItr.next();
					//Get the Comments Value
					strVUD =  (String) ebomsubsItr.next();
				}
			}
			if(null==strVUD ||strVUD.isEmpty())
			{
				strVUD="";
			}
						
			
	} catch(Exception e)
	{
		throw e;
	}
	return strVUD;
}
	
	
	
/**
 * DSM(DS) 2018x.2 - This method gets Valid  Date attribute value for Formulation and VI	
 * @param context
 * @param args
 * @return
 * @throws Exception
 */
public String getValidDate(Context context, Map mapObjectData, String attrib) throws Exception
{
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	StringValidatorUtil validator = new StringValidatorUtil();
	String strVUD = "";
	try {
		DomainObject doParentSub = DomainObject.newInstance(context);
		String strParentSubId = DomainConstants.EMPTY_STRING;
		
			strVUD = DomainConstants.EMPTY_STRING;
			if(mapObjectData != null && !mapObjectData.isEmpty()){
				strParentSubId = (String)mapObjectData.get(DomainConstants.SELECT_ID);
				
				if(FrameworkUtil.isObjectId(context, strParentSubId)){
					doParentSub.setId(strParentSubId); 
					if(doParentSub.isKindOf(context, FormulationSubstituteConstants.TYPE_PARENT_SUB)){
						strVUD = doParentSub.getAttributeValue(context,attrib );
					}
				}
			}
			if(null==strVUD ||strVUD.isEmpty())
			{
				strVUD="";
			}else{
				strVUD=validator.DateFormatter(strVUD);
			}
	} catch(Exception e)
	{
		throw e;
	}
	return strVUD; 
}
	
	
	
}
