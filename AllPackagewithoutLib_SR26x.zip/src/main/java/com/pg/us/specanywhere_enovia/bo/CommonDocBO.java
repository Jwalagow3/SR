/**
 * Project 		: SpecsAnywhere
 * Program 		: CommonDocBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import com.matrixone.apps.domain.DomainAccess;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.sapbom.pgV3Constants;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.FileUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectAttributesWithUnits;
import matrix.db.BusinessType;
import matrix.db.BusinessTypeItr;
import matrix.db.BusinessTypeList;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.SelectConstants;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class CommonDocBO extends BusinessObject {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(MasterCOPBO.class);
	BusObjectAttribUtil util = new BusObjectAttribUtil();
	public CommonDocBO() {
		// empty constructor
	}

	public CommonDocBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name 			: getDocBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getDocBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getDocDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getDocDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name 			: getSOPPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getSOPPartSelectables(Context context) {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}

	
	/**
	 * Method Name 			: getDefaultPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getDefaultPartSelectables(Context context) {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(getContextObjectBusSelectable(context));
		busSelect.addAll(getPartSpecSelects(context));
		busSelect.addAll(getOrgSelects(context));
		busSelect.addAll(getPlantSelects(context));
		busSelect.addAll(getRelPartsForAtsSelects(context));
		busSelect.addAll(getRelAtsSelects(context));
		busSelect.addAll(getRelAcsSelects(context));
		busSelect.addAll(getRelIapsSelects(context));
		busSelect.addAll(getSecuritySelects(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}


	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public StringList getContextObjectBusSelectable(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_OWNER);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATOR);
		busSelect.add(ConstantsUtil.SELECT_ORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS);
		busSelect.add(ConstantsUtil.STR_TEMPLATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE);
		busSelect.add(ConstantsUtil.OWNERSHIP);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STAGE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_IMPACTEDTYPE);
		busSelect.add(ConstantsUtil.STR_IPCLASS);
		busSelect.add(ConstantsUtil.STRSEGMENT);
		//SPEC: <13.10.2020>: Added for the Release 18x5 -- START--
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTIC);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSSUBTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ATTRIBUTE_IPMS);
		//SPEC: <13.10.2020>: Added for the Release 18x5 -- END
		busSelect.add(ConstantsUtil.STR_FILE_NAME);
		busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		busSelect.add(ConstantsUtil.STR_FILE_SIZE);
		//SPEC: <04.11.2020>: Added for the Release 18x5 -- START--
		busSelect.add(ConstantsUtil.strIntendedMarket);
		//SPEC: <04.11.2020>: Added for the Release 18x5 -- END--
		
		//SPEC: Added for Defect#37301 1.0.2 Release - Amman -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
		//SPEC: Added for Defect#37301 1.0.2 Release - Amman -- END
		
		busSelect.addElement("last.current");
		//SPEC: <01.03.2020>: Chandra Added for 18x.6 development  -- START
		busSelect.add(ConstantsUtil.SELECT_PHYSICAL_ID);
		//SPEC: <01.03.2020>: Chandra Added for 18x.6 development  -- END
		//SPEC: <02.03.2021>: Guna Added for Dev 18x.6   -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES);
		//SPEC: <02.03.2021>: Guna Added for Dev 18x.6   -- END
		//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAUTHORINGAPPLICATION);
		//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- END
		//SPEC: <15.03.2021>: Guna Added for Dev 18x.6   -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREGION);
		//SPEC: <15.03.2021>: Guna Added for Dev 18x.6   -- END
		//SPEC: <22.03.2021>: Guna Added for Defect 40839 Dev 18x.6   -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSPSORIGINATION);
		//SPEC: <22.03.2021>: Guna Added for Defect 40839 Dev 18x.6   -- END
		
		//SPEC: <21.05.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- START
		busSelect.add(ConstantsUtilIRM.SELECT_REL_SUBTYPE);
		//SPEC: <21.05.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- END
			//SPEC: <01.06.2022>: Satyam Added for Req 42769, 34417   -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISATSSPECIFICTOIMPACTEDPARTORSPECREV);
		//SPEC: <01.06.2022>: Satyam Added for Req 42769, 34417    -- END
		//SPEC: <01.06.2022>: Guna Added for Req 36041 22x Release  -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_GPSAPPROVEDBOUNDRY);
		//SPEC: <01.06.2022>: Guna Added for Req 36041 22x Release  -- END
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- START
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MATERIALRESTRICTIONCOMMENTS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_AUTHORINGAPPLICATION);
		//SPEC: <07.03.2023>: Satyam Added for Req 46464 -- END
		//Added by Ajay for Req No. 86913 -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_IRMMATERIALCERTIFICATION);
		//Added by Ajay for Req No. 86913 -- END
		return busSelect;
	}

	
	/**
	 * Method Name 			: getSecuritySelects
	 * Method Description 	: Fetching "Security" related data
	 * @param context
	 * @return
	 */
	public static StringList getSecuritySelects(Context context) {

		StringList busSelect = new StringList(3);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_DESC);
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_STATE);
		busSelect.add(ConstantsUtil.RELATIONSHIP_ACCESS_FROM_DISCONNECT);
		busSelect.add(ConstantsUtil.RELATIONSHIP_SUB_CLASS_NAME);
		//SPEC: <08.06.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- START
        busSelect.add(ConstantsUtilIRM.RELATIONSHIP_ACCESS_FROM_DISCONNECT_SECURITY);
      //SPEC: <08.06.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- END
		return busSelect;
	}
	
	
	
	/**
	 * Method Name 			: getOrgSelects
	 * Method Description 	: Fetching "Organization" related information
	 * @param context
	 * @return
	 */
	public StringList getOrgSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME);
		busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME);
		return busSelect;
	}

	
	/**
	 * Method Name 			: getPlantSelects
	 * Method Description 	: Fetching "Plant" related information
	 * @param context
	 * @return
	 */
	public StringList getPlantSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		//SPEC: <04.11.2020>: Added for the Release 18x5 -- START--
		busSelect.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
		//SPEC: <04.11.2020>: Added for the Release 18x5 -- END--
		return busSelect;
	}


	/**
	 * Method Name : getRelPartsForAtsSelects
	 * Method Description : 
	 * @param context
	 * @return
	 */
	public StringList getRelPartsForAtsSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.REL_ATS_TYPE);
		busSelect.add(ConstantsUtil.REL_ATS_NAME);
		busSelect.add(ConstantsUtil.REL_ATS_STATE);
		busSelect.add(ConstantsUtil.REL_ATS_TITLE);
		busSelect.add(ConstantsUtil.REL_ATS_REV);
		busSelect.add(ConstantsUtil.REL_ATS_ID);
		busSelect.add(ConstantsUtil.REL_ATS_RELEASE_PHASE);
		busSelect.add(ConstantsUtil.REL_ATS_OWNERSHIP);

		return busSelect;
	}


	/**
	 * Method Name 			: getRelAtsSelects
	 * Method Description 	: Fetching "Related ATS" information
	 * @param context
	 * @return
	 */
	public StringList getRelAtsSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.ATL_TYPE);
		busSelect.add(ConstantsUtil.ATL_ID);
		busSelect.add(ConstantsUtil.ATL_NAME);
		busSelect.add(ConstantsUtil.ATL_STATE);
		busSelect.add(ConstantsUtil.ATL_TITLE);
		busSelect.add(ConstantsUtil.ATL_RELEASE_PHASE);

		return busSelect;
	}

	
	/**
	 * Method Name 			: getRelAcsSelects
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public StringList getRelAcsSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ACS_NAME);
		busSelect.add(ConstantsUtil.SELECT_ACS_TYPE);
		busSelect.add(ConstantsUtil.SELECT_ACS_REV);
		busSelect.add(ConstantsUtil.SELECT_ACS_STATE);
		busSelect.add(ConstantsUtil.SELECT_ACS_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ACS_ID);
		busSelect.add(ConstantsUtil.SELECT_ACS_PHASE);
		return busSelect;
	}

	
	/**
	 * Method Name 			: getRelIapsSelects
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public StringList getRelIapsSelects(Context context) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_IAPS_NAME);
		busSelect.add(ConstantsUtil.SELECT_IAPS_TYPE);
		busSelect.add(ConstantsUtil.SELECT_IAPS_REV);
		busSelect.add(ConstantsUtil.SELECT_IAPS_STATE);
		busSelect.add(ConstantsUtil.SELECT_IAPS_TITLE);
		busSelect.add(ConstantsUtil.SELECT_IAPS_ID);
		busSelect.add(ConstantsUtil.SELECT_IAPS_PHASE);

		return busSelect;
	}


	/**
	 * Method Name : getPartSpecSelects
	 * Method Description : Fetching "Part Specifications" data
	 * @param context
	 * @return
	 */
	public static StringList getPartSpecSelects(Context context)
	{
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.STR_PARTSPEC_NAME);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_ID);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_STATE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_IPCLASS);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_TYPE);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_TITLE); 
		busSelect.add(ConstantsUtil.STR_PARTSPEC_ORIGINATOR);
		busSelect.add(ConstantsUtil.STR_PARTSPEC_ATTRIB_SHARING);

		return busSelect;
	}

	
	/**
	 * Method Name 			: addMultiList
	 * Method Description 	:
	 */
	public StringList addMultiList() {

		StringList slMultiSelects = new StringList();

		slMultiSelects.add(ConstantsUtil.REL_ATS_TYPE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_NAME);
		slMultiSelects.add(ConstantsUtil.REL_ATS_STATE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_ID);
		slMultiSelects.add(ConstantsUtil.REL_ATS_TITLE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_REV);
		slMultiSelects.add(ConstantsUtil.OWNERSHIP);
		slMultiSelects.add(ConstantsUtil.REL_ATS_RELEASE_PHASE);
		slMultiSelects.add(ConstantsUtil.REL_ATS_OWNERSHIP);

		slMultiSelects.add(ConstantsUtil.SELECT_ACS_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_REV);
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_STATE);
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_PHASE);
		slMultiSelects.add(ConstantsUtil.SELECT_ACS_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_NAME);
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_TYPE);
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_REV);
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_STATE);
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_TITLE);
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_ID);
		slMultiSelects.add(ConstantsUtil.SELECT_IAPS_PHASE);

		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_NAME);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
		slMultiSelects.add(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);

		slMultiSelects.add(ConstantsUtil.STR_FILE_CAPTURED);
		slMultiSelects.add(ConstantsUtil.STR_FORMAT_FILE);
		slMultiSelects.add(ConstantsUtil.STR_FILE_NAME);

		slMultiSelects.add(ConstantsUtil.STR_FILE_SIZE);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_IRM_PROJECT_NAME);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_IRM_PROJECT_ID);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPE);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOREGULATORYCLASSIFICATION);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ETHNICITYTORACE);
		slMultiSelects.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
		slMultiSelects.add(ConstantsUtilIRM.SELECT_RELATION_PGSTUDYSUPERVISED);
		
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- START
		slMultiSelects.add(ConstantsUtil.ATL_STATE);
		//SPEC: 13-06-2023: Added by Jwala for Defect 53519  -- END
		
		return slMultiSelects;

	}
		
	
		/**
		 * Method Name 			: removeMultiList
		 * Method Description 	: 
		 */
		public void removeMultiList() {
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.OWNERSHIP);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TYPE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_ID);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_STATE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_TITLE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_REV);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_RELEASE_PHASE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.REL_ATS_OWNERSHIP);
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_ID);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_PHASE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_TYPE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_REV);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_STATE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_ACS_TITLE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_TYPE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_REV);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_STATE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_TITLE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_ID);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_IAPS_PHASE);
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_PRODUCE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_VIEW);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_SELECT_PLANT_IS_AUTH_USE);
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FORMAT_FILE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
			
			
			//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--START
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_SIZE);
			//SPEC removeed on 12-Dec-2020 by Chandra for Defect 37723 ##--END
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SELECT_IRM_PROJECT_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SELECT_IRM_PROJECT_ID);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPE);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOREGULATORYCLASSIFICATION);
			//Added on 04/02/2021 by Aditya for Defect 38889 ##--START
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SELECT_RELATIONSHIP_ETHNICITYTORACE);
			//Added on 04/02/2021 by Aditya for Defect 38889 ##--END		
			
			//Added on 04/02/2021 by Aditya for Defect 38892 ##--START
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
			//Added on 04/02/2021 by Aditya for Defect 38892 ##--END
			
			//Added on 10/02/2021 by Aditya for Defect 38711 ##--START
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.SELECT_RELATION_PGSTUDYSUPERVISED);
			//Added on 10/02/2021 by Aditya for Defect 38711 ##--END
			
		}
		
		
		/**
		 * Method Name 			: updateRefDocs
		 * Method Description 	:
		 * @param context
		 * @param resultMaps
		 * @return
		 */
		public Map updateRefDocs(Context context,Map resultMaps,boolean bisIRMDoc) 
		{
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			StringList busSelect = new StringList();
			StringValidatorUtil validator = new StringValidatorUtil();
			
			busSelect.add(ConstantsUtil.SELECT_ID);
			busSelect.add(ConstantsUtil.SELECT_TYPE);
			busSelect.add(ConstantsUtil.SELECT_NAME);
			busSelect.add(ConstantsUtil.SELECT_REVISION);
			busSelect.add(ConstantsUtil.SELECT_OWNER);
			busSelect.add(ConstantsUtil.SELECT_CURRENT);
			busSelect.add(ConstantsUtil.SELECT_DESCRIPTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			busSelect.add(ConstantsUtil.STR_FILE_NAME);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			busSelect.add(ConstantsUtil.STR_IPCLASS);
			busSelect.add(ConstantsUtil.STR_IPCLASS_TYPE);
			//Added by Bala for Defect 38710----START
			busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
			//Added by Bala for Defect 38710----END
			//SPEC: <15.04.2021>: Guna Added for 42439 Defect  Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ACCESSTYPE);
			//SPEC: <15.04.2021>: Guna Added for 42439 Defect  Dev 18x.6   -- END
			

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String strtypeTMS = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

		
		Map<String, String> mpRefDoc = new HashMap();
		//START :: gaikwad.tg :: Defect#38088,36537
		String strNewTypePattern = PropertyUtil.getSchemaProperty(context, "type_DOCUMENTS");
		
		try
		{
			//DomainObject dobCdoc = new DomainObject(sObjectId);
			DomainObject dobCdoc = DomainObject.newInstance(context, sObjectId);
			MapList mlRelatedSpecs = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					strNewTypePattern, busSelect, new StringList(), false, true, (short) 1,
					"current != Obsolete", ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//Modified for Defect #39153 - END
			
			//START :: gaikwad.tg :: Defect#38521
			String strProtocolType = DomainConstants.EMPTY_STRING;
			boolean isStabilityReport = dobCdoc.isKindOf(context, PropertyUtil.getSchemaProperty("type_pgPKGStabilityReport"));
			boolean isValidationReport = dobCdoc.isKindOf(context, PropertyUtil.getSchemaProperty("type_pgPKGValidationReport"));
			if(isValidationReport || isStabilityReport)
			{
				strProtocolType = isStabilityReport ? PropertyUtil.getSchemaProperty("type_pgPKGStabilityProtocol") : PropertyUtil.getSchemaProperty("type_pgPKGValidationProtocol");
				MapList documentListProtocol = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT, strProtocolType, busSelect, new StringList(), true, false, (short)1,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				mlRelatedSpecs.addAll((Collection)documentListProtocol);
			}
			//END :: gaikwad.tg :: Defect#38521
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
			dobCdoc.close(context);
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
			Iterator objectListItr = mlRelatedSpecs.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType=new StringBuilder();
			StringBuilder sbRev=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbDescription=new StringBuilder();
			StringBuilder sbTitle=new StringBuilder();
			StringBuilder sbLangBuffer = new StringBuilder();
			//StringBuilder sbSource = new StringBuilder();
			StringBuilder sbGendocName = new StringBuilder();
			StringBuilder sbGendocPath = new StringBuilder();
			StringBuilder sbIsIRM = new StringBuilder();
			StringBuilder sbGendocFormat = new StringBuilder();
			SecurityService sct = new SecurityService();
			CommonDocBO commonDoc = new CommonDocBO();
			FileUtil fileUtil = new FileUtil();
			
			String sName = ConstantsUtil.EMPTY_STRING;
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sType    =  (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sId		=	(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sCurrent	=	(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev		=	(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sDesc	=	(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);
				String sTitle	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				//SPEC:  Modified for  Defect 37239 on 02/03/2021 by Chandra -- START
				//String sSource = util.getSource(context, sId);
				//SPEC:  Modified for  Defect 37239 on 02/03/2021 by Chandra -- END
				
				String sPGLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
				String sPGCSSType	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
				String sPLangBuffer	=	(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_LANGUAGE);
				String sLangBuffer =ConstantsUtil.EMPTY_STRING;
				//SPEC: <15.04.2021>: Guna Added for 42439 Defect  Dev 18x.6   -- START
				String sAccessType =(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ACCESSTYPE);
				//SPEC: <15.04.2021>: Guna Added for 42439 Defect  Dev 18x.6   -- END
				//DomainObject doObj = new DomainObject(sId);
				DomainObject doObj = DomainObject.newInstance(context, sId);
				Map mpFiles = new HashMap();
				String sGendocName = "";
				String sGendocPath = "";
				String sGendocPathFormat = "";
				bisIRMDoc = commonDoc.isIRMDoc(sType);
				String strIPMDoc = sType;
				
				if( !sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR) && !sType.equals(ConstantsUtil.TYPE_PLMPARAMETER) && !sType.equalsIgnoreCase(ConstantsUtil.TYPE_TRANSPORT_CHAR))
				{
					if (util.isModificatinRequired()) {
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_EXISTS)) {
							continue;
						}
					}
						if((sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) && sRev.equalsIgnoreCase("Rendition"))) {
							continue;
						}
						//SPEC: <01.22.2021>: Modified for Defect:38156 & 38209 by Sumit --START
						//Modified for Defect #38156 - START 
						if(sType.equals(ConstantsUtil.TYPE_PGPKGTRANSLATIONFILE))
						//Modified for Defect #38156 - END
							sLangBuffer=sPGLangBuffer;
						else 
							sLangBuffer=sPLangBuffer;
						//SPEC: <01.22.2021>: Modified for Defect:38156 & 38209 by Sumit --ENDS
						if("Reference_File".equalsIgnoreCase(sPGCSSType) || "Reference File".equalsIgnoreCase(sPGCSSType)){
							sType = "Reference File";
						}else if("QEC_File".equalsIgnoreCase(sPGCSSType)){
							sType="Quality Evolution Chart File";
							//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
						}else if("Design_File".equalsIgnoreCase(sPGCSSType) || "Design File".equalsIgnoreCase(sPGCSSType)){
							sType="Design File";
						}else if("Language_Rendition".equalsIgnoreCase(sPGCSSType)){
							sType="Language Rendition";
						}else if("Translation File".equalsIgnoreCase(sPGCSSType) || "Translation_File".equalsIgnoreCase(sPGCSSType)){
							sType="Translation File";
						}
						if(bisIRMDoc) {
							mpFiles=fileUtil.getGendocForIRM(context, doObj);
							sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
							sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
						}else {
							mpFiles = fileUtil.getFilesForIPM(context, doObj);
							sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_NAME));
							sGendocPath=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
							sGendocPathFormat = validator
									.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtil.STR_FORMAT_FILE));
						}
						doObj.close(context);
						boolean showData = util.checkHasAccess(context, null, sId);
						if(!sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_EXISTS)) {
							sId = ConstantsUtil.EMPTY_STRING;
						}
						sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
						//SPEC: <16.04.2021>: Guna Added for 42500 Defect Dev 18x.6   -- START
						if(strIPMDoc.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)){
							if (sName.contains("LR_")) {
								sLangBuffer = sRev;
							}
							else {
								sLangBuffer = "";
							}
					       }
						//SPEC: <16.04.2021>: Guna Added for 42500 Defect Dev 18x.6   -- END
						//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- START
						if(!bisIRMDoc){
							sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_FILE_NAME));
						}
						//SPEC: Release SR18x.5.2 - Added for Defect# 39561  by Guna on Date 12/02/2021 -- END
						
						if(!bisIRMDoc && !sAccessType.isEmpty() && !util.isModificatinRequired()){
						        if(sAccessType.equals(ConstantsUtilIRM.INHERITED)){
						        	showData =true;
						        }
						}
						//SPEC: <15.04.2021>: Guna Modified for 42439 Defect Dev 18x.6   -- END
						
						//SPEC: <26.03.2021>: Guna Added for Defect 41829 Dev 18x.6   -- END
						//Modified by Bala for Defect #38710 & #39065----END
						
						// SPEC: Modified by Ketan for Internal Defect
						if(!showData) {
							sId=ConstantsUtil.EMPTY_STRING;
							//sSource=ConstantsUtil.NO_ACCESS;
							sDesc=ConstantsUtil.NO_ACCESS;
							sTitle=ConstantsUtil.NO_ACCESS;
							sLangBuffer=ConstantsUtil.NO_ACCESS;
							sCurrent=ConstantsUtil.NO_ACCESS;
							sRev=ConstantsUtil.NO_ACCESS; //Added by Ketan for Internal Defect
						}
						//Modified by Bala for Defect 38710----END
						
						//SPEC: <26.03.2021>: Guna Modified for Defect 41768 Dev 18x.6   -- START
						if(!strIPMDoc.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT)){
						sType = util.mapType(sType);
						}
						//SPEC: <26.03.2021>: Guna Modified for Defect 41768 Dev 18x.6   -- END
						
						//SPEC: Release SR18x.6.0.1 - Added by Amman on May 06, 2021 for Req #33248 -- START
						if (util.isModificatinRequired()) {
							if(!showData) {
								continue;
							}
							if(!sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_EXISTS)) {
								continue;
							}
						}
						//SPEC: Release SR18x.6.0.1 - Added by Amman on May 06, 2021 for Req #33248 -- END
						if (bisIRMDoc && !showData)
						{
							sId=ConstantsUtil.EMPTY_STRING;
						}
						util.formatData(sbType,sType);
						util.formatData(sbName,sName);
						util.formatData(sbDescription,sDesc);
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbId,sId);
						util.formatData(sbRev,sRev);
						util.formatData(sbTitle,sTitle);
						//util.formatData(sbSource,sSource);
						util.formatData(sbLangBuffer,sLangBuffer);
						util.formatData(sbGendocName,sGendocName);
						util.formatData(sbGendocPath,sGendocPath);
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						util.formatData(sbGendocFormat, sGendocPathFormat);
					}
			}
			
				//mpRefDoc.put(ConstantsUtil.COMMONSOURCE, sbSource.toString());//Commented by Ketan for Req. no. 47200
				mpRefDoc.put(ConstantsUtil.LANGUAGE, sbLangBuffer.toString());
				mpRefDoc.put(ConstantsUtil.REVISION, sbRev.toString());
				mpRefDoc.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
				mpRefDoc.put(ConstantsUtil.NAME, sbName.toString());
				mpRefDoc.put(ConstantsUtil.TITLE, sbTitle.toString());
				mpRefDoc.put(ConstantsUtil.TYPE, sbType.toString());
				mpRefDoc.put(ConstantsUtil.STATE, sbCurrent.toString());
				mpRefDoc.put(ConstantsUtil.ID, sbId.toString());
				mpRefDoc.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
				mpRefDoc.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
				mpRefDoc.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
				mpRefDoc.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());

		}catch(Exception e){

			LOGGER.error("Exception in Program : CommonDocBO Method :updateRefDocs "+e);
			return new HashMap();
		}

		return util.filterMapList(mpRefDoc);
	}


	/**
	 * Method Name 			: validateRelatedParts
	 * Method Description 	: It will Validates the Related Parts
	 * @param context
	 * @param mpRelatedParts
	 * @return
	 */

	public Map<String, String> validateRelatedParts(Context context ,Map<String, String> mpRelatedParts) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		boolean bHasOwnerShip=false;
		StringList sbFinalIndex = new StringList();
		try
		{
			SecurityService sec = new SecurityService();
			String sComp = sec.getUserCauthorities();
			StringList slsComp=util.filterOwnerShip(sComp);
			
			String	sType =validator.isNotNullOrEmpty((String)mpRelatedParts.get(ConstantsUtil.TYPE))?(String)mpRelatedParts.get(ConstantsUtil.TYPE) : ConstantsUtil.EMPTY_STRING;
			String	sChildOwnerShip= validator.isNotNullOrEmpty((String)mpRelatedParts.get(ConstantsUtil.OWNERSHIP))?(String)mpRelatedParts.get(ConstantsUtil.OWNERSHIP) : ConstantsUtil.EMPTY_STRING;
			String[] saChildOwnerShip =sChildOwnerShip.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			String[] saType =sType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			//added by Ganesh for security impl----start
            String	strObjectId =validator.isNotNullOrEmpty((String)mpRelatedParts.get(ConstantsUtil.SELECT_ID))?(String)mpRelatedParts.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			
			String[] saIDs =strObjectId.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			//added by Ganesh for security impl----start

			for (int i = 0; i < saChildOwnerShip.length; i++) 
			{
				if (UIUtil.isNotNullAndNotEmpty(saChildOwnerShip[i]))
				{
					//bHasOwnerShip=util.checkOwnerShip(context,slsComp,saChildOwnerShip[i]);
					//modified by Ganesh for security impl------>start
					bHasOwnerShip = util.checkHasAccess(context, null, saIDs[i]);
					//modified by Ganesh for security impl------>end
					if(!bHasOwnerShip) 
						sbFinalIndex.add(String.valueOf(i));
				}
			}
			if (sbFinalIndex.size()!=0)
			{
				mpRelatedParts=util.filterRelatedPartObjects(sbFinalIndex,mpRelatedParts);
			}

		}catch(Exception e){
			LOGGER.error("Exception in Program : CommonDocBo Method :validateRelatedParts "+e);
			return new HashMap();
		}	


		return mpRelatedParts;
	}

	/**
	 * Method Name 			: validateRelatedATS
	 * Method Description 	: It will Validates the Related ATS
	 * @param context
	 * @param mpRelatedParts
	 * @return
	 */

	public Map<String, String> validateRelatedATS(Context context ,Map<String, String> mpRelatedATS) {
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		boolean bHasOwnerShip=false;
		StringList sbFinalIndex = new StringList();
		try
		{
			SecurityService sec = new SecurityService();
			String sComp = sec.getUserCauthorities();
			StringList slsComp=util.filterOwnerShip(sComp);
			
			String	sType =validator.isNotNullOrEmpty((String)mpRelatedATS.get(ConstantsUtil.TYPE))?(String)mpRelatedATS.get(ConstantsUtil.TYPE) : ConstantsUtil.EMPTY_STRING;
			String	strObjectId =validator.isNotNullOrEmpty((String)mpRelatedATS.get(ConstantsUtil.SELECT_ID))?(String)mpRelatedATS.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			
			String[] saIDs =strObjectId.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

			for (int i = 0; i < saIDs.length; i++) 
			{
				if (UIUtil.isNotNullAndNotEmpty(saIDs[i]))
				{
					//modified by Ganesh for security impl------>start
					//bHasOwnerShip=util.checkOwnerShip(context,slsComp,saIDs[i]);
					bHasOwnerShip = util.checkHasAccess(context, null, saIDs[i]);
					//modified by Ganesh for security impl------>end
					
					if(!bHasOwnerShip) 
						sbFinalIndex.add(String.valueOf(i));
				}
			}
			if (sbFinalIndex.size()!=0)
			{
				mpRelatedATS=util.filterRelatedPartObjects(sbFinalIndex,mpRelatedATS);
			}

		}catch(Exception e){
			LOGGER.error("Exception in Program : CommonDocBo Method :validateRelatedATS "+e);
			return new HashMap();
		}	

		return mpRelatedATS;
	}

	/**
	 * Method Name 			: getPartSpecs
	 * Method Description 	: Fetching "Part Specifications" details
	 * @param context
	 * @param resultMaps
	 * @param sType
	 * @return
	 */
	public Map<String, String> getPartSpecs(Context context, Map resultMaps, String sType) {
		StringValidatorUtil validator = new StringValidatorUtil();
        String partId = (String) resultMaps.get(ConstantsUtil.ID);                  
        MapList relatedPartSpecsList = new MapList();
        StringList slParentOwnerShip = new StringList();
        StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType=new StringBuilder();
		StringBuilder sbRev=new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbDescription=new StringBuilder();
		StringBuilder sbTitle=new StringBuilder();
		StringBuilder sbOriginator=new StringBuilder();
		//StringBuilder sbOriginatingSrc=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		StringBuilder sbSpecSubType=new StringBuilder();
		
        Map mpPartSpecResult = new HashMap();
        StringList slHIRTypes = new StringList();
		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		//SPEC: 23/04/2021: Added for 18x.6 Defect-42534 by Guna -- START
		slHIRTypes.addElement("last.current");
		slHIRTypes.addElement("last.id");
	     //SPEC: 23/04/2021: Added for 18x.6 Defect-42534 by Guna -- END
        try
        {
        	
        	SecurityService ss = new SecurityService();
			String sUserCompanies = ss.getUserCauthorities();
			String[] aCompany = sUserCompanies.split(",");
			StringBuilder sbCompany = new StringBuilder();
			
			boolean bHasOwnerShip = false;
			if(aCompany.length>-1) {
				for(int i=0;i<aCompany.length;i++) {
					if(null!=aCompany[i]) {
						String Company = aCompany[i].toString();
						sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					}
				}
			}


			DomainObject aTSpartObj =  DomainObject.newInstance(context, partId) ;
			StringList selectStmts =getContextObjectBusSelectable(context);                     // putting elements to StringList
			StringList selectRelStmts = new StringList(2);
			selectRelStmts.addElement(DomainConstants.SELECT_RELATIONSHIP_ID); // Relationship Selects
			selectRelStmts.addElement(DomainConstants.SELECT_RELATIONSHIP_NAME);
			// Retrieving related item
			Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION);

			Pattern typePattern = new Pattern("");
			StringList slAllowedObjectList = new StringList();
			slAllowedObjectList = FrameworkUtil.split(ConstantsUtil.IMPACTED_TYPES_SPECS,ConstantsUtil.SYMBL_COMMA);
			if(!slAllowedObjectList.isEmpty() && slAllowedObjectList != null)
			{
				for(int j = 0 ; j<slAllowedObjectList.size() ; j++ )
				{
					String strAllowedType = PropertyUtil.getSchemaProperty(context,(String)slAllowedObjectList.get(j));
					if(!typePattern.match(strAllowedType))
					{
						typePattern.addPattern(strAllowedType);
					}
				}
			}
			//String sWhere=ConstantsUtil.EMPTY_STRING;
			//SPEC: <27.01.2020>: Modified for Defect :38383 & 38424 --START
			//sWhere = "current==Release";
			//sWhere = "revision==last && (current==Release || current==Obsolete)";
			//SPEC: <27.01.2020>: Commented for Defect :38383 & 38424 --START
			//sWhere = "revision==last || (current==Release || current==Obsolete)";
			//SPEC: <27.01.2020>: Commented for Defect :38383 & 38424 --START
			//SPEC: <27.01.2020>: Modified for Defect :38383 & 38424 --END
			
			//SPEC: 23/04/2021: Modified for 18x.6 Defect-42534 by Guna -- START
			relatedPartSpecsList = aTSpartObj.getRelatedObjects(context,
					relPattern.getPattern(),  //relationship pattern 
					typePattern.getPattern(), // object pattern
					selectStmts,                 // object selects
					selectRelStmts,              // relationship selects
					false,                        // to direction
					true,                       // from direction
					(short)1,                    // recursion level
					"latest==True",//null,                        // object where clause
					null,
					0);
			//SPEC: 23/04/2021: Modified for 18x.6 Defect-42534 by Guna -- END
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
			aTSpartObj.close(context);
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
			//SPEC: 23/04/2021: Added for 18x.6 Defect-42534 by Guna -- START
			HashMap tempMap = new HashMap<>();
			relatedPartSpecsList.sort(ConstantsUtil.SELECT_CURRENT, "descending", "string");
			//SPEC: 23/04/2021: Added for 18x.6 Defect-42534 by Guna -- END
			boolean isExternal=util.isModificatinRequired();
			SecurityService sec = new SecurityService();

			String	 sParentOwnerShip =  sec.getUserCauthorities();
			if(isExternal){
				slParentOwnerShip = util.filterOwnerShip(sParentOwnerShip);
				relatedPartSpecsList=util.filterPhase(relatedPartSpecsList);
			}
			Iterator objectListItr = relatedPartSpecsList.iterator();

			StringList slObjectOwnership = new StringList();
			while(objectListItr.hasNext()) 
			{

				Map objectMap = (Map) objectListItr.next();
				String strId = (String)objectMap.get(ConstantsUtil.SELECT_ID);
				String strState = (String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String strType = (String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sIPClassfication=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
				/*String soriginatingSource=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				if(soriginatingSource.equalsIgnoreCase("DSO")) {
					soriginatingSource=ConstantsUtil.SOURCE_DIRECT;
				}*/
				String soriginator=(String)objectMap.get(ConstantsUtil.SELECT_ORIGINATOR);
				String sPhase=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 41741 on Date 29/03/2021 --START
				//String specSubType=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBTYPE);
				String specSubType = util.UpdateSpecSubType(context, strId);
				//SPEC: Release SR18x.6. Modified by Dominic for Defect 41741 on Date 29/03/2021 --END
				String sOwnership =validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.OWNERSHIP));
				
				//SPEC: <27.01.2020>: Added for Defect :38383 & 38424 --START
				String strPreviousRev =validator.getStringEquivalentForStringList( objectMap.get("last.current"));

				//SPEC: 23/04/2021: Added for 18x.6 Defect-42534 by Guna -- START
				String sPartName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.NAME)));
				if(tempMap != null && !tempMap.isEmpty() && tempMap.containsKey(sPartName))
				continue;
				
				if(!tempMap.containsKey(sPartName))
				tempMap.put(sPartName, strState);
				//SPEC: 23/04/2021: Added for 18x.6 Defect-42534 by Guna -- END
				
				//SPEC: Modififed for Defect :38384 by Jwala --START
				if(!strState.equals(ConstantsUtil.STATE_RELEASE) && (!strState.equals(ConstantsUtil.STATE_OBSOLETE))){
					if(!strPreviousRev.equals(ConstantsUtil.STATE_OBSOLETE)){
						continue;
					}
					//SPEC: 23/04/2021: Added for 18x.6 Defect-42534 by Guna -- START
					else
						strId = validator.getStringEquivalentForStringList( objectMap.get("last.id"));
					//SPEC: 23/04/2021: Added for 18x.6 Defect-42534 by Guna -- END
				}
				//SPEC: : Modififed for Defect :38384 by Jwala --END
				
				//SPEC: <27.01.2020>: Added for Defect :38383 & 38424 --END
				if(isExternal)
				{
					//SPEC: <12.03.2020>: Shashank Commented for Defect :37597 ## --START
					/*	slObjectOwnership=util.filterOwnerShip(sOwnership);
					bHasOwnerShip = util.checkOwnerShip(sbCompany,slObjectOwnership);*/
					//SPEC: <12.03.2020>: Shashank Commented for Defect :37597 ## --End

					bHasOwnerShip=util.checkHasAccess(context,ss.getUserType(),strId);
					
					//SPEC: Release SR18x.6.0 - Added by Amman on Mar 22, 2021 for Req 38550 -- START
					if(strState.equals(ConstantsUtil.STATE_RELEASE)||strState.equals(ConstantsUtil.RELEASED)) {
					//SPEC: Release SR18x.6.0 - Added by Amman on Mar 22, 2021 for Req 38550 -- END
						
						if(bHasOwnerShip) 
						{
							util.formatData(sbId,(String)objectMap.get(ConstantsUtil.SELECT_ID));
							util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
							strType=util.mapType(strType);
							util.formatData(sbType,strType);
							util.formatData(sbRev,(String)objectMap.get(ConstantsUtil.SELECT_REVISION));
							util.formatData(sbDescription,(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
							util.formatData(sbTitle,(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							util.formatData(sbCurrent,(String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
							util.formatData(sbPhase,sPhase);
							util.formatData(sbSpecSubType,specSubType);
							if(("MI").equalsIgnoreCase(sType) || ("PROS").equalsIgnoreCase(sType) || ("LIS").equalsIgnoreCase(sType) || ("ATS").equalsIgnoreCase(sType)) {//Modified by Ketan for Defect no. 53233
								util.formatData(sbOriginator,soriginator);
								//util.formatData(sbOriginatingSrc,soriginatingSource);
							}else{
								util.formatData(sbOriginator,ConstantsUtil.EMPTY_STRING);
								//util.formatData(sbOriginatingSrc,soriginatingSource);
							}
						}else
						{
							//SPEC: Release SR18x.6.0.1 - Added by Amman on May 06, 2021 for Req #33248 -- START
							/*
							util.formatData(sbId,ConstantsUtil.NO_ACCESS);
							util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
							strType=util.mapType(strType);
							util.formatData(sbType,strType);
							util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
							util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
							util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
							util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
							util.formatData(sbOriginator,ConstantsUtil.NO_ACCESS);
							util.formatData(sbOriginatingSrc,ConstantsUtil.NO_ACCESS);
							*/
							continue;
							//SPEC: Release SR18x.6.0.1 - Added by Amman on May 06, 2021 for Req #33248-- END
						}
					//SPEC: Release SR18x.6.0 - Added by Amman on Mar 22, 2021 for Req 38550 -- START	
					}
					//SPEC: Release SR18x.6.0 - Added by Amman on Mar 22, 2021 for Req 38550 -- END
				}else 
				{
					boolean showData=true;
					//SPEC: <12.03.2020>: Shashank Commented for Defect :37597 ## --START
					/*SecurityService sct = new SecurityService();
				String sUserlicense = sct.getUserLicense();
				String sClassification = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.STR_IPCLASS));
				if(ss.isStaffAUGUser()) {
					if(null!=sUserlicense && null!=sClassification && !sUserlicense.contains(sClassification)) {
						showData=false;
					}
					String sFormulaClassif =sClassification;
					if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
						showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
					}else {
						showData=util.checkInternalUserAcess(sUserlicense,sClassification);
					}
				}else {
					if(slHIRTypes.contains(strType))
					{
						String sFormulaClassif =sClassification;
						if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaClassif = util.getFormulaPropagateClassification(context, strId);
							showData=util.checkInternalUserAcess(sUserlicense,sFormulaClassif);
						}else {
							showData=util.checkInternalUserAcess(sUserlicense,sClassification);
						}
					}else{
						showData=true;
					}
					if(sIPClassfication.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED)) {
						if(null!=sUserlicense && null!=sClassification && !sUserlicense.contains(sClassification)) {
							showData=false;
						}
					}
				}*/
					//SPEC: <12.03.2020>: Shashank Commented for Defect :37597 ## --END
					//SPEC: <12.03.2020>: Shashank Modified for Defect :37597 ## --START
					showData = util.checkHasAccess(context,ss.getUserType(),strId);
					//SPEC: <12.03.2020>: Shashank Modified for Defect :37597 ## --END


					if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
						strId=ConstantsUtil.NO_ACCESS;
					}

					if(showData) 
					{
						//util.formatData(sbId,(String)objectMap.get(ConstantsUtil.SELECT_ID));
						sbId.append(strId).append(ConstantsUtil.SYMBL_PIPE);
						util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
						strType=util.mapType(strType);
						util.formatData(sbType,strType);
						util.formatData(sbRev,(String)objectMap.get(ConstantsUtil.SELECT_REVISION));
						util.formatData(sbDescription,(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
						util.formatData(sbTitle,(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						util.formatData(sbCurrent,(String)objectMap.get(ConstantsUtil.SELECT_CURRENT));
						util.formatData(sbPhase,sPhase);
						util.formatData(sbSpecSubType,specSubType);
						//SPEC: Release SR18x.5.2 - Modified for Defect #39207 by Bala on Date Feb 14, 2021 -- START
						//if(sType.equalsIgnoreCase("MI") || sType.equalsIgnoreCase("PROS") || sType.equalsIgnoreCase("LIS")) {
						if(sType.equalsIgnoreCase("MI") || sType.equalsIgnoreCase("PROS") || sType.equalsIgnoreCase("LIS") || sType.equalsIgnoreCase("ATS")) {
							//SPEC: Release SR18x.5.2 - Modified for Defect #39207 by Bala on Date Feb 14, 2021 -- END
							util.formatData(sbOriginator,soriginator);
							//util.formatData(sbOriginatingSrc,soriginatingSource);
						}else{
							util.formatData(sbOriginator,ConstantsUtil.EMPTY_STRING);
							//util.formatData(sbOriginatingSrc,soriginatingSource);
						}
					}else 
					{
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbName,(String)objectMap.get(ConstantsUtil.SELECT_NAME));
						strType=util.mapType(strType);
						util.formatData(sbType,strType);
						util.formatData(sbRev,ConstantsUtil.NO_ACCESS);
						util.formatData(sbDescription,ConstantsUtil.NO_ACCESS);
						util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
						util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
						util.formatData(sbPhase,ConstantsUtil.NO_ACCESS);
						util.formatData(sbSpecSubType,ConstantsUtil.NO_ACCESS);
						util.formatData(sbOriginator,ConstantsUtil.NO_ACCESS);
						//util.formatData(sbOriginatingSrc,ConstantsUtil.NO_ACCESS);
					}
				}
			}//While
			mpPartSpecResult.put(ConstantsUtil.ID, sbId.toString());
			mpPartSpecResult.put(ConstantsUtil.NAME, sbName.toString());
			mpPartSpecResult.put(ConstantsUtil.TYPE, sbType.toString());
			mpPartSpecResult.put(ConstantsUtil.REVISION, sbRev.toString());
			mpPartSpecResult.put(ConstantsUtil.DESCRIPTION, sbDescription.toString());
			mpPartSpecResult.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpPartSpecResult.put(ConstantsUtil.STATE, sbCurrent.toString());
			//SPEC: <12.03.2020>: Shashank Added for Defect :37597 ## --START
			//mpPartSpecResult.put(ConstantsUtil.SOURCE, sbOriginatingSrc.toString());//Commented by Ketan for Req. no. 47200
			//SPEC: <12.03.2020>: Shashank Added for Defect :37597 ## --END

			//SPEC: Release SR18x.5.2 - Added for Defect #39207 by Bala on Date Feb 14, 2021 -- START
			mpPartSpecResult.put(ConstantsUtil.ORIGINATOR, sbOriginator.toString());
			//SPEC: Release SR18x.5.2 - Added for Defect #39207 by Bala on Date Feb 14, 2021 -- END
			//SPEC: Release SR18x.6. Added by Dominic for Defect 41741 on Date 29/03/2021 --START
			mpPartSpecResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
			//SPEC: Release SR18x.6. Added by Dominic for Defect 41741 on Date 29/03/2021 --END

			mpPartSpecResult=util.filterMapList(mpPartSpecResult);
		}catch(Exception e)
		{
			LOGGER.error("Exception in Program : CommonDocBo Method :getPartSpecs "+e);
			return new HashMap();
		}
		return mpPartSpecResult ;
	}


	/**
	 * Method Name : getRelatedParts
	 * Method Description : Fetching "Related Part" details
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map<String, String> getRelatedParts(Context context, Map resultMaps) {
		StringValidatorUtil validator = new StringValidatorUtil();
        String partId = (String) resultMaps.get(ConstantsUtil.ID);                  
        MapList relatedPartList = new MapList();
        Map mpRelatedParts = new HashMap();
        
        StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType=new StringBuilder();
		StringBuilder sbRev=new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbTitle=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
		StringBuilder sbHasFile=new StringBuilder();
		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END		
		
		
		 StringList selectStmts = new StringList();                     
         selectStmts.add(ConstantsUtil.TYPE);
         selectStmts.add(ConstantsUtil.NAME);
         selectStmts.add(ConstantsUtil.SELECT_CURRENT);
         selectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
         selectStmts.add(ConstantsUtil.SELECT_REVISION);
         selectStmts.add(ConstantsUtil.ID);
         selectStmts.add(ConstantsUtil.OWNERSHIP);
         selectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
         selectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
         selectStmts.add(ConstantsUtil.STR_IPCLASS);
         selectStmts.add(ConstantsUtil.STR_IPCLASS_TYPE);
         selectStmts.add("last.current");
       //SPEC: Release SR18x.6.0 - Added for Defect# 42534  by gaikwad.tg on Date 19 April 2021 -- START
         selectStmts.add("last.id");
       //SPEC: Release SR18x.6.0 - Added for Defect# 42534  by gaikwad.tg on Date 19 April 2021 -- END
       //SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
         selectStmts.add(ConstantsUtil.STR_FILE_CAPTURED);
       //SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
         
         boolean isHir=false;
         StringList selectRelStmts = new StringList(2);
         selectRelStmts.add(DomainConstants.SELECT_RELATIONSHIP_ID); 
         selectRelStmts.add(DomainConstants.SELECT_RELATIONSHIP_NAME);
         Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION);
         SecurityService sct = new SecurityService();
		 String sUserlicense = sct.getUserLicense();
		 boolean showData = false;
		boolean bHasOwnerShip = false;
		//String sWhere =ConstantsUtil.EMPTY_STRING;
		//defect 36014 - only Released data must be accessible to users
		//if(util.isModificatinRequired()){
			//sWhere ="current==Release";
		//}
		
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		
		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}
		
		
        try
        {
        	 	DomainObject aTSpartObj =  DomainObject.newInstance(context, partId) ;
	           
	            Pattern typePattern = new Pattern("");
	            StringList slAllowedObjectList = new StringList();
	            slAllowedObjectList = FrameworkUtil.split(ConstantsUtil.IMPACTED_TYPES_PARTS,ConstantsUtil.SYMBL_COMMA);
	            if(!slAllowedObjectList.isEmpty() && slAllowedObjectList != null)
				{
		            for(int j = 0 ; j<slAllowedObjectList.size() ; j++ )
		    		{
		    			String strAllowedType = PropertyUtil.getSchemaProperty(context,(String)slAllowedObjectList.get(j));
		    			if(!typePattern.match(strAllowedType))
						{
		    				typePattern.addPattern(strAllowedType);
						}
		    		}
				}
	            
				//String sUserProjectlicense = sct.getProjectLicenses();
	            relatedPartList = aTSpartObj.getRelatedObjects(context,
	                    relPattern.getPattern(),  //relationship pattern 
	                    typePattern.getPattern(), // object pattern
	                    selectStmts,                 // object selects
	                    selectRelStmts,              // relationship selects
	                    false,                        // to direction
	                    true,                       // from direction
	                    (short)1,   	// recursion level
	                 //<SPEC> 02/02/2021: Modified from sWhere to null for Defect#38407
	                  //SPEC: Release SR18x.6.0 - Added for Defect# 42534  by gaikwad.tg on Date 19 April 2021 -- START ::ADDED where Clause instead of null
	                    "latest==True",//sWhere,                        // object where clause
	                    null,
	                    0);
	          //SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
				aTSpartObj.close(context);
				//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
	          //SPEC: Release SR18x.6.0 - Added for Defect# 42534  by gaikwad.tg on Date 19 April 2021 -- START
				HashMap tempMap = new HashMap<>();
				relatedPartList.sort(ConstantsUtil.SELECT_CURRENT, "descending", "string");
				//SPEC: Release SR18x.6.0 - Added for Defect# 42534  by gaikwad.tg on Date 19 April 2021 -- END
	            
	            Iterator objectListItr = relatedPartList.iterator();
				String sPartId= ConstantsUtil.EMPTY_STRING;
				StringList slHIRTypes = new StringList();
				slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
				slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
				slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
			while(objectListItr.hasNext()) 
			{

				Map objectMap = (Map) objectListItr.next();
			            
		        String sPartType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.TYPE)));
		        if(slHIRTypes.contains(sPartType)) {
		        	isHir=true;
		        }
				String sPartName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.NAME)));
				String sPartState = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_CURRENT)));
				
				//SPEC: Release SR18x.6.0 - Added for Defect# 42534  by gaikwad.tg on Date 19 April 2021 -- START
				if(tempMap != null && !tempMap.isEmpty() && tempMap.containsKey(sPartName))
				continue;
				
				if(!tempMap.containsKey(sPartName))
				tempMap.put(sPartName, sPartState);
				//SPEC: Release SR18x.6.0 - Added for Defect# 42534  by gaikwad.tg on Date 19 April 2021 -- END
				
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 23, 2021 for Defect 41409 -- START
				//String sPartTitle = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
				String sPartTitle = validator.getStringEquivalentForStringListWithComma((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
				//SPEC: Release SR18x.6.0 - Added by Amman on Mar 23, 2021 for Defect 41409 -- END
				
				String sPartRev = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_REVISION)));
				sPartId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.ID)));
				String sPartOwnership = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.OWNERSHIP)));
				
				String strClassFied = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.STR_IPCLASS));
				String sPartClassType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS_TYPE)));
				
				String sIPClassfication = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String sPhase = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));
				
				//SPEC: Added for Defect :39775 --START
				//SPEC: Modififed for Defect :39834 by Jwala --START
				String strPreviousRev =validator.getStringEquivalentForStringList( objectMap.get("last.current"));
				if(!sPartState.equals(ConstantsUtil.STATE_RELEASE) && (!sPartState.equals(ConstantsUtil.STATE_OBSOLETE))){
					if(!strPreviousRev.equals(ConstantsUtil.STATE_OBSOLETE)){
						continue;
					}
					//SPEC: Release SR18x.6.0 - Added for Defect# 42534  by gaikwad.tg on Date 19 April 2021 -- START
					else
					sPartId = validator.getStringEquivalentForStringList( objectMap.get("last.id"));
					//SPEC: Release SR18x.6.0 - Added for Defect# 42534  by gaikwad.tg on Date 19 April 2021 -- END
				}
				//SPEC: Modififed for Defect :39834 by Jwala --START
				//SPEC:Added for Defect :39775 ---END
				
				//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
				String sHasFileAttached = ConstantsUtil.FALSE;
				String sGendocPath=validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.STR_FILE_CAPTURED));				
				//SPEC: <19.04.2021>: Guna Modified for 42490 Defect  Dev 18x.6   -- START
				String TYPE_EXTERNAL_MATERIAL= PropertyUtil.getSchemaProperty("type_ExternalMaterial");
				
				//if(sGendocPath.length()>1) // since | is added by default
				if(!sPartType.equals(ConstantsUtil.TYPE_INTERNAL_MATERIAL) || !sPartType.equals(ConstantsUtil.TYPE_QUALIFICATION) || !sPartType.equals(TYPE_EXTERNAL_MATERIAL))
				{
					
					sHasFileAttached = ConstantsUtil.TRUE;					
				}	
				//SPEC: <19.04.2021>: Guna Modified for 42490 Defect  Dev 18x.6   -- END
				
				//SPEC: Release SR18x.6.0.1 - Added by Amman on June 21, 2021 for Updated Req #38549 -- START
				if (!util.isModificatinRequired()) {
				//SPEC: Release SR18x.6.0.1 - Added by Amman on June 21, 2021 for Updated Req #38549 -- END
				
					util.formatData(sbHasFile,sHasFileAttached);
					//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END

					util.formatData(sbName,sPartName);
					//sPartType=util.mapType(sPartType);
					util.formatData(sbType,util.mapType(sPartType));
					util.formatData(sbPhase,sPhase);
				
				//SPEC: Release SR18x.6.0.1 - Added by Amman on June 21, 2021 for Updated Req #38549 -- START
				}
				//SPEC: Release SR18x.6.0.1 - Added by Amman on June 21, 2021 for Updated Req #38549 -- END
				
				if (util.isModificatinRequired()) 
				{
					//commented by Ganesh for security impl --->start
					/*StringList slEachOwnership = util.filterOwnerShip(sPartOwnership);
					bHasOwnerShip = util.checkOwnerShip(sbCompany,slEachOwnership);*/
					//commented by Ganesh for security impl-----> end
					//modified by Ganesh for security impl ----> start
					bHasOwnerShip = util.checkHasAccess(context, null, sPartId);
					//modified by Ganesh for security impl---->end
					
					if(bHasOwnerShip) 
					{
						
						if(!sPartState.equals(ConstantsUtil.RELEASE) &&  !sPartState.equals(ConstantsUtil.RELEASED)) {
							continue;
						}else {
							util.formatData(sbId,sPartId);
						}
						util.formatData(sbRev,sPartRev);
						util.formatData(sbTitle,sPartTitle);
						util.formatData(sbCurrent,sPartState);
						util.formatData(sbHasFile,sHasFileAttached);
						util.formatData(sbName,sPartName);
						util.formatData(sbType,util.mapType(sPartType));
						util.formatData(sbPhase,sPhase);
					}else {
						continue;
					}
				}else if(sct.isStaffAUGUser()) {
					showData = util.checkHasAccess(context, null, sPartId);
				}else {
					showData = util.checkHasAccess(context, null, sPartId);
					if(sPartClassType.contains("Security Control Class")){
						if(!util.checkHasAccess(context, null, sPartId)) {
							showData=false;
						}
					}
					
					
				}
				
				if (!util.isModificatinRequired()) {
					if(showData) {
						
						if(!sPartState.equals(ConstantsUtil.RELEASE) &&  !sPartState.equals(ConstantsUtil.RELEASED)) {
							util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						}else {
							util.formatData(sbId,sPartId);
						}
						util.formatData(sbRev,sPartRev);
						util.formatData(sbTitle,sPartTitle);
						util.formatData(sbCurrent,sPartState);
					}else
					{
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbRev,sPartRev);
						util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
						util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
					}
				}
				
					mpRelatedParts.put(ConstantsUtil.ID, sbId.toString());
					mpRelatedParts.put(ConstantsUtil.NAME, sbName.toString());
					mpRelatedParts.put(ConstantsUtil.TYPE, sbType.toString());
					mpRelatedParts.put(ConstantsUtil.REVISION, sbRev.toString());
					mpRelatedParts.put(ConstantsUtil.TITLE, sbTitle.toString());
					mpRelatedParts.put(ConstantsUtil.STATE, sbCurrent.toString());
					mpRelatedParts.put(ConstantsUtil.PHASE, sbPhase.toString());
					mpRelatedParts.put(ConstantsUtilIRM.ISFILEATTACHED, sbHasFile.toString());
			}
			
        }catch(Exception e)
        {
        	LOGGER.error("Exception in Program : CommonDocBo Method :getRelatedParts "+e);
			return new HashMap();
        }
        return mpRelatedParts ;
	}


	/**
	 * 
	 * @param context
	 * @param sParentType
	 * @param sObjectID
	 * @return
	 * @throws Exception
	 */
	
	public HashMap getPartSpecifications(Context context, String sParentType ,String sObjectID,String ldapuser,String ldappwd) throws Exception {
		HashMap<String, String> mpFinalList = new HashMap();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbState = new StringBuilder();
		StringBuilder sbSubType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		//StringBuilder sbSource = new StringBuilder();
		StringBuilder sbOrig = new StringBuilder();
		StringValidatorUtil validator = new StringValidatorUtil();


		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		StringList slCompanies = new StringList();
		boolean isStaffAUg = ss.isStaffAUGUser();
		String sUserlicense = ss.getUserLicense();
		boolean bHasOwnerShip = false;
		String sWhere = ConstantsUtil.EMPTY_STRING;
		String sUserType = util.getUserType();
		
        if(("tms").equalsIgnoreCase(sParentType) || ("qual").equalsIgnoreCase(sParentType)  || ("mi").equalsIgnoreCase(sParentType)  || ("sp").equalsIgnoreCase(sParentType)  || ("ilst").equalsIgnoreCase(sParentType) || ("lis").equalsIgnoreCase(sParentType)) //Modified by Ketan for Internal defect

        	sWhere = "current==Release";
		else
        	sWhere = "revision==last || (current==Release || current==Obsolete)";
        if(sParentType.equalsIgnoreCase("mi")){
        	sWhere = "current!=Obsolete";
        }
		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
					slCompanies.add(Company);
				}
			}
		}
		
		StringList slRemoveDupli = new StringList();
		StringList slBusSelects = util.getPartSpecSelects();
		
		Pattern typePattern = new Pattern(ConstantsUtil.TYPE_PART);
		  typePattern.addPattern(ConstantsUtil.TYPE_DOCUMENT);
		
				MapList mapList;
		try
		{
			//DomainObject dobCdoc = new DomainObject(sObjectID);
			DomainObject dobCdoc = DomainObject.newInstance(context, sObjectID);

			 mapList = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION,
					 typePattern.getPattern(), slBusSelects, null, false, true, (short) 1,
			sWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			 dobCdoc.close(context);
			mapList.sort(ConstantsUtil.SELECT_TYPE,ConstantsUtil.ASCENDING,ConstantsUtil.INTEGER);
			 
			 
			 Iterator objectListItr = mapList.iterator();
			 while(objectListItr.hasNext()) 
			 {
				Map mpEachObj = (Map) objectListItr.next();
				StringList eachOwnership = validator.getStringListEquivalentForString(mpEachObj.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);

				String strType = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_TYPE));
				if(sParentType.equalsIgnoreCase("ILST")) {
				strType=util.getMappedTypeData(context,strType);
				}
				String strName = validator.getStringEquivalentForSubstituteString(mpEachObj.get(ConstantsUtil.SELECT_NAME));
				
				String strSharable = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHAREWITHSUPPLIERS));
				String strId = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.ID));
				String strIPControlClass = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
				if (slRemoveDupli.contains(strId)) {
						continue;
				}else{
					slRemoveDupli.add(strId);
				}
				
				String strClassFied = validator
						.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String strSubType = util.UpdateSpecSubType(context, strId);

				String strState = validator.getStringEquivalentForStringList(mpEachObj.get(ConstantsUtil.SELECT_CURRENT));
				String strId_Result = strId;
				if (!strState.equals(ConstantsUtil.RELEASE) && !strState.equals(ConstantsUtil.RELEASED)){
					strId_Result=ConstantsUtil.NO_ACCESS;
				}
				
				
				boolean showData=util.checkHasAccess(context, sUserType, strId);
				if(!showData && util.isModificatinRequired()){
					continue;
				}
				if (showData) {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
				
					sbState.append(strState).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(strSubType).append(ConstantsUtil.SYMBL_PIPE);
					String strTitle = validator.getStringEquivalentForSubstituteString(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					sbTitle.append(strTitle).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(strId_Result).append(ConstantsUtil.SYMBL_PIPE);
					String strOrig = validator.getStringEquivalentForStringList(
							mpEachObj.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR));
					
					if(!sParentType.equalsIgnoreCase("PROS")){
					strOrig = util.getOriginatorName(context,mpEachObj,ldapuser,ldappwd);
					}
					
					if(sParentType.equalsIgnoreCase("MI") || sParentType.equalsIgnoreCase("PROS") || sParentType.equalsIgnoreCase("LIS") || sParentType.equalsIgnoreCase("IAPS")) {
						util.formatData(sbOrig,strOrig);
					}					
					else if (sParentType.equalsIgnoreCase("PI") || sParentType.equalsIgnoreCase("SP") || sParentType.equalsIgnoreCase("ACS") || sParentType.equalsIgnoreCase("ILST") || sParentType.equalsIgnoreCase("QUAL") || sParentType.equalsIgnoreCase("TMS")) {
						util.formatData(sbOrig,strOrig);
					}
					
					else{										
						util.formatData(sbOrig,ConstantsUtil.EMPTY_STRING);
						util.formatData(sbOrig,strOrig);
					}
					
				} else {
					sbType.append(util.mapType(strType)).append(ConstantsUtil.SYMBL_PIPE);
					sbName.append(strName).append(ConstantsUtil.SYMBL_PIPE);
					sbState.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbSubType.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbTitle.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbId.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);
					sbOrig.append(ConstantsUtil.NO_ACCESS).append(ConstantsUtil.SYMBL_PIPE);

				}

			}
			mpFinalList.put(ConstantsUtil.TYPE, sbType.toString());
			mpFinalList.put(ConstantsUtil.NAME, sbName.toString());
			mpFinalList.put(ConstantsUtil.STATE, sbState.toString());
			mpFinalList.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSubType.toString());
			mpFinalList.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpFinalList.put(ConstantsUtil.ID, sbId.toString());
			mpFinalList.put(ConstantsUtil.ORIGINATOR, sbOrig.toString());

		} catch (FrameworkException e) {
			e.printStackTrace();
			LOGGER.error("Exception in CommonDocBO: getPartSpecifications: " + e);
			return new HashMap();
		}
		return mpFinalList;
	}

	
	/**
	 * Method Name        : getMarketsApproved
	 * Method Description : to find the list of countries under relationship "pgAAA_POAToCountry"
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getMarketsApproved(Context context, Map resultMaps) {
		
		boolean bHasOwnerShip = false;

		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();

		if (aCompany.length > -1) {
			for (int i = 0; i < aCompany.length; i++) {
				if (null != aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}
		
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		
		Map<String, String> mpMarketsApproved = new HashMap();
		
		String sID = validator.isNotNullOrEmpty((String) resultMaps.get(ConstantsUtil.SELECT_ID))
				? (String) resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;	
				
		try {
			StringBuilder sbCountryName = new StringBuilder();
			
			//DomainObject dom = new DomainObject(sID);
			DomainObject dom = DomainObject.newInstance(context, sID);
			MapList mlMarketsApproved = dom.getRelatedObjects(context,ConstantsUtil.RELATIONSHIP_PGAAA_POATOCOUNTRY, DomainConstants.QUERY_WILDCARD, busSelect,
					new StringList(), false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
			dom.close(context);
			Iterator objectListItr = mlMarketsApproved.iterator();

			while(objectListItr.hasNext())
			{
				Map mpTemp = (Map) objectListItr.next();
				String slCountryName = (String)mpTemp.get(ConstantsUtil.SELECT_NAME);
				
				String strClassFied = validator
						.getStringEquivalentForStringList(mpTemp.get(ConstantsUtil.STR_IPCLASS));
				String sIPClassfication = validator.getStringEquivalentForStringList(
						mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				StringList eachOwnership = validator
						.getStringListEquivalentForString(mpTemp.get(ConstantsUtil.OWNERSHIP));
				StringList slEachOwnership = util.filterOwnerShip(eachOwnership);
				//commented by Ganesh Start
				/*if (util.isModificatinRequired()) {
					bHasOwnerShip = util.checkOwnerShip(sbCompany, slEachOwnership);
					if (bHasOwnerShip) {
						util.formatData(sbCountryName,slCountryName);
					}
				} else {
					boolean showData = true;
					if (sIPClassfication.equalsIgnoreCase(ConstantsUtil.HIGHLY_RESTRICTED)) {
						SecurityService sct = new SecurityService();
						String sUserlicense = sct.getUserLicense();
						showData=util.checkInternalUserAcess(sUserlicense,strClassFied);
						if (null != sUserlicense && null != strClassFied && !sUserlicense.contains(strClassFied)) {
							showData = false;
						}
						if (showData) {
							util.formatData(sbCountryName,slCountryName);
						}
					} else {
						util.formatData(sbCountryName,slCountryName);
					}
				}commented by Ganesh stop*/
				//Added by Ganesh Start
				boolean showData = util.checkHasAccess(context, null, sID);
				if (showData) {
					util.formatData(sbCountryName,slCountryName);
				}
				//Added by Ganesh Stop
			}
			
			mpMarketsApproved.put(ConstantsUtil.MARKETSAPPROVED, sbCountryName.toString());

			}catch(Exception e) {
				LOGGER.error("Exception in Program : CommonDocBO Method :getMarketsApproved " + e);
				return new HashMap();
			}
			return mpMarketsApproved;
		}
	
	
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
		/**
		 * getFiles Selectables
		 * @param context
		 * @return StringList
		 */
		public static StringList getFileSelects(Context context) {

			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.STR_FILE_NAME);
			busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
			busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
			busSelect.add(ConstantsUtil.STR_FILE_SIZE);
			return busSelect;

		}
		//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
		
		
	// SPEC: Added for 18x.5.2 DEV --Shashank -- START
	/**
	 * isIRMDoc
	 * 
	 * @param context
	 * @return StringList
	 */
	public boolean isIRMDoc(String sType) {
		if (("pgPKGValidationReport").equalsIgnoreCase(sType)
				|| ("pgPKGDevelopmentOther").equalsIgnoreCase(sType)
				|| ("pgPKGTranslationFile").equalsIgnoreCase(sType)
				|| ("pgPKGProductReadiness").equalsIgnoreCase(sType)
				|| ("pgPKGOutofSpec").equalsIgnoreCase(sType)
				|| ("pgPKGStabilityReport").equalsIgnoreCase(sType)
				|| ("pgPKGValidationReport").equalsIgnoreCase(sType)
				|| ("pgPKGValidationProtocol").equalsIgnoreCase(sType)
				|| ("pgValidationOther").equalsIgnoreCase(sType)
				|| ("pgPKGTechnicalRationale").equalsIgnoreCase(sType)
				|| ("pgPKGStudyProtocol").equalsIgnoreCase(sType)
				|| ("pgPKGStabilityReport").equalsIgnoreCase(sType)
				|| ("pgStabilityOther").equalsIgnoreCase(sType)
				|| ("pgAAA_RTA_Generic_Document").equalsIgnoreCase(sType)
				|| ("pgPKGDIPlatform").equalsIgnoreCase(sType)
				|| ("pgPKGProductReadiness").equalsIgnoreCase(sType)
				|| ("pgPKGConsumerProposition").equalsIgnoreCase(sType)
				|| ("pgPKGStabilityProtocol").equalsIgnoreCase(sType)
				|| ("Core Innovation Record").equalsIgnoreCase(sType)
				//SPEC: Release SR18x.5.2 - Added for Defect# 39888  by Guna on Date 19/02/2021 -- START
				|| ("Document").equalsIgnoreCase(sType)
				//SPEC: Release SR18x.5.2 - Added for Defect# 39888  by Guna on Date 19/02/2021 -- END
				//SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- START
				|| ("pgPKGReferenceDocs").equalsIgnoreCase(sType)
				//SPEC: <21.03.2021>: Guna Added for Internal Defect 18x.6   -- END
				//SPEC: Added by Ajay for Req. no. 89008 START
				|| ("pgPackagingMinimizationReport").equalsIgnoreCase(sType)
				//SPEC: Added by Ajay for Req. no. 89008 END
				) {
			return true;
		}else {
			return false;
		}

	}
	// SPEC: Added for 18x.5.2 DEV --Shashank -- END
	
	
	/**
	 * isStudyProtocol
	 * 
	 * @param context
	 * @return StringList
	 */
	public boolean isStudyProtocol(String sType) {
		if (("pgPKGStudyProtocol").equalsIgnoreCase(sType)) {
			return true;
		}else {
			return false;
		}
	}
	
	
	// SPEC: Added for 18x.5.2 DEV --Shashank -- START
	/**
	 * Method Name 			: getIRMDocSelects
	 * Method Description 	: Return object selects for different IRM docs
	 * @param context
	 * @return
	 */
	public StringList getIRMDocSelects(Context context, String sType) {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtilIRM.SELECT_PROJECTSPACE_PROJECTID);
		busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_PROJECTDOCUMENT_NAME);
		busSelect.add(ConstantsUtilIRM.SELECT_IRM_PROJECT_NAME);
		busSelect.add(ConstantsUtilIRM.SELECT_IRM_PROJECT_ID);
		busSelect.add(ConstantsUtil.SELECT_REGION_OWNS);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSAREA);
		busSelect.add(ConstantsUtil.SELECT_VAULT);
		busSelect.add(ConstantsUtil.SELECT_POLICY);
		busSelect.add(ConstantsUtil.SELECT_MODIFIED);
		//SPEC: <18.05.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_DOCEXPIRATIONDATE);
		//SPEC: <18.05.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- END
		switch (sType) {
		case "pgPKGValidationProtocol":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSTEP);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSYSTEM);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSITE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGINITIATIVE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGCHANGEMANAGEMENTCONTROLNUMBER);
			break;
		case "pgValidationOther":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSTEP);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGVALIDATIONTYPE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSITE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSYSTEM);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGINITIATIVE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGCHANGEMANAGEMENTCONTROLNUMBER);
			break;
		case "pgPKGValidationReport":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSTEP);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSITE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGVALIDATIONSYSTEM);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGINITIATIVE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGCHANGEMANAGEMENTCONTROLNUMBER);
			// SPEC: Added for 18x.5.2 DEV --Guna -- START
			busSelect.add(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENT);
			// SPEC: Added for 18x.5.2 DEV --Guna -- END
			//START:: gaikwad.tg :: Defect#38212
			//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
			if(util.isModificatinRequired()){
				busSelect.add(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTVPROTOCOL);
				busSelect.add(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTVPROTOCOLTITLE);
			}else{
				busSelect.add(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTFORVPROTOCOL);
				busSelect.add(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTVPROTOCOLID);
			}
			//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
			//END:: gaikwad.tg :: Defect#38212
			//busSelect.add(ConstantsUtil.); Add selectable for Validation Protocol
			break;
		case "pgPKGDevelopmentOther":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGDEVELOPMENTTYPE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGDEVELOPMENTAREA);
			// Release SR18x.5.2: Added for Defect 38075 by Amman ## -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGDEVELOPMENTTOAREA);
			// Release SR18x.5.2: Added for Defect 38075 by Amman ## -- END
			break;
		case "pgPKGProductReadiness":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRTYPE);
			//SPEC: <22.06.2021>: Guna Added for 43765 Defect  Dev 18x.6.0.1   -- START
			busSelect.add(ConstantsUtilIRM.REL_PGDOCUMENTTOSUBTYPE);
			//SPEC: <22.06.2021>: Guna Added for 43765 Defect  Dev 18x.6.0.1   -- END
			break;	
		case "pgPKGConsumerProposition":
			//SPEC: Release SR18x.5.2 - Added for Defect #39790 by Josephine  on Date Feb 16, 2021 -- START
			busSelect.add(ConstantsUtilIRM.REL_PGDOCUMENTTOSUBTYPE);
			//SPEC: Release SR18x.5.2 - Added for Defect #39790 by Josephine  on Date Feb 16, 2021 -- END
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCRTYPE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCRPNUMBER);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGGPSCLEARANCE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGCONSUMERSTUDYLEG);
			break;
		
		case "pgPKGTechnicalRationale":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE);
			// SPEC: Added for 18x.5.2 DEV --Guna -- START
			busSelect.add(ConstantsUtilIRM.SELECTABLE_STABILITY_STUDYNUMBER);
			busSelect.add(ConstantsUtilIRM.SELECTABLE_ATTRIBUTE_TITLE);
			// SPEC: Added for 18x.5.2 DEV --Guna -- END
			//busSelect.add(ConstantsUtil.); Add selectable for Stability Protocol
			
			//SPEC: Release SR18x.5.2 - Added for Defect #39738 by Bala on Date Feb 15, 2021 -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_STABILITY_STUDY_NUMBER);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
			//SPEC: Release SR18x.5.2 - Added for Defect #39738 by Bala on Date Feb 15, 2021 -- END	
					
			break;
		case "pgStabilityOther":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCSTABILITYTYPE);
			break;
		case "pgPKGOutofSpec":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.REFERENCE_DOCUMENT_TITLE);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- END
			//SPEC: <24.06.2021>: Guna Added for 43831 Defect  Dev 18x.6.0.1   -- START
			busSelect.add(ConstantsUtilIRM.SELECTABLE_REFERENCEDOCUMENTSTABILITYID);
			//SPEC: <24.06.2021>: Guna Added for 43831 Defect  Dev 18x.6.0.1   -- END
			break;
		case "pgPKGStabilityProtocol":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_STABILITY_STUDY_NUMBER);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- END
			break;
		case "pgPKGTranslationFile":
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLANGUAGE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGDEVELOPMENTAREA);
			// Release SR18x.5.2: Added for Defect 38075 by Amman ## -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGDEVELOPMENTTOAREA);
			// Release SR18x.5.2: Added for Defect 38075 by Amman ## -- END
			break;
		case "pgPKGStabilityReport":
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPKGSTUDYTYPE);
			//busSelect.add(ConstantsUtil.); Add selectable for Stability Protocol
			//busSelect.add(ConstantsUtil.); Add selectable for Stability Study Number
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOUNDARYCONDITIONS);
			//busSelect.add(ConstantsUtil.); Add selectable for Product Form
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTSIZE);
			//busSelect.add(ConstantsUtil.); Add selectable for Product Size UoM
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPIRATIONDATE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTOTALSHELFLIFE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTEMPERATUREGROUP);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGHUMIDITYGROUP);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTFREEZEPROTECTION);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTRANSPORTHEATPROTECTION);
			// SPEC: Added for 18x.5.2 DEV --Guna -- START
			busSelect.add(ConstantsUtilIRM.SELECTABLE_STABILITY_STUDYNUMBER);
			busSelect.add(ConstantsUtilIRM.SELECTABLE_ATTRIBUTE_TITLE);
			// SPEC: Added for 18x.5.2 DEV --Guna -- END
			break;
		case "pgPKGStudyProtocol":
			//STUDY OBJECTIVES AND SUCCESS CRITERIA
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMPURPOSE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMSUCCESSCRITERIA);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMACTION);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMBACKGROUND);
			//STUDY DESIGN
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMSTUDYBACKGROUND);
			busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOSTUDYTYPE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTYPEOFRESEARCH);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMCONFIDENCELEVELSIGNIFICANCETESTING);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMTOTALNUMBEROFPANELISTS);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTUDYPROTOCOLTOADDITIONALSERVICE);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTUDYPANELISTPURCHASEINTENT);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNOTIFYPATENTOFFICE);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.REL_TECHNIQUE_USED);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_TECHNIQUEOTHER);
			busSelect.add(ConstantsUtilIRM.REL_FEEDBACKTYPE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_DESCRIPTIONMETHODOLOGY);
			busSelect.add(ConstantsUtilIRM.REL_OBJECTIVETYPE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_OBJECTIVETYPEOTHER);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- END
			//STUDY CLASSIFICATION
			busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYCLASS_NAME);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMDATAUSE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIRMREGULATORYCLASSIFICATIONSTUDY);
			busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOREGULATORYCLASSIFICATION);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSKINLAB);	//Is this a clinical study?
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PURCHASEINTENT);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_TSCAINGREDIENTS);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PANELISTPURCHASEINTENT);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- END
			//PANELIST RECRUITING CRITERIA
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOPANELISTTYPE_NAME);
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTORACE_NAME);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERAGELIMIT);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGUPPERRAGELIMIT);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMANAGEMENTSAMPLES);
			//When Product User age range is not provided enter other criteria Add file for details.*
			//Will product be used for R&D Team Test within the same usage parameters as the main test?
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTINCLUSIONCRITERIA);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTEXCLUSIONCRITERIA);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTEXCLUSIONDETAILS);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTINCLUSIONDETAILS);
			busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYPROTOCOLTOGENDER);
			busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ETHNICITYTORACE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBALANCINGCRITERIA);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTUSEDFORRND);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTSTABILITYDATAREQUIRED);
			//SPEC: <19.03.2021>: Guna Added for Internal Defect 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTRANGENOTPROVIDED);
			//SPEC: <19.03.2021>: Guna Added for Internal Defect 18x.6   -- END
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_NATIVENUMBER);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXPERIENCEDNUMBER);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_RECONTACTNUMBER);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_GRANTEDCONSENT);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- END
			
			//SPECIAL PRODUCT ELEMENTS
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTUNIQUECONSUMERPACKAGE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTANCILLIARYSUPPORTINGITEMS);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLOCATIONOFSTABILITY);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_STABILITYTESTING);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- END
			//PANELIST TASK
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTSIGNINFORMEDCONSENT);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGEXPECTEDPANELISTCOMPENSATION);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTUDYCDASIGNEDFORPANELIST);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTUDYPANELISTHOMEWORK);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTUDYPANELISTEMAILADDRESS);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTUDYSUPERVISED);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDESCRIBEPANEISTINTERATION);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTINSTRUCTIONATTACHED);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PANELISTTASKOTHER);
			//SPEC: <09.03.2021>: Guna Added for Dev 18x.6   -- END
			//SPEC: <23.03.2021>: Guna Added for Defect 41412 Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.REL_PENELISTTASK);
			//SPEC: <23.03.2021>: Guna Added for Defect 41412 Dev 18x.6   -- END
			
			//Panelist Questionnaire/Diary Utilized (Screener, After Use, Diary) If yes, attach Panelist Questionnaire(s)
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTFOCUSGROUPINTERVIEW);
			//GPS ASSESSMENT TYPE
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGPSAPPROVALREQUIREDTORELEASESTUDY);
			//If Study Protocol is covered by an existing GPS Assessment enter Task or NRQ ID
			//<SPEC> 06/02/2021 Added by Govind for Defect #38890 start			
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGPSASSESSMENTTASKNRQID);
			//<SPEC> 06/02/2021 Added by Govind for Defect #38890 end
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGUSEPRODUCTBYCONTRACTMANUFORCOMPETITOR);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLEGACYRQID);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSINGLECONSUMERSTUDY);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGREQUESTEDEXPIRATIONDATE);
			//SPEC: <01.06.2022>: Guna Added for Req 36041 22x Release  -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_GPSAPPROVEDBOUNDRY);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGHASPARTICLESIZEDISTRIBUTIONFILE);
			//SPEC: <01.06.2022>: Guna Added for Req 36041 22x Release  -- END
			
			//STUDY LOCATION.DATES
			//Market of Study Placement*
			busSelect.add(ConstantsUtil.strPGCountry);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTUDYLAUNCHDATE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLOCATIONFORDISTRIBUTINGPRODUCTS);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGADDRESSOTHERPGSITE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGDURATIONSTUDY);
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOASSEMBLYSTATE_NAME);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTUSELOCATION);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTORAGEUNPLACEDPRODUCT);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGOTHERLOCATION);
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOSURPLUSDISPOSITION_NAME);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRETURNADDRESS);
			//SPEC: <23.03.2021>: Guna Added for Defect 41414 Dev 18x.6   -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSURPLUSDISPOSITION);
			//SPEC: <23.03.2021>: Guna Added for Defect 41414 Dev 18x.6   -- END
			
			//AGENCY TASKS
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGAGENCY);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPLACEMENTFIELDINGINSTRUCTIONS);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGESTIMATEDFIELDINGSCHEDULE);
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATACOLLECTIONMETHODS_NAME);
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTODATAMERGE_NAME);
			busSelect.add(ConstantsUtil.SELECT_RELATIONSHIP_PGSTUDYPROTOCOLTOATTACHMENTFORMAT_NAME);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGREQUESTEDSITESCHEDULE);
			busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_STUDYLOCATIONS);
			
			//BUDGET OWNER AND APPROVAL
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBUDGETAPPROVER);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGESTIMATEDCOMPLETIONDATEOFSTUDY);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCOSTOFPLACINGEXECUTION);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCURRENCY);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPO);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBUDGETCCIO);
			busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
			busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
			busSelect.add(ConstantsUtil.RELATIONSHIP_SECURITY_CONTROL_CLASS_NAME);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGIPPROJECTSECURITY);
			
			// SPEC : Added for Defect #38134 -- Govind Start
			busSelect.add(ConstantsUtilIRM.SELECT_STUDYPROTOCOLTOSTUDYTYPE);
			busSelect.add(ConstantsUtilIRM.SELECT_RELATION_PGSTUDYSUPERVISED);
			busSelect.add(ConstantsUtilIRM.SELECT_PGPANELISTQUESTIONAIRE);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSTUDYPANELISTMATERIALS); // Added :01/02/2021
			// SPEC : Added for Defect #38134 -- Govind end
			// Guna Added for Defect 38711 18x.5.2 Release -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_IRMNRQID);
			// Guna Added for Defect 38711 18x.5.2 Release -- END
			
			// Aditya Added for Defect 38711 18x.5.2 Release -- START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_DOCEXPIRATIONDATE);
			// Aditya Added for Defect 38711 18x.5.2 Release -- END
			
			break;
		case "pgPackagingMinimizationReport":
			//SPEC: Added by Ajay for Req. no. 89008 START
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ASSESSMENTBASIS_LOCATION);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ASSESSMENTLEVEL);
			//SPEC: Added by Ajay for Req. no. 89008 END
			break;
		}
		return busSelect;
	}
	/// SPEC: Added for 18x.5.2 DEV --Shashank -- END
	
	
	/**
	 * isIRMDoc
	 * 
	 * @param context
	 * @return StringList
	 */
	//SPEC: Updated the method by Sanjeeva for 18x.6.0.3 ELS Issue. Defects: 47517,47786 -- START
	public HashMap getIRMDocFiles(Context context, DomainObject doIrm) {
		Map mpFiles = new HashMap();
		Map resultMaps = new HashMap();
		StringValidatorUtil validator = new StringValidatorUtil();
		try {
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
			busSelect.add(ConstantsUtil.STR_FILE_NAME);
			
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_CAPTURED);
			//Added by Jwala for defect : SR2018x6.0 : 41204 - START
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_FILE_NAME);
			//Added by Jwala for defect : SR2018x6.0 : 41204 - END
			
			resultMaps = doIrm.getInfo(context, busSelect);
			
			//LOGGER.info("Files Map:"+resultMaps);
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_CAPTURED);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_FILE_NAME);
			String FileCapturedFile = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
			
			//SPEC: <29.07.2022>: Guna Added for Internal Defect  Dev 22x NovermberCW   -- START
			//Modified by Jwala for defect : SR2018x6.0 : 41204 - START
			String FileName = validator.getStringEquivalentForStringListWithSpecialChar(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
			FileName = FileName.substring( 1, FileName.length() - 1);
			FileName = FileName.replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
			//Modified by Jwala for defect : SR2018x6.0 : 41204 - END
			//SPEC: <29.07.2022>: Guna Added for Internal Defect  Dev 22x NovermberCW   -- END
			
			StringTokenizer nameTokenizer = new StringTokenizer(FileName,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			StringTokenizer pathTokenizer = new StringTokenizer(FileCapturedFile,ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			
			String sGendoc =DomainConstants.EMPTY_STRING;
			Map mpFileDetails = new HashMap<String,String>();
			StringBuilder sbFileName = new StringBuilder();
			StringBuilder sbFilePath = new StringBuilder();
			StringBuilder sbFileStore = new StringBuilder();
			StringBuilder sbFileVersion = new StringBuilder();
			StringBuilder sbFileOriginated = new StringBuilder();
			StringBuilder sbFileOriginator = new StringBuilder();
			StringBuilder sbFileComments = new StringBuilder();
			StringBuilder sbFileFormat = new StringBuilder();
			StringBuilder sbFileSize = new StringBuilder();
			StringBuilder sbGendoc = new StringBuilder();
			StringBuilder sbFileContentId = new StringBuilder();//SPEC: Added by Ajay for Req. no. 30355
			
			if(nameTokenizer.countTokens()>0) {
				int count = nameTokenizer.countTokens();
				
				
				StringList slVerObjSelects = new StringList();
				slVerObjSelects.add(ConstantsUtil.SELECT_REVISION);
				slVerObjSelects.add(ConstantsUtil.SELECT_ORIGINATED);
				slVerObjSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);
				slVerObjSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHECKIN_REASON);
				//SPEC: <27.07.2021>: Dominic Added for Internal Defect  Dev 22x NovermberCW   -- START
				slVerObjSelects.add(pgV3Constants.SELECT_ATTRIBUTE_TITLE);
				//SPEC: <27.07.2021>: Dominic Added for Internal Defect  Dev 22x NovermberCW   -- END
				//SPEC: Added by Ajay for Req. no. 30355 START
				slVerObjSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_FILECONTENTID);
				//SPEC: Added by Ajay for Req. no. 30355 END
				String sName=DomainConstants.EMPTY_STRING;
				String sRev=DomainConstants.EMPTY_STRING;
				String sOriginated = DomainConstants.EMPTY_STRING;
				String sOriginator = DomainConstants.EMPTY_STRING;
				String sComment = DomainConstants.EMPTY_STRING;
				String strCapturedFilePath = DomainConstants.EMPTY_STRING; 
				String strStoreName = DomainConstants.EMPTY_STRING;
				String strFileContentId = DomainConstants.EMPTY_STRING;
				PersonUtil person = new PersonUtil();
				MapList mlVersionObjects = doIrm.getRelatedObjects(context,//MatrixContext
						ConstantsUtilIRM.ACTIVEVERSION, //relationshipPattern
						DomainConstants.QUERY_WILDCARD, //typePattern
						slVerObjSelects, //objectSelects
						null, //relationshipSelects
						false, //getTo
						true,  //getFrom
						(short) 1,  //recurseToLevel
						null, //objectWhere
						null, //relationshipWhere
						0); //limit
				for(int i = 0; i<count;i++) {
					/*
					 * sName=DomainConstants.EMPTY_STRING; sRev=DomainConstants.EMPTY_STRING;
					 * sOriginated=DomainConstants.EMPTY_STRING;
					 * sOriginator=DomainConstants.EMPTY_STRING; strCapturedFilePath=
					 * DomainConstants.EMPTY_STRING; strStoreName=DomainConstants.EMPTY_STRING;
					 */
					if(nameTokenizer.hasMoreTokens()) {
						//SPEC: <29.07.2022>: Guna Modified for Internal Defect  Dev 22x NovermberCW   -- START
						sName = nameTokenizer.nextToken().trim();
						//SPEC: <29.07.2022>: Guna Modified for Internal Defect  Dev 22x NovermberCW   -- END
						StringBuilder sbDocSelectFilePath = new StringBuilder();
						StringBuilder sbDocSelectStore = new StringBuilder();
						StringList slFileSelects = new StringList();
						sbDocSelectFilePath.append(ConstantsUtilIRM.STR_FORMAT_FILE_);
						sbDocSelectFilePath.append(sName);
						sbDocSelectFilePath.append(ConstantsUtilIRM.STR_CAPTURED_FILE_);
						
						sbDocSelectStore.append(ConstantsUtilIRM.STR_FORMAT_FILE_);
						sbDocSelectStore.append(sName);
						sbDocSelectStore.append(ConstantsUtilIRM.STR_STORE_);
						
						slFileSelects.add(sbDocSelectFilePath.toString());
						slFileSelects.add(sbDocSelectStore.toString());
						
						mpFileDetails = doIrm.getInfo(context, slFileSelects);
						
						Iterator objectListItr = mlVersionObjects.iterator();
						while(objectListItr.hasNext())
						{
							Map objectMap = (Map) objectListItr.next();
							//SPEC: <27.07.2021>: Dominic Added for Internal Defect  Dev 22x NovermberCW   -- START
							String strTitle=(String)objectMap.get(pgV3Constants.SELECT_ATTRIBUTE_TITLE);
							if(strTitle.equalsIgnoreCase(sName)) {
							//SPEC: <27.07.2021>: Dominic Added for Internal Defect  Dev 22x NovermberCW   -- END
								sRev=(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
								sOriginated=(String)objectMap.get(ConstantsUtil.SELECT_ORIGINATED);
								sOriginator=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR);
								sComment=(String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHECKIN_REASON);
							//SPEC: <27.07.2021>: Dominic Added for Internal Defect  Dev 22x NovermberCW   -- START
								//SPEC: Added by Ajay for Req. no. 30355 START
								strFileContentId = validator.getEquivalentStringComma(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_FILECONTENTID));								//SPEC: Added by Ajay for Req. no. 30355 END
							}
							//SPEC: <27.07.2021>: Dominic Added for Internal Defect  Dev 22x NovermberCW   -- END
						}
						//SPEC: <27.07.2021>: Dominic Added for Internal Defect  Dev 22x NovermberCW   -- START
						if(UIUtil.isNotNullAndNotEmpty(sRev)) {
						//SPEC: <27.07.2021>: Dominic Added for Internal Defect  Dev 22x NovermberCW   -- END
							util.formatData(sbFileName,sName);
							strCapturedFilePath = mpFileDetails.get(sbDocSelectFilePath.toString()) == null ? DomainConstants.EMPTY_STRING :mpFileDetails.get(sbDocSelectFilePath.toString()).toString();
							strStoreName = mpFileDetails.get(sbDocSelectStore.toString()) == null ? DomainConstants.EMPTY_STRING :mpFileDetails.get(sbDocSelectStore.toString()).toString();
							
							util.formatData(sbFileStore,strStoreName);
							
							if(UIUtil.isNotNullAndNotEmpty(strStoreName) && UIUtil.isNotNullAndNotEmpty(strCapturedFilePath)) 
							{
								if (!strStoreName.equalsIgnoreCase(ConstantsUtil.STR_STORE)){
									StringBuilder sbCapturedPath = new StringBuilder();
									strCapturedFilePath = sbCapturedPath.append(strStoreName.toLowerCase().replaceAll(ConstantsUtilIRM.BLANK_SPACE, DomainConstants.EMPTY_STRING))
																		.append(ConstantsUtil.SYMBL_SLASH)
																		.append(mpFileDetails.get(sbDocSelectFilePath.toString()) == null ? DomainConstants.EMPTY_STRING :mpFileDetails.get(sbDocSelectFilePath.toString())).toString();
									if(sName.trim().contains("Approval Document")){
										sbGendoc = sbGendoc.append(strStoreName.toLowerCase().replaceAll(ConstantsUtilIRM.BLANK_SPACE, DomainConstants.EMPTY_STRING))
												.append(ConstantsUtil.SYMBL_SLASH)
												.append(((mpFileDetails.get(sbDocSelectFilePath.toString()) == null ? DomainConstants.EMPTY_STRING :mpFileDetails.get(sbDocSelectFilePath.toString())).toString())).append(ConstantsUtil.SYMBL_PIPE).append(ConstantsUtil.SYMBL_PIPE).append(sName);
										//sGendoc=sPath+"||"+sName;
									}
								} else {
									if(sName.trim().contains("Approval Document")){
										sbGendoc = sbGendoc.append(((mpFileDetails.get(sbDocSelectFilePath.toString()) == null ? DomainConstants.EMPTY_STRING :mpFileDetails.get(sbDocSelectFilePath.toString())).toString())).append(ConstantsUtil.SYMBL_PIPE).append(ConstantsUtil.SYMBL_PIPE).append(sName);
									}
								}
							}
							util.formatData(sbFilePath,strCapturedFilePath);
							util.formatData(sbFileVersion,sRev);
							util.formatData(sbFileOriginated,validator.DateFormatter(sOriginated));
							util.formatData(sbFileOriginator,person.getFullName(context, sOriginator).toString());
							sComment = sComment.replace(ConstantsUtil.SYMBL_PIPE, ConstantsUtil.SYMBL_COMMA);
							util.formatData(sbFileComments,sComment);
							util.formatData(sbFileContentId,strFileContentId);//SPEC: Added by Ajay for Req. no. 30355 START
						//SPEC: <27.07.2021>: Dominic Modified for Internal Defect  Dev 22x NovermberCW   -- START		
						}
						//SPEC: <27.07.2021>: Dominic Modified for Internal Defect  Dev 22x NovermberCW   -- END
					}
					String sPath=DomainConstants.EMPTY_STRING;
					if(pathTokenizer.hasMoreTokens()) {
						sPath = pathTokenizer.nextToken();
					}
					
				}
			}
			//SPEC: <27.07.2021>: Dominic Modified for Internal Defect  Dev 22x NovermberCW   -- START
			mpFiles.put(ConstantsUtilIRM.FILENAME, sbFileName.toString());
			//SPEC: <27.07.2021>: Dominic Modified for Internal Defect  Dev 22x NovermberCW   -- END
			mpFiles.put(ConstantsUtilIRM.VERSION, sbFileVersion.toString());
			mpFiles.put(ConstantsUtil.ORIGINATED, sbFileOriginated.toString());
			mpFiles.put(ConstantsUtil.COMMENTS, sbFileComments.toString());
			mpFiles.put(ConstantsUtil.ORIGINATOR, sbFileOriginator.toString());
			mpFiles.put(ConstantsUtilIRM.FILEPATH, sbFilePath);
			mpFiles.put(ConstantsUtilIRM.GENDOC, sbGendoc.toString());
			mpFiles.put(ConstantsUtilIRM.FILECONTENTID, sbFileContentId.toString());//SPEC: Added by Ajay for Req. no. 30355 START
			
		} catch (FrameworkException e) {
			LOGGER.error("Exception in Program : CommonDocBO Method :getIRMDocFiles " + e);
			return new HashMap();
		}
		return (HashMap) mpFiles;
	}
	
	//SPEC: Updated the method by Sanjeeva for 18x.6.0.3 ELS Issue. Defects: 47517,47786 -- END	
	

	/**
	 * Method Name 			: getRelatedPartsforIrmDocs
	 * Method Description 	:
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map getRelatedPartsforIrmDocs(Context context,Map resultMaps) 
	{
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		//Added by Bala for Defect 38709----START
		busSelect.add(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE);
		//Added by Bala for Defect 38709----END
		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START	
		busSelect.add(ConstantsUtil.STR_FILE_CAPTURED);
		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END



		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		Map<String, String> mpRelParts = new HashMap();
		try
		{
			//DomainObject dobCdoc = new DomainObject(sObjectId);
			DomainObject dobCdoc = DomainObject.newInstance(context, sObjectId);
			
			StringBuffer strWhere = new StringBuffer(DomainConstants.SELECT_TYPE).append(".kindof[").append(ConstantsUtilIRM.TYPE_DOCUMENT).append("]==false");
			//SPEC: <26.05.2021>: Guna Modified for 43100 Defect  Dev 18x.6.0.1   -- START
			if(util.isModificatinRequired()){
				//SPEC: <05.07.2021>: Guna Modified for 44004 Defect  Dev 18x.6.0.1   -- START
				strWhere.append(" && (current==Release || current==Qualified || current ==Approved || current ==Active)");
				//SPEC: <05.07.2021>: Guna Modified for 44004 Defect  Dev 18x.6.0.1   -- END
				//SPEC: <26.05.2021>: Guna Modified for 43100 Defect  Dev 18x.6.0.1   -- END
			}else{
			//SPEC: <02.09.2022>: Jwala Modified for 50531 Defect  Dev 22x  -- START
			strWhere.append(" && current!="+ConstantsUtil.STATE_OBSOLETE+ "&& current!="+ConstantsUtilIRM.STATE_REVIEW+"&& current!="+ConstantsUtil.STATE_FROZEN);
			//SPEC: <02.09.2022>: Jwala Modified for 50531 Defect  Dev 22x  -- END
			}

			MapList mlRelatedParts = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					ConstantsUtil.SYMBL_ASTERISK, busSelect, new StringList(), true, false, (short) 1,
					strWhere.toString(), ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			dobCdoc.close(context);
			
			Iterator objectListItr = mlRelatedParts.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType=new StringBuilder();
			StringBuilder sbRev=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbTitle=new StringBuilder();
			
			StringBuilder sbHasFile=new StringBuilder();	
			
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			
			String sName = ConstantsUtil.EMPTY_STRING;
			//Added by Bala for Defect 38709----START
			String strSecurityControl = ConstantsUtil.EMPTY_STRING;
			//Added by Bala for Defect 38709----END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sType    =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
				String sId		=  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				String sCurrent	=  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
				String sRev		=  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				String sTitle	=  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				
			
				//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
				String sHasFileAttached = ConstantsUtil.FALSE;
				String sGendocPath=validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.STR_FILE_CAPTURED));				
				//SPEC: <19.04.2021>: Guna Modified for 42490 Defect  Dev 18x.6   -- START
				
				//if(sGendocPath.length()>1) // since | is added by default
				if(!sType.equals(ConstantsUtil.TYPE_INTERNAL_MATERIAL) && !sType.equals(ConstantsUtil.TYPE_QUALIFICATION) && !sType.equals(ConstantsUtilIRM.TYPE_EXTERNAL_MATERIAL)) {
					sHasFileAttached = ConstantsUtil.TRUE;					
				}	
				//SPEC: <19.04.2021>: Guna Modified for 42490 Defect  Dev 18x.6   -- END
				//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
				
				//SPEC: Release SR18x.6.0 Defect#42651 - Added  by gaikwad.tg on Date 21 April 2021 -- END
				if (UIUtil.isNotNullAndNotEmpty(sCurrent) && sCurrent.equalsIgnoreCase(ConstantsUtil.DEVELOPMENT))
				{
					sCurrent = ConstantsUtil.STATE_INWORK;
				}
				//SPEC: Release SR18x.6.0 Defect#42651 - Added  by gaikwad.tg on Date 21 April 2021 -- END
				
				//Added by Bala for Defect 38709----START
				strSecurityControl = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.RELATIONSHIP_CLASSFIED_ITEM_TYPE));
				//Added by Bala for Defect 38709----END
				if (util.isModificatinRequired()) {
					boolean showData = util.checkHasAccess(context, sct.getUserType(), sId);
					//SPEC: <11.05.2021>: Guna Modified for 33248 Req  Dev 18x.6.0.1   -- START
					//SPEC: 22-08-2022: Pooja Modified for Defect 50521 -- START
					if(!showData && !sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED)){
						//SPEC: 22-08-2022: Pooja Modified for Defect 50521 -- END
						sType = util.mapType(sType);
						util.formatData(sbType,sType);
						util.formatData(sbName,sName);
						util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
						util.formatData(sbId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbRev,sRev);
						util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
						util.formatData(sbHasFile,sHasFileAttached);
					}
					//SPEC: <11.05.2021>: Guna Modified for 33248 Req  Dev 18x.6.0.1   -- END
					else {
						//SPEC: 22-08-2022: Pooja Modified for Defect 50521 -- START
						if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_QUALIFICATION) || "Part Qualification Record".equalsIgnoreCase(sType)) {
							sCurrent = sCurrent.replace(ConstantsUtil.RELEASED, ConstantsUtil.STATE_APPROVED);
						}
						//SPEC: 22-08-2022: Pooja Modified for Defect 50521 -- END
						sType = util.mapType(sType);
						util.formatData(sbType,sType);
						util.formatData(sbName,sName);
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbId,sId);
						util.formatData(sbRev,sRev);
						util.formatData(sbTitle,sTitle);
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
						util.formatData(sbHasFile,sHasFileAttached);
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END

					}
				}else{					

					boolean showData = util.checkHasAccess(context, sct.getUserType(), sId);
					
						//SPEC: Release SR18x.6.0 - Modified  by Manikanta for defect 41203 on Date 8/04/2021 -- START
						if (sType.equals(ConstantsUtil.TYPE_SUBSTANCE) || sType.equals(ConstantsUtil.TYPE_INTERNALMATERIAL)) {
	                        showData = util.checkAccessForIRMIMorMCP(context, sId);
	                        if (!sCurrent.equals(ConstantsUtil.RELEASE) && !sCurrent.equals(ConstantsUtil.RELEASED)
	                                && !sCurrent.equals(ConstantsUtil.APPROVED)) {
	                            sId = ConstantsUtil.NO_ACCESS;
	                        }
	                    }
						
						else if((!sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_APPROVED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.QUALIFICATION_STATE_QUALIFIED) && !(sType.equals(ConstantsUtilIRM.TYPE_EXTERNAL_MATERIAL) && sCurrent.equals(ConstantsUtilIRM.STATE_ACTIVE)) ) {

								sId=ConstantsUtil.NO_ACCESS;
						}
						//SPEC: Release SR18x.6.0 - Modified  by Manikanta for defect 41203 on Date 8/04/2021 -- END
						if (!showData) {
							sId=ConstantsUtil.NO_ACCESS;
							sCurrent = ConstantsUtil.NO_ACCESS;
							sTitle = ConstantsUtil.NO_ACCESS;
						}
						sType = util.mapType(sType);
						// SPEC: Release 18x.5.2 - Modified for Defect 38130 by Amman ## -- START
						
						// SPEC: Release 18x.5.2 - Modified for Defect 38375 by Jwala ## -- START
						if(sType.equalsIgnoreCase("Formulation Part") && (!sCurrent.equalsIgnoreCase("Preliminary"))){
						sCurrent = util.mapType(sCurrent);
						}else if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_RAWMATERIALPART) && sCurrent.equals(ConstantsUtil.STATE_PART_REVIEW)){
							sCurrent = sCurrent;
						}
						else if(!sType.equalsIgnoreCase("Formulation Part")){
							sCurrent = util.mapType(sCurrent);
						}

						if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_QUALIFICATION) || "Part Qualification Record".equalsIgnoreCase(sType)) {
							sCurrent = sCurrent.replace(ConstantsUtil.RELEASED, ConstantsUtil.STATE_APPROVED);
						}

						util.formatData(sbType,sType);
						util.formatData(sbName,sName);
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbId,sId);
						util.formatData(sbRev,sRev);
						util.formatData(sbTitle,sTitle);
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
						util.formatData(sbHasFile,sHasFileAttached);
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END

				}
			}
			mpRelParts.put(ConstantsUtil.NAME, sbName.toString());
			mpRelParts.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpRelParts.put(ConstantsUtil.TYPE, sbType.toString());
			mpRelParts.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRelParts.put(ConstantsUtil.REVISION, sbRev.toString());
			mpRelParts.put(ConstantsUtil.ID, sbId.toString());
			//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
			mpRelParts.put(ConstantsUtilIRM.ISFILEATTACHED, sbHasFile.toString());
			//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END


	}catch(Exception e){

		LOGGER.error("Exception in Program : CommonDocBO Method :getRelatedPartsforIrmDocs "+e);
		return new HashMap();
	}

	return util.filterMapList(mpRelParts);
	}
	
	
	//Shashank
	/**
	 * getLegDetails for IRMDocs (Related Parts for Study Protocol)
	 * @param context
	 * @param parentId
	 * @return Map
	 * @throws Exception
	 */
	 public Map getLegDetails(Context context, String parentId) throws Exception {
		 
		 	Map mpRelParts = new HashMap();
		 	Map mpLegTable = new HashMap();
		 	Map mpPartTableOne = new HashMap();
		 	Map mpPartTableTwo = new HashMap();
		 	Map mpPartTableThree = new HashMap();

		 	MapList mlObjectList = new MapList();
			MapList mlReturntList = new MapList();
			StringValidatorUtil validatorUtil = new StringValidatorUtil();
			Map mpLegInfo = new HashMap();
			String sType = DomainConstants.EMPTY_STRING;
			String srelpgLegInput = ConstantsUtil.RELATIONSHIP_PGLEGINPUT;
			String srelpgLegProcess = ConstantsUtil.RELATIONSHIP_PGLEGPROCESS;
			String strRelPattern = srelpgLegInput+","+srelpgLegProcess;
			StringList typeSelects = new StringList(1);
			typeSelects.add(ConstantsUtil.SELECT_ID);
			typeSelects.add(ConstantsUtil.SELECT_NAME);
			typeSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			typeSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
			//SPEC: <07.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- START
			typeSelects.add(ConstantsUtil.SELECT_CURRENT);
			//SPEC: <07.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- END
			//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
			typeSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASEPHASE);
			//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
			
			
			//Added by Bala for Defects #38629 and #38536 STARTS---
			typeSelects.add("to[" + ConstantsUtil.RELATIONSHIP_PGLEGINPUT + "].from.name");
			//Added by Bala for Defects #38629 and #38536 ENDS---
			//SPEC: <23.03.2021>: Guna Added for Defect 41418 Dev 18x.6   -- START
			typeSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTCODEPANELISTS);
			typeSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNUMBEROFPANELISTS);
			//SPEC: <23.03.2021>: Guna Added for Defect 41418 Dev 18x.6   -- END
			//SPEC: <14.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- START
			typeSelects.add(ConstantsUtil.SELECT_REVISION);
			typeSelects.add("to[" + ConstantsUtil.RELATIONSHIP_PGLEGINPUT + "].from.revision");
			//SPEC: <14.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- END
			StringList relSelects = new StringList(2);
			relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_NAME);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTCODE);
			relSelects.add(ConstantsUtilIRM.SELECT_LEG_PLANTNAME);
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRFREQUENCYSAMEASCURRENTMARKETPRODUCT);
			//Added for defect# 38265 - START
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGRELPACKINGSITE);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGWASHOUTTIMEBETWEENPRODUCTS);
			// Guna Commented for Defect 38265  18x.5.2 Release -- START
			//relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNUMBEROFPANELISTS);
			// Guna Commented for Defect 38265  18x.5.2 Release -- END
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNUMBEROFUNITSPERBAG);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS);
			//Added for defect# 38265 - END
			// Guna Added for Defect 38265  18x.5.2 Release -- START
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFREQUENCY);
			// Guna Added for Defect 38265  18x.5.2 Release -- END
			//SPEC: Release SR18x.5.2 - Added for Defect #38536 by Bala on Date Feb 19, 2021 -- START
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSITEIFOTHERSELECTED);
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISPRODUCTREPACKAGED);
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGUNITWEIGHT);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTABILITYSAMPLECOUNT);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGANALYTICALSAMPLECOUNT);		
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMICROMCT);
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTSCOMPLETES);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLACEMENTS);			
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGUNITSTOLABEL);
			relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLABELING);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRNDTEAMSAMPLECOUNT);
			//relSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTOTALNUMBERRETAINS);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGNUMBEROFUNITSTOSHIP);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGINVENTORYSAMPLECOUNT);
			relSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCH);
			//SPEC: Release SR18x.5.2 - Added for Defect #38536 by Bala on Date Feb 19, 2021 -- END
			
			
			relSelects.add("id[connection]");
			
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			SecurityService sct = new SecurityService();
			String sUserType=util.getUserType();
			boolean showData=false;	
			
			//Added by Bala for Defects #38629 and #38536 STARTS---
			String sChildName = DomainConstants.EMPTY_STRING;
			String sChildTitle = DomainConstants.EMPTY_STRING;			
			String sChildType    =  DomainConstants.EMPTY_STRING;
			String sChildId = DomainConstants.EMPTY_STRING;
			String sChildConnectionId = DomainConstants.EMPTY_STRING;
			String sChildDescription = DomainConstants.EMPTY_STRING;
			String sChildNumOfPanel = DomainConstants.EMPTY_STRING;
			String sChildTProdCodePanel = DomainConstants.EMPTY_STRING;			
			String sChildSiteOfOther = DomainConstants.EMPTY_STRING;
			String sChildNumOfUnitsPerBag = DomainConstants.EMPTY_STRING;
			String sChildTPackSite = DomainConstants.EMPTY_STRING;
			String sChildWashOutTimeBetweenProducts = DomainConstants.EMPTY_STRING;
			String sChildMicroMCT = DomainConstants.EMPTY_STRING;
			String sChildTPanelCompletes = DomainConstants.EMPTY_STRING;
			String sChildPlacements = DomainConstants.EMPTY_STRING;
			String sChildUnitsToLabel = DomainConstants.EMPTY_STRING;
			String sChildLabeling = DomainConstants.EMPTY_STRING;
			String sChildStabilitySampleCount = DomainConstants.EMPTY_STRING;
			String sChildAnalyticalSampleCount = DomainConstants.EMPTY_STRING;
			String sChildInventorySampleCount = DomainConstants.EMPTY_STRING;
			String sChildNumberOfUnitsToShip = DomainConstants.EMPTY_STRING;
			String sChildTBatch = DomainConstants.EMPTY_STRING;
			String sChildUnitWeight = DomainConstants.EMPTY_STRING;
			String sChildIsProductRepacked = DomainConstants.EMPTY_STRING;
			String sChildRelId = DomainConstants.EMPTY_STRING;
			String sChildRelName = DomainConstants.EMPTY_STRING;
			String sChildProdCode = DomainConstants.EMPTY_STRING;
			String sChildLegPlantName = DomainConstants.EMPTY_STRING;
			String sChildFreq = DomainConstants.EMPTY_STRING;
			String sChildRndTeamSampleCount = DomainConstants.EMPTY_STRING;			
			String sChildComments = DomainConstants.EMPTY_STRING;
			String sPlant = DomainConstants.EMPTY_STRING;
			String sNetSampleCount =  DomainConstants.EMPTY_STRING;
			//Added by Bala for Defects #38629 and #38536 ENDS---
			// Guna Added for Defect 38265  18x.5.2 Release -- START
			String sFreqTestProduct =  DomainConstants.EMPTY_STRING;
			// Guna Added for Defect 38265  18x.5.2 Release -- END
			String sChildFreqTestProd = DomainConstants.EMPTY_STRING; // Added for Defect #38892
			//Added by Bala for Defects #38629 and #38536 STARTS---
			String strChildFromName = DomainConstants.EMPTY_STRING; 
			String sLEGName = DomainConstants.EMPTY_STRING;
			String sLEGTitle  = DomainConstants.EMPTY_STRING;
			//SPEC: <07.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- START
			String sCurrent = DomainConstants.EMPTY_STRING;
			//SPEC: <07.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- END
			
			//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
			String sReleasePhase =DomainConstants.EMPTY_STRING;
			//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
			Map mpLEGResult = new HashMap();
			Map mLEGobjectMap = new HashMap();
			Map objectMap = new HashMap();
			MapList mlLEGList = new MapList();
			int index=1;
			//Added by Bala for Defects #38629 and #38536 ENDS---
			//SPEC: <14.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- START
			String sWhere = "current!="+ConstantsUtil.STATE_OBSOLETE;
			//SPEC: <14.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- END
			//SPEC: <14.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- START
			String sLEGRev = ConstantsUtil.EMPTY_STRING;
			String strChildFromRev = ConstantsUtil.EMPTY_STRING; 
			//SPEC: <14.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- END
	        try
	        {
				if (validatorUtil.isNotNullOrEmpty(parentId)) {
					DomainObject masterObject = DomainObject.newInstance(context, parentId);
					String sParentType = masterObject.getInfo(context,DomainObject.SELECT_TYPE);
					if(sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGPKGSTUDYPROTOCOL) || sParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGSTUDYLEG)){
						//SPEC: <14.04.2021>: Guna Modified for 40163 Defect  Dev 18x.6   -- START
						//SPEC: <19.04.2021>: Guna Modified for 42357 Defect  Dev 18x.6   -- START
						mlObjectList = masterObject.getRelatedObjects(context,
													 strRelPattern,
													 DomainConstants.QUERY_WILDCARD,
													 typeSelects,
													 relSelects, 
													 false, 
													 true, 
													 (short)1, 
													 sWhere, 
													 null,	
													 0);
						//SPEC: <19.04.2021>: Guna Modified for 42357 Defect  Dev 18x.6   -- END
						//SPEC: <14.04.2021>: Guna Modified for 40163 Defect  Dev 18x.6   -- END
					}
					else {
						//SPEC: <14.04.2021>: Guna Modified for 40163 Defect  Dev 18x.6   -- START
						mlObjectList = masterObject.getRelatedObjects(context,
														ConstantsUtil.RELATIONSHIP_EBOM,
														DomainConstants.QUERY_WILDCARD,
														 typeSelects,
														 relSelects, 
														 false, 
														 true, 
														 (short)1, 
														 sWhere, 
														 null,	
														 0);
						//SPEC: <14.04.2021>: Guna Modified for 40163 Defect  Dev 18x.6   -- END
					}
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
					masterObject.close(context);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
				}
				
				if(mlObjectList != null && mlObjectList.size()>0){
					int i = 0;
					for(Iterator itr = mlObjectList.iterator(); itr.hasNext();){
						mpLegInfo = (Map)itr.next();
						sType = (String)mpLegInfo.get("type");
						String sLegName =(String)mpLegInfo.get("name");
						//Modified by Bala for Defects #38629 and #38536 STARTS---
						if(((String)mpLegInfo.get(DomainConstants.SELECT_RELATIONSHIP_NAME)).equalsIgnoreCase(DomainConstants.RELATIONSHIP_EBOM)){
							mpLegInfo.put("disableSelection","true");
						}
						
						if(ConstantsUtil.TYPE_PGSTUDYLEG.equals(sType)) {
							//SPEC: <19.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- START
							StringList slList =FrameworkUtil.split(sLegName, " ");
							if(slList.size() !=0 && slList.size()>=2){
								i =Integer.parseInt(slList.get(1));  
							}
							mpLegInfo.put("SequenceOrder",String.valueOf(i));
							//SPEC: <19.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- END
							mlReturntList.add(mpLegInfo);
						}
						else {
							mpLegInfo.put("SequenceOrder","");
							mlLEGList.add(mpLegInfo);
						}						
						//Modified by Bala for Defects #38629 and #38536 ENDS---
					}
				}
				//SPEC: <19.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- START
				Collections.sort(mlReturntList, new Comparator<Map<String, String>>() {
					public int compare(final Map<String, String> map1, final Map<String, String> map2) {
						int count = 0;
						String str1 = ConstantsUtil.EMPTY_STRING;
						String str2 = ConstantsUtil.EMPTY_STRING;
						int rtn = 0;
						for (Map.Entry<String, String> pair1 : map1.entrySet()) {
							if (pair1.getKey().contains("SequenceOrder")) {
								str1 = pair1.getValue();
								
							}
							for (Map.Entry<String, String> pair2 : map2.entrySet()) {
								if (pair2.getKey().contains("SequenceOrder")) {
									str2 = pair2.getValue();
									
										if (UIUtil.isNotNullAndNotEmpty(str1) && UIUtil.isNotNullAndNotEmpty(str2)) {
											rtn = compareInt(Integer.parseInt(str1), Integer.parseInt(str2));
										}
									}
							}
						}
						return rtn;
					}

					private int compareInt(Integer valueOf, Integer valueOf2) {
						// TODO Auto-generated method stub

						int n = 0;
						if (valueOf == valueOf2) {
							n = 0;
						} else if (valueOf > valueOf2) {
							n = 1;
						} else if (valueOf < valueOf2) {
							n = -1;
						}
						return n;

					}
				});
				//SPEC: <19.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   --END
				
				Iterator itrLegAndPart = mlReturntList.iterator();
				while(itrLegAndPart.hasNext()) {
					//Modified by Bala for Defects #38629 and #38536 STARTS---
					objectMap = new HashMap();
					mLEGobjectMap = new HashMap();
					mpRelParts = new HashMap();
					objectMap = (Map) itrLegAndPart.next();
					
					StringBuilder sbType = new StringBuilder();
					StringBuilder sbChildId = new StringBuilder();
					StringBuilder sbChildTitle = new StringBuilder();
					//Added for defect# 38265 - START
					StringBuilder sbChildPartName = new StringBuilder();
					//Added for defect# 38265 - END
					StringBuilder sbChildDescription = new StringBuilder();
					StringBuilder sbChildNumOfPanel = new StringBuilder();
					StringBuilder sbChildTProdCodePanel = new StringBuilder();
					StringBuilder sbChildSiteOfOther = new StringBuilder();
					StringBuilder sbChildNumOfUnitsPerBag = new StringBuilder();
					StringBuilder sbChildTPackSite = new StringBuilder();
					StringBuilder sbChildWashOutTimeBetweenProducts = new StringBuilder();
					StringBuilder sbChildMicroMCT = new StringBuilder();
					StringBuilder sbChildTPanelCompletes = new StringBuilder();
					StringBuilder sbChildPlacements = new StringBuilder();
					StringBuilder sbChildUnitsToLabel = new StringBuilder();
					StringBuilder sbChildLabeling = new StringBuilder();
					StringBuilder sbChildStabilitySampleCount = new StringBuilder();
					StringBuilder sbChildAnalyticalSampleCount = new StringBuilder();
					StringBuilder sbChildNumberOfUnitsToShip = new StringBuilder();
					StringBuilder sbChildInventorySampleCount = new StringBuilder();
					StringBuilder sbChildTBatch = new StringBuilder();
					StringBuilder sbChildUnitWeight = new StringBuilder();
					StringBuilder sbChildIsProductRepacked = new StringBuilder();
					StringBuilder sbChildRelId = new StringBuilder();
					StringBuilder sbChildRelName = new StringBuilder();
					StringBuilder sbChildProdCode = new StringBuilder();
					StringBuilder sbChildLegPlantName = new StringBuilder();
					StringBuilder sbChildFreq = new StringBuilder();
					StringBuilder sbChildFreqTestProd = new StringBuilder(); // Added for Defect #38892
					StringBuilder sbChildRndTeamSampleCount = new StringBuilder();
					StringBuilder sbChildRndRetains = new StringBuilder();
					StringBuilder sbChildNetSampleCount = new StringBuilder();
					StringBuilder sbComments = new StringBuilder();
					
					StringBuilder sbLegTitle = new StringBuilder();
					StringBuilder sbLegType = new StringBuilder();
					StringBuilder sbLegDescription = new StringBuilder();
					StringBuilder sbLegNumOfPanel = new StringBuilder();
					StringBuilder sbLegTProdCodePanel = new StringBuilder();
					StringBuilder sbLegId = new StringBuilder();
					// Guna Added for Defect 38265  18x.5.2 Release -- START
					StringBuilder sbFreqTestProduct =  new StringBuilder();
					// Guna Added for Defect 38265  18x.5.2 Release -- END
					//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
					StringBuilder sbHasFile =  new StringBuilder();
					//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
					
					//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
					StringBuilder sbCurrent =  new StringBuilder();
					StringBuilder sbLegRev =  new StringBuilder();
					StringBuilder sbReleasePhase =  new StringBuilder();
					//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
					
					String sChildLevel = validatorUtil.getStringEquivalentForStringList(objectMap.get("level"));					

					sLEGName = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
					//Modified by Bala for Defects #38629 and #38536 ENDS---
					sChildTitle = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
					sChildType    =  validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
					sChildId = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
					//SPEC: <19.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- START
					DomainObject domLeg =DomainObject.newInstance(context, sChildId);
					//SPEC: <19.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- END
					sChildConnectionId = validatorUtil.getStringEquivalentForStringList(objectMap.get("id[connection]"));
					//SPEC: <19.04.2021>: Guna Modified for 42357 Defect  Dev 18x.6   -- START
					//sChildDescription = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
					sChildDescription = validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
					//SPEC: <19.04.2021>: Guna Modified for 42357 Defect  Dev 18x.6   -- END
					//<SPEC>09/02/2021 Modified by Govind for Defect #38892 start
					sChildNumOfPanel = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNUMBEROFPANELISTS));
					
					sChildTProdCodePanel = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTCODEPANELISTS));
					sChildNumOfUnitsPerBag = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNUMBEROFUNITSPERBAG));
					sChildTPackSite = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGRELPACKINGSITE));
					sChildWashOutTimeBetweenProducts = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWASHOUTTIMEBETWEENPRODUCTS));
					sChildMicroMCT = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMICROMCT));
					sChildTPanelCompletes = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTSCOMPLETES));
					sChildPlacements = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLACEMENTS));
					sChildUnitsToLabel = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGUNITSTOLABEL));
					//SPEC: <31.03.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- START
					//sChildLabeling = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLABELING));
					sChildLabeling = validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLABELING));
					//SPEC: <31.03.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- END
					sChildStabilitySampleCount = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTABILITYSAMPLECOUNT));
					sChildAnalyticalSampleCount = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGANALYTICALSAMPLECOUNT));
					sChildInventorySampleCount = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINVENTORYSAMPLECOUNT));
					sChildNumberOfUnitsToShip = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNUMBEROFUNITSTOSHIP));
					sChildTBatch = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCH));
					sChildUnitWeight = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGUNITWEIGHT));
					sChildIsProductRepacked = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISPRODUCTREPACKAGED));
					sChildRelId = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_ID));
					sChildRelName = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_NAME));
					sChildProdCode = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTCODE));
					//SPEC: <31.03.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- START
					//sChildLegPlantName = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_LEG_PLANTNAME));
					sChildLegPlantName = validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_LEG_PLANTNAME));
					//SPEC: <31.03.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- END
					sChildFreq = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRFREQUENCYSAMEASCURRENTMARKETPRODUCT));
					sChildRndTeamSampleCount = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRNDTEAMSAMPLECOUNT));
					//Added for defect# 38265 - START
					//String sChildComments = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS));
					sChildComments = validatorUtil.getStringEquivalentForStringListWithComma(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS));
					//Added for defect# 38265 - END
					sChildType = util.mapType(sChildType);
					//getPlants
					sPlant = getIRMDocPlantsFromRelationship(context, sChildId,sChildConnectionId);
					sNetSampleCount =  displayNetSampleCount(context, sChildId, sChildConnectionId, sChildLevel);
					//Modified by Bala for Defects #38629 and #38536 ENDS---
					// Guna Added for Defect 38265  18x.5.2 Release -- START
					sFreqTestProduct = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFREQUENCY));
					// Guna Added for Defect 38265  18x.5.2 Release -- END
					//SPEC: <14.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- START
					sLEGRev = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
					//SPEC: <14.04.2021>: Guna Added for 42357 Defect  Dev 18x.6   -- END
					//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
					String sHasFileAttached = ConstantsUtil.FALSE;
					String sGendocPath=validatorUtil.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.STR_FILE_CAPTURED));				
					if(sGendocPath.length()>1) // since | is added by default
					{
						sHasFileAttached = ConstantsUtil.TRUE;					
					}	
					//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END

					if(util.isModificatinRequired()) {
						showData = util.checkHasAccess(context, sUserType, sChildId);
					}else {
						showData = util.checkHasAccess(context, sUserType, sChildId);
					}
					//SPEC: <07.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- START
					 sCurrent =validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_CURRENT));
					if(!sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
						//sId = ConstantsUtil.EMPTY_STRING;
						sChildId = ConstantsUtil.NO_ACCESS;
					}
					//SPEC: <07.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- END
					//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
					sReleasePhase = validatorUtil.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASEPHASE));
					//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
					if(showData) {
						util.formatData(sbType,sChildType);
						util.formatData(sbChildId,sChildId);
						util.formatData(sbChildPartName,sLEGName);
						/*}*/
							//SPEC: <15.04.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- END
						util.formatData(sbChildTitle,sChildTitle);
						//Added for defect# 38265 - END
						util.formatData(sbChildDescription,sChildDescription);
						util.formatData(sbChildNumOfPanel,sChildNumOfPanel);
						util.formatData(sbChildFreqTestProd,sChildFreqTestProd);//<SPEC>09/02/2021 Added by Govind for Defect #38892 end
						util.formatData(sbChildTProdCodePanel,sChildTProdCodePanel);
						util.formatData(sbChildSiteOfOther,sPlant);
						util.formatData(sbChildNumOfUnitsPerBag,sChildNumOfUnitsPerBag);
						util.formatData(sbChildTPackSite,sChildTPackSite);
						util.formatData(sbChildWashOutTimeBetweenProducts,sChildWashOutTimeBetweenProducts);
						util.formatData(sbChildMicroMCT,sChildMicroMCT);
						util.formatData(sbChildTPanelCompletes,sChildTPanelCompletes);
						util.formatData(sbChildPlacements,sChildPlacements);
						util.formatData(sbChildUnitsToLabel,sChildUnitsToLabel);
						util.formatData(sbChildLabeling,sChildLabeling);
						util.formatData(sbChildStabilitySampleCount,sChildStabilitySampleCount);
						util.formatData(sbChildAnalyticalSampleCount,sChildAnalyticalSampleCount);
						util.formatData(sbChildRndRetains,sChildInventorySampleCount);
						util.formatData(sbChildNumberOfUnitsToShip,sChildNumberOfUnitsToShip);
						util.formatData(sbChildTBatch,sChildTBatch);
						util.formatData(sbChildUnitWeight,sChildUnitWeight);
						util.formatData(sbChildIsProductRepacked,sChildIsProductRepacked);
						util.formatData(sbChildRelId,sChildRelId);
						util.formatData(sbChildRelName,sChildRelName);
						util.formatData(sbChildProdCode,sChildProdCode);
						util.formatData(sbChildLegPlantName,sChildLegPlantName);
						util.formatData(sbChildFreq,sChildFreq);
						util.formatData(sbChildRndTeamSampleCount,sChildRndTeamSampleCount);
						util.formatData(sbChildNetSampleCount,sNetSampleCount);
						util.formatData(sbComments,sChildComments);
						//Added for defect# 38265 - START
						// Guna Added for Defect 38265  18x.5.2 Release -- START
						util.formatData(sbFreqTestProduct,sFreqTestProduct);
						// Guna Added for Defect 38265  18x.5.2 Release -- END
						
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
						util.formatData(sbHasFile,sHasFileAttached);
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
						//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbLegRev,sLEGRev);
						util.formatData(sbReleasePhase,sReleasePhase);
						//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
						LOGGER.info("sChildComments::::"+sChildComments);
						//Added for defect# 38265 - END
					}else {
						util.formatData(sbType,sChildType);
						util.formatData(sbChildId,ConstantsUtil.NO_ACCESS);
						util.formatData(sbChildPartName,sLEGName);						
						util.formatData(sbChildTitle,ConstantsUtil.NO_ACCESS);
						//Added for defect# 38265 - END
						util.formatData(sbChildDescription,ConstantsUtil.NO_ACCESS);
						util.formatData(sbChildNumOfPanel,ConstantsUtil.NO_ACCESS);
						util.formatData(sbChildFreqTestProd,sChildFreqTestProd);//<SPEC>09/02/2021 Added by Govind for Defect #38892 end
						util.formatData(sbChildTProdCodePanel,ConstantsUtil.NO_ACCESS);
						util.formatData(sbChildSiteOfOther,sPlant);
						util.formatData(sbChildNumOfUnitsPerBag,sChildNumOfUnitsPerBag);
						util.formatData(sbChildTPackSite,sChildTPackSite);
						util.formatData(sbChildWashOutTimeBetweenProducts,sChildWashOutTimeBetweenProducts);
						util.formatData(sbChildMicroMCT,sChildMicroMCT);
						util.formatData(sbChildTPanelCompletes,sChildTPanelCompletes);
						util.formatData(sbChildPlacements,sChildPlacements);
						util.formatData(sbChildUnitsToLabel,sChildUnitsToLabel);
						util.formatData(sbChildLabeling,sChildLabeling);
						util.formatData(sbChildStabilitySampleCount,sChildStabilitySampleCount);
						util.formatData(sbChildAnalyticalSampleCount,sChildAnalyticalSampleCount);
						util.formatData(sbChildRndRetains,sChildInventorySampleCount);
						util.formatData(sbChildNumberOfUnitsToShip,sChildNumberOfUnitsToShip);
						util.formatData(sbChildTBatch,sChildTBatch);
						util.formatData(sbChildUnitWeight,sChildUnitWeight);
						util.formatData(sbChildIsProductRepacked,sChildIsProductRepacked);
						util.formatData(sbChildRelId,sChildRelId);
						util.formatData(sbChildRelName,sChildRelName);
						util.formatData(sbChildProdCode,sChildProdCode);
						util.formatData(sbChildLegPlantName,sChildLegPlantName);
						util.formatData(sbChildFreq,sChildFreq);
						util.formatData(sbChildRndTeamSampleCount,sChildRndTeamSampleCount);
						util.formatData(sbChildNetSampleCount,sNetSampleCount);
						util.formatData(sbComments,sChildComments);
						util.formatData(sbFreqTestProduct,sFreqTestProduct);
						//SPEC: <19.03.2021>: Guna Modified for Req 38566 18x.6   -- END
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
						util.formatData(sbHasFile,sHasFileAttached);
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
						//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbLegRev,sLEGRev);
						util.formatData(sbReleasePhase,sReleasePhase);
						//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
					}
					//}	
					//Added by Bala for Defects #38629 and #38536 STARTS---
					//SPEC: <19.04.2021>: Guna Modified for 42357 Defect  Dev 18x.6   -- START
					mlLEGList = domLeg.getRelatedObjects(context,
							 ConstantsUtil.RELATIONSHIP_PGLEGINPUT,
							 DomainConstants.QUERY_WILDCARD,
							 typeSelects,
							 relSelects, 
							 false, 
							 true, 
							 (short)0, 
							 sWhere, 
							 null,	
							 0);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
					domLeg.close(context);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
					StringList duplicateList =new StringList();
					for (int j=0; j<mlLEGList.size(); j++) {						
						mLEGobjectMap = (Map) mlLEGList.get(j);					
						strChildFromName = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get("to[" + ConstantsUtil.RELATIONSHIP_PGLEGINPUT + "].from.name"));
						StringList slLEGObjectList = FrameworkUtil.split(strChildFromName,ConstantsUtil.SYMBL_PIPE);
			            if(!slLEGObjectList.isEmpty() && slLEGObjectList != null)
						{
				            for(int k = 0 ; k<slLEGObjectList.size() ; k++ )
				    		{
				            	strChildFromName = (String)slLEGObjectList.get(0);				    			
				    		}
						}
			            	
							sChildLevel = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get("level"));
							sChildName = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_NAME));
							sChildTitle = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
							sChildType    =  validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_TYPE));
							sChildId = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ID));
							sChildConnectionId = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get("id[connection]"));
							sChildDescription = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
							//<SPEC>09/02/2021 Modified by Govind for Defect #38892 start	
							sChildNumOfPanel = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNUMBEROFPANELISTS));
							//sChildNumOfPanel = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIRMTOTALNUMBEROFPANELISTS));
							//sChildFreqTestProd= validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFREQUENCY));
							//<SPEC>09/02/2021 Modified by Govind for Defect #38892 end
							sChildTProdCodePanel = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRODUCTCODEPANELISTS));
							//SPEC: <27.12.2021>: Guna Modified for 42924 Defect  Dev 18x.6.0.3   -- START
							sChildSiteOfOther = validatorUtil.getStringEquivalentForSubstituteString(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGSITEIFOTHERSELECTED));
							//SPEC: <27.12.2021>: Guna Modified for 42924 Defect  Dev 18x.6.0.3   -- END
							sChildNumOfUnitsPerBag = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGNUMBEROFUNITSPERBAG));
							sChildTPackSite = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGRELPACKINGSITE));
							sChildWashOutTimeBetweenProducts = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWASHOUTTIMEBETWEENPRODUCTS));
							sChildMicroMCT = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMICROMCT));
							sChildTPanelCompletes = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPANELISTSCOMPLETES));
							sChildPlacements = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLACEMENTS));
							sChildUnitsToLabel = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGUNITSTOLABEL));
							
							//SPEC: <31.03.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- START
							//sChildLabeling = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLABELING));
							sChildLabeling = validatorUtil.getStringEquivalentForSubstituteString(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGLABELING));
							//SPEC: <31.03.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- END
							sChildStabilitySampleCount = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTABILITYSAMPLECOUNT));
							sChildAnalyticalSampleCount = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGANALYTICALSAMPLECOUNT));
							sChildInventorySampleCount = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINVENTORYSAMPLECOUNT));
							sChildNumberOfUnitsToShip = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNUMBEROFUNITSTOSHIP));
							//SPEC: <15.04.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- START
							//sChildTBatch = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCH));
							sChildTBatch = validatorUtil.getStringEquivalentForSubstituteString(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATCH));
							//SPEC: <15.04.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- END
							sChildUnitWeight = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGUNITWEIGHT));
							sChildIsProductRepacked = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGISPRODUCTREPACKAGED));
							sChildRelId = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_ID));
							sChildRelName = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_RELATIONSHIP_NAME));
							sChildProdCode = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTCODE));
							//SPEC: <31.03.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- START
							//sChildLegPlantName = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_LEG_PLANTNAME));
							sChildLegPlantName = validatorUtil.getStringEquivalentForSubstituteString(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_LEG_PLANTNAME));
							//SPEC: <31.03.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- END
							sChildFreq = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPRFREQUENCYSAMEASCURRENTMARKETPRODUCT));
							sChildRndTeamSampleCount = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRNDTEAMSAMPLECOUNT));
							sChildComments = validatorUtil.getStringEquivalentForStringListWithComma(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS));
							sChildType = util.mapType(sChildType);
							//getPlants
							sPlant = getIRMDocPlantsFromRelationship(context, sChildId,sChildConnectionId);
							//SPEC: <26.04.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- START
							int iLevel =Integer.parseInt(sChildLevel);
							++iLevel;
							//sNetSampleCount =  displayNetSampleCount(context, sChildId, sChildConnectionId, sChildLevel);
							sNetSampleCount =  displayNetSampleCount(context, sChildId, sChildConnectionId, String.valueOf(iLevel));
							//SPEC: <26.04.2021>: Guna Modified for 41418 Defect  Dev 18x.6   -- END
							// Guna Added for Defect 38265  18x.5.2 Release -- START
							sFreqTestProduct = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFREQUENCY));
							// Guna Added for Defect 38265  18x.5.2 Release -- END	
							if(util.isModificatinRequired()) {
								showData = util.checkHasAccess(context, sUserType, sChildId);
							}else {
								showData = util.checkHasAccess(context, sUserType, sChildId);
							}
							//SPEC: <07.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- START
							 sCurrent =validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_CURRENT));
							if(!sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
								//sId = ConstantsUtil.EMPTY_STRING;
								sChildId = ConstantsUtil.NO_ACCESS;
							}
							//SPEC: <07.04.2021>: Guna Added for 40163 Defect  Dev 18x.6   -- END
							//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
							sLEGRev = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(DomainConstants.SELECT_REVISION));
							sReleasePhase = validatorUtil.getStringEquivalentForStringList(mLEGobjectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASEPHASE));
							//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
							if(showData) {
								util.formatData(sbType,sChildType);
								util.formatData(sbChildId,sChildId);								
								if(sChildType.equals("Leg")) {
									util.formatData(sbChildPartName,sChildTitle);
								}else {
									util.formatData(sbChildPartName,sChildName);
								}
								util.formatData(sbChildTitle,sChildTitle);								
								util.formatData(sbChildDescription,sChildDescription);
								util.formatData(sbChildNumOfPanel,sChildNumOfPanel);
								util.formatData(sbChildFreqTestProd,sChildFreqTestProd); // Added for Defect#38892
								util.formatData(sbChildTProdCodePanel,sChildTProdCodePanel);
								// Guna Modified for Defect 38265 18x.5.2 Release -- START
								util.formatData(sbChildSiteOfOther,sChildSiteOfOther);
								// Guna Modified for Defect 38265 18x.5.2 Release -- END
								util.formatData(sbChildNumOfUnitsPerBag,sChildNumOfUnitsPerBag);
								util.formatData(sbChildTPackSite,sChildTPackSite);
								util.formatData(sbChildWashOutTimeBetweenProducts,sChildWashOutTimeBetweenProducts);
								util.formatData(sbChildMicroMCT,sChildMicroMCT);
								util.formatData(sbChildTPanelCompletes,sChildTPanelCompletes);
								util.formatData(sbChildPlacements,sChildPlacements);
								util.formatData(sbChildUnitsToLabel,sChildUnitsToLabel);
								util.formatData(sbChildLabeling,sChildLabeling);
								util.formatData(sbChildStabilitySampleCount,sChildStabilitySampleCount);
								util.formatData(sbChildAnalyticalSampleCount,sChildAnalyticalSampleCount);
								util.formatData(sbChildRndRetains,sChildInventorySampleCount);
								util.formatData(sbChildNumberOfUnitsToShip,sChildNumberOfUnitsToShip);
								util.formatData(sbChildTBatch,sChildTBatch);
								util.formatData(sbChildUnitWeight,sChildUnitWeight);
								util.formatData(sbChildIsProductRepacked,sChildIsProductRepacked);
								util.formatData(sbChildRelId,sChildRelId);
								util.formatData(sbChildRelName,sChildRelName);
								util.formatData(sbChildProdCode,sChildProdCode);
								util.formatData(sbChildLegPlantName,sChildLegPlantName);
								util.formatData(sbChildFreq,sChildFreq);
								util.formatData(sbChildRndTeamSampleCount,sChildRndTeamSampleCount);
								util.formatData(sbChildNetSampleCount,sNetSampleCount);
								util.formatData(sbComments,sChildComments);	
								//SPEC: Release SR18x.5.2 - Commented for Defect# 38629  by Guna on Date 17/02/2021 -- START
								//util.formatData(sbComments,ConstantsUtil.NO_ACCESS);
								//SPEC: Release SR18x.5.2 - Commented for Defect# 38629  by Guna on Date 17/02/2021 -- END
								// Guna Added for Defect 38265  18x.5.2 Release -- START
								util.formatData(sbFreqTestProduct,sFreqTestProduct);
								// Guna Added for Defect 38265  18x.5.2 Release -- END
								//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
								util.formatData(sbHasFile,sHasFileAttached);
								//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
								//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
								util.formatData(sbCurrent,sCurrent);
								util.formatData(sbLegRev,sLEGRev);
								util.formatData(sbReleasePhase,sReleasePhase);
								//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
								LOGGER.info("sChildComments::::"+sChildComments);
							}else {
								util.formatData(sbType,sChildType);
								util.formatData(sbChildId,ConstantsUtil.NO_ACCESS);
								if(sChildType.equals("Leg")) {
									util.formatData(sbChildPartName,sChildTitle);
								}else {
									util.formatData(sbChildPartName,sChildName);
								}
																
								util.formatData(sbChildTitle,ConstantsUtil.NO_ACCESS);								
								util.formatData(sbChildDescription,ConstantsUtil.NO_ACCESS);
								util.formatData(sbChildNumOfPanel,ConstantsUtil.NO_ACCESS);
								util.formatData(sbChildFreqTestProd,sChildFreqTestProd); // Added for Defect#38892
								util.formatData(sbChildTProdCodePanel,ConstantsUtil.NO_ACCESS);
								util.formatData(sbChildSiteOfOther,sChildSiteOfOther);
								util.formatData(sbChildNumOfUnitsPerBag,sChildNumOfUnitsPerBag);
								util.formatData(sbChildTPackSite,sChildTPackSite);
								util.formatData(sbChildWashOutTimeBetweenProducts,sChildWashOutTimeBetweenProducts);
								util.formatData(sbChildMicroMCT,sChildMicroMCT);
								util.formatData(sbChildTPanelCompletes,sChildTPanelCompletes);
								util.formatData(sbChildPlacements,sChildPlacements);
								util.formatData(sbChildUnitsToLabel,sChildUnitsToLabel);
								util.formatData(sbChildLabeling,sChildLabeling);
								util.formatData(sbChildStabilitySampleCount,sChildStabilitySampleCount);
								util.formatData(sbChildAnalyticalSampleCount,sChildAnalyticalSampleCount);
								util.formatData(sbChildRndRetains,sChildInventorySampleCount);
								util.formatData(sbChildNumberOfUnitsToShip,sChildNumberOfUnitsToShip);
								util.formatData(sbChildTBatch,sChildTBatch);
								util.formatData(sbChildUnitWeight,sChildUnitWeight);
								util.formatData(sbChildIsProductRepacked,sChildIsProductRepacked);
								util.formatData(sbChildRelId,sChildRelId);
								util.formatData(sbChildRelName,sChildRelName);
								util.formatData(sbChildProdCode,sChildProdCode);
								util.formatData(sbChildLegPlantName,sChildLegPlantName);
								util.formatData(sbChildFreq,sChildFreq);
								util.formatData(sbChildRndTeamSampleCount,sChildRndTeamSampleCount);
								util.formatData(sbChildNetSampleCount,sNetSampleCount);
								util.formatData(sbComments,sChildComments);	
								util.formatData(sbFreqTestProduct,sFreqTestProduct);
								//SPEC: <19.03.2021>: Guna Modified for Req 38566 18x.6   -- END
								//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
								util.formatData(sbHasFile,sHasFileAttached);
								//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
								//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
								util.formatData(sbCurrent,sCurrent);
								util.formatData(sbLegRev,sLEGRev);
								util.formatData(sbReleasePhase,sReleasePhase);
								//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
							}								
						
					}
					
					mpRelParts.put(ConstantsUtilIRM.LEGDETAILS, sbChildPartName.toString());
					//Added for defect# 38265 - END
					mpRelParts.put(ConstantsUtil.TYPE, sbType.toString());
					mpRelParts.put(ConstantsUtil.TITLE, sbChildTitle.toString());
					mpRelParts.put(ConstantsUtil.DESCRIPTION, sbChildDescription.toString());
					mpRelParts.put(ConstantsUtilIRM.TOTALNUMBEROFPANELSINLEG, sbChildNumOfPanel.toString());
					mpRelParts.put(ConstantsUtilIRM.NUMBEROFPRODUCTCODESPANELISTSWILLRECEIVE, sbChildTProdCodePanel.toString());
					mpRelParts.put(ConstantsUtilIRM.PART, sbChildPartName.toString());
					//Added for defect# 38265 - END
					mpRelParts.put(ConstantsUtilIRM.PRODUCTCODE, sbChildProdCode.toString());
					mpRelParts.put(ConstantsUtilIRM.SITEFORPRODUCTMANUFACTURING, sbChildLegPlantName.toString());
					mpRelParts.put(ConstantsUtilIRM.SITEOFOTHER, sbChildSiteOfOther.toString());
					mpRelParts.put(ConstantsUtilIRM.FREQUENCYMARKETPRODUCT, sbChildFreq.toString());
					// Guna Modified for Defect 38265  18x.5.2 Release -- START
					//mpRelParts.put(ConstantsUtilIRM.FREQUENCYOFTESTPRODUCT, sbChildSiteOfOther.toString());
					mpRelParts.put(ConstantsUtilIRM.FREQUENCYOFTESTPRODUCT, sbFreqTestProduct.toString());
					// Guna Modified for Defect 38265  18x.5.2 Release -- END
					mpRelParts.put(ConstantsUtilIRM.NUMBEROFUNITSPERPANELISTS, sbChildNumOfUnitsPerBag.toString());
					mpRelParts.put(ConstantsUtilIRM.PACKAGINGSITE, sbChildTPackSite.toString());
					mpRelParts.put(ConstantsUtilIRM.WASHOUTTIMEBETWEENPRODUCTS, sbChildWashOutTimeBetweenProducts.toString());
					mpRelParts.put(ConstantsUtilIRM.SELECTALLENTRIES, "");//todo
					
					//TABLE 3
					//Added for defect# 38265 - START
					//mpRelParts.put(ConstantsUtilIRM.PART, sbChildTitle.toString());
					mpRelParts.put(ConstantsUtilIRM.PART, sbChildPartName.toString());
					//Added for defect# 38265 - END
					mpRelParts.put(ConstantsUtilIRM.PROVIDESPECIFICMCT, sbChildMicroMCT.toString());
					mpRelParts.put(ConstantsUtilIRM.NUMBEROFPANELISTCOMPLETES, sbChildTPanelCompletes.toString());
					mpRelParts.put(ConstantsUtilIRM.NUMBEROFPANELISTSPLACEMENTS, sbChildPlacements.toString());
					mpRelParts.put(ConstantsUtilIRM.NUMBEROFUNITSTOLABEL, sbChildUnitsToLabel.toString());
					mpRelParts.put(ConstantsUtilIRM.LABELDESCRIPTION, sbChildLabeling.toString());
					mpRelParts.put(ConstantsUtilIRM.ISPRODUCTREPACKAGED, sbChildIsProductRepacked.toString());
					mpRelParts.put(ConstantsUtilIRM.UNITWEIGHTORVOLUME, sbChildUnitWeight.toString());
					mpRelParts.put(ConstantsUtilIRM.STABILITYSAMPLECOUNT, sbChildStabilitySampleCount.toString());
					mpRelParts.put(ConstantsUtilIRM.ANALYTICALSAMPLECOUNT, sbChildAnalyticalSampleCount.toString());
					
					//TABLE 4
					//Added for defect# 38265 - START
					//mpRelParts.put(ConstantsUtilIRM.PART, sbChildTitle.toString());
					mpRelParts.put(ConstantsUtilIRM.PART, sbChildPartName.toString());
					//Added for defect# 38265 - END
					mpRelParts.put(ConstantsUtilIRM.RDSAMPLECOUNT, sbChildRndTeamSampleCount.toString());
					mpRelParts.put(ConstantsUtilIRM.RDRETAINS, sbChildRndRetains.toString());
					mpRelParts.put(ConstantsUtilIRM.NUMBEROFUNITSTOSHIP, sbChildNumberOfUnitsToShip.toString());
					mpRelParts.put(ConstantsUtilIRM.NETSAMPLECOUNT, sbChildNetSampleCount.toString());
					mpRelParts.put(ConstantsUtilIRM.BATCHMANUFLOT, sbChildTBatch.toString());
					mpRelParts.put(ConstantsUtil.COMMENTS, sbComments.toString());
					
					//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- START
					mpRelParts.put(ConstantsUtil.STATE, sbCurrent.toString());
					mpRelParts.put(ConstantsUtil.REVISION, sbLegRev.toString());
					mpRelParts.put(ConstantsUtil.RELEASEPHASE, sbReleasePhase.toString());
					//SPEC: <05.04.2022>: Guna Added for Req 36041 22x Release  -- END
					//Added for defect# 38265 - START
					LOGGER.info("Comment::::"+sbComments);
					//Added for defect# 38265 - END
					mpRelParts.put(ConstantsUtil.ID, sbChildId.toString());
					
					//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
					mpRelParts.put(ConstantsUtilIRM.ISFILEATTACHED, sbHasFile.toString());
					//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
					
				//Added by Bala for Defects #38629 and #38536 STARTS---	
					//SPEC: <20.04.2021>: Guna Modified for 42357 Defect  Dev 18x.6   -- START
					if(mlLEGList.size() !=0 ){
					//mpLEGResult.put(String.valueOf(index), mpRelParts);
					mpLEGResult.put(index, mpRelParts);
					}
					//SPEC: <20.04.2021>: Guna Modified for 42357 Defect  Dev 18x.6   -- END
					//mpLEGResult.put(index, mpRelParts);
					index++;
				//SPEC: Release SR18x.5.2 - Removed for Defect# 38629  by Bala on Date Feb 11, 2021 -- START
				//}	
				//SPEC: Release SR18x.5.2 - Removed for Defect# 38629  by Bala on Date Feb 11, 2021 -- END		
				}	
				//Map<Integer, String> treeMap = new TreeMap(mpLEGResult);
				//mpLEGResult
				return mpLEGResult;
				//Added by Bala for Defects #38629 and #38536 ENDS---
	        }
	        catch (Exception ex)
	        {
	        	LOGGER.error("Exception in Program : CommonDocBO Method :getLegDetails "+ex);
	            ex.printStackTrace();
	            return new HashMap();
	        }
	    }
	
	 	/**
	 	 * getIRMDocPlantsFromRelationship
	 	 * @param context
	 	 * @param objectId
	 	 * @param relInputId
	 	 * @return String
	 	 */
	 	public String getIRMDocPlantsFromRelationship(Context context, String objectId, String relInputId ) {
		 	String strType = ConstantsUtil.TYPE_PLANT;
			String strRelName = ConstantsUtilIRM.RELATIONSHIP_PG_MANUFACTURINGRESPONSIBILITY_LEG;
			String plantName = "tomid[" + strRelName + "].from.name";
			StringList relSelects = new StringList();
			relSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			relSelects.add(plantName);
			StringValidatorUtil validator = new StringValidatorUtil();
			StringBuilder sbValue = new StringBuilder();
			String[] sRelIdArray = new String[1];
			String sValue = "";
			try {
				if (validator.isNotNullOrEmpty(relInputId)) {
					DomainObject sdomObject = DomainObject.newInstance(context, objectId);
					String sTypeFrom =(String) sdomObject.getInfo(context, DomainConstants.SELECT_TYPE);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
					sdomObject.close(context);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
					sRelIdArray[0] = relInputId;
					MapList mlObj = DomainRelationship.getInfo(context,sRelIdArray, relSelects);
					Map mRelatedObject = (Map)mlObj.get(0);
					Object obj   = (Object) mRelatedObject.get(plantName);
					if(obj != null) {
						if (obj instanceof StringList) {
							StringList strListPlantName = (StringList)mRelatedObject.get(plantName);
							for (String str : strListPlantName){
									sbValue.append(str);
									sbValue.append(ConstantsUtil.SEPARATOR);
							}
						} else {
							String plantNameFromRel = (String)mRelatedObject.get(plantName);
							String setPlantName = (plantNameFromRel == null) ? "" : plantNameFromRel;
							sbValue.append(setPlantName);
						}
					}
				sValue = sbValue.toString();
				if(sValue.endsWith(ConstantsUtil.SEPARATOR))
					sValue = sValue.substring(0,sValue.length()-1);
				
			}
		 }catch(Exception e) {
			LOGGER.error("Exception in Program : CommonDocBO Method :getIRMDocPlantsFromRelationship "+e);
			e.printStackTrace();
			return "";
		 }
		 return sValue;
	 }
	 
	 	
	 	/**
	 	 * displayNetSampleCount
	 	 * @param context
	 	 * @param objectId
	 	 * @param sRelId
	 	 * @param slevel
	 	 * @return String
	 	 * @throws Exception
	 	 */
	 	public String displayNetSampleCount(Context context, String objectId, String sRelId, String slevel) throws Exception {
			Map<?,?> tempObjMap = null;
			String sNetSampleCount = DomainConstants.EMPTY_STRING;
			String[] sRelIdArray = new String[1];
			Map mapObj = null;
			int mapObjSize =0;
			MapList mlObj = new MapList();
			String sStabilitySampleCount ="";
			String sAnalyticalSampleCount ="";
			String sRnDTeamSampleCount ="";
			String sInventorySampleCount ="";
			String sNumberOfUnitsToShip ="";
			
			int iStabilitySampleCount = 0;
			int iAnalyticalSampleCount = 0;
			int iRnDTeamSampleCount = 0;
			int iInventorySampleCount = 0;
			int iNumberOfUnitsToShip = 0;
			int iNetSampleCount = 0;
			
			StringList slObjSelect = new StringList(5);
			slObjSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSTABILITYSAMPLECOUNT);
			slObjSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGANALYTICALSAMPLECOUNT);
			slObjSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGRNDTEAMSAMPLECOUNT);
			slObjSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGINVENTORYSAMPLECOUNT);
			slObjSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGNUMBEROFUNITSTOSHIP);
			StringValidatorUtil validator = new StringValidatorUtil();
			StringBuilder sbResult = new StringBuilder();
			
			try {
					sRelIdArray[0] = sRelId;
					String strObj = sRelIdArray[0];
					if(validator.isNotNullOrEmpty(strObj) ) {
						mlObj = DomainRelationship.getInfo(context,sRelIdArray, slObjSelect);
						mapObjSize = mlObj.size();
						for(int j=0; j<mapObjSize; j++){
							mapObj = (Map) mlObj.get(j);
							if(!ConstantsUtilIRM.STR_ZERO.equals(slevel) && !ConstantsUtilIRM.STR_ONE.equals(slevel)) {
								sStabilitySampleCount = (String) mapObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTABILITYSAMPLECOUNT);
								sAnalyticalSampleCount	= (String) mapObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGANALYTICALSAMPLECOUNT);
								sRnDTeamSampleCount 		= (String) mapObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRNDTEAMSAMPLECOUNT);
								sInventorySampleCount 	= (String) mapObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINVENTORYSAMPLECOUNT);
								sNumberOfUnitsToShip 	= (String) mapObj.get(ConstantsUtil.SELECT_ATTRIBUTE_PGNUMBEROFUNITSTOSHIP);
								if(!validator.isNotNullOrEmpty(sStabilitySampleCount)){
									sStabilitySampleCount= ConstantsUtilIRM.STR_ZERO;
								} if(!validator.isNotNullOrEmpty(sAnalyticalSampleCount)){
									sAnalyticalSampleCount = ConstantsUtilIRM.STR_ZERO;
								} if(!validator.isNotNullOrEmpty(sRnDTeamSampleCount)){
									sRnDTeamSampleCount = ConstantsUtilIRM.STR_ZERO;
								} if(!validator.isNotNullOrEmpty(sInventorySampleCount)){
									sInventorySampleCount = ConstantsUtilIRM.STR_ZERO;
								} if (!validator.isNotNullOrEmpty(sNumberOfUnitsToShip)){	
									sNumberOfUnitsToShip = ConstantsUtilIRM.STR_ZERO;
								}
								iStabilitySampleCount		= Integer.parseInt(sStabilitySampleCount);					
								iAnalyticalSampleCount 		= Integer.parseInt(sAnalyticalSampleCount);
								iRnDTeamSampleCount 		= Integer.parseInt(sRnDTeamSampleCount);
								iInventorySampleCount 		= Integer.parseInt(sInventorySampleCount);
								iNumberOfUnitsToShip 		= Integer.parseInt(sNumberOfUnitsToShip);
								iNetSampleCount = iStabilitySampleCount + iAnalyticalSampleCount + iRnDTeamSampleCount
									+ iInventorySampleCount + iNumberOfUnitsToShip;
								sNetSampleCount 				= Integer.toString(iNetSampleCount);
							}
						}
					}				
					sbResult.append(sNetSampleCount);
			}catch (Exception e) {
				LOGGER.error("Exception in Program : CommonDocBO Method :displayNetSampleCount "+e);
				e.printStackTrace();
			}
			return sbResult.toString();
		}
	
	 	/**
	 	 * getMultipleOwnershipAccess
	 	 * @param context
	 	 * @param parentId
	 	 * @return Map
	 	 * @throws Exception
	 	 */
	 	public Map getMultipleOwnershipAccess(Context context, String parentId) throws Exception {
	 		Map mpMultipleOwnerAccess = new HashMap();
	 		StringBuilder sbAccessId = new StringBuilder();
	 		StringBuilder sbAccess = new StringBuilder();
	 		StringBuilder sbLevel = new StringBuilder();
	 		StringBuilder sbOrg = new StringBuilder();
	 		StringBuilder sbHasChildren = new StringBuilder();
	 		StringBuilder sbName = new StringBuilder();
	 		StringBuilder sbProject = new StringBuilder();
	 		StringBuilder sbComment = new StringBuilder();
	 		StringBuilder sbUserName = new StringBuilder();
	 		StringBuilder sbType = new StringBuilder();
	 		StringBuilder sbInheritedFrom = new StringBuilder();
	 		StringBuilder sbInheritedAccess = new StringBuilder();
	 		try {
	 			MapList results = getObjectAccessList(context, parentId);
		 		if(null!=results) {
		 			Iterator itr = results.iterator();
			     	while(itr.hasNext()) {
			     		Map mpAccess = (Map) itr.next();
			     		String sAccessId = (String) mpAccess.get("accessId");
			     		String sAccess = (String) mpAccess.get("access");
			     		String sLevel = (String) mpAccess.get("level");
			     		String sOrg = (String) mpAccess.get("org");
			     		String sHasChildren = (String) mpAccess.get("hasChildren");
			     		String sName = (String) mpAccess.get("name");
			     		String sProject = (String) mpAccess.get("project");
			     		String sComment = (String) mpAccess.get("comment");
			     		String sUserName = (String) mpAccess.get("username");
			     		String sType = ConstantsUtilIRM.SECURITY_CONTEXT;
			     		if(sOrg.isEmpty()) {
			     			sType = ConstantsUtilIRM.PERSON;
			     		}
			     		
			     		util.formatData(sbAccessId, sAccessId);
			     		util.formatData(sbAccess, sAccess);
			     		util.formatData(sbLevel, sLevel);
			     		util.formatData(sbOrg, sOrg);
			     		util.formatData(sbHasChildren, sHasChildren);
			     		util.formatData(sbName, sName);
			     		util.formatData(sbProject, sProject);
			     		util.formatData(sbComment, sComment);
			     		util.formatData(sbUserName, sUserName);
			     		util.formatData(sbType, sType);
			     		util.formatData(sbInheritedFrom, "");//todo
			     		util.formatData(sbInheritedAccess, "");//todo
			     		
			     	}
		 		}
		     	mpMultipleOwnerAccess.put(ConstantsUtil.TYPE, sbType.toString());
		 		mpMultipleOwnerAccess.put(ConstantsUtil.ORGANIZATIONS, sbOrg.toString());
		 		mpMultipleOwnerAccess.put(ConstantsUtilIRM.COLLABORATIVESPACEUSERGRP, sbProject.toString());
		 		mpMultipleOwnerAccess.put(ConstantsUtilIRM.INHERITEDFROM, sbInheritedFrom.toString());//todo
		 		mpMultipleOwnerAccess.put(ConstantsUtilIRM.ACCESS, sbAccess.toString());
		 		mpMultipleOwnerAccess.put(ConstantsUtilIRM.INHERITEDACCESS, sbInheritedAccess.toString());//todo
		 		mpMultipleOwnerAccess.put(ConstantsUtil.COMMENTS, sbComment.toString());
	 		}catch(Exception ex) {
	 			LOGGER.error("Exception in Program : CommonDocBO Method :getMultipleOwnershipAccess "+ex);
	 		}
			return mpMultipleOwnerAccess;
	 	}
	 	
	 	
	 	/**
	 	 * getPlatformChassis
	 	 * @param context
	 	 * @param parentId
	 	 * @return Map
	 	 * @throws Exception
	 	 */
	 	public Map getPlatformChassis(Context context, String parentId) throws Exception {
	 		Map mpPlatformChassis = new HashMap();
	 		StringValidatorUtil validator = new StringValidatorUtil();
	 		Map<String, String> connectedObjectIds = new LinkedHashMap();
	 		try {
	 			String sFranchisePlatform = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds, ConstantsUtilIRM.FRANCHISE_PLATFORM, ConstantsUtilIRM.FRANCHISE_PLATFORM);
		 		String sProductCategoryPlatform = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds, ConstantsUtilIRM.PRODUCT_CATEGORY_PLATFORM, ConstantsUtilIRM.PRODUCT_CATEGORY_PLATFORM);
		 		String sMaterialPlatform = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds, ConstantsUtilIRM.MATERIAL_PLATFORM, ConstantsUtilIRM.MATERIAL_PLATFORM);
		 		String sTechnicalBuildingBlocks = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds,
		 				ConstantsUtilIRM.TECHNICAL_BUILDING_BLOCKS, ConstantsUtilIRM.TECHNICAL_BUILDING_BLOCKS);
		 		String sProductTechnologyPlatform = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds,
		 				ConstantsUtilIRM.PRODUCT_TECHNOLOGY_PLATFORM, ConstantsUtilIRM.PRODUCT_TECHNOLOGY_PLATFORM);
		 		String sProductTechnologyChassis = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds,
		 				ConstantsUtilIRM.PRODUCT_TECHNOLOGY, ConstantsUtilIRM.PRODUCT_TECHNOLOGY);
		 		String sPackagePlatform = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds,
		 				ConstantsUtilIRM.PACKAGE_PLATFORM, ConstantsUtilIRM.PACKAGE_PLATFORM);
		 		String sPackageChassis = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds,
		 				ConstantsUtilIRM.PACKAGE, ConstantsUtilIRM.PACKAGE);
		 		String sProductProcessPlatform = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds,
		 				ConstantsUtilIRM.PRODUCT_PROCESS_PLATFORM, ConstantsUtilIRM.PRODUCT_PROCESS_PLATFORM);
		 		String sPackageProcessPlatform = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds,
		 				ConstantsUtilIRM.PACKAGE_PROCESS_PLATFORM, ConstantsUtilIRM.PACKAGE_PROCESS_PLATFORM);
		 		String sProductEquipmentPlatform = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds,
		 				ConstantsUtilIRM.PRODUCT_EQUIPMENT_PLATFORM, ConstantsUtilIRM.PRODUCT_EQUIPMENT_PLATFORM);
		 		String sPackageEquipmentPlatform = displayAllIRMPlatformAndChassisValue(context, parentId, connectedObjectIds,
		 				ConstantsUtilIRM.PACKAGE_EQUIPMENT_PLATFORM, ConstantsUtilIRM.PACKAGE_EQUIPMENT_PLATFORM);
		 		
		 		//SPEC: <24.03.2021>: Guna Modified for Defect 41519 Dev 18x.6   -- START
		 		/*mpPlatformChassis.put(ConstantsUtilIRM.FRANCHISEPLATFORM, validator.getStringEquivalentForStringListWithComma(sFranchisePlatform));
		 		mpPlatformChassis.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM, validator.getStringEquivalentForStringListWithComma(sProductCategoryPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.MATERIALPLATFORM, validator.getStringEquivalentForStringListWithComma(sMaterialPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.TECHNICALBUILDINGBLOCKS, validator.getStringEquivalentForStringListWithComma(sTechnicalBuildingBlocks));
		 		mpPlatformChassis.put(ConstantsUtil.PRODUCTTECHNOLOGYPLATFORM, validator.getStringEquivalentForStringListWithComma(sProductTechnologyPlatform));
		 		mpPlatformChassis.put(ConstantsUtil.PRODUCTTECHNOLOGYCHASSIS, validator.getStringEquivalentForStringListWithComma(sProductTechnologyChassis));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PACKAGEPLATFORM, validator.getStringEquivalentForStringListWithComma(sPackagePlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PACKAGECHASSIS, validator.getStringEquivalentForStringListWithComma(sPackageChassis));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PRODUCTPROCESSPLATFORM, validator.getStringEquivalentForStringListWithComma(sProductProcessPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PACKAGEPROCESSPLATFORM, validator.getStringEquivalentForStringListWithComma(sPackageProcessPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PRODUCTEQUIPMENTPLATFORM, validator.getStringEquivalentForStringListWithComma(sProductEquipmentPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PACKAGEEQUIPMENTPLATFORM, validator.getStringEquivalentForStringListWithComma(sPackageEquipmentPlatform));
		 		*/
		 		mpPlatformChassis.put(ConstantsUtilIRM.FRANCHISEPLATFORM, validator.getStringEquivalentForStringList(sFranchisePlatform));
		 		mpPlatformChassis.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM, validator.getStringEquivalentForStringList(sProductCategoryPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.MATERIALPLATFORM, validator.getStringEquivalentForStringList(sMaterialPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.TECHNICALBUILDINGBLOCKS, validator.getStringEquivalentForStringList(sTechnicalBuildingBlocks));
		 		mpPlatformChassis.put(ConstantsUtil.PRODUCTTECHNOLOGYPLATFORM, validator.getStringEquivalentForStringList(sProductTechnologyPlatform));
		 		mpPlatformChassis.put(ConstantsUtil.PRODUCTTECHNOLOGYCHASSIS, validator.getStringEquivalentForStringList(sProductTechnologyChassis));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PACKAGEPLATFORM, validator.getStringEquivalentForStringList(sPackagePlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PACKAGECHASSIS, validator.getStringEquivalentForStringList(sPackageChassis));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PRODUCTPROCESSPLATFORM, validator.getStringEquivalentForStringList(sProductProcessPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PACKAGEPROCESSPLATFORM, validator.getStringEquivalentForStringList(sPackageProcessPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PRODUCTEQUIPMENTPLATFORM, validator.getStringEquivalentForStringList(sProductEquipmentPlatform));
		 		mpPlatformChassis.put(ConstantsUtilIRM.PACKAGEEQUIPMENTPLATFORM, validator.getStringEquivalentForStringList(sPackageEquipmentPlatform));
		 		
		 		//SPEC: <24.03.2021>: Guna Modified for Defect 41519 Dev 18x.6   -- END
	 		}catch(Exception ex) {
	 			LOGGER.error("Exception in Program : CommonDocBO Method :getPlatformChassis "+ex);
	 			ex.printStackTrace();
	 		}
	 		
			return mpPlatformChassis;
	 	}
	 	
	 	
	 	
	 	/**
	 	 * getObjectAccessList
	 	 * @param context
	 	 * @param id
	 	 * @return MapList
	 	 * @throws Exception
	 	 */
	 	public MapList getObjectAccessList(Context context, String id) throws Exception {
	 		MapList results = null;
	 		try {
	 			if(UIUtil.isNotNullAndNotEmpty(id))
		     	{
	 				//SPEC: Release SR18x.5.2 - Modified for Defect 39737 by Sanjeeva ## -- START
		     		
	 				DomainObject domObj = DomainObject.newInstance(context, id);
		     		id = domObj.getInfo(context,DomainConstants.SELECT_ID);
		     		//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
		     		domObj.close(context);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
				//Spec: Chandra Modified for Defect 38605  18x.5.2 Release -- START
		     		//SPEC: <04.03.2021>: Guna Modified for Dev 18x.6   -- START
	 				results = DomainAccess.getAccessSummaryList(context, id);
	 				//SPEC: <04.03.2021>: Guna Modified for Dev 18x.6   -- END
	 			//Spec: Chandra Modified for Defect 38605  18x.5.2 Release -- END
		     	}
 				
	 			//SPEC: Release SR18x.5.2 - Modified for Defect 39737 by Sanjeeva ## -- START
	 			
	 		}catch(Exception ex) {
	 			LOGGER.error("Exception in Program : CommonDocBO Method :getObjectAccessList "+ex);
	 			//ex.printStackTrace();
	 		}
	     	
	     	return results;

	     }
	 	
	 	/**
	 	 * displayAllIRMPlatformAndChassisValue
	 	 * @param context
	 	 * @param strDocId
	 	 * @param connectedObjectIds
	 	 * @param strPicklistCategory
	 	 * @param strfieldName
	 	 * @return String
	 	 * @throws Exception
	 	 */
	 	public String displayAllIRMPlatformAndChassisValue(Context context, String strDocId, Map<String, String> connectedObjectIds, String strPicklistCategory,
				String strfieldName) throws Exception {
			StringList sRangevalueList = new StringList();
			MapList mlObjPlatChassisBADetails = findPlatChassBAPicklistObjDetailsOfIRMDoc(context, strDocId);
			if (!mlObjPlatChassisBADetails.isEmpty()) {
				mlObjPlatChassisBADetails.sort("name", "ascending", "String");
				Map<String, String> mapPickListItem;
				String strPickListName = null;
				String strPickListId = null;
				String strPickListType = null;
				String strFieldType = null;
				
				if ((UIUtil.isNotNullAndNotEmpty(strPicklistCategory))) {
					strFieldType = getTypeFromAttribute(strPicklistCategory);
				}
				
				if (ConstantsUtilIRM.PG_BUSINESS_AREA.equalsIgnoreCase(strfieldName)) {
					strFieldType = ConstantsUtilIRM.TYPE_PG_PLI_BUSINESSAREA;
				}
				for (int i = 0; i < mlObjPlatChassisBADetails.size(); i++) {
					mapPickListItem = (Map<String, String>) mlObjPlatChassisBADetails.get(i);
					strPickListId = mapPickListItem.get(DomainConstants.SELECT_ID);
					strPickListName = mapPickListItem.get(DomainConstants.SELECT_NAME);
					connectedObjectIds.put(strPickListName+"|"+strPickListId, strPickListId);
					strPickListType = mapPickListItem.get(DomainConstants.SELECT_TYPE);
					if (strFieldType.equals(strPickListType)) {
						sRangevalueList.add(strPickListName);
					}
				}
			}
			return sRangevalueList.toString();
		}
	 	
	 	/**
	 	 * findPlatChassBAPicklistObjDetailsOfIRMDoc
	 	 * @param context
	 	 * @param strDocId
	 	 * @return MapList
	 	 * @throws Exception
	 	 */
	 	private MapList findPlatChassBAPicklistObjDetailsOfIRMDoc(Context context, String strDocId) throws Exception {
			MapList mlObjPlatChassisBADetails = new MapList();
			StringList slPlatformSelectList = new StringList();
			try {
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_FRANCHISEPLATFORM);
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCTCATEGORYPLATFORM);
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYPLATFORM_IRMDOCS);
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCTPROCESSPLATFORM);
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCTEQUIPMENTPLATFORM);
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKAGEPLATFORM);
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKAGEPROCESSPLATFORM);
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALPLATFORM);
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_TECHNICALBUILDINGBLOCKS);
				slPlatformSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKAGEEQUIPMENTPLATFORM);
				StringList slChassisSelectList = new StringList();
				slChassisSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PRODUCTTECHNOLOGYCHASSIS_IRMDOCS);
				slChassisSelectList.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PACKAGECHASSIS);
				StringList slObjectSelects = new StringList(13);
				slObjectSelects.addAll(slPlatformSelectList);
				slObjectSelects.addAll(slChassisSelectList);
				slObjectSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_BUSINESSAREA);
				MapList mlObjectPlatformChassisBANames = DomainObject.getInfo(context, new String[] { strDocId }, slObjectSelects);
				Map<?, ?> mapObjPlatChassisBANames = (Map<?, ?>) mlObjectPlatformChassisBANames.get(0);
				mlObjPlatChassisBADetails
						.addAll(findObjectDetails(context, ConstantsUtilIRM.TYPE_PG_PLI_BUSINESSAREA, getInfoFromMapAsStringList(mapObjPlatChassisBANames, new StringList(ConstantsUtilIRM.SELECT_ATTRIBUTE_BUSINESSAREA))));
				mlObjPlatChassisBADetails.addAll(findObjectDetails(context, ConstantsUtilIRM.TYPE_PG_PLIPLATFORM, getInfoFromMapAsStringList(mapObjPlatChassisBANames, slPlatformSelectList)));
				mlObjPlatChassisBADetails.addAll(findObjectDetails(context, ConstantsUtilIRM.TYPE_PG_PLICHASSIS, getInfoFromMapAsStringList(mapObjPlatChassisBANames, slChassisSelectList)));
			
			}catch(Exception e) {
				LOGGER.error("Exception in Program : CommonDocBO Method :findPlatChassBAPicklistObjDetailsOfIRMDoc "+e);
				e.printStackTrace();
			}
			
			return mlObjPlatChassisBADetails;
		}
	 	
	 	
	 	/**
	 	 * getInfoFromMapAsStringList
	 	 * @param map
	 	 * @param slSelectList
	 	 * @return StringList
	 	 */
	 	private StringList getInfoFromMapAsStringList(Map map, StringList slSelectList) {
			StringList slValues = new StringList();
			for (String strSelect : slSelectList) {
				String strValue = (String) map.get(strSelect);
				slValues.addAll(StringUtil.split(strValue, SelectConstants.cSelectDelimiter));
			}
			return slValues;
		}
	 	
	 	
	 	/**
	 	 * findObjectDetails
	 	 * @param context
	 	 * @param strTypePattern
	 	 * @param slNameList
	 	 * @return MapList
	 	 * @throws Exception
	 	 */
	 	public MapList findObjectDetails(Context context, String strTypePattern, StringList slNameList) throws Exception {
	 		MapList mapReturnList=new MapList();
	 		try {
	 			
				if(slNameList.size() > 0) {
					StringList objectSelects = new StringList(2);
					objectSelects.add(DomainConstants.SELECT_ID);
					objectSelects.add(DomainConstants.SELECT_NAME);
					objectSelects.add(DomainConstants.SELECT_TYPE);
					Pattern strNamePattern = new Pattern(slNameList.get(0));
					for (int i = 1, nSize = slNameList.size(); i < nSize; i++) {
						strNamePattern.addPattern(slNameList.get(i));
					}
					mapReturnList = DomainObject.findObjects(context, //MatrixContext
							strTypePattern, //typePattern
							strNamePattern.getPattern(), //namePattern
							DomainConstants.QUERY_WILDCARD, //revPattern
							DomainConstants.QUERY_WILDCARD, //ownerPattern
							ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
							null, //whereExpression
							true, //expandType
							objectSelects); //objectSelects
					
				}
	 		}catch(Exception e) {
	 			LOGGER.error("Exception in Program : CommonDocBO Method :findObjectDetails "+e);
	 			e.printStackTrace();
	 		}
			return mapReturnList;
			
		}
	 	
	 	
	 	/**
	 	 * getTypeFromAttribute
	 	 * @param strRelAttrName
	 	 * @return String
	 	 */
	 	public String getTypeFromAttribute(String strRelAttrName) {
			switch (strRelAttrName) {
				case ConstantsUtilIRM.FRANCHISE_PLATFORM:
					return ConstantsUtilIRM.TYPE_FRANCHISE_PLATFORM;
				case ConstantsUtilIRM.PRODUCT_CATEGORY_PLATFORM:
					return ConstantsUtilIRM.TYPE_PRODUCT_CATEGORY_PLATFORM;
				case ConstantsUtilIRM.PRODUCT_TECHNOLOGY_PLATFORM:
					return ConstantsUtilIRM.TYPE_PRODUCT_TECHNOLOGY_PLATFORM;
				case ConstantsUtilIRM.PRODUCT_PROCESS_PLATFORM:
					return ConstantsUtilIRM.TYPE_PRODUCT_PROCESS_PLATFORM;
				case ConstantsUtilIRM.PRODUCT_EQUIPMENT_PLATFORM:
					return ConstantsUtilIRM.TYPE_PRODUCT_EQUIPMENT_PLATFORM;
				case ConstantsUtilIRM.PACKAGE_PLATFORM:
					return ConstantsUtilIRM.TYPE_PACKAGE_PLATFORM;
				case ConstantsUtilIRM.PACKAGE_PROCESS_PLATFORM:
					return ConstantsUtilIRM.TYPE_PACKAGE_PROCESS_PLATFORM;
				case ConstantsUtilIRM.MATERIAL_PLATFORM:
					return ConstantsUtilIRM.TYPE_MATERIAL_PLATFORM;
				case ConstantsUtilIRM.TECHNICAL_BUILDING_BLOCKS:
					return ConstantsUtilIRM.TYPE_TECHNICAL_BUILDING_BLOCKS;
				case ConstantsUtilIRM.PACKAGE_EQUIPMENT_PLATFORM:
					return ConstantsUtilIRM.TYPE_PACKAGE_EQUIPMENT_PLATFORM;
				case ConstantsUtilIRM.PACKAGE:
					return ConstantsUtilIRM.TYPE_PACKAGE_CHASSIS;
				case ConstantsUtilIRM.PRODUCT_TECHNOLOGY:
					return ConstantsUtilIRM.TYPE_PRODUCT_TECHNOLOGY_CHASSIS;
				default:
					return null;
			}
		}
	 	
	 	
	 	
	 	/**
	 	 * getAllGPSAssessmentTask
	 	 * @param context
	 	 * @param strObjectId
	 	 * @return MapList
	 	 * @throws Exception
	 	 */
	 	public Map getAllGPSAssessmentTask(Context context, String strObjectId) throws Exception
		{
			MapList mlGPSAssessmentsList = null;
			MapList mlGPSAssessmentList1 = null;
			MapList mlGPSAssessmentList2 = null;
			StringBuilder sbStatus = new StringBuilder();
			StringBuilder sbTaskName = new StringBuilder();
			StringBuilder sbNRQName = new StringBuilder();
			Map mpGPSAssessment = new HashMap();
			
			MapList mlGPSAssessmentUniqueTaskList = new MapList();
			int imlDeliverablesSize;
			int projectDataMapListSize;
			Map docMap = null;
			Map mpTaskInfo = new HashMap();
			Map mpTaskInfo1 = null;
			String sName = null;
			String sTaskName =null;
			String strDeliverableId = null;
			try {
				StringList slObjSel = new StringList(4);
				String strType = null;
				slObjSel.add(DomainConstants.SELECT_ID);
				slObjSel.add(DomainConstants.SELECT_NAME);
				slObjSel.add(DomainConstants.SELECT_CURRENT);
				slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGPSASSESSMENTCATEGORY);
				slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGPSSTATUS);
				slObjSel.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTASKNAME);
				Pattern sRelPattern = new Pattern(ConstantsUtilIRM.RELATIONSHIP_PGGPSASSESSMENTTASKINPUTS);
				sRelPattern.addPattern(ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT);
				Pattern sTypePattern = new Pattern(ConstantsUtil.TYPE_PGGPSASSESSMENTTASK);
				sTypePattern.addPattern(ConstantsUtilIRM.TYPE_DOCUMENTS);
				DomainObject domObj1=null;
				if(UIUtil.isNotNullAndNotEmpty(strObjectId))
				{
					DomainObject domObj = DomainObject.newInstance(context, strObjectId);
					mlGPSAssessmentsList = domObj.getRelatedObjects(context,
							ConstantsUtilIRM.RELATIONSHIP_PGGPSASSESSMENTTASKINPUTS,
							ConstantsUtil.TYPE_PGGPSASSESSMENTTASK,
							slObjSel, //objectSelects
							null, //relationshipSelects
							true, //getTo
							false, //getFrom
							(short)1, //recurseToLevel
							null, //objectWhere
							null, //relationshipWhere
							0);
					mlGPSAssessmentList1 = domObj.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
							ConstantsUtilIRM.TYPE_DOCUMENTS,
							slObjSel, //objectSelects
							null, //relationshipSelects
							true, //getTo
							false, //getFrom
							(short)1, //recurseToLevel
							null, //objectWhere
							null, //relationshipWhere
							0);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
					domObj.close(context);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
					if (mlGPSAssessmentList1 != null && !mlGPSAssessmentList1.isEmpty()) {
						imlDeliverablesSize = mlGPSAssessmentList1.size();
						for (int iDeliverables = 0; iDeliverables < imlDeliverablesSize; iDeliverables++) {
							docMap = (Map) mlGPSAssessmentList1.get(iDeliverables);
							strDeliverableId = (String) docMap.get(DomainObject.SELECT_ID);
							if(UIUtil.isNotNullAndNotEmpty(strDeliverableId))
							{
								domObj1 = DomainObject.newInstance(context, strDeliverableId);
								mlGPSAssessmentList2 = domObj1.getRelatedObjects(context,
										ConstantsUtilIRM.RELATIONSHIP_PGGPSASSESSMENTTASKINPUTS,
										ConstantsUtil.TYPE_PGGPSASSESSMENTTASK,
										slObjSel, //objectSelects
										null, //relationshipSelects
										true, //getTo
										false, //getFrom
										(short)1, //recurseToLevel
										null, //objectWhere
										null, //relationshipWhere
										0);
								//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
								domObj1.close(context);
								//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
							}
							mlGPSAssessmentsList.addAll(mlGPSAssessmentList2);
						}
					}
					if (mlGPSAssessmentsList != null && !mlGPSAssessmentsList.isEmpty()) {
						projectDataMapListSize = mlGPSAssessmentsList.size();
						for (int iprojectDataMapList = 0; iprojectDataMapList < projectDataMapListSize; iprojectDataMapList++) {
							mpTaskInfo = (Map) mlGPSAssessmentsList.get(iprojectDataMapList);
							sName = (java.lang.String) mpTaskInfo.get("name");
							int count = 0;
							for (int iprojectDataMapList1 = iprojectDataMapList+1 ; iprojectDataMapList1 < projectDataMapListSize; iprojectDataMapList1++) {
								mpTaskInfo1 = (Map) mlGPSAssessmentsList.get(iprojectDataMapList1);
								sTaskName = (java.lang.String) mpTaskInfo1.get("name");
								if (sTaskName.equals(sName)) {
									count++;
								} 
							}
							if (count == 0 ) {
								mlGPSAssessmentUniqueTaskList.add(mpTaskInfo);
							}
						}
					}
				}
				
				Iterator itr = mlGPSAssessmentUniqueTaskList.iterator();
				while(itr.hasNext()) 
				{
					Map objectMap = (Map) itr.next();
					String sStatus    =  (String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGGPSSTATUS);
					String sTask    =  (String)objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTASKNAME);
					String sNRQName    =  (String)objectMap.get(ConstantsUtil.SELECT_NAME);
					util.formatData(sbStatus, sStatus);
					util.formatData(sbTaskName, sTask);
					util.formatData(sbNRQName, sNRQName);
				}
				
				mpGPSAssessment.put(ConstantsUtilIRM.STATUS_IRM, sbStatus.toString());
				mpGPSAssessment.put(ConstantsUtilIRM.TASKNAME_IRM, sbTaskName.toString());
				mpGPSAssessment.put(ConstantsUtilIRM.NRQID, sbNRQName.toString());
				
			}catch(Exception e){
				LOGGER.error("Exception in Program : CommonDocBO Method :getAllGPSAssessmentTask "+e);
				e.printStackTrace();
			}

			return mpGPSAssessment;
		}
	 	
	 	// SPEC: Added for 18x.5.2 DEV --Guna -- START
	/**
	 * TO display the Product Form 
	 * getProductFormSizeValue
	 * @return String
	 * @throws Exception
	 */
	public String getProductFormSizeValue(Context context, String strObjId, String relationshipProductform, String typePliproductform) throws Exception{
		String sReturn =ConstantsUtil.EMPTY_STRING;
		String SELECT_NAME="from["+relationshipProductform+"].to["+typePliproductform+"].name";	
		DomainObject domObj =DomainObject.newInstance(context, strObjId);
		StringList oldName = domObj.getInfoList(context,SELECT_NAME);
		//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
		domObj.close(context);
		//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
		for(int i=0;i<oldName.size();i++){
			String strListTemp = (String)oldName.get(i);
			if(sReturn.length()>0){
				sReturn = sReturn+ " | " +strListTemp;
			}
			else {
				sReturn = strListTemp;
			}
		}
		return sReturn;	
	}
	// SPEC: Added for 18x.5.2 DEV --Guna -- END
	
	
	// SPEC: Release SR18x.5.2 - Added for Defect 38203 by Amman ## -- START
	/**
	 * Method Name 			: displayProjectId
	 * Method Description 	: 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public String displayProjectId (Context context, Map resultMap) throws Exception 
	{
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		String sReturn 					= ConstantsUtil.EMPTY_STRING;
		try{
			Map mBM 					= new HashMap();
			Map mProj 					= new HashMap();
			String sObjectID 			= (String)resultMap.get(DomainConstants.SELECT_ID);
			String sProjectId 			= ConstantsUtil.EMPTY_STRING;
			String sProjectName 		= ConstantsUtil.EMPTY_STRING;
			String sBMId 				= ConstantsUtil.EMPTY_STRING;
			int iThree 					= 3;
			DomainObject doDoc 			= DomainObject.newInstance(context, sObjectID);
			StringBuilder sbHTMLBuilder = new StringBuilder();
			StringList slProjectID 		= new StringList();
			StringList slProjectName 	= new StringList();
			StringList slObjectSelect 	= new StringList(5);
			slObjectSelect.add("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.id");
			slObjectSelect.add("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGPKGPROJECTID + "].value");
			slObjectSelect.add(DomainConstants.SELECT_ID);
			slObjectSelect.add("to[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTKEYACCESS + "].from.from[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTACCESSLIST + "].to.attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGPKGPROJECTID + "].value");
			slObjectSelect.add("to[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTKEYACCESS + "].from.from[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTACCESSLIST + "].to.id");
			
			StringList slObjectSelectFolder = new StringList(2);
			//SPEC: <15.06.2021>: Guna Modified for 43590 Defect  Dev 18x.6.0.1   -- START
			//slObjectSelectFolder.add("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.id");
			//slObjectSelectFolder.add("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGPKGPROJECTID + "].value");
			slObjectSelectFolder.add("to[Project Vaults].from.id");
			slObjectSelectFolder.add("to[Project Vaults].from.attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGPKGPROJECTID + "].value");
			//SPEC: <15.06.2021>: Guna Modified for 43590 Defect  Dev 18x.6.0.1   -- END
			
			Pattern relPattern 	= new Pattern(ConstantsUtilIRM.RELATIONSHIP_VAULTDOCUMENTREV2);
			relPattern.addPattern(ConstantsUtilIRM.RELATIONSHIP_PGRITASKINPUTS);
			relPattern.addPattern(ConstantsUtilIRM.RELATIONSHIP_TASKDELIVERABLE);

			Pattern typePattern = new Pattern(ConstantsUtilIRM.TYPE_WORKSPACEVAULT);
			typePattern.addPattern(ConstantsUtilIRM.TYPE_TASK);
			MapList mlProject = null;
			DomainObject doBM = null;
			MapList mlBM 		= doDoc.getRelatedObjects(context, relPattern.getPattern(), typePattern.getPattern(), slObjectSelect, null, true, false, (short)1, null, null);
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
			doDoc.close(context);
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
			if(mlBM.size() > 0)
			{
				Iterator itrBM 		= mlBM.iterator();
				while(itrBM.hasNext())
				{
					mBM 			= (Map)itrBM.next();				
					sProjectId		=(String)mBM.get("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.id");
					sProjectName	=(String)mBM.get("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGPKGPROJECTID + "].value");
					
					if (UIUtil.isNullOrEmpty(sProjectId))
					{
						sProjectId		=(String)mBM.get("to[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTKEYACCESS + "].from.from[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTACCESSLIST + "].to.id");
						sProjectName	=(String)mBM.get("to[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTKEYACCESS + "].from.from[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTACCESSLIST + "].to.attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGPKGPROJECTID + "].value");
					}
					if (UIUtil.isNotNullAndNotEmpty(sProjectId) && !slProjectID.contains(sProjectId))
					{
						slProjectID.add(sProjectId);
						slProjectName.add(sProjectName);
					}
					else
					{
						sBMId					=(String)mBM.get(DomainConstants.SELECT_ID);
						doBM 					= DomainObject.newInstance(context, sBMId);
						mlProject 				= doBM.getRelatedObjects(context, ConstantsUtilIRM.RELATIONSHIP_SUBVAULTS, ConstantsUtilIRM.TYPE_WORKSPACEVAULT, slObjectSelectFolder, null, true, false, (short)0, null, null);
						//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
						doBM.close(context);
						//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
						if(mlProject.size() > 0)
						{
							Iterator itrProj 	= mlProject.iterator();
							while(itrProj.hasNext())
							{
								mProj 			= (Map)itrProj.next();				
								sProjectId		=(String)mProj.get("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.id");
								if (UIUtil.isNotNullAndNotEmpty(sProjectId) && !slProjectID.contains(sProjectId))
								{
									sProjectName=(String)mProj.get("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.attribute[" + ConstantsUtilIRM.ATTRIBUTE_PGPKGPROJECTID + "].value");
									slProjectID.add(sProjectId);
									slProjectName.add(sProjectName);
								}
							}
						}
					}
				}
			}
			sReturn = validator.getStringEquivalentForSubstituteString(slProjectName);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			sReturn = ConstantsUtil.EMPTY_STRING;
		}
		return sReturn;
	}
	
	
	/**
	 * Method Name 			: displayProjectName
	 * Method Description 	:
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public String displayProjectName(Context context, Map resultMap) throws Exception 
	{
		Map<String,String> mpAttribResult = new HashMap<String,String>();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		String sReturn = ConstantsUtil.EMPTY_STRING;
		try {
		  Map<Object, Object> mpBookmark = new HashMap<>();
		  Map<Object, Object> mpProject = new HashMap<>();
		  String sObjectID = (String)resultMap.get(DomainConstants.SELECT_ID);
		  String sProjectId = ConstantsUtil.EMPTY_STRING;
		  String sProjectName = ConstantsUtil.EMPTY_STRING;
		  String sBookmarkId = ConstantsUtil.EMPTY_STRING;
		  int intThree = 3;
		  MapList mlProject = new MapList();
		  DomainObject doBookmark = null;
		  DomainObject doDoc = DomainObject.newInstance(context, sObjectID);
		  StringBuilder sbHTMLBuilder = new StringBuilder();
		  StringList slProjectID = new StringList();
		  StringList slProjectName = new StringList();
		  StringList slObjectSelect = new StringList(5);
		  slObjectSelect.add("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.id");
		  slObjectSelect.add("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.name");
		  slObjectSelect.add(DomainConstants.SELECT_ID);
		  slObjectSelect.add("to[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTKEYACCESS + "].from.from[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTACCESSLIST + "].to.name");
		  slObjectSelect.add("to[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTKEYACCESS + "].from.from[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTACCESSLIST + "].to.id");
		  
		  StringList slObjectSelectFolder = new StringList(2);

		  slObjectSelectFolder.add("to[Project Vaults].from.id");
		  slObjectSelectFolder.add("to[Project Vaults].from.name");
		  
		  Pattern relPattern = new Pattern(ConstantsUtilIRM.RELATIONSHIP_VAULTDOCUMENTREV2);
		  relPattern.addPattern(ConstantsUtilIRM.RELATIONSHIP_PGRITASKINPUTS);
		  relPattern.addPattern(ConstantsUtilIRM.RELATIONSHIP_TASKDELIVERABLE);
		  
		  Pattern typePattern = new Pattern(ConstantsUtilIRM.TYPE_WORKSPACEVAULT);
		  typePattern.addPattern(ConstantsUtilIRM.TYPE_TASK);
		  
		  MapList mlBookMark = doDoc.getRelatedObjects(context, relPattern
		      .getPattern(), typePattern
		      .getPattern(), slObjectSelect, null, true, false, (short)1, null, null);
		//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
		  doDoc.close(context);
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
		  if (mlBookMark.size() > 0)
		  {
		    Iterator<Map<Object, Object>> itrBookMark = mlBookMark.iterator();
		    while (itrBookMark.hasNext()) 
		    {
		      mpBookmark = itrBookMark.next();
		      sProjectId = (String)mpBookmark.get("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.id");
		      sProjectName = (String)mpBookmark.get("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.name");
		      if (UIUtil.isNullOrEmpty(sProjectId)) 
		      {
		        sProjectId = (String)mpBookmark.get("to[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTKEYACCESS + "].from.from[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTACCESSLIST + "].to.id");
		        sProjectName = (String)mpBookmark.get("to[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTKEYACCESS + "].from.from[" + ConstantsUtilIRM.RELATIONSHIP_PROJECTACCESSLIST + "].to.name");
		      } 
		      if (UIUtil.isNotNullAndNotEmpty(sProjectId) && !slProjectID.contains(sProjectId)) 
		      {
		        slProjectID.add(sProjectId);
		        slProjectName.add(sProjectName);
		        continue;
		      } 
		      sBookmarkId = (String)mpBookmark.get("id");
		      doBookmark = DomainObject.newInstance(context, sBookmarkId);
		      mlProject = doBookmark.getRelatedObjects(context, ConstantsUtilIRM.RELATIONSHIP_SUBVAULTS, ConstantsUtilIRM.TYPE_WORKSPACEVAULT, slObjectSelectFolder, null, true, false, (short)0, null, null);
		       //SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
		        doBookmark.close(context);
				//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
		      if (mlProject.size() > 0) 
		      {
		        Iterator<Map<Object, Object>> itrProj = mlProject.iterator();
		        while (itrProj.hasNext()) 
		        {
		          mpProject = itrProj.next();
		          sProjectId = (String)mpProject.get("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.id");
		          
		          if (UIUtil.isNotNullAndNotEmpty(sProjectId) && !slProjectID.contains(sProjectId)) 
		          {
		            sProjectName = (String)mpProject.get("to[" + ConstantsUtilIRM.RELATIONSHIP_DATA_VAULT + "].from.name");
		            slProjectID.add(sProjectId);
		            slProjectName.add(sProjectName);
		          } 
		        } 
		      } 
		    } 
		  }
		  sReturn = validator.getStringEquivalentForSubstituteString(slProjectName);
		}
		catch (Exception e) 
		{
		  e.printStackTrace();
		  sReturn = ConstantsUtil.EMPTY_STRING;
		} 
		return sReturn;
	}
	// SPEC: Release SR18x.5.2 - Added for Defect 38203 by Amman ## -- END
	
	
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 -- START
	/**
	 * Method Name : getRelatedPartsData
	 * Method Description : Fetching "Related Part" details for ATS (External User)
	 * @param context
	 * @param resultMaps
	 * @return
	 */
	public Map<String, String> getRelatedPartsData(Context context, Map resultMaps) {
		StringValidatorUtil validator = new StringValidatorUtil();
        String partId = (String) resultMaps.get(ConstantsUtil.ID);                  
        MapList relatedPartList = new MapList();
        Map mpRelatedParts = new HashMap();
        
        StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType=new StringBuilder();
		StringBuilder sbRev=new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbTitle=new StringBuilder();
		StringBuilder sbPhase=new StringBuilder();
		
		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
		StringBuilder sbHasFile =  new StringBuilder();
		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
		
		StringList selectStmts = new StringList();                     
		selectStmts.add(ConstantsUtil.TYPE);
		selectStmts.add(ConstantsUtil.NAME);
		selectStmts.add(ConstantsUtil.SELECT_CURRENT);
		selectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		selectStmts.add(ConstantsUtil.SELECT_REVISION);
		selectStmts.add(ConstantsUtil.ID);
		selectStmts.add(ConstantsUtil.OWNERSHIP);
		selectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		selectStmts.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		selectStmts.add(ConstantsUtil.STR_IPCLASS);
		selectStmts.add(ConstantsUtil.STR_IPCLASS_TYPE);
		selectStmts.add("last.current");
		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
		selectStmts.add(ConstantsUtil.STR_FILE_CAPTURED);
		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
		boolean isHir=false;
		
		StringList selectRelStmts = new StringList(2);
		selectRelStmts.add(DomainConstants.SELECT_RELATIONSHIP_ID); 
		selectRelStmts.add(DomainConstants.SELECT_RELATIONSHIP_NAME);
		
		Pattern relPattern = new Pattern(ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION);
		
		SecurityService sct = new SecurityService();
		
		String sUserlicense = sct.getUserLicense();
		
		boolean showData = false;
		boolean bHasOwnerShip = false;
		String sWhere =ConstantsUtil.EMPTY_STRING;
		
		SecurityService ss = new SecurityService();
		String sUserCompanies = ss.getUserCauthorities();
		String[] aCompany = sUserCompanies.split(",");
		StringBuilder sbCompany = new StringBuilder();
		
		if(aCompany.length>-1) {
			for(int i=0;i<aCompany.length;i++) {
				if(null!=aCompany[i]) {
					String Company = aCompany[i].toString();
					sbCompany.append(Company.trim().replace(" Plant", "")).append("|");
				}
			}
		}
		
		
        try
        {
        	DomainObject aTSpartObj =  DomainObject.newInstance(context, partId) ;

        	Pattern typePattern = new Pattern("");
        	StringList slAllowedObjectList = new StringList();
        	slAllowedObjectList = FrameworkUtil.split(ConstantsUtil.IMPACTED_TYPES_PARTS,ConstantsUtil.SYMBL_COMMA);
        	if(!slAllowedObjectList.isEmpty() && slAllowedObjectList != null)
        	{
        		for(int j = 0 ; j<slAllowedObjectList.size() ; j++ )
        		{
        			String strAllowedType = PropertyUtil.getSchemaProperty(context,(String)slAllowedObjectList.get(j));
        			if(!typePattern.match(strAllowedType))
        			{
        				typePattern.addPattern(strAllowedType);
        			}
        		}
        	}

        	String sUserProjectlicense = sct.getProjectLicenses();
        	
        	relatedPartList = aTSpartObj.getRelatedObjects(context,
        			relPattern.getPattern(),  //relationship pattern 
        			typePattern.getPattern(), // object pattern
        			selectStmts,                 // object selects
        			selectRelStmts,              // relationship selects
        			false,                        // to direction
        			true,                       // from direction
        			(short)1,   	// recursion level
        			null,//sWhere,                        // object where clause
        			null,
        			0);
        	//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
        	aTSpartObj.close(context);
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
        	Iterator objectListItr = relatedPartList.iterator();

        	String sPartId= ConstantsUtil.EMPTY_STRING;
        	StringList slHIRTypes = new StringList();
        	slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
        	slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
        	slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
        	slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
        	slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
        	while(objectListItr.hasNext()) 
        	{

        		Map objectMap = (Map) objectListItr.next();

        		String sPartType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.TYPE)));
        		if(slHIRTypes.contains(sPartType)) {
        			isHir=true;
        		}
        		String sPartName = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.NAME)));
        		String sPartState = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_CURRENT)));
        		
        		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 23, 2021 for Defect 41409 -- START
        		//String sPartTitle = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
        		String sPartTitle = validator.getStringEquivalentForStringListWithComma((objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
        		//SPEC: Release SR18x.6.0 - Added by Amman on Mar 23, 2021 for Defect 41409 -- END
        		
        		String sPartRev = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.SELECT_REVISION)));
        		sPartId = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.ID)));
        		String sPartOwnership = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.OWNERSHIP)));

        		String strClassFied = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.STR_IPCLASS));
        		String sPartClassType = validator.getStringEquivalentForStringList((objectMap.get(ConstantsUtil.STR_IPCLASS_TYPE)));

        		String sIPClassfication = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
        		String sPhase = validator.getStringEquivalentForStringList( objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE));

        		String strPreviousRev =validator.getStringEquivalentForStringList( objectMap.get("last.current"));
        		if(!sPartState.equals(ConstantsUtil.STATE_RELEASE) && (!sPartState.equals(ConstantsUtil.STATE_OBSOLETE))){
        			if(!strPreviousRev.equals(ConstantsUtil.STATE_OBSOLETE)){
        				continue;
        			}
        		}
        		
        		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
        		
        		//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 18, 2021 for Defect raised by Internal Testing Team -- START
        		String sHasFileAttached = ConstantsUtil.FALSE;
        		/*
				String sGendocPath=validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.STR_FILE_CAPTURED));				
				if(sGendocPath.length()>1) // since | is added by default
				{
					sHasFileAttached = ConstantsUtil.TRUE;					
				}	
				*/
        		//String TYPE_EXTERNAL_MATERIAL= PropertyUtil.getSchemaProperty("type_ExternalMaterial");
        		if(!sPartType.equals(ConstantsUtil.TYPE_INTERNAL_MATERIAL) || !sPartType.equals(ConstantsUtil.TYPE_QUALIFICATION) || !sPartType.equals(ConstantsUtilIRM.TYPE_EXTERNAL_MATERIAL))
				{
					
					sHasFileAttached = ConstantsUtil.TRUE;					
				}
				//SPEC: Release SR18x.6.0.1 - Modified by Amman on May 18, 2021 for Defect raised by Internal Testing Team -- END
				
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 06, 2021 for Req #33248 -- START
				if (!util.isModificatinRequired()) 
				{
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 06, 2021 for Req #33248 -- END
					util.formatData(sbHasFile,sHasFileAttached);
				//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END

					util.formatData(sbName,sPartName);
					util.formatData(sbType,util.mapType(sPartType));
					util.formatData(sbPhase,sPhase);
					util.formatData(sbRev,sPartRev);
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 06, 2021 for Req #33248 -- START
				}
				//SPEC: Release SR18x.6.0.1 - Added by Amman on May 06, 2021 for Req #33248 -- END
				
        		if (util.isModificatinRequired()) 
        		{
        			bHasOwnerShip = util.checkHasAccess(context, null, sPartId);
        			
        			if(bHasOwnerShip) 
        			{
        				if(!sPartState.equals(ConstantsUtil.RELEASE) &&  !sPartState.equals(ConstantsUtil.RELEASED)) {
        					//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 03, 2021 for Req #39652 -- START
        					util.formatData(sbId,ConstantsUtil.NO_ACCESS);
        					//continue;
        					util.formatData(sbHasFile,sHasFileAttached);
        					util.formatData(sbName,sPartName);
        					util.formatData(sbType,util.mapType(sPartType));
        					util.formatData(sbPhase,sPhase);
        					util.formatData(sbRev,sPartRev);
        					util.formatData(sbTitle,sPartTitle);
            				util.formatData(sbCurrent,sPartState);
        				}else {
        					util.formatData(sbId,sPartId);
        					util.formatData(sbHasFile,sHasFileAttached);
        					util.formatData(sbName,sPartName);
        					util.formatData(sbType,util.mapType(sPartType));
        					util.formatData(sbPhase,sPhase);
        					util.formatData(sbRev,sPartRev);
        					util.formatData(sbTitle,sPartTitle);
            				util.formatData(sbCurrent,sPartState);
            				//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 03, 2021 for Req #39652 -- END
        				}
        			}else
        			{
        				//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 03, 2021 for Req #39652 -- START
        				//continue;
        				util.formatData(sbId,ConstantsUtil.NO_ACCESS);
    					util.formatData(sbHasFile,sHasFileAttached);
    					util.formatData(sbName,sPartName);
    					util.formatData(sbType,util.mapType(sPartType));
    					util.formatData(sbPhase,sPhase);
    					util.formatData(sbRev,sPartRev);
    					util.formatData(sbTitle,sPartTitle);
        				util.formatData(sbCurrent,sPartState);
        				//SPEC: Release SR18x.6.0.1 - Modified by Amman on June 03, 2021 for Req #39652 -- END
        			}
        		}else if(sct.isStaffAUGUser()) {
        			showData = util.checkHasAccess(context, null, sPartId);
        		}else {
        			showData = util.checkHasAccess(context, null, sPartId);
        			
        			if(sPartClassType.contains("Security Control Class")){
        				if(!util.checkHasAccess(context, null, sPartId))
        				{
        					showData=false;
        				}
        			}
        		}
        		
        		if (!util.isModificatinRequired()) {
        			if(showData) 
        			{
        				if(!sPartState.equals(ConstantsUtil.RELEASE) &&  !sPartState.equals(ConstantsUtil.RELEASED)) {
        					util.formatData(sbId,ConstantsUtil.NO_ACCESS);
        				}else {
        					util.formatData(sbId,sPartId);
        				}

        				util.formatData(sbRev,sPartRev);
        				util.formatData(sbTitle,sPartTitle);
        				util.formatData(sbCurrent,sPartState);
        			}else
        			{
        				util.formatData(sbId,ConstantsUtil.NO_ACCESS);
        				util.formatData(sbRev,sPartRev);
        				util.formatData(sbTitle,ConstantsUtil.NO_ACCESS);
        				util.formatData(sbCurrent,ConstantsUtil.NO_ACCESS);
        			}
        		}

        		mpRelatedParts.put(ConstantsUtil.ID, sbId.toString());
        		mpRelatedParts.put(ConstantsUtil.NAME, sbName.toString());
        		mpRelatedParts.put(ConstantsUtil.TYPE, sbType.toString());
        		mpRelatedParts.put(ConstantsUtil.REVISION, sbRev.toString());
        		mpRelatedParts.put(ConstantsUtil.TITLE, sbTitle.toString());
        		mpRelatedParts.put(ConstantsUtil.STATE, sbCurrent.toString());
        		mpRelatedParts.put(ConstantsUtil.PHASE, sbPhase.toString());
        		//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
        		mpRelatedParts.put(ConstantsUtilIRM.ISFILEATTACHED, sbHasFile.toString());
    			//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
        	}
        }catch(Exception e)
        {
        	LOGGER.error("Exception in Program : CommonDocBo Method :getRelatedParts "+e);
			return new HashMap();
        }
        return mpRelatedParts ;
	}
	//SPEC: Release SR18x.6.0 - Added by Amman on Mar 15, 2021 -- END
	//SPEC: <19.03.2021>: Guna Added for Internal Defect 18x.6   -- START
	public String updateFileSize(StringList fileSizeList) {
		StringBuilder sbFileSize =new StringBuilder();
		try {
			if(fileSizeList.size() !=0){
				for (String strFileSize : fileSizeList) {
					double dblFileSize = Double.parseDouble(strFileSize);
		    		DecimalFormat decFormat = new DecimalFormat("0.00");
		    		String sFileSize=ConstantsUtil.EMPTY_STRING;
		    		if(dblFileSize <= 512){
		    			sFileSize = strFileSize + " B";
		    		} else if(dblFileSize > 512 && dblFileSize <= (1024*512)){
		    			sFileSize = decFormat.format(dblFileSize / 1024) + " KB";
		    		}else if(dblFileSize > (1024*512) && dblFileSize <= (1024*1024*512)){
		    			sFileSize = decFormat.format(dblFileSize / (1024*1024)) + " MB";
		    		}else if(dblFileSize > (1024*1024*512)){
		    			sFileSize = decFormat.format(dblFileSize / (1024*1024*1024)) + " GB";
		    		}else{
		    			sFileSize = strFileSize;
		    		}
						util.formatData(sbFileSize, sFileSize);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		// TODO Auto-generated method stub
		return sbFileSize.toString();
	}
	//SPEC: <19.03.2021>: Guna Added for Internal Defect 18x.6   -- END
	
	//SPEC: <23.03.2021>: Guna Added for 41277 Defect 18x.6   -- START
	/**
	 * Method Name 			: getReferenceDocsForIRM
	 * Method Description 	:
	 * @param context
	 * @param resultMaps
	 * @param bisIRMDoc 
	 * @return
	 */
	//SPEC: <25.03.2021>: Guna Modified for 41277 Defect 18x.6   -- START
	public Map getReferenceDocsForIRM(Context context,Map resultMaps, boolean bisIRMDoc) 
	{
		//SPEC: <25.03.2021>: Guna Modified for 41277 Defect 18x.6   -- END
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringList busSelect = new StringList();
		StringValidatorUtil validator = new StringValidatorUtil();
		
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		

		String sObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;

		Map<String, String> mpRefDocs = new HashMap();
		try
		{
			
			//DomainObject dobCdoc = new DomainObject(sObjectId);
			DomainObject dobCdoc = DomainObject.newInstance(context, sObjectId);
			//SPEC: <18.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
			String strWhere =ConstantsUtil.EMPTY_STRING;
			if(util.isModificatinRequired()){
				strWhere = "(current == "+ConstantsUtil.RELEASED+" || current == "+ConstantsUtil.STATE_RELEASE+" || current == "+ConstantsUtil.STR_CAP_RELEASED+" )";
			}else{
			 strWhere = "current!=Obsolete";
			}
			//SPEC: <18.05.2021>: Guna Modified for Internal Defect Dev 18x.6.0.1   -- END
			MapList mlRelatedParts = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT,
					DomainConstants.QUERY_WILDCARD, busSelect, new StringList(), false, true, (short) 1,
					strWhere, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			//SPEC: <03.05.2021>: Guna Commented for Internal Defect Dev 18x.6.0.1   -- START
			/*if(util.isModificatinRequired()) {
				mlRelatedParts=util.filterPhase(mlRelatedParts);
			}*/
			//SPEC: <03.05.2021>: Guna Commented for Internal Defect Dev 18x.6.0.1   -- END
			//SPEC: <14.06.2021>: Guna Added for 43532 Defect Dev 18x.6.0.1   -- START
			String strProtocolType = DomainConstants.EMPTY_STRING;
			boolean isStabilityReport = dobCdoc.isKindOf(context, PropertyUtil.getSchemaProperty("type_pgPKGStabilityReport"));
			boolean isValidationReport = dobCdoc.isKindOf(context, PropertyUtil.getSchemaProperty("type_pgPKGValidationReport"));
			if(isValidationReport || isStabilityReport)
			{
				strProtocolType = isStabilityReport ? PropertyUtil.getSchemaProperty("type_pgPKGStabilityProtocol") : PropertyUtil.getSchemaProperty("type_pgPKGValidationProtocol");
				MapList documentListProtocol = dobCdoc.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_REFERENCEDOCUMENT, strProtocolType, busSelect, new StringList(), true, false, (short)1,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				mlRelatedParts.addAll((Collection)documentListProtocol);
			}
			//SPEC: <08.07.2022>: Guna Added for req 42847 22x Release  -- START
			if(bisIRMDoc) {
			mlRelatedParts = getDocList(context, dobCdoc, dobCdoc.getType(context), mlRelatedParts,strWhere);
			}
			//SPEC: <08.07.2022>: Guna Added for req 42847 22x Release  -- END
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
			dobCdoc.close(context);
			//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
			//SPEC: <14.06.2021>: Guna Added for 43532 Defect Dev 18x.6.0.1   -- END
			Iterator objectListItr = mlRelatedParts.iterator();
			StringBuilder sbName = new StringBuilder();
			StringBuilder sbId = new StringBuilder();
			StringBuilder sbType=new StringBuilder();
			StringBuilder sbCurrent=new StringBuilder();
			StringBuilder sbTitle=new StringBuilder();
			StringBuilder sbRev = new StringBuilder();
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			//SPEC: <25.03.2021>: Guna Added for 41277 Defect 18x.6   -- START
			StringBuilder sbIsIRM = new StringBuilder();
			//SPEC: <25.03.2021>: Guna Added for 41277 Defect 18x.6   -- END
			String sName = ConstantsUtil.EMPTY_STRING;
			
			//SPEC: <26.03.2021>: Guna Added for 41380 Defect 18x.6   -- START
			StringBuilder sbGendocFormat = new StringBuilder();
			StringBuilder sbGendocName = new StringBuilder();
			StringBuilder sbGendocPath = new StringBuilder();
			
			StringBuilder sbHasFile = new StringBuilder();
			
			CommonDocBO commonDoc = new CommonDocBO();
			FileUtil fileUtil = new FileUtil();
			//SPEC: <26.03.2021>: Guna Added for 41380 Defect 18x.6   -- END
			//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- START
			StringBuilder sbIsGendoc = new StringBuilder();
			//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- END
			while(objectListItr.hasNext()) 
			{
				Map objectMap = (Map) objectListItr.next();
				String sType    =  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_TYPE));
				String sId		=  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ID));
				//SPEC: 02.09.2022: Sanjeeva modified for Defect 46550 18x.6.0.3   -- START
				String sCurrent	=  validator.getStringEquivalentForString(objectMap.get(com.matrixone.apps.domain.DomainConstants.SELECT_CURRENT));
				//SPEC: 02.09.2022: Sanjeeva modified for Defect 46550 18x.6.0.3   -- END
				
				String sRevision = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_REVISION));
				//SPEC: 26.04.2021: Jwala Added for 41945 Defect 18x.6   -- START
				//String sTitle	=  validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));\
				String sTitle	=  validator.getStringEquivalentForSubstituteStringTitle(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
				//SPEC: 26.04.2021: Jwala Added for 41945 Defect 18x.6   -- END
				sName = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.SELECT_NAME));
				//SPEC: <26.03.2021>: Guna Added for 41380 Defect 18x.6   -- START
				//DomainObject doObj = new DomainObject(sId);
				DomainObject doObj = DomainObject.newInstance(context, sId);
				Map mpFiles = new HashMap();
				String sGendocName = ConstantsUtil.EMPTY_STRING;
				String sGendocPath = ConstantsUtil.EMPTY_STRING;
				
				//Added by Jwala for IRMStore path 47636 -- START
				String sGendocStore = DomainConstants.EMPTY_STRING;
				String sStore = DomainConstants.EMPTY_STRING;
				StringBuilder sbGendocPathwithirmstore = new StringBuilder();
				//Added by Jwala for IRMStore path 47636 -- END
				
				String sGendocPathFormat = ConstantsUtil.EMPTY_STRING;
				bisIRMDoc = commonDoc.isIRMDoc(sType);
				//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- START
				boolean isGendoc =false;
				//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- END
				//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START											
				String sHasFileAttached = ConstantsUtil.FALSE;
				//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END											
				if(bisIRMDoc) {
					mpFiles=fileUtil.getGendocForIRM(context, doObj);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- START
					doObj.close(context);
					//SPEC: <08-13-2021>: Guna Added for Stress Testing Defect 44365  -- END
					sGendocName=validator.getStringEquivalentForSubstituteString(mpFiles.get(ConstantsUtilIRM.SELECT_IRMDOC_FILE_NAME));
					
					//Added by Jwala for IRMStore path 47636 -- START
					sGendocPath=validator.getEquivalentString(mpFiles.get(ConstantsUtil.STR_FILE_CAPTURED));
					sGendocStore=validator.getEquivalentString(mpFiles.get(ConstantsUtil.STR_FILE_STORE));
					sGendocStore = sGendocStore.toLowerCase();

					String[] strGendocPath=sGendocPath.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strgendocStore=sGendocStore.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE) ;

					for (int i = 0; i < strGendocPath.length; i++){
						sStore = strgendocStore[i];
						if(UIUtil.isNotNullAndNotEmpty(strGendocPath[i]) && UIUtil.isNotNullAndNotEmpty(strgendocStore[i]) && !sStore.equalsIgnoreCase(ConstantsUtil.STR_STORE)){
							sbGendocPathwithirmstore.append(strgendocStore[i]).append(ConstantsUtil.SYMBL_SLASH).append(strGendocPath[i]).append(ConstantsUtil.SYMBL_COMMA);
						}else{
							sbGendocPathwithirmstore.append(strGendocPath[i]).append(ConstantsUtil.SYMBL_COMMA);
						}
					}
					if(sbGendocPathwithirmstore.length() != 0 ){
						sbGendocPathwithirmstore.deleteCharAt(sbGendocPathwithirmstore. length()-1);
					}
					//Added by Jwala for IRMStore path 47636 -- END

					//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START					
					if(sGendocPath.length()>1) // since | is added by default
					{
						sHasFileAttached = ConstantsUtil.TRUE;					
					}
					//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END			
				}
				//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- START
				else if (!bisIRMDoc && !sType.equals(ConstantsUtil.TYPE_PGIPMDOCUMENT) ) {
					isGendoc =true;
				}
				//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- END
				
				boolean showData = util.checkHasAccess(context, null, sId);	
				//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
				if(!showData && util.isModificatinRequired()){
					continue;
				}
				//SPEC: <06.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END
				
				//SPEC: <30.03.2021>: Guna Added for 41941 Defect  Dev 18x.6   -- START
				if(!sCurrent.equalsIgnoreCase(ConstantsUtil.RELEASED) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE) && !sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_EXISTS)) {
					sId = ConstantsUtil.NO_ACCESS;
				}
				//SPEC: <30.03.2021>: Guna Added for 41941 Defect  Dev 18x.6   -- END
				if(!showData) {
					//Modified by Bala for Defect #38710 & #39065----END
					//SPEC: <30.03.2021>: Guna Modified for 41941 Defect  Dev 18x.6   -- START
						//sId=ConstantsUtil.EMPTY_STRING;
						sId=ConstantsUtil.NO_ACCESS;
						//SPEC: <30.03.2021>: Guna Modified for 41941 Defect  Dev 18x.6   -- END
						sTitle=ConstantsUtil.NO_ACCESS;
						sCurrent=ConstantsUtil.NO_ACCESS;
						sGendocName=ConstantsUtil.NO_ACCESS;
						sGendocPath=ConstantsUtil.NO_ACCESS;
						sGendocPathFormat=ConstantsUtil.NO_ACCESS;
					}
				
				//SPEC: Release SR18x.6.0 Defect#42652 - Added  by gaikwad.tg on Date 21 April 2021 -- END
				String strTempState = (String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				if(UIUtil.isNotNullAndNotEmpty(strTempState) && strTempState.equalsIgnoreCase(ConstantsUtil.STATE_APPROVED) && sType.equalsIgnoreCase("pgPKGDevelopmentOther"))
				sCurrent = ConstantsUtil.STATE_APPROVED;
				//SPEC: Release SR18x.6.0 Defect#42652 - Added  by gaikwad.tg on Date 21 April 2021 -- END
				
						sType = util.mapType(sType);
						util.formatData(sbType,sType);
						util.formatData(sbName,sName);
						util.formatData(sbCurrent,sCurrent);
						util.formatData(sbId,sId);
						util.formatData(sbTitle,sTitle);
						//SPEC: <25.03.2021>: Guna Added for 41277 Defect 18x.6   -- START
						util.formatData(sbIsIRM,String.valueOf(bisIRMDoc));
						//SPEC: <25.03.2021>: Guna Added for 41277 Defect 18x.6   -- END
						//SPEC: <26.03.2021>: Guna Added for 41380 Defect 18x.6   -- START
						//Added by Jwala for IRMStore path 47636 -- START
						util.formatData(sbGendocName,sGendocName);
						util.formatData(sbGendocPath,sbGendocPathwithirmstore.toString());
						//Added by Jwala for IRMStore path 47636 -- END

						util.formatData(sbGendocFormat, sGendocPathFormat);
						//SPEC: <26.03.2021>: Guna Added for 41380 Defect 18x.6   -- END
						//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- START
						util.formatData(sbIsGendoc, String.valueOf(isGendoc));
						//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- END
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- START
						util.formatData(sbHasFile,sHasFileAttached);
						//SPEC: Release SR18x.6.0 Defect#42093 - Added  by gopal.m on Date 08 April 2021 -- END
						util.formatData(sbRev,sRevision);
						
				//}
			//SPEC: <26.03.2021>: Guna Modified for 41380 Defect 18x.6   -- END		
			}
			mpRefDocs.put(ConstantsUtil.NAME, sbName.toString());
			mpRefDocs.put(ConstantsUtil.TITLE, sbTitle.toString());
			mpRefDocs.put(ConstantsUtil.TYPE, sbType.toString());
			mpRefDocs.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpRefDocs.put(ConstantsUtil.ID, sbId.toString());
			//SPEC: <25.03.2021>: Guna Added for 41277 Defect 18x.6   -- START
			mpRefDocs.put(ConstantsUtil.ISIRM, sbIsIRM.toString());
			//SPEC: <25.03.2021>: Guna Added for 41277 Defect 18x.6   -- END
			
			//SPEC: <26.03.2021>: Guna Added for 41380 Defect 18x.6   -- START
			mpRefDocs.put(ConstantsUtil.GENDOCNAME, sbGendocName.toString());
			mpRefDocs.put(ConstantsUtil.GENDOCPATH, sbGendocPath.toString());
			mpRefDocs.put(ConstantsUtil.GENDOCFORMAT, sbGendocFormat.toString());
			//SPEC: <26.03.2021>: Guna Added for 41380 Defect 18x.6   -- END
			//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- START
			mpRefDocs.put(ConstantsUtilIRM.ISGENDOC, sbIsGendoc.toString());
			//SPEC: <08.04.2021>: Guna Added for 41945 Defect 18x.6   -- END
			mpRefDocs.put(ConstantsUtil.REVISION, sbRev.toString());
	
	}catch(Exception e){

		LOGGER.error("Exception in Program : CommonDocBO Method :getReferenceDocsForIRM "+e);
		return new HashMap();
	}

	return util.filterMapList(mpRefDocs);
	}
	//SPEC: <23.03.2021>: Guna Added for 41277 Defect 18x.6   -- END
	
	
	//SPEC: <9/7/2021>: Added by Jwala for the defect 42876 -- START 
	/**
	 * Method Name 			: getQualitySpecificationSubType
	 * Method Description 	:
	 * @param context
	 * @param ObjectId
	 * @returnString SpecSubtypeAttrivalue
	 */
	public String getQualitySpecificationSubType(Context context, String sObjectId) throws Exception{
		String strAttributeValue = ConstantsUtil.EMPTY_STRING;
		try {
			//DomainObject dObjQS = new DomainObject(sObjectId);
			DomainObject dObjQS = DomainObject.newInstance(context, sObjectId);
			String strSubtypeAttributeValue = (String)dObjQS.getAttributeValue(context,ConstantsUtil.ATTRIBUTE_PGCSSTYPE);
			dObjQS.close(context);
			if(strSubtypeAttributeValue.equalsIgnoreCase(ConstantsUtilIRM.STR_AMAT)){
				strAttributeValue = ConstantsUtilIRM.STR_APPROVAL_MATRIX;
			}else if(strSubtypeAttributeValue.equalsIgnoreCase(ConstantsUtilIRM.STR_QAC)){
				strAttributeValue = ConstantsUtilIRM.STR_QUALITY_ACCEPTANCE_CRITERIA;
			}else if(strSubtypeAttributeValue.equalsIgnoreCase(ConstantsUtilIRM.STR_RMPI)){
				strAttributeValue = ConstantsUtilIRM.STR_RAWMATERIAL_PLANT_INSTRUCTION;
			}else if(strSubtypeAttributeValue.equalsIgnoreCase(ConstantsUtilIRM.STR_CBA)){
				strAttributeValue = ConstantsUtilIRM.STR_CURRENT_BEST_APPROCH;
			}else if(strSubtypeAttributeValue.equalsIgnoreCase(ConstantsUtilIRM.STR_GPMS)){
				strAttributeValue = ConstantsUtilIRM.STR_GENERAL_PMS;
			}else if(strSubtypeAttributeValue.equalsIgnoreCase(ConstantsUtilIRM.STR_GPS)){
				strAttributeValue = ConstantsUtilIRM.STR_GENERAL_PACKING_STANDARD;
			}else if(strSubtypeAttributeValue.equalsIgnoreCase(ConstantsUtilIRM.STR_IAS)){
				strAttributeValue = ConstantsUtilIRM.STR_INCOMMING_ACCEPT_SPEC;
			}else if(strSubtypeAttributeValue.equalsIgnoreCase(ConstantsUtilIRM.STR_MOC)){
				strAttributeValue = ConstantsUtilIRM.STR_MATERIAL_OF_CONSTRUCTION;
			}
		} catch(Exception e){
			LOGGER.error("Exception in Program : CommonDocBO Method :getQualitySpecificationSubType "+e);
			return ConstantsUtil.EMPTY_STRING;
		}
		return strAttributeValue;
	}
	//SPEC: <9/7/2021>: Added by Jwala for the defect 42876 -- END 

	/**
	 * @param context
	 * @param doFC
	 * @param c 
	 * @param b 
	 * @return
	 */
	public Map getRelatedACS(Context context, DomainObject doFC) 
	{
		StringBuilder sbPartType = new StringBuilder();
		StringBuilder sbPartID = new StringBuilder();
		StringBuilder sbPartName = new StringBuilder();
		StringBuilder sbPartState = new StringBuilder();
		StringBuilder sbPartTitle = new StringBuilder();

		StringBuilder sbPartRev = new StringBuilder();
		StringBuilder sbPartSpecSub = new StringBuilder();
		StringBuilder sbPartDisplay = new StringBuilder();


		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		Map mpAcs = new HashMap();

		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ID);
		busSelect.add(ConstantsUtil.SELECT_TYPE);
		busSelect.add(ConstantsUtil.SELECT_CURRENT);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_REVISION);
		MapList mapList;

		StringBuffer sbWhereCond = new StringBuffer();
		sbWhereCond.append("(");
		sbWhereCond.append(DomainObject.SELECT_CURRENT);

		sbWhereCond.append("==");
		sbWhereCond.append(ConstantsUtil.STATE_RELEASE);
		sbWhereCond.append(")");
		try 
		{
			mapList = doFC.getRelatedObjects(context, 
					ConstantsUtil.RELATIONSHIP_PGAUTHORIZEDCONFIGURATIONSTANDARD, //relationship pattern
					ConstantsUtil.SYMBL_ASTERISK,                                 // object pattern
					busSelect,                                                    // object selects
					null,                                                         // relationship selects
					false,                                                        // to direction
					true,                                                         // from direction
					(short) 1,                                                    // recursion level
					sbWhereCond.toString(),                                       // object where clause
					ConstantsUtil.EMPTY_STRING, 
					ConstantsUtil.ZERO_LEVEL);
			
			Iterator objectListItr = mapList.iterator();
			while (objectListItr.hasNext()) 
			{
				Map mpTemp = (Map) objectListItr.next();
				String sPartType = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_TYPE)));
				sPartType=busUtil.mapType(sPartType);
				String sPartID = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_ID))).trim();
				String sPartName = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_NAME)));
				String sPartState = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_CURRENT))).trim();
				String sPartRev = validator.getStringEquivalentForStringList((mpTemp.get(ConstantsUtil.SELECT_REVISION)));
				String sPartTitle = validator.getStringEquivalentForStringListWithComma((mpTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)));
				
				boolean bHasAccess =busUtil.checkHasAccess(context, null, sPartID);

				if (!bHasAccess || (!sPartState.equals(ConstantsUtil.RELEASE) && !sPartState.equals(ConstantsUtil.RELEASED) )) {
					sPartID= ConstantsUtil.NO_ACCESS;
				}

				busUtil.formatData(sbPartType, sPartType);
				busUtil.formatData(sbPartID, sPartID);
				busUtil.formatData(sbPartName, sPartName);
				busUtil.formatData(sbPartState, sPartState);
				busUtil.formatData(sbPartRev, sPartRev);
				busUtil.formatData(sbPartTitle, sPartTitle);
				
			}
			
			mpAcs.put(ConstantsUtil.NAME, sbPartName.toString());
			mpAcs.put(ConstantsUtil.ID, sbPartID.toString());
			mpAcs.put(ConstantsUtil.TYPE, sbPartType.toString());
			mpAcs.put(ConstantsUtil.REVISION, sbPartRev.toString());
			mpAcs.put(ConstantsUtil.STATE, sbPartState.toString());
			mpAcs.put(ConstantsUtil.TITLE, sbPartTitle.toString());
			
		} catch (Exception e) {
			LOGGER.error("Exception in Program : CommonBO -  Method :getRelatedACS " + e);
			return new HashMap();
		}
		return mpAcs;
	}
	
	//SPEC: <10.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- START
	public Map removeNoAccessParts(Context context, Map mpAcs) {
		StringList slNoAccess= new StringList();
		if (mpAcs.isEmpty()) {
			return new HashMap();
		}
		Map objectMap = new HashMap();
		// TODO Auto-generated method stub
		try {
			if (mpAcs.containsKey(ConstantsUtil.ID)) {
				String sId = (String) mpAcs.get(ConstantsUtil.ID);
				String saId[] = sId.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
				boolean showData =false;
				if (saId.length != 0) {
					for (int i = 0; i < saId.length; i++) {
					//SPEC: <18.07.2022>: Guna Modified for Req 41754 22x Release  -- START
					  showData =util.checkHasAccess(context, null, saId[i].trim());
					//SPEC: <18.07.2022>: Guna Modified for Req 41754 22x Release  -- END
					  if(!showData){
						  slNoAccess.add((String.valueOf(i)).trim());
					  }
					}
					}
				if (slNoAccess.size() != 0) {
					mpAcs = filterNoAccessObjects(slNoAccess, mpAcs);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			LOGGER.error("Exception in Program : CommonDocBO Method :removeNoAccessParts "+e);
		}
		return mpAcs;
	}
	public Map filterNoAccessObjects(StringList slNoAccess, Map<String,String> mpAcs) {
		
		Map mpTemp = new HashMap();
		// TODO Auto-generated method stub
		try{
		for (Map.Entry<String, String> entry : mpAcs.entrySet()) {
			String sKey = entry.getKey();
			String sVal = entry.getValue();

			StringList slValueList = FrameworkUtil.split(sVal, ConstantsUtil.SYMBL_PIPE);
			StringBuilder sbVal =removeIndexValues(slNoAccess,slValueList);
			mpTemp.put(sKey, sbVal.toString());
		}
		}catch (Exception e) {
			// TODO: handle exception
			LOGGER.error("Exception in Program : CommonDocBO Method :filterNoAccessObjects "+e);
		}
		return mpTemp;
	}
	//SPEC: <08-13-2021>: Guna Modified  for Stress Testing Defect 44365  -- START
	private StringBuilder removeIndexValues(StringList slNoAccess, StringList slValueList)throws Exception{
		//SPEC: <08-13-2021>: Guna Modified for Stress Testing Defect 44365  -- END
		// TODO Auto-generated method stub
		StringBuilder sbReturn = new StringBuilder();
		for(int j=0;j<slValueList.size();j++){
			if(!slNoAccess.contains(String.valueOf(j))){
				sbReturn.append(slValueList.get(j).trim()).append(ConstantsUtil.SYMBL_PIPE);
			}
		}
		return sbReturn;
	}
	//SPEC: <10.05.2021>: Guna Added for 33248 Req  Dev 18x.6.0.1   -- END
	//SPEC: <20.05.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- START
	public String getValidationProtocol(Context context, StringList vlProtocolId, StringList vlProtocolTitle) {
		// TODO Auto-generated method stub
		StringBuilder rtnBuilder =new StringBuilder();
		String srtnValPro =ConstantsUtil.EMPTY_STRING;
		try {
			if(vlProtocolId.size() !=0){
				for(int idx=0;idx<vlProtocolId.size();idx++){
				 Boolean showData =util.checkHasAccess(context, null, (String)vlProtocolId.get(idx));
				 if(showData){
					//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
					 rtnBuilder.append((String)vlProtocolTitle.get(idx)).append(" "+ConstantsUtil.SYMBL_PIPE+" ");
					//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
				   }
				}
			}
			rtnBuilder =rtnBuilder.deleteCharAt(rtnBuilder.lastIndexOf("|"));
			//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- START
			srtnValPro =rtnBuilder.toString().trim();
			//SPEC: <20.05.2021>: Guna Modified for Internal Defect  Dev 18x.6.0.1   -- END
		} catch (Exception e) {
			// TODO: handle exception
			LOGGER.error("Exception in Program : CommonDocBO Method :getValidationProtocol "+e);
		}
		return srtnValPro;
	}
	//SPEC: <20.05.2021>: Guna Added for Internal Defect  Dev 18x.6.0.1   -- END

	//SPEC: <08.06.2022>: Guna Added for req 36041 22x Release  -- START
	public String getConsumerAndDPICFile(Context context, MapList mlLatestVersion, String constConsumertestlabel) {
		String strReturn = ConstantsUtil.EMPTY_STRING;
		try {
			StringList slReturn = new StringList();
		      if (mlLatestVersion != null && !mlLatestVersion.isEmpty()) {
		    	  mlLatestVersion.sort(ConstantsUtil.SELECT_ATTRIBUTE_TITLE, ConstantsUtil.ASCENDING, ConstantsUtil.STRING);
		          int mlRelatedDocVersionLength = mlLatestVersion.size();
		    	  for (int i = 0; i < mlRelatedDocVersionLength; i++) {
		              Map<String, String> mlRelatedVersion = (Map<String, String>)mlLatestVersion.get(i);
		              String strCheckinreason = mlRelatedVersion.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHECKIN_REASON);
		             //SPEC: 23-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50233-- START
		              if(strCheckinreason.startsWith(constConsumertestlabel)) {
		            //SPEC: 23-08-2022: Dominic Modified for SR22x.0_NovemberCW Defect 50233-- END
		              slReturn.add(mlRelatedVersion.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
		              }
		      }
		      }
		      strReturn =util.replaceSquareBracketsOnly(slReturn.toString());
		} catch (Exception e) {
			LOGGER.error("Exception in Program : CommonDocBO Method :getConsumerAndDPICFile "+e);
		}
		
		return strReturn;
	}

	public MapList getLatestVersions(Context context, String objId) {
		MapList mlRelatedDocVersion =new MapList();
		try {
			StringBuilder sbTypePattern = new StringBuilder();
			//SPEC: 26-08-2022: Pooja Modified for Defect 50359
		    sbTypePattern.append(ConstantsUtil.TYPE_PGPKGSTUDYPROTOCOL);
		    DomainObject objectDo = DomainObject.newInstance(context, objId);
		      StringList slBusSelect = new StringList(3);
		      slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		      slBusSelect.add(DomainConstants.SELECT_ID);
		      slBusSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHECKIN_REASON);
		       mlRelatedDocVersion = objectDo.getRelatedObjects(context, ConstantsUtilIRM.RELATIONSHIP_LATEST_VERSION, sbTypePattern
		          .toString(), slBusSelect, null, false, true, (short)1, null, null, 0);
		     //SPEC: 23-08-2022: Pooja Modified for Defect 50359
		} catch (Exception e) {
			LOGGER.error("Exception in Program : CommonDocBO Method :getLatestVersions "+e);
		}
		return mlRelatedDocVersion;
	}
	//SPEC: <08.06.2022>: Guna Added for req 36041 22x Release  -- END
	
	//SPEC: <08.07.2022>: Guna Added for req 42847 22x Release  -- START
	 private MapList getDocList(Context context, DomainObject domainObject, String type, MapList retDocList, String strWhere) {
		    MapList docList = new MapList();
		    try {
		    StringList slTypesList = new StringList();
		    BusinessType documentType = new BusinessType(ConstantsUtilIRM.TYPE_PG_IRM_DOCUMENT, context.getVault());
		    HashMap<Object, Object> methodArgs = new HashMap<>();
		    methodArgs.put(ConstantsUtilIRM.BUSINESSTYPE, documentType);
		    methodArgs.put(ConstantsUtilIRM.TYPELIST, slTypesList);
		    slTypesList = getBusinessTypeChildren(context, JPO.packArgs(methodArgs));
		    if (!slTypesList.isEmpty() && slTypesList.contains(type)) {
		      StringList slTypeSelects = new StringList(1);
		      slTypeSelects.add(DomainConstants.SELECT_ID);
		      slTypeSelects.add(DomainConstants.SELECT_TYPE);
		      slTypeSelects.add(DomainConstants.SELECT_NAME);
		      slTypeSelects.add(DomainConstants.SELECT_CURRENT);
			  slTypeSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
			  slTypeSelects.add(DomainConstants.SELECT_REVISION);
		      StringList slRelSelects = new StringList(1);
		      slRelSelects.add(ConstantsUtil.SELECT_CONNECTION_ID);
		      docList = domainObject.getRelatedObjects(context, DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT, DomainConstants.TYPE_DOCUMENT, slTypeSelects, slRelSelects, true, true, (short)1, strWhere, null, 0);
		    } else {
		      docList = retDocList;
		    } 
		    }catch (Exception e) {
		    	LOGGER.error("Exception in Program : CommonDocBO Method :getDocList "+e);
			}
		    return docList;
		  }
		  
		  public StringList getBusinessTypeChildren(Context context, String[] args)  {
			  StringList docTypeList =new StringList();
			  try {
		    HashMap argsMap = (HashMap)JPO.unpackArgs(args);
		    BusinessType businessType = (BusinessType)argsMap.get(ConstantsUtilIRM.BUSINESSTYPE);
		    docTypeList = (StringList)argsMap.get(ConstantsUtilIRM.TYPELIST);
		    docTypeList.add(businessType.getName().trim());
		    HashMap<Object, Object> methodArgs = new HashMap<>();
		    methodArgs.put(ConstantsUtilIRM.TYPELIST, docTypeList);
		    if (businessType.hasChildren()) {
		      BusinessTypeList businessTypeList = businessType.getChildren(context);
		      BusinessTypeItr businessTypeItr = new BusinessTypeItr(businessTypeList);
		      while (businessTypeItr.next()) {
		        BusinessType businessTypeChild = (BusinessType)businessTypeItr.obj();
		        methodArgs.put(ConstantsUtilIRM.BUSINESSTYPE, businessTypeChild);
		        docTypeList = getBusinessTypeChildren(context, JPO.packArgs(methodArgs));
		      } 
		      } 
			  }catch (Exception e) {
				  LOGGER.error("Exception in Program : CommonDocBO Method :getBusinessTypeChildren "+e);
			}
		    return docTypeList;
		  }
		//SPEC: <08.07.2022>: Guna Added for req 42847 22x Release  -- END
}
