/**
 * Project 		: SpecReader
 * Program 		: SoftwareBuildPartBO
 * Author  		: Chandra-Infosys Ltd.
 * Date 		:05-03-2021
 * Description 	: As part of 18x.6 this was introduced.
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class SoftwareBuildPartBO extends BusinessObject{
	private static Logger LOGGER = Logger.getLogger(SoftwareBuildPartBO.class);
	
	public SoftwareBuildPartBO() {
		// empty constructor
	}

	public SoftwareBuildPartBO(String oid) {
		this.setObjectId(oid);
	}

	
	/**
	 * Method Name : getSBPBO
	 * Method Description : Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getSBPBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getSBPDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getSBPDO(Context context, String oId) throws Exception {
		try {
			DomainObject bo = new DomainObject(oId);
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID: " + oId);
			throw e;
		}
	}


	
	/**
	 * Method Name 			: getContextPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public StringList getContextPartSelectables(Context context) {
		StringList busSelect = new StringList(40);
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable());
		return busSelect;
	}

	/**
	 * SoftwareBuildPart context selects
	 * @return
	 */
	private StringList getContextObjectBusSelectable() {
		StringList busSelect = new StringList();
		
		busSelect.add(ConstantsUtilIRM. PRODUCT_BUILD_TYPE );			
		busSelect.add(ConstantsUtilIRM. PRODUCT_BUILD_ID );			
		busSelect.add(ConstantsUtilIRM. PRODUCT_BUILD_NAME );			
		busSelect.add(ConstantsUtilIRM. PRODUCT_CONFIGURATION_TYPE );	
		busSelect.add(ConstantsUtilIRM. PRODUCT_CONFIGURATION_ID );	
		busSelect.add(ConstantsUtilIRM. PRODUCT_CONFIGURATION_NAME );	
		busSelect.add(ConstantsUtilIRM. REL_ASSIGNED_PART_NAME );		
		busSelect.add(ConstantsUtilIRM. REL_ASSIGNED_PART_ID );		
		busSelect.add(ConstantsUtilIRM. REL_ASSIGNED_PART_TYPE );		
		busSelect.add(ConstantsUtilIRM. REL_ASSIGNED_PART_REV );		
		busSelect.add(ConstantsUtilIRM. REL_CUSTOMER_TYPE );			
		busSelect.add(ConstantsUtilIRM. REL_CUSTOMER_NAME );			
		busSelect.add(ConstantsUtilIRM. REL_CUSTOMER_ID );				
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGBUILDPATH);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_BUILD_UNIT_NUM);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PLANNED_BUILD_DATE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_SHORTH_HAND_NOTATION);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_BUILD_SERIAL_NUM);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_DATE_SHIPPED);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ACTUAL_BUILD_DATE);
		busSelect.add(ConstantsUtilIRM.REL_MANUFACTURING_PLANT_NAME);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		
		// SPEC Added on 05-April-2021 by Chandra for Defect 42124 --START
		busSelect.add(ConstantsUtil.OWNING_STANDARD_OFFICE);
		// SPEC Added on 05-April-2021 by Chandra for Defect 42124 --END
		
		
		
		return busSelect;
	}

	/**
	 * The below selects has multivalues, 
	 * so adding to the multivalue before DB extratction
	 * 
	 */
	public StringList addMultiValue(){
		StringList slMultiSelects = new StringList();
		slMultiSelects.add(ConstantsUtilIRM.REL_MANUFACTURING_PLANT_NAME); 
		return slMultiSelects;
	}
	
	//Added by Ajay for Req 21324 -- START
	public Map GetDistributionInfo(Context context ,String objId) throws Exception{
		
			Map<String,String> mpDistributionInfo = new HashMap<String,String>();
			StringValidatorUtil validator = new StringValidatorUtil();
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			StringBuilder sbFormatFile = new StringBuilder();
			StringBuilder sbFormatSize = new StringBuilder();
			StringBuilder sbFileName = new StringBuilder();
			StringBuilder sbComment = new StringBuilder();
			StringBuilder sbAction = new StringBuilder();
			StringList relSelect = new StringList();
			StringList busSelect = new StringList();
			busSelect.add(ConstantsUtil.STR_FORMAT_FILE);
			busSelect.add(ConstantsUtil.STR_FILE_SIZE);
			busSelect.add(ConstantsUtil.STR_FILE_NAME);
			busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_NOTES);
			busSelect.add(ConstantsUtilIRM.STR_FORMAT_FILE_PATH);
			StringList busSelects = new StringList();
			StringList relSelects = new StringList();
		
			try 
			{	
				DomainObject SBPBo = new DomainObject(objId);
				MapList mlObjList = SBPBo.getRelatedObjects(context,ConstantsUtilIRM.RELATIONSHIP_DISTRIBUTIONFILE,ConstantsUtil.QUERY_WILDCARD, busSelect, relSelect, false, true,
						(short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
				
				Iterator objectListItr = mlObjList.iterator();
				while(objectListItr.hasNext())
				{
					Map resultMap = (Map) objectListItr.next();
					
					String strFormatFile = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.STR_FORMAT_FILE));
					String strFormatSize = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.STR_FILE_SIZE));
					String strFileName = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtil.STR_FILE_NAME));
					String strComment = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_NOTES));
					String strAction = validator.getStringEquivalentForSubstituteString(resultMap.get(ConstantsUtilIRM.STR_FORMAT_FILE_PATH));
					util.formatData(sbFormatFile, strFormatFile);
					util.formatData(sbFormatSize, strFormatSize);
					util.formatData(sbFileName, strFileName);
					util.formatData(sbComment, strComment);
					util.formatData(sbAction, strAction);
				}
				mpDistributionInfo.put(ConstantsUtil.STR_FILE_NAME,sbFileName.toString());
				mpDistributionInfo.put(ConstantsUtil.COMMENTS,sbComment.toString());
				mpDistributionInfo.put(ConstantsUtil.STR_FILE_SIZE,sbFormatSize.toString());
				mpDistributionInfo.put(ConstantsUtil.STR_FORMAT_FILE,sbFormatFile.toString());
				mpDistributionInfo.put(ConstantsUtil.ACTION,sbAction.toString());
				
			}catch (Exception e) {
				LOGGER.error("Exception in Program : ASLBO Method :GetSupplierInfo "+e);
				return new HashMap();
			}
			return mpDistributionInfo;
		}
	//Added by Ajay for Req 21324 -- END
	/**
	 * The below selects has multivalues, 
	 * so removing from the multivalue after DB extratction
	 * 
	 */
	public void removeMultiValue(){
		DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtilIRM.REL_MANUFACTURING_PLANT_NAME);
	}
}
