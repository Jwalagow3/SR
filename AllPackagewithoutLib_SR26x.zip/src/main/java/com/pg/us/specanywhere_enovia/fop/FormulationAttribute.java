package com.pg.us.specanywhere_enovia.fop;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.PropertyUtil;
import matrix.db.AttributeType;
import matrix.db.Context;
import matrix.util.MatrixException;
public enum FormulationAttribute {



		STAGE("attribute_ReleasePhase"), RELEASE_DATE("attribute_ReleaseDate"), SHARED_TABLE_CHARACTERISTIC_SEQUENCE(
				"attribute_SharedTableCharacteristicSequence"), MANDATORY_SECTIONS("attribute_MandatorySections"), QUANTITY(
						"attribute_Quantity"), UNIT_OF_MEASURE("attribute_QuantityUnitOfMeasure"), CONFIDENTIAL(
								"attribute_Confidential"), ATTRIBUTE_CPNSUBSCRIPTIONSTATUS(
										"attribute_CPNSubscriptionStatus"), ATTRIBUTE_CPNMARKFORDAILYSUBSCRIPTION(
												"attribute_CPNMarkForDailySubscription"), ATTRIBUTE_CPNMARKFORWEEKLYSUBSCRIPTION(
														"attribute_CPNMarkForWeeklySubscription"), ATTRIBUTE_CPNMANUFACTURERFORSUBSCRIPTION(
																"attribute_CPNManufacturerForSubscription"), ATTRIBUTE_CPNEVENTFORDAILYSUBSCRIPTION(
																		"attribute_CPNEventForDailySubscription"), ATTRIBUTE_CPNEVENTFORWEEKLYSUBSCRIPTION(
																				"attribute_CPNEventForWeeklySubscription"), ATTRIBUTE_CPNMANUFACTURERADDEDFORDAILYSUBSCRIPTION(
																						"attribute_CPNManufacturerAddedForDailySubscription"), ATTRIBUTE_CPNMANUFACTURERADDEDFORWEEKLYSUBSCRIPTION(
																								"attribute_CPNManufacturerAddedForWeeklySubscription"), ATTRIBUTE_CPNMARKFORNEXTSUBSCRIPTION(
																										"attribute_CPNMarkForNextSubscription"), ATTRIBUTE_CPNEVENTFORNEXTSUBSCRIPTION(
																												"attribute_CPNEventForNextSubscription"), NEXT_PROPAGATE_NUMBER(
																														"attribute_NextPropagateNumber"), PROPAGATE_NUMBER(
																																"attribute_PropagateNumber"), NEEDS_UPDATE(
																																		"attribute_NeedsUpdate"), ENGINUITY_AUTHORED(
																																				"attribute_EnginuityAuthored"), ATTRIBUTE_NEXT_PROCESS_NUMBER(
																																						"attribute_NextProcessNumber"), PROCESS_NUMBER(
																																								"attribute_ProcessNumber"), END_ITEM(
																																										"attribute_EndItem"), END_ITEM_OVERRIDE_ENABLED(
																																												"attribute_EndItemOverrideEnabled"), DESIGN_PURCHASE(
																																														"attribute_DesignPurchase"), START_EFFECTIVITY_DATE(
																																																"attribute_StartEffectivityDate"), END_EFFECTIVITY_DATE(
																																																		"attribute_EndEffectivityDate"), FIND_NUMBER(
																																																				"attribute_FindNumber"), INSTRUCTION(
																																																						"attribute_Instruction"), ADJUSTABLE_INGREDIENT_FLAG(
																																																								"attribute_AdjustableIngredientFlag"), MIN(
																																																										"attribute_Min"), MAX(
																																																												"attribute_Max"), LOSS(
																																																														"attribute_Loss"), TOTAL(
																																																																"attribute_Total"), TITLE(
																																																																		"attribute_Title"), QUANTITY_ADJUSTMENT(
																																																																				"attribute_QuantityAdjustment"), PRIMARY_REPLACEMENT_INGREDIENT(
																																																																						"attribute_PrimaryReplacementIngredient"), SUBSTITUTE_INSTRUCTIONS(
																																																																								"attribute_SubstituteInstructions"), STANDARD_COSTPERKG(
																																																																										"attribute_StandardCostPerKg"), CONTAIN_RESTRICTED_SUBSTANCES(
																																																																												"attribute_ContainRestrictedSubstances"), IS_VPM_VISIBLE(
																																																																														"attribute_isVPMVisible"), PRODUCTION_RESTRICTION(
																																																																																"attribute_ProductionRestriction"), TARGET_PERCENT_AS_CONSUMED(
																																																																																		"attribute_TargetPercentAsConsumed"), CAS_NUMBER(
																																																																																				"attribute_CASNumber"), EC_NUMBER(
																																																																																						"attribute_ECNumber"), APPLICATION(
																																																																																								"attribute_Application"), MINIMUM_WEIGHT(
																																																																																										"attribute_MinimumWeight"), MAXIMUM_WEIGHT(
																																																																																												"attribute_MaximumWeight"), IS_CONTAMINANT(
																																																																																														"attribute_IsContaminant"), SUBSTANCE_NAME(
																																																																																																"attribute_SubstanceName"), QS_TO_COMPOSITE(
																																																																																																		"attribute_QsToComposite"), IS_TARGET_MATERIAL(
																																																																																																				"attribute_IsTargetMaterial"), PRESERVATIVE_FLAG(
																																																																																																						"attribute_PreservativeFlag"), IS_COLORANT(
																																																																																																								"attribute_IsColorant"), ACTIVE_INGREDIENT_FLAG(
																																																																																																										"attribute_ActiveIngredientFlag"), QUANTITY_UNIT_OF_MEASURE(
																																																																																																												"attribute_QuantityUnitOfMeasure"), CONTAIN_QS_IN_RESTRICTED_SUBSTANCES(
																																																																																																														"attribute_ContainQSInRestrictedSubstances"), TOTAL_QUANTITY_OF_RESTRICTED_SUBSTANCE(
																																																																																																																"attribute_TotalQuantityOfRestrictedSubstance"), IS_TARGET_PERCENT_AS_CONSUMED_FIXED(
																																																																																																																		"attribute_IsTargetPercentAsConsumedFixed"), VIRTUAL_INTERMEDIATE_PHYSICAL_ID(
																																																																																																																				"attribute_VirtualIntermediatePhysicalId"), FORMULATION_TYPE(
																																																																																																																						"attribute_FormulationType"), TARGET_PERCENT_WET_IN_VIRTUAL_INTERMEDIATE(
																																																																																																																								"attribute_TargetPercentWetInVirtualIntermediate"), VIRTUAL_INTERMEDIATE_USAGE_COUNTER(
																																																																																																																										"attribute_VirtualIntermediateUsageCounter");

		private final String _name;

		private FormulationAttribute(String var3) {
			this._name = var3;
		}

		public String getAttribute(Context var1) {
			return PropertyUtil.getSchemaProperty(var1, this._name);
		}

		public String getAttributeSelect(Context var1) {
			return DomainObject.getAttributeSelect(this.getAttribute(var1));
		}

		public String getDefaultValule(Context var1) throws MatrixException {
			AttributeType var2 = new AttributeType(this.getAttribute(var1));
			return var2.getDefaultValue(var1);
		}

		public String toString() {
			return this._name;
		}
	
}
