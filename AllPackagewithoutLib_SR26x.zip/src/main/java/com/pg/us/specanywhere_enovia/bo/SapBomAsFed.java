package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.sapbom.Sapbom;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import matrix.db.Context;
import matrix.util.StringList;

public class SapBomAsFed
{

	private static Logger LOGGER = Logger.getLogger(SapBomAsFed.class);
	
	public Map getSapBOMasFed(Context context ,String sContextId)
	{
		
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util =new BusObjectAttribUtil();
		Map mapSapBomAsFedResult = new HashMap();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbSapType = new StringBuilder();
		StringBuilder sbSpecSubType = new StringBuilder();
		StringBuilder sbSpecGroup = new StringBuilder();
		StringBuilder sbBOMQTY = new StringBuilder();
		StringBuilder sbBuom = new StringBuilder();
		StringBuilder sbComnt = new StringBuilder();
		StringBuilder sbAuthorized = new StringBuilder();
		StringBuilder sbAuthorizedToUse = new StringBuilder();
		StringBuilder sbAuthorizedToProduce = new StringBuilder();
		StringBuilder sbOC = new StringBuilder();
		
		StringBuilder sbTUType = new StringBuilder();
		StringBuilder sbTUName = new StringBuilder();
		StringBuilder sbTUId = new StringBuilder();
		StringBuilder sbSAPDesc = new StringBuilder();
		
		StringBuilder sbMaxQTY = new StringBuilder();
		StringBuilder sbMinQTY = new StringBuilder();

		
		try
		{
			Sapbom sapbo = new Sapbom();
			MapList mlSapBomAsFed = (MapList) sapbo.getTableData(context, sContextId);
			
			StringList	slspecSubType = getSpecificationSubtype(context ,mlSapBomAsFed);
			
			Iterator objectListItr = mlSapBomAsFed.iterator();
			
			for (int i = 0; i < mlSapBomAsFed.size(); i++) 
			{
				Map objectMap = (Map) mlSapBomAsFed.get(i);;

				String sId =(String)objectMap.get(ConstantsUtil.MAP_KEY_ID);
				String sName =(String)objectMap.get(ConstantsUtil.NAME);
				String sType =(String)objectMap.get(ConstantsUtil.TYPE);
				String sSapType =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPTYPE);
				String sSpecGroup =(String)objectMap.get(ConstantsUtil.MAP_KEY_SUBSTITUTE);
				String sQty =(String)objectMap.get(ConstantsUtil.MAP_KEY_BOMQTY);
				String sBuom =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPUOM);
				String strComment = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.ATTRIBUTE_COMMENT));
				String strSAPDesc = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_DESCRIPTION));
				String strOC = validator.getStringEquivalentForString(objectMap.get(ConstantsUtil.MAP_KEY_OPTCOMPONENT));
				String strSpecSubType= slspecSubType.get(i);
				String strTUType = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_TYPE);
				String strTUName = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_NAME);
				String strTUId = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_ID);
				
				String strMaxQTY = (String)objectMap.get(ConstantsUtil.MAX);
				String strMinQTY = (String)objectMap.get(ConstantsUtil.MIN);
				
				boolean bObjectHasAccess=util.checkHasAccess(context,null,sId);
				
				if(!bObjectHasAccess)
				{
					sId =ConstantsUtil.NO_ACCESS;
					strSAPDesc=ConstantsUtil.NO_ACCESS;
					strTUType =ConstantsUtil.NO_ACCESS;
					strTUName=ConstantsUtil.NO_ACCESS;
					strTUId =ConstantsUtil.NO_ACCESS;
				}
				// Added by Ajay for the Req 24463 - START
				if(sQty.contains(ConstantsUtil.SYMBL_DOT)) {
					BigDecimal bdQty = new BigDecimal(sQty);
					bdQty = bdQty.setScale(3, RoundingMode.HALF_UP);
					sQty=bdQty.toString();
				}
				// Added by Ajay for the Req 24463 - END
				formatData(sbId,sId);
				formatData(sbName,sName);
				formatData(sbType,util.mapType(sType));
				formatData(sbSapType,sSapType);
				formatData(sbSpecGroup,sSpecGroup);
				formatData(sbBOMQTY,sQty);
				formatData(sbBuom,sBuom);
				formatData(sbComnt,strComment);
				formatData(sbSAPDesc,strSAPDesc);
				formatData(sbOC,strOC);
				util.formatData(sbMaxQTY,strMaxQTY);
				util.formatData(sbMinQTY,strMinQTY);
				formatData(sbTUType,strTUType);
				formatData(sbTUName,strTUName);
				formatData(sbTUId,strTUId);
				formatData(sbSpecSubType,strSpecSubType);
				
			}
			mapSapBomAsFedResult.put(ConstantsUtil.NAME, sbName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.ID, sbId.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TYPE, sbType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPTYPE, sbSapType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONGROUP, sbSpecGroup.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BOMQUANTITY, sbBOMQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbBuom.toString());
			
			mapSapBomAsFedResult.put(ConstantsUtil.COMMENTS, sbComnt.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPDESCRIPTION, sbSAPDesc.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZED, sbAuthorized.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOUSE, sbAuthorizedToUse.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, sbAuthorizedToProduce.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.OC,sbOC.toString());
			
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_NAME,sbTUName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_TYPE,sbTUType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_ID,sbTUId.toString());
			
			mapSapBomAsFedResult.put(ConstantsUtil.MAX,sbMaxQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.MIN,sbMinQTY.toString());

		}catch(Exception e){
			
			LOGGER.error("Exception in program SapBomAsFed :getSapBOMasFed ");
			return new HashMap();
		}
		return mapSapBomAsFedResult;
	}

	/**
	 * Formatting the data
	 * @param slData
	 * @param sData
	 */
	
	public void formatData(StringBuilder slData, String sData) {
		slData.append(sData);
		slData.append(ConstantsUtil.SYMBL_PIPE);
	}
		
	public StringList getSpecificationSubtype(Context context,MapList objectList) throws Exception
	{
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		StringList vc= new StringList();
		long startTime = System.currentTimeMillis();

		Map mapDataMapping = null;

		String strAttributeName = PropertyUtil.getSchemaProperty("attribute_pgAssemblyType");
		String strAttributeCSSType = PropertyUtil.getSchemaProperty("attribute_pgCSSType");
		String strTypepgFinishedProduct = PropertyUtil.getSchemaProperty("type_pgFinishedProduct");
		String strTypepgQualitySpecification = PropertyUtil.getSchemaProperty("type_pgQualitySpecification");
		String strAttrPgAssemblyType = ""; 
		String strTypepgTestMethod= PropertyUtil.getSchemaProperty("type_pgTestMethod");		

		String strSpecSubTypeValue = DomainConstants.EMPTY_STRING;  
		String strRelPgPDTemplatestopgPLIAssemblyType = DomainConstants.EMPTY_STRING;
		String strSelect = DomainConstants.EMPTY_STRING;

		Map mapObject = null;
		String strID="";
		String strRootNode="";
		String strSpecSubType = "";
		String strType = "";
		String strAttrPgCSSType = "";
		boolean isContextPush = false;

		ContextUtil.pushContext(context, "User Agent", "", "");
		isContextPush = true;
		for (Iterator iterator = objectList.iterator(); iterator.hasNext();)
		{
			mapDataMapping = new HashMap();
			mapDataMapping.put("pgPackingMaterial","Packaging");
			mapObject = (Map) iterator.next();			
			strID=(String)mapObject.get(DomainConstants.SELECT_ID);			
			DomainObject dom = new DomainObject(strID);
			boolean isDSO = busUtil.isOfDSOOrigin(context, strID);
			strType = (String)mapObject.get(DomainConstants.SELECT_TYPE);


			if (strTypepgFinishedProduct.equals(strType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equals(strType))

			{
				strAttrPgAssemblyType = dom.getInfo(context, "attribute["+strAttributeName+"]");

				if("".equals(strAttrPgAssemblyType)){

					mapDataMapping.put("pgFinishedProduct","Finished Product");
				}
				else if("FWIP-Finished Work in Process".equals(strAttrPgAssemblyType)) {
					mapDataMapping.put("pgFinishedProduct","FWIP-Finished Work in Process");			
				}

				else if("Purchased Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgPackingSubassembly","Purchased Subassembly");	
				}
				else if("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgPackingSubassembly","Purchased and/or Produced Subassembly");	
				}else{
					mapDataMapping.put("pgFinishedProduct",strAttrPgAssemblyType);	
				}				
			}

			if (strTypepgQualitySpecification.equals(strType) && !isDSO){
				strAttrPgCSSType = dom.getInfo(context, "attribute["+strAttributeCSSType+"]");

				if("AMAT".equals(strAttrPgCSSType)) {
					mapDataMapping.put("pgQualitySpecification","Approval Matrix");			
				}
				else if ("CBA".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Current Best Approach");	
				}
				else if ("GPMS".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","General Packaging Material Specification");	
				}
				else if ("GPS".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","General Packing Standard");	
				}
				else if ("IAS".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Incoming Acceptance Specification");	
				}
				else if ("MOC".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Material of Construction");	
				}
				else if ("QAC".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Quality Acceptance Criteria");
				}
				else if ("RMPI".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Raw Material Plant Instruction");	
				}else{
					mapDataMapping.put("pgQualitySpecification",strAttrPgCSSType);
				}		

			}

			if(ConstantsUtil.TYPE_PGRAWMATERIAL.equals(strType)){
				if(!isDSO){
					mapDataMapping.put("pgRawMaterial","Raw");
				}
			}
			if (isDSO){
				if(ConstantsUtil.TYPE_FORMULATIONPART.equals(strType)){
					strSpecSubTypeValue =  (String)dom.getInfo(context,"to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
				} else {
					strSpecSubTypeValue =  (String)dom.getInfo(context,"attribute["+strAttributeName+"]");
				}
			}else {
				strSpecSubTypeValue= "";
			}


			if (strTypepgTestMethod.equals(strType))
			{   
				strAttrPgCSSType = dom.getInfo(context, "attribute["+strAttributeCSSType+"]");
				if ("TAMU".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgTestMethod","TAMU");
				}
				else {
					mapDataMapping.put("pgTestMethod","");
				}

			}								

			strRootNode=(String)mapObject.get("Root Node");

			if(!"true".equalsIgnoreCase(strRootNode))
			{
				strSpecSubType = (String)mapDataMapping.get(strType);
				if(strSpecSubType != null)
				{
					vc.add(strSpecSubType);
				}
				else if(UIUtil.isNotNullAndNotEmpty(strSpecSubTypeValue))
				{
					vc.add(strSpecSubTypeValue);
				}
				else
				{
					vc.add("");
				}
			}else{
				vc.add("");
			}
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dom.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
		}

		long endTime = System.currentTimeMillis();
		if(isContextPush){
			ContextUtil.popContext(context);
			isContextPush = false;
		}

		StringBuilder sbSpec = new StringBuilder();
		for (int i = 0; i < vc.size(); i++) {

			String sSpecSub = (String) vc.get(i);
			sbSpec.append(sSpecSub).append(ConstantsUtil.SYMBL_PIPE);
		}
		
		return vc;

}

}
