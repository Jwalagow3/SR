package com.pg.us.specanywhere_enovia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpecanywhereApplication {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		SpringApplication.run(SpecanywhereApplication.class, args);
	}

}