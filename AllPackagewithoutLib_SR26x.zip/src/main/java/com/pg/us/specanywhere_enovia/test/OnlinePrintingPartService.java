package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.OnlinePrintingPartBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.PromotionalItemPartBO;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class OnlinePrintingPartService {
	private static Logger LOGGER = Logger.getLogger(OnlinePrintingPartService.class);

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();

		String objId = "20336.41905.32777.13156";   // 91560451

		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
		Context context = pool.checkOut();
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();

		/*
		 * User Profile
		 * 
		SecurityService sct = new SecurityService();
		String sUserType = sct.getUserType();
		if(null==sUserType) {
			throw new Exception("Error in Log-In User Profile");
		}*/

		boolean bAllInfoView = true;
		boolean bSupplierView = true;
		boolean bManufacturerView = false;

		/*switch (sUserType) {
		case ConstantsUtil.PG:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PGSTAFF:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PG_CM:
			bManufacturerView = true;
			break;

		case ConstantsUtil.PG_SP:
			bSupplierView = true;
			break;
		}*/

		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpHeaderResult = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
		Map<String,String> mpDerivedToResult = new HashMap<String,String>();
		Map<String,String> mpPerformChar = new HashMap<String,String>();
		Map<String,String> mpMaterialResult = new HashMap<String,String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mpPlantResult = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String, String>();
		Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
		Map<String,String> mpSecurity = new HashMap<String,String>();
		Map<String,String> mpMasterAttribute = new HashMap<String,String>();
		Map<String,String> mpMasterSpecs = new HashMap<String,String>();
		Map<String,String> mpSubStanceResult = new HashMap<String,String>();
	

		OnlinePrintingPartBO OPPBO =new OnlinePrintingPartBO();
		StringValidatorUtil validator = new StringValidatorUtil();

		BusObjectAttribUtil util = new BusObjectAttribUtil();
		Map<String, StringList> BusinessObjectSelectableMap = OPPBO.getOnlinePrintingPartSelectables(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);

		DomainObject doOPP =  OPPBO.getOPPDO(context, objId);
		OPPBO.addMultiList();
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doOPP.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("OPP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		OPPBO.removeMultiList();


		if(bAllInfoView || bSupplierView || bManufacturerView) {

			//Header Content
			mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);

			//Basic  Data
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STAGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PARTCOLOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PART_COLOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRINTINGPROCESS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRPRINTINGPROSS)))?(String)resultMaps.get(ConstantsUtil.STRPRINTINGPROSS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DECORATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_DECORATION_DETAILS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);

			//Performance Car
			Map paramMap = new HashMap();
			paramMap.put(ConstantsUtil.OBJECT_ID, objId);
			paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
			paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
			paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

			PerformanceCharcteristics perform = new PerformanceCharcteristics();
			StopWatch swPerfChar = new StopWatch();
			swPerfChar.start();
			MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
			if(!mlPerformChar.isEmpty())
			{
				FinishedProductPartBO fppBO = new FinishedProductPartBO();
				MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
				//mpPerformChar =util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
				swPerfChar.stop();
				LOGGER.info("OPP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
			}


			//Materials
			mpMaterialResult = OPPBO.getSubstances(resultMaps);

			//Master Attribute Data
			String sMasterID= (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID) : ConstantsUtil.EMPTY_STRING);
			sMasterID="20336.41905.35132.43771";
			if(validator.isNotNullOrEmpty(sMasterID)){
				StopWatch swMasterAttrib = new StopWatch();
				swMasterAttrib.start();
				mpMasterAttribute = OPPBO.getMasterAttributeData(context,sMasterID);
				swMasterAttrib.stop();
				LOGGER.info("OPP GET MASTER ATTRIB ELAPSED TIME : "+swMasterAttrib.getTime());
			}

			//RelatedSpec
			StopWatch swRelatedSpec = new StopWatch();
			swRelatedSpec.start();
			mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
			swRelatedSpec.stop();
			LOGGER.info("OPP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());

		}

		if(bSupplierView || bManufacturerView) {
			
			/*
			 * LOAD SUBSTANCES
			 * */
			mpSubStanceResult.put(ConstantsUtil.NAME,(validator.isNotNullOrEmpty((String)mpMaterialResult.get(ConstantsUtil.COMP_NAME)))?(String)mpMaterialResult.get(ConstantsUtil.COMP_NAME) : ConstantsUtil.EMPTY_STRING);
			mpSubStanceResult.put(ConstantsUtil.CAS,(validator.isNotNullOrEmpty((String)mpMaterialResult.get(ConstantsUtil.COMP_CASNUM)))?(String)mpMaterialResult.get(ConstantsUtil.COMP_CASNUM) : ConstantsUtil.EMPTY_STRING);
			mpSubStanceResult.put(ConstantsUtil.ECNUMBER,(validator.isNotNullOrEmpty((String)mpMaterialResult.get(ConstantsUtil.COMP_ECNUMBER)))?(String)mpMaterialResult.get(ConstantsUtil.COMP_ECNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpSubStanceResult.put(ConstantsUtil.QUANTITY,(validator.isNotNullOrEmpty((String)mpMaterialResult.get(ConstantsUtil.COMP_QTY)))?(String)mpMaterialResult.get(ConstantsUtil.COMP_QTY) : ConstantsUtil.EMPTY_STRING);
			mpSubStanceResult.put(ConstantsUtil.TYPE,(validator.isNotNullOrEmpty((String)mpMaterialResult.get(ConstantsUtil.COMP_TYPE)))?(String)mpMaterialResult.get(ConstantsUtil.COMP_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,(validator.isNotNullOrEmpty((String)mpMaterialResult.get(ConstantsUtil.COMP_DESC)))?(String)mpMaterialResult.get(ConstantsUtil.COMP_DESC) : ConstantsUtil.EMPTY_STRING);
			mpSubStanceResult.put(ConstantsUtil.REACHREGISTATUS,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_REACHSTATUS)))?(String)resultMaps.get(ConstantsUtil.COMP_REACHSTATUS) : ConstantsUtil.EMPTY_STRING);
			mpSubStanceResult.put(ConstantsUtil.REACHPREREGSTATUS,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COMP_RPRSTATUS)))?(String)resultMaps.get(ConstantsUtil.COMP_RPRSTATUS) : ConstantsUtil.EMPTY_STRING);

		}

		if(bAllInfoView) {

			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
			mpAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
			String sClassifictaion = util.getClassification(resultMaps);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);

			//LifeCycle
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			mpLifeCycleApproval = util.getCOName(context, changeargs);
			swLifecycle.stop();
			LOGGER.info("OPP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
			mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);

			//Organization Data
			StopWatch swOrganization = new StopWatch();
			swOrganization.start();
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = util.filterMapList(mpOrganization);
			swOrganization.stop();
			LOGGER.info("OPP Organization ELAPSED TIME : "+swOrganization.getTime());

			//Derived Data
			StopWatch swDerived = new StopWatch();
			swDerived.start();
			String sName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING;
			mpDerivedFromResult = OPPBO.updateDerivedDataInfo(context,sName, sRev, sCreatedDate, doOPP,true,false);
			mpDerivedToResult = OPPBO.updateDerivedDataInfo(context,sName, sRev, sCreatedDate, doOPP,false,true);
			swDerived.stop();
			LOGGER.info("OPP  Derived ELAPSED TIME : "+swDerived.getTime());

			//Reference Docs
			StopWatch swReference= new StopWatch();
			swReference.start();
			MasterCOPBO mcop = new MasterCOPBO();
			mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
			swReference.stop();
			LOGGER.info("OPP  Reference ELAPSED TIME : "+swReference.getTime());

			//Plant Data
			StopWatch swPlant = new StopWatch();
			swPlant.start();
			FabricatedPartBO fab = new FabricatedPartBO();
			mpPlantResult = fab.updatePlantInfo(resultMaps);
			swPlant.stop();
			LOGGER.info("OPP Plant ELAPSED TIME : "+swPlant.getTime());

			//Ownership
			StopWatch swOwnerShip = new StopWatch();
			swOwnerShip.start();
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_CO_OWNERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);
			swOwnerShip.stop();
			LOGGER.info("OPP  OwnerShip ELAPSED TIME : "+swOwnerShip.getTime());

			/*
			 * LOAD SECURITY SECTION
			 * */
			StopWatch swSecurity = new StopWatch();
			CommonBusUtilBO commonBo = new CommonBusUtilBO();
			swSecurity.start();
			mpSecurity =commonBo.updateSecurity(context,resultMaps);
			swSecurity.stop();
			LOGGER.info("OPP  Security ELAPSED TIME : "+swSecurity.getTime());

			//Master Specs
			mpMasterSpecs.put(ConstantsUtil.ID,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_ID)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_ID) : ConstantsUtil.EMPTY_STRING);
			mpMasterSpecs.put(ConstantsUtil.NAME,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_NAME)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_NAME) : ConstantsUtil.EMPTY_STRING);
			mpMasterSpecs.put(ConstantsUtil.TITLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_TITLE)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpMasterSpecs.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_TYPE)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpMasterSpecs.put(ConstantsUtil.SPECIFICATIONSUBTYPE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_ASSEMBLY)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_ASSEMBLY) : ConstantsUtil.EMPTY_STRING);
			mpMasterSpecs.put(ConstantsUtil.STATE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_STATE)))?(String)resultMaps.get(ConstantsUtil.STR_MASTER_SPECS_STATE) : ConstantsUtil.EMPTY_STRING);
			//mpMasterSpecs = util.filterMapList(mpMasterSpecs);

		}

		pool.checkIn(context);

		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO, mpDerivedToResult);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
		hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpMaterialResult);
		hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
		hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
		hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
		hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
		hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
		hmAttrib.put(ConstantsUtil.MASTERATTRIBUTES, mpMasterAttribute);
		hmAttrib.put(ConstantsUtil.SUBSTANCES, mpSubStanceResult);

		sp.stop();
		System.out.println("OPP MESSAGE ELAPSED TIME::" + sp.getTime());
		System.out.println("RESULT:: \n" + hmAttrib);
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
	}

}
