package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class CMBO extends BusinessObject{

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(CMBO.class);
	static StringValidatorUtil validator = new StringValidatorUtil();
	static BusObjectAttribUtil util = new BusObjectAttribUtil();
	public CMBO() {
		// empty constructor
	}

	public CMBO(String oid) {
		this.setObjectId(oid);
	}

	/**
	 * Method Name : getDPPBO
	 * Method Description : Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getCMBO(String oId) throws MatrixException {
		try {
			return new BusinessObject(oId);
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}


	/**
	 * Method Name : getDPPDO
	 * Method Description : Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getCMDO(Context context, String oId) throws MatrixException {
		try {
			DomainObject bo =  DomainObject.newInstance(context, oId) ;
			if(bo.exists(context))
				return bo;
			else
				return null;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize Domainobject for ID in CMBO: " + oId);
			throw e;
		}
	}

	/**
	 * Method Name 			: getDPPPartSelectables
	 * Method Description 	: 
	 * @param context
	 * @return
	 */
	public Map<String, StringList> getCMPartSelectables(Context context) {
		StringList busSelect = new StringList(150);
		Map<String, StringList> mapSelecables = new HashMap<>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info selectables
		busSelect.addAll(getContextObjectBusSelectable());

		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;

	}

	/**
	 * Method Name 			: getContextObjectBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	public static StringList getContextObjectBusSelectable() {
		StringList busSelect = new StringList();
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE);

		return busSelect;
	}

	/**
	 * Method Name 			: getDPPRelatedObjsSelectableMap
	 * Method Description 	: 
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getCMRelatedObjsSelectableMap(Context context) {
		StringList busSelect = new StringList();
		StringList relSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); 

		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		mapSelecables.put(ConstantsUtil.REL_SELECTS, relSelect);
		return mapSelecables;

	}

	public Map getCharacteristicInformation(Context context,Map resultMaps){
		Map<String, String> mpCharacteristicInfo = new HashMap();

		StringBuilder sbBusinessArea = new StringBuilder();
		StringBuilder sbProductCategoryPlatform = new StringBuilder();
		StringBuilder sbCategory = new StringBuilder();
		StringBuilder sbCategorySpecifics= new StringBuilder();
		StringBuilder sbCharacteristic = new StringBuilder();
		StringBuilder sbCharacteristicSpecifics = new StringBuilder();
		StringBuilder sbOverwriteAllowedonChild = new StringBuilder();
		StringBuilder sbCharacteristicDescription = new StringBuilder();
		StringBuilder sbDimension = new StringBuilder();
		StringBuilder sbUOM = new StringBuilder();
		MapList relatedPartList = new MapList();

		String strBusinessArea = DomainConstants.EMPTY_STRING;
		String strPCP = DomainConstants.EMPTY_STRING;
		String strCategory = DomainConstants.EMPTY_STRING;
		String strCategorySpecifics = DomainConstants.EMPTY_STRING;
		String strCharacteristic = DomainConstants.EMPTY_STRING;
		String strCharacteristicSpecifics = DomainConstants.EMPTY_STRING;
		String strOverwriteAllowedonChild = DomainConstants.EMPTY_STRING;
		String strCharacteristicDescription = DomainConstants.EMPTY_STRING;
		String strDimension = DomainConstants.EMPTY_STRING;
		String strUOM = DomainConstants.EMPTY_STRING;

		try {
			CATIAAPPBO caAppBo =new CATIAAPPBO();
			Map<String, StringList> mpDimensionDisplayVals =caAppBo.getDimensions(context);
			StringList slSelect = new StringList(6);
			slSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSAREA);
			slSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTCATEGORYPLATFORM);

			StringList slMultiSel=new StringList();
			slMultiSel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSAREA);
			slMultiSel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTCATEGORYPLATFORM);

			StringList slbusSelects = new StringList();
			slbusSelects.add(DomainConstants.SELECT_NAME);
			slbusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARACTERISTICCATEGORY);
			slbusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCATEGORYSPECIFICS);
			slbusSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS);
			slbusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_OLMPARAMDISPLAYUNIT);
			slbusSelects.add(DomainConstants.SELECT_DESCRIPTION);
			slbusSelects.add(ConstantsUtilIRM.INTERFACE);
			slbusSelects.add(ConstantsUtilIRM.SELECT_UNIT_OF_MEASURE);
			StringList slRelSelects = new StringList();
			slRelSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_OVERWRITEALLOWEDONCHILD);

			String strObjectID = (String)resultMaps.get(DomainConstants.SELECT_ID);

			if(UIUtil.isNotNullAndNotEmpty(strObjectID))
			{
				DomainObject domObj =  DomainObject.newInstance(context, strObjectID) ;

				Map<?, ?> mObjList = domObj.getInfo(context,slSelect,slMultiSel);
				domObj.close(context);

				strBusinessArea = validator.getStringEquivalentForStringList(mObjList.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBUSINESSAREA));
				strPCP = validator.getStringEquivalentForStringList(mObjList.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTCATEGORYPLATFORM));

				util.formatData(sbBusinessArea, strBusinessArea);
				util.formatData(sbProductCategoryPlatform, strPCP);

				// Retrieving related item
				relatedPartList = domObj.getRelatedObjects(context,
						ConstantsUtil.REL_PARAMETERAGGREGATION,  //relationship pattern
						ConstantsUtil.SYMBL_ASTERISK,  // object pattern
						slbusSelects,                  // object selects
						slRelSelects,                  // relationship selects
						false,                         // to direction
						true,                          // from direction
						(short)1,                      // recursion level
						null,                          // object where clause
						null,
						0);

				Iterator<?> objectListItr = relatedPartList.iterator();
				while(objectListItr.hasNext()) {
					Map<?, ?> objectMap = (Map<?, ?>) objectListItr.next();

					strCategory = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARACTERISTICCATEGORY));
					strCategorySpecifics = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGCATEGORYSPECIFICS));
					strCharacteristic = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.SELECT_ATTRIBUTE_TITLE));
					strCharacteristicSpecifics = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCHARACTERISTICSPECIFICS));
					strOverwriteAllowedonChild = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_OVERWRITEALLOWEDONCHILD));
					strCharacteristicDescription = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.SELECT_DESCRIPTION));
					StringList slInterface = (StringList)objectMap.get(ConstantsUtilIRM.INTERFACE);
					strDimension =caAppBo.identifyDimensionUsingInterface(slInterface,mpDimensionDisplayVals);
					strUOM = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_OLMPARAMDISPLAYUNIT));
					//SPEC: 01-09-2022: Pooja Modified for Defect 50499 -- START
					if(strUOM.isEmpty() && !strDimension.equals(ConstantsUtil.STRING)) {
						strUOM = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_UNIT_OF_MEASURE));
					}
					//SPEC: 01-09-2022: Pooja Modified for Defect 50499 -- END
					util.formatData(sbCategory, strCategory);
					util.formatData(sbCategorySpecifics, strCategorySpecifics);
					util.formatData(sbCharacteristic, strCharacteristic);
					util.formatData(sbCharacteristicSpecifics, strCharacteristicSpecifics);
					util.formatData(sbOverwriteAllowedonChild, strOverwriteAllowedonChild);
					util.formatData(sbCharacteristicDescription, strCharacteristicDescription);
					util.formatData(sbDimension, strDimension);
					util.formatData(sbUOM, strUOM);

				}

				mpCharacteristicInfo.put(ConstantsUtil.BUSINESSAREA,sbBusinessArea.toString());
				mpCharacteristicInfo.put(ConstantsUtil.PRODUCTCATEGORYPLATFORM,sbProductCategoryPlatform.toString());
				mpCharacteristicInfo.put(ConstantsUtil.CATEGORY,sbCategory.toString());
				mpCharacteristicInfo.put(ConstantsUtilIRM.CATEGORYSPECIFICS,sbCategorySpecifics.toString());
				mpCharacteristicInfo.put(ConstantsUtil.CHARACTERISTIC,sbCharacteristic.toString());
				mpCharacteristicInfo.put(ConstantsUtil.CHARACTERISTICSPECIFICS,sbCharacteristicSpecifics.toString());
				mpCharacteristicInfo.put(ConstantsUtilIRM.OVERWRITEALLOWEDONCHILD,sbOverwriteAllowedonChild.toString());
				mpCharacteristicInfo.put(ConstantsUtilIRM.CHARACTERISTICDESCRIPTION,sbCharacteristicDescription.toString());
				mpCharacteristicInfo.put(ConstantsUtilIRM.DIMENSION,sbDimension.toString());
				mpCharacteristicInfo.put(ConstantsUtil.UOM,sbUOM.toString());

			}
		}catch(Exception e){
			LOGGER.error("Error from CMBO:  getCharacteristicInformation"+e);
			return new HashMap<String, String>();
		}
		return mpCharacteristicInfo;
	}

	public Map getValues(Context context,Map resultMaps){
		Map<String, String> mpValues = new HashMap();
		CATIAAPPBO catiaBO = new CATIAAPPBO();

		StringBuilder sbDesignSpecifics = new StringBuilder();
		StringBuilder sbLowerSpecificationLimit = new StringBuilder();
		StringBuilder sbLowerRoutineReleaseLimit = new StringBuilder();
		StringBuilder sbLowerTarget = new StringBuilder();
		StringBuilder sbTarget = new StringBuilder();
		StringBuilder sbUpperTarget = new StringBuilder();
		StringBuilder sbUpperRoutineReleaseLimit = new StringBuilder();
		StringBuilder sbUpperSpecificationLimit = new StringBuilder();
		StringBuilder sbCharacteristicNotes = new StringBuilder();
		StringBuilder sbTestMethodLogic = new StringBuilder();
		StringBuilder sbTestMethodOrigin = new StringBuilder();
		StringBuilder sbOtherTestMethodNumber = new StringBuilder();
		StringBuilder sbTestMethodSpecifics = new StringBuilder();
		StringBuilder sbTMReferenceDocName = new StringBuilder();
		StringBuilder sbTMReferenceDocID = new StringBuilder();
		StringBuilder sbTMReferenceDocType = new StringBuilder();
		StringBuilder sbSampling = new StringBuilder();
		StringBuilder sbSubgroup = new StringBuilder();
		StringBuilder sbPlantTestingLevel = new StringBuilder();
		StringBuilder sbPlantTestingRetesting = new StringBuilder();
		StringBuilder sbRetestingUOM = new StringBuilder();
		StringBuilder sbReportToNearest = new StringBuilder();
		StringBuilder sbReportType = new StringBuilder();
		StringBuilder sbIsDesignDriven = new StringBuilder();
		StringBuilder sbReleaseCriteria = new StringBuilder();
		StringBuilder sbActionRequired = new StringBuilder();
		StringBuilder sbCriticalityFactor = new StringBuilder();
		StringBuilder sbBasis = new StringBuilder();
		StringBuilder sbTestGroup = new StringBuilder();
		StringBuilder sbApplication = new StringBuilder();
		StringBuilder sbAppliestoInProcess = new StringBuilder();
		StringBuilder sbAppliestoBulk = new StringBuilder();
		StringBuilder sbAppliestoFinalPackage = new StringBuilder();

		String strDesignSpecifics = DomainConstants.EMPTY_STRING;
		String strLowerSpecificationLimit = DomainConstants.EMPTY_STRING;
		String strLowerRoutineReleaseLimit = DomainConstants.EMPTY_STRING;
		String strLowerTarget = DomainConstants.EMPTY_STRING;
		String strTarget = DomainConstants.EMPTY_STRING;
		String strUpperTarget = DomainConstants.EMPTY_STRING;
		String strUpperRoutineReleaseLimit = DomainConstants.EMPTY_STRING;
		String strUpperSpecificationLimit = DomainConstants.EMPTY_STRING;
		String strCharacteristicNotes = DomainConstants.EMPTY_STRING;
		String strTestMethodLogic = DomainConstants.EMPTY_STRING;
		String strTestMethodOrigin = DomainConstants.EMPTY_STRING;
		String strOtherTestMethodNumber = DomainConstants.EMPTY_STRING;
		String strTestMethodSpecifics = DomainConstants.EMPTY_STRING;
		String strSampling = DomainConstants.EMPTY_STRING;
		String strSubgroup = DomainConstants.EMPTY_STRING;
		String strPlantTestingLevel = DomainConstants.EMPTY_STRING;
		String strPlantTestingRetesting = DomainConstants.EMPTY_STRING;
		String strRetestingUOM = DomainConstants.EMPTY_STRING;
		String strReportToNearest = DomainConstants.EMPTY_STRING;
		String strReportType = DomainConstants.EMPTY_STRING;
		String strIsDesignDriven = DomainConstants.EMPTY_STRING;
		String strReleaseCriteria = DomainConstants.EMPTY_STRING;
		String strActionRequired = DomainConstants.EMPTY_STRING;
		String strCriticalityFactor = DomainConstants.EMPTY_STRING;
		String strBasis = DomainConstants.EMPTY_STRING;
		String strTestGroup = DomainConstants.EMPTY_STRING;
		String strApplication = DomainConstants.EMPTY_STRING;
		String strAppliestoInProcess = DomainConstants.EMPTY_STRING;
		String strAppliestoBulk = DomainConstants.EMPTY_STRING;
		String strAppliestoFinalPackage = DomainConstants.EMPTY_STRING;

		MapList relatedValuesList = new MapList();

		try {
			StringList slbusSelects = new StringList();
			slbusSelects.add(DomainConstants.SELECT_NAME);
			slbusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_DESIGNSPECIFICS);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT);
			slbusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARNOTES);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS);
			slbusSelects.add(ConstantsUtilIRM.SELECT_TMRD_NAME);
			slbusSelects.add(ConstantsUtilIRM.SELECT_TMRD_ID);
			slbusSelects.add(ConstantsUtilIRM.SELECT_TMRD_TYPE);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE);
			slbusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_ISDESIGNDRIVEN);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP);
			slbusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION);
			slbusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_APPLIESTOBULK);
			slbusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_APPLIESTOINPROCESS);
			slbusSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_APPLIESTOFINALPACKAGE);

			StringList slRelSelects = new StringList();
			String strObjectID = (String)resultMaps.get(DomainConstants.SELECT_ID);
			if(UIUtil.isNotNullAndNotEmpty(strObjectID)) {
				DomainObject domObj =  DomainObject.newInstance(context, strObjectID) ;
				// Retrieving related item
				relatedValuesList = domObj.getRelatedObjects(context,
						ConstantsUtil.REL_PARAMETERAGGREGATION,  //relationship pattern
						ConstantsUtil.SYMBL_ASTERISK,  // object pattern
						slbusSelects,                  // object selects
						slRelSelects,                  // relationship selects
						false,                         // to direction
						true,                          // from direction
						(short)1,                      // recursion level
						null,                          // object where clause
						null,
						0);

				Iterator<?> objectListItr = relatedValuesList.iterator();

				while(objectListItr.hasNext()) {
					Map<?, ?> objectMap = (Map<?, ?>) objectListItr.next();

					strDesignSpecifics = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_DESIGNSPECIFICS));
					strLowerSpecificationLimit = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOWERSPECIFICATIONLIMIT));
					strLowerRoutineReleaseLimit = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.EMPTY_STRING));
					strLowerTarget = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.EMPTY_STRING));
					strTarget = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.EMPTY_STRING));
					strUpperTarget = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.EMPTY_STRING));
					strUpperRoutineReleaseLimit = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.EMPTY_STRING));
					strUpperSpecificationLimit = validator.getStringEquivalentForSubstituteString(objectMap.get(DomainConstants.EMPTY_STRING));
					strCharacteristicNotes = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_CHARNOTES));
					strTestMethodLogic = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTMLOGIC));
					strTestMethodOrigin = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODORIGIN));
					strOtherTestMethodNumber = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODNUMBER));
					strTestMethodSpecifics = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMETHODSPECIFICS));
					strSampling = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAMPLING));
					strSubgroup = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBGROUP));
					strPlantTestingLevel = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTING));
					strPlantTestingRetesting = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLANTTESTINGRETESTING));
					strRetestingUOM = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRETESTINGUOM));
					strReportToNearest = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTONEAREST));
					strReportType = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPORTTYPE));
					strIsDesignDriven = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_ISDESIGNDRIVEN));
					strReleaseCriteria = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRELEASECRITERIA));
					strActionRequired = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGACTIONREQUIRED));
					strCriticalityFactor = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCRITICALITYFACTOR));
					strBasis = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASIS));
					strTestGroup = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTESTGROUP));
					strApplication = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAPPLICATION));
					strAppliestoInProcess = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_APPLIESTOINPROCESS));
					strAppliestoBulk = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_APPLIESTOBULK));
					strAppliestoFinalPackage = validator.getStringEquivalentForSubstituteString(objectMap.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_APPLIESTOFINALPACKAGE));

					StringList slTMRDID =validator.getStringListEquivalentForString(objectMap.get(ConstantsUtilIRM.SELECT_TMRD_ID));
					StringList slTMRDName = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtilIRM.SELECT_TMRD_NAME));
					StringList slTMRDType = validator.getStringListEquivalentForString(objectMap.get(ConstantsUtilIRM.SELECT_TMRD_TYPE));
					
					//SPEC: <18.08.2022>: Guna Modified for Defect 50051 22x Release  -- START
					Map finalMaps =catiaBO.checkAccessToTM(context, slTMRDID, slTMRDName, slTMRDType);
					
					util.formatData(sbTMReferenceDocName, validator.getStringEquivalentForSubstituteString(finalMaps.get(ConstantsUtil.TMFILNAME)));
					util.formatData(sbTMReferenceDocType, validator.getStringEquivalentForSubstituteString(finalMaps.get(ConstantsUtil.TMFILTYPE)));
					util.formatData(sbTMReferenceDocID, validator.getStringEquivalentForSubstituteString(finalMaps.get(ConstantsUtil.TMFILID)));
					//SPEC: <18.08.2022>: Guna Modified for Defect 50051 22x Release  -- END
					util.formatData(sbDesignSpecifics, strDesignSpecifics);
					util.formatData(sbLowerSpecificationLimit, strLowerSpecificationLimit);
					util.formatData(sbLowerRoutineReleaseLimit, strLowerRoutineReleaseLimit);
					util.formatData(sbLowerTarget, strLowerTarget);
					util.formatData(sbTarget, strTarget);
					util.formatData(sbUpperTarget, strUpperTarget);
					util.formatData(sbUpperRoutineReleaseLimit, strUpperRoutineReleaseLimit);
					util.formatData(sbUpperSpecificationLimit, strUpperSpecificationLimit);
					util.formatData(sbCharacteristicNotes, strCharacteristicNotes);
					util.formatData(sbTestMethodLogic, strTestMethodLogic);
					util.formatData(sbTestMethodOrigin, strTestMethodOrigin);
					util.formatData(sbOtherTestMethodNumber, strOtherTestMethodNumber);
					util.formatData(sbTestMethodSpecifics, strTestMethodSpecifics);
					util.formatData(sbSampling, strSampling);
					util.formatData(sbSubgroup, strSubgroup);
					util.formatData(sbPlantTestingLevel, strPlantTestingLevel);
					util.formatData(sbPlantTestingRetesting, strPlantTestingRetesting);
					util.formatData(sbRetestingUOM, strRetestingUOM);
					util.formatData(sbReportToNearest, strReportToNearest);
					util.formatData(sbReportType, strReportType);
					util.formatData(sbIsDesignDriven, strIsDesignDriven);
					util.formatData(sbReleaseCriteria, strReleaseCriteria);
					util.formatData(sbActionRequired, strActionRequired);
					util.formatData(sbCriticalityFactor, strCriticalityFactor);
					util.formatData(sbBasis, strBasis);
					util.formatData(sbTestGroup, strTestGroup);
					util.formatData(sbApplication, strApplication);
					util.formatData(sbAppliestoInProcess, strAppliestoInProcess);
					util.formatData(sbAppliestoBulk, strAppliestoBulk);
					util.formatData(sbAppliestoFinalPackage, strAppliestoFinalPackage);

				}
				mpValues.put(ConstantsUtilIRM.DESIGNSPECIFICS,strDesignSpecifics.toString());
				mpValues.put(ConstantsUtil.LOWERSPECLIMIT, sbLowerSpecificationLimit.toString());
				mpValues.put(ConstantsUtil.LRRL, sbLowerRoutineReleaseLimit.toString());
				mpValues.put(ConstantsUtil.LTGT, sbLowerTarget.toString());
				mpValues.put(ConstantsUtil.TGT, sbTarget.toString());
				mpValues.put(ConstantsUtil.UTGT, sbUpperTarget.toString());
				mpValues.put(ConstantsUtil.URRL, sbUpperRoutineReleaseLimit.toString());
				mpValues.put(ConstantsUtil.USL, sbUpperSpecificationLimit.toString());
				mpValues.put(ConstantsUtilIRM.CHARNOTES, sbCharacteristicNotes.toString());
				mpValues.put(ConstantsUtil.TML, sbTestMethodLogic.toString());
				mpValues.put(ConstantsUtil.ORIGIN, sbTestMethodOrigin.toString());
				mpValues.put(ConstantsUtil.TM, sbOtherTestMethodNumber.toString());
				mpValues.put(ConstantsUtil.SP, sbTestMethodSpecifics.toString());
				mpValues.put(ConstantsUtil.REF, sbTMReferenceDocName.toString());
				mpValues.put(ConstantsUtil.REFTYPE, sbTMReferenceDocType.toString());
				mpValues.put(ConstantsUtil.REFID, sbTMReferenceDocID.toString());
				mpValues.put(ConstantsUtil.SAMPLINGSM, sbSampling.toString());
				mpValues.put(ConstantsUtilIRM.SUBGROUP, sbSubgroup.toString());
				mpValues.put(ConstantsUtil.PLANTTESTING, sbPlantTestingLevel.toString());
				mpValues.put(ConstantsUtil.RT, sbPlantTestingRetesting.toString());
				mpValues.put(ConstantsUtil.UOM, sbRetestingUOM.toString());
				mpValues.put(ConstantsUtil.RTN, sbReportToNearest.toString());
				mpValues.put(ConstantsUtil.RTT, sbReportType.toString());
				mpValues.put(ConstantsUtilIRM.ISDESIGNDRIVEN, sbIsDesignDriven.toString());
				mpValues.put(ConstantsUtil.RELEASECRITERIA, sbReleaseCriteria.toString());
				mpValues.put(ConstantsUtil.ACTIONREQUIRED, sbActionRequired.toString());
				mpValues.put(ConstantsUtilIRM.CRITICALFACTOR, sbCriticalityFactor.toString());
				mpValues.put(ConstantsUtil.BA, sbBasis.toString());
				mpValues.put(ConstantsUtil.TESTGROUP, sbTestGroup.toString());
				mpValues.put(ConstantsUtil.AP, sbApplication.toString());
				mpValues.put(ConstantsUtilIRM.APPROCESS, sbAppliestoInProcess.toString());
				mpValues.put(ConstantsUtilIRM.APBULK, sbAppliestoBulk.toString());
				mpValues.put(ConstantsUtilIRM.APFINALPKG, sbAppliestoFinalPackage.toString());
			}

		}catch(Exception e){
			LOGGER.error("Error from CMBO:  getValues"+e);
			return new HashMap<String, String>();
		}

		return mpValues;
	}
}
