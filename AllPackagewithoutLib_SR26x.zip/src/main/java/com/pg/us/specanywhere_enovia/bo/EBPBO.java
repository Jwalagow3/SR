/**
 * Project 		: SpecsAnywhere
 * Program 		: EBPBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;
import matrix.util.StringList;
import com.matrixone.apps.framework.ui.UIUtil;

public class EBPBO {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(EBPBO.class);
	BusObjectAttribUtil util  = new BusObjectAttribUtil();

	public EBPBO() {
		// empty constructor
	}

	
	
	/**
	 * Method Name 			: getEBPSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public StringList getEBPSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		busSelect.add("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.id");
		busSelect.add("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.type");
		busSelect.add("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.name");
		busSelect.add("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.revision");
		busSelect.add("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.description");
		busSelect.add("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to.current");
		busSelect.add("from[" +ConstantsUtil.RELATIONSHIP_PGSUMMARYTOPRODUCTDATA+ "].to."+ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		return busSelect;
	}
	
	
	/**
	 * Method Name 			: getImpactedPartDetails
	 * Method Description 	: Fetching "EBP Impacted Part" related data
	 * @param context 
	 * @param strObjId
	 * @return
	 */
	 @SuppressWarnings("unchecked")
	public Map<String, String> getImpactedPartDetails(Context context, String strObjId, String strType, String siName,String siRev, String siTitle, boolean bSpecCount) {
		 	
		 Map<String, String> mImpactedPartDetails = new HashMap<>();
		 Map<String, String> mImpactedPartFPPDetails = new HashMap<>();
		 StringList slImpactedpartSelects = new StringList();
		 slImpactedpartSelects.add(DomainConstants.SELECT_TYPE);
		 slImpactedpartSelects.add(DomainConstants.SELECT_NAME);
		 slImpactedpartSelects.add(DomainConstants.SELECT_REVISION);
		 slImpactedpartSelects.add(DomainConstants.SELECT_CURRENT);
		 slImpactedpartSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		 slImpactedpartSelects.add(DomainConstants.SELECT_ID);
		 
		 StringBuilder sbName=new StringBuilder();
		 StringBuilder sbID = new StringBuilder();
		 StringBuilder sbType = new StringBuilder();
		 StringBuilder sbTypeBack = new StringBuilder();
		 StringBuilder sbDisType = new StringBuilder();
		 StringBuilder sbTitle = new StringBuilder();
		 StringBuilder sbRev = new StringBuilder();
		 StringList strUniqueId= new StringList();//added by ajay for 22x.06 Defect 8030
		 
		 short rshort = (short) 1;
		 try {
				DomainObject doObj = DomainObject.newInstance(context,strObjId);
				String relPattern = DomainConstants.EMPTY_STRING;
				String typePattern = ConstantsUtil.SYMBL_ASTERISK;
				boolean bShowDetails = false;
				if(ConstantsUtilIRM.WHERE_USED_TYPE.contains(strType)) {
					if(!(siName.contains(ConstantsUtilIRM.CONST_MEP) || siName.contains(ConstantsUtilIRM.CONST_SEP))) {
						bShowDetails=util.checkHasAccess(context, null, strObjId);
						if(bShowDetails && !strUniqueId.contains(strObjId)){
							util.formatData(sbName,siName);
							util.formatData(sbID,strObjId);
							util.formatData(sbTypeBack,strType);
							String sDisplayType = util.getMappedTypeforMPS(strType);
							String sFinalType = util.mapType(strType);
							util.formatData(sbType,sFinalType);
							util.formatData(sbDisType,sDisplayType);
							util.formatData(sbTitle,siTitle);
							util.formatData(sbRev,siRev);
						}
						strUniqueId.add(strObjId);// //added by ajay for 22x.06 Defect 8030
					}
				}
				else {
				if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGTRANSPORTUNITPART)) {
					 relPattern = ConstantsUtil.RELATIONSHIP_PGTRANSPORTUNIT;
				 }
				//Modified by Ajay for Req. 10874  -- START
				else if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGINNERPACKUNITPART) || strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNIT) || strType.equalsIgnoreCase(ConstantsUtil.TYPE_PG_CUSTOMERUNIT) || strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERCONSUMERUNITPART) || strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERCUSTOMERUNITPART) || strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGMASTERINNERPACKUNITPART)) { 
					 relPattern = ConstantsUtil.RELATIONSHIP_EBOM + "," +ConstantsUtil.RELATIONSHIP_ALTERNATE;
					 rshort = (short) 0;
					 typePattern = ConstantsUtil.SYMBL_ASTERISK;
				 }
				//Modified by Ajay for Req. 10874  -- END
				else if(ConstantsUtilIRM.WHERE_USED_MASTER_TYPE.contains(strType)) {
					relPattern = ConstantsUtilIRM.REL_CLASSIFIED_ITEM;
					typePattern = ConstantsUtil.SYMBL_ASTERISK;
				}
				StringList slImpactedpartRelSelects = new StringList();
				slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.id");
				slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.name");
				slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.type");
				slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.revision");
				slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.current");
				slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.attribute[Title]");
		
				if(ConstantsUtilIRM.WHERE_USED_FIRST_LVL_SPEC.contains(strType)) {
					MapList mlMasterBom1 = doObj.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION, // Rel
							// Pattern
							ConstantsUtil.SYMBL_ASTERISK, // Type
							// Pattern
							slImpactedpartSelects, // Object Select
							null, // rel Select
							true, // get To
							false, // get From
							(short) 1, // recurse level
							ConstantsUtilIRM.CURRENT_RELEASE, // where Clause
							null, // relationshipWhere Clause
							0);
					Iterator objectListItr1 = mlMasterBom1.iterator();
					
					while(objectListItr1.hasNext())
					{
						Map objectMap1 = (Map) objectListItr1.next();

						String sName1=(String)objectMap1.get(DomainConstants.SELECT_NAME);
						String sID1=(String)objectMap1.get(DomainConstants.SELECT_ID);
						String sType1=(String)objectMap1.get(DomainConstants.SELECT_TYPE);
						String sTitle1=(String)objectMap1.get(DomainConstants.SELECT_ATTRIBUTE_TITLE);
						String sRev1=(String)objectMap1.get(DomainConstants.SELECT_REVISION);
						
						if(!(sName1.contains(ConstantsUtilIRM.CONST_MEP) || sName1.contains(ConstantsUtilIRM.CONST_SEP))) {
							bShowDetails=util.checkHasAccess(context, null, sID1);
							if(bShowDetails && !strUniqueId.contains(sID1)) {
								util.formatData(sbName,sName1);
								util.formatData(sbID,sID1);
								util.formatData(sbTypeBack,sType1);
								String sDisplayType = util.getMappedTypeforMPS(sType1);
								String sFinalType = util.mapType(sType1);
								util.formatData(sbType,sFinalType);
								util.formatData(sbDisType,sDisplayType);
								util.formatData(sbTitle,sTitle1);
								util.formatData(sbRev,sRev1);
							}
							strUniqueId.add(sID1);// //added by ajay for 22x.06 Defect 8030
						}
				}
				
			}else{
				MapList mlMasterBom = doObj.getRelatedObjects(context, 
						relPattern, // Rel Pattern
						typePattern, // Type Pattern
						slImpactedpartSelects, // Object Select
						slImpactedpartRelSelects, // rel Select
						true, // get To
						false, // get From
						rshort, // recurse level
						ConstantsUtilIRM.CURRENT_RELEASE_OR_ACTIVE, // where Clause
						null, // relationshipWhere Clause
						0);
				//Added by Ajay for Defect 11202 - START
				String	strMQLCommand = "print bus " + strObjId + " select " + ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_SELECTS + "";
				String	strResult = MqlUtil.mqlCommand(context, strMQLCommand);
				String saSubstitute[] = strResult.split("\\r?\\n");
				int intTokens = saSubstitute.length;
				String saEachObj[] = new String[7];
				StringList slsCurrent = new StringList();
				StringList slsType = new StringList();
				StringList slsName = new StringList();
				StringList slsRevision = new StringList();
				StringList slsId = new StringList();
				StringList slsTitle = new StringList();
				StringValidatorUtil validator = new StringValidatorUtil();
				if(validator.isNotNullOrEmpty(strResult)) {
					for (int i=0;i<intTokens;i++)
					{
						String strTemp = saSubstitute[i];
						if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_CURRENT)) {
								saEachObj = strTemp.split("\\=");
								String sCurrent=saEachObj[1];
								sCurrent=sCurrent.trim();
								slsCurrent.add(sCurrent);
						}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_TYPE)) {
								saEachObj = strTemp.split("\\=");
								String sType=saEachObj[1];
								sType=sType.trim();
								slsType.add(sType);	
							
						}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_NAME)) {
								saEachObj = strTemp.split("\\=");
								String sName=saEachObj[1];
								sName=sName.trim();
								slsName.add(sName);
						}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_REV)) {
								saEachObj = strTemp.split("\\=");
								String sRevision=saEachObj[1];
								sRevision=sRevision.trim();
								slsRevision.add(sRevision);
						}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_ID)) {
								saEachObj = strTemp.split("\\=");
								String sId=saEachObj[1];
								sId=sId.trim();
								slsId.add(sId);
						}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_TITLE)) {
								saEachObj = strTemp.split("\\=");
								String sTitle=saEachObj[1];
								sTitle=sTitle.trim();
								slsTitle.add(sTitle);
						}
						
					}
					int iCount=slsCurrent.size();
					for(int i=0;i<iCount;i++) {
						String sCurrent= (String)slsCurrent.get(i);
						if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
							String sType = (String)slsType.get(i);
							String sId = (String)slsId.get(i);
							String sTitle = (String)slsTitle.get(i);
							String sRevision = (String)slsRevision.get(i);
							String sName = (String)slsName.get(i);
							//Modified by Ajay for Req 102605 - START
							//Added by Ajay for Defect 11208 - START
							DomainObject doObj1 = DomainObject.newInstance(context,sId);
							
							MapList mlMasterBom1 = doObj1.getRelatedObjects(context, 
									relPattern, // Rel Pattern
									typePattern, // Type Pattern
									slImpactedpartSelects, // Object Select
									slImpactedpartRelSelects, // rel Select
									true, // get To
									false, // get From
									rshort, // recurse level
									ConstantsUtilIRM.CURRENT_RELEASE_OR_ACTIVE, // where Clause
									null, // relationshipWhere Clause
									0);
							mlMasterBom.addAll(mlMasterBom1);
							
							if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
								Map<String,String> mapObj = new HashMap<String, String>();
								mapObj.put(DomainConstants.SELECT_ID, sId);
								mapObj.put(DomainConstants.SELECT_TYPE, sType);
								mapObj.put(DomainConstants.SELECT_CURRENT, sCurrent);
								mapObj.put(DomainConstants.SELECT_ATTRIBUTE_TITLE, sTitle);
								mapObj.put(DomainConstants.SELECT_REVISION, sRevision);
								mapObj.put(DomainConstants.SELECT_NAME, sName);
								mapObj.put(DomainConstants.SELECT_LEVEL, ConstantsUtilIRM.STR_ONE);
								mlMasterBom.add(mapObj);
							}
							//Added by Ajay for Defect 11208 - END
							//Modified by Ajay for Req 102605 - END
						}
					}
				}
				//Added by Ajay for Defect 11202 - END
				Iterator objectListItr = mlMasterBom.iterator();
				//Added by Ajay for 22x.06 Defect 7887 - START
				int iLevel = 0;
				int iPrevLevel = -1;
				boolean bIsFPPfound = false;
				//Added by Ajay for 22x.06 Defect 7887 - END
				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String sName = ConstantsUtil.EMPTY_STRING;
					String sID = ConstantsUtil.EMPTY_STRING;
					String sType = ConstantsUtil.EMPTY_STRING;
					String sRev = ConstantsUtil.EMPTY_STRING;
					String sTitle = ConstantsUtil.EMPTY_STRING;
					String sCurrent = ConstantsUtil.EMPTY_STRING;
					
					if(ConstantsUtilIRM.WHERE_USED_MASTER_TYPE.contains(strType)) {
					//StringValidatorUtil validator = new StringValidatorUtil();
					sName=validator.getStringEquivalentForStringList(objectMap.get("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.name"));
					sID=validator.getStringEquivalentForStringList(objectMap.get("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.id"));
					sType=validator.getStringEquivalentForStringList(objectMap.get("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.type"));
					sRev=validator.getStringEquivalentForStringList(objectMap.get("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.revision"));
					sCurrent=validator.getStringEquivalentForStringList(objectMap.get("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.current"));
					
					 String [] slName = sName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			         String [] slId = sID.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			         String [] slType = sType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			         String [] slRev = sRev.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			         String [] slCurrent = sCurrent.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
			         if(bSpecCount == true) {
			         if (slCurrent.length > -1 && slCurrent.length <= 20) {
							for (int i = 0; i < slCurrent.length; i++) {
								if (null != slCurrent[i]) {
									String strCurrent = slCurrent[i].toString().trim();
									String strName = slName[i].toString().trim();
									String strId = slId[i].toString().trim();
									String srType = slType[i].toString().trim();
									String strRev = slRev[i].toString().trim();
									String strTitle = DomainConstants.EMPTY_STRING;
									if (strCurrent.equals(ConstantsUtil.STATE_RELEASE)) {
										if(!(strName.contains(ConstantsUtilIRM.CONST_MEP) || strName.contains(ConstantsUtilIRM.CONST_SEP))) {
											bShowDetails=util.checkHasAccess(context, null, strId);
											if(bShowDetails && !strUniqueId.contains(strId)){
												util.formatData(sbName,strName);
												util.formatData(sbID,strId);
												util.formatData(sbTypeBack,srType);
												String sDisplayType = util.getMappedTypeforMPS(srType);
												String sFinalType = util.mapType(srType);
												util.formatData(sbType,sFinalType);
												util.formatData(sbDisType,sDisplayType);
												DomainObject dObject = DomainObject.newInstance(context, strId);
												strTitle = dObject.getInfo(context, DomainConstants.SELECT_ATTRIBUTE_TITLE);
												util.formatData(sbTitle,strTitle);
												util.formatData(sbRev,strRev);
											}
											strUniqueId.add(strId);//added by ajay for 22x.06 Defect 8030
											if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
												mImpactedPartFPPDetails = getImpactedFPPParts(context,sID,sType,strUniqueId);
												String srDisplayType = mImpactedPartFPPDetails.get(ConstantsUtilIRM.DISPLAY_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srName = mImpactedPartFPPDetails.get(DomainConstants.SELECT_NAME).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srId = mImpactedPartFPPDetails.get(DomainConstants.SELECT_ID).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srTitle = mImpactedPartFPPDetails.get(ConstantsUtil.TITLE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srRevision = mImpactedPartFPPDetails.get(DomainConstants.SELECT_REVISION).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srrType = mImpactedPartFPPDetails.get(DomainConstants.SELECT_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												if(UIUtil.isNotNullAndNotEmpty(srId)) {
													util.formatData(sbName,srName);
													util.formatData(sbID,srId);
													util.formatData(sbTypeBack,srrType);
													util.formatData(sbType,srrType);
													util.formatData(sbDisType,srDisplayType);
													util.formatData(sbTitle,srTitle);
													util.formatData(sbRev,srRevision);
												}
												
											}
										}
									}
								}
							}
						}
			         else {

							for (int i = 0; i < 20; i++) {
								if (null != slCurrent[i]) {
									String strCurrent = slCurrent[i].toString().trim();
									String strName = slName[i].toString().trim();
									String strId = slId[i].toString().trim();
									String srType = slType[i].toString().trim();
									String strRev = slRev[i].toString().trim();
									String strTitle = DomainConstants.EMPTY_STRING;
									if (strCurrent.equals(ConstantsUtil.STATE_RELEASE)) {
										if(!(strName.contains(ConstantsUtilIRM.CONST_MEP) || strName.contains(ConstantsUtilIRM.CONST_SEP))) {
											bShowDetails=util.checkHasAccess(context, null, strId);
											if(bShowDetails && !strUniqueId.contains(strId)){
												util.formatData(sbName,strName);
												util.formatData(sbID,strId);
												util.formatData(sbTypeBack,srType);
												String sDisplayType = util.getMappedTypeforMPS(srType);
												String sFinalType = util.mapType(srType);
												util.formatData(sbType,sFinalType);
												util.formatData(sbDisType,sDisplayType);
												DomainObject dObject = DomainObject.newInstance(context, strId);
												strTitle = dObject.getInfo(context, DomainConstants.SELECT_ATTRIBUTE_TITLE);
												util.formatData(sbTitle,strTitle);
												util.formatData(sbRev,strRev);
											}
											strUniqueId.add(strId);//added by ajay for 22x.06 Defect 8030
											if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
												mImpactedPartFPPDetails = getImpactedFPPParts(context,sID,sType,strUniqueId);
												String srDisplayType = mImpactedPartFPPDetails.get(ConstantsUtilIRM.DISPLAY_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srName = mImpactedPartFPPDetails.get(DomainConstants.SELECT_NAME).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srId = mImpactedPartFPPDetails.get(DomainConstants.SELECT_ID).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srTitle = mImpactedPartFPPDetails.get(ConstantsUtil.TITLE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srRevision = mImpactedPartFPPDetails.get(DomainConstants.SELECT_REVISION).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srrType = mImpactedPartFPPDetails.get(DomainConstants.SELECT_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												if(UIUtil.isNotNullAndNotEmpty(srId)) {
													util.formatData(sbName,srName);
													util.formatData(sbID,srId);
													util.formatData(sbTypeBack,srrType);
													util.formatData(sbType,srrType);
													util.formatData(sbDisType,srDisplayType);
													util.formatData(sbTitle,srTitle);
													util.formatData(sbRev,srRevision);
												}
												
											}
										}
									}
								}
							}
						
			         }
			         }
			         else {

							for (int i = 0; i < slCurrent.length; i++) {
								if (null != slCurrent[i]) {
									String strCurrent = slCurrent[i].toString().trim();
									String strName = slName[i].toString().trim();
									String strId = slId[i].toString().trim();
									String srType = slType[i].toString().trim();
									String strRev = slRev[i].toString().trim();
									String strTitle = DomainConstants.EMPTY_STRING;
									if (strCurrent.equals(ConstantsUtil.STATE_RELEASE)) {
										if(!(strName.contains(ConstantsUtilIRM.CONST_MEP) || strName.contains(ConstantsUtilIRM.CONST_SEP))) {
											bShowDetails=util.checkHasAccess(context, null, strId);
											if(bShowDetails && !strUniqueId.contains(strId)){
												util.formatData(sbName,strName);
												util.formatData(sbID,strId);
												util.formatData(sbTypeBack,srType);
												String sDisplayType = util.getMappedTypeforMPS(srType);
												String sFinalType = util.mapType(srType);
												util.formatData(sbType,sFinalType);
												util.formatData(sbDisType,sDisplayType);
												DomainObject dObject = DomainObject.newInstance(context, strId);
												strTitle = dObject.getInfo(context, DomainConstants.SELECT_ATTRIBUTE_TITLE);
												util.formatData(sbTitle,strTitle);
												util.formatData(sbRev,strRev);
											}
											strUniqueId.add(strId);//added by ajay for 22x.06 Defect 8030
											if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
												mImpactedPartFPPDetails = getImpactedFPPParts(context,sID,sType,strUniqueId);
												String srDisplayType = mImpactedPartFPPDetails.get(ConstantsUtilIRM.DISPLAY_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srName = mImpactedPartFPPDetails.get(DomainConstants.SELECT_NAME).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srId = mImpactedPartFPPDetails.get(DomainConstants.SELECT_ID).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srTitle = mImpactedPartFPPDetails.get(ConstantsUtil.TITLE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srRevision = mImpactedPartFPPDetails.get(DomainConstants.SELECT_REVISION).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												String srrType = mImpactedPartFPPDetails.get(DomainConstants.SELECT_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
												if(UIUtil.isNotNullAndNotEmpty(srId)) {
													util.formatData(sbName,srName);
													util.formatData(sbID,srId);
													util.formatData(sbTypeBack,srrType);
													util.formatData(sbType,srrType);
													util.formatData(sbDisType,srDisplayType);
													util.formatData(sbTitle,srTitle);
													util.formatData(sbRev,srRevision);
												}
												
											}
										}
									}
								}
							}
						
			         }
					}
					
					else {
					sType=(String)objectMap.get(DomainConstants.SELECT_TYPE);
					sName=(String)objectMap.get(DomainConstants.SELECT_NAME);
					sID=(String)objectMap.get(DomainConstants.SELECT_ID);
					sTitle=(String)objectMap.get(DomainConstants.SELECT_ATTRIBUTE_TITLE);
					sRev=(String)objectMap.get(DomainConstants.SELECT_REVISION);
					}
					
					if((strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGINNERPACKUNITPART) || strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNIT) || strType.equalsIgnoreCase(ConstantsUtil.TYPE_PG_CUSTOMERUNIT)) && sType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
						if(!(sName.contains(ConstantsUtilIRM.CONST_MEP) || sName.contains(ConstantsUtilIRM.CONST_SEP))) {
							//Modified by Ajay for Defect 11208 - START
							iLevel=Integer.parseInt((String)objectMap.get(DomainConstants.SELECT_LEVEL));
							bShowDetails=util.checkHasAccess(context, null, sID);
							//Modified by Ajay for 22x.06 Defect 7887 - START
							if (iLevel <= iPrevLevel){
								bIsFPPfound = false;
							}
							//Modified by Ajay for Defect 11208 - END
							if(bShowDetails && !strUniqueId.contains(sID) && !bIsFPPfound){
								util.formatData(sbName,sName);
								util.formatData(sbID,sID);
								util.formatData(sbTypeBack,sType);
								String sDisplayType = util.getMappedTypeforMPS(sType);
								String sFinalType = util.mapType(sType);
								util.formatData(sbType,sFinalType);
								util.formatData(sbDisType,sDisplayType);
								util.formatData(sbTitle,sTitle);
								util.formatData(sbRev,sRev);
								bIsFPPfound = false;//Modified by Ajay for Req 102605
								iPrevLevel = iLevel;
							}
							//Modified by Ajay for 22x.06 Defect 7887 - END
							strUniqueId.add(sID);//added by ajay for 22x.06 Defect 8030
							if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
								mImpactedPartFPPDetails = getImpactedFPPParts(context,sID,sType,strUniqueId);
								String srDisplayType = mImpactedPartFPPDetails.get(ConstantsUtilIRM.DISPLAY_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srName = mImpactedPartFPPDetails.get(DomainConstants.SELECT_NAME).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srId = mImpactedPartFPPDetails.get(DomainConstants.SELECT_ID).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srTitle = mImpactedPartFPPDetails.get(ConstantsUtil.TITLE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srRevision = mImpactedPartFPPDetails.get(DomainConstants.SELECT_REVISION).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srrType = mImpactedPartFPPDetails.get(DomainConstants.SELECT_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								if(UIUtil.isNotNullAndNotEmpty(srId)) {
									util.formatData(sbName,srName);
									util.formatData(sbID,srId);
									util.formatData(sbTypeBack,srrType);
									util.formatData(sbType,srrType);
									util.formatData(sbDisType,srDisplayType);
									util.formatData(sbTitle,srTitle);
									util.formatData(sbRev,srRevision);
								}
								
							}
						}
					 }
					
					if(strType.equalsIgnoreCase(ConstantsUtil.TYPE_PGTRANSPORTUNITPART)){
						if(!(sName.contains(ConstantsUtilIRM.CONST_MEP) || sName.contains(ConstantsUtilIRM.CONST_SEP))) {
							bShowDetails=util.checkHasAccess(context, null, sID);
							if(bShowDetails && !strUniqueId.contains(sID)){
								util.formatData(sbName,sName);
								util.formatData(sbID,sID);
								util.formatData(sbTypeBack,sType);
								String sDisplayType = util.getMappedTypeforMPS(sType);
								String sFinalType = util.mapType(sType);
								util.formatData(sbType,sFinalType);
								util.formatData(sbDisType,sDisplayType);
								util.formatData(sbTitle,sTitle);
								util.formatData(sbRev,sRev);
							}
							strUniqueId.add(sID);//added by ajay for 22x.06 Defect 8030
							if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
								mImpactedPartFPPDetails = getImpactedFPPParts(context,sID,sType,strUniqueId);
								String srDisplayType = (mImpactedPartFPPDetails.get(ConstantsUtilIRM.DISPLAY_TYPE)).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srName = mImpactedPartFPPDetails.get(DomainConstants.SELECT_NAME).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srId = mImpactedPartFPPDetails.get(DomainConstants.SELECT_ID).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srTitle = mImpactedPartFPPDetails.get(ConstantsUtil.TITLE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srRevision = mImpactedPartFPPDetails.get(DomainConstants.SELECT_REVISION).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								String srType = mImpactedPartFPPDetails.get(DomainConstants.SELECT_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
								if(UIUtil.isNotNullAndNotEmpty(srId)) {
									util.formatData(sbName,srName);
									util.formatData(sbID,srId);
									util.formatData(sbTypeBack,srType);
									util.formatData(sbType,srType);
									util.formatData(sbDisType,srDisplayType);
									util.formatData(sbTitle,srTitle);
									util.formatData(sbRev,srRevision);
								}
								
							}
							
						} 
					 }
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_PGTRANSPORTUNITPART)){
						DomainObject doObjTUP = DomainObject.newInstance(context,sID);
						MapList mlTUPBom = doObjTUP.getRelatedObjects(context, 
								ConstantsUtil.RELATIONSHIP_PGTRANSPORTUNIT, // Rel Pattern
								typePattern, // Type Pattern
								slImpactedpartSelects, // Object Select
								null, // rel Select
								true, // get To
								false, // get From
								rshort, // recurse level
								ConstantsUtilIRM.CURRENT_RELEASE, // where Clause
								null, // relationshipWhere Clause
								0);
						Iterator objTUPListItr = mlTUPBom.iterator();
						while(objTUPListItr.hasNext())
						{
							Map objMap = (Map) objTUPListItr.next();
							String sFPPType=(String)objMap.get(DomainConstants.SELECT_TYPE);
							String strName=(String)objMap.get(DomainConstants.SELECT_NAME);
							String strID=(String)objMap.get(DomainConstants.SELECT_ID);
							String strTitle=(String)objMap.get(DomainConstants.SELECT_ATTRIBUTE_TITLE);
							String strRev=(String)objMap.get(DomainConstants.SELECT_REVISION);
							if(!(strName.contains(ConstantsUtilIRM.CONST_MEP) || strName.contains(ConstantsUtilIRM.CONST_SEP))) {
								bShowDetails=util.checkHasAccess(context, null, strID);
								if(bShowDetails){
									if(!sbName.toString().contains(strName) && !strUniqueId.contains(strID)) {
										util.formatData(sbName,strName);
										util.formatData(sbID,strID);
										util.formatData(sbTypeBack,sFPPType);
										String sDisplayType = util.getMappedTypeforMPS(sFPPType);
										String sFinalType = util.mapType(sFPPType);
										util.formatData(sbType,sFinalType);
										util.formatData(sbDisType,sDisplayType);
										util.formatData(sbTitle,strTitle);
										util.formatData(sbRev,strRev);
									}
									strUniqueId.add(strID);//added by ajay for 22x.06 Defect 8030
									if(sFPPType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
										mImpactedPartFPPDetails = getImpactedFPPParts(context,strID,sFPPType,strUniqueId);
										String srDisplayType = mImpactedPartFPPDetails.get(ConstantsUtilIRM.DISPLAY_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
										String srName = mImpactedPartFPPDetails.get(DomainConstants.SELECT_NAME).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
										String srId = mImpactedPartFPPDetails.get(DomainConstants.SELECT_ID).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
										String srTitle = mImpactedPartFPPDetails.get(ConstantsUtil.TITLE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
										String srRevision = mImpactedPartFPPDetails.get(DomainConstants.SELECT_REVISION).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
										String srrType = mImpactedPartFPPDetails.get(DomainConstants.SELECT_TYPE).replaceAll(ConstantsUtilIRM.BACK_SLASH_PIPE, ConstantsUtil.VALUE_BOM_TEXT);
										if(UIUtil.isNotNullAndNotEmpty(srId)) {
											util.formatData(sbName,srName);
											util.formatData(sbID,srId);
											util.formatData(sbTypeBack,srrType);
											util.formatData(sbType,srrType);
											util.formatData(sbDisType,srDisplayType);
											util.formatData(sbTitle,srTitle);
											util.formatData(sbRev,srRevision);
										}
										
									}
								}
							}
						}
						
					}
				}
				}
				}
				mImpactedPartDetails.put(ConstantsUtil.ID, sbID.toString());
				mImpactedPartDetails.put(ConstantsUtil.TYPE,sbType.toString());
				mImpactedPartDetails.put(ConstantsUtilIRM.DISPLAY_TYPE,sbDisType.toString());
				mImpactedPartDetails.put(ConstantsUtilIRM.TYPE_BACKEND,sbTypeBack.toString());
				mImpactedPartDetails.put(ConstantsUtil.NAME, sbName.toString());
				mImpactedPartDetails.put(ConstantsUtil.REVISION, sbRev.toString());
				mImpactedPartDetails.put(ConstantsUtil.TITLE, sbTitle.toString());
				} catch (Exception ex) {
	      		LOGGER.error("Exception in Program : EBPBO Method :getImpactedPartDetails "+ex);
		 } 
		 return mImpactedPartDetails;
	 }
	 
	 public Map<String, String> getSpecImpactedPartDetails(Context context, String strObjId, String strType) {
		 	
		 Map<String, String> mImpactedPartDetails = new HashMap<>();
		 Map<String, String> mTempImpactedPartDetails = new HashMap<>();//Added by Ketan for Defect no. 6910
		 Map<String, String> mFinalImpactedPartDetails = new HashMap<>();
		 StringList slImpactedpartSelects = new StringList();
		 slImpactedpartSelects.add(DomainConstants.SELECT_TYPE);
		 slImpactedpartSelects.add(DomainConstants.SELECT_NAME);
		 slImpactedpartSelects.add(DomainConstants.SELECT_REVISION);
		 slImpactedpartSelects.add(DomainConstants.SELECT_CURRENT);
		 slImpactedpartSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		 slImpactedpartSelects.add(DomainConstants.SELECT_ID);
		 short rshort = (short) 1;
		 boolean bSpecCount = false;
		 try {
				DomainObject doObj = DomainObject.newInstance(context,strObjId);
				String relPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION;
				String typePattern = ConstantsUtil.SYMBL_ASTERISK;
				MapList mlMasterBom = doObj.getRelatedObjects(context, 
						relPattern, // Rel Pattern
						typePattern, // Type Pattern
						slImpactedpartSelects, // Object Select
						null, // rel Select
						true, // get To
						false, // get From
						rshort, // recurse level
						ConstantsUtilIRM.CURRENT_RELEASE, // where Clause
						null, // relationshipWhere Clause
						300);//Modified by Ajay for 22x.06 Defect 9458
				int isize = mlMasterBom.size();
				//Modified by Ajay for 22x.06 Defect 9458 - START
				if (isize == 300) {
					bSpecCount = true;
				}
				//Modified by Ajay for 22x.06 Defect 9458 - END
				if(ConstantsUtilIRM.WHERE_USED_PERF_CHAR_SPEC.contains(strType)) {
					relPattern = ConstantsUtilIRM.REFERENCEDOCUMENT;
					typePattern = ConstantsUtil.TYPE__PERFORMANCE_CHAR;
					MapList mlperfBom = doObj.getRelatedObjects(context, 
							relPattern, // Rel Pattern
							typePattern, // Type Pattern
							slImpactedpartSelects, // Object Select
							null, // rel Select
							false, // get To
							true, // get From
							rshort, // recurse level
							ConstantsUtilIRM.CURRENT_DRAFT, // where Clause
							null, // relationshipWhere Clause
							300);//Modified by Ajay for 22x.06 Defect 9458
					int ipersize = mlperfBom.size();
					//Modified by Ajay for 22x.06 Defect 9458 - START
					if (ipersize == 300) {
						bSpecCount = true; 
					}
					//Modified by Ajay for 22x.06 Defect 9458 - END
					mlMasterBom.addAll(mlperfBom);
					DeviceProductPartBO DPPBO = new DeviceProductPartBO();
					mlMasterBom = DPPBO.removeDuplicates(mlMasterBom);
				}
				Iterator objectListItr = mlMasterBom.iterator();
				//boolean bShowDetails = false;
				StringValidatorUtil validator = new StringValidatorUtil();//Added by Ketan for Defect no. 6910
				StringBuilder sbFName=new StringBuilder();
				StringBuilder sbFID = new StringBuilder();
				StringBuilder sbFType = new StringBuilder();
				StringBuilder sbFDisplayType = new StringBuilder();
				StringBuilder sbFTitle = new StringBuilder();
				StringBuilder sbFRev = new StringBuilder();
				
				StringBuilder sbTempName=new StringBuilder();
				StringBuilder sbTempID = new StringBuilder();
				StringBuilder sbTempType = new StringBuilder();
				StringBuilder sbTempDisplayType = new StringBuilder();
				StringBuilder sbTempTitle = new StringBuilder();
				StringBuilder sbTempRev = new StringBuilder();
				
				StringList busSelect = new StringList();
				busSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "id");
				busSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "type");
				busSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "name");
				busSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "revision");
				busSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "current");
				busSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL +ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				//Added by Ketan for Defect no. 6910 -- START
				StringList multiSelect = new StringList();
				multiSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "id");
				multiSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "type");
				multiSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "name");
				multiSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "revision");
				multiSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "current");
				multiSelect.add(ConstantsUtilIRM.EXTENDED_DATA_SEL +ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "id");
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "type");
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "name");
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "revision");
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "current");
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.EXTENDED_DATA_SEL +ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				//Added by Ketan for Defect no. 6910 -- END
				while(objectListItr.hasNext())
				{
					Map objectMap = (Map) objectListItr.next();
					String sType=(String)objectMap.get(DomainConstants.SELECT_TYPE);
					String sID=(String)objectMap.get(DomainConstants.SELECT_ID);
					String sName=(String)objectMap.get(DomainConstants.SELECT_NAME);
					String sRev=(String)objectMap.get(DomainConstants.SELECT_REVISION);
					String sTitle=(String)objectMap.get(DomainConstants.SELECT_ATTRIBUTE_TITLE);
					if(sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR)) {
						DomainObject doPerfObj = new DomainObject(sID);
						Map resultMaps = doPerfObj.getInfo(context, busSelect, multiSelect);//Modified by Ketan
						//Added by Ketan for Defect no. 6910 -- START
						String sPerfType = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "type"));
						String sPerfId = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "id"));
						String sPerfName = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "name"));
						String sPerfRev = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "revision"));
						String sPerfTitle = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL +ConstantsUtil.SELECT_ATTRIBUTE_TITLE));
						String sPerfCurrent = validator.getStringEquivalentForStringListWithComma(resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "current"));

						String[] sPerfTypeArr = sPerfType.split(ConstantsUtilIRM.COMMA_SPACE);
						String[] sPerfIdArr = sPerfId.split(ConstantsUtilIRM.COMMA_SPACE);
						String[] sPerfNameArr = sPerfName.split(ConstantsUtilIRM.COMMA_SPACE);
						String[] sPerfRevArr = sPerfRev.split(ConstantsUtilIRM.COMMA_SPACE);
						String[] sPerfTitleArr = sPerfTitle.split(ConstantsUtilIRM.COMMA_SPACE);
						String[] sPerfCurrentArr = sPerfCurrent.split(ConstantsUtilIRM.COMMA_SPACE);
						
						for(int i=0;i<sPerfTypeArr.length;i++) {
							if(UIUtil.isNotNullAndNotEmpty(sID) && sPerfCurrentArr[i].equals(ConstantsUtil.STATE_RELEASE)){
								mTempImpactedPartDetails = getImpactedPartDetails(context,sPerfIdArr[i],sPerfTypeArr[i],sPerfNameArr[i],sPerfRevArr[i],sPerfTitleArr[i],bSpecCount);
								
								if(!mTempImpactedPartDetails.get(ConstantsUtil.ID).isEmpty()) {
									String sTempId = validator.getStringEquivalentForStringList(mTempImpactedPartDetails.get(ConstantsUtil.ID));
									String sTempType = validator.getStringEquivalentForStringList(mTempImpactedPartDetails.get(ConstantsUtil.TYPE));
									String sTempDisType = validator.getStringEquivalentForStringList(mTempImpactedPartDetails.get(ConstantsUtilIRM.DISPLAY_TYPE));
									String sTempName = validator.getStringEquivalentForStringList(mTempImpactedPartDetails.get(ConstantsUtil.NAME));
									String sTempRev = validator.getStringEquivalentForStringList(mTempImpactedPartDetails.get(ConstantsUtil.REVISION));
									String sTempTitle = validator.getStringEquivalentForStringList(mTempImpactedPartDetails.get(ConstantsUtil.TITLE));
									
									String[] strIdArr = sTempId.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] strTypeArr = sTempType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] strDisplayTypeArr = sTempDisType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] strNameArr = sTempName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] strRevArr = sTempRev.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									String[] strTitleArr = sTempTitle.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
									
									for(int j=0;j<strIdArr.length;j++) {
										if(!sbTempName.toString().contains(strNameArr[j])) {
											util.formatData(sbTempName,strNameArr[j]);
											util.formatData(sbTempID,strIdArr[j]);
											util.formatData(sbTempType,strTypeArr[j]);
											util.formatData(sbTempDisplayType,strDisplayTypeArr[j]);
											util.formatData(sbTempTitle,strTitleArr[j]);
											util.formatData(sbTempRev,strRevArr[j]);
										}
									}
									
									mImpactedPartDetails.put(ConstantsUtil.ID, sbTempID.toString());
									mImpactedPartDetails.put(ConstantsUtil.TYPE,sbTempType.toString());
									mImpactedPartDetails.put(ConstantsUtilIRM.DISPLAY_TYPE,sbTempDisplayType.toString());
									mImpactedPartDetails.put(ConstantsUtil.NAME, sbTempName.toString());
									mImpactedPartDetails.put(ConstantsUtil.REVISION, sbTempRev.toString());
									mImpactedPartDetails.put(ConstantsUtil.TITLE, sbTempTitle.toString());
								}
							}
							//Added by Ketan for Defect no. 6910 -- END
						}
					}
					else {
					mImpactedPartDetails = getImpactedPartDetails(context,sID,sType,sName,sRev,sTitle,bSpecCount);
					}
					String sFId = validator.getStringEquivalentForStringList(mImpactedPartDetails.get(ConstantsUtil.ID));
					String sFType = validator.getStringEquivalentForStringList(mImpactedPartDetails.get(ConstantsUtil.TYPE));
					String sFDisType = validator.getStringEquivalentForStringList(mImpactedPartDetails.get(ConstantsUtilIRM.DISPLAY_TYPE));
					String sFName = validator.getStringEquivalentForStringList(mImpactedPartDetails.get(ConstantsUtil.NAME));
					String sFRev = validator.getStringEquivalentForStringList(mImpactedPartDetails.get(ConstantsUtil.REVISION));
					String sFTitle = validator.getStringEquivalentForStringList(mImpactedPartDetails.get(ConstantsUtil.TITLE));
					
					if(sFId.isEmpty()) {
						continue;
					}
					
					String[] stIdArr = sFId.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] stTypeArr = sFType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] stDisplayTypeArr = sFDisType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] stNameArr = sFName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] stRevArr = sFRev.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] stTitleArr = sFTitle.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					
					for(int k=0;k<stIdArr.length;k++) {
						if(!sbFName.toString().contains(stNameArr[k])) {
							util.formatData(sbFName,stNameArr[k]);
							util.formatData(sbFID,stIdArr[k]);
							util.formatData(sbFType,stTypeArr[k]);
							util.formatData(sbFDisplayType,stDisplayTypeArr[k]);
							util.formatData(sbFTitle,stTitleArr[k]);
							util.formatData(sbFRev,stRevArr[k]);
							}
					}
					
				}
				mFinalImpactedPartDetails.put(ConstantsUtil.ID, sbFID.toString());
				mFinalImpactedPartDetails.put(ConstantsUtil.TYPE,sbFType.toString());
				mFinalImpactedPartDetails.put(ConstantsUtilIRM.DISPLAY_TYPE,sbFDisplayType.toString());
				mFinalImpactedPartDetails.put(ConstantsUtil.NAME, sbFName.toString());
				mFinalImpactedPartDetails.put(ConstantsUtil.REVISION, sbFRev.toString());
				mFinalImpactedPartDetails.put(ConstantsUtil.TITLE, sbFTitle.toString());
				if(bSpecCount){
					String[] sError = ConstantsUtilIRM.E118.split(ConstantsUtil.SYMBL_COLON);
					mFinalImpactedPartDetails.put(ConstantsUtil.ERROR, sError[1].toString());
				}else {
					mFinalImpactedPartDetails.put(ConstantsUtil.ERROR, ConstantsUtil.EMPTY_STRING);
				}
				} catch (Exception ex) {
	      		LOGGER.error("Exception in Program : EBPBO Method :getSpecImpactedPartDetails "+ex);
		 } 
		 return mFinalImpactedPartDetails;
	 }


	//Added by Ketan for Req no. 1589,2180 -- START
	 public Map<String, String> getRelatedPartDetails(Context context, String strSpecId, String strType) throws Exception {

		 DomainObject dobCdoc = new DomainObject(strSpecId);
		 Map<String,String> mapImpactedParts = new HashMap<String, String>();
		 Map<String,String> mpImpactedParts = new HashMap<String, String>();
		 Map<String,String> mapStrImpactedParts = new HashMap<String, String>();
		 StringValidatorUtil validator = new StringValidatorUtil();

		 StringBuilder sbFName=new StringBuilder();
		 StringBuilder sbFID = new StringBuilder();
		 StringBuilder sbFType = new StringBuilder();
		 StringBuilder sbFDisplayType = new StringBuilder();
		 StringBuilder sbFTitle = new StringBuilder();
		 StringBuilder sbFRev = new StringBuilder();

		 StringList busSelect =new StringList();
		 busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_IMPACTEDTYPE);
		 busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_ID);
		 busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_TYPE);
		 busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_NAME);
		 busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_REVISION);
		 busSelect.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_TITLE);
		 StringList multiSel =new StringList();
		 multiSel.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_ID);
		 multiSel.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_TYPE);
		 multiSel.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_NAME);
		 multiSel.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_REVISION);
		 multiSel.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_TITLE);
		 DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_ID);
		 DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_TYPE);
		 DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_NAME);
		 DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_REVISION);
		 DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_TITLE);

		 Map resultMap = dobCdoc.getInfo(context, busSelect, multiSel);

		 String sImpactedType = validator.getStringEquivalentForStringList(resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_IMPACTEDTYPE));
		 String sRelatedPartId = validator.getStringEquivalentForStringListWithComma(resultMap.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_ID));
		 String sRelatedPartType = validator.getStringEquivalentForStringListWithComma(resultMap.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_TYPE));
		 String sRelatedPartName = validator.getStringEquivalentForStringListWithComma(resultMap.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_NAME));
		 String sRelatedPartRev = validator.getStringEquivalentForStringListWithComma(resultMap.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_REVISION));
		 String sRelatedPartTitle = validator.getStringEquivalentForStringListWithComma(resultMap.get(ConstantsUtilIRM.SELECT_RELATIONSHIP_ATS_TO_TITLE));

		 String[] sTypeArr = sRelatedPartType.split(ConstantsUtilIRM.COMMA_SPACE);
		 String[] sIdArr = sRelatedPartId.split(ConstantsUtilIRM.COMMA_SPACE);
		 String[] sNameArr = sRelatedPartName.split(ConstantsUtilIRM.COMMA_SPACE);
		 String[] sRevArr = sRelatedPartRev.split(ConstantsUtilIRM.COMMA_SPACE);
		 String[] sTitleArr = sRelatedPartTitle.split(ConstantsUtilIRM.COMMA_SPACE);

		 for(int i=0;i<sTypeArr.length;i++) {
			 if (ConstantsUtilIRM.STRUCTURED_TYPE.contains(sImpactedType)) {
				 mpImpactedParts = getImpactedPartDetails(context,sIdArr[i],sTypeArr[i],sNameArr[i],sRevArr[i],sTitleArr[i],false);
				 if(!mpImpactedParts.get(ConstantsUtil.ID).isEmpty()) {
					 String strFiID = (String) mpImpactedParts.get(ConstantsUtil.ID);
					 String strFiType = (String) mpImpactedParts.get(ConstantsUtil.TYPE);
					 String strFiDisplayType = (String) mpImpactedParts.get(ConstantsUtilIRM.DISPLAY_TYPE);
					 String strFiName = (String) mpImpactedParts.get(ConstantsUtil.NAME);
					 String strFiRev = (String) mpImpactedParts.get(ConstantsUtil.REVISION);
					 String strFiTitle = (String) mpImpactedParts.get(ConstantsUtil.TITLE);

					 String strFID = strFiID.substring(0, strFiID.length()-1);
					 String strFType = strFiType.substring(0, strFiType.length()-1);
					 String strFDisplayType = strFiDisplayType.substring(0, strFiDisplayType.length()-1);
					 String strFName = strFiName.substring(0, strFiName.length()-1);
					 String strFRev = strFiRev.substring(0, strFiRev.length()-1);
					 String strFTitle = strFiTitle.substring(0, strFiTitle.length()-1);

					 util.formatData(sbFName,strFName);
					 util.formatData(sbFID,strFID);
					 util.formatData(sbFType,strFType);
					 util.formatData(sbFDisplayType,strFDisplayType);
					 util.formatData(sbFTitle,strFTitle);
					 util.formatData(sbFRev,strFRev);

					 mapImpactedParts.put(ConstantsUtil.ID, sbFID.toString());
					 mapImpactedParts.put(ConstantsUtil.TYPE,sbFType.toString());
					 mapImpactedParts.put(ConstantsUtilIRM.DISPLAY_TYPE,sbFDisplayType.toString());
					 mapImpactedParts.put(ConstantsUtil.NAME, sbFName.toString());
					 mapImpactedParts.put(ConstantsUtil.REVISION, sbFRev.toString());
					 mapImpactedParts.put(ConstantsUtil.TITLE, sbFTitle.toString());

				 }
			 }
			 else if(ConstantsUtilIRM.UNSTRUCTURED_TYPE.contains(sImpactedType)) {
				 mpImpactedParts = getImpactedPartForUnstructuredParts(context,sIdArr[i],sTypeArr[i],sNameArr[i],sRevArr[i],sTitleArr[i],false);
				 if(!mpImpactedParts.get(ConstantsUtil.ID).isEmpty()) {
					 String strFiID = (String) mpImpactedParts.get(ConstantsUtil.ID);
					 String strFiTypeBack = (String) mpImpactedParts.get(ConstantsUtilIRM.TYPE_BACKEND);
					 String strFiType = (String) mpImpactedParts.get(ConstantsUtil.TYPE);
					 String strFiDisplayType = (String) mpImpactedParts.get(ConstantsUtilIRM.DISPLAY_TYPE);
					 String strFiName = (String) mpImpactedParts.get(ConstantsUtil.NAME);
					 String strFiRev = (String) mpImpactedParts.get(ConstantsUtil.REVISION);
					 String strFiTitle = (String) mpImpactedParts.get(ConstantsUtil.TITLE);

					 String strFID = strFiID.substring(0, strFiID.length()-1);
					 String strFTypeBack = strFiTypeBack.substring(0, strFiTypeBack.length()-1);
					 String strFType = strFiType.substring(0, strFiType.length()-1);
					 String strFDisplayType = strFiDisplayType.substring(0, strFiDisplayType.length()-1);
					 String strFName = strFiName.substring(0, strFiName.length()-1);
					 String strFRev = strFiRev.substring(0, strFiRev.length()-1);
					 String strFTitle = strFiTitle.substring(0, strFiTitle.length()-1);

					 String[] strIDArr = strFID.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					 String[] strTypeArrBack = strFTypeBack.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					 String[] strTypeArr = strFType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					 String[] strDisTypeArr = strFDisplayType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					 String[] strNameArr = strFName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					 String[] strRevArr = strFRev.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					 String[] strTitleArr = strFTitle.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);

					 for(int j=0;j<strTypeArr.length;j++) {
						 if(ConstantsUtilIRM.UNSTRUCTURED_TYPE.contains(strTypeArrBack[j])) {
							 mapStrImpactedParts = getImpactedPartForUnstructuredParts(context,strIDArr[j],strTypeArr[j],strNameArr[j],strRevArr[j],strTitleArr[j],false);
							 if(!mapStrImpactedParts.isEmpty()) {
								 String strFinID = (String) mapStrImpactedParts.get(ConstantsUtil.ID);
								 String strFinType = (String) mapStrImpactedParts.get(ConstantsUtil.TYPE);
								 String strFinBackType = (String) mapStrImpactedParts.get(ConstantsUtilIRM.TYPE_BACKEND);
								 String strFinDisplayType = (String) mapStrImpactedParts.get(ConstantsUtilIRM.DISPLAY_TYPE);
								 String strFinName = (String) mapStrImpactedParts.get(ConstantsUtil.NAME);
								 String strFinRev = (String) mapStrImpactedParts.get(ConstantsUtil.REVISION);
								 String strFinTitle = (String) mapStrImpactedParts.get(ConstantsUtil.TITLE);

								 String strFinalID = strFinID.substring(0, strFinID.length()-1);
								 String strFinalType = strFinType.substring(0, strFinType.length()-1);
								 String strFinalBackType = strFinBackType.substring(0, strFinBackType.length()-1);
								 String strFinalDisplayType = strFinDisplayType.substring(0, strFinDisplayType.length()-1);
								 String strFinalName = strFinName.substring(0, strFinName.length()-1);
								 String strFinalRev = strFinRev.substring(0, strFinRev.length()-1);
								 String strFinalTitle = strFinTitle.substring(0, strFinTitle.length()-1);
								 
								 String[] stIDArr = strFinalID.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
								 String[] stTypeArrBack = strFinalBackType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
								 String[] stTypeArr = strFinalType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
								 String[] stDisTypeArr = strFinalDisplayType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
								 String[] stNameArr = strFinalName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
								 String[] stRevArr = strFinalRev.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
								 String[] stTitleArr = strFinalTitle.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
								 
								 for(int k=0;k<stTypeArrBack.length;k++) {
									 if(!ConstantsUtilIRM.UNSTRUCTURED_TYPE.contains(stTypeArrBack[k])) {
										 util.formatData(sbFName,stNameArr[k]);
										 util.formatData(sbFID,stIDArr[k]);
										 util.formatData(sbFType,stTypeArr[k]);
										 util.formatData(sbFDisplayType,stDisTypeArr[k]);
										 util.formatData(sbFTitle,stTitleArr[k]);
										 util.formatData(sbFRev,stRevArr[k]);
									 }
								 }
							 }
						 }
						 else {
							 util.formatData(sbFName,strNameArr[j]);
							 util.formatData(sbFID,strIDArr[j]);
							 util.formatData(sbFType,strTypeArr[j]);
							 util.formatData(sbFDisplayType,strDisTypeArr[j]);
							 util.formatData(sbFTitle,strTitleArr[j]);
							 util.formatData(sbFRev,strRevArr[j]);
						 }
					 }

					 mapImpactedParts.put(ConstantsUtil.ID, sbFID.toString());
					 mapImpactedParts.put(ConstantsUtil.TYPE,sbFType.toString());
					 mapImpactedParts.put(ConstantsUtilIRM.DISPLAY_TYPE,sbFDisplayType.toString());
					 mapImpactedParts.put(ConstantsUtil.NAME, sbFName.toString());
					 mapImpactedParts.put(ConstantsUtil.REVISION, sbFRev.toString());
					 mapImpactedParts.put(ConstantsUtil.TITLE, sbFTitle.toString());

				 }
			 }
		 }
		 return mapImpactedParts;
	 }
	//Added by Ketan for Req no. 1589,2180 -- END
	 
	 //Added by Ketan for Defect no. 2541
	 public Map<String, String> getImpactedPartForUnstructuredParts(Context context, String strObjId, String strType, String siName,String siRev, String siTitle, boolean bSpecCount) throws Exception {
		 
		 Map<String,String> mapImpactedParts = new HashMap<String, String>();
		 Map<String,String> mpImpactedParts = new HashMap<String, String>();
		 
		 StringBuilder sbFName=new StringBuilder();
		 StringBuilder sbFID = new StringBuilder();
		 StringBuilder sbFTypeBack = new StringBuilder();
		 StringBuilder sbFType = new StringBuilder();
		 StringBuilder sbFDisplayType = new StringBuilder();
		 StringBuilder sbFTitle = new StringBuilder();
		 StringBuilder sbFRev = new StringBuilder();
		 StringList slUniqueId = new StringList(); //added by ajay for testing

		 StringList slImpactedpartSelects = new StringList();
		 slImpactedpartSelects.add(DomainConstants.SELECT_TYPE);
		 slImpactedpartSelects.add(DomainConstants.SELECT_NAME);
		 slImpactedpartSelects.add(DomainConstants.SELECT_REVISION);
		 slImpactedpartSelects.add(DomainConstants.SELECT_CURRENT);
		 slImpactedpartSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		 slImpactedpartSelects.add(DomainConstants.SELECT_ID);
		 short rshort = (short) 1;
		 
		 try {
			 DomainObject doObj = DomainObject.newInstance(context,strObjId);
			 String relPattern = ConstantsUtil.RELATIONSHIP_PARTSPECIFICATION;
			 String typePattern = ConstantsUtil.SYMBL_ASTERISK;
			 MapList mlMasterBom = doObj.getRelatedObjects(context, 
					 relPattern, // Rel Pattern
					 typePattern, // Type Pattern
					 slImpactedpartSelects, // Object Select
					 null, // rel Select
					 true, // get To
					 false, // get From
					 rshort, // recurse level
					 ConstantsUtilIRM.CURRENT_RELEASE, // where Clause
					 null, // relationshipWhere Clause
					 300);//Modified by Ajay for 22x.06 Defect 9458
			 int isize = mlMasterBom.size();
			//Modified by Ajay for 22x.06 Defect 9458 - START
			 if (isize == 300) {
				 bSpecCount = true;
			 }
			//Modified by Ajay for 22x.06 Defect 9458 - END
			 if(ConstantsUtilIRM.WHERE_USED_PERF_CHAR_SPEC.contains(strType)) {
				 relPattern = ConstantsUtilIRM.REFERENCEDOCUMENT;
				 typePattern = ConstantsUtil.TYPE__PERFORMANCE_CHAR;
				 MapList mlperfBom = doObj.getRelatedObjects(context, 
						 relPattern, // Rel Pattern
						 typePattern, // Type Pattern
						 slImpactedpartSelects, // Object Select
						 null, // rel Select
						 false, // get To
						 true, // get From
						 rshort, // recurse level
						 ConstantsUtilIRM.CURRENT_DRAFT, // where Clause
						 null, // relationshipWhere Clause
						 300);//Modified by Ajay for 22x.06 Defect 9458
				 int ipersize = mlperfBom.size();
				//Modified by Ajay for 22x.06 Defect 9458 - START
				 if (ipersize == 300) { 
					 bSpecCount = true;
				 }
				//Modified by Ajay for 22x.06 Defect 9458 - END
				 mlMasterBom.addAll(mlperfBom);
				 DeviceProductPartBO DPPBO = new DeviceProductPartBO();
				 mlMasterBom = DPPBO.removeDuplicates(mlMasterBom);
			 }
			 Iterator objectListItr = mlMasterBom.iterator();

			 StringList busSelects = new StringList();
			 busSelects.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "id");
			 busSelects.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "type");
			 busSelects.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "name");
			 busSelects.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "revision");
			 busSelects.add(ConstantsUtilIRM.EXTENDED_DATA_SEL + "current");
			 busSelects.add(ConstantsUtilIRM.EXTENDED_DATA_SEL +ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			 while(objectListItr.hasNext())
			 {
				 Map objectMap = (Map) objectListItr.next();
				 String sType=(String)objectMap.get(DomainConstants.SELECT_TYPE);
				 String sID=(String)objectMap.get(DomainConstants.SELECT_ID);
				 String sName=(String)objectMap.get(DomainConstants.SELECT_NAME);
				 String sRev=(String)objectMap.get(DomainConstants.SELECT_REVISION);
				 String sTitle=(String)objectMap.get(DomainConstants.SELECT_ATTRIBUTE_TITLE);
				 String sCurrent =(String)objectMap.get(DomainConstants.SELECT_CURRENT);
				 if(sType.equals(ConstantsUtil.TYPE__PERFORMANCE_CHAR)) {
					 DomainObject doPerfObj = new DomainObject(sID);
					 Map resultMaps = doPerfObj.getInfo(context, busSelects);
					 sType = (String) resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "type");
					 sID = (String) resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "id");
					 sName = (String) resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "name");
					 sRev = (String) resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "revision");
					 sTitle = (String) resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL +ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					 sCurrent = (String) resultMaps.get(ConstantsUtilIRM.EXTENDED_DATA_SEL + "current");
				 }

				 if(ConstantsUtilIRM.MASTER_TYPES.contains(sType)) {
					 if(UIUtil.isNotNullAndNotEmpty(sID) && sCurrent.equals(ConstantsUtil.STATE_RELEASE)){
						 mpImpactedParts = getImpactedPartDetails(context,sID,sType,sName,sRev,sTitle,bSpecCount);
						 if(!mpImpactedParts.get(ConstantsUtil.ID).isEmpty()) {
							 String strFiID = (String) mpImpactedParts.get(ConstantsUtil.ID);
							 String strFiTypeBack = (String) mpImpactedParts.get(ConstantsUtilIRM.TYPE_BACKEND);
							 String strFiType = (String) mpImpactedParts.get(ConstantsUtil.TYPE);
							 String strFiDisplayType = (String) mpImpactedParts.get(ConstantsUtilIRM.DISPLAY_TYPE);
							 String strFiName = (String) mpImpactedParts.get(ConstantsUtil.NAME);
							 String strFiRev = (String) mpImpactedParts.get(ConstantsUtil.REVISION);
							 String strFiTitle = (String) mpImpactedParts.get(ConstantsUtil.TITLE);

							 String strFID = strFiID.substring(0, strFiID.length()-1);
							 String strFTypeBack = strFiTypeBack.substring(0, strFiTypeBack.length()-1);
							 String strFType = strFiType.substring(0, strFiType.length()-1);
							 String strFDisplayType = strFiDisplayType.substring(0, strFiDisplayType.length()-1);
							 String strFName = strFiName.substring(0, strFiName.length()-1);
							 String strFRev = strFiRev.substring(0, strFiRev.length()-1);
							 String strFTitle = strFiTitle.substring(0, strFiTitle.length()-1);

							 util.formatData(sbFName,strFName);
							 util.formatData(sbFID,strFID);
							 util.formatData(sbFTypeBack,strFTypeBack);
							 util.formatData(sbFType,strFType);
							 util.formatData(sbFDisplayType,strFDisplayType);
							 util.formatData(sbFTitle,strFTitle);
							 util.formatData(sbFRev,strFRev);

							 mapImpactedParts.put(ConstantsUtil.ID, sbFID.toString());
							 mapImpactedParts.put(ConstantsUtil.TYPE,sbFType.toString());
							 mapImpactedParts.put(ConstantsUtilIRM.DISPLAY_TYPE,sbFDisplayType.toString());
							 mapImpactedParts.put(ConstantsUtilIRM.TYPE_BACKEND,sbFTypeBack.toString());
							 mapImpactedParts.put(ConstantsUtil.NAME, sbFName.toString());
							 mapImpactedParts.put(ConstantsUtil.REVISION, sbFRev.toString());
							 mapImpactedParts.put(ConstantsUtil.TITLE, sbFTitle.toString());

						 }
					 }
				 }
				 else {
					 if(!(sName.contains(ConstantsUtilIRM.CONST_MEP) || sName.contains(ConstantsUtilIRM.CONST_SEP))) {
						 boolean bShowDetails = false;
						 bShowDetails=util.checkHasAccess(context, null, sID);
						 if(bShowDetails && !slUniqueId.contains(sID)){
							 util.formatData(sbFName,sName);
							 util.formatData(sbFID,sID);
							 util.formatData(sbFTypeBack,sType);
							 String sDisplayType = util.getMappedTypeforMPS(sType);
							 String sFinalType = util.mapType(sType);
							 util.formatData(sbFType,sFinalType);
							 util.formatData(sbFDisplayType,sDisplayType);
							 util.formatData(sbFTitle,sTitle);
							 util.formatData(sbFRev,sRev);
						 }
						 slUniqueId.add(sID); // added by ajay
					 }
					 mapImpactedParts.put(ConstantsUtil.ID, sbFID.toString());
					 mapImpactedParts.put(ConstantsUtil.TYPE,sbFType.toString());
					 mapImpactedParts.put(ConstantsUtilIRM.DISPLAY_TYPE,sbFDisplayType.toString());
					 mapImpactedParts.put(ConstantsUtilIRM.TYPE_BACKEND,sbFTypeBack.toString());
					 mapImpactedParts.put(ConstantsUtil.NAME, sbFName.toString());
					 mapImpactedParts.put(ConstantsUtil.REVISION, sbFRev.toString());
					 mapImpactedParts.put(ConstantsUtil.TITLE, sbFTitle.toString());	
				 }
			 }
		 } catch (Exception ex) {
			 LOGGER.error("Exception in Program : EBPBO Method :getImpactedPartForUnstructuredParts "+ex);
		 } 

	 return mapImpactedParts;	 
	 }


	//Added by Ketan for Req no. 7093,7090 -- START
	public Map<String, String> getImpactedParts(Context context, String sObjectID, String strType) {
		
		Map<String, String> mapImpactedParts = new HashMap<>();
		//Added by Ketan for Defect no. 7612 -- START
		Map<String, String> mapTempImpactedParts = new HashMap<>();
		StringValidatorUtil validator = new StringValidatorUtil();
		//Added by Ketan for Defect no. 7612 -- END
		StringList slImpactedpartSelects = new StringList();
		slImpactedpartSelects.add(DomainConstants.SELECT_TYPE);
		slImpactedpartSelects.add(DomainConstants.SELECT_NAME);
		slImpactedpartSelects.add(DomainConstants.SELECT_REVISION);
		slImpactedpartSelects.add(DomainConstants.SELECT_CURRENT);
		slImpactedpartSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		slImpactedpartSelects.add(DomainConstants.SELECT_ID);
		
		boolean bShowDetails = false;
		StringBuilder sbName=new StringBuilder();
		StringBuilder sbID = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbTypeBack = new StringBuilder();
		StringBuilder sbDisType = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringList slUniqueId = new StringList(); 
		
		try {
			DomainObject doObj = DomainObject.newInstance(context,sObjectID);
			//Modified by Ajay for Req. 10874  -- START
			MapList mlMasterBom = doObj.getRelatedObjects(context, 
					ConstantsUtil.RELATIONSHIP_EBOM + "," + ConstantsUtil.RELATIONSHIP_ALTERNATE, // Rel Pattern
					ConstantsUtil.SYMBL_ASTERISK, // Type Pattern
					slImpactedpartSelects, // Object Select
					null, // rel Select
					true, // get To
					false, // get From
					(short) 1, // recurse level
					ConstantsUtilIRM.CURRENT_RELEASE, // where Clause
					null, // relationshipWhere Clause
					0);
			//Modified by Ajay for Req. 10874  -- END
			//Added by Manikanta for Reg. no. 9601 START
			String	strMQLCommand = "print bus " + sObjectID + " select " + ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_SELECTS + "";
		
			String	strResult = MqlUtil.mqlCommand(context, strMQLCommand);
			String saSubstitute[] = strResult.split("\\r?\\n");
			System.out.println("test :1046"+saSubstitute);
			int intTokens = saSubstitute.length;
			String saEachObj[] = new String[7];
			StringList slCurrent = new StringList();
			StringList slType = new StringList();
			StringList slName = new StringList();
			StringList slRevision = new StringList();
			StringList slId = new StringList();
			StringList slTitle = new StringList();
			
			if(validator.isNotNullOrEmpty(strResult)) {
				for (int i=0;i<intTokens;i++)
				{
					String strTemp = saSubstitute[i];
					if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_CURRENT)) {
							saEachObj = strTemp.split("\\=");
							String sCurrent=saEachObj[1];
							sCurrent=sCurrent.trim();
							slCurrent.add(sCurrent);
					}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_TYPE)) {
							saEachObj = strTemp.split("\\=");
							String sType=saEachObj[1];
							sType=sType.trim();
							slType.add(sType);	
						
					}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_NAME)) {
							saEachObj = strTemp.split("\\=");
							String sName=saEachObj[1];
							sName=sName.trim();
							slName.add(sName);
					}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_REV)) {
							saEachObj = strTemp.split("\\=");
							String sRevision=saEachObj[1];
							sRevision=sRevision.trim();
							slRevision.add(sRevision);
					}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_ID)) {
							saEachObj = strTemp.split("\\=");
							String sId=saEachObj[1];
							sId=sId.trim();
							slId.add(sId);
					}if (strTemp.contains(ConstantsUtilIRM.REL_EBOM_SUBSTITUTE_TITLE)) {
							saEachObj = strTemp.split("\\=");
							String sTitle=saEachObj[1];
							sTitle=sTitle.trim();
							slTitle.add(sTitle);
					}
					
				}
				int iCount=slCurrent.size();
				for(int i=0;i<iCount;i++) {
					String sCurrent= (String)slCurrent.get(i);
					if(sCurrent.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE)) {
						String sType = (String)slType.get(i);
						String sId = (String)slId.get(i);
						String sTitle = (String)slTitle.get(i);
						String sRevision = (String)slRevision.get(i);
						String sName = (String)slName.get(i);
						Map<String,String> mapObj = new HashMap<String, String>();
						mapObj.put(DomainConstants.SELECT_ID, sId);
						mapObj.put(DomainConstants.SELECT_TYPE, sType);
						mapObj.put(DomainConstants.SELECT_CURRENT, sCurrent);
						mapObj.put(DomainConstants.SELECT_ATTRIBUTE_TITLE, sTitle);
						mapObj.put(DomainConstants.SELECT_REVISION, sRevision);
						mapObj.put(DomainConstants.SELECT_NAME, sName);
						mlMasterBom.add(mapObj);
						
					}
					
				}
			}
			
			//Added by Manikanta for Reg. no. 9601 END
			
			
			Iterator objectListItr = mlMasterBom.iterator();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sType=(String)objectMap.get(DomainConstants.SELECT_TYPE);
				String sName=(String)objectMap.get(DomainConstants.SELECT_NAME);
				String sID=(String)objectMap.get(DomainConstants.SELECT_ID);
				String sTitle=(String)objectMap.get(DomainConstants.SELECT_ATTRIBUTE_TITLE);
				String sRev=(String)objectMap.get(DomainConstants.SELECT_REVISION);

				if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_PGINNERPACKUNITPART) || sType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNIT) || sType.equalsIgnoreCase(ConstantsUtil.TYPE_PG_CUSTOMERUNIT) || sType.equalsIgnoreCase(ConstantsUtil.TYPE_PGTRANSPORTUNITPART)) {
					mapTempImpactedParts = getImpactedPartDetails(context,sID,sType,sName,sRev,sTitle,false);
					//Added by Ketan for Defect no. 7612 -- START
					String strId = validator.getStringEquivalentForStringList(mapTempImpactedParts.get(ConstantsUtil.ID));
					String stType = validator.getStringEquivalentForStringList(mapTempImpactedParts.get(ConstantsUtil.TYPE));
					String strDisplayType = validator.getStringEquivalentForStringList(mapTempImpactedParts.get(ConstantsUtilIRM.DISPLAY_TYPE));
					String strName = validator.getStringEquivalentForStringList(mapTempImpactedParts.get(ConstantsUtil.NAME));
					String strRev = validator.getStringEquivalentForStringList(mapTempImpactedParts.get(ConstantsUtil.REVISION));
					String strTitle = validator.getStringEquivalentForStringList(mapTempImpactedParts.get(ConstantsUtil.TITLE));

					String[] strIdArr = strId.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strTypeArr = stType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strDisplayTypeArr = strDisplayType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strNameArr = strName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strRevArr = strRev.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					String[] strTitleArr = strTitle.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					
					for(int i=0;i<strIdArr.length;i++) {
						//SPEC: Added by Ajay for Defect. no. 76024 -- START
						if(!strIdArr[i].isEmpty() && !slUniqueId.contains(strIdArr[i])) {
							util.formatData(sbName,strNameArr[i]);
							util.formatData(sbID,strIdArr[i]);
							util.formatData(sbDisType,strDisplayTypeArr[i]);
							util.formatData(sbTitle,strTitleArr[i]);
							util.formatData(sbRev,strRevArr[i]);
							util.formatData(sbType,strTypeArr[i]);
						}
						slUniqueId.add(strIdArr[i]);
						//SPEC: Added by Ajay for Defect. no. 76024 -- END
					}
					//Added by Ketan for Defect no. 7612 -- END
				} 
				else {
					if(!(sName.contains(ConstantsUtilIRM.CONST_MEP) || sName.contains(ConstantsUtilIRM.CONST_SEP))) {
						bShowDetails=util.checkHasAccess(context, null, sID);
						if(bShowDetails && !slUniqueId.contains(sID)){
							util.formatData(sbName,sName);
							util.formatData(sbID,sID);
							util.formatData(sbTypeBack,sType);
							String sDisplayType = util.getMappedTypeforMPS(sType);
							String sFinalType = util.mapType(sType);
							util.formatData(sbType,sFinalType);
							util.formatData(sbDisType,sDisplayType);
							util.formatData(sbTitle,sTitle);
							util.formatData(sbRev,sRev);
						}
						slUniqueId.add(sID); // added by ajay
					}
				}
			}
			mapImpactedParts.put(ConstantsUtil.ID, sbID.toString());
			mapImpactedParts.put(ConstantsUtil.TYPE,sbType.toString());
			mapImpactedParts.put(ConstantsUtilIRM.DISPLAY_TYPE,sbDisType.toString());
			mapImpactedParts.put(ConstantsUtil.NAME, sbName.toString());
			mapImpactedParts.put(ConstantsUtil.REVISION, sbRev.toString());
			mapImpactedParts.put(ConstantsUtil.TITLE, sbTitle.toString());
			
		} catch (Exception ex) {
      		LOGGER.error("Exception in Program : EBPBO Method :getImpactedPart "+ex);
		}
		
		return mapImpactedParts;
	}
	//Added by Ketan for Req no. 7093,7090 -- END
	//added by ajay for 22x.06 Defect 107252 -- START
	public Map<String, String> getImpactedFPPParts(Context context, String sObjectID, String stType, StringList strUniqueId) {
		Map<String, String> mapImpactedParts = new HashMap<>();
		StringList slImpactedpartSelects = new StringList();
		 slImpactedpartSelects.add(DomainConstants.SELECT_TYPE);
		 slImpactedpartSelects.add(DomainConstants.SELECT_NAME);
		 slImpactedpartSelects.add(DomainConstants.SELECT_REVISION);
		 slImpactedpartSelects.add(DomainConstants.SELECT_CURRENT);
		 slImpactedpartSelects.add(DomainConstants.SELECT_ATTRIBUTE_TITLE);
		 slImpactedpartSelects.add(DomainConstants.SELECT_ID);
		 
		 StringBuilder sbName=new StringBuilder();
		 StringBuilder sbID = new StringBuilder();
		 StringBuilder sbType = new StringBuilder();
		 StringBuilder sbTypeBack = new StringBuilder();
		 StringBuilder sbDisType = new StringBuilder();
		 StringBuilder sbTitle = new StringBuilder();
		 StringBuilder sbRev = new StringBuilder();
		 //StringList strUniqueId= strUniqueId;//added by ajay for 22x.06 Defect 8030
		
		try{
			String relPattern = DomainConstants.EMPTY_STRING;
			String typePattern = ConstantsUtil.SYMBL_ASTERISK;
			boolean bShowDetails = false;
			StringList slImpactedpartRelSelects = new StringList();
			slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.id");
			slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.name");
			slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.type");
			slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.revision");
			slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.current");
			slImpactedpartRelSelects.add("tomid[" + ConstantsUtilIRM.REL_PARTFAMILYREFERENCE + "].fromrel.to.attribute[Title]");
			DomainObject doObj1 = DomainObject.newInstance(context,sObjectID);
			MapList mlMasterBom1 = doObj1.getRelatedObjects(context, 
					ConstantsUtil.RELATIONSHIP_EBOM, // Rel Pattern
					typePattern, // Type Pattern
					slImpactedpartSelects, // Object Select
					slImpactedpartRelSelects, // rel Select
					true, // get To
					false, // get From
					(short)0, // recurse level
					ConstantsUtilIRM.CURRENT_RELEASE_OR_ACTIVE, // where Clause
					null, // relationshipWhere Clause
					0);
			Iterator objectList1Itr = mlMasterBom1.iterator();
			
			while(objectList1Itr.hasNext()) {
				Map objectMap2 = (Map) objectList1Itr.next();
				String sEName = ConstantsUtil.EMPTY_STRING;
				String sEID = ConstantsUtil.EMPTY_STRING;
				String sEType = ConstantsUtil.EMPTY_STRING;
				String sERev = ConstantsUtil.EMPTY_STRING;
				String sECurrent = ConstantsUtil.EMPTY_STRING;
				String sETitle = ConstantsUtil.EMPTY_STRING;
				
				
				sEType=(String)objectMap2.get(DomainConstants.SELECT_TYPE);
				sEName=(String)objectMap2.get(DomainConstants.SELECT_NAME);
				sEID=(String)objectMap2.get(DomainConstants.SELECT_ID);
				sETitle=(String)objectMap2.get(DomainConstants.SELECT_ATTRIBUTE_TITLE);
				sERev=(String)objectMap2.get(DomainConstants.SELECT_REVISION);
				sECurrent=(String)objectMap2.get(DomainConstants.SELECT_CURRENT);
				String [] slEName = sEName.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		        String [] slEId = sEID.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		        String [] slEType = sEType.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		        String [] slERev = sERev.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		        String [] slECurrent = sECurrent.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
		        
		        if (slECurrent.length > -1 && slECurrent.length <= 20) {
					for (int i = 0; i < slECurrent.length; i++) {
						if (null != slECurrent[i]) {
							String strCurrent = slECurrent[i].toString().trim();
							String strName = slEName[i].toString().trim();
							String strId = slEId[i].toString().trim();
							String srType = slEType[i].toString().trim();
							String strRev = slERev[i].toString().trim();
							String strTitle = DomainConstants.EMPTY_STRING;
							if (strCurrent.equals(ConstantsUtil.STATE_RELEASE)) {
								if(srType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
									if(UIUtil.isNotNullAndNotEmpty(strId)) {
										bShowDetails=util.checkHasAccess(context, null, strId);
										if(bShowDetails && !strUniqueId.contains(strId)){
											util.formatData(sbName,strName);
											util.formatData(sbID,strId);
											util.formatData(sbTypeBack,srType);
											String sDisplayType = util.getMappedTypeforMPS(srType);
											String sFinalType = util.mapType(srType);
											util.formatData(sbType,sFinalType);
											util.formatData(sbDisType,sDisplayType);
											DomainObject dObject = DomainObject.newInstance(context, strId);
											strTitle = dObject.getInfo(context, DomainConstants.SELECT_ATTRIBUTE_TITLE);
											util.formatData(sbTitle,strTitle);
											util.formatData(sbRev,strRev);
										}
										strUniqueId.add(strId);//added by ajay for 22x.06 Defect 8030
									}
									
								}
							}
						}
					}
				}
			}
			mapImpactedParts.put(ConstantsUtil.ID, sbID.toString());
			mapImpactedParts.put(ConstantsUtil.TYPE,sbType.toString());
			mapImpactedParts.put(ConstantsUtilIRM.DISPLAY_TYPE,sbDisType.toString());
			mapImpactedParts.put(ConstantsUtil.NAME, sbName.toString());
			mapImpactedParts.put(ConstantsUtil.REVISION, sbRev.toString());
			mapImpactedParts.put(ConstantsUtil.TITLE, sbTitle.toString());
		
			
		
		} catch (Exception ex) {
      		LOGGER.error("Exception in Program : EBPBO Method :getImpactedFPPParts "+ex);
		}
		return mapImpactedParts;
	}//added by ajay for 22x.06 Defect 107252 -- END
}
