package com.pg.us.specanywhere_enovia.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.DeviceProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.FormulaPartBO;
import com.pg.us.specanywhere_enovia.bo.IRMSBO;
import com.pg.us.specanywhere_enovia.bo.MPPBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusExtractUtil;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class DeviceProductPartService {
	private static Logger LOGGER = Logger.getLogger(DeviceProductPartService.class);

	public static void main(String[] args) throws Exception {
		StopWatch sp = new StopWatch();
		sp.start();


		String objId = "20336.41905.47675.5222";

		EnoviaConnectionPool pool = new EnoviaConnectionPool(ConstantsUtil.USER_NAME,ConstantsUtil.USER_PASS,ConstantsUtil.USER_VAULT);
		Context context = pool.checkOut();

		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();

		boolean bAllInfoView = true;
		boolean bSupplierView = false;
		boolean bManufacturerView = false;


		/*// * User Profile
		 //* 
		SecurityService sct = new SecurityService();
		String sUserType = sct.getUserType();
		if(UIUtil.isNullOrEmpty(sUserType)) {
			LOGGER.info("Error in Log-In User Profile");
		}*/


		/*switch (sUserType) {
		case ConstantsUtil.PG:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PGSTAFF:
			bAllInfoView = true;
			break;

		case ConstantsUtil.PG_CM:
			bManufacturerView = true;
			break;

		case ConstantsUtil.PG_SP:
			bSupplierView = true;
			break;
		}*/

		Map<String,String> mpAttribResult = new HashMap<String,String>();
		Map<String,String> mpHeaderContent = new HashMap<String,String>();
		Map<String,String> mpOrganization = new HashMap<String,String>();
		Map<String,String> mpDangerousGoodsClf = new HashMap<String,String>();
		Map<String,String> mpGlobalHarStandard = new HashMap<String,String>();
		Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
		Map<String,String> mpStability = new HashMap<String,String>();
		Map<String,String> mpNotes = new HashMap<String,String>();
		Map<String,String> mapMaterialResult = new HashMap<String,String>();
		Map<String,String> mpEBOMResult = new HashMap<String,String>();
		Map<String,String> mpSubstitute = new HashMap<String,String>();
		Map<String,String> mpPerformChar = new HashMap<String,String>();
		Map<String,String> mpWeightResult = new HashMap<String,String>();
		Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
		Map<String,String> mapCountryClearanceResult = new HashMap<String,String>();
		Map<String,String> mapCertifications = new HashMap<String,String>();
		Map<String,String> mpPlantResult = new HashMap<String,String>();
		Map<String,String> mapReferenceDocs = new HashMap<String, String>();
		Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
		Map<String,String> mpDerivedToResult = new HashMap<String,String>();
		Map<String,String> mpMaterialProduced = new HashMap<String,String>();
		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
		Map<String,String> mpSecurity = new HashMap<String,String>();
		Map<String,String> mpMEPResult = new HashMap<String,String>();
		Map<String,String> mpSEPResult = new HashMap<String,String>();
		Map<String,String> mpRelatedATS = new HashMap<String,String>();
		Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
		Map<String,String> mpMasterSpecs = new HashMap<String,String>();
		Map<String,String> mpMasterAttribute = new HashMap<String,String>();

		DeviceProductPartBO DPPBO = new DeviceProductPartBO();
		FabricatedPartBO fabBo = new FabricatedPartBO();
		MPPBO mppbo = new MPPBO();
		MasterCOPBO mcop = new MasterCOPBO();
		BusObjectAttribUtil BbUtil = new BusObjectAttribUtil();
		Map<String, StringList> BusinessObjectSelectableMap = DPPBO.getDPPPartSelectables(context);
		Map<String, StringList> ChilsObjectSelectableMap = DPPBO.getDPPRelatedObjsSelectableMap(context);
		StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
		StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		DomainObject doDPP =  DPPBO.getDPPDO(context, objId);

		/*if (null == doDPP) {
			HashMap<String,String> errorMap = new HashMap<String,String>();
			String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
			errorMap.put(sError[0], sError[1]);
			hmAttrib.put(ConstantsUtil.ERROR, errorMap);
			LOGGER.info("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
			return hmAttrib;
		}*/
		DPPBO.addMultiList();
		StopWatch swAttributes = new StopWatch();
		swAttributes.start();
		Map resultMaps = doDPP.getInfo(context, slContextSelects);
		swAttributes.stop();
		LOGGER.info("DPP GETINFO ELAPSED TIME : "+swAttributes.getTime());
		DPPBO.removeMultiValueList();

		boolean bGendocView=false;
		//boolean bAuthorizedtoUse = BbUtil.getAuthorizedtoUse(context,doDPP,resultMaps);
		boolean bAuthorizedtoUse = true;

		boolean bHIRComplaint = BbUtil.getHIRComplaintForSupplier(context,doDPP,resultMaps);

		if((bManufacturerView && !bAuthorizedtoUse) || ((bSupplierView && bHIRComplaint))) {
			bGendocView = true;
		}

		String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;

		//Common usage Variables
		String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
		String sType = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;

		
		if (bGendocView || bAllInfoView ){
			StopWatch swBom = new StopWatch();
			swBom.start();
			MapList mapList = doDPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.SYMBL_ASTERISK, slChildBusSelects , slChildRelSelects, false, true, (short)1,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);

			if ((bManufacturerView) || (bSupplierView && bHIRComplaint) ){
				mapList=BbUtil.filterPhase(mapList);
			}
			
			if(mapList.size()!=0){
				mpEBOMResult =	DPPBO.parseMaplist(context,mapList,bSupplierView);//Modified by Ketan for Req. no. 46464
				mpSubstitute =  DPPBO.getSubstitute(context,mapList);
			}

			swBom.stop();
			LOGGER.info("DPP  BOM ELAPSED TIME : "+swBom.getTime());
		}
		
		if(bAllInfoView || bManufacturerView || bGendocView) {

			/**
			 * LOAD BASIC ATTRIBUTES SECTION
			 * */
			mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRODUCTCERTIFICATIONORLOCALSTANDARDSCOMPLIANCESTATEMENTREQUIRED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PRODUCTDOSEPERUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTDOSEPERUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPECTEDFREQUENCYOFUSEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPECTEDFREQUENCYOFUSEUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MODEOFPRODUCTDISPOSAL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMODEOFPRODUCTDISPOSAL) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRAND) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PROD_VARIANNT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXTRAVARIANT) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDENSITYUOM) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ONSHELFPRODDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGONSHELFPRODUCTDENSITY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.INTENDED_MARKET, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.REPLACE_PROD_ID, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGREPLACEDBYPRODUCTID) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.UNIQUE_FORMULA_IDENTIFIER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNIQUEFORUMULAIDENTIFIER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.DOESTHISDEVICECONTAINFLAMMABLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESDEVICECONTAINFLAMMABLELIQUID)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESDEVICECONTAINFLAMMABLELIQUID) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
			String sClassifictaion = util.getClassification(resultMaps);
			mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));

			/**
			 * LOAD HEADER CONTENT SECTION
			 * */
			mpHeaderContent.put(ConstantsUtil.TYPE,BbUtil.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpHeaderContent.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
			mpHeaderContent.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING); 
			mpHeaderContent.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);

			if(!bManufacturerView && !bSupplierView){
				mpHeaderContent.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
			}

			mpHeaderContent.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpHeaderContent.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
			mpHeaderContent.put(ConstantsUtil.PDF_VIEW, util.getPdfViewtype(bAllInfoView, bGendocView, bSupplierView));

			/**
			 * LOAD DANGEROUS GOODS CLASSIFICATION SECTION
			 * */

			/*mpDangerousGoodsClf.put(ConstantsUtil.ID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ID))));
			mpDangerousGoodsClf.put(ConstantsUtil.PPN, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_NAME))));
			mpDangerousGoodsClf.put(ConstantsUtil.PPR, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_REVISION))));
			mpDangerousGoodsClf.put(ConstantsUtil.PPT, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_TITLE))));
			 */
			mpDangerousGoodsClf=util.getDangerousProdcutValue(context,resultMaps);
			mpDangerousGoodsClf.put(ConstantsUtil.DGD, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.UNN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_UNNUMBER) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.PSN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PSN) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.HC, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_HC) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.PGGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGGROUP) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.SHIPPINGQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_SHIPMENTQTY) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.CON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CON) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.OPR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_CUST) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.UNSPECPACKGGREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_PGMAXCONSUMERUNITSIZE) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.CUST, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_OPR) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.SDGCUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCUP) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.SDGCOP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_DGCOP) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			mpDangerousGoodsClf.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGDANGEROUSGOODS_ORGN_SOURCE) : ConstantsUtil.EMPTY_STRING);

			if(bManufacturerView || bGendocView) {

				mpDangerousGoodsClf=BbUtil.filterPhase(mpDangerousGoodsClf);
			}

			/**
			 * LOAD GLOBAL HARMONIZED STANDARD SECTION
			 * */
			//mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			//mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTREVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
			//mpGlobalHarStandard.put(ConstantsUtil.PRODUCTPARTTITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard = util.getGHSProdcutValue(context,resultMaps);
			mpGlobalHarStandard.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_NAME) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_CURRENT) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.MARKETS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS) : ConstantsUtil.EMPTY_STRING);
			mpGlobalHarStandard.put(ConstantsUtil.LANGUAGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_LANGUAGE) : ConstantsUtil.EMPTY_STRING);
			if(bManufacturerView || bGendocView) {
				mpGlobalHarStandard=BbUtil.filterPhase(mpGlobalHarStandard);
			}


			/**
			 * LOAD STORAGE AND LABEL SECTION
			 * */
			mapStorageAndLabelResult.put(ConstantsUtil.STR_TECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.POWERSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.BATTERYWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHT) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.BATTERYWEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTUOM) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.BATTERYCHEMICALCOMPOSITION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYCHEMISTRY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYCHEMISTRY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.BATTERYLITHUM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYLITHUM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYLITHUM) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.BATTERYLITHUMUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTLIUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYWEIGHTLIUOM) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYENERGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYWHRATING)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYWHRATING) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYENERGYUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYENRUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYENRUOM) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYVOLTAGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYVOLTAGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYVOLTAGE) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.LITHUMBATTERYVOLTAGEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYVOLUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYVOLUOM) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.BATTERYSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYSIZE) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.ISABUTTON, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLYESNO)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLYESNO) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.NUMBEROFCELLS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCELLS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCELLS) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.TYPICALCAPACITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCAPACITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLIBATTERYCAPACITY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.TYPICALCAPACITYUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYTCUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPLBATTERYTCUOM) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.ISTHEPRODUCTABATTERY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTHEPRODUCTABATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISTHEPRODUCTABATTERY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.DOESTHEPRODUCTCONTAINBATTERY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTCONTAINABATTERY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTCONTAINABATTERY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.NUMBEROFCELLSSHIPPEDINSIDEDEVICE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDINSIDEDEVICE) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.NUMBEROFCELLSSHIPPEDOUTSIDEDEVICE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDOUTSIDEDEVICE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERIESSHIPPEDOUTSIDEDEVICE) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.AREBATTERIESREQUIRED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAREBATTERIESREQUIRED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGAREBATTERIESREQUIRED) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTMARKETEDASCHILDRENSPRODUCT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.DOESTHEPRODUCTREQUIRECHILDSAFEDESIGN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);        
			mapStorageAndLabelResult.put(ConstantsUtil.WAREHOUSECLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTEXPOSEDTOCHILDREN, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.EVAPORATIONRATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEVAPORATIONRATE) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.RESERVEACIDITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVEACIDITY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.RESERVEALKALLNITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGRESERVERALKALINITY) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGHAZARDCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
			mapStorageAndLabelResult.put(ConstantsUtil.INTENDEDMARKETS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGINTENDEDMARKETS) : ConstantsUtil.EMPTY_STRING);

			/**
			 * LOAD STABILITY SECTION
			 * */
			/*mpStability.put(ConstantsUtil.MASTERPRODUCTPARTNAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_NAME) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.MASTERPRODUCTPARTREV,  (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_REVISION) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.MASTERPRODUCTPARTTITLE,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TITLE) : ConstantsUtil.EMPTY_STRING);
			 */
			mpStability =util.getWeightProdcutValue(context,resultMaps);

			mpStability.put(ConstantsUtil.PRODUCTEXPDATEREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_PRODUCTEXPDATE)) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.TOTALSHELFLIFEDAYS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TOTALSHELFLIFEDAYS) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.TEMPERATUREGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABILITYTOTEMPGRP_TEMPGRP) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.HUMIDITYGROUP, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGSTABIILITYTOHUMIDITYGRP_HMGRP) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.TRANSPORTFREEZEPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSFREEZEPROTECTION) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.TRANSPORTHEATPROTECTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_TRANSHEATPROTECTION) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.BOUNDARYCONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS)))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_BOUNDARYCONDITIONS) : ConstantsUtil.EMPTY_STRING);
			mpStability.put(ConstantsUtil.STABILITYREPORTLINK, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);

			/**
			 * LOAD NOTES SECTION
			 * */
			mpNotes=mcop.updateNotes(context, resultMaps);

			/**
			 * LOAD PERFORMANCE CHAR SECTION
			 * */
			Map paramMap = new HashMap();
			paramMap.put(ConstantsUtil.OBJECT_ID, objId);
			paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
			paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
			paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

			PerformanceCharcteristics perform = new PerformanceCharcteristics();
			StopWatch swPerfChar = new StopWatch();
			swPerfChar.start();
			MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
			if(!mlPerformChar.isEmpty())
			{
				FinishedProductPartBO fppBO = new FinishedProductPartBO();
				MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
				//mpPerformChar =BbUtil.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
			}
			swPerfChar.stop();
			LOGGER.info("DPP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

			/**
			 * LOAD WEIGHT CHAR SECTION
			 * */
			mpWeightResult.put(ConstantsUtil.TYPE, BbUtil.mapType(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
			mpWeightResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
			mpWeightResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENTS) : ConstantsUtil.EMPTY_STRING);

			/**
			 * LOAD MATERIALS PRODUCED SECTION
			 * */
			StopWatch swMaterial = new StopWatch();
			swMaterial.start();
			mpMaterialProduced = DPPBO.getMaterialProduced(context,sContextObjectId);
			if(bManufacturerView || bGendocView) {
				mpMaterialProduced=BbUtil.filterPhase(mpMaterialProduced);
			}
			mpMaterialProduced = BbUtil.filterMapList(mpMaterialProduced);
			swMaterial.stop();
			LOGGER.info("DPP MATERIALS ELAPSED TIME : "+swMaterial.getTime());

			/**
			 * LOAD RELATED ATS SECTION
			 * */

			StopWatch swAts = new StopWatch();
			swAts.start();
			mpRelatedATS.put(ConstantsUtil.ATS_NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_NAME)))?(String)resultMaps.get(ConstantsUtil.ATL_NAME) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_TYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TYPE)))?(String)resultMaps.get(ConstantsUtil.ATL_TYPE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_TITLE)))?(String)resultMaps.get(ConstantsUtil.ATL_TITLE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.ATS_STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_STATE)))?(String)resultMaps.get(ConstantsUtil.ATL_STATE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_STATE)))?(String)resultMaps.get(ConstantsUtil.ATL_STATE) : ConstantsUtil.EMPTY_STRING);
			mpRelatedATS.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.ATL_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.ATL_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);

			if(bManufacturerView || bGendocView) {
				mpRelatedATS=BbUtil.filterPhase(mpRelatedATS);
			}
			mpRelatedATS = BbUtil.filterMapList(mpRelatedATS);
			swAts.stop();
			LOGGER.info("DPP ATS ELAPSED TIME : "+swAts.getTime());

			/**
			 * LOAD RELATED SPEC SECTION
			 * */
			StopWatch swRelatedSpec = new StopWatch();
			swRelatedSpec.start();
			mpRelatedSpecResult = BbUtil.updatePartSpec(context, resultMaps);
			swRelatedSpec.stop();
			LOGGER.info("DPP  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());

			/**
			 * MASTER SPECIFICATION
			 * */
			StopWatch swmpMasterSpecs = new StopWatch();
			swmpMasterSpecs.start();
			mpMasterSpecs = BbUtil.getMasterSpecs(context,sContextObjectId);
			//mpMasterSpecs = BbUtil.filterMapList(mpMasterSpecs);
			swmpMasterSpecs.stop();
			LOGGER.info("DPP MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());

			/**
			 * LOAD REFERENCE DOCS SECTION
			 * */
			StopWatch swReference= new StopWatch();
			swReference.start();
			//mapReferenceDocs = mcop.updateRefDocs(context, resultMaps);
			mapReferenceDocs = BbUtil.filterMapList(mapReferenceDocs);
			swReference.stop();
			LOGGER.info("DPP  REFERENCE DOCS ELAPSED TIME : "+swReference.getTime());


			/**
			 * LOAD MASTER ATTRIBUTES DATA 
			 * */
			StopWatch swMaster = new StopWatch();
			swMaster.start();
			String sMasterID= (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID))?(String)resultMaps.get(ConstantsUtil.STR_CLASSI_REFERENCE_ID) : ConstantsUtil.EMPTY_STRING);
			if(validator.isNotNullOrEmpty(sMasterID)){
				FabricatedPartBO FABBO = new FabricatedPartBO();
				mpMasterAttribute = FABBO.getMasterAttributeData(context,sMasterID);
				if(bManufacturerView || (bSupplierView && bHIRComplaint)) {
					mpMasterAttribute=BbUtil.filterPhase(mpMasterAttribute);
				}
				mpMasterAttribute = BbUtil.filterMapList(mpMasterAttribute);

			}
			swMaster.stop();
			LOGGER.info("DPP GET MASTER ATTRIB ELAPSED TIME : "+swMaster.getTime());
		}

		if(bAllInfoView) {
			/**
			 * LOAD BASIC ATTRIBUTES SECTION
			 * */
			mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMaps.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
			mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);

			/**
			 * LOAD ORGANIZATION DATA SECTION
			 * */
			mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
			mpOrganization = BbUtil.filterMapList(mpOrganization);

			/**
			 * LOAD PLANTS SECTION
			 * */
			StopWatch swPlant = new StopWatch();
			swPlant.start();
			mpPlantResult=fabBo.updatePlantInfo(resultMaps);
			swPlant.stop();
			LOGGER.info("DPP PLANTS ELAPSED TIME : "+swPlant.getTime());


			/**
			 * LOAD MATERIAL RESULTS SECTION
			 * */
			StopWatch swMaterial = new StopWatch();
			swMaterial.start();
			//mapMaterialResult = DPPBO.getSubstances(resultMaps,strContext);
			//mapMaterialResult =util.verifyOwnership(context,mapMaterialResult);
			swMaterial.stop();
			LOGGER.info("DPP MATERIAL ELAPSED TIME : "+swMaterial.getTime());

			/**
			 * LOAD CERTIFICATIONS SECTION
			 * */
			mapCertifications.put(ConstantsUtil.CERTIFICATIONCLAIM,(validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REL_MATERIAL_CERTIFICATIONS_CERTIFICATIONCLAIM)))?(String)resultMaps.get(ConstantsUtil.SELECT_REL_MATERIAL_CERTIFICATIONS_CERTIFICATIONCLAIM) : ConstantsUtil.EMPTY_STRING);
			mapCertifications.put(ConstantsUtil.MARKETS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS)))?(String)resultMaps.get(ConstantsUtil.STR_RELATIONSHIP_PGGLOBALHARMONIZEDSTANDARD_MARKETS) : ConstantsUtil.EMPTY_STRING);
			mapCertifications = BbUtil.filterMapList(mapCertifications);


			/**
			 * LOAD SAP BOM as FED SECTION
			 * */
			StopWatch swSapBomAsFed = new StopWatch();
			swSapBomAsFed.start();
			CalculateBOM clBom = new CalculateBOM();
			mpSapBomAsFedcResult = clBom.getSapBOMasFed(context,sContextObjectId);
			swSapBomAsFed.stop();
			LOGGER.info("DPP GET SAPBO AS FED ELAPSED TIME : "+swSapBomAsFed.getTime());

			/**
			 * LOAD MARKET CLEARANCE
			 * */
			StopWatch swcountry = new StopWatch();
			swcountry.start();
			mapCountryClearanceResult = DPPBO.getCountryClearanceResult(context,sContextObjectId);
			mapCountryClearanceResult = BbUtil.filterMapList(mapCountryClearanceResult);
			swcountry.stop();
			LOGGER.info("DPP MARKET CLEARANCE TIME : "+swcountry.getTime());


			/**
			 * LOAD DERIVED DATA(RELATED PARTS) SECTION
			 * */
			StopWatch swDerived = new StopWatch();
			swDerived.start();
			IRMSBO irmsbo = new IRMSBO();
			String sDName = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
			String sRev = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
			String sCreatedDate = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING;

			mpDerivedFromResult = irmsbo.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doDPP,true,false);
			mpDerivedToResult = irmsbo.updateDerivedDataInfo(context,sDName, sRev,sType,sContextObjectId, sCreatedDate, doDPP,false,true);

			mpDerivedFromResult = BbUtil.filterMapList(mpDerivedFromResult);
			mpDerivedToResult = BbUtil.filterMapList(mpDerivedToResult);
			swDerived.stop();
			LOGGER.info("DPP  Derived ELAPSED TIME : "+swDerived.getTime());

			/**
			 * LOAD LIFECYCLE SECTION
			 * */
			String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
			String[] changeargs={objId,sPhysicalId};
			StopWatch swLifecycle = new StopWatch();
			swLifecycle.start();
			mpLifeCycleApproval = BbUtil.getCOName(context, changeargs);
			swLifecycle.stop();
			LOGGER.info("DPP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());

			/**
			 * LOAD OWNERSHIP SECTION
			 * */
			mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty(lastUpdatedUser))?lastUpdatedUser : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
			mapOwnerShipResult = BbUtil.filterMapList(mapOwnerShipResult);

			/**
			 * LOAD SECURITY SECTION
			 * */
			StopWatch swSecurity = new StopWatch();
			CommonBusUtilBO bo = new CommonBusUtilBO();
			swSecurity.start();
			mpSecurity =bo.updateSecurity(context,resultMaps);;
			swSecurity.stop();
			LOGGER.info("DPP  Security ELAPSED TIME : "+swSecurity.getTime());

			/**
			 * This Method is for getting the MEPS
			 * @param context
			 * @param Relationship
			 * @param objectMap
			 * @param bMEP
			 * @return
			 * @throws Exception
			 */

			BusExtractUtil busExtct = new BusExtractUtil();
			mpMEPResult = busExtct.getEquivalents(context, resultMaps, true, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT);

			/**
			 * This Method is for getting the SEPS 
			 * @param context
			 * @param Relationship
			 * @param objectMap
			 * @param bSEP
			 * @return
			 * @throws Exception
			 */

			mpSEPResult = busExtct.getEquivalents(context, resultMaps, false, ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT);
		}
		/**
		 * LOAD BOM SECTION
		 * 
		 *if the user is CM and Plant AuthoriseToUse true he should not have access to BOM - 33221*/
		


		if(bGendocView || bAllInfoView) {
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
		}

		if(!bGendocView || bAllInfoView) {
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			hmAttrib.put(ConstantsUtil.MASTERATTRIBUTES, mpMasterAttribute);
		}

		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
		hmAttrib.put(ConstantsUtil.GLABALHARMONIZEDSTANDARD, mpGlobalHarStandard);
		hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATA, mapStorageAndLabelResult);
		hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mpWeightResult);
		hmAttrib.put(ConstantsUtil.MATERIALPRODUCED, mpMaterialProduced);
		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderContent);
		hmAttrib.put(ConstantsUtil.STABILITYRESULTS, mpStability);
		hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);

		if(bAllInfoView) {
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
			hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult);
			hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
			hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO,mpDerivedToResult);
			hmAttrib.put(ConstantsUtil.MARKETOFCLEARANCE, mapCountryClearanceResult);
			hmAttrib.put(ConstantsUtil.CERTIFICATIONS, mapCertifications);
			hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			hmAttrib.put(ConstantsUtil.MATERIALS, mapMaterialResult);
			hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
			hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			hmAttrib.put(ConstantsUtil.DANGEROUSGOODCLASSIFICATION, mpDangerousGoodsClf);


			sp.stop();
			System.out.println("Execution TIME::" + sp.getTime());
			System.out.println("RESULT:: \n" + mapMaterialResult);

		}// main method
		
		//Subhajit Added for Memory Leakage Analysis - Start
		context.close();
		//Subhajit Added for Memory Leakage Analysis - End
	}
}//End of Class
