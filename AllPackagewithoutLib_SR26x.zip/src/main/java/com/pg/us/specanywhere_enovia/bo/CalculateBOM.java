package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Stack;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.Pattern;
import matrix.util.StringList;

public class CalculateBOM {

	private static Logger LOGGER = Logger.getLogger(CalculateBOM.class);

	StringValidatorUtil BusinessUtil= new StringValidatorUtil();
	public static final StringList SL_OBJECT_INFO_SELECT 			= 	getObjectSelects();
	public static final StringList SL_RELATION_INFO_SELECT_EBOM		=	getRelationshipSelectsEBOM();
	public static final StringList SL_RELATION_INFO_SELECT_OTHERS	=	getRelationshipSelectsOthers();
	public static final StringList SL_FOP_OBJECT_INFO_SELECT 		= 	getFOPObjectSelects();
	private boolean bExecuteRFC 									= 	true;
	private boolean bSitesListActive 								= 	false;
	private String strDesignatedSites 								= 	DomainConstants.EMPTY_STRING;
	private static String strSuccess				 						= 	"BOM Successfully Processed";
	public static final String PATTERN_DECIMALFORMAT = "##.###";

	public static final String SELECT_SUBSTITUTE_OPT_COMPONENT = "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].attribute[pgOptionalComponent]";
	public static final int OPT_COMPONENT = 24;
	public static final int BOM_ARRAY_SIZE = 26;
	public static final int COMMENT = 25;
	public static final int OBJECT_ID = 22;
	public static final int DISPLAY_OBJECT_ID = 23;
	public static final String PGPHASE_EXPAND_TYPES = "pgFinishedProduct,pgFormulatedProduct,pgRawMaterial,pgPackingMaterial,pgPackingSubassembly";

	public String strParentRev = "";
	public ArrayList alBOMFC = new ArrayList();
	public String _AbortReason = "";
	public String _ParentMatlNumber = "";
	private boolean bCreatingSubsRows = false;
	private String strSubsDispId = "";

	public String strFirstlevelObjId = "";
	public String strFirstlevelObjIdCopy = "";
	HashMap hmParentObjects = new HashMap();
	HashMap hmChildObjects = new HashMap();
	int iChildObjCount =0;
	private String strParentBUOM = DomainConstants.EMPTY_STRING;
	private String strParentType = DomainConstants.EMPTY_STRING;

	public String strAlternateAllowedTypes = ConstantsUtil.TYPE_RAWMATERIALPART+","+ConstantsUtil.TYPE_PGRAWMATERIAL+","+ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART;


	public synchronized boolean doProdUsageCheckForeDelivery(Context context,Map mapPartDetails) throws Exception {

		boolean bProdStage3 = false;
		String strStage		= DomainConstants.EMPTY_STRING;
		String strStatus	= DomainConstants.EMPTY_STRING;
		try {

			if(null != mapPartDetails && mapPartDetails.size()>0) {
				strStatus = (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
				strStage = (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);

				if(BusinessUtil.isNotNullOrEmpty(strStatus) && !"Unknown".equalsIgnoreCase(strStatus) && !ConstantsUtil.RANGE_ATTRIBUTE_STATUS_PLANNING.equalsIgnoreCase(strStatus) && !ConstantsUtil.RANGE_ATTRIBUTE_PGBOMBASEQUANTITY_EXPERIMENTAL.equalsIgnoreCase(strStatus) ) {

					bProdStage3 = true;
				}

				if(!bProdStage3 && BusinessUtil.isNotNullOrEmpty(strStage) && !ConstantsUtil.RANGE_ATTRIBUTE_STATUS_PLANNING.equalsIgnoreCase(strStage) && !ConstantsUtil.RANGE_ATTRIBUTE_PGBOMBASEQUANTITY_EXPERIMENTAL.equalsIgnoreCase(strStage) ) {

					bProdStage3 = true;
				}
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return bProdStage3;
	}


	public synchronized ArrayList performDataReadFromEnovia(Context context,String[] args) throws Exception{

		return performDataReadFromEnovia(context, args[0]);

	}


	public synchronized ArrayList performDataReadFromEnovia(Context context,String sPartObjectID) throws Exception {

		Map 	mapPartDetails				= new HashMap();

		ArrayList alPartRelatedObjects 		= new ArrayList();
		String strSpecSubType = DomainConstants.EMPTY_STRING;
		String strFormulationType = DomainConstants.EMPTY_STRING;

		try {

			if(BusinessUtil.isNotNullOrEmpty(sPartObjectID)){

				DomainObject doPart = DomainObject.newInstance(context,sPartObjectID);
				StringList slBusSelect = new StringList(12);
				slBusSelect.add(DomainConstants.SELECT_TYPE);
				slBusSelect.add(DomainConstants.SELECT_NAME);
				slBusSelect.add(DomainConstants.SELECT_ID);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				slBusSelect.add(ConstantsUtil.STR_IPCLASS);

				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
				slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
				slBusSelect.add("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
				slBusSelect.add("next.id");
				mapPartDetails = doPart.getInfo(context, slBusSelect);

				if(null != mapPartDetails && mapPartDetails.size()>0) {

					strSpecSubType = (String) mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
					Object OFormulationType = (Object)mapPartDetails.get("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);

					StringList slFormulationType = new StringList();

					if (null != OFormulationType) {
						if (OFormulationType instanceof StringList) {
							slFormulationType = (StringList) OFormulationType;
						} else if (OFormulationType instanceof String) {
							slFormulationType.add(OFormulationType.toString());
						}
					}								
					if(doProdUsageCheckForeDelivery(context,mapPartDetails)) {

						String strPartType	=	(String)mapPartDetails.get(DomainConstants.SELECT_TYPE);

						if(BusinessUtil.isNotNullOrEmpty(strPartType)) {

							if(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGFINISHEDPRODUCT.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equalsIgnoreCase(strPartType)) {

								alPartRelatedObjects = getPartObjectsFromEBOM(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_FORMULATIONPART.equalsIgnoreCase(strPartType) && !slFormulationType.isEmpty() && !slFormulationType.contains(ConstantsUtil.THIRD_PARTY_FORMULA) ) {
								alPartRelatedObjects = getObjectsForFOPFromFormulaIngredient(context,mapPartDetails);

							} else if(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART.equalsIgnoreCase(strPartType) || (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strPartType) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = getPartObjectsFromIntermediateBOM(context,sPartObjectID);
							} else if(ConstantsUtil.TYPE_FABRICATEDPART.equalsIgnoreCase(strPartType) ||   ConstantsUtil.TYPE_INTERMEDIATEPRODUCTPART.equalsIgnoreCase(strPartType) || ((ConstantsUtil.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strPartType) || ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strPartType)) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType))) {

								alPartRelatedObjects = getPartObjectsFromBOM(context,sPartObjectID);
							}
						}
					}
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return alPartRelatedObjects;
	}

	public ArrayList getPartObjectsFromIntermediateBOM(Context context, String IPSId) throws Exception {

		MapList mlFlatBOM 					= new MapList();
		MapList mpTUPDATA 					= new MapList();
		ArrayList alBOM						= new ArrayList();
		StringList vc = new StringList();

		Map mpBOM							= new HashMap();
		Map tmpMap 							= new HashMap();
		Map mapTemp 						= new HashMap();
		Map tempMap 						= new HashMap();
		Map mpNodeDeatails					= new HashMap();
		MapList mlIntermediateChildData 	= new MapList();
		MapList mlSubInterFirstLevelData	= new MapList();
		MapList mlConnectedInterChildData 	= new MapList();

		DomainObject dObjForTopNodePart 	= null;
		DomainObject dObjIntermediate 		= null;
		DomainObject dobjAlternate 			= null;
		DomainObject dObjInter 				= null;



		String strSubstituteInterType 		= DomainConstants.EMPTY_STRING;;
		String strSubstituteType 			= DomainConstants.EMPTY_STRING;;


		String strTopNodeType 				= DomainConstants.EMPTY_STRING;
		String strTopNodeName 				= DomainConstants.EMPTY_STRING;
		String strTopNodeEffeDate 			= DomainConstants.EMPTY_STRING;
		String strTopNodeBOMQty 			= DomainConstants.EMPTY_STRING;
		String strReshipperLevel 			= DomainConstants.EMPTY_STRING;
		String strID 						= DomainConstants.EMPTY_STRING;
		String strObjectType 				= DomainConstants.EMPTY_STRING;
		String strSAPType 				= DomainConstants.EMPTY_STRING;
		String strName 						= DomainConstants.EMPTY_STRING;
		String strRev 						= DomainConstants.EMPTY_STRING;
		String strLevel 					= DomainConstants.EMPTY_STRING;
		String strType				 		= DomainConstants.EMPTY_STRING;
		String strInterID 					= DomainConstants.EMPTY_STRING;
		String strFindNumb					= DomainConstants.EMPTY_STRING;
		String strEffectivityDateChild		= DomainConstants.EMPTY_STRING;
		String sChildName					= DomainConstants.EMPTY_STRING;
		String sQuantity					= DomainConstants.EMPTY_STRING;
		String strMax						= DomainConstants.EMPTY_STRING; 
		String sTarget						= DomainConstants.EMPTY_STRING;
		String strMin						= DomainConstants.EMPTY_STRING;
		String strPosInd					= DomainConstants.EMPTY_STRING;
		String strFILBaseQty				= DomainConstants.EMPTY_STRING;
		String strpgPhaseBOMQty				= DomainConstants.EMPTY_STRING;
		String strQtyTmp					= DomainConstants.EMPTY_STRING;
		String strGroupTmp					= DomainConstants.EMPTY_STRING;
		String strOptComponent				= DomainConstants.EMPTY_STRING;
		String strComment					= DomainConstants.EMPTY_STRING;
		int iAltsSize = 0;
		Map mpAltMap = null;
		MapList mlSubAlts = null;

		String strBUOM					= DomainConstants.EMPTY_STRING;

		String strFrommid					= "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.id";
		String strFrommtype					= "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.type";

		String strFrommName				= "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.name";

		String strFrommPGASSEMBLYTYPE		= "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to." +ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE;

		String strFrommRev					= "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.revision";
		String strFrommTocurrent					= "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.current";
		String strFromAltId					= "from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to.id";

		String strFrommToID					= "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].id";

		String strSelect_Substitute_EffectivityDate = "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.attribute["+ConstantsUtil.ATTRIBUTE_EFFECTIVITYDATE+"]";
		String strSelect_Substitute_ValidUntilDate = "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].attribute["+ConstantsUtil.ATTR_VALID_UNTIL_DATE+"]";
		String strValidUntilDate		= DomainConstants.EMPTY_STRING;
		String strSelect_Substitute_pgSAPType = "frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to."+ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE;

		String[] arrBOM;

		char cAltItem1						= ConstantsUtil.ALT_ITEM_NINE, cAltItem2	=	ConstantsUtil.ALT_ITEM_A;

		StringList strListQty				= new StringList(1);
		StringList slSubstituteGroupValues				= new StringList(1);
		String strDONOTINCLUDETYPE 		= "pgPhase,pgCustomerUnitPart,pgInnerPackUnitPart,pgConsumerUnitPart,pgAncillaryPackagingMaterialPart,pgPromotionalItemPart";
		String objectWhere 					= DomainObject.SELECT_CURRENT+ " != " + DomainConstants.STATE_PART_OBSOLETE;
		Pattern pIntermediateObjectType = new Pattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
		pIntermediateObjectType.addPattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
		pIntermediateObjectType.addPattern(ConstantsUtil.TYPE_PGINNERPACKUNITPART);
		StringList slSubIntermediate 		= new StringList();
		String strSelect_SubstituteComment = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("]."+ConstantsUtil.SELECT_ATTRIBUTE_COMMENT).toString();
		String strSpecSubType			= DomainConstants.EMPTY_STRING;
		String strInterSpecSubType		= DomainConstants.EMPTY_STRING;
		boolean isReshipperSub = false;
		float fChildSAPQty = 1;
		String strChildQuantity	= DomainConstants.EMPTY_STRING;
		String strInterMedLevel	= DomainConstants.EMPTY_STRING;
		StringList slSubstituteInterIdReshipper = new StringList();
		float fIntermediateSAPQty = 1;
		String strIntermediateTypes	= ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART+","+ConstantsUtil.TYPE_PGCONSUMERUNITPART;
		StringList slChildCOPConnectedFPPQTY = new StringList(1);
		MapList mlChildCOPConnectedFPP = new MapList();
		StringList slReleaseFPPQTY = new StringList(1);
		MapList mlReleasedFPP = new MapList();
		String strIntermediateObjectQty = DomainConstants.EMPTY_STRING;		
		BigDecimal bdIntermediateObjectQty = new BigDecimal("1");	
		Map mpChildMap = new HashMap();
		String strCOPToCOPQuantity = DomainConstants.EMPTY_STRING;
		try {
			if (BusinessUtil.isNotNullOrEmpty(IPSId)) {

				dObjForTopNodePart 			= DomainObject.newInstance(context, IPSId);					
				mpNodeDeatails 			= dObjForTopNodePart.getInfo(context,SL_OBJECT_INFO_SELECT);
				strTopNodeType 				= (String) mpNodeDeatails.get(DomainConstants.SELECT_TYPE);
				strTopNodeName 				= (String) mpNodeDeatails.get(DomainConstants.SELECT_NAME);
				strTopNodeEffeDate 			= (String) mpNodeDeatails.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				strTopNodeBOMQty 			= (String) mpNodeDeatails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				strBUOM						= (String) mpNodeDeatails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

				MapList mlFPPChildData = dObjForTopNodePart.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_EBOM, 	// relationship pattern
						pIntermediateObjectType.getPattern(), // Type pattern
						SL_OBJECT_INFO_SELECT,        		// object selects
						SL_RELATION_INFO_SELECT_EBOM,  		 	// rel selects 
						false,                 				// to side
						true,                  				// from side
						(short)0,              				// recursion level
						objectWhere,           				// object where clause
						null,0);                    			// rel where clause
				if (null != mlFPPChildData && mlFPPChildData.size() > 0) {

					int iSizeOfChildData	= mlFPPChildData.size();
					Map mpPreviousLevelChildType = new HashMap();

					for (int i=0;i<iSizeOfChildData;i++) {

						tempMap 			= (Map)mlFPPChildData.get(i);
						strLevel 			= (String)(tempMap).get(DomainConstants.SELECT_LEVEL);
						if ((BusinessUtil.isNotNullOrEmpty(strLevel)) && (BusinessUtil.isNotNullOrEmpty(strReshipperLevel)) && (parseValue(strLevel) 	 > parseValue(strReshipperLevel))) {

							continue;
						}
						else if ((BusinessUtil.isNotNullOrEmpty(strLevel)) && (BusinessUtil.isNotNullOrEmpty(strReshipperLevel)) && (parseValue(strLevel) <= parseValue(strReshipperLevel))) {

							strReshipperLevel = DomainConstants.EMPTY_STRING;
						}
						strID 				= (String)(tempMap).get(DomainConstants.SELECT_ID);
						strObjectType 		= (String)(tempMap).get(DomainConstants.SELECT_TYPE);
						strName 			= (String)(tempMap).get(DomainConstants.SELECT_NAME);
						strRev 				= (String)(tempMap).get(DomainConstants.SELECT_REVISION);
						mpPreviousLevelChildType.put(parseValue(strLevel),strObjectType);
						if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType) && parseValue(strLevel) > 1)
						{
							String strPreviousTypeToSecondLevelCOP = (String)mpPreviousLevelChildType.get(parseValue(strLevel)-1);
							String strPreviousTypeToThirdLevelCOP = (String)mpPreviousLevelChildType.get(parseValue(strLevel)-2);

							if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToSecondLevelCOP) && !ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToThirdLevelCOP))
							{
								for(int j=iSizeOfChildData - 1;j>0;j--){
									mpChildMap = (Map)mlFPPChildData.get(j-1);
									String strIntermediateLevel 			= (String)(mpChildMap).get(DomainConstants.SELECT_LEVEL);
									if(parseValue(strIntermediateLevel) < parseValue(strLevel))
									{
										strIntermediateObjectQty = (String)(mpChildMap).get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
										bdIntermediateObjectQty = bdIntermediateObjectQty.multiply(new BigDecimal(strIntermediateObjectQty));
									}
								}
								strCOPToCOPQuantity 		= (String)(tempMap).get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
								Object COPSubstituteId 		= (Object) (tempMap).get(strFrommid);
								StringList slCOPSubstituteIds 	= new StringList();

								if (null != COPSubstituteId) {

									if (COPSubstituteId instanceof StringList) {

										slCOPSubstituteIds 		= (StringList) COPSubstituteId;
									} else {
										slCOPSubstituteIds.add(COPSubstituteId.toString());
									}
								}

								Map mpConnectedFPPToChildCOP = getFPPObjectsForChildCOPInCOP(context,strID,strCOPToCOPQuantity,IPSId,slCOPSubstituteIds,strTopNodeBOMQty,bdIntermediateObjectQty, strBUOM);
								bdIntermediateObjectQty = new BigDecimal("1");
								mlChildCOPConnectedFPP = (MapList)mpConnectedFPPToChildCOP.get("mlReleasedFPP");
								slChildCOPConnectedFPPQTY = (StringList)mpConnectedFPPToChildCOP.get("strListQtyValues");
								if(mlChildCOPConnectedFPP.isEmpty() && slChildCOPConnectedFPPQTY.isEmpty())
								{
									return alBOM;
								}else{
									mlReleasedFPP.addAll(mlChildCOPConnectedFPP);
									slReleaseFPPQTY.addAll(slChildCOPConnectedFPPQTY);
								}
								continue; 

							}else if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToSecondLevelCOP))
							{
								continue;
							}
						}
						strSpecSubType 		= (String)(tempMap).get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
						if((ConstantsUtil.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strObjectType) || ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType)) && ConstantsUtil.THIRD_PARTY.equals(strSpecSubType)){
							break;
						}
						if(strIntermediateTypes.contains(strObjectType)){
							String strIntermediateObjQty = (String)(tempMap).get("attribute[Quantity]");
							if(UIUtil.isNotNullAndNotEmpty(strBUOM) && ("IT".equalsIgnoreCase(strBUOM) || "MP".equalsIgnoreCase(strBUOM) || "BP".equalsIgnoreCase(strBUOM) || "SW".equalsIgnoreCase(strBUOM) || "SP".equalsIgnoreCase(strBUOM)) && UIUtil.isNotNullAndNotEmpty(strIntermediateObjQty))
							{
								fIntermediateSAPQty = Float.valueOf(strIntermediateObjQty) * fIntermediateSAPQty;
							}
						}	
						Object substituteInterId 		= (Object) (tempMap).get(strFrommid);						
						StringList substituteInterIds 	= new StringList();

						if (null != substituteInterId) {

							if (substituteInterId instanceof StringList) {

								substituteInterIds = (StringList) substituteInterId;
							} else {
								substituteInterIds.add(substituteInterId.toString());
							}
						}
						slSubstituteInterIdReshipper = substituteInterIds;

						Object substituteInterType 		= (Object) (tempMap).get(strFrommtype);
						StringList substituteInterTypes = new StringList(); // Intermediate parts substitute parts types

						if (null != substituteInterType) {

							if (substituteInterType instanceof StringList) {

								substituteInterTypes = (StringList) substituteInterType;
							} else {
								substituteInterTypes.add(substituteInterType.toString());
							}
						}

						Object substituteSpecificationType 			= (Object) (tempMap).get(strFrommPGASSEMBLYTYPE);
						StringList slSubstituteSpecificationTypes 	= new StringList(); // Intermediate part substitute specification Type

						if (null != substituteSpecificationType) {

							if (substituteSpecificationType instanceof StringList) {

								slSubstituteSpecificationTypes = (StringList) substituteInterType;
							} else {
								slSubstituteSpecificationTypes.add(substituteSpecificationType.toString());
							}
						}

						if (null != substituteInterIds && substituteInterIds.size() > 0) {

							for(int iSubInter=0;iSubInter < substituteInterIds.size();iSubInter++) {
								strSubstituteInterType = (String)substituteInterTypes.get(iSubInter);
								strSpecSubType = (String)slSubstituteSpecificationTypes.get(iSubInter);
								if(((ConstantsUtil.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strSubstituteInterType)) || (ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strSubstituteInterType)) && !ConstantsUtil.THIRD_PARTY.equals(strSpecSubType)) ||(ConstantsUtil.TYPE_PGINNERPACKUNITPART.equalsIgnoreCase(strSubstituteInterType))) {
									slSubIntermediate.addElement((String)substituteInterIds.get(iSubInter));
								}
							}
						}

						if ((strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)) && (slSubstituteSpecificationTypes.indexOf(ConstantsUtil.RESHIPPER_ASS_TYPE_VAL) != -1) && (strTopNodeType.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART))) {

							strReshipperLevel = strLevel;
							isReshipperSub=true;
							continue;
						}

						dObjIntermediate 		= DomainObject.newInstance(context, strID);
						mlIntermediateChildData = dObjIntermediate.getRelatedObjects(context,
								ConstantsUtil.RELATIONSHIP_EBOM, // rel pattern
								ConstantsUtil.SYMBL_ASTERISK,                             // type pattern
								SL_OBJECT_INFO_SELECT,           // object select
								SL_RELATION_INFO_SELECT_EBOM,         //  rel select 
								false,                           // to side
								true,                            //  from side
								(short)1,                        // recursion level
								objectWhere,                     //  object where clause  
								null,0);                             //  rel where clause 

						if (null != mlIntermediateChildData && mlIntermediateChildData.size() > 0) {

							mlIntermediateChildData.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");

							int iSizeOfIntermediateChild=mlIntermediateChildData.size();

							for (int iCount=0;iCount<iSizeOfIntermediateChild;iCount++) {

								tmpMap 	= (Map)mlIntermediateChildData.get(iCount);
								strType = (String)(tmpMap).get(DomainConstants.SELECT_TYPE);
								if(strObjectType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART) && strType.equals(ConstantsUtil.TYPE_PGCONSUMERUNITPART))
								{
									continue;
								}
								strSpecSubType = (String)(tmpMap).get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
								if(ConstantsUtil.THIRD_PARTY.equals(strSpecSubType)){
									continue;	
								}
								if (!(strDONOTINCLUDETYPE.contains(strType))) {
									(tmpMap).put("IntermediateName", strName+"."+strRev);
									(tmpMap).put("IntermediateID", strID);
									(tmpMap).put("IntermediateType", strObjectType);
									(tmpMap).put("IntermediateLevel", strLevel);
									(tmpMap).put("IsDirectComponent", "true");

									if(strType.contains(ConstantsUtil.TYPE_MASTER)) {

										String strMasterID = (String)(tmpMap).get(DomainConstants.SELECT_ID);
										DomainObject dmaster = DomainObject.newInstance(context,strMasterID );
										MapList masterList = dmaster.getRelatedObjects(context,
												ConstantsUtil.RELATIONSHIP_EBOM, // rel pattern
												ConstantsUtil.SYMBL_ASTERISK,                             // type pattern
												SL_OBJECT_INFO_SELECT,           // object select
												SL_RELATION_INFO_SELECT_EBOM,         //  rel select 
												false,                           // to side
												true,                            //  from side
												(short)1,                        // recursion level
												DomainConstants.EMPTY_STRING,                     //  object where clause  
												null,0);  

										int masterComp = masterList.size();
										for(int k=0; k<masterComp; k++){

											tempMap 		= (Map)masterList.get(k);
											strID 			= (String)(tempMap).get(DomainConstants.SELECT_ID);
											strObjectType 	= (String)(tempMap).get(DomainConstants.SELECT_TYPE);
											strName 		= (String)(tempMap).get(DomainConstants.SELECT_NAME);
											strRev 			= (String)(tempMap).get(DomainConstants.SELECT_REVISION);
											mlFlatBOM.add(tempMap);
										}


									}
									if(!(strType.contains(ConstantsUtil.TYPE_MASTER))){
										mlFlatBOM.add(tmpMap);
									}

								}

								Object substituteId 		= (Object) (tmpMap).get(strFrommid);
								StringList substituteIds 	= new StringList();

								if (null != substituteId) {

									if (substituteId instanceof StringList) {

										substituteIds 		= (StringList) substituteId;
									} else {
										substituteIds.add(substituteId.toString());
									}
								}
								Object substituteSAPType = (Object) (tmpMap).get(strSelect_Substitute_pgSAPType);
								StringList substituteSAPTypes 	= new StringList();
								if (null != substituteSAPType) {
									if (substituteSAPType instanceof StringList) {
										substituteSAPTypes 	= (StringList) substituteSAPType;
									} else {
										substituteSAPTypes.add(substituteSAPType.toString());
									}
								}
								Object substituteName 		= (Object) (tmpMap).get(strFrommName);
								StringList substituteNames 	= new StringList();

								if (null != substituteName) {

									if (substituteName instanceof StringList) {

										substituteNames 	= (StringList) substituteName;
									} else {
										substituteNames.add(substituteName.toString());
									}
								}

								Object substituteType 		= (Object) (tmpMap).get(strFrommtype);
								StringList substituteTypes 	= new StringList();

								if (null != substituteType) {

									if (substituteType instanceof StringList) {

										substituteTypes 	= (StringList) substituteType;
									} else {
										substituteTypes.add(substituteType.toString());
									}
								}

								Object substituteRev 		= (Object) (tmpMap).get(strFrommRev);
								StringList slsubstituteRev 	= new StringList();

								if (null != substituteRev) {

									if (substituteRev instanceof StringList) {

										slsubstituteRev 	= (StringList) substituteRev;
									} else {
										slsubstituteRev.add(substituteRev.toString());
									}
								}

								Object substituteState 			= (Object) (tmpMap).get(strFrommTocurrent);
								StringList slsubstituteCurrent 	= new StringList();

								if (null != substituteState) {

									if (substituteState instanceof StringList) {

										slsubstituteCurrent 	= (StringList) substituteState;
									} else {
										slsubstituteCurrent.add(substituteState.toString());
									}
								}

								Object substituteRelID 			= (Object) (tmpMap).get(strFrommToID);
								StringList slsubstituteRelID 	= new StringList();

								if (null != substituteRelID) {

									if (substituteRelID instanceof StringList) {

										slsubstituteRelID 		= (StringList) substituteRelID;
									} else {
										slsubstituteRelID.add(substituteRelID.toString());
									}
								}

								Object substituteEffectivityDate = (Object) (tmpMap).get(strSelect_Substitute_EffectivityDate);
								StringList slSubstituteEffectivityDate = new StringList();
								if (null != substituteEffectivityDate) {
									if (substituteEffectivityDate instanceof StringList) {
										slSubstituteEffectivityDate = (StringList) substituteEffectivityDate;
									} else {
										slSubstituteEffectivityDate.add(substituteEffectivityDate.toString());
									}
								}
								Object substituteValidUntilDate = (Object) (tmpMap).get(strSelect_Substitute_ValidUntilDate);
								StringList slSubstituteValidUntilDate = new StringList();
								if (null != substituteValidUntilDate) {
									if (substituteValidUntilDate instanceof StringList) {
										slSubstituteValidUntilDate = (StringList) substituteValidUntilDate;
									} else if (substituteValidUntilDate instanceof String){
										slSubstituteValidUntilDate.add(substituteValidUntilDate.toString());
									}
								}


								Object substituteOptComponent = (Object) (tmpMap).get(SELECT_SUBSTITUTE_OPT_COMPONENT);
								StringList slSubstituteOptComponent = new StringList();
								if (null != substituteOptComponent) {
									if (substituteOptComponent instanceof StringList) {
										slSubstituteOptComponent = (StringList) substituteOptComponent;
									} else {
										slSubstituteOptComponent.add(substituteOptComponent.toString());
									}
								}
								Object substituteComment = (Object) (tmpMap).get(strSelect_SubstituteComment);
								StringList slSubstituteComment = new StringList();
								if (null != substituteComment) {
									if (substituteComment instanceof StringList) {
										slSubstituteComment = (StringList) substituteComment;
									} else {
										slSubstituteComment.add(substituteComment.toString());
									}
								}
								Object oSubSpecSubType = (Object) (tmpMap).get(strFrommPGASSEMBLYTYPE);
								StringList slSubSpecSubType = new StringList();
								if (null != oSubSpecSubType) {
									if (oSubSpecSubType instanceof StringList) {
										slSubSpecSubType = (StringList) oSubSpecSubType;
									} else {
										slSubSpecSubType.add(oSubSpecSubType.toString());
									}
								}
								if (!(strDONOTINCLUDETYPE.contains(strType))) {
									Object oAlternateIds 		= (Object) (tmpMap).get(strFromAltId);
									StringList slAlternateIds 	= new StringList();

									if (null != oAlternateIds) {

										if (oAlternateIds instanceof StringList) {

											slAlternateIds 		= (StringList) oAlternateIds;
										} else {
											slAlternateIds.add(oAlternateIds.toString());
										}
									}

									for (Object oAlternateId : slAlternateIds) {

										dobjAlternate 	= DomainObject.newInstance(context, (String) oAlternateId);
										Map mpAlternate = dobjAlternate.getInfo(context,SL_OBJECT_INFO_SELECT);
										if(!ConstantsUtil.THIRD_PARTY.equals((String) tmpMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE))){
											(mpAlternate).put(DomainConstants.SELECT_RELATIONSHIP_ID,(String) tmpMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
											(mpAlternate).put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
											(mpAlternate).put("IntermediateName", strName+"."+strRev);
											(mpAlternate).put("IntermediateID", strID);
											(mpAlternate).put("IntermediateType", strObjectType);
											(mpAlternate).put("IntermediateLevel", strLevel);
											mlFlatBOM.add(mpAlternate);
										}
									}

								}

								if (null != substituteIds && substituteIds.size() > 0) {

									int iSizeOfSubstitutes = substituteIds.size();

									for (int iSub = 0; iSub < iSizeOfSubstitutes; iSub++) {
										String strSubstitutepgSAPType=(String)substituteSAPTypes.get(iSub);
										if (!(strDONOTINCLUDETYPE.contains((String)substituteTypes.get(iSub))) && !(ConstantsUtil.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(ConstantsUtil.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))) {
											mapTemp = new HashMap();

											String strSubstituteId = (String)substituteIds.get(iSub);
											strSubstituteType = (String)substituteTypes.get(iSub);

											mapTemp.put("name", (String)substituteNames.get(iSub));
											mapTemp.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
											mapTemp.put("relationship", ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE);
											mapTemp.put(DomainConstants.SELECT_ID, strSubstituteId);
											mapTemp.put(DomainConstants.SELECT_TYPE, strSubstituteType);

											mapTemp.put("IntermediateName", strName+"."+strRev);
											mapTemp.put("IntermediateID", strID);
											mapTemp.put("IntermediateType", strObjectType);
											mapTemp.put(DomainConstants.SELECT_REVISION, (String)slsubstituteRev.get(iSub));
											mapTemp.put(DomainConstants.SELECT_CURRENT, (String)slsubstituteCurrent.get(iSub));
											mapTemp.put(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE, (String)slSubstituteEffectivityDate.get(iSub));

											mapTemp.put(ConstantsUtil.ATTR_VALID_UNTIL_DATE, (String)slSubstituteValidUntilDate.get(iSub));
											mapTemp.put(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT, (String)slSubstituteOptComponent.get(iSub));
											mapTemp.put(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT, (String)slSubstituteComment.get(iSub));
											mapTemp.put("IntermediateLevel", strLevel);
											mlFlatBOM.add(mapTemp);

											if(UIUtil.isNotNullAndNotEmpty(strSubstituteType) && strAlternateAllowedTypes.contains(strSubstituteType)){
												mlSubAlts= getAlternates(context, strSubstituteId);
												iAltsSize = mlSubAlts.size();
												for(int j=0;j<iAltsSize;j++){
													mpAltMap = (Map) mlSubAlts.get(j);
													mpAltMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
													mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
													mpAltMap.put("IntermediateName", strName+"."+strRev);
													mpAltMap.put("IntermediateID", strID);
													mpAltMap.put("IntermediateType", strObjectType);
													mpAltMap.put("IntermediateLevel", strLevel);
													mlFlatBOM.add(mpAltMap);
												}
											}

										} else {
											slSubIntermediate.addElement((String)substituteIds.get(iSub));
										}
									}
								}
							}
						}
					}
				}
				if (null != slSubIntermediate && slSubIntermediate.size() > 0) {						

					int iSizeOfSubInterm = slSubIntermediate.size();
					float fQtyMultiplier = 0;
					for (int iSubInter=0; iSubInter < iSizeOfSubInterm; iSubInter++) {

						strInterID = (String)slSubIntermediate.get(iSubInter);
						dObjInter = DomainObject.newInstance(context, strInterID);

						mlIntermediateChildData = dObjInter.getRelatedObjects(context,
								ConstantsUtil.RELATIONSHIP_EBOM,   // rel pattern
								pIntermediateObjectType.getPattern(),  // type pattern
								SL_OBJECT_INFO_SELECT,             // object selects
								SL_RELATION_INFO_SELECT_EBOM,           //  rel selects 
								false,                             // to side
								true,                              // from side
								(short)0,                          //  recursion level
								objectWhere,                       // object where clause
								null,0);                             //  rel where clause
						fQtyMultiplier = 1;
						String strTemplevel = DomainConstants.EMPTY_STRING;
						if (null != mlIntermediateChildData && mlIntermediateChildData.size() > 0) {

							int iSizeOfInterChild = mlIntermediateChildData.size();								
							Map mpPreviousLevelSubstituteType = new HashMap();

							for (int i=0;i<iSizeOfInterChild;i++) {

								tempMap 		= (Map)mlIntermediateChildData.get(i);
								strID 			= (String)(tempMap).get(DomainConstants.SELECT_ID);
								strObjectType 	= (String)(tempMap).get(DomainConstants.SELECT_TYPE);
								strLevel 			= (String)(tempMap).get(DomainConstants.SELECT_LEVEL);
								mpPreviousLevelSubstituteType.put(parseValue(strLevel),strObjectType);
								if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType) && parseValue(strLevel) > 1)
								{
									String strPreviousTypeToScndLevelCOPSubstitute = (String)mpPreviousLevelSubstituteType.get(parseValue(strLevel)-1);
									String strPreviousTypeToThirdLevelSubsctituteCOP = (String)mpPreviousLevelSubstituteType.get(parseValue(strLevel)-2);
									if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToScndLevelCOPSubstitute) && !ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToThirdLevelSubsctituteCOP))
									{

										for(int j=iSizeOfInterChild - 1;j>0;j--){
											mpChildMap = (Map)mlIntermediateChildData.get(j-1);
											String strIntermediateLevel 			= (String)(mpChildMap).get(DomainConstants.SELECT_LEVEL);
											if(parseValue(strIntermediateLevel) < parseValue(strLevel))
											{
												strIntermediateObjectQty = (String)(mpChildMap).get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
												bdIntermediateObjectQty = bdIntermediateObjectQty.multiply(new BigDecimal(strIntermediateObjectQty));
											}
										}								
										strCOPToCOPQuantity 		= (String)(tempMap).get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
										Object COPSubstituteId 		= (Object) (tempMap).get(strFrommid);
										StringList slCOPSubstituteIds 	= new StringList();
										if (null != COPSubstituteId) {
											if (COPSubstituteId instanceof StringList) {
												slCOPSubstituteIds 		= (StringList) COPSubstituteId;
											} else {
												slCOPSubstituteIds.add(COPSubstituteId.toString());
											}
										}
										Map mpConnectedFPPToChildCOP = getFPPObjectsForChildCOPInCOP(context,strID,strCOPToCOPQuantity,IPSId,slCOPSubstituteIds,strTopNodeBOMQty,bdIntermediateObjectQty, strBUOM);
										bdIntermediateObjectQty = new BigDecimal("1");
										mlChildCOPConnectedFPP = (MapList)mpConnectedFPPToChildCOP.get("mlReleasedFPP");
										slChildCOPConnectedFPPQTY = (StringList)mpConnectedFPPToChildCOP.get("strListQtyValues");
										if(mlChildCOPConnectedFPP.isEmpty() && slChildCOPConnectedFPPQTY.isEmpty())
										{
											return alBOM;
										}else
										{
											mlReleasedFPP.addAll(mlChildCOPConnectedFPP);
											slReleaseFPPQTY.addAll(slChildCOPConnectedFPPQTY);
										}
										continue;
									}
									else if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousTypeToScndLevelCOPSubstitute))
									{
										continue;
									}
								}
								strInterSpecSubType = (String)(tempMap).get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
								if((ConstantsUtil.TYPE_PGCUSTOMERUNITPART.equalsIgnoreCase(strObjectType) || ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType)) && ConstantsUtil.THIRD_PARTY.equals(strInterSpecSubType)){
									break;
								}
								strName 		= (String)(tempMap).get(DomainConstants.SELECT_NAME);
								strRev 			= (String)(tempMap).get(DomainConstants.SELECT_REVISION);

								strInterMedLevel = (String)(tempMap).get(DomainConstants.SELECT_LEVEL);
								if(strInterMedLevel.equals("1")){
									fQtyMultiplier = 1;
								}
								String strInterQuantity	= (String)tempMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
								if(!strTemplevel.equals(strInterMedLevel) && UIUtil.isNotNullAndNotEmpty(strInterQuantity)){
									fQtyMultiplier = fQtyMultiplier * (Float.valueOf(strInterQuantity)).floatValue();
									strTemplevel = strInterMedLevel;
								}

								dObjIntermediate= DomainObject.newInstance(context, strID);

								mlConnectedInterChildData = dObjIntermediate.getRelatedObjects(context,
										ConstantsUtil.RELATIONSHIP_EBOM,// rel pattern
										ConstantsUtil.SYMBL_ASTERISK,                    		// type pattern
										SL_OBJECT_INFO_SELECT,         	// object select
										SL_RELATION_INFO_SELECT_EBOM,    	// rel select
										false,                  		// to side
										true,                   		// from side 
										(short)1,               		// recursion level
										objectWhere,            		// object where clause
										DomainConstants.EMPTY_STRING,0);                    		// rel where clause

								if (null != mlConnectedInterChildData && mlConnectedInterChildData.size() > 0) {

									mlConnectedInterChildData.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");
									strType = DomainConstants.EMPTY_STRING;

									for(int iCount=0;iCount<mlConnectedInterChildData.size();iCount++) {

										tmpMap 	= (Map)mlConnectedInterChildData.get(iCount);
										strType = (String)(tmpMap).get(DomainConstants.SELECT_TYPE);
										strInterSpecSubType = (String)(tmpMap).get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);

										if(!(strDONOTINCLUDETYPE.contains(strType)) && !ConstantsUtil.THIRD_PARTY.equals(strInterSpecSubType)) {
											(tmpMap).put("IntermediateName", strName+"."+strRev);
											(tmpMap).put("IntermediateID", strID);
											(tmpMap).put("IntermediateType", strObjectType);
											if(isReshipperSub && ("IT".equalsIgnoreCase(strBUOM) || "MP".equalsIgnoreCase(strBUOM) || "BP".equalsIgnoreCase(strBUOM) || "SW".equalsIgnoreCase(strBUOM) || "SP".equalsIgnoreCase(strBUOM)))
											{
												int iLevel = Integer.parseInt(strLevel);
												iLevel++;
												(tmpMap).put("IntermediateLevel", String.valueOf(iLevel));
											}else{
												(tmpMap).put("IntermediateLevel", strLevel);
											}
											if(isReshipperSub && !("IT".equalsIgnoreCase(strBUOM) || "MP".equalsIgnoreCase(strBUOM) || "BP".equalsIgnoreCase(strBUOM) || "SW".equalsIgnoreCase(strBUOM) || "SP".equalsIgnoreCase(strBUOM))){	
												strChildQuantity	= (String)tmpMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
												if(UIUtil.isNotNullAndNotEmpty(strTopNodeBOMQty) && UIUtil.isNotNullAndNotEmpty(strChildQuantity))
												{
													fChildSAPQty = (Float.valueOf(strTopNodeBOMQty)).floatValue() * fQtyMultiplier * (Float.valueOf(strChildQuantity)).floatValue();
													strListQty.add(String.valueOf(fChildSAPQty));
												}
											}
											mlFlatBOM.add(tmpMap);
										}
									}
								}
							}
						}

						mlSubInterFirstLevelData = dObjInter.getRelatedObjects(context,
								ConstantsUtil.RELATIONSHIP_EBOM, 	// rel pattern
								ConstantsUtil.SYMBL_ASTERISK,                    			// type pattern
								SL_OBJECT_INFO_SELECT,         		// object select
								SL_RELATION_INFO_SELECT_EBOM,    		// rel select
								false,                  			// to side
								true,                   			// from side 
								(short)1,               			// recursion level
								objectWhere,            			// object where clause
								"",0);                    			// rel where clause

						if (null != mlSubInterFirstLevelData && mlSubInterFirstLevelData.size() > 0) {

							mlSubInterFirstLevelData.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");

							int iSizeOfSubInterFirstLevel = mlSubInterFirstLevelData.size();

							for(int iCount=0;iCount<iSizeOfSubInterFirstLevel;iCount++) {

								tempMap = (Map)mlSubInterFirstLevelData.get(iCount);
								strType = (String)(tempMap).get(DomainConstants.SELECT_TYPE);
								strLevel = (String)(tempMap).get(DomainConstants.SELECT_LEVEL);
								(tempMap).put("IntermediateLevel", strLevel);
								strInterSpecSubType = (String)(tempMap).get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
								if(!(strDONOTINCLUDETYPE.contains(strType)) && !ConstantsUtil.THIRD_PARTY.equals(strInterSpecSubType) ) {
									mlFlatBOM.add(tempMap);
									if(isReshipperSub && !("IT".equalsIgnoreCase(strBUOM) || "MP".equalsIgnoreCase(strBUOM) || "BP".equalsIgnoreCase(strBUOM) || "SW".equalsIgnoreCase(strBUOM) || "SP".equalsIgnoreCase(strBUOM))){										
										strChildQuantity	= (String)tempMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
										if(UIUtil.isNotNullAndNotEmpty(strTopNodeBOMQty) && UIUtil.isNotNullAndNotEmpty(strChildQuantity))
										{
											fChildSAPQty = (Float.valueOf(strTopNodeBOMQty)).floatValue() * (Float.valueOf(strChildQuantity)).floatValue();
											strListQty.add(String.valueOf(fChildSAPQty));
										}
									}
								}
							}
						}
					}
				}

				MapList mlFPPFirstLevelData = dObjForTopNodePart.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_EBOM, 	// rel pattern
						ConstantsUtil.SYMBL_ASTERISK,                    			// type pattern
						SL_OBJECT_INFO_SELECT,         		// object select
						SL_RELATION_INFO_SELECT_EBOM,    		// rel select
						false,                  			// to side
						true,                   			// from side 
						(short)1,               			// recursion level
						objectWhere,            			// object where clause
						DomainConstants.EMPTY_STRING,0);                    			// rel where clause

				if (null != mlFPPFirstLevelData && mlFPPFirstLevelData.size() > 0) {

					mlFPPFirstLevelData.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");

					int iSizeOfFirstLevelData = mlFPPFirstLevelData.size();

					for (int iCount=0;iCount<iSizeOfFirstLevelData;iCount++) {

						tmpMap 		= (Map)mlFPPFirstLevelData.get(iCount);
						strType 	= (String)(tmpMap).get(DomainConstants.SELECT_TYPE);
						strLevel 	= (String)(tmpMap).get(DomainConstants.SELECT_LEVEL);

						if(!(strDONOTINCLUDETYPE.contains(strType))) {
							(tmpMap).put("IsDirectComponent", "true");

							if (strType.contains(ConstantsUtil.TYPE_MASTER)) {

								return (new MapList());
							}
							mlFlatBOM.add(tmpMap);
						}

						//Check if there is substitute
						Object substituteId   		= (Object) (tmpMap).get(strFrommid);
						StringList substituteIds 	= new StringList();

						if (null != substituteId) {

							if (substituteId instanceof StringList) {

								substituteIds 		= (StringList) substituteId;
							} else {
								substituteIds.add(substituteId.toString());
							}
						}

						Object substituteSAPType = (Object) (tmpMap).get(strSelect_Substitute_pgSAPType);

						StringList substituteSAPTypes 	= new StringList();

						if (null != substituteSAPType) {

							if (substituteSAPType instanceof StringList) {

								substituteSAPTypes 	= (StringList) substituteSAPType;
							} else {
								substituteSAPTypes.add(substituteSAPType.toString());
							}
						}

						Object substituteName 		= (Object) (tmpMap).get(strFrommName);
						StringList substituteNames 	= new StringList();

						if (null != substituteName) {

							if (substituteName instanceof StringList) {

								substituteNames 	= (StringList) substituteName;
							} else {
								substituteNames.add(substituteName.toString());
							}
						}

						Object substituteType 		= (Object) (tmpMap).get(strFrommtype);
						StringList substituteTypes 	= new StringList();

						if (null != substituteType) {

							if (substituteType instanceof StringList) {

								substituteTypes 	= (StringList) substituteType;
							} else {
								substituteTypes.add(substituteType.toString());
							}
						}

						Object substituteRev 		= (Object) (tmpMap).get(strFrommRev);
						StringList substituteRevs 	= new StringList();

						if (null != substituteRev) {

							if (substituteRev instanceof StringList) {

								substituteRevs 		= (StringList) substituteRev;
							} else {
								substituteRevs.add(substituteRev.toString());
							}
						}
						Object substituteState   		= (Object) (tmpMap).get(strFrommTocurrent);
						StringList slsubstituteCurrent 	= new StringList();
						if (null != substituteState) {
							if (substituteState instanceof StringList) {
								slsubstituteCurrent 	= (StringList) substituteState;
							} else {
								slsubstituteCurrent.add(substituteState.toString());
							}
						}
						Object substituteRelID 			= (Object) (tmpMap).get(strFrommToID);
						StringList slsubstituteRelID 	= new StringList();
						if (null != substituteRelID) {
							if (substituteRelID instanceof StringList) {
								slsubstituteRelID 		= (StringList) substituteRelID;
							} else {
								slsubstituteRelID.add(substituteRelID.toString());
							}
						}

						Object substituteEffectivityDate = (Object) (tmpMap).get(strSelect_Substitute_EffectivityDate);
						StringList slSubstituteEffectivityDate = new StringList();
						if (null != substituteEffectivityDate) {
							if (substituteEffectivityDate instanceof StringList) {
								slSubstituteEffectivityDate = (StringList) substituteEffectivityDate;
							} else {
								slSubstituteEffectivityDate.add(substituteEffectivityDate.toString());
							}
						}
						Object substituteValidUntilDate = (Object) (tmpMap).get(strSelect_Substitute_ValidUntilDate);
						StringList slSubstituteValidUntilDate = new StringList();
						if (null != substituteValidUntilDate) {
							if (substituteValidUntilDate instanceof StringList) {
								slSubstituteValidUntilDate = (StringList) substituteValidUntilDate;
							} else if (substituteValidUntilDate instanceof String) {
								slSubstituteValidUntilDate.add(substituteValidUntilDate.toString());
							}
						}
						Object substituteOptComponent = (Object) (tmpMap).get(SELECT_SUBSTITUTE_OPT_COMPONENT);
						StringList slSubstituteOptComponent = new StringList();
						if (null != substituteOptComponent) {
							if (substituteOptComponent instanceof StringList) {
								slSubstituteOptComponent = (StringList) substituteOptComponent;
							} else {
								slSubstituteOptComponent.add(substituteOptComponent.toString());
							}
						}
						Object substituteComment = (Object) (tmpMap).get(strSelect_SubstituteComment);
						StringList slSubstituteComment = new StringList();
						if (null != substituteComment) {
							if (substituteComment instanceof StringList) {
								slSubstituteComment = (StringList) substituteComment;
							} else {
								slSubstituteComment.add(substituteComment.toString());
							}
						}
						Object oSubSpecSubType = (Object) (tmpMap).get(strFrommPGASSEMBLYTYPE);
						StringList slSubSpecSubType = new StringList();
						if (null != oSubSpecSubType) {
							if (oSubSpecSubType instanceof StringList) {
								slSubSpecSubType = (StringList) oSubSpecSubType;
							} else {
								slSubSpecSubType.add(oSubSpecSubType.toString());
							}
						}
						if (!(strDONOTINCLUDETYPE.contains(strType))) {
							Object oAlternateIds 		= (Object) (tmpMap).get(strFromAltId);
							StringList slAlternateIds 	= new StringList();
							if (null != oAlternateIds) {
								if (oAlternateIds instanceof StringList) {
									slAlternateIds 		= (StringList) oAlternateIds;
								} else {
									slAlternateIds.add(oAlternateIds.toString());
								}
							}
							for(Object oAlternateId : slAlternateIds) {
								dobjAlternate = DomainObject.newInstance(context, (String) oAlternateId);
								Map mpAlternate = dobjAlternate.getInfo(context,SL_OBJECT_INFO_SELECT);
								(mpAlternate).put(DomainConstants.SELECT_RELATIONSHIP_ID,(String) tmpMap.get(DomainConstants.SELECT_RELATIONSHIP_ID));
								(mpAlternate).put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
								(mpAlternate).put("level", strLevel);
								mlFlatBOM.add(mpAlternate);
							}
						}

						if (null != substituteIds && substituteIds.size() > 0) {
							int iSizeOfSubstitutes = substituteIds.size();
							for(int iSub = 0; iSub < iSizeOfSubstitutes; iSub++) {
								strSubstituteType = (String)substituteTypes.get(iSub);
								String strSubstitutepgSAPType=(String)substituteSAPTypes.get(iSub);

								if(!(strDONOTINCLUDETYPE.contains(strSubstituteType)) && !(ConstantsUtil.THIRD_PARTY.equals(slSubSpecSubType.get(iSub))) && !(ConstantsUtil.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSubstitutepgSAPType))){
									mapTemp = new HashMap();
									String strSubstituteId = (String)substituteIds.get(iSub);

									mapTemp.put("name", (String)substituteNames.get(iSub));
									mapTemp.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
									mapTemp.put("relationship", ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE);
									mapTemp.put(DomainConstants.SELECT_ID, strSubstituteId);
									mapTemp.put(DomainConstants.SELECT_TYPE, strSubstituteType);

									mapTemp.put(DomainConstants.SELECT_REVISION, (String)substituteRevs.get(iSub));
									mapTemp.put(DomainConstants.SELECT_CURRENT, (String)slsubstituteCurrent.get(iSub));
									mapTemp.put(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE, (String)slSubstituteEffectivityDate.get(iSub));
									mapTemp.put(ConstantsUtil.ATTR_VALID_UNTIL_DATE, (String)slSubstituteValidUntilDate.get(iSub));
									mapTemp.put(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT, (String)slSubstituteOptComponent.get(iSub));
									mapTemp.put(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT, (String)slSubstituteComment.get(iSub));
									mapTemp.put("level", strLevel);
									mlFlatBOM.add(mapTemp);

									if(UIUtil.isNotNullAndNotEmpty(strSubstituteType) && strAlternateAllowedTypes.contains(strSubstituteType)){
										mlSubAlts= getAlternates(context, strSubstituteId);
										iAltsSize = mlSubAlts.size();
										for(int i=0;i<iAltsSize;i++){
											mpAltMap = (Map) mlSubAlts.get(i);
											mpAltMap.put(DomainConstants.SELECT_RELATIONSHIP_ID, (String)slsubstituteRelID.get(iSub));
											mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
											mpAltMap.put("IntermediateName", strName+"."+strRev);
											mpAltMap.put("IntermediateID", strID);
											mpAltMap.put("IntermediateType", strObjectType);
											mpAltMap.put("IntermediateLevel", strLevel);
											mlFlatBOM.add(mpAltMap);
										}
									}
								}
							}
						}

					}
				}
				if (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strTopNodeType)) {
					mpTUPDATA = getPartBOMFEEDData(context,IPSId,strTopNodeType);
				}

				Map mParamList = new  HashMap();
				mParamList.put("objectId", IPSId);
				Map hmArgMapParams = new HashMap();		
				hmArgMapParams.put("objectList", mlFlatBOM); 
				hmArgMapParams.put("paramList", mParamList);
				String strCalcQTY = null;


				if((null!=mlFlatBOM && mlFlatBOM.size()>0) || (null!=mlReleasedFPP && mlReleasedFPP.size()>0)) {
					if (ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strTopNodeType) && ("IT".equalsIgnoreCase(strBUOM) || "MP".equalsIgnoreCase(strBUOM) || "BP".equalsIgnoreCase(strBUOM) || "SW".equalsIgnoreCase(strBUOM) || "SP".equalsIgnoreCase(strBUOM))) {
						Map mpBOMQTY = getBOMQTYDataFPP(context,hmArgMapParams,isReshipperSub,slSubstituteInterIdReshipper,strBUOM);
						fIntermediateSAPQty = (float) mpBOMQTY.get("fIntermediateSAPQty");
						strListQty = (StringList)mpBOMQTY.get("strListQtyValues");
					}else if(!isReshipperSub){
						strListQty = getQuantityValue(context,IPSId,mlFlatBOM);
					}
					if (null!=mpTUPDATA && mpTUPDATA.size()>0) {
						mlFlatBOM.addAll(mpTUPDATA);
						strListQty.addAll(getTUPBOMQTYData(context,IPSId,mpTUPDATA,fIntermediateSAPQty,strBUOM));
					}
					if(null!=mlReleasedFPP && mlReleasedFPP.size()>0){
						mlFlatBOM.addAll(mlReleasedFPP);
						strListQty.addAll(slReleaseFPPQTY);
					}
					slSubstituteGroupValues = getSubstituteGroupValue(context,IPSId,mlFlatBOM);
				} else if (null!=mpTUPDATA && mpTUPDATA.size()>0) {
					strListQty = getTUPBOMQTYData(context,IPSId,mpTUPDATA,fIntermediateSAPQty,strBUOM);
					slSubstituteGroupValues = getSubstituteGroupValue(context,IPSId,mpTUPDATA);
					mlFlatBOM = mpTUPDATA;
				}
				
				if(null != mlFlatBOM) {
					int iSizeFlatBOM	= mlFlatBOM.size();
					if(null != strListQty && iSizeFlatBOM == strListQty.size()) {
						for (int i=0;iSizeFlatBOM>i;i++) {
							mpBOM			= (Map)mlFlatBOM.get(i);
							strType			= (String)mpBOM.get(DomainObject.SELECT_TYPE);

							if(!(strDONOTINCLUDETYPE.contains(strType))) {
								strFindNumb				= (String)mpBOM.get(DomainConstants.SELECT_ATTRIBUTE_FIND_NUMBER);
								strEffectivityDateChild	= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
								strValidUntilDate	= (String)mpBOM.get(ConstantsUtil.ATTR_VALID_UNTIL_DATE);
								sChildName				= (String)mpBOM.get(DomainConstants.SELECT_NAME);
								sQuantity				= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
								strMax					= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
								strMin					= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
								sTarget					= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
								strPosInd				= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
								strFILBaseQty			= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
								strID 					= (String)mpBOM.get(DomainObject.SELECT_ID); 
								strObjectType 			= (String)mpBOM.get(DomainConstants.SELECT_TYPE);
								strSAPType				= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
								strQtyTmp  				= (String)strListQty.get(i); 
								strGroupTmp  			= (String)slSubstituteGroupValues.get(i);
								String strRelID 		= (String)mpBOM.get(DomainConstants.SELECT_RELATIONSHIP_ID); 
								strOptComponent			= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
								strComment			= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
								//SPEC: 11/03/2020: Modified for Defect:37014 -- START
								if(!ConstantsUtil.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSAPType) && !strObjectType.contains(ConstantsUtil.TYPE_MASTER))  {
								//SPEC: 11/03/2020: Modified for Defect:37014 -- END
									
									arrBOM 	= buildBOMArray ( strTopNodeName,  strFindNumb,
											strEffectivityDateChild,
											sChildName,  strQtyTmp,
											strMax,  sTarget,  strMin,
											strTopNodeEffeDate, 
											strTopNodeBOMQty,  strPosInd, strFILBaseQty, strpgPhaseBOMQty, strGroupTmp,strID,strOptComponent,strComment,
											"","","", strValidUntilDate);
									
									arrBOM[ConstantsUtil.INDEX_TPU_ID] = (String)mpBOM.get("TUP_ID");
									//SPEC: 11/06/2020: Modified for Defect:37257 -- START
									arrBOM[ConstantsUtil.INDEX_TPU_TYPE] = (String)mpBOM.get("TUP_Type");
									arrBOM[ConstantsUtil.INDEX_TPU_NAME] = (String)mpBOM.get("TUP_Name");
									//SPEC: 11/06/2020: Modified for Defect:37257 -- START
									
									alBOM.add(arrBOM);
								}
							}
						}
					}
				}	
			} 
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return alBOM;
	}

	/**
	 * Gets EBOM, Substitutes and Alternate of Fabricated Part, Assembled Product Part and Devise Product Part.
	 * @param context
	 * @param strObjectID: Object Id
	 * @arg object details
	 * @return Maplist of BOM FEED
	 * @throws Exception
	 */
	public ArrayList getPartObjectsFromBOM(Context context, String  strObjectID) throws Exception {
		ArrayList alBOM = new ArrayList();
		MapList mlMinMaxQtyValues = new MapList();
		Map mpMinMaxQty = null;
		StringList slSubstituteGroupValues = new StringList(1);
		String strFindNumb				= DomainConstants.EMPTY_STRING;
		String strEffectivityDateChild	= DomainConstants.EMPTY_STRING;

		String strValidUntilDate	= DomainConstants.EMPTY_STRING;

		String sChildName				= DomainConstants.EMPTY_STRING;
		String sQuantity				= DomainConstants.EMPTY_STRING;
		String strMax					= DomainConstants.EMPTY_STRING;
		String strMin					= DomainConstants.EMPTY_STRING;
		String sTarget					= DomainConstants.EMPTY_STRING;
		String strPosInd				= DomainConstants.EMPTY_STRING;
		String strFILBaseQty			= DomainConstants.EMPTY_STRING;
		String strID 					= DomainConstants.EMPTY_STRING;
		String strQtyTmp  				= DomainConstants.EMPTY_STRING;
		String strGroupTmp  			= DomainConstants.EMPTY_STRING;
		String strRelID 				= DomainConstants.EMPTY_STRING;
		String strTopNodeType 			= DomainConstants.EMPTY_STRING;
		String strTopNodeName 			= DomainConstants.EMPTY_STRING;
		String strTopNodeEffeDate 		= DomainConstants.EMPTY_STRING;
		String strTopNodeBOMQty 		= DomainConstants.EMPTY_STRING;
		String strpgPhaseBOMQty			= DomainConstants.EMPTY_STRING;
		String strSAPType				= DomainConstants.EMPTY_STRING;
		String strObjectType			= DomainConstants.EMPTY_STRING;
		String strOptComponent			= DomainConstants.EMPTY_STRING;
		String strComment			= DomainConstants.EMPTY_STRING;
		Map mpBOM = null;
		Map mpNodeDeatails = null;
		String[] arrBOM;
		try {
			if(BusinessUtil.isNotNullOrEmpty(strObjectID)) {
				DomainObject dObjForTopNodePart = DomainObject.newInstance(context, strObjectID);
				mpNodeDeatails 			= dObjForTopNodePart.getInfo(context,SL_OBJECT_INFO_SELECT);
				strTopNodeType 				= (String) mpNodeDeatails.get(DomainConstants.SELECT_TYPE);
				strTopNodeName 				= (String) mpNodeDeatails.get(DomainConstants.SELECT_NAME);
				strTopNodeEffeDate 			= (String) mpNodeDeatails.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				strTopNodeBOMQty 			= (String) mpNodeDeatails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				MapList mlFlatBOM = getPartBOMFEEDData(context, strObjectID,strTopNodeType);
				int iSizeFlatBOM = mlFlatBOM.size();
				if(null!=mlFlatBOM && iSizeFlatBOM>0) {
					mlMinMaxQtyValues = getPartBOMQTYData(context,strObjectID,mlFlatBOM);
					slSubstituteGroupValues = getSubstituteGroupValue(context,strObjectID,mlFlatBOM);
					if(null != mlMinMaxQtyValues && iSizeFlatBOM == mlMinMaxQtyValues.size()) {
						for (int i=0;iSizeFlatBOM>i;i++)
						{
							mpBOM = (Map)mlFlatBOM.get(i);
							strFindNumb				= (String)mpBOM.get(DomainConstants.SELECT_ATTRIBUTE_FIND_NUMBER);
							strEffectivityDateChild	= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);

							strValidUntilDate	= (String)mpBOM.get(ConstantsUtil.ATTR_VALID_UNTIL_DATE);

							sChildName				= (String)mpBOM.get(DomainConstants.SELECT_NAME);
							sQuantity				= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
							mpMinMaxQty = (Map)mlMinMaxQtyValues.get(i);
							strMax					= (String)mpMinMaxQty.get("MaxQty");
							strMin					= (String)mpMinMaxQty.get("MinQty");
							sTarget					= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
							strPosInd				= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
							strFILBaseQty			= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
							strID 					= (String)mpBOM.get(DomainObject.SELECT_ID); 
							strObjectType 			= (String)mpBOM.get(DomainConstants.SELECT_TYPE);
							strSAPType				= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
							strOptComponent			= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
							strComment				= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
							strQtyTmp  				= (String)mpMinMaxQty.get("Qty");
							strGroupTmp  			= (String)slSubstituteGroupValues.get(i);

							if(!ConstantsUtil.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSAPType) && !strObjectType.contains(ConstantsUtil.TYPE_MASTER))  
							{
								arrBOM 					= buildBOMArray ( strTopNodeName,  strFindNumb,
										strEffectivityDateChild,
										sChildName,  strQtyTmp,
										strMax,  sTarget,  strMin,
										strTopNodeEffeDate, 
										strTopNodeBOMQty,  strPosInd, strFILBaseQty, strpgPhaseBOMQty, strGroupTmp,strID, strOptComponent,strComment
										,"","","",strValidUntilDate);
								arrBOM[ConstantsUtil.INDEX_TPU_ID] = (String)mpBOM.get("TUP_ID");
								//SPEC: 11/06/2020: Modified for Defect:37257 -- START
								arrBOM[ConstantsUtil.INDEX_TPU_TYPE] = (String)mpBOM.get("TUP_Type");
								arrBOM[ConstantsUtil.INDEX_TPU_NAME] = (String)mpBOM.get("TUP_Name");
								//SPEC: 11/06/2020: Modified for Defect:37257 -- START
								alBOM.add(arrBOM);
							}

						}
					}
				}
			} 
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return alBOM;
	}

	public MapList getTableData(Context context, ArrayList alPartObjectsWithGroupAndQty) throws Exception {
		MapList mpReturnList = new MapList();
		boolean isContextPushed = false;
		int OBJECT_ID = 27;
		int SUBSTITUTE_FLAG = 14;
		int QUANTITY = 10;
		int FC_MIN_QTY = 23;
		int FC_MAX_QTY = 25;
		int SORT_STRING = 13;
		int TUP_ID = 28;
		int OPT_COMPONENT = 29;
		
		//SPEC 11/05/2020 added for defect:37077 ##--START
		int INDEX_TPU_TYPE = 34;
		int INDEX_TPU_NAME = 35;
		//SPEC 11/05/2020 added for defect: 37077##--END
		
		try {
			StringList slPartSelect = new StringList(7);
			slPartSelect.addElement(DomainConstants.SELECT_NAME);
			slPartSelect.addElement(DomainConstants.SELECT_TYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			slPartSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slPartSelect.addElement(ConstantsUtil.STR_IPCLASS);
			slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.STR_IPCLASS);
			ContextUtil.pushContext(context);
			
			//SPEC 11/05/2020 added for defect: 37150 ##--START
			StringList slRelSelect = new StringList();
			slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
			slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
			slRelSelect.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
			//SPEC 11/05/2020 added for defect: 37150 ##--END
			
			isContextPushed = true;
			if(null != alPartObjectsWithGroupAndQty) 
			{
				int alsize=alPartObjectsWithGroupAndQty.size();
				StringValidatorUtil validator = new StringValidatorUtil();
				String strObjID = null;
				String strSubstitute=null;
				String strBOMQuantity = null;
				String strMin = null;
				String strMax = null;
				String strPosInd = null;
				String strObjectType = null;
				String strSAPUOM = null;
				String strSAPType = null;
				String strPGCSSType = null;
				String strTUPObjID = null;
				String strTransportUnit = null;
				String strIPClass = null;
				String strOptComponent = null;
				DomainObject domObject = null;
				Map mpPartObjectInfo = null;
				int COMMENT = 30;
				
				String strComment = DomainConstants.EMPTY_STRING; 
				String strName = DomainConstants.EMPTY_STRING; 
				String strDescription = DomainConstants.EMPTY_STRING; 
				String strTUPObjName = DomainConstants.EMPTY_STRING; 
				String strTUPObjType = DomainConstants.EMPTY_STRING;
				
				HashMap hmTemp = null;
				for (int i=0; i<alsize; i++) {
					String [] satemp = (String[]) alPartObjectsWithGroupAndQty.get(i);
					strObjID = satemp[OBJECT_ID];
					strSubstitute= satemp[SUBSTITUTE_FLAG];
					strBOMQuantity = satemp[QUANTITY];
					strMin = satemp[FC_MIN_QTY];
					strMax = satemp[FC_MAX_QTY];
					strPosInd = satemp[SORT_STRING];
					strTUPObjID = satemp[TUP_ID];
					String sqty = satemp[ConstantsUtil.INDEX_TARGET] ;	
					strOptComponent = satemp[OPT_COMPONENT];
					domObject = DomainObject.newInstance(context,strObjID);
					mpPartObjectInfo = domObject.getInfo(context, slPartSelect);
					strObjectType = (String)mpPartObjectInfo.get(DomainConstants.SELECT_TYPE);
					strSAPUOM = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
					strSAPType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
					strPGCSSType = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
					strComment = satemp[COMMENT];
					strName = (String)mpPartObjectInfo.get(DomainConstants.SELECT_NAME);
					strDescription = (String)mpPartObjectInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
					strIPClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.STR_IPCLASS));
					String strIPControlClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
					
					//SPEC 11/05/2020 added for defect: 37077##--START
					strTUPObjID = validator.getStringEquivalentForStringList(satemp[TUP_ID]);
					strTUPObjName = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_NAME]);
					strTUPObjType = validator.getStringEquivalentForStringList(satemp[INDEX_TPU_TYPE]);
					//SPEC 11/05/2020 added for defect: 37077##--END
					
					
					boolean bTUPAccess=false;
					if(UIUtil.isNotNullAndNotEmpty(strTUPObjID)){
					 bTUPAccess = checkHasAccess(context,strTUPObjID);
					}
					
					if(!bTUPAccess){
						strTUPObjID=ConstantsUtil.NO_ACCESS;
					}
					//SPEC 11/05/2020 added for defect: ##--START
					MapList mlParentPlantList = getConnectedPlantList(context, strObjID, slRelSelect, null);
					
					StringList	slAVPlantList = new StringList();
					StringList	slAUPlantList = new StringList();
					StringList	slAPPlantList = new StringList();
					if(mlParentPlantList!=null && mlParentPlantList.size()>0)
					{
						for(int ip=0;ip<mlParentPlantList.size();ip++)
						{
							Map mapSAPBOMComponent = (Map)mlParentPlantList.get(ip);
							String	sAVAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOVIEW);
							String	sAUAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOUSE);
							String	sAPAttributeValue = (String)mapSAPBOMComponent.get(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);
							String	sSAPBOMComponentPlantName = (String)mapSAPBOMComponent.get(DomainObject.SELECT_NAME);
							
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAVAttributeValue) && strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAVPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAUAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAUPlantList.add(sSAPBOMComponentPlantName);
							}
							if ((ConstantsUtil.TRUE).equalsIgnoreCase(sAPAttributeValue) && !strObjectType.equals(ConstantsUtil.TYPE_RAWMATERIALPART) || strObjectType.equals(ConstantsUtil.TYPE_PACKAGINGMATERIALPART)){
								slAPPlantList.add(sSAPBOMComponentPlantName);
							}
						}
					}
					
					String	strAVPlantList = DomainConstants.EMPTY_STRING;
					String	strAUPlantList = DomainConstants.EMPTY_STRING;
					String	strAPPlantList = DomainConstants.EMPTY_STRING;
					
					if(slAVPlantList!= null && slAVPlantList.size()>0)
					{
						strAVPlantList = FrameworkUtil.join(slAVPlantList, "&&&");
					}

					if(slAUPlantList!= null && slAUPlantList.size()>0)
					{
						strAUPlantList = FrameworkUtil.join(slAUPlantList, "&&&");
					}
					
					if(slAPPlantList!= null && slAPPlantList.size()>0)
					{
						strAPPlantList = FrameworkUtil.join(slAPPlantList, "&&&");
					}
					
					//SPEC 11/05/2020 added for defect: ##--END
					
					hmTemp = new  HashMap();
					hmTemp.put("id",strObjID);  
					hmTemp.put("type",strObjectType);  
					hmTemp.put("substitute",strSubstitute);
					hmTemp.put("BOMQty",strBOMQuantity);
					hmTemp.put("Min",strMin);
					hmTemp.put("Max",strMax);
					hmTemp.put("PosInd",strPosInd);
					hmTemp.put("SAPUOM",strSAPUOM);
					hmTemp.put("SAPType",strSAPType);
					hmTemp.put("SSType",strPGCSSType);
					hmTemp.put("dispId", strObjID);
					hmTemp.put("OptComponent", strOptComponent);
					hmTemp.put(ConstantsUtil.ATTRIBUTE_COMMENT, strComment);
					hmTemp.put(DomainConstants.SELECT_NAME, strName);
					hmTemp.put(DomainConstants.SELECT_DESCRIPTION, strDescription);
					hmTemp.put(ConstantsUtil.SECURITY, strIPClass);
					hmTemp.put(ConstantsUtil.OBJECTSECURITYCLASS, strIPControlClass);
					
					//SPEC 11/05/2020 added for defect:37150  ##--START
					hmTemp.put(ConstantsUtil.AUTHORIZED, strAVPlantList);
					hmTemp.put(ConstantsUtil.OC, strOptComponent);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOUSE, strAUPlantList);
					hmTemp.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, strAPPlantList);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_TYPE, strTUPObjType);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_NAME, strTUPObjName);
					hmTemp.put(ConstantsUtil.TRANSPORTUNIT_ID, strTUPObjID);					
					//SPEC 11/05/2020 added for defect:37150  ##--END
					
					mpReturnList.add(hmTemp);
				}
			}
			
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.STR_IPCLASS);
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(isContextPushed) {
				ContextUtil.popContext(context);
				isContextPushed = false;
			}
		}
		return mpReturnList;
	}


	public synchronized ArrayList getPartObjectsFromEBOM(Context context,Map mapPartDetails) throws Exception {

		MapList mlPartObjects 				= new MapList();
		ArrayList alPartRelatedObjects 		= new ArrayList();		

		String strType 							= 	DomainConstants.EMPTY_STRING;
		String strName 							= 	DomainConstants.EMPTY_STRING;
		String strRev 							= 	DomainConstants.EMPTY_STRING;
		String strFindNumb						=	DomainConstants.EMPTY_STRING;
		String strEffectivityDate				 	=	DomainConstants.EMPTY_STRING;
		String strParentEffectivityDate					=	DomainConstants.EMPTY_STRING;
		String sChildName						=	DomainConstants.EMPTY_STRING;
		String sQuantity						=	DomainConstants.EMPTY_STRING;
		String strMax							=	DomainConstants.EMPTY_STRING;
		String sTarget							=	DomainConstants.EMPTY_STRING;
		String strMin							=	DomainConstants.EMPTY_STRING;
		String strPosInd						=	DomainConstants.EMPTY_STRING;
		String strFILBaseQty					=	DomainConstants.EMPTY_STRING;
		String strSubstitute 					= 	DomainConstants.EMPTY_STRING;		
		String strBOMQuantity 					= 	DomainConstants.EMPTY_STRING;
		String strSAPName 						= 	DomainConstants.EMPTY_STRING;
		String id 								= 	DomainConstants.EMPTY_STRING;
		String strObjectType					= 	DomainConstants.EMPTY_STRING;
		String strTempSAPType					= 	DomainConstants.EMPTY_STRING;
		String strObjID							= 	DomainConstants.EMPTY_STRING;
		String strChildID						= 	DomainConstants.EMPTY_STRING;
		String strpgPhaseBOMQty					=	DomainConstants.EMPTY_STRING;
		String strOptComponent					=	DomainConstants.EMPTY_STRING;
		String strComment						=	DomainConstants.EMPTY_STRING;
		String strParentBOMBaseQty 				= DomainConstants.EMPTY_STRING;

		try {

			if(null != mapPartDetails && mapPartDetails.size()>0) {

				strType 						= (String)mapPartDetails.get(DomainConstants.SELECT_TYPE);
				strName 						= (String)mapPartDetails.get(DomainConstants.SELECT_NAME);
				strRev 							= (String)mapPartDetails.get(DomainConstants.SELECT_REVISION);
				strParentEffectivityDate		= (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				strParentBOMBaseQty 				= (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);

				HashMap mpPartDataMap 			= new HashMap(); 
				DomainObject dChildObj 			= DomainObject.newInstance(context); 
				Map mAllData					= new HashMap();

				String arrOutput[][] 			= getBOMData(context, mapPartDetails);

				StringList slPartInfo			= new StringList(8);
				slPartInfo.addElement(DomainConstants.SELECT_TYPE);
				slPartInfo.addElement(DomainConstants.SELECT_DESCRIPTION);
				slPartInfo.addElement(DomainConstants.SELECT_NAME);
				slPartInfo.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slPartInfo.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
				slPartInfo.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
				slPartInfo.addElement(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
				slPartInfo.addElement(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);

				if(null != arrOutput && arrOutput.length > 0)
				{
					for(int i=0;i<arrOutput.length;i++)
					{

						mpPartDataMap  			= new HashMap();
						id 						= arrOutput[i][23];
						strSubstitute 			= arrOutput[i][14];		
						strBOMQuantity 			= arrOutput[i][10];
						mpPartDataMap.put(ConstantsUtil.MAP_KEY_BOM_TARGET,arrOutput[i][18]);
						strMin 					= arrOutput[i][19];
						strMax 					= arrOutput[i][17];
						strPosInd 				= arrOutput[i][13];
						strSAPName 				= arrOutput[i][9];


						mpPartDataMap.put(ConstantsUtil.MAP_KEY_ID,arrOutput[i][23]);
						mpPartDataMap.put(ConstantsUtil.MAP_KEY_SUBSTITUTE,strSubstitute);
						mpPartDataMap.put(ConstantsUtil.MAP_KEY_BOMQTY,strBOMQuantity);
						mpPartDataMap.put(ConstantsUtil.MAP_KEY_MIN,strMin);
						mpPartDataMap.put(ConstantsUtil.MAP_KEY_MAX,strMax);
						mpPartDataMap.put(ConstantsUtil.MAP_KEY_POSINDEX,strPosInd);
						mpPartDataMap.put(ConstantsUtil.MAP_KEY_SAPNAME,strSAPName);
						mpPartDataMap.put(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT,arrOutput[i][24]);
						mpPartDataMap.put(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT,arrOutput[i][25]);
						if(BusinessUtil.isNotNullOrEmpty(id)) {

							dChildObj = DomainObject.newInstance(context,id);

							mAllData	= dChildObj.getInfo(context,slPartInfo);

							if(null != mAllData && mAllData.size()>0) {


								strTempSAPType = (String)mAllData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
								strObjectType = (String)mAllData.get(DomainConstants.SELECT_TYPE);
								strEffectivityDate = (String)mAllData.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
								mpPartDataMap.put(ConstantsUtil.MAP_KEY_EFFECTIVITYDATE,strEffectivityDate);
								mpPartDataMap.put(DomainConstants.SELECT_TYPE,strObjectType);
								mpPartDataMap.put(DomainConstants.SELECT_DESCRIPTION,(String)mAllData.get(DomainConstants.SELECT_DESCRIPTION));
								mpPartDataMap.put(ConstantsUtil.MAP_KEY_CHILD, (String)mAllData.get(DomainConstants.SELECT_NAME));
								mpPartDataMap.put(ConstantsUtil.MAP_KEY_SAPUOM,(String)mAllData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE));
								mpPartDataMap.put(ConstantsUtil.MAP_KEY_SAPTYPE,(String)mAllData.get(strTempSAPType));
								mpPartDataMap.put(ConstantsUtil.MAP_KEY_SSTYPE,ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
								mpPartDataMap.put(ConstantsUtil.MAP_KEY_SAPDESC,(String)mAllData.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE));

								mpPartDataMap.put(ConstantsUtil.MAP_KEY_dISPLAYID, arrOutput[i][23]);

								mpPartDataMap.put(ConstantsUtil.MAP_KEY_CHILD_ID, id);

								if(!ConstantsUtil.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strTempSAPType) && !strObjectType.contains(ConstantsUtil.TYPE_MASTER))  {

									mlPartObjects.add(mpPartDataMap);									

								}
							}
						}
					}
				}

				if(mlPartObjects.size()!=0) { 

					int iSizeFlatBOM				=	mlPartObjects.size();
					Map mpBOM					=	new HashMap();

					String[] arrBOM				=	new String[ConstantsUtil.INDEX_BOM_ARRAY_SIZE];

					for(int i=0;iSizeFlatBOM>i;i++) {

						mpBOM=(Map)mlPartObjects.get(i);


						strEffectivityDate		= (String)mpBOM.get(ConstantsUtil.MAP_KEY_EFFECTIVITYDATE);
						sChildName 				= (String)mpBOM.get(ConstantsUtil.MAP_KEY_CHILD);
						sQuantity 				= (String)mpBOM.get(ConstantsUtil.MAP_KEY_BOMQTY);
						sTarget 				= (String)mpBOM.get(ConstantsUtil.MAP_KEY_BOM_TARGET);
						strMin 					= (String)mpBOM.get(ConstantsUtil.MAP_KEY_MIN);
						strMax 					= (String)mpBOM.get(ConstantsUtil.MAP_KEY_MAX);
						strPosInd 				= (String)mpBOM.get(ConstantsUtil.MAP_KEY_POSINDEX);
						strObjID				= (String)mpBOM.get(DomainObject.SELECT_ID);
						strChildID				= (String)mpBOM.get(ConstantsUtil.MAP_KEY_CHILD_ID);
						strOptComponent			= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
						strComment			= (String)mpBOM.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);

						arrBOM = buildBOMArray ( strName,  strFindNumb,strEffectivityDate,sChildName,  sQuantity,strMax,  sTarget,  strMin, strParentEffectivityDate, strParentBOMBaseQty,  strPosInd, strFILBaseQty, strpgPhaseBOMQty, (String)mpBOM.get(ConstantsUtil.MAP_KEY_SUBSTITUTE),strObjID, strOptComponent,strComment,"","","", "");

						alPartRelatedObjects.add(arrBOM);

					}
				}		

			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return alPartRelatedObjects;
	}

	public synchronized ArrayList getObjectsForFOPFromFormulaIngredient(Context context,Map mapPartDetails) throws Exception {


		String[] saPLBOMArray = new String[ConstantsUtil.INDEX_BOM_ARRAY_SIZE];

		ArrayList alPartObjects = new ArrayList();

		Map mpPLBOMData 						= new HashMap();
		DomainObject domPhaseObjectChild 		= null;
		DomainObject doAlternateObj 			= null;

		String 	strName 						= DomainConstants.EMPTY_STRING;

		String 	strID 							= DomainConstants.EMPTY_STRING;
		String 	strBOMBaseQty 					= DomainConstants.EMPTY_STRING;
		String 	strParentEffectivDate			= DomainConstants.EMPTY_STRING;
		String 	RELATIONSHIP_PLANNEDFOR 		= ConstantsUtil.RELATIONSHIP_PLANNEDFOR;
		String 	TYPE_FORMULATIONPROCESS 		= ConstantsUtil.TYPE_FORMULATIONPROCESS;
		String 	TYPE_FORMULATIONPHASE 			= ConstantsUtil.TYPE_FORMULATIONPHASE;
		char 		cAltItem1 					= ConstantsUtil.ALT_ITEM_NINE;		
		char 		cAltItem2 					= ConstantsUtil.ALT_ITEM_A;

		String 	strChildType					= DomainConstants.EMPTY_STRING;
		String 	strChildID						= DomainConstants.EMPTY_STRING;
		String[] 	saChild 					= new String[1]; 

		String strFormulationChildType 			= DomainConstants.EMPTY_STRING;
		String strFormulationChildId 			= DomainConstants.EMPTY_STRING;
		String strFormPhaseChildType 			= DomainConstants.EMPTY_STRING;
		MapList mpListChildren					= new MapList();
		String strParentName					= DomainConstants.EMPTY_STRING;
		String strFindNumber					= DomainConstants.EMPTY_STRING;
		String strEffectivityDateChild			= DomainConstants.EMPTY_STRING;
		String strObjectName					= DomainConstants.EMPTY_STRING;
		String strQuantity						= DomainConstants.EMPTY_STRING;
		String strMax							= DomainConstants.EMPTY_STRING;
		String strTargetQuantity				= DomainConstants.EMPTY_STRING;
		String strMin							= DomainConstants.EMPTY_STRING;
		String strPosInd						= DomainConstants.EMPTY_STRING;
		String strFILBaseQty					= DomainConstants.EMPTY_STRING;
		String strpgPhaseBOMQty					= DomainConstants.EMPTY_STRING;
		String id								= DomainConstants.EMPTY_STRING;
		String strSAPType						= DomainConstants.EMPTY_STRING;
		String strObjectType					= DomainConstants.EMPTY_STRING;
		String strAlternate						= DomainConstants.EMPTY_STRING;
		String strPLBOMRelId 					= DomainConstants.EMPTY_STRING;
		String strSubstitue						= DomainConstants.EMPTY_STRING;
		String strTSName 						= DomainConstants.EMPTY_STRING;
		String strTSType 						= DomainConstants.EMPTY_STRING;
		String strValidFromDateSub 				= DomainConstants.EMPTY_STRING;
		String strQty			 				= DomainConstants.EMPTY_STRING;
		String strGroup			 				= DomainConstants.EMPTY_STRING;
		String[][] saSubs						= new String[1][1];		
		StringList slQtyValues 					= new StringList(1);		
		StringList slSubstituteGroupValues 		= new StringList(1);
		MapList mpListIngredients				= new MapList();


		String 	strChildEffectivDate			= DomainConstants.EMPTY_STRING;

		String strFOPName			 				= DomainConstants.EMPTY_STRING;

		int iCounter = 0;
		String strBaseUOMChild = DomainConstants.EMPTY_STRING;
		String strBaseUOMParent = DomainConstants.EMPTY_STRING;
		String strBaseUOMSub = DomainConstants.EMPTY_STRING;
		String strSubRelID = DomainConstants.EMPTY_STRING;
		String strSelect_SubstitutePartId = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_PLBOMSUBSTITUTE).append("].to.from[").append(ConstantsUtil.RELATIONSHIP_PLBOM).append("].to.id").toString();
		String strSelect_SubstitutePartName = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_PLBOMSUBSTITUTE).append("].to.from[").append(ConstantsUtil.RELATIONSHIP_PLBOM).append("].to.name").toString();
		String strSelect_SubstitutePartType = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_PLBOMSUBSTITUTE).append("].to.from[").append(ConstantsUtil.RELATIONSHIP_PLBOM).append("].to.type").toString();
		String strSelect_SubstituteRelId = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_PLBOMSUBSTITUTE).append("].to.from[").append(ConstantsUtil.RELATIONSHIP_PLBOM).append("].id").toString();
		String strSelect_SubstituteBaseUOM = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_PLBOMSUBSTITUTE).append("].to.from[").append(ConstantsUtil.RELATIONSHIP_PLBOM).append("].to.").append(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE).toString();
		String strSelect_Substitute_EffectivityDate = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_PLBOMSUBSTITUTE).append("].to.from[").append(ConstantsUtil.RELATIONSHIP_PLBOM).append("].to.").append(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE).toString();
		String strSelect_Substitute_FormulationType = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_PLBOMSUBSTITUTE).append("].to.from[").append(ConstantsUtil.RELATIONSHIP_PLBOM).append("].to.to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE).toString();
		String sChildFormulationType = DomainConstants.EMPTY_STRING;
		String strChildSubFormulationType = DomainConstants.EMPTY_STRING;
		String strSelect_AlternateId = new StringBuffer("from[").append(DomainConstants.RELATIONSHIP_ALTERNATE).append("].to.id").toString();
		String strSelect_AlternateType = new StringBuffer("from[").append(DomainConstants.RELATIONSHIP_ALTERNATE).append("].to.type").toString();
		String strSelect_AlternateName = new StringBuffer("from[").append(DomainConstants.RELATIONSHIP_ALTERNATE).append("].to.name").toString();
		String strSelect_Alternate_Eff_Date = new StringBuffer("from[").append(DomainConstants.RELATIONSHIP_ALTERNATE).append("].to.").append(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE).toString();
		String strSelect_Alternate_BaseUOM = new StringBuffer("from[").append(DomainConstants.RELATIONSHIP_ALTERNATE).append("].to.").append(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE).toString();
		String strAlternateBaseUOM = DomainConstants.EMPTY_STRING;
		String strNONGCASTYPE = EnoviaResourceBundle.getProperty (context, "emxCPN", context.getLocale(), "emxCPN.SAPBOM.DSM.NONGCASTypes");
		String strObjectWhere = new StringBuffer(DomainObject.SELECT_CURRENT).append( " != ").append(ConstantsUtil.STATE_PART_OBSOLETE).toString();
		String strFOPNextRev = DomainConstants.EMPTY_STRING;			
		MapList mlSubAlts = null;
		int iAltsSize = 0;
		String strAltId = DomainConstants.EMPTY_STRING;
		String strAltName = DomainConstants.EMPTY_STRING;
		String strAltEffDate = DomainConstants.EMPTY_STRING;
		String strSubQuantity = DomainConstants.EMPTY_STRING;
		String strSubMaxQty = DomainConstants.EMPTY_STRING;
		String strSubMinQty = DomainConstants.EMPTY_STRING;
		String strAlternateMin = DomainConstants.EMPTY_STRING;
		String strAlternateMax = DomainConstants.EMPTY_STRING;
		String strAlternateQTY = DomainConstants.EMPTY_STRING;

		try {
			if(null != mapPartDetails && mapPartDetails.size()>0) {
				strID 				= (String)mapPartDetails.get(DomainConstants.SELECT_ID);
				strFOPName 			= (String)mapPartDetails.get(DomainConstants.SELECT_NAME);
				strBOMBaseQty 		= (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				strParentEffectivDate	= (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				strBaseUOMParent	= (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				if(BusinessUtil.isNotNullOrEmpty(strID)) {
					strFOPNextRev	= (String)mapPartDetails.get("next.id");
					mpListChildren = getValidFormulationProcess(context, strID, strFOPNextRev);

					if(null != mpListChildren && mpListChildren.size()>0) {

						int iChildrenSize 				= mpListChildren.size();
						Map mpTempChildData 			= new HashMap();
						DomainObject domObjectChild 	= DomainObject.newInstance(context);

						MapList mlPLBOMParts 			= new MapList();

						String strActualWeightDry		= DomainConstants.EMPTY_STRING;
						String strActualPercentDry		= DomainConstants.EMPTY_STRING;
						String strActualWeightWet		= DomainConstants.EMPTY_STRING;
						String strActualPercentWet		= DomainConstants.EMPTY_STRING;
						String strLoss2					= DomainConstants.EMPTY_STRING;
						double dTotal_Dry_Weight 			= 0.0;
						double dFOP_Percent 				= 100;
						double dFOP_Loss					= 0.0;
						double dFOP_Actual_Weight_Wet    	= 0.0;
						double dFOP_Loss_Percent    		= 0.0;


						for (int i=0;i<iChildrenSize;i++) {

							mpTempChildData = (Map)mpListChildren.get(i);
							strChildType 	= (String) mpTempChildData.get(DomainConstants.SELECT_TYPE);
							strChildID 		= (String) mpTempChildData.get(DomainConstants.SELECT_ID);

							if(TYPE_FORMULATIONPROCESS.equalsIgnoreCase(strChildType)){

								strActualWeightDry 	= (String) mpTempChildData.get(ConstantsUtil.SELECT_ATTRIBUTE_ACTUAL_WEIGHT_DRY);
								strActualPercentDry = (String) mpTempChildData.get(ConstantsUtil.SELECT_ATTRIBUTE_ACTUAL_PERCENT_DRY);
								strActualWeightWet 	= (String) mpTempChildData.get(ConstantsUtil.SELECT_ATTRIBUTE_ACTUAL_WEIGHT_WET);
								strActualPercentWet = (String) mpTempChildData.get(ConstantsUtil.SELECT_ATTRIBUTE_ACTUAL_PERCENT_WET);

								if(BusinessUtil.isNotNullOrEmpty(strChildID)) {

									domObjectChild = DomainObject.newInstance(context, strChildID);

									if(null != domObjectChild) {


										MapList mlPhases =  domObjectChild.getRelatedObjects(context,
												ConstantsUtil.RELATIONSHIP_PLBOM, 	//relationshipPattern
												ConstantsUtil.SYMBL_ASTERISK, 			//typePattern
												false, 								//getTo
												true, 								//getFrom
												(short)1, 							//recurseToLevel
												SL_FOP_OBJECT_INFO_SELECT, 			//objectSelects
												SL_RELATION_INFO_SELECT_OTHERS, 	//relationshipSelects
												strObjectWhere, 					//objectWhere
												null, 								//relationshipWhere
												null,								//PostRelPattern
												null,			//PostTypePattern
												null);

										if(mlPhases != null && mlPhases.size()>0) {

											Collections.sort(mlPhases, new Comparator() {					
												public int compare(Object first,
														Object second) {
													Map firstMap = (Map) first;
													Map secondMap = (Map) second;
													String firstValue = (String) (firstMap.get(DomainConstants.SELECT_NAME));
													String secondValue = (String) secondMap.get(DomainConstants.SELECT_NAME);

													return firstValue.compareTo(secondValue);
												}
											} );

											for(int l=0; l<mlPhases.size();l++) {


												Map phaseInfo = (Map) mlPhases.get(l);
												String phaseId = (String) phaseInfo.get(DomainConstants.SELECT_ID);
												DomainObject domPhase = DomainObject.newInstance(context, phaseId);

												mlPLBOMParts =  domPhase.getRelatedObjects(context,
														ConstantsUtil.RELATIONSHIP_PLBOM, 	//relationshipPattern
														ConstantsUtil.SYMBL_ASTERISK, 			//typePattern
														false, 								//getTo
														true, 								//getFrom
														(short)2, 							//recurseToLevel
														SL_FOP_OBJECT_INFO_SELECT, 			//objectSelects
														SL_RELATION_INFO_SELECT_OTHERS, 	//relationshipSelects
														strObjectWhere, 					//objectWhere
														null, 								//relationshipWhere
														null,								//PostRelPattern
														null,			//PostTypePattern
														null);
												if(null != mlPLBOMParts && mlPLBOMParts.size()>0) {

													int iPLBOMSize = mlPLBOMParts.size();

													String strMaxWet = DomainConstants.EMPTY_STRING;
													String strMinWet = DomainConstants.EMPTY_STRING;
													String strLoss = DomainConstants.EMPTY_STRING;
													String strQty2 = DomainConstants.EMPTY_STRING;
													String strFindNumber2 = DomainConstants.EMPTY_STRING;
													String strFindNumb = DomainConstants.EMPTY_STRING;
													String sChildName = DomainConstants.EMPTY_STRING;
													String strTempSAPType = DomainConstants.EMPTY_STRING;
													String sQuantity = DomainConstants.EMPTY_STRING;
													String sTarget = DomainConstants.EMPTY_STRING;
													String strQtyTmp = DomainConstants.EMPTY_STRING;
													String strGroupTmp = DomainConstants.EMPTY_STRING;
													String strFOPChildID = DomainConstants.EMPTY_STRING;
													String strFOPChildType = DomainConstants.EMPTY_STRING;

													String strTargetDryWeight = DomainConstants.EMPTY_STRING;
													String strTargetWetWeight = DomainConstants.EMPTY_STRING;

													String strBOMType = "";
													String strBOMName = "";
													DomainObject doRMP = DomainObject.newInstance(context);
													MapList mpListBOMChildren = new MapList();


													Map mpReturned = null; 

													StringList  slAltType = new StringList(1);
													StringList slAltName = new StringList(1);
													StringList slAltID = new StringList(1);
													for(int j=0;j<iPLBOMSize;j++) {
														strMaxWet 		= DomainConstants.EMPTY_STRING;
														strMinWet 		= DomainConstants.EMPTY_STRING;
														strLoss 		= DomainConstants.EMPTY_STRING;
														strQty2 		= DomainConstants.EMPTY_STRING;
														strFindNumber2 	= DomainConstants.EMPTY_STRING;
														mpPLBOMData = (Map)mlPLBOMParts.get(j);
														strTempSAPType			= (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
														strFormulationChildType = (String) mpPLBOMData.get(DomainConstants.SELECT_TYPE);

														Object OChildFormulationType = (Object)mpPLBOMData.get("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);

														StringList slChildFormulationType = new StringList();

														if (null != OChildFormulationType) {
															if (OChildFormulationType instanceof StringList) {
																slChildFormulationType = (StringList) OChildFormulationType;
															} else if (OChildFormulationType instanceof String){
																slChildFormulationType.add(OChildFormulationType.toString());
															}
														}


														if((!(ConstantsUtil.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strTempSAPType)) && !(strNONGCASTYPE.contains(strFormulationChildType))) && (!ConstantsUtil.TYPE_FORMULATIONPART.equals(strFormulationChildType) || (ConstantsUtil.TYPE_FORMULATIONPART.equals(strFormulationChildType) && !slChildFormulationType.isEmpty() && !slChildFormulationType.contains(ConstantsUtil.THIRD_PARTY_FORMULA)))) {
															strFormulationChildId	= (String) mpPLBOMData.get(DomainConstants.SELECT_ID);
															strChildEffectivDate	= (String) mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
															strFindNumb				= (String)mpPLBOMData.get(DomainConstants.SELECT_ATTRIBUTE_FIND_NUMBER);
															strEffectivityDateChild	= (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
															sChildName				= (String)mpPLBOMData.get(DomainConstants.SELECT_NAME);
															sQuantity				= (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
															strMax					= (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
															strMin					= (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
															sTarget					= (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
															strPosInd				= (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR);
															strFILBaseQty			= (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
															strID 					= (String)mpPLBOMData.get(DomainObject.SELECT_ID); 
															strBaseUOMChild			= (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
															strQtyTmp  				= strQty2;
															strPLBOMRelId 			= (String)mpPLBOMData.get(DomainRelationship.SELECT_ID);
															strBOMType = "";
															strBOMName = "";

															strTargetDryWeight = (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
															strTargetWetWeight = (String)mpPLBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);

															if(BusinessUtil.isNotNullOrEmpty(strFormulationChildId)) {

																Object oSubstituteId  = (Object) mpPLBOMData.get(strSelect_SubstitutePartId);
																StringList slSubstituteId = new StringList();
																if (null != oSubstituteId) {
																	if (oSubstituteId instanceof StringList) {
																		slSubstituteId = (StringList) oSubstituteId;
																	} else {
																		slSubstituteId.add(oSubstituteId.toString());
																	}
																}
																Object oSubstituteType  = (Object) mpPLBOMData.get(strSelect_SubstitutePartType);
																StringList slSubstituteType = new StringList();
																if (null != oSubstituteType) {
																	if (oSubstituteType instanceof StringList) {
																		slSubstituteType = (StringList) oSubstituteType;
																	} else {
																		slSubstituteType.add(oSubstituteType.toString());
																	}
																}
																Object oSubstituteName  = (Object) mpPLBOMData.get(strSelect_SubstitutePartName);
																StringList slSubstituteName = new StringList();
																if (null != oSubstituteName) {
																	if (oSubstituteName instanceof StringList) {
																		slSubstituteName = (StringList) oSubstituteName;
																	} else {
																		slSubstituteName.add(oSubstituteName.toString());
																	}
																}
																Object oSubstituteBaseUOM  = (Object) mpPLBOMData.get(strSelect_SubstituteBaseUOM);
																StringList slSubstituteBaseUOM = new StringList();
																if (null != oSubstituteBaseUOM) {
																	if (oSubstituteBaseUOM instanceof StringList) {
																		slSubstituteBaseUOM = (StringList) oSubstituteBaseUOM;
																	} else {
																		slSubstituteBaseUOM.add(oSubstituteBaseUOM.toString());
																	}
																}
																Object substituteEffectivityDate = (Object) mpPLBOMData.get(strSelect_Substitute_EffectivityDate);
																StringList slSubstituteEffectivityDate = new StringList();
																if (null != substituteEffectivityDate) {
																	if (substituteEffectivityDate instanceof StringList) {
																		slSubstituteEffectivityDate = (StringList) substituteEffectivityDate;
																	} else {
																		slSubstituteEffectivityDate.add(substituteEffectivityDate.toString());
																	}
																} 
																Object oSubstituteRelID  = (Object) mpPLBOMData.get(strSelect_SubstituteRelId);
																StringList slSubstituteRelID = new StringList();
																if (null != oSubstituteRelID) {
																	if (oSubstituteRelID instanceof StringList) {
																		slSubstituteRelID = (StringList) oSubstituteRelID;
																	} else {
																		slSubstituteRelID.add(oSubstituteRelID.toString());
																	}
																}
																Object substituteFormulationType = (Object) mpPLBOMData.get(strSelect_Substitute_FormulationType);
																StringList slSubstituteFormulationType = new StringList();
																if (null != substituteFormulationType) {
																	if (substituteFormulationType instanceof StringList) {
																		slSubstituteFormulationType = (StringList) substituteFormulationType;
																	} else {
																		slSubstituteFormulationType.add(substituteFormulationType.toString());
																	}
																} 
																Object oAlternateId = (Object) mpPLBOMData.get(strSelect_AlternateId);
																StringList slAlternateId = new StringList();
																if (null != oAlternateId) {
																	if (oAlternateId instanceof StringList) {
																		slAlternateId = (StringList) oAlternateId;
																	} else {
																		slAlternateId.add(oAlternateId.toString());
																	}
																}
																Object oAlternateType = (Object) mpPLBOMData.get(strSelect_AlternateType);
																StringList slAlternateType = new StringList();
																if (null != oAlternateType) {
																	if (oAlternateType instanceof StringList) {
																		slAlternateType = (StringList) oAlternateType;
																	} else {
																		slAlternateType.add(oAlternateType.toString());
																	}
																}
																Object oAlternateName = (Object) mpPLBOMData.get(strSelect_AlternateName);
																StringList slAlternateName = new StringList();
																if (null != oAlternateName) {
																	if (oAlternateName instanceof StringList) {
																		slAlternateName = (StringList) oAlternateName;
																	} else {
																		slAlternateName.add(oAlternateName.toString());
																	}
																}
																Object oAlternateEffDate = (Object) mpPLBOMData.get(strSelect_Alternate_Eff_Date);
																StringList slAlternateEffDate = new StringList();
																if (null != oAlternateEffDate) {
																	if (oAlternateEffDate instanceof StringList) {
																		slAlternateEffDate = (StringList) oAlternateEffDate;
																	} else {
																		slAlternateEffDate.add(oAlternateEffDate.toString());
																	}
																}
																Object oAlternateBaseUOM  = (Object) mpPLBOMData.get(strSelect_Alternate_BaseUOM);
																StringList slAlternateBaseUOM = new StringList();
																if (null != oAlternateBaseUOM) {
																	if (oAlternateBaseUOM instanceof StringList) {
																		slAlternateBaseUOM = (StringList) oAlternateBaseUOM;
																	} else {
																		slAlternateBaseUOM.add(oAlternateBaseUOM.toString());
																	}
																}
																if((null != slSubstituteId && slSubstituteId.size()>0) || (null != slAlternateId && slAlternateId.size()>0)) {
																	if(iCounter > 0) {
																		if (cAltItem2 == 'Z') {
																			cAltItem2 = 'A';
																			cAltItem1--;
																		} else {
																			cAltItem2++;
																		}
																	}
																	iCounter++ ;
																	strGroupTmp = cAltItem1 + "" + cAltItem2;
																} else {
																	strGroupTmp = DomainConstants.EMPTY_STRING;
																}
																StringList slMinMaxQty_Primary = calculateMaxMinQtyForFOPChild(context,strPLBOMRelId,strBOMBaseQty,strBaseUOMParent, strBaseUOMChild,false);
																saPLBOMArray=	buildBOMArray(strFOPName , strFindNumber,strEffectivityDateChild, sChildName, (String)slMinMaxQty_Primary.get(2),(String)slMinMaxQty_Primary.get(1), "",(String)slMinMaxQty_Primary.get(0), strParentEffectivDate, strBOMBaseQty,"", "","",strGroupTmp,strFormulationChildId,"","", strTargetWetWeight,strTargetDryWeight, "True", "");
																alPartObjects.add(saPLBOMArray);
																if(null != slAlternateId) {
																	String strAlternateType = DomainConstants.EMPTY_STRING;
																	String strAlternateName = DomainConstants.EMPTY_STRING;
																	String strAlternateID = DomainConstants.EMPTY_STRING;
																	String strAlternateEffDate = DomainConstants.EMPTY_STRING;
																	for(int kk=0;kk<slAlternateId.size();kk++) {
																		strAlternateType= (String)slAlternateType.get(kk);
																		strAlternateName = (String)slAlternateName.get(kk); 
																		strAlternateID = (String)slAlternateId.get(kk); 
																		strAlternateEffDate = (String)slAlternateEffDate.get(kk);

																		String[] saTemp2 = new String[ConstantsUtil.INDEX_BOM_ARRAY_SIZE]; 												//Modified by DSM(Sogeti) - for 2015x.4 BOM eDelivery defect 12826,12829 - Starts	
																		strAlternateBaseUOM = (String)slAlternateBaseUOM.get(kk);
																		strAlternateMin = (String)slMinMaxQty_Primary.get(0);
																		strAlternateMax = (String)slMinMaxQty_Primary.get(1);
																		strAlternateQTY = (String)slMinMaxQty_Primary.get(2);
																		if(BusinessUtil.isNotNullOrEmpty(strBaseUOMParent) || BusinessUtil.isNotNullOrEmpty(strAlternateBaseUOM) || !strBaseUOMParent.equalsIgnoreCase(strAlternateBaseUOM) )
																		{
																			strAlternateMin = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
																			strAlternateMax = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
																			strAlternateQTY = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
																		}
																		saTemp2=	buildBOMArray(strFOPName , strFindNumber,strAlternateEffDate, strAlternateName, strAlternateQTY,strAlternateMax, "",strAlternateMin, strParentEffectivDate, strBOMBaseQty,"", "","",strGroupTmp,strAlternateID,"","", "", "","", "");
																		alPartObjects.add(saTemp2);
																	}
																}
																if(null != slSubstituteId) {
																	int iFormulationTypeSize=slSubstituteFormulationType.size();
																	int iCounterFormulation=0;
																	for(int pp=0;pp<slSubstituteId.size();pp++) {
																		strBOMType = (String)slSubstituteType.get(pp);
																		if(ConstantsUtil.TYPE_FORMULATIONPART.equals(strBOMType) && (iCounterFormulation<iFormulationTypeSize)){
																			strChildSubFormulationType = (String) slSubstituteFormulationType.get(iCounterFormulation);
																			iCounterFormulation++;
																		}
																		else 
																			strChildSubFormulationType = DomainConstants.EMPTY_STRING;
																		if(!ConstantsUtil.TYPE_FORMULATIONPART.equals(strBOMType) || (ConstantsUtil.TYPE_FORMULATIONPART.equals(strBOMType) && UIUtil.isNotNullAndNotEmpty(strChildSubFormulationType) && !ConstantsUtil.THIRD_PARTY_FORMULA.equals(strChildSubFormulationType))){
																			strBOMName = (String)slSubstituteName.get(pp); 
																			strBaseUOMSub = (String)slSubstituteBaseUOM.get(pp);
																			strEffectivityDateChild = (String)slSubstituteEffectivityDate.get(pp);
																			strSubRelID = (String)slSubstituteRelID.get(pp); 
																			String strBOMIdName = (String)slSubstituteId.get(pp);


																			String[] saTemp = new String[ConstantsUtil.INDEX_BOM_ARRAY_SIZE]; 
																			StringList slMinMaxQty = calculateMaxMinQtyForFOPChild(context,strSubRelID,strBOMBaseQty,strBaseUOMParent, strBaseUOMSub,true);
																			strSubQuantity = (String)slMinMaxQty.get(2);
																			strSubMaxQty = (String)slMinMaxQty.get(1);
																			strSubMinQty = (String)slMinMaxQty.get(0);

																			saTemp=	buildBOMArray(strFOPName , strFindNumber,strEffectivityDateChild, strBOMName, strSubQuantity,strSubMaxQty, "",strSubMinQty, strParentEffectivDate, strBOMBaseQty,"", "","",strGroupTmp,strBOMIdName,"","", "", "","", "");

																			alPartObjects.add(saTemp);

																			if(UIUtil.isNotNullAndNotEmpty(strBOMType) && strAlternateAllowedTypes.contains(strBOMType)){
																				mlSubAlts= getAlternates(context,
																						strBOMIdName);
																				iAltsSize = mlSubAlts.size();
																				for(int k=0;k<iAltsSize;k++){
																					Map mpAltMap = (Map) mlSubAlts.get(k);
																					strAltId = (String) mpAltMap.get(DomainConstants.SELECT_ID);
																					strAltName = (String) mpAltMap.get(DomainConstants.SELECT_NAME);
																					strAltEffDate = (String) mpAltMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
																					strAlternateBaseUOM = (String) mpAltMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
																					strAlternateMin = strSubMinQty;
																					strAlternateMax = strSubMaxQty;
																					strAlternateQTY = strSubQuantity;
																					if(BusinessUtil.isNotNullOrEmpty(strBaseUOMParent) || BusinessUtil.isNotNullOrEmpty(strAlternateBaseUOM) || !strBaseUOMParent.equalsIgnoreCase(strAlternateBaseUOM) )
																					{
																						strAlternateMin = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
																						strAlternateMax = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
																						strAlternateQTY = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
																					}

																					saTemp = new String[ConstantsUtil.INDEX_BOM_ARRAY_SIZE];
																					saTemp=	buildBOMArray(strFOPName , strFindNumber,strAltEffDate, strAltName, strAlternateQTY,strAlternateMax, "",strAlternateMin, strParentEffectivDate, strBOMBaseQty,"", "","",strGroupTmp,strAltId,"","", "", "","", "");
																					alPartObjects.add(saTemp);
																				}
																			}
																		}
																	}
																}
															}
														}
													} 

												}

											} 
										}
									}	
								}
							}
						}
					}
				}
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return alPartObjects;
	}


	public String[][] getBOMData(Context context, Map mapPartDetails) {

		String[][] saBOM = null;
		String strValidFromDate = DomainConstants.EMPTY_STRING;
		String strBOMBaseQty = DomainConstants.EMPTY_STRING;
		String strStatus = DomainConstants.EMPTY_STRING;
		String strBOMUsage = DomainConstants.EMPTY_STRING;
		String strObjectID = DomainConstants.EMPTY_STRING;
		String strObjectName = DomainConstants.EMPTY_STRING;
		String strObjectRev = DomainConstants.EMPTY_STRING;
		String strChildType = DomainConstants.EMPTY_STRING;
		String strChildName = DomainConstants.EMPTY_STRING;
		String strChildRev = DomainConstants.EMPTY_STRING;
		String strPgFPC = DomainConstants.EMPTY_STRING;
		String strChildObjID = DomainConstants.EMPTY_STRING;
		String strFindNumber = DomainConstants.EMPTY_STRING;
		String strRelId = DomainConstants.EMPTY_STRING;
		String strQuantity = DomainConstants.EMPTY_STRING;
		String strTarget = DomainConstants.EMPTY_STRING;
		String strLowerLim = DomainConstants.EMPTY_STRING;
		String strUpperLim = DomainConstants.EMPTY_STRING;
		String strPosIndicator = DomainConstants.EMPTY_STRING;
		String strOptComponent = DomainConstants.EMPTY_STRING;
		String strComment = DomainConstants.EMPTY_STRING;
		String strValidFromDateComp = DomainConstants.EMPTY_STRING;
		String strSubstFlag = DomainConstants.EMPTY_STRING;
		String strBOMNumber = DomainConstants.EMPTY_STRING;
		String strComponentNumber = DomainConstants.EMPTY_STRING;
		String strPhaseName = DomainConstants.EMPTY_STRING;
		String strPhaseObjID = DomainConstants.EMPTY_STRING;
		DomainObject dObjPhase = null;
		MapList mlPhaseChildObjList = null;
		MapList mlFirstLevelData = null;
		Map hmPhaseMap = null;
		Map hmPhaseChildMap = null;
		String strChildBUOM = DomainConstants.EMPTY_STRING;
		try {
			strObjectName = (String)mapPartDetails.get(DomainConstants.SELECT_NAME);
			strObjectRev = (String)mapPartDetails.get(DomainConstants.SELECT_REVISION);
			strObjectID = (String)mapPartDetails.get(DomainConstants.SELECT_ID);
			DomainObject dObjForTopNodePart = DomainObject.newInstance(context, strObjectID);

			strBOMBaseQty = (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			strStatus = (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
			strParentBUOM = (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			strParentType = (String)mapPartDetails.get(DomainConstants.SELECT_TYPE);
			if (strStatus.equals(ConstantsUtil.RANGE_ATTRIBUTE_STATUS_PLANNING))
				strBOMUsage = "2";
			else if (!strStatus.equals(ConstantsUtil.RANGE_ATTRIBUTE_PGBOMBASEQUANTITY_EXPERIMENTAL)) 
				strBOMUsage = "3";

			strValidFromDate = (String)mapPartDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			strValidFromDate = convertPLMDateToSAP(strValidFromDate);

			_ParentMatlNumber = strObjectName;
			strParentRev = strObjectRev;

			StringList slPhaseBusSelect = new StringList(2);
			slPhaseBusSelect.add(DomainConstants.SELECT_NAME);
			slPhaseBusSelect.add(DomainConstants.SELECT_ID);

			mlFirstLevelData = dObjForTopNodePart.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_EBOM, 	// rel pattern
					ConstantsUtil.TYPE_PGPHASE,         // type pattern
					//SL_OBJECT_INFO_SELECT,         	// object select
					slPhaseBusSelect,
					//SL_RELATION_INFO_SELECT_EBOM,   // rel select
					null,
					false,                  			// to side
					true,                   			// from side 
					(short)1,               			// recursion level
					DomainConstants.EMPTY_STRING,       // object where clause
					DomainConstants.EMPTY_STRING,0); 
			Iterator itr = mlFirstLevelData.iterator();
			String[] saBOMRow = null;
			while (itr.hasNext()) {

				hmPhaseMap = (Hashtable) itr.next();

				strPhaseName = (String)hmPhaseMap.get(DomainConstants.SELECT_NAME);
				strPhaseObjID = (String)hmPhaseMap.get(DomainConstants.SELECT_ID);
				dObjPhase = DomainObject.newInstance(context, strPhaseObjID);

				Pattern pgPhaseExpTypePattern = new Pattern(ConstantsUtil.TYPE_PGFINISHEDPRODUCT);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_PGRAWMATERIAL);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_PGPACKINGMATERIAL);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_FINISHEDPRODUCTPART);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_PACKAGINGASSEMBLYPART);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_FORMULATIONPART);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_PACKAGINGMATERIALPART);
				pgPhaseExpTypePattern.addPattern(ConstantsUtil.TYPE_RAWMATERIALPART);

				StringList slPhaseChildBusSelect = new StringList(6);
				slPhaseChildBusSelect.add(DomainConstants.SELECT_TYPE);
				slPhaseChildBusSelect.add(DomainConstants.SELECT_NAME);
				slPhaseChildBusSelect.add(DomainConstants.SELECT_REVISION);
				slPhaseChildBusSelect.add(DomainConstants.SELECT_ID);
				slPhaseChildBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
				slPhaseChildBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slPhaseChildBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

				StringList slPhaseChildRelSelect = new StringList(7);
				slPhaseChildRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
				slPhaseChildRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				slPhaseChildRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
				slPhaseChildRelSelect.add(DomainConstants.SELECT_RELATIONSHIP_ID);
				slPhaseChildRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
				slPhaseChildRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
				slPhaseChildRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
				slPhaseChildRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				mlPhaseChildObjList = dObjPhase.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_EBOM, 		// rel pattern
						pgPhaseExpTypePattern.getPattern(), 	// type pattern
						//SL_OBJECT_INFO_SELECT,         		// object select
						slPhaseChildBusSelect,
						//SL_RELATION_INFO_SELECT_EBOM,    		// rel select
						slPhaseChildRelSelect,
						false,                  				// to side
						true,                   				// from side 
						(short)1,               				// recursion level
						DomainConstants.EMPTY_STRING,           // object where clause
						DomainConstants.EMPTY_STRING,0); 

				Iterator pgPhaseItr = mlPhaseChildObjList.iterator();

				while (pgPhaseItr.hasNext()) {

					hmPhaseChildMap = (Hashtable)pgPhaseItr.next();

					strChildType = (String) hmPhaseChildMap.get(DomainConstants.SELECT_TYPE);
					strChildName = (String) hmPhaseChildMap.get(DomainConstants.SELECT_NAME);
					strChildRev = (String) hmPhaseChildMap.get(DomainConstants.SELECT_REVISION);
					strPgFPC = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
					strChildObjID = (String) hmPhaseChildMap.get(DomainConstants.SELECT_ID);						
					strFindNumber = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
					strChildBUOM = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

					strComponentNumber = strChildName;

					strRelId = (String) hmPhaseChildMap.get(DomainConstants.SELECT_RELATIONSHIP_ID);

					strQuantity = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
					strTarget = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
					strLowerLim = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
					strUpperLim = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
					strPosIndicator = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);

					strOptComponent = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
					strComment = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
					strValidFromDateComp = (String) hmPhaseChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
					strValidFromDateComp = convertPLMDateToSAP(strValidFromDateComp);

					if(!strFirstlevelObjId.equals(""))
						hmParentObjects.put(strFirstlevelObjId,iChildObjCount);
					strFirstlevelObjId = strChildObjID;
					iChildObjCount = 1;

					if (strChildType.equals(ConstantsUtil.TYPE_PGBASEFORMULA)) {
						getBaseFormulaRows(context, strChildName, strChildRev, 
								strFindNumber,strPhaseName,strObjectName,  strValidFromDate, strBOMBaseQty,
								strBOMUsage, strChildObjID);
					} else {

						if (strChildType.startsWith(ConstantsUtil.PGMASTER)) {

							getIndividualsFromMaster(context,strObjectName, strValidFromDate, strBOMBaseQty, 
									strPhaseName, strFindNumber, strBOMNumber, strChildType,
									strChildName, strChildRev, strBOMUsage, strQuantity, strUpperLim,
									strTarget, strLowerLim, strValidFromDateComp, strPosIndicator, true, strChildObjID);
							buildFCBOMArray(context, strPhaseName, strFindNumber,
									strObjectName, strBOMUsage, strValidFromDate,
									strComponentNumber, strQuantity, strSubstFlag,
									strUpperLim, strTarget, strLowerLim,
									strValidFromDateComp, strBOMNumber, strBOMBaseQty,
									strPosIndicator, strRelId, strChildName, strChildRev, true, strChildObjID, "","", strChildBUOM);
						} else{
							buildFCBOMArray(context, strPhaseName, strFindNumber,
									strObjectName, strBOMUsage, strValidFromDate,
									strComponentNumber, strQuantity, strSubstFlag,
									strUpperLim, strTarget, strLowerLim,
									strValidFromDateComp, strBOMNumber, strBOMBaseQty,
									strPosIndicator, strRelId, strChildName, strChildRev, false, strChildObjID, strOptComponent,strComment, strChildBUOM);
						}
					}
				}
			}
			hmParentObjects.put(strFirstlevelObjId,iChildObjCount);

			alBOMFC = getBOMAlternateSubstituteGrouping(context, alBOMFC);				
			saBOM = convertArrayListToArray(alBOMFC, BOM_ARRAY_SIZE);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (saBOM != null){			

			Arrays.sort(saBOM, new Comparator(){
				public int compare(Object obj1, Object obj2)
				{
					int result = 0;

					String[] str1 = (String[]) obj1;
					String[] str2 = (String[]) obj2; 


					if ((result = str1[ConstantsUtil.INDEX_PHASE_NAME].compareTo(str2[ConstantsUtil.INDEX_PHASE_NAME])) == 0)
					{
						Float in1 = null;
						if(UIUtil.isNotNullAndNotEmpty(str1[ConstantsUtil.INDEX_FIND_NUMBER]) && !(str1[ConstantsUtil.INDEX_FIND_NUMBER].contains("#DENIED!")))
						{
							in1=Float.valueOf(str1[ConstantsUtil.INDEX_FIND_NUMBER]);
						}
						Float in2 = null;
						if(UIUtil.isNotNullAndNotEmpty(str2[ConstantsUtil.INDEX_FIND_NUMBER]) && !(str2[ConstantsUtil.INDEX_FIND_NUMBER].contains("#DENIED!")))
						{
							in2=Float.valueOf(str2[ConstantsUtil.INDEX_FIND_NUMBER]);
						}
						if(null != in1 && null != in2)
							result = in1.compareTo(in2);
					}					
					return result;
				}

			}); 
		}		
		return saBOM;
	}







	public static StringList getObjectSelects() {
		StringList slEBOMTarget = new StringList(15);
		try{


			slEBOMTarget.add(DomainConstants.SELECT_TYPE);

			slEBOMTarget.add(DomainConstants.SELECT_NAME);
			slEBOMTarget.add(DomainConstants.SELECT_REVISION);
			slEBOMTarget.add(DomainConstants.SELECT_ID);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_STATUS);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			slEBOMTarget.add("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to.id");
			slEBOMTarget.add("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to.type");
			slEBOMTarget.add("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to.name");
			//slEBOMTarget.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"]");
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_ENGINUITYAUTHORED);
			slEBOMTarget.add("from["+ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION+"].to.name");
			slEBOMTarget.add("from["+ConstantsUtil.RELATIONSHIP_PGMASTER+"].to.name");
			slEBOMTarget.addElement(DomainConstants.SELECT_LEVEL);

		}catch(Exception ex) {
			ex.printStackTrace();		
		}

		return slEBOMTarget;
	}

	/**
	 * This Method is use for Global Object selectables
	 * 
	 * @return StringList
	 * @throws Exception 
	 */

	public static StringList getFOPObjectSelects() {

		StringList slEBOMTarget = new StringList(22);
		try{

			slEBOMTarget.add(DomainConstants.SELECT_TYPE);

			slEBOMTarget.add(DomainConstants.SELECT_NAME);
			slEBOMTarget.add(DomainConstants.SELECT_REVISION);
			slEBOMTarget.add(DomainConstants.SELECT_ID);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCSSTYPE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);			
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTUAL_WEIGHT_DRY);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTUAL_PERCENT_DRY);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTUAL_WEIGHT_WET);
			slEBOMTarget.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTUAL_PERCENT_WET);
			slEBOMTarget.add("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to.id");
			slEBOMTarget.add("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to.name");
			slEBOMTarget.add("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to.type");
			slEBOMTarget.add("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to."+ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			slEBOMTarget.add("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to."+ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
			slEBOMTarget.add("to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return slEBOMTarget;
	}

	/**
	 * This Method is use for Relationship selectables
	 * 
	 * @return StringList
	 */


	public static StringList getRelationshipSelectsEBOM(){
		StringList slEBOMRel = new StringList(31);
		try{

			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
			slEBOMRel.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].id");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"]");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.id");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.type");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.name");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.revision");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.current");
			
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.attribute["+ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY+"]");
			slEBOMRel.add("frommid[EBOM Substitute].to.attribute["+ConstantsUtil.ATTRIBUTE_PGSAPTYPE+"]");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.attribute["+ConstantsUtil.ATTRIBUTE_EFFECTIVITYDATE+"]");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to." +ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR); // added as per  defect # 10351
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"]."+ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"]." +ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"]."+ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"]."+ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"]."+ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);

			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].attribute["+DomainObject.ATTRIBUTE_START_EFFECTIVITY+"]");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].attribute["+ConstantsUtil.ATTR_VALID_UNTIL_DATE+"]");

		}catch(Exception ex) {
			ex.printStackTrace();

		}		
		return slEBOMRel;
	}


	/**
	 * This Method is use for Relationship selectables
	 * 
	 * @return StringList
	 */


	public static StringList getRelationshipSelectsOthers() {
		StringList slEBOMRel = new StringList(22);
		try{			
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
			slEBOMRel.add(DomainConstants.SELECT_RELATIONSHIP_ID);			
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINIMUMPERCENTWEIGHTBYWEIGHT);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMAXIMUMPERCENTWEIGHTBYWEIGHT); 		
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);

			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWEIGHTDRY);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISAUTHORIZEDTOPRODUCE);			
			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_PGISACTIVATED);

			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE+"].to.from["+ConstantsUtil.REL_FBOM+"].to.type");

			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE+"].to.from["+ConstantsUtil.REL_FBOM+"].to.name");

			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE+"].to.from["+ConstantsUtil.REL_FBOM+"].to.id");

			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE+"].to.from["+ConstantsUtil.REL_FBOM+"].id");

			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE+"].to.from["+ConstantsUtil.REL_FBOM+"].to."+ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

			slEBOMRel.add(ConstantsUtil.SELECT_ATTRIBUTE_REFERENCEDESIGNATOR); 
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE+"].to.from["+ConstantsUtil.REL_FBOM+"].to."+ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE+"]");
			slEBOMRel.add("frommid["+ConstantsUtil.RELATIONSHIP_FBOM_SUBSTITUTE+"].to.from["+ConstantsUtil.REL_FBOM+"].to.to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
		}catch(Exception ex) {
			ex.printStackTrace();

		}		
		return slEBOMRel;
	}




	private double parseValue(String strValue) {

		double dValue					= 1;
		try { 
			dValue				= Double.parseDouble(strValue);
		}catch(Exception e) {
			dValue				= 1;
		}
		if(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED.equalsIgnoreCase(strValue)) {
			dValue = -9.99;
		}
		dValue				   =	(double)Math.round(dValue*1000)/1000;
		return dValue;

	}
	private String parseQuantityValue(String strValue) {

		double dValue					= -9.99;
		try { 

			if(BusinessUtil.isNotNullOrEmpty(strValue)){

				dValue				= Double.parseDouble(strValue);
				if(dValue<0) {

					strValue = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
					dValue = -9.99;
				}

			} else {
				strValue = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
				dValue = -9.99;
			}
		}catch(Exception e) {
			dValue				= -9.99;
		}
		if(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED.equalsIgnoreCase(strValue)) {
			dValue = -9.99;
		}

		return dValue + DomainConstants.EMPTY_STRING;


	}

	private double parseFOPQuantityValue(String strValue) {

		double dValue					= 1;
		if(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED.equalsIgnoreCase(strValue)) {
			dValue = -9.99;
		}else{
			try { 
				dValue				= Double.parseDouble(strValue);

			}catch(Exception e) {
				dValue				= 1;
			}
		}
		return dValue;	
	}

	private double parseValue_Double(String strValue) {
		double dValue					= 1;
		try {
			dValue				= Double.parseDouble(strValue);
		}catch(Exception e) {
			dValue				= 1;
		}
		if(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED.equalsIgnoreCase(strValue)) {
			dValue = -9.99;
		}
		dValue				   =	(double)Math.round(dValue*1000)/1000;
		return dValue;	
	}


	public String[] buildBOMArray (String strParentName, String strFindNumber,
			String strEffectivityDateChild,
			String sComponentName, String sQuantity,
			String strMax, String sTarget, String strMin,
			String strEffectivDateParent, 
			String sBOMBaseQuantity, String strPosInd,String strFILBaseQty,String strpgPhaseBOMQty,String strSubFlag,
			String strID, String strOptComponent, String strComment, String strTargetWetWeight, String strTargetDryWeight, String strIsPrimaryComponent, String strValidUntilDate) {
		String[] saTemp = new String[ConstantsUtil.INDEX_BOM_ARRAY_SIZE]; 

		try {

			if(!BusinessUtil.isNotNullOrEmpty(sQuantity))
				sQuantity="1";
			if(!BusinessUtil.isNotNullOrEmpty(strMax))
				strMax=ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
			if(!BusinessUtil.isNotNullOrEmpty(strMin))
				strMin=ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
			if(!BusinessUtil.isNotNullOrEmpty(sBOMBaseQuantity))
				sBOMBaseQuantity="1";
			if(!BusinessUtil.isNotNullOrEmpty(strFILBaseQty))
				strFILBaseQty="1";
			if(!BusinessUtil.isNotNullOrEmpty(strpgPhaseBOMQty))
				strpgPhaseBOMQty="1";
			if(!BusinessUtil.isNotNullOrEmpty(sTarget))
				sTarget="1";

			double dFil 					= 1;
			double dMinQty					= 1;
			double dPgPhaseBOMQty			= 1;
			double dBOMBaseQty				= 1;
			double dTargetQty				= 1;
			double dMaxQty					= 1;
			double dFilBaseQty				= 1;
			double dPCTBase					= 1;
			double dQuantity				= 1;
			double dFormula_Card_Minimum_Quantity = parseValue_Double(strMin);
			double dFormula_Card_Maximum_Quantity = parseValue_Double(strMax);

			double dFormula_Card = 1;
			double dIPS_Quantity = 1;

			dMinQty 			= parseValue(strMin);
			dPgPhaseBOMQty		= parseValue(strpgPhaseBOMQty);
			dBOMBaseQty			= parseValue(sBOMBaseQuantity);				
			dTargetQty			= parseValue(sTarget);
			dMaxQty				= parseValue(strMax);
			dFilBaseQty			= parseValue(parseQuantityValue(strFILBaseQty));
			dPCTBase			= dFilBaseQty;
			dQuantity			= parseValue(parseQuantityValue(sQuantity));

			strMin				= dMinQty+DomainConstants.EMPTY_STRING;
			strpgPhaseBOMQty	= dPgPhaseBOMQty+DomainConstants.EMPTY_STRING;
			sBOMBaseQuantity	= dBOMBaseQty+DomainConstants.EMPTY_STRING;
			sTarget				= dTargetQty+DomainConstants.EMPTY_STRING;
			strMax				= dMaxQty+DomainConstants.EMPTY_STRING;
			strFILBaseQty		= dFilBaseQty+DomainConstants.EMPTY_STRING;
			//SPEC: 11/06/2020 : Commented for Defect: 37071 ##-- START
			//sQuantity			= dQuantity+DomainConstants.EMPTY_STRING;
			//SPEC: 11/06/2020 : Commented for Defect: 37071 ##-- END

			if(BusinessUtil.isNotNullOrEmpty(sTarget) && !ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED.equals(sTarget)) {
				dFormula_Card  				  	= dBOMBaseQty /(dFilBaseQty  * dTargetQty);
				dFormula_Card				   =	(double)Math.round(dFormula_Card*1000)/1000;
			}else {

				dFormula_Card = parseValue(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED) ;
			}

			if(BusinessUtil.isNotNullOrEmpty(sQuantity) && !ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED.equals(sQuantity)) {
				dIPS_Quantity 				  	= dBOMBaseQty /(dPCTBase * dQuantity);
				dIPS_Quantity				   =	(double)Math.round(dIPS_Quantity*1000)/1000;
			}else {

				dIPS_Quantity = parseValue(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED) ;
			}

			if (UIUtil.isNotNullAndNotEmpty(strSubFlag)) {
				saTemp[ConstantsUtil.INDEX_USAGE_PROBABILITY] = ConstantsUtil.VALUE_USAGE_PROBABILITY;
			} else {
				saTemp[ConstantsUtil.INDEX_USAGE_PROBABILITY] = "";
			}

			saTemp[ConstantsUtil.INDEX_ALT_BOM] 				= ConstantsUtil.VALUE_ALT_BOM;
			saTemp[ConstantsUtil.INDEX_BOM_STATUS] 				= ConstantsUtil.VALUE_BOM_STATUS;
			saTemp[ConstantsUtil.INDEX_ITEM_CATEGORY] 			= ConstantsUtil.VALUE_ITEM_CATEGORY;
			saTemp[ConstantsUtil.INDEX_BOM_TEXT] 				= strParentName ;
			saTemp[ConstantsUtil.INDEX_ALT_BOM_TEXT] 			= ConstantsUtil.VALUE_ALT_BOM_TEXT;
			saTemp[ConstantsUtil.INDEX_MATERIAL_NUMBER] 		= strParentName;
			saTemp[ConstantsUtil.INDEX_BOM_USAGE] 				= ConstantsUtil.VALID_CODE;
			saTemp[ConstantsUtil.INDEX_VALID_FROM_DATE_PARENT] 	= strEffectivDateParent;
			saTemp[ConstantsUtil.INDEX_COMPONENT_NAME] 			= sComponentName;
			saTemp[ConstantsUtil.INDEX_QUANTITY] 				= sQuantity;
			saTemp[ConstantsUtil.INDEX_UPPER_LIMIT] 			= strMax;
			saTemp[ConstantsUtil.INDEX_TARGET] 					= sQuantity;
			saTemp[ConstantsUtil.INDEX_LOWER_LIMIT] 			= strMin;
			saTemp[ConstantsUtil.INDEX_FIND_NUMBER] 			= strFindNumber;
			saTemp[ConstantsUtil.INDEX_VALID_FROM_DATE_CHILD] 	= strEffectivityDateChild;

			saTemp[ConstantsUtil.INDEX_VALID_UNTIL_DATE] 	= strValidUntilDate;

			saTemp[ConstantsUtil.INDEX_PHASE_NAME] 				= DomainConstants.EMPTY_STRING;
			saTemp[ConstantsUtil.INDEX_CONFIRMED_QUANTITY] 		= sBOMBaseQuantity;
			saTemp[ConstantsUtil.INDEX_SORT_STRING] 			= strPosInd;
			saTemp[ConstantsUtil.INDEX_BOM_ITEM_NUMBER] 		= DomainConstants.EMPTY_STRING;
			saTemp[ConstantsUtil.INDEX_SUBSTITUTE_FLAG] 		= strSubFlag;
			saTemp[ConstantsUtil.INDEX_FC_MIN_QTY] 				= dFormula_Card_Minimum_Quantity+DomainConstants.EMPTY_STRING;
			saTemp[ConstantsUtil.INDEX_FORMULA_CARD] 			= dFormula_Card+DomainConstants.EMPTY_STRING;
			saTemp[ConstantsUtil.INDEX_FC_MAX_QTY] 				= dFormula_Card_Maximum_Quantity+DomainConstants.EMPTY_STRING;
			saTemp[ConstantsUtil.INDEX_IPS_QTY] 				= dIPS_Quantity+DomainConstants.EMPTY_STRING;

			saTemp[ConstantsUtil.INDEX_OPT_COMPONENT] 			= strOptComponent;
			saTemp[ConstantsUtil.INDEX_COMMENT] 				= strComment;

			saTemp[ConstantsUtil.INDEX_TARGETWETWEIGHT] 				= strTargetWetWeight;
			saTemp[ConstantsUtil.INDEX_TARGETDRYWEIGHT] 				= strTargetDryWeight;
			saTemp[ConstantsUtil.INDEX_ISPRIMARYCOMPONENT] 				= strIsPrimaryComponent;

			saTemp[ConstantsUtil.INDEX_OBJECT_ID] 				= strID;

			if (saTemp[ConstantsUtil.INDEX_UPPER_LIMIT] == null || saTemp[ConstantsUtil.INDEX_UPPER_LIMIT].equals("")) {
				saTemp[ConstantsUtil.INDEX_RANGE_FLAG] = DomainConstants.EMPTY_STRING;
			} else
				saTemp[ConstantsUtil.INDEX_RANGE_FLAG] = ConstantsUtil.VALUE_RANGE_FLAG;


		}catch(Exception e) {		
			e.printStackTrace();
		}		
		return saTemp;

	}


	public MapList getPartBOMFEEDData(Context context, String strObjectID,String strTopNodeType) throws Exception {
		MapList mlFlatBOM = new MapList();
		String strTUPID = DomainConstants.EMPTY_STRING;
		String strPartType = DomainConstants.EMPTY_STRING;
		String strRelWhere = DomainConstants.EMPTY_STRING;
		
		String strTUPType = DomainConstants.EMPTY_STRING;
		String strTUPName =DomainConstants.EMPTY_STRING;
		
		
		Map mapSub = null;
		Map mpAlternate  = null;
		Map mpCompPart = null;
		MapList mlTUPPart = null;
		MapList mlPartChildData = null;
		String strSelect_SubstitutePartId = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.id").toString();
		String strSelect_SubstitutePartName = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.name").toString();
		String strSelect_SubstitutePartType = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.type").toString();
		String strSelect_SubstitutePartRevision = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.revision").toString();
		String strSelect_SubstitutePartCurrent = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.current").toString();
		String strSelect_SubstituteRelId = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].id").toString();
		String strSelect_Substitute_EffectivityDate = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to.attribute[").append(ConstantsUtil.ATTRIBUTE_EFFECTIVITYDATE).append("]").toString();
		String strSelect_AlternateId = new StringBuffer("from[").append(DomainConstants.RELATIONSHIP_ALTERNATE).append("].to.id").toString();
		String strSelect_SubstituteComment = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("]."+ConstantsUtil.SELECT_ATTRIBUTE_COMMENT).toString();
		String strSelect_SubstituteSpecSubType = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].to."+ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE).toString();
		String strSelect_SubstituteMinQty = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("]."+ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET).toString();
		String strSelect_SubstituteMaxQty = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("]."+ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET).toString();
		String strSelect_SubstituteQty = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("]."+ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY).toString();
		String strSelect_Substitute_ValidUntilDate = new StringBuffer("frommid[").append(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE).append("].attribute[").append(ConstantsUtil.ATTR_VALID_UNTIL_DATE).append("]").toString();
		MapList mlSubAlts = null;
		int iAltsSize = 0;
		Map mpAltMap = null;

		try {
			if(BusinessUtil.isNotNullOrEmpty(strObjectID)) {
				DomainObject dObjPart = DomainObject.newInstance(context, strObjectID);				
				if(ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strTopNodeType)) {
					strRelWhere = new StringBuffer(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY).append("==TRUE").toString();
					mlTUPPart = dObjPart.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_PGTRANSPORTUNIT,  // Rel Pattern
							ConstantsUtil.TYPE_PGTRANSPORTUNITPART,		// Type Pattern
							SL_OBJECT_INFO_SELECT,                  	// bus select
							null,										// Rel select
							false,										// to side
							true,										// from side
							(short)1,									// recursion level
							null,										// Object Where Clause
							strRelWhere,								// Rel Where Clause
							0);
					if(null != mlTUPPart && mlTUPPart.size() > 0) {
						Map mapTUPData = (Map)mlTUPPart.get(0);
						strTUPID = (String)mapTUPData.get(DomainConstants.SELECT_ID);
						 strTUPType = (String)mapTUPData.get(DomainConstants.SELECT_TYPE);
						 strTUPName = (String)mapTUPData.get(DomainConstants.SELECT_NAME);
					}
					mlPartChildData = getTUPBOMData(context,strTUPID);
				} else if (ConstantsUtil.TYPE_FABRICATEDPART.equalsIgnoreCase(strTopNodeType) || ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART.equalsIgnoreCase(strTopNodeType) || ConstantsUtil.TYPE_DEVICEPRODUCTPART.equalsIgnoreCase(strTopNodeType) || ConstantsUtil.TYPE_INTERMEDIATEPRODUCTPART.equalsIgnoreCase(strTopNodeType)) {
					mlPartChildData = getEBOMData(context,strObjectID);
				}
				if(null != mlPartChildData && mlPartChildData.size() > 0) {
					mlPartChildData.sort(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER,"ascending","integer");
					int isizePartData = mlPartChildData.size();
					StringList slSubstituteIds = null;
					for(int iCount=0;iCount<isizePartData;iCount++) {
						mpCompPart = (Map)mlPartChildData.get(iCount);
						(mpCompPart).put("IsDirectComponent", "true");
						(mpCompPart).put("TUP_ID",strTUPID);
						(mpCompPart).put("TUP_Type",strTUPType);
						(mpCompPart).put("TUP_Name",strTUPName);
						mlFlatBOM.add(mpCompPart);
						Object substituteId  = (Object) (mpCompPart).get(strSelect_SubstitutePartId);
						slSubstituteIds = new StringList();
						if (null != substituteId) {
							if (substituteId instanceof StringList) {
								slSubstituteIds = (StringList) substituteId;
							} else {
								slSubstituteIds.add(substituteId.toString());
							}
						}
						Object substituteName = (Object) (mpCompPart).get(strSelect_SubstitutePartName);
						StringList slSubstituteNames = new StringList();
						if (null != substituteName) {
							if (substituteName instanceof StringList) {
								slSubstituteNames 	= (StringList) substituteName;
							} 
							else {
								slSubstituteNames.add(substituteName.toString());
							}
						}
						Object substituteType = (Object) (mpCompPart).get(strSelect_SubstitutePartType);
						StringList slSubstituteTypes = new StringList();
						if (null != substituteType) {
							if (substituteType instanceof StringList) {
								slSubstituteTypes = (StringList) substituteType;
							} else {
								slSubstituteTypes.add(substituteType.toString());
							}
						}
						Object substituteRev = (Object) (mpCompPart).get(strSelect_SubstitutePartRevision);
						StringList slSubstituteRevs = new StringList();
						if (null != substituteRev) {
							if (substituteRev instanceof StringList) {
								slSubstituteRevs = (StringList) substituteRev;
							} else {
								slSubstituteRevs.add(substituteRev.toString());
							}
						}
						Object substituteState = (Object) (mpCompPart).get(strSelect_SubstitutePartCurrent);
						StringList slSubstituteCurrent = new StringList();
						if (null != substituteState) {
							if (substituteState instanceof StringList) {
								slSubstituteCurrent = (StringList) substituteState;
							} else {
								slSubstituteCurrent.add(substituteState.toString());
							}
						}
						Object substituteEffectivityDate = (Object) (mpCompPart).get(strSelect_Substitute_EffectivityDate);
						StringList slSubstituteEffectivityDate = new StringList();
						if (null != substituteEffectivityDate) {
							if (substituteEffectivityDate instanceof StringList) {
								slSubstituteEffectivityDate = (StringList) substituteEffectivityDate;
							} else {
								slSubstituteEffectivityDate.add(substituteEffectivityDate.toString());
							}
						}


						Object SubstituteValidUntilDate = (Object) (mpCompPart).get(strSelect_Substitute_ValidUntilDate);
						StringList slSubstituteValidUntilDate = new StringList();
						if (null != SubstituteValidUntilDate) {
							if (SubstituteValidUntilDate instanceof StringList) {
								slSubstituteValidUntilDate = (StringList) SubstituteValidUntilDate;
							} else if (SubstituteValidUntilDate instanceof String) {
								slSubstituteValidUntilDate.add(SubstituteValidUntilDate.toString());
							}
						}


						Object substituteOptComponent = (Object) (mpCompPart).get(SELECT_SUBSTITUTE_OPT_COMPONENT);
						StringList slSubstituteOptComponent = new StringList();
						if (null != substituteOptComponent) {
							if (substituteOptComponent instanceof StringList) {
								slSubstituteOptComponent = (StringList) substituteOptComponent;
							} else {
								slSubstituteOptComponent.add(substituteOptComponent.toString());
							}
						}

						Object substituteRelID = (Object) (mpCompPart).get(strSelect_SubstituteRelId);
						StringList slSubstituteRelID = new StringList();
						if (null != substituteRelID) {
							if (substituteRelID instanceof StringList) {
								slSubstituteRelID = (StringList) substituteRelID;
							} else {
								slSubstituteRelID.add(substituteRelID.toString());
							}
						}
						Object substituteComment = (Object) (mpCompPart).get(strSelect_SubstituteComment);
						StringList slSubstituteComment = new StringList();
						if (null != substituteComment) {
							if (substituteComment instanceof StringList) {
								slSubstituteComment = (StringList) substituteComment;
							} else {
								slSubstituteComment.add(substituteComment.toString());
							}
						}else
						{	
							int isizeOfSubstituteComponents = slSubstituteRelID.size();
							for(int iSubstitute = 0; iSubstitute < isizeOfSubstituteComponents; iSubstitute++) 
							{
								String strSubstituteRelId = (String)slSubstituteRelID.get(iSubstitute);
								String strComment = DomainRelationship.getAttributeValue(context,strSubstituteRelId,ConstantsUtil.ATTRIBUTE_COMMENT);
								if(!BusinessUtil.isNotNullOrEmpty(strComment))
								{
									slSubstituteComment.add(DomainConstants.EMPTY_STRING);
								}
							}
						}
						Object substituteSpecSubType = (Object) (mpCompPart).get(strSelect_SubstituteSpecSubType);
						StringList slSubSpecSubTypes = new StringList();
						if (null != substituteSpecSubType) {
							if (substituteSpecSubType instanceof StringList) {
								slSubSpecSubTypes 	= (StringList) substituteSpecSubType;
							} 
							else {
								slSubSpecSubTypes.add(substituteSpecSubType.toString());
							}
						}
						String strSpecSubType = DomainConstants.EMPTY_STRING;
						Object substituteMinQty = (Object) (mpCompPart).get(strSelect_SubstituteMinQty);
						StringList slSubstituteMinQty = new StringList();
						if (null != substituteMinQty) {
							if (substituteMinQty instanceof StringList) {
								slSubstituteMinQty = (StringList) substituteMinQty;
							} else {
								slSubstituteMinQty.add(substituteMinQty.toString());
							}
						}
						Object substituteMaxQty = (Object) (mpCompPart).get(strSelect_SubstituteMaxQty);
						StringList slSubstituteMaxQty = new StringList();
						if (null != substituteMaxQty) {
							if (substituteMaxQty instanceof StringList) {
								slSubstituteMaxQty = (StringList) substituteMaxQty;
							} else {
								slSubstituteMaxQty.add(substituteMaxQty.toString());
							}
						}
						Object substituteQty = (Object) (mpCompPart).get(strSelect_SubstituteQty);
						StringList slSubstituteQty = new StringList();
						if (null != substituteQty) {
							if (substituteQty instanceof StringList) {
								slSubstituteQty = (StringList) substituteQty;
							} else {
								slSubstituteQty.add(substituteQty.toString());
							}
						}
						Object oAlternateIds = (Object) (mpCompPart).get(strSelect_AlternateId);
						StringList slAlternateIds = new StringList();
						if (null != oAlternateIds) {
							if (oAlternateIds instanceof StringList) {
								slAlternateIds = (StringList) oAlternateIds;
							} else {
								slAlternateIds.add(oAlternateIds.toString());
							}
						}
						for(Object oAlternateId : slAlternateIds) {
							DomainObject dobjAlternate = DomainObject.newInstance(context, (String) oAlternateId);
							mpAlternate = dobjAlternate.getInfo(context,SL_OBJECT_INFO_SELECT);
							(mpAlternate).put(DomainRelationship.SELECT_ID,(String) mpCompPart.get(DomainConstants.SELECT_RELATIONSHIP_ID));
							(mpAlternate).put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
							(mpAlternate).put(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY,(String) mpCompPart.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
							(mpAlternate).put("TUP_ID",strTUPID);
							(mpAlternate).put("TUP_Type",strTUPType);
							(mpAlternate).put("TUP_Name",strTUPName);
							mlFlatBOM.add(mpAlternate);
						}



						if (null != slSubstituteIds) {
							int isizeOfSubstitutes = slSubstituteIds.size();
							for(int iSub = 0; iSub < isizeOfSubstitutes; iSub++) {
								strSpecSubType =  (String)slSubSpecSubTypes.get(iSub);
								if(!ConstantsUtil.THIRD_PARTY.equals(strSpecSubType)){
									mapSub = new HashMap();
									String strSubstituteId = (String) slSubstituteIds.get(iSub);
									String strSubstituteType = (String)slSubstituteTypes.get(iSub);

									mapSub.put(DomainConstants.SELECT_NAME, (String)slSubstituteNames.get(iSub));
									mapSub.put(DomainRelationship.SELECT_ID, (String)slSubstituteRelID.get(iSub));
									mapSub.put(DomainConstants.SELECT_ID, strSubstituteId);
									mapSub.put(DomainConstants.SELECT_TYPE, strSubstituteType);
									mapSub.put(DomainConstants.SELECT_REVISION, (String)slSubstituteRevs.get(iSub));
									mapSub.put(DomainConstants.SELECT_CURRENT, (String)slSubstituteCurrent.get(iSub));
									mapSub.put(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE, (String)slSubstituteEffectivityDate.get(iSub));
									mapSub.put(ConstantsUtil.ATTR_VALID_UNTIL_DATE, (String)slSubstituteValidUntilDate.get(iSub));
									mapSub.put(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT, (String)slSubstituteOptComponent.get(iSub));
									mapSub.put(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT, (String)slSubstituteComment.get(iSub));
									mapSub.put("relationship", ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE);
									mapSub.put("TUP_ID",strTUPID);
									mapSub.put("TUP_Type",strTUPType);
									mapSub.put("TUP_Name",strTUPName);
									mapSub.put(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET, (String)slSubstituteMinQty.get(iSub));
									mapSub.put(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET, (String)slSubstituteMaxQty.get(iSub));
									mapSub.put(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY, (String)slSubstituteQty.get(iSub));
									mlFlatBOM.add(mapSub);

									if(UIUtil.isNotNullAndNotEmpty(strSubstituteType) && strAlternateAllowedTypes.contains(strSubstituteType)){
										mlSubAlts= getAlternates(context, strSubstituteId);
										iAltsSize = mlSubAlts.size();
										for(int i=0;i<iAltsSize;i++){
											mpAltMap = (Map) mlSubAlts.get(i);
											mpAltMap.put("relationship", DomainConstants.RELATIONSHIP_ALTERNATE);
											mpAltMap.put(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET, (String)slSubstituteMinQty.get(iSub));
											mpAltMap.put(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET, (String)slSubstituteMaxQty.get(iSub));
											mpAltMap.put(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY, (String)slSubstituteQty.get(iSub));
											mpAltMap.put("TUP_ID",strTUPID);
											mpAltMap.put("TUP_Type",strTUPType);
											mpAltMap.put("TUP_Name",strTUPName);
											mlFlatBOM.add(mpAltMap); 
										}
									}

								}
							}
						}
					}
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return mlFlatBOM;
	}


	public MapList getAlternates(Context context, String strObjectId) throws Exception{

		MapList mlAltsList = null;
		try{
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){

				DomainObject doParentObj = DomainObject.newInstance(context, strObjectId);
				StringList slAltObjSelects = new StringList(4);
				slAltObjSelects.add(DomainConstants.SELECT_ID);
				slAltObjSelects.add(DomainConstants.SELECT_NAME);
				slAltObjSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				slAltObjSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				slAltObjSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
				StringList slAltRelSelects = new StringList(1);
				slAltObjSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);

				mlAltsList = doParentObj.getRelatedObjects(context,
						DomainConstants.RELATIONSHIP_ALTERNATE, 	// rel pattern
						"*",     									// type pattern
						slAltObjSelects,							// obj selects
						slAltRelSelects,							// rel selects
						false,                  					// to side
						true,                   					// from side 
						(short)1,               					// recursion level
						DomainConstants.EMPTY_STRING,       							// object where clause
						DomainConstants.EMPTY_STRING,0); 
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}		
		return mlAltsList;
	}



	public Map getFPPObjectsForChildCOPInCOP(Context context,String strID,String strCOPToCOPQuantity,String strContextFPPId,StringList slCOPSubstituteIds, String strBOMBaseQuantity, BigDecimal bdIntermediateObjectQty, String strContextFPPBUOM) throws Exception
	{
		Map mpReturn = new HashMap();
		String strCOPId = strID;
		DomainObject doObjectCOP 	= null;
		MapList mlConnectedFPPs = null;
		StringList slObjectSelects = new StringList(3);
		slObjectSelects.add(DomainConstants.SELECT_ID);
		slObjectSelects.add(DomainConstants.SELECT_NAME);
		slObjectSelects.add(DomainConstants.SELECT_CURRENT);
		slObjectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		slObjectSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
		StringList slRelSelects = new StringList(3);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		slRelSelects.add(DomainRelationship.SELECT_ID);
		slRelSelects.add("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.id");
		String strCOPCUPITQuantity = DomainConstants.EMPTY_STRING;
		Pattern pIntermediateTypesForCOPToCOP = new Pattern(ConstantsUtil.TYPE_FINISHEDPRODUCTPART);
		pIntermediateTypesForCOPToCOP.addPattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
		pIntermediateTypesForCOPToCOP.addPattern(ConstantsUtil.TYPE_PGINNERPACKUNITPART);
		Map mpFPPObjects = new HashMap();
		String strFPPId = DomainConstants.EMPTY_STRING;
		String strFPPCurrent = DomainConstants.EMPTY_STRING;
		String strFPPType = DomainConstants.EMPTY_STRING;
		Map mpsubstituteFPPObjects = new HashMap();
		String strSubstituteFPPId = DomainConstants.EMPTY_STRING;
		String strSubstituteFPPCurrent = DomainConstants.EMPTY_STRING;
		String strSubstituteFPPType = DomainConstants.EMPTY_STRING;		
		MapList mlReleasedFPP = new MapList();
		StringList strListQtyValues = new StringList(1);
		String strObjWhere = "current=="+ConstantsUtil.STATE_RELEASE+"";
		String strReleasedFPPBUOM = DomainConstants.EMPTY_STRING;
		String strIntermediateObjQty = DomainConstants.EMPTY_STRING;
		String strConnectedFPPLevel = DomainConstants.EMPTY_STRING;
		BigDecimal bdDenominator = new BigDecimal("1");
		BigDecimal bdNumerator = new BigDecimal("1");
		BigDecimal bdBOMQty = new BigDecimal("1");
		BigDecimal bdBOMQuantityCheck=new BigDecimal("9999999999.999");
		String strBUoMITBPMP = ConstantsUtil.BASEUNITOFMEASURE_IT + "|" + ConstantsUtil.BASEUNITOFMEASURE_MP + "|" + ConstantsUtil.BASEUNITOFMEASURE_BP;
		try
		{
			doObjectCOP = DomainObject.newInstance(context, strCOPId);
			mlConnectedFPPs = doObjectCOP.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_EBOM, 	// relationship pattern
					ConstantsUtil.TYPE_FINISHEDPRODUCTPART+","+ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART, // Type pattern
					slObjectSelects,        		// object selects
					slRelSelects,  		 	// rel selects 
					true,                 				// to side
					false,                  				// from side
					(short)0,              				// recursion level
					strObjWhere,           				// object where clause
					null,0);                    			// rel where clause 
			int mlConnectedFPPSize = mlConnectedFPPs.size();
			bdNumerator = new BigDecimal(strCOPToCOPQuantity);
			for(int i=0;i<mlConnectedFPPSize;i++)
			{
				bdBOMQty = new BigDecimal("1");
				mpFPPObjects = (Map)mlConnectedFPPs.get(i);
				mpFPPObjects.put("COPinCOP",strCOPId);
				strFPPId = (String)mpFPPObjects.get(DomainConstants.SELECT_ID);
				strFPPCurrent = (String)mpFPPObjects.get(DomainConstants.SELECT_CURRENT);
				strFPPType = (String)mpFPPObjects.get(DomainConstants.SELECT_TYPE);
				strConnectedFPPLevel = (String)mpFPPObjects.get(DomainConstants.SELECT_LEVEL);
				if(parseValue(strConnectedFPPLevel)==1)
					bdDenominator = new BigDecimal("1");
				if(ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strFPPType))
					strReleasedFPPBUOM = (String)mpFPPObjects.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
				strIntermediateObjQty = (String)mpFPPObjects.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				if(UIUtil.isNotNullAndNotEmpty(strIntermediateObjQty)){					
					bdDenominator = bdDenominator.multiply(new BigDecimal(strIntermediateObjQty));
				}				
				if(ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strFPPType) && !strFPPId.equalsIgnoreCase(strContextFPPId))
				{
					mlReleasedFPP.add(mpFPPObjects);					

					if(ConstantsUtil.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strReleasedFPPBUOM)){
						strListQtyValues.add(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED);
						continue;
					}
					if((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && !strBUoMITBPMP.contains(strContextFPPBUOM)) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && !strBUoMITBPMP.contains(strReleasedFPPBUOM))){						
						if(bdDenominator.compareTo(BigDecimal.ZERO) != 0)
							bdBOMQty = bdNumerator.divide(bdDenominator,6,RoundingMode.HALF_UP);
						bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));	
						bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty);	

					} else if((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && !strBUoMITBPMP.contains(strContextFPPBUOM)) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && (ConstantsUtil.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))){							
						bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));	
						bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty);
						bdBOMQty = bdBOMQty.multiply(bdNumerator);

					} else if((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && (ConstantsUtil.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM))) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && !strBUoMITBPMP.contains(strReleasedFPPBUOM))){
						if(bdDenominator.compareTo(BigDecimal.ZERO) != 0)	
							bdBOMQty = bdNumerator.divide(bdDenominator,6,RoundingMode.HALF_UP);
						bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));

					} else if((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && (ConstantsUtil.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM)  || ConstantsUtil.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM))) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && (ConstantsUtil.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))){						
						bdBOMQty = bdNumerator.multiply(new BigDecimal(strBOMBaseQuantity));	
					}


					if(bdBOMQty.compareTo(BigDecimal.ZERO) == 0 || bdBOMQty.compareTo(bdBOMQuantityCheck)>0)
					{						
						bdBOMQty = new BigDecimal(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED);
					}	
					strListQtyValues.add(bdBOMQty.toString());
				}	
			}
			int slSubstituteIdSize = slCOPSubstituteIds.size();
			if(mlReleasedFPP.size()>0 && slSubstituteIdSize>0)
			{
				for(int iCOPSubstitute=0;iCOPSubstitute<slSubstituteIdSize;iCOPSubstitute++)
				{
					String strSubstituteId = (String)slCOPSubstituteIds.get(iCOPSubstitute);
					DomainObject doSubstituteId = DomainObject.newInstance(context,strSubstituteId);
					MapList mlSubstituteConnectedFPP = doSubstituteId.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_EBOM, 	// relationship pattern
							ConstantsUtil.TYPE_FINISHEDPRODUCTPART+","+ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART, // Type pattern
							slObjectSelects,        		// object selects
							slRelSelects,  		 	// rel selects 
							true,                 				// to side
							false,                  				// from side
							(short)0,              				// recursion level
							strObjWhere,           				// object where clause
							null,0);                    			// rel where clause
					int imlSubstituteConnectedFPP = mlSubstituteConnectedFPP.size();
					for(int iSubstituteConnectedFPP=0;iSubstituteConnectedFPP<imlSubstituteConnectedFPP;iSubstituteConnectedFPP++)
					{
						bdBOMQty = new BigDecimal("1");
						mpsubstituteFPPObjects = (Map)mlSubstituteConnectedFPP.get(iSubstituteConnectedFPP);
						mpsubstituteFPPObjects.put("COPinCOP",strCOPId);
						strSubstituteFPPId = (String)mpsubstituteFPPObjects.get(DomainConstants.SELECT_ID);
						strSubstituteFPPCurrent = (String)mpsubstituteFPPObjects.get(DomainConstants.SELECT_CURRENT);
						strSubstituteFPPType = (String)mpsubstituteFPPObjects.get(DomainConstants.SELECT_TYPE);
						if(ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strSubstituteFPPType))
							strReleasedFPPBUOM = (String)mpsubstituteFPPObjects.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
						strIntermediateObjQty = (String)mpsubstituteFPPObjects.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
						strConnectedFPPLevel = (String)mpsubstituteFPPObjects.get(DomainConstants.SELECT_LEVEL);
						if(parseValue(strConnectedFPPLevel)==1)
							bdDenominator = new BigDecimal("1");
						if(UIUtil.isNotNullAndNotEmpty(strIntermediateObjQty)){					
							bdDenominator = bdDenominator.multiply(new BigDecimal(strIntermediateObjQty));
						}				
						if(ConstantsUtil.TYPE_FINISHEDPRODUCTPART.equalsIgnoreCase(strSubstituteFPPType) && !strFPPId.equalsIgnoreCase(strContextFPPId))
						{
							mlReleasedFPP.add(mpsubstituteFPPObjects);					
							bdNumerator = new BigDecimal(strCOPToCOPQuantity);
							if(ConstantsUtil.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strReleasedFPPBUOM)){
								strListQtyValues.add(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED);
								continue;
							}

							if((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && !strBUoMITBPMP.contains(strContextFPPBUOM)) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && !strBUoMITBPMP.contains(strReleasedFPPBUOM))){	
								if(bdDenominator.compareTo(BigDecimal.ZERO) != 0)					
									bdBOMQty = bdNumerator.divide(bdDenominator,6,RoundingMode.HALF_UP);
								bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));	
								bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty);	

							} else if((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && !strBUoMITBPMP.contains(strContextFPPBUOM)) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && (ConstantsUtil.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))){							
								bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));	
								bdBOMQty = bdBOMQty.multiply(bdIntermediateObjectQty);
								bdBOMQty = bdBOMQty.multiply(bdNumerator);

							} else if((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && (ConstantsUtil.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM))) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && !strBUoMITBPMP.contains(strReleasedFPPBUOM))){
								if(bdDenominator.compareTo(BigDecimal.ZERO) != 0)
									bdBOMQty = bdNumerator.divide(bdDenominator,6,RoundingMode.HALF_UP);
								bdBOMQty = bdBOMQty.multiply(new BigDecimal(strBOMBaseQuantity));

							} else if((UIUtil.isNotNullAndNotEmpty(strContextFPPBUOM) && (ConstantsUtil.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strContextFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strContextFPPBUOM))) && (UIUtil.isNotNullAndNotEmpty(strReleasedFPPBUOM) && (ConstantsUtil.BASEUNITOFMEASURE_IT.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_MP.equalsIgnoreCase(strReleasedFPPBUOM) || ConstantsUtil.BASEUNITOFMEASURE_BP.equalsIgnoreCase(strReleasedFPPBUOM)))){						
								bdBOMQty = bdNumerator.multiply(new BigDecimal(strBOMBaseQuantity));	
							}


							if(bdBOMQty.compareTo(BigDecimal.ZERO) == 0 || bdBOMQty.compareTo(bdBOMQuantityCheck)>0)
							{						
								bdBOMQty = new BigDecimal(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED);
							}	
							strListQtyValues.add(bdBOMQty.toString());
						}
					}
				}	
			}
			mpReturn.put("strListQtyValues",strListQtyValues);
			mpReturn.put("mlReleasedFPP",mlReleasedFPP);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return mpReturn;
	}




	public Map getBOMQTYDataFPP(Context context, Map FPPmap,boolean isReshipperSub,StringList slSubstituteInterIdReshipper,String strBUOM) throws Exception
	{
		BigDecimal bdBOMBaseQty = BigDecimal.ZERO;
		BigDecimal bdInterObjRelAttrQty = BigDecimal.ZERO;
		BigDecimal bdBOMQuantityCheck = new BigDecimal("9999999999.999");
		Map mpReturn = new HashMap();
		float fIntermediateSAPQty = 1;
		Vector vc = new Vector();
		StringList strListQtyValues = new StringList(1);
		String strCalcQTY = null;
		try {

			MapList objectList = (MapList)FPPmap.get("objectList");
			HashMap paramList = (HashMap)FPPmap.get("paramList");
			String  strFPPID          = (String) paramList.get("objectId");
			DomainObject dObjFPP = DomainObject.newInstance(context,strFPPID);
			DomainObject doCUPObjInter = null;

			StringList slObjectSelect = new StringList(5);
			slObjectSelect.addElement(DomainConstants.SELECT_ID);
			slObjectSelect.addElement(DomainConstants.SELECT_NAME);
			slObjectSelect.addElement(DomainConstants.SELECT_TYPE);
			slObjectSelect.addElement(DomainConstants.SELECT_REVISION);
			slObjectSelect.addElement(DomainConstants.SELECT_LEVEL);
			StringList relationshipSelects = new StringList(4);

			relationshipSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			relationshipSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			MapList mlFPPChildData = new MapList();
			boolean bFlatReshipper = false;
			if(isReshipperSub && slSubstituteInterIdReshipper.size() > 0)
			{
				String strInterCUPID = DomainConstants.EMPTY_STRING;			
				int iSizeOfSubInterm = slSubstituteInterIdReshipper.size();
				for (int iSubInter=0; iSubInter < iSizeOfSubInterm; iSubInter++) {
					strInterCUPID = (String)slSubstituteInterIdReshipper.get(iSubInter);
					doCUPObjInter = DomainObject.newInstance(context, strInterCUPID);
					StringList slIntermediateObjectReshipperType = doCUPObjInter.getInfoList(context,"from[EBOM].to.type");
					if(slIntermediateObjectReshipperType.contains(ConstantsUtil.TYPE_PGCONSUMERUNITPART) || slIntermediateObjectReshipperType.contains(ConstantsUtil.TYPE_PGINNERPACKUNITPART)) {
						mlFPPChildData = doCUPObjInter.getRelatedObjects(context,
								ConstantsUtil.RELATIONSHIP_EBOM,   // rel pattern
								ConstantsUtil.TYPE_PGCONSUMERUNITPART+","+ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART ,  // type pattern
								slObjectSelect,             // object selects
								relationshipSelects,           //  rel selects 
								false,                             // to side
								true,                              // from side
								(short)0,                          //  recursion level
								null,                       // object where clause
								null);                             //  rel where clause
					}else{
						bFlatReshipper = true;

						mlFPPChildData = dObjFPP.getRelatedObjects(context,
								ConstantsUtil.RELATIONSHIP_EBOM,  // Rel Pattern

								ConstantsUtil.TYPE_PGCONSUMERUNITPART+","+ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART ,              //Type Pattern

								slObjectSelect,                  //  bus select

								relationshipSelects,             //   Rel select

								false,							 // to side

								true,                           // from side

								(short)0,					   //  recursion level

								null,						  // Object Where Clause

								null);                       // Rel Where Clause
					}

				}

			}else{
				mlFPPChildData = dObjFPP.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_EBOM,  // Rel Pattern

						ConstantsUtil.TYPE_PGCONSUMERUNITPART+","+ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART ,              //Type Pattern

						slObjectSelect,                  //  bus select

						relationshipSelects,             //   Rel select

						false,							 // to side

						true,                           // from side

						(short)0,					   //  recursion level

						null,						  // Object Where Clause

						null);                       // Rel Where Clause
			}
			float fltBCF = 0;
			StringList slBCF = new StringList(1);
			slBCF.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);

			Map mapBCF = (Map)dObjFPP.getInfo(context,slBCF);

			float flBOMBaseQty = 0;
			float flPCTBaseQty = 0;

			String strBOMBaseQty = (String)mapBCF.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			bdBOMBaseQty = new BigDecimal(strBOMBaseQty);

			if(null != objectList && objectList.size() > 0)
			{
				BigDecimal bdBOMQty = BigDecimal.ZERO;
				String strBOMQty 				= "";
				String strObjectID 				= "";
				String strConnectionID = null;
				String strChildName = null;
				String strChildID = null;
				String strChildType = null;
				String strInterObjRelAttrQty = null;
				String strInterQTY = null;
				String strLevel = null;
				String level = null;
				String strDenominator=null;
				float flNumber 					= 0.0f;
				float fdenominator 				= 0.0f;
				BigDecimal bdNumerator 			= BigDecimal.ZERO;
				BigDecimal bdDenominator        = BigDecimal.ZERO;
				int sizeOfChildData 			= mlFPPChildData.size();
				Map mapTempInter 				= null;
				Map mapTemp 					= null;
				int denoLevel 					= 0;
				float fTemp 					= 1.0f;
				float fTemp1 					= 1.0f;
				int iSizeOfChildDataCOP = sizeOfChildData;
				Map mpTempInterExcludingCOPToCOP 				= null;
				MapList mlFPPChildDataExcludingCOPTOCOP = new MapList();
				Map mpPreviousLevelChildType = new HashMap();
				for(int i=0; i < iSizeOfChildDataCOP; i++)
				{
					mapTempInter = (Map)mlFPPChildData.get(i);
					String strRelAttrQty = (String)mapTempInter.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);				
					String strObjectType = (String)mapTempInter.get(DomainConstants.SELECT_TYPE);	
					String strObjectId = (String)mapTempInter.get(DomainConstants.SELECT_ID);
					mpPreviousLevelChildType.put(i+1,strObjectType);
					if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strObjectType))
					{
						String strPreviousLevelType = (String)mpPreviousLevelChildType.get(i);
						if(ConstantsUtil.TYPE_PGCONSUMERUNITPART.equalsIgnoreCase(strPreviousLevelType))
						{
							sizeOfChildData--;
							continue;
						}
					}
					mlFPPChildDataExcludingCOPTOCOP.add(mapTempInter);
				}
				float[] floatArrQTY 			= null;
				float[] floatArrDenominator 	= null;
				String[] strArrLevel 			= null;
				if(isReshipperSub && !bFlatReshipper)
				{
					floatArrQTY 			= new float[sizeOfChildData+1];
					floatArrDenominator 	= new float[sizeOfChildData+1];
					strArrLevel 			= new String[sizeOfChildData+1];
				}else
				{
					floatArrQTY 			= new float[sizeOfChildData];
					floatArrDenominator 	= new float[sizeOfChildData];
					strArrLevel 			= new String[sizeOfChildData];
				}
				int iFPPChildDataCOPTOCOPRelSize = mlFPPChildDataExcludingCOPTOCOP.size();
				for(int i=0; i < iFPPChildDataCOPTOCOPRelSize; i++)
				{
					mpTempInterExcludingCOPToCOP = (Map)mlFPPChildDataExcludingCOPTOCOP.get(i);
					String strRelAttrQty = (String)mpTempInterExcludingCOPToCOP.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					if(isReshipperSub && !bFlatReshipper)
					{
						floatArrQTY[0] = 1.0f;
						int iSizeOfChildData = sizeOfChildData+1;
						strArrLevel[sizeOfChildData] = String.valueOf(iSizeOfChildData);
						floatArrQTY[i+1] = (Float.valueOf(strRelAttrQty)).floatValue();
						strArrLevel[i] = (String)mpTempInterExcludingCOPToCOP.get("level");
					}else{
						floatArrQTY[i] = (Float.valueOf(strRelAttrQty)).floatValue();
						strArrLevel[i] = (String)mpTempInterExcludingCOPToCOP.get("level");
					}

				}

				int iCount = 0;

				if(isReshipperSub && !bFlatReshipper)
				{
					iCount = sizeOfChildData;
				}
				else{
					iCount = sizeOfChildData -1;
				}
				Map denominatorMap = new HashMap();
				String strKey = null;
				for(int i = 0; i<floatArrQTY.length; i++)
				{
					fTemp = 1.0f;
					for(int j=iCount; j>i; j--){
						fTemp1 = floatArrQTY[j] * fTemp;
						fTemp = fTemp1;
					}
					floatArrDenominator[i] = fTemp;				
					strKey = "level"+strArrLevel[i];
					denominatorMap.put(strKey, floatArrDenominator[i]);
				}
				fIntermediateSAPQty = (float) denominatorMap.get("level1");
				for(int i=0; i<objectList.size(); i++)
				{
					strBOMQty = "";
					if("SW".equalsIgnoreCase(strBUOM) || "SP".equalsIgnoreCase(strBUOM))
					{
						strBOMQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
					}else{
						mapTemp = (Map)objectList.get(i);
						strConnectionID = (String)mapTemp.get("id[connection]");
						strChildName = (String)mapTemp.get("name");
						strChildID = (String)mapTemp.get("id");
						strChildType = (String)mapTemp.get("type");
						strInterObjRelAttrQty = DomainRelationship.getAttributeValue(context,strConnectionID,ConstantsUtil.ATTRIBUTE_QUANTITY);
						strLevel = (String)mapTemp.get("IntermediateLevel");

						bdInterObjRelAttrQty = new BigDecimal(strInterObjRelAttrQty);

						if(null != strChildID && strChildID.length() > 0 && bdInterObjRelAttrQty.compareTo(BigDecimal.ZERO)!=0)
						{
							bdNumerator = bdBOMBaseQty.multiply(bdInterObjRelAttrQty);
							
							//SPEC: 11/03/2020: Null Check added for Defect:37014 -- START
							if(UIUtil.isNotNullAndNotEmpty(strLevel)){
							
								fdenominator=(float) denominatorMap.get("level"+strLevel);
								
								strDenominator=String.valueOf(fdenominator);
								//calculate BOM Quantity
								bdDenominator = new BigDecimal(strDenominator);
								if(bdDenominator.compareTo(BigDecimal.ZERO)!=0)
								{
									bdBOMQty = bdNumerator.divide(bdDenominator,3,RoundingMode.HALF_UP);
								}
							
							}
							//SPEC: 11/03/2020: Null Check added for Defect:37014 -- END
						}

						if(UIUtil.isNotNullAndNotEmpty(strLevel)){
							strBOMQty = String.valueOf(bdBOMQty);
						}
						if((bdBOMQty.compareTo(BigDecimal.ZERO)==0) || (bdBOMQty.compareTo(bdBOMQuantityCheck)>0))
						{
							strBOMQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
						}
						
						
					}
					vc.add(strBOMQty);
				}	
			}

			if(null != vc && vc.size()>0) {


				for(int k=0;k<vc.size();k++) {
					strCalcQTY = (String)vc.get(k);
					if(!BusinessUtil.isNotNullOrEmpty(strCalcQTY)) {
						strCalcQTY	 = DomainConstants.EMPTY_STRING;
					}
					strListQtyValues.add(strCalcQTY);
				}

			}


		} catch(Exception ex)
		{
			ex.printStackTrace();
		}
		mpReturn.put("strListQtyValues",strListQtyValues);
		mpReturn.put("fIntermediateSAPQty",fIntermediateSAPQty);
		return mpReturn;

	}



	private StringList getQuantityValue(Context context, String strObjectID,MapList mpListChildren) throws Exception {

		String strQTY = DomainConstants.EMPTY_STRING;
		float fQTY = 0;

		StringList strListQtyValues = new StringList(1);

		try {

			Map mParamList = new  HashMap();
			mParamList.put(ConstantsUtil.OBJECT_ID, strObjectID);
			Map hmArgMapParams = new HashMap();		
			hmArgMapParams.put("objectList", mpListChildren); 
			hmArgMapParams.put("paramList", mParamList);
			String[] argsArrQtyInput= JPO.packArgs(hmArgMapParams);

			Vector BOMQuantityData = getBOMQTYData(context, argsArrQtyInput);

			if(null != BOMQuantityData && BOMQuantityData.size()>0) {

				for(int k=0;k<BOMQuantityData.size();k++) {

					strQTY = (String)BOMQuantityData.get(k);
					if(!BusinessUtil.isNotNullOrEmpty(strQTY)) {
						strQTY	 = DomainConstants.EMPTY_STRING;
					}
					strListQtyValues.add(strQTY);
				}

			}	

		}catch (Exception e) {

			e.printStackTrace();

		}

		return strListQtyValues ;
	}
/**
 * SPEC: 11/06/2020 : Commented for Defect: 37071
 * @param context
 * @param strObjectID
 * @param mpListChildren
 * @param fIntermediateSAPQty
 * @param strBUOM
 * @return
 * @throws Exception
 */
	
	public StringList getTUPBOMQTYData(Context context, String strObjectID,MapList mpListChildren, Float fIntermediateSAPQty,String strBUOM) throws Exception {
		StringList slQtyValues = new StringList(1);
		try {
			BigDecimal bdCUPQty = BigDecimal.ZERO;
			BigDecimal bdBOMBaseQty = BigDecimal.ZERO;
			BigDecimal bdIntermediateSAPQty=BigDecimal.valueOf(fIntermediateSAPQty); 
			BigDecimal bdBOMQuantityCheck = new BigDecimal("9999999999.999"); 
			BigDecimal bdNumber = BigDecimal.ZERO;
			BigDecimal bdBOMQty = BigDecimal.ZERO;
			
			String strCUPQty 		= DomainConstants.EMPTY_STRING;
			String strBOMBaseQty 	= DomainConstants.EMPTY_STRING;
			String strTUPID 		= DomainConstants.EMPTY_STRING;
			String strRelWhere = new StringBuffer(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY).append("==TRUE").toString();
			
			DomainObject dObjFPP = null;
			
			String strCompQty		= null;
			String strBOMQty 		= null;
			String strConnectionID 	= null;
			
			Map mapTemp = null;
			
			MapList mlPart 			= new MapList();
			MapList mlTUPChildData 	= new MapList();
			
			StringList relationshipSelects = new StringList(1);
			relationshipSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			if (BusinessUtil.isNotNullOrEmpty(strObjectID)) {				
				
				dObjFPP = DomainObject.newInstance(context,strObjectID);
				strBOMBaseQty = dObjFPP.getInfo(context,ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);

				// Modified for both are marked as true 
					mlPart = dObjFPP.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_PGTRANSPORTUNIT, // Rel Pattern
							ConstantsUtil.TYPE_PGTRANSPORTUNITPART,     // Type Pattern
						SL_OBJECT_INFO_SELECT,                  	// Bus select
						null,             							// Rel select
						false,							 			// to side
						true,                           			// from side
						(short)1,					   				// recursion level
						null,						  				// Object Where Clause
						strRelWhere,0);  							// Rel Where Clause		

				if(null != mlPart && mlPart.size() > 0) {
					Map mapTUPData = (Map)mlPart.get(0);
					strTUPID = (String)mapTUPData.get(DomainConstants.SELECT_ID);
				}
				if (BusinessUtil.isNotNullOrEmpty(strTUPID) ) {
					DomainObject dObjTUP = DomainObject.newInstance(context,strTUPID);
					mlTUPChildData = dObjTUP.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_EBOM,  				// Rel Pattern
							ConstantsUtil.TYPE_PGMASTERCUSTOMERUNITPART, 	// Type Pattern
							null,                  							// Bus select
							relationshipSelects,             				// Rel select
							false,											// to side
							true,                           				// from side
							(short)0,					   					// recursion level
							null,						  					// Object Where Clause
							null);  										// Rel Where Clause
					if(null != mlTUPChildData && mlTUPChildData.size() > 0) {
						Map mapCUPData = (Map)mlTUPChildData.get(0);
						strCUPQty = (String)mapCUPData.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					}					
					//Converting Quantity to the float
					//coverting String To BigDecimal
					try {
						if(BusinessUtil.isNotNullOrEmpty(strBOMBaseQty)) {
							bdBOMBaseQty = new BigDecimal(strBOMBaseQty);
						}
						if(BusinessUtil.isNotNullOrEmpty(strCUPQty)) {
							bdCUPQty = new BigDecimal(strCUPQty);
						}
					} catch(Exception ex) {
						ex.printStackTrace();
					}
					if(null != mpListChildren) {
						int iObjSize = mpListChildren.size();
						
						for(int i=0;i<iObjSize;i++) {
							if(ConstantsUtil.BASEUNITOFMEASURE_SW.equalsIgnoreCase(strBUOM) || ConstantsUtil.BASEUNITOFMEASURE_SP.equalsIgnoreCase(strBUOM)){
								strBOMQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
							}else{
								//flBOMQty = 0;
								bdBOMQty = BigDecimal.ZERO;
								strBOMQty = "";
								mapTemp = (Map)mpListChildren.get(i);
								strConnectionID = (String)mapTemp.get(DomainRelationship.SELECT_ID);							
								strCompQty = DomainRelationship.getAttributeValue(context,strConnectionID,ConstantsUtil.ATTRIBUTE_QUANTITY);

								if(BusinessUtil.isNotNullOrEmpty(strCompQty)) {
									bdNumber = new BigDecimal(strCompQty);
								}
								//BOM Quantity Calculation
								if(bdCUPQty.compareTo(BigDecimal.ZERO)!=0)
									bdBOMQty = bdBOMBaseQty.divide(bdCUPQty,5,RoundingMode.HALF_UP);
									bdBOMQty = bdBOMQty.multiply(bdNumber);
								//if(fIntermediateSAPQty > 0)
									bdBOMQty = bdBOMQty.divide(bdIntermediateSAPQty,5,RoundingMode.HALF_UP);
								//Convert this float to String
								strBOMQty = String.valueOf(bdBOMQty);
								if((bdBOMQty.compareTo(BigDecimal.ZERO)==0) || (bdBOMQty.compareTo(bdBOMQuantityCheck)>0)) {
									strBOMQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
								}
							}
							slQtyValues.add(strBOMQty);
						}
					}
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			//throw ex;
		}
		return slQtyValues;
	}
	

	//SPEC: 11/06/2020 : Commented for Defect: 37071 ##-- START

	/*public StringList getTUPBOMQTYData(Context context, String strObjectID,MapList mpListChildren, Float fIntermediateSAPQty,String strBUOM) throws Exception {
		StringList slQtyValues = new StringList(1);
		try {
			float flMCUPQty = 0;
			float flBOMBaseQty = 0;
			String strCUPQty = DomainConstants.EMPTY_STRING;
			String strBOMBaseQty = DomainConstants.EMPTY_STRING;
			String strTUPID = DomainConstants.EMPTY_STRING;
			StringList relationshipSelects = new StringList(1);
			relationshipSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			if (BusinessUtil.isNotNullOrEmpty(strObjectID)) {				
				String strRelWhere = new StringBuffer(ConstantsUtil.SELECT_ATTRIBUTE_PGISPRIMARY).append("==TRUE").toString();
				DomainObject dObjFPP = DomainObject.newInstance(context,strObjectID);
				strBOMBaseQty = dObjFPP.getInfo(context,ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);

				MapList mlPart = dObjFPP.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_PGTRANSPORTUNIT,  // Rel Pattern
						ConstantsUtil.TYPE_PGTRANSPORTUNITPART,      //Type Pattern
						SL_OBJECT_INFO_SELECT,                  //  bus select
						null,             //   Rel select
						true,							 // to side
						true,                           // from side
						(short)1,					   //  recursion level
						null,						  // Object Where Clause
						strRelWhere,0);  					// Rel Where Clause		

				if(null != mlPart && mlPart.size() > 0) {
					Map mapTUPData = (Map)mlPart.get(0);
					strTUPID = (String)mapTUPData.get(DomainConstants.SELECT_ID);
				}
				if (BusinessUtil.isNotNullOrEmpty(strTUPID) ) {
					DomainObject dObjTUP = DomainObject.newInstance(context,strTUPID);
					MapList mlTUPChildData = dObjTUP.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_EBOM,  // Rel Pattern
							ConstantsUtil.TYPE_PGMASTERCUSTOMERUNITPART,      //Type Pattern
							null,                  //  bus select
							relationshipSelects,             //   Rel select
							false,							 // to side
							true,                           // from side
							(short)0,					   //  recursion level
							null,						  // Object Where Clause
							null);  
					if(null != mlTUPChildData && mlTUPChildData.size() > 0) {
						Map mapCUPData = (Map)mlTUPChildData.get(0);
						strCUPQty = (String)mapCUPData.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					}					
					try {
						if(BusinessUtil.isNotNullOrEmpty(strBOMBaseQty)) {
							flBOMBaseQty = (Float.valueOf(strBOMBaseQty)).floatValue();
						}
						if(BusinessUtil.isNotNullOrEmpty(strCUPQty)) {
							flMCUPQty = (Float.valueOf(strCUPQty)).floatValue();
						}
					} catch(Exception ex) {
						ex.printStackTrace();
					}
					
					
					
					if(null != mpListChildren) {
						float flNumber = 0;
						float flBOMQty = 0;
						String strCompQty = null;
						String strBOMQty = null;
						String strConnectionID = null;
						int iObjSize = mpListChildren.size();
						Map mapTemp = null;
						for(int i=0;i<iObjSize;i++) {
							if("SW".equalsIgnoreCase(strBUOM) || "SP".equalsIgnoreCase(strBUOM)){
								strBOMQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
							}else{
								flBOMQty = 0;
								strBOMQty = "";
								mapTemp = (Map)mpListChildren.get(i);
								strConnectionID = (String)mapTemp.get(DomainRelationship.SELECT_ID);							
								strCompQty = DomainRelationship.getAttributeValue(context,strConnectionID,ConstantsUtil.ATTRIBUTE_QUANTITY);

								if(BusinessUtil.isNotNullOrEmpty(strCompQty)) {
									flNumber = (Float.valueOf(strCompQty)).floatValue();
								}
								if(flMCUPQty != 0)
									flBOMQty = (flBOMBaseQty / flMCUPQty) * flNumber;
								if(fIntermediateSAPQty > 0)
									flBOMQty = flBOMQty / fIntermediateSAPQty;
								strBOMQty = String.valueOf(flBOMQty);
								if(flBOMQty == 0 || flBOMQty > 9999999999.999) {
									strBOMQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
								}
							}
							slQtyValues.add(strBOMQty);
						}
					}
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return slQtyValues;
	}


*/

	//SPEC: 11/06/2020 : Commented for Defect: 37071 ##-- END
	

	private StringList getSubstituteGroupValue(Context context, String strObjectID,MapList mpListChildren) throws Exception {

		String strGroup = DomainConstants.EMPTY_STRING;
		float fQTY = 0;

		StringList slGroupValues = new StringList(1);

		try {

			Map mParamList = new  HashMap();
			mParamList.put("objectId", strObjectID);
			Map hmArgMapParams = new HashMap();		
			hmArgMapParams.put("objectList", mpListChildren); 
			hmArgMapParams.put("paramList", mParamList);
			String[] strArrArgsSubInput= JPO.packArgs(hmArgMapParams);

			Vector vBOMGroupData =getSubstituteFlag(context, strArrArgsSubInput);

			if(null != vBOMGroupData && vBOMGroupData.size()>0) {

				for(int k=0;k<vBOMGroupData.size();k++) {

					strGroup = (String)vBOMGroupData.get(k);
					if(!BusinessUtil.isNotNullOrEmpty(strGroup)) {
						strGroup	 = DomainConstants.EMPTY_STRING;
					}
					slGroupValues.add(strGroup);
				}

			}		

		}catch (Exception e) {

			e.printStackTrace();
			slGroupValues = new StringList();
		}		
		return slGroupValues ;
	}


	public Vector getSubstituteFlag(Context context, String args[])
	{
		Vector vc = new Vector();
		char cAltItem1 = '9';
		char cAltItem2 = 'A';

		try {
			Map paramMap = (Map)JPO.unpackArgs(args);
			MapList objectList = (MapList)paramMap.get("objectList");
			if(objectList != null)
			{
				int objectListSize = objectList.size();
				Map mtempMap = null;
				int iCounter = 0;
				String strRelName = null;
				String strFPPGroupingId = "";
				String strCOPinCOP = "";
				String strFPPId = "";
				String strCOPIdentical = "";
				StringList slCOPInCOP =  new StringList(1);
				int iCOPInCOP = 0;
				for(int i=0;i<objectListSize;i++)
				{
					mtempMap = (Map)objectList.get(i);
					Object substituteInterId = (Object) (mtempMap).get("frommid["+ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE+"].to.id");
					Object oAlternateIds = (Object) (mtempMap).get("from["+DomainConstants.RELATIONSHIP_ALTERNATE+"].to.id");
					String strIsDirectComp = (String) (mtempMap).get("IsDirectComponent");
					strRelName = (String) (mtempMap).get("relationship");
					strCOPinCOP = (String) (mtempMap).get("COPinCOP");
					strFPPId = (String) (mtempMap).get("id");
					if(UIUtil.isNotNullAndNotEmpty(strCOPinCOP) && !slCOPInCOP.contains(strCOPinCOP))
					{
						slCOPInCOP.add(strCOPinCOP);
						if(iCounter > 0)
						{
							if (cAltItem2 == 'Z') {
								cAltItem2 = 'A';
								cAltItem1--;
							} else {
								cAltItem2++;
							}
						}
						String strSubCOP = cAltItem1 + "" + cAltItem2;
						iCOPInCOP = 0;
						for(int m=0;m<objectListSize;m++)
						{
							Map mptempMap = (Map)objectList.get(m);
							strCOPIdentical = (String) (mptempMap).get("COPinCOP");
							strFPPGroupingId = (String) (mptempMap).get("id");
							if((!strFPPId.equals(strFPPGroupingId)) && strCOPinCOP.equals(strCOPIdentical))
							{
								vc.add(strSubCOP);
								if(iCOPInCOP>0)
								{
									iCounter++ ;
								}
								iCOPInCOP++;
							}
						}
						if(iCOPInCOP>0){
							vc.add(strSubCOP);
						}
						else{
							vc.add("");
						}
					}else if(UIUtil.isNotNullAndNotEmpty(strCOPinCOP) && slCOPInCOP.contains(strCOPinCOP)){
						continue;
					}else{
						if((null != substituteInterId && "true".equals(strIsDirectComp)) || (!(DomainConstants.RELATIONSHIP_ALTERNATE.equals(strRelName)) && null != oAlternateIds && "true".equals(strIsDirectComp))) {
							if(iCounter > 0)
							{
								if (cAltItem2 == 'Z') {
									cAltItem2 = 'A';
									cAltItem1--;
								} else {
									cAltItem2++;				
								}
							}
							vc.add(cAltItem1 + "" + cAltItem2);
							iCounter++ ;
						} else {
							if(ConstantsUtil.RELATIONSHIP_EBOMSUBSTITUTE.equals(strRelName) || DomainConstants.RELATIONSHIP_ALTERNATE.equals(strRelName)) {
								vc.add(cAltItem1 + "" + cAltItem2);
							} else {
								vc.add(" ");
								continue;
							}
						}
					}
				}
			}
		} catch(Exception e)
		{
			e.printStackTrace();
		}
		return vc;
	}

	public MapList getPartBOMQTYData(Context context, String strObjectID,MapList mpListChildren) throws Exception {
		MapList mlMinMaxQtyValues = new MapList();
		try {
			float flSAPBOMBaseQty = 0;
			float flBOMBaseQty = 1;
			StringList slBCF = new StringList(2);
			slBCF.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			slBCF.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
			if (BusinessUtil.isNotNullOrEmpty(strObjectID)) {
				DomainObject dObjFPP = DomainObject.newInstance(context,strObjectID);
				Map mapBCF = (Map)dObjFPP.getInfo(context,slBCF);
				String strSAPBOMBaseQty = (String)mapBCF.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
				String strBOMBaseQty = (String)mapBCF.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY);
				if(BusinessUtil.isNotNullOrEmpty(strSAPBOMBaseQty)) {
					flSAPBOMBaseQty = (Float.valueOf(strSAPBOMBaseQty)).floatValue();
				}
				if(BusinessUtil.isNotNullOrEmpty(strBOMBaseQty)) {
					flBOMBaseQty = (Float.valueOf(strBOMBaseQty)).floatValue();
				}
				if(null != mpListChildren) {
					String strMinQty = null;
					String strMaxQty = null;
					String strMinVal = null;
					String strMaxVal = null;
					float fltMinQty = 0;
					float fltMaxQty = 0;
					float flMinQuantity = 0;
					float flMaxQuantity = 0;
					String strBOMQty = null;
					String strQuantityVal = null;
					Map mapTemp = null;
					float fltBOMQty = 0;
					float flQuantity = 0;
					for(int i=0;i<mpListChildren.size();i++) {
						mapTemp = (Map)mpListChildren.get(i);
						strQuantityVal 	= (String)mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
						strMinVal      	= (String)mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_MINACTUAL_PERCENTWET);
						strMaxVal		 	= (String)mapTemp.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXACTUALPERCENTWET);
						if(BusinessUtil.isNotNullOrEmpty(strQuantityVal)) {
							flQuantity = (Float.valueOf(strQuantityVal)).floatValue();
						}
						if(flBOMBaseQty != 0) {
							fltBOMQty = (flSAPBOMBaseQty/flBOMBaseQty)*flQuantity;
						}
						strBOMQty = String.valueOf(fltBOMQty);
						if(fltBOMQty == 0 || fltBOMQty > 9999999999.999) {
							strBOMQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
						}
						if(BusinessUtil.isNotNullOrEmpty(strMinVal)) {
							flMinQuantity = (Float.valueOf(strMinVal)).floatValue();
						}
						if(flBOMBaseQty != 0) {
							fltMinQty = (flSAPBOMBaseQty/flBOMBaseQty)*flMinQuantity;
						}
						strMinQty = String.valueOf(fltMinQty);
						if(fltMinQty == 0 || fltMinQty > 9999999999.999) {
							strMinQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
						}
						if(BusinessUtil.isNotNullOrEmpty(strMaxVal)) {
							flMaxQuantity = (Float.valueOf(strMaxVal)).floatValue();
						}
						if(flBOMBaseQty != 0) {
							fltMaxQty = (flSAPBOMBaseQty/flBOMBaseQty)*flMaxQuantity;
						}
						strMaxQty = String.valueOf(fltMaxQty);
						if(fltMaxQty == 0 || fltMaxQty > 9999999999.999) {
							strMaxQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
						}
						Map mpMinMaxQtyValue = new HashMap();
						mpMinMaxQtyValue.put("Qty",strBOMQty);
						mpMinMaxQtyValue.put("MinQty",strMinQty);
						mpMinMaxQtyValue.put("MaxQty",strMaxQty);
						mlMinMaxQtyValues.add(mpMinMaxQtyValue);
						fltBOMQty = 0;
						flQuantity = 0;fltMaxQty = 0;
						flQuantity = 0;
						flMinQuantity = 0;
						flMaxQuantity = 0;
						strBOMQty = DomainConstants.EMPTY_STRING;
						strMinQty = DomainConstants.EMPTY_STRING;
						strMaxQty = DomainConstants.EMPTY_STRING;
					}
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return mlMinMaxQtyValues;
	}






	public MapList getValidFormulationProcess(Context context, String strID, String strFOPNextRev) throws Exception{
		DomainObject doTS = null;
		MapList mpListChildFP = new MapList();
		String strFPObjWhere = DomainConstants.EMPTY_STRING;
		try{			
			if(BusinessUtil.isNotNullOrEmpty(strID)) {
				doTS = DomainObject.newInstance(context, strID);
				if(UIUtil.isNotNullAndNotEmpty(strFOPNextRev)){
					strFPObjWhere = "(current==Release && (revision==last||next.current!= Release))";
				} else{
					strFPObjWhere = "revision == last";						
				}
				mpListChildFP = doTS.getRelatedObjects(context,ConstantsUtil.RELATIONSHIP_PLANNEDFOR, ConstantsUtil.TYPE_FORMULATIONPROCESS, SL_OBJECT_INFO_SELECT, SL_RELATION_INFO_SELECT_OTHERS, false, true,(short) 1, strFPObjWhere, "", 0);

			}	

		}catch(Exception ex){
			throw ex;	
		}
		return mpListChildFP;
	}


	private StringList calculateMaxMinQtyForFOPChild(Context context,String strPLBOMRelId, String strSAPBOMBaseQty,String strBaseUOMParent,String strBaseUOMChild,boolean bSubstitute) {
		StringList slReturn = new StringList(3);
		final String ATTRIBUTE_TOTAL= PropertyUtil.getSchemaProperty("attribute_Total");
		final String SELECT_ATTRIBUTE_TOTAL = "attribute[" + ATTRIBUTE_TOTAL + "].inputvalue";
		String strMin = DomainConstants.EMPTY_STRING;
		String strMax = DomainConstants.EMPTY_STRING;
		String strQty = DomainConstants.EMPTY_STRING;
		final String  ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT  = "Maximum Actual Percent Wet";
		final String ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT = "Minimum Actual Percent Wet";

		final String SELECT_ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT = "attribute[" + ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT + "]";
		final String SELECT_ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT = "attribute[" + ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT + "]";

		boolean bProcessingLoss100Percent = false;
		double dBaseQty =  100;
		double dSAPBOMBaseQty =  1000;
		double dPercentWet = 0;
		double dMinimumPercentWet = 0;
		double dMaximumPercentWet = 0;
		double dLoss = 0;
		double dDryPercent = 0;
		double dWeightWeightSAP = 0;
		double dDryWeight = 0;
		double dTargetWeightWet = 0;
		DecimalFormat decimalformatter = new DecimalFormat(PATTERN_DECIMALFORMAT);
		StringList slDefaultQTY = new StringList(3);
		slDefaultQTY.add(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED); //BOM Minimum QTY
		slDefaultQTY.add(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED);	//BOM Maximum QTY
		slDefaultQTY.add(ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED);	//BOM QTY
		if(!BusinessUtil.isNotNullOrEmpty(strBaseUOMParent) || !BusinessUtil.isNotNullOrEmpty(strBaseUOMChild) || !strBaseUOMChild.equalsIgnoreCase(strBaseUOMParent) ) {
			return slDefaultQTY;
		}
		if(BusinessUtil.isNotNullOrEmpty(strSAPBOMBaseQty)) {
			dSAPBOMBaseQty = parseValue(strSAPBOMBaseQty);
		}
		try {
			StringList slBusSelect = new StringList(2);
			slBusSelect.add(DomainConstants.SELECT_ID);
			slBusSelect.add(DomainConstants.SELECT_NAME);
			StringList slRelSelect = new StringList(6);
			slRelSelect.add("attribute["+ConstantsUtil.ATTRIBUTE_QUANTITY+"].inputvalue");
			slRelSelect.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			slRelSelect.add(SELECT_ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT);
			slRelSelect.add(SELECT_ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT);
			slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
			slRelSelect.add(SELECT_ATTRIBUTE_TOTAL);  
			slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
			String strTargetWetValue = DomainConstants.EMPTY_STRING;
			String strTempPhaseName = DomainConstants.EMPTY_STRING;
			String PercentWet = DomainConstants.EMPTY_STRING;
			String MinimumPercentWet = DomainConstants.EMPTY_STRING;
			String MaximumPercentWet = DomainConstants.EMPTY_STRING;
			String strTempLossValue = DomainConstants.EMPTY_STRING;
			String strDryPercentValue = DomainConstants.EMPTY_STRING;
			Map mpTempData = null;
			if(null != strPLBOMRelId) {
				String sArrRelId[] = new String[1];
				sArrRelId[0] = strPLBOMRelId;
				MapList mlPLBOMSub = (MapList)DomainRelationship.getInfo(context, sArrRelId, slRelSelect);
				if(null != mlPLBOMSub && mlPLBOMSub.size() > 0) {
					mpTempData 		= (Map) mlPLBOMSub.get(0);
					PercentWet 			= (String)mpTempData.get("attribute["+ConstantsUtil.ATTRIBUTE_QUANTITY+"].inputvalue");
					MinimumPercentWet 	= (String)mpTempData.get(SELECT_ATTRIBUTE_MINIMUMACTUALPERCENTWEIGHT);
					MaximumPercentWet 	= (String)mpTempData.get(SELECT_ATTRIBUTE_MAXIMUMACTUALPERCENTWEIGHT);
					strTempLossValue 	= (String)mpTempData.get(ConstantsUtil.SELECT_ATTRIBUTE_LOSS);
					strDryPercentValue 	= (String)mpTempData.get(SELECT_ATTRIBUTE_TOTAL);
					strTargetWetValue	= (String)mpTempData.get(ConstantsUtil.SELECT_ATTRIBUTE_TARGETWETWEIGHT);
					if(BusinessUtil.isNotNullOrEmpty(PercentWet)) {
						dPercentWet = parseFOPQuantityValue(PercentWet);
					}
					if(BusinessUtil.isNotNullOrEmpty(MinimumPercentWet)) {
						dMinimumPercentWet = parseFOPQuantityValue(MinimumPercentWet);
					}
					if(BusinessUtil.isNotNullOrEmpty(MaximumPercentWet)) {
						dMaximumPercentWet = parseFOPQuantityValue(MaximumPercentWet);
					}
					if(BusinessUtil.isNotNullOrEmpty(strTempLossValue)) {
						dLoss = parseFOPQuantityValue(strTempLossValue);
						if(dLoss == 100.0)
						{
							bProcessingLoss100Percent = true;
						}	
					}
					if(BusinessUtil.isNotNullOrEmpty(strDryPercentValue)) {
						dDryPercent = parseFOPQuantityValue(strDryPercentValue);
					}
				}
				BigDecimal bdBaseQTY = BigDecimal.valueOf(dBaseQty);
				BigDecimal bdLoss 	= BigDecimal.valueOf((100-dLoss));
				if(dMinimumPercentWet>0) {
					BigDecimal bdMinQuantityVal=BigDecimal.valueOf(dMinimumPercentWet);
					bdMinQuantityVal = bdMinQuantityVal.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
					if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
						bdMinQuantityVal = (BigDecimal)divideBigDecimalValues(bdMinQuantityVal,bdBaseQTY);
					}
					dMinimumPercentWet = bdMinQuantityVal.doubleValue();
				}
				if(dMaximumPercentWet>0) {
					BigDecimal bdMaxQuantityVal=BigDecimal.valueOf(dMaximumPercentWet);
					bdMaxQuantityVal = bdMaxQuantityVal.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
					if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
						bdMaxQuantityVal = (BigDecimal)divideBigDecimalValues(bdMaxQuantityVal,bdBaseQTY);
					}
					dMaximumPercentWet = bdMaxQuantityVal.doubleValue();
				}
				if (!bSubstitute) {
					if(dPercentWet>0) {
						if(dLoss>0.0){
							dDryWeight = (100-dLoss) * dPercentWet; // 100 * 20 = 2000
							dWeightWeightSAP = (dDryWeight / (100-dLoss)) * dSAPBOMBaseQty; // 20 * 100 = 2000 
							dWeightWeightSAP = dWeightWeightSAP / dBaseQty ;
						}
						else{
							dWeightWeightSAP = dPercentWet / dBaseQty ;
							dWeightWeightSAP = dWeightWeightSAP * dSAPBOMBaseQty;
						}

						BigDecimal bdWeightWeightSAP = BigDecimal.valueOf(dPercentWet);
						if(dLoss == 100.0)
						{
							bdWeightWeightSAP =  bdWeightWeightSAP.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
							if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
								bdWeightWeightSAP = (BigDecimal)divideBigDecimalValues(bdWeightWeightSAP,bdBaseQTY);
							}
						}else if(dLoss>0.0){
							if(bdLoss.compareTo(BigDecimal.ZERO)!=0) {
								bdWeightWeightSAP =  bdWeightWeightSAP.multiply(bdLoss);
								bdWeightWeightSAP = (BigDecimal)divideBigDecimalValues(bdWeightWeightSAP,bdLoss);
							}
							bdWeightWeightSAP =  bdWeightWeightSAP.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
							if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
								bdWeightWeightSAP = (BigDecimal)divideBigDecimalValues(bdWeightWeightSAP,bdBaseQTY);
							}	
						}
						else{
							bdWeightWeightSAP =  bdWeightWeightSAP.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
							if(bdBaseQTY.compareTo(BigDecimal.ZERO)!=0) {
								bdWeightWeightSAP = (BigDecimal)divideBigDecimalValues(bdWeightWeightSAP,bdBaseQTY);
							}
						}
						dWeightWeightSAP =  bdWeightWeightSAP.doubleValue();
					}
					if(dDryPercent>0 && !bProcessingLoss100Percent) {					
						BigDecimal bdDryWeightSAP = BigDecimal.valueOf(dDryPercent);
						bdDryWeightSAP =  bdDryWeightSAP.multiply(BigDecimal.valueOf(dSAPBOMBaseQty));
						if(bdLoss.compareTo(BigDecimal.ZERO)!=0) {
							bdDryWeightSAP = (BigDecimal)divideBigDecimalValues(bdDryWeightSAP,bdLoss);
						}
						dWeightWeightSAP =  bdDryWeightSAP.doubleValue();
					}
				} else if (bSubstitute && BusinessUtil.isNotNullOrEmpty(PercentWet)) {
					
					if(bdBaseQTY.compareTo(BigDecimal.ZERO) > 0) {
						dTargetWeightWet = parseFOPQuantityValue(PercentWet);
						BigDecimal bdWeightWeightSAP = BigDecimal.valueOf(dSAPBOMBaseQty);
						bdWeightWeightSAP = bdWeightWeightSAP.divide(bdBaseQTY);
						bdWeightWeightSAP = (bdWeightWeightSAP.multiply(BigDecimal.valueOf(dTargetWeightWet))).setScale(3,RoundingMode.HALF_UP);
						dWeightWeightSAP =  bdWeightWeightSAP.doubleValue();
					}	
				}
				if(dMinimumPercentWet <= 0 || dMinimumPercentWet > 9999999999.999) {
					strMin = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
				} else {
					strMin = String.valueOf(decimalformatter.format(dMinimumPercentWet));
				}
				if(dMaximumPercentWet <= 0 || dMaximumPercentWet > 9999999999.999) {
					strMax = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
				} else {
					strMax = String.valueOf(decimalformatter.format(dMaximumPercentWet));
				}
				if(dWeightWeightSAP <= 0 || dWeightWeightSAP > 9999999999.999) {
					strQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
				} else {
					strQty = String.valueOf(decimalformatter.format(dWeightWeightSAP));
				}
				slReturn.add(strMin);
				slReturn.add(strMax);
				slReturn.add(strQty);
			}
		} catch(Exception e) {
			e.printStackTrace();
			return slDefaultQTY;
		}
		return slReturn;
	}


	public static String convertPLMDateToSAP(String strDate) {		
		String strSAPDate = DomainConstants.EMPTY_STRING;;
		Date dMatrixDate = null;
		SimpleDateFormat formatter = null;
		SimpleDateFormat sapFormatter = null;
		try
		{
			if (UIUtil.isNotNullAndNotEmpty(strDate)){
				formatter = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat());			
				sapFormatter = new SimpleDateFormat(ConstantsUtil.SAP_DATE_FORMAT);							
				dMatrixDate = formatter.parse(strDate);
				strSAPDate = sapFormatter.format(dMatrixDate);
			}
		}catch (Exception e){
			// System.out.println(e.toString());
			//  e.printStackTrace();
		}		
		return(strSAPDate);
	}



	public ArrayList getBaseFormulaRows(Context context, String strBSFName, String strBSFRev, 
			String strFindNumber, String strPgPhaseName, String strParentName, String strParentEffectiveDate, 
			String strParentBOMBaseQty, String strBOMUsage, String strTSID) {
		String[][] saReturn = null;
		String strType = DomainConstants.EMPTY_STRING;
		String strName = DomainConstants.EMPTY_STRING;
		String strRev = DomainConstants.EMPTY_STRING;
		String strRelId = DomainConstants.EMPTY_STRING;
		String strChildObjId = DomainConstants.EMPTY_STRING;
		String strRowFindNumber = DomainConstants.EMPTY_STRING;
		String strComponentNumber = DomainConstants.EMPTY_STRING;
		String strQuantity = DomainConstants.EMPTY_STRING;
		String strTarget = DomainConstants.EMPTY_STRING;
		String strLowerLim = DomainConstants.EMPTY_STRING;
		String strUpperLim = DomainConstants.EMPTY_STRING;
		String strPosIndicator = DomainConstants.EMPTY_STRING;
		String strOptComponent = DomainConstants.EMPTY_STRING;
		String strComment = DomainConstants.EMPTY_STRING;
		String strValidFromDateComp = DomainConstants.EMPTY_STRING;
		String strBOMNumber = DomainConstants.EMPTY_STRING;
		String strSubstFlag = DomainConstants.EMPTY_STRING;
		String strChildBUOM = DomainConstants.EMPTY_STRING;

		try {

			DomainObject domBSF = DomainObject.newInstance(context, strTSID);

			StringList slBusSelect = new StringList(6);
			slBusSelect.add(DomainConstants.SELECT_TYPE);
			slBusSelect.add(DomainConstants.SELECT_NAME);
			slBusSelect.add(DomainConstants.SELECT_REVISION);
			slBusSelect.add(DomainConstants.SELECT_ID);
			slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE);
			slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
			slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

			StringList slRelSelect = new StringList(8);
			slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
			slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
			slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
			slRelSelect.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
			slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
			slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
			slRelSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
			MapList mlBSFChildObjList = domBSF.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_EBOM, 	// rel pattern
					ConstantsUtil.TYPE_PRODUCTDATA,     // type pattern
					slBusSelect,
					slRelSelect,
					false,                  			// to side
					true,                   			// from side 
					(short)1,               			// recursion level
					DomainConstants.EMPTY_STRING,       // object where clause
					DomainConstants.EMPTY_STRING,0); 

			Iterator bsfChildItr = mlBSFChildObjList.iterator();

			while (bsfChildItr.hasNext()) {

				Map hmChildMap = (HashMap) bsfChildItr.next();

				strType = (String) hmChildMap.get(DomainConstants.SELECT_TYPE);
				strName = (String) hmChildMap.get(DomainConstants.SELECT_NAME);
				strRev = (String) hmChildMap.get(DomainConstants.SELECT_REVISION);
				strRelId = (String) hmChildMap.get(DomainConstants.SELECT_RELATIONSHIP_ID);
				strChildObjId = (String) hmChildMap.get(DomainConstants.SELECT_ID);
				strRowFindNumber = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_FINDNUMBER);
				strQuantity = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
				strTarget = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY);
				strLowerLim = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMINCALCQUANTITY);
				strUpperLim = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY);
				strPosIndicator = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR);
				strOptComponent = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT);
				strComment = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
				strChildBUOM = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);	
				strValidFromDateComp = (String) hmChildMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
				//strValidFromDateComp = convertPLMDateToSAP(strValidFromDateComp);

				if (strType.startsWith(ConstantsUtil.PGMASTER)) {
					buildFCBOMArray(context, strPgPhaseName, strRowFindNumber,
							strParentName, strBOMUsage, strParentEffectiveDate,
							strComponentNumber, strQuantity, strSubstFlag,
							strUpperLim, strTarget, strLowerLim,
							strValidFromDateComp, strBOMNumber, strParentBOMBaseQty,
							strPosIndicator, strRelId, strName, strRev, false, strChildObjId, "","", strChildBUOM);

					getIndividualsFromMaster(context, strParentName,strParentEffectiveDate, strParentBOMBaseQty, 
							strPgPhaseName, strFindNumber, strBOMNumber, strType,
							strName, strRev, strBOMUsage, strQuantity, strUpperLim,
							strTarget, strLowerLim, strValidFromDateComp, strPosIndicator, true, strChildObjId);
				} else {
					buildFCBOMArray(context, strPgPhaseName, strRowFindNumber,
							strParentName, strBOMUsage, strParentEffectiveDate,
							strComponentNumber, strQuantity, strSubstFlag,
							strUpperLim, strTarget, strLowerLim,
							strValidFromDateComp, strBOMNumber, strParentBOMBaseQty,
							strPosIndicator, strRelId, strName, strRev, false, strChildObjId, strOptComponent,strComment, strChildBUOM);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return alBOMFC;
	}


	public void buildFCBOMArray(Context context, String strPgPhase, String strFindNumber,
			String strName, String strBomUsage, String strValidFromDate,
			String strComponentName, String strQuantity, String strSubstituteFlag,
			String strUpperLimit, String strTarget, String strLowerLimit,
			String strValidFromDateComponent, String strBOMNumber,
			String strBOMBaseQuantity, String strPositionIndicator, String strRelId,
			String strGCAS, String strVersion, boolean bOnlySendChildren, String strTSID, String strOptComponent,String strComment, String strChildBUOM) {
		boolean bIgnoreBlankTarget = false;
		if (strTarget.equals("")) {
			_AbortReason = "Aborting BOM because target is null for " + strComponentName;
			bIgnoreBlankTarget = true;
		}

		String[] saTemp = new String[BOM_ARRAY_SIZE];
		String[][] saSubs = null;
		String strTSName = DomainConstants.EMPTY_STRING;	
		String strTSType = DomainConstants.EMPTY_STRING;	
		String strTSRev  = DomainConstants.EMPTY_STRING;
		String strValidFromDateSub = DomainConstants.EMPTY_STRING;
		String strSubComponentNumber = DomainConstants.EMPTY_STRING;

		saTemp[ConstantsUtil.INDEX_ALT_BOM] = ConstantsUtil.VALUE_ALT_BOM;
		saTemp[ConstantsUtil.INDEX_BOM_STATUS] = ConstantsUtil.VALUE_BOM_STATUS;
		saTemp[ConstantsUtil.INDEX_ITEM_CATEGORY] = ConstantsUtil.VALUE_ITEM_CATEGORY;
		saTemp[ConstantsUtil.INDEX_BOM_TEXT] = _ParentMatlNumber + "." + strParentRev;	
		saTemp[ConstantsUtil.INDEX_ALT_BOM_TEXT] = ConstantsUtil.VALUE_ALT_BOM_TEXT;

		if (!strSubstituteFlag.equals("")) {
			saTemp[ConstantsUtil.INDEX_SUBSTITUTE_FLAG] = strSubstituteFlag;
			saTemp[ConstantsUtil.INDEX_USAGE_PROBABILITY] = ConstantsUtil.VALUE_USAGE_PROBABILITY;
		} else {
			saTemp[ConstantsUtil.INDEX_SUBSTITUTE_FLAG] = "";
			saTemp[ConstantsUtil.INDEX_USAGE_PROBABILITY] = "";
		}

		saTemp[ConstantsUtil.INDEX_MATERIAL_NUMBER] = _ParentMatlNumber;
		saTemp[ConstantsUtil.INDEX_BOM_USAGE] = strBomUsage;
		saTemp[ConstantsUtil.INDEX_VALID_FROM_DATE_PARENT] = strValidFromDate;
		saTemp[ConstantsUtil.INDEX_COMPONENT_NAME] = strComponentName;
		if(strParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT) && !strChildBUOM.equalsIgnoreCase(strParentBUOM)) {

			saTemp[ConstantsUtil.INDEX_QUANTITY] = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
			saTemp[ConstantsUtil.INDEX_UPPER_LIMIT] = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
			saTemp[ConstantsUtil.INDEX_LOWER_LIMIT] = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
		} else {

			saTemp[ConstantsUtil.INDEX_QUANTITY] = strQuantity;
			saTemp[ConstantsUtil.INDEX_UPPER_LIMIT] = strUpperLimit;
			saTemp[ConstantsUtil.INDEX_LOWER_LIMIT] = strLowerLimit;
		}		

		if(bIgnoreBlankTarget || (strParentType.equalsIgnoreCase(ConstantsUtil.TYPE_PGFINISHEDPRODUCT) && !strChildBUOM.equalsIgnoreCase(strParentBUOM))) {
			saTemp[ConstantsUtil.INDEX_TARGET] = "-9.99";
		} else {
			saTemp[ConstantsUtil.INDEX_TARGET] = strTarget;	
		}			
		saTemp[ConstantsUtil.INDEX_FIND_NUMBER] = strFindNumber;
		saTemp[ConstantsUtil.INDEX_VALID_FROM_DATE_CHILD] = strValidFromDateComponent;
		saTemp[ConstantsUtil.INDEX_PHASE_NAME] = strPgPhase;
		saTemp[ConstantsUtil.INDEX_CONFIRMED_QUANTITY] = strBOMBaseQuantity;
		saTemp[ConstantsUtil.INDEX_SORT_STRING] = strPositionIndicator;
		saTemp[OPT_COMPONENT] = strOptComponent;
		saTemp[COMMENT] = strComment;
		saTemp[ConstantsUtil.INDEX_BOM_ITEM_NUMBER] = strBOMNumber;
		saTemp[OBJECT_ID] = strTSID;
		if(bCreatingSubsRows) {
			saTemp[DISPLAY_OBJECT_ID] = strSubsDispId;
		} else {
			saTemp[DISPLAY_OBJECT_ID] = strTSID;	
		}
		if (saTemp[ConstantsUtil.INDEX_UPPER_LIMIT] == null || saTemp[ConstantsUtil.INDEX_UPPER_LIMIT].equals("")) {
			saTemp[ConstantsUtil.INDEX_RANGE_FLAG] = "";
		} else 
			saTemp[ConstantsUtil.INDEX_RANGE_FLAG] = ConstantsUtil.VALUE_RANGE_FLAG;

		saSubs = getSubs(context, strRelId);

		if (saSubs!=null) {
			saTemp[ConstantsUtil.INDEX_SUBSTITUTE_FLAG] = "";
			saTemp[ConstantsUtil.INDEX_USAGE_PROBABILITY] = ConstantsUtil.VALUE_USAGE_PROBABILITY;
		}

		if (!bOnlySendChildren){
			alBOMFC.add(saTemp);
			if(strFirstlevelObjIdCopy.equals(""))
				strFirstlevelObjIdCopy = strFirstlevelObjId;
			else if(!strFirstlevelObjIdCopy.equals(strFirstlevelObjId))
				strFirstlevelObjIdCopy = strFirstlevelObjId;
			else
				iChildObjCount++;

			hmChildObjects.put(saTemp[DISPLAY_OBJECT_ID],strFirstlevelObjId);
		}

		boolean bIncrementAltItem = true;
		if (saSubs!=null) {			
			for (int i=0; i<saSubs.length; i++) {
				bCreatingSubsRows = true;
				strSubsDispId = saSubs[i][13];							
				strTSName = saSubs[i][6];				
				strTSType = saSubs[i][7];				
				strTSRev = saSubs[i][11];
				//strValidFromDateSub = convertPLMDateToSAP(saSubs[i][10]);
				strChildBUOM = saSubs[i][17];

				if (strTSType.startsWith(ConstantsUtil.PGMASTER)) {
					try {
						strTarget = saSubs[i][2];
						bCreatingSubsRows = false;
						getIndividualsFromMaster(context, strName, strValidFromDate, strBOMBaseQuantity, strPgPhase,
								strFindNumber, strBOMNumber, strTSType,strTSName, strTSRev, 
								strBomUsage, strQuantity, strUpperLimit, strTarget, strLowerLimit,
								strValidFromDateComponent,strPositionIndicator, false, strTSID);
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					bIncrementAltItem = false;
				} else {

					strSubComponentNumber = strTSName;
					buildFCBOMArray(context, strPgPhase, strFindNumber,
							strName, strBomUsage, strValidFromDate,
							strSubComponentNumber, saSubs[i][2], saSubs[i][5],
							saSubs[i][3], saSubs[i][2], saSubs[i][1],
							strValidFromDateSub, strBOMNumber,
							strBOMBaseQuantity, saSubs[i][0], "", strGCAS, strVersion, false, strTSID, saSubs[i][14],saSubs[i][15], strChildBUOM);
				}

				if(i == saSubs.length - 1) {
					bCreatingSubsRows = false;
					strSubsDispId = "";
				}

			}
		}
	}


	public void getIndividualsFromMaster(Context context, String TSName, String strValidFromDate, String strBOMBaseQty,String strPgPhaseName, String strFindNumber, String strBOMNumber, String strMasterTSType, String strMasterTSName, String strMasterTSRev, String strBOMUsage, String strQuantity, String strUpperLim, String strTarget, String strLowerLim, String strValidFromDateComp, String strPosIndicator, boolean bIncrementAltItem,String strTSID) throws Exception {

		String strComponentNumber = DomainConstants.EMPTY_STRING;				
		String strIndSubFlag = DomainConstants.EMPTY_STRING;				
		String strMasterObjectId = DomainConstants.EMPTY_STRING;
		String strRelId = DomainConstants.EMPTY_STRING;
		String strIndObjectId = DomainConstants.EMPTY_STRING;
		String strIndType = DomainConstants.EMPTY_STRING;
		String strIndName = DomainConstants.EMPTY_STRING;
		String strIndRev = DomainConstants.EMPTY_STRING;
		StringList slIndNames= new StringList();
		Map hmMasterDetails = null;
		Map hmIndDetails = null;
		MapList mlIndividuals = null;
		int iIndObjCount=0;
		MapList mlMasterObjectList = null;	
		DomainObject domMaster = null;
		String strChildBUOM = DomainConstants.EMPTY_STRING;
		try{
			String strMQLStmt = "temp query bus $1 $2 $3 select $4 dump $5";			
			String strMqlRes = MqlUtil.mqlCommand(context, strMQLStmt, strMasterTSType, strMasterTSName, DomainConstants.QUERY_WILDCARD, DomainObject.SELECT_ID, "|");
			StringList strlResult = new StringList();
			StringList slMasterIds =FrameworkUtil.split(strMqlRes,"\n");
			Iterator itrMasters=slMasterIds.iterator();
			while(itrMasters.hasNext())
			{
				String strMaster=(String)itrMasters.next();
				strlResult = FrameworkUtil.split(strMaster,"|");
				strMasterObjectId=(String)strlResult.get(3);

				if (BusinessUtil.isNotNullOrEmpty(strMasterObjectId)) {
					domMaster = DomainObject.newInstance(context,strMasterObjectId);
					StringList slBusSelect = new StringList(4);
					slBusSelect.add(DomainConstants.SELECT_TYPE);
					slBusSelect.add(DomainConstants.SELECT_NAME);
					slBusSelect.add(DomainConstants.SELECT_REVISION);
					slBusSelect.add(DomainConstants.SELECT_ID);
					slBusSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);

					mlIndividuals = domMaster.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_PGMASTER,
							DomainConstants.QUERY_WILDCARD,
							true, 						//getTo
							true, 						//getFrom
							(short)1, 					// recursionLevel
							slBusSelect,
							new StringList(DomainObject.SELECT_RELATIONSHIP_ID), 							//relSelects
							null, 						// busWhereClause,
							null, 						// relWhereClause,
							null, 						// postRelPattern,
							null, 						//postTypePattern
							null);

					Iterator itrIndiv = mlIndividuals.iterator();
					while(itrIndiv.hasNext()){
						hmIndDetails = (Hashtable) itrIndiv.next();
						strRelId = (String) hmIndDetails.get(DomainConstants.SELECT_RELATIONSHIP_ID);
						strIndObjectId = (String) hmIndDetails.get(DomainConstants.SELECT_ID);
						strIndType = (String) hmIndDetails.get(DomainConstants.SELECT_TYPE);
						strIndName = (String) hmIndDetails.get(DomainConstants.SELECT_NAME);
						strIndRev = (String) hmIndDetails.get(DomainConstants.SELECT_REVISION);
						strChildBUOM = (String) hmIndDetails.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE);
						strComponentNumber = strIndName;	
						//strValidFromDateComp = convertPLMDateToSAP(getEffDateForLatestInd(context, strIndType, strIndName, strMasterTSName));

						if (BusinessUtil.isNotNullOrEmpty(strValidFromDateComp)){ 
							if (!slIndNames.contains(strIndName)) {
								buildFCBOMArray(context, strPgPhaseName, strFindNumber, TSName, strBOMUsage, strValidFromDate, strComponentNumber, strQuantity, strIndSubFlag, strUpperLim, strTarget, strLowerLim, strValidFromDateComp, strBOMNumber, strBOMBaseQty, strPosIndicator, strRelId, strMasterTSName, strMasterTSRev, false, strIndObjectId, "","", strChildBUOM);
								slIndNames.add(strIndName);
							}
						}
						iIndObjCount++;
					}

				}						
			}
			if (iIndObjCount == 0) {
				_AbortReason = "Aborting because there are no individuals connected to Master " + strMasterTSName + " " + strMasterTSRev;
			}
		}catch(Exception ex){

			ex.printStackTrace();
		}
	}


	public BigDecimal divideBigDecimalValues(BigDecimal bdNum , BigDecimal bdDen) {	
		try{
			if(bdDen.compareTo(BigDecimal.ZERO)!=0) {
				bdNum = bdNum.divide(bdDen,3,RoundingMode.HALF_UP);
			}
		}
		catch(ArithmeticException ae){
			bdNum = bdNum.divide(bdDen,3,RoundingMode.HALF_UP);
		}
		return bdNum;
	}







	public MapList getTUPBOMData(Context context, String strObjectID) throws Exception {
		MapList mlBOM = new MapList();
		String strObjectWhere = new StringBuffer(DomainObject.SELECT_CURRENT).append( " != ").append(ConstantsUtil.STATE_PART_OBSOLETE).toString();
		DomainObject dObjTUP = null;
		Pattern pObjectType = new Pattern(ConstantsUtil.TYPE_RAWMATERIALPART);
		pObjectType.addPattern(ConstantsUtil.TYPE_PACKAGINGMATERIALPART);
		pObjectType.addPattern(ConstantsUtil.TYPE_PGRAWMATERIAL);
		pObjectType.addPattern(ConstantsUtil.TYPE_PGPACKINGMATERIAL);
		try {
			if(BusinessUtil.isNotNullOrEmpty(strObjectID)) {
				dObjTUP = DomainObject.newInstance(context,strObjectID);
				mlBOM =  dObjTUP.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_EBOM, 	//relationshipPattern
						"*", 								//typePattern
						false, 								//getTo
						true, 								//getFrom
						(short)0, 							//recurseToLevel
						SL_OBJECT_INFO_SELECT, 				//objectSelects
						SL_RELATION_INFO_SELECT_EBOM, 		//relationshipSelects
						strObjectWhere, 					//objectWhere
						null, 								//relationshipWhere
						null,								//PostRelPattern
						pObjectType.getPattern(),			//PostTypePattern
						null);
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return mlBOM;
	}



	public ArrayList getBOMAlternateSubstituteGrouping(Context ctx, ArrayList alBOM){		

		ArrayList tempAllBOM = new ArrayList();
		String strParentObjId = "";
		String strObjId = "";
		int ichildObjCount = 0;
		String strTempId="";
		boolean bIncGrouping = true;		
		char _cAltItem1 = '9';
		char _cAltItem2 = 'A';
		if (alBOM != null) {			
			Iterator itr = alBOM.iterator();			
			while (itr.hasNext()) {
				String[] saTempBOM = (String[]) itr.next();
				strObjId = saTempBOM[DISPLAY_OBJECT_ID];
				strParentObjId = (String)hmChildObjects.get(strObjId);
				ichildObjCount = (int)hmParentObjects.get(strParentObjId);
				if(ichildObjCount>1){
					if(!bIncGrouping && !strTempId.equals(strParentObjId)){
						if (_cAltItem2 == 'Z') {
							_cAltItem2 = 'A';
							_cAltItem1--;
						} else {
							_cAltItem2++;				
						}
					}
					bIncGrouping=false;
					saTempBOM[ConstantsUtil.INDEX_SUBSTITUTE_FLAG]=_cAltItem1 + "" + _cAltItem2;
					saTempBOM[ConstantsUtil.INDEX_USAGE_PROBABILITY] = ConstantsUtil.VALUE_USAGE_PROBABILITY;
				}else{
					saTempBOM[ConstantsUtil.INDEX_SUBSTITUTE_FLAG]="";
					saTempBOM[ConstantsUtil.INDEX_USAGE_PROBABILITY] ="";
				}
				tempAllBOM.add(saTempBOM);
				strTempId=strParentObjId;
			}
		}
		return tempAllBOM;		
	}

	private String[][] convertArrayListToArray(ArrayList alGeneric, int iArraySize) throws Exception {
		String[][] saReturn = new String[1][1];
		try {
			if (alGeneric != null) {
				Iterator itr = alGeneric.iterator();

				saReturn = new String[alGeneric.size()][iArraySize];
				int i = 0;
				while (itr.hasNext()) {
					String[] saTemp = (String[]) itr.next();
					saReturn[i] = saTemp;
					i++;
				}
			}else {
				saReturn = new String[1][1];
			}
		} catch (Exception e) {
			e.printStackTrace();
			saReturn = new String[1][1];
		}

		return saReturn;
	}



	public MapList getEBOMData(Context context, String strObjectID) throws Exception {
		MapList mlBOM = new MapList();
		MapList mlEBOMTemp = new MapList();
		DomainObject dObjPart = null;
		String strNONGCASTYPE = EnoviaResourceBundle.getProperty (context, "emxCPN", context.getLocale(), "emxCPN.SAPBOM.DSM.NONGCASTypes");
		
		
		//SPEC: 09-29-2020: Modified for the Defect #36193 -- START
		//String strObjectWhere = new StringBuffer(DomainObject.SELECT_CURRENT).append( " != ").append(ConstantsUtil.STATE_PART_OBSOLETE).toString();
		StringBuffer strObjectWhere = new StringBuffer();
		strObjectWhere.append(DomainObject.SELECT_CURRENT).append( " != ").append(ConstantsUtil.STATE_PART_OBSOLETE);
		strObjectWhere.append(" && ").append(DomainObject.SELECT_TYPE).append( " != ").append(ConstantsUtil.TYPE_ANCILLARYRAWMATERIALPART);
		//SPEC: 09-29-2020: Modified for the Defect #36193 -- END
	
		Map mpBOMData = null;
		String strSpecSubType			= DomainConstants.EMPTY_STRING;
		try {
			if(BusinessUtil.isNotNullOrEmpty(strObjectID)) {
				dObjPart = DomainObject.newInstance(context, strObjectID);
				mlEBOMTemp =  dObjPart.getRelatedObjects(context,
						ConstantsUtil.RELATIONSHIP_EBOM, 	//relationshipPattern
						ConstantsUtil.SYMBL_ASTERISK, 			//typePattern
						false, 								//getTo
						true, 								//getFrom
						(short)1, 							//recurseToLevel
						SL_OBJECT_INFO_SELECT, 				//objectSelects
						SL_RELATION_INFO_SELECT_EBOM, 		//relationshipSelects
						strObjectWhere.toString(), 					//objectWhere
						null, 								//relationshipWhere
						null,								//PostRelPattern
						null,								//PostTypePattern
						null);
				if(null !=mlEBOMTemp) {
					int iMLBOMSize = mlEBOMTemp.size();
					String strSAPType = DomainConstants.EMPTY_STRING;
					String strChildType = DomainConstants.EMPTY_STRING;
					for(int j=0;j<iMLBOMSize;j++) {
						mpBOMData = (Map)mlEBOMTemp.get(j);
						strSAPType = (String)mpBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
						strChildType = (String)mpBOMData.get(DomainConstants.SELECT_TYPE);
						strSpecSubType = (String)mpBOMData.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE);
						if(!(ConstantsUtil.RANGE_ATTRIBUTE_SAPTYPE_DOC.equalsIgnoreCase(strSAPType)) && !(strNONGCASTYPE.contains(strChildType)) && !(ConstantsUtil.THIRD_PARTY).equals(strSpecSubType))  {
							mlBOM.add(mpBOMData);
						} 
					}
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		return mlBOM;
	}

	public String[][] getSubs(Context context, String strRelId) {
		String[][] saReturn = null;
		String strSubsCommand = DomainConstants.EMPTY_STRING; 
		String strMQLSubResult = DomainConstants.EMPTY_STRING; 
		String strSapType = DomainConstants.EMPTY_STRING; 
		String strType = DomainConstants.EMPTY_STRING; 
		String strATS = DomainConstants.EMPTY_STRING; 
		String[] saParts = null;
		String strMQLStmt = DomainConstants.EMPTY_STRING;
		String strMqlRes = DomainConstants.EMPTY_STRING;
		ArrayList<String[]> alSubRows = new ArrayList<String[]>();
		String[] saIds = null;

		if (strRelId.equals(""))
			return saReturn;
		try {

			strMQLStmt = "print connection $1 select $2 dump $3";			
			strMqlRes = MqlUtil.mqlCommand(context, strMQLStmt, strRelId, "frommid[EBOM Substitute].id", "|");			

			if (!strMqlRes.equals("")) {
				saIds = (strMqlRes.trim().split("\\|", -1));
				if (!saIds[0].equals("")) {
					for (int i = 0; i < saIds.length; i++) {						
						strSubsCommand = "print connection $1 select $2 $3 $4 $5 $6 $7 $8 $9 $10 $11 $12 $13 $14 $15 $16 $17 $18 $19 dump $20";
						strMQLSubResult = MqlUtil.mqlCommand(context, strSubsCommand, saIds[i], ConstantsUtil.SELECT_ATTRIBUTE_PGPOSITIONINDICATOR, ConstantsUtil.SELECT_ATTRIBUTE_PGMINCALCQUANTITY, ConstantsUtil.SELECT_ATTRIBUTE_PGCALCQUANTITY, ConstantsUtil.SELECT_ATTRIBUTE_PGMIXCALCQUANTITY, ConstantsUtil.SELECT_ATTRIBUTE_PGQUANTITYUNITOFMEASURE, ConstantsUtil.SELECT_ATTRIBUTE_PGSUBSTITUTECOMBINATIONNUMBER, "to.name", "to.type", "to."+ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE, "to."+ConstantsUtil.SELECT_ATTRIBUTE_PGFINISHEDPRODUCTCODE, "to."+ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE, "to.revision", "to."+ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE, "to.id", "to.from["+ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION+"]", ConstantsUtil.SELECT_ATTRIBUTE_OPTIONAL_COMPONENT,ConstantsUtil.SELECT_ATTRIBUTE_COMMENT,"to."+ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE,"|");
						saParts = (strMQLSubResult.trim().split("\\|", -1));
						strSapType = saParts[12];
						strType = saParts[7];
						strATS = saParts[14];
						if (strType.startsWith(ConstantsUtil.PGMASTER)||(!strSapType.equalsIgnoreCase(ConstantsUtil.RANGE_ATTRIBUTE_SAPTYPE_DOC) && (ConstantsUtil.ATTRIBUTE_PGCOSCALCULATE_FALSE.equals(strATS))))
							alSubRows.add(saParts);
					}
				}
				if (alSubRows.size()>0) {
					saReturn = convertArrayListToArray(alSubRows, 17);
					Arrays.sort(saReturn, new Comparator(){
						public int compare(Object obj1, Object obj2)
						{
							int result = 0;

							String[] str1 = (String[]) obj1;
							String[] str2 = (String[]) obj2; 

							Float in1 = Float.valueOf(str1[5]);
							Float in2 = Float.valueOf(str2[5]);
							result = in1.compareTo(in2);

							return result;
						}						
					}); 

					for (int i=0; i<saReturn.length; i++) {
						saReturn[i][5]="";
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return saReturn;
	}


	public String getEffDateForLatestInd(Context context, String strType, String strName, String strMasterName) throws Exception{
		String strEffDate = DomainConstants.EMPTY_STRING;	
		String strATS = DomainConstants.EMPTY_STRING;
		String strDocType = DomainConstants.EMPTY_STRING;	
		String strMaster = DomainConstants.EMPTY_STRING;	
		Map mpIndInfo = new HashMap();		
		MapList mlIndObjectList = new MapList();
		StringList slSelectables = new StringList();
		slSelectables.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		slSelectables.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		slSelectables.add("from["+ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION+"].to.name");
		slSelectables.add("from["+ConstantsUtil.RELATIONSHIP_PGMASTER+"].to.name");

		try{			
			StringBuffer sbWhereCond = new StringBuffer();				 	
			sbWhereCond.append("(");
			sbWhereCond.append(DomainObject.SELECT_CURRENT);
			sbWhereCond.append("==");
			sbWhereCond.append(ConstantsUtil.STATE_RELEASE);
			sbWhereCond.append(" && (next.current != "+ ConstantsUtil.STATE_RELEASE +" || revision == last)");		
			sbWhereCond.append(")");

			mlIndObjectList = DomainObject.findObjects(
					context,
					strType, //typePattern
					strName, //namePattern
					"*", //revPattern
					"*", //ownerPattern
					ConstantsUtil.VAULT_ESERVICEPRODUCTION, //vaultPattern
					sbWhereCond.toString(), //whereExpression
					false, //expandType
					slSelectables); //objectSelects
			if(mlIndObjectList.size()!=0){
				mpIndInfo = (HashMap) mlIndObjectList.get(0);
				strATS = (String) mpIndInfo.get("from["+ConstantsUtil.RELATIONSHIP_AUTHORIZEDTEMPORARYSPECIFICATION+"].to.name"); 
				strDocType = (String) mpIndInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
				if (UIUtil.isNotNullAndNotEmpty(strDocType) && (!strDocType.equalsIgnoreCase(ConstantsUtil.RANGE_ATTRIBUTE_SAPTYPE_DOC) || !strType.startsWith(ConstantsUtil.PGMASTER))){
					if (strATS == null || strATS.equals("")){
						strMaster = (String) mpIndInfo.get("from["+ConstantsUtil.RELATIONSHIP_PGMASTER+"].to.name");
						if (UIUtil.isNotNullAndNotEmpty(strMaster) && strMaster.contains(strMasterName))
							strEffDate = (String) mpIndInfo.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
					}				
				}	

			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strEffDate;		
	}


	public Vector getBOMQTYData(Context context, String[] args) throws Exception
	{
		Vector vc = new Vector();
		try {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			BigDecimal bdBOMBaseQty=BigDecimal.ZERO;
			BigDecimal bdBOMQuantity=BigDecimal.ZERO;
			BigDecimal bdBOMFinalQuantity=BigDecimal.ZERO;
			BigDecimal bdBOMQuantityCheck=new BigDecimal("9999999999.999");

			MapList objectList = (MapList)programMap.get("objectList");
			HashMap paramList = (HashMap)programMap.get("paramList");
			String  strFPPID          = (String) paramList.get("objectId");
			DomainObject dObjFPP = DomainObject.newInstance(context,strFPPID);

			StringList slObjectSelect = new StringList(5);
			slObjectSelect.addElement(DomainConstants.SELECT_ID);
			slObjectSelect.addElement(DomainConstants.SELECT_NAME);
			slObjectSelect.addElement(DomainConstants.SELECT_TYPE);
			slObjectSelect.addElement(DomainConstants.SELECT_REVISION);
			slObjectSelect.addElement(DomainConstants.SELECT_LEVEL);
			StringList relationshipSelects = new StringList(4);

			relationshipSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			relationshipSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			MapList mlFPPChildData = dObjFPP.getRelatedObjects(context,
					ConstantsUtil.RELATIONSHIP_EBOM,  // Rel Pattern

					ConstantsUtil.TYPE_PGCONSUMERUNITPART+","+ConstantsUtil.TYPE_PGCUSTOMERUNITPART+","+ConstantsUtil.TYPE_PGINNERPACKUNITPART + "," + ConstantsUtil.TYPE_FABRICATEDPART,              //Type Pattern

					slObjectSelect,                  //  bus select

					relationshipSelects,             //   Rel select

					false,							 // to side

					true,                           // from side

					(short)0,					   //  recursion level

					null,						  // Object Where Clause

					null);                       // Rel Where Clause

			StringList slBCF = new StringList(2);
			slBCF.addElement(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			Map mapBCF = (Map)dObjFPP.getInfo(context,slBCF);
			String strBOMBaseQty = (String)mapBCF.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY);
			try {
				if(null !=strBOMBaseQty && !"".equals(strBOMBaseQty))
				{
					bdBOMBaseQty=new BigDecimal(strBOMBaseQty);

				}
			} catch(Exception ex)
			{
				System.out.println("Exception in converting to BigDecimal "+ex.getMessage());
			}catch(Error ex)
			{
				System.out.println("Error in converting to BigDecimal "+ex.getMessage());
			}

			if(null != objectList && objectList.size() > 0)
			{
				String strBOMQty = "";
				String strObjectID = null;

				String strConnectionID = null;

				String strItermediate = null;

				String strItermediateID = null;

				String strIntermediateType = null;

				String sAttrVal = null;

				Map mapTemp = null;

				for(int i=0;i<objectList.size();i++)
				{
					strBOMQty = "";

					mapTemp = (Map)objectList.get(i);
					strObjectID = (String)mapTemp.get("id");
					strConnectionID = (String)mapTemp.get("id[connection]");
					strItermediate = (String)mapTemp.get("IntermediateName");
					strItermediateID = (String)mapTemp.get("IntermediateID");
					strIntermediateType = (String)mapTemp.get("IntermediateType");
					sAttrVal = DomainRelationship.getAttributeValue(context,strConnectionID,ConstantsUtil.ATTRIBUTE_QUANTITY);
					if(null != sAttrVal && !"".equals(sAttrVal))
					{
						bdBOMQuantity=new BigDecimal(sAttrVal);

					}
					if(null != strItermediateID && strItermediateID.length() > 0 && bdBOMQuantity.compareTo(BigDecimal.ZERO)!=0)
					{
						bdBOMFinalQuantity=bdBOMBaseQty.multiply(bdBOMQuantity).setScale(3, BigDecimal.ROUND_HALF_UP);
						String strLevel = "";
						String strIterType = DomainConstants.EMPTY_STRING;
						int sizeOfChildData = mlFPPChildData.size();
						Stack tempStack = null;
						int stackTopData;
						int currentLevel;
						for(int iCount=0; iCount < sizeOfChildData; iCount++)
						{
							Map mapTemp1 = (Map)mlFPPChildData.get(iCount);
							if(((String)mapTemp1.get("id")).equals(strItermediateID))
							{
								tempStack = new Stack();
								for(int iChild = iCount;iChild >= 0;iChild--)
								{
									Map mapTempInter = (Map)mlFPPChildData.get(iChild);
									strLevel = (String)mapTempInter.get("level");
									currentLevel = Integer.parseInt(strLevel);
									if(iChild == iCount){
										tempStack.push(currentLevel);
									}
									else {			
										stackTopData = (int)tempStack.peek();
										if(currentLevel >= stackTopData)
											continue;
										else
											tempStack.push(currentLevel);
									}

									strIterType = (String)mapTempInter.get(DomainConstants.SELECT_TYPE);
									if((UIUtil.isNotNullAndNotEmpty(strIterType)) && (
											(strIterType.equalsIgnoreCase(ConstantsUtil.TYPE_FABRICATEDPART)) ||
											((UIUtil.isNotNullAndNotEmpty(strIntermediateType)) && (strIntermediateType.equalsIgnoreCase(ConstantsUtil.TYPE_FABRICATEDPART)) && !(strIterType.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNITPART))))){
										continue;
									}
									String strIterQty = (String)mapTempInter.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
									if(UIUtil.isNotNullAndNotEmpty(strIterQty))
									{
										bdBOMQuantity=new BigDecimal(strIterQty);
										bdBOMFinalQuantity=bdBOMFinalQuantity.multiply(bdBOMQuantity).setScale(3, BigDecimal.ROUND_HALF_UP);
									}
									if("1".equals(strLevel))
									{
										break;
									}
								}
								if("1".equals(strLevel))
								{
									break;
								}
							}
						}
					}
					else 
					{

						bdBOMFinalQuantity= bdBOMBaseQty.multiply(bdBOMQuantity).setScale(3, BigDecimal.ROUND_HALF_UP);
					}
					
					strBOMQty = String.valueOf(bdBOMFinalQuantity);
					if((bdBOMFinalQuantity.compareTo(BigDecimal.ZERO)==0) || (bdBOMFinalQuantity.compareTo(bdBOMQuantityCheck)>0))
					{
						strBOMQty = ConstantsUtil.STR_DEFAULT_QTY_IF_FAILED;
					}
					
					vc.add(strBOMQty);
				}
			}

		} catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return vc;
	}



	public StringBuilder getSpecificationSubtype(Context context,MapList objectList) throws Exception
	{
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		Vector vc= new Vector();
		long startTime = System.currentTimeMillis();

		Map mapDataMapping = null;

		String strAttributeName = PropertyUtil.getSchemaProperty("attribute_pgAssemblyType");
		String strAttributeCSSType = PropertyUtil.getSchemaProperty("attribute_pgCSSType");
		String strTypepgFinishedProduct = PropertyUtil.getSchemaProperty("type_pgFinishedProduct");
		String strTypepgQualitySpecification = PropertyUtil.getSchemaProperty("type_pgQualitySpecification");
		String strAttrPgAssemblyType = ""; 
		String strTypepgTestMethod= PropertyUtil.getSchemaProperty("type_pgTestMethod");		

		String strSpecSubTypeValue = DomainConstants.EMPTY_STRING;  
		String strRelPgPDTemplatestopgPLIAssemblyType = DomainConstants.EMPTY_STRING;
		String strSelect = DomainConstants.EMPTY_STRING;

		Map mapObject = null;
		String strID="";
		String strRootNode="";
		String strSpecSubType = "";
		String strType = "";
		String strAttrPgCSSType = "";
		boolean isContextPush = false;

		ContextUtil.pushContext(context, "User Agent", "", "");
		isContextPush = true;
		for (Iterator iterator = objectList.iterator(); iterator.hasNext();)
		{
			mapDataMapping = new HashMap();
			mapDataMapping.put("pgPackingMaterial","Packaging");
			mapObject = (Map) iterator.next();			
			strID=(String)mapObject.get(DomainConstants.SELECT_ID);			
			DomainObject dom = new DomainObject(strID);
			boolean isDSO = busUtil.isOfDSOOrigin(context, strID);
			strType = (String)mapObject.get(DomainConstants.SELECT_TYPE);


			if (strTypepgFinishedProduct.equals(strType) || ConstantsUtil.TYPE_PGPACKINGSUBASSEMBLY.equals(strType))

			{

				strAttrPgAssemblyType = dom.getInfo(context, "attribute["+strAttributeName+"]");

				if("".equals(strAttrPgAssemblyType)){

					mapDataMapping.put("pgFinishedProduct","Finished Product");
				}
				else if("FWIP-Finished Work in Process".equals(strAttrPgAssemblyType)) {
					mapDataMapping.put("pgFinishedProduct","FWIP-Finished Work in Process");			
				}

				else if("Purchased Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgPackingSubassembly","Purchased Subassembly");	
				}
				else if("Purchased and/or Produced Subassembly".equals(strAttrPgAssemblyType)){
					mapDataMapping.put("pgPackingSubassembly","Purchased and/or Produced Subassembly");	
				}else{
					mapDataMapping.put("pgFinishedProduct",strAttrPgAssemblyType);	
				}				
			}

			if (strTypepgQualitySpecification.equals(strType) && !isDSO){
				strAttrPgCSSType = dom.getInfo(context, "attribute["+strAttributeCSSType+"]");

				if("AMAT".equals(strAttrPgCSSType)) {
					mapDataMapping.put("pgQualitySpecification","Approval Matrix");			
				}
				else if ("CBA".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Current Best Approach");	
				}
				else if ("GPMS".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","General Packaging Material Specification");	
				}
				else if ("GPS".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","General Packing Standard");	
				}
				else if ("IAS".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Incoming Acceptance Specification");	
				}
				else if ("MOC".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Material of Construction");	
				}
				else if ("QAC".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Quality Acceptance Criteria");
				}
				else if ("RMPI".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgQualitySpecification","Raw Material Plant Instruction");	
				}else{
					mapDataMapping.put("pgQualitySpecification",strAttrPgCSSType);
				}		

			}

			if(ConstantsUtil.TYPE_PGRAWMATERIAL.equals(strType)){
				if(!isDSO){
					mapDataMapping.put("pgRawMaterial","Raw");
				}
			}
			if (isDSO){
				if(ConstantsUtil.TYPE_FORMULATIONPART.equals(strType)){
					strSpecSubTypeValue =  (String)dom.getInfo(context,"to["+ConstantsUtil.RELATIONSHIP_FORMULATIONPROPAGATE+"].from."+ConstantsUtil.SELECT_ATTRIBUTE_FORMULATIONTYPE);
				} else {
					strSpecSubTypeValue =  (String)dom.getInfo(context,"attribute["+strAttributeName+"]");
				}
			}else {
				strSpecSubTypeValue= "";
			}


			if (strTypepgTestMethod.equals(strType))
			{   
				strAttrPgCSSType = dom.getInfo(context, "attribute["+strAttributeCSSType+"]");
				if ("TAMU".equals(strAttrPgCSSType)){
					mapDataMapping.put("pgTestMethod","TAMU");
				}
				else {
					mapDataMapping.put("pgTestMethod","");
				}

			}								

			strRootNode=(String)mapObject.get("Root Node");

			if(!"true".equalsIgnoreCase(strRootNode))
			{
				strSpecSubType = (String)mapDataMapping.get(strType);
				if(strSpecSubType != null)
				{
					vc.add(strSpecSubType);
				}
				else if(UIUtil.isNotNullAndNotEmpty(strSpecSubTypeValue))
				{
					vc.add(strSpecSubTypeValue);
				}
				else
				{
					vc.add("");
				}
			}else{
				vc.add("");
			}
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			dom.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- ENd
		}

		long endTime = System.currentTimeMillis();
		if(isContextPush){
			ContextUtil.popContext(context);
			isContextPush = false;
		}

		StringBuilder sbSpec = new StringBuilder();
		for (int i = 0; i < vc.size(); i++) {

			String sSpecSub = (String) vc.get(i);
			sbSpec.append(sSpecSub).append(ConstantsUtil.SYMBL_PIPE);
		}
		
		return sbSpec;

	}


	/**
	 * It will return the connected SAP BOM
	 * @param context
	 * @param sID
	 * @return
	 */
	public Map getSapBOMasFed(Context context ,String sID){
		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
		Map mapSapBomAsFedResult = new HashMap();
		SecurityService sct = new SecurityService();
		boolean isStaffAUg = sct.isStaffAUGUser();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbId = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbSapType = new StringBuilder();
		StringBuilder sbSpecSubType = new StringBuilder();
		StringBuilder sbSpecGroup = new StringBuilder();
		StringBuilder sbBOMQTY = new StringBuilder();
		StringBuilder sbBuom = new StringBuilder();
		StringBuilder sbComnt = new StringBuilder();
		
		StringBuilder sbSAPDesc = new StringBuilder();
		StringBuilder sbAuthorized = new StringBuilder();
		StringBuilder sbAuthorizedToUse = new StringBuilder();
		StringBuilder sbAuthorizedToProduce = new StringBuilder();
		StringBuilder sbOC = new StringBuilder();
		
		StringBuilder sbTUType = new StringBuilder();
		StringBuilder sbTUName = new StringBuilder();
		StringBuilder sbTUId = new StringBuilder();
		
		StringList slHIRTypes = new StringList();

		slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
		slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
		slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
		slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);
		
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		StringValidatorUtil validator = new StringValidatorUtil();
		try
		{
			ArrayList alSapBom = performDataReadFromEnovia(context,sID);
			MapList ml = getTableData(context,alSapBom);
			
			sbSpecSubType =getSpecificationSubtype(context ,ml);
			Iterator objectListItr = ml.iterator();
			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sId =(String)objectMap.get(ConstantsUtil.MAP_KEY_ID);
				String sName =(String)objectMap.get(ConstantsUtil.NAME);
				String sTitle =(String)objectMap.get(ConstantsUtil.DESCRIPTION);
				String sType =(String)objectMap.get(ConstantsUtil.TYPE);
				String sSapType =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPTYPE);
				String sSpecGroup =(String)objectMap.get(ConstantsUtil.MAP_KEY_SUBSTITUTE);
				String sQty =(String)objectMap.get(ConstantsUtil.MAP_KEY_BOMQTY);
				String sBuom =(String)objectMap.get(ConstantsUtil.MAP_KEY_SAPUOM);
				String strClassFied = (String)objectMap.get(ConstantsUtil.SECURITY);
				String strControlClass = (String)objectMap.get(ConstantsUtil.OBJECTSECURITYCLASS);
				String strComment = (String)objectMap.get(ConstantsUtil.ATTRIBUTE_COMMENT);
				
				//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
				String strOC = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.OC));
				 String strAuthorizedToProduce =validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOPRODUCE));
				String strAuthorizedToUse = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZEDTOUSE));
				String strAuthorized = validator.getStringEquivalentForStringList(objectMap.get(ConstantsUtil.AUTHORIZED));
				String strSAPDesc = (String)objectMap.get(ConstantsUtil.SAPDESCRIPTION);
				
				
				String strTUType = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_TYPE);
				String strTUName = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_NAME);
				String strTUId = (String)objectMap.get(ConstantsUtil.TRANSPORTUNIT_ID);
				
				//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END
				boolean bHasOwnership = false;
				String sUserlicense = sct.getUserLicense();
				String sFormulaPropagate = sId;
				
				if(sType.equals(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT) || sType.equals(ConstantsUtil.TYPE_FORMULA_CARD))
				{
					sId =ConstantsUtil.NO_ACCESS;
					sTitle =ConstantsUtil.NO_ACCESS;
					//sSapType =ConstantsUtil.NO_ACCESS;
					//sSpecGroup =ConstantsUtil.NO_ACCESS;
					//sQty =ConstantsUtil.NO_ACCESS;
					//sBuom =ConstantsUtil.NO_ACCESS;
					//strComment=ConstantsUtil.NO_ACCESS;
					
					strAuthorized=ConstantsUtil.NO_ACCESS;
					strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
					strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
					
					
			}
			else
			{//commented by Ganesh for security impl -----> start
				if(util.isModificatinRequired())
				{
					/* sec = new SecurityService();
					String sComp = sec.getUserCauthorities();
					StringList slUserOwnership=util.filterOwnerShip(sComp);

					//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
					if(sType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, sId);
					}
					
					if(!sFormulaPropagate.isEmpty()) {
						bHasOwnership = util.checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}*///commented by Ganesh for security impl -----> end
				//modified by Ganesh for security impl -----> start
				bHasOwnership = util.checkHasAccess(context, null, sId);
				//modified by Ganesh for security impl -----> end
					if(!bHasOwnership)
					{
						sTitle = ConstantsUtil.NO_ACCESS;
						sId =ConstantsUtil.NO_ACCESS;
						sTitle =ConstantsUtil.NO_ACCESS;
						sSapType =ConstantsUtil.NO_ACCESS;
						sSpecGroup =ConstantsUtil.NO_ACCESS;
						sQty =ConstantsUtil.NO_ACCESS;
						sBuom =ConstantsUtil.NO_ACCESS;
						strComment=ConstantsUtil.NO_ACCESS;
						strSAPDesc=ConstantsUtil.NO_ACCESS;
						strAuthorized=ConstantsUtil.NO_ACCESS;
						strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
						strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
						strOC=ConstantsUtil.NO_ACCESS;
					}
				}else if(isStaffAUg)
				{
					boolean showData = true;
					//commented by ganesh--->start
					/*String sFormulaClassif =strControlClass;
					
						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
							sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}
						
						showData= util.checkLicenses(sUserlicense,sFormulaClassif);*/
					//commented by ganesh--->end
					//modified by Ganesh for security impl--->start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl--->end
						if(!showData)
						{
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}
						}
					
				}else
				{
					boolean showData = true;
					//commented by Ganesh --->start
					/*if(slHIRTypes.contains(sType) )
					{
						String sFormulaClassif =strClassFied;
						//SPEC: <11.5.2020>: Modified for req 18x.5 ## -- START
						if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) 
						{
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
						}
							showData= util.checkLicenses(sUserlicense,sFormulaClassif);*/
					//commented by Ganesh --->end
							
							/*if (sType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
								sFormulaClassif = util.getFormulaPropagateClassification(context, sId);
							}
							if(null!=sUserlicense && null!=sFormulaClassif && !sUserlicense.contains(sFormulaClassif)) {
								showData=false;
							}*/
							//SPEC: <11.5.2020>: Modified for req 18x.5 ## -- END
					//modified by Ganesh for security impl---->start
					showData = util.checkHasAccess(context, null, sId);
					//modified by Ganesh for security impl---> end
						if(!showData){
							sId =ConstantsUtil.NO_ACCESS;
							sTitle =ConstantsUtil.NO_ACCESS;
							//sSapType =ConstantsUtil.NO_ACCESS;
							//sSpecGroup =ConstantsUtil.NO_ACCESS;
							//sQty =ConstantsUtil.NO_ACCESS;
							//sBuom =ConstantsUtil.NO_ACCESS;
							//strComment=ConstantsUtil.NO_ACCESS;
							//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
							if(UIUtil.isNotNullAndNotEmpty(strAuthorized)){
								strAuthorized=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorized=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToProduce)){
								strAuthorizedToProduce=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToProduce=ConstantsUtil.EMPTY_STRING;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strAuthorizedToUse)){
								strAuthorizedToUse=ConstantsUtil.NO_ACCESS;
							}else{
								strAuthorizedToUse=ConstantsUtil.EMPTY_STRING;
							}
							//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END
						}

					//}//commented by Ganesh
				}
			}
				busUtil.formatData(sbId,sId);
				busUtil.formatData(sbName,sName);
				busUtil.formatData(sbTitle,sTitle);
				busUtil.formatData(sbType,busUtil.mapType(sType));
				busUtil.formatData(sbSapType,sSapType);
				busUtil.formatData(sbSpecGroup,sSpecGroup);
				busUtil.formatData(sbBOMQTY,sQty);
				busUtil.formatData(sbBuom,sBuom);
				busUtil.formatData(sbComnt,strComment);
				
				util.formatData(sbSAPDesc,strSAPDesc);
				util.formatData(sbAuthorized,strAuthorized);
				util.formatData(sbAuthorizedToUse,strAuthorizedToUse);
				util.formatData(sbAuthorizedToProduce,strAuthorizedToProduce);
				util.formatData(sbOC,strOC);
				
				util.formatData(sbTUType,strTUType);
				util.formatData(sbTUName,strTUName);
				util.formatData(sbTUId,strTUId);
				
			}

			mapSapBomAsFedResult.put(ConstantsUtil.NAME, sbName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.ID, sbId.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TITLE, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TYPE, sbType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SAPTYPE, sbSapType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbSpecSubType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONGROUP, sbSpecGroup.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BOMQUANTITY, sbBOMQTY.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbBuom.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.COMMENTS, sbComnt.toString());
			//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
			mapSapBomAsFedResult.put(ConstantsUtil.SAPDESCRIPTION, sbTitle.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZED, sbAuthorized.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOUSE, sbAuthorizedToUse.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.AUTHORIZEDTOPRODUCE, sbAuthorizedToProduce.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.OC,sbOC.toString());

			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_NAME,sbTUName.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_TYPE,sbTUType.toString());
			mapSapBomAsFedResult.put(ConstantsUtil.TRANSPORTUNIT_ID,sbTUId.toString());
			//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END

		}catch(Exception e){

			LOGGER.error("Exception in program CalculateBOm :getSapBOMasFed ");

		}
		return mapSapBomAsFedResult;

	}

	
	/**
	 * Added for Plant Values 
	 * for 18X.5 changes
	 * @param context
	 * @param objectId
	 * @param relSelectList
	 * @param relWhereClause
	 * @return
	 * @throws Exception
	 */
	
	 
	public MapList getConnectedPlantList(Context context, String objectId, StringList relSelectList, String relWhereClause) throws Exception 
	{
			
			MapList mlPlantList = new MapList();
			try 
			{
				
				DomainObject domObj = DomainObject.newInstance(context,objectId);
				
				if(UIUtil.isNotNullAndNotEmpty(objectId))
				{
					StringList slObjSelect = new StringList(2);
					slObjSelect.addElement(DomainObject.SELECT_ID);
					slObjSelect.addElement(DomainObject.SELECT_NAME);
					
					StringList slRelSelect = new StringList();
					if(null!=relSelectList && relSelectList.size()>0)
					{
						slRelSelect.addAll(relSelectList);
					}
					
					mlPlantList = domObj.getRelatedObjects(context,
							ConstantsUtil.RELATIONSHIP_MANUFACTURINGRESPONSIBILITY, //relationship Pattern
							ConstantsUtil.TYPE_PLANT, //type Pattern
							slObjSelect, //objectSelects
							slRelSelect, //relSelects
							true, 		 // to side
							false, 		 // from side
							(short)1,	 // recursion level
							null,		 //objectWhere
							relWhereClause, //relWhere
							0);
				}	
					Collections.sort(mlPlantList, new Comparator() {					
						public int compare(Object first,
							Object second) {
							Map firstMap = (Map) first;
							Map secondMap = (Map) second;
							String firstValue = (String) (firstMap.get(DomainConstants.SELECT_NAME));
							String secondValue = (String) secondMap.get(DomainConstants.SELECT_NAME);
																		
							return firstValue.compareTo(secondValue);
							}
						} );
				
			} catch (Exception e)
			{
				LOGGER.error("Exception in program CalculateBOm :getConnectedPlantList ");
				new MapList();
			}
			return mlPlantList;
			
		}
		
	
	/**
	 * This Method will verify the user is having access or not for the object.
	 * @param context
	 * @param sUserType
	 * @param objId
	 * @return
	 */

		public boolean checkHasAccess(Context context, String objId)
		{
			boolean bReturnFlag=true;
			StringValidatorUtil validator = new StringValidatorUtil();
			BusObjectAttribUtil util = new BusObjectAttribUtil();
			StringList slHIRTypes = new StringList();
			slHIRTypes.add(ConstantsUtil.TYPE_FORMULATIONPART);
			slHIRTypes.add(ConstantsUtil.TYPE_ASSEMBLEDPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_DEVICEPRODUCTPART);
			slHIRTypes.add(ConstantsUtil.TYPE_INTERMEDIATE_PRODUCT_PART);
			slHIRTypes.add(ConstantsUtil.TYPE_PGFORMULATEDPRODUCT);

			StringList slPartSelect = new StringList();		
			slPartSelect.addElement(ConstantsUtil.TYPE);
			slPartSelect.addElement(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
			
			SecurityService sct = new SecurityService();
			String sUserlicense = sct.getUserLicense();
			
			String sUserType= sct.getUserType();
			try
			{
				DomainObject doObj = new DomainObject().newInstance(context,objId);
				DomainConstants.MULTI_VALUE_LIST.add(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
				Map mpPartObjectInfo = doObj.getInfo(context, slPartSelect);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
				doObj.close(context);
				//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- ENd
				DomainConstants.MULTI_VALUE_LIST.remove(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME);
				
				String strObjectType = (String)mpPartObjectInfo.get(DomainConstants.SELECT_TYPE);
				String strIPControlClass = validator.getStringEquivalentForStringList(mpPartObjectInfo.get(ConstantsUtil.RELATIONSHIP_IPCONTROLCLASS_NAME));
				
				if (sUserType.equals(ConstantsUtil.PGSTAFF)) 
				{
					if(slHIRTypes.contains(strObjectType) )
					{
						String sFormulaClassif =strIPControlClass;
						if (strObjectType.equals(ConstantsUtil.TYPE_FORMULATIONPART)) {
							 sFormulaClassif =util.getFormulaPropagateClassification(context, objId);
						}
						bReturnFlag= util.checkLicenses(sUserlicense,sFormulaClassif);
					}
					
				}else if(sUserType.equals(ConstantsUtil.PG_CM) || sUserType.equals(ConstantsUtil.PG_SP)) 
				{
					
					StringList slUserOwnership=util.filterOwnerShip(sct.getUserCauthorities());
					String sFormulaPropagate=objId;
					//Formulation part does not have ownership on itself, hence expand to get it from the Cosmetic formulation
					if(strObjectType.equalsIgnoreCase(ConstantsUtil.TYPE_FORMULATIONPART)) {
						sFormulaPropagate = util.getFormulaPropagate(context, objId);
					}
					
					if(!sFormulaPropagate.isEmpty()) {
						bReturnFlag =util. checkOwnerShip(context, slUserOwnership, sFormulaPropagate);
					}
				}else
				{
					//For Internal Users TUP can be accessed directly without security rules
					return true;
				}
				
			}catch(Exception e)
			{
				LOGGER.error("Error from CalculateBOM :  checkHasAccess" + e);
				return bReturnFlag;
			}
			return bReturnFlag;
		}
		
		
		
		
		

}
