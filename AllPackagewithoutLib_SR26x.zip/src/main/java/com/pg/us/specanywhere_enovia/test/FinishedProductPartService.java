//package com.pg.us.specanywhere_enovia.test;
//

//import java.util.Map;
//
//import org.apache.commons.lang3.time.StopWatch;
//import org.apache.log4j.Logger;
//
//import com.matrixone.apps.domain.DomainObject;
//import com.matrixone.apps.domain.util.ContextUtil;
//import com.matrixone.apps.domain.util.MapList;
//import com.matrixone.apps.domain.util.PropertyUtil;
//import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
//import com.pg.us.specanywhere_enovia.cp.EnoviaContext;
//import com.pg.us.specanywhere_enovia.security.SecurityService;
//import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
//import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
//import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
//import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
//import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
//
//import matrix.db.Context;
//import matrix.db.JPO;
//import matrix.util.Pattern;
//import matrix.util.StringList;
//
//public class FinishedProductPartService {
//
//	private static Logger LOGGER = Logger.getLogger(FinishedProductPartService.class);
//
//	public static void main(String[] args) throws Exception {
//		HashMap<String, Map<String,String>> hmAttrib = new HashMap<String, Map<String, String>>();
//		LOGGER.info("Enter FinishedProductPartService Class");
//		StopWatch sp = new StopWatch();
//		sp.start();
//
//		String objId = "20336.41905.36619.6063";
//		//String objId = "20336.41905.32768.13808";
//		//String objId = "20336.41905.39617.24471";
//		LOGGER.info("FPP CONTEXT SET---------------- ELAPSED TIME : "+sp.getTime());
//		//sp.reset();
//		//sp.start();
//		Context context = pool.checkOut();
//
//		LOGGER.info("FPP CONTEXT SET ELAPSED TIME : "+sp.getTime());
//
//
//
//		//* User Profile
//		//* 
//		SecurityService sct = new SecurityService();
//		//String sUserlicense = sct.getUserLicense();
//		String sUserlicense = "";
//		//boolean isExternalUser = sct.isExternalUser();
//		boolean isExternalUser = false;
//
//		// * FPP Message Extraction Business Logic Begins
//		//* 
//
//		FinishedProductPartBO fppBO = new FinishedProductPartBO();
//		Map BusinessObjectSelectableMap = fppBO.getFinishedProductPartSelectableMap(context);
//
//		BusObjectAttribUtil busUtil = new BusObjectAttribUtil();
//		Map<String,String> mpHeaderResult = new HashMap<String,String>();
//		Map<String,String> mapAttribResult = new HashMap<String,String>();
//		Map<String,String> mapStorageAndLabelResult = new HashMap<String,String>();
//		Map<String,String> mapBomResult = new HashMap<String,String>();
//		Map<String,String> mapPlantResult = new HashMap<String,String>();
//		Map<String,String> mapWnDResult = new HashMap<String,String>();
//		Map<String,String> mapSapBomAsFedResult = new HashMap<String,String>();
//		Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
//		Map<String,String> mapCosResult = new HashMap<String,String>();
//		Map<String,String> mapWarehouseClassResult = new HashMap<String,String>();
//		Map<String,String> mpOrganization = new HashMap<String,String>();
//		Map<String,String> mapPartSpecification = new HashMap<String,String>();
//		Map<String,String> mpMasterSpecs = new HashMap<String,String>();
//		Map<String,String> mpDerivedResult = new HashMap<String,String>();
//		Map<String,String> mapTupBomResult = new HashMap<String,String>();
//		Map<String,String> mapPackagingUnitResult = new HashMap<String,String>();
//		Map<String,String> mapTransportUnitResult = new HashMap<String,String>();
//		Map<String,String> mpBomMcupResult = new HashMap<String,String>();
//		Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
//		Map<String,String> mpEBOMMasterInnerPack = new HashMap<String,String>();
//		Map<String,String> mpPerformChar= new HashMap<String,String>();
//
//		StringList slSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
//		Map BusinessObjectRelSelectableMap = fppBO.getFppRelatedObjsSelectableMap(context);
//		StringList slEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.BUS_SELECTS);
//		StringList slRelEBOMSelects = (StringList) BusinessObjectRelSelectableMap.get(ConstantsUtil.REL_SELECTS);
//
//		StringValidatorUtil validator = new StringValidatorUtil();
//		DomainObject doFPP = fppBO.getFppDO(context, objId);
//		fppBO.addMultiList();
//
//		StopWatch swAttributes = new StopWatch();
//		swAttributes.start();			
//		Map resultMap = doFPP.getInfo(context, slSelects);
//
//		swAttributes.stop();
//		LOGGER.info("FPP GETINFO ELAPSED TIME : "+swAttributes.getTime());
//		fppBO.removeMultiList();
//
//		//BOM
//		StopWatch swBom = new StopWatch();
//		swBom.start();
//		MapList mlEBOMList = doFPP.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slEBOMSelects , slRelEBOMSelects, false, true, (short)0,ConstantsUtil.EMPTY_STRING,ConstantsUtil.EMPTY_STRING, 0);
//		swBom.stop();
//		LOGGER.info("FPP BOM ELAPSED TIME : "+swBom.getTime());
//		String sType = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING;
//		mapBomResult =	busUtil.parseBOMMaplist(mlEBOMList,sUserlicense,isExternalUser);
//		StopWatch swTUP = new StopWatch();
//		swTUP.start();
//		MapList mlTUPFromFPP = doFPP.getRelatedObjects(context,ConstantsUtil.RELATIONSHIP_PGTRANSPORTUNIT, ConstantsUtil.TYPE_PGTRANSPORTUNITPART, slEBOMSelects,slRelEBOMSelects, false, true, (short) 1, null, null, 0);
//		swTUP.stop();
//		LOGGER.info("FPP TUP ELAPSED TIME : "+swTUP.getTime());
//		//MapList mlTupSubstitutes = busUtil.getTupBom(context, mlTUPFromFPP, slEBOMSelects, slRelEBOMSelects,);
//
//		MapList mlTupSubstitutes = new MapList();
//		if(mlTupSubstitutes.size()>0) {
//			String strTupName = (String) mlTupSubstitutes.get(mlTupSubstitutes.size()-1);
//			mlTupSubstitutes.remove(mlTupSubstitutes.size()-1);
//			mapTupBomResult = busUtil.parseMaplist(context,mlTupSubstitutes);			
//			mapTupBomResult.put(ConstantsUtil.TUPNAME, strTupName);
//		}
//		mlEBOMList.addAll(mlTupSubstitutes);
//
//		//Get Packing Unit and Transport Unit Table
//		MapList mlRelatedObjects = new MapList();
//		StringList slRelSelects = new StringList(ConstantsUtil.SELECT_PARTFAMILYREF_PGDIMENSIONUOM);
//		try {
//			StopWatch swRelatedObj = new StopWatch();
//			swRelatedObj.start();
//
//			Pattern sbTypePattern = new Pattern(ConstantsUtil.TYPE_PGTRANSPORTUNITCHARACTERISTIC);
//			sbTypePattern.addPattern(ConstantsUtil.TYPE_PGPACKINGUNITCHARACTERISTIC);
//
//			mlRelatedObjects = doFPP.getRelatedObjects(context,
//					ConstantsUtil.RELATIONSHIP_CHARACTERISTIC,
//					sbTypePattern.getPattern(),
//					slSelects,
//					slRelSelects,
//					false,
//					true,
//					(short) 1,
//					null,
//					null,
//					0);
//			swRelatedObj.stop();
//			LOGGER.info("FPP TUP RELATED OBJS ELAPSED TIME : "+swRelatedObj.getTime());
//		}catch(Exception e) {
//			LOGGER.error("Exception From FPP Service IMPL Class "+e);
//			//Subhajit Added for Memory Leakage Analysis - Start
//			context.close();
//			//Subhajit Added for Memory Leakage Analysis - End
//			throw e;
//		}
//		if (!mlRelatedObjects.isEmpty() && !sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT) ) {
//			mapPackagingUnitResult = busUtil.parsePUMaplist(mlRelatedObjects, true);
//		}
//		else 
//		{
//			mapPackagingUnitResult =  fppBO.UpdatePackagingChar(context, resultMap);
//		}
//		StopWatch swClassItem = new StopWatch();
//		swClassItem.start();
//
//		Pattern sbTypePattern = new Pattern(ConstantsUtil.TYPE_PGCUSTOMERUNITPART);
//		sbTypePattern.addPattern(ConstantsUtil.TYPE_PGINNERPACKUNITPART);
//		sbTypePattern.addPattern(ConstantsUtil.TYPE_PGCONSUMERUNITPART);
//		sbTypePattern.addPattern(ConstantsUtil.TYPE_FINISHEDPRODUCTPART);
//
//		MapList ebomPgCustPartList = doFPP.getRelatedObjects(context,
//				DomainObject.RELATIONSHIP_EBOM,                  //Rel Pattern
//				sbTypePattern.getPattern(),                      // Type Pattern
//				fppBO.addUnitSelects(fppBO.getMasterBusEbom()),  //Object Select
//				fppBO.getMasterRelEbom(), 						 //rel Select
//				false,											 //get To
//				true,											 //get From
//				(short)0,										 //recurse level
//				ConstantsUtil.EMPTY_STRING,												 //where Clause
//				null,											 //relationshipWhere Clause
//				0);
//		swClassItem.stop();
//		LOGGER.info("FPP TUP CLASSIFIED OBJS ELAPSED TIME : "+swClassItem.getTime());
//		if (!ebomPgCustPartList.isEmpty())
//		{
//			mpBomMcupResult=fppBO.updateMasterBom(ebomPgCustPartList);
//			mpEBOMMasterInnerPack=fppBO.updateMasterInnerPackBom(ebomPgCustPartList);
//
//			ebomPgCustPartList.addSortKey(ConstantsUtil.TYPE, ConstantsUtil.CONST_ASCENDING, ConstantsUtil.STRING);//Sorting necessary to populate Packaging Unit Table in order (CUP/COP)
//			ebomPgCustPartList.sort();
//			if(!sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT)){
//				mapPackagingUnitResult = busUtil.parsePUMaplist(mlRelatedObjects, true);
//				mapPackagingUnitResult = busUtil.getUOM(context, ebomPgCustPartList,mapPackagingUnitResult);
//			}
//
//		}
//
//		String sPhysicalId = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMap.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
//		String[] changeargs={objId,sPhysicalId};
//		StopWatch swLifecycle = new StopWatch();
//		swLifecycle.start();
//		mpLifeCycleApproval = busUtil.getCOName(context, changeargs);
//		swLifecycle.stop();
//		LOGGER.info("FPP GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
//		mapAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
//
//		//Header Content
//		mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
//		mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
//		mpHeaderResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
//		mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMap.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);		
//		mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
//
//		//ATTRIBUTES
//		mapAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.ID, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ID)))?(String)resultMap.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.TYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.OWNER, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_OWNER)))?(String)resultMap.get(ConstantsUtil.SELECT_OWNER) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.POLICY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_POLICY)))?(String)resultMap.get(ConstantsUtil.SELECT_POLICY) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.MODIFIED, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMap.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.ORIGINATED)))?(String)resultMap.get(ConstantsUtil.ORIGINATED) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_STATUS) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.PARTFAMILY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PARTFAMILY) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
//		String strBrand=ConstantsUtil.EMPTY_STRING;
//		if(validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION))) {
//			strBrand = (String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION);
//			String[] Brand=strBrand.split(ConstantsUtil.SYMBL_TILDA);
//			strBrand = Brand[0].toString();
//		}
//		mapAttribResult.put(ConstantsUtil.BRAND, strBrand);
//		mapAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.MARKETINGSIZE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMARKETINGSIZE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.CUSTOMIZATIONTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMIZATIONTYPE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
//		String sClassifictaion = busUtil.getClassification(resultMap);
//		mapAttribResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion);
//		mapAttribResult.put(ConstantsUtil.STATISTICALUNIT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_STATISTICALUNIT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PG_STATISTICALUNIT) : ConstantsUtil.EMPTY_STRING);
//		mapAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.strPGPDTTOPGPLIREFUN)))?(String)resultMap.get(ConstantsUtil.strPGPDTTOPGPLIREFUN) : ConstantsUtil.EMPTY_STRING);
//
//		//STORAGE AND LABEL
//		mapStorageAndLabelResult.put(ConstantsUtil.POWERSOURCE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTMARKETEDASCHILDRENSPRODUCT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTMARKETEDASCHILDRENPRODUCT) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.DOESTHEPRODUCTREQUIRECHILDSAFEDESIGN, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDOESTHEPRODUCTREQUIRECHILDSAFEDESIGN) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.ISPRODUCTEXPOSEDTOCHILDREN, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPRODUCTEXPOSEDTOCHILDREN) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.WAREHOUSINGCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.DANGEROUSGOODSCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGDANGEROUSGOODSCLASSIFICATION) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.CUSTOMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCUSTOMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.CONSUMERUNITLABELING, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCONSUMERUNITLABELING) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.UNNUMBER, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPUNNUMBER) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.PROPERSHIPPINGNAME, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPROPERSHIPPINGNAME) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.HAZARDCLASS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGHAZARDCLASS) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.PACKINGGROUP, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKINGGROUP) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.STORAGEINFORMATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEINFORMATION) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);
//		mapStorageAndLabelResult = busUtil.filterMapList(mapStorageAndLabelResult);
//
//		//WAREHOUSE
//		mapWarehouseClassResult.put(ConstantsUtil.CORROSIVE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVE)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCORROSIVE) : ConstantsUtil.EMPTY_STRING);
//		mapWarehouseClassResult.put(ConstantsUtil.WAREHOUSINGCLASSIFICATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWAREHOUSECLASIFICATION) : ConstantsUtil.EMPTY_STRING);
//		mapWarehouseClassResult = busUtil.filterMapList(mapWarehouseClassResult);
//
//		//Part Spec Data
//		mapPartSpecification = busUtil.updatePartSpec(context, resultMap);
//
//		//Master Specs
//		StopWatch swMasterSpec = new StopWatch();
//		swMasterSpec.start();
//		mpMasterSpecs = fppBO.getMasterSpecs(context,doFPP);
//		swMasterSpec.stop();
//		LOGGER.info("FPP MASTER SPEC ELAPSED TIME : "+swMasterSpec.getTime());
//
//		//Derived Data
//		String sName = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_NAME))?(String)resultMap.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING;
//		String sRev = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_REVISION))?(String)resultMap.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING;
//		String sCreatedDate = validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ORIGINATED))?(String)resultMap.get(ConstantsUtil.SELECT_ORIGINATED) : ConstantsUtil.EMPTY_STRING;
//		mpDerivedResult = busUtil.updateDerivedDataInfo(context,sName, sRev, sCreatedDate, doFPP,true,false);
//
//
//		//PLANTS
//		mapPlantResult = busUtil.updatePlantInfo(resultMap);
//
//
//		//WND
//		mapWnDResult.put(ConstantsUtil.HEIGHT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_WND_OUTER_DIMENSION_HEIGHT)))?(String)resultMap.get(ConstantsUtil.SELECT_WND_OUTER_DIMENSION_HEIGHT) : ConstantsUtil.EMPTY_STRING);
//		mapWnDResult.put(ConstantsUtil.WIDTH, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_WND_OUTER_DIMENSION_WIDTH)))?(String)resultMap.get(ConstantsUtil.SELECT_WND_OUTER_DIMENSION_WIDTH) : ConstantsUtil.EMPTY_STRING);
//		mapWnDResult.put(ConstantsUtil.UOM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_WND_ATTRIBUTE_PG_DIMENSTION_UOM)))?(String)resultMap.get(ConstantsUtil.SELECT_WND_ATTRIBUTE_PG_DIMENSTION_UOM) : ConstantsUtil.EMPTY_STRING);
//		mapWnDResult.put(ConstantsUtil.LENGTH, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_WND_OUTER_DIMENSION_LENGTH)))?(String)resultMap.get(ConstantsUtil.SELECT_WND_OUTER_DIMENSION_LENGTH) : ConstantsUtil.EMPTY_STRING);
//		mapWnDResult.put(ConstantsUtil.WDSTATUS, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGWDSTATIUS) : ConstantsUtil.EMPTY_STRING);
//		mapWnDResult.put(ConstantsUtil.UNITOFMEASURESYSTEM, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGUNITOFMEASURESYSTEM) : ConstantsUtil.EMPTY_STRING);
//		mpOrganization = busUtil.filterMapList(mpOrganization);
//
//		StringList slCos=(validator.isNotNullOrEmpty((StringList)resultMap.get(ConstantsUtil.SELECT_COS_NAME)));
//		String strCos = slCos.toString();
//		strCos = strCos.replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
//		mapCosResult.put(ConstantsUtil.COUNTRIESOFSALE, strCos);
//		StringList slCosRestriction = (validator.isNotNullOrEmpty((StringList)resultMap.get(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION)));
//		String strCosRestriction = slCosRestriction.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
//		mapCosResult.put(ConstantsUtil.COUNTRIESOFSALERESTRICTIONS,strCosRestriction);
//		StringList slCosDateAndTime = (validator.isNotNullOrEmpty((StringList)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE)));
//		String strCosDateAndTime = slCosDateAndTime.toString().replace(ConstantsUtil.SYMBL_OPENBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_CLOSEBRACE, ConstantsUtil.EMPTY_STRING).replace(ConstantsUtil.SYMBL_COMMA, ConstantsUtil.SYMBL_PIPE);
//		mapCosResult.put(ConstantsUtil.DATEANDTIMEOFLASTCOSCALC, strCosDateAndTime);
//		mapCosResult = busUtil.filterMapList(mapCosResult);
//
//		//Ownership
//		mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
//		mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSEGMENT) : ConstantsUtil.EMPTY_STRING);
//		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEUSER, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER)))?(String)resultMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLASTUPDATEUSER) : ConstantsUtil.EMPTY_STRING);
//		mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
//		mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_MODIFIED)))?(String)resultMap.get(ConstantsUtil.SELECT_MODIFIED) : ConstantsUtil.EMPTY_STRING);
//		mapOwnerShipResult = busUtil.filterMapList(mapOwnerShipResult);
//
//		//Organization Data
//		mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
//		mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMap.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
//		mpOrganization = busUtil.filterMapList(mpOrganization);
//
//		StringBuffer sbName = new StringBuffer();
//		StringBuffer sbtitle = new StringBuffer();
//		StringBuffer sbtype = new StringBuffer();
//		StringBuffer sbsapType = new StringBuffer();
//		StringBuffer sbsapSubType = new StringBuffer();
//		StringBuffer sbbomQuantity = new StringBuffer();
//		StringBuffer sbbomBuom = new StringBuffer();
//		Map<String,String> mpBomCupResult = new HashMap<String,String>();
//		Map<String,String> mpBomCopResult = new HashMap<String,String>();
//		Map<String,String> mpBomIpResult = new HashMap<String,String>();
//		Map<String,String> mpBomMcopResult = new HashMap<String,String>();
//		Map<String,String> mpBomSubstituteResult = new HashMap<String,String>();
//		int i;
//		Map<String, String> mp = null;
//		for(i=0;i<mlEBOMList.size();i++) {
//			mp = (Map<String, String>) mlEBOMList.get(i);
//			String name = mp.get(ConstantsUtil.SELECT_NAME).toString();
//			String type = mp.get(ConstantsUtil.SELECT_TYPE).toString();
//
//			//CUP-BOM
//			if(type.equalsIgnoreCase(ConstantsUtil.TYPE_PGCUSTOMERUNITPART)) {
//				String strOid = mp.get(ConstantsUtil.SELECT_ID);
//				if (!strOid.isEmpty()) {
//					DomainObject doCup = new DomainObject(strOid);
//					slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_NAME);
//					slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_REVISION);
//					slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_TITLE);
//					slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_RELEASEDATE);
//					slRelEBOMSelects.add(ConstantsUtil.SELECT_EBOM_SUBSTITUTE_PGASSEMBLYTYPE);
//					StopWatch swCup = new StopWatch();
//					swCup.start();
//					MapList mlCup = doCup.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slSelects,
//							slRelEBOMSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
//
//					swCup.stop();
//					LOGGER.info("FPP GET CUPBOM ELAPSED TIME : "+swCup.getTime());
//					if(mlCup.size()!=0){
//						mpBomCupResult =	busUtil.parseMaplist(context,mlCup);
//						//MapList mlSubstitute = fppBO.getSubstitutes(mlCup);
//						MapList mlSubstitute = new MapList();
//						mpBomSubstituteResult = busUtil.parseMaplistForSubstitute(context, mlSubstitute);
//					}
//				}
//			}
//
//			//COP-BOM
//			if(type.equalsIgnoreCase(ConstantsUtil.TYPE_PGCONSUMERUNITPART) || type.equalsIgnoreCase(ConstantsUtil.TYPE_CUSTOMERUNITPART)) {
//				String strOid = (String) mp.get(ConstantsUtil.SELECT_ID);
//				if (!strOid.isEmpty()) {
//					DomainObject doCop = new DomainObject(strOid);
//					slRelEBOMSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT);
//					StopWatch swCOPBom = new StopWatch();
//					swCOPBom.start();
//					MapList mlCop = doCop.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slSelects,
//							slRelEBOMSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
//					swCOPBom.stop();
//					LOGGER.info("FPP GET COPBOM ELAPSED TIME : "+swCOPBom.getTime());
//					if(mlCop.size()!=0){
//						mpBomCopResult =	busUtil.parseBomCopMaplist(mlCop);
//					}
//				}
//			}
//
//			if(type.equalsIgnoreCase(ConstantsUtil.TYPE_PGINNERPACKUNITPART) || type.equalsIgnoreCase(ConstantsUtil.INNERPACKUNITPAT)) {
//				String strOid =(String) mp.get(ConstantsUtil.SELECT_ID);
//				if (!strOid.isEmpty()) {
//					DomainObject doIp = new DomainObject(strOid);
//					StopWatch swIp = new StopWatch();
//					swIp.start();
//					MapList mlIp = doIp.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM, ConstantsUtil.QUERY_WILDCARD, slSelects,
//							slRelEBOMSelects, false, true, (short) 1, ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, 0);
//					swIp.stop();
//					LOGGER.info("FPP GET IPBOM ELAPSED TIME : "+swIp.getTime());
//					if(mlIp.size()!=0){
//						mpBomIpResult =	busUtil.parseMaplist(context,mlIp);
//					}
//				}
//			}
//
//			if(name.contains(ConstantsUtil.CUP) || name.contains(ConstantsUtil.COP) || type.equalsIgnoreCase(ConstantsUtil.TYPE_FINISHEDPRODUCTPART)) {
//				continue;
//			}
//			sbName.append(name);
//			sbtitle.append(mp.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE).toString());
//			type = busUtil.mapType(type);
//			sbtype.append(type);
//			sbsapSubType.append(mp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGASSEMBLYTYPE).toString());
//			sbsapType.append(mp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE).toString());
//			String sQty = validator.isNotNullOrEmpty((String)mp.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY))?(String)mp.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY):ConstantsUtil.EMPTY_STRING;
//			float sQuantity = Float.parseFloat(sQty);
//			sQuantity*=1000;
//			sbbomQuantity.append(sQuantity);
//			sbbomBuom.append(mp.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE).toString());
//			if(i<(mlEBOMList.size()-1)) {
//				sbName.append(ConstantsUtil.SYMBL_PIPE);
//				sbtitle.append(ConstantsUtil.SYMBL_PIPE);
//				sbtype.append(ConstantsUtil.SYMBL_PIPE);
//				sbsapType.append(ConstantsUtil.SYMBL_PIPE);
//				sbsapSubType.append(ConstantsUtil.SYMBL_PIPE);
//				sbbomQuantity.append(ConstantsUtil.SYMBL_PIPE);
//				sbbomBuom.append(ConstantsUtil.SYMBL_PIPE);
//			}
//
//		}
//		mapSapBomAsFedResult.put(ConstantsUtil.NAME, sbName.toString());
//		mapSapBomAsFedResult.put(ConstantsUtil.TITLE, sbtitle.toString());
//		mapSapBomAsFedResult.put(ConstantsUtil.TYPE, sbtype.toString());
//		mapSapBomAsFedResult.put(ConstantsUtil.SAPTYPE, sbsapType.toString());
//		mapSapBomAsFedResult.put(ConstantsUtil.SPECIFICATIONSUBTYPE, sbsapSubType.toString());
//		mapSapBomAsFedResult.put(ConstantsUtil.BOMQUANTITY, sbbomQuantity.toString());
//		mapSapBomAsFedResult.put(ConstantsUtil.BASEUNITOFMEASURE, sbbomBuom.toString());
//
//
//		//Transport Unit
//		if(sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT))
//		{
//			mapTransportUnitResult= fppBO.UpdateTransportChar(context, resultMap);
//		} else {
//			//mapTransportUnitResult = fppBO.parseTransMaplist(mlTUPFromFPP);
//		}
//
//
//		//Performance Car
//		StopWatch swPerfChar = new StopWatch();
//		swPerfChar.start();
//		Map<String, String> paramMap = new HashMap<String, String>();
//		paramMap.put(ConstantsUtil.OBJECT_ID, objId);
//		paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
//		paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
//		paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);
//
//
//		if(sType.equals(ConstantsUtil.TYPE_PGFINISHEDPRODUCT))
//		{
//			//mpPerformChar = busUtil.getExtendedPerformChar(context, doFPP, sRev, sName,resultMap);
//			swPerfChar.stop();
//			LOGGER.info("FPP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
//		}
//		else{
//			PerformanceCharcteristics perform = new PerformanceCharcteristics();
//			MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
//			MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
//			//mpPerformChar =  busUtil.updatePerformCharcteristic(context,mlPerformAttrib,resultMap);
//			swPerfChar.stop();
//			LOGGER.info("FPP GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());
//		}
//
//
//
//
//
//		hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
//		hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mapAttribResult);
//		hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
//		hmAttrib.put(ConstantsUtil.PLANTS, mapPlantResult);
//		hmAttrib.put(ConstantsUtil.STORAGETRANSPORTDATAOBJECT, mapStorageAndLabelResult);
//		hmAttrib.put(ConstantsUtil.SAPBOMASFED, mapSapBomAsFedResult);
//		hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mapBomResult);
//		hmAttrib.put(ConstantsUtil.BILLOFMATERIALSCUSTOMERUNIT, mpBomCupResult);
//		hmAttrib.put(ConstantsUtil.BILLOFMATERIALSCONSUMERUNIT, mpBomCopResult);
//		hmAttrib.put(ConstantsUtil.BILLOFMATERIALSTRANSPORTUNIT, mapTupBomResult);
//		if(null!=mpBomIpResult && !mpBomIpResult.isEmpty()) {
//			hmAttrib.put(ConstantsUtil.BILLOFMATERIALSINNERPACK, mpBomIpResult);
//		}
//		if(null!=mpBomMcupResult && !mpBomMcupResult.isEmpty()) {
//			hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERCUSTOMERUNIT, mpBomMcupResult);
//		}
//		hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERINNERPACK, mpEBOMMasterInnerPack);
//		hmAttrib.put(ConstantsUtil.BILLOFMATERIALSMASTERCONSUMERUNIT, mpBomMcopResult);
//		hmAttrib.put(ConstantsUtil.WEIGHTSDIMENSIONSOBJECT, mapWnDResult);
//		hmAttrib.put(ConstantsUtil.OWNERSHIPOBJECT, mapOwnerShipResult);
//		if(null!=strCos && !strCos.isEmpty()) {
//			hmAttrib.put(ConstantsUtil.COUNTRIESOFSALE, mapCosResult);
//		}
//
//
//		hmAttrib.put(ConstantsUtil.WAREHOUSECLASSIFICATION, mapWarehouseClassResult);
//		hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mapPartSpecification);
//		hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
//		hmAttrib.put(ConstantsUtil.PACKINGUNIT, mapPackagingUnitResult);
//		hmAttrib.put(ConstantsUtil.TRANSPORTUNIT, mapTransportUnitResult);
//		hmAttrib.put(ConstantsUtil.SUBSTITUTESCUSTOMERUNIT, mpBomSubstituteResult);
//		hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTS, mpDerivedResult);
//		hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
//		hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
//
//		System.out.println("SESSION ID :::"+context.getSession().getSessionId());
//		pool.checkIn(context);
//		//Subhajit Added for Memory Leakage Analysis - Start
//		context.close();
//		//Subhajit Added for Memory Leakage Analysis - End
//		sp.stop();
//		LOGGER.info("FPP MESSAGE ELAPSED TIME::" + sp.getTime() +"  " + "FPP OBJECT NAME::"+resultMap.get(ConstantsUtil.SELECT_NAME));
//	}
//}