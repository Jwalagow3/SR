/**
 * Project 		: SpecsAnywhere
 * Program 		: EnoviaFABServiceImpl
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.bo.CalculateBOM;
import com.pg.us.specanywhere_enovia.bo.CommonBusUtilBO;
import com.pg.us.specanywhere_enovia.bo.ConsumerUnitPartBO;
import com.pg.us.specanywhere_enovia.bo.FabricatedPartBO;
import com.pg.us.specanywhere_enovia.bo.FinishedProductPartBO;
import com.pg.us.specanywhere_enovia.bo.MasterCOPBO;
import com.pg.us.specanywhere_enovia.bo.PackagingMaterialPartBO;
import com.pg.us.specanywhere_enovia.bo.PerformanceCharcteristics;
import com.pg.us.specanywhere_enovia.bo.SapBomAsFed;
import com.pg.us.specanywhere_enovia.cp.EnoviaConnectionPool;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.service.EnoviaFABService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class EnoviaFABServiceImpl implements EnoviaFABService  {


	private static Logger LOGGER = Logger.getLogger(EnoviaFABServiceImpl.class);
	
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
	@Autowired
    private HttpServletRequest request;
	//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
	
	@Autowired
	private EnoviaConnectionPool pool;
	
	@Override
	public HashMap<String, Map<String, String>> getFABdata(String objId, String sComp, Environment env) throws Exception {
		HashMap<String, Map<String, String>> hmAttrib = new HashMap<String, Map<String, String>>();
		StopWatch sp = new StopWatch();
		sp.start();
		Context context = null;
		
		try
		{
			StopWatch swContext = new StopWatch();
			swContext.start();
			context = pool.checkOut();
			swContext.stop();
			
			LOGGER.info("FAB CONTEXT ELAPSED TIME : "+swContext.getTime());

			/**
			 * User Profile
			 * */
			SecurityService sct = new SecurityService();
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- START
			String sUserType = sct.getUserType();
			BusObjectAttribUtil BObjutil = new BusObjectAttribUtil();
			if(sUserType.equalsIgnoreCase(ConstantsUtil.PG_CM)){
				sUserType = BObjutil.getUserView(context, objId);
			}
			//SPEC: Release SR18x.6.0.1 - Modified by Manikanta on June 17, 2021 for Defect #43415 -- END
			if(null==sUserType) {
				LOGGER.error("ERROR: INVALID USER PROFILE FROM INTEGRATION SERVICE : "+sUserType);
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E101.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}

			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			boolean bAllInfoView = false;
			boolean bSupplierView = false;
			boolean bManufacturerView = false;
			
			StringValidatorUtil validator = new StringValidatorUtil();
			String strPDFView = validator.isNotNullOrEmpty(request.getHeader("view"))?request.getHeader("view") : ConstantsUtil.EMPTY_STRING;
			LOGGER.info("PDF VIEW Info : "+strPDFView);
			
				if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
					bManufacturerView = true;
				} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
					bSupplierView = true;
				} else {
					switch (sUserType) {
					case ConstantsUtil.PG:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PGSTAFF:
						bAllInfoView = true;
						break;

					case ConstantsUtil.PG_CM:
						bManufacturerView = true;
						break;

					case ConstantsUtil.PG_SP:
						bSupplierView = true;
						break;
					}

				}
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
			FabricatedPartBO FABBO = new FabricatedPartBO();
			DomainObject doFAB =  FABBO.getFABDO(context, objId);
			String strCurrent = doFAB.getInfo(context, DomainConstants.SELECT_CURRENT);
			
			if(UIUtil.isNotNullAndNotEmpty(sUserType) && (sComp!=ConstantsUtilIRM.COMPARE &&  sComp!=ConstantsUtilIRM.STATE_PRILIMNARY))
			{
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess && (strCurrent.equals(ConstantsUtil.RELEASE))) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					return hmAttrib;
				
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- START
				else if(!strCurrent.equals(ConstantsUtil.RELEASE)) {
					HashMap<String, String> errorMap = new HashMap<String, String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					if(strCurrent.equals(ConstantsUtil.STATE_OBSOLETE)) {
						sError = ConstantsUtil.E107.split(ConstantsUtil.SYMBL_COLON);
					}
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					LOGGER.error("ERROR: No ACCESS AS OBJECT IS NOT RELEASED : " + objId);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				}
				//SPEC: <12.08.2022>: Satyam Added for Defect 49774 -- END
			}else {
				BusObjectAttribUtil Bbutil = new BusObjectAttribUtil();
				boolean bObjectHasAccess=Bbutil.checkHasAccess(context,sUserType,objId);
				if (!bObjectHasAccess) 
				{
					HashMap<String,String> errorMap = new HashMap<String,String>();
					String[] sError = ConstantsUtil.E104.split(ConstantsUtil.SYMBL_COLON);
					errorMap.put(sError[0], sError[1]);
					hmAttrib.put(ConstantsUtil.ERROR, errorMap);
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
					context.close();
					//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
					return hmAttrib;
				
				}
			}//SPEC: Modified by Ajay for Req. no. 23960 END
			//SPEC : 10/19/2020 : Security Check added for granting the access  --END
			
			
			Map<String,String> mpHeaderResult = new HashMap<String,String>();
			Map<String,String> mpAttribResult = new HashMap<String,String>();
			Map<String,String> mpOrganization = new HashMap<String,String>();
			Map<String,String> mpEBOMResult = new HashMap<String,String>();
			Map<String,String> mpSubstitute = new HashMap<String,String>();
			Map<String,String> mpNotes = new HashMap<String,String>();
			Map<String,String> mapWeightCharResult = new HashMap<String,String>();
			Map<String,String> mpSapBomAsFedcResult = new HashMap<String,String>();
			Map<String,String> mpPlantResult = new HashMap<String,String>();
			/*Map<String,String> mpDerivedFromResult = new HashMap<String,String>();
			Map<String,String> mpDerivedToResult = new HashMap<String,String>();*/
			Map<String,String> mpLifeCycleApproval = new HashMap<String,String>();
			Map<String,String> mapOwnerShipResult = new HashMap<String,String>();
			Map<String,String> mpRelatedSpecResult = new HashMap<String,String>();
			Map<String,String> mpPerformChar = new HashMap<String,String>();
			Map<String,String> mpSecurity = new HashMap<String,String>();
			Map<String,String> mapReferenceDocs = new HashMap<String, String>();
			Map<String,String> mpRelatedATS = new HashMap<String,String>();
			Map<String,String> mpMasterSpecs = new HashMap<String,String>();
			Map<String,String> mpMEPResult = new HashMap<String,String>();
			Map<String,String> mpSEPResult = new HashMap<String,String>();
			Map<String,String> mpMasterAttribute = new HashMap<String,String>();
			Map<String,String> mapCosResult = new HashMap<String,String>();
			Map<String,String> mpSustainability = new HashMap<>();//Added by Ketan for Req. no. 48322
			//SPEC: <10.12.2020>: Added for req 18x.5 ## -- START
			Map<String,String> mpIpSecuritySetting = new HashMap<String,String>();
			Map<String,String> mpMaterialResult = new HashMap<String,String>();
			Map<String,String> mpFiles = new HashMap<String,String>();
			//SPEC: <10.12.2020>: Added for req 18x.5 ## -- END
			//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- START
			Map<String,String> mpAlternates = new HashMap<String,String>();
			Map<String,String> mpRegistrationDetails = new HashMap<String,String>();
			CommonBusUtilBO commonBO = new CommonBusUtilBO();
			//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- END
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- START
			Map<String,String> mpCertification = new HashMap<>();
			ConsumerUnitPartBO CopBO = new ConsumerUnitPartBO();
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- END
			Map<String,String> mpExtendedAttribute = new HashMap<String,String>();

			BusObjectAttribUtil util = new BusObjectAttribUtil();
			Map<String, StringList> BusinessObjectSelectableMap = FABBO.getFabricatedPartSelectables(context);
			Map<String, StringList> ChilsObjectSelectableMap = FABBO.getFABRelatedObjsSelectableMap(context);
			StringList slContextSelects = (StringList) BusinessObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- START
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGORIGINATINGSOURCE);
			slContextSelects.add(ConstantsUtil.ATL_STATE);
			slContextSelects.add(ConstantsUtil.LEGACYENVCLASSNAME);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE);
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM); 
			slContextSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL);
			//Added by Ketan for Req. no. 48322 -- START
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGEDURABILITY);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALTHICKNESS);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALDENSITY);
			slContextSelects.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY);
			//Added by Ketan for Req. no. 48322 -- END
			StringList slChildBusSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.BUS_SELECTS);
			StringList slChildRelSelects = (StringList) ChilsObjectSelectableMap.get(ConstantsUtil.REL_SELECTS);

			if (null == doFAB) {
				HashMap<String,String> errorMap = new HashMap<String,String>();
				String[] sError = ConstantsUtil.E100.split(ConstantsUtil.SYMBL_COLON);
				errorMap.put(sError[0], sError[1]);
				hmAttrib.put(ConstantsUtil.ERROR, errorMap);
				LOGGER.error("ERROR: OBJECT NOT FOUND IN DB WITH OID : "+objId);
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- START
				context.close();
				//SPEC: <08-11-2021>: Bala Added for Defect 45181  -- END
				return hmAttrib;
			}
			
			StopWatch swAttributes = new StopWatch();
			swAttributes.start();
			//Map resultMaps = doFAB.getInfo(context, slContextSelects);
			Map resultMaps = doFAB.getInfo(context, slContextSelects,FABBO.addMultiList());
			swAttributes.stop();
			LOGGER.info("FAB GETINFO ELAPSED TIME : "+swAttributes.getTime());
			
			String lastUpdatedUser = ConstantsUtil.EMPTY_STRING;
			//Common usage Variables
			String sContextObjectId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
			String sClassifictaion = util.getClassification(resultMaps);
			
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- START
			if(strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW)) {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_CM);
			} else if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, ConstantsUtil.PG_SP);
			} else {
				mpHeaderResult.put(ConstantsUtilIRM.ROLEINFO, sUserType);
			}
			//Added by Jwala for PDF VIews requirement 34055 2022x Development -- END
			
			if(bAllInfoView || bSupplierView || bManufacturerView) {
				/**
				 * LOAD BASIC ATTRIBUTES SECTION
				 * */
				mpAttribResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.DESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.TYPE,util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PHASE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PREVIOUSREVISIONOBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPREVIOUSREVISIONOBSOLETEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.MANUFACTURINGSTATUS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLIFECYCLESTATUS) : ConstantsUtil.EMPTY_STRING);		
				mpAttribResult.put(ConstantsUtil.REASONFORCHANGE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_REASONFORCHANGE) : ConstantsUtil.EMPTY_STRING);
				
				//mpAttribResult.put(ConstantsUtil.BRAND, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBRANDINFORMATION) : ConstantsUtil.EMPTY_STRING);
				String sID = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_ID) : ConstantsUtil.EMPTY_STRING;
				String strBrand = util.getBrandInformationValue(context,sID);
				if(strBrand.isEmpty()) {
					strBrand = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME))?(String)resultMaps.get(ConstantsUtil.SELECT_PGPDTEMPLATESTOPGBRAND_NAME):ConstantsUtil.EMPTY_STRING;
				}
				mpAttribResult.put(ConstantsUtil.BRAND, strBrand);
				
				mpAttribResult.put(ConstantsUtil.CLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SUBCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSUBCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.REPORTEDFUNCTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION)))?(String)resultMaps.get(ConstantsUtil.REPORTED_FUNCTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.POWERSOURCE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPOWERSOURCE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BATTERYTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBATTERYTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEUNITOFMEASURE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBASEUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.BASEQUANTITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGENTRYBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.SAPBOMBASEQTY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGBOMBASEQUANTITY) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6. Modified by Dominic on Date 15/03/2021 --START
				//mpAttribResult.put(ConstantsUtil.LEGACYENVCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGMATERIALLEGACYENVCLASS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LEGACYENVCLASS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.LEGACYENVCLASSNAME)))?(String)resultMaps.get(ConstantsUtil.LEGACYENVCLASSNAME) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6. Modified by Dominic on Date 15/03/2021 --END
				mpAttribResult.put(ConstantsUtil.EXPANDBOMONSAPBOMASFED, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGEXPANDBOMONSAPBOMASFED) : ConstantsUtil.EMPTY_STRING));
				mpAttribResult.put(ConstantsUtil.LOCALDESCRIPTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLOCALDESCRIPTION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OTHERNAMES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGOTHERNAMES) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGSIZEUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGSIZEUOM) : ConstantsUtil.EMPTY_STRING);
				//Added by Ketan for Req. no. 48322 -- START
				mpAttribResult.put(ConstantsUtil.PACKAGINGCOMPONENTTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGCOMPONENTTYPE) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGMATERIALTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGMATERIALTYPE) : ConstantsUtil.EMPTY_STRING);
				//Added by Ketan for Req. no. 48322 -- END
				//SPEC: Release SR18x.5.2: Modified for Defect 37289 by Amman ## -- START
				//mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.PACKAGINGTECHNOLOGY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGPACKAGINGTECHNOLOGY) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.5.2: Modified for Defect 37289 by Amman ## -- END
				
				mpAttribResult.put(ConstantsUtil.SHIPPINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSHIPPINGINSTRUCTIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.LABELINGINFORMATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGLABELINGINFORMATION) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGETEMPERATURELIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGETEMPERATURELIMITS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.STORAGEHUMIDITYLIMITS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTORAGEHUMIDITYLIMITS) : ConstantsUtil.EMPTY_STRING);		
				mpAttribResult.put(ConstantsUtil.STORAGECONDITIONS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_STORAGECONDITIONS) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				
				//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
				mpAttribResult.put(ConstantsUtil.STRUCTUREDRELEASECRITERIAREQ, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSTRUCTUREDRELEASECRITERIAREQ) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END
				//SPEC: 05/04/2022: Added by Manikanta for 22x DEV -- START
				mpAttribResult.put(ConstantsUtilIRM.TRANSPORTATIONTEMPCONTROL, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGTRANSPORTATIONTEMPCONTROL) : ConstantsUtil.EMPTY_STRING);
				//SPEC: 05/04/2022: Added by Manikanta for 22x DEV -- END
				
				//Added by Subhajit for Req 46464 - Start
				if(!bSupplierView) {
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTION) : ConstantsUtil.EMPTY_STRING);
					mpAttribResult.put(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_RELATIONSHIPRESTRICTIONCOMMENTS) : ConstantsUtil.EMPTY_STRING);
				}
				//Added by Subhajit for Req 46464 - End
				
				
				/**
				 * LOAD HEADER CONTENT SECTION
				 * */
				mpHeaderResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.REVISION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_REVISION)))?(String)resultMaps.get(ConstantsUtil.SELECT_REVISION) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.TYPE, util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				//SPEC: Release SR18x.6. Modified by Dominic on Date 09/03/2021 --START
				//mpHeaderResult.put(ConstantsUtil.STATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING);
				String strState=validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_CURRENT))?(String)resultMaps.get(ConstantsUtil.SELECT_CURRENT) : ConstantsUtil.EMPTY_STRING;
				if(strState.equalsIgnoreCase(ConstantsUtil.STATE_RELEASE))
				{
					strState=ConstantsUtil.RELEASED;
				}
				mpHeaderResult.put(ConstantsUtil.STATE, strState);
				//SPEC: Release SR18x.6. Modified by Dominic on Date 09/03/2021 --END
	
				mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.EFFECTIVEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE)) : ConstantsUtil.EMPTY_STRING);
				
				if(!bManufacturerView && !bSupplierView){
					mpHeaderResult.put(ConstantsUtil.SAPTYPE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE) : ConstantsUtil.EMPTY_STRING); 
				}
				
				//SPEC: 10/12/2020: Added for 18x.5 DEV -- START
				mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				//mpHeaderResult.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))));
				//SPEC: 10/12/2020: Added for 18x.5 DEV -- END
				
				mpHeaderResult.put(ConstantsUtil.TITLE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.EXPIRATIONDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE)) : ConstantsUtil.EMPTY_STRING);
				mpHeaderResult.put(ConstantsUtil.CLASSIFICATION, sClassifictaion); 
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- START
				mpHeaderResult.put(ConstantsUtil.MASTERPARTNAME, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTNAME))));
				mpHeaderResult.put(ConstantsUtil.MASTERPARTTYPE, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTTYPE))));
				//mpHeaderResult.put(ConstantsUtil.MASTERPARTID, (validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID))));
				//Modified by Ganesh for Defect 38137  18x.5.2 Release ---->start
				String masterId = validator
						.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_MASTERPARTID));
				if (UIUtil.isNotNullAndNotEmpty(masterId)) {
					DomainObject obj = new DomainObject(masterId);
					String masterState = obj.getInfo(context, ConstantsUtil.SELECT_CURRENT);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
					obj.close(context);
					//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
					if (!masterState.equals(ConstantsUtil.RELEASE) && !masterState.equals(ConstantsUtil.RELEASED)) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
					boolean showData = util.checkHasAccess(context, sUserType, masterId);
					if (!showData) {
						masterId = ConstantsUtil.NO_ACCESS;
					}
				}
				mpHeaderResult.put(ConstantsUtil.MASTERPARTID, masterId);
                 //Modified by Ganesh for Defect 38137  18x.5.2 Release ---->END
				//SPEC: 10/09/2020: Added for 18x.5 DEV -- END
				
				/**
				 * LOAD BOM SECTION
				 * */
				StopWatch swBom = new StopWatch();
				swBom.start();
				MapList mapList = doFAB.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_EBOM,
						ConstantsUtil.SYMBL_ASTERISK, slChildBusSelects, slChildRelSelects, false, true, (short) 1,
						ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				
				if(bManufacturerView || bSupplierView) {
					mapList=util.filterPhase(mapList);
				}
				
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				if(mapList.size()!=0){
					mpEBOMResult =FABBO.parseMaplist(context,mapList);
					//Added by Ketan for Req no. 46464 -- START
					if(bSupplierView) {
						mpEBOMResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTION);
						mpEBOMResult.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS);
					}
					//Added by Ketan for Req no. 46464 -- END
					//mpSubstitute = FABBO.getSubstitute(context,mapList);
					mpSubstitute = FABBO.parseSubstitute(context,mapList);
					//Added by Ketan for Req no. 46464 -- START
					if(bSupplierView) {
						mpSubstitute.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTION);
						mpSubstitute.remove(ConstantsUtilIRM.RELATIONSHIPRESTRICTIONCOMMENTS);
					}
					//Added by Ketan for Req no. 46464 -- END
				}
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- END
				swBom.stop();
				
				/**
				 * LOAD NOTES SECTION
				 * */
				MasterCOPBO mcop = new MasterCOPBO();
				mpNotes=mcop.updateNotes(context, resultMaps);
				LOGGER.info("FAB BOM AND NOTES ELAPSED TIME : "+swBom.getTime());

				/**
				 * LOAD PERFORMANCE CHAR SECTION
				 * */
				Map paramMap = new HashMap();
				paramMap.put(ConstantsUtil.OBJECT_ID, objId);
				paramMap.put(ConstantsUtil.ADDROW, ConstantsUtil.TRUE);
				paramMap.put(ConstantsUtil.SELECTEDTABLE, ConstantsUtil.PGVPDPERMANCECHARTABLE);
				paramMap.put(ConstantsUtil.PGVPDPERMANCECHARFILTER, ConstantsUtil.ALL);

				PerformanceCharcteristics perform = new PerformanceCharcteristics();
				StopWatch swPerfChar = new StopWatch();
				swPerfChar.start();
				MapList mlPerformChar = perform.getPerformanceChar(context,JPO.packArgs(paramMap));
				if(!mlPerformChar.isEmpty())
				{
					FinishedProductPartBO fppBO = new FinishedProductPartBO();
					MapList mlPerformAttrib =fppBO.getAttributes(context, mlPerformChar);
					
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - START
					//mpPerformChar = util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps);
					mpPerformChar = util.updatePerformCharcteristic(context,mlPerformAttrib,resultMaps,objId);
					//SPEC: Release SR18x.6.0.1 - Modified  by Sanjeeva for MPT (Internal Defect) on 05/05/2021 - END
					
				}
				swPerfChar.stop();
				LOGGER.info("FAB GET PERF CHAR ELAPSED TIME : "+swPerfChar.getTime());

				/**
				 * LOAD WEIGHT CHARACTERISTICS SECTION
				 * */
				StopWatch swWeightCharacteristics = new StopWatch();
				swWeightCharacteristics.start();
				//SPEC: Release SR18x.6.0 - Modified for FAB  by Dominic on Date 25/02/2021 -- START
				//mapWeightCharResult.put(ConstantsUtil.NAME, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_NAME) : ConstantsUtil.EMPTY_STRING);
				mapWeightCharResult.put(ConstantsUtil.GROSSWEIGHT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTREAL) : ConstantsUtil.EMPTY_STRING);
				mapWeightCharResult.put(ConstantsUtil.WEIGHTUOM, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGGROSSWEIGHTUNITOFMEASURE) : ConstantsUtil.EMPTY_STRING);
				//mapWeightCharResult.put(ConstantsUtil.COMMENTS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_COMMENT) : ConstantsUtil.EMPTY_STRING);
				//mapWeightCharResult.put(ConstantsUtil.TYPE,  util.mapType((validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_TYPE)))?(String)resultMaps.get(ConstantsUtil.SELECT_TYPE) : ConstantsUtil.EMPTY_STRING));
				//SPEC: Release SR18x.6.0 - Modified for FAB  by Dominic on Date 25/02/2021 -- END
				mapWeightCharResult = util.filterMapList(mapWeightCharResult);
				swWeightCharacteristics.stop();
				LOGGER.info("FAB GET WEIGHT CHAR ELAPSED TIME : "+swWeightCharacteristics.getTime());

				/**
				 * LOAD SAP BOM as FED SECTION
				 * */
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				StopWatch swSapBomAsFed = new StopWatch();
				swSapBomAsFed.start();
				CalculateBOM clBom = new CalculateBOM();
	            //mpSapBomAsFedcResult = clBom.getSapBOMasFed(context,sContextObjectId);
				//mpSapBomAsFedcResult = FABBO.getSapBOMasFed(context,sContextObjectId);
				  SapBomAsFed sapBom = new SapBomAsFed();
		            mpSapBomAsFedcResult = sapBom.getSapBOMasFed(context,sContextObjectId);
		          //SPEC: Release SR18x.6.0 - Commented for FAB  by Dominic on Date 25/02/2021 -- START
					/* if (mpSapBomAsFedcResult.containsKey(ConstantsUtil.MAX)) {
						 mpSapBomAsFedcResult.remove(ConstantsUtil.MAX);
					}
					 if (mpSapBomAsFedcResult.containsKey(ConstantsUtil.MIN)) {
						 mpSapBomAsFedcResult.remove(ConstantsUtil.MIN);
					}*/
					//SPEC: Release SR18x.6.0 - Commented for FAB  by Dominic on Date 25/02/2021 -- END
					//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- START
					 if (mpSapBomAsFedcResult.containsKey(ConstantsUtil.AUTHORIZED)) {
						 mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZED);
					}
					 if (mpSapBomAsFedcResult.containsKey(ConstantsUtil.AUTHORIZEDTOUSE)) {
						 mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOUSE);
					}
					 if (mpSapBomAsFedcResult.containsKey(ConstantsUtil.AUTHORIZEDTOPRODUCE)) {
						 mpSapBomAsFedcResult.remove(ConstantsUtil.AUTHORIZEDTOPRODUCE);
					}
					//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- END
					//SPEC: 07/04/2022: Added by Manikanta for 22x DEV -- START
					 if (mpSapBomAsFedcResult.containsKey( ConstantsUtil.MAX)) {
						 mpSapBomAsFedcResult.remove( ConstantsUtil.MAX);
					}
					 if (mpSapBomAsFedcResult.containsKey(ConstantsUtil.MIN)) {
						 mpSapBomAsFedcResult.remove(ConstantsUtil.MIN);
					}
					//SPEC: 07/04/2022: Added by Manikanta for 22x DEV -- END
				swSapBomAsFed.stop();
				LOGGER.info("FAB GET SAP BOM AS FED ELAPSED TIME : "+swSapBomAsFed.getTime());
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				
				/**
				 * LOAD MARKET OF SALE (MOS) SECTION
				 * */
				
				/*String strCos = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COS_NAME));
				String strCosRestriction = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_COS_PGCOSRESTRICTION));
				
				
				//SPEC: <10.19.2020>: Modified for req 18x.5 ## -- START
				//mapCosResult.put(ConstantsUtil.COUNTRIESOFSALE, strCos);
				mapCosResult.put(ConstantsUtil.MARKETOFSALE, strCos);
				//mapCosResult.put(ConstantsUtil.COUNTRIESOFSALERESTRICTIONS,strCosRestriction);
				mapCosResult.put(ConstantsUtil.MARKETOFSALERESTRICTIONS,strCosRestriction);
				//mapCosResult.put(ConstantsUtil.DATEANDTIMEOFLASTCOSCALC, strCosDateAndTime);
				mapCosResult.put(ConstantsUtil.DATEANDTIMEOFLASTMOSCALC, strCosDateAndTime);
				//SPEC: <10.19.2020>: Modified for req 18x.5 ## -- END
				
				*/
				
				String strCosDateAndTime = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGCOSRUNDATE));
				mapCosResult = FABBO.getMarketOfSale(context,sContextObjectId);
				mapCosResult.put(ConstantsUtil.DATEANDTIMEOFLASTMOSCALC, strCosDateAndTime);
				
				mapCosResult = util.filterMapList(mapCosResult);
				
				/**
				 * LOAD RELATED SPEC SECTION
				 * */
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				StopWatch swRelatedSpec = new StopWatch();
				swRelatedSpec.start();
				// Guna modified for Defect 35928  18x.5.2 Release -- START
				mpRelatedSpecResult = util.updatePartSpec(context, resultMaps);
				//mpRelatedSpecResult = FABBO.updatePartSpec(context, resultMaps);
				// Guna modified for Defect 35928  18x.5.2 Release -- END
				swRelatedSpec.stop();
				LOGGER.info("FAB  Related Spec ELAPSED TIME : "+swRelatedSpec.getTime());
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- END
				
				/**
				 * LOAD REFERENCE DOCS SECTION
				 * */
				StopWatch swReference= new StopWatch();
				swReference.start();
				mapReferenceDocs =  mcop.updateRefDocs(context, resultMaps);
				swReference.stop();
				LOGGER.info("FAB  Reference ELAPSED TIME : "+swReference.getTime());

				
				/**
				 * LOAD RELATED ATS SECTION
				 * */
				StopWatch swAts = new StopWatch();
				swAts.start();
				mpRelatedATS=util.getRelatedAts(context, doFAB);
				
				mpRelatedATS=util.filterMapList(mpRelatedATS);
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- START
				String sHasATSAttrVal = util.checkHasATSForSIS(context,resultMaps);
				mpHeaderResult.put(ConstantsUtil.HASATS, sHasATSAttrVal);
				/*if(!mpRelatedATS.isEmpty()){
					mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_YES);
				}else{
					mpHeaderResult.put(ConstantsUtil.HASATS, ConstantsUtil.SYMBL_NO);
				}*/
				//SPEC: Release SR18x.5.2 - Added for Defect# 38162  by gaikwad.tg on Date 10 Feb 2021 -- END
				
				if(bManufacturerView || bSupplierView) {
					mpRelatedATS=util.filterPhase(mpRelatedATS);
				}
				swAts.stop();
				LOGGER.info("FAB ATS ELAPSED TIME : "+swAts.getTime());
				
				/**
				 * LOAD MASTER ATTRIBUTE DATA SECTION
				 * */
				
				StopWatch swMasterAttrib = new StopWatch();
				swMasterAttrib.start();
				mpMasterAttribute = util.getMasterAttributes(context,sContextObjectId,"FAB");
				if(bManufacturerView) {
					mpMasterAttribute=util.filterPhase(mpMasterAttribute);
				}
				mpMasterAttribute = util.filterMapList(mpMasterAttribute);
				swMasterAttrib.stop();
				LOGGER.info("FAB GET MASTER ATTRIB ELAPSED TIME : "+swMasterAttrib.getTime());
				
				/**
				 * MASTER SPECIFICATION
				 * */
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				StopWatch swmpMasterSpecs = new StopWatch();
				swmpMasterSpecs.start();
				//SPEC: Modified for Defect#37656 1.0.2 Release - Jwala -- START
				//we have all the parameters are available in Common method. Hence pointing to common method
				mpMasterSpecs = util.getMasterSpecs(context,sContextObjectId);
				//mpMasterSpecs = FABBO.getMasterSpecs(context,sContextObjectId);
				//SPEC: Modified for Defect#37656 1.0.2 Release - Jwala -- START
				swmpMasterSpecs.stop();
				LOGGER.info("FAB MASTER SPECS ELAPSED TIME : "+swmpMasterSpecs.getTime());
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- START
				mpAlternates = commonBO.getAlternates(context, sContextObjectId);
				mpAlternates = util.filterMapList(mpAlternates);
				//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 19/03/2021 -- START
				//SPEC: Release SR18x.6.0.1 Modified by Dominic  on Date 18/05/2021 --START
				//if(bAllInfoView)
				if(bAllInfoView || bManufacturerView)
				{
				//SPEC: Release SR18x.6.0.1 Modified by Dominic  on Date 18/05/2021 --END
				//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 19/03/2021 -- END
					mpRegistrationDetails = commonBO.getRegistrationDetails(context, sContextObjectId);
					mpRegistrationDetails = util.filterMapList(mpRegistrationDetails);
				//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 19/03/2021 -- START
				}
				//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 19/03/2021 -- END
				//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- END
				//SPEC: Release SR18x.6. Added by Dominic on Date 11/03/2021 --START
				mpAttribResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.ORIGINATED, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATED)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.RELEASEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_DATE)) : ConstantsUtil.EMPTY_STRING);
				/**
				 * SUBSTANCES & MATERIALS SECTION
				 * */
				PackagingMaterialPartBO pmpBO = new PackagingMaterialPartBO();
				mpMaterialResult = pmpBO.getSubstances(context,resultMaps);
				if(bSupplierView || bManufacturerView) {
					mpMaterialResult=util.filterPhase(mpMaterialResult);
					mpMaterialResult=util.filterMapList(mpMaterialResult);
				}
				
				//Added by Jwala for 22x Development Req 42996 -- START
				boolean isUserCMandSP = BObjutil.isUserCMandSP(context, objId);
				//Added by Jwala for 22x Development Req 42996 -- END
				
				mpMEPResult = util.getPQREquivalents(context, resultMaps, true, ConstantsUtil.RELATIONSHIP_MANUFACTURINGEQUIVALENT,sUserType);
				
				if(bManufacturerView || bSupplierView){
					mpMEPResult.remove(ConstantsUtil.PQRBA);
					mpMEPResult.remove(ConstantsUtil.PQRPCP);
					//Modified by Jwala for 22x Development Req 42996 -- START
					if(bSupplierView && !isUserCMandSP){
						mpMEPResult.remove(ConstantsUtil.PQRPLANTS);
					}
					//Modified by Jwala for 22x Development Req 42996 -- END
				}
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- START
				if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
					mpMEPResult = new HashMap<String,String>();
                }
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- END
				
				mpSEPResult = util.getPQREquivalents(context, resultMaps, false, ConstantsUtil.RELATIONSHIP_SUPPLIEREQUIVALENT,sUserType);
				
				if(bManufacturerView || bSupplierView){
					mpSEPResult.remove(ConstantsUtil.PQRBA);
					mpSEPResult.remove(ConstantsUtil.PQRPCP);
					//Modified by Jwala for 22x Development Req 42996 -- START
					if(bSupplierView && !isUserCMandSP){
						mpSEPResult.remove(ConstantsUtil.PQRPLANTS);
					}
					//Modified by Jwala for 22x Development Req 42996 -- END
				}
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- START
				if (strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFCMVIEW) || strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)) {
					mpSEPResult = new HashMap<String,String>();
                }
				//SPEC: 23-12-2022: Satyam added for Req 34055 -- END
				/**
				 * LOAD IP CLASSES SECTION
				 */
				StringList slIpSelects = new StringList();
				slIpSelects.add(ConstantsUtil.SELECT_NAME);
				slIpSelects.add(ConstantsUtil.SELECT_ID);
				slIpSelects.add(ConstantsUtil.SELECT_CURRENT);
				slIpSelects.add(ConstantsUtil.SELECT_TYPE);
				slIpSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
				mpIpSecuritySetting =FABBO.getIpClass(context, doFAB, slIpSelects);
				/**
				 * LOAD SECURITY SECTION
				 * */
				StopWatch swSecurity = new StopWatch();
				CommonBusUtilBO commonBo = new CommonBusUtilBO();
				swSecurity.start();
				mpSecurity =FABBO.updateSecurity(resultMaps);
				swSecurity.stop();
				LOGGER.info("FAB  Security ELAPSED TIME : "+swSecurity.getTime());
				/**
				 * LOAD ORGANIZATION DATA SECTION
				 * */
				StopWatch swOrganization = new StopWatch();
				swOrganization.start();
				mpOrganization.put(ConstantsUtil.PRIMARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGPRIMARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization.put(ConstantsUtil.SECONDARYORGANIZATION, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME)))?(String)resultMaps.get(ConstantsUtil.SELECT_RELATIONSHIP_PGSECONDARYORGANIZATION_NAME) : ConstantsUtil.EMPTY_STRING);
				mpOrganization = util.filterMapList(mpOrganization);
				swOrganization.stop();
				LOGGER.info("FAB Organization ELAPSED TIME : "+swOrganization.getTime());
				//SPEC: Release SR18x.6. Added by Dominic on Date 11/03/2021 --END
				
				/**
				 *  SUSTAINABILITY
				 **/
				//Added by Ketan for Req. no. 48322 -- START
				mpSustainability.put(ConstantsUtilIRM.PGPACKAGECOMPOPTPROPERTIES, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGECOMPONENTOPTICALPROPERTIES) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGPACKAGEDURABILITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGEDURABILITY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPACKAGEDURABILITY) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGMATERIALTHICKNESS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALTHICKNESS)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALTHICKNESS) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGMATERIALDENSITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALDENSITY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGMATERIALDENSITY) : ConstantsUtil.EMPTY_STRING);
				mpSustainability.put(ConstantsUtilIRM.PGPAPERDISSOLVABILITY, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY)))?(String)resultMaps.get(ConstantsUtilIRM.SELECT_ATTRIBUTE_PGPAPERDISSOLVABILITY) : ConstantsUtil.EMPTY_STRING);
				//Added by Ketan for Req. no. 48322 -- END
			}

			if(bAllInfoView) {
				/**
				 * LOAD BASIC ATTRIBUTE DATA SECTION
				 * */
				mpAttribResult.put(ConstantsUtil.OWNER, PersonUtil.getFullName(context,(String)resultMaps.get(ConstantsUtil.SELECT_OWNER)));
				mpAttribResult.put(ConstantsUtil.OBSOLETEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVEDATE)) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.OBSOLETECOMMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT)))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_PGARCHIVECOMMENT) : ConstantsUtil.EMPTY_STRING);
				mpAttribResult.put(ConstantsUtil.CLASSIFICATION, (sClassifictaion));
				
				//SPEC: Release SR18x.6.0 - Added by Amman on Apr 1, 2021 for Internal Defect -- START
				mpAttribResult.put(ConstantsUtil.LASTUPDATEUSER,  util.getLastUpdatedUser(context, sContextObjectId));
				//SPEC: Release SR18x.6.0 - Added by Amman on Apr 1, 2021 for Internal Defect -- END
				
				/**
				 * LOAD LIFECYCLE SECTION
				 * */
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- START
				String sPhysicalId = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID))?(String)resultMaps.get(ConstantsUtil.SELECT_PHYSICAL_ID):ConstantsUtil.EMPTY_STRING;
				String[] changeargs={objId,sPhysicalId};
				StopWatch swLifecycle = new StopWatch();
				swLifecycle.start();
				//SPEC: <11.20.2020>: Chandra Modified for Defect :37529 ## --START
				mpLifeCycleApproval = util.getCOName(context, changeargs);
				//mpLifeCycleApproval = FABBO.getCOName(context, changeargs);
				//SPEC: <11.20.2020>: Chandra Modified for Defect :37529 ## --END
				//SPEC: Release SR18x.6. Modified by Dominic on Date 09/03/2021 --START
				mpLifeCycleApproval.put(ConstantsUtil.APPROVER,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6. Modified by Dominic on Date 09/03/2021 --END
				
				swLifecycle.stop();
				LOGGER.info("FAB GET LIFECYCLE ELAPSED TIME : "+swLifecycle.getTime());
				//SPEC: <10.11.2020>: Modified for req 18x.5 ## -- END
				
				mpAttribResult.put(ConstantsUtil.CO, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO)))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING);
				//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 01/03/2021 -- START
				mpAttribResult.put(ConstantsUtilIRM.COCA, (validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.CO))?(String)mpLifeCycleApproval.get(ConstantsUtil.CO) : ConstantsUtil.EMPTY_STRING));
				//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 01/03/2021 -- END
				
				/**
				 * LOAD PLANTS SECTION
				 * */
				StopWatch swPlant = new StopWatch();
				swPlant.start();
				mpPlantResult = FABBO.updatePlantInfo(resultMaps);
				swPlant.stop();
				LOGGER.info("FAB Plant ELAPSED TIME : "+swPlant.getTime());

				
				/**
				 * LOAD OWNERSHIP SECTION
				 * */
				//SPEC: Release SR18x.6. Modified by Dominic on Date 09/03/2021 --START
				//SPEC: <11.20.2020>: Chandra Modified for Defect :37529 ## --START
				mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS)))?(String)mpLifeCycleApproval.get(ConstantsUtil.TASKAPPROVERS) : ConstantsUtil.EMPTY_STRING);
				//mapOwnerShipResult.put(ConstantsUtil.APPROVERS,(validator.isNotNullOrEmpty((String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME)))?(String)mpLifeCycleApproval.get(ConstantsUtil.APPROVER_FULLNAME) : ConstantsUtil.EMPTY_STRING);
				//SPEC: <11.20.2020>: Chandra Modified for Defect :37529 ## --END
				//SPEC: Release SR18x.6. Modified by Dominic on Date 09/03/2021 --END
				mapOwnerShipResult.put(ConstantsUtil.ORIGINATOR, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR)))?(String)resultMaps.get(ConstantsUtil.SELECT_ORIGINATOR) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.SEGMENT, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.STRSEGMENT)))?(String)resultMaps.get(ConstantsUtil.STRSEGMENT) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.LASTUPDATEDATE, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)))?validator.DateFormatter((String)resultMaps.get(ConstantsUtil.SELECT_MODIFIED)) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult.put(ConstantsUtil.COOWNERS, (validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.COOWNERS)))?(String)resultMaps.get(ConstantsUtil.COOWNERS) : ConstantsUtil.EMPTY_STRING);
				mapOwnerShipResult = util.filterMapList(mapOwnerShipResult);

				
				String FileCapturedFie = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_CAPTURED));
				String FileFormats = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FORMAT_FILE));
				String FileName = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_NAME));
				String FileSize = validator.getEquivalentString(resultMaps.get(ConstantsUtil.STR_FILE_SIZE));
				//SPEC Added on 12-Dec-2020 by Chandra for Defect 37746 ##--END	
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- START
				StringBuilder sbFileSize = new StringBuilder();
				if(!FileSize.isEmpty()) {
					String[] strFileSize=FileSize.split(ConstantsUtil.SYMBL_BACKSLASH_PIPE);
					for (int i = 0; i < strFileSize.length; i++) {
						String strEachFileSize = strFileSize[i];
						double dFileSize = Double.parseDouble(strEachFileSize);
						dFileSize = dFileSize/1024;
						strEachFileSize=Double.toString(dFileSize).format("%.2f", dFileSize);
						sbFileSize.append(strEachFileSize).append(" KB").append(ConstantsUtil.SYMBL_PIPE);
					}
				}
				//SPEC: 29-06-2022: Pooja Added for Internal Defect -- END
				mpFiles.put(ConstantsUtil.ACTION, FileCapturedFie);
				mpFiles.put(ConstantsUtil.FILESFORMAT, FileFormats);
				mpFiles.put(ConstantsUtil.FILESNAMES, FileName);
				mpFiles.put(ConstantsUtil.FILESSIZES, sbFileSize.toString());
				//SPEC: <10.12.2020>: Added for req 18x.5 ## -- END
			}

			
			hmAttrib.put(ConstantsUtil.HEADERCONTENT, mpHeaderResult);
			hmAttrib.put(ConstantsUtil.ATTRIBUTESOBJECT, mpAttribResult);
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- START
			if(bAllInfoView) {
				hmAttrib.put(ConstantsUtil.ORGANIZATIONSOBJECT, mpOrganization);
			}
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- END
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- START
			/**
			 * LOAD PACKAGING CERTIFICATIONS
			 * */
			// Added by Jwala for the req 4945 - START
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				StopWatch swPkgCert = new StopWatch();
				swPkgCert.start();
				mpCertification = CopBO.getPackagingCertificationsList(context, objId,(String)resultMaps.get(ConstantsUtil.SELECT_TYPE));
				swPkgCert.stop();
				LOGGER.info("PACKAGING CERTIFICATIONS ELAPSED TIME : "+swPkgCert.getTime());
			}
			
			if(!strPDFView.equalsIgnoreCase(ConstantsUtilIRM.PDFSPVIEW)){
				hmAttrib.put(ConstantsUtilIRM.PACKAGINGCERTIFICATIONS, mpCertification);
			}
			// Added by Jwala for the req 4945 - END
			//SPEC: Modified by Ajay for Req. no. 30189 START
			/**
			 * LOAD EXTENDED SECTION
			 * */
			mpExtendedAttribute = BObjutil.getExtendedAtrributes(context, objId);
			//SPEC: Modified by Ajay for Req. no. 30189 END
			//SPEC: 10/06/2022: Added by Manikanta for 22x DEV Req 41754-- END
			hmAttrib.put(ConstantsUtil.NOTES, mpNotes);
			hmAttrib.put(ConstantsUtil.BILLOFMATERIALS, mpEBOMResult);
			hmAttrib.put(ConstantsUtil.SUBSTITUTEPARTS, mpSubstitute);
			hmAttrib.put(ConstantsUtil.PERFORMANCECHARACTERISTIC, mpPerformChar);
			hmAttrib.put(ConstantsUtil.WEIGHTCHARACTERISTIC, mapWeightCharResult);
			hmAttrib.put(ConstantsUtil.SAPBOMASFED, mpSapBomAsFedcResult);
			hmAttrib.put(ConstantsUtil.MARKETOFSALE, mapCosResult);
			hmAttrib.put(ConstantsUtil.PLANTS, mpPlantResult);
			hmAttrib.put(ConstantsUtil.REFERENCEDOCUMENTS, mapReferenceDocs);
			
			//SPEC: <10.11.2020>: Commented for req 18x.5 ## -- START
			/*
			hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSFROM,mpDerivedFromResult);
			hmAttrib.put(ConstantsUtil.LISTDERIVEDPARTSTO,mpDerivedToResult);
			hmAttrib.put(ConstantsUtil.MASTERATTRIBUTES, mpMasterAttribute);
			*/
			//SPEC: <10.11.2020>: Commented for req 18x.5 ## -- END
			
			hmAttrib.put(ConstantsUtil.LIFECYCLEAPPROVALPOWERVIEW, mpLifeCycleApproval);
			hmAttrib.put(ConstantsUtil.OWNERSHIP, mapOwnerShipResult);
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- START
			if(bAllInfoView) {
				mpSecurity.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.SECURITY, mpSecurity);
			}
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- END
			hmAttrib.put(ConstantsUtil.RELATEDATS, mpRelatedATS);
			hmAttrib.put(ConstantsUtil.RELATEDSPECIFICATIONS, mpRelatedSpecResult);
			hmAttrib.put(ConstantsUtil.MASTERSPECIFICATIONS, mpMasterSpecs);
			hmAttrib.put(ConstantsUtil.MANUFACTUREREQUIVALENTS, mpMEPResult); 
			hmAttrib.put(ConstantsUtil.SUPPLIEREQUIVALENTS, mpSEPResult);
			//Added by Ketan for Req. no. 48322 -- START
			hmAttrib.put(ConstantsUtilIRM.SUSTAINABILITY, mpSustainability);
			//Added by Ketan for Req. no. 48322 -- END
			//SPEC: <10.11.2020>: Added for req 18x.5 ## -- START
			hmAttrib.put(ConstantsUtil.SUBSTANCESMATERIALS, mpMaterialResult);
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- START
			if(bAllInfoView) {
				mpIpSecuritySetting.remove(ConstantsUtil.HASCLASSACCESS);
				hmAttrib.put(ConstantsUtil.IPSECURITYSETTING, mpIpSecuritySetting);
			}
			//SPEC: 07/04/2022: Modified by Manikanta for 22x DEV -- END
			hmAttrib.put(ConstantsUtil.FILES, mpFiles);
			//SPEC: <10.11.2020>: Added for req 18x.5 ## -- END
			//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- START
			hmAttrib.put(ConstantsUtil.ALTERNATES, mpAlternates);
			hmAttrib.put(ConstantsUtilIRM.REGISTRATIONDETAILS, mpRegistrationDetails);
			//SPEC: Release SR18x.6.0 - Added for FAB  by Dominic on Date 25/02/2021 -- END
			hmAttrib.put(ConstantsUtilIRM.EXTENDED_ATTRIBUTE, mpExtendedAttribute);//SPEC: Modified by Ajay for Req. no. 30189
			
			pool.checkIn(context);
			sp.stop();
			LOGGER.info("FAB Execution TIME::" + sp.getTime() +"  " + "FAB OBJECT NAME::"+resultMaps.get(ConstantsUtil.SELECT_NAME));
			
			if(sComp.equals(ConstantsUtilIRM.FAB) || sComp.equals(ConstantsUtilIRM.STATE_PRILIMNARY)) {
				context.close();
			}

		} catch (IOException e) {
			LOGGER.error("Unable to getFABdetails "+e);
		} catch (MatrixException e) {
			LOGGER.error("Unable to getFABdetails "+e);
		} finally {
			if(context!=null) {
				context.close();
			}
		}
		
		return hmAttrib;
	}


}
