package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaPGContactService {

	public HashMap<String, Map<String, String>> getPersondata(Environment env, Map<String, String> mUserDetails) throws Exception;
}
