package com.pg.us.specanywhere_enovia.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;

public interface EnoviaARMPCompService {
	public HashMap<String, HashMap<String, Map<String, String>>> getARMPCompdata(String objId, Environment env) throws Exception; 

}
