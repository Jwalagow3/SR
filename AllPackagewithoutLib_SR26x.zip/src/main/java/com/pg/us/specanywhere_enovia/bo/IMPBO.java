/**
 * Project 		: SpecsAnywhere
 * Program 		: IMPBO
 * Author  		: Infosys Ltd.
 * Description 	: 
 */

package com.pg.us.specanywhere_enovia.bo;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.pg.us.specanywhere_enovia.security.SecurityService;
import com.pg.us.specanywhere_enovia.utility.BusObjectAttribUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtil;
import com.pg.us.specanywhere_enovia.utility.ConstantsUtilIRM;
import com.pg.us.specanywhere_enovia.utility.StringValidatorUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;

public class IMPBO {

	private static final long serialVersionUID = -5442107496256036512L;
	private static Logger LOGGER = Logger.getLogger(IMPBO.class);
	BusObjectAttribUtil util  = new BusObjectAttribUtil();

	public IMPBO() {
		// empty constructor
	}

	
	/**
	 * Method Name 			: getIMPBBO
	 * Method Description 	: Initialization of business objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws MatrixException
	 */
	public BusinessObject getIMPBBO(Context context, String oId) throws MatrixException {
		try {
			BusinessObject bo = new BusinessObject(oId);
			return bo;
		} catch (MatrixException e) {
			LOGGER.error("Error: Unable to initialize businessobject for ID: " + oId);
			throw e;
		}
	}

	
	/**
	 * Method Name 			: getIMPBDO
	 * Method Description 	: Initialization of domain objects with their corresponding IDs
	 * @param context
	 * @param oId
	 * @return
	 * @throws Exception
	 */
	public DomainObject getIMPBDO(Context context, String oId) throws Exception {
		try {
			DomainObject doObj = new DomainObject(oId);
			return doObj;
		} catch (Exception e) {
			LOGGER.error("Error: Unable to initialize domainobject for ID: " + oId);
			throw e;
		}
	}
	
	
	/**
	 * Method Name 			: getIMPSelectableMap
	 * Method Description 	:
	 * @param context
	 * @return
	 * @throws MatrixException
	 */
	public static Map<String, StringList> getIMPSelectableMap(Context context) throws MatrixException {
		StringList busSelect = new StringList();
		Map<String, StringList> mapSelecables = new HashMap<String, StringList>();
		busSelect.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context)); // Gets all basic attribute info
		busSelect.addAll(getCommonDataBusSelectable(context));
		mapSelecables.put(ConstantsUtil.BUS_SELECTS, busSelect);
		return mapSelecables;
	}
	
	
	/**
	 * Method Name 			: getCommonDataBusSelectable
	 * Method Description 	:
	 * @param context
	 * @return
	 */
	private static StringList getCommonDataBusSelectable(Context context) {
		StringList busSelect = new StringList();
		
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_INTERNAL_MATERIAL_FOR);
		busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_NAME);
		busSelect.add(ConstantsUtil.SELECT_CLASSIFIED_ITEM_ID);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EFFECTIVITYDATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_TITLE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGCLASSIFICATION);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_EXPIRATION_DATE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_PGSAPTYPE);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_MANUFACTURER);
		busSelect.add(ConstantsUtil.SELECT_ATTRIBUTE_GPSORIGINATED);
		busSelect.add(ConstantsUtil.SELECT_REL_MCPRF);
		
		//SPEC: 03-17-2020: Added for 18x.6 DEV by Sanjeeva -- START
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONLEVEL);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_EXTERNALREVISIONDATE);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_MATERIALNUMBER);
		busSelect.add(ConstantsUtilIRM.SELECT_ATTRIBUTE_STANDARDMATERIALNUMBER);
		//SPEC: 03-17-2020: Added for 18x.6 DEV by Sanjeeva -- END
		
		return busSelect;
	}

	
	/**
	 * Method Name 			: updateMaterials
	 * Method Description 	:
	 * @param context
	 * @param dob
	 * @return
	 */
	public Map<String, String> updateMaterials(Context context ,DomainObject dob)
	{
		Map<String, String> mpComp = new HashMap<String, String>();

		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID= new StringBuilder();
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbQUOM = new StringBuilder();
		
		StringBuilder sbTitle=new StringBuilder();
		StringBuilder sbDesc=new StringBuilder();
		StringBuilder sbCurrent=new StringBuilder();
		StringBuilder sbQTY=new StringBuilder();
		StringBuilder sbMaxPercent=new StringBuilder();
		StringBuilder sbMinPercent=new StringBuilder();
		
		StringBuilder sbApplicaton=new StringBuilder();

		StringBuilder sbQST = new StringBuilder();
		StringBuilder sbFlags = new StringBuilder();
		
		StringBuilder sbIsCont = new StringBuilder();
		StringBuilder sbCAS = new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbClassfied = new StringBuilder();
		StringBuilder sbIPClassAttr = new StringBuilder();
		
		
		StringList slBusSelects = new StringList();
		slBusSelects.add(ConstantsUtil.SELECT_NAME);
		slBusSelects.add(ConstantsUtil.SELECT_ID);
		slBusSelects.add(ConstantsUtil.SELECT_TYPE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCENAME);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
		slBusSelects.add(ConstantsUtil.SELECT_CURRENT);
		slBusSelects.add(ConstantsUtil.SELECT_REVISION);
		slBusSelects.add(ConstantsUtil.SELECT_DESCRIPTION);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
		slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
		
		StringList slRelSelects = new StringList();
		
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
		slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
		slRelSelects.add(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
		slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
		StringList list = StringList.create(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG,
				ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT,
				ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
		slRelSelects.addAll(list);
		
		MapList mlCopmonentsList = new MapList();;
		try 
		{
			mlCopmonentsList = dob.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, false, true, (short) 0,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
				if (util.isModificatinRequired()) {
					mlCopmonentsList=util.filterPhase(mlCopmonentsList);
				}
				if(ConstantsUtil.PG_CM.equals(util.getUserType())){
					mlCopmonentsList=util.filterPhase(mlCopmonentsList);
				}		
			
			mlCopmonentsList=getUsageFlags(mlCopmonentsList);
				
			Iterator objectListItr = mlCopmonentsList.iterator();

			while(objectListItr.hasNext())
			{
				Map objectMap = (Map) objectListItr.next();

				String sName=(String)objectMap.get(ConstantsUtil.SELECT_NAME);
				String sID=(String)objectMap.get(ConstantsUtil.SELECT_ID);
				String sType=(String)objectMap.get(ConstantsUtil.SELECT_TYPE);
				String sTitle=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCENAME);
				String sMin=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
				String sQTY=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
				String sMax=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
				String  strQST	=ConstantsUtil.EMPTY_STRING;
				String sQSTOCOMP=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
				String sFlags=(String)objectMap.get(ConstantsUtil.FLAGS);
				String sIsTarget=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
				
				String sQUOM=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
				String sISCont=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
				String sCAS=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);

				String sCurrent=(String)objectMap.get(ConstantsUtil.SELECT_CURRENT);
				String sRev=(String)objectMap.get(ConstantsUtil.SELECT_REVISION);
				String sDesc=(String)objectMap.get(ConstantsUtil.SELECT_DESCRIPTION);

				
				String strClassFied=(String)objectMap.get(ConstantsUtil.RELATIONSHIP_IPCLASS_NAME);
				String sIPClassfication=(String)objectMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
						
				util.formatData(sbClassfied,strClassFied);
				util.formatData(sbIPClassAttr,sIPClassfication);
				
				/*util.formatData(sbName,sName);
				util.formatData(sbID,sID);
				util.formatData(sbType,sType);*/
				util.formatData(sbName,sName);
				util.formatData(sbID,sID);
				util.formatData(sbType,sType);
				util.formatData(sbTitle,sTitle);
				util.formatData(sbMinPercent,sMin);
				util.formatData(sbQTY,sQTY);
				util.formatData(sbMaxPercent,sMax);
				util.formatData(sbQUOM,sQUOM);
				util.formatData(sbIsCont,sISCont);
				util.formatData(sbFlags,sFlags);
				util.formatData(sbCAS,sCAS);
				util.formatData(sbCurrent,sCurrent);
				util.formatData(sbRev,sRev);
				util.formatData(sbDesc,sDesc);
				util.formatData(sbApplicaton,ConstantsUtil.EMPTY_STRING);
				
				if(UIUtil.isNotNullAndNotEmpty(sQSTOCOMP) && UIUtil.isNotNullAndNotEmpty(sIsTarget)){
					 strQST	 = (sQSTOCOMP.equalsIgnoreCase("TRUE"))? ConstantsUtil.QS:
									(sIsTarget.equalsIgnoreCase("TRUE"))? ConstantsUtil.TARGET_COMPONENT : "";
						}
				util.formatData(sbQST,strQST);
			}

			mpComp.put(ConstantsUtil.NAME, sbName.toString());
			//SPEC: <13.10.2020>: Commented for the Release 18x5 -- START--
			//mpComp.put(ConstantsUtil.ID, sbID.toString());
			//SPEC: <13.10.2020>: Commented for the Release 18x5 -- END --
			mpComp.put(ConstantsUtil.TYPE,sbType.toString());
			mpComp.put(ConstantsUtil.TITLE, sbTitle.toString());
			
			mpComp.put(ConstantsUtil.MIN, sbMinPercent.toString());
			mpComp.put(ConstantsUtil.DRYWEIGHT, sbQTY.toString());
			mpComp.put(ConstantsUtil.MAX, sbMaxPercent.toString());
			mpComp.put(ConstantsUtil.QUANTITY,sbQUOM.toString());
			
			mpComp.put(ConstantsUtil.QSTARGET,sbQST.toString());
			mpComp.put(ConstantsUtil.FLAGS, sbFlags.toString());
			
			mpComp.put(ConstantsUtil.IMPURITY,sbIsCont.toString());
			mpComp.put(ConstantsUtil.CAS,sbCAS.toString());
			mpComp.put(ConstantsUtil.FUNCTIONS,sbApplicaton.toString());
			mpComp.put(ConstantsUtil.STATE, sbCurrent.toString());
			mpComp.put(ConstantsUtil.REV,sbRev.toString());
			mpComp.put(ConstantsUtil.DESCRIPTION, sbDesc.toString());
			
			mpComp.put(ConstantsUtil.SECURITY, sbClassfied.toString());
			mpComp.put(ConstantsUtil.IPCLASSES,sbIPClassAttr.toString());
			mpComp=util.verifyOwnership(context,mpComp);
			
		} catch (Exception e) {
			LOGGER.error("Exception in Program : IMPBO Method :updateMaterials "+e);
			return new HashMap();
		}
		
		return util.filterMapList(mpComp);
	}

	/**
	 * Method Name 			: getUsageFlags
	 * Method Description 	: Getting the Flags on the Materials
	 * @param resultMap
	 * @return
	 * @throws Exception
	 */
	public MapList getUsageFlags(MapList resultMap) throws Exception{
		
		String 	strResult = ConstantsUtil.EMPTY_STRING;
		StringList strList = new StringList();
		MapList mlfinalList = new MapList();
		try{

			Map mpTemp = new HashMap();
			Iterator itr = resultMap.iterator();
			while(itr.hasNext())
			{
				Map resMap = (Map) itr.next();
				String	 drugActive = (String) resMap.get(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
				String	 Colorant = (String) resMap.get(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
				String	 Preservative  = (String) resMap.get(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
				String	 rel = (String) resMap.get(DomainConstants.SELECT_NAME);
			
					if( UIUtil.isNotNullAndNotEmpty(drugActive) && UIUtil.isNotNullAndNotEmpty(Colorant) && UIUtil.isNotNullAndNotEmpty(Preservative))
					{
						if(drugActive.equalsIgnoreCase("Yes"))
							strList.add(ConstantsUtil.DRUG_ACTIVE);;
						 if(Colorant.equalsIgnoreCase("TRUE"))
							 strList.add(ConstantsUtil.COLORANT);;
						 if(Preservative.equalsIgnoreCase("Yes"))
							 strList.add(ConstantsUtil.PRESERVATIVE);;
					}
				resMap.put(ConstantsUtil.FLAGS, FrameworkUtil.join(strList, ","));
				mlfinalList.add(resMap);
		   } 	
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}
		
		return mlfinalList;
	}
	
	
	//Modified for Defect #37436 by Amman on 11/26/2020 -- START
	/**
	 * Method Name 			: getMaterialComposition
	 * Method Description 	:
	 * @param context
	 * @param dob
	 * @return
	 */
	public Map<String, String> getMaterialComposition(Context context, Map resultMaps)
	{
		Map<String, String> mpSubStanceResult = new HashMap<String, String>();
		
		StringValidatorUtil validator = new StringValidatorUtil();
		BusObjectAttribUtil util = new BusObjectAttribUtil();
		
		String sRawMatId = (String) resultMaps.get(ConstantsUtil.SELECT_ID);
		
		StringBuilder sbType = new StringBuilder();
		StringBuilder sbName = new StringBuilder();
		StringBuilder sbID	 =  new StringBuilder();
		StringBuilder sbRev = new StringBuilder();
		StringBuilder sbDesc = new StringBuilder();
		StringBuilder sbTitle = new StringBuilder();
		StringBuilder sbCurrent = new StringBuilder();
		StringBuilder sbCAS = new StringBuilder();
		StringBuilder sbCont = new StringBuilder();
		StringBuilder sbMAXWt = new StringBuilder();
		StringBuilder sbMInWt = new StringBuilder();
		StringBuilder sbQUOM = new StringBuilder();
		StringBuilder sbDRY = new StringBuilder();
		StringBuilder sbFunctions = new StringBuilder();
		StringBuilder sbtrClassFied = new StringBuilder();
		StringBuilder sbIPClassfication = new StringBuilder();
		StringBuilder sbQTS = new StringBuilder();
		StringBuilder sbUF = new StringBuilder();
		StringBuilder sbParentName = new StringBuilder();//Added by Ajay for 22x.06 Req.9264

		//SPEC: 03-05-2020: Added for 18x.6 DEV by Sanjeeva -- START
		StringBuilder sbStateRev = new StringBuilder();
		String strStateRev = new String();
		//SPEC: 03-05-2020: Added for 18x.6 DEV by Sanjeeva -- END
		String strStateRev1 = new String();
		try
		{
			DomainObject doComponent = new DomainObject(sRawMatId);
			StringList slBusSelects = new StringList();
			slBusSelects.addAll(BusObjectAttribUtil.getBasicInfoBusSelectable(context));
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME);
			slBusSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER);
			slBusSelects.add(ConstantsUtil.COMP_CLASSIITEM);
			
			StringList slRelSelects = new StringList();
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_USAGE);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_FILL);
			
			//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- START
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_PRESERVATIVE_FLAG);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_IS_COLORANT);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_ACTIVE_INGRIDIENT_FLAG);
			slRelSelects.add(ConstantsUtilIRM.SELECT_EBOM_NAME);
			//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- END
			
			
			//SPEC: Modified for Defect #38257 by Chandra on 01/27/2021 -- START
			
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_QSTOCOMPOSITE);
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_ID);
			slRelSelects.add(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION);
			//SPEC: Modified for Defect #38257 by Chandra on 01/27/2021 -- END
			
			
			//SPEC : Modified by Ganesh on 6-Jan-2021 for  Requirement 38258 --START
			
			/*MapList mlComponentsAnSubstance = doComponent.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE,
					ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, true, true, (short) 1,
					ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);*/
			//added by Ganesh
			
			slRelSelects.add(ConstantsUtil.SELECT_RELATIONSHIP_NAME);
			Pattern objType = new Pattern(ConstantsUtil.TYPE_MATERIAL);
            objType.addPattern(ConstantsUtil.TYPE_SUBSTANCE); 

            Pattern relType = new Pattern(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL);
            relType.addPattern(ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE);
            relType.addPattern(ConstantsUtil.RELATIONSHIP_SECURE_COMPONENT_SUBSTANCE);
            
			//MapList mlComponentsAnSubstance = doComponent.getRelatedObjects(context, ConstantsUtil.RELATIONSHIP_COMPONENT_SUBSTANCE+","+ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,
					//ConstantsUtil.SYMBL_ASTERISK, slBusSelects, slRelSelects, true, true, (short) 0,
					//ConstantsUtil.EMPTY_STRING, ConstantsUtil.EMPTY_STRING, ConstantsUtil.ZERO_LEVEL);
			
			MapList mlComponentsAnSubstance = doComponent.getRelatedObjects(context, 
					relType.getPattern(),
					objType.getPattern(), 
					slBusSelects, 
					slRelSelects, 
					false, 
					true, 
					(short) 0, //Expand level to all
					ConstantsUtil.EMPTY_STRING, 
					ConstantsUtil.EMPTY_STRING, 
					ConstantsUtil.ZERO_LEVEL);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- START
			doComponent.close(context);
			//SPEC: <08-23-2021>: Sanjeeva Added for Stress Testing Defect 44365  -- END
			
			//START :: gaikwad.tg
			mlComponentsAnSubstance = util.getSortedMaplistWithSequence(context, mlComponentsAnSubstance, sRawMatId);
			//mlComponentsAnSubstance.sort(ConstantsUtil.RELATIONSHIP_COMPONENT_MATERIAL,ConstantsUtil.ASCENDING,ConstantsUtil.STRING);
			//END :: gaikwad.tg
			String pType = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_TYPE));
			String pName = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_NAME));
			String pID	 =  validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_ID));
			String pRev = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_REVISION));
			String pDesc = validator.getStringEquivalentForSubstituteString(resultMaps.get(ConstantsUtil.SELECT_DESCRIPTION));
			//modified by Ganesh for defect 38544 ---->start
			String pTitle = validator.isNotNullOrEmpty((String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE))?(String)resultMaps.get(ConstantsUtil.SELECT_ATTRIBUTE_TITLE) : ConstantsUtil.EMPTY_STRING;
			//modified by Ganesh for defect 38544 ---->end
			util.formatData(sbType, util.mapType(pType));
			util.formatData(sbName, pName);
			util.formatData(sbID, pID);
			util.formatData(sbRev, pRev);
			util.formatData(sbDesc, pDesc);

			
			//SPEC: 03-15-2020: Added for 18x.6 DEV by Sanjeeva -- START
			String pCur = validator.getStringEquivalentForStringList(resultMaps.get(ConstantsUtil.SELECT_CURRENT));
			//strStateRev = strStateRev.concat(pCur).concat(ConstantsUtil.SYMBL_PIPE).concat(pRev);
			
			//SPEC: 03-22-2020: Added for 18x.6 DEV by Sanjeeva -- START
			//StringValidatorUtil  = new StringValidatorUtil();
			if (validator.isNotNullOrEmpty(pRev)) {
			strStateRev = strStateRev.concat(pCur).concat(ConstantsUtil.SYMBL_AND).concat(pRev);
			} else {
				strStateRev1 = strStateRev.concat(pCur);
			}
			//SPEC: 03-22-2020: Added for 18x.6 DEV by Sanjeeva -- END
			
			//util.formatData(sbStateRev, strStateRev);
			//SPEC: 03-15-2020: Added for 18x.6 DEV by Sanjeeva -- END
			
			//modified by Ganesh for defect 38544 ---->start 
			//util.formatData(sbTitle, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbTitle, pTitle);
			//modified by Ganesh for defect 38544 ---->end
			util.formatData(sbCurrent, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbCAS, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbQTS, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbUF, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbCont, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbMAXWt, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbMInWt, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbParentName, ConstantsUtil.EMPTY_STRING);//Added by Ajay for 22x.06 Req.9264
			//SPEC: 23/04/2021: Added for 18x.6 Defect-42721 by Guna -- START
			DomainObject domContextPart = DomainObject.newInstance(context, pID);
			String strTotalQuantytites = ConstantsUtil.EMPTY_STRING;
			BigDecimal dQuantites = new BigDecimal(0.0D);
			StringList slQuantities = DomainConstants.EMPTY_STRINGLIST;
			slQuantities = util.getNonContaminantQuantities(context, domContextPart);
			slQuantities.sort();
			for (int j = 0; j < slQuantities.size(); j++)
			{
				dQuantites = dQuantites.add(new BigDecimal((String)slQuantities.get(j)));
			}
			if (dQuantites.compareTo(new BigDecimal(0.0D)) != 0)
			{
				strTotalQuantytites = dQuantites.toPlainString();
			}
			util.formatData(sbDRY, strTotalQuantytites);
			//SPEC: 23/04/2021: Commented for 18x.6 Defect-42721 by Guna -- END
			
			//SPEC: 23/04/2021: Added for 18x.6 Defect-42721 by Guna -- START
			//SPEC: Release SR18x5.2- modified for Defect #36311 by Govind on Date 18/02/2021 start
			/*if(mlComponentsAnSubstance.size()>0)
				util.formatData(sbDRY, "100.0");
			else 
				util.formatData(sbDRY, ConstantsUtil.EMPTY_STRING);*/
			//SPEC: Release SR18x5.2- modified for Defect #36311 by Govind on Date 18/02/2021 start
			//SPEC: 23/04/2021: Commented for 18x.6 Defect-42721 by Guna -- END
			util.formatData(sbQUOM,ConstantsUtil.EMPTY_STRING);
			util.formatData(sbFunctions, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbtrClassFied, ConstantsUtil.EMPTY_STRING);
			util.formatData(sbIPClassfication, ConstantsUtil.EMPTY_STRING);
			//SPEC : Modified by Ganesh on 6-Jan-2021 for  Requirement 38258 --END
			
			//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- START
			ARMPBO armpbo = new ARMPBO();
			//SPEC: Modified for Defect #38257 by Chandra on 01/27/2021 -- START
			//mlComponentsAnSubstance=armpbo.getUsageFlags(mlComponentsAnSubstance);
			mlComponentsAnSubstance = util.getUsageFlags(context, mlComponentsAnSubstance);
			//SPEC: Modified for Defect #38257 by Chandra on 01/27/2021 -- END
			
			//SPEC: Added for Defect#37618 1.0.2 Release - Jwala -- END
			
			Iterator objectListItr2 = mlComponentsAnSubstance.iterator();
			
			//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- START
			//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
			//boolean showData = false;
			//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
			//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- END
			
			while(objectListItr2.hasNext())
			{
				Map objectMap2 = (Map) objectListItr2.next();
				String sType = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_TYPE));
				String sName = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_NAME));
				String strID	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ID));
				String sRev = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_REVISION));
				String sParentName	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtilIRM.SELECT_EBOM_NAME));

				//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- START
				//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- START
				/*showData=util.checkHasAccess(context, null, strID);
				
				if (!showData && util.isModificatinRequired()) {
				
					continue;
				}*/
				
				//SPEC: 05-11-2021: Added for 18x.6.0.1 Req# 33248 by Sanjeeva -- END
				//SPEC: 06-3-2021: Added for 18x.6.0.1 Req# 39652 by Sanjeeva -- END
				
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sDesc = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_DESCRIPTION));
				String sDesc = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_DESCRIPTION));
				//String sTitle = validator.getStringEquivalentForStringListWithComma(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME));
				String sTitle = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_SUBSTANCE_NAME));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sCurrent = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_CURRENT));
				sCurrent = sCurrent.replace(ConstantsUtil.APPROVED, ConstantsUtil.RELEASED);
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sCAS = validator.getStringEquivalentForStringListWithComma(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
				String sCAS = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_CASNUMBER));
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String sCont = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISCONTAMINANT));
				String sMAXWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MAXIMUMWEIGHT));
				String sMInWt = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_MINIMUMWEIGHT));
				String sQUOM = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITYUNITOFMEASURE));
				String sDRY = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QUANTITY));
				
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- START
				//String sFunctions = validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
				//SPEC: Modified for Defect #38263 by Chandra on 01/27/2021 -- START	
				//String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_REPORTED_FUNCTION));
				String sFunctions = validator.getStringEquivalentForSubstituteString(objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_APPLICATION));
				if (UIUtil.isNotNullAndNotEmpty(sFunctions)) 
				{
					sFunctions=util.getIdFromPhysicalIdFunction(context,sFunctions);
					
				}
				//SPEC: Modified for Defect #38263 by Chandra on 01/25/2021 -- END
				//SPEC: 12/04/2020: Modified for Defect 37782 by Amman -- END
				
				String strClassFied = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.COMP_CLASSIITEM));
				String sIPClassfication = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_PGIPCLASSIFICATION));
				String sQTS = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_QSTARGETLEVEL));
				//SPEC: Modified for Defect#37618 1.0.2 Release - Jwala -- START
				//String sUF = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_USAGE));
				
				//SPEC: Modified for Defect #38257 by Chandra on 01/27/2021 -- START
				//String sUF	 =  validator.getStringEquivalentForStringList(objectMap2.get(ConstantsUtil.FLAGS));
				String sUF	 =  validator.getStringEquivalentForStringListWithComma(objectMap2.get(ConstantsUtil.FLAGS));
				//SPEC: Modified for Defect #38257 by Chandra on 01/27/2021 -- END
				
				//SPEC: Modified for Defect#37618 1.0.2 Release - Jwala -- END
				String sTarget = validator.getStringEquivalentForStringList( objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_ISTARGETMATERIAL));
				
				//SPEC: Modified for Defect#37639 - Sumit -- START
				/*if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
					if(sTarget.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
						sQTS = ConstantsUtil.TARGET_MATERIAL;
					}else {
						sQTS = ConstantsUtil.QS;
					}
				}*/
				String sFill = (String)objectMap2.get(ConstantsUtil.SELECT_ATTRIBUTE_FILL);

				sQTS = sFill.equalsIgnoreCase("TRUE") ?  ConstantsUtil.QS : (sTarget.equalsIgnoreCase(ConstantsUtil.SYMBL_YES) ? ConstantsUtil.TARGET_MATERIAL : "");
				//SPEC: Modified for Defect#37639 - Sumit -- ENDS
				
				util.formatData(sbType, util.mapType(sType));
				util.formatData(sbName, sName);
				util.formatData(sbID, strID);
				util.formatData(sbRev, sRev);
				util.formatData(sbDesc, sDesc);
				util.formatData(sbTitle, sTitle);
				util.formatData(sbCurrent, sCurrent);
				util.formatData(sbCAS, sCAS);
				util.formatData(sbQTS, sQTS);
				util.formatData(sbUF, sUF);
				util.formatData(sbParentName, sParentName);//Added by Ajay for 22x.06 Req.9264


				
				if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_YES)) {
					sCont = ConstantsUtil.SYMBL_CAPTRUE;
				} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_NO)) {
					sCont = ConstantsUtil.SYMBL_CAPFALSE;
				}
				
				util.formatData(sbCont, sCont);
				
				if(!validator.isNotNullOrEmpty(sMInWt) || sMInWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sMInWt = ConstantsUtil.EMPTY_SPACE;
				}
				//Added by Ganesh for Internal defect--->START
				sMInWt=util.formattingDryValueToDisplay(context, sMInWt);
				//Added by Ganesh for Internal defect--->END
				//commented by Ganesh for Internal defect--->START
				/*if(!validator.isNotNullOrEmpty(sDRY) || sDRY.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sDRY = ConstantsUtil.EMPTY_SPACE;
				}*/
				//commented by Ganesh for Internal defect--->END
				if(!validator.isNotNullOrEmpty(sMAXWt) || sMAXWt.equalsIgnoreCase(ConstantsUtil.ZERO_SIZE)) {
					sMAXWt = ConstantsUtil.EMPTY_SPACE;
				}
				
				if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPTRUE)) {
					util.formatData(sbMAXWt, sDRY);
				} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPFALSE)) {
				//Added by Ganesh for Internal defect--->START
					sMAXWt=util.formattingDryValueToDisplay(context, sMAXWt);
				//Added by Ganesh for Internal defect--->START	
					util.formatData(sbMAXWt, sMAXWt);
				}
				
				util.formatData(sbMInWt, sMInWt);
				//Commented by Ganesh for Internal defect--->START
				/*if(sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPTRUE)) {
					util.formatData(sbDRY, sMAXWt);
				} else if (sCont.equalsIgnoreCase(ConstantsUtil.SYMBL_CAPFALSE)) {
					util.formatData(sbDRY, sDRY);
				}*/
				//Commented by Ganesh for Internal defect--->END
				//Added by Ganesh for Internal defect--->START
				String strTempDry = util.getDryValueToDisplay(context, objectMap2);
				strTempDry=util.formattingDryValueToDisplay(context,strTempDry);
				util.formatData(sbDRY, strTempDry);
				
				//Added by Ganesh for Internal defect--->END
				util.formatData(sbQUOM,sQUOM);
				util.formatData(sbFunctions, sFunctions);
				util.formatData(sbtrClassFied, strClassFied);
				util.formatData(sbIPClassfication, sIPClassfication);
		}
		mpSubStanceResult.put(ConstantsUtil.SECURITY, sbtrClassFied.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.IPCLASSES,sbIPClassfication.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.DESCRIPTION,sbDesc.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.TITLE,sbTitle.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.TYPE,sbType.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.NAME,sbName.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.REV,sbRev.toString().trim());
		//SPEC: 09-08-2022: Pooja Added for Internal Defect -- START
		//SPEC: 03-15-2020: Added for 18x.6 DEV by Sanjeeva -- START
		mpSubStanceResult.put(ConstantsUtil.STATE,strStateRev1.concat(sbCurrent.toString().trim()));
		//SPEC: 03-15-2020: Added for 18x.6 DEV by Sanjeeva -- END
		//SPEC: 09-08-2022: Pooja Added for Internal Defect -- END
		mpSubStanceResult.put(ConstantsUtil.CAS,sbCAS.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.IP,sbCont.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.MAX,sbMAXWt.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.MIN,sbMInWt.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.UOM,sbQUOM.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.DRYWEIGHT,sbDRY.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.FUNCTIONS,sbFunctions.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.ID, sbID.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.QSTARGET,sbQTS.toString().trim());
		mpSubStanceResult.put(ConstantsUtil.UF, sbUF.toString().trim());
		mpSubStanceResult.put(ConstantsUtilIRM.PARENT_NAME, sbParentName.toString().trim());//Added by Ajay for 22x.06 Req.9264

		
		//SPEC: 03-15-2020: Added for 18x.6 DEV by Sanjeeva -- START
		mpSubStanceResult.put(ConstantsUtilIRM.STATEREVISION, strStateRev.concat(sbCurrent.toString().trim()));
		//SPEC: 03-15-2020: Added for 18x.6 DEV by Sanjeeva -- END
		
	}catch(Exception e){
	
		LOGGER.error("Error from IMPBO:  getMaterialComposition"+e);
		return new HashMap();
	}
	return mpSubStanceResult;
	}
	//Modified for Defect #37436 by Amman on 11/26/2020 -- START
}
